//$Id$
package com.zoho.quick.livedesk.util;

import java.net.*;
import java.net.URL;
import java.net.HttpURLConnection;

import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.servlet.WebdriverApi;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.google.common.base.Function;

import com.zoho.livedesk.util.FileUtil;
import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.util.Util;

import com.zoho.quick.livedesk.SalesIQTestSV;
import com.zoho.quick.livedesk.LiveDeskTesting;
import com.zoho.quick.livedesk.SalesIQTestAsso;

import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;


public class SalesIQTestBasicTestCasesQuick extends TestCase{
    private static final int MYTHREADS = 200;
    private static int ncount = 0;
    //private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    //public Hashtable hashtable;
    public Hashtable result;
    public Hashtable servicedown;
    public Hashtable res;
    public Hashtable finalresult;
    public static boolean isstarted = false;
    public static boolean isended = false;
    long starttime;
    long endtime = 0L;
    String browser = "";
    Hashtable report;
    String url = "";
    public static long etime = 0L;
    public static Set<ExtentTest> etests = new HashSet<ExtentTest>();
    ArrayList<String> modules = new ArrayList(Arrays.asList("SU1","SU2","SC1","SC2","SD1","SD2","SP1","SP2","SB1","SB2","SW1","SW2","SCM1","SCM2","SI1","SI2","SI3","CM1","CM2","CM3","Login","STR1","STR2","STR3","STR4","AFH1","AFH2","AFH3","KBSK1","KBSK2","KBSK3","PER1","PER2","TRC1","TRC2","CHAT1","CHAT5","CHAT6","CHAT7","CHAT9","CHAT15","CHAT22","CHAT23","CHAT26","CHAT29","CHAT30","CHAT34","CHAT49","CHAT62","CHAT73","CHAT79","CHAT82","CHAT101"));

    Hashtable showstopper;

    public WebDriver setUpDriver() throws Exception
    {
        return Functions.setUp(true);
    }

    public boolean testingStarted() throws Exception
    {
        return isstarted;
    }

    public boolean testingEnded() throws Exception
    {
        return isended;
    }

    public void testInit() throws Exception
    {
        etests = new HashSet<ExtentTest>();
        res = new Hashtable();
        result = new Hashtable();
        servicedown = new Hashtable();
        report = new Hashtable();
        showstopper = new Hashtable();
        finalresult = new Hashtable();
        starttime = System.currentTimeMillis();

        ExecutorService executor = Executors.newFixedThreadPool(MYTHREADS);

        for (int i = 0; i <= 2; i++)
        {
            Runnable worker = new MyRunnable(i);
            executor.execute(worker);
        }
        executor.shutdown();

        while (!executor.isTerminated()) {}

        for(ExtentTest etest : etests)
        {
            ComplexReportFactory.closeTest(etest);
        }

        endtime = System.currentTimeMillis();

        setEndTime();
        calculateReport(result,endtime-starttime);

        String filePath = FileUtil.sendFileReport(report,res,showstopper,servicedown);
        //ChatUtil.sendChatResult(report,res,showstopper,servicedown,filePath,"Basic Test Cases",false);
        Util.buggyFinder(report,"Basic Test Cases",filePath);
        isended = true;
        Thread.sleep(5000);
        isended = false;

        finalresult.put("result",result);
        finalresult.put("servicedown",servicedown);
        finalresult.put("report",report);
        finalresult.put("SalesIQTestBasicTestCasesQuick","Basic Test Cases - Total Use Cases:"+report.get("TotalUseCases")+" Failure:"+report.get("Failure")+" ("+report.get("Failure_per")+"%)");

        System.out.println(" Result Hash >>>"+result);
        System.out.println(" Service down Hash >>>"+servicedown);
        System.out.println(" Report Hash >>> "+report);

        tearDown();
    }

    public Hashtable sendResult()
    {
        System.out.println(" Result Hash >>>"+finalresult.get("result"));
        System.out.println(" Service down Hash >>>"+finalresult.get("servicedown"));
        System.out.println(" Report Hash >>>"+finalresult.get("report"));
        return finalresult;
    }

    public void setEndTime() throws Exception
    {
        try
        {
            etime = System.currentTimeMillis();
        }
        catch(Exception e)
        {}
    }

    public long getEndTime() throws Exception
    {
        return etime;
    }

    private void calculateReport(Hashtable result, long timetaken)
    {
        try
        {
            timetaken = timetaken/1000;
            String time = "";

            if(timetaken > 60)
            {
                long s = timetaken % 60;
                long m = (timetaken / 60) % 60;
                long h = (timetaken / (60 * 60)) % 24;
                if(h > 0)
                {
                    if(h == 1)
                    {
                        time += h+" hour ";
                    }
                    else
                    {
                        time += h+" hours ";
                    }
                }
                if(m > 0)
                {
                    if(m == 1)
                    {
                        time += m+ " min ";
                    }
                    else
                    {
                        time += m+" mins ";
                    }
                }
                if(s > 0)
                {
                    if(s == 1)
                    {
                        time += s +" sec";
                    }
                    else
                    {
                        time += s +" secs";
                    }
                }
            }
            else
            {
                time = timetaken + " secs";
            }

            report.put("TimeTaken", time);

            int size = result.size();
            int success = 0;
            report.put("TotalUseCases", size);
            Set<String> keys = result.keySet();
            for(String key: keys){
                if((boolean) (""+result.get(key)).equals("true"))
                {
                    success++;
                }
                else
                {
                    res.put(KeyManager.getRealValue(key),"fail");
                    if(modules.contains(key))
                    {
                        showstopper.put(KeyManager.getRealValue(key),"failed");
                    }
                }
            }
            report.put("Success", success);
            report.put("Failure", size-success);
            int success_per = (success*100)/size;
            report.put("Success_per", success_per);
            report.put("Failure_per", 100-success_per);
            if(browser.contains("chrome"))
            {
                report.put("Browser", "chrome");
            }
            else if(browser.contains("firefox"))
            {
                report.put("Browser", "firefox");
            }
            else
            {
                report.put("Browser", "IE");
            }
            //String setup = ConfManager.getSetup();
            String setup = Util.siteNameout();
            if(setup.contains("labsalesiq"))
            {
                report.put("Setup", "LabSalesIQ");
            }
            else if(setup.contains("localzoho"))
            {
                report.put("Setup", "LocalZoho");
            }
            else if(setup.contains("presalesiq"))
            {
                report.put("Setup", "Pre Setup");
            }
            else if(setup.contains(".zoho"))
            {
                report.put("Setup", "IDC");
            }
            else
            {
                report.put("Setup", "-");
            }
            String loginsite = Util.siteNameout()+"/automation";
            report.put("URL", loginsite);
            //String build = WebdriverQAUtil.getBuildlable();
            String build = Util.buildlabel();

            report.put("Build", build);
        }
        catch(Exception e)
        {
            // System.out.println("Exception calculating report : "+e);
            // e.printStackTrace();
        }
    }
    @Override
    public void tearDown() throws Exception
    {
        //driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    public static TestSuite suite()
    {
        TestSuite suite = new TestSuite();
        suite.addTestSuite(SalesIQTestBasicTestCasesQuick.class);
        return suite;
    }

    public static void main(String[] args)
    {
        ConfManager.init();
        junit.textui.TestRunner.run(suite());
    }

    public class MyRunnable implements Runnable {
        private int fnum;

        MyRunnable(int fnum) {
            this.fnum = fnum;
        }

        @Override
        public void run() {

            try
            {
                if(fnum == 0 && LiveDeskTesting.isTest(LiveDeskTesting.modules))
                {
                    WebDriver driver = setUpDriver();
                    result.put("Login - Admin",Functions.login(driver,"admin_quick"));
                    if((boolean)result.get("Login - Admin"))
                    {
                        Hashtable f0 = LiveDeskTesting.test(driver,starttime);
                        result.putAll((Hashtable) f0.get("result"));
                        Util.getModulesResult((Hashtable) f0.get("result"),"Basic Test Cases - Admin");
                        servicedown.putAll((Hashtable) f0.get("servicedown"));
                    }
                    Functions.logout(driver,"Admin");
                }
                else if(fnum == 1)
                {
                    Hashtable f1 = new Hashtable();
                    WebDriver driver=null;

                    if(SalesIQTestSV.isTest(SalesIQTestSV.modules))
                    {
                        driver = setUpDriver();
                        result.put("Login - Supervisor",Functions.login(driver,"supervisor_quick"));
                        if((boolean)result.get("Login - Supervisor"))
                        {
                            f1 = SalesIQTestSV.test1(driver,starttime);
                            result.putAll((Hashtable) f1.get("result"));
                            Util.getModulesResult((Hashtable) f1.get("result"),"Basic Test Cases - Supervisor");
                            servicedown.putAll((Hashtable) f1.get("servicedown"));
                        }
                        Functions.logout(driver,"Supervisor");
                    }
                }
                else if(fnum == 2)
                {
                    Hashtable f1 = new Hashtable();
                    WebDriver driver=null;
                    if(SalesIQTestAsso.isTest(SalesIQTestAsso.modules))
                    {
                        driver = setUpDriver();

                        result.put("Login - Associate",Functions.login(driver,"associate_quick"));
                        if((boolean)result.get("Login - Associate"))
                        {
                            f1 = SalesIQTestAsso.test2(driver,starttime);
                            result.putAll((Hashtable) f1.get("result"));
                            Util.getModulesResult((Hashtable) f1.get("result"),"Basic Test Cases - Associate");
                            servicedown.putAll((Hashtable) f1.get("servicedown"));
                        }
                        Functions.logout(driver,"Associate");
                    }                    
                }
           }
            catch (Exception e)
            {
                System.out.println("Status: Exception  for fnum"+fnum+": "+e);
                e.printStackTrace();
            }
            System.out.println("Status: Success");
        }
    }

}
