//$Id$
package com.zoho.quick.livedesk.util;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.client.BlockedIP;
import com.zoho.livedesk.client.Department;
import com.zoho.livedesk.client.CompanyInfo;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.AgentsSettings;
import com.zoho.livedesk.client.ComplexReportFactory;


public class CleanupQuick
{
	public static String MODULE_NAME = "Cleanup quick";
	public static WebDriver driver = null;
	public static ExtentTest etest;

	public static void startCleanup()
	{
		try
		{
			etest = ComplexReportFactory.getTest("Cleanup -- Agent settings");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			driver = Functions.setUp();
			Functions.login(driver,"admin_quick");
			try
			{
				if(AgentsSettings.clearAgentSettings(driver))
				{
					etest.log(Status.PASS,"Agents cleared from the main portal");
				}
				else
				{
					etest.log(Status.WARNING,"Please set agent settings");
				}
			}
			catch(Exception e)
			{
				etest.log(Status.WARNING,"Please set agent settings");
		        TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failed","Check",e);                
		        e.printStackTrace();
			}

			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Cleanup -- company info");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			try
			{
				if(CompanyInfo.clearCompanyInfo(driver))
				{
					etest.log(Status.PASS,"Company settings was set");
				}
				else
				{
					etest.log(Status.WARNING,"Please set company settings");
				}
			}
			catch(Exception e)
			{
				etest.log(Status.WARNING,"Please set company settings");
		        TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failed","Check",e);                
		        e.printStackTrace();
			}

			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Cleanup -- Department details");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			try
            {
                Cleanup.takeBeforeCleanupScreenshot(driver,etest);

                Cleanup.deleteAllDeparmentsExcept(driver,null);
                etest.log(Status.PASS,"All deparments were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all deparments manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }

			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Cleanup -- Blocked IP");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			try
            {
                Cleanup.takeBeforeCleanupScreenshot(driver,etest);

                Cleanup.deleteAllBlockedIP(driver);
                etest.log(Status.PASS,"All blocked IP were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all blocked IP manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }

			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Cleanup -- Clear sessions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
		
			Cleanup.clearSessions(driver,etest);

			Functions.logout(driver);

			driver = Functions.setUp();

			Functions.login(driver,"associate_quick");

			Cleanup.clearSessions(driver,etest);

			Functions.logout(driver);
			
			driver = Functions.setUp();

			Functions.login(driver,"supervisor_quick");

			Cleanup.clearSessions(driver,etest);

			Functions.logout(driver);

			driver = Functions.setUp();

			Functions.login(driver,"chathistory1");

			Cleanup.clearSessions(driver,etest);

			Functions.logout(driver);

			driver = Functions.setUp();

			Functions.login(driver,"static_idc_agent");

			Cleanup.clearSessions(driver,etest);

			Functions.logout(driver);
			
			ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			etest.log(Status.WARNING,"Login failed! cleanup settings manually or run cleanup before next automation");
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failed","Check",e);
			e.printStackTrace();
		}
	}
}
