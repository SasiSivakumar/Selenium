//$Id$
package com.zoho.quick.livedesk;

import java.util.List;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;

import com.zoho.livedesk.client.BlockedIP;
import com.zoho.livedesk.client.Department;
import com.zoho.livedesk.client.CompanyInfo;
import com.zoho.livedesk.client.ReportsModule;
import com.zoho.livedesk.client.PortalSettings;
import com.zoho.livedesk.client.CannedMessages;
import com.zoho.livedesk.client.AgentsSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.CannedResponse.CannedResponseModule;
import com.zoho.livedesk.client.CannedResponse.CannedResponseCommonFunctions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.server.ConfManager;

public class LiveDeskTesting {

	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	public static ArrayList<String> tested_modules = new ArrayList<String>();
	public static String modulesstr = ConfManager.getModules();
	public static ArrayList<String> list = new ArrayList<String>(Arrays.asList(modulesstr.split(",")));
	public static Hashtable report = new Hashtable();

	public static final String[] modules={"Operators Settings","Company Settings","BlockedIP Settings","Department Settings","Reports"};

	public static Hashtable test(WebDriver driver, long starttime)
	{
		tested_modules = new ArrayList<String>();
		result = new Hashtable();
		report.put("starttime", starttime);
        if(isTest("BlockedIP Settings"))
        {
            hashtable = BlockedIP.blockedIP(driver);
            result.putAll((Hashtable) hashtable.get("result"));
            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
            tested_modules.add("BlockedIP Settings");
        }

		if(isTest("Reports"))
        {
            hashtable = ReportsModule.genReport(driver);
            result.putAll((Hashtable) hashtable.get("result"));
            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
            tested_modules.add("Reports");
        }
		if(isTest("Operators Settings"))
		{
			hashtable = AgentsSettings.agentsConfig(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Operators Settings");
		}

		if(isTest("Company Settings"))
	    {
			hashtable = CompanyInfo.companydetails(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Company Settings");
		}

        if(isTest("Department Settings"))
		{
			hashtable = Department.department(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Department Settings");
		}

        hashtable = new Hashtable();
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	public static boolean isTest(String... module_names)
	{
		return Util.isTest(list,module_names);
	}
}
