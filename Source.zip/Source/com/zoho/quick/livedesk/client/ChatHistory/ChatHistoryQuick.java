//$Id$
package com.zoho.quick.livedesk.client.ChatHistory;

import java.io.File;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.Hashtable;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.apache.bcel.generic.NEW;

import com.google.common.base.Function;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.DistributedTest;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;

import com.zoho./*quick.*/livedesk.util.Util;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.CRM.PotentialAdd;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;

public class ChatHistoryQuick implements DistributedTest
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();;
	public static Hashtable servicedown = new Hashtable();

	public static ExtentTest etest;

	public static String MODULE_NAME="Chat History Quick";

	public void startThread(int thread_number) throws Exception
	{
		WebDriver driver = Functions.setUp();

		if(thread_number==0)
		{	
			Functions.login(driver,"chathistoryportal1");
            Functions.closeBannersAfterLogin(driver);
			usecase1(driver);
		}

		if(thread_number==1)
		{
			Functions.login(driver,"chathistoryportal2");
            Functions.closeBannersAfterLogin(driver);
			usecase2(driver);
		}

		if(thread_number==2)
		{
			Functions.login(driver,"chathistoryportal3");
            Functions.closeBannersAfterLogin(driver);
			usecase3(driver);
		}

		if(thread_number==3)
		{
			Functions.login(driver,"chathistoryportal4");
            Functions.closeBannersAfterLogin(driver);
			usecase4(driver);
		}

		if(thread_number==4)
		{
			Functions.login(driver,"chathistoryportal5");
            Functions.closeBannersAfterLogin(driver);
			usecase5(driver);
		}

		if(thread_number==5)
		{
			Functions.login(driver,"chathistoryportal6");
            Functions.closeBannersAfterLogin(driver);
			usecase6(driver);
		}
		
		String portal=ExecuteStatements.getPortal(driver);
		ChatHistoryTests.visitor_driver_manager.closeAllDrivers(portal);

		Functions.logout(driver);
	}

	public static Hashtable test()
	{
		ChatHistoryTests.visitor_driver_manager = new VisitorDriverManager();
		ChatHistoryTests.result = result;
		ChatHistoryTests.MODULE_NAME = MODULE_NAME;

		ChatHistoryQuick usecases = new ChatHistoryQuick();

		Distributor distributor = new Distributor(usecases,6);

		distributor.initiate();

		ChatHistoryTests.visitor_driver_manager.terminateAllDriverSessions();

		ComplexReportFactory.closeTest(etest);
        finalResult.put("result", result);
		finalResult.put("servicedown", servicedown);
		return finalResult;
	}

	public static void usecase1(WebDriver driver)
	{
		String WIDGET_CODE="",WEBSITE_NAME="";
		try
		{
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH6",checkDeleteChat(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH10",ChatHistoryTests.checkChatIDIncreasesByOne(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

            ChatHistoryTests.WIDGET_CODE = WIDGET_CODE;
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH11",ChatHistoryTests.checkRetrieveChatInfoBasic(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

		}

		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);
        }    
	}

	public static void usecase2(WebDriver driver)
	{
		String WIDGET_CODE="",WEBSITE_NAME="";
		try
		{
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH19"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH19",ChatHistoryTests.checkVisitorInfoRetrieved(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH20"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH20",ChatHistoryTests.checkReasonForMissed(driver,etest,WIDGET_CODE,AgentStatus.BUSY));
            ComplexReportFactory.closeTest(etest);
		}
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);
        }    
	}

	public static void usecase3(WebDriver driver)
	{
		String WIDGET_CODE="",WEBSITE_NAME="";
		try
		{
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH21"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH21",ChatHistoryTests.checkReasonForMissed(driver,etest,WIDGET_CODE,AgentStatus.AVAILABLE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH26"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH26",ChatHistoryTests.checkChatHistoryChatTabsOpened(driver,etest,ChatWindow.CHAT_VIEW_ID,"CH27"));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH28"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH28",ChatHistoryTests.checkChatHistoryChatTabsOpened(driver,etest,ChatWindow.NOTES_VIEW_ID,"CH29"));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH30"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH30",ChatHistoryTests.checkChatHistoryChatTabsOpened(driver,etest,ChatWindow.INFO_VIEW_ID,"CH31"));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check edit visitor info");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			ChatHistoryTests.checkEditVisitorInfo(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);
		}
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);
        }    
	}

	public static void usecase4(WebDriver driver)
	{
		String WIDGET_CODE="",WEBSITE_NAME="";
		try
		{
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest("Toggle recent chats and visitor info in chat window RHS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			ChatHistoryTests.checkRecentChatsToggle(driver,etest,WIDGET_CODE);
			etest.log(Status.INFO,""+ChatHistoryChat.getRHSVisitorDataContainer(driver).getText()+"");
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH40"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH40",ChatHistoryTests.verifyRecentChatsInfo(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);
		}
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);
        }    
	}

	public static void usecase5(WebDriver driver)
	{
		String WIDGET_CODE="",WEBSITE_NAME="";
		try
		{
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH43"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH43",ChatHistoryTests.checkHistoryChatTab(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH41"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH41",ChatHistoryTests.verifyHistoryChatInfo(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH44"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH44",ChatHistoryTests.checkHistoryChatTab(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);
		}
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);
        }    
	}

	public static void usecase6(WebDriver driver)
	{
		String WIDGET_CODE="",WEBSITE_NAME="";
		try
		{
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			ChatHistoryTests.checkFilterOptions(driver,etest,WIDGET_CODE);
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);
        }    
	}

	public static boolean checkDeleteChat(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount = 0;

		String label = CommonUtil.getUniqueMessage();
		WebDriver visitor_driver = null;

		try
		{
			visitor_driver = Functions.setUp();
			ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label);

			Tab.clickChatHistory(driver);

			boolean isDeleted = ChatHistory.deleteChat(driver,etest,label);

			if(isDeleted)
			{
				result.put("CH4",true);
				etest.log(Status.PASS,"Chat was NOT found in chat history tab after it was deleted");
			}
			else
			{
				result.put("CH4",false);
				etest.log(Status.FAIL,"Chat was found in chat history tab after it was deleted");	
				TakeScreenshot.screenshot(driver,etest);			
			}

			List<WebElement> search_result = GlobalSearch.search(driver,label);

			if(search_result == null || search_result.isEmpty())
			{
				etest.log(Status.PASS,"Deleted chat was NOT found in search results");
			}
			else
			{
				etest.log(Status.FAIL,"Deleted chat was found in search results");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}

		return CommonUtil.returnResult(failcount);
	}
}
