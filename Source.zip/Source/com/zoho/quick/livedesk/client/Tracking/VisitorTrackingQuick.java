//$Id$
package com.zoho.quick.livedesk.client.Tracking;

import java.util.*;

import com.google.common.base.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;

import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TrackingRingsCustomize.*;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;

import com.zoho.livedesk.client.Tracking.*;

public class VisitorTrackingQuick
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static WebDriver visdriver = null;

	public static String MODULE_NAME="Visitor Tracking";
	public static String WIDGET_CODE="";
	public static String WEBSITE_NAME="";

	public static String
    EMBED_NAME=ConfManager.getRealValue("quicktrackingembed"),
    PORTAL_NAME=ConfManager.getRealValue("quicktrackingportal");

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
			WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS1"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            
				FluentWait waiter = CommonUtil.waitreturner(driver,30,200);

				waiter.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("rings_tracking"))));
				CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();

				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
				Thread.sleep(1000);
				result.put("RINGS1",true);
				visdriver = VisitorSite.createPage();
			
				if((boolean)result.get("RINGS1"))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS1")+" is checked");
				}
			
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Deleting All Presets before Automation"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			TrackingRings.setupTrackingRingsForAutomation(driver,etest);
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC1"));
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				result.put("TRC1", TrackingRingsCustomizeTests.checkCustomizeHeaderAndDescription(driver,etest));
            ComplexReportFactory.closeTest(etest);
            
            TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS2"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
				result.put("RINGS2",initialIncomingVisitor.incomingVisitor(driver));
				visdriver.quit();
			
				if((boolean)result.get("RINGS2"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS2")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS3"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS3",initialLeavingVisitor.leavingVisitor(driver));
            	//oldVisit = vlist;
			
				if((boolean)result.get("RINGS3"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS3")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS4"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				visdriver = VisitorSite.createPage();
				result.put("RINGS4",initialIncomingVisitorList.incomingVisitor(driver));
				visdriver.quit();
			
				if((boolean)result.get("RINGS4"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS4")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS5"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS5",initialLeavingVisitorList.leavingVisitor(driver));
           
				if((boolean)result.get("RINGS5"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS5")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


			result.put("RINGS93", visStatus.checkRepeatedVisitor(driver,EMBED_NAME,PORTAL_NAME,visStatus.VisitorStatus.REPEATED_USER,TrackingRings.TestStatus.CONTINUE_TEST,"RINGS93"));
                       
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS18"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				visdriver = VisitorSite.createPage();
				result.put("RINGS18",tilesCheck.tilesUICheckPartition(driver,"Available,Idle","div.detbox.box1"));
			
				if((boolean)result.get("RINGS18"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS18")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS19"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS19",tilesCheck.tilesUICheckPartition(driver,"Time on site","div.detbox.box2"));
			
				if((boolean)result.get("RINGS19"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS19")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS20"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS20",tilesCheck.tilesUICheckPartition(driver,"Visitor History","div.detbox.box3"));
			
				if((boolean)result.get("RINGS20"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS20")+" is checked");
			
			ComplexReportFactory.closeTest(etest);
            

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS21"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS21",tilesCheck.tilesUICheckPartition(driver,"Visitor Location and IP","div.detbox.box4"));
			
				if((boolean)result.get("RINGS21"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS21")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS22"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            
            	TrackingRings.etest=etest;
				result.put("RINGS22",tilesCheck.tilesUICheckPartition(driver,"Visitor landing page","div.detbox.box5"));
			
				if((boolean)result.get("RINGS22"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS22")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS23"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS23",tilesCheck.tilesUICheckPartition(driver,"Direct Traffic,Referral","div.detbox.box6"));
			
				if((boolean)result.get("RINGS23"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS23")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS24"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS24",tilesCheck.tilesCheckQuesArea(driver));
			
				if((boolean)result.get("RINGS24"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS24")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS25"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS25",tilesCheck.tilesCheckVisInfo(driver,"infoname_","//div[contains(@class,'vinfohdr')]//span[contains(@class,'txtelips')][1]"));
			
				if((boolean)result.get("RINGS25"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS25")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS26"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS26",tilesCheck.tilesCheckVisInfo(driver,"ccode","//div[contains(@class,'vinfohdr')]//span[contains(@class,'gspritebg')][1]"));
			
				if((boolean)result.get("RINGS26"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS26")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS27"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS27",tilesCheck.tilesCheckVisInfo(driver,"browser","//div[contains(@class,'vinfohdr')]//span[contains(@class,'gspritebg')][2]"));
			
				if((boolean)result.get("RINGS27"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS27")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS28"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS28",tilesCheck.tilesCheckVisInfo(driver,"os","//div[contains(@class,'vinfohdr')]//span[contains(@class,'gspritebg')][3]"));
			
				if((boolean)result.get("RINGS28"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS28")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS33"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				result.put("RINGS33",tilesCheck.proActiveOneDept(driver));
				
				if((boolean)result.get("RINGS33"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS33")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS36"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            
				visdriver = VisitorSite.createPage();
				result.put("RINGS36",proActiveBasic.tilesInvi(driver));
				visdriver.quit();
			
				if((boolean)result.get("RINGS36"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS36")+" is checked");
			
			ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS74"));
            	ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            	TrackingRings.etest=etest;
            	
				visdriver = VisitorSite.createPage();
				WebDriver visdriverOnline1 = VisitorSite.createPage();
				WebDriver visdriverOnline2 = VisitorSite.createPage();
				result.put("RINGS74",visOnline.visCheck(driver,3));
				visdriver.quit();
				visdriverOnline1.quit();
				visdriverOnline2.quit();
				
				if((boolean)result.get("RINGS74"))
					etest.log(Status.PASS,KeyManager.getRealValue("RINGS74")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}
	}
}