//$Id$
package com.zoho.quick.livedesk.client.visitorhistory;

import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.visitorhistory.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;

import com.zoho.livedesk.util.Util;

public class VisitorHistoryQuick
{
      private static Hashtable result = new Hashtable();
      private static Hashtable hashtable = new Hashtable();
      private static Hashtable servicedown = new Hashtable();

      public static ExtentTest etest;

      public static String widgetCode;

      public static String MODULE_NAME="Visitor History";

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            widgetCode = ExecuteStatements.getWidgetCode(driver);

            String portal = ExecuteStatements.getPortal(driver);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH1"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            driver.navigate().refresh();
            Thread.sleep(5000);
            CommonFunctions.clickVisitorHistory(driver);
            result.put("VH1",true);
            etest.log(Status.PASS,"Visitor History tab available");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH12"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH12",View.checkViews(driver));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH2"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH2",Partition.checkPartition(driver));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH8"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH8",PopUp.checkPopUp(driver));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH4"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH4",Partition.partInvi(driver));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Visitor History - Check visitor");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            initiateChat(driver,portal,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH32"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            driver.get(Util.siteNameout()+"/visitorhistory");
            CommonFunctions.setToAllVis(driver);
            result.put("VH32",VInfoTab.basicInfo(driver));
            CommonFunctions.setToAllVis(driver);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH45"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH45",VisitorEvent.checkVisitsInfo(driver));
            CommonFunctions.setToAllVis(driver);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH47"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH47",VisitorEvent.checkVisitDet(driver));
            CommonFunctions.setToAllVis(driver);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH48"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH48",VisitorEvent.checkMoreAction(driver));
            CommonFunctions.setToAllVis(driver);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH41"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH41",VisitorEvent.checkVisits(driver));
            CommonFunctions.setToAllVis(driver);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH49"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH49",VisitorEvent.checkActions(driver));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH50"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            vhistory.etest = etest;
            result.put("VH50",VisitorEvent.checkChatConv(driver));
            CommonFunctions.setToAllVis(driver);
            ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            TakeScreenshot.log(e,etest);
        }
		finally
		{
            ComplexReportFactory.closeTest(etest);
            hashtable.put("result",result);
            hashtable.put("servicedown",servicedown);
            return hashtable;
		}
	}

    public static void initiateChat(WebDriver driver,String portal,ExtentTest etest) throws Exception
    {
        try
        {
            WebDriver visDriver = Functions.setUp();
          
            String visitorid = null;

            try
            {
                  VisitorWindow.createPage(visDriver,widgetCode);
                  VisitorWindow.initiateChatVisTheme(visDriver,null,"rajka@raja123.com","9123456789","there ?",etest);
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(visDriver,etest,"VisitorHistoryQuick","initateChat","Exception0",e);
                  return;
            }
          
            try
            {
                ChatWindow.acceptChat(driver,etest);
                ChatWindow.closeAllChats(driver);
                
                visitorid = VisitorWindow.getVisitorId(visDriver,portal);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorHistoryQuick","initateChat","Exception1",e);
            }
          
            visDriver.get("https://www.zoho.com/");

            VisitorsOnline.waitTillVisitorLeaves(driver, visitorid);

            Thread.sleep(3000);

            String id = "";

            try
            {
                  VisitorWindow.createPage(visDriver,widgetCode);
                  id = VisitorWindow.getVisitorId(visDriver,portal);
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,"VisitorHistoryQuick","initateChat","Exception2",e);
                  return;
            }

            VisitorsOnline.waitTillVisitorPresent(driver,id);

            driver.findElement(By.id("name_"+id+"")).click();
            Thread.sleep(1000);
            CommonSikuli.findInWholePage(driver,"VOspeedometer.png","UI310",vhistory.etest);
            // Actions action = new Actions(driver);
            // action.sendKeys(Keys.ESCAPE).perform();
            CannedMessagesCommonFunctions.sendEscapeKeyToTilesUIChat(driver,id);

            Thread.sleep(3000);

            visDriver.quit();
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorHistoryQuick","initateChat","Exception3",e);
        }
    } 
}
