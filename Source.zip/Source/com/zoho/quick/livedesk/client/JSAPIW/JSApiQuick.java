//$Id$
package com.zoho.quick.livedesk.client.JSAPIW;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;


import com.zoho.livedesk.client.JSAPIW.CommonFunctions;
import com.zoho.livedesk.client.JSAPIW.JSApiutilWC;

public class JSApiQuick
{
    private static Hashtable result = new Hashtable();
    private static Hashtable hashtable = new Hashtable();
    private static Hashtable servicedown = new Hashtable();
    public static WebDriver ApiDriver = null;
    
    public static String widgetcode = "";

    public static ExtentTest etest;

    public static Hashtable jsApiAutomation(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result = new Hashtable();
            
            if(Util.setUptracking().contains("local"))
            {
                JSApiutilWC.widgetcode = "0b6b4eba2943b675b19c06303df4f4059f3ab667577e0649dface964e319feb5120dd4a0fe8956c9336cff03c12517fc";
            }
            else
            {
                JSApiutilWC.widgetcode = "fc77c527e82dfaeeca60e7ece4f7db540e9feb6b662b58f1d7fb6706df5da6ce2b4496887091071614a96b7c00b157bf";
            }

            etest = ComplexReportFactory.getTest("Widget code - Open Api Site");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","Checks if the JSAPI site is accessible");

            ApiDriver = CommonFunctions.openApiSite(null);

            result.put("JSW1",true);

            etest.log(Status.PASS,"Site is accessible and is opened");
            ComplexReportFactory.closeTest(etest);
            ApiDriver.quit();

            /* Working set starts here */

            ApiDriver = CommonFunctions.openApiSite(null);
            JSApiutilWC.changeConfigBasic(ApiDriver);
            JSApiutilWC.checkConfigBasic(ApiDriver);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            JSApiutilWC.changeConfig(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester5","rajkumar.natarajan+11223@zohocorp.com","8767588867","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.clickMinimize(ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.sendFeedbackandRating(ApiDriver,"4");
            JSApiutilWC.checkConfig(driver,ApiDriver);
            ApiDriver.quit();

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatwindow.click()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on clicking the float button.");
            JSApiutilWC.etest = etest;

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW8",JSApiutilWC.checkClicks(ApiDriver,"evtbuttonclk","evntbclk"));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.online()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when the agents are online. This will be called once after the page is loaded.");

            JSApiutilWC.etest = etest;
            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW12",JSApiutilWC.checkEvHandler(ApiDriver));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"busy");
            
            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.offlinemessage()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on submitting an offline request.");
            JSApiutilWC.etest = etest;

            ApiDriver = CommonFunctions.openApiSite(null);
            JSApiutilWC.ApiDriver = ApiDriver;
            result.put("JSW7",JSApiutilWC.checkOffline(ApiDriver));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.offline()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when the agents are offline. This will be called once after the page is loaded.");
            JSApiutilWC.etest = etest;

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW11",JSApiutilWC.checkChatHandler(ApiDriver,"evtchatoffline","evtchatoffline"));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"available");

        }
        catch(Exception e)
        {
            result.put("JSW1",false);
            etest.log(Status.FATAL,"Error occurred while trying to open API Site");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiShowStopper","JSApiError",e);
        }

        ComplexReportFactory.closeTest(etest);

        hashtable.put("result",result);
        hashtable.put("servicedown",servicedown);
        return hashtable;
    }
}