//$Id$
package com.zoho.quick.livedesk.client;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import com.zoho.livedesk.client.Chat;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;

import com.zoho.livedesk.util.common.actions.ChatWindow;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

public class ChatQuick
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
	public static ExtentTest etest;

	public static String MODULE_NAME="Chat Quick";
	public static String WIDGET_CODE="";
	public static String PORTAL_NAME="";
	public static String WEBSITE_NAME="";
	public static String AGENT_TEXT = "Agent replied text";
	public static String user = "";
	public static String visitorid = "";
	public static String time = "";

	public static VisitorDriverManager visitor_driver_manager;
	public static WebDriver visitor_driver = null;

	public static Hashtable test(WebDriver driver)
	{
		String user ="",portal = "";
		try
		{
			user = ExecuteStatements.getUserName(driver);
			portal=ExecuteStatements.getPortal(driver);
			visitor_driver_manager = new VisitorDriverManager();
			visitor_driver = visitor_driver_manager.getDriver(driver);
			result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
			WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ1"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ1",checkChatWidget(driver,true,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ2"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ2",checkChatWidget(driver,false,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Fields of chat widget");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkFields(driver,visitor_driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check visitor info fields operator side");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkFieldsOperatorSide(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check visitor message on agent side");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ11",checkVisitorMessageOnAgentSide(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check agent message on visitor side");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ12",checkMessageInVisitorWindow(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ13"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ13",checkChatsTab(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ14"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ14",checkConnectedTab(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ15"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ15",endChat(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ16"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ16",checkAgentSideAfterEndChat(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ17"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ17",checkVisitorSideAfterEndChat(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ18"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ18",checkWaitingTimer(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ37"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ37",checkAcceptChatFromNotification(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ20"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ20",endChatVisitor(visitor_driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ21"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ21",checkCloseThisWindow(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check history tab details");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkHistoryTab(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ35"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkIgnoreChat(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ38"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ38",checkBlockIP(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ39"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ39",checkShareURL(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ40"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ40",checkTransferChat(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ41"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ41",checkAllOptionsWithEndSession(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ42"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ42",checkMoreActions(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ43"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ43",checkMoreOptionsVisitorSide(driver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CQ22"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("CQ22",checkEndChatTimer(driver,etest));
            ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);	
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			visitor_driver_manager.closeAllDrivers(portal);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}
	}

	public static boolean checkChatWidget(WebDriver driver,boolean isPresent,ExtentTest etest) throws Exception
	{
		String status_change_to = null;
		int failcount = 0;
		try
		{
			status_change_to = isPresent?"busy":"available";

			VisitorWindow.createPage(visitor_driver,WIDGET_CODE);
			if(isPresent)
			{
				if(!VisitorWindow.checkChatWidgetOffline(visitor_driver))
				{
					etest.log(Status.PASS,"Chat widget is available");
				}
				else
				{
					etest.log(Status.FAIL,"Chat widget is not available");
					failcount++;
				}
			}
			else
			{
				CommonUtil.refreshPage(visitor_driver);
				VisitorWindow.createPage(visitor_driver,WIDGET_CODE);
				if(VisitorWindow.checkChatWidgetOffline(visitor_driver))
				{
					etest.log(Status.PASS,"Chat widget is not available for offline");
				}
				else
				{
					etest.log(Status.FAIL,"Chat widget is available for offline");
					failcount++;
				}
			}
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status_change_to);
		}
		catch(Exception e)
		{
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status_change_to);
			TakeScreenshot.log(e,etest);
			failcount++;
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return CommonUtil.returnResult(failcount);
	}

	public static void checkFields(WebDriver driver,WebDriver visDriver,ExtentTest etest)
	{
		try
		{
			if(VisitorWindow.checkFields(visDriver,"name"))
			{
				etest.log(Status.PASS,"Name field is found");
				result.put("CQ3",true);
			}
			else
			{
				etest.log(Status.FAIL,"Name field is not found");
				result.put("CQ3",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		try
		{
			if(VisitorWindow.checkFields(visDriver,"email"))
			{
				etest.log(Status.PASS,"Email field is found");
				result.put("CQ4",true);
			}
			else
			{
				etest.log(Status.FAIL,"Email field is not found");
				result.put("CQ4",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		try
		{
			if(VisitorWindow.checkFields(visDriver,"phone"))
			{
				etest.log(Status.PASS,"Phone field is found");
				result.put("CQ5",true);
			}
			else
			{
				etest.log(Status.FAIL,"Phone field is not found");
				result.put("CQ5",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		try
		{
			VisitorWindow.clickChatButton(visDriver);
	        VisitorWindow.switchToChatWidget(visDriver);
	        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

	        WebElement section = CommonUtil.elfinder(visDriver,"xpath","//section[contains(@class,'content')]");

	        if(section.getAttribute("innerHTML").contains("msgbox"))
	        {
	            if(section.getAttribute("innerHTML").contains("question"))
	            {
	                etest.log(Status.PASS,"Question field is found");
					result.put("CQ6",true);
	            }
	            else
	            {
	            	etest.log(Status.FAIL,"Question field is not found");
					result.put("CQ6",false);
	            }
	        }
	        else
            {
            	etest.log(Status.FAIL,"Question field is not found");
				result.put("CQ6",false);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}

		try
		{
			if(VisitorWindow.checkMandatoryFields(visitor_driver,"email"))
			{
				etest.log(Status.PASS,"Email field is mandatory - Checked");
				result.put("CQ19",true);
			}
			else
			{
				etest.log(Status.FAIL,"Email field is not mandatory - Check failed");
				result.put("CQ19",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		finally
		{
			try
			{
				VisitorWindow.clickCloseChatWidget(visitor_driver);
			}
			catch(Exception e)
			{
				etest.log(Status.WARNING,"Chat widget not closed may lead to fatal error");
			}
		}
	}

	public static void checkFieldsOperatorSide(WebDriver driver,ExtentTest etest,String widget_code)
	{
		String label = CommonUtil.getUniqueMessage();
		String name = "V "+label;
		String email = "v"+label+"@email.com";
		String phone = "+"+label;
		String ques = "Q"+label+"?";
		String dept;
		try
		{
			dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
			VisitorWindow.createPage(visitor_driver,WIDGET_CODE);
			VisitorWindow.initiateChatVisTheme(visitor_driver,name,email,phone,dept,ques,etest);
			ChatWindow.acceptChat(driver,etest);
			
			try
			{
				if(name.equals(driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText()))
				{
					if((driver.findElement(By.className("t-v-subtxt")).getText()).contains(name))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CQ7")+" is checked");
						result.put("CQ7", true);
					}
					else
					{
						etest.log(Status.FAIL,KeyManager.getRealValue("CQ7")+" is failed");
	                	TakeScreenshot.screenshot(driver,etest);
						result.put("CQ7", false);
					}
				}
				else
				{
					etest.log(Status.FAIL,KeyManager.getRealValue("CQ7")+" is failed");
					TakeScreenshot.screenshot(driver,etest);
					result.put("CQ7", false);
				}
			}
			catch(Exception e)
	        {
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
				result.put("CQ7", false);
			}
			try
			{
				WebElement editicon = CommonUtil.elfinder(driver,"id","cvemail");
				CommonUtil.mouseHover(driver,editicon);   
				CommonSikuli.findInWholePage(driver,"Visitoredit.png","UI88",etest);

				if(email.equals(driver.findElement(By.id("cvemail")).findElement(By.tagName("a")).getText()))
				{
					if((driver.findElement(By.className("t-v-subtxt")).getText()).contains(email))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CQ8")+" is checked");
						result.put("CQ8", true);
					}
					else
					{
						etest.log(Status.FAIL,KeyManager.getRealValue("CQ8")+" is failed");
						TakeScreenshot.screenshot(driver,etest);
						result.put("CQ8", false);
					}
				}
				else
				{
					etest.log(Status.FAIL,KeyManager.getRealValue("CQ8")+" is failed");
					TakeScreenshot.screenshot(driver,etest);
					result.put("CQ8", false);
				}
			}
			catch(Exception e)
	        {
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
				result.put("CQ8", false);
	        }
	        try
			{
				List<WebElement> elmts1 = driver.findElement(By.id("visitordata")).findElements(By.className("rcvstinfotxt"));
				String txt = "";
				if(elmts1.size() > 2)
				{
					txt = elmts1.get(1).getText();
				}
				else if(elmts1.size() == 2)
				{
					txt = elmts1.get(0).getText();
				}

				CommonSikuli.findInWholePage(driver,"Visitordept.png","UI89",etest);

				if((txt).contains(dept))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CQ9")+" is checked");
					result.put("CQ9", true);
				}
				else
				{
					etest.log(Status.FAIL,KeyManager.getRealValue("CQ9")+" is failed");
					TakeScreenshot.screenshot(driver,etest);
					result.put("CQ9", false);
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
				result.put("CQ9", false);
			}
			try
			{
				WebElement elmt2 = driver.findElement(By.id("msgtablediv"));
				List<WebElement> txt = elmt2.findElements(By.className("t-v-questionmn"));

				if((txt.get(0).getText()).contains(ques))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CQ10")+" is checked");
					result.put("CQ10", true);
				}
				else
				{
					etest.log(Status.FAIL,KeyManager.getRealValue("CQ10")+" is failed");
					TakeScreenshot.screenshot(driver,etest);
					result.put("CQ10", false);
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
				result.put("CQ10", false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
	}

	public static boolean endChatVisitor(WebDriver driver,ExtentTest etest)
	{
		try
		{
			VisitorWindow.endChatVisitor(visitor_driver);
			etest.log(Status.PASS,"Chat ended from visitor end");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkMessageInVisitorWindow(WebDriver driver,ExtentTest etest)
	{
		try
		{
			ChatWindow.sentMessage(driver,AGENT_TEXT);
			if(VisitorWindow.checkAgentMessageInChatWindow(visitor_driver,"",AGENT_TEXT,1))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CQ12")+" is checked");
				return true;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkVisitorMessageOnAgentSide(WebDriver driver,ExtentTest etest)
	{
		String visitortext = "Visitor replied text";
		try
		{
			VisitorWindow.sentMessageInTheme(visitor_driver,visitortext);
			if(VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",visitortext,2))
			{
				CommonWait.waitTillDisplayed(driver,By.className("t-v-fcont"));
                WebElement elmt = driver.findElement(By.className("t-v-fcont")).findElement(By.className("t-v-msg"));
				if(visitortext.equals(elmt.getText()))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CQ11")+" is checked");
					ChatWindow.sentMessage(driver,AGENT_TEXT);
                    return true;
				}
                else
                {
					etest.log(Status.FAIL,KeyManager.getRealValue("CQ11")+" is failed");
					TakeScreenshot.screenshot(driver,etest);
                }
			}
            else
            {
				etest.log(Status.FAIL,KeyManager.getRealValue("CQ11")+" is failed");
				TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkChatsTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String tabtxt = driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_mycurrent")).getText();
			if(tabtxt.contains(ResourceManager.getRealValue("shortcut_chats")))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CQ13")+" is checked");
                return true;
			}
            else
            {
				etest.log(Status.FAIL,KeyManager.getRealValue("CQ13")+" is failed");
				TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkConnectedTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String tabtxt = driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_current")).getText();
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        	wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        	CommonUtil.elfinder(driver,"partiallinktext","Connected").click();
        	// Chat.commonIconsVerifyinConnctedtab(driver);

			if(tabtxt.contains(ResourceManager.getRealValue("common_visitors")))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CQ14")+" is checked");
                return true;
			}
            else
            {
				etest.log(Status.FAIL,KeyManager.getRealValue("CQ14")+" is failed");
				TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean endChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.clickMyChats(driver);
			CommonSikuli.findInWholePage(driver,"Endchat.png","UI96",etest);
			ChatWindow.endChat(driver);
	        return true;
        }
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkAgentSideAfterEndChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			WebElement elmt = CommonUtil.getElement(driver,By.id("infodiv"));
			if(ResourceManager.getRealValue("chatsessionendtext").equals(elmt.findElement(By.tagName("h1")).getText()))
			{
				List<WebElement> elmts = elmt.findElement(By.className("grayish")).findElements(By.tagName("a"));
				String value1 = elmts.get(0).getText();
				String value2 = elmts.get(1).getText();
				if((ResourceManager.getRealValue("chatsessionendopt1").equals(value1)) && (ResourceManager.getRealValue("chatsessionendopt2").equals(value2)))
				{
					CommonUtil.getElement(driver,By.linkText(ResourceManager.getRealValue("closewindow"))).click();
					etest.log(Status.PASS,KeyManager.getRealValue("CQ16")+" is checked");
                    return true;
				}
                else
                {
                    etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("chatsessionendopt1")+"--"+ResourceManager.getRealValue("chatsessionendopt2")+"--Actual"+value1+"--"+value2+"--");
					TakeScreenshot.screenshot(driver,etest);
                }
			}
            else
            {
				etest.log(Status.FAIL,KeyManager.getRealValue("CQ16")+" is failed");
				TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkVisitorSideAfterEndChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			VisitorWindow.checkChatEndedInTheme(visitor_driver);
			etest.log(Status.PASS,KeyManager.getRealValue("CQ17")+" is checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkIgnoreChat(WebDriver driver,ExtentTest etest)
	{
		String dept = "";
		try
		{
			dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,WIDGET_CODE);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"test","test@test.com","1234",dept,"qwer",etest);
            
            try
            {
            	ChatWindow.ignoreChat(driver);
            }
            catch(Exception e)
            {
            	if(CommonUtil.getElement(driver,By.id("waitinglist")).getAttribute("innerHTML").length() == 0)
            	{
            		CommonUtil.clickWebElement(driver,By.id("waitinglist"),By.id("wcancel"));
            	}
            }
            try
			{
				CommonWait.waitTillDisplayed(driver,By.id("waitinglist"));
				if(CommonUtil.getElement(driver,By.id("waitinglist")).getAttribute("innerHTML").length() == 0)
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CQ35")+" is checked");
                	result.put("CQ35", true);
				}
				else
				{
					etest.log(Status.FAIL,KeyManager.getRealValue("CQ35")+" -- Failed");
                	result.put("CQ35", false);
                	TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e)
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CQ35")+" is checked");
                result.put("CQ35", true);
			}

			driver.findElement(By.id("leftnav")).findElement(By.id("suppm_current")).findElement(By.tagName("a")).click();
			CommonWait.waitTillDisplayed(driver,By.id("historylist"));

			driver.findElement(By.id("historylist")).findElement(By.tagName("table")).findElements(By.tagName("tr")).get(1).click();
			CommonWait.waitTillDisplayed(driver,By.id("current_div"));
			
			driver.findElement(By.id("current_div")).findElement(By.id("innerheader")).findElement(By.className("gren-btn")).click();
			CommonWait.waitTillDisplayed(driver,By.id("msgtablediv"));
			
			if(CommonWait.waitTillDisplayed(driver,By.id("msgtablediv")))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CQ36")+" is checked");
                result.put("CQ36", true);
			}
            else
            {
				etest.log(Status.PASS,KeyManager.getRealValue("CQ36")+" is failed");
                TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkWaitingTimer(WebDriver driver,ExtentTest etest)
	{
		String dept = null;
		try
		{
			dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,WIDGET_CODE);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"test","test@test.com","1234",dept,"qwer",etest);

            if(VisitorWindow.checkWaitingTimer(visitor_driver,0,59,0,45))
            {
            	etest.log(Status.PASS,KeyManager.getRealValue("CQ18")+" is checked");
				return true;
            }
            else
            {
            	etest.log(Status.FAIL,KeyManager.getRealValue("CQ18")+" is failed");
            	TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkCloseThisWindow(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.clickMyChats(driver);

            CommonWait.waitTillDisplayed(driver,By.linkText(ResourceManager.getRealValue("closewindow")));

			driver.findElement(By.linkText(ResourceManager.getRealValue("closewindow"))).click();

			etest.log(Status.PASS,"Chat Window is closed by Agent");

			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkEndChatTimer(WebDriver driver,ExtentTest etest)
	{
		try
		{
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	        WebElement chat = ChatWindow.chatInMyChats(driver);

	        CommonUtil.elementfinder(driver,chat,"id","endsession").click();
	        
	        WebElement e = CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue("endsession_30secs"));
	        wait.until(ExpectedConditions.visibilityOf(e));
	        e.click();

			if(VisitorWindow.checkEndTimer(visitor_driver,30,true,true,etest))
        	{
        	    etest.log(Status.PASS,"Chat ended after 30 seconds as expected");
        	    return true;
        	}
        	else
        	{
        		etest.log(Status.FAIL,"Chat was not ended after 30 seconds as expected");
        	    TakeScreenshot.screenshot(driver,etest);
        	    TakeScreenshot.screenshot(visitor_driver,etest);
        	}
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static void checkHistoryTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			if(ResourceManager.getRealValue("common_history").equals(driver.findElement(By.id("history_div")).findElement(By.id("innerheader")).findElement(By.tagName("h1")).getText()))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CQ23")+" is checked");

                result.put("CQ23", true);
			}
            else
            {
            	TakeScreenshot.screenshot(driver,etest);
            }
            CommonWait.waitTillDisplayed(driver,By.id("history_div"));

			WebElement actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions"));
			CommonWait.waitTillDisplayed(actions);

			try
			{

				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.className("combotitle")).click();
				CommonWait.waitTillDisplayed(driver,By.id("expdrpdowncntnt"));
				List<WebElement> actns = driver.findElement(By.id("expdrpdowncntnt")).findElements(By.tagName("li"));
				if(actns.size() == 2)
				{
                    String value1 = actns.get(0).findElement(By.tagName("div")).getText();
                    String value2 = actns.get(1).findElement(By.tagName("div")).getText();
					if((ResourceManager.getRealValue("exportexcel").equals(value1)) && (ResourceManager.getRealValue("exportcsv").equals(value2)))
					{
					   	etest.log(Status.PASS,KeyManager.getRealValue("CQ25")+" is checked");

                        result.put("CQ25", true);
					}
                    else
                    {
                        etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("exportexcel")+"--"+ResourceManager.getRealValue("exportcsv")+"--Actual:"+value1+"--"+value2+"--");
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
                else
                {
            		TakeScreenshot.screenshot(driver,etest);
                }
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.className("combotitle")).click();
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
			}

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("cushistoryfilter")).findElement(By.tagName("span")).click();
				wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("ul")));
				etest.log(Status.PASS,KeyManager.getRealValue("CQ26")+" is checked");
                result.put("CQ26", true);
				WebElement list = driver.findElement(By.tagName("ul"));
				try{
					WebElement elmt = driver.findElement(By.id("sagent"));
					if(ResourceManager.getRealValue("filter_user").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("sagent")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CQ27")+" is checked");

                        result.put("CQ27", true);
					}
                    else
                    {
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
               	catch(Exception e)
				{
					TakeScreenshot.log(e,etest);
					TakeScreenshot.screenshot(driver,etest);		
					TakeScreenshot.screenshot(visitor_driver,etest);	
				}

				try{
					WebElement elmt = driver.findElement(By.id("vstatus"));
					if(ResourceManager.getRealValue("filter_status").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("vstatus")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CQ28")+" is checked");

                        result.put("CQ28", true);
					}
                    else
                    {
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
                catch(Exception e)
				{
					TakeScreenshot.log(e,etest);
					TakeScreenshot.screenshot(driver,etest);		
					TakeScreenshot.screenshot(visitor_driver,etest);	
				}
				try{
					WebElement elmt = driver.findElement(By.id("vdeptid"));
					if(ResourceManager.getRealValue("filter_department").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("vdeptid")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CQ29")+" is checked");

                        result.put("CQ29", true);
					}
                    else
                    {
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
                catch(Exception e)
				{
					TakeScreenshot.log(e,etest);
					TakeScreenshot.screenshot(driver,etest);		
					TakeScreenshot.screenshot(visitor_driver,etest);	
				}
				try{
					WebElement elmt = driver.findElement(By.id("lsid"));
					if(ResourceManager.getRealValue("filter_embed").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("lsid")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CQ30")+" is checked");

                        result.put("CQ30", true);
					}
                    else
                    {
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
                catch(Exception e)
				{
					TakeScreenshot.log(e,etest);
					TakeScreenshot.screenshot(driver,etest);		
					TakeScreenshot.screenshot(visitor_driver,etest);	
				}
				try{
					WebElement elmt = driver.findElement(By.id("timekey"));
					if(ResourceManager.getRealValue("filter_date").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("timevalue")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CQ31")+" is checked");

                        result.put("CQ31", true);
					}
                    else
                    {
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
                catch(Exception e)
				{
					TakeScreenshot.log(e,etest);
					TakeScreenshot.screenshot(driver,etest);		
					TakeScreenshot.screenshot(visitor_driver,etest);	
				}
				try{
					WebElement elmt = driver.findElement(By.id("vintegstatus"));
					if(ResourceManager.getRealValue("filter_integ").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("vintegstatus")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CQ32")+" is checked");

                        result.put("CQ32", true);
					}
                    else
                    {
            			TakeScreenshot.screenshot(driver,etest);
                    }
				}
                catch(Exception e)
				{
					TakeScreenshot.log(e,etest);
					TakeScreenshot.screenshot(driver,etest);		
					TakeScreenshot.screenshot(visitor_driver,etest);	
				}
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("cushistoryfilter")).click();
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
			}

			WebElement history = history_content.findElement(By.id("historylist"));
			CommonWait.waitTillDisplayed(history);
			try
			{
				WebElement header = history.findElement(By.className("un-sel"));
				String header1 = header.findElement(By.className("secnd-clm")).findElement(By.tagName("div")).getText();
				String header2 = header.findElement(By.className("thrd-clm")).findElement(By.tagName("div")).getText();
				String header3 = header.findElement(By.className("four-clm")).findElement(By.tagName("div")).getText();
				if((ResourceManager.getRealValue("history_nameemail").equals(header1)) && (ResourceManager.getRealValue("history_questime").equals(header2)) && (ResourceManager.getRealValue("history_owner").equals(header3)))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CQ33")+" is checked");

                    result.put("CQ33", true);
				}
                else
                {
                    etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("history_nameemail")+","+ResourceManager.getRealValue("history_questime")+","+ResourceManager.getRealValue("history_owner")+"--Actual"+header1+"--"+header2+"--"+header3+"--");
            		TakeScreenshot.screenshot(driver,etest);
                }
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver,etest);		
				TakeScreenshot.screenshot(visitor_driver,etest);	
			}
			List<WebElement> tr = history.findElements(By.className("cursr-point"));
			WebElement scolumn = tr.get(0).findElement(By.className("secnd-clm"));
			WebElement column = tr.get(0).findElement(By.className("thrd-clm"));
			CommonWait.waitTillDisplayed(scolumn);
			if(("test".equals(scolumn.findElement(By.tagName("h2")).getText())) && ("test@test.com".equals(scolumn.findElement(By.tagName("div")).getText())))
			{
				if((visitorid.equals(column.findElement(By.className("grayee")).findElement(By.tagName("span")).getText())) && ((column.findElement(By.className("grayee")).getText()).contains("qwer")))
				{
					if(time.equals(column.findElement(By.className("grayish")).findElements(By.tagName("span")).get(0).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CQ34")+" is checked");
                        result.put("CQ34",true);
					}
                    else
                    {
                        etest.log(Status.FAIL,"MismatchContent:"+time);
                        TakeScreenshot.screenshot(driver,etest);
                    }
				}
                else
                {
					etest.log(Status.FAIL,"MismatchContent:"+visitorid+","+column);	
        			TakeScreenshot.screenshot(driver,etest);
                }
			}
            else
            {
            	etest.log(Status.FAIL,"MismatchContent:test,test@test.com");
            	TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
	}

	public static boolean checkAcceptChatFromNotification(WebDriver driver,ExtentTest etest)
	{
		try
		{
			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.PASS,KeyManager.getRealValue("CQ37")+"is checked");
			visitorid = driver.findElement(By.id("msgtablediv")).findElements(By.className("lvst_idtxt")).get(0).getText();
			String timestr = driver.findElement(By.id("msgtablediv")).findElements(By.className("t-v-subtxt")).get(0).getText();
			time = (timestr.split(" by"))[0];
			time = "Today at "+time;
			time = time.trim();
			time = time.substring(0, time.lastIndexOf(":"))+time.substring(time.lastIndexOf(" "),time.length());
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkBlockIP(WebDriver driver,ExtentTest etest)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("moreaction")).click();
			CommonWait.waitTillDisplayed(driver,By.id("divcontainer"));

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if((ResourceManager.getRealValue("chatsessionendopt3").equals(el.findElement(By.tagName("a")).getText())))
					{
						el.findElement(By.tagName("a")).click();
						wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupmn")));
                        CommonSikuli.findInWholePage(driver,"Blockipclose.png","UI119",etest);
                        WebElement elmt2 = driver.findElement(By.className("lvd_popupmn")).findElement(By.className("lvd_popupsub")).findElement(By.className("lvd_popupcnt")).findElement(By.className("lvd_popuptitle"));
						if((ResourceManager.getRealValue("blockip_text")).equals(elmt2.getText()))
						{
							driver. findElement(By.className("lvd_popupmn")).findElement(By.className("lvd_popupsub")).findElement(By.id("popupftr")).findElement(By.id("cancelbtn")).click();
							CommonWait.waitTillHidden(driver,By.className("lvd_popupmn"));
							try
							{
								driver.findElement(By.className("lvd_popupmn")).click();
                                etest.log(Status.FAIL,"Chat window exists after blocking IP");
							}
							catch(Exception e)
							{
								etest.log(Status.PASS,KeyManager.getRealValue("CQ38")+" is checked");
                                return true;
							}
						}
                        else
                        {
                            etest.log(Status.FAIL,"MismatchContent:"+ResourceManager.getRealValue("blockip_text"));
                        }
						driver.findElement(By.className("lvd_popupmn")).findElement(By.className("lvd_popupsub")).findElement(By.id("popupftr")).findElement(By.id("cancelbtn")).click();
						break;
					}
				}
                etest.log(Status.FAIL,"MismatchContent : "+ResourceManager.getRealValue("chatsessionendopt3"));
                TakeScreenshot.screenshot(driver,etest);
			}
            else
            {
            	etest.log(Status.FAIL,"There area no actions");
            	TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkShareURL(WebDriver driver,ExtentTest etest)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("moreaction")).click();
			CommonWait.waitTillDisplayed(driver,By.id("divcontainer"));

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if((ResourceManager.getRealValue("action_shareurl").equals(el.findElement(By.tagName("a")).getText())))
					{
						el.findElement(By.tagName("a")).click();

                        CommonSikuli.findInWholePage(driver,"Shareurlclose.png","UI120",etest);
						wait.until(ExpectedConditions.presenceOfElementLocated(By.id("pushmsgdiv")));

						driver.findElement(By.id("pushmsg")).click();
						driver.findElement(By.id("pushmsg")).clear();
						driver.findElement(By.id("pushmsg")).sendKeys("www.zoho.com");
						CommonWait.waitTillDisplayed(driver,By.id("dlgbox"));
                        driver.findElement(By.id("dlgbox")).findElement(By.tagName("form")).findElement(By.className("actionbtn-base")).findElement(By.className("cnfmbtm")).click();
                        VisitorWindow.switchToChatWidget(visitor_driver);
						CommonWait.waitTillDisplayed(visitor_driver,By.id("info_banr"));

                        String info = VisitorWindow.getInfoBannerMessage(visitor_driver);
                        
                        System.out.println("<>ShareUrlText<>"+info+"<><>");

						if((info).contains(ResourceManager.getRealValue("shareurl")))
						{
							wait = CommonUtil.waitreturner(driver,30,250);
							etest.log(Status.PASS,KeyManager.getRealValue("CQ39")+" is checked");

                            return true;
						}
                        else
                        {
                            etest.log(Status.FAIL,"MismatchContent:"+ResourceManager.getRealValue("shareurltext"));
                            TakeScreenshot.screenshot(driver,etest);
                            TakeScreenshot.screenshot(visitor_driver,etest);
                        }
						wait = CommonUtil.waitreturner(driver,30,250);
						break;
					}
                }
                etest.log(Status.FAIL,"Share URL is Not Present");
                TakeScreenshot.screenshot(driver,etest);
			}
            else
            {
                etest.log(Status.FAIL,"ThereIsNoActions");
                TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkTransferChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("moreaction")).click();
			CommonWait.waitTillDisplayed(driver,By.id("divcontainer"));

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if((ResourceManager.getRealValue("action_transferchat").equals(el.findElement(By.tagName("a")).getText())))
					{
						el.findElement(By.tagName("a")).click();
						wait.until(ExpectedConditions.presenceOfElementLocated(By.className("modal-window")));
						CommonSikuli.findInWholePage(driver,"Transferchatclose.png","UI121",etest);
						WebElement elmt2 = driver.findElement(By.className("modal-window"));

						if((ResourceManager.getRealValue("action_transferchat")).equals(elmt2.findElement(By.className("modal-header")).findElement(By.tagName("h4")).getText()))
						{

                            driver.findElement(By.id("popupdiv")).findElement(By.className("modal-header")).findElement(By.tagName("em")).click();

                            etest.log(Status.PASS,KeyManager.getRealValue("CQ40")+" is checked");

                            return true;
						}
                        else
                        {
                            etest.log(Status.FAIL,KeyManager.getRealValue("CQ40")+" is failed");
                            TakeScreenshot.screenshot(driver,etest);
                        }
						break;
					}
				}
				etest.log(Status.FAIL,"TransferChatisNotPresent");
                TakeScreenshot.screenshot(driver,etest);
			}
            else
            {
            	etest.log(Status.FAIL,"ThereIsNoActions");
                TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkAllOptionsWithEndSession(WebDriver driver,ExtentTest etest)
	{
		try
		{
			ArrayList endsession = new ArrayList();
			endsession.add(ResourceManager.getRealValue("endsession_90secs"));
			endsession.add(ResourceManager.getRealValue("endsession_60secs"));
			endsession.add(ResourceManager.getRealValue("endsession_45secs"));
			endsession.add(ResourceManager.getRealValue("endsession_30secs"));
			endsession.add(ResourceManager.getRealValue("endsession_endimd"));

			driver.findElement(By.id("endsession")).click();

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(endsession.size() == elmts.size())
			{
				for(WebElement el:elmts)
				{
					if(!(endsession.contains(el.findElement(By.tagName("a")).getText())))
					{
						etest.log(Status.FAIL,"Default EndSession Does Not Contains:"+el.findElement(By.tagName("a")).getText());
						TakeScreenshot.screenshot(driver,etest);
                        return false;
					}
				}
				etest.log(Status.PASS,KeyManager.getRealValue("CQ41")+" is checked");

                return true;
			}
            else
            {
                etest.log(Status.FAIL,"EndsessionDefaultCountMismatch");
                TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkMoreActions(WebDriver driver,ExtentTest etest)
	{
		try
		{
			ArrayList moreactions = new ArrayList();
			moreactions.add(ResourceManager.getRealValue("chatsessionendopt3"));
			moreactions.add(ResourceManager.getRealValue("action_shareurl"));
			moreactions.add(ResourceManager.getRealValue("action_transferchat"));
            moreactions.add(ResourceManager.getRealValue("action_translatechat"));
            moreactions.add(ResourceManager.getRealValue("action_inviteusers"));
			moreactions.add(ResourceManager.getRealValue("action_share_screen"));
			moreactions.add(ResourceManager.getRealValue("action_visitor_share_screen"));

			driver.findElement(By.id("moreaction")).click();
			CommonWait.waitTillDisplayed(driver,By.id("divcontainer"));

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

            int chsize = moreactions.size();

			if(elmts.size() != 0)
			{
				for(WebElement el:elmts)
				{
                    chsize--;
                    if(chsize>=0)
                    {
                        if(!(moreactions.contains((el.findElement(By.tagName("a")).getText()))))
                        {
                            etest.log(Status.FAIL,"Default More Sessions Does Not Contains"+el.findElement(By.tagName("a")).getText());
                            TakeScreenshot.screenshot(driver,etest);
                            return false;
                        }
                    }
				}
				etest.log(Status.PASS,KeyManager.getRealValue("CQ42")+" is checked");

                return true;
			}
            else
            {
                etest.log(Status.FAIL,"More Actions Default Count Mismatch");
                TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		return false;
	}

	public static boolean checkMoreOptionsVisitorSide(WebDriver driver,ExtentTest etest)
	{
		try
		{
			VisitorWindow.checkOptions(visitor_driver);
			etest.log(Status.PASS,KeyManager.getRealValue("CQ43")+" is checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.log(e,etest);
			TakeScreenshot.screenshot(driver,etest);		
			TakeScreenshot.screenshot(visitor_driver,etest);	
		}
		TakeScreenshot.screenshot(driver,etest);
		TakeScreenshot.screenshot(visitor_driver,etest);
		return false;
	}

}
