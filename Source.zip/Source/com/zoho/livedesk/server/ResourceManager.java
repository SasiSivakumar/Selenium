//$Id$
package com.zoho.livedesk.server;

import java.io.FileInputStream;
import java.util.Properties;

import com.zoho.qa.server.WebdriverQAUtil;

public class ResourceManager {
	
	private static String resourcepath = WebdriverQAUtil.getAttachmentPath("ldresource.properties");
	public static Properties prop = getProperties(resourcepath);
	public static String getRealValue(String key)
	{
		try
		{
			if(resourcepath.contains("null"))
			{
				resourcepath = resourcepath.replace("null","salesiq");
				prop = getProperties(resourcepath);
			}
			String val = null;
			val = prop.getProperty(key,val);
			if(val != null)
			{
				if(key.contains("Theme"))
				{
					val =  val.replace("$","'");
				}
					
				val=val.replace("<apostrophe>","’");

				return val;
			}
		}
		catch(Exception e){}
		return key;
	}
	
	public static Properties getProperties(String propsFile)
    {
            try
            {
                    Properties props = new Properties();
                    props.load(new FileInputStream(propsFile));
                    return props;
            }
            catch (Exception exp)
            {
                    return null;
            }
    }
}
