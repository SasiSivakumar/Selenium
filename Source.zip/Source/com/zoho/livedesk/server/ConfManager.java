//$Id$
package com.zoho.livedesk.server;

import java.io.FileInputStream;
import java.util.Properties;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;

public class ConfManager {

	
	private static String login_url = null;
	private static String login_name = null;
	private static String login_password = null;
	private static String screenname = null;
	private static String portalname= null;
	private static String lang = null;
	private static String setup = null;
	private static String browser = null;
	private static String build = null;
	private static String ccemailaddr = null;
	private static String fromemailaddr = null;
	private static String toemailaddr = null;
    private static String adminaddr = null;
	private static String username = null;
	private static String clearmodules = null;
	private static String modules = null;
    private static String integration_modules = null;
    private static String automation_modules = null;
    private static String chatwidget_modules = null;
    private static String modules5 = null;
    private static String other_modules = null;
    private static String crmplus_modules = null;
    private static String modulenames = null;
	private static String ignore_modules = null;
    private static String mailUsername = null;
    private static String mailPassword = null;
    private static String channelID = null;
    private static String authToken = null;
    private static String super_name = null;
    private static String super_password = null;
    private static String asso_name = null;
    private static String asso_password = null;
    private static String crm_login_name = null;
    private static String crm_login_password = null;
    private static String embed_login_name = null;
    private static String embed_login_password = null;
    private static String tracking_login_name = null;
    private static String tracking_login_password = null;
    private static String js_login_name = null;
    private static String js_login_password = null;
    private static String supermodules = null;
    private static String assomodules = null;
    private static String assomodulenames = null;
    private static String supermodulenames = null;
    private static String crmmodulenames = null;
    private static String trackingmodulenames = null;
    private static String checkingURL = null;
    private static String trackingportal = null;
    private static String trackingembed = null;
    private static String jsportal = null;
    private static String jsembed = null;
    private static String weportal = null;
    private static String weembed = null;
    private static String successThresh = null;
    private static String maximumFailPercent = null;
    private static String timeOutWait = null;
    private static String freeplan_login_name = null;
    private static String enterprise_login_name = null;
    private static String prof_login_name = null;
    private static String basic_login_name = null;
    private static String plan_login_password = null;
    private static String campaign_login_name = null;
    private static String campaign_login_password = null;
    private static String campaignembedname = null;
    private static String campaignportalname = null;
    private static String chatmonitorembedname = null;
    private static String chatmonitorportalname = null;
    private static String transferchatembedname = null;
    private static String transferchatportalname = null;
    private static String chatmonitor_supervisor_login_name = null;
    private static String chatmonitor_supervisor_login_password = null;
    private static String chatmonitor_associate_login_name = null;
    private static String chatmonitor_associate_login_password = null;
    
    public static void init()
	{
		try
		{
			String serverconf = WebdriverQAUtil.getAttachmentPath("livedeskconf.properties");
			serverconf = serverconf.replace("null","salesiq");
			Properties prop = getProperties(serverconf);
			login_name = prop.getProperty("login_name",login_name);
			login_password = prop.getProperty("login_password",login_password);
            super_name = prop.getProperty("super_name",super_name);
            super_password = prop.getProperty("super_password",super_password);
            asso_name = prop.getProperty("asso_name",asso_name);
            asso_password = prop.getProperty("asso_password",asso_password);
            crm_login_name = prop.getProperty("crm_login_name",crm_login_name);
            crm_login_password = prop.getProperty("crm_login_password",crm_login_password);
            embed_login_name = prop.getProperty("embed_login_name",embed_login_name);
            embed_login_password = prop.getProperty("embed_login_password",embed_login_password);
            tracking_login_name = prop.getProperty("tracking_login_name",tracking_login_name);
            tracking_login_password = prop.getProperty("tracking_login_password",tracking_login_password);
            js_login_name = prop.getProperty("js_login_name",js_login_name);
            js_login_password = prop.getProperty("js_login_password",js_login_password);
			screenname = prop.getProperty("screenname",screenname);
			setup = WebdriverQAUtil.getCurrentSetupURL();
			if(setup == null)
			{
				setup = prop.getProperty("setup", setup);
			}
			login_url = setup+"/"+screenname;
			lang = prop.getProperty("lang", lang);
			portalname = prop.getProperty("portalname",portalname);
			browser = prop.getProperty("browser", browser);
			build = prop.getProperty("build", build);
			ccemailaddr = prop.getProperty("ccemailaddr", ccemailaddr);
			fromemailaddr = prop.getProperty("fromemailaddr", fromemailaddr);
			toemailaddr = prop.getProperty("toemailaddr", toemailaddr);
            adminaddr = prop.getProperty("adminaddr", adminaddr);
			username = prop.getProperty("username", username);
			clearmodules = prop.getProperty("clearmodules", clearmodules);
			modules = prop.getProperty("modules", modules);
            integration_modules = prop.getProperty("integration_modules", integration_modules);
            automation_modules = prop.getProperty("automation_modules", automation_modules);
            chatwidget_modules = prop.getProperty("chatwidget_modules",chatwidget_modules);
            modules5 = prop.getProperty("salesiq5_modules",modules5);
            other_modules = prop.getProperty("other_modules",other_modules);
            crmplus_modules = prop.getProperty("crmplus_modules",crmplus_modules);
            supermodules = prop.getProperty("supermodules",supermodules);
            assomodules = prop.getProperty("assomodules",assomodules);
            modulenames = prop.getProperty("module_names", modulenames);
            supermodulenames = prop.getProperty("supermodule_names",supermodulenames);
            assomodulenames = prop.getProperty("assomodule_names",assomodulenames);
            crmmodulenames = prop.getProperty("crmmodule_names",crmmodulenames);
            trackingmodulenames = prop.getProperty("trackingmodule_names",trackingmodulenames);
			ignore_modules = prop.getProperty("ignore_modules", ignore_modules);
            mailUsername = prop.getProperty("mailUsername", mailUsername);
            mailPassword = prop.getProperty("mailPassword", mailPassword);
            channelID = prop.getProperty("channelID", channelID);
            authToken = prop.getProperty("authToken", authToken);
            checkingURL = prop.getProperty("checkingURL",checkingURL);
            trackingembed = prop.getProperty("trackingembed",trackingembed);
            trackingportal = prop.getProperty("trackingportal",trackingportal);
            jsembed = prop.getProperty("jsembed",jsembed);
            jsportal = prop.getProperty("jsportal",jsportal);
            weembed = prop.getProperty("weembed",weembed);
            weportal = prop.getProperty("weportal",weportal);
            successThresh = prop.getProperty("successThresh",successThresh);
            maximumFailPercent = prop.getProperty("maximumFailPercent",maximumFailPercent);
            timeOutWait = prop.getProperty("timeOutWait",timeOutWait);
            freeplan_login_name = prop.getProperty("freeplan_login_name",freeplan_login_name);
            enterprise_login_name = prop.getProperty("enterprise_login_name",enterprise_login_name);
            prof_login_name = prop.getProperty("prof_login_name",prof_login_name);
            basic_login_name = prop.getProperty("basic_login_name",basic_login_name);
            plan_login_password = prop.getProperty("plan_login_password",plan_login_password);
            campaign_login_name = prop.getProperty("campaign_login_name",campaign_login_name);
            campaign_login_password = prop.getProperty("campaign_login_password",campaign_login_password);
            campaignembedname = prop.getProperty("campaignembedname",campaignembedname);
            campaignportalname = prop.getProperty("campaignportalname",campaignportalname);
            chatmonitor_supervisor_login_name = prop.getProperty("chatmonitor_supervisor_login_name",chatmonitor_supervisor_login_name);
            chatmonitor_supervisor_login_password = prop.getProperty("chatmonitor_supervisor_login_password",chatmonitor_supervisor_login_password);
            chatmonitor_associate_login_name = prop.getProperty("chatmonitor_associate_login_name",chatmonitor_associate_login_name);
            chatmonitor_associate_login_password = prop.getProperty("chatmonitor_associate_login_password",chatmonitor_associate_login_password);
            chatmonitorembedname = prop.getProperty("chatmonitorembedname",chatmonitorembedname);
            chatmonitorportalname = prop.getProperty("chatmonitorportalname",chatmonitorportalname);
            transferchatembedname = prop.getProperty("transferchatembedname",transferchatembedname);
            transferchatportalname = prop.getProperty("transferchatportalname",transferchatportalname);
        }
		catch(Exception e)
		{}
	}
	
	public static String getLoginName()
	{
		return login_name;
	}
	
	public static String getLoginPswd()
	{
		return login_password;
	}
    
    public static String getSuperName()
    {
        return super_name;
    }
    
    public static String getSuperPswd()
    {
        return super_password;
    }
    
    public static String getAssoName()
    {
        return asso_name;
    }
    
    public static String getAssoPswd()
    {
        return asso_password;
    }
    
    public static String getCRMLoginName()
    {
        return crm_login_name;
    }
    
    public static String getCRMLoginPswd()
    {
        return crm_login_password;
    }
    
    public static String getEmbedLoginName()
    {
        return embed_login_name;
    }
    
    public static String getEmbedLoginPswd()
    {
        return embed_login_password;
    }
    
    public static String getTrackingLoginName()
    {
        return tracking_login_name;
    }
    
    public static String getTrackingLoginPswd()
    {
        return tracking_login_password;
    }
    
    public static String getJSLoginName()
    {
        return js_login_name;
    }
    
    public static String getJSLoginPswd()
    {
        return js_login_password;
    }
    
    public static String getLoginURL()
	{
		if(WebdriverQAUtil.getPortalName() != null && WebdriverQAUtil.getPortalName() != "")
		{
			login_url = setup+"/"+WebdriverQAUtil.getPortalName();
		}
		return login_url;
	}
	
    public static String getScreenname()
    {
        return screenname;
    }
	public static String getPortalName()
	{
		if(WebdriverQAUtil.getPortalName() != null && WebdriverQAUtil.getPortalName() != "")
		{
			portalname = WebdriverQAUtil.getPortalName();
		}
		return portalname;
	}
	
	public static String getLanguage()
	{
		if("en".equals(lang))
		{
			return "";
		}
		return lang;
	}

	public static void setBrowser(String sbrowser)
	{
		browser = sbrowser;
	}
	
	public static String getBrowser()
	{
		return browser;
	}
	
	public static String getSetup()
	{
		return setup;
	}

	public static String requestURL()
	{
		String url = setup+"/abcd1234";
		return url;
	}
    
    public static String getCheckingURL()
    {
        return checkingURL;
    }
	
	public static String getBuild()
	{
		return build;
	}

	public static String getReportFromAddr()
	{
		return fromemailaddr;
	}

	public static String getToEmailAddr()
	{
		return toemailaddr;
	}
	
	public static String getCcEmailAddr()
	{
		return ccemailaddr;
	}
	
    public static String getAdminAddr()
    {
        return adminaddr;
    }
    
	public static String getUserName()
	{
		return username;
	}

	public static String ignoreModules()
	{
		return ignore_modules;
	}

	public static boolean clearModules()
	{
		return Boolean.parseBoolean(clearmodules);
	}

	public static void setModules()
	{
		if(WebdriverQAUtil.getModule() != null && WebdriverQAUtil.getModule() != "")
		{
			modules = WebdriverQAUtil.getModule();
		}
	}

	public static String getModules()
	{
		return modules;
	}

    public static String getIntegrationModules()
    {
        return integration_modules;
    }

    public static String getAutomationModules()
    {
        return automation_modules;
    }
    
    public static String getChatWidgetModules()
    {
        return chatwidget_modules;
    }
    
    public static String getModules5()
    {
        return modules5;
    }
    
    public static String getOtherModules()
    {
        return other_modules;
    }

    public static String getCRMPlusModules()
    {
        return crmplus_modules;
    }
    
    public static String getSuperModules()
    {
        return supermodules;
    }
    
    public static String getAssoModules()
    {
        return assomodules;
    }

    public static String getModuleNames()
	{
		return modulenames;
	}
    
    public static String getSuperModuleNames()
	{
		return supermodulenames;
	}
    
    public static String getAssoModuleNames()
	{
		return assomodulenames;
	}
    
    public static String getCRMModuleNames()
    {
        return crmmodulenames;
    }
        
    public static String getTrackingModuleNames()
    {
        return trackingmodulenames;
    }
    
    public static String getUname()
    {
        return mailUsername;
    }
	
    public static String getPassword()
    {
        return mailPassword;
    }
    
    public static String getAuthToken()
    {
        if(WebdriverQAUtil.getAuthToken()!=null && WebdriverQAUtil.getAuthToken().equals("")==false)
        {
            return WebdriverQAUtil.getAuthToken();
        }

        return ConfManager.getRealValue("authToken");
    }
    
    public static String getChannelID()
    {
        return getChannelID(false);
    }

    public static String forceGetChannelID()
    {
        return getChannelID(true);
    }
    
    public static String getChannelID(boolean isForceGet)
    {
        if(isForceGet==false)
        {
            if(SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
            {
                return ConfManager.getRealValue("automation_dev_channel");
            }
        }

        if(WebdriverQAUtil.getChannelID()!=null && WebdriverQAUtil.getChannelID().equals("")==false)
        {
            return WebdriverQAUtil.getChannelID();
        }

        return ConfManager.getRealValue("channelID");
    }
    
    public static String trackingPortal()
    {
        return trackingportal;
    }

    public static String trackingEmbed()
    {
        return trackingembed;
    }
    
    public static String getJsPortal()
    {
        return jsportal;
    }
    
    public static String getJsEmbed()
    {
        return jsembed;
    }
    
    public static String getWEportal()
    {
        return weportal;
    }
    
    public static String getWEembed()
    {
        return weembed;
    }
    
    public static String getSuccessThresh()
    {
        return successThresh;
    }
    
    public static String getMaximumFailPercent()
    {
        return maximumFailPercent;
    }
    
    public static String getScheduleTimeOut()
    {
        return timeOutWait;
    }

    public static String getFreeplanusername()
    {
        return freeplan_login_name;
    }

    public static String getEnterpriseusername()
    {
        return enterprise_login_name;
    }

    public static String getProfusername()
    {
        return prof_login_name;
    }

    public static String getBasicusername()
    {
        return basic_login_name;
    }
    
    public static String getPlanLoginPwsd()
    {
        return plan_login_password;
    }
    
    public static String getCampaignUsername()
    {
        return campaign_login_name;
    }
    
    public static String getCampaignLoginPwsd()
    {
        return campaign_login_password;
    }
    
    public static String getCampaignEmbedName()
    {
        return campaignembedname;
    }
    
    public static String getCampaignPortalName()
    {
        return campaignportalname;
    }

    public static String getChatmonitorEmbedName()
    {
        return chatmonitorembedname;
    }
    
    public static String getChatmonitorPortalName()
    {
        return chatmonitorportalname;
    }

    public static String getTransferChatEmbedName()
    {
        return transferchatembedname;
    }
    
    public static String getTransferChatPortalName()
    {
        return transferchatportalname;
    }

    public static String getChatMonitorSupervisorUsername()
    {
        return chatmonitor_supervisor_login_name;
    }
    
    public static String getChatMonitorSupervisorLoginPwsd()
    {
        return chatmonitor_supervisor_login_password;
    }

    public static String getChatMonitorAssociateUsername()
    {
        return chatmonitor_associate_login_name;
    }
    
    public static String getChatMonitorAssociateLoginPwsd()
    {
        return chatmonitor_associate_login_password;
    }

    public static Properties getProperties(String propsFile)
    {
            try
            {
                    Properties props = new Properties();
                    props.load(new FileInputStream(propsFile));
                    return props;
            }
            catch (Exception exp)
            {
                    return null;
            }
    }
	
    public static String getRealValue(String key)
    {
        String resourcepath = WebdriverQAUtil.getAttachmentPath("livedeskconf.properties");
        Properties prop = getProperties(resourcepath);
    
        try
        {
            if(resourcepath.contains("null"))
            {
                resourcepath = resourcepath.replace("null","salesiq");
                prop = getProperties(resourcepath);
            }
            String val = null;
            val = prop.getProperty(key,val);
            if(val != null)
            {
                return val;
            }
        }
        catch(Exception e){}
        return key;
    }
}
