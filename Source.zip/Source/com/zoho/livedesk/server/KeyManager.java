//$Id$
package com.zoho.livedesk.server;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

import com.zoho.qa.server.WebdriverQAUtil;

public class KeyManager 
{

	private static String resourcepath = WebdriverQAUtil.getAttachmentPath("ldkeys.properties");
	public static Properties prop = getProperties(resourcepath);
	public static String getRealValue(String key)
	{
		try
		{
			if(resourcepath.contains("null"))
			{
				resourcepath = resourcepath.replace("null","salesiq");
				prop = getProperties(resourcepath);
			}
			String val = null;
			val = prop.getProperty(key,val);
			if(val != null)
			{
				return val;
			}
		}
		catch(Exception e){}
		return key;
	}

	public static Hashtable<String,String> getDBResultHashtable(Hashtable<String,Boolean> final_result)
	{
		Hashtable<String,String> db_result=new Hashtable<String,String>();

		ArrayList<String> skipped_cases=getSkippedCases(final_result);

		for(String skipped_case : skipped_cases)
		{
			db_result.put(skipped_case,"skipped");
		}

        Set<String> keys = final_result.keySet();

        for(String key: keys)
        {
        	if(final_result.get(key))
        	{
        		db_result.put(key,"pass");
        	}
        	else
        	{
        		db_result.put(key,"fail");
        	}
        }

		return db_result;
	}

	public static boolean isKeyWhitelisted(String key)
	{
		ArrayList<String> whitelisted_keys=getWhitelistedKeys();

		for(String whitelisted_key : whitelisted_keys)
		{
			if(key.matches(whitelisted_key))
			{
				return true;
			}
		}

		return false;
	}

	public static ArrayList<String> getWhitelistedKeys()
	{
		/*Whitelisted keys wont be considered as skipped*/
		ArrayList<String> whitelisted_keys=new ArrayList<String>();
		
		whitelisted_keys.add("CQ\\d+");
		whitelisted_keys.add("MA\\d+");

		return whitelisted_keys;
	}

	public static ArrayList<String> getSkippedCases(Hashtable<String,Boolean> final_result)
	{
		ArrayList<String> skipped_cases=new ArrayList<String>();

		List final_result_keys=new ArrayList <String>();
		List property_file_keys=new ArrayList <String>();

		final_result_keys.addAll(final_result.keySet());
		property_file_keys.addAll(prop.keySet());

		for(Object property_file_key : property_file_keys)
		{
			String property_file_key_str=property_file_key.toString();

			if(final_result_keys.contains(property_file_key_str)==false && !isKeyWhitelisted(property_file_key_str))
			{
				skipped_cases.add(property_file_key.toString());
			}
		}

		return skipped_cases;
	}

	public static Hashtable<String,Boolean> getDummyResult()
	{
		/*Method to be used for code testing purposes only. It generates a dummy final result hashtable*/

		Hashtable<String,Boolean> result=new Hashtable<String,Boolean>();

		List property_file_keys=new ArrayList <String>();

		property_file_keys.addAll(prop.keySet());

		for(Object property_file_key : property_file_keys)
		{
			String key=property_file_key.toString();

 			int rand=(int)(Math.random() * 1000 + 1);

 			if(rand%3==0)
 			{
 				result.put(key, true);
 			}
 			else if(rand%3==1)
 			{
 				result.put(key, false);
 			}
 			//if above two conditions not matches usecase will be added as skipped
		}

		Hashtable ht=new Hashtable();

		ht.put("result",result);
		ht.put("servicedown",new Hashtable());

		return ht;
	}

	public static void logSkippedUsecases(Hashtable<String,Boolean> final_result)
	{
		try
		{
			if(final_result.keySet().size()<250)
			{
				return;
			}

			List final_result_keys=new ArrayList <String>();
			List property_file_keys=new ArrayList <String>();

			final_result_keys.addAll(final_result.keySet());
			property_file_keys.addAll(prop.keySet());

			System.out.println("---------------------------------SKIPPED USE CASES LIST BEGINS---------------------------------");

			for(Object property_file_key : property_file_keys)
			{
				if(final_result_keys.contains(property_file_key.toString())==false)
				{
					System.out.println(property_file_key.toString()+"="+getRealValue(property_file_key.toString()));
				}
			}

			System.out.println("---------------------------------SKIPPED USE CASES LIST ENDS---------------------------------");

			System.out.println("---------------------------------KEYS MISSING IN PROPERTY FILE LIST BEGINS---------------------------------");

			for(Object final_result_key : final_result_keys)
			{
				if(property_file_keys.contains(final_result_key.toString())==false)
				{
					System.out.println(final_result_key.toString());
				}
			}

			System.out.println("---------------------------------KEYS MISSING IN PROPERTY FILE LIST ENDS---------------------------------");


			System.out.println("---------------------------------FAILED CASES LIST BEGINS---------------------------------");

			for(Object final_result_key : final_result_keys)
			{
				if(final_result.get(final_result_key.toString())==false)
				{
					System.out.println(final_result_key.toString()+"="+getRealValue(final_result_key.toString()));
				}
			}

			System.out.println("---------------------------------FAILED CASES LIST ENDS---------------------------------");

		}	
		catch(Exception e)
		{
			System.out.println("~~Error while analysing final result hashtable.");
			e.printStackTrace();
		}		
	}

	public static Properties getProperties(String propsFile)
	{
		try
		{
			Properties props = new Properties();
			props.load(new FileInputStream(propsFile));
			return props;
		}
		catch (Exception exp)
		{
			exp.printStackTrace();
			return null;
		}
	}
}

