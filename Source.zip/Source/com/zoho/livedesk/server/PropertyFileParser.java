//$Id$
package com.zoho.livedesk.server;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.common.actions.FileUpload;
import java.io.*;

public class PropertyFileParser {

    public String filename;

    public PropertyFileParser(String filename)
    {
        this.filename=filename;

        try
        {
            FileUpload.createFileIfNotExists(WebdriverQAUtil.getAttachmentPath(filename));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public Properties getProperties(String propsFile)
    {
            try
            {
                    Properties props = new Properties();
                    props.load(new FileInputStream(propsFile));
                    return props;
            }
            catch (Exception exp)
            {
                    return null;
            }
    }
	
    public String getRealValue(String key)
    {
        String resourcepath = WebdriverQAUtil.getAttachmentPath(filename);

        Properties prop = getProperties(resourcepath);

        try
        {
            if(resourcepath.contains("null"))
            {
                resourcepath = resourcepath.replace("null","salesiq");
                prop = getProperties(resourcepath);
            }

            String val = null;
            val = prop.getProperty(key,val);
            if(val != null)
            {
                return val;
            }
        }
        catch(Exception e){}

        return key;
    }

    public void set(String key,String value)  throws FileNotFoundException,IOException
    {
        set(key,value,"No Comment");
    }

    public void set(String key,String value,String comment) throws FileNotFoundException,IOException
    {
        String resourcepath = WebdriverQAUtil.getAttachmentPath(filename);
        Properties prop = getProperties(resourcepath);
        prop.setProperty(key, value);
        prop.store(new FileOutputStream(resourcepath),comment);
    }
}
