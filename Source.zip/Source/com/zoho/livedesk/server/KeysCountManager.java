//$Id$
package com.zoho.livedesk.server;

import com.zoho.livedesk.server.PropertyFileParser;

public class KeysCountManager 
{
    public static PropertyFileParser key_count_manager=new PropertyFileParser("usecases_per_module.properties");
    public static String getRealValue(String key)
    {
        return key_count_manager.getRealValue(key);
    }
}