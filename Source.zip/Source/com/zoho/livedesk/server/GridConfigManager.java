//$Id$
package com.zoho.livedesk.server;

import java.io.FileInputStream;
import java.util.Properties;
import com.zoho.livedesk.server.PropertyFileParser;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class GridConfigManager 
{
    public static PropertyFileParser grid_config_manager=new PropertyFileParser("gridconfig.properties");

    public static String getMachineName(String hostname)
    {
        return getRealValue(hostname+"_machinename");
    }
	
    public static String getUserName(String hostname)
    {
    	return getRealValue(hostname+"_username");
    }

    public static String getPassword(String hostname)
    {
    	return getRealValue(hostname+"_password");
    }

    public static String getPrivateKeyPath()
    {
        return "/Users/"+"admin"+"/.ssh/id_rsa";
    }

    public static String getRealValue(String key)
    {
    	String value=grid_config_manager.getRealValue(key);

    	if(value==null || value.equals(key))
    	{
    		throw new ZohoSalesIQRuntimeException("Credentials were not found for key : "+key+", Unknown host name, Please configure the node credentials in gridconfig.properties.");
    	}

        return value;
    }
}
