//$Id$
package com.zoho.livedesk.util.ImageProcessor;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.client.ComplexReportFactory;

public class ImageBreakageDetector
{
	public static ArrayList<String> all_breakages;

	public static final String
	MODULE_NAME="Image Breakages";

	public static void init()
	{
		all_breakages=new ArrayList<String>();
	}

	public static ArrayList<String> getBreakages(WebDriver driver)
	{
		/*
		var all_img_tags=document.getElementsByTagName('img');
		var sikuli_breakages=[];
		
		for(var i=0;i<all_img_tags.length;i++)
		{
			if(all_img_tags[i].naturalWidth==0)
			{
				var src=all_img_tags[i].src;
				if(src.endsWith('.html')==false)
                 {
					sikuli_breakages.push(src);
                 }
			}
		}

		sikuli_breakages.toString();
		*/

		final String script="var all_img_tags=document.getElementsByTagName('img'); var sikuli_breakages=[]; for(var i=0;i<all_img_tags.length;i++) { if(all_img_tags[i].naturalWidth==0) { var src=all_img_tags[i].src; if(src.endsWith('.html')==false) { sikuli_breakages.push(src); } } } return sikuli_breakages.toString();";

		ArrayList<String> image_breakages=new ArrayList<String>();

		try
		{
	        String breakages=(((JavascriptExecutor) driver).executeScript(script)).toString();

	        if(breakages.equals(""))
	        {
	        	return image_breakages;
	        }

	        image_breakages = new ArrayList<String>(Arrays.asList(breakages.split(",")));

	        //removing overall duplicate checks
	        for(String image_breakage : image_breakages)
	        {
	        	if(all_breakages.contains(image_breakage))
	        	{
	        		image_breakages.remove(image_breakage);
	        	}
	        }

	        all_breakages.addAll(image_breakages);

	        return image_breakages;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return image_breakages;
		}
	}

	public static void detect(WebDriver driver)
	{
		detect(driver,null);
	}

	public static void detect(WebDriver driver,ExtentTest etest)
	{
		try
		{
			boolean isNewtest=false;

			if(etest==null)
			{
				isNewtest=true;
			}

			ArrayList<String> breakages=getBreakages(driver);

			if(breakages.isEmpty())
			{
				return;
			}

			if(isNewtest)
			{
				etest=ComplexReportFactory.getTest("Image breakages for URL : "+driver.getCurrentUrl());
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			}

			TakeScreenshot.screenshot(driver,etest);

			for(String breakage : breakages)
			{
				etest.log(Status.FAIL,"Image did not load, src:"+breakage);
			}

			if(isNewtest)
			{
				ComplexReportFactory.closeTest(etest);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
