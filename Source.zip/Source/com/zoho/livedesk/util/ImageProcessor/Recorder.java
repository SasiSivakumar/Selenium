//$Id$
package com.zoho.livedesk.util.ImageProcessor;

import java.net.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Iterator;
import javax.imageio.*;
import javax.imageio.stream.*;
import java.util.UUID;
import com.zoho.livedesk.client.TakeScreenshot;

import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.Util;
import java.nio.file.Files;

public class Recorder 
{

  public static final String end_image=com.zoho.livedesk.util.common.actions.FileUpload.getSampleFilesDirectory()+"end.jpg";

  WebDriver driver;
  ExtentTest etest;

  public static final int FRAMES_PER_SECOND=2;

  public String file_directory;

  public String gif_link;

  ArrayList<String> files;

  private boolean isRecord=false;

  public Recorder(WebDriver driver,ExtentTest etest)
  {
    this.driver=driver;
    this.etest=etest;
    setDirectory();
  }

  public void setDirectory()
  {
    String folder_name=UUID.randomUUID().toString();
    this.file_directory=TakeScreenshot.filePath()+TakeScreenshot.getBuildLabel()+"/GIF_Screenshots/"+folder_name+"/<filename>.jpg";
    this.gif_link="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+TakeScreenshot.getBuildLabel()+"/GIF_Screenshots/"+folder_name+"/<filename>";
    files=new ArrayList<String>();
  }

  public void record() throws SalesIQTestRecorderException
  {
      if(isRecorderActive())
      {
        throw new SalesIQTestRecorderException("Recorder is already recording. Please stop the previous recording isRecorderActive : "+isRecorderActive());
      }

      setIsRecord(true);

      ExecutorService executor = Executors.newFixedThreadPool(100);
     
      RecordWebDriver worker = new RecordWebDriver(this);
      executor.execute(worker);
      executor.shutdown();
        // Wait until all threads are finish
      // while (!executor.isTerminated())
      // {
      //   if(!isRecord)
      //   {
      //     executor.shutdownNow();
      //   }
      // }

  }

  public boolean isRecorderActive()
  {
    return isRecord();
  }

  public boolean isRecord()
  {
    return isRecord;
  }

  public void setIsRecord(boolean isRecord)
  {
    this.isRecord=isRecord;
  }

  public void setGifLink(String gif_path)
  {
    String gif_name=gif_path.split("/")[gif_path.split("/").length-1];
    gif_link=gif_link.replace("<filename>",gif_name);
  }

  public void stop()
  {
    setIsRecord(false);
    try
    {
      String gif_path=createGif();
      setGifLink(gif_path);
      logGif(etest);
      deleteAllScreenshots();
    }
    catch(Exception e)
    {
      e.printStackTrace();      
      String stack_trace=TakeScreenshot.getStacktrace(e);
      String log_info_string=TakeScreenshot.getCustomHTMLForReport("Test recording failed",stack_trace);
      etest.log(Status.WARNING,log_info_string);
    }
  }

  public void logGif(ExtentTest etest)
  {
    try
    {
      etest.addScreenCaptureFromPath(gif_link,"Agent Session");
    }
    catch(Exception e)
    {
      TakeScreenshot.log(e,etest);
    }
  }

  public String createGif() throws Exception
  {
    addEndCard();
    return GifSequenceWriter.writeGif(this.files);
  }

  public void addEndCard()
  {
    this.files.add(end_image);
  }

  public static int getWaitInterval()
  {
    return 1000/FRAMES_PER_SECOND;
  }

  public class RecordWebDriver implements Runnable 
  {
      int file_number;
      Recorder recorder;

      RecordWebDriver(Recorder recorder)
      {
          this.recorder=recorder;
          this.file_number=0;
      }
      
      @Override
      public void run() 
      {
        while(recorder.isRecord())
        {
          takeScreenshot();
        }
      }

      public void takeScreenshot()
      {
        CommonUtil.sleep(recorder.getWaitInterval());
        String file_name=getFilePath();
        recorder.files.add(file_name);
        try
        {
          TakeScreenshot.takeScreenshot(recorder.driver,file_name);
        }
        catch(Exception e)
        {

        }        
      }

      public String getFilePath()
      {
        return recorder.file_directory.replace("<filename>",""+(++file_number));
      }
  }

  public void deleteAllScreenshots()
  {
    for(String filepath : this.files)
    {
      try
      {
        if(filepath.endsWith(".gif")==false && filepath.endsWith("end.jpg")==false)
        {
          File file = new File(filepath);
          Files.deleteIfExists(file.toPath());
        }
      }
      catch(Exception e)
      {
        etest.log(Status.WARNING,"Screenshots taken for gif were not deleted.");
        e.printStackTrace();
      }
    }
    etest.log(Status.INFO,"All files were deleted after gif was created");
    System.out.println("~~All files were deleted.");
  }
}
