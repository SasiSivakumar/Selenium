//$Id$
package com.zoho.livedesk.util.ImageProcessor;


import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Iterator;
import javax.imageio.*;
import javax.imageio.stream.*;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


public class ImageCompressor 
{

  public static void compressAndWrite(File file_to_compress,String file_location) throws IOException 
  {

    File input = file_to_compress;
    BufferedImage image = ImageIO.read(input);

    File compressedImageFile = new File(file_location);
    OutputStream os = new FileOutputStream(compressedImageFile);

    Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
    ImageWriter writer = (ImageWriter) writers.next();

    ImageOutputStream ios = ImageIO.createImageOutputStream(os);
    writer.setOutput(ios);

    ImageWriteParam param = writer.getDefaultWriteParam();

    param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
    param.setCompressionQuality(0.25f);  // Change the quality value you prefer
    writer.write(null, new IIOImage(image, null, null), param);

    os.close();
    ios.close();
    writer.dispose();
  }

/*
  public static void createFilesAsGif(ExtentTest etest,String file_directory)
  {

  }

  public static ArrayList<String> getFileNames(String file_directory)
  {
    ArrayList<String> file_list=new ArrayList<String>();

    File file = new File(file_directory);

    File[] files = file.listFiles();  

    for (File f:files)  
    {  
        System.out.println(f.getAbsolutePath());  
        file_list.add(f.getAbsolutePath());
    }

    return file_list;
  }

  */
}