//$Id$
package com.zoho.livedesk.util.ImageProcessor;

public class SalesIQTestRecorderException extends RuntimeException
{
	public SalesIQTestRecorderException(String message)
	{
		super(message);
	}
}