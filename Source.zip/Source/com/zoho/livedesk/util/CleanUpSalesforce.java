//$Id$
package com.zoho.livedesk.util;

import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.server.ConfManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.common.Driver;

public class CleanUpSalesforce
{
	public static void clean(WebDriver driver1,ExtentTest etest) throws Exception
	{
		String message, verificationCode;
		WebDriver driver = Driver.getCleanupDriver();

		WebDriver mailDriver = Driver.getCleanupDriver();

		try
		{
			mailDriver.get("https://accounts.google.com/");

			driver.get("https://login.salesforce.com/");

			// salesforce login
			CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("username")),ConfManager.getRealValue("salesforce_username"));
			CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("password")),ConfManager.getRealValue("salesforce_password"));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("Login")));
			etest.log(Status.INFO,"Logging in with salesforce");
			TakeScreenshot.infoScreenshot(driver,etest);
			//mail login
			mailLogin(mailDriver,etest);

			//getting verification code
			message = CommonUtil.getElement(mailDriver,By.className("nH")).getText();
			verificationCode = message.substring(message.lastIndexOf("Verification Code:")+19,message.lastIndexOf("Verification Code:")+24);
			etest.log(Status.INFO,"Verification code = "+verificationCode);

			//entering verification code
			CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("emc")),verificationCode);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("save")));

			//click data -> Mass Delete Records
			CommonWait.waitTillDisplayed(driver,By.id("split-left"));
			List<WebElement> listWebElements = CommonUtil.getElement(driver,By.id("split-left")).findElements(By.tagName("li"));
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(listWebElements,"innerText","Data"));

			//delete records
			delete(driver,1,etest);		//Mass Delete Accounts

			delete(driver,2,etest);		//Mass Delete Leads

			delete(driver,4,etest);		//Mass Delete Contacts
		}
		catch(Exception e)
		{
			e.printStackTrace();
			etest.log(Status.WARNING,"Please clean Salesfore account manually");
			TakeScreenshot.log(e,etest);
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(mailDriver,etest);
		}
		finally
		{
			mailLogout(mailDriver);
			salesforceLogout(driver);
			mailDriver.quit();
			driver.quit();
		}
	}

	public static void delete(WebDriver driver,int i,ExtentTest etest) throws Exception
	{
		CommonWait.waitTillDisplayed(driver,By.id("split-left"));
		List<WebElement> listWebElements = CommonUtil.getElement(driver,By.id("split-left")).findElements(By.tagName("li"));

		driver.get("https://ap5.lightning.force.com/lightning/setup/DataManagementDelete/home");

		CommonWait.waitTillDisplayed(driver,By.tagName("iframe"));

		driver.switchTo().frame(CommonUtil.getElement(driver,By.tagName("iframe")));

		List<WebElement> dataElements = CommonUtil.getElement(driver,By.tagName("dl")).findElements(By.tagName("dt"));
		CommonUtil.clickWebElement(driver, CommonUtil.getElement(dataElements.get(i-1),By.tagName("a")));

		driver.switchTo().defaultContent();
		CommonWait.waitTillDisplayed(driver,By.tagName("iframe"));
		Thread.sleep(5000);

		//search all
		driver.switchTo().frame(CommonUtil.getElement(driver,By.tagName("iframe")));
		CommonWait.waitTillDisplayed(driver,By.className("btn"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.className("btn")));

		driver.switchTo().defaultContent();
		CommonWait.waitTillDisplayed(driver,By.tagName("iframe"));

		//select all and permanently delete options
		driver.switchTo().frame(CommonUtil.getElement(driver,By.tagName("iframe")));
		try
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("hardDelete")));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("allBox")));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.cssSelector("input[value=Delete]")));
		}
		catch(Exception e)
		{
			etest.log(Status.INFO,"No data present for this item");
		}
		finally
		{
			etest.log(Status.PASS,"After deleting records");
			TakeScreenshot.infoScreenshot(driver,etest);
			driver.switchTo().defaultContent();
		}
	}

	public static void mailLogin(WebDriver driver,ExtentTest etest) throws Exception
	{
		CommonWait.waitTillDisplayed(driver,By.id("identifierId"));
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("identifierId")),ConfManager.getRealValue("salesforce_mail_username"));

		CommonWait.waitTillDisplayed(driver,By.id("identifierNext"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("identifierNext")));

		CommonWait.waitTillDisplayed(driver,By.id("password"));
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("password"),By.cssSelector(".whsOnd.zHQkBf")),ConfManager.getRealValue("salesforce_mail_password"));

		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("passwordNext"),By.cssSelector(".ZFr60d.CeoRYc")));

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.tagName("body")),"innerHTML","Sign out");

		driver.get("http://mail.google.com");

		CommonWait.waitTillDisplayed(driver,By.id("gbq1"));
		etest.log(Status.INFO,"Logged in with Gmail to get the verification code");
		TakeScreenshot.infoScreenshot(driver,etest);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.cssSelector(".zA.zE")));
	}

	public static void mailLogout(WebDriver driver)
	{
		driver.get("https://accounts.google.com/logout");
	}

	public static void salesforceLogout(WebDriver driver)
	{
		driver.get("https://ap5.salesforce.com/secur/logout.jsp");
	}
}
