//$Id$
package com.zoho.livedesk.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Arrays;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

import com.zoho.livedesk.client.Triggers.CommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.*;
import java.util.LinkedHashSet;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.Debugger;

public class Cleanup implements DistributedTest
{
    public static final String
    CLEANUP_IDENTIFIER="<cleanup>";

    public static final String
    ADMIN_MODULE_CLEANUP_PROCESS="ADMIN_MODULE_CLEANUP_PROCESS",
    SALESFORCE_CLEANUP_PROCESS="SALESFORCE_CLEANUP_PROCESS",
    MAILCHIMP_CLEANUP_PROCESS="MAILCHIMP_CLEANUP_PROCESS",
    LEADSCORING_RULE_PROCESS="LEADSCORING_RULE_PROCESS";

    public static final String
    CHAT_MONITOR_POPUP_INNERTEXT="Monitor",
    DELETE_COMMON_TEXT="delete",
    DELETE_ICONS_CLASS_1="sqico-delico",
    DELETE_ICONS_CLASS_2="deletescr",
    DELETE_ICONS_CLASS_3="list_lefticon",
    DELETE_ICONS_CLASS_4="list_cmndlttxt",
    DEPARTMENT_DROPDOWN_ID="deptselect",
    UNCHECKED_CHECKBOX_CLASSNAME="sqico-uncheckbox",
    CHATS_CLASSNAME="mratmn",
    ACTIVE_SESSIONS_CLEAR_URL="https://accounts.localzoho.com/u/h#sessions/useractivesessions",
    CLOSE1_CLASSNAME="sqico-close"
    ;

    public static final By
    LIST_VIEW=By.id("listview"),
    LIST_ROW=By.className("list-row"),
    DELETE_ICONS_1=By.className(DELETE_ICONS_CLASS_1),
    DELETE_ICONS_2=By.className(DELETE_ICONS_CLASS_2),
    DELETE_ICONS_3=By.className(DELETE_ICONS_CLASS_3),
    DELETE_ICONS_4=By.className(DELETE_ICONS_CLASS_4),
    VISITOR_HISTORY_DROPDOWN_BUTTON=By.id("favdrpdown0"),
    VISITOR_HISTORY_DROPDOWN=By.id("favdrpdown0_ddown"),
    VISITOR_HISTORY_DELETE_ICON_CLASS_NAME=By.className("drop-tick"),
    WEBSITES_AND_DEPARMENTS=By.className("list_fchild"),
    DEPARTMENT_DROPDOWN=By.id(DEPARTMENT_DROPDOWN_ID),
    CLEAR_ALL_SESSIONS_BUTTON=By.className("usersession-clearall"),
    CLOSE1=By.className(CLOSE1_CLASSNAME),
    SESSIONS_BOX = By.id("sessions_box"),
    OTHER_SESSION = By.id("other_sesion"),
    FIELD_SESSION = By.className("Field_session"),
    DEVICE_NAME = By.className("device_name"),
    ACTIVESESSIONS_POPUP = By.id("activesessions_pop"),
    CURRENT_SESSION_LOGOUT = By.id("current_session_logout")
    ;

    public static ArrayList<CleanupPortal> portals;

    public static Hashtable<String,String> accounts = new Hashtable<String,String>();

    public static boolean isTakeBeforeCleanupScreenshot=false;

    public static boolean isCleanup;

    public void startThread(int thread_number) throws Exception
    {

        ExtentTest etest=null;

        if(isCleanup)
        {
            CleanupPortal portal = portals.get(thread_number);

            String portal_name=portal.portal_name;

            WebDriver driver=Driver.getCleanupDriver();
            login(driver,portal.login_module);

            if(portal_name!=null)
            {
                driver.get(Util.siteNameout()+"/"+portal_name+"/");
                Functions.closeBannersAfterLogin(driver);
            }

            etest=ComplexReportFactory.getTest("Cleanup for portal '"+ExecuteStatements.getPortal(driver)+"' from account '"+portal.login_module+"'");
            ComplexReportFactory.setValues(etest,"Cleanup","Cleanup");
            performCleanupActions(driver,etest,portal);
            ComplexReportFactory.closeTest(etest);

            Functions.logout(driver);
        }

        boolean isClearSessions=(!isCleanup);

        if(isClearSessions)
        {

            String module_key=new ArrayList<String>(accounts.keySet()).get(thread_number);
            String module=accounts.get(module_key);

            WebDriver driver=Driver.getCleanupDriver();
            login(driver,module);
            String user_mail=ExecuteStatements.getUserMail(driver);

            etest=ComplexReportFactory.getTest("Clear Sessions for '"+user_mail+"'");
            ComplexReportFactory.setValues(etest,"Cleanup","Cleanup");
            clearSessions(driver,etest);
            Functions.logout(driver);

            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void login(WebDriver driver,String module) throws Exception
    {
        Functions.login(driver,module+CLEANUP_IDENTIFIER);
    }

    public static void takeBeforeCleanupScreenshot(WebDriver driver,ExtentTest etest) throws Exception
    {
        if(isTakeBeforeCleanupScreenshot)
        {
            TakeScreenshot.screenshot(driver,etest,"Before","Cleanup","success",1);
        }
    }

    public static void startCleanup()
    {
        isCleanup=true;

        portals=new ArrayList<CleanupPortal>();
        // accounts=new Hashtable<String,String>();

        // CleanupPortal test=new CleanupPortal("developer_mode",null,CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS,CleanupAction.DELETE_ALL_CHAT_MONITOR);
        // test.addIgnoreDeparments("ignore3","ignore4");
        // test.addIgnoreWebsites("ignore1","ignore2");
        // test.addIgnoreOperators("Mohan Krishnan");
        // portals.add(test);

        CleanupPortal admin_module=new CleanupPortal("admin",ConfManager.getRealValue("admin_portal"),CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_OPERATORS_EXCEPT,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_BLOCKED_IP,CleanupAction.DISABLE_BUSINESS_HOURS);
        admin_module.addIgnoreWebsites("embed2","Automation");
        admin_module.addIgnoreOperators("LDAssociate","LDSupervisor","QA Offline");
        admin_module.addUniqueCleanupCases(ADMIN_MODULE_CLEANUP_PROCESS);

        CleanupPortal salesforce_module=new CleanupPortal("salesforce_crm",null);
        salesforce_module.addUniqueCleanupCases(SALESFORCE_CLEANUP_PROCESS);

        CleanupPortal embed_config1=new CleanupPortal("embedconfig1",ConfManager.getRealValue("embedconfig1_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config2=new CleanupPortal("embed_config_theme1",ConfManager.getRealValue("embed_config_theme1_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config3=new CleanupPortal("embed_config_chatwindow_theme1",ConfManager.getRealValue("embed_config_chatwindow_theme1_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config4=new CleanupPortal("embedconfig2",ConfManager.getRealValue("embedconfig2_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config5=new CleanupPortal("embed_config_theme2",ConfManager.getRealValue("embed_config_theme2_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config6=new CleanupPortal("embed_config_theme3",ConfManager.getRealValue("embed_config_theme3_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config7=new CleanupPortal("embed_config_chatwindow_theme2",ConfManager.getRealValue("embed_config_chatwindow_theme2_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal embed_config8=new CleanupPortal("embed_config_chatwindow_theme3",ConfManager.getRealValue("embed_config_chatwindow_theme3_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        CleanupPortal zendesk1=new CleanupPortal("zendesk1",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal zendesk2=new CleanupPortal("zendesk2",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal zendesk3=new CleanupPortal("zendesk3",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal zendesk4=new CleanupPortal("zendesk4",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal desk1=new CleanupPortal("desk1",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal desk2=new CleanupPortal("desk2",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal desk3=new CleanupPortal("desk3",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal desk4=new CleanupPortal("desk4",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal supervisor=new CleanupPortal("supervisor",ConfManager.getRealValue("supervisor_portal"),CleanupAction.DELETE_ALL_CHAT_MONITOR);
        CleanupPortal associate=new CleanupPortal("associate",ConfManager.getRealValue("associate_portal"),CleanupAction.CLEAR_ALL_ACTIVE_SESSIONS);
        CleanupPortal mail_chimp=new CleanupPortal("mailchimp",null,CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS);
        mail_chimp.addUniqueCleanupCases(MAILCHIMP_CLEANUP_PROCESS);
        CleanupPortal triggers_and_visitor_routing_crud=new CleanupPortal("it_crud_vr_crud",null,CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS,CleanupAction.DELETE_ALL_VISITOR_ROUTING);
        CleanupPortal leadscoring_crud_and_triggers_rt=new CleanupPortal("leadscoring_crud_it_real_time",null,CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS,CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT);
        leadscoring_crud_and_triggers_rt.addIgnoreWebsites("embed2","automation3");

        CleanupPortal leadscoring_rt=new CleanupPortal("leadscoring_real_time","automation3",CleanupAction.CLEAR_ALL_ACTIVE_SESSIONS);
        leadscoring_rt.addUniqueCleanupCases(LEADSCORING_RULE_PROCESS);

        CleanupPortal jsapi=new CleanupPortal("jsapi",ConfManager.getRealValue("jsapi_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal visitorhistory=new CleanupPortal("visitorhistory_main",ConfManager.getRealValue("visitorhistory_main_portal"),CleanupAction.DELETE_ALL_VISITOR_HISTORY_LIST);
        CleanupPortal tracking_rings_customize=new CleanupPortal("trc",null,CleanupAction.DEFAULT_TRACKING_RINGS_VIEW);   

        CleanupPortal tracking_rings=new CleanupPortal("trackingrings",null,CleanupAction.DEFAULT_TRACKING_RINGS_VIEW);   
        CleanupPortal campaign=new CleanupPortal("integration","automation5",CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS);
        CleanupPortal visitor_routing1=new CleanupPortal("vr_rt_admin","visitorrouting",CleanupAction.DELETE_ALL_VISITOR_ROUTING,CleanupAction.DELETE_ALL_MISSED_CHATS);
        CleanupPortal visitor_routing2=new CleanupPortal("vr_rt2_admin","visitorrouting2",CleanupAction.DELETE_ALL_VISITOR_ROUTING,CleanupAction.DELETE_ALL_MISSED_CHATS);
        CleanupPortal chatops=new CleanupPortal("webembed_crud_chat","chatops",CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        chatops.addIgnoreDeparments("testDepartment");
        CleanupPortal transfer_chat=new CleanupPortal("transferchat","transferchat",CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS);
        transfer_chat.addIgnoreDeparments("Automation");

        CleanupPortal chatmonitor_email_schedules=new CleanupPortal("chatmonitor_email_schedules","chatmonitor",CleanupAction.DELETE_ALL_CHAT_MONITOR,CleanupAction.DELETE_ALL_EMAIL_SCHEDULES,CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS);
        CleanupPortal chatmonitor_supervisor=new CleanupPortal("cm_rt_supervisor","chatmonitor",CleanupAction.DELETE_ALL_CHAT_MONITOR);
        CleanupPortal chatmonitor_associate=new CleanupPortal("cm_rt_associate","chatmonitor",CleanupAction.CLEAR_ALL_ACTIVE_SESSIONS);
        CleanupPortal chatrouting=new CleanupPortal("chat_routing",null,CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,CleanupAction.CLEAR_ALL_ACTIVE_SESSIONS);
        CleanupPortal portal_settings_real_time=new CleanupPortal("portal_settings",null,CleanupAction.DELETE_ALL_BLOCKED_IP,CleanupAction.CLEAR_ALL_ACTIVE_SESSIONS);
        CleanupPortal rest_api=new CleanupPortal("restapi",ConfManager.getRealValue("restapi_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);
        CleanupPortal business_hours=new CleanupPortal("customcss",null,CleanupAction.DISABLE_BUSINESS_HOURS);

        CleanupPortal plan_enterprise=new CleanupPortal("plan_enterprise","automation6",CleanupAction.REACH_PLAN_THRESHOLD);
        CleanupPortal plan_professional=new CleanupPortal("plan_professional","automation7",CleanupAction.REACH_PLAN_THRESHOLD);
        CleanupPortal plan_basic=new CleanupPortal("plan_basic","automation8",CleanupAction.REACH_PLAN_THRESHOLD);
        CleanupPortal plan_free=new CleanupPortal("plan_free","automation9",CleanupAction.REACH_PLAN_THRESHOLD);

        CleanupPortal canned_message = new CleanupPortal("feedback","ldautomation12",CleanupAction.DELETE_ALL_CANNED_MESSAGES);
        CleanupPortal bots_crud=new CleanupPortal("bots1_admin",ConfManager.getRealValue("bots1_admin_portal"),CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT);

        CleanupPortal wmsbar=new CleanupPortal("ga","googleanalytics1",CleanupAction.DELETE_ALL_MISSED_CHATS);

        portals.add(admin_module);
        portals.add(embed_config1);
        portals.add(embed_config2);
        portals.add(embed_config3);
        portals.add(embed_config4);
        portals.add(embed_config5);
        portals.add(embed_config6);
        portals.add(embed_config7);
        portals.add(embed_config8);
        portals.add(zendesk1);
        portals.add(zendesk2);
        portals.add(zendesk3);
        portals.add(zendesk4);
        portals.add(desk1);
        portals.add(desk2);
        portals.add(desk3);
        portals.add(desk4);
        portals.add(supervisor);
        portals.add(associate);
        portals.add(mail_chimp);
        portals.add(triggers_and_visitor_routing_crud);
        portals.add(leadscoring_crud_and_triggers_rt);
        portals.add(tracking_rings);
        portals.add(campaign);
        portals.add(visitor_routing1);
        portals.add(visitor_routing2);
        portals.add(chatops);
        portals.add(transfer_chat);
        portals.add(chatmonitor_email_schedules);
        portals.add(chatmonitor_supervisor);
        portals.add(chatmonitor_associate);
        portals.add(leadscoring_rt);
        portals.add(chatrouting);
        portals.add(portal_settings_real_time);
        portals.add(rest_api);
        portals.add(salesforce_module);
        portals.add(business_hours);
        portals.add(plan_enterprise);
        portals.add(plan_professional);
        portals.add(plan_basic);
        portals.add(plan_free);
        portals.add(canned_message);
        portals.add(bots_crud);
        portals.add(wmsbar);
        portals.add(jsapi);
        portals.add(visitorhistory);
        portals.add(tracking_rings_customize); 
        
        Cleanup usecases = new Cleanup();

        int no_of_threads=portals.size();

        Distributor distributor = new Distributor(usecases,no_of_threads);
        distributor.initiate();

        isCleanup=false;//so that clear sessions will run instead of cleanup in the distributor thread

        Distributor distributor2 = new Distributor(usecases,accounts.size());
        distributor2.initiate();
    }

 

    public enum CleanupAction
    {
       DELETE_ALL_INTELLIGENT_TRIGGERS,
       DELETE_ALL_VISITOR_ROUTING,
       DELETE_ALL_CHAT_ROUTING,
       DELETE_ALL_CHAT_MONITOR,
       DELETE_ALL_EMAIL_SCHEDULES,
       DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT,
       DELETE_ALL_WEBSITES_EXCEPT_DEFAULT,
       DELETE_ALL_BLOCKED_IP,
       DELETE_ALL_CANNED_MESSAGES,
       DELETE_ALL_VISITOR_HISTORY_LIST,
       DELETE_ALL_CHAT_HISTORY,
       DELETE_ALL_MISSED_CHATS,
       DELETE_ALL_OPERATORS_EXCEPT,
       DEFAULT_TRACKING_RINGS_VIEW,
       DISABLE_BUSINESS_HOURS,
       REACH_PLAN_THRESHOLD,
       //ALWAYS DO BELOW PROCESS
       CLEAR_ALL_ACTIVE_SESSIONS,
       SET_PORTAL_CHAT_LIMIT_DEFAULT,
       SET_USERS_CHAT_LIMIT_DEFAULT,
       SET_OPERATOR_IDLE_TIME_TO_NEVER
       ;
    }

    public static void performUniqueCleanupActions(WebDriver driver,ExtentTest etest,CleanupPortal portal)
    {
        ArrayList<String> unique_cleanup_process=portal.getUniqueSpecialCleanupCases();

        if(unique_cleanup_process.contains(ADMIN_MODULE_CLEANUP_PROCESS))
        {
            try
            {
                if(com.zoho.livedesk.client.CleanUp.cleanUpAdmin.companyInfo(driver)==false)
                {
                    etest.log(Status.WARNING,"Please set expected company settings values");
                    TakeScreenshot.screenshot(driver,etest,"cleanup","company","failure",1);
                }
                else
                {
                    etest.log(Status.PASS,"Company settings was set.");
                }
                if(com.zoho.livedesk.client.CleanUp.cleanUpAdmin.portalSettings(driver)==false)
                {
                    etest.log(Status.WARNING,"Please set expected portal settings values");
                    TakeScreenshot.screenshot(driver,etest,"cleanup","portal","failure",1);
                }
                else
                {
                     etest.log(Status.PASS,"Portal settings was set.");
                }
                if(com.zoho.livedesk.client.CleanUp.cleanUpAdmin.cannedMessages(driver)==false)
                {
                    etest.log(Status.WARNING,"Please set canned messages values");
                    TakeScreenshot.screenshot(driver,etest,"cleanup","canned","failure",1);
                }
                else
                {
                     etest.log(Status.PASS,"Canned messages was set.");
                }
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please set company settings and portals settings");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
                e.printStackTrace();
            }
        }

        if(unique_cleanup_process.contains(LEADSCORING_RULE_PROCESS))
        {
            try
            {
                for(int i = 0;i <= 10;i++)
                {
                    String leadScoring_portal=null;

                    if(i>0)
                    {
                        leadScoring_portal="leadscore"+i;
                    }
                    else
                    {
                        leadScoring_portal=portal.portal_name;
                    }

                    driver.get(Util.siteNameout()+"/"+leadScoring_portal);

                    if(com.zoho.livedesk.client.CleanUp.cleanUpAutomations.leadScoring(driver)==false)
                    {
                        etest.log(Status.WARNING,"Please cleanup leadscoring module for portal '"+leadScoring_portal+"'");
                        TakeScreenshot.screenshot(driver,etest,"cleanup","leadscore","failure",1);                        
                    }
                    else
                    {
                        etest.log(Status.PASS,"Leadscoring was set for "+leadScoring_portal);   
                    }
                }
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please cleanup leadscoring portals manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
                e.printStackTrace();
            }
        }

        if(unique_cleanup_process.contains(SALESFORCE_CLEANUP_PROCESS))
        {
            try
            {
                CleanUpSalesforce.clean(driver,etest);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please cleanup salesforce account manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
                CommonUtil.printStackTrace(e);
            }
        }

        if(unique_cleanup_process.contains(MAILCHIMP_CLEANUP_PROCESS))
        {
            try
            {
                CleanupMailchimp.clean();
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please cleanup Mailchimp account manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
                e.printStackTrace();
            }
        }
    }

    public static void performCleanupActions(WebDriver driver,ExtentTest etest,CleanupPortal portal)
    {
        ArrayList<CleanupAction> cleanup_actions=portal.cleanup_actions_list;

        String user_mail="";

        try
        {
            user_mail=ExecuteStatements.getUserMail(driver);
        }
        catch(Exception e)
        {

        }

        accounts.put(user_mail,portal.login_module);

        // SET_OPERATOR_IDLE_TIME_TO_NEVER
        if(true)
        {

            try
            {
                takeBeforeCleanupScreenshot(driver,etest);
                PortalInput portal_input=new PortalInput(PortalSetting.SET_OPERATOR_IDLE_TIME,PortalSettingsConstants.NEVER);
                PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);
                etest.log(Status.PASS,"User idle time was set to "+PortalSettingsConstants.NEVER);
            }
            catch(Exception e)
            {
                e.printStackTrace();
                etest.log(Status.INFO,"User idle time was not set to "+PortalSettingsConstants.NEVER);
            }
        }

        try
        {
           // SET_PORTAL_CHAT_LIMIT_DEFAULT,
           // SET_USERS_CHAT_LIMIT_DEFAULT,

            if(ExecuteStatements.isAdministrator(driver))
            {
                takeBeforeCleanupScreenshot(driver,etest);

                String user_name=ExecuteStatements.getUserName(driver);

                Portal portal_limit = new Portal();
                User user = new User(user_name);

                ConcurrentChatCommonFunctions.setupConcurrentChatType(driver,etest,null,user,portal_limit);

                etest.log(Status.PASS,"Portal chats limit and operator chats limit was set to default");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
        }
        catch(Exception e)
        {
            etest.log(Status.INFO,"Please set portal limit and operator limit to default");
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_CANNED_MESSAGES))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllCannedMessagesAndCategories(driver);
                etest.log(Status.PASS,"All canned messages were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all canned messages manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_BLOCKED_IP))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllBlockedIP(driver);
                etest.log(Status.PASS,"All blocked IP were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all blocked IP manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_VISITOR_HISTORY_LIST))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllVisitorHistoryLists(driver);
                etest.log(Status.PASS,"All visitor history list were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.INFO,"All visitor history may NOT be deleted");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
                e.printStackTrace();                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_EMAIL_SCHEDULES))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllEmailSchedules(driver);
                etest.log(Status.PASS,"All email schedules were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all email schedules  manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_CHAT_MONITOR))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllChatMonitor(driver);
                etest.log(Status.PASS,"All chats monitors were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                e.printStackTrace();
                etest.log(Status.WARNING,"Please delete all chat monitors manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_INTELLIGENT_TRIGGERS))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllTriggers(driver);
                etest.log(Status.PASS,"All triggers were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all triggers manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_VISITOR_ROUTING))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllVisitorRouting(driver);
                etest.log(Status.PASS,"All visitor routing rules were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all visitor routing rules manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_CHAT_ROUTING))
        {
            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllChatRouting(driver);
                etest.log(Status.PASS,"All were chat routing rules deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all chat routing rules manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_DEPARTMENTS_EXCEPT_DEFAULT))
        {
            ArrayList<String> ignore_list=portal.getIgnoreDepartments();

            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllDeparmentsExcept(driver,ignore_list);
                etest.log(Status.PASS,"All deparments(except : "+ignore_list.toString()+") were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all deparments(except : "+ignore_list.toString()+") manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_WEBSITES_EXCEPT_DEFAULT))
        {
            ArrayList<String> ignore_list=portal.getIgnoreWebsites();

            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllWebsitesExcept(driver,ignore_list);
                etest.log(Status.PASS,"All websites(except : "+ignore_list.toString()+") were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all websites(except : "+ignore_list.toString()+") manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_OPERATORS_EXCEPT))
        {
            ArrayList<String> ignore_list=portal.getIgnoreOperators();

            try
            {
                takeBeforeCleanupScreenshot(driver,etest);

                deleteAllOperatorsExcept(driver,ignore_list);
                etest.log(Status.PASS,"All operators(except : "+ignore_list.toString()+") were deleted");
                TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all operators(except : "+ignore_list.toString()+") manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);                
            }
        }

        if(cleanup_actions.contains(CleanupAction.DEFAULT_TRACKING_RINGS_VIEW))
        {
            try
            {
               takeBeforeCleanupScreenshot(driver,etest);

               Tab.clickVisitorsOnline(driver);
               VisitorsOnline.selectRingsViewInVisitorsOnline(driver);
               etest.log(Status.PASS,"Rings view was selected in tracking rings menu");
               TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please select rings view in tracking rings menu manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
                e.printStackTrace();
            }
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_MISSED_CHATS))
        {
            try
            {
               takeBeforeCleanupScreenshot(driver,etest);

               deleteAllMissedChats(driver);
               etest.log(Status.PASS,"All missed chats were deleted");
               TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all missed chats manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
                e.printStackTrace();
            }            
        }

        if(cleanup_actions.contains(CleanupAction.DELETE_ALL_CHAT_HISTORY))
        {
            try
            {
               takeBeforeCleanupScreenshot(driver,etest);

               deleteAllChatsFromChatHistory(driver);
               etest.log(Status.PASS,"All chats from chat history were deleted");
               TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please delete all chats from chat history manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
                e.printStackTrace();
            }            
        }

        if(cleanup_actions.contains(CleanupAction.DISABLE_BUSINESS_HOURS))
        {
            try
            {
               takeBeforeCleanupScreenshot(driver,etest);

               Tab.navToCompTab(driver);
               Company.toggleBusinessHours(driver,false);

               etest.log(Status.PASS,"Business hours was disabled in company settings");
               TakeScreenshot.screenshot(driver,etest,"cleanup","portals","success",1);
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Please disable business hours from company settings. manually");
                TakeScreenshot.screenshot(driver,etest,"Cleanup","Failed","Check",e);
                e.printStackTrace();
            }            
        }

        if(cleanup_actions.contains(CleanupAction.REACH_PLAN_THRESHOLD))
        {
            reachPlanLimit(driver,etest);
            etest.log(Status.PASS,"ALL PLAN LIMITS WERE REACHED FOR PORTAL : "+portal.portal_name);
        }

        if(portal.getUniqueSpecialCleanupCases().isEmpty()==false)
        {
            performUniqueCleanupActions(driver,etest,portal);
        }

        try
        {
            if(accounts.containsKey(user_mail)==false)
            {
                // clearAllActiveSessions(driver);
                // etest.log(Status.PASS,"All active sessions are cleared for "+user_mail);
            }
        }
        catch(Exception e)
        {
            etest.log(Status.INFO,"All active sessions were NOT cleared for "+user_mail);
        }
    }

    public static void clearSessions(WebDriver driver,ExtentTest etest)
    {
        try
        {
            clearAllActiveSessions(driver);
            etest.log(Status.PASS,"All active sessions were cleared");
            TakeScreenshot.infoScreenshot(driver,etest);            
        }
        catch(Exception e)
        {
            etest.log(Status.WARNING,"All active session are NOT cleared, Please clear them manually if necessary.");
            e.printStackTrace();
            TakeScreenshot.screenshot(driver,etest,e);
        }
    }

    public static class CleanupPortal
    {
        String login_module,portal_name;

        CleanupAction[] cleanup_actions_array;

        ArrayList<CleanupAction> cleanup_actions_list;

        ArrayList<String> ignore_deparments,ignore_websites,ignore_operators,unique_cleanup_process;

        CleanupPortal(String login_module,String portal_name,CleanupAction... cleanup_actions_array)
        {
            this.login_module=login_module;
            this.portal_name=portal_name;
            this.cleanup_actions_array=cleanup_actions_array;
            this.cleanup_actions_list=new ArrayList<CleanupAction>(Arrays.asList(cleanup_actions_array));
            this.ignore_deparments=new ArrayList<String>();
            this.ignore_websites=new ArrayList<String>();            
            this.ignore_operators=new ArrayList<String>();
            this.unique_cleanup_process=new ArrayList<String>();
        }

        public void addIgnoreDeparments(String... ignore_deparments_array)
        {
            for(String deparment : ignore_deparments_array)
            {
                ignore_deparments.add(deparment);
            }
        }

        public void addIgnoreWebsites(String... ignore_websites_array)
        {
            for(String website : ignore_websites_array)
            {
                ignore_websites.add(website);
            }
        }

        public void addIgnoreOperators(String... ignore_operators_array)
        {
            for(String operator : ignore_operators_array)
            {
                ignore_operators.add(operator);
            }
        }

        public void addUniqueCleanupCases(String... unique_cleanup_process_array)
        {
            for(String clean_up_process : unique_cleanup_process_array)
            {
                unique_cleanup_process.add(clean_up_process);
            }
        }  

        public ArrayList<String> getUniqueSpecialCleanupCases()
        {
            return unique_cleanup_process;
        }

        public ArrayList<String> getIgnoreDepartments()
        {
            return ignore_deparments;
        }

        public ArrayList<String> getIgnoreWebsites()
        {
            return ignore_websites;
        }

        public ArrayList<String> getIgnoreOperators()
        {
            return ignore_operators;
        }

    }

    public static void clickButtonByPurpose(List<WebElement> buttons,String purpose)
    {
        WebElement button=CommonUtil.getElementByAttributeValue(buttons,"purpose",purpose);
        CommonWait.waitTillDisplayed(button);
        button.click();
    }

    public static boolean isEmptySlate(WebDriver driver)
    {
        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("emptyslate"))
        {
            if(driver.findElements(By.id("emptyslate")).size()>0)
            {
                System.out.println("~~return true");

                return true;
            }
        }
                System.out.println("~~return false");


        return false;
    }

    public static boolean isBodyContains(WebDriver driver,String str)
    {
        return driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains(str);
    }

    public static WebElement getDeleteButton(WebDriver driver)
    {
        WebElement delete=null;

        if(isBodyContains(driver,DELETE_ICONS_CLASS_1) && CommonWait.isPresent(driver,DELETE_ICONS_1))
        {
            delete=CommonUtil.getElement(driver,DELETE_ICONS_1);
            return delete;
        }
        else if(isBodyContains(driver,DELETE_ICONS_CLASS_2) && CommonWait.isPresent(driver,DELETE_ICONS_2))
        {
            delete=CommonUtil.getElement(driver,DELETE_ICONS_2);
            return delete;
        }
        else if(isBodyContains(driver,DELETE_ICONS_CLASS_4) && CommonWait.isPresent(driver,DELETE_ICONS_4))
        {
            delete=CommonUtil.getElement(driver,DELETE_ICONS_4);
            return delete;
        }
        else if(isBodyContains(driver,DELETE_ICONS_CLASS_3) && CommonWait.isPresent(driver,DELETE_ICONS_3))
        {
            delete=CommonUtil.getElement(driver,DELETE_ICONS_3);
            return delete;
        }

        return null;
    }

    public static void clearAllActiveSessions(WebDriver driver)
    {
        String original_url=driver.getCurrentUrl();

        String url=ACTIVE_SESSIONS_CLEAR_URL;

        if(original_url.contains("salesiq.zoho.com"))
        {
            url=url.replace("accounts.localzoho.com","accounts.zoho.com");
        }

        driver.get(url);

        CommonUtil.sleep(5000);

        if(!CommonWait.isDisplayed(driver,SESSIONS_BOX))
        {
            try
            {
                if(!CommonWait.isPresent(driver,CLEAR_ALL_SESSIONS_BUTTON))
                {
                    return;
                }

                CommonWait.waitTillDisplayed(driver,CLEAR_ALL_SESSIONS_BUTTON);
            }
            catch(Exception e)
            {
                return;
            }

            CommonUtil.getElement(driver,CLEAR_ALL_SESSIONS_BUTTON).click();
            CommonWait.waitTillHidden(driver,CLEAR_ALL_SESSIONS_BUTTON);
        }
        else
        {
            try
            {
                CommonWait.waitTillDisplayed(driver,SESSIONS_BOX,OTHER_SESSION);
                List<WebElement> sessions = CommonUtil.getElement(driver,SESSIONS_BOX,OTHER_SESSION).findElements(FIELD_SESSION);
                int size = sessions.size();

                for(int i = 0; i < size; i++)
                {
                    WebElement session = CommonUtil.getElement(driver,SESSIONS_BOX,OTHER_SESSION,FIELD_SESSION);
                    CommonUtil.clickWebElement(driver,session.findElement(DEVICE_NAME));
                    CommonUtil.clickWebElement(driver,ACTIVESESSIONS_POPUP,CURRENT_SESSION_LOGOUT);
                    CommonUtil.sleep(2000);
                }
            }
            catch(Exception e)
            {
                return;
            }
        }

        // driver.get(original_url);
    }

    public static void deleteAllRules(WebDriver driver)
    {
        int MAX_ATTEMPTS=25;

        int no_of_attempts=0;

        while( (getDeleteButton(driver)!=null) && no_of_attempts<MAX_ATTEMPTS)
        {
            try
            {
                WebElement delete=getDeleteButton(driver);

                System.out.println("~~Now checking "+delete.getAttribute("class"));

                CommonUtil.mouseHover(driver,delete);

                try
                {
                   CommonWait.waitTillDisplayed(delete);
                }
                catch(Exception exp)
                {
                   exp.printStackTrace(); 
                   break; 
                }

                delete.click();
                CommonUtil.sleep(250);
                WebElement popup=HandleCommonUI.getPopupByInnerText(driver,DELETE_COMMON_TEXT);
                HandleCommonUI.clickPositivePopupButton(popup);
                CommonUtil.sleep(1000);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            no_of_attempts++;
        }
    }

    public static void deleteAllTriggers(WebDriver driver)
    {
        try
        {
            Tab.navToITTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);
    }

    public static void deleteAllVisitorRouting(WebDriver driver)
    {
        try
        {
            Tab.navToVRTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);
    }

    public static void deleteAllCannedMessagesAndCategories(WebDriver driver)
    {
        try
        {
            Tab.clickCannedMessagesCategory(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);
    }

    public static void deleteAllVisitorHistoryLists(WebDriver driver)
    {
        try
        {
            Tab.clickVisitorHistory(driver);
        }
        catch(Exception e)
        {

        }

        deleteVisitorHistoryLists(driver);
    }

    public static void deleteAllChatRouting(WebDriver driver)
    {
        try
        {
            Tab.navToChatRoutingTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);
    }

    public static void deleteAllCallRouting(WebDriver driver)
    {
        try
        {
            Tab.navToCallRoutingTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);
    }

    public static void deleteAllLeadscoring(WebDriver driver)
    {
        try
        {
            Tab.navToLeadscoringTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);
    }

    public static void deleteAllBlockedIP(WebDriver driver)
    {
        try
        {
            Tab.navToBlockedIPTab(driver);
        }
        catch(Exception e)
        {

        }
        BlockedIP.rejectAllIPs(driver);
        deleteAllRules(driver);
    }

    public static void deleteAllEmailSchedules(WebDriver driver)
    {
        try
        {
            Tab.navToSchedulesTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);   
    }

    public static void deleteAllArticles(WebDriver driver)
    {
        try
        {
            Tab.navToArticlesTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);           
    }

    public static void deleteAllBots(WebDriver driver)
    {
        try
        {
            Tab.navToBotsTab(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllRules(driver);           
    }

    public static void deleteAllChatMonitor(WebDriver driver)
    {
        try
        {
            Tab.navToCMTab(driver);
        }
        catch(Exception e)
        {

        }

        int MAX_ATTEMPTS=25;

        int no_of_attempts=0;

        while(!isEmptySlate(driver) && no_of_attempts<MAX_ATTEMPTS)
        {
            clickButtonByPurpose( CommonUtil.getElement(driver,LIST_VIEW).findElement(LIST_ROW).findElements(By.tagName("em")) ,"delete" );
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,CHAT_MONITOR_POPUP_INNERTEXT);
            System.out.println("~~"+popup.getText()+"<br>"+popup.getAttribute("innerHTML"));
            HandleCommonUI.clickPositivePopupButton(popup);
            CommonUtil.sleep(1000);
            no_of_attempts++;
        }
    }

    public static void deleteVisitorHistoryLists(WebDriver driver)
    {
        int MAX_ATTEMPTS=25;

        int no_of_attempts=0;

        while(deleteVisitorHistoryList(driver) && no_of_attempts<MAX_ATTEMPTS)
        {   
            no_of_attempts++;
        }        
    }

    public static boolean deleteVisitorHistoryList(WebDriver driver)
    {
        //returns true if no VH list is present
        
        WebElement new_history_list = null;
        WebElement dropdown=CommonUtil.getElement(driver,VISITOR_HISTORY_DROPDOWN_BUTTON,By.className("txtelips"));
        CommonUtil.mouseHoverAndClick(driver,dropdown);
        CommonWait.waitTillDisplayed(driver,VISITOR_HISTORY_DROPDOWN_BUTTON,VISITOR_HISTORY_DROPDOWN,By.tagName("ul"));
        List<WebElement> list = CommonUtil.getElement(driver,VISITOR_HISTORY_DROPDOWN_BUTTON,VISITOR_HISTORY_DROPDOWN,By.tagName("ul")).findElements(By.tagName("li"));
        for(WebElement ele : list)
        {
            if(ele.getAttribute("val").length() > 3)
            {
                new_history_list = ele;
                break;
            }
        }
        if(new_history_list == null)
        {
            return false;
        }
        WebElement delete=CommonUtil.getElement(new_history_list,VISITOR_HISTORY_DELETE_ICON_CLASS_NAME);
        // WebElement delete=CommonUtil.getElement(driver,VISITOR_HISTORY_DROPDOWN_BUTTON,VISITOR_HISTORY_DROPDOWN,By.tagName("ul"),VISITOR_HISTORY_DELETE_ICON_CLASS_NAME);
        if(delete!=null)
        {
            CommonUtil.mouseHoverAndClick(driver,delete);
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,DELETE_COMMON_TEXT);
            HandleCommonUI.clickPositivePopupButton(popup);
            CommonUtil.sleep(1000);
            return true;        
        }
        else
        {
            return false;
        }
    }

    public static boolean isStringContains(String str,ArrayList<String> data_set)
    {
        for(String data : data_set)
        {
            if(str.toLowerCase().contains(data.toLowerCase()))
            {
                return true;
            }
        }

        return false;
    }

    public static void deleteAllWebsitesExcept(WebDriver driver,ArrayList<String> exceptions) throws Exception
    {
        try
        {
            Tab.navToEmbedTab(driver);
        }
        catch(Exception e)
        {

        }

        exceptions.add(ExecuteStatements.getDefaultEmbedName(driver));

        deleteAllExcept(driver,exceptions);
    }

    public static void deleteAllDeparmentsExcept(WebDriver driver,ArrayList<String> exceptions) throws Exception
    {
        try
        {
            Tab.navToDeptTab(driver);
        }
        catch(Exception e)
        {

        }

        if(exceptions==null)
        {
            exceptions=new ArrayList<String>();
        }

        exceptions.add(ExecuteStatements.getSystemGeneratedDepartment(driver));

        deleteAllExcept(driver,exceptions);   
    }


    public static void deleteAllExcept(WebDriver driver,ArrayList<String> exceptions) throws Exception
    {
        //common for websites and department
        List<WebElement> list=driver.findElements(LIST_ROW);

        List<String> list_ids=CommonUtil.getAttributesFromList(list,"id");

        for(String list_id : list_ids)
        {
            WebElement element=CommonUtil.getElement(driver,By.id(list_id),WEBSITES_AND_DEPARMENTS);

            if(!isStringContains(element.getText(),exceptions))
            {
                
                if(element.findElements(DELETE_ICONS_3).size()>0)
                {
                    WebElement delete=element.findElement(DELETE_ICONS_3);
                    CommonUtil.inViewPort(delete);
                    CommonUtil.mouseHoverAndClick(driver,delete);
                    WebElement popup=HandleCommonUI.getPopupByInnerText(driver,DELETE_COMMON_TEXT);

                    if(popup.getAttribute("innerHTML").contains(DEPARTMENT_DROPDOWN_ID))
                    {
                        popup.findElement(DEPARTMENT_DROPDOWN).click();
                        HandleCommonUI.chooseFromDropdown( popup.findElement(DEPARTMENT_DROPDOWN) ,ExecuteStatements.getSystemGeneratedDepartment(driver) );
                    }

                    HandleCommonUI.clickPositivePopupButton(popup);
                    CommonUtil.sleep(1500);        
                }
            }
        }
    }

    public static void deleteAllOperatorsExcept(WebDriver driver,ArrayList<String> exceptions) throws Exception
    {

        Tab.navToUsersTab(driver);

        List<WebElement> list=driver.findElements(LIST_ROW);

        List<String> list_ids=CommonUtil.getAttributesFromList(list,"id");

        for(String list_id : list_ids)
        {
            WebElement element=CommonUtil.getElement(driver,By.id(list_id));

            if(!isStringContains(element.getText(),exceptions))
            {    
                if(element.findElements(DELETE_ICONS_4).size()>0)
                {
                    WebElement delete=element.findElement(DELETE_ICONS_4);
                    CommonUtil.inViewPort(delete);
                    CommonUtil.mouseHoverAndClick(driver,delete);
                    WebElement popup=HandleCommonUI.getPopupByInnerText(driver,DELETE_COMMON_TEXT);
                    HandleCommonUI.clickPositivePopupButton(popup);
                    CommonUtil.sleep(1500);        
                }
            }
        }
    }

    public static void deleteAllChatsFromChatHistory(WebDriver driver)
    {
        try
        {
            Tab.clickChatHistory(driver);
        }
        catch(Exception e)
        {

        }

        deleteAllChats(driver);
    }

    public static void deleteAllMissedChats(WebDriver driver)
    {
        if(!CommonWait.isDisplayed(driver,By.id("suppm_missed")))
        {
            return;
        }

        try
        {
            Tab.clickMissed(driver);
        }   
        catch(Exception e)
        {

        }

        deleteAllChats(driver);
    }

    public static void deleteAllChats(WebDriver driver)
    {
        int MAX_ATTEMPTS=10;
        int no_of_attempts=0;

        boolean isAllChatsDeleted=false;

        while(!isAllChatsDeleted && no_of_attempts<MAX_ATTEMPTS)
        {
            driver.navigate().refresh();

            CommonUtil.sleep(1000);

            selectAllChats(driver);
            CommonUtil.sleep(250);

            WebElement delete=getDeleteButton(driver);

            if(delete!=null && CommonWait.isDisplayed(delete))
            {
                CommonUtil.mouseHoverAndClick(driver,delete);
                WebElement popup=HandleCommonUI.getPopupByInnerText(driver,DELETE_COMMON_TEXT);
                HandleCommonUI.clickPositivePopupButton(popup);
                CommonUtil.sleep(5000);//sleep is to prevent ip blocked due to too many requests
            }
            else
            {
                isAllChatsDeleted=true;
            }

            no_of_attempts++;
        }
    }

    public static void selectAllChats(WebDriver driver)
    {
        //max upto 50 chats a time due to limitations in product
        /*
        Formatted code
    
        var list=document.getElementsByClassName("mratmn");
        for(var i=0;i<50;i++)
        {
            try
            {
                list[i].getElementsByClassName("sqico-uncheckbox")[0].click();
            }
            catch(e)
            {

            }    
        }

        */
        String select_all_chats_js="var list=document.getElementsByClassName('"+CHATS_CLASSNAME+"'); for(var i=0;i<50;i++) { try { list[i].getElementsByClassName('"+UNCHECKED_CHECKBOX_CLASSNAME+"')[0].click(); } catch(e) { } }";
        ((JavascriptExecutor) driver).executeScript(select_all_chats_js);
    }

    public static void reachPlanLimit(WebDriver driver,ExtentTest etest)
    {
        Plan current_plan=getPlan(driver);
        reachOperatorsLimit(driver,etest,current_plan.OPERATORS_LIMIT);
        reachWebsitesLimit(driver,etest,current_plan.WEBSITES_LIMIT);
        reachDepartmentLimit(driver,etest,current_plan.DEPARTMENTS_LIMIT);
        reachTriggersLimit(driver,etest,current_plan.TRIGGERS_LIMIT);
        reachVisitorRoutingLimit(driver,etest,current_plan.VISITOR_ROUTING_LIMIT);
        reachSchedulesLimit(driver,etest,current_plan.EMAIL_SCHEDULES_LIMIT);
        reachLeadscoreLimit(driver,etest,current_plan.LEADSCORE_LIMIT);
        reachChatRoutingLimit(driver,etest,current_plan.CHAT_ROUTING_LIMIT);
    }

    public static void reachOperatorsLimit(WebDriver driver,ExtentTest etest,int limit)
    {
        if(limit==0)
        {
            return;
        }

        String portal="Unknown";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);

            int current_count=getCurrentOperatorsCount(driver);
            int operators_to_add=limit-current_count;
            int max_attempts=operators_to_add+5;
            int operators_added=0,attempts=0;

            etest.log(Status.INFO,"current operators count : "+current_count+", operators to add : "+operators_to_add);



            while(operators_to_add>operators_added && attempts<max_attempts)
            {
                String mail="O"+CommonUtil.getUniqueMessage()+"@email.com";

                try
                {
                    UsersTab.addUser(driver,mail,"associate",null,etest);
                    operators_added++;
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding operator");
                    TakeScreenshot.infoScreenshot(driver,etest);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                }

                attempts++;
            }

            if(operators_added>=operators_to_add)
            {
                etest.log(Status.PASS,"Operators were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,"Operators were added according to plan limit");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,"Operators were not added for portal "+portal);
            TakeScreenshot.infoScreenshot(driver,etest);
            TakeScreenshot.log(e,etest,Status.WARNING);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachWebsitesLimit(WebDriver driver,ExtentTest etest,int limit)
    {
        if(limit==0)
        {
            return;
        }

        String portal="Unknown";
        String name="website";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);      

            int current_count=getCurrentWebsitesCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);


            while(to_add>added && attempts<max_attempts)
            {
                String create_with_name="W"+CommonUtil.getUniqueMessage();

                try
                {
                    WebEmbed.addWebEmbed(driver,create_with_name);
                    CommonUtil.sleep(3000);
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.infoScreenshot(driver,etest);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.infoScreenshot(driver,etest);
            TakeScreenshot.log(e,etest,Status.WARNING);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachDepartmentLimit(WebDriver driver,ExtentTest etest,int limit)
    {
        if(limit==0)
        {
            return;
        }

        String portal="Unknown";
        String name="department";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);      

            int current_count=getCurrentDepartmentsCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);


            while(to_add>added && attempts<max_attempts)
            {
                String create_with_name="D"+CommonUtil.getUniqueMessage();

                try
                {
                    Department.addDept(driver,create_with_name,"depttype_publi",ExecuteStatements.getUserName(driver),etest);
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.infoScreenshot(driver,etest);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.infoScreenshot(driver,etest);
            TakeScreenshot.log(e,etest,Status.WARNING);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachTriggersLimit(WebDriver driver,ExtentTest etest,int limit)
    {

        if(limit==0)
        {
            return;
        }

        String portal="Unknown";
        String name="intelligent triggers";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);      

            int current_count=getCurrentTriggersCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);

            while(to_add>added && attempts<max_attempts)
            {
                String create_with_name="Q"+CommonUtil.getUniqueMessage()+"?";

                try
                {
                    Trigger.addTrigger(driver,etest,"Lands on my website","Visitor Type","is equal to","All",null,"Send chat invite","3 Seconds","Automation",create_with_name);
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.infoScreenshot(driver,etest);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.infoScreenshot(driver,etest);
            TakeScreenshot.log(e,etest,Status.WARNING);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachVisitorRoutingLimit(WebDriver driver,ExtentTest etest,int limit)
    {
        if(limit==0)
        {
            return;
        }


        String portal="Unknown";
        String name="visitor routing";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);      

            Tab.navToVRTab(driver);

            int current_count=getCurrentVisitorRoutingCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);

            while(to_add>added && attempts<max_attempts)
            {
                String create_with_name="Q"+CommonUtil.getUniqueMessage()+"?";

                try
                {
                    Routing.clickAdd(driver,etest);
                    CommonUtil.sleep(3000);
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }  
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                    TakeScreenshot.infoScreenshot(driver,etest);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.log(e,etest,Status.WARNING);
            TakeScreenshot.infoScreenshot(driver,etest);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachSchedulesLimit(WebDriver driver,ExtentTest etest,int limit)
    {

        if(limit==0)
        {
            return;
        }

        String portal="Unknown";
        String name="email schedules";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);      

            Tab.navToSchedulesTab(driver);

            int current_count=getCurrentEmailSchedulesCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);

            while(to_add>added && attempts<max_attempts)
            {
                String create_with_name="E"+CommonUtil.getUniqueMessage()+"@email.com";

                try
                {
                    EmailSchedule.addSchedule(driver,etest,"All Visitors",create_with_name,false,null,false,null,"Every day","xlsx",ExecuteStatements.getUserName(driver));
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }   
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                    TakeScreenshot.infoScreenshot(driver,etest);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.log(e,etest,Status.WARNING);
            TakeScreenshot.infoScreenshot(driver,etest);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachLeadscoreLimit(WebDriver driver,ExtentTest etest,int limit)
    {

        if(limit==0)
        {
            return;
        }

        String portal="Unknown";
        String name="lead score";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);

            Tab.navToLeadscoringTab(driver);

            int current_count=getCurrentLeadscoringCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);

            while(to_add>added && attempts<max_attempts)
            {
                try
                {
                    com.zoho.livedesk.client.LeadScoringRT.LeadScoringRealTime.addRule(etest,driver,"1", "Browser", null, "is equal to", "Google Chrome", null, "96", true);
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }   
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                    TakeScreenshot.infoScreenshot(driver,etest);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.log(e,etest,Status.WARNING);
            TakeScreenshot.infoScreenshot(driver,etest);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void reachChatRoutingLimit(WebDriver driver,ExtentTest etest,int limit)
    {
        if(limit==0)
        {
            return;
        }

        String portal="Unknown";
        String name="chat routing";

        try
        {
            portal=ExecuteStatements.getPortal(driver);
            driver.navigate().refresh();CommonUtil.sleep(5000);      

            Tab.navToChatRoutingTab(driver);

            int current_count=getCurrentChatRoutingCount(driver);
            int to_add=limit-current_count;
            int max_attempts=to_add+5;
            int added=0,attempts=0;

            etest.log(Status.INFO,"current "+name+" count : "+current_count+", to add : "+to_add);

            while(to_add>added && attempts<max_attempts)
            {
                try
                {
                    ChatRouting.addNewRule(driver,etest);
                    CommonUtil.sleep(3000);
                    added++;

                    if(added%5==0)
                    {
                       CommonUtil.sleep(10000);//to avoid ip block
                    }   
                }
                catch(Exception e1)
                {
                    e1.printStackTrace();
                    etest.log(Status.WARNING,"Exception occured when adding "+name);
                    TakeScreenshot.log(e1,etest,Status.WARNING);
                    TakeScreenshot.infoScreenshot(driver,etest);
                }

                attempts++;
            }

            if(added>=to_add)
            {
                etest.log(Status.PASS,name+" were added according to plan limit");
            }
            else
            {
                etest.log(Status.FAIL,name+" were NOT added according to plan limit");
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.WARNING,name+" were not added for portal "+portal);
            TakeScreenshot.log(e,etest,Status.WARNING);
            TakeScreenshot.infoScreenshot(driver,etest);
        }

        TakeScreenshot.infoScreenshot(driver,etest);
    }


    public static Plan getPlan(WebDriver driver)
    {
        String plan=ExecuteStatements.getCurrentPlanName(driver);
        if(plan.contains("Enterprise"))
        {
            return Plan.ENTERPRISE;
        }
        if(plan.contains("Professional"))
        {
            return Plan.PROFESSIONAL;
        }
        if(plan.contains("Basic"))
        {
            return Plan.BASIC;
        }
        if(plan.contains("Free"))
        {
            return Plan.FREE;
        }

        return null;
    }

    public static int getListCount(WebDriver driver,String script)
    {
        String value=(((JavascriptExecutor) driver).executeScript(script)).toString();
        return Integer.parseInt(value);
    }

    public static int getCurrentOperatorsCount(WebDriver driver)
    {
        return getListCount(driver,Plan.OPERATORS_SCRIPT);
    }

    public static int getCurrentDepartmentsCount(WebDriver driver)
    {
        return getListCount(driver,Plan.DEPT_SCRIPT);
    }

    public static int getCurrentWebsitesCount(WebDriver driver)
    {
        return getListCount(driver,Plan.WEBSITE_SCRIPT);
    }

    public static int getCurrentTriggersCount(WebDriver driver) throws Exception
    {
        Tab.navToITTab(driver);

        return getListCount(driver,Plan.RULES_SCRIPT);
    }

    public static int getCurrentVisitorRoutingCount(WebDriver driver) throws Exception
    {
        Tab.navToVRTab(driver);

        return getListCount(driver,Plan.RULES_SCRIPT);
    }

    public static int getCurrentEmailSchedulesCount(WebDriver driver) throws Exception
    {
        Tab.navToSchedulesTab(driver);

        return getListCount(driver,Plan.SCHEDULES_SCRIPT);
    }

    public static int getCurrentLeadscoringCount(WebDriver driver) throws Exception
    {
        Tab.navToLeadscoringTab(driver);

        return getListCount(driver,Plan.LEADSCORE_SCRIPT);
    }

    public static int getCurrentChatRoutingCount(WebDriver driver) throws Exception
    {
        Tab.navToChatRoutingTab(driver);
        return getListCount(driver,Plan.CHAT_ROUTING_SCRIPT);
    }

    public enum Plan
    {
        ENTERPRISE(10,25,25,25,25,10,25,25),
        PROFESSIONAL(5,5,5,5,5,5,25,5),
        BASIC(3,3,3,3,3,3,25,3),
        FREE(2,1,1,0,0,0,25,0);

        static final String
        OPERATORS_SCRIPT="return Object.keys(AgentDB.reps).length;",
        WEBSITE_SCRIPT="return Object.keys(EmbedChats.list).length;",
        DEPT_SCRIPT="return Object.keys(DepartmentDB.alldepts).length;",
        CHAT_MONITOR_SCRIPT="return Object.keys(ChatMonitor.list).length;",
        RULES_SCRIPT="return Object.keys(Rules.getList()).length;",
        SCHEDULES_SCRIPT="return Object.keys(LvAction.schedulerlist).length;",
        LEADSCORE_SCRIPT="return  Object.keys(LeadScore.list).length;",
        CHAT_ROUTING_SCRIPT="return  Object.keys(Rules.crlist).length;";
        
        public int
        OPERATORS_LIMIT,WEBSITES_LIMIT,DEPARTMENTS_LIMIT,TRIGGERS_LIMIT,VISITOR_ROUTING_LIMIT,EMAIL_SCHEDULES_LIMIT,LEADSCORE_LIMIT,CHAT_ROUTING_LIMIT;
        
        Plan(int OPERATORS_LIMIT,int WEBSITES_LIMIT,int DEPARTMENTS_LIMIT,int TRIGGERS_LIMIT,int VISITOR_ROUTING_LIMIT,int EMAIL_SCHEDULES_LIMIT,int LEADSCORE_LIMIT,int CHAT_ROUTING_LIMIT)
        {
            this.OPERATORS_LIMIT=OPERATORS_LIMIT;
            this.WEBSITES_LIMIT=WEBSITES_LIMIT;
            this.DEPARTMENTS_LIMIT=DEPARTMENTS_LIMIT;
            this.TRIGGERS_LIMIT=TRIGGERS_LIMIT;
            this.VISITOR_ROUTING_LIMIT=VISITOR_ROUTING_LIMIT;
            this.EMAIL_SCHEDULES_LIMIT=EMAIL_SCHEDULES_LIMIT;
            this.LEADSCORE_LIMIT=LEADSCORE_LIMIT;
            this.CHAT_ROUTING_LIMIT=CHAT_ROUTING_LIMIT;
        }        
    }

    public static ArrayList<WebElement> getCloseButtons(WebDriver driver)
    {
        ArrayList<WebElement> close_buttons=new ArrayList<WebElement>();

        if(isBodyContains(driver,CLOSE1_CLASSNAME) && CommonWait.isPresent(driver,CLOSE1) )
        {
            List<WebElement> close_list=CommonUtil.getElements(driver,CLOSE1);
            close_buttons.addAll(close_list);
        }

        return close_buttons;
    }

    public static void closeAllPopups(WebDriver driver,ExtentTest etest)
    {
        if(Debugger.isSalesIQPage(driver)==false)
        {
            return;
        }

        try
        {
            ArrayList<WebElement> close_buttons=getCloseButtons(driver);

            boolean isLogged=false;

            for(int j=0;j<2;j++)//running 2 times to make sure all are closed
            {
                for(int i=0;i<close_buttons.size();i++)
                {
                    try
                    {
                        if(!isLogged)
                        {
                            etest.log(Status.INFO,"Closing any popups that might be open.");
                            TakeScreenshot.infoScreenshot(driver,etest);
                            isLogged=true;
                        }

                        WebElement close=close_buttons.get(i);
                        CommonUtil.jsClick(driver,close);
                        CommonWait.waitTillHidden(close);
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
        catch(Exception e1)
        {
            e1.printStackTrace();
            etest.log(Status.WARNING,"Exception while closing unclosed popups");
            TakeScreenshot.log(e1,etest,Status.INFO);
            TakeScreenshot.infoScreenshot(driver,etest);
        }
    }
}
