//$Id$
package com.zoho.livedesk.util;

import java.net.*;
import java.net.URL;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.FileUtil;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.crmplus.chats.ChatBasics;
import com.zoho.livedesk.client.crmplus.chats.ConnectedTab;
import com.zoho.livedesk.client.crmplus.rings.TrackingRings;
import com.zoho.livedesk.client.crmplus.chats.CRMPChatHistory;
import com.zoho.livedesk.client.crmplus.chats.ChatIntegDetails;
import com.zoho.livedesk.client.crmplus.others.CRMPIntegSettings;
import com.zoho.livedesk.client.crmplus.others.CRMPlusTestOthers;
import com.zoho.livedesk.client.crmplus.others.CRMPlusTestBasics;
import com.zoho.livedesk.client.crmplus.visitorhistory.VisitorHistory;

public class SalesIQTestCRMPlus extends TestCase
{
    private static final int MYTHREADS = 200;
    private static int ncount = 0;
    //private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    public Hashtable result;
    public Hashtable servicedown;
    public Hashtable res;
    public Hashtable finalresult;
    public static boolean isstarted = false;
    public static boolean isended = false;
    long starttime;
    long endtime = 0L;
    String browser = "";
    Hashtable report;
    String url = "";
    public static long etime = 0L;
    public static ArrayList<String> tested_modules = new ArrayList<String>();
    public static String modulesstr = ConfManager.getCRMPlusModules();
    public static ArrayList<String> list = new ArrayList<String>(Arrays.asList(modulesstr.split(",")));

    ArrayList<String> modules = new ArrayList(Arrays.asList("showstopperkey1","showstopperkey2"));
    public static Set<ExtentTest> etests = new HashSet<ExtentTest>();
    Hashtable showstopper;

    public WebDriver setUpDriver() throws Exception
    {
        return Functions.setUp(true);
    }

    public boolean testingStarted() throws Exception
    {
        return isstarted;
    }

    public boolean testingEnded() throws Exception
    {
        return isended;
    }

    public void testInit() throws Exception
    {
        etests = new HashSet<ExtentTest>();
        res = new Hashtable();
        result = new Hashtable();
        servicedown = new Hashtable();
        report = new Hashtable();
        showstopper = new Hashtable();
        finalresult = new Hashtable();
        starttime = System.currentTimeMillis();

        ExecutorService executor = Executors.newFixedThreadPool(MYTHREADS);

        for (int i = 0; i < 6; i++)
        {
            Runnable worker = new MyRunnable(i);
            executor.execute(worker);
        }
        executor.shutdown();

        while (!executor.isTerminated()) 
        {
            String unusedVariable = "Added this statement for avoiding code check errors";
        }

        for(ExtentTest etest : etests)
        {
            ComplexReportFactory.closeTest(etest);
        }

        endtime = System.currentTimeMillis();

        setEndTime();
        calculateReport(result,endtime-starttime);

        String filePath = FileUtil.sendFileReport(report,res,showstopper,servicedown);
        String module = "CRMPlus Modules";
        //ChatUtil.sendChatResult(report,res,showstopper,servicedown,filePath,module,false);
        Util.buggyFinder(report,module,filePath);

        isended = true;
        Thread.sleep(5000);

        isended = false;

        finalresult.put("result",result);
        finalresult.put("servicedown",servicedown);
        finalresult.put("report",report);
        finalresult.put("SalesIQTestCRMPlus"," *"+module+"* :\\n Total Use Cases:"+report.get("TotalUseCases")+" Failure:"+report.get("Failure")+" ("+report.get("Failure_per")+"%)");

        Util.print(" Result Hash >>>"+result);
        Util.print(" Service down Hash >>>"+servicedown);
        Util.print(" Report Hash >>> "+report);
    }

    public Hashtable sendResult()
    {
        Util.print(" Result Hash >>>"+finalresult.get("result"));
        Util.print(" Service down Hash >>>"+finalresult.get("servicedown"));
        Util.print(" Report Hash >>>"+finalresult.get("report"));
        return finalresult;
    }

    public void setEndTime() throws Exception
    {
        try
        {
            etime = System.currentTimeMillis();
        }
        catch(Exception e)
        {}
    }

    public long getEndTime() throws Exception
    {
        return etime;
    }

    private void calculateReport(Hashtable result, long timetaken)
    {
        try
        {
            timetaken = timetaken/1000;
            String time = "";

            if(timetaken > 60)
            {
                long s = timetaken % 60;
                long m = (timetaken / 60) % 60;
                long h = (timetaken / (60 * 60)) % 24;
                if(h > 0)
                {
                    if(h == 1)
                    {
                        time += h+" hour ";
                    }
                    else
                    {
                        time += h+" hours ";
                    }
                }
                if(m > 0)
                {
                    if(m == 1)
                    {
                        time += m+ " min ";
                    }
                    else
                    {
                        time += m+" mins ";
                    }
                }
                if(s > 0)
                {
                    if(s == 1)
                    {
                        time += s +" sec";
                    }
                    else
                    {
                        time += s +" secs";
                    }
                }
            }
            else
            {
                time = timetaken + " secs";
            }

            report.put("TimeTaken", time);

            int size = result.size();
            int success = 0;
            report.put("TotalUseCases", size);
            Set<String> keys = result.keySet();
            for(String key: keys)
            {
                if((boolean) (""+result.get(key)).equals("true"))
                {
                    success++;
                }
                else
                {
                    res.put(KeyManager.getRealValue(key),"fail");
                    if(modules.contains(key))
                    {
                        showstopper.put(KeyManager.getRealValue(key),"failed");
                    }
                }
            }
            report.put("Success", success);
            report.put("Failure", size-success);
            int success_per = (success*100)/size;
            report.put("Success_per", success_per);
            report.put("Failure_per", 100-success_per);
            if(browser.contains("chrome"))
            {
                report.put("Browser", "chrome");
            }
            else if(browser.contains("firefox"))
            {
                report.put("Browser", "firefox");
            }
            else
            {
                report.put("Browser", "IE");
            }
            //String setup = ConfManager.getSetup();
            String setup = Util.siteNameout();
            if(setup.contains("labsalesiq"))
            {
                report.put("Setup", "LabSalesIQ");
            }
            else if(setup.contains("localzoho"))
            {
                report.put("Setup", "LocalZoho");
            }
            else if(setup.contains("presalesiq"))
            {
                report.put("Setup", "Pre Setup");
            }
            else if(setup.contains(".zoho"))
            {
                report.put("Setup", "IDC");
            }
            else
            {
                report.put("Setup", "-");
            }
            String loginsite = Util.siteNameout()+"/automation";
            report.put("URL", loginsite);
            //String build = WebdriverQAUtil.getBuildlable();
            String build = Util.buildlabel();

            report.put("Build", build);
        }
        catch(Exception e)
        {
            // Util.print("Exception calculating report : "+e);
            // e.printStackTrace();
        }
    }
    @Override
    public void tearDown() throws Exception
    {
        //driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    public static TestSuite suite()
    {
        TestSuite suite = new TestSuite();
        suite.addTestSuite(SalesIQTestCRMPlus.class);
        return suite;
    }

    public static void main(String[] args)
    {
        ConfManager.init();
        junit.textui.TestRunner.run(suite());
    }

    public class MyRunnable implements Runnable {
        private int fnum;

        MyRunnable(int fnum) {
            this.fnum = fnum;
        }

        @Override
        public void run() {

            try
            {

                if(fnum == 0 && isTest("CRMP Tracking Rings"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.loginCRMP(driver,"trackingrings"))
                    {
                        if(isTest("CRMP Tracking Rings"))
                        {
                            Hashtable hashtable = TrackingRings.testRings(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Tracking Rings");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Tracking Rings");
                        }
                    }
                    Functions.logout(driver);
                }
                else if(fnum == 1 && isTest("CRMP Visitor History"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.loginCRMP(driver,"visitorhistory"))
                    {
                        if(isTest("CRMP Visitor History"))
                        {
                            Hashtable hashtable = VisitorHistory.testVisitor(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Visitor History");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Visitor History");
                        }
                    }
                    Functions.logout(driver);
                }
                else if(fnum == 2 && isTest("CRMP Chat History","CRMP Integ Settings"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.loginCRMP(driver,"chathistory"))
                    {
                        if(isTest("CRMP Chat History"))
                        {
                            Hashtable hashtable = CRMPChatHistory.testChatHistory(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Chat History");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Chat History");
                        }

                        if(isTest("CRMP Integ Settings"))
                        {
                            Hashtable hashtable = CRMPIntegSettings.testIntegSettings(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Integ Settings");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Integ Settings");
                        }
                    }
                    Functions.logout(driver);
                }
                else if(fnum == 3 && isTest("CRMP Chat Basics","CRMP Connected","CRMP Test Others"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.loginCRMP(driver,"chatbasics"))
                    {
                        if(isTest("CRMP Connected"))
                        {
                            Hashtable hashtable = ConnectedTab.testConnectedTab(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Connected");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Connected");
                        }

                        if(isTest("CRMP Test Others"))
                        {
                            Hashtable hashtable = CRMPlusTestOthers.testOthers(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Test Others");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Test Others");
                        }
                        
                        if(isTest("CRMP Chat Basics"))
                        {
                            Hashtable hashtable = ChatBasics.testChatBasics(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Chat Basics");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Chat Basics");
                        }
                    }
                    Functions.logout(driver);
                }
                else if(fnum == 4 && isTest("CRMP Chat Integ Details"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.loginCRMP(driver,"chatinteg"))
                    {
                        if(isTest("CRMP Chat Integ Details"))
                        {
                            Hashtable hashtable = ChatIntegDetails.testChatInteg(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Chat Integ Details");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Chat Integ Details");
                        }
                    }
                    Functions.logout(driver);
                }
                else if(fnum == 5 && isTest("CRMP Test Basics"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.loginCRMP(driver,"basics"))
                    {
                        if(isTest("CRMP Test Basics"))
                        {
                            Hashtable hashtable = CRMPlusTestBasics.testBasics(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"CRMP Test Basics");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("CRMP Test Basics");
                        }
                    }
                    Functions.logout(driver);
                }
            }
            catch (Exception e)
            {
                Util.print("Status: Exception  for fnum"+fnum+": "+e);
                e.printStackTrace();
            }
            Util.print("Status: Success");
        }
    }

    public static boolean isTest(String... module_names)
    {
        return Util.isTest(list,module_names);
    }

}
