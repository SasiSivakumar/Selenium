//$Id$
package com.zoho.livedesk.util;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;
import java.net.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.Chat;
import com.zoho.livedesk.client.CSS.CustomCSS;
import com.zoho.livedesk.client.WebEmbedSettings;
import com.zoho.livedesk.client.ChatWidget;
import com.zoho.livedesk.client.NewEmbed.NewEmbedUtil;
import com.zoho.livedesk.client.FeedbackUtil;
import com.zoho.livedesk.client.ChatNotifications;
import com.zoho.livedesk.client.FormSubmission;
import com.zoho.livedesk.client.FormSubmissionWC;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesModule;
import com.zoho.livedesk.client.ConcurrentChat;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPIModule;
import com.zoho.livedesk.client.MissedChat.MissedChatModule;
import com.zoho.livedesk.client.ChatTransfer.TransferChat;
import com.zoho.livedesk.client.EmbedConfig.TestInit;
import com.zoho.livedesk.client.EmbedConfigTheme.TestInitTheme;
import com.zoho.livedesk.client.EmbedConfigTheme2.TestInitTheme2;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;
import com.zoho.livedesk.client.ConversationView.ConversationViewTests;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatTests;
import com.zoho.livedesk.client.PortalSettingsRealTime.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.CannedResponse.CannedResponseModule;
import com.zoho.livedesk.client.SignatureLiveChat.SignatureLiveChatModule;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.client.VisitorChat.VisitorChatAdvanced;
import com.zoho.livedesk.client.VisitorChat.VisitorEndTests;
import com.zoho.livedesk.client.BusinessHours.BusinessHoursTests;
import com.zoho.livedesk.client.Templates.EmailTemplateTests;

public class SalesIQTestChatWidget extends TestCase{
    private static final int MYTHREADS = 200;
    private static int ncount = 0;
    //private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    public Hashtable result;
    public Hashtable servicedown;
    public Hashtable res;
    public Hashtable finalresult;
    public static boolean isstarted = false;
    public static boolean isended = false;
    long starttime;
    long endtime = 0L;
    String browser = "";
    Hashtable report;
    String url = "";
    public static long etime = 0L;
    public static ArrayList<String> tested_modules = new ArrayList<String>();
    public static String modulesstr = ConfManager.getChatWidgetModules();
    public static ArrayList<String> list = new ArrayList<String>(Arrays.asList(modulesstr.split(",")));
    public static Set<ExtentTest> etests = new HashSet<ExtentTest>();
    ArrayList<String> modules = new ArrayList(Arrays.asList("SU1","SU2","SC1","SC2","SD1","SD2","SP1","SP2","SB1","SB2","SW1","SW2","SCM1","SCM2","SI1","SI2","SI3","CM1","CM2","CM3","Login","STR1","STR2","STR3","STR4","AFH1","AFH2","AFH3","KBSK1","KBSK2","KBSK3","PER1","PER2","TRC1","TRC2","CHAT1","CHAT5","CHAT6","CHAT7","CHAT9","CHAT15","CHAT22","CHAT23","CHAT26","CHAT29","CHAT30","CHAT34","CHAT49","CHAT62","CHAT73","CHAT79","CHAT82","CHAT101"));

    Hashtable showstopper;

    public WebDriver setUpDriver() throws Exception
    {
        Thread.sleep(15000);
        
        return Functions.setUp();
    }

    public boolean testingStarted() throws Exception
    {
        return isstarted;
    }

    public boolean testingEnded() throws Exception
    {
        return isended;
    }

    public void testInit() throws Exception
    {
        etests = new HashSet<ExtentTest>();
        res = new Hashtable();
        result = new Hashtable();
        servicedown = new Hashtable();
        report = new Hashtable();
        showstopper = new Hashtable();
        finalresult = new Hashtable();
        starttime = System.currentTimeMillis();

        ExecutorService executor = Executors.newFixedThreadPool(MYTHREADS);

        for (int i = 0; i <= 13; i++)
        {
            Runnable worker = new MyRunnable(i);
            executor.execute(worker);
        }
        executor.shutdown();

        while (!executor.isTerminated()) {}

        for(ExtentTest etest : etests)
        {
            ComplexReportFactory.closeTest(etest);
        }

        endtime = System.currentTimeMillis();

        setEndTime();
        calculateReport(result,endtime-starttime);

        String filePath = FileUtil.sendFileReport(report,res,showstopper,servicedown);
        String module = "Chat Widget Module";
        //ChatUtil.sendChatResult(report,res,showstopper,servicedown,filePath,module,false);
        Util.buggyFinder(report,module,filePath);

        isended = true;
        Thread.sleep(5000);
        isended = false;

        finalresult.put("result",result);
        finalresult.put("servicedown",servicedown);
        finalresult.put("report",report);
        finalresult.put("SalesIQTestChatWidget"," *"+module+"* :\\n Total Use Cases:"+report.get("TotalUseCases")+" | Failure:"+report.get("Failure")+" ("+report.get("Failure_per")+"%)");

        System.out.println(" Result Hash >>>"+result);
        System.out.println(" Service down Hash >>>"+servicedown);
        System.out.println(" Report Hash >>> "+report);
    }

    public Hashtable sendResult()
    {
        System.out.println(" Result Hash >>>"+finalresult.get("result"));
        System.out.println(" Service down Hash >>>"+finalresult.get("servicedown"));
        System.out.println(" Report Hash >>>"+finalresult.get("report"));
        return finalresult;
    }

    public void setEndTime() throws Exception
    {
        try
        {
            etime = System.currentTimeMillis();
        }
        catch(Exception e)
        {}
    }

    public long getEndTime() throws Exception
    {
        return etime;
    }

    private void calculateReport(Hashtable result, long timetaken)
    {
        try
        {
            timetaken = timetaken/1000;
            String time = "";

            if(timetaken > 60)
            {
                long s = timetaken % 60;
                long m = (timetaken / 60) % 60;
                long h = (timetaken / (60 * 60)) % 24;
                if(h > 0)
                {
                    if(h == 1)
                    {
                        time += h+" hour ";
                    }
                    else
                    {
                        time += h+" hours ";
                    }
                }
                if(m > 0)
                {
                    if(m == 1)
                    {
                        time += m+ " min ";
                    }
                    else
                    {
                        time += m+" mins ";
                    }
                }
                if(s > 0)
                {
                    if(s == 1)
                    {
                        time += s +" sec";
                    }
                    else
                    {
                        time += s +" secs";
                    }
                }
            }
            else
            {
                time = timetaken + " secs";
            }

            report.put("TimeTaken", time);

            int size = result.size();
            int success = 0;
            report.put("TotalUseCases", size);
            Set<String> keys = result.keySet();
            for(String key: keys){
                if((boolean) (""+result.get(key)).equals("true"))
                {
                    success++;
                }
                else
                {
                    res.put(KeyManager.getRealValue(key),"fail");
                    if(modules.contains(key))
                    {
                        showstopper.put(KeyManager.getRealValue(key),"failed");
                    }
                }
            }
            report.put("Success", success);
            report.put("Failure", size-success);
            int success_per = (success*100)/size;
            report.put("Success_per", success_per);
            report.put("Failure_per", 100-success_per);
            if(browser.contains("chrome"))
            {
                report.put("Browser", "chrome");
            }
            else if(browser.contains("firefox"))
            {
                report.put("Browser", "firefox");
            }
            else
            {
                report.put("Browser", "IE");
            }
            //String setup = ConfManager.getSetup();
            String setup = Util.siteNameout();
            if(setup.contains("labsalesiq"))
            {
                report.put("Setup", "LabSalesIQ");
            }
            else if(setup.contains("localzoho"))
            {
                report.put("Setup", "LocalZoho");
            }
            else if(setup.contains("presalesiq"))
            {
                report.put("Setup", "Pre Setup");
            }
            else if(setup.contains(".zoho"))
            {
                report.put("Setup", "IDC");
            }
            else
            {
                report.put("Setup", "-");
            }
            String loginsite = Util.siteNameout()+"/ldautomation2";
            report.put("URL", loginsite);
            //String build = WebdriverQAUtil.getBuildlable();
            String build = Util.buildlabel();

            report.put("Build", build);
        }
        catch(Exception e)
        {
            // System.out.println("Exception calculating report : "+e);
            // e.printStackTrace();
        }
    }
    @Override
    public void tearDown() throws Exception
    {
        //driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    public static TestSuite suite()
    {
        TestSuite suite = new TestSuite();
        suite.addTestSuite(SalesIQTestChatWidget.class);
        return suite;
    }

    public static void main(String[] args)
    {
        ConfManager.init();
        junit.textui.TestRunner.run(suite());
    }

    public class MyRunnable implements Runnable {
        private int fnum;

        MyRunnable(int fnum) {
            this.fnum = fnum;
        }

        @Override
        public void run() {

            try
            {
                if(fnum == 0 && isTest("Email Templates"))
                {
                    WebDriver driver = setUpDriver();

                    if(Functions.login(driver,"emailTemplate"))
                    {
                        if(isTest("Email Templates"))
                        {
                            Hashtable hashtable = EmailTemplateTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Email Templates");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Email Templates");
                        }
                    }

                    Functions.logout(driver);
                }
                else if(fnum == 1 && isTest("Feedback","Dynamic Canned Message","Chat Notification","Form Submission","Concurrent Chats","REST API"))
                {
                    WebDriver driver = setUpDriver();
                    if(Functions.login(driver,"feedback"))
                    {
                        if(isTest("Feedback"))
                        {
                            Hashtable hashtable = FeedbackUtil.fdk(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Feedback");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Feedback");
                        }
                        
                        if(isTest("Dynamic Canned Message"))
                        {
                            // have navigated this to canned response module
                            
                            // Hashtable hashtable = CannedMessagesModule.test(driver);
                            // result.putAll((Hashtable) hashtable.get("result"));
                            // Util.getModulesResult((Hashtable) hashtable.get("result"),"Dynamic Canned Message");
                            // servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            // tested_modules.add("Dynamic Canned Message");
                        }

                        if(isTest("Chat Notification"))
                        {
                            Hashtable hashtable = ChatNotifications.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Chat Notification");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Chat Notification");
                        }

                        if(isTest("Form Submission"))
                        {
//                            Hashtable hashtable = FormSubmission.test(driver);
//                            result.putAll((Hashtable) hashtable.get("result"));
//                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Form Submission");
//                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
//                            tested_modules.add("Form Submission");
                        
                            Hashtable hashtable = FormSubmissionWC.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Form Submission WC");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Form Submission WC");
                        }

                        if(isTest("Concurrent Chats"))
                        {
                            Hashtable hashtable = ConcurrentChat.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Concurrent Chat");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Concurrent Chat");
                        }

                        if(isTest("REST API") && !(Util.siteNameout().contains("lab")))
                        {
                            Hashtable hashtable = SalesIQRestAPIModule.test();
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"REST API");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("REST API");
                        }
                    }
                    Functions.logout(driver);
                }
                else if(fnum == 2 && isTest("Transfer Chat","Conversation History"))
                {
                    WebDriver driver = setUpDriver();
                    
                    if(Functions.login(driver,"transferchat"))
                    {
                        if(isTest("Conversation History"))
                        {
                            Hashtable hashtable = ConversationViewTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"ConversationView");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Conversation History");
                        }
                        

                        if(isTest("Transfer Chat"))
                        {
                            Hashtable hashtable = TransferChat.testtransferchat(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Transfer Chat");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Transfer Chat");
                        }
                    }
                    
                    Functions.logout(driver);
                }
                else if(fnum == 3 && isTest("Embed Configuration"))
                {
                    //login implemented in usecase class

                    if(isTest("Embed Configuration"))
                    {
                        Hashtable hashtable = TestInit.usecase();
                        result.putAll((Hashtable) hashtable.get("result"));
                        Util.getModulesResult((Hashtable) hashtable.get("result"),"Embed Configuration Basics");
                        servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                        tested_modules.add("Embed Configuration Basics");
                    }
                }
                else if(fnum == 4 && isTest("Embed Configuration"))
                {       
                    //login implemented in usecase class    
                    if(isTest("Embed Configuration"))
                    {
                        Hashtable hashtable = TestInitTheme.usecase();
                        result.putAll((Hashtable) hashtable.get("result"));
                        Util.getModulesResult((Hashtable) hashtable.get("result"),"Embed Configuration Theme");
                        servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                        tested_modules.add("Embed Configuration Theme");
                    }
                }
                else if(fnum == 5 && isTest("Embed Configuration"))
                {     
                    //login implemented in usecase class      
                    if(isTest("Embed Configuration"))     
                    {
                        Hashtable hashtable = TestInitTheme2.usecase();
                        result.putAll((Hashtable) hashtable.get("result"));
                        Util.getModulesResult((Hashtable) hashtable.get("result"),"Embed Configuration Chat window Theme");
                        servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                        tested_modules.add("Embed Configuration Chat window Theme");
                    }
                }

                else if(fnum == 6 && isTest("Concurrent Chats"))
                {
                    WebDriver driver = setUpDriver();
                    
                    if(Functions.login(driver,"concurrent_chats"))
                    {                       
                        if(isTest("Concurrent Chats"))
                        {
                            Hashtable hashtable = ConcurrentChatTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Concurrent Chats");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Concurrent Chats");
                        }
                    }
                    
                    Functions.logout(driver);
                }

                else if(fnum == 7 && isTest("Portal Settings Real Time"))
                {
                    WebDriver driver = setUpDriver();
                    
                    if(Functions.login(driver,"portal_settings"))
                    {                        
                        if(isTest("Portal Settings Real Time"))
                        {
                            Hashtable hashtable = PortalSettingsRealTimeTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Portal Settings Real Time");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Portal Settings Real Time");
                        }
                    }
                    
                    Functions.logout(driver);
                }

                else if(fnum == 8 && isTest("Dynamic Canned Response","Signature Live Chat"))
                {
                    WebDriver driver = Driver.getDriver(Driver.getPageLoadStrategyCapabilities());

                    try
                    {
                        Functions.login(driver,"canned_response");
                    }
                    catch(Exception e)
                    {
                        CommonUtil.printStackTrace(e);
                        CommonUtil.sleep(15000);
                    }

                    if(isTest("Dynamic Canned Response"))
                    {
                        Hashtable hashtable = CannedResponseModule.test(driver);
                        result.putAll((Hashtable) hashtable.get("result"));
                        Util.getModulesResult((Hashtable) hashtable.get("result"),"Dynamic Canned Response");
                        servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                        tested_modules.add("Dynamic Canned Response");
                    }

                    if(isTest("Signature Live Chat"))
                    {
                        Hashtable hashtable = SignatureLiveChatModule.test(driver);
                        result.putAll((Hashtable) hashtable.get("result"));
                        Util.getModulesResult((Hashtable) hashtable.get("result"),"Signature Live Chat");
                        servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                        tested_modules.add("Signature Live Chat");
                    }

                    Functions.logout(driver);
                }

                else if(fnum == 9 && isTest("Chat History"))
                {
                    WebDriver driver = Driver.getLinuxDriver();
                    
                    if(Functions.login(driver,"chathistory"))
                    {                        
                        if(isTest("Chat History"))
                        {
                            Hashtable hashtable = ChatHistoryTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Chat History");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Chat History");
                        }
                    }
                    
                    Functions.logout(driver);
                }

                else if(fnum == 10 && isTest("Visitor Chat Advanced"))
                {
                    WebDriver driver = setUpDriver();
                    
                    if(Functions.login(driver,"visitor_chat"))
                    {                    
                        if(isTest("Visitor Chat Advanced"))
                        {
                            Hashtable hashtable = VisitorChatAdvanced.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Visitor Chat Advanced Set 1");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Visitor Chat Advanced Set 1");
                        }

                        if(isTest("Visitor Chat Advanced"))
                        {
                            Hashtable hashtable = VisitorEndTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Visitor Chat Advanced Set 2");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Visitor Chat Advanced Set 2");
                        }
                    }
                    
                    Functions.logout(driver);
                }

                else if(fnum == 11 && isTest("Custom CSS","Business Hours"))
                {
                    WebDriver driver = setUpDriver();

                    if(Functions.login(driver,"customcss"))
                    {
                        if(isTest("Custom CSS"))
                        {
                            Hashtable hashtable = CustomCSS.checkCSS(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Custom CSS");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Custom CSS");
                        }

                        if(isTest("Business Hours"))
                        {                            
                            Hashtable hashtable = BusinessHoursTests.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Business Hours");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Business Hours");
                        }
                        //do not add any module after business hours without cleanup
                    }

                    Functions.logout(driver);
                }
                else if(fnum == 12 && isTest("Missed Chat"))
                {
                    WebDriver driver = setUpDriver();

                    if(Functions.login(driver,"missedchatagent1"))
                    {
                        if(isTest("Missed Chat"))
                        {
                            Hashtable hashtable = MissedChatModule.test(driver);
                            result.putAll((Hashtable) hashtable.get("result"));
                            Util.getModulesResult((Hashtable) hashtable.get("result"),"Missed Chat");
                            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                            tested_modules.add("Missed Chat");
                        }
                    }

                    Functions.logout(driver);
                }
                else if(fnum == 13 && isTest("Apps"))
                {
                    com.zoho.livedesk.util.common.CommonUtil.doNothing();
                    //Uncomment this after apps module enabled in local setup

                    // WebDriver driver = setUpDriver();

                    // if(Functions.login(driver,"apps"))
                    // {
                    //     if(isTest("Apps"))
                    //     {
                    //         Hashtable hashtable = com.zoho.livedesk.client.Apps.AppsTests.test(driver);
                    //         result.putAll((Hashtable) hashtable.get("result"));
                    //         Util.getModulesResult((Hashtable) hashtable.get("result"),"Apps");
                    //         servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    //         tested_modules.add("Apps");
                    //     }
                    //     if(isTest("Apps"))
                    //     {
                    //         Hashtable hashtable = com.zoho.livedesk.client.Apps.AppsComponentsModuleTests.test(driver);
                    //         result.putAll((Hashtable) hashtable.get("result"));
                    //         Util.getModulesResult((Hashtable) hashtable.get("result"),"Apps");
                    //         servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    //         tested_modules.add("Apps");
                    //     }
                    // }

                    // Functions.logout(driver);
                }
            }
            catch (Exception e)
            {
                System.out.println("Status: Exception  for fnum"+fnum+": "+e);
                e.printStackTrace();
            }
            System.out.println("Status: Success");
        }
    }

    public static boolean isTest(String... module_names)
    {
        return Util.isTest(list,module_names);
    }

}
