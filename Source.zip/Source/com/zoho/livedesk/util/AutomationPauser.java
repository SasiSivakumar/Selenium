//$Id$
package com.zoho.livedesk.util;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.client.ComplexReportFactory;

public class AutomationPauser
{
    public static Boolean pause_automation;

    public static String paused_timestamp,reason;

    public static final int MAX_PAUSE_TIME_IN_MINS=30;
    public static final int MAX_PAUSE_TIME_IN_MILLIS=MAX_PAUSE_TIME_IN_MINS*(60*1000);

    public static final int MAX_PAUSES_ALLOWED=3;

    public static int times_paused_during_current_session;

    public static Long paused_time;

    public static void init()
    {
        pause_automation=false;
        reason=null;
        paused_timestamp=null;
        paused_time=null;
        times_paused_during_current_session=0;
    }

    public static boolean isAutomationPaused()
    {
        return pause_automation;
    }

    public static boolean isAutomationResumed()
    {
        return !isAutomationPaused();
    }

    public static void pauseAutomation(String reason_for_pause)
    {
        if(isAutomationPaused())
        {
            return;
        }

        if(times_paused_during_current_session>MAX_PAUSES_ALLOWED)
        {
            SalesIQAutomationExceptionHandler.forceStopAutomation("pausing the automation for more than "+MAX_PAUSES_ALLOWED+" times. This will cause many runtime failures in automation flow");
            return;
        }

        pause_automation=true;
        reason=reason_for_pause;
        paused_timestamp=CommonUtil.timestamp();
        paused_time=getCurrentTime();
        times_paused_during_current_session++;

        ChatUtil.postToChannel("Automation was paused. Reason : "+getReasonForPause(),Util.getChannelIDForRunningAutomation(),Util.getAuthTokenForRunningAutomation());
    }

    public static void resumeAutomation()
    {
        if(isAutomationResumed())
        {
            return;
        }

        pause_automation=false;

        ChatUtil.postToChannel("Automation was resumed.",Util.getChannelIDForRunningAutomation(),Util.getAuthTokenForRunningAutomation());
    }

    public static void handle(ExtentTest etest)
    {
        if(isAutomationPaused())
        {
            etest.log(Status.WARNING,"Automation has been paused at "+paused_timestamp+". Reason  : "+getReasonForPause());

            ComplexReportFactory.closeTest(etest,false);           

            while( (getCurrentTime()-paused_time) < MAX_PAUSE_TIME_IN_MILLIS )
            {
                CommonUtil.sleep(5000);//check every 5 seconds if automation can be resumed


                if(isAutomationResumed())
                {
                    etest.log(Status.WARNING,"Automation has been resumed at "+CommonUtil.timestamp()+".");
                    return;
                }

                //in case we stop autoamtion
                if(SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
                {
                    etest.log(Status.WARNING,"Automation has been stopped at "+CommonUtil.timestamp()+". Reason : "+SalesIQAutomationExceptionHandler.getReasonForStopping());
                    return;
                }
            }

            etest.log(Status.WARNING,"Automation has been forcefully resumed at "+CommonUtil.timestamp()+" after waiting for "+MAX_PAUSE_TIME_IN_MINS+" minutes"); 

            ComplexReportFactory.closeTest(etest,false);           
        }
    }

    public static String getReasonForPause()
    {
        return reason;
    }

    public static Long getCurrentTime()
    {
        return new Long(System.currentTimeMillis());
    }
}