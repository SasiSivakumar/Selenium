//$Id$
package com.zoho.livedesk.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.OutputStreamWriter;
import java.io.OutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.util.ArrayList;
import java.util.Arrays;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.qa.server.WebdriverQAUtil;


public class CSVUtil
{
    public static String fileret = "";
    public static String createCSV(Hashtable report, Hashtable result, Hashtable showstopper, Hashtable servicedown)
    {
        Date curdate = new Date();
        
        try
        {
            fileret = writeToCSV((report.get("Build").toString()));
            
            if(result.size()>0)
            {
                Set<String> keys = result.keySet();
                
                for(String key: keys){
                    if((boolean) (""+result.get(key)).equals("true"))
                    {
                        appendToCSV(fileret,KeyManager.getRealValue(key),"com.zoho.livedesk.client","Pass",curdate,(report.get("Build").toString()));
                    }
                    else
                    {
                        appendToCSV(fileret,KeyManager.getRealValue(key),"com.zoho.livedesk.client","Fail",curdate,(report.get("Build").toString()));
                    }
                }
            }
            
            return fileret;
        }
        catch(Exception e)
        {
            System.out.println("Error in get data");
        }
        return fileret;
    }
    
    private static String filePath()
    {
        URL location = FileUtil.class.getProtectionDomain().getCodeSource().getLocation();
        System.out.println(location.getFile());
        String fileloc = location.getFile();
        fileloc = fileloc.replaceAll("/lib/livedesk-webdriver.jar","/webapps/selenium/reports/");
        return fileloc;
    }
    
    public static String writeToCSV(String bLabel)
    {
        String filelocpath = "";
        try
        {
            filelocpath = filePath();
            
            // System.out.println("File Writing !!!"+filelocpath);
            
            String fileName = "/csvresults.csv";
            
            if(bLabel==null||bLabel=="")
            {
                bLabel = "UnknownLabel";
            }
            
            if(bLabel.contains("/"))
            {
                bLabel = bLabel.replaceAll("/","_");
            }
            
            final String dir = System.getProperty("user.dir");
            
            // System.out.println("current dir = " + dir);
            
            File file = new File(filelocpath+bLabel);
            
            // System.out.println("File Writing - "+filelocpath+bLabel);
            
            int fnum = 0;
            
            if(file.mkdir())
            {
                while(file.exists())
                {
                    fileName = "/csvresults"+fnum+".csv";
                    file = new File(filelocpath+bLabel+fileName);
                    // System.out.println("File Writing in name - "+filelocpath+bLabel+fileName);
                    if (!file.exists()) {
                        file.createNewFile();
                        break;
                    }
                    fnum++;
                }
            }
            else
            {
                while(file.exists())
                {
                    fileName = "/csvresults"+fnum+".csv";
                    file = new File(filelocpath+bLabel+fileName);
                    // System.out.println("File Writing in name - "+filelocpath+bLabel+fileName);
                    if (!file.exists()) {
                        file.createNewFile();
                        break;
                    }
                    fnum++;
                }
            }
            
            // System.out.println(bLabel);
            // if file doesnt exists, then create it
            /*if (!file.exists()) {
             file.createNewFile();
             }
             */
            
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.append("Testcase");
            bw.append(",");
            bw.append("Package");
            bw.append(",");
            bw.append("Result");
            bw.append(",");
            bw.append("Date");
            bw.append(",");
            bw.append("BuildName");
            bw.append("\n");
            bw.close();
            
            // System.out.println("File Writing Successful - Done !!!");
            
            String retfile = null;
            
            filelocpath = filelocpath+bLabel+fileName;
        }
        catch(Exception e)
        {
            System.out.println("Exception while writing to csv : "+e);
        }
        return filelocpath;
    }
    
    public static void appendToCSV(String location,String testCase,String packageName,String result,Date date,String buildName)
    {
        try
        {
            FileWriter pw = new FileWriter(location,true);
            
            pw.append(testCase);
            pw.append(",");
            pw.append(packageName);
            pw.append(",");
            pw.append(result);
            pw.append(",");
            pw.append(date.toString());
            pw.append(",");
            pw.append(buildName);
            pw.append("\n");
            
            pw.flush();
            pw.close();
        }
        catch(Exception e)
        {
            System.out.println("Exception while appending to csv : "+e);
        }
    }
    
    private static String getMailString(String path) throws Exception
    {
        BufferedReader reader = null;
        try
        {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(path),"UTF-8"));
            String line = null;
            StringBuffer st = new StringBuffer();
            while((line = reader.readLine())!=null)
            {
                st.append(line);
                st.append("\r\n");//No i18N
            }
            return st.toString();
        }
        finally
        {
            try{if(reader!=null){reader.close();}}catch(Exception e){System.out.println("Unable to close the reader");}
        }
    }
}
