//$Id$
package com.zoho.livedesk.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.OutputStreamWriter;
import java.io.OutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.util.ArrayList;
import java.util.Arrays;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.qa.server.WebdriverQAUtil;


public class FileUtil
{
    public static String fileret = "";
	public static String sendFileReport(Hashtable report, Hashtable result, Hashtable showstopper, Hashtable servicedown)
	{
		try
		{
			String report_template = WebdriverQAUtil.getAttachmentPath("ldreport_mail.html");
			report_template = report_template.replace("null", "salesiq");
			String content = getMailString(report_template);
			
			content=content.replace("$TOTALUSECASE", ""+report.get("TotalUseCases"));
			content=content.replace("$TIMETAKEN", (""+report.get("TimeTaken")));
			content=content.replace("$SUCCESS", ""+report.get("Success"));
			content=content.replace("$FAILURE", ""+report.get("Failure"));
			content=content.replace("$SUCESSPER", (""+report.get("Success_per")+"%"));
			content=content.replace("$FAILPER", (""+report.get("Failure_per")+"%"));
			content=content.replace("$BROWSER", ""+report.get("Browser"));
			content=content.replace("$SETUP", ""+report.get("Setup"));
			content=content.replace("$URL", ""+report.get("URL"));
			content=content.replace("$BUILD", ""+report.get("Build"));
            
			String data = "<table cellspacing='0'><tbody><tr><td style='width: 321px; vertical-align: top; font-family: 'Liberation Serif';font-size: 12pt;'> No failed use case</td></tbody></table>";
			if(result.size() > 0)
			{
				data = "<table cellspacing='0'><tbody><tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: middle; height:26px;'><div style='position: relative; padding: 4px; width: 313px; height:26px; font-weight: bold;font-family: 'Liberation Serif';font-size: 12pt;'>&nbsp;Use Cases</div></td>";
				data += "<td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: middle; height:26px;'><div style='position: relative; padding: 4px; width: 313px; height:22px; font-weight: bold;font-family: 'Liberation Serif';font-size: 12pt;'>&nbsp;Status</div></td></tr>";
				Set<String> keys = result.keySet();
                for(String key: keys){
                    data += "<tr style='height: 40px;'><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:26px;'>  "+key+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:26px;'>  "+result.get(key)+"</div></td></tr>";
                }
				data += "</tbody></table>";
			}
            content = content.replace("$REPORT", data);
            
			String sdata = "<table cellspacing='0'><tbody><tr><td style='width: 321px; vertical-align: top; font-family: 'Liberation Serif';font-size: 12pt;'> No show stopper issues </td></tbody></table>";
			if(showstopper.size() > 0)
			{
				sdata = "<table cellspacing='0'><tbody>";
				Set<String> keys = showstopper.keySet();
				int i = 1;
				for(String key: keys){
					if(i == 1)
					{
						sdata += "<tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+key+"</div></td><td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+showstopper.get(key)+"</div></td></tr>";
					}
					else
					{
						sdata += "<tr><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+key+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+showstopper.get(key)+"</div></td></tr>";
					}
					i++;
				}
				sdata += "</tbody></table>";
                
			}
			content = content.replace("$SHOWSTOPPER", sdata);
            
			String serdatastyle = "display:none;";
			String serdata = "";
			if(servicedown.size() > 0)
			{
				SimpleDateFormat format = new SimpleDateFormat("d MMM yyyy, h:mm:ss a ");
				serdatastyle = "display:block;";
				serdata = "<table cellspacing='0'><tbody>";
				Set<String> keys = servicedown.keySet();
				int i = 1;
				for(String key: keys){
					Date date = new Date(Long.parseLong(""+servicedown.get(key)));
					String value = format.format(date);
					if(i == 1)
					{
						serdata += "<tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+KeyManager.getRealValue(key)+"</div></td><td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+value+"</div></td></tr>";
					}
					else
					{
						serdata += "<tr><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+KeyManager.getRealValue(key)+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+value+"</div></td></tr>";
					}
					i++;
				}
				serdata += "</tbody></table>";
                
			}
			content = content.replace("$SERVICEDOWNSTYLE", serdatastyle);
			content = content.replace("$SERVICEDOWN", serdata);
            
            
			String modules = "";
			if((ConfManager.getModules()).equals("all"))
			{
				ArrayList<String> ignore_list = new ArrayList<String>(Arrays.asList((ConfManager.ignoreModules()).split(",")));
				ArrayList<String> mod = new ArrayList<String>(Arrays.asList((ConfManager.getModuleNames()).split(",")));
				for(int i=0;i<mod.size();i++)
				{
					if(!(ignore_list.contains(""+mod.get(i))))
					{
						modules += mod.get(i)+",";
					}
				}
                
                ArrayList<String> supermod = new ArrayList<String>(Arrays.asList((ConfManager.getSuperModuleNames()).split(",")));
                for(int i=0;i<supermod.size();i++)
				{
					if(!(ignore_list.contains(""+supermod.get(i))))
					{
						modules += supermod.get(i)+",";
					}
				}
                
                ArrayList<String> assomod = new ArrayList<String>(Arrays.asList((ConfManager.getAssoModuleNames()).split(",")));
                for(int i=0;i<assomod.size();i++)
				{
					if(!(ignore_list.contains(""+assomod.get(i))))
					{
						modules += assomod.get(i)+",";
					}
				}
                
                ArrayList<String> crmmod = new ArrayList<String>(Arrays.asList((ConfManager.getCRMModuleNames()).split(",")));
                for(int i=0;i<crmmod.size();i++)
                {
                    if(!(ignore_list.contains(""+crmmod.get(i))))
                    {
                        modules += crmmod.get(i)+",";
                    }
                }
                                
                ArrayList<String> trackingmod = new ArrayList<String>(Arrays.asList((ConfManager.getTrackingModuleNames()).split(",")));
                for(int i=0;i<trackingmod.size();i++)
                {
                    if(!(ignore_list.contains(""+trackingmod.get(i))))
                    {
                        modules += trackingmod.get(i)+",";
                    }
                }
                
			}
			else
			{
                modules = "Admin - Portal Owner : ";
                if(!ConfManager.getModules().equals(""))
                {
                    modules += ConfManager.getModules()+",";
                }
//                if(!ConfManager.getModules2().equals(""))
//                {
//                    modules += ConfManager.getModules2()+",";
//                }
//                if(!ConfManager.getModules3().equals(""))
//                {
//                    modules += ConfManager.getModules3()+",";
//                }
//                if(!ConfManager.getModules4().equals(""))
//                {
//                    modules += ConfManager.getModules4()+",";
//                }
//                if(!ConfManager.getModules5().equals(""))
//                {
//                    modules += ConfManager.getModules5()+",";
//                }
//                modules += ConfManager.getModules6();
                modules += "<div><span>&nbsp;</span></div>";
                modules += "Supervisor : "+ConfManager.getSuperModules()+"<div><span>&nbsp;</span></div>";
                modules += "Associate : "+ConfManager.getAssoModules()+"<div><span>&nbsp;</span></div>";

            }
            
			char comma = ",".charAt(0);
			if(comma == modules.charAt(modules.length()-1))
			{
				modules = modules.substring(0,modules.length()-1);
			}
			modules = modules.replaceAll(",", ", ");
			String modulestestedstyle = "display:none;";
            
			if(!(modules.equals("")))
			{
				modulestestedstyle = "display:block;";
			}
			content = content.replace("$MODULESTESTEDSTYLE", modulestestedstyle);
			content = content.replace("$MODULESTESTED", modules);
            
            String bLabel = (String) report.get("Build");
            
            fileret = writeToFile(content,bLabel);
            
            return fileret;
		}
		catch(Exception e)
		{
			System.out.println("Error in get data");
		}
        return fileret;
	}
	
    private static String filePath()
    {
        URL location = FileUtil.class.getProtectionDomain().getCodeSource().getLocation();
        System.out.println(location.getFile());
        String fileloc = location.getFile();
        fileloc = fileloc.replaceAll("/lib/livedesk-webdriver.jar","/webapps/selenium/reports/");
        return fileloc;
    }
    
    public static String writeToFile(String content,String bLabel)
    {
        String filelocpath = "";
        try
        {
            filelocpath = filePath();
            
            // System.out.println("File Writing !!!"+filelocpath);
            
            String fileName = "/results.html";
            
            if(bLabel==null||bLabel=="")
            {
                bLabel = "UnknownLabel";
            }
            
            if(bLabel.contains("/"))
            {
                bLabel = bLabel.replaceAll("/","_");
            }
            
            final String dir = System.getProperty("user.dir");
            
            // System.out.println("current dir = " + dir);
            
            File file = new File(filelocpath+bLabel);
            
            // System.out.println("File Writing - "+filelocpath+bLabel);
            
            int fnum = 0;
            
            if(file.mkdir())
            {
                while(file.exists())
                {
                    fileName = "/results"+fnum+".html";
                    file = new File(filelocpath+bLabel+fileName);
                    // System.out.println("File Writing in name - "+filelocpath+bLabel+fileName);
                    if (!file.exists()) {
                        file.createNewFile();
                        break;
                    }
                    fnum++;
                }
            }
            else
            {
                while(file.exists())
                {
                    fileName = "/results"+fnum+".html";
                    file = new File(filelocpath+bLabel+fileName);
                    // System.out.println("File Writing in name - "+filelocpath+bLabel+fileName);
                    if (!file.exists()) {
                        file.createNewFile();
                        break;
                    }
                    fnum++;
                }
            }
            
            // System.out.println(bLabel);
            // if file doesnt exists, then create it
            /*if (!file.exists()) {
                file.createNewFile();
            }
             */
            
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(content);
            bw.close();
            
            // System.out.println("File Writing Successful - Done !!!");
            
            String retfile = null;
            
            return "http://"+Util.serverHostName+":"+Util.serverPortNumber+"/reports/"+bLabel+fileName;
        }
        catch(Exception e)
        {
            System.out.println("Exception while writing to file : "+e);
        }
        return filelocpath;
    }
    
    private static String getMailString(String path) throws Exception
	{
        BufferedReader reader = null;
        try
        {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(path),"UTF-8"));
            String line = null;
            StringBuffer st = new StringBuffer();
            while((line = reader.readLine())!=null)
            {
                st.append(line);
                st.append("\r\n");//No i18N
            }
            return st.toString();
        }
        finally
        {
            try{if(reader!=null){reader.close();}}catch(Exception e){System.out.println("Unable to close the reader");}
        }
	}
}
