//$Id$
package com.zoho.livedesk.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.concurrent.TimeUnit;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.CommonUtil;

public class ServerTunnel
{
    public static 
    String
    scriptpath="/webapps/selenium/shell_scripts/",
    script_name="start_ngrok.sh",
    stop_script_name="stop_ngrok.sh"
    ;

    public static String getTunnelURL()
    {
        return ConfManager.getRealValue("ngrok_tunnel_url");
    }

    public static boolean isTunnelOpen()
    {
        try
        {
            String current_tunnel_url=getTunnelURL()+"/webhookauth";
            return SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(current_tunnel_url);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }

        return false;
    }

    public static void startTunnel()
    {
        startTunnel(true);
    }

    public static void startTunnel(boolean isForceStart)
    {
        if(isTunnelOpen() && !isForceStart)
        {
            return;
        }

        if(isForceStart)
        {
            stopTunnel();
        }

        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.directory(new File(getScriptDirectory()));
        processBuilder.command(getScriptFilePath());

        try
        {
            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
                            
            while ((line = reader.readLine()) != null) 
            {
                output.append(line + "\n");

                if(line.contains("<shell-eof>"))
                {
                    break;
                }
            }

            process.waitFor(5,TimeUnit.SECONDS);

            Util.print("Success!");
            Util.print(output.toString());
        }
        catch (IOException e) 
        {
            CommonUtil.printStackTrace(e);
        }
        catch (InterruptedException e) 
        {
            CommonUtil.printStackTrace(e);
        }

        Util.print("Tunnel Started");
    }

    public static void stopTunnel()
    {
        // if(!isTunnelOpen())
        // {
        //     return;
        // }

        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.directory(new File(getScriptDirectory()));
        processBuilder.command(getStopScriptFilePath());

        try
        {
            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) 
            {
                output.append(line + "\n");
            }

            process.waitFor(5,TimeUnit.SECONDS);

            Util.print("Success!");
            Util.print(output.toString());
        }
        catch (IOException e) 
        {
            CommonUtil.printStackTrace(e);
        }
        catch (InterruptedException e) 
        {
            CommonUtil.printStackTrace(e);
        }
    }
    public static String getScriptDirectory()
    {
        return FileUpload.getBuildRoot()+scriptpath;
    }

    public static String getScriptFilePath()
    {
        return getScriptDirectory()+script_name;
    }

    public static String getStopScriptFilePath()
    {
        return getScriptDirectory()+stop_script_name;
    }
}
