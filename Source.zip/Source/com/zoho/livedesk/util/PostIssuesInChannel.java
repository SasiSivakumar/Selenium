//$Id$
package com.zoho.livedesk.util;

import java.util.Hashtable;
import java.util.Set;
import java.util.LinkedHashMap;

public class PostIssuesInChannel {

	public static void postMessage() throws Exception
	{		
		LinkedHashMap<String, String[]> sometimes_issues = new LinkedHashMap<String, String[]>();
		LinkedHashMap<String, String[]> always_issues = new LinkedHashMap<String, String[]>();
		
		sometimes_issues.put("4127",new String[]{"[Slow response in some request urls](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-4127)","15-06-2017","Rajasekar Ramasamy"});
		// sometimes_issues.put("6125",new String[]{"[Chat history -- Agent image not found in RHS](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6125)","12-12-2018"});

		always_issues.put("5636",new String[]{"[UI breakage while adding Campaign mailing list in Triggers](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-5636)","25-07-2018","Manojpandi Sundharapandi"});
		always_issues.put("5638",new String[]{"[characters left count is not updating in Articles](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-5638)","26-07-2018","Harish Narayanan S"});
		always_issues.put("5978",new String[]{"[Chat monitor by IP is not working in local](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-5978)","08-11-2018","Not Assigned"});
		always_issues.put("5981",new String[]{"[Values are getting hidden in dropdown](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-5981)","08-11-2018","Manojpandi Sundharapandi"});
		always_issues.put("5688",new String[]{"[Broken image in new portal creation page](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-5688)","09-08-2018","Not Assigned"});
		always_issues.put("6007",new String[]{"[Signature chat | when upload high dimension images need to compress to default size](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6007)","14-11-2018","Raja BK"});
		always_issues.put("6044",new String[]{"[In Internal chat - Chat history messages are not updating](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6044)","22-11-2018","Karthik R"});
		// always_issues.put("6045",new String[]{"[Zoho.salesiq.chat.title JSPAI is not working](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6045)","22-11-2018"});
		// always_issues.put("6062",new String[]{"[Tracking rings - Tooltip issue in info banner](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6062)","29-11-2018"});
		// always_issues.put("6081",new String[]{"[Signature live chat - Show preview icon breakage in bigger window](_______________)","05-12-2018"});
		always_issues.put("6084",new String[]{"[Zendesk & zohodesk integration issue](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6084)","06-12-2018","Not Assigned"});
		// always_issues.put("6087",new String[]{"[JSAPI | Offline message is not working ](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6087)","06-12-2018"});
		always_issues.put("6088",new String[]{"[Customize rings by rule -- Custom Action is not working](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6088)","06-12-2018","Gokulakannan G"});
		always_issues.put("6107",new String[]{"[Phone field in not showing in Old embeds](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6107)","10-12-2018","Gomathi M"});
		always_issues.put("6135",new String[]{"[Filter by integration status not working in some portals](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6135)","14-12-2018","Baskar Karunanithi"});
		always_issues.put("6136",new String[]{"[Custom image upload widget issue](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6136)","14-12-2018","Gomathi M"});
		// always_issues.put("6219",new String[]{"[Response message editor is closing without any action](_______________)","21-01-2019"});
		always_issues.put("6245",new String[]{"[Department not associate while delete operator](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6245)","29-01-2019","Karthik R"});
		// always_issues.put("6338",new String[]{"[Email copier issue in portal settings](_______________)","02-12-2019"});
		// always_issues.put("6339",new String[]{"[Newsletter Subscription checkbox content is not updating](_______________)","02-12-2019"});
		always_issues.put("6349",new String[]{"[CRMPLUS - Timer was displayed for Proactive Initiated Chat](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6349)","13-02-2019","Karthik R"});
		// always_issues.put("6370",new String[]{"[zoho.com not working in local for email configuration](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6370)","18-02-2019"});
		// always_issues.put("6385",new String[]{"[Tracking - Check with Visitor Source - Adwords](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6385)","20-02-2019"});
		// always_issues.put("6521",new String[]{"[Mail not sent to emails configured in portal settings in local setup](_______________)","14-03-2019"});
		always_issues.put("6568",new String[]{"[Rating was not found after toggling but not updating](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6568)","21-03-2019","Raja BK"});
		always_issues.put("6604",new String[]{"[Editor is not working as expected in Email templates editor](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6604)","04-04-2019","Manojpandi Sundharapandi"});
		always_issues.put("6645",new String[]{"[WMS chat bar - Unable to open operator chats](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6645)","22-04-2019","Rajasekar Ramasamy"});
		always_issues.put("6700",new String[]{"[Getting opposite boolean for check box](https://projects.zoho.com/portal/zohochatteam#buginfo/218335000000050003/218335000010488417)","08-05-2019","Manojpandi Sundharapandi"});
		always_issues.put("6716",new String[]{"[Unable to create new list in mailchimp through trigger](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6716)","17-05-2019","Rajasekar Ramasamy"});
		always_issues.put("6730",new String[]{"[Server error shown when exporting chat history and it takes too long to export](https://projects.zoho.com/portal/zohochatteam#searchresult/218335000000050003/issue/ZLS-6730)","21-05-2019","Kannan K S"});
		always_issues.put("6876",new String[]{"[Unread notification shown even when there are no unread messages #Bots]](https://projects.zoho.com/portal/zohochatteam#buginfo/218335000000050003/218335000011055517)","19-07-2019","Manojpandi Sundharapandi"});

		// always_issues.put("<issue_id>",new String[]{" [<issue_description>](<issue_link>)","<issue_posted on>"});
		
		Set<String> always_issue_ids = always_issues.keySet();		
		String always_issues_list_rows = "";
		for(String issue_id  : always_issue_ids)
		{
			String description = always_issues.get(issue_id)[0];
			String date = always_issues.get(issue_id)[1];
			String owner = always_issues.get(issue_id)[2];
			
			String row = "{\"Issue Id\":\"$ID\",\"Description\":\"$DESC\",\"Reported date\":\"$REPORTEDDATE\",\"Owner\":\"$OWNER\"}";
			
			row = row.replace("$ID",issue_id);
			row = row.replace("$DESC", description);
			row = row.replace("$REPORTEDDATE", date);
			row = row.replace("$OWNER", owner);
			
			if(!always_issues_list_rows.equals(""))
			{
				always_issues_list_rows += ",";
			}
			
			always_issues_list_rows += row;
		}

		Set<String> sometimes_issue_ids = sometimes_issues.keySet();		
		String sometimes_issues_list_rows = "";
		for(String issue_id  : sometimes_issue_ids)
		{
			String description = sometimes_issues.get(issue_id)[0];
			String date = sometimes_issues.get(issue_id)[1];
			String owner = sometimes_issues.get(issue_id)[2];
			
			String row = "{\"Issue Id\":\"$ID\",\"Description\":\"$DESC\",\"Reported date\":\"$REPORTEDDATE\",\"Owner\":\"$OWNER\"}";
			
			row = row.replace("$ID",issue_id);
			row = row.replace("$DESC", description);
			row = row.replace("$REPORTEDDATE", date);
			row = row.replace("$OWNER", owner);
			
			if(!sometimes_issues_list_rows.equals(""))
			{
				sometimes_issues_list_rows += ",";
			}
			
			sometimes_issues_list_rows += row;
		}

		String table1="{\"type\":\"table\",\"title\":\"Always reproduced in automation\",\"data\":{\"headers\":[ \"Issue Id\",\"Description\",\"Reported date\",\"Owner\"],\"rows\":["
		        + always_issues_list_rows
		        + "]"
		        + "}"
		        + "}";

		String table2="{\"type\":\"table\",\"title\":\"Sometimes reproduced in automation\",\"data\":{\"headers\":[ \"Issue Id\",\"Description\",\"Reported date\",\"Owner\"],\"rows\":["
		        + sometimes_issues_list_rows
		        + "]"
		        + "}"
		        + "}";

		 String table3="{\"type\":\"list\",\"title\":\"Other issues\",\"data\":["
//		        + "Busy response message and Thank you(after ending the chat) in new embed theme is flashing fast and hence sometimes in Automation it is not able to capture it"
		        + "Cookie not found in visitor window even chat widget is loaded"
		        + ",Sometimes visitors are not tracked in rings"
		        + ",Character limit in various inputs is not updated in realtime"
		        + ",Sometimes join button is not shown in connected tab for monitored chats"
		        + ",Download urls in rest api responses are not working"
		        + ",For integrations with other services sometimes data is updated slowly"
		        + ",Live typing status is updated wrongly or very slowly"
		        + ",Mail not sent to emails configured in portal settings in local setup"
		        + ",After visitor left the browser session they are still visible in rings even after 1 minute"
		        + "]}";       
		        
		
		 String  content = "{\"text\":\" *Long pending open issues which are causing more failures in automation* \""
		        +",\"slides\" : ["+table1+","+table2+","+table3+"]"
		        +","
		        +"\"bot\":"
		        +"{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"},\"card\":{\"theme\":\"1\"}}";
		        		
		        System.out.println(content.length());
				ChatUtil.sendResultAsChatMessage(content);
	}
}
