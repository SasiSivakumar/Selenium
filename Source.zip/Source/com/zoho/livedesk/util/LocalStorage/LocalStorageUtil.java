//$Id$
package com.zoho.livedesk.util.LocalStorage;

import java.io.FileInputStream;
import java.util.Properties;
import com.zoho.livedesk.server.PropertyFileParser;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class LocalStorageUtil 
{
    public static PropertyFileParser local_storage=new PropertyFileParser("localstorage.properties");

    public static void set(String key,String value,String comment)
    {
        try
        {
            local_storage.set(key,value,comment);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static boolean isStored(String key)
    {
        return get(key).equals(key) == false ;
    }

    public static boolean isBoolean(String key)
    {
        if(isStored(key) && (get(key).equals("true") || get(key).equals("false")))
        {
            return true;
        }

        return false;
    }

    public static void set(String key,String value)
    {
        set(key,value,"Local Storage");
    }

    public static String get(String key)
    {
        return local_storage.getRealValue(key);
    }
}
