//$Id$
package com.zoho.livedesk.util;

import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;


public class CleanupMailchimp
{
	public static void clean()
	{
		WebDriver driver = null;
		ExtentTest etest = null;
		try
		{
			etest = ComplexReportFactory.getTest("Mailchimp list cleanup");
			ComplexReportFactory.setValues(etest,"Cleanup","Cleanup");

			driver = Driver.getCleanupDriver();
			Functions.loginMailChimp(driver);
			driver.get("https://us14.admin.mailchimp.com/lists/");
			CommonUtil.clickWebElement(driver,By.id("dojox_form_TriStateCheckBox_0"));

			List<WebElement> mailchimpList = CommonUtil.getElement(driver,By.id("lists")).findElements(By.tagName("li"));

			if(mailchimpList.size() > 2)
			{
				for(WebElement list : mailchimpList)
				{
					if(list.getText().contains("test1") || list.getText().contains("test2"))
					{
						CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(list,By.tagName("input"),"type","checkbox"));
					}
				}
				CommonUtil.clickWebElement(driver,By.id("delete-btn"));

				CommonUtil.sleep(2000);

				if(driver.findElement(By.id("dijit_Dialog_0")).isDisplayed())
				{
					driver.findElement(By.id("dijit__Templated_2-confirm-text")).click();
					driver.findElement(By.id("dijit__Templated_2-confirm-text")).sendKeys("DELETE");
					driver.findElement(By.id("dijit_Dialog_0")).findElement(By.className("dijitDialogPaneActionBar")).findElement(By.id("dijit_form_Button_1_label")).click();
				}

				etest.log(Status.INFO,"List has been cleared");
				TakeScreenshot.infoScreenshot(driver,etest);
			}

			driver.get("https://login.mailchimp.com/?logout=1");
			etest.log(Status.PASS,"SUCCESS");
		}
		catch(Exception e)
		{
			etest.log(Status.WARNING,"Cleanup Mailchimp manually");
			if(driver != null)
			{
				TakeScreenshot.infoScreenshot(driver,etest);
			}
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
		}
	}
}