//$Id$

package com.zoho.livedesk.util.BuildUpdateScheduler;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.zoho.livedesk.util.BuildUpdateScheduler.SchedulerMain;
import com.zoho.livedesk.util.BuildUpdateScheduler.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.TimerTask;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.JSONException;
import org.json.XML;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.server.ConfManager;

public class BuildupdIdcProduction extends TimerTask
{

    public void run()
    {
        try
        {
            if (!SchedulerMain.getruntimebuild("us4_pre_production").equals(SchedulerMain.get_idclabel()))
            {
                SchedulerMain.resetIDC();
                StopBuildUpdate.set_stop_idc_update(false);
                SchedulerMain.postToCliq("Not updating as different builds are there now");
                return;
            }
        }
        catch (Exception e)
        {
            CommonUtil.printStackTrace(e);
            SchedulerMain.resetIDC();
            StopBuildUpdate.set_stop_idc_update(false);
            SchedulerMain.postToCliq("Not updating due to exception occured when comparing build");
            return;
        }

        try
        {
            HttpURLConnection httpcon = null;
            String update_url = SchedulerMain.DOMAIN + "/api/startupgrade?authtoken=" + SchedulerMain.AUTHTOKEN + "&product=" + SchedulerMain.PRODUCT + "&bType=us4_pre_main";
            URL url = new URL(update_url);
            httpcon = (HttpURLConnection)(url.openConnection());
            httpcon.setRequestMethod("GET");
            httpcon.setConnectTimeout(1200000); //20minutes for build update
            Thread.sleep(300000); //5minutes for zac update

            SchedulerMain.postToCliq("IDC update API was called");
            SchedulerMain.resetIDC();
            StopBuildUpdate.set_stop_idc_update(false);
        }
        catch (Exception e)
        {
            CommonUtil.printStackTrace(e);
            SchedulerMain.resetIDC();
            StopBuildUpdate.set_stop_idc_update(false);
        }

    }

}