//$Id$
package com.zoho.livedesk.util.BuildUpdateScheduler;

import com.beust.testng.TestNG;

import com.zoho.qa.server.CommondMethods;

import com.zoho.qa.server.TestNGreportGen;
import com.zoho.qa.server.WebdriverApiHub;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.WebdriverTestContainer;

import com.zoho.qa.server.WebdriverTestServer;
import com.zoho.qa.server.WebdriverTestsuite;
import com.zoho.qa.server.WebdriverTestsuiteProvider;
//import com.zoho.writer.TestSuite;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;

import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;

import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import org.testng.ITestNGListener;

import org.testng.TestListenerAdapter;
import org.testng.xml.XmlClass;

import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.zoho.livedesk.util.LocalStorage.LocalStorageUtil;

public class StopBuildUpdate
{
    public static void set_stop_pre_update(boolean value)
    {
        if(value==true)
        {
            SchedulerMain.resetPre();
            SchedulerMain.stopPreTimer();
        }

        LocalStorageUtil.set("stop_pre_update",value+"");
    }
    public static void set_stop_I18N_update(boolean value)
    {
        if(value==true)
        {
            SchedulerMain.resetI18N();
            SchedulerMain.stopI18NTimer();
        }

        LocalStorageUtil.set("stop_I18N_update",value+"");
    }
    public static void set_stop_idc_update(boolean value)
    {
        if(value==true)
        {
            SchedulerMain.resetIDC();
            SchedulerMain.stopIDCTimer();
        }

        LocalStorageUtil.set("stop_idc_update",value+"");
    }

    public static boolean get_stop_pre_update()
    {
        if(LocalStorageUtil.isBoolean("stop_pre_update"))
        {
            return Boolean.parseBoolean(LocalStorageUtil.get("stop_pre_update"));
        }

        return false;
    }
    public static boolean get_stop_I18N_update()
    {
        if(LocalStorageUtil.isBoolean("stop_I18N_update"))
        {
            return Boolean.parseBoolean(LocalStorageUtil.get("stop_I18N_update"));
        }

        return false;
    }
    public static boolean get_stop_idc_update()
    {
        if(LocalStorageUtil.isBoolean("stop_idc_update"))
        {
            return Boolean.parseBoolean(LocalStorageUtil.get("stop_idc_update"));
        }

        return false;
    }

}
