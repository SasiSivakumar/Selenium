//$Id$
package com.zoho.livedesk.util.BuildUpdateScheduler;

import java.util.Calendar;
import java.util.Timer;
import java.util.concurrent.TimeUnit;
import com.zoho.livedesk.util.BuildUpdateScheduler.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import com.zoho.livedesk.util.LocalStorage.LocalStorageUtil;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.Performance.LogsAnalyser;

public class SchedulerMain
{
    // public static final String
    // DOMAIN = "https://sd.csez.zohocorpin.com",
    // AUTHTOKEN = "8514d56742ab433bfd275f7c00a824d0bef3",
    // PRODUCT = "ZOHOLIVESUPPORT";
    // ;

    public static final String
    DOMAIN = "https://kabilan-5523",
    AUTHTOKEN = "abcd1234",
    PRODUCT = "KABILAN";
    ;

    public static void resetAllScheduler()
    {
        resetPre();
        resetI18N();
        resetIDC();
        StopBuildUpdate.set_stop_pre_update(false);
        StopBuildUpdate.set_stop_I18N_update(false);
        StopBuildUpdate.set_stop_idc_update(false);
    }

    public static void startAllSchedulers()
    {
        try
        {
            schedulePreUpdate();
            scheduleI18NUpdate();
            scheduleIDCUpdate();

            schedulePerformanceLogsAnalyser();
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
    }

    public static void resetPre()
    {
        set_isPreBuildUpdateFinished(false);
        set_build_preupd_time("");
        set_prelabel("");
    }

    public static void resetI18N()
    {
        set_isI18NBuildUpdateFinished(false);
        set_build_I18Nupd_time("");
        set_I18Nlabel("");
    }

    public static void resetIDC()
    {
        set_isIDCBuildUpdateFinished(false);
        set_build_idcupd_time("");
        set_idclabel("");
    }

    public static Timer
    pre_update_timer=null,
    I18N_update_timer=null,
    idc_update_timer=null;

    public static void stopPreTimer()
    {
        if(pre_update_timer!=null)
        {
            pre_update_timer.cancel();
        }
    }
    public static void stopI18NTimer()
    {
        if(I18N_update_timer!=null)
        {
            I18N_update_timer.cancel();
        }
    }
    public static void stopIDCTimer()
    {
        if(idc_update_timer!=null)
        {
            idc_update_timer.cancel();
        }
    }

    public static void schedulePreUpdate() throws Exception
    {
        if(get_build_preupd_time().equals("")==false)
        {
            schedulePreUpdate(get_build_preupd_time(),get_prelabel()); 
        }
    }
    public static void schedulePreUpdate(String upd_time, String label) throws Exception
    {
        try
        {
            DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = dateFormatter .parse(upd_time);
  
            set_build_preupd_time(upd_time);
            set_prelabel(label);
            set_isPreBuildUpdateFinished(true);

            pre_update_timer=new Timer();
            pre_update_timer.schedule(new BuildupdPreProduction(), date);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            resetPre();
            StopBuildUpdate.set_stop_pre_update(false);
        }
    }

    public static void scheduleI18NUpdate() throws Exception
    {
        if(get_build_I18Nupd_time().equals("")==false)
        {
            scheduleI18NUpdate(get_build_I18Nupd_time(),get_I18Nlabel()); 
        }
    }
    public static void scheduleI18NUpdate(String upd_time, String label) throws Exception
    {
        try
        {
            DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = dateFormatter .parse(upd_time);
  
            set_build_I18Nupd_time(upd_time);
            set_I18Nlabel(label);
            set_isI18NBuildUpdateFinished(true);

            I18N_update_timer=new Timer();
            I18N_update_timer.schedule(new BuildupdI18NProduction(), date);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            resetI18N();
            StopBuildUpdate.set_stop_I18N_update(false);
        }
    }


    public static void scheduleIDCUpdate() throws Exception
    {
        if(get_build_idcupd_time().equals("")==false)
        {
            scheduleIDCUpdate(get_build_idcupd_time(),get_idclabel()); 
        }
    }
    public static void scheduleIDCUpdate(String upd_time, String label) throws Exception
    {
        try
        {
            DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = dateFormatter .parse(upd_time);
  
            set_build_idcupd_time(upd_time);
            set_idclabel(label);
            set_isIDCBuildUpdateFinished(true);

            idc_update_timer=new Timer();
            idc_update_timer.schedule(new BuildupdIdcProduction(), date);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            resetIDC();
            StopBuildUpdate.set_stop_idc_update(false);
        }
    }

    public static String getruntimebuild(String setup) throws Exception
    {
        String url = DOMAIN + "/rest/getLatestDeployedBuild?product=" + PRODUCT + "&bType=" + setup + "&authtoken=" + AUTHTOKEN;
        String build = null;

        URL urlConn = new URL(url);

        HttpURLConnection httpcon = null;

        httpcon = (HttpURLConnection) (urlConn.openConnection());
        httpcon.setRequestMethod("GET");

        InputStream in = httpcon.getInputStream();
        String encoding = httpcon.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);

        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(body);

        JSONArray list = (JSONArray)json.get("info");

        JSONObject e = (JSONObject) list.get(0);

        build = e.get("CurrentUrl").toString();
        return build;
    }

    public static void set_prelabel(String value)
    {
        LocalStorageUtil.set("prelabel", value);
    }
    public static void set_I18Nlabel(String value)
    {
        LocalStorageUtil.set("I18Nlabel", value);
    }
    public static void set_idclabel(String value)
    {
        LocalStorageUtil.set("idclabel", value);
    }
    public static String get_prelabel()
    {
        if(LocalStorageUtil.isStored("prelabel"))
        {
            return LocalStorageUtil.get("prelabel");
        }

        return "";
    }
    public static String get_I18Nlabel()
    {
        if(LocalStorageUtil.isStored("I18Nlabel"))
        {
            return LocalStorageUtil.get("I18Nlabel");
        }

        return "";
    }
    public static String get_idclabel()
    {
        if(LocalStorageUtil.isStored("idclabel"))
        {
            return LocalStorageUtil.get("idclabel");
        }

        return "";
    }

    public static void set_build_preupd_time(String value)
    {
        LocalStorageUtil.set("build_preupd_time", value);
    }
    public static void set_build_I18Nupd_time(String value)
    {
        LocalStorageUtil.set("build_I18Nupd_time", value);
    }
    public static void set_build_idcupd_time(String value)
    {
        LocalStorageUtil.set("build_idcupd_time", value);
    }
    public static String get_build_preupd_time()
    {
        if(LocalStorageUtil.isStored("build_preupd_time"))
        {
            return LocalStorageUtil.get("build_preupd_time");
        }

        return "";
    }
    public static String get_build_I18Nupd_time()
    {
        if(LocalStorageUtil.isStored("build_I18Nupd_time"))
        {
            return LocalStorageUtil.get("build_I18Nupd_time");
        }

        return "";
    }
    public static String get_build_idcupd_time()
    {
        if(LocalStorageUtil.isStored("build_idcupd_time"))
        {
            return LocalStorageUtil.get("build_idcupd_time");
        }

        return "";
    }

    public static void set_isPreBuildUpdateFinished(boolean value)
    {
        //is pre build update scheduled
        LocalStorageUtil.set("isPreBuildUpdateFinished", value + "");
    }
    public static void set_isI18NBuildUpdateFinished(boolean value)
    {
        //is i18n build update scheduled
        LocalStorageUtil.set("isI18NBuildUpdateFinished", value + "");
    }
    public static void set_isIDCBuildUpdateFinished(boolean value)
    {
        //is idc build update scheduled
        LocalStorageUtil.set("isPreBuildUpdateFinished", value + "");
    }

    public static boolean get_isPreBuildUpdateFinished()
    {
        if(LocalStorageUtil.isBoolean("isPreBuildUpdateFinished"))
        {
            return Boolean.parseBoolean(LocalStorageUtil.get("isPreBuildUpdateFinished"));
        }

        return false;
    }
    public static boolean get_isI18NBuildUpdateFinished()
    {
        if(LocalStorageUtil.isBoolean("isI18NBuildUpdateFinished"))
        {
            return Boolean.parseBoolean(LocalStorageUtil.get("isI18NBuildUpdateFinished"));
        }

        return false;
    }
    public static boolean get_isIDCBuildUpdateFinished()
    {
        if(LocalStorageUtil.isBoolean("isIDCBuildUpdateFinished"))
        {
            return Boolean.parseBoolean(LocalStorageUtil.get("isIDCBuildUpdateFinished"));
        }

        return false;
    }

    public static void postToCliq(String message)
    {
        com.zoho.livedesk.util.ChatUtil.postToCliq(message,"Build Tool",ConfManager.getRealValue("automation_dev_channel"),ConfManager.getRealValue("authToken"),false);
    }

    public static void schedulePerformanceLogsAnalyser() throws Exception
    {
        try
        {
            Calendar today = Calendar.getInstance();

            //1 PM everyday
            today.set(Calendar.HOUR_OF_DAY, 13);
            today.set(Calendar.MINUTE, 0);
            today.set(Calendar.SECOND, 0);

            Date firstTime = today.getTime();

            if(firstTime.before(new Date()))
            {
                today.add(Calendar.DATE, 1);
                firstTime = today.getTime();
            }
            
            Timer timer = new Timer();
            timer.schedule(new LogsAnalyser(), firstTime, TimeUnit.MILLISECONDS.convert(1, TimeUnit.DAYS)); // period: 1 day
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
    }
}
