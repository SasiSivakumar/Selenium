//$Id$
package com.zoho.livedesk.util;

import java.io.FileInputStream;
import java.util.Properties;
import com.zoho.livedesk.server.PropertyFileParser;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.ServerTunnel;
import com.zoho.livedesk.util.common.CommonUtil;

public class ServerInit extends HttpServlet
{
	public static boolean isInitAlready=false;

    public void init() throws ServletException
    {
        if(isInitAlready)
        {
            return;
        }
        
        isInitAlready=true;

        Util.print("---------- ServerInit Initialized process started successfully ----------");
                
        com.zoho.livedesk.util.BuildUpdateScheduler.SchedulerMain.startAllSchedulers();

        Util.print("---------- ServerInit Initialized process ended successfully ----------");
    }
}
