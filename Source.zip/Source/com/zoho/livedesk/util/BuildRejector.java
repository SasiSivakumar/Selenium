//$Id$
package com.zoho.livedesk.util;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import com.zoho.livedesk.util.BuildRejector;

public class BuildRejector
{
    public static ArrayList<String> showstopper_list;

    public static void init()
    {
    	showstopper_list=new ArrayList<String>();
    }
    
    public static boolean isBuildApproved()
    {
    	if(showstopper_list.size()>0)
    	{
    		return false;
    	}

    	return true;
    }

    public static void rejectBuildDueTo(String reason)
    {
    	showstopper_list.add(reason);
    }

    public static void analyse(Hashtable<String,Boolean> result,String reason)
    {
		Set<String> keys = result.keySet();
		for(String key: keys)
		{
			if(result.get(key)==false)
			{
				rejectBuildDueTo(reason);
				return;
			}
		}
    }

    public static void postToChat()
    {
    	if(!isBuildApproved())
    	{
    		ChatUtil.postToCliq(getMessage());
    	}
    }

    private static String getMessage()
    {
    	String content="Build contains the following critical issues. Avoid moving build to IDC without investigating the issues listed below.\\n";

    	for(String issue : showstopper_list)
    	{
    		content=content+"\\n-->"+issue;
    	}

    	return content;
    }
}
