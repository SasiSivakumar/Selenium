//$Id$
package com.zoho.livedesk.util.exceptions;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.server.GridConfigManager;
import com.zoho.livedesk.util.SeleniumGridUtil;
import org.openqa.selenium.Cookie;


public class Debugger
{
	public static final By
	ERROR_CONTAINER=By.className("errorContainer");

	public static Hashtable getPortalState(WebDriver driver)
	{
		Hashtable<String,String> portal_state=new Hashtable<String,String>();

		try
		{
			//Machine info

			String host=SeleniumGridUtil.getHostName(driver);
			String user=null;

			try
			{
				user=GridConfigManager.getUserName(host);
			}
			catch(Exception e1)
			{
				user=host;
			}

			portal_state.put("Machine",user);
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Current Agent",ExecuteStatements.getUserName(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Current Agent Mail",ExecuteStatements.getUserMail(driver));
		}
		catch(Exception e)
		{
			
		}

		try
		{
			portal_state.put("Agent Status",com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver).toString());
		}
		catch(Exception e)
		{
			
		}

		try
		{
			portal_state.put("Current Agent Role",getUserRole(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Current Portal",ExecuteStatements.getPortal(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Current User ZUID",ExecuteStatements.getZUID(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Portal Owner ZUID",ExecuteStatements.getPortalOwnerZUID(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Current Portal SOID",ExecuteStatements.getSOID(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("Current User WMSID",ExecuteStatements.getWMSID(driver));
		}
		catch(Exception e)
		{

		}

		try
		{
			portal_state.put("is portal under free plan",ExecuteStatements.isFreePlan(driver)+"");
		}
		catch(Exception e)
		{
			
		}

		try
		{
			portal_state.put("Portal Agents",Arrays.toString(ExecuteStatements.getAllAgentNames(driver)));
		}
		catch(Exception e)
		{
			
		}

		try
		{
			portal_state.put("Cookie-->_iamadt",getCookieValue(driver,"_iamadt").toString());
		}
		catch(Exception e)
		{
			
		}

		try
		{
			portal_state.put("Cookie-->_iambdt",getCookieValue(driver,"_iambdt").toString());
		}
		catch(Exception e)
		{
			
		}		

		return portal_state;
	}

	public static Hashtable getVisitorSiteState(WebDriver driver)
	{
		Hashtable<String,String> visitor_site_state=new Hashtable<String,String>();

		try
		{
			visitor_site_state.put("Widget Code",ExecuteStatements.getWidgetCodeFromVisitorSite(driver));
		}
		catch(Exception e)
		{

		}

		return visitor_site_state;
	}

	public static Hashtable getSiteState(WebDriver driver)
	{
		if(isSalesIQPage(driver))
		{
			return getPortalState(driver);
		}

		if(isVisitorSite(driver))
		{
			return getVisitorSiteState(driver);
		}

		return null;
	}


	public static String getUserRole(WebDriver driver)
	{
		try
		{
			if(ExecuteStatements.isOwner(driver))
			{
				return "Owner";
			}

			if(ExecuteStatements.isAdministrator(driver))
			{
				return "Admin";
			}

			if(ExecuteStatements.isSupervisor(driver))
			{
				return "Supervisor";
			}

			if(ExecuteStatements.isAssociate(driver))
			{
				return "Associate";
			}
		}
		catch(Exception e)
		{

		}

		return "Unknown";
	}

	public static void logAccountState(WebDriver driver,ExtentTest etest)
	{
		logAccountState(driver,etest,Status.FAIL);
	}

	public static void logAccountState(WebDriver driver,ExtentTest etest,Status log_status)
	{
		try
		{
			if(driver.getCurrentUrl().contains("salesiq.") && driver.getCurrentUrl().contains("zoho.com"))
			{
		        String portal_state_html=TakeScreenshot.getCustomHTMLForReport("<b style='color:#8E44AD'>Click here to view the site state during automation</b>",getSiteStateAsHTML(driver));
		        etest.log(log_status,portal_state_html);			
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static boolean isSalesIQPage(WebDriver driver)
	{
		String page_url=driver.getCurrentUrl();	
		
		page_url=page_url.replaceAll("http.+//", "");		
		String domain=page_url.split("/")[0];
		String url=page_url.replace(domain, "");

		if(domain.contains("salesiq.") && domain.contains("zoho.com") && page_url.contains("://accounts.")==false && url.contains("/deluge/")==false && url.contains("/apps/")==false && url.contains("/drawchat.ls")==false && url.contains("/portal.do")==false && CommonWait.isPresent(driver,ERROR_CONTAINER)==false)
		{
			return true;
		}

		return false;
	}

	public static boolean isVisitorSite(WebDriver driver)
	{
		try
		{
			ExecuteStatements.getWidgetCodeFromVisitorSite(driver);
			return true;
		}
		catch(Exception e)
		{

		}

		return false;
	}

	public static boolean isSiteStateLoggable(WebDriver driver)
	{
		if(SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
		{
			//no need to log in this case
			return false;
		}

		return (isSalesIQPage(driver) || isVisitorSite(driver));
	}

	public static String getSiteStateAsHTML(WebDriver driver)
	{
		String portal_state_as_html="";

		Hashtable<String,String> portal_state=getSiteState(driver);

        Set<String> portal_state_keys = portal_state.keySet();
        for(String portal_state_key : portal_state_keys)
        {
        	portal_state_as_html=portal_state_as_html+portal_state_key+" : "+portal_state.get(portal_state_key)+"\n";
        }

        return portal_state_as_html;
	}

	public static Set<Cookie> getCookies(WebDriver driver)
	{
		return driver.manage().getCookies();
	}

	public static String getCookieValue(WebDriver driver,String name)
	{
        Set<Cookie> cookies = getCookies(driver);

	    for(Cookie cookie : cookies)
	    {
	        if(cookie.getName().contains(name))
			{
				return cookie.getValue();	          	             
			}
	    }

	    return null;
	}
}
