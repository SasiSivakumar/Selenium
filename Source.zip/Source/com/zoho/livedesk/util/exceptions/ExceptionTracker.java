//$Id$
package com.zoho.livedesk.util.exceptions;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;


public class ExceptionTracker
{
	public static final String ZOHO_FUNCTION_REGEX="(?<=at )com.zoho.+(?=\\()";

	//contains top most class,function in stacktrace
	public static Hashtable<String,Integer> classes=null;
	public static Hashtable<String,Integer> functions=null;

	public static Hashtable<String,Integer> classes_overall=null;//after checking all classes in stacktrace

	public static void init()
	{
		classes=new Hashtable<String,Integer>();
		functions=new Hashtable<String,Integer>();
		classes_overall=new Hashtable<String,Integer>();	
	}

	public static void track(Exception e)
	{
		if(SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
		{
			//no need to track if automation stopped
			return;
		}

		try
		{
			//get
			String stacktrace=SalesIQAutomationExceptionHandler.getStacktrace(e);
			//parse
			ArrayList<String> stacktrace_list=CommonUtil.getAllMatches(stacktrace,ZOHO_FUNCTION_REGEX);

			String functionName=getExceptionFunction(stacktrace_list);
			String className=getClassName(functionName);
			//add
			add(classes,className);
			add(functions,functionName);
			add(classes_overall,stacktrace_list);
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
	}

	private static void add(Hashtable<String,Integer> hashtable,ArrayList<String> classes_list)
	{
		for(String classname : classes_list)
		{
			add(hashtable,classname);
		}
	}

	private static void add(Hashtable<String,Integer> hashtable,String key)
	{
		if(hashtable.containsKey(key))
		{
			Integer count=hashtable.get(key);
			hashtable.put( key, count+1 );
		}
		else
		{
			hashtable.put( key, 1 );
		}
	}

	public static void printExceptionStats()
	{
		try
		{
			String chat_content="";

			chat_content=chat_content+"```";//code block for cliq

			chat_content=chat_content+"Zoho SalesIQ Automation Code Exception Stats\\n";

			chat_content=chat_content+"\\n--------FAILED CLASSES LIST--------\\n";

			System.out.println("--------MOST FAILED CLASSES LIST BEGINS---------------------------------");

			String classes_content=printSortedList(classes);
			chat_content=chat_content+classes_content;

			System.out.println("---------------------------------MOST FAILED CLASSES LIST ENDS---------------------------------");

			// chat_content=chat_content+"\\n---------------------------------MOST FAILED CLASSES LIST ENDS---------------------------------\\n";



			chat_content=chat_content+"\\n--------FAILED FUNCTIONS LIST--------\\n";

			System.out.println("---------------------------------MOST FAILED FUNCTIONS LIST BEGINS---------------------------------");

			String functions_content=printSortedList(functions);
			chat_content=chat_content+functions_content;

			System.out.println("---------------------------------MOST FAILED FUNCTIONS LIST ENDS---------------------------------");

			// chat_content=chat_content+"\\n---------------------------------MOST FAILED FUNCTIONS LIST ENDS---------------------------------\\n";



			chat_content=chat_content+"\\n--------FAILURE INVOLVED CLASSES LIST--------\\n";

			System.out.println("---------------------------------MOST FAILURE INVOLVED CLASSES LIST BEGINS---------------------------------");

			String involved_classes=printSortedList(classes_overall);
			chat_content=chat_content+involved_classes;

			System.out.println("---------------------------------MOST FAILURE INVOLVED CLASSES LIST ENDS---------------------------------");

			// chat_content=chat_content+"\\n---------------------------------MOST FAILURE INVOLVED CLASSES LIST ENDS---------------------------------\\n";

			chat_content=chat_content+"```";//code block for cliq

			try
			{
				com.zoho.livedesk.util.ChatUtil.postCollapsedMessage(com.zoho.livedesk.server.ConfManager.getRealValue("automation_dev_channel"),"Automation Code Exception Stats",chat_content);
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	//prints all values. but returns only top 10 values
	public static String printSortedList(Hashtable<String,Integer> hashtable)
	{
		String content="";

		ArrayList<Map.Entry<?, Integer>> sorted_list=sortValue(hashtable);

		int i=0;

		for(Map.Entry<?, Integer> list_element : sorted_list)
		{
			String value=list_element.getKey()+"---->"+list_element.getValue();
			System.out.println(value);
			
			//return only top 10 values
			if(i<10)
			{
				content=content+value+"\\n";
			}

			i++;
		}

		return content;
	}

    public static ArrayList<Map.Entry<?, Integer>> sortValue(Hashtable<?, Integer> t)
    {
    	return sortValue(t,true);
    }

    public static ArrayList<Map.Entry<?, Integer>> sortValueByAscending(Hashtable<?, Integer> t)
    {
    	return sortValue(t,false);
    }

    public static ArrayList<Map.Entry<?, Integer>> sortValue(Hashtable<?, Integer> t,boolean isSortByDesc)
	{
		ArrayList<Map.Entry<?, Integer>> l = new ArrayList(t.entrySet());
		Collections.sort(l, new Comparator<Map.Entry<?, Integer>>(){

		public int compare(Map.Entry<?, Integer> o1, Map.Entry<?, Integer> o2) 
		{
			if(isSortByDesc)
			{
				return o2.getValue().compareTo(o1.getValue());
			}
			else
			{
				return o1.getValue().compareTo(o2.getValue());				
			}

		}});

		return l;
	}

	private static String getExceptionFunction(ArrayList<String> stacktrace_list)
	{
		for(int i=0;i<stacktrace_list.size();i++)
		{
			String function=stacktrace_list.get(i);
			String classname=getClassName(function);

			if(getIgnoreClassNames().contains(classname)==false)
			{
				return function;
			}
		}

		return stacktrace_list.get(0);
	}

	public static ArrayList<String> getIgnoreClassNames()
	{
		ArrayList<String> ignore_classes=new ArrayList<String>();

		ignore_classes.add("com.zoho.livedesk.util.common.CommonUtil");
		ignore_classes.add("com.zoho.livedesk.util.common.CommonWait");
		ignore_classes.add("com.zoho.livedesk.util.common.CommonWait");
		ignore_classes.add("com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException");

		return ignore_classes;
	}

	private static String getClassName(String function)
	{
		String[] split=function.split("\\.");
		return function.replace("."+split[split.length-1],"");
	}

}
