//$Id$
package com.zoho.livedesk.util.exceptions;

public class ZohoSalesIQRuntimeException extends RuntimeException
{
	public ZohoSalesIQRuntimeException(String message)
	{
		super(message);
	}
}
