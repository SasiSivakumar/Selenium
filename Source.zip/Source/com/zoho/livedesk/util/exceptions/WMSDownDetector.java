//$Id$
package com.zoho.livedesk.util.exceptions;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.AutomationPauser;

public class WMSDownDetector
{
    public static final int CHECK_INTERVAL_IN_SECONDS=10;

    public static final String
    TEST="WMS Status during automation",
    MODULE_NAME="Issues"
    ;

    public static WebDriver driver;

    public static boolean isWMSDownNow;

    public static ExtentTest etest;

    public static void init()
    {
        setIsWMSDownNow(false);
        etest=ComplexReportFactory.getTest(TEST);
        ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    }

    public static void setIsWMSDownNow(boolean isWMSDown)
    {
        isWMSDownNow=isWMSDown;
    }

    public static boolean isWMSDownNow()
    {
        return isWMSDownNow;
    }

    public static boolean isDetect()
    {
        try
        {
            if(Boolean.parseBoolean(ConfManager.getRealValue("is_detect_wms_down")))
            {
                if(Util.isLocalBuild())
                {   
                    return true;
                }
            }
        }
        catch(Exception e)
        {

        }

        return false;
    }

    public static void start()
    {
        if(!isDetect())
        {
            return;
        }

        try
        {
            driver=Driver.getDriver();

            Functions.login(driver,"developer_mode");

            //while automation is running
            while(Util.isAutomationRunning())
            {
                boolean isStatusAndWMSBarHidden=SalesIQAutomationExceptionHandler.isStatusAndWMSBarHidden(driver);

                if(isStatusAndWMSBarHidden==true && isWMSDownNow()==false)
                {
                    AutomationPauser.pauseAutomation("WMS was down");
                    setIsWMSDownNow(true);
                    etest.log(Status.FAIL,"WMS was down at "+CommonUtil.timestamp());
                    TakeScreenshot.screenshot(driver,etest);
                    ComplexReportFactory.closeTest(etest,false);
                }
                else if(isStatusAndWMSBarHidden==false && isWMSDownNow()==true)
                {
                    AutomationPauser.resumeAutomation();
                    setIsWMSDownNow(false);
                    etest.log(Status.PASS,"WMS was up at "+CommonUtil.timestamp());
                    TakeScreenshot.infoScreenshot(driver,etest);
                    ComplexReportFactory.closeTest(etest,false);
                }

                CommonUtil.sleep(CHECK_INTERVAL_IN_SECONDS*1000);

                driver.navigate().refresh();
            }

            Functions.logout(driver);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
    }
}