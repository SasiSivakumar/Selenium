//$Id$
package com.zoho.livedesk.util.exceptions;

import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import java.io.StringWriter;
import java.io.PrintWriter;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.ChatUtil;
import java.util.Hashtable;
import java.util.Set;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

public class SalesIQAutomationExceptionHandler
{

	public static boolean isFatalErrorOccurred=false;//this variable should be set to be true, when automation should stopped due to fatal error

	public static boolean isFatalErrorMessagePosted=false;

	public static String fatal_error_reason="Unknown reason";

    public static Hashtable<String,String> wmsErrorInfo; 

	public static final String
	BLANK_PAGE_IDENTIFER_ID="rightcontainer",
	LOADING_USER_STATUS_CLASS="switch-loadr",
	USER_STATUS_ID="switch-bg",
	CHAT_BAR_ID="lschatbar"
	;

	public static int no_of_wms_errors=0;
	public static boolean isWMSDownHandled = false;

	public static final int MAX_WMS_ERRORS_ALLOWED=25;

	public static void throwCustomException(String message) throws ZohoSalesIQRuntimeException
	{
		throw new ZohoSalesIQRuntimeException(message);
	}

	public static void init()
	{
		no_of_wms_errors=0;
		isWMSDownHandled = false;
		isFatalErrorMessagePosted=false;
        wmsErrorInfo=new Hashtable<String,String>();
	}

	//Exception handlers

	public static void handleAllExceptions(WebDriver driver,ExtentTest etest)
	{
		if(isFatalErrorOccurred())
		{
			//no need to handle if automation stopped
			return;
		}

		if(Debugger.isSalesIQPage(driver)==false)
		{
			return;
		}

		try
		{
			handleBlankPageException(driver,etest);
			handleWMSDown(driver,etest);
			handleOpenPopups(driver,etest);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			etest.log(Status.INFO,"Exception occured while handling exception."+e.toString());
		}
	}

	public static boolean isSalesIQBlankPage(WebDriver driver)
	{
		if(driver.getCurrentUrl().contains("salesiq.") && driver.getCurrentUrl().contains("zoho.com"))
		{
			if(driver.findElement(By.id(BLANK_PAGE_IDENTIFER_ID)).getAttribute("innerHTML").toString().equals(""))
			{
				return true;
			}
		}

		return false;
	}
	
	public static void handleWMSDown(WebDriver driver,ExtentTest etest)
	{	
		if(isStatusAndWMSBarHidden(driver))
		{
			no_of_wms_errors++;
			etest.log(Status.WARNING,"Status and WMS bar are not found.");

			if(no_of_wms_errors>=MAX_WMS_ERRORS_ALLOWED && !isWMSDownHandled)
			{
				fatal_error_reason="Status and WMS bar are not found.";

				if(isWMSDown(driver))
				{
					fatal_error_reason="WMS is down";
					postWMSDownIssueToWMSChannel();
				}

				etest.log(Status.FATAL,fatal_error_reason);
				setIsFatalErrorOccurred(true);
				isWMSDownHandled = true;
			}
		}
	}

	public static void forceStopAutomation(String reason)
	{
		fatal_error_reason=reason;
		setIsFatalErrorOccurred(true);
	}

	public static String getReasonForStopping()
	{
		return fatal_error_reason;
	}

	public static boolean isFatalErrorOccurred()
	{
		return isFatalErrorOccurred;
	}

	public static void setIsFatalErrorOccurred(boolean isFatalErrorOccurred)
	{		
		if(isFatalErrorOccurred)
		{
			postFatalErrorOccuredMessage();
		}
		
		SalesIQAutomationExceptionHandler.isFatalErrorOccurred=isFatalErrorOccurred;
	}

	public static void postFatalErrorOccuredMessage()
	{
		if(isFatalErrorMessagePosted)
		{
			return;
		}

		if(isFatalErrorOccurred()==false)//If its true, it means message is already posted. So we post only when its false
		{
	        isFatalErrorMessagePosted=true;

	        if(Util.isCleanupRunning()==true)
	        {
	        	ChatUtil.postToAutomationDevChannel("Cleanup was stopped due to "+fatal_error_reason);
	        }
	        else
	        {
	        	ChatUtil.postToChannel("Automation was stopped due to "+fatal_error_reason,Util.getChannelIDForRunningAutomation(),Util.getAuthTokenForRunningAutomation());
	        }
		}
	}

	public static boolean isStatusAndWMSBarHidden(WebDriver driver)
	{
		boolean isStatusStillLoading=false,isChatBarNotWorking=false;

		if(Debugger.isSalesIQPage(driver))
		{
			driver.switchTo().defaultContent();
			
			try
			{
				if(!(driver.findElement(By.id("switch-bg")).getAttribute("class").contains("userstatus")))
				{
					isStatusStillLoading=true;
				}
			}
			catch(Exception e)
			{
				isStatusStillLoading=true;
			}

			if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains(CHAT_BAR_ID)==false)
			{
				if(driver.findElements(By.id(CHAT_BAR_ID)).size()==0)
				{
					isChatBarNotWorking=true;
				}
			}

			if(isStatusStillLoading && isChatBarNotWorking)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;//for pages not from salesiq domain
		}
	}

	public static boolean isWMSDown(final WebDriver driver)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,120,250);

		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
	            public Boolean apply(WebDriver driver)
	            {
	                if(Boolean.parseBoolean(ExecuteStatements.isWMSDown(driver)))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        return true;
		}
		catch(Exception e)
		{

		}

		return false;
	}

	public static void handleBlankPageException(WebDriver driver,ExtentTest test)
	{
		try
		{
			if(isSalesIQBlankPage(driver)==true)
			{
				int
				attempts=0,
				no_of_refresh_attempts=1;

				while(attempts<no_of_refresh_attempts)
				{
					if(isSalesIQBlankPage(driver)==true)
					{
						attempts++;
						// test.log(Status.INFO,"Blank page issue may have has occured. Refreshing the page (attempt:"+attempts+")");
						driver.navigate().refresh();
					}
					else
					{
						// test.log(Status.INFO,"Blank page issue was resolved after refreshing the page.");
						return;						
					}
				}

				if(isSalesIQBlankPage(driver)==true)
				{
					// test.log(Status.FAIL,"Blank page issue was not resolved even after refreshing the page (attempts:"+attempts+")");
				}
			}
		}
		catch(Exception e)
		{
			System.out.println("~~Exception occured while attempting to resolve blank page exception");
			e.printStackTrace();
		}
	}

	public static void postWMSDownIssueToWMSChannel()
	{
		if(Util.isTestingBuild() && ConfManager.getChannelID().equals("updatesv") && Util.isLocalBuild())
		{
			ChatUtil.postToCliq("SalesIQ automation was stopped due to WMS connection error in localzoho.","WMS Issue Reporter",ConfManager.getRealValue("wms_issues_channel"));
		}
	}

	public static void postWMSErrorsInfoToChannel()
	{
		try
		{
			Hashtable<String,String> errors_info=SalesIQAutomationExceptionHandler.getWMSErrorInfo();

			if(errors_info.isEmpty()==false)
			{
				String chat_message="";

			    Set<String> wmsids = errors_info.keySet();

			    for(String wmsid: wmsids)
			    {
			    	chat_message=chat_message+"\\n\\n---> *WMSID* : "+wmsid+" at "+errors_info.get(wmsid);
			    }

			    ChatUtil.postCollapsedMessage(ConfManager.forceGetChannelID(),"WMS-IAM auth validation failure during automation (WMSID,timestamp,cookie values)",chat_message);
			    // ChatUtil.postCollapsedMessage("2198167567685899748","WMS-IAM auth validation failure during automation (WMSID,timestamp,cookie values)",chat_message,"WMS-IAM Auth Error Detector",true);

			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void setWMSErrorInfo(WebDriver driver)
	{
        try
        {
        	String value="";
        	value=value+""+CommonUtil.timestamp()+",";

        	try
        	{
	        	value=value+"\\n"+"ZUID:"+ExecuteStatements.getZUID(driver)+",";
	        	value=value+"\\n"+"_iamadt:"+Debugger.getCookieValue(driver,"_iamadt")+",";
	        	value=value+"\\n"+"_iambdt:"+Debugger.getCookieValue(driver,"_iambdt")+",";
        	}
        	catch(Exception e1)
        	{
        		e1.printStackTrace();
        	}

            wmsErrorInfo.put(ExecuteStatements.getWMSID(driver),value);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
	}

	public static void reportWMSAuthErrorAsFalsePositive(WebDriver driver)
	{
        try
        {
            String wmsid=ExecuteStatements.getWMSID(driver);

            if(wmsErrorInfo.containsKey(wmsid))
            {
                wmsErrorInfo.remove(wmsid);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
	}

    public static Hashtable<String,String> getWMSErrorInfo()
    {
        return wmsErrorInfo;
    }

    public static String getStacktrace(Exception e)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String sStackTrace = sw.toString(); // stack trace as a string
        return sStackTrace;
    }

    public static void handleOpenPopups(WebDriver driver,ExtentTest etest)
    {
    	try
    	{
    		Cleanup.closeAllPopups(driver,etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,e);
    		e.printStackTrace();
    	}
    }
}
