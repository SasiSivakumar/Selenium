//$Id$
package com.zoho.livedesk.util;

import com.beust.testng.TestNG;

import com.zoho.qa.server.CommondMethods;

import com.zoho.qa.server.TestNGreportGen;
import com.zoho.qa.server.WebdriverApiHub;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.WebdriverTestContainer;

import com.zoho.qa.server.WebdriverTestServer;
import com.zoho.qa.server.WebdriverTestsuite;
import com.zoho.qa.server.WebdriverTestsuiteProvider;
//import com.zoho.writer.TestSuite;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;

import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;

import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import org.testng.ITestNGListener;

import org.testng.TestListenerAdapter;
import org.testng.xml.XmlClass;

import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.Date;
import com.zoho.livedesk.client.ComplexReportFactory;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import com.zoho.livedesk.util.common.CommonUtil;

public class Webhook extends HttpServlet 
{
	public static String bot_reply = "<bot_reply>";
	public static String date_format = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";

	public static final String
	FORWARD_AGENT_EMAIL="kabilan.b+bots6_t0@zohotest.com";

	public static String[] article_ids={"Not Created","Not Created","Not Created"};

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse http_response) throws ServletException, IOException 
	{
		try
		{
			String incoming_payload_str=getInputStream(request);

			http_response.setIntHeader("Refresh", 5);
			http_response.setContentType("text/html");
			PrintWriter out = http_response.getWriter();

			Util.print("~~Webhook Recieved");
			Util.print("--------------------------------------------------------------------------");
			// com.zoho.livedesk.util.BuildChangeSetAnalyser.BuildUpdate.logRequest(request);
			// Util.print("--------------------------------------------------------------------------");

			String method = request.getMethod();
			if("HEAD".equals(method))
			{
				return;
			}


			JSONObject incoming_payload=new JSONObject(incoming_payload_str);

			// Map params = com.zoho.livedesk.util.BuildChangeSetAnalyser.BuildUpdate.jsonToMap(incoming_payload);
			// Util.print("PARAMS--->"+params.toString());

			JSONArray attachments=getJSONArrayParam(incoming_payload,"attachments");
			JSONObject location=getJSONParam(incoming_payload,"location");
			JSONObject chat=getJSONParam(incoming_payload,"chat");
			String operation=getParam(incoming_payload,"operation");
			String handler=getParam(incoming_payload,"handler");
			String org_id=getParam(incoming_payload,"org_id");
			JSONObject visitor=getJSONParam(incoming_payload,"visitor");

			JSONObject message=null;
			String message_id=null,text=null,type=null;

			String context_id=null;
			JSONObject answers=null;

			JSONObject response=null;

			if(handler!=null && handler.equals("message"))
			{

				boolean isAttachment=(attachments.length()>0);

				if(isAttachment)
				{
					response=invokeMessageHandlerForAttachments(attachments);
				}
				else
				{
					message=new JSONObject(getParam(incoming_payload,"message"));

					try
					{
						message_id=message.getString("message_id");
					}
					catch(Exception e)
					{
						Util.print("message_id NOT found");
					}


					text=message.getString("text");
					type=message.getString("type");

					response=invokeMessageHandler(text);					
				}
			}
			else if(handler!=null && handler.equals("context"))
			{

				context_id=getParam(incoming_payload,"context_id");
				answers=new JSONObject(getParam(incoming_payload,"answers"));

				response=invokeContextHandler(context_id,answers);
			}
			else if(  ( handler!=null && handler.equals("trigger") )  || ( operation!=null && ( operation.equals("chat") || operation.equals("message") ) ) )
			{

				response=invokeTriggerHandler();
			}

			Util.print(response.toString());
			out.print(response.toString());
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public String getInputStream(HttpServletRequest request) throws Exception
	{
		StringWriter writer = new StringWriter();
        IOUtils.copy(request.getInputStream(), writer, "UTF-8");
        String requestBody = writer.toString();
        return requestBody;
	}

	public JSONObject invokeMessageHandler(String visitor_message) throws Exception
	{
		String text=visitor_message;

		JSONObject response=new JSONObject();

		response.put("action","reply");

		JSONArray replies=new JSONArray();
		replies.put(bot_reply);

		if(text.equals("INVOKE CALENDAR1"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("format",date_format);
			input.put("type","calendar");
			input.put("time","true");
			input.put("tz","true");
			input.put("from","-5");
			input.put("to","+5");
			input.put("label",bot_reply);

			response.put("input",input);
		}
		else if(text.equals("INVOKE CALENDAR2"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("format",date_format);
			input.put("type","calendar");
			input.put("time","false");
			input.put("tz","false");
			input.put("label",bot_reply);

			response.put("input",input);
		}
		else if(text.equals("INVOKE RANGE CALENDAR1"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("format",date_format);
			input.put("type","range-calendar");
			input.put("time","true");
			input.put("tz","true");
			input.put("from","-5");
			input.put("to","+5");
			input.put("label",bot_reply);

			response.put("input",input);
		}
		else if(text.equals("INVOKE RANGE CALENDAR2"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("format",date_format);
			input.put("type","range-calendar");
			input.put("time","false");
			input.put("tz","false");
			input.put("label",bot_reply);

			response.put("input",input);
		}
		else if(text.equals("INVOKE HAPPINESS RATING LEVEL3"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","happiness-rating");
			input.put("level","3");

			response.put("input",input);
		}
		else if(text.equals("INVOKE HAPPINESS RATING LEVEL5"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","happiness-rating");
			input.put("level","5");

			response.put("input",input);
		}
		else if(text.equals("INVOKE LIKE SKIPPABLE"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","like");

			response.put("input",input);
		}
		else if(text.equals("INVOKE LIKE UNSKIPPABLE"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","like");

			response.put("input",input);
		}
		else if(text.equals("INVOKE SLIDER"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","slider");

			JSONArray values=new JSONArray();
			values.put("0");
			values.put("10");
			values.put("20");
			values.put("30");
			values.put("40");

			input.put("values",values);

			response.put("input",input);
		}
		else if(text.equals("INVOKE RANGE SLIDER"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","range-slider");

			JSONArray values=new JSONArray();
			values.put("0");
			values.put("10");
			values.put("20");
			values.put("30");
			values.put("40");
			values.put("50");
			values.put("60");
			values.put("70");
			values.put("80");
			values.put("90");

			input.put("values",values);

			response.put("input",input);
		}
		else if(text.equals("INVOKE 5STAR RATING"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","star-rating");
			input.put("level","5");

			response.put("input",input);
		}
		else if(text.equals("INVOKE 10STAR RATING"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","star-rating");
			input.put("level","10");

			response.put("input",input);
		}
		else if(text.equals("INVOKE SINGLE SELECT1"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","select");

			JSONArray options=new JSONArray();
			options.put("SalesIQ");
			options.put("Cliq");
			options.put("CRM");
			options.put("Desk");
			options.put("People");
			options.put("Connect");
			options.put("Mail");
			options.put("Docs");
			options.put("Writer");
			options.put("Projects");

			input.put("options",options);

			response.put("input",input);
		}
		else if(text.equals("INVOKE SINGLE SELECT2"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","select");

			JSONArray options=new JSONArray();
			options.put("012345678901234567890123456789");
			options.put("Char limit usecase");

			input.put("options",options);

			response.put("input",input);
		}
		else if(text.equals("INVOKE MULTISELECT1"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","multiple-select");
			input.put("max_selection","5");

			JSONArray options=new JSONArray();
			options.put("SalesIQ");
			options.put("Cliq");
			options.put("CRM");
			options.put("Desk");
			options.put("People");
			options.put("Connect");
			options.put("Mail");
			options.put("Docs");
			options.put("Writer");
			options.put("Projects");

			input.put("options",options);

			response.put("input",input);
		}
		else if(text.equals("INVOKE MULTISELECT2"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","multiple-select");
			input.put("max_selection","5");

			JSONArray options=new JSONArray();
			options.put("SalesIQ");
			options.put("Cliq");
			options.put("CRM");
			options.put("Desk");
			options.put("People");
			options.put("Connect");
			options.put("Mail");
			options.put("Docs");
			options.put("Writer");
			options.put("Projects");

			input.put("options",options);

			response.put("input",input);
		}
		else if(text.equals("INVOKE TIMESLOTS1"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","timeslots");
			input.put("tz","true");

			JSONArray slots=new JSONArray();
			slots.put("00:00");
			slots.put("24:00");
			slots.put("12:00");
			slots.put("03:00");
			slots.put("15:00");

			input.put("slots",slots);

			response.put("input",input);
		}
		else if(text.equals("INVOKE TIMESLOTS2"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","timeslots");
			input.put("tz","false");

			JSONArray slots=new JSONArray();
			slots.put("00:00");
			slots.put("24:00");
			slots.put("12:00");
			slots.put("03:00");
			slots.put("15:00");

			input.put("slots",slots);

			response.put("input",input);
		}
		else if(text.equals("INVOKE DATETIMESLOTS1"))
		{
			response.put("action","reply");
			response.put("skippable","true");

			JSONObject input=new JSONObject();
			input.put("type","date-timeslots");
			input.put("tz","true");

			JSONObject slots=new JSONObject();
			JSONArray slot=null;

			slot=new JSONArray();
			slot.put("00:00");
			slot.put("24:00");
			slots.put("01/01/2018",slot);

			slot=new JSONArray();
			slot.put("12:00");
			slot.put("03:00");
			slots.put("31/12/2018",slot);

			slot=new JSONArray();
			slot.put("15:00");
			slots.put("15/08/2018",slot);

			input.put("slots",slots);

			response.put("input",input);
		}
		else if(text.equals("INVOKE DATETIMESLOTS2"))
		{
			response.put("action","reply");
			response.put("skippable","false");

			JSONObject input=new JSONObject();
			input.put("type","date-timeslots");
			input.put("tz","false");

			JSONObject slots=new JSONObject();
			JSONArray slot=null;

			slot=new JSONArray();
			slot.put("00:00");
			slot.put("24:00");
			slots.put("01/01/2018",slot);

			slot=new JSONArray();
			slot.put("12:00");
			slot.put("03:00");
			slots.put("31/12/2018",slot);

			slot=new JSONArray();
			slot.put("15:00");
			slots.put("15/08/2018",slot);

			input.put("slots",slots);

			response.put("input",input);
		}
		else if(text.equals("INVOKE LINK"))
		{
			response.put("action","reply");

			JSONObject link_input=new JSONObject();
			JSONArray links=new JSONArray();
			JSONObject link=null;

			link=new JSONObject();
			link.put("url","https://www.google.com");
			link.put("text","1_"+bot_reply);
			link.put("icon","https://img.icons8.com/color/2x/google-logo.png");
			links.put(link);

			link=new JSONObject();
			link.put("url","https://salesiq.zoho.com");
			link.put("text","2_"+bot_reply);
			link.put("icon","https://image.freepik.com/free-icon/facebook_318-136394.jpg");
			links.put(link);

			link_input.put("links",links);
			link_input.put("text","Links");
			link_input.put("type","links");

			replies.put(link_input);
		}
		else if(text.equals("INVOKE IMAGE"))
		{
			response.put("action","reply");

			JSONObject image=new JSONObject();
			image.put("text",bot_reply);
			image.put("image","https://img.icons8.com/color/2x/google-logo.png");
			replies.put(image);
		}
		else if(text.equals("INVOKE ARTICLES"))
		{
			response.put("action","reply");

			JSONObject articles=new JSONObject();

			JSONArray articles_list=new JSONArray();

			for(String article_id : article_ids)
			{
				articles_list.put(article_id);
			}

			articles.put("text",bot_reply);
			articles.put("type","articles");
			articles.put("description",bot_reply + "_description");
			articles.put("articles",articles_list);

			replies.put(articles);
		}
		else if(text.equals("INVOKE_FORWARD_TO_ALL"))
		{
			response.put("action","forward");
		}
		else if(text.equals("INVOKE_FORWARD_TO_AGENT"))
		{
			response.put("action","forward");
			response.put("operators",new JSONArray().put(FORWARD_AGENT_EMAIL));
		}
		else if(text.equals("INVOKE_OPERATOR_BUSY"))
		{
			response.put("action","operator_busy");
		}
		else if(text.equals("INVOKE_BLOCK"))
		{
			response.put("action","block");
		}
		else if(text.equals("INVOKE_END"))
		{
			response.put("action","end");
		}
		else if(text.contains("CONTEXT"))
		{
			JSONArray questions=new JSONArray();
			JSONObject question=null;
			JSONArray question_content=null;
			JSONArray suggestions=null;

			response.put("action","context");

			if(text.contains("Flow1"))
			{
				response.put("context_id","context1");

				question=new JSONObject();
				question_content=new JSONArray();
				suggestions=new JSONArray();
				question_content.put("question1?");
				suggestions.put("answer11");
				suggestions.put("answer12");
				question.put("name","q1");
				question.put("suggestions",suggestions);
				question.put("replies",question_content);
				questions.put(question);

				question=new JSONObject();
				question_content=new JSONArray();
				suggestions=new JSONArray();
				question_content.put("question2?");
				question.put("name","q2");
				question.put("replies",question_content);
				questions.put(question);

				question=new JSONObject();
				question_content=new JSONArray();
				suggestions=new JSONArray();
				question_content.put("question3?");
				question.put("name","q3");
				question.put("replies",question_content);
				questions.put(question);
			}
			else if(text.contains("Flow2"))
			{
				response.put("context_id","context2");

				question=new JSONObject();
				question_content=new JSONArray();
				suggestions=new JSONArray();
				question_content.put("question4?");
				suggestions.put("answer41");
				suggestions.put("answer42");
				question.put("name","q4");
				question.put("suggestions",suggestions);
				question.put("replies",question_content);
				questions.put(question);

				question=new JSONObject();
				question_content=new JSONArray();
				suggestions=new JSONArray();
				question_content.put("question5?");
				question.put("name","q5");
				question.put("replies",question_content);
				questions.put(question);

				question=new JSONObject();
				question_content=new JSONArray();
				suggestions=new JSONArray();
				question_content.put("question6?");
				question.put("name","q6");
				question.put("replies",question_content);
				questions.put(question);
			}

			response.put("questions",questions);
		}
		else if(text.equals("STORE NAME"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","enter name");
			reply.put("field_name","siq_name");
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("STORE EMAIL"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","enter email");
			reply.put("field_name","siq_email");
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("STORE PHONE"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","enter phone");
			reply.put("field_name","siq_phone");
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("VALIDATE EMAIL"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","validate email");
			JSONObject validate=new JSONObject();
			JSONArray error=new JSONArray();
			validate.put("format","email");
			error.put("invalid email");
			validate.put("error",error);
			reply.put("validate",validate);
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("VALIDATE PHONE"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","validate phoneno");
			JSONObject validate=new JSONObject();
			JSONArray error=new JSONArray();
			validate.put("format","phoneno");
			error.put("invalid phoneno");
			validate.put("error",error);
			reply.put("validate",validate);
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("VALIDATE WEBSITE"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","validate website");
			JSONObject validate=new JSONObject();
			JSONArray error=new JSONArray();
			validate.put("format","website");
			error.put("invalid website");
			validate.put("error",error);
			reply.put("validate",validate);
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("VALIDATE NUMBER"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","validate number");
			JSONObject validate=new JSONObject();
			JSONArray error=new JSONArray();
			validate.put("format","number");
			error.put("invalid number");
			validate.put("error",error);
			reply.put("validate",validate);
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("VALIDATE STRING(5-10)"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","validate string(5-10)");
			JSONObject validate=new JSONObject();
			JSONArray error=new JSONArray();
			validate.put("format","string(5-10)");
			error.put("invalid string(5-10)");
			validate.put("error",error);
			reply.put("validate",validate);
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("VALIDATE NUMBER(5-10)"))
		{
			response.put("action","reply");
			JSONObject reply=new JSONObject();
			reply.put("text","validate number(5-10)");
			JSONObject validate=new JSONObject();
			JSONArray error=new JSONArray();
			validate.put("format","number(5-10)");
			error.put("invalid number(5-10)");
			validate.put("error",error);
			reply.put("validate",validate);
			replies.put(reply);	
			response.put("replies", replies);
		}
		else if(text.equals("REPLY"))
		{
			response.put("action","reply");
			response.put("replies", replies);
		}
		else
		{
			JSONArray suggestions=new JSONArray();

			suggestions.put("REPLY");
			suggestions.put("INVOKE CALENDAR1");
			suggestions.put("INVOKE CALENDAR2");
			suggestions.put("INVOKE RANGE CALENDAR1");
			suggestions.put("INVOKE RANGE CALENDAR2");
			suggestions.put("INVOKE HAPPINESS RATING LEVEL3");
			suggestions.put("INVOKE HAPPINESS RATING LEVEL5");
			suggestions.put("INVOKE LIKE SKIPPABLE");
			suggestions.put("INVOKE LIKE UNSKIPPABLE");
			suggestions.put("INVOKE SLIDER");
			suggestions.put("INVOKE RANGE SLIDER");
			suggestions.put("INVOKE 5STAR RATING");
			suggestions.put("INVOKE 10STAR RATING");
			suggestions.put("INVOKE SINGLE SELECT1");
			suggestions.put("INVOKE SINGLE SELECT2");
			suggestions.put("INVOKE MULTISELECT1");
			suggestions.put("INVOKE MULTISELECT2");
			suggestions.put("INVOKE TIMESLOTS1");
			suggestions.put("INVOKE TIMESLOTS2");
			suggestions.put("INVOKE DATETIMESLOTS1");
			suggestions.put("INVOKE DATETIMESLOTS2");
			suggestions.put("INVOKE LINK");
			suggestions.put("INVOKE IMAGE");
			suggestions.put("INVOKE ARTICLES");
			suggestions.put("INVOKE_FORWARD_TO_ALL");
			suggestions.put("INVOKE_FORWARD_TO_AGENT");
			suggestions.put("INVOKE_OPERATOR_BUSY");
			suggestions.put("INVOKE_BLOCK");
			suggestions.put("INVOKE_END");
			suggestions.put("CONTEXT Flow1");
			suggestions.put("CONTEXT Flow2");
			suggestions.put("STORE NAME");
			suggestions.put("STORE EMAIL");
			suggestions.put("STORE PHONE");
			suggestions.put("VALIDATE EMAIL");
			suggestions.put("VALIDATE PHONE");
			suggestions.put("VALIDATE WEBSITE");
			suggestions.put("VALIDATE NUMBER");
			suggestions.put("VALIDATE STRING(5-10)");
			suggestions.put("VALIDATE NUMBER(5-10)");

			response.put("suggestions",suggestions);
		}

		response.put("replies", replies);

		return response;
	}

	public JSONObject invokeContextHandler(String context_id,JSONObject answers) throws Exception
	{
		JSONObject response=new JSONObject();

		response.put("action","reply");

		JSONArray replies=new JSONArray();

		if(context_id.equals("context1"))
		{
			replies.put( answers.getJSONObject("q1").getString("text") + "$$" + answers.getJSONObject("q2").getString("text") + "$$" + answers.getJSONObject("q3").getString("text") );			
		}
		else if(context_id.equals("context2"))
		{
			replies.put( answers.getJSONObject("q4").getString("text") + "$$" + answers.getJSONObject("q5").getString("text") + "$$" + answers.getJSONObject("q6").getString("text") );			
		}

		response.put("replies", replies);

		return response;
	}

	public JSONObject invokeTriggerHandler() throws Exception
	{
		JSONObject response=new JSONObject();
		response.put("action","reply");
		JSONArray replies=new JSONArray();
		replies.put("trigger"+bot_reply);
		response.put("replies", replies);

		return response;
	}

	public JSONObject invokeMessageHandlerForAttachments(JSONArray attachments) throws Exception
	{
		JSONObject attachment=attachments.getJSONObject(0);

		JSONObject response=new JSONObject();
		response.put("action","reply");

		JSONArray replies=new JSONArray();
		replies.put("url : "+attachment.getString("url"));
		replies.put("name : "+attachment.getString("name"));
		replies.put("contenttype : "+attachment.getString("contenttype"));

		response.put("replies", replies);

		return response;
	}

	public static void setBotUniqueMessage(String unique_message)
	{
		bot_reply=unique_message;
	}

	public static void setArticleIds(String... ids)
	{
		article_ids=ids;
	}

	public static String getParam(JSONObject json,String key)
	{
		try
		{
			return json.get(key).toString();
		}
		catch(Exception e)
		{
			// e.printStackTrace();
		}

		return null;
	}

	public static JSONObject getJSONParam(JSONObject json,String key)
	{
		try
		{
			return new JSONObject(getParam(json,key));
		}
		catch(Exception e)
		{
			// e.printStackTrace();
		}

		return null;
	}

	public static JSONArray getJSONArrayParam(JSONObject json,String key)
	{
		try
		{
			return new JSONArray(getParam(json,key));
		}
		catch(Exception e)
		{
			// e.printStackTrace();
		}

		return null;
	}

	public static boolean isEmpty(String value)
	{
		try
		{
			return (value.trim().length() == 0);
		}
		catch (NullPointerException npe)
		{
			return true;
		}
	}

	public static boolean isEmpty(String[] value)
	{
		return value == null || value.length == 0;
	}  
}
