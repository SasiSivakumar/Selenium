//$Id$
package com.zoho.livedesk.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.util.ArrayList;
import java.util.Arrays;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.client.ComplexReportFactory;

public class MailUtil {

	public static void sendAutomationInitiatedMail(String build,String url)
	{
		try
		{
			String report_template = WebdriverQAUtil.getAttachmentPath("ldinitiate_mail.html");
			report_template = report_template.replace("null", "salesiq");
			String content = getMailString(report_template);
            
            String all_modules = "";
            
            String[] modules1 = ConfManager.getModules().split(",");
            
            for(String s: modules1)
            {
                if(!s.equals(""))
                {
                    if(all_modules.equals(""))
                    {
                        all_modules = "<b>Basic Test Cases: </b>"+s;
                    }
                    else
                    {
                        all_modules = all_modules+", "+s;
                    }
                }
            }
            
            String[] supermodules = ConfManager.getSuperModules().split(",");
            
            for(String s: supermodules)
            {
                if(!s.equals(""))
                {
                    s = "Supervisor - "+s;
                    if(all_modules.equals(""))
                    {
                        all_modules = "<b>Basic Test Cases: </b>"+s;
                    }
                    else
                    {
                        all_modules = all_modules+", "+s;
                    }
                }
            }
            
            String[] assomodules = ConfManager.getAssoModules().split(",");
            
            for(String s: assomodules)
            {
                if(!s.equals(""))
                {
                    s = "Associate - "+s;
                    if(all_modules.equals(""))
                    {
                        all_modules = "<b>Basic Test Cases: </b>"+s;
                    }
                    else
                    {
                        all_modules = all_modules+", "+s;
                    }
                }
            }
            
            String[] modules2 = ConfManager.getIntegrationModules().split(",");
            
            if(!modules2[0].equals(""))
            {
                all_modules = all_modules+"<div><span>&nbsp;</span></div><b>Integration Modules: </b>";
            }
            
            for(String s: modules2)
            {
                if(!s.equals(""))
                {
                    if(all_modules.equals(""))
                    {
                        all_modules = s;
                    }
                    else
                    {
                        if(!modules2[0].equals(s))
                        {
                            all_modules = all_modules+", "+s;
                        }
                        else
                        {
                            all_modules = all_modules+s;
                        }
                    }
                }
            }
            
            String[] modules3 = ConfManager.getAutomationModules().split(",");
            
            if(!modules3[0].equals(""))
            {
                all_modules = all_modules+"<div><span>&nbsp;</span></div><b>Automations: </b>";
            }
            
            for(String s: modules3)
            {
                if(!s.equals(""))
                {
                    if(all_modules.equals(""))
                    {
                        all_modules = s;
                    }
                    else
                    {
                        if(!modules3[0].equals(s))
                        {
                            all_modules = all_modules+", "+s;
                        }
                        else
                        {
                            all_modules = all_modules+s;
                        }
                    }
                }
            }
            
            String[] modules4 = ConfManager.getChatWidgetModules().split(",");
            
            if(!modules4[0].equals(""))
            {
                all_modules = all_modules+"<div><span>&nbsp;</span></div><b>Chat Widget Operations: </b>";
            }
            
            for(String s: modules4)
            {
                if(!s.equals(""))
                {
                    if(all_modules.equals(""))
                    {
                        all_modules = s;
                    }
                    else
                    {
                        if(!modules4[0].equals(s))
                        {
                            all_modules = all_modules+", "+s;
                        }
                        else
                        {
                            all_modules = all_modules+s;
                        }
                    }
                }
            }
            
            String[] modules5 = ConfManager.getOtherModules().split(",");
            
            if(!modules5[0].equals(""))
            {
                all_modules = all_modules+"<div><span>&nbsp;</span></div>";
            }
            
            for(String s: modules5)
            {
                if(!s.equals(""))
                {
                    if(all_modules.equals(""))
                    {
                        all_modules = s;
                    }
                    else
                    {
                        if(!modules5[0].equals(s))
                        {
                            all_modules = all_modules+", "+s;
                        }
                        else
                        {
                            all_modules = all_modules+s;
                        }
                    }
                }
            }
            
            if(all_modules.equals(""))
            {
                all_modules = "No Modules";
            }
            
            String modules = all_modules;

			content = content.replace("$MODULESTESTED", modules);
			content = content.replace("$BUILD", build);
			content = content.replace("$URL", url);

			String report = ComplexReportFactory.extentreportLink;

			content = content.replace("$REPORT",report);

			String setUp = "IDC Setup";

			if(url.contains("lab"))
            {
                setUp = "Lab Local Setup";
            }
            else if(url.contains("local"))
			{
				setUp = "Local Setup";
			}
			else if(url.contains("pre"))
			{
				setUp = "Pre Production Setup";
			}

			String subject = "SalesIQ Automation - "+setUp+" - Automation Testing Started";

			sendMail(subject,content,ConfManager.getAdminAddr());
		}
		catch(Exception e)
		{
			System.out.println("Error in get data");
			e.printStackTrace();
		}
	}

	public static void sendReport(Hashtable report, Hashtable result, Hashtable showstopper, Hashtable servicedown)
	{
		try
		{
			String report_template = WebdriverQAUtil.getAttachmentPath("ldreport_mail.html");
			report_template = report_template.replace("null", "salesiq");
			String content = getMailString(report_template);
            
            String totalUsecases = "";
            
            if(Util.isQuickAutomationSet())
            {
                totalUsecases = ConfManager.getRealValue("totalUsecasesLocalQuick");
            }
            else
            {
                totalUsecases = ConfManager.getRealValue("totalUsecasesLocal");
            }

            int executedUseCase = Integer.parseInt(report.get("TotalUseCases").toString());
            int totalUsecaseCount = Integer.parseInt(totalUsecases);

            if(totalUsecaseCount < executedUseCase)
            {
                totalUsecases = report.get("TotalUseCases").toString();
            }
			
			content=content.replace("$TOTALUSECASE", totalUsecases);
            content=content.replace("$EXECUTEDUSECASE", ""+report.get("TotalUseCases"));
			content=content.replace("$TIMETAKEN", (""+report.get("TimeTaken")));
			content=content.replace("$SUCCESS", ""+report.get("Success"));
			content=content.replace("$FAILURE", ""+report.get("Failure"));
			content=content.replace("$SUCESSPER", (""+report.get("Success_per")+"%"));
			content=content.replace("$FAILPER", (""+report.get("Failure_per")+"%"));
			content=content.replace("$BROWSER", ""+report.get("Browser"));
			content=content.replace("$SETUP", ""+report.get("Setup"));
			content=content.replace("$URL", ""+report.get("URL"));
			content=content.replace("$BUILD", ""+report.get("Build"));

			String data = "<table cellspacing='0'><tbody><tr><td style='width: 321px; vertical-align: top; font-family: 'Liberation Serif';font-size: 12pt;'> No failed use case</td></tbody></table>";
			if(result.size() > 0)
			{
				data = "<table cellspacing='0'><tbody><tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: middle; height:26px;'><div style='position: relative; padding: 4px; width: 313px; height:26px; font-weight: bold;font-family: 'Liberation Serif';font-size: 12pt;'>&nbsp;Use Cases</div></td>";
				data += "<td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: middle; height:26px;'><div style='position: relative; padding: 4px; width: 313px; height:22px; font-weight: bold;font-family: 'Liberation Serif';font-size: 12pt;'>&nbsp;Status</div></td></tr>";
				Set<String> keys = result.keySet();
			        for(String key: keys){
	        			data += "<tr style='height: 40px;'><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:26px;'>  "+key+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:26px;'>  "+result.get(key)+"</div></td></tr>";
	        		}
				data += "</tbody></table>";
			}
	        	content = content.replace("$REPORT", data);

			String sdata = "<table cellspacing='0'><tbody><tr><td style='width: 321px; vertical-align: top; font-family: 'Liberation Serif';font-size: 12pt;'> No show stopper issues </td></tbody></table>";
			if(showstopper.size() > 0)
			{
				sdata = "<table cellspacing='0'><tbody>";
				Set<String> keys = showstopper.keySet();
				int i = 1;
				for(String key: keys){
					if(i == 1)
					{
						sdata += "<tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+key+"</div></td><td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+showstopper.get(key)+"</div></td></tr>";
					}
					else
					{
						sdata += "<tr><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+key+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+showstopper.get(key)+"</div></td></tr>";
					}
					i++;
				}
				sdata += "</tbody></table>";

			}
			content = content.replace("$SHOWSTOPPER", sdata);

			String serdatastyle = "display:none;";
			String serdata = "";
			if(servicedown.size() > 0)
			{
				SimpleDateFormat format = new SimpleDateFormat("d MMM yyyy, h:mm:ss a ");
				serdatastyle = "display:block;";
				serdata = "<table cellspacing='0'><tbody>";
				Set<String> keys = servicedown.keySet();
				int i = 1;
				for(String key: keys){
					Date date = new Date(Long.parseLong(""+servicedown.get(key)));
					String value = format.format(date);
					if(i == 1)
					{
						serdata += "<tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+KeyManager.getRealValue(key)+"</div></td><td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+value+"</div></td></tr>";
					}
					else
					{
						serdata += "<tr><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+KeyManager.getRealValue(key)+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+value+"</div></td></tr>";
					}
					i++;
				}
				serdata += "</tbody></table>";

			}
			content = content.replace("$SERVICEDOWNSTYLE", serdatastyle);
			content = content.replace("$SERVICEDOWN", serdata);
            
            
			String subject = "SalesIQ Automation - "+report.get("Setup")+" - Success Rate - "+report.get("Success_per")+"% | Failure Rate - "+report.get("Failure_per")+"%";
            
			sendMail(subject,content);
		}
		catch(Exception e)
		{
			System.out.println("Error in get data");
			e.printStackTrace();
		}	
	}
	
	private static String getMailString(String path) throws Exception
	{
        BufferedReader reader = null;
        try
        {
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(path),"UTF-8"));
                String line = null;
                StringBuffer st = new StringBuffer();
                while((line = reader.readLine())!=null)
                {
                        st.append(line);
                        st.append("\r\n");//No i18N
                }
                return st.toString();
        }
        finally
        {
                try{if(reader!=null){reader.close();}}catch(Exception e){System.out.println("Unable to close the reader");}
        }
	}
			
	public static void sendMail(String subject,String messageContent) throws Exception
    {
        try
        {
		final String uname = ConfManager.getUname();
		final String pwd = ConfManager.getPassword();
            String host = "smtp"; //NO i18N
 
            Properties properties = System.getProperties();
 
            properties.put("mail.smtp.host", host); //NO i18N
            properties.put("mail.smtp.auth","true");
            properties.put("mail.debug", "true");
 
            Authenticator auth = new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(uname,pwd);
                }
            };
            
            Session session = Session.getDefaultInstance(properties,auth);
 
            String fromAddress = ConfManager.getReportFromAddr();
            //String fromAddress = "anand.ramachandran@zohocorp.com";
            //String toAddress = "anand.ramachandran@zohocorp.com";
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromAddress));
            //String toAddress = WebdriverQAUtil.getCurrentReporter();
	    String toAddress = Util.getToEmailuser();
            if(toAddress == null)
            {
                toAddress = ConfManager.getCcEmailAddr();
            }
            /*else
            {
                toAddress = toAddress + "," + ConfManager.getCcEmailAddr();
            }*/
            String ccAddress = ConfManager.getCcEmailAddr();
            String ccAddrList[]= ccAddress.split(",");
 
            InternetAddress[] myCCList= new InternetAddress[ccAddrList.length];
            
            String toAddrList[]= toAddress.split(",");
            
            InternetAddress[] myList= new InternetAddress[toAddrList.length];
            for(int i = 0;i < toAddrList.length;i++)
            {
                String toAddr = toAddrList[i];
                if(!toAddr.equalsIgnoreCase("") && !toAddr.equalsIgnoreCase("null") && !toAddr.equalsIgnoreCase(null))
                {
                    myList[i] = new InternetAddress(toAddr);
                }
            }
            
            for(int i = 0;i < ccAddrList.length;i++)
            {
                String ccAddr = ccAddrList[i];
                if(!ccAddr.equalsIgnoreCase("") && !ccAddr.equalsIgnoreCase("null") && !ccAddr.equalsIgnoreCase(null))
                {
                    myCCList[i] = new InternetAddress(ccAddr);
                }
            }
           
            message.addRecipients(Message.RecipientType.TO,myList);
            message.addRecipients(Message.RecipientType.CC,myCCList);
	
            //String chmsg = "SalesIQ\\ Automation\\ -\\ "+report.get("Setup")+"\\ -\\ Success\\ Rate\\ -\\ "+report.get("Success_per")+"%\\ |\\ Failure\\ Rate\\ -\\ "+report.get("Failure_per")+"%";
            message.setSubject(subject);
 
            BodyPart messageBodyPart = new MimeBodyPart();
 
            messageBodyPart.setContent(messageContent,"text/html"); //NO i18N
 
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            
            message.setContent(multipart);
 
            Transport.send(message);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("Error Mgs : "+e.getMessage());
        }
    }

    public static void sendMail(String subject,String messageContent,String toEmail) throws Exception
    {
        try
        {
		final String uname = ConfManager.getUname();
		final String pwd = ConfManager.getPassword();
            String host = "smtp"; //NO i18N
 
            Properties properties = System.getProperties();
 
            properties.put("mail.smtp.host", host); //NO i18N
            properties.put("mail.smtp.auth","true");
            properties.put("mail.debug", "true");
 
            Authenticator auth = new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(uname,pwd);
                }
            };
            
            Session session = Session.getDefaultInstance(properties,auth);
 
            String fromAddress = ConfManager.getReportFromAddr();
            //String fromAddress = "anand.ramachandran@zohocorp.com";
            //String toAddress = "anand.ramachandran@zohocorp.com";
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromAddress));
            //String toAddress = WebdriverQAUtil.getCurrentReporter();
	    	
	    	String toAddress = toEmail;//Util.getToEmailuser();
            
            /*else
            {
                toAddress = toAddress + "," + ConfManager.getCcEmailAddr();
            }*/
            String ccAddress = ConfManager.getReportFromAddr();//ConfManager.getCcEmailAddr();
            String ccAddrList[]= ccAddress.split(",");
 
            InternetAddress[] myCCList= new InternetAddress[ccAddrList.length];
            
            String toAddrList[]= toAddress.split(",");
            
            InternetAddress[] myList= new InternetAddress[toAddrList.length];
            for(int i = 0;i < toAddrList.length;i++)
            {
                String toAddr = toAddrList[i];
                if(!toAddr.equalsIgnoreCase("") && !toAddr.equalsIgnoreCase("null") && !toAddr.equalsIgnoreCase(null))
                {
                    myList[i] = new InternetAddress(toAddr);
                }
            }
            
            for(int i = 0;i < ccAddrList.length;i++)
            {
                String ccAddr = ccAddrList[i];
                if(!ccAddr.equalsIgnoreCase("") && !ccAddr.equalsIgnoreCase("null") && !ccAddr.equalsIgnoreCase(null))
                {
                    myCCList[i] = new InternetAddress(ccAddr);
                }
            }
           
            message.addRecipients(Message.RecipientType.TO,myList);
            message.addRecipients(Message.RecipientType.CC,myCCList);
	
            //String chmsg = "SalesIQ\\ Automation\\ -\\ "+report.get("Setup")+"\\ -\\ Success\\ Rate\\ -\\ "+report.get("Success_per")+"%\\ |\\ Failure\\ Rate\\ -\\ "+report.get("Failure_per")+"%";
            message.setSubject(subject);
 
            BodyPart messageBodyPart = new MimeBodyPart();
 
            messageBodyPart.setContent(messageContent,"text/html"); //NO i18N
 
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            
            message.setContent(multipart);
 
            Transport.send(message);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("Error Mgs : "+e.getMessage());
        }
    }

    public static void sendToWithCont(String adminEmail,String messageContent,String subject)
    {
        try
        {
            final String uname = ConfManager.getUname();
            final String pwd = ConfManager.getPassword();
            String host = "smtp"; //NO i18N
            
            Properties properties = System.getProperties();
            
            properties.put("mail.smtp.host", host); //NO i18N
            properties.put("mail.smtp.auth","true");
            properties.put("mail.debug", "true");
            
            Authenticator auth = new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(uname,pwd);
                }
            };
            
            Session session = Session.getDefaultInstance(properties,auth);
            
            String fromAddress = ConfManager.getReportFromAddr();
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromAddress));
            String toAddress = adminEmail;
            if(toAddress == null)
            {
                toAddress = ConfManager.getCcEmailAddr();
            }
            /*else
             {
             toAddress = toAddress + "," + ConfManager.getCcEmailAddr();
             }*/
            
            String toAddrList[]= toAddress.split(",");
            
            InternetAddress[] myList= new InternetAddress[toAddrList.length];
            for(int i = 0;i < toAddrList.length;i++)
            {
                String toAddr = toAddrList[i];
                if(!toAddr.equalsIgnoreCase("") && !toAddr.equalsIgnoreCase("null") && !toAddr.equalsIgnoreCase(null))
                {
                    myList[i] = new InternetAddress(toAddr);
                }
            }
            
            message.addRecipients(Message.RecipientType.TO,myList);
            
            message.setSubject(subject);
            
            BodyPart messageBodyPart = new MimeBodyPart();
            
            messageBodyPart.setContent(messageContent,"text/html"); //NO i18N
            
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            
            message.setContent(multipart);
            
            Transport.send(message);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("Error Mgs : "+e.getMessage());
        }
    }
    
    public static void sendMailReport(String adminEmail)
    {
        String subject = "SalesIQ Automation - CleanUp Success";
        
        String message = "CleanUp Success and All fields have been cleared as per configured";
        
        sendToWithCont(adminEmail,message,subject);
    }
    
    public static void sendMailReport(String adminEmail,String failedmods)
    {
        String subject = "SalesIQ Automation - CleanUp Failure";
        
        failedmods = "Modules : "+failedmods;
        
        String message = "CleanUp Failed - Please check the following setups - <div><span>&nbsp;</span></div>"+failedmods;
        
        sendToWithCont(adminEmail,message,subject);
    }
}
