//$Id$
package com.zoho.livedesk.util.BuildChangeSetAnalyser;
import com.beust.testng.TestNG;

import com.zoho.qa.server.CommondMethods;

import com.zoho.qa.server.TestNGreportGen;
import com.zoho.qa.server.WebdriverApiHub;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.WebdriverTestContainer;

import com.zoho.qa.server.WebdriverTestServer;
import com.zoho.qa.server.WebdriverTestsuite;
import com.zoho.qa.server.WebdriverTestsuiteProvider;
//import com.zoho.writer.TestSuite;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;

import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;

import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import org.testng.ITestNGListener;

import org.testng.TestListenerAdapter;
import org.testng.xml.XmlClass;

import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.util.Hashtable;

import org.apache.commons.io.IOUtils;
import java.nio.charset.Charset;
import java.net.MalformedURLException;
import java.util.Iterator;
import com.zoho.livedesk.server.ConfManager;
import java.net.HttpURLConnection;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.io.PrintWriter;
import org.json.JSONObject;

public class BuildStatus extends HttpServlet 
{
	public static final String is_testing_build="is_testing_build";

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, MalformedURLException
	{
		try
		{
			response.setContentType("application/json");
			PrintWriter out = response.getWriter();

			JSONObject current_configuration = new JSONObject();
			current_configuration.put(is_testing_build, false );

			out.print(current_configuration.toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BuildUpdate.logger(e);
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, MalformedURLException
	{
		//not handled
	}
}