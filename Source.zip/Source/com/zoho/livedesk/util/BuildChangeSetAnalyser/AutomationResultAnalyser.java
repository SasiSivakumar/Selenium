//$Id$
package com.zoho.livedesk.util.BuildChangeSetAnalyser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import com.mysql.jdbc.PreparedStatement;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.exceptions.ExceptionTracker;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import com.zoho.livedesk.server.KeyManager;
import java.text.DecimalFormat;
import com.zoho.livedesk.util.common.DateTimeUtil;
import com.zoho.livedesk.util.LocalStorage.LocalStorageUtil;
import com.zoho.livedesk.util.common.CommonUtil;

public class AutomationResultAnalyser 
{

	public static final String SEPERATOR="<>";

	public static final String LOCALSTORAGEKEY="isAutomationHistoryReportPosted";

	public static Hashtable<String, Hashtable<String,Integer> > generateTestHistoryReportForPast3Runs() throws SQLException,JSONException,ClassNotFoundException
	{
		return generateTestHistoryReportForPastNRuns(3);
	}

	private static void add(Hashtable<String,Integer> hashtable,String key)
	{
		if(hashtable.containsKey(key))
		{
			Integer count=hashtable.get(key);
			hashtable.put( key, count+1 );
		}
		else
		{
			hashtable.put( key, 1 );
		}
	}

	private static void subtract(Hashtable<String,Integer> hashtable,String key)
	{
		if(hashtable.containsKey(key))
		{
			Integer count=hashtable.get(key);
			hashtable.put( key, count-1 );
		}
		else
		{
			hashtable.put( key, 1 );
		}
	}

	public static ArrayList<String> getSortedValueInfo(Hashtable<String,Integer> hashtable,boolean isSortByDesc,int sortedValuesCount)
	{
		ArrayList<String> top_values=new ArrayList<String>();

		ArrayList<Map.Entry<?, Integer>> sorted_list=ExceptionTracker.sortValue(hashtable,isSortByDesc);

		int i=0;

		for(Map.Entry<?, Integer> list_element : sorted_list)
		{
			String key=list_element.getKey()+"";
			Integer value=list_element.getValue();

			String seperated_values=key+SEPERATOR+KeyManager.getRealValue(key)+SEPERATOR+list_element.getValue();
			
			//return only top values
			if(i<sortedValuesCount)
			{
				top_values.add(seperated_values);
			}

			i++;
		}

		return top_values;
	}

	public static Hashtable<String, Hashtable<String,Integer> > generateTestHistoryReportForPastNRuns(int no_of_past_runs_to_be_considered) throws SQLException,JSONException,ClassNotFoundException
	{
		Hashtable<String,Integer> passed_count=new Hashtable<String,Integer>();
		Hashtable<String,Integer> skipped_count=new Hashtable<String,Integer>();
		Hashtable<String,Integer> failed_count=new Hashtable<String,Integer>();
		Hashtable<String,Integer> inconsistent_meter_value=new Hashtable<String,Integer>();

		String query="SELECT * FROM "+BuildUpdateSQLUtil.TABLE_NAME+" ORDER BY id DESC limit 50";

		Connection conn=BuildUpdateSQLUtil.getConnection();

		Statement stmt = conn.createStatement();

		try 
		{
			int records_considered=0;

		    ResultSet rs = stmt.executeQuery(query);

		    while (rs.next()) 
		    {
		    	try
		    	{
			    	if(rs.getString("result_json")!=null)
			    	{
				    	//get datas
				    	JSONObject result_json=new JSONObject( rs.getString("result_json") );
				    	Hashtable<String,String> result=BuildUpdateSQLUtil.getHashtable(result_json);

				    	//loop hashtable
				        Set<String> keys = result.keySet();

				        for(String key: keys)
				        {
				        	if(result.get(key).equals("pass"))
				        	{
				        		add(passed_count,key);
				        		add(inconsistent_meter_value,key);
				        	}
				        	else if(result.get(key).equals("fail"))
				        	{
				        		add(failed_count,key);
				        		subtract(inconsistent_meter_value,key);
				        	}
				        	else if(result.get(key).equals("skipped"))
				        	{
				        		add(skipped_count,key);
				        		subtract(inconsistent_meter_value,key);
				        	}
				        }

				        records_considered++;

				        if(records_considered>=no_of_past_runs_to_be_considered)
				        {
				        	break;
				        }
			    	}
		    	}
		    	catch(Exception e1)
		    	{
		    		e1.printStackTrace();
		    	}
		    }
		}
		catch(Exception e)
		{
		    stmt.close();
		    conn.close();
			e.printStackTrace();
			throw e;
		}
		finally 
		{
		    stmt.close();
		    conn.close();
		}

		Hashtable<String, Hashtable<String,Integer> > report=new Hashtable<String, Hashtable<String,Integer> > ();

		report.put("passed",passed_count);
		report.put("failed",failed_count);
		report.put("skipped",skipped_count);
		report.put("consistency",inconsistent_meter_value);

		return report;
	}

	public static JSONObject getReportAsCliqJSON(Hashtable<String, Hashtable<String,Integer> > report,int past_runs_count,String report_type,int sortedValuesCount) throws Exception
	{
		boolean isAddAll=report_type.equals("all");

		JSONObject chat_message=new JSONObject();
		JSONObject bot=new JSONObject();
		JSONObject card=new JSONObject();
		JSONArray slides=new JSONArray();
		
		bot.put("name", "Automation");
		bot.put("image", "https://www.zoho.com/salesiq/images/icon-salesiq.png");
		
		card.put("theme","1");
		
		chat_message.put("text", "*Automation "+(isAddAll?"":report_type)+" usecases history report for the past "+past_runs_count+" runs - "+CommonUtil.timestamp().split(" ")[0]+" *");
		chat_message.put("bot", bot);
		chat_message.put("card", card);
				
		if(isAddAll || report_type.contains("failed"))
		{
			ArrayList<String> failed_values=getSortedValueInfo(report.get("failed"),true,sortedValuesCount);
			slides.put(getReportTableSlideCliqObject("Top "+sortedValuesCount+" frequently failed usecases","Times Failed",failed_values,past_runs_count));
		}
		if(isAddAll || report_type.contains("skipped"))
		{
			ArrayList<String> skipped_values=getSortedValueInfo(report.get("skipped"),true,sortedValuesCount);
			slides.put(getReportTableSlideCliqObject("Top "+sortedValuesCount+" frequently skipped usecases","Times Skipped",skipped_values,past_runs_count));
		}
		if(isAddAll || report_type.contains("consistency"))
		{
			ArrayList<String> inconsistent_meter_values=getSortedValueInfo(report.get("consistency"),false,sortedValuesCount);
			slides.put(getReportTableSlideCliqObject("Top "+sortedValuesCount+" unstable usecases","Stablity Score",inconsistent_meter_values,null));
		}

		chat_message.put("slides", slides);

		return chat_message;
	}


	public static JSONObject getReportTableSlideCliqObject(String title,String count_column_name,ArrayList<String> table_values,Integer past_runs_count) throws Exception
	{
		JSONObject table=new JSONObject();
		JSONObject data=new JSONObject();
		JSONArray headers=new JSONArray();
		JSONArray rows=new JSONArray();
		
		table.put("type", "table");
		table.put("title", title);

		headers.put("Rank");
		headers.put("Key");
		headers.put("Test");
		headers.put(count_column_name);

		String percentage_column="Percentage";

		if(past_runs_count!=null)
		{
			headers.put(percentage_column);
		}
		
		data.put("headers", headers);

		int i=0;
		
		for(String table_value : table_values)
		{
			i++;

			String key=table_value.split(SEPERATOR)[0];
			String test=table_value.split(SEPERATOR)[1];
			String count=table_value.split(SEPERATOR)[2];
			
			JSONObject row=new JSONObject();
			
			row.put("Rank",i+"");
			row.put("Key",key);
			row.put("Test",test);
			row.put(count_column_name,count);

			if(past_runs_count!=null)
			{
				DecimalFormat df = new DecimalFormat(".##");

				double percentage=(( (double) (Integer.parseInt(count)) )/past_runs_count )*100;
				String rounded_percentage=df.format(percentage);
				row.put(percentage_column, ""+rounded_percentage+" %"  );				
			}
			
			rows.put(row);
		}
		
		data.put("rows",rows);
		
		table.put("data", data);
		
		return table;
	}

	public static void postEntireAutomationHistoryReportInOneMessage(int past_runs_count,String channel) throws Exception
	{
		try
		{
			Hashtable<String, Hashtable<String,Integer> > report=generateTestHistoryReportForPastNRuns(past_runs_count);

			org.json.JSONObject chat_message=getReportAsCliqJSON(report,past_runs_count,"all",15);

	        ChatUtil.sendChatMessage(chat_message.toString(),channel);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void postAutomationHistoryReport(int past_runs_count,String channel) throws Exception
	{
		try
		{
			Hashtable<String, Hashtable<String,Integer> > report=generateTestHistoryReportForPastNRuns(past_runs_count);

			org.json.JSONObject failed_chat_message=getReportAsCliqJSON(report,past_runs_count,"failed",30);
	        ChatUtil.sendChatMessage(failed_chat_message.toString(),channel);

			org.json.JSONObject skipped_chat_message=getReportAsCliqJSON(report,past_runs_count,"skipped",30);
	        ChatUtil.sendChatMessage(skipped_chat_message.toString(),channel);

			org.json.JSONObject unstable_chat_message=getReportAsCliqJSON(report,past_runs_count,"consistency",30);
	        ChatUtil.sendChatMessage(unstable_chat_message.toString(),channel);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void setReportedPostedTime()
	{
		try
		{
			String time=""+new Long(System.currentTimeMillis());
			LocalStorageUtil.set(LOCALSTORAGEKEY,time);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static boolean isReportPostedToday()
	{
		try
		{
			String time=LocalStorageUtil.get(LOCALSTORAGEKEY);
			return DateTimeUtil.isToday(time);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return false;
	}
}
