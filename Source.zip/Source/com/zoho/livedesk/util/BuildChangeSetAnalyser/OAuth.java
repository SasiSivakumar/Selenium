//$Id$
package com.zoho.livedesk.util.BuildChangeSetAnalyser;
import com.beust.testng.TestNG;

import com.zoho.qa.server.CommondMethods;

import com.zoho.qa.server.TestNGreportGen;
import com.zoho.qa.server.WebdriverApiHub;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.WebdriverTestContainer;

import com.zoho.qa.server.WebdriverTestServer;
import com.zoho.qa.server.WebdriverTestsuite;
import com.zoho.qa.server.WebdriverTestsuiteProvider;
//import com.zoho.writer.TestSuite;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;

import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;

import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import org.testng.ITestNGListener;

import org.testng.TestListenerAdapter;
import org.testng.xml.XmlClass;

import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.util.Hashtable;

import org.apache.commons.io.IOUtils;
import java.nio.charset.Charset;
import java.net.MalformedURLException;
import java.util.Iterator;
import com.zoho.livedesk.server.ConfManager;
import java.net.HttpURLConnection;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import com.zoho.livedesk.util.BuildChangeSetAnalyser.BuildUpdateSQLUtil;
import com.zoho.livedesk.client.SalesIQRestAPI.RestAPICredentialManager;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class OAuth
{
	public static final String OAUTH_API_TEMPLATE="http://localhost:9090/REST_API/getAccessToken.jsp?ClientID=<cid>&ClientSecret=<csec>&RedirectURL=<url>&RefreshToken=<rtkn>&API=https%3A%2F%2Fsalesiq.zoho.com%2Fapi%2Fv1%2F%3Cscreenname%3E%2Fchats%2F%3Cchat_id%3E";

	public static String getAccessToken(String module) throws Exception
	{
		return getAccessToken(RestAPICredentialManager.getRealValueByKey(module+"_cid"),RestAPICredentialManager.getRealValueByKey(module+"_csec"),RestAPICredentialManager.getRealValueByKey(module+"_url"),RestAPICredentialManager.getRealValueByKey(module+"_rtoken"));
	}

	public static String getAccessToken(String cid,String csec,String redirect_url,String refresh_tkn) throws Exception
	{
		String url=OAUTH_API_TEMPLATE.replace("<cid>",cid).replace("<csec>",csec).replace("<url>",redirect_url).replace("<rtkn>",refresh_tkn);
		String resp=IOUtils.toString(new URL(url), Charset.forName("UTF-8"));
		resp=resp.replace("<!--$Id$-->","").replaceAll("\n","");
		resp=resp.trim();
		return resp;
	}

	public static String sendOAuthRequest(String api_url,String accesstoken,String request_type) throws Exception
	{
		System.setProperty("http.agent", "Chrome");
		
		URL url=new URL(api_url);
		
		String resp="";
		
	    HttpURLConnection connection = (HttpURLConnection)url.openConnection();
	    connection.addRequestProperty("User-Agent", "Safari");    	
	    connection.addRequestProperty("Authorization" , "Zoho-oauthtoken "+accesstoken);
	    connection.setRequestMethod(request_type);
	    connection.connect();

	    int code = connection.getResponseCode();
	    
		BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));

	    for (String line; (line = reader.readLine()) != null;) 
	    {
	        resp=resp+line;
	    }

		return resp;
	}
}
