//$Id$
package com.zoho.livedesk.util.BuildChangeSetAnalyser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import com.mysql.jdbc.PreparedStatement;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.util.Hashtable;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.util.common.CommonUtil;

public class BuildUpdateSQLUtil 
{
	public static final String
	DB_USERNAME=ConfManager.getRealValue("sql_username"),
	DB_PASSWORD=ConfManager.getRealValue("sql_password"),
	DB_NAME="Automation",
	TABLE_NAME="buildupdate"
	;

	public static void alterTableIfRequired(Connection conn) throws SQLException
	{
		addResultColumn(conn);
	}
	
	public static void addResultColumn(Connection conn) throws SQLException
	{
		addColumnIfNotExists(conn,"result_json","MEDIUMTEXT"); 
	}

	public static void addColumnIfNotExists(Connection conn,String column_name,String column_type) throws SQLException
	{
		try
		{
			String update_statement="ALTER TABLE "+TABLE_NAME+" ADD "+column_name+" "+column_type+";";
			Statement stmt = conn.createStatement();
		    stmt.execute(update_statement);
		}
		catch(MySQLSyntaxErrorException e)
		{
			//Column already exists
			// CommonUtil.printStackTrace(e);
		}
	}

	public static void BuildUpdateDBInit() throws SQLException, ClassNotFoundException
	{
		createDatabaseIfNotExist();
		Connection conn=getConnection();
		createTableIfNotExist(conn);
		alterTableIfRequired(conn);
		conn.close();
	}

	public static void addLabel() throws SQLException, ClassNotFoundException
	{
		try
		{
			addLabel(label());
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			ChatUtil.postToAutomationDevChannel("addLabel Failed "+SalesIQAutomationExceptionHandler.getStacktrace(e));
		}
	}

	public static void setIsAutomationStarted() throws SQLException, ClassNotFoundException
	{
		try
		{
			setIsAutomationStarted(label(),true);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			ChatUtil.postToAutomationDevChannel("setIsAutomationStarted Failed "+SalesIQAutomationExceptionHandler.getStacktrace(e));
		}
	}

	public static void setIsAutomationEnded() throws SQLException, ClassNotFoundException
	{
		try
		{
			setIsAutomationEnded(label(),true);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			ChatUtil.postToAutomationDevChannel("setIsAutomationEnded Failed "+SalesIQAutomationExceptionHandler.getStacktrace(e));
		}
	}

	public static void setResult(Hashtable<String,String> result_hashtable) throws SQLException, ClassNotFoundException
	{
		try
		{
			setResult(label(),result_hashtable);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			ChatUtil.postToAutomationDevChannel("setResult Failed "+SalesIQAutomationExceptionHandler.getStacktrace(e));
		}
	}

	private static String label()
	{
		return WebdriverQAUtil.getBuildlable();
	}

	public static void addLabel(String label) throws SQLException, ClassNotFoundException
	{
		addLabel(label,null);
	}

	public static void addLabel(String label,String build_by) throws SQLException, ClassNotFoundException
	{
		if(build_by==null)
		{
			build_by="Unknown";
		}

		Connection conn=getConnection();
		if(!isLabelExists(conn,label))
		{
			addLabel(conn,label,build_by);

		}
		conn.close();
	}

	public static void setIsAutomationStarted(String label,boolean is_automation_started) throws SQLException, ClassNotFoundException
	{
		Connection conn=getConnection();
		setIsAutomationStarted(conn,label,is_automation_started);
		conn.close();
	}

	public static void setIsAutomationEnded(String label,boolean is_automation_ended) throws SQLException, ClassNotFoundException
	{
		Connection conn=getConnection();
		setIsAutomationEnded(conn,label,is_automation_ended);
		conn.close();
	}
	
	public static boolean getIsAutomationStarted(String label) throws SQLException, ClassNotFoundException
	{
		Connection conn=getConnection();
		boolean isStarted=getBooleanFromRow(conn,label,"is_automation_started");
		conn.close();
		return isStarted;
	}

	public static boolean getIsAutomationEnded(String label) throws SQLException, ClassNotFoundException
	{
		Connection conn=getConnection();
		boolean isEnded=getBooleanFromRow(conn,label,"is_automation_ended");
		conn.close();
		return isEnded;
	}

	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME,DB_USERNAME,DB_PASSWORD);
		return conn;
	}

	public static void createDatabaseIfNotExist() throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306",DB_USERNAME,DB_PASSWORD);
		
		String createDB="CREATE DATABASE IF NOT EXISTS "+DB_NAME+";";
		Statement stmt = conn.createStatement();
	    stmt.execute(createDB);
	}

	public static void createTableIfNotExist(Connection conn) throws SQLException
	{
		String createTable="CREATE TABLE IF NOT EXISTS  "+TABLE_NAME+" ( id int(10) NOT NULL AUTO_INCREMENT,label VARCHAR(200), is_automation_started BOOLEAN NOT NULL DEFAULT 0, is_automation_ended BOOLEAN NOT NULL DEFAULT 0, build_by VARCHAR(100) NOT NULL,PRIMARY KEY(label),KEY(id) );";
		Statement stmt = conn.createStatement();
	    stmt.execute(createTable);
	}
	
	public static boolean isLabelExists(Connection conn,String label) throws SQLException
	{
		label=getDBLabel(label);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM "+TABLE_NAME+" WHERE label='"+label+"';");
        boolean isEmptyResult= rs.next();
        return isEmptyResult;
  	}

	public static void addLabel(Connection conn,String label,String build_by) throws SQLException
	{
		label=getDBLabel(label);
		String insert_row="INSERT INTO "+TABLE_NAME+" (label, build_by) VALUES (?,?);";
		PreparedStatement preparedStmt = (PreparedStatement) conn.prepareStatement(insert_row);
		preparedStmt.setString(1, label);
		preparedStmt.setString(2, build_by);
		preparedStmt.executeUpdate();
	}
	
	public static void setIsAutomationStarted(Connection conn,String label,boolean is_automation_started) throws SQLException
	{
		updateBooleanInRow(conn,label,"is_automation_started",is_automation_started);
	}

	public static void setIsAutomationEnded(Connection conn,String label,boolean is_automation_ended) throws SQLException
	{
		updateBooleanInRow(conn,label,"is_automation_ended",is_automation_ended);		
	}
	
	public static boolean getIsAutomationStarted(Connection conn,String label) throws SQLException
	{
		return getBooleanFromRow(conn,label,"is_automation_started");
	}

	public static boolean getIsAutomationEnded(Connection conn,String label) throws SQLException
	{
		return getBooleanFromRow(conn,label,"is_automation_ended");
	}

	public static void setResult(String label,Hashtable<String,String> result) throws SQLException,ClassNotFoundException
	{
		Connection conn=getConnection();
		setResult(conn,label,result);
		conn.close();
	}


	public static void setResult(Connection conn,String label,Hashtable<String,String> result) throws SQLException
	{
		JSONObject json=new JSONObject(result);
		String result_json_string=json.toString();
		updateRow(conn,label,"result_json",result_json_string);		
	}


	public static Hashtable<String,String> getResult(String label) throws SQLException,JSONException,ClassNotFoundException
	{
		Connection conn=getConnection();
		Hashtable<String,String> result=getResult(conn,label);
		conn.close();
		return result;
	}
	public static Hashtable<String,String> getResult(Connection conn,String label) throws SQLException,JSONException
	{
		String result_json_string=getStringFromRow(conn,label,"result_json");
		JSONObject json=new JSONObject(result_json_string);
		return getHashtable(json);
	}

 	public static Hashtable<String,String> getHashtable(JSONObject json) throws JSONException
 	{
 		Hashtable<String,String> ht=new Hashtable<String,String>();
 		
 		Iterator<String> keys = json.keys();
 		while(keys.hasNext()) 
 		{
 		    String key = keys.next();
 		    String value=json.getString(key);
 		    ht.put(key, value);
 		}
 		
 		
 		return ht;
 	}

	public static void updateBooleanInRow(Connection conn,String label,String column_name,boolean value) throws SQLException
	{		
		updateRow(conn,label,column_name,(value?"1":"0"));
	}

	public static void updateRow(Connection conn,String label,String column_name,String value) throws SQLException
	{		
		label=getDBLabel(label);
		String update_statement="UPDATE "+TABLE_NAME+" SET "+column_name+"='"+value+"' WHERE label='"+label+"';";
		Statement stmt = conn.createStatement();
	    stmt.execute(update_statement);
	}
	
	public static boolean getBooleanFromRow(Connection conn,String label,String boolean_column_name) throws SQLException
	{
		ResultSet sql_cell=getColumn(conn,label,boolean_column_name);

		if(sql_cell==null)
		{
			return false;
		}

		return getColumn(conn,label,boolean_column_name).getBoolean(boolean_column_name);
	}

	public static String getStringFromRow(Connection conn,String label,String column_name) throws SQLException
	{
		return getColumn(conn,label,column_name).getString(column_name);
	}
	
	public static ResultSet getColumn(Connection conn,String label,String column_name) throws SQLException
	{
		if(!isLabelExists(conn,label))
		{
			return null;
		}

		label=getDBLabel(label);

        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT "+column_name+" FROM "+TABLE_NAME+" WHERE label='"+label+"';");
        rs.next();
       
        return rs;
	}

	public static String getDBLabel(String label)
	{
		return label.split("/zoho/")[1].split("/ZohoLiveSupport.zip")[0];
	}		
}
