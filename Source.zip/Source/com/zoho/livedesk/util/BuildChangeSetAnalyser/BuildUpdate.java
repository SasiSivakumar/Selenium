//$Id$
package com.zoho.livedesk.util.BuildChangeSetAnalyser;
import com.beust.testng.TestNG;

import com.zoho.qa.server.CommondMethods;

import com.zoho.qa.server.TestNGreportGen;
import com.zoho.qa.server.WebdriverApiHub;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.WebdriverTestContainer;

import com.zoho.qa.server.WebdriverTestServer;
import com.zoho.qa.server.WebdriverTestsuite;
import com.zoho.qa.server.WebdriverTestsuiteProvider;
//import com.zoho.writer.TestSuite;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;

import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;

import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import org.testng.ITestNGListener;

import org.testng.TestListenerAdapter;
import org.testng.xml.XmlClass;

import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.util.Hashtable;

import org.apache.commons.io.IOUtils;
import java.nio.charset.Charset;
import java.net.MalformedURLException;
import java.util.Iterator;
import com.zoho.livedesk.server.ConfManager;
import java.net.HttpURLConnection;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import com.zoho.livedesk.util.BuildChangeSetAnalyser.BuildUpdateSQLUtil;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.LocalStorage.LocalStorageUtil;

/*
test api call

http://localhost:9090/selenium/triggeraction?url1=http://sdtools4/dload/ZOHOLIVESUPPORT/local/1201129/changeSetReport.json&url2=http://sdtools4/dload/ZOHOLIVESUPPORT/local/1201129/buildDetails.json&select-url1=salesiq.localzoho.com&select-browser=googlechrome&buildURL=http://build/zoho/zoholivesupport/ZOHOLIVESUPPORT_REVIEWED/Apr_19_2018/ZohoLiveSupport.zip&webselect-type1=0&enable_automation=on&destination_setup=local&select-servername=salesiq

API upgrade test api call

http://localhost:9090/selenium/triggeraction?url1=http://sdtools4/dload/ZOHOLIVESUPPORT/local/1269597/changeSetReport.json&url2=http://sdtools4/dload/ZOHOLIVESUPPORT/local/1269597/buildDetails.json&select-url1=salesiq.localzoho.com&select-browser=googlechrome&buildURL=http://build/zoho/zoholivesupport/ZOHOLIVESUPPORT_REVIEWED/May_17_2018/ZohoLiveSupport.zip&webselect-type1=0&enable_automation=on&destination_setup=local&select-servername=salesiq

*/

public class BuildUpdate extends HttpServlet {

	public static final String
	CHANGESET="changeset",
	AUTHOR="author",
	DESCRIPTION="description",
	DATE="date";
	public static final int BUILD_DEPLOYED_WAIT_TIME_IN_MINS=30;
	public static final int ALLOWED_TIME_LIMIT_BETWEEN_EACH_API_CALL_IN_MINS=15;


	public static final String GET_LOCAL_BUILD_API="https://sd.csez.zohocorpin.com/rest/getLatestDeployedBuild?product=ZOHOLIVESUPPORT&bType=local&authtoken=8514d56742ab433bfd275f7c00a824d0bef3";

	public static final String START_AUTOMATION_API_TEMPLATE="http://localhost:9090/selenium/apiwebdriver?select-servername=$select-servername$&webselect-type1=$webselect-type1$&buildURL=$buildURL$&select-browser=$select-browser$&select-url1=$select-url1$&selsiqpackages=$selsiqpackages$&channelid_post_result=$channelid_post_result$&authToken_post_result=$authToken_post_result$&on_automation_success_action=$on_automation_success_action$&quickAutomation=$quickAutomation$";

	public static final String SECURITY_ERROR_API_TEMPLATE="https://hacksaw.zohosecurity.com/buildblockingapi?buildurl=$buildURL$";

	public static final String BUILD_DETAIL_SD_API_FORMAT="http://sdtools14/dload/ZOHOLIVESUPPORT/local/$build_id$/buildDetails.json";
	public static final String CHANGESET_SD_API_FORMAT="http://sdtools14/dload/ZOHOLIVESUPPORT/local/$build_id$/changeSetReport.json";
	public static final String GET_BUILD_ID="https://sd.csez.zohocorpin.com/api/IdVsUrl?pName=ZOHOLIVESUPPORT&url=$buildURL$&authtoken=8514d56742ab433bfd275f7c00a824d0bef3";

	private static boolean isAlwaysPostToChannel=false;

	private static String previousBuildURL="null";

	private static Long last_api_called_time=null;

	private static Hashtable<String,String> previous_request_hashtable=null;

	public static final String SENDER="Build Tool";

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, MalformedURLException
	{
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, MalformedURLException
	{
		logger("# Logger Session Starts");

		logRequest(request);

		if(isCalledTwiceSimultaneously(request))
		{
			return;
		}

		boolean isLocalBuild=request.getParameter("destination_setup").equals("local");
		String build_label=request.getParameter("buildURL");

		if(isLocalBuild)
		{
			try
			{
				if(build_label.contains("build/zoho") && request.getParameter("selsiqpackages")==null || request.getParameter("selsiqpackages").trim().equals(""))
				{
					BuildUpdateSQLUtil.BuildUpdateDBInit();
					BuildUpdateSQLUtil.addLabel(build_label);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				logger(e);
			}
		}

		//storing buildURL to detect API called twice
		if(build_label!=null)
		{
			previousBuildURL=build_label;
			last_api_called_time=new Long(System.currentTimeMillis());
		}

		//storing request to detect API called twice
		setPreviousRequestHashtable(request);

		final boolean isStartAutomation;

		try
		{
			isStartAutomation=(request.getParameter("enable_automation").equals("on"))?true:false;
		}
		catch(Exception e)
		{
			logger(e);
			throw e;
		}

		String buildURL=null;

		try
		{
			buildURL=request.getParameter("buildURL");
			buildURL=getBuildDownloadURL(buildURL);

			Hashtable<String,String> security_errors_info=getSecurityErrorsInfo(buildURL);

			int security_error_count=Integer.parseInt(security_errors_info.get("count"));

			if(security_error_count>0)
			{
				String report_url=security_errors_info.get("report_link");

				String message="Build "+buildURL+" contains "+security_error_count+" security issues. "+getCliqLink("view report",report_url);
				String channel=(isStartAutomation && isLocalBuild)?getMainChannel():getLogsChannel();
				postToCliq(channel,message);
				return;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger("Could not calculate security issues.");
			logger(e);
		}

		//update changeset
		try
		{
			if(isLocalBuild==false || (isLocalBuild==true && LocalStorageUtil.get("changeset_posted_for_build").contains(buildURL)==false) )
			{
				parseJSONAndPostToCliq(request);
			}
		}
		catch(Exception e)
		{
			logger(e);
			e.printStackTrace();
		}

		//start automation
		try
		{
			if(isStartAutomation)
			{
				startAutomation(request);
			}
		}
		catch(Exception e)
		{
			logger(e);
			e.printStackTrace();
		}
	}

	public static void parseJSONAndPostToCliq(HttpServletRequest request)
	{
		try
		{
			boolean isStartAutomation=(request.getParameter("enable_automation").equals("on"))?true:false;
			boolean isLocalBuild=request.getParameter("destination_setup").equals("local");
			String build_label=request.getParameter("buildURL");
			build_label=build_label.replaceAll("\\s+","");//remove spaces
			String url1=request.getParameter("url1");
			String url2=request.getParameter("url2");

			if(url1.equals("null") && url2.equals("null"))
			{
				String build_id=getBuildIds(build_label);

				logger("Build id was found as "+build_id);
				url1=CHANGESET_SD_API_FORMAT.replace("$build_id$",build_id);
				url2=BUILD_DETAIL_SD_API_FORMAT.replace("$build_id$",build_id);
			}

			String changesetMessage=null,mergesMessage=null;
			JSONObject changeSetJSON=null;
			Map changeSet=null;

			if(isLocalBuild && url1!=null)
			{
				changeSetJSON=getJSON(url1);
				changeSet=jsonToMap(changeSetJSON);

				Hashtable<String,String> contributions_by_developer=getContributionsByDeveloper(changeSet);
				changesetMessage=getChangeSetAsChatMessage(contributions_by_developer);

				Hashtable<String,String> merges_by_developer=getMergesByDeveloper(changeSet);
				mergesMessage=getChangeSetAsChatMessage(merges_by_developer);
			}
			if(isLocalBuild && url2!=null)
			{
				JSONObject buildInfoJSON=getJSON(url2);
			}

			String chat_message=getChatMessage(changeSet,isStartAutomation,request.getParameter("destination_setup"),request.getParameter("buildURL"),changesetMessage);
			String merged_info_chat_message=getChatMessage(changeSet,isStartAutomation,request.getParameter("destination_setup"),request.getParameter("buildURL"),mergesMessage);

			String channel=getBuildUpdateMessageChannel(request);

			if(chat_message.length()<2000)
			{
				postToCliq(channel,chat_message);
			}
			else if(chat_message.length()<9000)
			{
				postCollapsedMessageToCliq(channel,"Changeset for Build "+build_label,chat_message);
			}
			else
			{
				Hashtable<String,String> contributions_by_developer=getContributionsByDeveloper(changeSet);
				Hashtable<String,String> contributions_by_developer_temporary=new Hashtable<String,String>();				

		        Set<String> developer_names = contributions_by_developer.keySet();

		       	int chat_posted_changeset_count=0;

		       	int i=0;

				for(String developer_name : developer_names)
				{
					contributions_by_developer_temporary.put(developer_name, contributions_by_developer.get(developer_name) );
					changesetMessage=getChangeSetAsChatMessage(contributions_by_developer_temporary);

					if( changesetMessage.length()>9000)
					{
						//remove current value and post to chat, but retain current value
						contributions_by_developer_temporary.remove(developer_name);
						changesetMessage=getChangeSetAsChatMessage(contributions_by_developer_temporary);
						chat_posted_changeset_count++;
						String splitted_chat_message=getChatMessage(changeSet,isStartAutomation,null,request.getParameter("destination_setup"),request.getParameter("buildURL"),changesetMessage,(chat_posted_changeset_count!=1));
						postCollapsedMessageToCliq(channel,"Changeset "+chat_posted_changeset_count+" for Build "+build_label,splitted_chat_message);

						contributions_by_developer_temporary=new Hashtable<String,String>();
						contributions_by_developer_temporary.put(developer_name, contributions_by_developer.get(developer_name) );
					}
					else if(i==developer_names.size()-1)
					{
						chat_posted_changeset_count++;
						String splitted_chat_message=getChatMessage(changeSet,isStartAutomation,null,request.getParameter("destination_setup"),request.getParameter("buildURL"),changesetMessage,(chat_posted_changeset_count!=1));
						postCollapsedMessageToCliq(channel,"Changeset "+chat_posted_changeset_count+" for Build "+build_label,splitted_chat_message);						
					}

					i++;
				}
			}

			if(mergesMessage.length()>0)
			{
				postCollapsedMessageToCliq(getLogsChannel(),"Merge Changeset for Build "+build_label,merged_info_chat_message);
			}


			if(isLocalBuild)
			{
				String buildURL=request.getParameter("buildURL");
				buildURL=getBuildDownloadURL(buildURL);
				LocalStorageUtil.set("changeset_posted_for_build",buildURL);
			}
		}
		catch(Exception e)
		{
			logger(e);
			e.printStackTrace();
		}
	}

	public static String getBuildUpdateMessageChannel(HttpServletRequest request)
	{
		boolean isStartAutomation=(request.getParameter("enable_automation").equals("on"))?true:false;
		String setup=request.getParameter("destination_setup");

		if(request.getParameter("channelid_post_result")!=null && request.getParameter("channelid_post_result").trim().equals("")==false)
		{
			//to make it to use authtoken from client for posting build update messages in selected channel. (it will also be set in WebDriverApi.java also)
			WebdriverQAUtil.setChannelID(request.getParameter("channelid_post_result"));
			WebdriverQAUtil.setAuthToken(request.getParameter("authToken_post_result"));
			
			return request.getParameter("channelid_post_result");	
		}
		else if( isStartAutomation || (!setup.equals("local")) || getIsAlwaysPostToChannel())
		{
			return getMainChannel();
		}
		else
		{
			return getLogsChannel();
		}
	}

	public static String getMergedBranchesAsString(Map changeSetMap)
	{
		ArrayList<String> branches=getMergedBranches(changeSetMap);
		return CommonUtil.toCommaSeperatedString(branches);
	}

	public static ArrayList<String> getMergedBranches(Map changeSetMap)
	{
		ArrayList<HashMap> changeSetList=(ArrayList<HashMap>)changeSetMap.get("data");

		ArrayList<String> branches=new ArrayList<String>();

		for(HashMap changeSet : changeSetList)
		{
			String changeset_message_string=extractChangeSetInfo(changeSet);

			if(isMergedInfoMessage(changeset_message_string))
			{
				String branch=getBranch(changeset_message_string);

				branch=branch.toLowerCase();

				if(!branches.contains(branch))
				{
					branches.add(branch);	
				}
			}
		}

		return branches;		
	}

	public static String getBranch(String commit_message)
	{
		String branch=commit_message;
 		
 		branch=branch.replaceAll("(?i).+merge", "");
 		branch=branch.replaceAll("(?i).+with", "");
 		branch=branch.trim();
 		branch=branch.replaceAll("[^A-Za-z0-9_].+", "");
 		
 		return branch;
	}

	public static Hashtable<String,String> getContributionsByDeveloper(Map changeSetMap) throws JSONException
	{
		return getContributionsByDeveloper(changeSetMap,false);
	}

	public static Hashtable<String,String> getMergesByDeveloper(Map changeSetMap) throws JSONException
	{
		return getContributionsByDeveloper(changeSetMap,true);
	}

	public static Hashtable<String,String> getContributionsByDeveloper(Map changeSetMap,boolean isGetMergeContributionsOnly) throws JSONException
	{
		ArrayList<HashMap> changeSetList=(ArrayList<HashMap>)changeSetMap.get("data");

		Hashtable<String,String> contributions_by_developer=new Hashtable<String,String>();

		String author,changeset,description,date,changeset_info;

		for(HashMap changeSet : changeSetList)
		{
			String changeset_message_string=getCommitMessage(changeSet);

			boolean isCurrentChangesetInfoNeeded=false;

			if(isGetMergeContributionsOnly==false)
			{
				if(isMergedInfoMessage(changeset_message_string))
				{
					changeset_message_string=extractChangesFromMergeInfoMessage(changeset_message_string);
					isCurrentChangesetInfoNeeded=changeset_message_string!=null;
				}
				else
				{
					isCurrentChangesetInfoNeeded=true;
				}
			}
			else if(isGetMergeContributionsOnly==true && isMergedInfoMessage(changeset_message_string)==true)
			{
				isCurrentChangesetInfoNeeded=true;
			}

			if(isCurrentChangesetInfoNeeded)
			{
				author=(String)(changeSet.get(AUTHOR));

				changeSet.put(DESCRIPTION,changeset_message_string);
		 		changeset_message_string=extractChangeSetInfo(changeSet);

				changeset_info=null;

				if(contributions_by_developer.containsKey(author))
				{
					String existing_changeset_info=contributions_by_developer.get(author);
					contributions_by_developer.put(author,existing_changeset_info+changeset_message_string);
				}
				else
				{
					contributions_by_developer.put(author,changeset_message_string);
				}
			}
		}

		return contributions_by_developer;
	}

	public static boolean isContainsChar(String str)
	{
		//to check if string contains any vaild info. e.g. "One"-->true, "On"-->false, "*("-->false

		str=" "+str+" ";
		return str.matches(".+[A-Za-z0-9]{3}.+");
	}

	public static String extractChangesFromMergeInfoMessage(String commit_message)
	{
		String changes=null;

		boolean isCommitMessageContainsChangesetId=(" "+commit_message+" ").matches(".+[a-z0-9]{12}.+");

		if(isCommitMessageContainsChangesetId)
		{
			//cases where change is given after merge info. e.g. Merged with i18n branch - 72224 : 81fc72c4172c - Session data store rest change
			try
			{
				changes=commit_message;
		 		changes=changes.split("[a-z0-9]{12}")[1];
		 		changes=changes.replaceAll("^[^A-Za-z0-9]+ ", "");

		 		if(changes!=null && changes.trim().equals("")==false)
		 		{
		 			if(isContainsChar(changes))
		 			{
			 			return changes;
		 			}

		 		}
			}
			catch(Exception e)
			{
				// e.printStackTrace();
			}

			//cases where change is given before merge info. e.g. Security milestone changed, build updated - Merge with i18n a5f41ea9aa7a 
			try
			{
				changes=commit_message;
		 		changes=changes.split("[a-z0-9]{12}")[0];
		 		changes=changes.split("(?i)merge")[0];
		 		changes=changes.replaceAll("[^A-Za-z0-9]+$", "");

		 		if(changes!=null && changes.trim().equals("")==false)
		 		{
		 			if(isContainsChar(changes))
		 			{
			 			return changes;
		 			}
		 		}
			}
			catch(Exception e)
			{
				// e.printStackTrace();
			}
		}
		else
		{
			//cases where no changeset id is given. e.g. merged with trainee branch - markdown changes
			try
			{
				String[] message_parts=commit_message.split("-");

		 		for(String message_part : message_parts)
		 		{
					message_part=" "+message_part+" ";

		 			if(isContains(message_part,"merge")==false && message_part.matches(".+[A-Za-z0-9]{12}.+")==false && message_part.trim().equals("")==false)
		 			{
		 				changes=message_part;
		 				changes=changes.trim();


			 			if(isContainsChar(changes))
			 			{
				 			return changes;
			 			}
		 			}
		 		}
			}
			catch(Exception e)
			{
				// e.printStackTrace();
			}
		}

		return null;
	}

	public static boolean isMergedInfoMessage(String commit_message)
	{
		if(isContains(commit_message,"Merge") && isContains(commit_message,"With"))
		{
			return true;
		}

		if(isContains(commit_message,"Merge") && isContains(commit_message,"Self"))
		{
			return true;
		}

		return false;
	}

	public static boolean isContains(String str1,String str2)
	{
		return str1.toLowerCase().contains(str2.toLowerCase());
	}

	public static String getChangeSetAsChatMessage(Hashtable<String,String> contributions_by_developer)
	{
        Set<String> developers = contributions_by_developer.keySet();

        String changeset="";

        for(String developer: developers)
        {
        	changeset=changeset+"\\n\\n*Developer : "+developer+"*\\n"+contributions_by_developer.get(developer);
        }

        return changeset;
	}

	public static String extractChangeSetInfo(HashMap changeSet)
	{
		// String changeset_info="--> "+(String)(changeSet.get(DESCRIPTION))+"( changeset : "+(String)(changeSet.get(CHANGESET))+")\\n";
		String changeset_id=(String)(changeSet.get(CHANGESET));
		String changeset_link=changesetLink(changeset_id);

		String changeset_info="--> "+(String)(changeSet.get(DESCRIPTION))+" "+changeset_link+"\\n";
		return changeset_info;
	}

	public static String getCommitMessage(HashMap changeSet)
	{
		return (String)(changeSet.get(DESCRIPTION));
	}

	public static String changesetLink(String changeset_id)
	{
		String LINK_TEMPLATE="https://cmsuite.csez.zohocorpin.com/zoholivesupport/code/default/$changeset_id$";
		String changeset_link=LINK_TEMPLATE.replace("$changeset_id$",changeset_id);

		return getCliqLink("view",changeset_link);
	}

	public static String getCliqLink(String link_text,String link)
	{
		return "["+link_text+"]("+link+")";
	}

	public static String getChatMessage(Map changeSet,boolean isStartAutomation,String old_setup,String setup,String build_label,String changeset)
	{
		return getChatMessage(changeSet,isStartAutomation,old_setup,setup,build_label,changeset,false);
	}

	public static String getChatMessage(Map changeSet,boolean isStartAutomation,String old_setup,String setup,String build_label,String changeset,boolean isAppendChangeSetOnly)
	{
		String automation_status=isStartAutomation?"will be":"will NOT be";

		boolean isContainsMergeInfo=false;

		String branches="";

		if(setup.equals("local"))
		{
			branches=getMergedBranchesAsString(changeSet);
			isContainsMergeInfo=(branches.equals("")==false);			
		}


		String template=getMessageTemplate(build_label,setup,isContainsMergeInfo,isAppendChangeSetOnly);

		// build_label=build_label.replace("http://","").replace("https://","");

		template=template.replace("$setup$",setup);
		template=template.replace("$label$",build_label);
		template=template.replace("$automation_status$",automation_status);
		template=template.replace("$branches$",branches);

		if(changeset!=null)
		{
			template=template.replace("$changeset$",changeset);
		}
		if(setup.equals("local")==false && old_setup!=null)
		{
			template=template.replace("$old_setup$",old_setup);
		}

		return template;
	}

	public static String getChatMessage(Map changeSet,boolean isStartAutomation,String setup,String build_label,String changeset)
	{
		return getChatMessage(changeSet,isStartAutomation,null,setup,build_label,changeset);
	}

	public static String getMessageTemplate(String build_label,String setup,boolean isContainsMergeInfo,boolean isAppendChangeSetOnly)
	{
		// for non collapsed message
		String template=isAppendChangeSetOnly?"":"*Build $label$ updated to $setup$*";

		// for collapsed message
		// String template="\\n\\nAutomation *$automation_status$* started for this build";

		// if(setup.equals("local")==false)
		// {
		// 	template=template+"from $old_setup";
		// }

		if(setup.equals("local"))
		{
			// template=template+"\\n\\nAutomation *$automation_status$* started for this build";
			template=template+"\\n\\n";
			template=template+"*Changeset*$changeset$";

			if(isContainsMergeInfo && !isAppendChangeSetOnly)
			{
				template=template+"\\n\\n"+"Merged with $branches$";
			}
		}
		else if(setup.equals("us3_pre_production") || setup.equals("us3_pre_main") || setup.equals("us4_pre_production") || setup.equals("us4_pre_main"))
		{
			try
			{
				String automation_status="";
				boolean isStarted,isEnded;
				isStarted=BuildUpdateSQLUtil.getIsAutomationStarted(build_label);
				isEnded=BuildUpdateSQLUtil.getIsAutomationEnded(build_label);

				if(isStarted && !isEnded)
				{
					automation_status=automation_status+"\\n\\n\\n Automation was not completely executed (started but not completed) for this build";
				}
				else if(!isEnded)
				{
					//temp condition. will be removed
					automation_status=automation_status+"\\n\\n\\n Automation was not executed for this build";
				}
				// else if(!isStarted)
				// {
				// 	automation_status=automation_status+"\\n\\n\\n Automation was not executed for this build";
				// }

				template=template+automation_status;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				logger(e);
			}
		}

		return template;
	}

	public static String getCurrentBuildLabel()
	{
		try
		{
			return getJSON(GET_LOCAL_BUILD_API).getJSONArray("info").getJSONObject(0).get("CurrentUrl").toString();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger("Exception occured when trying to get current build label from local."+e.getMessage());
		}

		return "Not Found";
	}

	public static boolean waitTillBuildUpdatedInLocal()
	{
		String old_build_label=getCurrentBuildLabel();
		Long wait_start_time=new Long(System.currentTimeMillis());

		while(!isTimeout(wait_start_time) && !isBuildDeployedInLocal(old_build_label))
		{
			try
			{
				Thread.sleep(2*60*1000);
			}
			catch(Exception e)
			{

			}
		}
		return isBuildDeployedInLocal(old_build_label);
	}

	public static void startAutomation(HttpServletRequest request) throws IOException
	{
		String api=getStartAutomationAPI(request);
		sendPOST(api);
	}

	public static String getStartAutomationAPI(HttpServletRequest request)
	{
		String start_automation_api=START_AUTOMATION_API_TEMPLATE;

		//called from automation console
		if(request.getParameter("selsiqpackages")!=null)
		{
			if(request.getParameter("selsiqpackages")!=null)
			{
				start_automation_api=start_automation_api.replace("$selsiqpackages$",request.getParameter("selsiqpackages"));
			}
			if(request.getParameter("channelid_post_result")!=null)
			{
				start_automation_api=start_automation_api.replace("$channelid_post_result$",request.getParameter("channelid_post_result"));			
			}
			if(request.getParameter("authToken_post_result")!=null)
			{
				start_automation_api=start_automation_api.replace("$authToken_post_result$",request.getParameter("authToken_post_result"));
			}
			if(request.getParameter("on_automation_success_action")!=null)
			{
				start_automation_api=start_automation_api.replace("$on_automation_success_action$",request.getParameter("on_automation_success_action"));
			}
			if(request.getParameter("quickAutomation")!=null)
			{
				start_automation_api=start_automation_api.replace("$quickAutomation$",request.getParameter("quickAutomation"));
			}
			
		}
		//called from sd team api
		else
		{
			//removing unsupported params
			start_automation_api=start_automation_api.split("&selsiqpackages")[0];
		}

		start_automation_api=start_automation_api.replace("$select-url1$",request.getParameter("select-url1"));
		start_automation_api=start_automation_api.replace("$select-browser$",request.getParameter("select-browser"));
		start_automation_api=start_automation_api.replace("$buildURL$",request.getParameter("buildURL").trim());
		start_automation_api=start_automation_api.replace("$webselect-type1$",request.getParameter("webselect-type1"));
		start_automation_api=start_automation_api.replace("$select-servername$",request.getParameter("select-servername"));

		return start_automation_api;
	}

	public static boolean isTimeout(Long wait_start_time)
	{
		return isTimeout(wait_start_time,BUILD_DEPLOYED_WAIT_TIME_IN_MINS);
	}

	public static boolean isTimeout(Long wait_start_time,int time_to_wait_in_mins)
	{
		return com.zoho.livedesk.util.common.CommonUtil.isTimeout(wait_start_time,time_to_wait_in_mins);
	}

	public static boolean isBuildDeployedInLocal(String old_build_label)
	{
		if(getCurrentBuildLabel().equals(old_build_label))
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	public static String getLogsChannel()
	{
		return ConfManager.getRealValue("trigger_action_logs_channel");
	}

	public static String getMainChannel()
	{
		return ConfManager.getRealValue("channelID");	
	}

	public static void postCollapsedMessageToCliq(String channel,String title,String message)
	{
		try
		{
			ChatUtil.postCollapsedMessage(channel,title,message,SENDER);
		}	
		catch(Exception e)
		{
			System.out.println("~~Failed to post message-->\n"+message+"\n\n to channel "+channel);
			e.printStackTrace();
		}		
	}

	public static void postToCliq(String channel,String message)
	{
		try
		{
			ChatUtil.postToCliq(message,SENDER,channel);
		}	
		catch(Exception e)
		{
			System.out.println("~~Failed to post message-->\n"+message+"\n\n to channel "+channel);
			e.printStackTrace();
		}	
	}

	public static void postToMainChannel(String message)
	{
		postToCliq(getMainChannel(),message);
	}

	public static void logger(Exception e)
	{
		String log="Exception Occured\\n\\n"+SalesIQAutomationExceptionHandler.getStacktrace(e);
		log=log.replace("\n","\\n");
		logger(log);
	}

	public static void logger(String log)
	{
		String channel=getLogsChannel();

		if(log.contains("Exception Occured"))
		{
			channel="triggeractionupdates";
		}

		postToCliq(channel,"*Log at "+timestamp()+"*\\n\\n```"+log+"```");
	}

	public static boolean isRequestContains(HttpServletRequest request,String key)
	{
		Enumeration<String> params = request.getParameterNames(); 

		while(params.hasMoreElements())
		{
			String paramName = params.nextElement();

			if(paramName.equals(key))
			{
				return true;
			}
		}

		return false;
	}

	public static void logRequest(HttpServletRequest request)
	{
		//check all params
		try
		{
			String send_to_chat="";

			Enumeration<String> params = request.getParameterNames(); 

			while(params.hasMoreElements())
			{
				String paramName = params.nextElement();
				send_to_chat=send_to_chat+"\\n"+"Parameter Name - "+paramName+", Value - "+request.getParameter(paramName);
			}

			logger("Got the API. "+send_to_chat);
		}

		catch(Exception e)
		{
			logger(e);
			e.printStackTrace();
		}
	}

	public static void setPreviousRequestHashtable(HttpServletRequest request)
	{
		previous_request_hashtable=getRequestAsHashtable(request);
	}

	public static Hashtable<String,String> getRequestAsHashtable(HttpServletRequest request)
	{
		Hashtable<String,String> hashtable=new Hashtable<String,String>();

		try
		{
			Enumeration<String> params = request.getParameterNames(); 

			while(params.hasMoreElements())
			{
				String paramName = params.nextElement();
				hashtable.put(paramName,request.getParameter(paramName).toString());
			}
		}

		catch(Exception e)
		{
			logger(e);
			e.printStackTrace();
		}

		return hashtable;		
	}

	private static void sendPOST(String url) throws IOException 
	{
		String POST_URL=url;
		POST_URL=CommonUtil.encode(POST_URL);
		
		URL obj = new URL(POST_URL);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", "Mozilla/5.0");

		// // For POST only - START
		// con.setDoOutput(true);
		// OutputStream os = con.getOutputStream();
		// os.write(POST_PARAMS.getBytes());
		// os.flush();
		// os.close();
		// // For POST only - END

		int responseCode = con.getResponseCode();
		logger(url+" POST Response Code :: " + responseCode);

		if (responseCode == HttpURLConnection.HTTP_OK) 
		{ //success
			BufferedReader in = new BufferedReader(new InputStreamReader(
			con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			logger(response.toString());
		} 
		else 
		{
			logger("POST request not worked");
		}
	}

	public static String getBuildDownloadURL(String build_url)
	{
		build_url=build_url.trim();

		if(build_url.startsWith("http://")==false && build_url.startsWith("build/zoho"))
		{
			build_url="http://"+build_url;
		}

		if(build_url.endsWith("ZohoLiveSupport.zip")==false)
		{
			if(build_url.endsWith("/"))
			{
				build_url=build_url+"ZohoLiveSupport.zip";
			}
			else
			{
				build_url=build_url+"/ZohoLiveSupport.zip";				
			}
		}

		if(!build_url.startsWith("http://") || !build_url.endsWith("ZohoLiveSupport.zip"))
		{
			logger("Build URL not formed properly. build_url:"+build_url);
		}

		return build_url;
	}


	public static void setIsAlwaysPostToChannel(boolean isAlwaysPostToChannelValue)
	{
		isAlwaysPostToChannel=isAlwaysPostToChannelValue;
	}

	public static boolean getIsAlwaysPostToChannel()
	{
		return isAlwaysPostToChannel;
	}	

	public static String timestamp()
	{
		String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		return timeStamp;
	}

	public static Hashtable<String,String> getSecurityErrorsInfo(String buildURL) throws Exception
	{
		Hashtable<String,String> security_errors=new Hashtable<String,String>();

		String api="not found";

		try
		{
			api=SECURITY_ERROR_API_TEMPLATE;
			api=api.replace("$buildURL$",buildURL);

			String accesstoken=OAuth.getAccessToken("idc_hacksaw");

			String json_resp=OAuth.sendOAuthRequest(api,accesstoken,"GET");

			JSONObject securityErrorJSON=new JSONObject(json_resp);	

			Map securityError=jsonToMap(securityErrorJSON);
			String issue_count_string=( (HashMap)securityError).get("BLOCKING_ISSUE_COUNT").toString();
			String report_link=( (HashMap)securityError).get("REPORT_LINK").toString();

			security_errors.put("count",issue_count_string);
			security_errors.put("report_link",report_link);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger("Security error api "+api);
			throw e;
		}

		return security_errors;
	}

	public static boolean isCalledTwiceSimultaneously(HttpServletRequest request)
	{
		if(last_api_called_time!=null && isTimeout(last_api_called_time,ALLOWED_TIME_LIMIT_BETWEEN_EACH_API_CALL_IN_MINS))
		{
			return false;
		}

		try
		{
			if(isSameAsPreviousRequest(request))
			{
				logger("Trigger Action API was called twice within "+ALLOWED_TIME_LIMIT_BETWEEN_EACH_API_CALL_IN_MINS+" minutes. All request parameters were the same");
				return true;
			}

			String url2=request.getParameter("url2");

			if(url2!=null && !url2.equals("null"))
			{
				JSONObject buildInfoJSON=getJSON(url2);
				String build_by=buildInfoJSON.get("build_by").toString();

				String currentBuildURL=request.getParameter("buildURL");
				boolean isSameBuildURL=(currentBuildURL!=null && previousBuildURL!=null && currentBuildURL.equals(previousBuildURL));

				if( build_by.equals("api_upgrade") && ( Util.isAutomationRunning() || isSameBuildURL ) )
				{	
					logger("Trigger Action API was called twice within "+ALLOWED_TIME_LIMIT_BETWEEN_EACH_API_CALL_IN_MINS+" minutes");
					return true;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger("Error while detecting if API was called twice");
			logger(e);
		}

		return false;
	}

	public static boolean isSameAsPreviousRequest(HttpServletRequest request)
	{
		if(previous_request_hashtable!=null)
		{
			Hashtable<String,String> current_request_hashtable=getRequestAsHashtable(request);
			return com.zoho.livedesk.util.common.CommonUtil.compareHashtable(previous_request_hashtable,current_request_hashtable,null);
		}

		return false;
	}

	public static String getBuildIds(String buildURL) throws Exception
	{
		buildURL=getBuildDownloadURL(buildURL);

		String api=GET_BUILD_ID.replace("$buildURL$",buildURL);

		JSONArray build_ids_array=getJSONArray(api);

		for(int i = 0; i < build_ids_array.length(); i++)
		{
		      JSONObject object = build_ids_array.getJSONObject(i);
		      String build_id=object.getString("build_id");
		      String url=CHANGESET_SD_API_FORMAT.replace("$build_id$",build_id);

		      if(com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(url))
		      {
		      	return build_id;
		      }
		}
		return "not_found";
	}

	//json functions
	public static String get(String url) throws MalformedURLException, IOException
	{
		return IOUtils.toString(new URL(url), Charset.forName("UTF-8"));
	}

	public static JSONObject getJSON(String url) throws MalformedURLException, IOException
	{
		try
		{
			JSONObject json = new JSONObject(get(url));
			return json;
		}
		catch(JSONException e)
		{
			logger(e);
			e.printStackTrace();
		}

		return null;
	}

	public static JSONArray getJSONArray(String url) throws MalformedURLException, IOException
	{
		try
		{
			JSONArray json = new JSONArray(get(url));
			return json;
		}
		catch(JSONException e)
		{
			logger(e);
			e.printStackTrace();
		}

		return null;
	}

	public static Map<String, Object> jsonToMap(JSONObject json) 
	{
		try
		{
		    Map<String, Object> retMap = new HashMap<String, Object>();

		    if(json != JSONObject.NULL) 
		    {
		        retMap = toMap(json);
		    }
		    return retMap;
		}
		catch(JSONException e)
		{
			logger(e);
			e.printStackTrace();
		}
		return null;
	}

	public static Map<String, Object> toMap(JSONObject object) throws JSONException 
	{
	    Map<String, Object> map = new HashMap<String, Object>();

	    Iterator<String> keysItr = object.keys();
	    while(keysItr.hasNext()) 
	    {
	        String key = keysItr.next();
	        Object value = object.get(key);

	        if(value instanceof JSONArray) {
	            value = toList((JSONArray) value);
	        }

	        else if(value instanceof JSONObject) {
	            value = toMap((JSONObject) value);
	        }
	        map.put(key, value);
	    }
	    return map;
	}

	public static List<Object> toList(JSONArray array) throws JSONException 
	{
	    List<Object> list = new ArrayList<Object>();
	    for(int i = 0; i < array.length(); i++) 
	    {
	        Object value = array.get(i);
	        if(value instanceof JSONArray) 
	        {
	            value = toList((JSONArray) value);
	        }

	        else if(value instanceof JSONObject) 
	        {
	            value = toMap((JSONObject) value);
	        }
	        list.add(value);
	    }
	    return list;
	}
}
