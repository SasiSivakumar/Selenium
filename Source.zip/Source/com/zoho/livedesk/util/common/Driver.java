//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.ArrayList;

import org.openqa.selenium.*;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;


public class Driver
{
    public static String downloadFolder;

    public static String synchronized_variable = new String();

    public static ArrayList<WebDriver> drivers;
    public static int drivers_count;

    public static void initializeDriverList()
    {
        drivers=new ArrayList<WebDriver>();
        drivers_count = 0;
    }

    public static WebDriver setUp(boolean mac) throws Exception
    {
        DesiredCapabilities capability=null;

        capability= DesiredCapabilities.chrome();

        capability.setBrowserName("chrome");
                
        String url = "http://localhost:4444/wd/hub";

//        if(mac)
//        {
//            capability.setCapability(CapabilityType.PLATFORM,"MAC");
//        }

        WebDriver driver = new RemoteWebDriver(new URL(url), capability);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        Point targetPosition = new Point(0, 0);
        driver.manage().window().setPosition(targetPosition);

        Dimension targetSize = new Dimension(2560,1440);
//        Dimension targetSize = new Dimension(1440,900);
        //Imac - 2560*1440  Mac - 1440*900
        
        driver.manage().window().setSize(targetSize);

        return driver;
    }

    public static WebDriver getMacDriver() throws Exception
    {
        return getDriver( getMacCapablities() );
    }

    public static WebDriver getLinuxDriver() throws Exception
    {
        return getDriver( getLinuxCapablities() );
    }

    public static DesiredCapabilities getMacCapablities()
    {
        DesiredCapabilities capability=getCapabilities();
        capability.setPlatform(Platform.MAC);
        return capability;
    }

    public static DesiredCapabilities getLinuxCapablities()
    {
        DesiredCapabilities capability=getCapabilities();
        capability.setPlatform(Platform.LINUX);
        return capability;
    }

    public static WebDriver getDriver(Boolean mac) throws Exception
    {
        return getDriver( getCapabilities() );
    }

    public static WebDriver getDriver() throws Exception
    {
        return getDriver(true);
    }

    public static WebDriver getDriver(DesiredCapabilities capability) throws Exception
    {
        return getDriver(capability,false);
    }

    public static WebDriver getCleanupDriver() throws Exception
    {
        return getDriver(getCapabilities(),true);
    }

    public static WebDriver getDriver(DesiredCapabilities capability,boolean isForceGetDriver) throws Exception
    {
        if(!isForceGetDriver && SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
        {
            throw new ZohoSalesIQRuntimeException("Automation was stopped due to reason : "+SalesIQAutomationExceptionHandler.getReasonForStopping());
        }
                
        String url = "http://localhost:4444/wd/hub";

        WebDriver driver=null;

        //try for 10 times at 2 second intervals till driver object is obtained
        for(int i=0;i<10;i++)
        {
            try
            {
                drivers_count++;
                driver=new RemoteWebDriver(new URL(url), capability);
                break;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                com.zoho.livedesk.util.common.CommonUtil.sleep(2000);
            }
            driver.quit();
        }
         

        drivers.add(driver);

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        Point targetPosition = new Point(0, 0);
        driver.manage().window().setPosition(targetPosition);

        Dimension targetSize = new Dimension(2560,1440);
        // Dimension targetSize = new Dimension(1680,1440);
        
        driver.manage().window().setSize(targetSize);


        return driver;
    }

    public static int getDriversCount()
    {
        return drivers_count;
    }

    public static String getDownloadFolder()
    {
        return downloadFolder;
    }

    public static DesiredCapabilities getCapabilities()
    {
        downloadFolder = com.zoho.livedesk.client.TakeScreenshot.getBuildLabel();

        String downloadFilepath="./downloads/"+getDownloadFolder();
 
        HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
         
        chromePrefs.put("profile.default_content_settings.popups", 0);
        chromePrefs.put("download.default_directory", downloadFilepath);
        ChromeOptions options = new ChromeOptions();
 
        HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
        options.setExperimentalOption("prefs", chromePrefs);
        options.addArguments("--test-type");

        DesiredCapabilities capability=null;

        capability= DesiredCapabilities.chrome();

        capability.setBrowserName("chrome");

        capability.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
        capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        capability.setCapability(ChromeOptions.CAPABILITY, options);

        return capability;
    }

    public static DesiredCapabilities getPageLoadStrategyCapabilities()
    {
        DesiredCapabilities capability=getCapabilities();
        capability.setCapability("pageLoadStrategy", "none");
        return capability;
    }


    // public static WebDriver getDriver(Boolean mac) throws Exception
    // {
    //     DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    //     Date dateobj = new Date();
    //     String driverGetTime = df.format(dateobj);

    //     WebDriver driver = testIt(true,mac);

    //     if(driver == null)
    //     {
    //         dateobj = new Date();
    //         String driverReturnTime = df.format(dateobj);
    //         System.out.println("<><> Error while getting driver <><> "+driverGetTime+"<><>"+driverReturnTime);
    //     }

    //     drivers.add(driver);

    //     return driver;
    // }

    public static class Thread_Class extends Thread
    {
        private WebDriver driver = null;
        private Boolean mac = false;

        Thread_Class()
        {

        }
        Thread_Class(Boolean mac)
        {
            this.mac = mac;
        }

        public void run()
        {
            try
            {
                driver = setUp(mac);
            }
            catch (Exception e)
            {}
        }

        public WebDriver getValue()
        {
            return driver;
        }
    }

    public static WebDriver testIt(boolean another,Boolean mac) throws Exception
    {
        synchronized(synchronized_variable)
        {
            WebDriver driver = null;

            Thread_Class obj = new Thread_Class(mac);

            int count = 0;

            obj.start();
            for(;;)
            {
                if(obj.getValue() != null)
                {
                    driver = obj.getValue();
                    break;
                }
                if(count++ > 30)
                {
                    stopThread(obj);
                    if(another)
                    {
                        return testIt(false,mac);
                    }
                    else
                    {
                        return null;
                    }
                }
                Thread.sleep(1000);
            }

            return driver;
        }
    }

    public static void stopThread(Thread_Class e) throws Exception
    {
        Method m = Thread.class.getDeclaredMethod( "stop0" , new Class[]{Object.class} );
        m.setAccessible( true );
        m.invoke( e , new ThreadDeath() );
    }

    public static void closeAllDriversOpenedDuringAutomation()
    {
        // System.out.println("~~~~Driver Stats of Current Run ");
        // closeAllDriversFromHashtable(drivers);
        CloseAllOpenDrivers.close();
    }

    public static boolean hasQuit(WebDriver driver) 
    {
        try
        {
            return ((RemoteWebDriver)driver).getSessionId() == null;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        //if exception thrown driver object is not valid, so it must have been closed
        return true;
    }

    public static void closeAllDriversFromHashtable(ArrayList<WebDriver> drivers)
    {
        int driver_count=drivers.size();
        int open_drivers_count=0;

        try
        {
            for(WebDriver driver: drivers)
            {
                try
                {
                    if(!Driver.hasQuit(driver))
                    {
                        open_drivers_count++;
                        quitDriver(driver);
                    }
                }
                catch(Exception e1)
                {

                }
            }
        }
        catch(Exception e2)
        {

        }

        System.out.println("----------Driver Stats---------");
        System.out.println("Total Drivers Opened : "+driver_count);
        System.out.println("Total Drivers Closed : "+(driver_count-open_drivers_count));
        System.out.println("Total Drivers Not Closed : "+open_drivers_count);
    }

    public static void quitDriver(WebDriver driver)
    {
        try
        {
            if(driver!=null)
            {
               if(driver.getCurrentUrl().contains("salesiq"))
               {
                    try
                    {
                        Functions.logout(driver);   
                    }
                    catch(Exception e)
                    {

                    }
               }
               driver.quit(); 
            }
        }
        catch(Exception e1)
        {
            e1.printStackTrace();
        }
    }

    public static boolean isMacOS(WebDriver driver)
    {
        return !isLinuxOS(driver);
    }

    public static boolean isLinuxOS(WebDriver driver)
    {
        return getOS(driver).contains("LINUX");
    }

    public static String getOS(WebDriver driver)
    {
        Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
        String os=cap.getPlatform().toString();
        return os;
    }
}
