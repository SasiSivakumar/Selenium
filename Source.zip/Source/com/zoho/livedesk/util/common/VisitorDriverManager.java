//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.ArrayList;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;



public class VisitorDriverManager
{
    public Boolean isLinuxDriver=false;

    public VisitorDriverManager()
    {
        this(false);
    }

    public VisitorDriverManager(boolean isLinuxDriver)
    {
        this.isLinuxDriver = Boolean.valueOf(isLinuxDriver);
    }

    public VisitorDriverManager(Boolean isLinuxDriver)
    {
        this.isLinuxDriver=isLinuxDriver;
    }

    public Hashtable<String,Set<WebDriver>> visitor_drivers_by_portal = new Hashtable();

    public WebDriver getDriver(String portalname,boolean isCloseAllOtherDrivers) throws Exception
    {
        WebDriver visitor_driver=null;

        if(isLinuxDriver == null)
        {
            visitor_driver = Driver.getMacDriver();
        }
        else if(isLinuxDriver)
        {
            visitor_driver=Driver.getLinuxDriver();
        }
        else
        {
            visitor_driver=Driver.getDriver();
        }

        if(isCloseAllOtherDrivers)
        {
            closeAllDrivers(portalname);
        }

        if(visitor_drivers_by_portal.get(portalname)==null)
        {
            visitor_drivers_by_portal.put(portalname,new HashSet());
        }

        visitor_drivers_by_portal.get(portalname).add(visitor_driver);

        return visitor_driver;
    }

    public WebDriver getDriver(String portal) throws Exception
    {
        return getDriver(portal,true);
    }


    public WebDriver getDriver(WebDriver agent_driver,boolean isCloseAllOtherDrivers) throws Exception
    {
        String portal=ExecuteStatements.getPortal(agent_driver);
        return getDriver(portal,isCloseAllOtherDrivers);
    }

    public WebDriver getDriver(WebDriver agent_driver) throws Exception
    {
        String portal=ExecuteStatements.getPortal(agent_driver);
        return getDriver(portal);
    }

    public WebDriver getDriver() throws Exception
    {
        return getDriver("anonyomous");
    }


    public void closeAllDrivers(String portalname)
    {
        if(visitor_drivers_by_portal.get(portalname)==null)
        {
            return;
        }

        for(WebDriver visitor_driver : visitor_drivers_by_portal.get(portalname))
        {
            try
            {
                visitor_driver.quit();
            }
            catch(Exception e){}
        }
    }

    public void terminateAllDriverSessions()
    {
        Set<String> portals = visitor_drivers_by_portal.keySet();
        for(String portal : portals)
        {
            closeAllDrivers(portal);
        }
    }
}
