//$Id$
package com.zoho.livedesk.util.common;

import java.util.*;
import java.io.*;
import com.zoho.livedesk.util.Util;
import org.openqa.selenium.WebDriver;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.server.ConfManager;
import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;

public class RunChat
{
	public static void runChatNTimes()
	{
		/* This module is used for running chat a N number of times
		/* This is mainly created to initiate and end N number of chats
		/* in cases where we need to attain certain amount of chats to
		/* test the limit reached. Mainly created for checking the 
		/* free portal limit reach.
		/* To call this module, follow the procedure
		/* --> Open the console and give the deploy URL and build Label
		/* --> Now, click Show Other Options
		/* --> Option to run N chats will be displayed. Click the checkbox
		/* --> Now enter the login credentials for the portal you want to run N chats
		/* --> Also enter the number of times (N) the chat has to be initiated
		/* 
		/* #MA
		*/
		try
		{
			int failcount = 0;
			String runChatEmail = Util.getRunChatEmail();
			String runChatPwd = Util.getRunChatPwd();
			String runChatTimes = Util.getRunChatTimes();

			if(runChatEmail != null && runChatPwd != null && runChatTimes != null)
			{
				changeConfFile(runChatEmail,runChatPwd,runChatTimes);
			}

			int n = Integer.parseInt(ConfManager.getRealValue("runChat_times"));
			ExtentTest etest = ComplexReportFactory.getEtest("Running chat for "+n+" times","RUN CHAT");
			WebDriver driver = Functions.setUp();
			WebDriver visitor_driver = Functions.setUp();
			Functions.login(driver,"runChat");
			String widget_code = ExecuteStatements.getWidgetCode(driver);
			for(int i = 0; i < n; i++)
			{
				String label = CommonUtil.getUniqueMessage();
				try
				{
					VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.COMPLETED);
				}
				catch(Exception e)
				{
					CommonUtil.doNothing();
					failcount++;
				}
			}
			Functions.logout(driver);
			driver.quit();
			visitor_driver.quit();
			etest.info("<b style=\"color:red;\">Chats Initiated = "+(n - failcount)+"</b>");
			etest.info("<b style=\"color:green;\">SUCCESS</b>");
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			CommonUtil.print("Exception occurred in run chat ");
			CommonUtil.printStackTrace(e);
			CommonUtil.doNothing();
		}
	}

	public static void changeConfFile(String runChatUsername,String runChatPwd,String runChatTimes)
	{
		try
		{
			String[] keysToChange = {"runChat_username","runChat_password","runChat_times"};
			String[] valuesToReplace = {runChatUsername,runChatPwd,runChatTimes};
			
			String serverconf = WebdriverQAUtil.getAttachmentPath("livedeskconf.properties");
			serverconf = serverconf.replace("null","salesiq");

			File livedeskPropFile = new File(serverconf);
			int i = 0;
			Scanner sc = new Scanner(livedeskPropFile); 
			String[] line = new String[1023];
			while(sc.hasNextLine())
			{
				line[i] = sc.nextLine();
				for(int itr = 0; itr < keysToChange.length; itr++)
				{
					if(line[i].startsWith(keysToChange[itr]))
					{
						line[i] = line[i].substring( 0, line[i].indexOf(keysToChange[itr]) + keysToChange[itr].length()+1 ) + valuesToReplace[itr];
						break;
					}
				}
				i++;
			}
			
			FileWriter writer = new FileWriter(livedeskPropFile);
			BufferedWriter writeToFile = new BufferedWriter(writer);
			for(int j = 0; j < i ; j++)
			{
				writeToFile.write(line[j]+"\n");
			}

			writeToFile.close();
			sc.close();
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}
}
