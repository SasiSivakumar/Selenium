//$Id$
package com.zoho.livedesk.util.common;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;
import com.zoho.livedesk.client.crmplus.others.CRMPlusDialog;
import com.zoho.livedesk.client.crmplus.chats.CRMPChatWindow;

public class CRMPlusCommonUtil
{

	public static By
	customizeHeader = By.id("customizeheader"),
	visitsDiv = By.id("visits_div"),
	visitorsOnlineTab = By.id("crmpluscommonui_salesiq_tracking"),
	visitorsHistoryTab = By.id("crmpluscommonui_salesiq_visits"),
	myChatsTab = By.id("crmpluscommonui_salesiq_mycurrent"),
	missedTab = By.id("crmpluscommonui_salesiq_missed"),
	connectedTab = By.id("crmpluscommonui_salesiq_current"),
	chatHistoryTab = By.id("crmpluscommonui_salesiq_history"),
	crmContact = By.id("crmpluscommonui_crm_Contacts"),
	crmLead = By.id("crmpluscommonui_crm_Leads"),
	settings = By.id("crmpluscommonuisetupicon"),
	setupBar = By.id("crmpluscommonuisetupbar"),
	closeSettingsIcon = By.id("crmpluscommonuiclose"),
	addUser = By.id("buttonuseradd")
	;

	public static String
	visitorsOnline = "tracking",
	visitorsHistory = "visits",
	myChats = "mycurrent",
	missed = "missed",
	connected = "current",
	chatHistory = "history"
	;


	public static void switchToSalesiqFrame(WebDriver driver)
	{
		switchToFrame(driver,"salesiq");
	}

	public static void switchToFrame(WebDriver driver,String app)
	{
		String frameId = app + "LoadFrame";
		driver.switchTo().defaultContent();
		driver.switchTo().frame(CommonUtil.getElement(driver,By.id(frameId)));
	}

	public static void waitTillTabSelected(WebDriver driver,By tab)
	{
		driver.switchTo().defaultContent();
		try
		{
			CommonWait.waitTillDisplayed(driver,30,tab);
		}
		catch(Exception e)
		{
			CommonUtil.refreshPage(driver);
			try
			{
				CommonWait.waitTillDisplayed(driver,30,tab);
				CommonUtil.clickWebElement(driver,tab);
			}
			catch(Exception excep)
			{
				CommonUtil.printStackTrace(excep);
			}
		}
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,tab),"class","selected");
		switchToSalesiqFrame(driver);
	}

	public static boolean isTabSelected(WebDriver driver,By tab)
	{
		driver.switchTo().defaultContent();
		return CommonUtil.getElement(driver,tab).getAttribute("class").contains("selected");
	}

	public static void navTo(WebDriver driver,String app)
	{
		String tabId = app + "commonuileftpanelswitch";
		String frameId = app + "LoadFrame";
		
		driver.switchTo().defaultContent();

		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(tabId),By.tagName("a")));

		CommonWait.waitTillDisplayed(driver,By.id(frameId));

		switchToFrame(driver,app);
	}

	public static void clickTab(WebDriver driver,String app,String tab)
	{
		String tabId = "crmpluscommonui_"+app+"_"+tab;
		navTo(driver,app);
		driver.switchTo().defaultContent();
		try
		{
			CommonWait.waitTillDisplayed(driver,By.id(tabId));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(CommonWait.isDisplayed(driver,By.id(tabId)))
		{
			CommonUtil.clickWebElement(driver,By.id(tabId));
			waitTillTabSelected(driver,By.id(tabId));
		}
		switchToFrame(driver,app);
	}

	public static void navToSalesiq(WebDriver driver)
	{
		navTo(driver,"salesiq");
	}

	public static void navToDesk(WebDriver driver)
	{
		navTo(driver,"support");
	}

	public static void navToCRM(WebDriver driver)
	{
		navTo(driver,"crm");
	}

	public static void clickVisitorsOnline(WebDriver driver)
	{
		clickTabInSalesiq(driver,visitorsOnline);
		com.zoho.livedesk.client.crmplus.rings.CommonFunctionsTR.clickRingsView(driver);
	}

	public static void clickVisitorsHistory(WebDriver driver)
	{
		clickTabInSalesiq(driver,visitorsHistory);
	}

	public static void clickMyChats(WebDriver driver)
	{
		clickTabInSalesiq(driver,myChats);
	}

	public static void clickMissedChats(WebDriver driver)
	{
		clickTabInSalesiq(driver,missed);
	}

	public static void clickConnected(WebDriver driver)
	{
		clickTabInSalesiq(driver,connected);
	}

	public static void clickChatHistory(WebDriver driver)
	{
		clickTabInSalesiq(driver,chatHistory);
	}

	public static void clickTabInSalesiq(WebDriver driver,String tab)
	{
		clickTab(driver,"salesiq",tab);
	}

	public static void clickCRMContact(WebDriver driver)
	{
		clickTab(driver,"crm","Contacts");
	}

	public static void clickCRMLead(WebDriver driver)
	{
		clickTab(driver,"crm","Leads");
	}

	public static void clickSettings(WebDriver driver)
	{
		driver.switchTo().defaultContent();
		if(!CommonWait.isDisplayed(driver,setupBar))
		{
			CommonUtil.clickWebElement(driver,settings);
			CommonWait.waitTillDisplayed(driver,setupBar);
		}
	}

	public static void clickDept(WebDriver driver)
	{
		clickSettings(driver);
		switchToSalesiqFrame(driver);
		try
		{
			Tab.clickDept(driver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public static void closeSettings(WebDriver driver)
	{
		closeSettings(driver,"salesiq");
	}

	public static void closeSettings(WebDriver driver,String app)
	{
		driver.switchTo().defaultContent();
		if(CommonWait.isDisplayed(driver,setupBar))
		{
			CommonUtil.clickWebElement(driver,closeSettingsIcon);
			CommonWait.waitTillHidden(driver,setupBar);
		}
		switchToFrame(driver,app);
	}

	public static Hashtable initResultHashtable(Hashtable result,String startKey,int endNo)
	{
		for(int i = 1; i <= endNo; i++)
		{
			String key = startKey+i;
			result.put(key,false);
		}
		return result;
	}

	public static void clickAddOperator(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,addUser);
		driver.switchTo().defaultContent();
		CommonWait.waitTillDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG);
	}

	public static void deleteAllOperatorsExcept(WebDriver driver,ArrayList<String> exceptions)
	{
		try
		{
			CRMPlusCommonUtil.clickSettings(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			List<WebElement> list=driver.findElements(Cleanup.LIST_ROW);

	        List<String> list_ids=CommonUtil.getAttributesFromList(list,"id");

	        for(String list_id : list_ids)
	        {
	            WebElement element=CommonUtil.getElement(driver,By.id(list_id));

	            if(!Cleanup.isStringContains(element.getText(),exceptions))
	            {    
	                if(element.findElements(Cleanup.DELETE_ICONS_4).size()>0)
	                {
	                    WebElement delete=element.findElement(Cleanup.DELETE_ICONS_4);
	                    CommonUtil.inViewPort(delete);
	                    CommonUtil.mouseHoverAndClick(driver,delete);
	                    WebElement popup=HandleCommonUI.getPopupByInnerText(driver,Cleanup.DELETE_COMMON_TEXT);
	                    HandleCommonUI.clickPositivePopupButton(popup);
	                    CommonUtil.sleep(1500);        
	                }
	            }
	        }
	    }
	    catch(Exception e)
	    {
	    	CommonUtil.printStackTrace(e);
	    }
	}
}
