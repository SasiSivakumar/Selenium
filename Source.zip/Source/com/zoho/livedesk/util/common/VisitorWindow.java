//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Stack;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.util.common.actions.bots.BotsVisitorSide;
import org.openqa.selenium.JavascriptExecutor;


public class VisitorWindow
{
    public static boolean started = false;
    public static ExtentTest etest = null;
    public static Hashtable<String, Stack> last5ChatsInPortal = new Hashtable<String, Stack>();

    public static final String 
    NAME="NAME",
    EMAIL="EMAIL",
    PHONE="PHONE"
    ;

    public static final String 
    MUTE="Mute",
    UNMUTE="Unmute"
    ;

    public static final String
    MUTE_CLASS_NAME="sqico-mute",
    UNMUTE_CLASS_NAME="sqico-unmute",
    AGENT_MESSAGE_CLASS_NAME="siq-agntmsg";

    //GDPR locators
    public static final By
    GDPR_BANNER=By.id("gdprbanner"),
    GDPR_BANNER_DESCRIPTION=By.cssSelector("span[class=dib-mid]"),
    GDPR_POLICY_LINK=By.className("siq-lnmor"),
    GDPR_OK_BUTTON=By.className("siq-okbtn"),
    GDPR_DONT_TRACK_BUTTON=By.className("siq-trkbtn"),
    CURRENT_CHAT_MESSAGE_AREA=By.cssSelector(".siqembed[cwview=msgarea]"),
    CHAT_CONSENT_CONTAINER=By.id("chatconsentdiv"),
    CHAT_CONSENT_ACCEPT=By.cssSelector("[onclick*='.getChatUserConsent(1']"),
    CHAT_CONSENT_DECLINE=By.cssSelector("[onclick*='.getChatUserConsent(0']"),
    OFFLINE_CONSENT_CONTAINER=By.id("offlineconsent"),
    OFFLINE_CONSENT_CHECKBOX=By.className("sqico-chkbx"),
    OFFLINE_CONSENT_CHECKBOX_STATE_INPUT=By.id("chatconsent"),
    ATTENDER_NAME=By.id("attname"),
    ATTENDER_ABOUT_ME=By.id("attabtme"),
    DEPT_DROPDOWN_CONTAINER=By.cssSelector("[info='department']"),
    MESSAGE=By.cssSelector("[data-field='message']"),
    AGENT_MESSAGE=By.cssSelector(".siq-agntmsg[data-field='message']"),
    VISITOR_MESSAGE=By.cssSelector(".siq-visitmsg[data-field='message']"),
    VISITOR_MESSAGE_TEXT=By.className("siq-visitor-message"),
    MESSAGE_AREA=By.id("msgarea"),
    INFO_MESSAGE=By.className("siq-info-message")
    ;

    public static final int
    ONLINE=1,
    OFFLINE=-1,
    NOT_FOUND=0
    ;

	public static String getVisitorId(WebDriver driver,String portalname) throws Exception
    {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String time = sdf.format(cal.getTime());
            
        String visitorId = "Visitor id cannot be found from cookie";
        
        String cookii = "";
            
        for(int  i = 1; i <=80;i++)
        {
            cookii = "";
            
            Set<Cookie> cookies = driver.manage().getCookies();
            for(Cookie cookie : cookies)
            {
                if(cookie.getName().contains(portalname+"-_zldt"))
                 {
                     visitorId = cookie.getValue();
                     
                     System.out.println("Visitor id for portal - "+portalname+"@"+time+"<><>"+visitorId+"<><>");
                     
                     return visitorId;
                 }
                cookii += cookie;
            }
            Thread.sleep(500);
        }

        if(!started)
        {
            etest = ComplexReportFactory.getTest("Visitor Cookie");
            ComplexReportFactory.setValues(etest,"Automation","Issues");
            
            started = true;
        }
        
        etest.log(Status.FAIL,"Visitor id cannot rendered from browser at "+time+" for portal "+portalname+". Cookie at that time "+cookii);
        TakeScreenshot.screenshot(driver,etest,"VisitorWindow","GetCookie","Error");
        System.out.println("Visitor id cannot rendered from browser at "+time+" for portal "+portalname+" -Cookie at that time - "+cookii);

        return visitorId;
    }
    
    public static void initiateChatVis(WebDriver driver,String vname,String vemail,String vphone,String vques,ExtentTest etest) throws Exception
    {
        initiateChatVis(driver,vname,vemail,vphone,null,vques,etest);
    }

    public static void initiateChatVis(WebDriver driver,String vname,String vemail,String vphone,final String dept,String vques,ExtentTest etest) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            driver.switchTo().defaultContent();
            
            clickChatButton(driver);
            
            switchToChatWidget(driver);
            
            if(vname != null)
            {
                wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","name")));
                CommonUtil.elfinder(driver,"id","name").click();
                CommonUtil.elfinder(driver,"id","name").sendKeys(vname);
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("name")),vname);
            }
            if(vemail != null)
            {
                CommonUtil.elfinder(driver,"id","email").click();
                CommonUtil.elfinder(driver,"id","email").sendKeys(vemail);
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("email")),vemail);
            }
            if(vphone != null)
            {
                CommonUtil.elfinder(driver,"id","phone").click();
                CommonUtil.elfinder(driver,"id","phone").sendKeys(vphone);
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("phone")),vphone);
            }
            if(dept != null)
            {
                CommonUtil.elfinder(driver,"id","selecteddept").click();
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(!(driver.findElement(By.id("deptlist")).getAttribute("style").contains("none")))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                WebElement e = null;
                List<WebElement> depts = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","deptlist"),"tagname","ul").findElements(By.tagName("li"));
                for(WebElement d : depts)
                {
                    if(d.getText().equals(dept))
                    {
                        e = d;
                    }
                }
                e.click();
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("deptlist")).getAttribute("style").contains("none") && driver.findElement(By.id("selecteddept")).getText().equals(dept))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            if(vques != null)
            {
                CommonUtil.elfinder(driver,"id","question").click();
                CommonUtil.elfinder(driver,"id","question").sendKeys(vques);
            
                TakeScreenshot.screenshot(driver,etest,"VisitorWindow","InitiateChat","Before",0);
                
                CommonUtil.elfinder(driver,"id","btnaddvisitor").click();

                Thread.sleep(1000);
                
                TakeScreenshot.screenshot(driver,etest,"VisitorWindow","InitiateChat","After",0);
                
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(!(driver.findElement(By.id("waitingform")).getAttribute("style").contains("none")))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                driver.switchTo().defaultContent();
            }
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            System.out.println("Exception while initiating chat : "+e);
            throw e;
        }
    }

    public static void initiateChatVisTheme(WebDriver driver,String vname,String vemail,String vphone,String vques,ExtentTest etest) throws Exception
    {
        initiateChatVisTheme(driver,vname,vemail,vphone,null,vques,etest);
    }
    
    public static void initiateChatVisTheme(WebDriver driver,String vname,String vemail,String vphone,String dept,String vques,ExtentTest etest) throws Exception
    {
        initiateChatVisTheme(driver,vname,vemail,vphone,dept,vques,true,etest);
    }
    
    public static void initiateChatVisTheme(WebDriver driver,String vname,String vemail,String vphone,String dept,String vques,Boolean initiate,ExtentTest etest) throws Exception
    {
        initiateChatVisTheme(driver,vname,vemail,vphone,dept,vques,initiate,etest,true);
    }
    
    public static void initiateChatVisTheme(WebDriver driver,String vname,String vemail,String vphone,String dept,String vques,Boolean checkInitiated,ExtentTest etest,Boolean initiate) throws Exception
    {
        String portal = getPortalName(driver);
        
        if(portal.equals("Cant get portalname"))
        {
            if(!driver.getCurrentUrl().contains("index.html"))
            {
                etest.log(Status.FAIL,"Cannot get portal name");
            
                TakeScreenshot.screenshot(driver,etest,"VisitorWindow","GetPortalName","Error");
            }
        }
        else
        {
            initiateAfterThreshold(portal);
        }
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        String details = chatDetails(vname,vemail,vphone,dept,vques);
        
        if(details.equals("Error"))
        {
            etest.log(Status.FAIL,details);
        }
        else
        {
            etest.log(Status.INFO,details);
        }
        
        driver.switchTo().defaultContent();
        
        clickChatButton(driver);
        
        VisitorWindow.clickCreateChatNowFromConversationView(driver);

        switchToChatWidget(driver);

        try
        {
            CommonWait.waitTillDisplayed(driver,By.xpath(ResourceManager.getRealValue("Theme.initiatechat")));
        }
        catch(Exception e)
        {
            CommonUtil.sleep(5000); // waiting for chat window to appear completely
        }
        
        if(vname != null)
        {
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.name")).click();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.name")).clear();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.name")).sendKeys(vname);
        }
        if(vemail != null)
        {
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.email")).click();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.email")).clear();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.email")).sendKeys(vemail);
        }
        if(vphone != null)
        {
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.phone")).click();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.phone")).clear();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.phone")).sendKeys(vphone);
        }
        if(vques != null)
        {
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).click();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).clear();
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).sendKeys(vques);
        }
            
        if(dept != null && ExecuteStatements.isDepartmentDropdownExpectedToBeDisplayed(driver))
        {
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.dept")).click();

            wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("dropcontent")).getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.seldept").replace("DEPT",dept))));
            
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.seldept").replace("DEPT",dept)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("dropcontent")).getAttribute("style").contains("none"))
                        {
                            return true;
                        }
                        return false;
                    }
            });
        }
        
        TakeScreenshot.screenshot(driver,etest,"VisitorWindow","InitiateChat","Before",0);
        
        if(initiate)
        {
            CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.initiatechat")).click();
            
            Thread.sleep(500);
            
            TakeScreenshot.screenshot(driver,etest,"VisitorWindow","InitiateChat","After",0);
            
            pushValueForThreshold(portal);
        }
        
        if(checkInitiated)
        {
            if(ExecuteStatements.isBotGoingToPickupChat(driver)==false)
            {
                checkWaitingDiv(driver);
            }
            else
            {
                BotsVisitorSide.waitTillBotPicksUp(driver);
            }
        }
        
        driver.switchTo().defaultContent();
    }

    public static void sendKeysToXpathFromResourceFile(WebDriver driver,String resource_key,String keys)
    {
        String value=ResourceManager.getRealValue(resource_key);
        WebElement input=CommonUtil.getElement(driver,By.xpath(value));
        CommonUtil.sendKeysToWebElement(driver,input,keys);
    }

    public static void clickSubmit(WebDriver driver) throws Exception
    {
        String portal = getPortalName(driver);
        switchToChatWidget(driver);
        WebElement submit=CommonUtil.getElement(driver,By.xpath(ResourceManager.getRealValue("Theme.initiatechat")));

        if(submit.getAttribute("documentclick")==null)
        {
            throw new ZohoSalesIQRuntimeException("Submit button was not clickable. documentclick-->null");
        }

        submit.click(); 
    }

    public static void submitResponseAfterMissingChatWithAgent(WebDriver driver,String question) throws Exception
    {
        //use after waiting timer is ended and busy response message is displayed
        /*Warning : this method is to be used only for cases where faster execution is required. for normal use cases use VisitorWindow.initiateChatVisTheme(driver,null,null,null,null,<Response to be submitted>,false,etest,true); itself*/
        String portal = getPortalName(driver);
        switchToChatWidget(driver);
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).click();
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).sendKeys(question);
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.enter")).click();
        pushValueForThreshold(portal);        
    }
    
    public static boolean checkWaitingDiv(WebDriver driver)
    {
        switchToChatWidget(driver);
        return CommonWait.waitTillDisplayed(driver,By.xpath(ResourceManager.getRealValue("Theme.wait")));        
    }

    public static boolean isWaitingDivShown(WebDriver driver)
    {
        switchToChatWidget(driver);
        return CommonWait.isDisplayed(driver,By.id("wait_div"));          
    }
    
    public static void checkWaitingDivNotPresent(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,5,200);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("wait_div"))
                {
                    return false;
                }
                return true;
            }
        });
    }

    public static void switchToChatWidget(WebDriver driver)
    {
        driver.switchTo().defaultContent();

        if(isBotPreviewChatPage(driver))
        {
            return;
        }

        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("siqiframe"))
        {
            driver.switchTo().frame(CommonUtil.getElement(driver,By.id("siqiframe")));
        }        
        else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zlsiframe"))
        {
            driver.switchTo().frame(CommonUtil.getElement(driver,By.id("zlsiframe")));
        }
        //agent side preview check
        else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("previewframe"))
        {
            driver.switchTo().frame(CommonUtil.getElement(driver,By.id("previewframe")));      
            driver.switchTo().frame(CommonUtil.getElement(driver,By.id("siqiframe")));
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Unable to find any chat window frame.");
        }

    }

    public static boolean checkChatWidgetOffline(WebDriver driver) throws Exception
    {
        driver.switchTo().defaultContent();
        
        if(CommonUtil.getElement(driver,By.tagName("body")).getAttribute("innerHTML").contains("zsiqbtn"))
        {
            clickChatButton(driver);
            switchToChatWidget(driver);
            if(CommonUtil.getElement(driver,By.tagName("body")).getAttribute("innerText").contains("Leave a message"))
            {
                return true;
            }
            return false;
        }
        else if(CommonUtil.elfinder(driver,"tagname","body").getAttribute("innerHTML").contains("zsiq_float"))
        {
            clickCloseChatWidget(driver);
            
            driver.switchTo().defaultContent();
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));
            
            WebElement e = CommonUtil.elfinder(driver,"id","zsiq_float");
            
            if(e.getAttribute("innerHTML").contains("sqico-offline"))
            {
                wait = CommonUtil.waitreturner(driver,3,200);
                
                WebElement off = CommonUtil.elementfinder(driver,e,"classname","sqico-offline");
                
                wait.until(ExpectedConditions.visibilityOf(off));
                
                return true;
            }
            else if(e.getAttribute("innerHTML").contains("siqico-offline"))
            {
                try
                {
                    CommonWait.waitTillDisplayed(driver,By.className("siqico-offline"));
                    return true;
                }
                catch (Exception excep) 
                {
                    return false;
                }
            }
            else
            {
                if(e.getAttribute("class").contains("zsiq_off"))
                {
                    return true;
                }
            }
            
            return false;
        }
        else
        {
            clickChatButton(driver);
            switchToChatWidget(driver);
            
            if(CommonUtil.elfinder(driver,"tagname","body").getAttribute("innerHTML").contains("offelemcont"))
            {
                if(CommonUtil.elfinder(driver,"id","offelemcont") != null)
                {
                    return true;
                }
            }
            
            return false;
        }
    }

    public static void createPage(WebDriver driver,String embedname,String portalname) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","embedname").sendKeys(embedname);
        CommonUtil.elfinder(driver,"id","portalname").sendKeys(portalname);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zlscht"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));CommonUtil.sleep(5000);
        Thread.sleep(1000);
    }

    public static void createPageCampaign(WebDriver driver,String embedname,String portalname,String campaign) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html?utm_campaign="+campaign);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","embedname").sendKeys(embedname);
        CommonUtil.elfinder(driver,"id","portalname").sendKeys(portalname);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zlscht"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));CommonUtil.sleep(5000);
        Thread.sleep(1000);
    }

    public static void createPageReferrer(WebDriver driver,String embedname,String portalname) throws Exception
    {
        createPageReferrer(driver,embedname,portalname,"http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html");
    }

    public static void createPageReferrer(WebDriver driver,String embedname,String portalname,String referrer) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","embedname").sendKeys(embedname);
        CommonUtil.elfinder(driver,"id","portalname").sendKeys(portalname);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        CommonUtil.elfinder(driver,"id","referrer").sendKeys(referrer);
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zlscht"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));CommonUtil.sleep(5000);
        Thread.sleep(1000);
    }

    public static void createPage(WebDriver driver,String code) throws Exception
    {
        createPage(driver,code,true);
    }

    public static void createPage(WebDriver driver,String code,boolean isCheckDisplayed) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        for(int i = 0;i <= 2; i++)
        {
            driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html?automation_tracking_id="+CommonUtil.getUniqueId());
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
            CommonUtil.elfinder(driver,"id","code").sendKeys(code);
            CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
            Thread.sleep(1000);
            CommonUtil.elfinder(driver,"id","submit").click();

            CommonUtil.sleep(5000);

            if(isCheckDisplayed)
            {
                try
                {
                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            try
                            {
                                if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float"))
                                {
                                    return true;
                                }
                            }
                            catch(StaleElementReferenceException e){}
                            return false;
                        }
                    });
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
                }
                catch(Exception e)
                {
                    if(i == 2)
                    {
                        throw new ZohoSalesIQRuntimeException("Chat widget not found after 3 tries");
                    }
                    driver.navigate().refresh();
                    continue;
                }
                
                WebElement e1 = CommonUtil.elfinder(driver,"id","zsiq_float");
                
                wait = CommonUtil.waitreturner(driver,5,200);

                try
                {
                    wait.until(ExpectedConditions.visibilityOf(e1));
                }
                catch(Exception e)
                {
                    try
                    {
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(driver.findElement(By.className("zsiq_floatmain")).getAttribute("class").contains("zsiqfanim"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });
                        
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });
                    }
                    catch(Exception excep)
                    {
                        // System.out.println("chat widget attempt"+i);
                        if(i == 2)
                        {
                            throw new ZohoSalesIQRuntimeException("Chat widget not found after 3 tries");
                        }
                        driver.navigate().refresh();
                        continue;
                    }
                    
                    WebElement wind = CommonUtil.elfinder(driver,"classname","zls-sptwndw");
                    
                    wait.until(ExpectedConditions.visibilityOf(wind));
                    
                    Thread.sleep(1000);
                    
                    clickCloseChatWidget(driver);
                }
                
                e1 = CommonUtil.elfinder(driver,"id","zsiq_float");
                
                try
                {
                    wait.until(ExpectedConditions.visibilityOf(e1));
                    break;
                }
                catch(Exception e)
                {
                    // System.out.println("chat widget attempt"+i);
                    if(i == 2)
                    {
                        throw new ZohoSalesIQRuntimeException("Chat widget not found after 3 tries");
                    }
                    driver.navigate().refresh();
                }
            }
        }

        CommonUtil.sleep(5000);
    }

    public static void clickpreviouschathistoryicon(WebDriver driver,String code) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","code").sendKeys(code);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        System.out.println("Previouschatsiqiframe");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("showsiqchatui")));
        Thread.sleep(2000);
        CommonUtil.elfinder(driver,"id","showsiqchatui").click();
        System.out.println("Previouschatshowsiqchatui");
    }

    public static void createPageCampaign(WebDriver driver,String code,String campaign) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html?utm_campaign="+campaign);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","code").sendKeys(code);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));CommonUtil.sleep(5000);
        Thread.sleep(1000);
    }

    public static void createPageReferrer(WebDriver driver,String code) throws Exception
    {
        createPageReferrer1(driver,code,"http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html");
    }

    public static void createPageReferrer1(WebDriver driver,String code,String referrer) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","code").sendKeys(code);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        CommonUtil.elfinder(driver,"id","referrer").sendKeys(referrer);
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));CommonUtil.sleep(5000);
        Thread.sleep(1000);
    }

    public static void createPageForButton(WebDriver driver,String code) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","code").sendKeys(code);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqbtn"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiqbtn")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiqbtn")));
        
        WebElement e1 = CommonUtil.elfinder(driver,"id","siqbtndiv");
        
        wait = CommonUtil.waitreturner(driver,5,200);
        
        wait.until(ExpectedConditions.visibilityOf(e1));
        
        Thread.sleep(1500);
    }
    
    public static void createPageForPersonalized(WebDriver driver,String code) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","code").sendKeys(code);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqpersonalize"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiqpersonalize")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiqpersonalize")));
        
        WebElement e1 = CommonUtil.elfinder(driver,"id","zsiqpersonalize");
        
        wait = CommonUtil.waitreturner(driver,5,200);
        
        wait.until(ExpectedConditions.visibilityOf(e1));
        
        Thread.sleep(6000);//sleep added due to ZLS-6780
    }
    
    public static void createPageGA(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        String setup = Util.setUptracking();
        
        driver.get("https://"+setup+"zohosalesiq.blogspot.in");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        
        WebElement e1 = CommonUtil.elfinder(driver,"id","zsiq_float");
        
        wait = CommonUtil.waitreturner(driver,5,200);
        
        try
        {
            wait.until(ExpectedConditions.visibilityOf(e1));
        }
        catch(Exception e)
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zsiq_floatmain")).getAttribute("class").contains("zsiqfanim"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement wind = CommonUtil.elfinder(driver,"classname","zls-sptwndw");
            
            wait.until(ExpectedConditions.visibilityOf(wind));
            
            Thread.sleep(1000);
            
            clickCloseChatWidget(driver);
        }
        
        // e1 = CommonUtil.elfinder(driver,"id","zsiq_float");
        
        // wait.until(ExpectedConditions.visibilityOf(e1));

        try
        {
            CommonWait.waitTillDisplayed(driver,By.id("zsiq_float"));
        }
        catch(Exception e)
        {
            if(!driver.findElement(By.className("zsiq_floatmain")).getAttribute("class").contains("zsiqfanim"))
            {
                e.printStackTrace();
            }

        }
    }

    public static void sentMessage(WebDriver driver,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        switchToChatWidget(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgdiv")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("msgdiv")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lstxteditor")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lstxteditor")));
        
        CommonUtil.elfinder(driver,"id","lstxteditor").sendKeys(msg);
        CommonUtil.elfinder(driver,"id","lstxteditor").sendKeys(Keys.RETURN);
        
        driver.switchTo().defaultContent();
    }

    public static boolean checkMessageInVisitorWindow(WebDriver driver,String user,final String msg) throws Exception
    {
        return checkMessageInVisitorWindow(driver,user,msg,0);
    }
    
    public static boolean checkMessageInVisitorWindow(WebDriver driver,String user,final String msg,int i) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            switchToChatWidget(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgcntr")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("msgcntr")));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("msgcntr")).getAttribute("innerHTML").contains(msg))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Thread.sleep(500);
            
            List<WebElement> messages = CommonUtil.elfinder(driver,"id","msgcntr").findElements(By.className("agntcont"));
            
            for(WebElement e : messages)
            {
                if(e.getText().contains(user) && e.getText().contains(msg))
                {
                    driver.switchTo().defaultContent();
                    return true;
                }
            }
            
            driver.switchTo().defaultContent();
            return false;
        }
        catch(StaleElementReferenceException exp)
        {
            exp.printStackTrace();
            
            if(i == 0)
            {
                Thread.sleep(2000);
                return checkMessageInVisitorWindow(driver,user,msg,1);
            }
            
            throw exp;
        }
    }

    public static boolean waitTillMessageInChat(WebDriver driver,final String expected_text)
    {
        return waitTillMessageInChat(driver,expected_text,10);
    }

    public static boolean waitTillMessageInChat(WebDriver driver,final String expected_text,final int wait_time)
    {
        try
        {
            switchToChatWidget(driver);
        }
        catch(Exception e){}

        FluentWait wait = CommonUtil.waitreturner(driver,wait_time,250);

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(CommonUtil.getElement(driver,By.className("siqembed")).getText().toLowerCase().contains(expected_text.toLowerCase()))
                {
                    return true;
                }
                return false;
            }
        });

        return true;
    }

    public static String getChatWindowInnerText(WebDriver driver)
    {
        try
        {
            switchToChatWidget(driver);
        }
        catch(Exception e){}

        return CommonUtil.getElement(driver,By.className("siqembed")).getText();
    }

    public static void endChat(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        switchToChatWidget(driver);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("optionbtn")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("optionbtn")));
        CommonUtil.elfinder(driver,"id","optionbtn").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("options")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("endcht")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("endcht")));
        CommonUtil.elfinder(driver,"classname","endcht").click();
        
        checkChatEnded(driver);
    }
    
    public static void checkChatEnded(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        switchToChatWidget(driver);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("fltfdk_cntmn")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("fltfdk_cntmn")));
        WebElement e1 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","fltfdk_cntmn"),"id","fdbckmsg");
        WebElement e2 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","fltfdk_cntmn"),"id","ratingul");
        
        wait.until(ExpectedConditions.visibilityOf(e1));
        wait.until(ExpectedConditions.visibilityOf(e2));
        
    }
    
    public static void enterFeedback(WebDriver driver,String star,String feedbackmsg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        switchToChatWidget(driver);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submitfeedback")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submitfeedback")));
        Thread.sleep(500);
        CommonUtil.elfinder(driver,"id","submitfeedback").click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fdbckdiv")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fdbckdiv")));
        Thread.sleep(500);
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdiv"),"id","ratingul"),"xpath","//li[@class='"+star+"']//a").click();
        Thread.sleep(500);
        if(feedbackmsg != null)
        {
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdiv"),"id","sprwinact"),"id","txtmsg");
            elmt.click();
            elmt.clear();
            elmt.sendKeys(feedbackmsg);
            Thread.sleep(500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnsavefeedback")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnsavefeedback")));
            CommonUtil.elfinder(driver,"id","btnsavefeedback").click();
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("fdbksdiv"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fdbksdiv")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fdbksdiv")));
        }
    }

    public static void waitTillChatisMissed(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,80,250);
        
        switchToChatWidget(driver);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("waitingform") && driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("embedcontainer"))
                {
                    return true;
                }
                return false;
            }
        });

        final WebElement wait_div = CommonUtil.elfinder(driver,"id","waitingform");
        final WebElement timer = CommonUtil.elfinder(driver,"id","embedcontainer");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(timer.getAttribute("class").contains("timer_svgmin"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!timer.getAttribute("class").contains("timer_svgmin") && wait_div.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(2000);
    }

    public static void clickChatButton(WebDriver driver) throws Exception
    {
        for(int i = 0; i < 2; i++)
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            driver.switchTo().defaultContent();

            if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqpersonalize"))
            {
                clickChatButtonInPersonalized(driver,0);
                i = 2;
            }
            else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqbtn"))
            {
                WebElement div2 = CommonUtil.elfinder(driver,"classname","zls-sptwndw");
                
                if(!div2.getAttribute("class").contains("siqanim"))
                {
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("siqbtndiv")));
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("siqbtndiv")));
                    
                    CommonUtil.sleep(500);
                    CommonUtil.elfinder(driver,"id","siqbtndiv").click();
                    
                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                    
                    Thread.sleep(1000);
                }
                i = 2;
            }
            else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float"))
            {
                WebElement div1 = CommonUtil.elfinder(driver,"classname","zsiq_floatmain");
                WebElement div2 = CommonUtil.elfinder(driver,"classname","zls-sptwndw");

                if(!div1.getAttribute("class").contains("zsiqfanim") && !div2.getAttribute("class").contains("siqanim"))
                {
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));
                
                    CommonUtil.sleep(500);
                    // CommonWait.waitTillDisplayed(driver,By.id("zsiq_float"));
                    if(CommonWait.isDisplayed(driver,By.id("zsiq_float")))
                    {
                        CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("zsiq_float")));
                    }
                    else
                    {
                        CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("showsiqchatui")));
                    }
                    // CommonUtil.elfinder(driver,"id","zsiq_float").click();

                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.className("zsiq_floatmain")).getAttribute("class").contains("zsiqfanim")
                                && driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                            {
                                return true;
                            }
                            CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("zsiq_float")));
                            return false;
                        }
                    });

                    Thread.sleep(1000);
                }
                i = 2;
            }
            else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zls-btnmn"))
            {
                WebElement div = CommonUtil.elfinder(driver,"classname","zls-btnmn");

                if(!div.getAttribute("style").contains("none"))
                {
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zls_ctn_wrap")));
                
                    CommonUtil.sleep(500);            
                    CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();

                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.className("zls-btnmn")).getAttribute("style").contains("none"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });

                    Thread.sleep(1000);
                }
                i = 2;
            }
        }
    }
    
    public static void clickChatButtonInPersonalized(WebDriver driver, int index) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        driver.switchTo().defaultContent();
        
        WebElement div2 = CommonUtil.elfinder(driver,"classname","zls-sptwndw");
            
        if(!div2.getAttribute("class").contains("siqanim"))
        {
            if(buttonMinimizedDiv(driver))
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("zsiqmin_float")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("zsiqmin_float")));
                
                CommonUtil.elfinder(driver,"classname","zsiqmin_float").click();
            }
            else
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("startchat")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("startchat")));
                
                WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","zsiqpersonalize"),"xpath",".//div[@index='"+index+"']");
                
                CommonUtil.elementfinder(driver,e,"id","startchat").click();
            }
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Thread.sleep(1000);
        }
    }

    public static void clickCloseChatWidget(WebDriver driver) throws Exception
    {
        if(CommonWait.isPresent(driver,By.className("siqanim")))
        {
            switchToChatWidget(driver);
            WebElement close=CommonUtil.getElement(driver,By.xpath(ResourceManager.getRealValue("Theme.minimize")));
            CommonUtil.clickWebElement(driver,close);
            driver.switchTo().defaultContent();
            CommonWait.waitTillHidden(driver,By.className("siqanim"));
        }
    }

    public static boolean checkCampaignPresence(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,80,250);

        clickChatButton(driver);
        
        switchToChatWidget(driver);

        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("campaign"))
        {
            return true;
        }

        return false;
    }

    public static void clickCampaignCheckBox(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,80,250);

        clickChatButton(driver);
        
        switchToChatWidget(driver);

        CommonUtil.elfinder(driver,"id","campaign").click();
    }

    public static boolean checkCampaignPresenceInTheme(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,80,250);
        
        clickChatButton(driver);
        
        switchToChatWidget(driver);
        
        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("newsletter"))
        {
            return true;
        }
        
        return false;
    }
    
    public static void clickCampaignCheckBoxInTheme(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,80,250);
        
        clickChatButton(driver);
        
        switchToChatWidget(driver);
        
        WebElement e = CommonUtil.elfinder(driver,"classname","sqico-chkbx");
        
        wait.until(ExpectedConditions.visibilityOf(e));
        
        e.click();
    }
    
    public static String getThemeInChatWidget(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);
        
        String theme = CommonUtil.elementfinder(visDriver,CommonUtil.elfinder(visDriver,"tagname","head"),"xpath","//link[@rel='stylesheet'][@type='text/css'][contains(@href,'.css')]").getAttribute("href");
        
        visDriver.switchTo().defaultContent();
        
        return theme;
    }
    
    public static boolean checkWaitingDiv(WebDriver visDriver,boolean presence,ExtentTest etest) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        if(!presence)
        {
            for(int i = 1; i <= 10;i++)
            {
                if(CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML").contains(ResourceManager.getRealValue("Theme.wait.path")))
                {
                    if(!CommonUtil.elfinder(visDriver,ResourceManager.getRealValue("Theme.wait.by"),ResourceManager.getRealValue("Theme.wait.path")).isDisplayed())
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
                
                Thread.sleep(500);
            }
            
            return false;
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.wait"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.wait"))));
        
        String initialContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.wait")).getAttribute("innerHTML");
        
        for(int i = 1 ; i <= 3 ; i++)
        {
            Thread.sleep(1500);
            String finalContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.wait")).getAttribute("innerHTML");
            if(finalContent.equals("") || finalContent.equals(initialContent))
            {
                System.out.println("<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                etest.log(Status.FAIL,"Same Content in Waiting div<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                return false;
            }
            initialContent = finalContent;
        }
        
        return true;
    }
    
    public static boolean checkVisitorMessageInChatWindow(WebDriver driver,boolean namePresence,String name,String msg,int count) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        try
        {
            switchToChatWidget(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitormsg").replace("MSG",msg).replace("COUNT",""+count))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitormsg").replace("MSG",msg).replace("COUNT",""+count))));
            
            if(namePresence)
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitorname").replace("NAME",name).replace("COUNT",""+count))));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitorname").replace("NAME",name).replace("COUNT",""+count))));
            }
            
            driver.switchTo().defaultContent();
            return true;
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            return false;
        }
    }
    
    public static boolean checkAgentMessageInChatWindow(WebDriver driver,String user,String msg,int count) throws Exception
    {
    	if(user != null)
    	{
    		return checkAgentMessageInChatWindow(driver,true,user,msg,count);
    	}
    	else
    	{
    		return checkAgentMessageInChatWindow(driver,false,user,msg,count);
    	}
    }

    public static boolean checkAgentMessageInChatWindow(WebDriver driver,boolean userPresence,String user,String msg,int count) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        try
        {
            switchToChatWidget(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentmsg").replace("MSG",msg).replace("COUNT",""+count))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentmsg").replace("MSG",msg).replace("COUNT",""+count))));
            
            if(userPresence)
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentname").replace("NAME",user).replace("COUNT",""+count))));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentname").replace("NAME",user).replace("COUNT",""+count))));
            }
            
            driver.switchTo().defaultContent();
            return true;
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            return false;
        }
    }
    
    public static void sentMessageInTheme(WebDriver visDriver,String msg) throws Exception
    {
        sentMessageInTheme(visDriver,msg,false);
    }

    public static void typeMessage(WebDriver visDriver,String msg) throws Exception
    {
        sentMessageInTheme(visDriver,msg,null);
    }

    public static void focusMessageInput(WebDriver visDriver) throws Exception
    {
        sentMessageInTheme(visDriver,"",true);
    }

    public static void removeCharsFromTypedMessage(WebDriver visDriver,int no_of_chars) throws Exception
    {
        switchToChatWidget(visDriver);
        CommonWait.waitTillDisplayed(visDriver,By.xpath(ResourceManager.getRealValue("Theme.message")));
        WebElement message_input=CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message"));
        CommonUtil.removeCharsFromElement(message_input,no_of_chars);
        visDriver.switchTo().defaultContent();
    }

    public static void sendTypedMessage(WebDriver visDriver) throws Exception
    {
        sentMessageInTheme(visDriver,null,false);
    }

    public static void sentMessageInTheme(WebDriver visDriver,String msg,Boolean enter) throws Exception
    {
        sentMessageInTheme(visDriver,msg,enter,false);
    }
    
    public static void sentMessageInTheme(WebDriver visDriver,String msg,Boolean enter,boolean isClearInput) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        if(msg!=null)
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.message"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.message"))));
            
            CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).click();

            if(isClearInput)
            {
                CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).clear();
            }

            WebElement message_input=CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message"));

            if(enter==null)//just to type slowly at human speed, when only typing action is performed.
            {
                CommonUtil.sendKeysLikeHuman(message_input,msg);
            }
            else
            {
                message_input.sendKeys(msg);
            }
        }

        if(enter!=null)
        {
            if(enter)
            {
                CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).sendKeys(Keys.ENTER);
            }
            else
            {
                WebElement enterButton = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.enter"));
                wait.until(ExpectedConditions.visibilityOf(enterButton));
                enterButton.click();
            }
        }
                        
        visDriver.switchTo().defaultContent();
    }

    public static boolean isChatEnded(WebDriver driver)
    {
        switchToChatWidget(driver);
        return CommonWait.waitTillDisplayed(driver,By.cssSelector("[documentclick=restartchat]"));
    }
    
    public static void checkChatEndedInTheme(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.header"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.header"))));
        
        for(int i = 1; i<= 5; i++)
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT",""+i))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT",""+i))));
        }
                
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit"))));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.cancel"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.cancel"))));
        
        visDriver.switchTo().defaultContent();
    }
    
    public static void enterFeedbackInTheme(WebDriver visDriver,String fdkmsg,String star) throws Exception
    {
        enterFeedbackInTheme(visDriver,fdkmsg,star,false,null);
    }
    public static void enterFeedbackInTheme(WebDriver visDriver,String fdkmsg,String star, Boolean notCancel, ExtentTest etest) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        
        if(star==null && fdkmsg!=null)
        {
            if(visDriver.findElements(By.xpath(ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT","3"))).size()>0)
            {
                star="3";//to give some rating
            }            
        }
 
        if(star != null)
        {
            String xpath=ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT",star);

            CommonWait.waitTillDisplayed(visDriver,By.xpath(xpath));

            WebElement star_ele=CommonUtil.getElement(visDriver,By.xpath(xpath));

            CommonUtil.clickWebElement(visDriver,star_ele);
            
            if(etest != null)
            {
                String star1 = "no star";
                
                switch(star)
                {
                    case "1": star1 = "5";break;
                    case "2": star1 = "4";break;
                    case "3": star1 = "3";break;
                    case "4": star1 = "2";break;
                    case "5": star1 = "1";break;
                }
                
                etest.log(Status.INFO,star1+" is clicked");
            }
        }
        
        if(fdkmsg != null)
        {
            String xpath=ResourceManager.getRealValue("Theme.feedback.text");
            CommonWait.waitTillDisplayed(visDriver,By.xpath(xpath));

            CommonUtil.getElement(visDriver,By.xpath(xpath)).sendKeys(fdkmsg);
        }
        
        if(notCancel)
        {
            return;
        }

        else if(fdkmsg != null)
        {
            WebElement input=CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.text"));
            input.sendKeys(Keys.RETURN);
            CommonWait.waitTillHidden(input);          
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));
        
        visDriver.switchTo().defaultContent();
    }
    
    public static boolean checkEndTimer(WebDriver visDriver,int time,boolean presence,boolean waitTillEnds,ExtentTest etest) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        if(!presence)
        {
            for(int i = 1; i <= 10;i++)
            {
                if(CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML").contains(ResourceManager.getRealValue("Theme.endtimer.path")))
                {
                    if(!CommonUtil.elfinder(visDriver,ResourceManager.getRealValue("Theme.endtimer.by"),ResourceManager.getRealValue("Theme.endtimer.path")).isDisplayed())
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
                
                Thread.sleep(500);
            }
            
            return false;
        }
        
        Long t1 = new Long(System.currentTimeMillis());
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer"))));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer.timer"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer.timer"))));
        
        String contents[] = ResourceManager.getRealValue("Theme.endtimer.content").split("/");
        
        WebElement element = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endtimer"));
        
        String content = element.getText();
        
        for(String s : contents)
        {
            if(!content.contains(s))
            {
                etest.log(Status.FAIL,s+" is not present in end timer content - "+content);
                return false;
            }
        }
        
        String initialContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endtimer")).getAttribute("innerHTML");
        
        for(int i = 1 ; i <= 3 ; i++)
        {
            Thread.sleep(1500);
            
            String finalContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endtimer")).getAttribute("innerHTML");
            
            if(finalContent.equals("") || finalContent.equals(initialContent))
            {
                System.out.println("<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                etest.log(Status.FAIL,"Same Content in End Timer div<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                return false;
            }
            
            initialContent = finalContent;
        }
        
        if(waitTillEnds)
        {
            Long t2 = new Long(System.currentTimeMillis());
            
            for(int i = 1;i<=91;i++)
            {
                int diff = (int)(t2 - t1);
                
                if(diff/1000 > time)
                {
                    break;
                }
                
                Thread.sleep(1000);
                
                t2 = new Long(System.currentTimeMillis());
            }
            
            checkChatEndedInTheme(visDriver);
        }
        
        visDriver.switchTo().defaultContent();
        
        return true;
    }

    public static void waitTillChatisMissedInTheme(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,80,250);
        
        switchToChatWidget(driver);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("info_banr")).getAttribute("innerHTML").contains("wait_div"))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("info_banr")).getAttribute("innerHTML").contains("wait_div"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(1000);
    }

    public static void continueChat(WebDriver visDriver) throws Exception
    {
        continueChat(visDriver, true);
    }
    
    public static void continueChat(WebDriver visDriver, Boolean click) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));
        
        if(click)
        {
            WebElement continue_chat=CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.continuechat"));
            CommonWait.waitTillDisplayed(continue_chat);
            CommonUtil.sleep(250);
            continue_chat.click();
            CommonWait.waitTillHidden(continue_chat);
        }    
        
        visDriver.switchTo().defaultContent();
    }
    
    public static void checkOptions(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley"))));
        
        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.smiley")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley.div"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley.div"))));
        
        final WebElement smileys = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.smiley.div"));
        
        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(smileys.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.options"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.options"))));
        
        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.options")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.optionsdiv"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.optionsdiv"))));
        
        String options[] = {"mute","sentmail","print","attach"};
        
        for(String option : options)
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme."+option))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme."+option))));
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));
        
        visDriver.switchTo().defaultContent();
    }
    
    public static void checkOptionsNotPresent(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        WebElement e = CommonUtil.elfinder(visDriver,"id","moreaction");
        
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(e)));

        try
        {
            CommonWait.isDisplayed(visDriver,By.xpath(ResourceManager.getRealValue("Theme.attach")));
            throw new ZohoSalesIQRuntimeException("File sharing option found");
        }
        catch(Exception excep)
        {
            //file sharing option not found -- SUCCESS
        }
        
        visDriver.switchTo().defaultContent();
    }
    
    public static String getOptionClassname(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        WebElement e = CommonUtil.elfinder(visDriver,"id","moreaction");
        
        String classname = e.getAttribute("class");
        
        visDriver.switchTo().defaultContent();
        
        return classname;
    }

    public static void clickMoreActions(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);        
        CommonUtil.elfinder(visDriver,"id","moreaction").click();
        waitTillMoreActionDropdownIsDisplayed(visDriver,true);
    }

    public static void waitTillMoreActionDropdownIsDisplayed(WebDriver visDriver,final boolean isDisplayed)
    {
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver visDriver)
            {
                if(CommonUtil.getElement(visDriver,By.id("mraction")).getAttribute("class").contains("shwact")==isDisplayed)
                {
                    return true;
                }
                return false;
            }
        });                        
    }

    public static WebElement getActionContainerFromMoreActions(WebDriver driver,String action_name)
    {
        List<WebElement> actions=CommonUtil.getElement(driver,By.id("mraction")).findElements(By.tagName("li"));
        WebElement action=CommonUtil.getElementByAttributeValue(actions,"innerText",action_name);
        return action;
    }

    public static void chooseActionFromMoreAction(WebDriver visDriver,String action_name)
    {
        getActionContainerFromMoreActions(visDriver,action_name).click();
    }

    public static void muteChat(WebDriver driver) throws Exception
    {
        clickMoreActions(driver);
        chooseActionFromMoreAction(driver,MUTE);
        waitTillMoreActionDropdownIsDisplayed(driver,false);
    }

    public static void unmuteChat(WebDriver driver) throws Exception
    {
        clickMoreActions(driver);   
        chooseActionFromMoreAction(driver,UNMUTE);
        waitTillMoreActionDropdownIsDisplayed(driver,false);
    }

    public static boolean isChatMuted(WebDriver driver) throws Exception
    {
        WebElement muted_icon=CommonUtil.getElement(getUserActionsContainer(driver),By.className("sqico-unmute"));
        return CommonWait.isDisplayed(muted_icon);
    }

    public static WebElement getUserActionsContainer(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        return CommonUtil.getElement(driver,By.className("usractico"));
    }

    public static void uploadFile(WebDriver driver,FileType file) throws Exception
    {
        clickMoreActions(driver);
        FileUpload.uploadFile( getAttachFileInputElement(driver) , file );       
    }

    public static boolean checkFileUpload(WebDriver driver,ExtentTest etest)
    {
        return ConversationViewCommonFunctions.checkFileUpload(driver,etest);
    }

    public static boolean checkFileNotUpload(WebDriver driver,ExtentTest etest)
    {
        return ConversationViewCommonFunctions.checkFileNotUpload(driver,etest);
    }

    public static WebElement getAttachFileInputElement(WebDriver visDriver)
    {
        List<WebElement> actions=CommonUtil.getElement(visDriver,By.id("mraction")).findElements(By.tagName("li"));        
        WebElement attach_button_container=CommonUtil.getElementByAttributeValue(actions,"innerText","Attach a file");
        return attach_button_container.findElement(By.tagName("input"));
    }
    
    public static void endChatVisitor(WebDriver visDriver) throws Exception
    {
        endChatVisitor(visDriver, true);
    }
    public static void endChatVisitor(WebDriver visDriver, Boolean check) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));
        
        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endchat")).click();
        
        if(check)
        {
            checkChatEndedInTheme(visDriver);
        }
        
        visDriver.switchTo().defaultContent();
    }

    public static void checkWidgetStatus(WebDriver visDriver) throws Exception
    {
        checkWidgetStatus(visDriver,"Leave a message");
    }

    public static void checkWidgetStatus(WebDriver visDriver, final String status) throws Exception
    {
        clickChatButton(visDriver);
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("attname")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("attname")));

        wait = CommonUtil.waitreturner(visDriver,6,200);

        final WebElement e = CommonUtil.elfinder(visDriver,"id","attname");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e.getText().contains(status))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static String getAttenderName(WebDriver visDriver) throws Exception
    {
        clickChatButton(visDriver);
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("attname")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("attname")));

        return CommonUtil.elfinder(visDriver,"id","attname").getText();
    }

    public static String getInfoBannerMessage(WebDriver visDriver)
    {
        try
        {
            return visDriver.findElement(By.id("info_banr")).getText();
        }
        catch(Exception e)
        {

        }

        return "";
    }

    public static boolean waitAndCheckTillExpectedInfoMessage(final WebDriver visDriver,final String expected_text) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,10,10);

        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(getInfoBannerMessage(visDriver).contains(expected_text))
                    {
                        return true;
                    }
                    return false;
                }
            });

            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public static String getInfoMessage(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        Long t1 = new Long(System.currentTimeMillis());
        
        for(;;)
        {
            WebElement body = visDriver.findElement(By.tagName("body"));
            
            try
            {
                if(body.getAttribute("innerHTML").contains("info_banr"))
                {
                    WebElement info = CommonUtil.elementfinder(visDriver,body,"id","info_banr");
                    
                    for(;;)
                    {
                        try
                        {
                            return info.getText();
                        }
                        catch(Exception e){}
                        
                        Long t2 = new Long(System.currentTimeMillis());
                        
                        if(t2 - t1 >= 15000)
                        {
                            return "Content cant be retrieved from info banner";
                        }
                    }
                }
            }
            catch(Exception excep){}
            
            Long t2 = new Long(System.currentTimeMillis());
            
            if(t2 - t1 >= 15000)
            {
                return "Info banner not found";
            }
        }
    }

    public static String getInfoMessage(WebDriver visDriver, String infoContent) throws Exception
    {
        switchToChatWidget(visDriver);

        Long t1 = new Long(System.currentTimeMillis());
        
        for(;;)
        {
            
            try
            {
                if(visDriver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("info_banr"))
                {
                    WebElement info = visDriver.findElement(By.id("info_banr"));
                    
                    for(;;)
                    {
                        try
                        {
                            if(info.getText().contains(infoContent))
                            {
                                return info.getText();
                            } 
                        }
                        catch(Exception e){}
                        
                        Long t2 = new Long(System.currentTimeMillis());
                        
                        if(t2 - t1 >= 15000)
                        {
                            return "Content cant be retrieved from info banner";
                        }
                    }
                }
            }
            catch(Exception excep){}
            
            Long t2 = new Long(System.currentTimeMillis());
            
            if(t2 - t1 >= 15000)
            {
                return "Info banner not found with expected content";
            }
        }
    }

    public static void infoInvisible(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("info_banr"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static boolean checkWaitingTimer(WebDriver visDriver, int min, int sec) throws Exception
    {
        return checkWaitingTimer(visDriver,min,sec,0,0);
    }
    public static boolean checkWaitingTimer(WebDriver visDriver, int min, int sec, int min2, int sec2) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("wait_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wait_div")));

        String e = CommonUtil.elfinder(visDriver,"id","wait_div").getText();

        Long t1 = new Long(System.currentTimeMillis());

        for(int i = min;i >= min2 ;i--)
        {
            String emin = "";
            String esec = "";

            for(int j = sec;j >= sec2; j--)
            {
                Long t2 = new Long(System.currentTimeMillis());

                if(t2 - t1 == 4000)
                {
                    System.out.println("Infinite - here at checkWaitingTimer");
                    break;
                }

                if(i <= 9)
                {
                    emin = "0"+i;
                }
                else
                {
                    emin = ""+i;
                }
                if(j <= 9)
                {
                    esec = "0"+j;
                }
                else
                {
                    esec = ""+j;
                }

                if((emin+":"+esec+"s").equals(e))
                {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean checkMandatoryFields(WebDriver visDriver, String field) throws Exception
    {
        clickChatButton(visDriver);
        switchToChatWidget(visDriver);
        CommonWait.waitTillDisplayed(visDriver,By.id("vis"+field));
        WebElement e = CommonUtil.getElement(visDriver,By.cssSelector("div[custom="+field+"]"),By.tagName("input"));
        return isFieldInputElementMandatory(e);
    }

    public static boolean isFieldInputElementMandatory(WebElement input)
    {
        if(CommonUtil.isAttributeContainsWord(input,"data-validate","optional"))
        {
            return false;
        }
        else if(CommonUtil.isAttributeContainsWord(input,"data-validate","required"))
        {
            return true;
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid validate values --> "+input.getAttribute("data-validate"));
        }
    }
    
    public static String chatDetails(String name, String email, String phone, String dept, String question)
    {
        try
        {
            String details = "";
            
            if(name != null && !name.equals(""))
            {
                details = "Name:"+name;
            }
            if(email != null && !email.equals(""))
            {
                details = (details.equals(""))?"Email:"+email:details+", Email:"+email;
            }
            if(phone != null && !phone.equals(""))
            {
                details = (details.equals(""))?"Phone:"+phone:details+", Phone:"+phone;
            }
            if(dept != null && !dept.equals(""))
            {
                details = (details.equals(""))?"Department:"+dept:details+", Department:"+dept;
            }
            if(question != null && !question.equals(""))
            {
                details = (details.equals(""))?"Question:"+question:details+", Question:"+question;
            }
            
            if(details.equals(""))
            {
                return "Fields are empty";
            }
            
            return details;
        }
        catch(Exception e)
        {
            System.out.println("Error in chat details:");
            e.printStackTrace();
            return "Error";
        }
    }
    
    public static String getPortalName(WebDriver visDriver) throws Exception
    {
        try
        {
            visDriver.switchTo().defaultContent();
            return (((JavascriptExecutor) visDriver).executeScript("return $ZSIQWidget.getEmbedObject().screenname")).toString();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Cant get portalname";
        }
    }
    
    public static void initiateAfterThreshold(String portal) throws Exception
    {
        if(last5ChatsInPortal.get(portal) == null)
        {
            last5ChatsInPortal.put(portal, new Stack<Long>());
        }
        
        int thresholdTime = 185;
        int thresholdLimit = 5;
        
        Long current = System.currentTimeMillis();
        
        Stack<Long> stack = last5ChatsInPortal.get(portal);
        
        if(stack.size() < thresholdLimit)
        {
            return;
        }
        
        Long diff = current - (long) stack.firstElement();
        
        if(diff >= thresholdTime*1000)
        {
            if(stack.size()>0)
            {
                stack.remove(stack.firstElement());
            }
        }
        else
        {
            for(int i = 1; i<=thresholdTime; i++)
            {
                current = System.currentTimeMillis();
                
                diff = current - (long) stack.firstElement();
                
                if(diff >= thresholdTime*1000)
                {
                    if(stack.size()>0)
                    {
                        stack.remove(stack.firstElement());
                    }

                    break;
                }
                
                Thread.sleep(1000);
            }
        }
    }
    
    public static void pushValueForThreshold(String portal) throws Exception
    {
        if(last5ChatsInPortal.get(portal) == null)
        {
            last5ChatsInPortal.put(portal, new Stack<Long>());
        }
        
        Long current = System.currentTimeMillis();
        
        if(last5ChatsInPortal.get(portal).size() < 5)
        {
            last5ChatsInPortal.get(portal).push(current);
        }
        
        else
        {
            last5ChatsInPortal.get(portal).push(current);
            last5ChatsInPortal.get(portal).remove(last5ChatsInPortal.get(portal).firstElement());
        }
    }

    public static boolean checkFields(WebDriver visDriver, String field) throws Exception
    {
        clickChatButton(visDriver);
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        WebElement section = CommonUtil.elfinder(visDriver,"xpath","//section[contains(@class,'content')]");

        if(section.getAttribute("innerHTML").contains(field))
        {
            if(section.getAttribute("innerHTML").contains("vis"+field))
            {
                return true;
            }
        }

        return false;
    }

    public static String getPosition(WebDriver visDriver) throws Exception
    {
        visDriver.switchTo().defaultContent();

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));

        WebElement e = CommonUtil.elfinder(visDriver,"id","zsiq_float");

        return CommonUtil.elementfinder(visDriver,e,"xpath","..").getAttribute("class");
    }
    
    public static WebElement getCompanylogo(WebDriver visDriver) throws Exception
    {
        clickChatButton(visDriver);
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("complogo")));
        
        WebElement logo = CommonUtil.elfinder(visDriver,"id","complogo");
        
        return logo;
    }
    
    public static String getLine1InFloat(WebDriver visDriver) throws Exception
    {
        clickCloseChatWidget(visDriver);
        
        visDriver.switchTo().defaultContent();
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_maintitle")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_maintitle")));
        
        return CommonUtil.elfinder(visDriver,"id","zsiq_maintitle").getText();
    }
    
    public static String getLine2InFloat(WebDriver visDriver) throws Exception
    {
        clickCloseChatWidget(visDriver);
        
        visDriver.switchTo().defaultContent();
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_byline")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_byline")));
        
        return CommonUtil.elfinder(visDriver,"id","zsiq_byline").getText();
    }
    
    public static String getLine1InButton(WebDriver visDriver) throws Exception
    {
        visDriver.switchTo().defaultContent();
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("siqbtndiv")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("siqbtndiv")));
        
        WebElement e = CommonUtil.elfinder(visDriver,"id","siqbtndiv");
        
        return CommonUtil.elementfinder(visDriver,e,"tagname","span").getText();
    }
    
    public static String getLine2InButton(WebDriver visDriver) throws Exception
    {
        visDriver.switchTo().defaultContent();
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("siqbtndiv")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("siqbtndiv")));
        
        WebElement e = CommonUtil.elfinder(visDriver,"id","siqbtndiv");
        
        return CommonUtil.elementfinder(visDriver,e,"tagname","em").getText();
    }
    
    public static String getContentInPersonalizedStartChat(WebDriver visDriver) throws Exception
    {
        visDriver.switchTo().defaultContent();
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("startchat")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("startchat")));
        
        WebElement e = CommonUtil.elfinder(visDriver,"id","startchat");
        
        return e.getText();
    }
    
    public static Boolean buttonMinimizedDiv(WebDriver visDriver) throws Exception
    {
        visDriver.switchTo().defaultContent();
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,2,200);
        
        visDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqmin_float"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("zsiqmin_float")));
            
            final WebElement e = CommonUtil.elfinder(visDriver,"classname","zsiqmin_float");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(e.isDisplayed())
                    {
                        return true;
                    }
                    
                    return false;
                }
            });
            
            visDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            visDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            return false;
        }
    }
    
    public static List<WebElement> getPersonalizedAgentList(WebDriver visDriver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(visDriver,3,250);
        
        visDriver.switchTo().defaultContent();
        
        final WebElement div = CommonUtil.elfinder(visDriver,"id","zsiqpersonalize");
        
        if(!div.getAttribute("class").contains("siq_slide"))
        {
            CommonUtil.elementfinder(visDriver,div,"tagname","h1").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("class").contains("siq_slide"))
                    {
                        return true;
                    }
                    
                    return false;
                }
            });
            
            Thread.sleep(1000);
        }
        
        List<WebElement> list = div.findElements(By.xpath(".//div[contains(@index,'0') or contains(@index,'1') or contains(@index,'2')]"));
        
        return list;
    }
    
    public static WebElement getPersonalizedAgentDiv(WebDriver visDriver, String agent) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(visDriver,3,250);
        
        List<WebElement> list = getPersonalizedAgentList(visDriver);
        
        for(WebElement e : list)
        {
            if(CommonUtil.elementfinder(visDriver,e,"tagname","h1").getAttribute("innerHTML").equals(agent))
            {
                return e;
            }
        }
        
        final WebElement div = CommonUtil.elfinder(visDriver,"id","zsiqpersonalize");
        
        if(div.getAttribute("innerHTML").contains("perremainusr"))
        {
            CommonUtil.elementfinder(visDriver,div,"id","perremainusr").click();
            
            String s1 = div.getAttribute("innerHTML");
            
            Long t1 = new Long(System.currentTimeMillis());
            Long t2 = new Long(System.currentTimeMillis());
            
            for(;;)
            {
                String s2 = div.getAttribute("innerHTML");
                
                if(!s1.equals(s2))
                {
                    s1 = s2;
                    t2 = new Long(System.currentTimeMillis());
                }
                
                Long t3 = new Long(System.currentTimeMillis());
                
                if(t3 - t1 >= 10000)
                {
                    break;
                }
                if(t3 - t2 >= 2000)
                {
                    break;
                }
                
                Thread.sleep(500);
            }
            
            list = getPersonalizedAgentList(visDriver);
            
            for(WebElement e : list)
            {
                if(CommonUtil.elementfinder(visDriver,e,"tagname","h1").getAttribute("innerHTML").equals(agent))
                {
                    return e;
                }
            }
        }
        
        return null;
    }
    
    
    public static void sentTranscriptInMail(final WebDriver visDriver, String email) throws Exception
    {
        switchToChatWidget(visDriver);
        
        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.options"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.options"))));
        
        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.options")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.optionsdiv"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.optionsdiv"))));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.sentmail"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.sentmail"))));
        
        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.sentmail")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("smailbx")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("smailbx")));
        
        CommonWait.waitTillDisplayed(visDriver,By.id("smailbx"));
        
        WebElement div = CommonUtil.elfinder(visDriver,"id","smailbx");
        
        CommonUtil.elementfinder(visDriver,div,"tagname","input").clear();
        CommonUtil.elementfinder(visDriver,div,"tagname","input").sendKeys(email);
        
        CommonUtil.elementfinder(visDriver,div,"tagname","input").sendKeys(Keys.RETURN);

        CommonWait.waitTillDisplayed(visDriver,By.id("consentbannerdiv"));

        CommonUtil.clickWebElement(visDriver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(visDriver,By.id("consentbannerdiv")).findElements(By.className("gltr-srno")),"innerText","Yes"));
        
        getInfoMessage(visDriver);
    }

    public static void clickCreateChatNowFromConversationView(WebDriver driver)
    {
        ConversationViewCommonFunctions.clickCreateChatNowFromConversationView(driver);
    }

    public static final String
    CHAT_CONTAINER_CLASS="siqembed";

    public static WebElement getLastAttachedFileElement(WebDriver driver)
    {
        List<WebElement> names=CommonUtil.getElement(driver,By.className(CHAT_CONTAINER_CLASS)).findElements(By.className(ConversationViewConstants.ATTACHMENTS_CLASS));
        return names.get(names.size()-1);
    }

    public static boolean checkFileRecievedInVisitorSide(WebDriver driver,ExtentTest etest)
    {

        List<WebElement> attachment_element_link_elements=getLastAttachedFileElement(driver).findElements(By.tagName("a"));
        WebElement attachment_link_element=CommonUtil.getElementByAttributeValue(attachment_element_link_elements,"class",ConversationViewConstants.ATTACHMENT_ANCHOR_TAG_CLASS);       
        String attachment_link=attachment_link_element.getAttribute("href");

        int failcount=0;
        
        boolean isSuccessResponseRecieved=false;

        try
        {
            isSuccessResponseRecieved=SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(attachment_link);
        }
        catch(Exception e){}

        if(isSuccessResponseRecieved)
        {
            etest.log(Status.PASS,"Attached file was found with a valid link with 200 response code");
        }
        else
        {
            etest.log(Status.FAIL,"Attached file was NOT found with a valid link with 200 response code");
            try
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorWindow","Failure","Visitor window screenshot");
            }
            catch(Exception e2){}

            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean isURLShared(WebDriver driver,String url) throws Exception
    {
        return waitAndCheckTillExpectedInfoMessage(driver,url);
    }

    public static boolean isArticlesTabFound(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        return CommonWait.isDisplayed(driver,ArticlesVisitorSide.FAQ_TAB);
    }

    public static void submitDataInOfflineChat(WebDriver visitor_driver,String visitor_name,String visitor_mail,String visitor_phone,String visitor_question,ExtentTest etest) throws Exception
    {
        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,visitor_phone,null,visitor_question,false,etest,true);
    }

    public static void waitTillChatWindowShown(WebDriver visitor_driver)
    {
        visitor_driver.switchTo().defaultContent();
        CommonWait.waitTillDisplayed(visitor_driver,By.className("siqembed"));
    }

    public static WebElement getChatWindow(WebDriver visitor_driver) throws Exception
    {
        waitTillChatWindowShown(visitor_driver);
        return CommonUtil.getElement(visitor_driver,By.className("siqembed"));
    }

    public static boolean isChatWindowDisplayed(WebDriver visitor_driver) throws Exception
    {
        visitor_driver.switchTo().defaultContent();
        return CommonWait.waitTillDisplayed(visitor_driver,By.className("siqembed"));
    }

    public static boolean isChatWindowHidden(WebDriver visitor_driver) throws Exception
    {
        visitor_driver.switchTo().defaultContent();
        return CommonWait.waitTillHidden(visitor_driver,By.className("siqembed"));
    }

    public static boolean isCurrentChatDisplayed(WebDriver driver)
    {
        return CommonWait.waitTillDisplayed(driver,By.cssSelector(".siqembed[cwview=msgarea]"));
    }

    public static boolean clickVisitorNameInChatToEditInfo(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        WebElement visitor_name=CommonUtil.getElement(driver,By.cssSelector("[documentclick=userdetails]"));
        CommonUtil.inViewPort(visitor_name);
        CommonUtil.clickWebElement(driver,visitor_name);

        return CommonWait.waitTillDisplayed(driver,By.cssSelector("[documentclick=updateuserdetails]"));
    }

    public static Hashtable<String,String> getVisitorInfo(WebDriver driver,ExtentTest etest) throws Exception
    {
        clickVisitorNameInChatToEditInfo(driver);

        TakeScreenshot.infoScreenshot(driver,etest);

        Hashtable<String,String> visitor_info=new Hashtable<String,String>();

        visitor_info.put(NAME,CommonUtil.getElement(driver,By.id("visname")).getAttribute("value").trim());
        visitor_info.put(EMAIL,CommonUtil.getElement(driver,By.id("visemail")).getAttribute("value").trim());
        visitor_info.put(PHONE,CommonUtil.getElement(driver,By.id("visphone")).getAttribute("value").trim());
   
        updateEditedVisitorInfo(driver,false);

        return visitor_info;
    }

    public static boolean checkVisitorInfo(WebDriver driver,ExtentTest etest,String name,String email,String phone) throws Exception
    {
        Hashtable<String,String> visitor_info=getVisitorInfo(driver,etest);

        int failcount=0;

        if(name!=null && !CommonUtil.checkStringContainsAndLog(name,visitor_info.get(NAME),"visitor name",etest))
        {
            failcount++;
        }
        else if(email!=null && !CommonUtil.checkStringContainsAndLog(email,visitor_info.get(EMAIL),"visitor email",etest))
        {
            failcount++;
        }
        else if(phone!=null && !CommonUtil.checkStringContainsAndLog(phone,visitor_info.get(PHONE),"visitor phone",etest))
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean editVisitorInfo(WebDriver driver,boolean isUpdate,String name,String email,String phone) throws Exception
    {
        clickVisitorNameInChatToEditInfo(driver);

        switchToChatWidget(driver);

        editVisitorInfo(driver,By.id("visname"),name);
        editVisitorInfo(driver,By.id("visemail"),email);
        editVisitorInfo(driver,By.id("visphone"),phone);

        return updateEditedVisitorInfo(driver,isUpdate);
    }

    public static boolean updateEditedVisitorInfo(WebDriver driver,boolean isUpdate)
    {
        By button_locator=isUpdate?By.cssSelector("[documentclick=updateuserdetails]"):By.cssSelector("[documentclick=hideuserdetails]");
        WebElement button=CommonUtil.getElement(driver,button_locator);

        button.click();

        return CommonWait.waitTillHidden(button);
    }

    private static void editVisitorInfo(WebDriver driver,By locator,String value)
    {
        WebElement edit_container=CommonUtil.getElement(driver,By.id("edituserdetails"));

        // edit_container.click();//just to focus it

        if(value!=null)
        {
            WebElement input=CommonUtil.getElement(edit_container,locator);

            if(input!=null)
            {
                CommonWait.waitTillDisplayed(input);
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,locator),value);
                // CommonUtil.sendKeysToWebElement(driver,input,value);
            }
            else
            {
                throw new ZohoSalesIQRuntimeException("input tag was not found with locator : "+locator.toString());
            }
        }
    }

    public static void setupChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code,String label,ChatType chat_type) throws Exception
    {
        com.zoho.livedesk.client.ChatHistory.ChatHistoryTests.quickChat(driver,visitor_driver,etest,widget_code,label,false,chat_type);
    }

    public static void setupOngoingChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code,String label) throws Exception
    {
        com.zoho.livedesk.client.ChatHistory.ChatHistoryTests.quickChat(driver,visitor_driver,etest,widget_code,label,false,ChatType.ONGOING);
    }

    public static WebElement getSharedURLContainer(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        WebElement container=CommonUtil.getElement(driver,By.cssSelector("[documentclick=accepturl]"));
        CommonWait.waitTillDisplayed(container);
        return container;
    }

    public static String openSharedURL(WebDriver driver) throws Exception
    {
        WebElement url_container=CommonUtil.getElement(getSharedURLContainer(driver),By.cssSelector("em[title*=http]"));
        String url=url_container.getText();
        CommonUtil.clickWebElement(driver,url_container);    
        return url;
    }

    public static boolean checkPreviewMessage(WebDriver visDriver,ExtentTest etest,boolean isFile,String message)
    {
        int failcount = 0;
        try
        {
            VisitorWindow.switchToChatWidget(visDriver);
            WebElement lastMessage = CommonUtil.getElement(visDriver,By.id("currchatconv"),By.className("siqc_msg"),By.tagName("em"));
            if(isFile)
            {
                if(lastMessage.getAttribute("class").contains("sqico-camera") && lastMessage.getText().contains(message))
                {
                    etest.log(Status.PASS,"Received file was shown in the preview in the conversation view in visitor end");
                }
                else
                {
                    etest.log(Status.FAIL,"Received file was not shown in the preview in the conversation view in visitor end");
                    failcount++;
                    TakeScreenshot.screenshot(visDriver,etest);
                }
            }
            else
            {
                if(lastMessage.getAttribute("title").toLowerCase().contains(message.toLowerCase()) && lastMessage.getAttribute("class").toLowerCase().contains("siqsly-"+message))
                {
                    etest.log(Status.PASS,"Received smiley was shown in the preview in conversation view in the visitor end");
                    CommonSikuli.findInWholePage(visDriver,"UI376.png","UI376",etest);
                }
                else
                {
                    etest.log(Status.FAIL,"Received smiley was not shown in the preview in conversation view in the visitor end");
                    failcount++;
                    TakeScreenshot.screenshot(visDriver,etest);
                }

            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visDriver,etest,"checkPreviewMessage","Exception","Exception",e);
        }
        return CommonUtil.returnResult(failcount);
    }

    //GDPR
    public static boolean isGDPRBannerDisplayed(WebDriver driver) throws Exception
    {
        driver.switchTo().defaultContent();
        return CommonWait.isDisplayed(driver,GDPR_BANNER);
    }

    public static boolean checkGDPRBannerDisplayed(WebDriver driver,ExtentTest etest,boolean expected_is_displayed) throws Exception
    {
        if(isGDPRBannerDisplayed(driver)==expected_is_displayed)
        {
            etest.log(Status.PASS,"GDPR banner was "+(expected_is_displayed?"displayed":"NOT displayed")+" as expected.");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"GDPR banner was "+(expected_is_displayed?"NOT displayed":"displayed")+" as expected.");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static String getGDPRBannerContent(WebDriver driver)
    {
        return CommonUtil.getElement(driver,GDPR_BANNER,GDPR_BANNER_DESCRIPTION).getText();
    }

    public static WebElement getCookiePolicyLinkElement(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        return CommonUtil.getElement(driver,GDPR_BANNER,GDPR_POLICY_LINK);

    }

    public static void clickGDPRPolicyURL(WebDriver driver)
    {
        WebElement a=getCookiePolicyLinkElement(driver);
        CommonUtil.clickWebElement(driver,a);        
    }

    public static boolean checkGDPRCookiePolicyURL(WebDriver driver,ExtentTest etest,String expected_link) throws Exception
    {
        final String
        LINK_TEXT="Learn More";

        WebElement a=getCookiePolicyLinkElement(driver);
        return HandleCommonUI.verifyAnchorTag(a,etest,LINK_TEXT,expected_link);
    }

    public static boolean isOkButtonFoundInGDPRBanner(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,GDPR_BANNER,GDPR_OK_BUTTON);
    }

    public static boolean isDoNotTrackButtonFoundInGDPRBanner(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,GDPR_BANNER,GDPR_DONT_TRACK_BUTTON);
    }

    public static boolean clickOkButtonInGDPRBanner(WebDriver driver)
    {
        return clickButtonInGDPRBanner(driver,GDPR_OK_BUTTON);
    }

    public static boolean clickDoNotTrackButtonInGDPRBanner(WebDriver driver)
    {
        return clickButtonInGDPRBanner(driver,GDPR_DONT_TRACK_BUTTON);
    }

    private static boolean clickButtonInGDPRBanner(WebDriver driver,By button_locator)
    {
        driver.switchTo().defaultContent();
        WebElement button=CommonUtil.getElement(driver,button_locator);
        CommonUtil.clickWebElement(driver,button);
        return CommonWait.waitTillHidden(driver,GDPR_BANNER);
    }

    public static boolean isChatConsentContainerDisplayed(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        return CommonWait.isDisplayed(driver,CURRENT_CHAT_MESSAGE_AREA,CHAT_CONSENT_CONTAINER);        
    }

    public static boolean verifyChatConsentText(WebDriver driver,ExtentTest etest) throws Exception
    {
        switchToChatWidget(driver);
        String actual=CommonUtil.getElement(driver,CURRENT_CHAT_MESSAGE_AREA,CHAT_CONSENT_CONTAINER).getText();
        String expected=ResourceManager.getRealValue("chat_consent_visitor");
        return CommonUtil.checkStringContainsAndLog(expected,actual,"chat consent text",etest);
    }

    public static boolean clickAcceptInChatConsent(WebDriver driver) throws Exception
    {
        return clickChatConsentButtons(driver,true);
    }

    public static boolean clickDeclineInChatConsent(WebDriver driver) throws Exception
    {
        return clickChatConsentButtons(driver,false);
    }

    private static boolean clickChatConsentButtons(WebDriver driver,boolean isAccept) throws Exception
    {
        switchToChatWidget(driver);
        By button_locator=isAccept?CHAT_CONSENT_ACCEPT:CHAT_CONSENT_DECLINE;
        WebElement button=CommonUtil.getElement(driver,CHAT_CONSENT_CONTAINER,button_locator);
        CommonUtil.clickWebElement(driver,button);

        if(isAccept)
        {
            return checkWaitingDiv(driver);
        }
        else
        {
            return CommonWait.waitTillHidden(driver,By.className(CHAT_CONTAINER_CLASS),By.tagName("iframe"));
        }
    }

    public static WebElement getChatConsentLinkElement(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        return CommonUtil.getElement(driver,CHAT_CONSENT_CONTAINER,GDPR_POLICY_LINK);
    }

    public static void clickChatConsentPolicyURL(WebDriver driver) throws Exception
    {
        WebElement a=getChatConsentLinkElement(driver);
        CommonUtil.clickWebElement(driver,a);        
    }
    public static boolean checkChatConsentPolicyURL(WebDriver driver,ExtentTest etest,String expected_link) throws Exception
    {
        final String
        LINK_TEXT="I agree to the terms and conditions.";
        WebElement a=getChatConsentLinkElement(driver);
        return HandleCommonUI.verifyAnchorTag(a,etest,LINK_TEXT,expected_link);
    }

    public static boolean isOfflineConsentDisplayed(WebDriver driver) throws Exception
    {
        switchToChatWidget(driver);
        return CommonWait.isDisplayed(driver,OFFLINE_CONSENT_CONTAINER,OFFLINE_CONSENT_CHECKBOX);
    }

    public static boolean setOfflineConsent(WebDriver driver,boolean isConsent) throws Exception
    {
        switchToChatWidget(driver);

        WebElement checkbox_input=CommonUtil.getElement(driver,OFFLINE_CONSENT_CHECKBOX_STATE_INPUT);

        if(HandleCommonUI.isCheckboxChecked(checkbox_input)==isConsent)
        {
            return true;
        }

        WebElement checkbox_div=CommonUtil.getElement(driver,OFFLINE_CONSENT_CONTAINER,OFFLINE_CONSENT_CHECKBOX);
        checkbox_div.click();

        return HandleCommonUI.waitTillCheckboxStateChange(checkbox_input,isConsent);
    }

    //returns 0-hidden 1-online -1 offline
    public static int getChatWindowState(WebDriver driver) throws Exception
    {
        if( CommonWait.isHidden( CommonUtil.getElement(driver,By.id("zsiq_float")) ) )
        {
            return NOT_FOUND;
        }
        
        return checkChatWidgetOffline(driver)?OFFLINE:ONLINE;
    }

    public static String getChatWindowState(int state)
    {
        if(state==ONLINE)
        {
            return "Online";
        }
        if(state==OFFLINE)
        {
            return "Offline";
        }
        if(state==NOT_FOUND)
        {
            return "Hidden";
        }

        return null;
    }

    public static boolean isContainsDepartment(WebDriver driver)
    {
        switchToChatWidget(driver);
        return CommonWait.isPresent(driver,DEPT_DROPDOWN_CONTAINER);
    }

    public static WebElement getLastMessageElementByLocator(WebDriver driver,By locator)
    {
        switchToChatWidget(driver);
        List<WebElement> messages=CommonUtil.getElements(driver,locator);
        return messages.get( messages.size() - 1 );        
    }

    public static String getLastMessage(WebDriver driver)
    {
        return getLastMessageElement(driver).getAttribute("innerText");
    }
    public static WebElement getLastMessageElement(WebDriver driver)
    {
        return getLastMessageElementByLocator(driver,MESSAGE);
    }

    public static String getLastVisitorMessage(WebDriver driver)
    {
        return getLastVisitorMessageElement(driver).findElement(VISITOR_MESSAGE_TEXT).getAttribute("innerText");
    }
    public static WebElement getLastVisitorMessageElement(WebDriver driver)
    {
        return getLastMessageElementByLocator(driver,VISITOR_MESSAGE);
    }

    public static String getLastAgentMessage(WebDriver driver)
    {
        return getLastAgentMessageElement(driver).getAttribute("innerText");
    }
    public static WebElement getLastAgentMessageElement(WebDriver driver)
    {
        return getLastMessageElementByLocator(driver,AGENT_MESSAGE);
    }

    public static boolean isLastMessageAgentMessage(WebDriver driver)
    {
        return CommonUtil.hasClass(getLastMessageElement(driver),AGENT_MESSAGE_CLASS_NAME);
    }

    public static boolean isDepartmentFound(WebDriver driver,String dept_id)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isPresent(driver,By.cssSelector("li[val='"+dept_id+"']"));
    }

    //checks if current page is bots preview chat page, Used mainly in switchToChatWidget for skipping switch to operation in case current page is bot preview chat because that chat has no frame
    public static boolean isBotPreviewChatPage(WebDriver driver)
    {
        return CommonWait.isPresent(driver,com.zoho.livedesk.util.common.actions.bots.DelugeScript.BOT_PREVIEW_WINDOW);
    }

    public static boolean isInfoMessageShown(WebDriver driver,String message)
    {
        VisitorWindow.switchToChatWidget(driver);

        FluentWait wait=CommonUtil.waitreturner(driver,5,250);

        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(CommonUtil.getElement(driver,VisitorWindow.INFO_MESSAGE).getText().toLowerCase().contains(message.toLowerCase()))
                    {
                        return true;
                    }
                    return false;
                }
            });

            return true;

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }

    public static boolean isVisitorQuestionInputFound(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isDisplayed(driver,By.cssSelector("[purpose='question']"));
    }

    public static boolean isFloatWidgetFound(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        return CommonWait.isPresent(driver,By.id("zsiq_float"));
    }

    public static boolean isSendMailButtonFound(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isPresent(driver,By.cssSelector("[documentclick='sendmail']"));        
    }

    public static boolean isScreenShareButtonFound(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isPresent(driver,By.cssSelector("[documentclick='sharedesktop']"));        
    }

    public static boolean isSmileyFound(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isPresent(driver,By.id("smiley"));        
    }

    public static boolean isFileUploadFound(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isPresent(driver,By.id("embdfileupload"));        
    }

    /*New Apps Function*/
    public static final String
    FLOAT_THEME=com.zoho.livedesk.util.common.actions.Apps.AppsMessenger.FLOAT,
    BUTTON_THEME=com.zoho.livedesk.util.common.actions.Apps.AppsMessenger.BUTTON
    ;

    public static final String FLOAT_THEME_LIST[]={null,"coin",null,"unicorn","dream","twinkle","doller","topaz","link","sassy","noel","bagel"};
    public static final String BUTTON_THEME_LIST[]={null,"cord","blueivy","zen","atom","coffee","paradise","meme","leo","ruby","cookie","fancy","cent","poppy","apollo"};

    public static String getCurrentStickerThemeType(WebDriver driver)
    {
        driver.switchTo().defaultContent();

        if(CommonWait.isPresent(driver,By.id("zsiq_float")))
        {
            return FLOAT_THEME;
        }
        else if(CommonWait.isPresent(driver,By.id("zsiqbtn")))
        {
            return BUTTON_THEME;
        }
        else
        {   
            throw new ZohoSalesIQRuntimeException("No valid theme was found in current visitor page.");
        }
    }

    public static String getCurrentStickerThemeName(WebDriver driver)
    {
        String type=getCurrentStickerThemeType(driver);

        if(type.equals(FLOAT_THEME))
        {
            String class_name=CommonUtil.getElement(driver,By.className("zsiq_floatmain")).getAttribute("class");
            String theme_number_str=class_name.split("zsiq_theme")[1].split(" ")[0];
            int theme_number=Integer.parseInt( theme_number_str );
            return FLOAT_THEME_LIST[theme_number];            
        }
        else if(type.equals(BUTTON_THEME))
        {
            String class_name=CommonUtil.getElement(driver,By.id("zsiqbtn")).getAttribute("class");
            int theme_number=Integer.parseInt( class_name.replace("zsiq_float","") );
            return BUTTON_THEME_LIST[theme_number];
        }

        return null;
    }

    public static boolean checkStickerContent(WebDriver driver,ExtentTest etest,String expected_line1,String expected_line2) throws Exception
    {
        String type=getCurrentStickerThemeType(driver);

        String actual_line1=null,actual_line2=null;

        if(type.equals(FLOAT_THEME))
        {
            actual_line1=getLine1InFloat(driver);
            actual_line2=getLine2InFloat(driver);
        }
        else if(type.equals(BUTTON_THEME))
        {
            actual_line1=getLine1InButton(driver);
            actual_line2=getLine2InButton(driver);            
        }

        int failcount=0;

        if(CommonUtil.checkStringContainsAndLog(expected_line1,actual_line1,"Chat Sticker Line 1",etest)==false)
        {
            failcount++;
        }
        if(CommonUtil.checkStringContainsAndLog(expected_line2,actual_line2,"Chat Sticker Line 2",etest)==false)
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }
}
