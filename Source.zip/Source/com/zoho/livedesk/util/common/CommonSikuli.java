//$Id$
package com.zoho.livedesk.util.common;

import java.io.File;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.OutputType;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;


import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.SeleniumGridUtil;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Finder;
import org.sikuli.script.Location;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import org.apache.commons.lang3.RandomStringUtils;
import java.net.InetAddress;
import java.net.UnknownHostException;
import com.google.common.base.Function;
import com.zoho.livedesk.util.ImageProcessor.ImageBreakageDetector;

public class CommonSikuli
{
  public static Hashtable<String,Boolean> result;
  public static Hashtable finalresult ;
  public static Hashtable report;
  public static Hashtable res;

  public static void initializeSikuliResultHashtable()
  { 
    finalresult = new Hashtable();
    result = new Hashtable<String,Boolean>();
    report = new Hashtable();
    res = new Hashtable();
  }

  public static void findInWholePage(WebDriver driver,String imageName,String key,ExtentTest etest)
  {
    if(SikuliDevModeHandler.isSikuliDevMode())
    {
      SikuliDevModeHandler.findInWholePage(driver,imageName,key,etest);
    }
    else
    {
      findInWholePageAndLog(driver,imageName,key,etest);
    }
  }

  public static Boolean findInWholePageAndLog(WebDriver driver,String imageName,String key,ExtentTest etest)
  {
    Boolean isPass=null;

    String usecase = null;

    if(SikuliDevModeHandler.isSikuliDevMode())
    {
      usecase=key.split("_")[0];
    }
    else
    {
      usecase = KeyManager.getRealValue(key);
    }


    ExtentTest uitest=ComplexReportFactory.getTest(usecase);
    ComplexReportFactory.setValues(uitest,"Automation","UI");

    try
    { 
      if(result.containsKey(key))
      {
        log(uitest,etest,usecase+" is already checked");
        return null;
      }

      result.put(key,findInWholePage(driver,imageName,etest,uitest));
      if(result.get(key)==true)
      {
        log(uitest,etest,Status.PASS,"Expected UI was found for usecase : "+usecase);
        isPass=true;
      }
      else
      {
        log(uitest,etest,Status.FAIL,"Expected UI was NOT found for usecase : "+usecase);
        isPass=false;
      }
    }
    catch(Exception e)
    {
      log(uitest,etest,Status.FAIL,"Exception occured during image comparism. Expected UI could not be verified for usecase : "+usecase);
      log(uitest,etest,e);
      isPass=false;
    }

    ComplexReportFactory.closeTest(uitest);

    return isPass;
  }  

  public static boolean findInWholePage(WebDriver driver,String imageName,ExtentTest etest) throws IOException, FindFailed, InterruptedException
  {
    return findInWholePage(driver,imageName,etest,null);
  }
  
  public static boolean findInWholePage(WebDriver driver,String imageName,ExtentTest etest,ExtentTest uitest) throws IOException, FindFailed, InterruptedException
  {

    if(!driver.getCurrentUrl().contains("crmplus"))
    {
      ImageBreakageDetector.detect(driver);
    }
    
    String expectedimg=getImageURL(driver,imageName);

    //String expectedimg = "http://"+Util.serverHostName+":"+Util.serverPortNumber+"/Sikuliimages/zsalesiq/"+imageName;  //zchat zsalesiq

    URL file_url = new URL(expectedimg);
    String uniqueID = UUID.randomUUID().toString();
    String actualimage = uniqueID+imageName;
    BufferedImage regionsetimage = screenCapture(driver,actualimage);

    //getting the match %
    String match_percentage="Not found";

    try
    {
      Pattern testImage = new Pattern(file_url); 
      Finder window1 = new Finder(regionsetimage);
      window1.find(testImage.similar((float) 0.01));  //.exact()
      Match found1 = window1.next();
      match_percentage=found1.getScore()*100+"%";
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }


    Finder window = new Finder(regionsetimage);
    Pattern testImage = new Pattern(file_url); 

    window.find(testImage.similar((float) 0.01));
    Match found = window.next();
    double score=found.getScore()*100;

    String expected_screenshot_url=expectedimg;
    String actual_screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+TakeScreenshot.getBuildLabel()+"/Sikuliscreenshots/"+actualimage;

    logScreenshots(uitest,etest,expected_screenshot_url,actual_screenshot_url);

    if(score>99)
    {
      log(uitest,etest,Status.PASS,"Machine : "+machinename(driver)+", Matching % : "+match_percentage);
      return true;
    }
    else
    {
      log(uitest,etest,Status.FAIL,"Machine : "+machinename(driver)+", Matching % : "+match_percentage);
      return false;
    }

    /*

    Older Implementation removed due to an issue in sikuli framework

    window.find(testImage.similar((float) 0.99));  //.exact()
    Match found = null;
    if (window.hasNext())
    {
      found = window.next();
      System.out.println(imageName + " Image found");
      log(uitest,etest,Status.PASS,"Expected: "+ expected + "Actual" + actual+", Machine : "+machinename(driver)+", Matching % : "+match_percentage);
      return true;
    }
    else
    {
      System.out.println(imageName + " Image Not found");
      log(uitest,etest,Status.FAIL,"Expected: "+ expected + "Actual" + actual+", Machine : "+machinename(driver)+", Matching % : "+match_percentage);
      return false;
    }

    */
  }

  public static boolean findInWholePage(WebDriver driver,String imageName) throws IOException, FindFailed, InterruptedException
  {
    return findInWholePage(driver,imageName,null);
  }


  public static String getImageURL(WebDriver driver,String imageName)
  {
    return "http://"+Util.serverHostName+":"+Util.serverPortNumber+"/"+getImagePathFromWebappsFolder(driver,imageName);
  }

  public static String getImagePath(WebDriver driver,String imageName)
  {
    return FileUpload.getBuildRoot()+"/webapps/selenium/"+getImagePathFromWebappsFolder(driver,imageName);
  }

  public static String getImagePathFromWebappsFolder(WebDriver driver,String imageName)
  {
    String expectedimg = "Sikuliimages/"+getFolderName(driver)+"/"+imageName;
    return expectedimg;
  }

  public static String getFolderName(WebDriver driver)
  {
    String folderName = "";

    String hostName = SeleniumGridUtil.getHostName(driver);

    if(hostName == null)
    {
      hostName = "others";
    }

    if (hostName.equals("192.168.144.228"))
    {
      folderName = "zchat"; 
    }
    else if (hostName.equals("192.168.144.123") || hostName.equals("192.168.144.218") || hostName.equals("192.168.144.40"))
    {
      folderName = "Testlinux"; 
    }
    else if(hostName.equals("172.21."+"183.120"))
    {
      folderName = "LinuxNew";
    }
    else
    {
      folderName = "zsalesiq";
    }

    return folderName;
  }

  public static BufferedImage screenCapture(WebDriver driver,String screenShotName) throws IOException
  {
    TakesScreenshot ts = (TakesScreenshot)driver;
    File source = ts.getScreenshotAs(OutputType.FILE);
    String dest = TakeScreenshot.filePath()+TakeScreenshot.getBuildLabel()+"/Sikuliscreenshots/"+screenShotName;
    File destination = new File(dest);
    FileUtils.copyFile(source, destination);
    BufferedImage image = ImageIO.read(destination);
    return image;
  }

  public static void logScreenshots(ExtentTest ui_test,ExtentTest etest,String expected,String actual) throws IOException
  {
    logScreenshots(etest,expected,actual);
    logScreenshots(ui_test,expected,actual);
  }

  public static void logScreenshots(ExtentTest etest,String expected,String actual) throws IOException
  {
    if(etest!=null)
    {
      etest.log(Status.INFO, "Expected: ", MediaEntityBuilder.createScreenCaptureFromPath(expected).build());
      etest.log(Status.INFO, "Actual: ", MediaEntityBuilder.createScreenCaptureFromPath(actual).build());
    }
  }

  public static void log(ExtentTest uitest,ExtentTest etest,String log)
  {
    log(uitest,etest,Status.INFO,log);
  }

  public static void log(ExtentTest uitest,ExtentTest etest,Status status,String log)
  {
      //sikuli logs are logged in current test and also as a seperate module

      if(uitest!=null)
      {
        uitest.log(status,log);
      }

      if(status==Status.FAIL)
      {
        status=Status.WARNING;
      }

      if(etest!=null)
      {
        etest.log(status,log);
      }
  }

  public static void log(ExtentTest uitest,ExtentTest etest,Exception e)
  {
      if(etest!=null)
      {
        TakeScreenshot.log(e,etest);
      }

      if(uitest!=null)
      {
        TakeScreenshot.log(e,uitest);
      }
  }

  public static String getImageNameInpreviewwindowcolour(String colour)
  {
    String color = colour.replaceAll("#","1"); 
    return "Ribbon"+color+".png";
  } 

  public static String getFooterImageName(String themename)
  {
    String fthemename = themename.toLowerCase().replaceAll(" ",""); 
    return "Footer"+fthemename+".png";
  } 

  public static String getImageNameInpreviewwindow(String theme)
  {
    String themename = theme.toLowerCase().replaceAll(" ","");
    return "P"+themename+".png";
  } 

  public static String getFooterImageNameInpreviewwindowcolour(String theme)
  {
    String themename = theme.toLowerCase().replaceAll(" ","");
    return "Pfooter"+themename+".png";
  } 

  public static String getTileNameBeforeIntiate(String part)
  {
    String partName;
    if(part.contains(","))
    {
      partName = part.replaceAll(",","").replaceAll("\\s","");  
    }
    else
    {
      partName = part.replaceAll("\\s","");
    }
    return partName+".png";
  } 

  public static String getTileNameAfterIntiate(String boxTitle)
  {
    return "Afterintiate"+boxTitle.replaceAll("\\s","").toLowerCase()+".png";
  } 

  public static String isRingHighlighted(String tracking)
  {
    String tracking_ring = tracking.toLowerCase();
    return tracking_ring+".png";
  } 

  public static String isListHighlighted(String tracking)
  {
    String tracking_ring = tracking.toLowerCase();
    return "L"+tracking_ring+".png";
  } 

  public static String getImageName(String themename)
  {
    String file_name="";
    try
    {
      switch(themename)
      {
      case "Lloyd":
        file_name="Lloyd.png";
        break;
      case "Pattern":
        file_name="Pattern.png";
        break;
      case "Pattern - Straight":
        file_name="PatternStraight.png";
        break;
      case "Pattern - Curve":
        file_name="PatternCurve.png";
        break;
      default:
        System.out.println("Invalid ThemeName");
        break;
      }
    }
    catch(Exception e)
    {
      System.out.println("Exception while trying to getImageName: ");
      e.printStackTrace();
    }
    return file_name;
  }

  public static String getImageNameBasedColour(String colour)
  {
    String file_name="Ribbon.png";
    try
    {
      switch(colour)
      {
      case "#D066E5":
        file_name="1"+ file_name;
        break;
      case "#FFB300":
        file_name="2" + file_name;
        break;
      case com.zoho.livedesk.client.EmbedConfig.TestInit.DEFAULT_COLOR:
        file_name="3" + file_name;
        break;
      default:
        System.out.println("No colour or invalid Colour");
        break;
      }  
    }
    catch(Exception e)
    {
      System.out.println("Exception while trying to getImageNameBasedColour: ");
      e.printStackTrace();
    }
    return file_name;
  }

  public static String getKeyvalue(String themename)
  {
    String key="";
    switch(themename)
    {
    case "Lloyd":
      key="UI26";
      break;
    case "Pattern":
      key="UI25";
      break;
    case "Pattern - Straight":
      key="UI27";
      break;
    case "Pattern - Curve":
      key="UI28";
      break;
    default:
      System.out.println("Invalid Key");
      break;
    }
    return key;
  }

 public static String getFooterKeyvalue(String themename)
  {
    String key="";
    switch(themename)
    {
    case "Lloyd":
      key="UI314";
      break;
    case "Pattern":
      key="UI315";
      break;
    case "Pattern - Straight":
      key="UI316";
      break;
    case "Pattern - Curve":
      key="UI317";
      break;
    default:
      System.out.println("Invalid Key");
      break;
    }
    return key;
  }

  public static String getKeyvaluebasedcolour(String colour)
  {
    String key="";
    switch(colour)
    {
    case "#D066E5":
      key="EC36";
      break;
    case "#FFB300":
      key="EC35";
      break;
    case com.zoho.livedesk.client.EmbedConfig.TestInit.DEFAULT_COLOR:
      key="EC34";
      break;
    default:
      System.out.println("No colour or invalid Colour in Key");
      break;
    }
    return key;
  }

  public static String getKeyValueBeforeIntiateChat(String partName)
  {
    String key="";
    switch(partName)
    {
    case "Available,Idle":
      key="UI72";
      break;
    case "Time on site":
      key="UI73";
      break;
    case "Visitor History":
      key="UI74";
      break;
    case "Visitor Location and IP":
      key="UI75";
      break;
    case "Visitor landing page":
      key="UI76";
      break;
    case "Direct Traffic,Referral":
      key="UI77";
      break;
    default:
      System.out.println("getKeyValueBeforeIntiateChat Error");
      break;
    }
    return key;
  }

  public static String getKeyValueAfterIntiateChat(String boxTitle)
  {
    String key="";
    switch(boxTitle)
    {
    case "Visitor History":
      key="UI78";
      break;
    case "Visitor Location and IP":
      key="UI79";
      break;
    case "Visitor landing page":
      key="UI80";
      break;
    case "Direct Traffic":
      key="UI77";
      break;
    default:
      System.out.println("getKeyValueAfterIntiateChat Error");
      break;
    }
    return key;
  }
  public static String getKeyValueRingHighlighted(String tracking_ring)
  {
    String key="";
    switch(tracking_ring)
    {
    case "RING1":
      key="UI64";
      break;
    case "RING2":
      key="UI65";
      break;
    case "RING3":
      key="UI66";
      break;
    case "RING4":
      key="UI67";
      break;
    default:
      System.out.println("getKeyValueRingHighlighted Error");
      break;
    }
    return key;
  }

  public static String getKeyValueListHighlighted(String tracking_ring)
  {
    String key="";
    switch(tracking_ring)
    {
    case "RING1":
      key="UI68";
      break;
    case "RING2":
      key="UI69";
      break;
    case "RING3":
      key="UI70";
      break;
    case "RING4":
      key="UI71";
      break;
    default:
      System.out.println("getKeyValueListHighlighted Error");
      break;
    }
    return key;
  }

  public static String getBrowsername(WebElement finder)
  {
    String browser = finder.getAttribute("title");
    if (browser.contains("Google Chrome"))
    {
      return "Chrome.png";
    }
    else
    {      
      return "Firefox.png";
    }
  }

  public static String getOSname(WebElement finder)
  {
    String browser = finder.getAttribute("title");
    if (browser.contains("Apple Macintosh"))
    {
      return "Apple.png";
    }
    else
    {
      return "Linux.png";
    }
  } 



  public static int browsericons(WebDriver driver,String type,String rule,ExtentTest etest) throws FindFailed, IOException, InterruptedException, Exception
  {
    int failcount = 0;
    
    String elid = driver.findElement(By.id("trouting")).findElement(By.className("data_row")).getAttribute("ruleid");

   String[] browser = {"Apple Safari","Google Chrome","Microsoft Internet Explorer","Mozilla Firefox","Opera","Unknown"};

    for (int i=0; i<browser.length; i++ ) 
    {       
      if(rule.equalsIgnoreCase("Default"))
      {
        driver.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).clear();
        driver.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).sendKeys(browser[i]);
      }

      else
      {
        driver.findElement(By.id("ldsettings")).findElement(By.id("col3_input1")).clear();
        driver.findElement(By.id("ldsettings")).findElement(By.id("col3_input1")).sendKeys(browser[i]);
      } 

      String additional = (rule.equals("Advanced") && browser[i].equals("Unknown"))?"A":"";

      findInWholePage(driver,additional+browser[i].replaceAll("\\s", "")+".png",getBrowsername(type,rule,browser[i].replaceAll("\\s", "")),etest);
      if(result.get(getBrowsername(type,rule,browser[i].replaceAll("\\s", "")))==false)
      {
        failcount++;
      }
    }

    return failcount;
  }

  public static int operatingsystemicons(WebDriver driver,String type,String rule,ExtentTest etest) throws FindFailed, IOException, InterruptedException, Exception
  {
    int failcount=0;

    String elid = driver.findElement(By.id("trouting")).findElement(By.className("data_row")).getAttribute("ruleid");

      String[] os = {"Android","Apple iPad","Mac OS","Blackberry","Kindle","Linux","Microsoft Windows","Motorola","Nintendo","Nokia","PlayStation","Sun Solaris","Symbian","Web OS"};

    for (int i=0; i<os.length; i++ ) 
    { 
      if(rule.equalsIgnoreCase("Default"))
      {
        driver.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).clear();
        driver.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).sendKeys(os[i]);
      }

      else
      {
        driver.findElement(By.id("ldsettings")).findElement(By.id("col3_input1")).clear();
        driver.findElement(By.id("ldsettings")).findElement(By.id("col3_input1")).sendKeys(os[i]);
      } 
      
      findInWholePage(driver,os[i].replaceAll("\\s", "")+".png",getOSname(type,rule,os[i].replaceAll("\\s", "")),etest);
      if(result.get(getOSname(type,rule,os[i].replaceAll("\\s", "")))==false)
      {
        failcount++;
      }
    }

    return failcount;
  }

  public static int regionIcons(WebDriver driver,String type,String rule,ExtentTest etest) throws FindFailed, IOException, InterruptedException, Exception
  {
    int failcount = 0;

    String elid = driver.findElement(By.id("trouting")).findElement(By.className("data_row")).getAttribute("ruleid");

     String[] region = {"Asia Pacific","Canada","Europe the Middle East and Africa","North America","South America","United Kingdom"};

    for (int i=0; i<region.length; i++) 
    { 
      if(rule.equalsIgnoreCase("Default"))
      {
        driver.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).clear();
        driver.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).sendKeys(region[i]);
      }

      else
      {
        driver.findElement(By.id("ldsettings")).findElement(By.id("col3_input1")).clear();
        driver.findElement(By.id("ldsettings")).findElement(By.id("col3_input1")).sendKeys(region[i]);
      } 
      
      findInWholePage(driver,region[i].replaceAll("\\s", "")+".png",getRegionname(type,rule,region[i].replaceAll("\\s", "")),etest);
      if(result.get(getRegionname(type,rule,region[i].replaceAll("\\s", "")))==false)
      {
        failcount++;
      }
    }

    return failcount;
  }

  public static String getBrowsername(String type,String rule,String browsername)
  {
    if(type.equalsIgnoreCase("Intelligent triggers"))
    {  
      if (rule.equalsIgnoreCase("Default"))
      {
        String key="";
        //System.out.println("________Default browser__________Intelligenttrigger");
        switch(browsername)
        {
        case "AppleSafari":
          key="UI168";
          break;
        case "GoogleChrome":
          key="UI130";
          break;
        case "MicrosoftInternetExplorer":
          key="UI133";
          break;
        case "MozillaFirefox":
          key="UI131";
          break;
        case "Opera":
          key="UI132";
          break;
        case "Unknown":
          key="UI134";
          break;

        default:
          System.out.println("Error while getting key for default browser Intelligenttrigger"+browsername);
          break;
        }
        return key;
      }
      // Advanced method
      else
      {
        String key="";
        //System.out.println("________Advanced browser__________Intelligenttrigger");
        switch(browsername)
        {
        case "AppleSafari":
          key="UI169";
          break;
        case "GoogleChrome":
          key="UI149";
          break;
        case "MicrosoftInternetExplorer":
          key="UI152";
          break;
        case "MozillaFirefox":
          key="UI150";
          break;
        case "Opera":
          key="UI151";
          break;
        case "Unknown":
          key="UI153";
          break;

        default:
          System.out.println("Error while getting key for Advanced browser Intelligenttrigger"+browsername);
          break;
        }
        return key;
      }
    }
    if(type.equalsIgnoreCase("Visitor Routing"))
    {
      if (rule.equalsIgnoreCase("Default"))
      {
        String key="";
        //System.out.println("________Default browser__________Visitor Routing");
        switch(browsername)
        {
        case "AppleSafari":
          key="UI210";
          break;
        case "GoogleChrome":
          key="UI172";
          break;
        case "MicrosoftInternetExplorer":
          key="UI175";
          break;
        case "MozillaFirefox":
          key="UI173";
          break;
        case "Opera":
          key="UI174";
          break;
        case "Unknown":
          key="UI176";
          break;

        default:
          System.out.println("Error while getting key for default browser visitorouting"+browsername);
          break;
        }
        return key;
      }
      else
      {

        String key="";
        //System.out.println("___________Advanced browser__________Visitor Routing");
        switch(browsername)
        {
        case "AppleSafari":
          key="UI211";
          break;
        case "GoogleChrome":
          key="UI191";
          break;
        case "MicrosoftInternetExplorer":
          key="UI194";
          break;
        case "MozillaFirefox":
          key="UI192";
          break;
        case "Opera":
          key="UI193";
          break;
        case "Unknown":
          key="UI195";
          break;

        default:
          System.out.println("Error while getting key for Advanced browser visitorouting"+browsername);
          break;
        }
        return key;
      }
    }
    return null;
  }
  //Operating system
  public static String getOSname(String type,String rule,String operatingsystemname)
  {
    if(type.equalsIgnoreCase("Intelligent triggers"))
    { 
      if (rule.equalsIgnoreCase("Default"))
      {
        //System.out.println("________Default OS__________Intelligenttrigger");
        String key="";
        switch(operatingsystemname)
        {
        case "Android":
          key="UI135";
          break;
        case "AppleiPad":
          key="UI136";
          break;
        case "MacOS":
          key="UI137";
          break;
        case "Blackberry":
          key="UI138";
          break;
        case "Kindle":
          key="UI139";
          break;
        case "Linux":
          key="UI140";
          break;
        case "MicrosoftWindows":
          key="UI141";
          break;
        case "Motorola":
          key="UI142";
          break;
        case "Nintendo":
          key="UI143";
          break;
        case "Nokia":
          key="UI144";
          break;
        case "PlayStation":
          key="UI145";
          break;
        case "SunSolaris":
          key="UI146";
          break;   
        case "Symbian":
          key="UI147";
          break;
        case "WebOS":
          key="UI148";
          break;    
        default:
          System.out.println("Error while getting key for default OS Intelligenttrigger" + operatingsystemname);
          break;
        }
        return key;
      }
      // Advanced method
      else
      { 
        //System.out.println("________Advanced OS__________Intelligenttrigger");
        String key="";
        switch(operatingsystemname)
        {
        case "Android":
          key="UI154";
          break;
        case "AppleiPad":
          key="UI155";
          break;
        case "MacOS":
          key="UI156";
          break;
        case "Blackberry":
          key="UI157";
          break;
        case "Kindle":
          key="UI158";
          break;
        case "Linux":
          key="UI159";
          break;
        case "MicrosoftWindows":
          key="UI160";
          break;
        case "Motorola":
          key="UI161";
          break;
        case "Nintendo":
          key="UI162";
          break;
        case "Nokia":
          key="UI163";
          break;
        case "PlayStation":
          key="UI164";
          break;
        case "SunSolaris":
          key="UI165";
          break;   
        case "Symbian":
          key="UI166";
          break;
        case "WebOS":
          key="UI167";
          break;    
        default:
          System.out.println("Error while getting key for advanced OS Intelligenttrigger" + operatingsystemname);
          break;
        }
        return key;
      }
    }
    if(type.equalsIgnoreCase("Visitor Routing"))
    {
      if (rule.equalsIgnoreCase("Default"))
      {
        String key="";
        //System.out.println("_______Default OS__________Visitor Routing");
        switch(operatingsystemname)
        {
        case "Android":
          key="UI177";
          break;
        case "AppleiPad":
          key="UI178";
          break;
        case "MacOS":
          key="UI179";
          break;
        case "Blackberry":
          key="UI180";
          break;
        case "Kindle":
          key="UI181";
          break;
        case "Linux":
          key="UI182";
          break;
        case "MicrosoftWindows":
          key="UI183";
          break;
        case "Motorola":
          key="UI184";
          break;
        case "Nintendo":
          key="UI185";
          break;
        case "Nokia":
          key="UI186";
          break;
        case "PlayStation":
          key="UI187";
          break;
        case "SunSolaris":
          key="UI188";
          break;   
        case "Symbian":
          key="UI189";
          break;
        case "WebOS":
          key="UI190";
          break;    
        default:
          System.out.println("Error while getting key for default OS visitorouting" + operatingsystemname);
          break;
        }
        return key;
      }
      else
      {
        String key="";
        // System.out.println("_________Advanced OS__________Visitor Routing");
        switch(operatingsystemname)
        {
        case "Android":
          key="UI196";
          break;
        case "AppleiPad":
          key="UI197";
          break;
        case "MacOS":
          key="UI198";
          break;
        case "Blackberry":
          key="UI199";
          break;
        case "Kindle":
          key="UI200";
          break;
        case "Linux":
          key="UI201";
          break;
        case "MicrosoftWindows":
          key="UI202";
          break;
        case "Motorola":
          key="UI203";
          break;
        case "Nintendo":
          key="UI204";
          break;
        case "Nokia":
          key="UI205";
          break;
        case "PlayStation":
          key="UI206";
          break;
        case "SunSolaris":
          key="UI207";
          break;   
        case "Symbian":
          key="UI208";
          break;
        case "WebOS":
          key="UI209";
          break;    
        default:
          System.out.println("Error while getting key for advanced OS visitorouting"+operatingsystemname);
          break;
        }
        return key;
      }
    }
    return null;
  }

  //Region Icons Check

  public static String getRegionname(String type,String rule,String regionname)
  {
    if(type.equalsIgnoreCase("Intelligent triggers"))
    {
      if (rule.equalsIgnoreCase("Default"))
      {
        String key="";
        //System.out.println("________Default Region__________Intelligenttrigger");
        switch(regionname)
        {
        case "AsiaPacific":
          key="UI215";
          break;
        case "Canada":
          key="UI216";
          break;
        case "EuropetheMiddleEastandAfrica":
          key="UI217";
          break;
        case "NorthAmerica":
          key="UI218";
          break;
        case "SouthAmerica":
          key="UI219";
          break;
        case "UnitedKingdom":
          key="UI220";
          break;
        default:
          System.out.println("Error while getting key for default Region Intelligenttrigger"+regionname);
          break;
        }
        //System.out.println(key+"keykeykeykeykeykeykey");
        return key;
      }
      // Advanced method
      else
      {
        String key="";
        // System.out.println("________Advanced Region__________Intelligenttrigger");
        switch(regionname)
        {
        case "AsiaPacific":
          key="UI221";
          break;
        case "Canada":
          key="UI222";
          break;
        case "EuropetheMiddleEastandAfrica":
          key="UI223";
          break;
        case "NorthAmerica":
          key="UI224";
          break;
        case "SouthAmerica":
          key="UI225";
          break;
        case "UnitedKingdom":
          key="UI226";
          break;
        default:
          System.out.println("Error while getting key for Advanced region Intelligenttrigger"+regionname);
          break;
        }
        return key;
      }
    }
    if(type.equalsIgnoreCase("Visitor Routing"))
    {
      if (rule.equalsIgnoreCase("Default"))
      {
        String key="";
        //System.out.println("________Default Region__________Visitor Routing");
        switch(regionname)
        {
        case "AsiaPacific":
          key="UI227";
          break;
        case "Canada":
          key="UI228";
          break;
        case "EuropetheMiddleEastandAfrica":
          key="UI229";
          break;
        case "NorthAmerica":
          key="UI230";
          break;
        case "SouthAmerica":
          key="UI231";
          break;
        case "UnitedKingdom":
          key="UI232";
          break;
        default:
          System.out.println("Error while getting key for default Region visitorouting"+regionname);
          break;
        }
        return key;
      }
      else
      {

        String key="";
        //System.out.println("___________Advanced Region__________Visitor Routing");
        switch(regionname)
        {
        case "AsiaPacific":
          key="UI233";
          break;
        case "Canada":
          key="UI234";
          break;
        case "EuropetheMiddleEastandAfrica":
          key="UI235";
          break;
        case "NorthAmerica":
          key="UI236";
          break;
        case "SouthAmerica":
          key="UI237";
          break;
        case "UnitedKingdom":
          key="UI238";
          break;
        default:
          System.out.println("Error while getting key for Advanced Region visitorouting"+regionname);
          break;
        }
        return key;
      }
    }
    return null;
  }


  public static String getImageNameBasedstar(String starval)
  {
    String star = starval.replace("-","");
    //System.out.println(star);
    return star+".png";
  } 

  public static String getKeyValueBasedstar(String Star)
  {
    String key="";
    switch(Star)
    {
    case "star-5":
      key="UI289";
      break;
    case "star-4":
      key="UI288";
      break;
    case "star-3":
      key="UI287";
      break;
    case "star-2":
      key="UI286";
      break;
    case "star-1":
      key="UI285";
      break;
    default:
      System.out.println("getKeyValueforFeedbackstar Error");
      break;
    }
    return key;
  }

  
public static Hashtable finalResult()
{
    calculateReport(result);
    finalresult.put("result",result);
    finalresult.put("report",report);
    finalresult.put("SalesIQTestUIAutomation"," *UIAutomation* : \\n Total Use Cases:"+report.get("TotalUseCases")+" | Failure:"+report.get("Failure")+" ("+report.get("Failure_per")+"%)");
    System.out.println(" Report Hash finalresult >>> "+finalresult);
    System.out.println(" Result Hash >>>"+finalresult.get("result"));
    System.out.println(" Report Hash >>>"+finalresult.get("report"));
    return finalresult;
}

  public static void calculateReport(Hashtable result)
    {
        try
        {
            int size = result.size();
            int success = 0;
            report.put("TotalUseCases", size);
            Set<String> keys = result.keySet();
            for(String key: keys){
                if((boolean) (""+result.get(key)).equals("true"))
                {
                    success++;
                }
                else
                {
                    res.put(KeyManager.getRealValue(key),"fail");
                }
            }
            report.put("Success", success);
            report.put("Failure", size-success);
            int success_per = (success*100)/size;
            report.put("Success_per", success_per);
            report.put("Failure_per", 100-success_per);
        }
        catch(Exception e)
        {
            // System.out.println("Exception calculating report : "+e);
            // e.printStackTrace();
        }
    }

  public static Hashtable sendResult()
  {
    return result;
  }

  public static String machinename(WebDriver driver)
  {
    String machineName=SeleniumGridUtil.getMachineName(driver);

    if(machineName==null)
    {
      machineName="others";
    }

    return machineName;
  }

}
