//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Action;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.google.common.base.Function;

import java.util.List;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import java.util.Hashtable;
import java.util.Set;

import java.util.Collection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.lang3.StringUtils;
import java.util.UUID;
import org.openqa.selenium.Keys;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml4;
import com.zoho.livedesk.util.common.actions.*;
import org.apache.commons.httpclient.util.URIUtil;
import java.util.HashMap;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Util;

public class CommonUtil {

		
	private static int trycnt = 0;
	public static ExtentTest etest = null;
	
	public static HashMap<String,Integer> get_element_attempts_by_ref_id=null;

	public static void init()
	{
		get_element_attempts_by_ref_id=new HashMap<String,Integer>();
	}

	public static FluentWait waitreturner(WebDriver driver,int timeOut,int polling)
	{
		FluentWait wait = new FluentWait(driver);
		wait.withTimeout(timeOut,TimeUnit.SECONDS);
		wait.pollingEvery(polling, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		return wait;
	}

	public static WebElement elfinder(WebDriver driver,String by,String finder) throws Exception
	{
		WebElement elmt = null;
		FluentWait wtr = waitreturner(driver, 30, 200);

		try
		{
			switch(by)
			{
			case "id":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.id(finder)));
				elmt = driver.findElement(By.id(finder));
				break;
			case "name":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.name(finder)));
				elmt = driver.findElement(By.name(finder));
				break;
			case "partiallinktext":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(finder)));
				elmt = driver.findElement(By.partialLinkText(finder));
				break;
			case "linktext":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.linkText(finder)));
				elmt = driver.findElement(By.linkText(finder));
				break;
			case "tagname":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.tagName(finder)));
				elmt = driver.findElement(By.tagName(finder));
				break;
			case "classname":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.className(finder)));
				elmt = driver.findElement(By.className(finder));
				break;
			case "css":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(finder)));
				elmt = driver.findElement(By.cssSelector(finder));
				break;
			case "xpath":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.xpath(finder)));
				elmt = driver.findElement(By.xpath(finder));
				break;
			default:
				//Thread.sleep(1000);
				System.out.println("Invalid Finder");
				break;
			}
		}
		catch(StaleElementReferenceException e)
		{
			if(trycnt>3)
			{
				trycnt = 0;
				throw e;
			}
			else
			{
				trycnt++;
				Thread.sleep(2000);
				elfinder(driver, by, finder);
			}
		}
		return elmt;
	}
	
	public static WebElement elementfinder(WebDriver driver,final WebElement elmtr,String by,final String finder) throws Exception
	{
		WebElement elmt = null;
		FluentWait wtr = waitreturner(driver, 30, 200);

		try
		{
			switch(by)
			{
			case "id":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.id(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.id(finder));
				break;
			case "name":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.name(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.name(finder));
				break;
			case "partiallinktext":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.partialLinkText(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.partialLinkText(finder));
				break;
			case "linktext":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.linkText(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.linkText(finder));
				break;
			case "tagname":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.tagName(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.tagName(finder));
				break;
			case "classname":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.className(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.className(finder));
				break;
			case "css":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.cssSelector(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.cssSelector(finder));
				break;
			case "xpath":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.xpath(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.xpath(finder));
				break;
			default:
				//Thread.sleep(1000);
				System.out.println("Invalid Finder");
				break;
			}
		}
		catch(StaleElementReferenceException e)
		{
			if(trycnt>3)
			{
				trycnt = 0;
				throw e;
			}
			else
			{
				trycnt++;
				Thread.sleep(2000);
				elfinder(driver, by, finder);
			}
		}
		return elmt;
	}

	public static boolean isCSSSelector(By by)
	{
		if(by.toString().contains("By.cssSelector"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static boolean isLocatorParsable(By by)
	{
		if(isCSSSelector(by))
		{	
			return false;
		}

		return true;
	}

	public static List<WebElement> getElements(WebDriver driver,By locator)
	{
		return getElements(getElement(driver,By.tagName("body")),locator);
	}

	public static List<WebElement> getElements(WebElement element,By locator)
	{
		int occurences=CommonUtil.getOccurences(element.getAttribute("innerHTML"),getByValue(locator));

		if(occurences<=1 && isLocatorParsable(locator))
		{
			List<WebElement> element_list=new ArrayList<WebElement>();
			WebElement found_element=CommonUtil.getElement(element,locator);
			if(found_element!=null)
			{
				element_list.add(found_element);
			}

			return element_list;
		}
		else
		{
			return element.findElements(locator);
		}
	}

	public static String generateRefId()
	{
		String ref_id=getUniqueId();
		get_element_attempts_by_ref_id.put(ref_id,0);
		return ref_id;
	}

	public static Integer getAttemptsByRefId(String ref_id)
	{
		return get_element_attempts_by_ref_id.get(ref_id);
	}

	public static void increaseAttempts(String ref_id)
	{
		int current_attempts=get_element_attempts_by_ref_id.get(ref_id);
		get_element_attempts_by_ref_id.put(ref_id,current_attempts+1);
	}

	public static WebElement getElement(WebDriver driver,By... by_objects)
	{
		return getElement(generateRefId(),driver,by_objects);
	}

	public static WebElement getElement(String ref_id,WebDriver driver,By... by_objects)
	{

		By current_locator=null;//for log

		try
		{
			WebElement web_element = null;
			
			for(By by_object : by_objects)
			{
				current_locator=by_object;//for log

				if(by_object == by_objects[0])
				{
					web_element=getWebElementFromDriver(ref_id,driver,by_object);
				}
				
				else
				{
					web_element=getWebElementFromWebElement(ref_id,web_element,by_object);				
				}
			}
			
			return web_element;
		}

		catch(Exception e)
		{
			System.out.println("getElement Exception while finding "+current_locator.toString());
			e.printStackTrace();
			return null;
		}

	}

	public static WebElement getElement(WebElement element,By... by_objects)
	{
		return getElement(generateRefId(),element,by_objects);
	}

	public static WebElement getElement(final String ref_id,WebElement element,By... by_objects)
	{
		By current_locator=null;//for log

		try
		{
			WebElement web_element = element;
			
			for(By by_object : by_objects)
			{				
				current_locator=by_object;//for log
				web_element=getWebElementFromWebElement(ref_id,web_element,by_object);
			}
			
			return web_element;
		}

		catch(Exception e)
		{
			System.out.println("getElement Exception while finding "+current_locator.toString());
			e.printStackTrace();
			return null;
		}
	}
	
	public static WebElement getWebElementFromDriver(final String ref_id,WebDriver driver,By by) throws Exception
	{
		WebElement elmt = null;
		FluentWait wtr = waitreturner(driver, 10, 200);

		try
		{
			wtr.until(ExpectedConditions.presenceOfElementLocated(by));
			elmt = driver.findElement(by);
		}
		catch(StaleElementReferenceException e)
		{
			if(getAttemptsByRefId(ref_id)>3)
			{
				throw e;
			}
			else
			{
				increaseAttempts(ref_id);
				Thread.sleep(2000);
				getWebElementFromDriver(ref_id,driver,by);
			}
		}
		return elmt;
	}

	public static WebElement getWebElementFromWebElement(final String ref_id,final WebElement web_element,final By by) throws Exception
	{
		WebElement found_element = null;

		FluentWait wait = new FluentWait(web_element);
		wait.withTimeout(10,TimeUnit.SECONDS);
		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);
		
		try
		{
			//wait.until(ExpectedConditions.presenceOfElementLocated(by));

			wait.until(new Function<WebElement,Boolean>()
			{
				public Boolean apply(final WebElement web_element)
				{
					if(web_element.findElement(by)!=null)
					{
						return true;
					}
					return false;
				}
			});
			
			found_element = web_element.findElement(by);

		
		
		}
		catch(StaleElementReferenceException e)
		{
			if(getAttemptsByRefId(ref_id)>3)
			{
				throw e;
			}
			else
			{
				increaseAttempts(ref_id);
				Thread.sleep(2000);
				return getWebElementFromWebElement(ref_id,web_element, by);
			}
		}
		return found_element;
	}

	public static WebElement getParent(WebDriver driver,WebElement element)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement parent_element = (WebElement)executor.executeScript("return arguments[0].parentNode;", element);
		return parent_element;
	}

    public static boolean returnResult(int failcount)
    {
        if(failcount>0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public static String getUniqueMessage()
    {
        return ""+new Long(System.currentTimeMillis());
    }

    public static String getUniqueId()
    {
    	return UUID.randomUUID().toString();
    }

	public static String timestamp()
	{
		String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		return timeStamp;
	}

	public static boolean checkStringequals(String s1,String s2,ExtentTest etest) 
	{
		if(!s1.equals(s2))
		{
			etest.log(Status.FAIL,"Mismatch Content: Actual---"+s1+"---;Excpected---"+s2+"---");
			return false;
		}
		return true;
	}
	public static boolean checkStringcontains(String s1,String s2,ExtentTest etest) 
	{
		if(!s1.contains(s2))
		{
			etest.log(Status.FAIL,"Mismatch Content: Actual---"+s1+"---;Excpected---"+s2+"---");
			return false;
		}
		return true;
	}
	public static void mouseHover(WebDriver driver,WebElement element)
	{
		new Actions(driver).moveToElement(element).build().perform();
	}
    public static void mouseHoverAndClick(WebDriver driver,WebElement element)
    {
        Actions actions = new Actions(driver);
        actions.moveToElement(element).build().perform();
        actions.moveToElement(element).click().build().perform();
    }

    public static void jsClick(WebDriver driver,By css_locator)
    {
    	jsClick(driver, getByValue(css_locator) );
    }

    public static void jsClick(WebDriver driver,String css_selector)
    {
    	jsClick(driver,css_selector,0);
    }

    public static void jsClick(WebDriver driver,String css_selector,int index)
    {
    	String js="document.querySelectorAll(\""+css_selector+"\")["+index+"].click();";
		((JavascriptExecutor) driver).executeScript(js);
    }

	public static void jsClick(WebDriver driver,WebElement element)
	{
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

    public static void dragAndDrop(WebDriver driver,WebElement element_to_drag,WebElement element_to_drop)
    {
    	dragAndDrop(driver,element_to_drag,element_to_drop,false);
    }

    public static void dragAndDrop(WebDriver driver,WebElement element_to_drag,WebElement element_to_drop,boolean is_double_click_after_dropping)
    {
    	inViewPort(element_to_drag);

		Actions builder = new Actions(driver);
		Action dragAndDrop=null;

		if(is_double_click_after_dropping)
		{
			dragAndDrop = builder.clickAndHold(element_to_drag)
			.moveToElement(element_to_drop)
			.release(element_to_drop)
			.doubleClick(element_to_drop)
			.build();
		}
		else
		{
			dragAndDrop = builder.clickAndHold(element_to_drag)
			.moveToElement(element_to_drop)
			.release(element_to_drop)
			.build();
		}

		dragAndDrop.perform();
    }

	public static void inViewPort(WebElement e)
	{
		Coordinates ord = ((Locatable)e).getCoordinates();
		ord.inViewPort();

		CommonUtil.sleep(500);
	}

	public static void inViewPortSafe(WebDriver driver,WebElement element,int pixels_to_scroll)
	{
		//not to be used for dropdowns,popup etc,
		scrollToTop(driver);
		inViewPort(element);
		scrollIntoView(driver,element);
		((JavascriptExecutor) driver).executeScript("javascript:window.scrollBy(0,"+pixels_to_scroll+")");
	}

	public static void scrollIntoView(WebDriver driver,By... by_objects)
	{
		scrollIntoView(driver,false,CommonUtil.getElement(driver,by_objects));
	}

	public static void scrollIntoView(WebDriver driver,boolean isAlignToTop,By... by_objects)
	{
		scrollIntoView(driver,isAlignToTop,CommonUtil.getElement(driver,by_objects));
	}

	public static void scrollIntoView(WebDriver driver,WebElement element)
	{
		//bottom of element will be aligned to bottom of visible area
		scrollIntoView(driver,false,element);
	}

	public static void scrollIntoView(WebDriver driver,boolean isAlignToTop,WebElement element)
	{
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView("+isAlignToTop+");", element);
	}

	public static void inViewPortSafe(WebDriver driver,WebElement element)
	{
		inViewPortSafe(driver,element,50);
	}

	public static void scrollToTop(WebDriver driver)
	{
		((JavascriptExecutor) driver).executeScript("scroll(0,0)");
	}

	public static void scrollToBottomOfPage(WebDriver driver)
	{
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public static void click(WebDriver driver,By... by_elements)
	{
		WebElement element=CommonUtil.getElement(driver,by_elements);
		clickWebElement(driver,element);
	}

	public static void click(WebDriver driver,WebElement element)
	{
		clickWebElement(driver,element);
	}

	public static void clickWebElement(WebDriver driver,By... by_elements)
	{
		clickWebElement(driver,getElement(driver,by_elements));
	}
	public static void clickWebElement(WebDriver driver,WebElement element)
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().build().perform();
	}

	public static void doubleClick(WebDriver driver,WebElement element)
	{
		Actions action = new Actions(driver);
		action.doubleClick(element).perform();	
	}

	public static void sendEnterKey(WebDriver driver,WebElement ele)
	{
		sendKeysToWebElement(driver,ele,Keys.RETURN);
	}

	public static void sendKeysToWebElement(WebDriver driver,WebElement ele,Keys key)
	{
		CommonUtil.inViewPort(ele);
		Actions actions = new Actions(driver);
		actions.moveToElement(ele).click().build().perform();
		ele.clear();	
		actions.moveToElement(ele).sendKeys(key).build().perform();
	}

	public static void sendKeysToWebElement(WebDriver driver,WebElement ele,String message)
	{
		CommonUtil.inViewPort(ele);
		Actions actions = new Actions(driver);
		ele.clear();
		actions.moveToElement(ele).click().build().perform();
		actions.moveToElement(ele).sendKeys(message).build().perform();

		String actualMessage = "";
		try
		{
			String tag_name = ele.getTagName();
			if(tag_name.equals("input") || tag_name.equals("textarea"))
			{
				actualMessage = ele.getAttribute("value");
			}
			else
			{
				actualMessage = ele.getAttribute("innerText");
			}
			if(!actualMessage.contains(message))
			{
				etest = ComplexReportFactory.getTest("Sending input keys");
				ComplexReportFactory.setValues(etest,"Automation","Issues");
				etest.log(Status.INFO,"<pre>Expected Message : "+message+" Actual message : "+actualMessage+"</pre>");
				TakeScreenshot.infoScreenshot(driver,etest);
				ComplexReportFactory.closeTest(etest);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void sendKeysLikeHuman(WebElement input, String text) 
	{
		int interval = 182;

		input.clear();

		for (char c : text.toCharArray()) 
		{
			String character = String.valueOf(c);
			input.sendKeys(character);
			CommonUtil.sleep(interval);
		}
	}

	public static void sendKeysByChar(WebDriver driver,WebElement input,String text) 
	{
		int interval = 5;

        Actions actions= new Actions(driver);

        actions.moveToElement(input);
        actions.click();
        actions.build().perform();

		for (char c : text.toCharArray()) 
		{
			String character = String.valueOf(c);
			new Actions(driver).sendKeys(character).build().perform();
			CommonUtil.sleep(interval);
		}
	}


	public static void sendKeysLineByLine(WebDriver driver,WebElement input,String text) 
	{
        Actions actions= new Actions(driver);

        actions.moveToElement(input);
        actions.click();
        actions.build().perform();

        String[] lines=text.split("\n");

		for (String line : lines) 
		{
			new Actions(driver).sendKeys(line).build().perform();
			new Actions(driver).sendKeys(Keys.RETURN).build().perform();
		}
	}

	public static void removeCharsFromElement(WebElement element,int chars_to_remove)
	{
		element.click();

		for(int i=0;i<chars_to_remove;i++)
		{
			element.click();
			element.sendKeys(Keys.BACK_SPACE);
		}
	}

	public static void waitTillWebElementDisplayed(WebDriver driver,final WebElement ele,int time,final boolean isDisplayed)
	{

		FluentWait wait=CommonUtil.waitreturner(driver,time,250);
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(ele.isDisplayed()==isDisplayed)
                    {
                        return true;
                    }
                    return false;
                }
            });
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void waitTillWebElementDisplayed(WebDriver driver,final WebElement ele,int time)
	{
		waitTillWebElementDisplayed(driver,ele,time,true);
	}

	public static void waitTillWebElementDisplayed(WebDriver driver,final WebElement ele)
	{
		waitTillWebElementDisplayed(driver,ele,10,true);
	}

	public static boolean waitTillWebElementContainsAttributeValue(final WebElement web_element,final String attribute,final String value)
	{
		return waitTillWebElementContainsAttributeValue(web_element,attribute,value,true);
	}

	public static boolean waitTillWebElementDoesNotContainAttributeValue(final WebElement web_element,final String attribute,final String value)
	{
		return waitTillWebElementContainsAttributeValue(web_element,attribute,value,false);
	}

	public static boolean waitTillWebElementContainsAttributeValue(final WebElement web_element,final String attribute,final String value,final boolean isContains)
	{

		FluentWait wait = new FluentWait(web_element);
		wait.withTimeout(20,TimeUnit.SECONDS);
		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		try
		{
			wait.until(new Function<WebElement,Boolean>()
			{
				public Boolean apply(final WebElement web_element)
				{
					if(web_element!=null && web_element.getAttribute(attribute)!=null && web_element.getAttribute(attribute).contains(value)==isContains)
					{
						return true;
					}
					return false;
				}
			});

			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	public static boolean waitTillTextFound(WebDriver driver,final WebElement ele,final String expected_text)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,10,250);

		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(ele.getText().toLowerCase().contains(expected_text.toLowerCase()))
                    {
                        return true;
                    }
                    return false;
                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public static boolean isTextFound(WebDriver driver,final WebElement ele,final String expected_text) throws Exception
	{
		// FluentWait wait=CommonUtil.waitreturner(driver,10,250);



		// try
		// {
		// 	wait.until(new Function<WebDriver,Boolean>()
		// 	{
  //               public Boolean apply(WebDriver driver)
  //               {

  //                   if(ele.getText().toLowerCase().contains(expected_text.toLowerCase()))
  //                   {
  //                       return true;
  //                   }
  //                   return false;
  //               }
  //           });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// 	return false;
		// }

		return waitTillTextFound(driver,ele,expected_text);

	}

	public static WebElement getVisibileWebElementFromList(WebDriver driver,List<WebElement> elements)
	{
		for(WebElement ele : elements)
		{
			if(ele.isDisplayed())
			{
				return ele;
			}
		}
		return null;
	}

	public static WebElement getVisibileWebElementFromList(List<WebElement> elements)
	{
		return getVisibileWebElementFromList(null,elements);
	}


    public static void CloseBrowser(WebDriver driver)
	{
		driver.quit();
	}

	public static void refreshPage(WebDriver driver)
	{
		driver.navigate().refresh();
	}

    public static Integer stringOccurence(String mainString, String subString)
    {
        int lastIndex = 0;
        int count = 0;
        
        while(lastIndex != -1){
            
            lastIndex = mainString.indexOf(subString,lastIndex);
            
            if(lastIndex != -1){
                count ++;
                lastIndex += subString.length();
            }
        }
        
        return count;
    }

    public static WebElement getElementByAttributeValue(WebDriver driver,By object,By groupByElements,String attr,String value)
	{
		return getElementByAttributeValue(CommonUtil.getElement(driver,object),groupByElements,attr,value);
	}

	public static WebElement getElementByAttributeValue(WebElement element,By groupByElements,String attr,String value)
	{
		return getElementByAttributeValue(element.findElements(groupByElements),attr,value);
	}

    public static WebElement getElementByAttributeValue(List<WebElement> elements,String attribute,String value)
	{
		for(WebElement element : elements)
		{
			try
			{
				if(element.getAttribute(attribute)!=null && element.getAttribute(attribute).equals(value))
				{
					return element;	
				}
			}
			catch (Exception e) 
			{
				doNothing();
			}
		}

		for(WebElement element : elements)
		{
			try
			{
				if(element.getAttribute(attribute)!=null && element.getAttribute(attribute).contains(value))
				{
					return element;	
				}
			}
			catch(Exception e)
			{
				doNothing();
			}
		}

		for(WebElement element : elements)
		{
			try
			{
				if(element.getAttribute(attribute)!=null && element.getAttribute(attribute).matches(value))
				{
					return element;	
				}
			}
			catch(Exception e)
			{
				doNothing();
			}
		}		

		return null;
	}

    public static List<String> getAttributesFromList(List<WebElement> elements,String attribute)
	{
		ArrayList<String> attributes = new ArrayList<String>();

		for(WebElement element : elements)
		{
			if(element.getAttribute(attribute)!=null)
			{
				attributes.add(element.getAttribute(attribute));
			}
		}

		return attributes;
	}


	public static List<WebElement> getChildElementOfElementListBy(List<WebElement> elements,By by_object)
	{
		return getChildElementOfElementListBy(elements,by_object,true);
	}

	public static List<WebElement> getChildElementsOfElementListBy(List<WebElement> elements,By by_object)
	{
		return getChildElementOfElementListBy(elements,by_object,false);
	}

	public static List<WebElement> getChildElementOfElementListBy(List<WebElement> elements,By by_object,boolean isFindOneChildOnly)
	{
		List<WebElement> child_elements = new ArrayList<WebElement>();
		
		for(WebElement element : elements)
		{
			List<WebElement> located_elements_list=element.findElements(by_object);

			if(located_elements_list.size()>0)
			{
				if(isFindOneChildOnly)
				{
					child_elements.add(located_elements_list.get(0));
				}
				else
				{
					child_elements.addAll(located_elements_list);
				}
			}
		}

		return child_elements;
	}


	public static void sleep(long milliseconds)
	{
		//to avoid throwing unnecessary InterruptedExceptions
		try
		{
			Thread.sleep(milliseconds);
		}
		catch(Exception e)
		{
			System.out.println("THREAD.SLEEP() ERROR"+milliseconds);
			e.printStackTrace();
		}
	}

	public static String format(String str)
	{
		return str.replaceAll("[\\t\\n\\r\\s]+","").trim();
	}

	public static boolean checkStringNotEquals(String expected_text,String actual_text)
	{
		return (compareStringAndLog(expected_text,actual_text,null,false,false,null)==false);
	}

	public static boolean compareStringAndLog(String expected_text,String actual_text,String description,boolean isCheckEquals,boolean isLog,ExtentTest etest)
	{
		String formatted_actual_text=format(actual_text);
		String formatted_expected_text=format(expected_text);

		if(formatted_expected_text.equals("")==true && formatted_actual_text.equals("")==false)
		{
			if(isLog && etest!=null)
			{
				etest.log(Status.FAIL,"Expected "+description+" value is empty (expected :  <pre>'"+escape(expected_text)+"'</pre> actual : <pre>'"+escape(actual_text)+"'</pre>)");
			}
			return false;
		}

		if(  (  formatted_actual_text.equals(formatted_expected_text) && isCheckEquals  ) || (formatted_actual_text.contains(formatted_expected_text) && !isCheckEquals  )  )
		{
			if(isLog && etest!=null)
			{
				etest.log(Status.PASS,"Expected "+description+" (expected :  <pre>'"+escape(expected_text)+"'</pre> actual : <pre>'"+escape(actual_text)+"'</pre>) was found.");
			}
			return true;
		}
		else
		{
			if(isLog && etest!=null)
			{
				etest.log(Status.FAIL,"Expected "+description+" was NOT found. Actual : <pre>'"+escape(actual_text)+"'</pre> Expected :<pre>'"+escape(expected_text)+"'</pre>");
			}
			return false;
		}
	}

	public static boolean isEquals(String expected_text,String actual_text)
	{
		return checkStringEqualsAndLog(expected_text,actual_text,null,null);
	}

	public static boolean isContains(String expected_text,String actual_text)
	{
		return checkStringContainsAndLog(expected_text,actual_text,null,null);
	}

	public static boolean checkStringEqualsAndLog(String expected_text,String actual_text,String description,ExtentTest etest)
	{
		return compareStringAndLog(expected_text,actual_text,description,true,true,etest);
	}

	public static boolean checkStringContainsAndLog(String expected_text,String actual_text,String description,ExtentTest etest)
	{
		return compareStringAndLog(expected_text,actual_text,description,false,true,etest);
	}

	public static boolean matchStringAndLog(String regex,String string_to_match,String description,ExtentTest etest)
	{
		if(string_to_match.matches(regex))
		{
			etest.log(Status.PASS,"Expected "+description+" (expected match : '"+regex+"' actual : '"+string_to_match+"') was matched.");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Expected "+description+" was NOT matched. Actual : '"+string_to_match+"' Expected match :'"+regex+"'");
			return false;
		}
	}



	public static boolean isFail(Hashtable<String,Boolean> result_hashtable,String... keys)
	{

		for(String key:keys)
		{
			if(result_hashtable.get(key)!=null && result_hashtable.get(key)==true)
			{

			}
			else
			{
				return true;
			}
		}

		return false;
	}

	public static boolean isChecked(String result_key,Hashtable<String,Boolean> result_hashtable)
	{
		if(result_hashtable==null)
		{
			return true;//isChecked will be returned as true but it is still not checked. But if the result hashtable is not defined yet it will cause an exception. So returning true so no action will be taken
		}

		if(result_hashtable.containsKey(result_key))
		{
			return true;
		}
		return false;
	}

	public static void navigateToPreviousPage(WebDriver driver)
	{
		((JavascriptExecutor) driver).executeScript("window.history.go(-1);");
	}

	public static void closeAllTabs(WebDriver driver)
	{
		//closes all tabs except the first one
		try
		{
			int attempts=0;

			while(getTabsCount(driver)>1 && attempts<5)
			{
				switchToTab(driver);
				closeCurrentTab(driver);
				attempts++;
			}

			switchToTab(driver,0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			switchToTab(driver,0);
			throw e;
		}
	}

	public static void switchToTab(WebDriver driver)
	{
		switchToTab(driver,-1);
	}

	public static void switchToTab(WebDriver driver,int tab_index)
	{
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		if(tab_index != -1)
		{
			driver.switchTo().window(tabs.get(tab_index));
		}
		else
		{
			driver.switchTo().window(tabs.get(tabs.size()-1));
		}
	}

	public static int getTabsCount(WebDriver driver)
	{
		return new ArrayList<String> (driver.getWindowHandles()).size();
	}

	public static void waitTillNewTabOpens(final WebDriver driver,final int current_tab_count)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,10,250);

		wait.until(new Function<WebDriver,Boolean>()
		{
            public Boolean apply(WebDriver driver)
            {
                if(getTabsCount(driver)>current_tab_count)
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static void waitTillTabCloses(final WebDriver driver,final int current_tab_count)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,10,250);

		wait.until(new Function<WebDriver,Boolean>()
		{
            public Boolean apply(WebDriver driver)
            {
                if(getTabsCount(driver)<current_tab_count)
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static void closeCurrentTab(WebDriver driver)
	{
		driver.close();
		closeAlerts(driver);
	}

    public static Collection getDifference(Collection old_collection,Collection new_collection)
    {
    	return com.zoho.livedesk.util.common.actions.ChatRouting.getDifference(old_collection,new_collection);
    }

    public static String getByValue(By by)
    {
    	String value=by.toString();
    	return value.replaceAll("By\\..+: ","").replaceAll("\\s+","");
    }

    public static String getByType(By by)
    {
    	String value=by.toString();
    	value=value.split("By.")[1].split(":")[0];
    	return value;
    }

    public static boolean isNull(String str)
    {
    	if(str==null)
    	{
    		return true;
    	}

    	str=format(str);

    	return str.equals("");
    }

    public static boolean hasClass(WebElement element,By class_by)
    {
    	return hasClass(element,CommonUtil.getByValue(class_by));
    }

    public static boolean hasClass(WebElement element,String expected_classname)
    {
    	return isAttributeContainsWord(element,"class",expected_classname);
    }

    public static boolean isAttributeContainsWord(WebElement element,String attribute,String expected_word) 
    {
    	if(element.getAttribute(attribute)==null)
    	{
    		return false;
    	}

		String values = element.getAttribute(attribute);

		for (String value : values.split(" ")) 
		{
		    if(value.equals(expected_word)) 
		    {
		        return true;
		    }
    	}

		return false;
	}

	public static boolean compareHashtable(Hashtable<String,String> expected,Hashtable<String,String> actual,ExtentTest etest)
	{
		int failcount=0;

        Set<String> expected_keys = expected.keySet();

        for(String expected_key : expected_keys)
        {
        	if(actual.containsKey(expected_key))
        	{
        		String expected_value=expected.get(expected_key);
        		String actual_value=actual.get(expected_key);

        		if(CommonUtil.checkStringContainsAndLog(expected_value,actual_value,"value for key '"+expected_key+"' ",etest)==false)
        		{
        			failcount++;
        		}
        	}
        	else
        	{
        		failcount++;
        		etest.log(Status.FAIL,"Expected key '"+expected_key+"' was not found. Expected key :"+expected_key+" Actual values :"+actual.toString());
        	}
        }

        return CommonUtil.returnResult(failcount);
	}

	public static boolean compareList(List<String> expected,List<String> actual,String description,ExtentTest etest)
	{
		expected=new ArrayList(expected);
		actual=new ArrayList(actual);

		String expected_backup=expected.toString();
		String actual_backup=actual.toString();

		expected.removeAll(actual);

		if(expected.isEmpty())
		{
			etest.log(Status.INFO,"Expected ("+expected_backup+") and actual ("+actual_backup+") '"+description+"' list matches");
			return true;
		}
		else
		{
			etest.log(Status.INFO,"Expected ("+expected_backup+") and actual ("+actual_backup+") '"+description+"' list does NOT match. here are the values missing --> "+expected.toString());			
			return false;
		}
	}

	public static boolean isListContains(List<String> list,String data)
	{
		for(String list_value : list)
		{
			if(list_value.contains(data))
			{
				return true;
			}
		}

		return false;
	}

	public static int getOccurences(String data,String search)
	{
		return StringUtils.countMatches(data,search);
	}

	public static boolean isCharMissing(String actual_data,String expected_data,ExtentTest etest)
	{
		String missing_chars=getMissingChar(actual_data,expected_data);

		if(missing_chars==null || missing_chars.equals(""))
		{
			return false;
		}

		if(etest!=null)
		{
			etest.log(Status.INFO,missing_chars.length()+" characters '"+missing_chars+"' were missing from '"+actual_data+"'. (actual string :'"+actual_data+"' expected_string : '"+expected_data+"')");
		}

		return true;
	}

	public static String getMissingChar(String actual_data,String expected_data)
	{
		actual_data=format(actual_data);
		expected_data=format(expected_data);

		if(isEquals(expected_data,actual_data))
		{
			return null;
		}

		int char_missing_from_index=-1;

		for (int i = 0; i < expected_data.length(); i++)
		{
		    char actual = actual_data.charAt(i);
		    char expected = expected_data.charAt(i);

		    if(expected!=actual)
		    {
		    	char_missing_from_index=i;
		    	break;
		    }
		}

		return expected_data.substring(char_missing_from_index);
	}

	public static String listToString(List<String> list)
	{
		//list converted to string by adding '|' between values for e.g. 1 2 3 4 5 will be converted to |1||2|3|4|5|, we can use this to check if string is present using string contains |<value-here>| 

		String str="|";

		for(String list_value : list)
		{
			str=str+list_value+"|";
		}

		return str;
	}

	public static void waitTillTimerRunsOut(Long start_time,int seconds_to_wait)
	{
		Long current_time=new Long(System.currentTimeMillis());

		//remaining_wait_time=total_wait_time-already_waited_time
		Long remaining_time_to_wait=(seconds_to_wait*1000)-(current_time-start_time);

		if(remaining_time_to_wait<=0)
		{
			return;
		}

		CommonUtil.sleep(remaining_time_to_wait);
	}

	public static ArrayList<String> getAllMatches(String sample,String regex)
	{
		ArrayList<String> allMatches = new ArrayList<String>();

		Matcher m = Pattern.compile(regex).matcher(sample);

		while (m.find()) 
		{
			allMatches.add(m.group());
		}

		return allMatches;
	}

	public static boolean isTimeout(Long wait_start_time,int time_to_wait_in_mins)
	{
		Long current_time=new Long(System.currentTimeMillis());

		if( (current_time-wait_start_time) < (time_to_wait_in_mins*60*1000) )
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	public static String toCommaSeperatedString(List<String> list)
	{
		if(list.isEmpty())
		{
			return "";
		}

		String joined_string=StringUtils.join(list, ",");

		if(joined_string.substring(joined_string.length()-1).equals(","))
		{
			joined_string=joined_string.substring(0,joined_string.length()-1);
		}

		return joined_string;
	}

	public static void addIfNotNull(Hashtable<String,String> hashtable,String key,String value)
	{
		if(key!=null && value!=null)
		{
			hashtable.put(key,value);
		}
	}

	public static String escape(String source)
	{
		return escapeHtml4(source);
	}

	public static void copyAllToClipboard(WebDriver driver,ExtentTest etest)
	{
		CommonUtil.getElement(driver,By.tagName("body")).click(); // Set focus on target element by clicking on it

		Actions actions = new Actions(driver);

		if(Driver.isMacOS(driver))
		{
			actions.sendKeys(Keys.chord(Keys.COMMAND, "A")).build().perform();
			CommonUtil.sleep(250);
			actions.sendKeys(Keys.chord(Keys.COMMAND, "C")).build().perform();
		}
		else
		{
			actions.sendKeys(Keys.chord(Keys.CONTROL, "A")).build().perform();
			CommonUtil.sleep(250);
			actions.sendKeys(Keys.chord(Keys.CONTROL, "C")).build().perform();
		}

		etest.log(Status.INFO,"All text in this page have been copied to clipboard");
		TakeScreenshot.infoScreenshot(driver,etest);

	}

	public static void copyToClipboardFromTextarea(WebDriver driver,ExtentTest etest)
	{
		WebElement input=CommonUtil.getElement(driver,By.id("txt"));
		input.click();// Set focus on target element by clicking on it
		etest.log(Status.INFO,"Below text is copied");
		TakeScreenshot.infoScreenshot(driver,etest);
	}


	public static void pasteFromClipboard(WebDriver driver,ExtentTest etest,WebElement element)
	{
		element.click();// Set focus on target element by clicking on it
		//now paste your content from clipboard
		
		Actions actions = new Actions(driver);

		if(Driver.isMacOS(driver))
		{
			etest.log(Status.INFO,"Performing COMMAND+V for MacOS");
			actions.moveToElement(element); 
			actions.click();
			actions.keyDown(Keys.COMMAND).sendKeys("v").keyUp(Keys.COMMAND).perform();

			TakeScreenshot.infoScreenshot(driver,etest);
		}
		else
		{
			etest.log(Status.INFO,"Performing CTRL+V for Linux");

			actions.moveToElement(element); 
			actions.click();
			actions.keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).perform();

			TakeScreenshot.infoScreenshot(driver,etest);
		}

		etest.log(Status.INFO,"Text copied to clipboard was pasted.");
		TakeScreenshot.infoScreenshot(driver,etest);
	}

	public static int getCssSelectorCount(WebDriver driver,By css_selector)
	{
		String selector=CommonUtil.getByValue(css_selector);
		String script="document.querySelectorAll(\""+selector+"\").length";
		String count=ExecuteStatements.get(driver,script);
		return Integer.parseInt(count);
	}

	public static String encode(String url)
	{
		try
		{
			return URIUtil.encodeQuery(url);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return url;
	}

	public static void doNothing()
	{
		String forEmptyCatch = "This method was created for empty catch statements to skip code check errors";
	}

	public static void print(Object... text) 
    {
		String toPrint = "";
		for(int i = 0; i < text.length; i++)
		{
			toPrint += text[i];
		}
        java.io.PrintStream out = System.out;
        out.println(toPrint);
    }

    public static void printStackTrace(Exception e)
    {
    	e.printStackTrace();
    }

    public static String getTextFromClipboard(WebDriver driver,ExtentTest etest)
    {
        String url="http://"+Util.serverHostName+":"+Util.serverPortNumber+com.zoho.livedesk.util.common.actions.bots.BotScripts.TEXTAREA_URL;

        String clipboard_text=null;

        try
        {
            ExecuteStatements.openNewTab(driver,url);

	        Actions actions= new Actions(driver);

	        WebElement input=CommonUtil.getElement(driver,By.id("txt"));
	        
	        actions.moveToElement(input);
	        actions.click();
	        actions.build().perform();

           	pasteFromClipboard(driver,etest, getElement(driver,By.id("txt")) ); 	

           	clipboard_text=CommonUtil.getElement(driver,By.id("txt")).getAttribute("innerText");
           	etest.log(Status.INFO,"The following content was found in the clipboard -->"+clipboard_text);
           	TakeScreenshot.infoScreenshot(driver,etest);

            CommonUtil.closeCurrentTab(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,e);
            CommonUtil.switchToTab(driver,0);
            throw new ZohoSalesIQRuntimeException("Unable to copy code to clipboard");
        }

        CommonUtil.switchToTab(driver,0);

        return clipboard_text;
    }

    public static void goToSalesIQURL(WebDriver driver)
    {
    	try
    	{
	    	String portal="";

	    	try
	    	{
	    		portal=ExecuteStatements.getPortal(driver);
	    	}
	    	catch(Exception e1)
	    	{

	    	}

	        CommonUtil.closeAllTabs(driver);
	        ExecuteStatements.openNewTab(driver,"https://www.wikipedia.org");
	        CommonUtil.switchToTab(driver,0);
	        CommonUtil.closeCurrentTab(driver);
	        CommonUtil.switchToTab(driver,0);
	        driver.get(Util.siteNameout()+"/"+portal);
    	}
    	catch(Exception e)
    	{
    		CommonUtil.printStackTrace(e);
    	}
    }

    public static void acceptAlertIfExists(WebDriver driver)
    {
    	try
    	{
    		driver.switchTo().alert().accept();
    	}
    	catch(Exception e)
    	{
    		CommonUtil.printStackTrace(e);
    	}
    }

    public static void dismissAlertIfExists(WebDriver driver)
    {
    	try
    	{
    		driver.switchTo().alert().dismiss();
    	}
    	catch(Exception e)
    	{
    		CommonUtil.printStackTrace(e);
    	}
    }

    public static void closeAlerts(WebDriver driver)
    {
		acceptAlertIfExists(driver);
		dismissAlertIfExists(driver);
    }

    public static void waitTillURLValid(String url) throws Exception
    {
    	for(int i=0;i<=10;i++)
    	{
    		try
    		{
	    		if(com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(url))
	    		{
	    			return;
	    		}
    		}
    		catch(Exception e)
    		{
    			if(i==10)
    			{
    				throw e;
    			}
    		}

    		sleep(5000);
    	}
    }

    public static int getRandomId()
	{
		String label = CommonUtil.getUniqueMessage();

		label = label.substring(label.length()-3,label.length());

		int randomId = Integer.parseInt(label);

		return randomId;
	}
}
