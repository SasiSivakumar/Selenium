//$Id$
package com.zoho.livedesk.util.common;

import junit.framework.TestCase;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.*;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.util.common.CommonUtil;
import java.util.List;
import java.io.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.SCPUtil;

import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;
import net.lingala.zip4j.core.ZipFile;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class CryptoUtil
{
    public static boolean isZipPasswordProtected(String zip_file_path) throws Exception
    {
        ZipFile zipFile = new ZipFile(zip_file_path);
        return zipFile.isEncrypted();
    }

    public static boolean isZipPassword(ExtentTest etest,String file_path,String password) throws ZipException
    {
        etest.log(Status.INFO,"Attempting to unzip the file : "+file_path+( (password!=null) ? " with password '"+password+"'" : " without pasword") );

        String extractedZipFilePath=SCPUtil.getSCPFileDownloadDirectory();

        ZipFile zipFile = new ZipFile(file_path);

        try
        {
            if(zipFile.isEncrypted())
            {
                etest.log(Status.INFO,"Zip file was found as encrypted");
                zipFile.setPassword(password);
            }

            zipFile.extractAll(extractedZipFilePath);
        }
        catch (ZipException e1) 
        {
            TakeScreenshot.log(e1,etest,Status.INFO);
            etest.log(Status.INFO,"Password '"+password+"' did not match for file "+file_path);
            return false;
        }
        catch(Exception e)
        {
            etest.log(Status.INFO,"Error occured while attempting to unzip "+file_path);
            TakeScreenshot.log(e,etest,Status.INFO);
            e.printStackTrace();
            return false;
        }

        return true;
    }

    public static boolean isPDFPasswordProtected(String pdf_file_path) throws Exception
    {
        PDDocument document = PDDocument.load(pdf_file_path);
        return document.isEncrypted();
    }

    public static boolean isPDFPassword(ExtentTest etest,final String pdf_file_path,String password) throws Exception
    {
        etest.log(Status.INFO,"Attempting to read the file : "+pdf_file_path+( (password!=null) ? " with password '"+password+"'" : " without pasword") );

        try
        {

            File originalPDF = new File(pdf_file_path);
            PDFParser parser = new PDFParser(new BufferedInputStream(new FileInputStream(originalPDF)));
            parser.parse();
            PDDocument originialPdfDoc = parser.getPDDocument();
            boolean isOriginalDocEncrypted = originialPdfDoc.isEncrypted();
            if (isOriginalDocEncrypted) 
            {
                originialPdfDoc.openProtection(new StandardDecryptionMaterial(password));
            }
        }
        catch(CryptographyException e1)
        {
            etest.log(Status.INFO,"Password '"+password+"' did not match for file "+pdf_file_path);
            return false;
        }
        catch(Exception e)
        {
            etest.log(Status.INFO,"Password was matched, But error occured while attempting to read "+pdf_file_path);
            TakeScreenshot.log(e,etest,Status.INFO);
            e.printStackTrace();
        }

        return true;
    }

    //For xlsx,xls files
    public static boolean isDocumentPasswordProtected(ExtentTest etest,String file_path) throws Exception
    {
        return (!isDocumentPassword(etest,file_path,""));
    }

    public static boolean isDocumentPassword(ExtentTest etest,String file_path,String password) throws Exception
    {
        etest.log(Status.INFO,"Attempting to read the file : "+file_path+( (password!=null && password.equals("")==false)  ? " with password '"+password+"'" : " without pasword") );

        System.out.println("~~isDocumentPassword start");

        try
        {
            ZipSecureFile.setMinInflateRatio(0);
            Workbook wb = WorkbookFactory.create(new File(file_path), password);
        System.out.println("~~isDocumentPassword done");

        }
        catch(EncryptedDocumentException e)
        {
                    System.out.println("~~isDocumentPassword ecry exp");

            etest.log(Status.INFO,"Password protected document could not opened"+( (password!=null && password.equals("")==false)  ? " with password '"+password+"'" : " without pasword") );
            TakeScreenshot.log(e,etest,Status.INFO);
            e.printStackTrace();
            return false;
        }
        catch(Exception e)
        {
                    System.out.println("~~isDocumentPassword normal exp");

            TakeScreenshot.log(e,etest,Status.INFO);  
            return false;          
        }
        return true;
    } 
}
