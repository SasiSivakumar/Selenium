//$Id$
package com.zoho.livedesk.util.common;

import java.net.*;
import java.util.Set;
import java.util.Date;
import java.util.List;
import java.util.HashSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import com.google.common.base.Function;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.crmplus.others.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.crmplus.chats.CRMPChatWindow;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
public class Functions
{
    public static boolean login_success = true;

    public static int failedLoginCount;

    public static final int FAILED_LOGINS_THRESHOLD=5;// Automation will stop if failedLoginCount>=FAILED_LOGINS_THRESHOLD

    public static void init()
    {
        failedLoginCountInit();
    }

    public static void failedLoginCountInit()
    {
        failedLoginCount=0;
    }

    public static int getFailedLoginCount()
    {
        return failedLoginCount;
    }

    public static void trackFailedLogin()
    {
        failedLoginCount++;
    }

    public static boolean isTooManyLoginsFailed()
    {
        return (failedLoginCount>FAILED_LOGINS_THRESHOLD);
    }

    public static boolean login(WebDriver driver,String module) throws Exception
    {
        boolean login=false;

        boolean isCleanupLogin=module.contains(com.zoho.livedesk.util.Cleanup.CLEANUP_IDENTIFIER);

        for(int i=0;i<3;i++)
        {
            boolean isFirstAttempt=(i==0);
            boolean isLastAttempt=(i==2);

            boolean isRetrying=isFirstAttempt?false:true;

            login=login(driver,module,isRetrying);

            String test_name="Login Failure For  - "+module.toUpperCase().replace("_"," ");

            if(SalesIQAutomationExceptionHandler.isStatusAndWMSBarHidden(driver))
            {
                ExtentTest etest = ComplexReportFactory.getTest(test_name);
                ComplexReportFactory.setValues(etest,"Automation","WMS - IAM Auth Failure Issues");
                etest.log(Status.FAIL,"WMS and Status bar not found. Logging out and retrying again.");
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.addSiteStateToReport(driver,etest);

                if(!isCleanupLogin)
                {
                    SalesIQAutomationExceptionHandler.setWMSErrorInfo(driver);
                }

                logout(driver,false);

                if(isLastAttempt)
                {
                    etest.log(Status.FAIL,"WMS and Status bar not found even during login attempt "+(i+1)+". WMS maybe down");

                    SalesIQAutomationExceptionHandler.reportWMSAuthErrorAsFalsePositive(driver);

                    SalesIQAutomationExceptionHandler.handleWMSDown(driver,etest);
                }

                ComplexReportFactory.closeTest(etest,false);
            }
            else
            {
                if(isFirstAttempt==false)
                {
                    ExtentTest etest = ComplexReportFactory.getTest(test_name);
                    etest.log(Status.FAIL,"WMS and Status bar was found during the login attempt "+(i+1)+". WMS may not be down. WMS - IAM Auth Failure Detected");
                    ComplexReportFactory.closeTest(etest,false);
                }

                break;
            }
        }

        return login;
    }

    
    public static boolean login(WebDriver driver,String module,boolean isRetrying) throws Exception
    {
        String loginId = "";
        Boolean checkStatic = module.contains("idc_")?true:false;

        ExtentTest etest=null;

        if(module.contains(com.zoho.livedesk.util.Cleanup.CLEANUP_IDENTIFIER))
        {
            module=module.replace(com.zoho.livedesk.util.Cleanup.CLEANUP_IDENTIFIER,"");

            etest = ComplexReportFactory.getTest("Login for Cleanup - "+module.toUpperCase().replace("_"," "));
            ComplexReportFactory.setValues(etest,"Cleanup","Login");

        }

        else
        {
            etest = ComplexReportFactory.getTest("Login - "+module.toUpperCase().replace("_"," "));
            ComplexReportFactory.setValues(etest,"Automation","Login");
        }
        
        if(checkStatic)
        {
            module =  module.replace("idc_","");
        }

        try
        {
            boolean isAutomationUnderDevelopmentMode = Boolean.parseBoolean(ConfManager.getRealValue("developer_mode"));
            if(isAutomationUnderDevelopmentMode)
            {
                module="developer_mode";
            }   
        }
        catch(Exception e)
        {
            System.out.println("~~Development Mode Login Failed");
            e.printStackTrace();
        }

        if(isRetrying)
        {
            etest.log(Status.WARNING,"Retrying login due to issues in product");
        }
        
        String loginname = ConfManager.getRealValue(module+"_username");
        String pswd = ConfManager.getRealValue(module+"_password");
        String portal = ConfManager.getRealValue(module+"_portal");
            
        //make null if not found

        if(portal.equals(module+"_portal"))
        {
            portal=null;
        }

        boolean login = false;
        
        try
        {
            String loginsite = Util.siteNameout();
            
            String accountsURL = "";
            String salesiqURL = "";
            
            if(checkStatic)
            {
                accountsURL = "https://accounts.zoho.com/";
                salesiqURL = "https://salesiq.zoho.com/";
            }
            else if(loginsite.contains("lab2salesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                salesiqURL = "https://lab2salesiq.localzoho.com/";
            }
            else if(loginsite.contains("labsalesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                salesiqURL = "https://labsalesiq.localzoho.com/";
            }
            else if(loginsite.contains("crmplus-salesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                salesiqURL = "https://crmplus-salesiq.localzoho.com/";
            }
            else if(loginsite.contains("salesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                salesiqURL = "https://salesiq.localzoho.com/";
            }
            else if(loginsite.contains("presalesiq.zoho.com"))
            {
                accountsURL = "https://accounts.zoho.com/";
                salesiqURL = "https://presalesiq.zoho.com/";
            }
            else
            {
                accountsURL = "https://accounts.zoho.com/";
                salesiqURL = "https://salesiq.zoho.com/";
            }

            if(portal!=null)
            {
                salesiqURL=salesiqURL+portal+"/";
            }
                        
            //retrying for 10 times till it succeeds because of issue in IAM.
            for(int i=0;i<10;i++)
            {
                try
                {
                    driver.get(accountsURL);
                    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                    CommonUtil.sleep(5000);
                    
                    if(CommonWait.isDisplayed(driver,By.id("login_id")))
                    {
                        loginId = "login_id";
                        CommonWait.waitTillDisplayed(driver,By.id("login_id"));                    
                        CommonUtil.getElement(driver,By.id("login_id")).clear();
                        etest.log(Status.PASS,"Accounts page was loaded");

                        driver.findElement(By.id("login_id")).clear();
                        driver.findElement(By.id("login_id")).sendKeys(loginname);
                        
                        CommonWait.waitTillDisplayed(driver,By.id("nextbtn"));
                        CommonUtil.click(driver,By.id("nextbtn"));

                        CommonWait.waitTillDisplayed(driver,By.id("password"));
                        driver.findElement(By.id("password")).clear();
                        driver.findElement(By.id("password")).sendKeys(pswd);

                        CommonWait.waitTillDisplayed(driver,By.id("nextbtn"));
                        CommonUtil.click(driver,By.id("nextbtn"));
                        CommonWait.waitTillHidden(driver,By.id("nextbtn"));
                    }
                    else
                    {
                        loginId = "login";
                        CommonWait.waitTillDisplayed(driver,By.id("lid"));                    
                        CommonUtil.getElement(driver,By.id("lid")).clear();
                        etest.log(Status.PASS,"Accounts page was loaded");

                        driver.findElement(By.id("lid")).clear();
                        driver.findElement(By.id("lid")).sendKeys(loginname);
                        
                        driver.findElement(By.name("pwd")).clear();
                        driver.findElement(By.name("pwd")).sendKeys(pswd);
                        driver.findElement(By.id("login")).findElement(By.className("redBtn")).click();
                    }
                        
                    driver.switchTo().defaultContent();
                    
                    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

                    CommonWait.waitTillNotPresent(driver,By.id(loginId));

                    break;
                }
                // catch(InvalidElementStateException e)
                catch(Exception e)
                {
                    boolean isLoggedIn=CommonWait.isPresent(driver,By.className("profile-container"));

                    if(isLoggedIn==false)
                    {
                        etest.log(Status.ERROR,"Login failed. Retrying Attempt : "+(i+1));
                        TakeScreenshot.infoScreenshot(driver,etest);
                        e.printStackTrace();            
                    }
                    else
                    {
                        break;
                    }
                }
            }

            try
            {
                CommonWait.waitTillNotPresent(driver,By.id(loginId));
            }
            catch(Exception e)
            {
                e.printStackTrace();
                TakeScreenshot.screenshot(driver,etest,"Login","Login","Error");
                ComplexReportFactory.closeTest(etest,false);
                handleFailedLogin();
                return false;
            }
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                        
            TakeScreenshot.screenshot(driver,etest,"Login","Check","Accounts",0);
            
            driver.get(salesiqURL);
            
            CommonWait.waitTillPresent(driver,By.id("maincontainer"));
            CommonWait.waitTillPresent(driver,By.linkText(ResourceManager.getRealValue("common_settings")));
            CommonUtil.getElement(driver,By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            etest.log(Status.PASS,"Successfully logged in");
            
            closeBannersAfterLogin(driver);
            
            String user_mail="";

            try
            {
                user_mail=ExecuteStatements.getUserMail(driver);
                com.zoho.livedesk.util.Cleanup.accounts.put(user_mail,module);
            }
            catch(Exception excep)
            {
                TakeScreenshot.screenshot(driver,etest,"Login","Login","Error",excep);
            }
            
            login = true;
        }
        catch(Exception e)
        {
            login_success = false;
            System.out.println("Exception while logging in for username : "+module+" "+e);
            TakeScreenshot.screenshot(driver,etest,"Login","Login","Error",e);
        }

        ComplexReportFactory.closeTest(etest,false);

        if(login==false)
        {
            handleFailedLogin();
        }

        return login;
    }

    public static boolean loginCRMP(WebDriver driver,String module) throws Exception
    {
        String loginId = "";
        ExtentTest etest=null;
        etest = ComplexReportFactory.getTest("Login - CRMP "+module.toUpperCase().replace("_"," "));
        ComplexReportFactory.setValues(etest,"Automation","Login");

        try
        {
            boolean isAutomationUnderDevelopmentMode = Boolean.parseBoolean(ConfManager.getRealValue("developer_mode"));
            if(isAutomationUnderDevelopmentMode)
            {
                module="developer_mode";
            }   
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        String loginname = ConfManager.getRealValue("crmplus_"+module+"_username");
        String pswd = ConfManager.getRealValue("crmplus_"+module+"_password");

        boolean login = false;
        
        try
        {
            String loginsite = Util.siteNameout();
            
            String accountsURL = "";
            String crmplusURL = "";
            
            if(loginsite.contains("labsalesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                crmplusURL = "https://crmpluslab.localzoho.com/";
            }
            else if(loginsite.contains("salesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                crmplusURL = "https://crmplus.localzoho.com/";
            }
            else if(loginsite.contains("presalesiq.zoho.com"))
            {
                accountsURL = "https://accounts.zoho.com/";
                crmplusURL = "https://precrmplus.zoho.com/";
            }
            else
            {
                accountsURL = "https://accounts.zoho.com/";
                crmplusURL = "https://crmplus.zoho.com/";
            }

            for(int i=0;i<10;i++)
            {
                try
                {
                    driver.get(accountsURL);
                    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                    CommonUtil.sleep(5000);
                    
                    if(CommonWait.isDisplayed(driver,By.id("login_id")))
                    {
                        loginId = "login_id";
                        CommonWait.waitTillDisplayed(driver,By.id("login_id"));                    
                        CommonUtil.getElement(driver,By.id("login_id")).clear();
                        etest.log(Status.PASS,"Accounts page was loaded");

                        driver.findElement(By.id("login_id")).clear();
                        driver.findElement(By.id("login_id")).sendKeys(loginname);
                        
                        CommonWait.waitTillDisplayed(driver,By.id("nextbtn"));
                        CommonUtil.click(driver,By.id("nextbtn"));

                        CommonWait.waitTillDisplayed(driver,By.id("password"));
                        driver.findElement(By.id("password")).clear();
                        driver.findElement(By.id("password")).sendKeys(pswd);

                        CommonWait.waitTillDisplayed(driver,By.id("nextbtn"));
                        CommonUtil.click(driver,By.id("nextbtn"));
                        CommonWait.waitTillHidden(driver,By.id("nextbtn"));
                    }
                    else
                    {
                        loginId = "login";
                        CommonWait.waitTillDisplayed(driver,By.id("lid"));                    
                        CommonUtil.getElement(driver,By.id("lid")).clear();
                        etest.log(Status.PASS,"Accounts page was loaded");

                        driver.findElement(By.id("lid")).clear();
                        driver.findElement(By.id("lid")).sendKeys(loginname);
                        
                        driver.findElement(By.name("pwd")).clear();
                        driver.findElement(By.name("pwd")).sendKeys(pswd);
                        driver.findElement(By.id("login")).findElement(By.className("redBtn")).click();
                    }
                    
                    driver.switchTo().defaultContent();
                    
                    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);


                    try
                    {
                        try
                        {
                            CommonWait.waitTillNotPresent(driver,By.id(loginId));
                        }
                        catch(Exception e1)
                        {
                            CommonWait.waitTillNotPresent(driver,By.id(loginId));
                        }
                    }
                    catch(Exception e2)
                    {
                        CommonUtil.printStackTrace(e2);
                        TakeScreenshot.screenshot(driver,etest,"Login","Login","Error");
                        ComplexReportFactory.closeTest(etest,false);
                        handleFailedLogin();
                        return false;
                    }

                    break;
                }
                catch(Exception e)
                {
                    etest.log(Status.ERROR,"Login failed. Retrying Attempt : "+(i+1));
                    TakeScreenshot.infoScreenshot(driver,etest);
                    e.printStackTrace();
                }
            }
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                        
            TakeScreenshot.screenshot(driver,etest,"Login","Check","Accounts",0);
            
            driver.get(crmplusURL);
            
            CommonWait.waitTillPresent(driver,By.id("serviceFrameContainer"));
            
            etest.log(Status.PASS,"Successfully logged in");
            
            login = true;
            try
            {
                if(CommonUtil.getElement(driver,By.id("commonuileftpanelswitchicon")).getAttribute("class").contains("IcnroatateY"))
                {
                    CommonUtil.mouseHoverAndClick(driver,CommonUtil.getElement(driver,By.id("commonuileftpanelswitchicon")));
                    CommonUtil.waitTillWebElementDoesNotContainAttributeValue(CommonUtil.getElement(driver,By.id("commonuileftpanelswitchicon")),"class","IcnroatateY");
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            CRMPlusCommonUtil.navToSalesiq(driver);

            CommonWait.waitTillPresent(driver,By.id("maincontainer"));
            try
            {
                try
                {
                    CommonWait.waitTillDisplayed(driver,By.id("dnenable"));
                }
                catch(Exception e)
                {
                    //no need to handle
                }
                if(CommonWait.isPresent(driver,By.id("dnenable")))
                {
                    WebElement close=CommonUtil.getElement(driver,By.id("dnenable"),By.className("sqico-close"));
                    CommonUtil.jsClick(driver,close);
                    CommonWait.waitTillHidden(close);
                    return true;
                }
            }
            catch(Exception e)
            {
                // e.printStackTrace();
            }
            CRMPlusCommonUtil.switchToSalesiqFrame(driver);
            CRMPChatWindow.closeAllChats(driver,etest);
            CommonFunctionsOthers.changeStatus(driver,"Available");
            CRMPlusCommonUtil.switchToSalesiqFrame(driver);

            etest.log(Status.INFO,"Switched to Salesiq");
            TakeScreenshot.infoScreenshot(driver,etest);
        }
        catch(Exception e)
        {
            login_success = false;
            TakeScreenshot.screenshot(driver,etest,"Login","Login","Error",e);
        }

        ComplexReportFactory.closeTest(etest,false);

        return login;
    }

    public static void handleFailedLogin()
    {
        trackFailedLogin();

        if(isTooManyLoginsFailed())
        {
            com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler.forceStopAutomation(getFailedLoginCount()+" login attempts were failed.");
        }        
    }

    public static boolean loginZohoDesk(WebDriver driver,String module) throws Exception
    {
        try
        {
            login(driver,module);

            String loginsite = Util.siteNameout();
            
            String loginURL = "";

            if(loginsite.contains("salesiq.localzoho.com"))
            {
                loginURL = "https://desk.localzoho.com/";
            }
            else
            {
                loginURL = "https://desk.zoho.com/";
            }

            driver.get(loginURL);

            return true;
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            return false;
        }
    }

    public static boolean loginZohoCampaign(WebDriver driver,String module) throws Exception
    {
        try
        {
            login(driver,module);

            String loginsite = Util.siteNameout();
            
            String loginURL = "";

            if(loginsite.contains("salesiq.localzoho.com"))
            {
                loginURL = "https://campaigns.localzoho.com/";
            }
            else
            {
                loginURL = "https://campaigns.zoho.com/";
            }

            driver.get(loginURL);

            return true;
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            return false;
        }
    }

    public static boolean loginCRM(WebDriver driver,String module, int i) throws Exception
    {
        String loginId = "";
        String loginname = ConfManager.getRealValue(module+"_username");
        String pswd = ConfManager.getRealValue(module+"_password");

        ExtentTest etest = ComplexReportFactory.getTest("Login - CRM Account "+i);
        ComplexReportFactory.setValues(etest,"Automation","Login");
        
        boolean login = false;
        
        try
        {
            String loginsite = Util.siteNameout();
            
            String accountsURL = "";
            String loginURL = "";
            
            if(loginsite.contains("labsalesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                loginURL = "https://crm.localzoho.com/";
            }
            else if(loginsite.contains("salesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
                loginURL = "https://crm.localzoho.com/";
            
            }
            else if(loginsite.contains("presalesiq.zoho.com"))
            {
                accountsURL = "https://accounts.zoho.com/";
                loginURL = "https://crm.zoho.com/";
                
            }
            else
            {
                accountsURL = "https://accounts.zoho.com/";
                loginURL = "https://crm.zoho.com/";
                
            }
            
            for(int j=0;j<10;j++)
            {
                try
                {
                    driver.get(accountsURL);
                    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                    CommonUtil.sleep(5000);
                    
                    if(CommonWait.isDisplayed(driver,By.id("login_id")))
                    {
                        loginId = "login_id";
                        CommonWait.waitTillDisplayed(driver,By.id("login_id"));                    
                        CommonUtil.getElement(driver,By.id("login_id")).clear();
                        etest.log(Status.PASS,"Accounts page was loaded");

                        driver.findElement(By.id("login_id")).clear();
                        driver.findElement(By.id("login_id")).sendKeys(loginname);
                        
                        CommonWait.waitTillDisplayed(driver,By.id("nextbtn"));
                        CommonUtil.click(driver,By.id("nextbtn"));

                        CommonWait.waitTillDisplayed(driver,By.id("password"));
                        driver.findElement(By.id("password")).clear();
                        driver.findElement(By.id("password")).sendKeys(pswd);

                        CommonWait.waitTillDisplayed(driver,By.id("nextbtn"));
                        CommonUtil.click(driver,By.id("nextbtn"));
                        CommonWait.waitTillHidden(driver,By.id("nextbtn"));
                    }
                    else
                    {
                        loginId = "login";
                        CommonWait.waitTillDisplayed(driver,By.id("lid"));                    
                        CommonUtil.getElement(driver,By.id("lid")).clear();
                        etest.log(Status.PASS,"Accounts page was loaded");

                        driver.findElement(By.id("lid")).clear();
                        driver.findElement(By.id("lid")).sendKeys(loginname);
                        
                        driver.findElement(By.name("pwd")).clear();
                        driver.findElement(By.name("pwd")).sendKeys(pswd);
                        driver.findElement(By.id("login")).findElement(By.className("redBtn")).click();
                    }
                        
                    driver.switchTo().defaultContent();
                    
                    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

                    CommonWait.waitTillNotPresent(driver,By.id(loginId));

                    break;
                }
                // catch(InvalidElementStateException e)
                catch(Exception e)
                {
                    boolean isLoggedIn=CommonWait.isPresent(driver,By.className("profile-container"));

                    if(isLoggedIn==false)
                    {
                        etest.log(Status.ERROR,"Login failed. Retrying Attempt : "+(i+1));
                        TakeScreenshot.infoScreenshot(driver,etest);
                        CommonUtil.printStackTrace(e);
                    }
                    else
                    {
                        break;
                    }
                }
            }

            try
            {
                CommonWait.waitTillNotPresent(driver,By.id(loginId));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
                TakeScreenshot.screenshot(driver,etest,"Login","Login","Error");
                ComplexReportFactory.closeTest(etest,false);
                handleFailedLogin();
                return false;
            }
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                        
            TakeScreenshot.screenshot(driver,etest,"Login","Check","Accounts",0);
            
            driver.get(loginURL);
            
            etest.log(Status.PASS,"Successfully logged in");
            
            login = true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while logging in for username : "+module+" "+e);
            TakeScreenshot.screenshot(driver,etest,"Login","Login","Error",e);
        }

        ComplexReportFactory.closeTest(etest,false);

        return login;
    }

    public static boolean loginMailChimp(WebDriver driver) throws Exception
    {
        // String loginname = ConfManager.getRealValue("mailchimpsite2_username");//"RajkumarNM";
        // String pswd = ConfManager.getRealValue("mailchimpsite2_password");//"test1234!A";

        return loginMailChimp(driver,"mailchimpsite2");
    }

    public static boolean loginMailChimp(WebDriver driver,String module) throws Exception
    {
        String
        mailChimpUserName = ConfManager.getRealValue(module+"_username"),
        mailChimpPassword = ConfManager.getRealValue(module+"_password")
        ;

        return loginMailChimp(driver,mailChimpUserName,mailChimpPassword);
    }

    public static boolean loginMailChimp(WebDriver driver,String loginname,String pswd) throws Exception
    {

        ExtentTest etest = ComplexReportFactory.getTest("Login - MailChimp");
        ComplexReportFactory.setValues(etest,"Automation","Login");
        
        boolean login = false;
        
        try
        {
            driver.get("https://login.mailchimp.com/");
            
            CommonUtil.elfinder(driver,"id","username").clear();
            CommonUtil.elfinder(driver,"id","username").sendKeys(loginname);
             
            CommonUtil.elfinder(driver,"id","password").clear();
            CommonUtil.elfinder(driver,"id","password").sendKeys(pswd);
            
            Thread.sleep(1000);

            CommonUtil.elfinder(driver,"xpath","//button[contains(text(),'Log in')]").click();

            // to wait for empty page load complete
            CommonUtil.sleep(2000);

            if(CommonWait.waitTillDisplayed(driver,By.className("send-email-code-button")))
            {
                // // this code is to get verification code from email
                // CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.className("send-email-code-button")));

                // WebDriver mailDriver = setUp();
                // loginGmail(mailDriver);
                // String verificationCode = getMailChimpVerificationCode(mailDriver);
                // CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("email_code")),verificationCode);


                // security question is set and the answer for security question is set as "test"
                CommonUtil.clickWebElement(driver,By.cssSelector("input[value='question']"));
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("question_answer")),"test");
                CommonUtil.clickWebElement(driver,By.className("submit-verification-button"));
            }

            etest.log(Status.PASS,"Successfully logged in");
            
            login = true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while logging in for username : MailChimp "+e);
            TakeScreenshot.screenshot(driver,etest,"Login","Login","Error",e);
            e.printStackTrace();
        }

        ComplexReportFactory.closeTest(etest,false);

        return login;
    }

    public static void loginGmail(WebDriver driver)
    {
        try
        {
            FluentWait wait2 = CommonUtil.waitreturner(driver, 30, 250);
        
            String url = "https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin";
            
            driver.get(url);
            
            String username = "automationsalesiq@gmail.com";
            String password = "zohosalesiq";

            if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("<input id=\"Email\""))
            {
                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("Email")));
                driver.findElement(By.id("Email")).sendKeys(username);
                CommonWait.waitTillDisplayed(driver,By.id("next"));

                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("next")));
                driver.findElement(By.id("next")).click();
                CommonWait.waitTillDisplayed(driver,By.id("Passwd"));

                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("Passwd")));
                driver.findElement(By.id("Passwd")).sendKeys(password);
                CommonWait.waitTillDisplayed(driver,By.id("signIn"));

                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("signIn")));
                driver.findElement(By.id("signIn")).click();
            }
            else
            {
                CommonWait.waitTillDisplayed(driver,By.id("identifierId"));
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("identifierId")),username);

                CommonWait.waitTillDisplayed(driver,By.id("identifierNext"));
                CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("identifierNext")));

                CommonWait.waitTillDisplayed(driver,By.id("password"));
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("password"),By.cssSelector(".whsOnd.zHQkBf")),password);

                CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("passwordNext"),By.cssSelector(".ZFr60d.CeoRYc")));
            }
            
            // waiting till gmail loaded
            CommonUtil.sleep(5000);
            
            driver.get(url);
            
            // to ensure if gmail loaded
            CommonUtil.sleep(6000);
        
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
    }

    public static String getMailChimpVerificationCode(WebDriver driver)
    {
        String verificationCode = "Error occurred while getting verification code";
        try
        {

            CommonWait.waitTillDisplayed(driver,By.id("gbq1"));
            CommonUtil.print("Logged in with Gmail to get the verification code");

            // CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.cssSelector(".zA.zE")));
            // CommonUtil.sleep(5000);
            //getting verification code
            String message = "";
            try
            {
                message = CommonUtil.getElement(driver,By.cssSelector("[role='row']]"),By.className("y2")).getText();
            }
            catch(Exception e)
            {
                message = CommonUtil.getElement(driver,By.className("y2")).getText();
            }

            CommonUtil.print("message = "+message);

            verificationCode = message.substring(message.indexOf("Verification Code")+"Verification Code field. ".length());

            CommonUtil.print("Verification code = "+verificationCode);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }

        return verificationCode;
    }

    public static void logout(WebDriver driver) throws Exception
    {
        logout(driver,true);
    }

    public static void logout(WebDriver driver,boolean isQuit) throws Exception
    {
        try
        {
            String currentURL = driver.getCurrentUrl();

            String loginsite = Util.siteNameout();
            
            String logoutURL = "";
            
            if(loginsite.contains("salesiq.localzoho.com"))
            {
                logoutURL = "https://salesiq.localzoho.com/logout.sas";

                if(currentURL.contains("crmplus"))
                {
                    logoutURL = "https://crmplus.localzoho.com/logout.sas";
                }
                else if(currentURL.contains("crm"))
                {
                    logoutURL = "https://crm.localzoho.com/logout.sas";
                }
//                else if(currentURL.contains("/salesiq.zoho.com/"))
//                {
//                    logoutURL = "https://salesiq.zoho.com/logout.sas";
//                }
            }
            else if(loginsite.contains("presalesiq.zoho.com"))
            {
                logoutURL = "https://presalesiq.zoho.com/logout.sas";

                if(currentURL.contains("crmplus"))
                {
                    logoutURL = "https://precrmplus.zoho.com/logout.sas";
                }
                else if(currentURL.contains("crm"))
                {
                    logoutURL = "https://crm.zoho.com/logout.sas";
                }
            }
            else
            {
                logoutURL = "https://salesiq.zoho.com/logout.sas";

                if(currentURL.contains("crmplus"))
                {
                    logoutURL = "https://crmplus.zoho.com/logout.sas";
                }
                else if(currentURL.contains("crm"))
                {
                    logoutURL = "https://crm.zoho.com/logout.sas";
                }
            }
            
            driver.get(logoutURL);
            
            Thread.sleep(3000);
        }
        catch(Exception e)
        {
        
        }

        if(isQuit)
        {
            driver.quit();
        }
    }
    
    public static boolean logout(WebDriver driver,String module) throws Exception
    {
        ExtentTest etest = ComplexReportFactory.getTest("Logout - "+module);
        ComplexReportFactory.setValues(etest,"Automation","Logout");

        boolean logout = false;
        
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            CommonWait.waitTillDisplayed(driver,By.id("hdrdrpdwntop"));

            CommonUtil.click(driver,By.id("hdrdrpdwntop"));

            CommonWait.waitTillDisplayed(driver,By.id("hdrdrpdwn"));
            
            CommonUtil.click(driver,By.id("hdrdrpdwn"),By.cssSelector("[href='logout.sas']"));
                        
            CommonWait.waitTillDisplayed(driver,By.className("header"),By.className("zgh-login"));
            
            CommonUtil.click(driver,By.id("header"),By.className("zgh-login"));
            
            CommonWait.waitTillHidden(driver,By.id("zgh-login"));            
            
            String loginsite = Util.siteNameout();
            
            String zohoURL = "";
            
            if(loginsite.contains("salesiq.localzoho.com"))
            {
                zohoURL = "localzoho";
            }
            else
            {
                zohoURL = "zoho";
            }
            
            final String url1 = "https://www."+zohoURL+".com/salesiq/logout.html";
            final String url2 = "https://accounts."+zohoURL+".com/login";
            final String url3 = "https://www."+zohoURL+".com/salesiq/login.html";
            final String url4 = "https://accounts."+zohoURL+".com/signin?servicename=livedesk&serviceurl=https://salesiq.localzoho.com/home.do";
            final String url5 = "https://accounts."+zohoURL+".com/login?newtheme=true";
            final String url6 = "https://accounts."+zohoURL+".com/signin?servicename=livedesk&signupurl=https://www."+zohoURL+".com/salesiq/signup.html";
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.getCurrentUrl().contains(url1) || driver.getCurrentUrl().contains(url2) || driver.getCurrentUrl().contains(url3) || driver.getCurrentUrl().contains(url4) || driver.getCurrentUrl().contains(url5) || driver.getCurrentUrl().contains(url6))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            try
            {
                if(driver.getCurrentUrl().contains(url1))
                {
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a.signin")));
                }
                else if(driver.getCurrentUrl().contains(url2) || driver.getCurrentUrl().contains(url4) || driver.getCurrentUrl().contains(url5) || driver.getCurrentUrl().contains(url6))
                {
                    CommonWait.waitTillDisplayed(driver,By.id("loginform"));
                }
                else
                {
                    CommonWait.waitTillDisplayed(driver,By.id("zohoiam"));
                }
            }
            catch(Exception e)
            {
                CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,By.tagName("body")),"Sign");
            }
            
            driver.quit();
            etest.log(Status.PASS,"Successfully logged out");
            
            logout = true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Logout","Module","Error",e);
        }

        ComplexReportFactory.closeTest(etest,false);

        return logout;
    }

    public static void logoutMailChimp(WebDriver driver)
    {
        try
        {
            String url = driver.getCurrentUrl();
         
            url = url.split("mailchimp.com")[0]+"mailchimp.com/login/out";
             
            System.out.println("MailChimpLogoutURL:"+url);

            driver.get(url);

            Thread.sleep(3000);
        }
        catch(Exception e)
        {
        
        }

        driver.quit(); 
    }

    public static WebDriver setUp() throws Exception
    {
        return Driver.getDriver(false);
    }
    
    public static WebDriver setUp(boolean mac) throws Exception
    {
        return Driver.getDriver(mac);
    }
    
    public static void closeBannersAfterLogin(WebDriver driver)
    {
        PopupsCloser.closeAllPopups(driver);
        checkPlanUpgradeNeeded(driver);
        quickPortalCleanup(driver);
    }

    public static void quickPortalCleanup(WebDriver driver)
    {
        try
        {
            ChatWindow.closeAllChats(driver);
        }
        catch(Exception e)
        {

        }

        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
        }
        catch(Exception e)
        {

        }

        com.zoho.livedesk.util.common.actions.HandleCommonUI.hideSeasonalFloat(driver);
    }

    public static void checkPlanUpgradeNeeded(WebDriver driver)
    {
        try
        {
            //check for portal expiry
            if(isPlanUpgradeNeeded(driver))
            {
                ChatUtil.postToAutomationDevChannel("Portal '"+ExecuteStatements.getPortal(driver)+"' expired please upgrade to paid plan");
                com.zoho.livedesk.util.common.actions.UpgradePortalPlan.upgrade(driver,getExpectedPlan(driver));
            }
        }
        catch(Exception exp1)
        {

        }
    }

    public static boolean isPlanUpgradeNeeded(WebDriver driver) throws Exception
    {
        String portal=ExecuteStatements.getPortal(driver);
        String mail=ExecuteStatements.getUserMail(driver);

        if(mail.equals(ConfManager.getRealValue("admin_console_username"))==true)
        {
            return false;
        }     

        if(mail.equals(ConfManager.getRealValue("plan_free_username"))==true && portal.equals(ConfManager.getRealValue("plan_free_portal")))
        {
            return false;
        }

        if(ExecuteStatements.isFreePlan(driver))
        {
            return true;
        }

        return false;
    }

    public static String getExpectedPlan(WebDriver driver) throws Exception
    {
        String portal=ExecuteStatements.getPortal(driver);
        String mail=ExecuteStatements.getUserMail(driver);

        if(mail.equals(ConfManager.getRealValue("plan_basic_username"))==true && portal.equals(ConfManager.getRealValue("plan_basic_portal")))
        {
            return UpgradePortalPlan.BASIC;
        }

        if(mail.equals(ConfManager.getRealValue("plan_professional_username"))==true && portal.equals(ConfManager.getRealValue("plan_professional_portal")))
        {
            return UpgradePortalPlan.PROFESSIONAL;
        }

        return UpgradePortalPlan.ENTERPRISE;
    }
    
    public static void loadSiteAndWaitForRSID(WebDriver driver, String portal) throws Exception
    {
        String previousRSID = "not found";
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        String time = df.format(dateobj);
        String mail = "not found";
        
        try
        {
            mail = ExecuteStatements.getUserMail(driver);
        }
        catch(Exception e)
        {
            System.out.println("<><>Mail could not be found @"+time);
            e.printStackTrace();
        }
        
        time = df.format(dateobj);
        
        try
        {
            previousRSID = ExecuteStatements.getRSid(driver);
        }
        catch(Exception e)
        {
            System.out.println("<><>RSid could not be found for account "+mail+"@"+time);
            e.printStackTrace();
        }
        
        driver.get(Util.siteNameout()+"/"+portal+"/");
        PopupsCloser.closeAllPopups(driver);
        waitTillRegistered(driver);
        
        for(int i = 1; i <= 30; i++)
        {
            try
            {
                String current = ExecuteStatements.getRSid(driver);
                if(current.equals(previousRSID))
                {
                    continue;
                }
                time = df.format(dateobj);
                System.out.println("<><>RSid for account "+mail+" while loading portal "+portal+"@"+time+" is "+current+"("+previousRSID+")");
                return;
            }
            catch(Exception e)
            {}
            
            Thread.sleep(1000);
        }
        
        System.out.println("<><>RSid could not be found for account "+mail+"@"+time);
    }
    
    public static void refreshSiteAndWaitForRSID(WebDriver driver) throws Exception
    {
        String previousRSID = "not found";
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        String time = df.format(dateobj);
        String mail = "not found";
        
        try
        {
            mail = ExecuteStatements.getUserMail(driver);
        }
        catch(Exception e)
        {
            System.out.println("<><>Mail could not be found @"+time);
            e.printStackTrace();
        }
        
        time = df.format(dateobj);
        try
        {
            previousRSID = ExecuteStatements.getRSid(driver);
        }
        catch(Exception e)
        {
            System.out.println("<><>RSid could not be found for account "+mail+"@"+time);
            e.printStackTrace();
        }
        
        driver.navigate().refresh();
        waitTillRegistered(driver);
        
        for(int i = 1; i <= 30; i++)
        {
            try
            {
                String current = ExecuteStatements.getRSid(driver);
                if(current.equals(previousRSID))
                {
                    Thread.sleep(1000);
                    continue;
                }
                time = df.format(dateobj);
                System.out.println("<><>RSid for account "+mail+" while refreshing@"+time+" is "+current+"("+previousRSID+")");
                return;
            }
            catch(Exception e)
            {}
            
            Thread.sleep(1000);
        }
        
        System.out.println("<><>RSid could not be found for account "+mail+"@"+time);
    }
    
    public static void waitTillRegistered(WebDriver driver) throws Exception
    {
        Long t1 ,t2;
        t1 = new Long(System.currentTimeMillis());
        String mail = "";
        
        for(int i =1;i <= 30; i++)
        {
            try
            {
                mail = ExecuteStatements.getUserMail(driver);
                String s =  ExecuteStatements.getPortalRegisteredStatus(driver);
                if(s.equals("true"))
                {
                    t2 = new Long(System.currentTimeMillis());
                    System.out.println(mail+"<><>Getting PortalUI.register status<><>@"+t2+"<><>"+(t2-t1));
                    break;
                }
            }
            catch(Exception e)
            {}
            
            Thread.sleep(1000);
        }
        
        System.out.println(mail+"<><>Could get true for PortalUI.register<><>@"+t1);
    }
    
    public static void createTabAndCloseCurrent(WebDriver driver)
    {
        
    }
    
    public static void createTabAndCloseCurrent2(WebDriver driver)
    {
        JavascriptExecutor je = (JavascriptExecutor)driver;
        
        String url = driver.getCurrentUrl();
        
        je.executeScript("window.open('"+url+"');");
        
        Set<String> windows = driver.getWindowHandles();
        
        for (String window : windows)
        {
            driver.switchTo().window(window);
            break;
        }
        
        driver.close();
        
        windows = driver.getWindowHandles();
        
        for (String window : windows)       
        {
            driver.switchTo().window(window);
        }
    }
}
