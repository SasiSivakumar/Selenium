//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.ArrayList;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.zoho.livedesk.util.common.DistributedTest;


public class PopupsCloser
{
    public static void closeAllPopups(WebDriver driver)
    {
        Thread t = new Thread(new Runnable() 
        {
            public void run()
            {
                try
                {
                    FluentWait wait = CommonUtil.waitreturner(driver, 30, 500);

                    wait.until(new Function<WebDriver,Boolean>(){
                      public Boolean apply(WebDriver driver)
                      {
                        int closed_count=0;

                        if(PopupsCloser.closeTopBarAnnouncement(driver))
                        {
                          closed_count++;
                        }

                        if(PopupsCloser.closeRHSBottomAnnouncement(driver))
                        {
                            closed_count++;
                        }

                        if(PopupsCloser.closeOnboarding(driver))
                        {
                            closed_count++;
                        }

                        if(PopupsCloser.closeRedeemBanner(driver))
                        {
                            closed_count++;
                        }

                        if(closed_count==4)
                        {
                            return true;
                        }

                        return false;
                      }
                    });
                }
                //exception will be thrown after timeout, no need to handle it
                catch(Exception e)
                {}
            }
        });

        t.start();
    }

    public static boolean closeTopBarAnnouncement(WebDriver driver)
    {
        try
        {
            if(CommonWait.isPresent(driver,By.id("dnenable")))
            {
                WebElement close=CommonUtil.getElement(driver,By.id("dnenable"),By.className("sqico-close"));
                CommonUtil.jsClick(driver,close);
                CommonWait.waitTillHidden(close);
                return true;
            }
        }
        catch(Exception e)
        {
            // e.printStackTrace();
        }

        return false;
    }

    public static boolean closeRHSBottomAnnouncement(WebDriver driver)
    {
        try
        {
            if(CommonWait.isPresent(driver,By.id("anncmnt")))
            {
                WebElement close=CommonUtil.getElement(driver,By.id("anncmnt"),By.id("bannerclose"));
                CommonUtil.jsClick(driver,close);
                CommonWait.waitTillHidden(close);
                return true;
            }
        }
        catch(Exception e)
        {
            // e.printStackTrace();
        }

        return false;
    }

    public static boolean closeOnboarding(WebDriver driver)
    {
        try
        {
            if(CommonWait.isPresent(driver,By.id("onboarddiv")))
            {
                WebElement close=CommonUtil.getElement(driver,By.cssSelector("[documentclick=showScheduleLater]"));
                CommonUtil.jsClick(driver,close);
                CommonWait.waitTillHidden(close);
                return true;
            }
        }
        catch(Exception e)
        {
            // e.printStackTrace();
        }

        return false;
    }

    public static boolean closeRedeemBanner(WebDriver driver)
    {
        try
        {
            if(CommonWait.isPresent(driver,By.cssSelector("[documentclick='closeredeembanner']")))
            {
                WebElement close=CommonUtil.getElement(driver,By.cssSelector("[documentclick='closeredeembanner']"));
                CommonUtil.jsClick(driver,close);
                CommonWait.waitTillHidden(close);
                return true;
            }
        }
        catch(Exception e)
        {
            // e.printStackTrace();
        }

        return false;
    }
}
