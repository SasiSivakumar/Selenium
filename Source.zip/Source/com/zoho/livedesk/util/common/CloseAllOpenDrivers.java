//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.ArrayList;

public class CloseAllOpenDrivers implements DistributedTest
{
	static int total_drivers_opened,total_left_opened;

	public static void init()
	{
		total_drivers_opened=Driver.drivers.size();
		total_left_opened=0;
	}

	public static void close()
	{
		init();

        CloseAllOpenDrivers this_class_object = new CloseAllOpenDrivers();

        System.out.println("~~~CloseAllOpenDrivers thread --> "+total_drivers_opened);
        System.out.println("~~~CloseAllOpenDrivers Started at "+CommonUtil.timestamp());

        Distributor distributor = new Distributor(this_class_object,(total_drivers_opened-1));
        distributor.initiate();
        printStats();

        System.out.println("~~~CloseAllOpenDrivers Ended"+CommonUtil.timestamp());
	}

	public static void printStats()
	{
        System.out.println("----------Driver Stats---------");
        System.out.println("Total Drivers Opened : "+total_drivers_opened);
        System.out.println("Total Drivers Closed : "+(total_drivers_opened-total_left_opened));
        System.out.println("Total Drivers Not Closed : "+total_left_opened);
	}

    public void startThread(int thread_number) throws Exception
    {
        WebDriver driver=Driver.drivers.get(thread_number);

		// ExtentTest etest=ComplexReportFactory.getTest("Close driver "+thread_number);
		// ComplexReportFactory.setValues(etest,"Cleanup","Close All Drivers");

		try
		{
			try
			{
			    if(!Driver.hasQuit(driver))
			    {
			    	// TakeScreenshot.infoScreenshot(driver,etest);		    	
			        total_left_opened++;
			    }
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}


		    Driver.quitDriver(driver);

		    // etest.log(Status.PASS,"Driver left open was was closed successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			// TakeScreenshot.log(e,etest,Status.WARNING);
			// TakeScreenshot.screenshot(driver,etest,e);
		}

        // ComplexReportFactory.closeTest(etest);
    }
}
