//$Id$
package com.zoho.livedesk.util.common;

import java.util.List;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;

public class SettingsTab
{
	public static final By
	LIST_ROW = By.className("list-row"),
	DATA_ROW = By.className("data_row"),
	BOT_NAME = By.className("bot-lstname"),
	TEXT = By.className("txtelips"),
	CONNECTED_TAB = By.id("suppm_current")
	;

	public static List<WebElement> getListElements(WebDriver driver)
	{        
        List<WebElement> elmts = driver.findElements(LIST_ROW);
        return elmts;
	}

	public static List<WebElement> getDataElements(WebDriver driver)
	{        
        List<WebElement> elmts = driver.findElements(DATA_ROW);
        return elmts;
	}

	public static ArrayList<String> getListText(WebDriver driver)
	{
		ArrayList<String> listTexts = new ArrayList<String>();

		List<WebElement> listElements = getListElements(driver);

		for(WebElement listElement : listElements)
        {
            String text = CommonUtil.getElement(listElement,TEXT).getText();
            listTexts.add(text);
        }

        return listTexts;
	}

	public static ArrayList<String> getDataTexts(WebDriver driver)
	{
		ArrayList<String> dataTexts = new ArrayList<String>();

		List<WebElement> dataElements = getDataElements(driver);

		if(dataElements != null)
		{
			for(WebElement dataElement : dataElements)
	        {
	            String text = CommonUtil.getElement(dataElement,BOT_NAME).getText();
	            dataTexts.add(text);
	        }
	    }

        return dataTexts;
	}

	public static ArrayList<String> getDepartmentList(WebDriver driver) throws Exception
	{
		Tab.navToDeptTab(driver);
		return getListText(driver);
	}

	public static ArrayList<String> getOperatorList(WebDriver driver) throws Exception
	{
		Tab.navToUsersTab(driver);
		return getListText(driver);
	}

	public static ArrayList<String> getEmbedList(WebDriver driver) throws Exception
	{
		Tab.navToEmbedTab(driver);
		return getListText(driver);
	}

	public static ArrayList<String> getBotsList(WebDriver driver) throws Exception
	{
		Tab.navToBotsTab(driver);
		return getDataTexts(driver);
	}

	public static boolean checkConnectedTabShown(WebDriver driver) throws Exception
	{
		try
		{
			return CommonWait.waitTillDisplayed(driver,CONNECTED_TAB);
		}
		catch(Exception e)
		{
			return false;
		}
	}
}
