//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;
import java.util.Hashtable;
import java.util.ArrayList;
import com.zoho.livedesk.util.common.*;


public class Department
{
    public static final String
    NAME="NAME",
    IS_PUBLIC="IS_PUBLIC",
    OPERATORS="OPERATORS",
    IS_ENABLED="IS_ENABLED",
    DESCRIPTION="DESCRIPTION",
    IS_SYSTEM_GENERATED="IS_SYSTEM_GENERATED",
    MISSED_MAIL="MISSED_MAIL",
    IS_MISSED_MAIL="IS_MISSED_MAIL",
    CC_MAIL="CC_MAIL",
    IS_CC_MAIL="IS_CC_MAIL",
    TRANSCRIPT_MAIL="TRANSCRIPT_MAIL",
    IS_TRANSCRIPT_MAIL="IS_TRANSCRIPT_MAIL",
    FEEDBACK_MAIL="FEEDBACK_MAIL",
    IS_FEEDBACK_MAIL="IS_FEEDBACK_MAIL",
    BLOCKEDIP_MAIL="BLOCKEDIP_MAIL",
    IS_BLOCKEDIP_MAIL="IS_BLOCKEDIP_MAIL",
    FROM_EMAIL="FROM_EMAIL"
    ;

	public static boolean addDept(WebDriver driver,String deptname, String type,String users, ExtentTest etest) throws Exception
	{
	    FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
		Thread.sleep(1000);
        
        Tab.navToDeptTab(driver);
        
        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","buttonadddept"),"tagname","span").click();
	 	
        Thread.sleep(1000);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));
        
	 	CommonUtil.elfinder(driver,"id","name").click();
	 	CommonUtil.elfinder(driver,"id","name").clear();
	 	CommonUtil.elfinder(driver,"id","name").sendKeys(deptname);
	 	
	 	CommonUtil.elfinder(driver,"id",type).click();
	 	
	 	CommonUtil.elfinder(driver,"id","desc").click();
        CommonUtil.elfinder(driver,"id","desc").clear();
        CommonUtil.elfinder(driver,"id","desc").sendKeys("Description");
        
        WebElement seldept = CommonUtil.elfinder(driver,"classname","seldept_alrt");
        
        if(seldept.isDisplayed())
        {
            if(users != null)
            {
                WebElement elmt = CommonUtil.elfinder(driver,"id","unassodeptlist");
                
                CommonUtil.inViewPort(elmt);
                
                com.zoho.livedesk.util.common.actions.HandleCommonUI.hideSeasonalFloat(driver);

                if(elmt.getAttribute("innerHTML").contains("mordept"))
                {
                    CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"classname","mordept"),"tagname","em").click();
                    Thread.sleep(1000);
                }
                
                List<WebElement> elmts = elmt.findElements(By.className("associatesel"));
                
                for(WebElement element:elmts)
                {
                    CommonUtil.inViewPort(element);
                    
                    WebElement ptag = CommonUtil.elementfinder(driver,element,"tagname","p");
                    
                    if(users.contains(ptag.getText()))
                    {
                        WebElement d = CommonUtil.elementfinder(driver,element,"tagname","div");
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+d.getLocation().y+"-300)");
                        d.click();
                    }
                }
            }
        }
        
	 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));

	 	WebElement add = CommonUtil.elfinder(driver,"id","deptaddbtn");

	 	CommonUtil.inViewPort(add);

	 	((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+add.getLocation().y+")");
        
        add.click();
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);

        Tab.clickDept(driver);
        
        if(getDept(driver,deptname) != null)
        {
        	return true;
        }
        else
        {
        	return false;
        }
	}
    
    public static List<WebElement> getDepartmentList(WebDriver driver) throws Exception
    {
        Tab.navToDeptTab(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        List<WebElement> elmts = CommonUtil.elfinder(driver,"id","module-list").findElements(By.className("list-row"));
        
        return elmts;
    }

	public static WebElement getDept(WebDriver driver,String deptname) throws Exception
	{
	    FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        List<WebElement> elmts = CommonUtil.elfinder(driver,"id","module-list").findElements(By.className("list-row"));

		for(WebElement elmt:elmts)
		{
			String data = CommonUtil.elementfinder(driver,elmt,"classname","txtelips").getText();
			
			if(data.equals(deptname))
			{
                return elmt;
			}
		}

		return null;
	}

    public static boolean isDepartmentNamePresent(WebDriver driver,String dept) throws Exception
    {
        Tab.navToDeptTab(driver);
        return CommonWait.isPresent(driver, By.cssSelector("em.txtelips[title*='"+dept+"']") );
    }

	public static boolean deleteDepartment(WebDriver driver,String deptToBeDeleted,String configureTo,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        Tab.navToDeptTab(driver);

        WebElement dept = getDept(driver,deptToBeDeleted);

        if(dept == null)
        {
        	return true;
        }

        if(!dept.getAttribute("innerHTML").contains("list_lefticon"))
        {
        	return false;
        }

        WebElement delete = CommonUtil.elementfinder(driver,dept,"classname","list_lefticon");
        
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+delete.getLocation().y+"-100)");

        CommonUtil.mouseHover(driver,CommonUtil.elementfinder(driver,dept,"classname","txtelips"));
        
        wait.until(ExpectedConditions.visibilityOf(delete));

        delete.click();

        wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","popupdiv")));

        final WebElement div = CommonUtil.elfinder(driver,"id","popupdiv");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getAttribute("innerHTML").contains("choosedept"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,div,"classname","txtelips")));

        CommonUtil.elementfinder(driver,div,"classname","txtelips").click();

        final WebElement dropdown = CommonUtil.elementfinder(driver,div,"id","deptselect_ddown");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(dropdown.getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        List<WebElement> list = CommonUtil.elementfinder(driver,dropdown,"id","deptselect1").findElements(By.tagName("li"));

        for(WebElement e : list)
        {
        	CommonUtil.inViewPort(e);

            if(configureTo == null)
            {
                e.click();
                break;
            }
            
        	if(e.getText().contains(configureTo))
        	{
        		e.click();
        		break;
        	}
        }

        CommonUtil.elementfinder(driver,div,"id","okbtn").click();
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Department deleted successfully","deldept.do",etest);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getAttribute("innerHTML").equals(""))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(500);

        dept = getDept(driver,deptToBeDeleted);

        if(dept == null)
        {
        	return true;
        }

		return false;
	}

    public static boolean isDepartmentFound(WebDriver driver,String department_id) throws Exception
    {
        Tab.navToDeptTab(driver);
        return CommonWait.isPresent(driver,By.id(department_id));
    }

    public static boolean openDepartment(WebDriver driver,String department_id)
    {
        WebElement dept_name=CommonUtil.getElement(driver,By.id(department_id),By.className("dept_namewth"),By.className("txtelips"));
        CommonUtil.clickWebElement(driver,dept_name);
        return CommonWait.waitTillHidden(dept_name);
    }

    public static ArrayList<String> getDepartments(WebDriver driver) throws Exception
    {
        ArrayList<String> departments=new ArrayList<String>();

        Tab.navToDeptTab(driver);

        List<WebElement> department_containers=driver.findElements(By.className("list-row"));

        for(WebElement department_container : department_containers)
        {
            String name=CommonUtil.getElement(department_container,By.className("dept_namewth"),By.className("txtelips")).getText();
            departments.add(name);
        }

        return departments;
    }

    public static Hashtable<String,String> getDepartmentInfo(WebDriver driver,String department_id) throws Exception
    {
        Hashtable<String,String> department_info=new Hashtable<String,String>();

        Tab.navToDeptTab(driver); 
        openDepartment(driver,department_id);

        department_info.put(NAME,getDepartmentInfoBy(driver,By.id("deptname")));

        department_info.put(IS_PUBLIC,""+isDepartmentPublic(driver));

        department_info.put(OPERATORS,  CommonUtil.listToString(getDepartmentOperatorIds(driver)) );

        department_info.put(IS_ENABLED,""+isDepartmentEnabled(driver));

        department_info.put(DESCRIPTION,getDepartmentInfoBy(driver,By.id("desc")));

        boolean isSystemGenerated=false;

        if(department_info.get(NAME).equals(ExecuteStatements.getSystemGeneratedDepartment(driver)))
        {
            isSystemGenerated=true;
        }

        department_info.put(IS_SYSTEM_GENERATED,""+isSystemGenerated);

        if(CommonWait.isPresent(driver,By.id("deptconfig")))
        {
            department_info.put(FROM_EMAIL,getDepartmentInfoBy(false,driver,"frommailid"));

            department_info.put(IS_MISSED_MAIL,getDepartmentInfoBy(true,driver,"offbusymsg"));
            department_info.put(MISSED_MAIL,getDepartmentInfoBy(false,driver,"offbusymsg"));

            department_info.put(IS_CC_MAIL,getDepartmentInfoBy(true,driver,"ccemailaddr"));
            department_info.put(CC_MAIL,getDepartmentInfoBy(false,driver,"ccemailaddr"));

            department_info.put(IS_TRANSCRIPT_MAIL,getDepartmentInfoBy(true,driver,"sendtranasemail"));
            department_info.put(TRANSCRIPT_MAIL,getDepartmentInfoBy(false,driver,"sendtranasemail"));

            department_info.put(IS_FEEDBACK_MAIL,getDepartmentInfoBy(true,driver,"visitorfeedback"));
            department_info.put(FEEDBACK_MAIL,getDepartmentInfoBy(false,driver,"visitorfeedback"));

            department_info.put(IS_BLOCKEDIP_MAIL,getDepartmentInfoBy(true,driver,"sendemailforipblockto"));
            department_info.put(BLOCKEDIP_MAIL,getDepartmentInfoBy(false,driver,"sendemailforipblockto"));
        }

        return department_info; 
    }

    
    public static void setDepartmentInfo(WebDriver driver,ExtentTest etest,String department_id,boolean isEnabled,String name,boolean isPublic,String description,String from_mail,Boolean isMissed,String missedmail,Boolean isFeedback,String fbmail,Boolean isCC,String ccmail,Boolean isTranscript,String transmail,Boolean isBlock,String blockmail) throws Exception
    {
        Hashtable<String,String> company_info=new Hashtable<String,String>();

        Tab.navToDeptTab(driver);
        openDepartment(driver,department_id);

        toggleDepartment(driver,isEnabled);

        if(!isEnabled)
        {
            return;
        }

        setDepartmentInfoBy(name,driver,etest,By.id("deptname"));
        toggleDepartmentType(driver,isPublic);
        setDepartmentInfoBy(description,driver,etest,By.id("desc"));

        setDepartmentInfoBy(from_mail,driver,etest,"frommailid");

        setDepartmentInfoBy(isMissed.toString(),driver,etest,"offbusymsg");
        setDepartmentInfoBy(missedmail,driver,etest,"offbusymsg");

        setDepartmentInfoBy(isCC.toString(),driver,etest,"ccemailaddr");
        setDepartmentInfoBy(ccmail,driver,etest,"ccemailaddr");

        setDepartmentInfoBy(isTranscript.toString(),driver,etest,"sendtranasemail");
        setDepartmentInfoBy(transmail,driver,etest,"sendtranasemail");

        setDepartmentInfoBy(isFeedback.toString(),driver,etest,"visitorfeedback");
        setDepartmentInfoBy(fbmail,driver,etest,"visitorfeedback");

        setDepartmentInfoBy(isBlock.toString(),driver,etest,"sendemailforipblockto");
        setDepartmentInfoBy(blockmail,driver,etest,"sendemailforipblockto");

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void setDepartmentInfoBy(String info,WebDriver driver,ExtentTest etest,By... locators)
    {
        if(info==null)
        {
            return;
        }

        WebElement element=CommonUtil.getElement(driver,locators);
        CommonUtil.inViewPortSafe(driver,element);
        CommonUtil.sendKeysToWebElement(driver,element,info);
        etest.log(Status.INFO,info+" was set as "+element.getAttribute("id"));
    }

    public static void setDepartmentInfoBy(String info,WebDriver driver,ExtentTest etest,String eid)
    {
        if(info==null)
        {
            return;
        }


        boolean isCheckbox=false;
        if(info.equals("true") || info.equals("false"))
        {
            isCheckbox=true;
        }

        WebElement element=null;


        if(isCheckbox)
        {
            element=CommonUtil.getElement(driver,By.cssSelector("[type=checkbox][eid='"+eid+"']"));
        }
        else
        {
            element=CommonUtil.getElement(driver,By.cssSelector("[type=text][eid='"+eid+"']"));
        }

        CommonUtil.inViewPortSafe(driver,element);

        if(element.getTagName().equals("input") && element.getAttribute("type")!=null && element.getAttribute("type").equals("checkbox")==true )
        {
            WebElement checkbox=CommonUtil.getElement(driver,By.cssSelector("[tbutid='"+eid+"']"));

            boolean isEnabled=CommonUtil.hasClass(checkbox,"set_on");

            boolean expected_state=Boolean.parseBoolean(info);

            if(isEnabled==expected_state)
            {
                return;
            }

            CommonUtil.inViewPortSafe(driver,checkbox);
            checkbox.click();

            //refreshing element to avoid staleness
            checkbox=CommonUtil.getElement(driver,By.cssSelector("[tbutid='"+eid+"']"));

            String expected_classname=expected_state?"set_on":"set_off";

            CommonUtil.waitTillWebElementContainsAttributeValue(checkbox,"class",expected_classname);
        }
        else if(element.getTagName().equals("input") || element.getTagName().equals("textarea"))
        {
            CommonUtil.sendKeysToWebElement(driver,element,info);
        }

        etest.log(Status.INFO,info+" was set as "+element.getAttribute("id"));
    }

    public static void toggleDepartmentType(final WebDriver driver,final boolean isPublic)
    {
        if(isDepartmentPublic(driver)==isPublic)
        {
            return;
        }

        By checkbox_locator=isPublic?By.id("Public"):By.id("Private");
        WebElement checkbox=CommonUtil.getElement(driver,checkbox_locator);
        CommonUtil.inViewPortSafe(driver,checkbox);
        checkbox.click();

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(isDepartmentPublic(driver)==isPublic)
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static String getDepartmentInfoBy(WebDriver driver,By... locators)
    {
        try
        {
            WebElement element=CommonUtil.getElement(driver,locators);

            if(element.getTagName().equals("input") || element.getTagName().equals("textarea"))
            {
                return element.getAttribute("value");
            }
            else
            {
                return element.getAttribute("innerText").trim();
            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String getDepartmentInfoBy(boolean isCheckbox,WebDriver driver,String eid)
    {
        if(isCheckbox)
        {
            WebElement checkbox=CommonUtil.getElement(driver,By.cssSelector("[tbutid='"+eid+"']"));
            return ""+CommonUtil.hasClass(checkbox,By.className("set_on"));
        }
        else
        {
            WebElement element=CommonUtil.getElement(driver,By.cssSelector("[type=text][eid='"+eid+"']"));

            if(element==null)
            {
                return "NULL";
            }

            return element.getAttribute("value");
        }
    }


    public static List<WebElement> getDepartmentOperatorContainers(WebDriver driver)
    {
        List<WebElement> operator_containers=CommonUtil.getElement(driver,By.id("associatedusers")).findElements(By.cssSelector("img[onload*=setUserStatus]"));
        return operator_containers;
    }

    public static ArrayList<String> getDepartmentOperatorIds(WebDriver driver)
    {
        return getDepartmentOperatorAttributes(driver,"id");
    }

    public static ArrayList<String> getDepartmentOperatorAttributes(WebDriver driver,String attribute)
    {
        List<WebElement> operator_containers=getDepartmentOperatorContainers(driver);

        ArrayList<String> values=new ArrayList<String>();

        for(WebElement operator_container : operator_containers)
        {
            values.add(operator_container.getAttribute(attribute));
        }

        return values;
    }

    public static void toggleDepartment(WebDriver driver,final boolean isEnable)
    {
        if(isDepartmentEnabled(driver)==isEnable)
        {
            return;
        }

        WebElement button=CommonUtil.getElement(driver,By.cssSelector("[onclick*='Department.changeStatus']"));
        button.click();

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(isDepartmentEnabled(driver)==isEnable)
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static boolean isDepartmentEnabled(WebDriver driver)
    {
        WebElement button=CommonUtil.getElement(driver,By.cssSelector("[onclick*='Department.changeStatus']"));

        if(CommonUtil.hasClass(button,By.className("cmn_redbut")))
        {
            return true;
        }

        return false;
    }

    public static boolean isDepartmentPublic(WebDriver driver)
    {
        List<WebElement> checkboxes=CommonUtil.getElement(driver,By.id("departmenttype")).findElements(By.className("uprdowrap"));

        for(WebElement checkbox : checkboxes)
        {
            if( CommonWait.isPresent(checkbox,By.className("rdselected")) && CommonWait.isPresent(checkbox,By.id("Public")) )
            {
                return true;
            }
        }

        return false;
    }

    public static boolean clickAddDepartment(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,By.id("buttonadddept"));
        WebElement add=CommonUtil.getElement(driver,By.id("buttonadddept"));
        CommonUtil.mouseHoverAndClick(driver,add);
        etest.log(Status.INFO,"Add department button was clicked.");
        return CommonWait.waitTillHidden(add);
    }


    public static boolean isOperatorFoundInAddDepartment(WebDriver driver,ExtentTest etest,String operator,boolean isPresent) throws Exception
    {
        Tab.navToDeptTab(driver);
        clickAddDepartment(driver,etest);

        if(CommonWait.isPresent(driver,By.cssSelector(".unasso_dept[title*='"+operator+"']"))==isPresent)
        {
            etest.log(Status.PASS,"Operator '"+operator+"' was "+(isPresent?"found":"NOT found")+" in the add department operators list");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Operator '"+operator+"' was "+(isPresent?"NOT found":"found")+" in the add department operators list");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static boolean renameDepartment(WebDriver driver,ExtentTest etest,String old_name,String new_name) throws Exception
    {
        Tab.navToDeptTab(driver);
        WebElement dept=getDept(driver,old_name);
        CommonUtil.mouseHoverAndClick(driver,dept);
        CommonWait.waitTillHidden(dept);

        CommonWait.waitTillDisplayed(driver,By.id("deptname"));
        WebElement input=CommonUtil.getElement(driver,By.id("deptname"));

        input.click();
        CommonUtil.sleep(100);
        CommonUtil.sendKeysToWebElement(driver,input,new_name);

        CommonUtil.getElement(driver,By.className("myprfdtlmn_lft")).click();

        etest.log(Status.INFO,"Department was renamed from '"+old_name+"' to '"+new_name+"'");

        return Tab.getBanner(driver)!=null;
    }
}
