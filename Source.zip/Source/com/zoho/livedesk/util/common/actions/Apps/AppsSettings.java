//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class AppsSettings
{
    /*Objects*/


    /*Constants*/
    private static final By
    GENERAL_TAB=By.id("general"),
    WAITING_TIMER_CONTAINER=By.id("showWatitingTime"),
    SELECTED_TAB=By.className("sel"),
    MAIL_TRANSCRIPT_CHECKBOX=By.id("mail_transcript"),
    CONVERSATION_CHECKBOX=By.id("view_conversation"),
    EMOJI_CHECKBOX=By.id("show_emojis"),
    SHARE_FILE_CHECKBOX=By.id("share_file"),
    SHARE_SCREEN_CHECKBOX=By.id("share_screen")
    ;

    public static final String
    PAGE="'Apps settings'"
    ;

    /*Tab Ids*/
    public static final String
    GENERAL="general",
    LANG="languages",
    PRIVACY="privacy",
    ABOUT="about",
    WAITING_TIMER_NAME_ATTRIBUTE="Waiting Time"
    ;


    public static String getCurrentTab(WebDriver driver)
    {
        return CommonUtil.getElement(driver,SELECTED_TAB).getAttribute("id");
    }

    public static boolean isTabOpen(WebDriver driver,String expected_tab)
    {
        return expected_tab.equals(getCurrentTab(driver));
    }

    /*Apps General Tab Methods*/
    public static boolean waitTillLoads(WebDriver driver)
    {
    	return CommonWait.waitTillDisplayed(driver,GENERAL_TAB);
    }

    public static boolean close(WebDriver driver)
    {
    	return AppsCommonElements.clickClose(driver);
    }

    public static void selectGeneralTab(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,GENERAL_TAB);
        CommonUtil.click(driver,GENERAL_TAB);
        CommonWait.waitTillDisplayed(driver,WAITING_TIMER_CONTAINER);
    }

    public static List<String> getDeparments(WebDriver driver)
    {
        return AppsAdd.getSelectedDepartments(driver);
    }

    public static boolean setWaitingTimer(WebDriver driver,ExtentTest etest,int waiting_time)
    {
        if(ExecuteStatements.getRadioValue(driver,WAITING_TIMER_NAME_ATTRIBUTE).equals(""+waiting_time))
        {
            etest.log(Status.INFO,"Waiting timer value was already set as "+waiting_time);
            return true;
        }

        By checkbox=By.cssSelector("[waiting_time='"+waiting_time+"']");
        WebElement checkbox_ele=CommonUtil.getElement(driver,checkbox);
        CommonUtil.clickWebElement(driver,checkbox_ele);
        etest.log(Status.INFO,"Waiting timer value was set as "+waiting_time+" seconds");
        return AppsCommonElements.handleSaveBanner(driver,etest,true);
    }

    public static void setEmailTranscript(WebDriver driver,ExtentTest etest,boolean isEnable)
    {
        setCheckbox(driver,etest,isEnable,MAIL_TRANSCRIPT_CHECKBOX);
    }

    public static void setConversationView(WebDriver driver,ExtentTest etest,boolean isEnable)
    {
        setCheckbox(driver,etest,isEnable,CONVERSATION_CHECKBOX);
    }

    public static void setEmojiSetting(WebDriver driver,ExtentTest etest,boolean isEnable)
    {
        setCheckbox(driver,etest,isEnable,EMOJI_CHECKBOX);
    }

    public static void setShareFileSetting(WebDriver driver,ExtentTest etest,boolean isEnable)
    {
        setCheckbox(driver,etest,isEnable,SHARE_FILE_CHECKBOX);
    }

    public static void setShareScreenSetting(WebDriver driver,ExtentTest etest,boolean isEnable)
    {
        setCheckbox(driver,etest,isEnable,SHARE_SCREEN_CHECKBOX);
    }

    public static void setCheckbox(WebDriver driver,ExtentTest etest,boolean isEnable,By locator)
    {
        WebElement checkbox=CommonUtil.getElement(driver,locator);
        AppsCommonElements.setCheckbox(driver,etest,checkbox,isEnable);
        etest.log(Status.INFO,"'"+CommonUtil.getByValue(locator)+"' checkbox was "+(isEnable?"enabled":"disabled"));
    }

}
