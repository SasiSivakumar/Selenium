//$Id$
package com.zoho.livedesk.util.common.actions;

import junit.framework.TestCase;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.*;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.util.common.CommonUtil;
import java.util.List;
import java.io.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.SCPUtil;

import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.FileUtils;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUpload
{
    public static final String file_directory_from_root="/webapps/selenium/sample_files_for_file_upload/";
    public static final String upload_limit_file_name="uploadlimit.dummy_file";//change enum value "UPLOAD_LIMIT_FILE" if this is changed
    public static final int upload_limit_in_mb=50;

    public enum FileType
    {
        IMAGE("JPEG.jpg"),
        SMALL_IMAGE("image.png"),
        SMALL_IMAGE2("image2.png"),
        CUSTOM_CSS_FILE("customcss.css"),
        XSS_FILE("<file>.xss"),//created dynamically
        UPLOAD_LIMIT_FILE("uploadlimit.dummy_file")//created dynamically
        ;
        
        public String file_name;

        FileType(String file_name)
        {
            this.file_name=file_name;
        }

        public String getFilePath()
        {
            return com.zoho.livedesk.util.common.actions.FileUpload.getSampleFilesDirectory()+file_name;
        }

        public String getFileName()
        {
            return file_name;
        }
    }

    public static void uploadFile(WebElement file_input,FileType file_type)
    {
        ((RemoteWebElement) file_input).setFileDetector(new LocalFileDetector());
        file_input.sendKeys(file_type.getFilePath());
    }

    public static void createFileForCheckingUploadLimit() throws IOException
    {
        if(!isFileExists(getSampleFilesDirectory(),upload_limit_file_name))
        {
            createDummyFile(upload_limit_file_name,(upload_limit_in_mb+1));//creating a file greater than upload limit
        }
    }

    public static void createDummyFile(String filename,int file_size_in_mb) throws IOException
    {
        if(!isFileExists(getSampleFilesDirectory(),filename))
        {
            RandomAccessFile f = new RandomAccessFile(getSampleFilesDirectory()+filename, "rw");
            f.setLength(file_size_in_mb * 1024 * 1024);           
        }
    }

    public static void createDirectoryIfNotExist(String file_dir) throws IOException
    {
        String filename=file_dir.replaceAll("/.+/","");
        String folder_of_file=file_dir.replace(filename,"");
        File file_obj=new File(folder_of_file);
        file_obj.mkdirs();
    }

    public static void createFileIfNotExists(String file_dir) throws IOException
    {
        if(!isFileExists(file_dir))
        {
            createDirectoryIfNotExist(file_dir);
            File file_obj=new File(file_dir);
            file_obj.createNewFile();
        }
    }

    public static boolean isFileExists(String directory,String filename)
    {
        return new File(directory, filename).exists();
    }

    public static boolean isFileExists(String filepath)
    {
        return new File(filepath).exists();
    }

    public static String getSampleFilesDirectory()
    {
        URL location = FileUpload.class.getProtectionDomain().getCodeSource().getLocation();
        String file_directory = location.getFile();
        file_directory = file_directory.replaceAll("/lib/livedesk-webdriver.jar",file_directory_from_root);
        return file_directory;
    }

    public static String getBuildRoot()
    {
        URL location = FileUpload.class.getProtectionDomain().getCodeSource().getLocation();
        String file_directory = location.getFile();
        file_directory = file_directory.replace("/lib/livedesk-webdriver.jar","");
        return file_directory;
    }

    public static String getFileExtension(String filepath)//can pass filename also
    {
        return FilenameUtils.getExtension(filepath);
    }

    public static boolean renameFile(String old_file_path,String new_file_path) throws IOException
    {
        File file = new File(old_file_path);
        File file2 = new File(new_file_path);

        if (file2.exists())
        {
           throw new java.io.IOException("file exists");
        }

        return file.renameTo(file2);
    }

    public static String getFileAsString(String path) throws IOException
    {
       return FileUtils.readFileToString(new File(path), "UTF-8");
    }

    public static void copyFile(String source,String destination) throws IOException
    {
        Path source_path=Paths.get(source);
        Path destination_path=Paths.get(destination);

        File directory = new File(destination);

        if (!directory.exists())
        {
          directory.mkdirs();
        }

        Files.copy(source_path, destination_path, StandardCopyOption.REPLACE_EXISTING);
    }
}
