//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class GlobalSearch
{
    public static final By
    SEARCH_INPUT=By.id("searchinput"),
    SEARCH_RESULT_CONTAINER=By.id("srchcntr"),
    SEARCH_RESULTS_CONTAINER=By.className("tablegrp")
    ;

    public static List<WebElement> search(WebDriver driver,String search_key)
    {
        CommonWait.waitTillDisplayed(driver,SEARCH_INPUT);
        WebElement search_input=CommonUtil.getElement(driver,SEARCH_INPUT);
        search_input.click();
        search_input.sendKeys(search_key);
        CommonUtil.sleep(10);
        search_input.sendKeys(Keys.RETURN);
        CommonWait.waitTillDisplayed(driver,SEARCH_RESULT_CONTAINER);
        return CommonUtil.getElement(driver,SEARCH_RESULT_CONTAINER).findElements(SEARCH_RESULTS_CONTAINER);
    }

    public static WebElement getSearchResultByInnerText(List<WebElement> results,String text)
    {
        return CommonUtil.getElementByAttributeValue(results,"innerText",text);
    }

    public static void searchAndOpenResult(WebDriver driver,String search_key,String text)
    {
        if(text==null)
        {
            text=search_key;
        }

        WebElement search_result=getSearchResultByInnerText(search(driver,search_key),text);
        CommonUtil.inViewPort(search_result);
        search_result.click();
    }

    public static void searchAndOpenResult(WebDriver driver,String search_key)
    {
        searchAndOpenResult(driver,search_key,null);
    }

    public static void searchAndOpenChat(WebDriver driver,String search_key)
    {
       searchAndOpenResult(driver,search_key);
       CommonWait.waitTillDisplayed(driver,By.id("history_mcontent"),By.id("displaydata"));
    }
}
