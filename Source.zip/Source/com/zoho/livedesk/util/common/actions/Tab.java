//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.Stack;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.bots.BotsTab;
import com.zoho.livedesk.util.common.actions.Apps.*;

public class Tab
{
    public static int waitingTime = 30;
    public static Hashtable<String, Set<String>> request_uri = new Hashtable<>();
    public static Stack<String> contents = new Stack<>();
    
    public static Boolean started = false;
    public static ExtentTest etest = null;
    public static Hashtable<ExtentTest, String> etestName = new Hashtable<>();
    public static Hashtable<ExtentTest, String> etestCategory = new Hashtable<>();
    
    public static String etestNameNotPresent = "";
    public static String etestCategoryNotPresent = "";

    public static final String
    INFO_BANNER="info",
    SUCCESS_BANNER="success",
    FAILURE_BANNER="failure";

    public static final By
    TAB_INNER_CONTENT=By.id("rightcontainer")
    ;

    
    public static void clickSettings(WebDriver driver)
	{
        //three attempts to click settings
        for(int i=0;i<=2;i++)
        {
            try
            {
                clickVisitorsOnline(driver);
                FluentWait wait = CommonUtil.waitreturner(driver,10,250);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
                WebElement settings = CommonUtil.getElement(driver,By.id("menu_setting"));
                settings.click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);

                if(i==2)
                {
                    throw e;
                }
            }
        }
	}

	public static void clickVisitorsOnline(WebDriver driver)
    {
        for(int attempt = 0; attempt < 3; attempt++)
        {
            try
            { 
                CommonUtil.click(driver,By.id("suppm_tracking"),By.tagName("a"));
                CommonWait.waitTillDisplayed(driver,By.cssSelector("[documentClick='showCircleView']"));           
            }
            catch(Exception e)
            {
                CommonUtil.refreshPage(driver);
                if(attempt == 2)
                {
                    CommonWait.waitTillDisplayed(driver,By.cssSelector("[documentClick='showCircleView']"));           
                }
            }
        }
    }

    public static void goToApps(WebDriver driver)
    {
        try
        {
            String current_url=driver.getCurrentUrl();

            if(current_url.endsWith("setting/apps"))
            {
                return;
            }
            else if(current_url.contains("setting/apps/"))
            {
                String apps_url=current_url.split("/apps/")[0]+"/apps";
                driver.get(apps_url);
            }
            else
            {
                driver.get(Util.siteNameout()+"/"+ExecuteStatements.getPortal(driver)+"/setting/apps");
            }
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
        // for(int attempt = 0; attempt < 3; attempt++)
        // {
        //     try
        //     { 
        //         CommonUtil.click(driver,By.id("menu_apps"),By.tagName("a"));
        //         Apps.waitTillLoads(driver);        
        //     }
        //     catch(Exception e)
        //     {
        //         CommonUtil.refreshPage(driver);
        //         if(attempt == 2)
        //         {
        //             CommonWait.waitTillDisplayed(driver,By.cssSelector("[documentClick='showCircleView']"));           
        //         }
        //     }
        // }
    }

    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_vhistory")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visits_div")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visits_div")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickChatHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_history")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_div")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("history_div")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","history_div"),"id","historylist");
        
        wait.until(ExpectedConditions.visibilityOf(e));
    }

    public static void clickMissed(WebDriver driver) throws Exception
    {
        clickVisitorsOnline(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("Missed")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("missed_mcontent")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("missed_mcontent")));
    }

    public static void clickFeedback(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        WebElement e = CommonUtil.elfinder(driver,"partiallinktext","Feedback");

        if(!e.getAttribute("class").contains("sel"))
        {
            e.click();
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("feedback_div")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("feedback_div")));
        
        final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedbacklist"),"tagname","tbody");
        
        wait = CommonUtil.waitreturner(driver,15,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                String s = div.getAttribute("innerHTML");
                if((s.equals("") || s.contains("cursr-point")) && !s.contains("feedbackload"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickReports(WebDriver driver) throws Exception
    {
        clickVisitorsOnline(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext","Reports").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().toLowerCase().contains("reports"))
                {
                    return true;
                }
                return false;
            }
        });

    }

    public static void clickReports(WebDriver driver,String view) throws Exception
    {
        clickVisitorsOnline(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext","Reports").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().toLowerCase().contains("reports"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

	public static void clickMyProfile(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext","My Profile").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("My Profile"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

    public static void clickMyProfile(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext","My Profile").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("My Profile"))
                {
                    return true;
                }
                return false;
            }
        });

    }

    public static void clickCannedMessages(WebDriver driver) throws Exception
    {

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext","Canned Messages").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("Canned Messages"))
                {
                    return true;
                }
                return false;
            }
        });
        
        waitTillPageLoadedInCanned(driver,"#canned");
    }

    public static void clickCannedResponses(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        Thread.sleep(1000);
        clickSettings(driver);

        Thread.sleep(1000);
        clickTemplates(driver);
        
        Thread.sleep(2000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("Canned responses"))
                {
                    return true;
                }
                return false;
            }
        });
        
        Thread.sleep(2000);
    }

    public static void clickTemplates(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_templates")));
        WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_templates");
        e.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }


    public static void clickArticlesTab(WebDriver driver)
    {
        if(Articles.isCurrentlyInArticlesTab(driver))
        {
            return;
        }

        WebElement articles_tab=Articles.getArticlesTab(driver);
        CommonUtil.clickWebElement(driver,articles_tab);
        CommonUtil.waitTillWebElementContainsAttributeValue( Articles.getArticlesTab(driver) ,"class",Articles.ARTICLES_LOADED_CLASS);
    }

    public static void clickEmailTemplatesTab(WebDriver driver)
    {
        if(EmailTemplates.isCurrentlyInEmailTemplatesTab(driver))
        {
            return;
        }

        WebElement emailTemplatesTab = EmailTemplates.getEmailTemplatesTab(driver);
        CommonUtil.clickWebElement(driver,emailTemplatesTab);
        CommonUtil.waitTillWebElementContainsAttributeValue( EmailTemplates.getEmailTemplatesTab(driver) ,"class",EmailTemplates.EMAIL_TEMPLATES_LOADED_CLASS);
    }
    
    public static void clickCannedMessagesCategory(WebDriver driver) throws Exception
    {
        clickCannedMessages(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("cannedmessages_categories"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(ResourceManager.getRealValue("cannedmessages_categories"))));
        
        driver.findElement(By.linkText(ResourceManager.getRealValue("cannedmessages_categories"))).click();
        
        waitTillPageLoadedInCanned(driver,"#organize");
    }

    public static void clickMyChats(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,By.id("suppm_mycurrent"),By.tagName("a"));
        CommonUtil.click(driver,By.id("suppm_mycurrent"),By.tagName("a"));
    }

    public static boolean isMyChatsShown(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,By.id("suppm_mycurrent"),By.tagName("a"));
    }



    public static void clickCompany(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_company")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_company");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
    }

    public static void clickBots(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,By.id("setting_sm_bot"));
        CommonUtil.getElement(driver,By.id("setting_sm_bot")).click();
        CommonWait.waitTillDisplayed(driver,BotsTab.ADD_BOT);
    }

    public static void clickDept(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_department")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_department");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-list")));
    }

    public static void clickPortalSettings(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_configration")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_configration");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
    }

    public static void clickBlockedIP(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_blockedip")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_blockedip");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modulelist")));
    }

    public static void clickEmbedTab(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));
		WebElement embed = CommonUtil.elfinder(driver,"id","setting_sm_embedchats");
		embed.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedlist")));
	}

	public static void clickAutomation(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_automation");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationtabs")));
    }

	public static void clickChatMonitor(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autochatmonitortab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autochatmonitortab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
        waitTillPageLoadedInAutomation(driver, "automation-chat-monitor");
    }

    public static void clickIntelligentTrigger(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotriggerstab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autotriggerstab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
        waitTillPageLoadedInAutomation(driver, "automation-intelligent-triggers");
    }

    public static void clickVisitorRouting(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoroutingrulestab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autoroutingrulestab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
        waitTillPageLoadedInAutomation(driver, "automation-visitor-routing");
    }

    public static void clickChatRouting(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autochatroutingtab")));
        WebElement e = CommonUtil.elfinder(driver,"classname","autochatroutingtab");
        e.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
        CommonUtil.sleep(5000);
        // CommonWait.waitTillDisplayed(driver,By.id("trouting"));
    }

    public static void clickCallRouting(WebDriver driver) throws Exception
    {
        for(int i=0;i<=3;i++)
        {
            try
            {
                FluentWait wait = CommonUtil.waitreturner(driver,10,250);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autocallroutingtab")));
                WebElement e = CommonUtil.elfinder(driver,"classname","autocallroutingtab");
                e.click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
                CommonWait.waitTillDisplayed(driver,By.id("trouting"));
                break;
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
                if(i==3)
                {
                    throw e;
                }
            }
        }
    }

    public static void clickEmailSchedule(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoschedulertab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autoschedulertab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
        waitTillPageLoadedInAutomation(driver, "visitorhistory-email-scheduler");
    }

    public static void clickLeadScoring(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_leadscoring")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_leadscoring");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
    }

	public static void clickInteg(WebDriver driver) throws Exception
	{
        for(int i = 0; i <= 3; i++)
		{
            FluentWait wait = CommonUtil.waitreturner(driver,10,250);
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_integration")));
    		WebElement integ = CommonUtil.elfinder(driver,"id","setting_sm_integration");
    		integ.click();
    		try
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("integhome")));
                break;
            }
            catch(Exception e)
            {
                CommonUtil.refreshPage(driver);
                if(driver.getCurrentUrl().contains("crmplus"))
                {
                    com.zoho.livedesk.util.common.CRMPlusCommonUtil.switchToSalesiqFrame(driver);
                }
                continue;
            }
        }
    }

    public static void navToUsersTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
    }

    public static void navToBotsTab(WebDriver driver)
    {
        clickSettings(driver);
        clickBots(driver);
    }

    public static void navToCompTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickCompany(driver);
    }

    public static void navToDeptTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickDept(driver);
    }

    public static void navToPortalTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickPortalSettings(driver);
    }

    public static void navToBlockedIPTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickBlockedIP(driver);
    }

    public static void navToEmbedTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickEmbedTab(driver);
    }

    public static void navToITTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickAutomation(driver);
        clickIntelligentTrigger(driver);
    }

    public static void navToVRTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickAutomation(driver);
        clickVisitorRouting(driver);
    }

    public static void navToLeadscoringTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickLeadScoring(driver);
    }

    public static void navToChatRoutingTab(WebDriver driver) throws Exception
    {
        if(driver.getCurrentUrl().contains("#setting/automation/chatrouting"))
        {
            return;
        }

        clickSettings(driver);
        clickAutomation(driver);
        clickChatRouting(driver);                
    }

    public static void navToCallRoutingTab(WebDriver driver) throws Exception
    {
        if(driver.getCurrentUrl().contains("#setting/automation/callrouting"))
        {
            return;
        }

        clickSettings(driver);
        clickAutomation(driver);
        clickCallRouting(driver);                
    }

    public static void navToCMTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickAutomation(driver);
        if(ExecuteStatements.isAdministrator(driver) == true)
        {
        clickChatMonitor(driver);
        }
    }
    public static void navToSchedulesTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickAutomation(driver);
        clickEmailSchedule(driver);
    }

    public static void navToArticlesTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickTemplates(driver);
        clickArticlesTab(driver);
    }

    public static void navToEmailTemplatesTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickTemplates(driver);
        clickEmailTemplatesTab(driver);
    }

    public static void navToIntegrationTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickInteg(driver);
    }

    
    public static void navToIntelligentTriggersTab(WebDriver driver) throws Exception
    {
        if(driver.getCurrentUrl().contains("#setting/automation/triggers"))
        {
            return;
        }

        clickSettings(driver);
        clickAutomation(driver);
        clickIntelligentTrigger(driver);               
    }

    public static void waitForLoading(WebDriver driver, String uri, ExtentTest test) throws Exception
    {
        Long startingTime = new Long(System.currentTimeMillis());
        
        WebElement banner = CommonUtil.elfinder(driver,"id","ldngtxt");
        
        Boolean present = false;
        
        Long t1 = new Long(System.currentTimeMillis());
        
        String allClass = "";
        String s1 = "";
        
        for(;;)
        {
            String s2 = banner.getAttribute("class");
            
            if(!s1.equals(s2))
            {
                s1 = s2;
                allClass += s1+"<>";
            }
            
            if(s2.contains("anim_bar"))
            {
                present = true;
                break;
            }
            
            Long t2 = new Long(System.currentTimeMillis());
            
            if(t2 - t1 >= (waitingTime*1000))
            {
                break;
            }
        }
        
        if(present)
        {
            allClass = "";
            s1 = "";
            t1 = new Long(System.currentTimeMillis());
            present = true;
            
            for(;;)
            {
                String s2 = banner.getAttribute("class");
                
                if(!s1.equals(s2))
                {
                    s1 = s2;
                    allClass += s1+"<>";
                }
                
                if(!s2.contains("anim_bar"))
                {
                    present = false;
                    addDetails(driver,uri,startingTime);
                    break;
                }
                
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2 - t1 >= (10*1000))
                {
                    break;
                }
            }
            
            if(present)
            {
                toBreakFlow(uri+"<>All class:"+allClass,driver,test,"Loading banner",uri,null);
            }
        }
        else
        {
            toBreakFlow(uri+"<>All class:"+allClass,driver,test,"Loading banner",uri,null);
        }
        
        synchronized(etestNameNotPresent)
        {
            if(etestName.get(test) == null)
            {
                StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
                
                String tracePath = "";
                
                for(StackTraceElement e : stackTraceElements)
                {
                    tracePath += e.getClassName()+"--"+e.getMethodName()+"--"+e.getLineNumber()+"<>";
                }
                
                etestNameNotPresent += tracePath;
            }
        }
        synchronized(etestCategoryNotPresent)
        {
            if(etestCategory.get(test) == null)
            {
                StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
                
                String tracePath = "";
                
                for(StackTraceElement e : stackTraceElements)
                {
                    tracePath += e.getClassName()+"<>"+e.getMethodName()+"<>"+e.getLineNumber()+"<>";
                }
                
                etestCategoryNotPresent += tracePath;
            }
        }
    }
    
    public static void waitForLoadingSuccessWithBanner(WebDriver driver,final String bannerContent, String uri, ExtentTest test) throws Exception
    {
        Long startingTime = new Long(System.currentTimeMillis());
        
        WebElement banner = CommonUtil.elfinder(driver,"id","ldngtxt");
        
        Boolean present = false;
        
        Long t1 = new Long(System.currentTimeMillis());
        
        String allClass = "";
        String content = "";
        String s1 = "";
        String content1 = "";
        
        for(;;)
        {
            String s2 = banner.getAttribute("class");
            String content2 = banner.getAttribute("innerHTML");
            
            if(!s1.equals(s2))
            {
                s1 = s2;
                allClass += s1+"<>";
            }
            
            if(!content1.equals(content2))
            {
                content1 = content2;
                content += content1+"<>";
            }
            
            if(content2.contains(bannerContent) && s2.contains("anim_bar") && s2.contains("ldng_success"))
            {
                present = true;
                break;
            }
            
            Long t2 = new Long(System.currentTimeMillis());
            
            if(t2 - t1 >= (waitingTime*1000))
            {
                break;
            }
        }
        
        if(present)
        {
            allClass = "";
            s1 = "";
            t1 = new Long(System.currentTimeMillis());
            present = true;
            
            for(;;)
            {
                String s2 = banner.getAttribute("class");
                
                if(!s1.equals(s2))
                {
                    s1 = s2;
                    allClass += s1+"<>";
                }
                
                if(!s2.contains("anim_bar"))
                {
                    present = false;
                    addDetails(driver,uri,startingTime);
                    break;
                }
                
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2 - t1 >= (10*1000))
                {
                    break;
                }
            }
            
            if(present)
            {
                toBreakFlow(uri+"<>All class:"+allClass,driver,test,"Loading success banner",uri,bannerContent);
            }
        }
        else
        {
            toBreakFlow(uri+"<>All class:"+allClass+"\nContent:"+content,driver,test,"Loading success banner",uri,bannerContent);
        }
    }
    
    public static void waitForLoadingLine(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,5,100);
        
        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("ajaxloder"))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            return;
        }
    
        wait = CommonUtil.waitreturner(driver,waitingTime,100);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("ajaxloder"))
                {
                    return false;
                }
                return true;
            }
        });
    }
    
    public static void waitTillPageLoadedInAutomation(WebDriver driver, final String content) throws Exception
    {
        for(int i = 1; i<=30; i++)
        {
            try
            {
                WebElement e = CommonUtil.elfinder(driver, "classname", "automationcontent");
                
                final  WebElement a = CommonUtil.elementfinder(driver, e, "tagname", "a");
                
                String aa = a.getAttribute("href");
                
                if(aa.contains(content))
                {
                    FluentWait wait = CommonUtil.waitreturner(driver,10,500);
                    
                    wait.until(ExpectedConditions.visibilityOf(a));
                    
                    Thread.sleep(500);
                    
                    break;
                }
            }
            catch(Exception e)
            {}
            
            Thread.sleep(500);
       	}
    }
    
    public static void waitTillPageLoadedInCanned(WebDriver driver, final String content) throws Exception
    {
        for(int i = 1; i<=30; i++)
        {
            try
            {
                final  WebElement a = CommonUtil.elfinder(driver, "classname", "linkdisplay");
                
                String aa = a.getAttribute("href");
                
                if(aa.contains(content) && aa.contains("canned-messages"))
                {
                    FluentWait wait = CommonUtil.waitreturner(driver,10,500);
                    
                    wait.until(ExpectedConditions.visibilityOf(a));
                    
                    Thread.sleep(500);
                    
                    break;
                }
            }
            catch(Exception e)
            {}
            
            Thread.sleep(500);
       	}
    }
    
    public static void toBreakFlow(String allClass, WebDriver driver, ExtentTest etestUsecase, String fail, String uri, String bannerContent) throws Exception
    {
        if(!started)
        {
            started = true;
            
            etest = ComplexReportFactory.getTest("Banner failures");
            ComplexReportFactory.setValues(etest,"Automation","Issues");
        }
        
        String usecaseName = etestName.get(etestUsecase);
        String usecaseCategory = etestCategory.get(etestUsecase);
        
        synchronized(etest)
        {
            String excludes[] = {""};
            
            StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
            
            String tracePath = "";
            
            for(StackTraceElement e : stackTraceElements)
            {
                tracePath += e.getClassName()+"<>"+e.getMethodName()+"<>"+e.getLineNumber()+"<>";
            }
            
            contents.add("<>toBreakFlow<>Loading<>"+tracePath+allClass+"<>");
            
            String content = fail+"-"+usecaseCategory+"-"+usecaseName+"-"+uri;
            
            if(bannerContent != null)
            {
                content += "-"+bannerContent;
            }
            
            etest.log(Status.FAIL,content);
            
            System.out.println(content+"<>toBreakFlow<>Loading<>"+tracePath+allClass+"<>");
            
//            "to break".replace("here",null);
        }
        
        String content = fail+"-"+usecaseCategory+"-"+usecaseName+"-"+uri;
        
        if(bannerContent != null)
        {
            content += "-"+bannerContent;
        }

        etestUsecase.log(Status.WARNING,content);
        
        TakeScreenshot.screenshot(driver,etestUsecase,"Banner","Failure","Error",0);
    }
    
    public static void addDetails(WebDriver driver, String uri, Long t1) throws Exception
    {
        try
        {
            Long t2 = new Long(System.currentTimeMillis());
            
            Date date = new Date(t1);
            DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
            String dateFormatted = formatter.format(date);
            
            String portal = "Not found";
            
            try
            {
                portal = ExecuteStatements.getPortal(driver);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            synchronized(request_uri)
            {
                Set<String> s = request_uri.get(uri);
                
                if(s == null)
                {
                    s = new HashSet<String>();
                }
                
                String content = portal+"/"+dateFormatted+"/"+(t2-t1);
                
                s.add(content);
                
                request_uri.put(uri,s);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static void printDetails() throws Exception
    {
        Set<String> request_uris = request_uri.keySet();
        
        String message = "{\"type\":\"table\",\"title\":\"$URI\",\"data\":"
        + "{\"headers\":[\"Portals\",\"Time(Duration)\"],"
        + "\"rows\":["
        + "$ROWS"
        + "]"
        + "}"
        + "}";
        
        String content = "";
        String error = "";
        
        int count = 0;
        
        for(String uri : request_uris)
        {
            String currentContent = message;
            String rows = "";
            count = 0;
            
            Set<String> values = request_uri.get(uri);
            
            Hashtable<String, Set<String>> portals = new Hashtable<>();
            
            for(String s : values)
            {
                Float diff = Float.parseFloat(s.split("/")[2]);
                
                diff = diff/1000;
                
                if(diff > 10)
                {
                    String portal = s.split("/")[0];
                    
                    Set<String> portalValues = portals.get(portal);
                    
                    if(portalValues == null)
                    {
                        portalValues = new HashSet<>();
                    }
                    
                    portalValues.add(s.split("/")[1]+"("+diff+")");
                    
                    portals.put(portal, portalValues);
                    
                    count++;
                }
            }
            
            if(count != 0)
            {
                values = portals.keySet();
                
                for(String portal : values)
                {
                    Set<String> portalValues = portals.get(portal);
                    
                    String portal2 = portal+"("+portalValues.size()+")";
                    
                    String v = "{\"Portals\":\""+portal2+"\",\"Time(Duration)\":\"";
                    
                    for(String v1 : portalValues)
                    {
                        v += v1+",";
                    }
                    
                    v+= "\"}";
                    
                    if(rows.equals(""))
                    {
                        rows = v;
                    }
                    else
                    {
                        rows += ","+v;
                    }
                    
                    System.out.println("printDetails<>"+v+"<>");
                }
                
                
                currentContent = currentContent.replace("$URI",""+uri+"("+count+")");
                currentContent = currentContent.replace("$ROWS",rows);
                
                if(content.equals(""))
                {
                    content = currentContent;
                }
                else
                {
                    content += ","+currentContent;
                }
            }
        }
        
        if(!content.equals(""))
        {
            String  messageContent = "{\"text\":\"Slow response - More than 10 seconds\""
            +",\"slides\":["
            +content
            + "]"
            + ","
            +"\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"},"
            +"\"card\":{\"theme\":\"1\"}}";
            
            
            ChatUtil.sendResultAsChatMessageForException(messageContent);
        }
    }

    public static WebElement getBanner(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,By.id("ldngtxt"));
        return CommonUtil.getElement(driver,By.id("ldngtxt"));
    }

    public static boolean isBannerFound(WebDriver driver,String expected_banner_text,String banner_type)
    {
        return isBannerFound(driver,null,expected_banner_text,banner_type);
    }

    public static boolean isBannerFound(WebDriver driver,ExtentTest etest,String expected_banner_text,String banner_type)
    {
        WebElement banner=getBanner(driver);
        String actual_banner_text=banner.getText();

        boolean isExpectedBannerType=false,isExpectedBannerContent=false;

        if(banner_type.equals(INFO_BANNER) && CommonUtil.hasClass(banner,"loadingcntmn"))
        {
            isExpectedBannerType=true;
        }
        else if(banner_type.equals(SUCCESS_BANNER) && CommonUtil.hasClass(banner,"ldng_success"))
        {
            isExpectedBannerType=true;
        }
        else if(banner_type.equals(FAILURE_BANNER) && CommonUtil.hasClass(banner,"ldng_error"))
        {
            isExpectedBannerType=true;
        }

        if(actual_banner_text.contains(expected_banner_text))
        {
            isExpectedBannerContent=true;
        }
        else if(expected_banner_text.matches(actual_banner_text))
        {
            //regex match
            isExpectedBannerContent=true;
        }


        if(etest!=null)
        {
            if(isExpectedBannerContent)
            {
                etest.log(Status.PASS,"Loading banner was found with expected content (actual : '"+actual_banner_text+"' expected : '"+expected_banner_text+"')");
            }
            else
            {
                etest.log(Status.FAIL,"Loading banner was NOT found with expected content (actual : '"+actual_banner_text+"' expected : '"+expected_banner_text+"')");
                TakeScreenshot.screenshot(driver,etest);
            }

            if(isExpectedBannerType)
            {
                etest.log(Status.PASS,banner_type+" banner was found");
            }
            else
            {
                etest.log(Status.FAIL,banner_type+" banner was NOT found. banner_class : '"+banner.getAttribute("class")+"'");
                TakeScreenshot.screenshot(driver,etest);                    
            }
        }

        return (isExpectedBannerContent && isExpectedBannerType);
    }

    public static boolean waitTillBanner(final WebDriver driver,final String banner_text,final String banner_type)
    {
        boolean isBannerFound=true;

        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(isBannerFound(driver,banner_text,banner_type))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            isBannerFound=false;
            e.printStackTrace();
        }

        return isBannerFound;
    }
}
