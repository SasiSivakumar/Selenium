//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class AppsMessenger
{
    /*Objects*/


    /*Constants*/
    private static final By
    PREVIEW_CONTAINER=By.id("previewHolder"),
    THEME_DESC=By.className("apps-list-desc"),
    SHOW_MORE=By.cssSelector("[action='show']")
    ;

    public static final String
    PAGE="'Apps-->Settings-->Messenger'"
    ;

    public static final String
    FLOAT="float",
    BUTTON="button"
    ;


    public static boolean waitTillLoads(WebDriver driver)
    {
        return CommonWait.waitTillDisplayed(driver,PREVIEW_CONTAINER);
    }

    public static boolean setTheme(WebDriver driver,ExtentTest etest,String type,String name)
    {
        By stickers_container_locator=By.cssSelector("[stickercontainertype='"+type+"']");
        By sticker_container_locator=By.cssSelector("[stickertype='"+name+"']");

        WebElement show_more=CommonUtil.getElement(driver,stickers_container_locator,SHOW_MORE);
        CommonUtil.clickWebElement(driver,show_more);

        WebElement sticker_container=CommonUtil.getElement(driver,stickers_container_locator,sticker_container_locator);
        CommonUtil.inViewPort(sticker_container);

        if(AppsCommonElements.isElementSelected(sticker_container))
        {
            etest.log(Status.INFO,"Theme type was already set as '"+type+"', and '"+name+"' theme was already selected");
            TakeScreenshot.infoScreenshot(driver,etest);
            return true;
        }

        CommonUtil.clickWebElement(driver, CommonUtil.getElement(sticker_container,THEME_DESC) );

        etest.log(Status.INFO,"Theme type was set as '"+type+"', and '"+name+"' theme was selected");

        return AppsCommonElements.handleSaveBanner(driver,etest,true);
    }

    public static boolean setWidgetContent(WebDriver driver,ExtentTest etest,boolean isOnlineState,String line1,String line2)
    {
        String widget_state=(isOnlineState?"online":"offline");
        By input=By.cssSelector("[key='"+widget_state+"_content']");

        List<WebElement> inputs=CommonUtil.getElements(driver,input);

        if(line1!=null)
        {
            AppsCommonElements.setInput(driver,inputs.get(0),line1);
        }
        if(line2!=null)
        {
            AppsCommonElements.setInput(driver,inputs.get(1),line2);
        }

        etest.log(Status.INFO,widget_state+" chat widget content was set as '"+line1+"' and '"+line2+"'");

        return AppsCommonElements.handleSaveBanner(driver,etest,true);
    }
}
