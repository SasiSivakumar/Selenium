//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.actions.*;
import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Hashtable;
import com.zoho.livedesk.client.ChatRouting.ChatRoutingTests;
import com.zoho.livedesk.client.Articles.ArticlesTests;
import com.zoho.livedesk.util.exceptions.Debugger;

public class ArticlesVisitorSide
{

    public static final By
    FAQ_CONTAINER=By.id("faqbox"),
    SEARCH=By.className("faq-srch"),
    NO_SEARCH_RESULT_CONTAINER=By.className("nofaq"),
    FAQ_ARTICLE_CONTAINER=By.cssSelector("[documentclick='faqpreview']"),
    FAQ_DIV=By.id("faqdiv"),
    ARTICLE_PREVIEW_CONTAINER=By.id("zsiqfaqpreview"),
    FAQ_LIST_ITEM=By.className("faqlst"),
    FAQ_CATEGORY_CONTAINER=By.cssSelector(".posrel[data-type='accordian']"),
    CATEGORY_FAQS_ITEM=By.cssSelector("[data-type='accordian-item']"),
    CATEGORY_FAQS_HEADER=By.cssSelector("[data-type='accordian-header']"),
    ARTICLE_HEADER=By.className("zsiq-prev-header"),
    ARTICLE_CONTENT=By.className("zsiq-prev-content"),
    CHAT_NOW_BUTTON_IN_ARTICLE=By.className("zsiq-cbtn"),
    ARTICLE_LIKE=By.className("siqico-like"),
    ARTICLE_DISLIKE=By.className("siqico-dislike"),
    ARTICLE_WRAPPER=By.id("article-wrap"),
    FAQ_TAB=By.id("faqtab"),
    CLOSE_ARTICLE_VISITOR_SIDE=By.className("siqico-close"),
    VOTE_CONTAINER=By.className("zsiq-aside")
    ;

    public static final String
    SEARCH_EXPANDED_CLASS="min-view",
    DATA_VOTE_ATTRIBUTE="data-vote",
    HEADER="header",
    CONTENT="content",
    LIKE="like",
    DISLIKE="dislike",
    CHATNOW="chatnow",
    ARTICLE_IDENTIFIER_TEXT="Was this article helpful",
    BEFORE_VOTING_TEXT="Was this article helpful?",
    AFTER_VOTING_TEXT="Thanks for your Feedback!";

    public static WebElement getArticleContainer(WebDriver driver)
    {
        return CommonUtil.getElement(driver,FAQ_CONTAINER);
    }

    public static WebElement getDepartmentContainer(WebDriver driver,String department) throws ZohoSalesIQRuntimeException
    {
        WebElement department_container=CommonUtil.getElementByAttributeValue( getArticleContainer(driver).findElements(FAQ_LIST_ITEM) ,"department",department);
                
        if(department_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Department '"+department+"' is not found in FAQ tab");
        }

        return department_container;
    }
 
    public static String getKnowledgeRepositoryName(WebDriver driver) throws Exception
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonUtil.getElement(driver,FAQ_TAB).getText();
    }

    public static WebElement getCategoryContainer(WebDriver driver,String category)
    {
        WebElement category_container=CommonUtil.getElementByAttributeValue( getCategoryContainers(driver) ,"innerText",category);

        if(category_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Category '"+category+"' is not found in FAQ tab:");
        }

        return category_container;        
    }

    public static List<WebElement> getCategoryContainers(WebDriver driver)
    {
        return getArticleContainer(driver).findElements(FAQ_CATEGORY_CONTAINER);
    }

    public static void clickArticlesTab(WebDriver driver) throws Exception
    {
        try
        {
            VisitorWindow.switchToChatWidget(driver);
        }
        catch(Exception e)
        {
            throw new ZohoSalesIQRuntimeException("Unable to switch to chat widget frame");
        }

        if(VisitorWindow.isArticlesTabFound(driver))
        {
            WebElement faq_tab=CommonUtil.getElement(driver,FAQ_TAB);
            CommonUtil.clickWebElement(driver,faq_tab);
            CommonWait.waitTillDisplayed(driver,FAQ_CONTAINER);   
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Articles tab was not found.");   
        }
    }

    public static boolean openArticle(WebDriver driver,ExtentTest etest,String article_title) throws Exception
    {
        return openArticle(driver,etest,article_title,null,null);
    }

    public static boolean openArticle(WebDriver driver,ExtentTest etest,String article_title,String category,String department) throws Exception
    {

        clickArticlesTab(driver);

        if(category==null && department==null)
        {
            //search
            etest.log(Status.INFO,"Searching for FAQ '"+article_title+"'");

            WebElement article_container=searchForFAQ(driver,etest,article_title);

            if(article_container!=null)
            {
                article_container.click();
                waitTillArticlePreviewDisplayed(driver);
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            //navigate and open

            // etest.log(Status.INFO,"Visitor : Opening department '"+department+"'");
            // openDepartment(driver,department);
            CommonUtil.sleep(500);
            etest.log(Status.INFO,"Visitor : Opening category '"+category+"'");
            openCategoryIfPresent(driver,category);
            WebElement article_container=getFAQContainerFromCategory(driver,article_title,category);

            if(article_container!=null)
            {
                etest.log(Status.INFO,"Visitor : Opening article '"+article_title+"'");
                CommonSikuli.findInWholePage(driver,"UI338.png","UI338",etest);
                CommonWait.waitTillDisplayed(article_container);
                article_container.click();
                waitTillArticlePreviewDisplayed(driver);
                
                return true;
            }
            else
            {
                etest.log(Status.INFO,"No FAQs were found by the name of '"+article_title+"'");
                return false;
            }
        }
    }

    public static void closeArticle(WebDriver driver)
    {
        if(Debugger.isSalesIQPage(driver))
        {
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,ARTICLE_IDENTIFIER_TEXT);
            boolean isClosed=HandleCommonUI.closePopup(popup);

            if(!CommonUtil.isChecked("ART64",ArticlesTests.result))
            {
                ArticlesTests.result.put("ART64",isClosed);
            }

        }
        else if(Debugger.isVisitorSite(driver))
        {
            WebElement close_button=getArticlePreviewContainer(driver).findElement(CLOSE_ARTICLE_VISITOR_SIDE);
            close_button.click();
            boolean isClosed=CommonWait.waitTillHidden(close_button);

            if(!CommonUtil.isChecked("ART65",ArticlesTests.result))
            {
                ArticlesTests.result.put("ART65",isClosed);
            }        
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid page. This page is neither a SalesIQ portal nor a SalesIQ visitor page.");
        }
    }

    public static WebElement getArticlePreviewContainer(WebDriver driver)
    {
        waitTillArticlePreviewDisplayed(driver);

        driver.switchTo().defaultContent();

        WebElement article_preview_container=CommonUtil.getElement(driver,ARTICLE_PREVIEW_CONTAINER);

        if(article_preview_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Article preview container was not found in visitor side");
        }

        return article_preview_container;
    }

    public static boolean waitTillArticlePreviewDisplayed(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        return CommonWait.waitTillDisplayed(driver,ARTICLE_PREVIEW_CONTAINER);
    }

    public static boolean waitTillArticlePreviewHidden(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        return CommonWait.waitTillHidden(driver,ARTICLE_PREVIEW_CONTAINER);
    }

    public static boolean verifyArticleData(ExtentTest etest,Hashtable<String,String> expected,Hashtable<String,String> actual)
    {
        int failcount=0;

        Set<String> keys = expected.keySet();

        for(String key: keys)
        {
            if(CommonUtil.checkStringEqualsAndLog(expected.get(key),actual.get(key),key,etest)==false)
            {
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static Hashtable<String,String> getExpectedArticleInfo(String title,String content,String like,String dislike,String chatnow)
    {
        Hashtable<String,String> expected_article_info=new Hashtable<String,String>();

        expected_article_info.put(HEADER,title);
        expected_article_info.put(CONTENT,content);
        expected_article_info.put(LIKE,like);
        expected_article_info.put(DISLIKE,dislike);
        expected_article_info.put(CHATNOW,chatnow);//"true" or "false" only
    
        return expected_article_info;
    }

    public static Hashtable<String,String> getArticleInfo(WebElement article_container)
    {
        Hashtable<String,String> article_info=new Hashtable<String,String>();

        String error_text="Not found due to exception";

        try
        {
            String value=CommonUtil.getElement(article_container,ARTICLE_HEADER).getText();
            article_info.put(HEADER,value);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            article_info.put(HEADER,error_text);
        }

        try
        {
            String value=CommonUtil.getElement(article_container,ARTICLE_CONTENT).getText();
            article_info.put(CONTENT,value);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            article_info.put(CONTENT,error_text);
        }

        try
        {
            String value=CommonUtil.getElement(article_container,ARTICLE_LIKE).getText();
            article_info.put(LIKE,value);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            article_info.put(LIKE,error_text);
        }

        try
        {
            String value=CommonUtil.getElement(article_container,ARTICLE_DISLIKE).getText();
            article_info.put(DISLIKE,value);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            article_info.put(DISLIKE,error_text);
        }

        try
        {
            article_info.put( CHATNOW, ""+CommonWait.isDisplayed( CommonUtil.getElement(article_container,CHAT_NOW_BUTTON_IN_ARTICLE) ) );
        }
        catch(Exception e)
        {
            e.printStackTrace();
            article_info.put(CHATNOW,error_text);
        }

        return article_info;
    }

    //may not work for ongoing chat with department selected from dropdown
    public static void openDepartment(WebDriver driver,String department) throws ZohoSalesIQRuntimeException
    {
        if(ExecuteStatements.getNoOfDepartmentsInVisitorSide(driver)<2)
        {
            try
            {
                VisitorWindow.switchToChatWidget(driver);
            }
            catch (Exception e) 
            {
                e.printStackTrace();    
            }

            return;
        }

        WebElement department_container=getDepartmentContainer(driver,department);
        department_container.click();
        CommonWait.waitTillHidden(department_container);
    }

    public static void openCategoryIfPresent(WebDriver driver,String category) throws ZohoSalesIQRuntimeException
    {
        WebElement category_container=getCategoryContainer(driver,category);

        try
        {
            CommonWait.waitTillDisplayed(category_container);
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }

        if(CommonWait.isDisplayed(category_container.findElement(CATEGORY_FAQS_ITEM)))
        {
            return;
        }

        CommonWait.waitTillDisplayed(category_container);

        category_container.findElement(CATEGORY_FAQS_HEADER).click();

        CommonWait.waitTillDisplayed(category_container.findElement(CATEGORY_FAQS_ITEM));
    }

    public static WebElement getFAQContainerFromCategory(WebDriver driver,String article_title,String category)
    {
        return CommonUtil.getElementByAttributeValue( getCategoryContainer(driver,category).findElements(FAQ_ARTICLE_CONTAINER),"innerText",article_title);
    }

    public static WebElement searchForFAQ(WebDriver driver,ExtentTest etest,String search_query)
    {
        //pass exact info in search query

        CommonSikuli.findInWholePage(driver,"UI339.png","UI339",etest);

        clickSearchFAQIcon(driver);

        WebElement search_input=CommonUtil.getElement(driver,SEARCH).findElement(By.tagName("input"));
        CommonUtil.sendKeysToWebElement(driver,search_input,search_query);

        CommonUtil.sleep(250);

        CommonUtil.waitTillWebElementContainsAttributeValue(getArticleContainer(driver),"innerText",search_query);

        if(CommonWait.isDisplayed(driver,NO_SEARCH_RESULT_CONTAINER))
        {
            etest.log(Status.INFO,"No FAQs were found in search results for search query '"+search_query+"'");
            TakeScreenshot.infoScreenshot(driver,etest);
            return null;
        }
        else
        {
            return getArticleContainer(driver).findElement(FAQ_DIV).findElement(FAQ_ARTICLE_CONTAINER);
        }
    }

    public static void clickSearchFAQIcon(WebDriver driver)
    {
        WebElement search=CommonUtil.getElement(driver,SEARCH);
        search.click();
        CommonUtil.waitTillWebElementDoesNotContainAttributeValue(search,"class",SEARCH_EXPANDED_CLASS);
    }

    public static boolean isArticlesCategorised(WebDriver driver)
    {
        return (getCategoryContainers(driver).size()>0);   
    }

    public static boolean likeArticle(WebDriver driver)
    {
        return voteArticle(driver,true);
    }

    public static boolean dislikeArticle(WebDriver driver)
    {
        return voteArticle(driver,false);
    }

    public static boolean voteArticle(WebDriver driver,boolean isLike)
    {
        By button_locator=isLike?ARTICLE_LIKE:ARTICLE_DISLIKE;
        WebElement like_button=getArticlePreviewContainer(driver).findElement(button_locator);
        like_button.click();
        return CommonWait.waitTillHidden(like_button);
    }

    public static boolean clickChatNowInArticlePreview(WebDriver driver,ExtentTest etest)
    {
        WebElement ele=CommonUtil.getElement( getArticlePreviewContainer(driver) , CHAT_NOW_BUTTON_IN_ARTICLE );
        CommonWait.waitTillDisplayed(ele);
        CommonUtil.click(driver,ele);
        etest.log(Status.INFO,"Chat now button was clicked in article preview container.");
        return CommonWait.waitTillHidden(driver);
    }
}
