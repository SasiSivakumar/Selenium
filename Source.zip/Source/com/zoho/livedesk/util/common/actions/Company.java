//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class Company
{

    /*Constants*/

    //hashtable keys/also same as REST API keys
    public static final String
    NAME="company_name",
    WEBSITE="website",
    ADDRESS="address",
    EMAIL="email_id",
    PHONE="phone",
    FAX="fax",
    LANGUAGE="language",
    TIMEZONE="time_zone",
    DESCRIPTION="description",
    SCREENNAME="screenname",
    LOGO="logo",
    ICON="icon",
    BUSINESS_HOURS_TBUTID="bhstatusradio",
    HIDE_CHAT_WIDGET_TBUTID="bhbtninput"
    ;

    public static final By
    COMPANY_NAME_INPUT=By.id("companyname"),
    WEBSITE_INPUT=By.id("companywebsite"),
    ADDRESS_INPUT=By.id("companyaddress"),
    EMAIL_INPUT=By.id("companyemail"),
    PHONE_INPUT=By.id("companytelephone"),
    FAX_INPUT=By.id("companyfax"),
    LANGUAGE_DIV=By.id("companylanguage"),
    TIMEZONE_DIV=By.id("companytimezone"),
    COMPANY_DESCRIPTION_INPUT=By.id("companydesc"),
    OVERLAPPING_DIV=By.className("lvdsblesb")
    ;
   
    /*Methods*/
    public static Hashtable<String,String> getCompanyInfo(WebDriver driver) throws Exception
    {
        Hashtable<String,String> company_info=new Hashtable<String,String>();

        Tab.navToCompTab(driver);

        company_info.put(NAME,getCompanyInfoBy(driver,COMPANY_NAME_INPUT));
        company_info.put(WEBSITE,getCompanyInfoBy(driver,WEBSITE_INPUT));
        company_info.put(ADDRESS,getCompanyInfoBy(driver,ADDRESS_INPUT));
        company_info.put(EMAIL,getCompanyInfoBy(driver,EMAIL_INPUT));
        company_info.put(PHONE,getCompanyInfoBy(driver,PHONE_INPUT));
        company_info.put(FAX,getCompanyInfoBy(driver,FAX_INPUT));
        company_info.put(LANGUAGE,getCompanyInfoBy(driver,LANGUAGE_DIV));
        company_info.put(TIMEZONE,getCompanyInfoBy(driver,TIMEZONE_DIV));
        company_info.put(DESCRIPTION,getCompanyInfoBy(driver,COMPANY_DESCRIPTION_INPUT));
        company_info.put(SCREENNAME,getCompanyInfoBy(driver,COMPANY_NAME_INPUT));

        return company_info;
    }

    public static void setCompanyInfo(WebDriver driver,ExtentTest etest,String name,String website,String address,String email,String phone,String fax,String language,String timezone,String description) throws Exception
    {
        Hashtable<String,String> company_info=new Hashtable<String,String>();

        Tab.navToCompTab(driver);

        setCompanyInfoBy(name,driver,etest,COMPANY_NAME_INPUT);
        setCompanyInfoBy(website,driver,etest,WEBSITE_INPUT);
        setCompanyInfoBy(address,driver,etest,ADDRESS_INPUT);
        setCompanyInfoBy(email,driver,etest,EMAIL_INPUT);
        setCompanyInfoBy(phone,driver,etest,PHONE_INPUT);
        setCompanyInfoBy(fax,driver,etest,FAX_INPUT);
        setCompanyInfoBy(language,driver,etest,LANGUAGE_DIV);
        setCompanyInfoBy(timezone,driver,etest,TIMEZONE_DIV);
        setCompanyInfoBy(description,driver,etest,COMPANY_DESCRIPTION_INPUT);

        Tab.clickCompany(driver);

        TakeScreenshot.infoScreenshot(driver,etest);
    }
    public static void setCompanyInfoBy(String info,WebDriver driver,ExtentTest etest,By... locators) throws Exception
    {
        if(info==null)
        {
            return;
        }

        WebElement element=CommonUtil.getElement(driver,locators);

        CommonUtil.inViewPortSafe(driver,element);

        if(element.getTagName().equals("input") || element.getTagName().equals("textarea"))
        {
            CommonUtil.sendKeysToWebElement(driver,element,info);
        }
        else
        {
            element.click();
            HandleCommonUI.chooseFromDropdown(element,info,true,true);
        }

        Tab.clickCompany(driver);

        etest.log(Status.INFO,info+" was set as "+element.getAttribute("id"));
    }

    public static String getCompanyInfoBy(WebDriver driver,By... locators)
    {
        try
        {
            WebElement element=CommonUtil.getElement(driver,locators);

            if(element.getTagName().equals("input") || element.getTagName().equals("textarea"))
            {
                return element.getAttribute("value");
            }
            else
            {
                return element.getAttribute("innerText").trim();
            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean toggleBusinessHours(WebDriver driver,boolean isEnable)
    {
        CommonUtil.scrollToBottomOfPage(driver);
        return HandleCommonUI.setToggle(driver,BUSINESS_HOURS_TBUTID,isEnable);
    }

    public static boolean toggleHideChatWidget(WebDriver driver,boolean isEnable)
    {
        CommonUtil.scrollToBottomOfPage(driver);

        if(isBusinessHoursEditAreaDisabled(driver))
        {
            throw new ZohoSalesIQRuntimeException("Business hours is not editable as business hours toggle is disabled.");
        }

        return HandleCommonUI.setToggle(driver,HIDE_CHAT_WIDGET_TBUTID,isEnable);
    }

    public static boolean isBusinessHoursEditAreaDisabled(WebDriver driver)
    {
        CommonUtil.scrollToBottomOfPage(driver);

        if(CommonWait.isPresent(driver,OVERLAPPING_DIV))
        {
            CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver,OVERLAPPING_DIV) );
        }
        else
        {
            return false;
        }

        return CommonWait.isDisplayed(driver,OVERLAPPING_DIV);
    }
}
