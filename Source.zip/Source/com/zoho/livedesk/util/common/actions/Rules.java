//$Id$
package com.zoho.livedesk.util.common.actions;

import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

public class Rules
{
	public static final By
    RULES_CONTAINER=By.id("trouting"),
    RULES_LIST_CONTAINER=By.id("rulelist"),
    RULE_CONTAINER=By.className("data_row"),
    RULE_NAME_INPUT=By.id("ruletitle_edit"),
    BUTTONS=By.className("rg-button"),
    ENABLE_DISABLE_BUTTON_CLASS=By.className("list_status"),
    RULE_EDIT_CONTAINER = By.className("rule_editmain"),
    POPUP_DIV = By.id("popupcontent"),
    SELECT_EMBED_DIV = By.id("ruleembed_edit_div"),
    SELECT_EMBED_DROPDOWN = By.id("ruleembed_edit_ddown")
    ;

    public static final String
    RULEID="ruleid",
    RULEID_EDIT_MODE_CLASS="rule_sel",
    SAVE_BUTTON_ONCLICK="handleRuleUpdate",
    CANCEL_BUTTON_ONCLICK = "hideEditRule",
    ENABLE_DISABLE_BUTTON_DOCUMENT_CLICK="handleRuleStatus",
    RULE_ENABLE_CLASS="enable"
    ;

    public static String getRuleId(WebDriver driver, int i) throws Exception
    {
        return CommonUtil.getElement(driver,RULES_CONTAINER,RULES_LIST_CONTAINER).findElements(RULE_CONTAINER).get(i).getAttribute(RULEID);
    }

    public static List<WebElement> getList(WebDriver driver) throws Exception
    {
        return CommonUtil.getElement(driver,RULES_CONTAINER,RULES_LIST_CONTAINER).findElements(RULE_CONTAINER);
    }

    public static void selectEmbed(WebDriver driver,String embed) throws Exception
    {
    	CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,SELECT_EMBED_DIV));
    	CommonWait.waitTillDisplayed(driver,SELECT_EMBED_DROPDOWN);
    	CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,SELECT_EMBED_DROPDOWN).findElements(By.tagName("li")),"title",embed));
    }

    public static void clickAdd(WebDriver driver, ExtentTest etest,String type,String rule) throws Exception
    {
        ((JavascriptExecutor) driver).executeScript("document.getElementById('ldngtxt').innerHTML = '';document.getElementById('ldngtxt').className = 'loadingcntmn';");

        clickAddButtonAutomationTab(driver,type);

        WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Select a website");

        saveRule(driver,etest,"0");

        etest.log(Status.INFO,rule+" - add button is clicked");
    }

    public static void clickAddButtonAutomationTab(WebDriver driver,String type)
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));
        
        WebElement e = CommonUtil.getElement(driver,By.className(type)).findElement(By.id("autobtnadd")); //CommonUtil.elfinder(driver,"id","autobtnadd");
        
        if(!CommonWait.isDisplayed(e))
        {
           WebElement action=CommonUtil.getElement(driver,By.className(type)).findElement(By.className("add_btn"));
           action.click();
        }
        else
        {
            e.click(); 
        }
    }

    public static void setRuleName(WebDriver driver,String id,String rule_name)
    {
        WebElement rule_name_element=getRuleEditContainer(driver,id).findElement(RULE_NAME_INPUT);
        CommonUtil.clickWebElement(driver,rule_name_element);
        CommonUtil.sendKeysToWebElement(driver,rule_name_element,rule_name);
    }

    public static WebElement getRuleContainer(WebDriver driver,String id)
    {
        List<WebElement> rules=CommonUtil.getElement(driver,RULES_CONTAINER,RULES_LIST_CONTAINER).findElements(RULE_CONTAINER);
        WebElement rule=CommonUtil.getElementByAttributeValue(rules,RULEID,id);
        return rule;
    }

    public static WebElement  getRuleEditContainer(WebDriver driver,String id)
    {
        WebElement rule = HandleCommonUI.getPopupByAttribute(driver,"innerHTML",id).findElement(RULE_EDIT_CONTAINER);
        return rule;
    }

    public static void openRuleEditView(WebDriver driver,String id)
    {
        getRuleContainer(driver,id).click();
        CommonUtil.waitTillWebElementContainsAttributeValue(getRuleContainer(driver,id),"class",RULEID_EDIT_MODE_CLASS);
    }

    public static void clickHeader(WebDriver driver, String id) throws Exception
    {
        WebElement e = Trigger.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        WebElement f = CommonUtil.elementfinder(driver,e,"classname","trulesinfo");
        
        mouseHoverAndClick(driver, f);
    }

    public static void mouseHoverAndClick(WebDriver driver,WebElement element)
    {
        int x = element.getLocation().x;
        int y = element.getLocation().y;
        
        Actions actions = new Actions(driver);
        actions.moveByOffset(x, y).build().perform();
        actions.click().build().perform();
    }

    public static boolean saveRule(WebDriver driver,ExtentTest etest,String id)
    {
        WebElement save_button=CommonUtil.getElementByAttributeValue( getRuleEditContainer(driver,id).findElements(BUTTONS) ,"documentclick",SAVE_BUTTON_ONCLICK );
        CommonUtil.inViewPort(save_button);
        save_button.click();
        etest.log(Status.INFO,"Rule (ruleid:"+id+") save button was clicked");
        return CommonWait.waitTillHidden(save_button);
    }

    public static boolean cancelRule(WebDriver driver,ExtentTest etest,String id)
    {
        WebElement cancel_button=CommonUtil.getElementByAttributeValue( getRuleEditContainer(driver,id).findElements(BUTTONS) ,"documentclick",CANCEL_BUTTON_ONCLICK );
        CommonUtil.inViewPort(cancel_button);
        cancel_button.click();
        etest.log(Status.INFO,"Rule (ruleid:"+id+") cancel button was clicked");
        return CommonWait.waitTillHidden(cancel_button);
    }
}
