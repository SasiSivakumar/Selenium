//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class ZiaConfiguration
{
    public static final String
    ZIA="Zia"
    ;

    public static final By
    HEADER=By.id("platformheader"),
    ACCESS_ZIA_CONSOLE_BUTTON=By.id("botconsole"),
    TRIGGER_CONTAINER=DialogflowConfiguration.TRIGGER_CONTAINER;
    ;

    public static boolean waitTillPageLoads(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,HEADER);
        WebElement header_ele=CommonUtil.getElement(driver,HEADER);
        return CommonUtil.waitTillTextFound(driver,header_ele,ZIA);
    }

    public static boolean clickAccessZiaConsole(WebDriver driver,ExtentTest etest)
    {
        DialogflowConfiguration.clickConsoleButton(driver);
        CommonUtil.waitTillNewTabOpens(driver,1);
        CommonUtil.switchToTab(driver,1);
        TakeScreenshot.infoScreenshot(driver,etest);
        return Zia.waitTillLoads(driver);
    }

    public static boolean isZiaSkillPresent(WebDriver driver,String skill_name)
    {
        return DialogflowConfiguration.isDialogflowAgentPresent(driver,skill_name);
    }

    public static boolean selectZiaAgent(WebDriver driver,String skill_name)
    {
        return DialogflowConfiguration.selectDialogflowAgent(driver,skill_name);
    }

    public static void setTriggerMessage(WebDriver driver,ExtentTest etest,String trigger_message)
    {
        String json_format_text = "{\"text\":\""+trigger_message+"\"}";
        String trigger_json = "{ \"replies\": [ "+json_format_text+" ] }";
        addTrigger(driver,etest,trigger_json);
    }

    public static void addTrigger(final WebDriver driver,ExtentTest etest,final String trigger_message)
    {
        WebElement trigger_input=CommonUtil.getElement(driver,TRIGGER_CONTAINER,By.tagName("textarea"));

        CommonUtil.sendKeysToWebElement(driver,trigger_input,trigger_message);

        etest.log(Status.INFO,"'"+trigger_message+"' was added as a bot trigger message");
    }

    public static void clickCreateBot(WebDriver driver)
    {
        DialogflowConfiguration.clickCreateBot(driver);
    }

    public static void clickEditBot(WebDriver driver)
    {
        DialogflowConfiguration.clickEditBot(driver); 
    }

    public static void clickSaveBot(WebDriver driver)
    {
        DialogflowConfiguration.clickSaveBot(driver);
    }

    public static boolean isBotPreviewChatInputDisplayed(WebDriver driver)
    {
        return DelugeScript.isBotPreviewChatInputDisplayed(driver);
    }

    public static void close(WebDriver driver)
    {
        DelugeScript.close(driver);
    }

    public static String getManagedByText(WebDriver driver)
    {
        return DialogflowConfiguration.getManagedByText(driver);
    }

    public static boolean isConnectWithZiaShown(WebDriver driver)
    {
        return DialogflowConfiguration.isConnectWithDialogflowButtonShown(driver);
    }
}
