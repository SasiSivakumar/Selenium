//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.actions.*;
import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Hashtable;
import com.zoho.livedesk.client.ChatRouting.ChatRoutingTests;
import com.zoho.livedesk.client.Articles.ArticlesTests;
import com.zoho.livedesk.util.common.CommonSikuli;
import java.util.Arrays;

public class ZohoDeskUI
{
	public static final By
	SETTINGS_ICON=By.id("zdsetup"),
	KNOWLEDGE_BASE_ICON=By.cssSelector("[href='#Solutions']"),
	DASHBOARD_BUTTON=By.cssSelector("[href*='Articledashboard']"),
	SELECT_ALL=By.cssSelector("[onchange*='selectAll']"),
	MASS_DELETE=By.cssSelector("[onclick*='massdelete']"),
	CONFIRM_DELETE=By.cssSelector("[value='Delete']"),
	ADD_ARTICLE=By.cssSelector("a#addModuleButton"),
	ARTICLE_TITLE_INPUT=By.id("SolutionForm_Title_Input"),
	CONTENT_INPUT_FRAME=By.className("KB_Editor_iframe"),
	ARTICLE_TEXT_BODY=By.cssSelector("body[contenteditable=true]"),
	DROPDOWN=By.id("select2-drop"),
	DROPDOWN_CONTAINER=By.cssSelector("div[id^='s2id'].categoryselectbox"),
	ALL_USERS=By.cssSelector("[data-permission='ALL_USERS']"),
	CREATE_NEW_CATEGORY=By.className("add-new-section"),
	NEW_CATEGORY_INPUT=By.cssSelector("input[onkeyup*='onEnterAddSection']"),
	SAVE_NEW_CATEGORY=By.className("Add-Subsec-save"),
	PUBLISH=By.cssSelector("#publish_btn"),
    CLOSE_BANNER=By.cssSelector("[onclick*=closeBanner]"),
    NOT_NOW=By.cssSelector(".notNow-btn"),
    DELETE_ARTICLE=By.cssSelector("a[onclick*='deleteArticle']"),
    EDIT_ARTICLE=By.cssSelector("a[onclick*='edit' i]")
	;

    public static void goToDesk1(WebDriver driver,ExtentTest etest)
    {
    	driver.get(Util.getOtherServiceURL("desk"));
    	TakeScreenshot.infoScreenshot(driver,etest);
        try
        {
            CommonWait.waitTillDisplayed(driver,SETTINGS_ICON);
        }
        catch(Exception e)
        {
            CommonUtil.sleep(30*1000);//in case exception occurs due to site slowness
            CommonWait.waitTillDisplayed(driver,SETTINGS_ICON);
        }

        if(CommonWait.isPresent(driver,CLOSE_BANNER))
        {
            CommonUtil.jsClick(driver,CLOSE_BANNER);
        }        
        if(CommonWait.isPresent(driver,NOT_NOW))
        {
            CommonUtil.jsClick(driver,NOT_NOW);
        }
    }

    public static void goToDesk(WebDriver driver,ExtentTest etest)
    {
        for(int i=0;i<=5;i++)
        {
            try
            {
                goToDesk1(driver,etest);
                break;
            }
            catch(Exception e)
            {
                if(i==5)
                {
                    throw e;
                }
            }
        }
    }

    public static void navToKBTab(WebDriver driver)
    {
        for(int i=0;i<=5;i++)
        {
            try
            {
                CommonWait.waitTillDisplayed(driver,KNOWLEDGE_BASE_ICON);
                CommonUtil.sleep(1000);
                CommonUtil.jsClick(driver,KNOWLEDGE_BASE_ICON);
                CommonWait.waitTillDisplayed(driver,DASHBOARD_BUTTON);
                break;
            }
            catch(Exception e)
            {
                if(i==5)
                {
                    throw e;
                }
            }
        }
    }

    public static void clickAddArticle(WebDriver driver,ExtentTest etest)
    {
        goToDesk(driver,etest);
        navToKBTab(driver);        
        driver.navigate().refresh();

        CommonWait.waitTillDisplayed(driver,ADD_ARTICLE);
        CommonUtil.click(driver,ADD_ARTICLE);
        CommonWait.waitTillHidden(driver,ADD_ARTICLE);
        CommonUtil.sleep(500);
    }

    public static boolean createArticle(WebDriver driver,ExtentTest etest,String title,String category,String content)
    {
        clickAddArticle(driver,etest);
        return enterArticleValues(driver,etest,title,category,content);
    }

    public static boolean enterArticleValues(WebDriver driver,ExtentTest etest,String title,String category,String content)
    {
    	CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,ARTICLE_TITLE_INPUT),title);
    	setArticleContent(driver,content);

        CommonWait.waitTillDisplayed(driver,ALL_USERS);
        WebElement all_users=CommonUtil.getElement(driver,ALL_USERS);
    	CommonUtil.click(driver,ALL_USERS);

    	setCategory(driver,etest,category);

    	CommonWait.waitTillPresent(driver,PUBLISH);
    	CommonUtil.jsClick(driver,PUBLISH);

        int i = 0;
        for(i = 0; i < 3; i++)
        {
            if(CommonWait.waitTillDisplayed(driver,30,By.id("saveComment")))
            {
                break;
            }
            else
            {
                CommonUtil.clickWebElement(driver,By.id("publish_btn"));
            }
        }

        if(i == 3)
        {
            etest.fail("Article was not successfully set");
            TakeScreenshot.screenshot(driver,etest);
        }
        else
        {
            etest.log(Status.INFO,"Article was successfully set with \ntitle-->"+title+"\ncategory-->"+category+"\n-->content-->"+content);
            TakeScreenshot.infoScreenshot(driver,etest);
        }

    	return CommonWait.waitTillDisplayed(driver,By.id("saveComment"));
    }

    public static void openArticleEditView(WebDriver driver,String article_name)
    {
        openArticle(driver,article_name);
        CommonWait.waitTillDisplayed(driver,EDIT_ARTICLE);
        CommonUtil.jsClick(driver,EDIT_ARTICLE);
        CommonWait.waitTillHidden(driver,EDIT_ARTICLE);
        CommonUtil.sleep(500);
    }

    public static boolean editArticle(WebDriver driver,ExtentTest etest,String old_title,String new_title,String new_category,String new_content)
    {
        openArticleEditView(driver,old_title);
        return enterArticleValues(driver,etest,new_title,new_category,new_content);
    }

    public static void setArticleContent(WebDriver driver,String content)
    {
        try
        {
            switchToArticleContainerFrame(driver);
            WebElement article_content_input=CommonUtil.getElement(driver,ARTICLE_TEXT_BODY);
            CommonUtil.sendKeysToWebElement(driver,article_content_input,content);
            driver.switchTo().defaultContent();
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
    }

    public static void setCategory(WebDriver driver,ExtentTest etest,String value)
    {
    	CommonUtil.getElement(driver,DROPDOWN_CONTAINER).click();
    	CommonWait.waitTillDisplayed(driver,DROPDOWN);

        // WebElement input=CommonUtil.getElement(driver,DROPDOWN,By.className("select2-input"));
        // CommonUtil.sendKeysToWebElement(driver,input,value);
        // CommonUtil.sendEnterKey(driver,input);
        // CommonWait.waitTillHidden(input);

        HandleCommonUI.chooseFromDropdown( CommonUtil.getElement(driver,DROPDOWN) , value );
    }

    public static void switchToArticleContainerFrame(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(CommonUtil.getElement(driver,CONTENT_INPUT_FRAME));
    }

    public static boolean openArticle(WebDriver driver,String article_name)
    {
        navToKBTab(driver);
        By locator=By.cssSelector("[title*='"+article_name+"']");
        CommonWait.waitTillDisplayed(driver,locator);
        CommonUtil.click(driver,locator);
        return CommonWait.waitTillHidden(driver,locator);
    }

    public static boolean deleteArticle(WebDriver driver,ExtentTest etest,String article_name)
    {
        openArticle(driver,article_name);
        return clickDeleteArticle(driver,etest,article_name);
    }

    public static boolean clickDeleteArticle(WebDriver driver,ExtentTest etest,String article_name)
    {
        CommonWait.waitTillDisplayed(driver,DELETE_ARTICLE);
        CommonUtil.jsClick(driver,DELETE_ARTICLE);
        CommonWait.waitTillPresent(driver,CONFIRM_DELETE);
        CommonUtil.jsClick(driver,CONFIRM_DELETE);
        etest.log(Status.INFO,"Article '"+article_name+"' was deleted");
        return CommonWait.waitTillHidden(driver,CONFIRM_DELETE);
    }

    public static void deleteAllArticles(WebDriver driver,ExtentTest etest)
    {
    	navToKBTab(driver);

        if(CommonWait.isPresent(driver,By.className("zsemptyartdashboard"))==false)
        {
            etest.log(Status.INFO,"Deleted all existing articles");
            CommonWait.waitTillPresent(driver,SELECT_ALL);
            CommonUtil.jsClick(driver,SELECT_ALL);
            CommonWait.waitTillPresent(driver,MASS_DELETE);
            CommonUtil.jsClick(driver,MASS_DELETE);
            CommonWait.waitTillPresent(driver,CONFIRM_DELETE);
            CommonUtil.jsClick(driver,CONFIRM_DELETE);
            CommonWait.waitTillHidden(driver,CONFIRM_DELETE);
        }
        else
        {
            etest.log(Status.INFO,"No articles were present in desk portal");
            TakeScreenshot.infoScreenshot(driver,etest);
        }
    }
}
