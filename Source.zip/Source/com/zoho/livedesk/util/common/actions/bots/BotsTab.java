//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;

public class BotsTab
{
    public static final By
    ADD_BOT=By.cssSelector("[documentclick='createZIA']"),
    BOTS_EMPTY_CONTAINER=By.className("bot-intgbody"),
    BOT_NAME=By.className("bot-lstname"),
    BOT_DESC=By.cssSelector("p.mT5"),
    BOT_PUBLISH_STATUS=By.cssSelector("span.mT10"),
    LISTED_BOT_CONTAINER=By.cssSelector("[documentclick='handleBotURL']"),
    CONVERSED_COUNT=By.className("sqico-chat-bubble"),
    TRANSFERED_PERCENTAGE=By.className("sqico-chatuser"),
    HOURS_WORKED=By.className("sqico-timing"),
    LAST_USED=By.className("sqico-calendar2"),
    TOGGLE_BOT=By.cssSelector("[documentclick='toggleBotStatus']"),
    DELETE_BOT=By.className("sqico-delico"),
    FAILED_TOOLTOP_TRIGGER=By.className("sqico-failed"),
    TYPING_DELAY=By.id("messagedelay_dropdown")
    ;

    public static final String
    STATUS_ENABLED="enable",
    STATUS_DISABLED="disable"
    ;

    public static boolean isBotsEmptyState(WebDriver driver)
    {
        return CommonWait.isPresent(driver,BOTS_EMPTY_CONTAINER);
    }

    public static boolean isBotsEmptyStateContentFound(WebDriver driver,ExtentTest etest)
    {
        int failcount=0;

        String tab_content=CommonUtil.getElement(driver,Tab.TAB_INNER_CONTENT).getAttribute("innerText");
        String expected=null;

        expected=ResourceManager.getRealValue("bots_tab_header");
        if( !CommonUtil.checkStringContainsAndLog(expected,tab_content,"empty state content",etest) )
        {
            failcount++;
        }

        expected=ResourceManager.getRealValue("bots_tab_description_empty_state");
        if( !CommonUtil.checkStringContainsAndLog(expected,tab_content,"empty state content",etest) )
        {
            failcount++;
        }

        expected=ResourceManager.getRealValue("bots_tab_empty_state_info1");
        if( !CommonUtil.checkStringContainsAndLog(expected,tab_content,"empty state content",etest) )
        {
            failcount++;
        }

        expected=ResourceManager.getRealValue("bots_tab_empty_state_info2");
        if( !CommonUtil.checkStringContainsAndLog(expected,tab_content,"empty state content",etest) )
        {
            failcount++;
        }

        expected=ResourceManager.getRealValue("bots_tab_empty_state_info3");
        if( !CommonUtil.checkStringContainsAndLog(expected,tab_content,"empty state content",etest) )
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean isBotsTabContentFound(WebDriver driver,ExtentTest etest)
    {
        int failcount=0;

        String tab_content=CommonUtil.getElement(driver,Tab.TAB_INNER_CONTENT).getAttribute("innerText");
        String expected=null;

        expected=ResourceManager.getRealValue("bots_tab_description");
        if( !CommonUtil.checkStringContainsAndLog(expected,tab_content,"bots tab content",etest) )
        {
            failcount++;
        }
        return CommonUtil.returnResult(failcount);
    }

    public static boolean isAddBotButtonShown(WebDriver driver,ExtentTest etest)
    {
        if(CommonWait.isPresent(driver,ADD_BOT)==false)
        {
            etest.log(Status.INFO,"Add bot button is NOT present");
            return false;
        }

        boolean isShown=CommonWait.isDisplayed(driver,ADD_BOT);

        if(isShown)
        {
            etest.log(Status.INFO,"Add bot button is displayed");
        }
        else
        {
            etest.log(Status.INFO,"Add bot button is NOT displayed");
        }

        return isShown;
    }

    public static boolean isBotPresent(WebDriver driver,String expected_bot)
    {
        return (getListedBotElement(driver,expected_bot)!=null);
    }

    public static boolean isBotEnabled(WebElement bot)
    {
        return bot.getAttribute("status").equals(STATUS_ENABLED);
    }


    public static boolean isBotEnabled(WebDriver driver,String bot_name)
    {
        return isBotEnabled(getListedBotElement(driver,bot_name));
    }
    public static WebElement getListedBotElement(WebDriver driver,String expected_bot)
    {
        Tab.navToBotsTab(driver);

        List<WebElement> bots=driver.findElements(LISTED_BOT_CONTAINER);

        for(WebElement bot : bots)
        {
            WebElement bot_name_element=CommonUtil.getElement(bot,BOT_NAME);

            String bot_name=bot_name_element.getAttribute("innerText").trim();

            if(bot_name.equals(expected_bot))
            {
                return bot;
            }
        }

        return null;
    }

    public static void clickAddBot(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,ADD_BOT);
        CommonUtil.getElement(driver,ADD_BOT).click();
        CommonWait.waitTillDisplayed(driver,BotConfiguration.BOT_NAME);
    }

    public static void openBotConfiguration(WebDriver driver,String name)
    {
        getListedBotElement(driver,name).click();
        CommonUtil.scrollIntoView(driver,CommonUtil.getElement(driver,BotConfiguration.BOT_NAME));
        CommonWait.waitTillDisplayed(driver,BotConfiguration.BOT_NAME);        
    }

    public static boolean toggleBot(WebDriver driver,ExtentTest etest,String name,boolean isEnable)
    {
        WebElement bot=getListedBotElement(driver,name);

        if(isBotEnabled(bot)==isEnable)
        {
            return true;
        }

        CommonUtil.scrollIntoView(driver,bot);

        CommonUtil.mouseHover(driver, CommonUtil.getElement(bot,BOT_NAME) );
        CommonWait.waitTillDisplayed(bot,TOGGLE_BOT);

        CommonUtil.getElement(bot,TOGGLE_BOT).click();

        etest.log(Status.INFO,"Bot '"+name+"' was "+(isEnable?"enabled":"disabled"));
        TakeScreenshot.infoScreenshot(driver,etest);

        return CommonUtil.waitTillWebElementContainsAttributeValue(bot,"status", (isEnable?STATUS_ENABLED:STATUS_DISABLED) );
    }

    public static void deleteAllBotsExcept(WebDriver driver,ExtentTest etest,String... ignore_bots)
    {
        Tab.navToBotsTab(driver);

        List<WebElement> bot_name_elements=CommonUtil.getElements(driver,BOT_NAME);
        List<String> bot_names=CommonUtil.getAttributesFromList(bot_name_elements,"innerText");

        String ignore_bots_list=String.join(",", ignore_bots);

        for(String bot : bot_names)
        {
            //delete if not in ignore list
            if(ignore_bots_list.contains(bot)==false)
            {
                deleteBot(driver,etest,bot);
            }
        }
    }

    public static void deleteAllBots(WebDriver driver,ExtentTest etest)
    {
        deleteAllBotsExcept(driver,etest,CommonUtil.getUniqueMessage());//giving a dummy value in ignore bots list
    }

    public static void disableAllBots(WebDriver driver,ExtentTest etest)
    {
        disableAllBotsExcept(driver,etest,CommonUtil.getUniqueMessage());//giving a dummy value in ignore bots list
    }

    public static void disableAllBotsExcept(WebDriver driver,ExtentTest etest,String... ignore_bots)
    {
        Tab.navToBotsTab(driver);

        List<WebElement> bot_name_elements=CommonUtil.getElements(driver,BOT_NAME);
        List<String> bot_names=CommonUtil.getAttributesFromList(bot_name_elements,"innerText");

        String ignore_bots_list=String.join(",", ignore_bots);

        for(String bot : bot_names)
        {
            //delete if not in ignore list
            if(ignore_bots_list.contains(bot)==false)
            {
                toggleBot(driver,etest,bot,false);
            }
            else
            {
                toggleBot(driver,etest,bot,true);                
            }
        }
    }

    public static boolean deleteBot(WebDriver driver,ExtentTest etest,String name)
    {
        WebElement bot=getListedBotElement(driver,name);

        CommonUtil.scrollIntoView(driver,bot);

        CommonUtil.mouseHover(driver, CommonUtil.getElement(bot,BOT_NAME) );
        CommonWait.waitTillDisplayed(bot,DELETE_BOT);

        CommonUtil.getElement(bot,DELETE_BOT).click();

        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"delete");
        HandleCommonUI.clickPositivePopupButton(popup);

        etest.log(Status.INFO,"Bot '"+name+"' was deleted");
        TakeScreenshot.infoScreenshot(driver,etest);

        return  (CommonWait.isDisplayed(bot)==false);
    }
}
