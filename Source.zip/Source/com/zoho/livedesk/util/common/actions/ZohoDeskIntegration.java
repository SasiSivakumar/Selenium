//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.actions.*;
import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Hashtable;
import com.zoho.livedesk.client.ChatRouting.ChatRoutingTests;
import com.zoho.livedesk.client.Articles.ArticlesTests;
import com.zoho.livedesk.util.common.CommonSikuli;
import java.util.Arrays;
import org.apache.commons.lang3.StringUtils;

public class ZohoDeskIntegration
{
	public static final By
	SCHEDULE_SYNC_DROPDOWN_CONTAINER=By.id("articlesyncfreq_div"),
	SCHEDULE_SYNC_DROPDOWN=By.id("articlesyncfreq_div_ddown"),
	SYNC_NOW=By.cssSelector("[onclick*='syncArticleNow()']"),
	WESBITE_CONTAINER=By.cssSelector("[conf='applist']"),
	SEARCH_INPUT=By.id("categorysearch"),
	SEARCH_RESULT=By.cssSelector("[records='1']"),
	REMOVE_ALL_CATEGORIES=By.cssSelector("[documentclick='handleCategoryRemove']"),
	SELECTED_DESK_DEPARTMENT=By.cssSelector("[purpose='selcategories']")
	;

	public static final String
	SERVICE_NAME="Zoho Desk"
	;

    public static void goToPage(WebDriver driver) throws Exception
    {
        Tab.navToIntegrationTab(driver);
        Integration.selectIntegApp(driver,SERVICE_NAME);
    }

	public static void enable(WebDriver driver,ExtentTest etest)
	{
		com.zoho.livedesk.client.IntegrationSettings.enableDeskInteg(driver,etest);
	}

	public static void disable(WebDriver driver,ExtentTest etest)
	{
		com.zoho.livedesk.client.IntegrationSettings.disableDeskInteg(driver,etest);
	}

	public static void setArticleAutoSyncValue(WebDriver driver,ExtentTest etest,String value)
	{
		enable(driver,etest);
		CommonWait.waitTillDisplayed(driver,SCHEDULE_SYNC_DROPDOWN_CONTAINER);
		CommonUtil.click(driver,SCHEDULE_SYNC_DROPDOWN_CONTAINER);
        HandleCommonUI.chooseFromDropdown( CommonUtil.getElement(driver,SCHEDULE_SYNC_DROPDOWN) , value);
	}

	public static void clearCategoryForWebsite(WebDriver driver,String website)
	{
		List<WebElement> containers=CommonUtil.getElements(driver,WESBITE_CONTAINER);
		WebElement container=CommonUtil.getElementByAttributeValue(containers,"innerText",website);

		for(int i=0;i<=3;i++)
		{
			if(CommonWait.isPresent(container,SELECTED_DESK_DEPARTMENT))
			{
				try
				{
					CommonUtil.inViewPort(CommonUtil.getElement(container,SELECTED_DESK_DEPARTMENT));
					CommonUtil.mouseHover(driver,CommonUtil.getElement(container,SELECTED_DESK_DEPARTMENT));
					WebElement remove_icon=CommonUtil.getElement(container,REMOVE_ALL_CATEGORIES);
					CommonWait.waitTillDisplayed(remove_icon);
					CommonUtil.mouseHoverAndClick(driver,remove_icon);
				}
				catch(Exception e)
				{
					if(i==3)
					{
						throw e;
					}
				}
			}
			else
			{
				break;
			}
		}
	}

	public static void addCategoryForWebsite(WebDriver driver,ExtentTest etest,String website,String category)
	{
		List<WebElement> containers=CommonUtil.getElements(driver,WESBITE_CONTAINER);
		WebElement container=CommonUtil.getElementByAttributeValue(containers,"innerText",website);

		String search=StringUtils.chop(category);//remove last char
		WebElement input=CommonUtil.getElement(container,SEARCH_INPUT);
		CommonUtil.inViewPort(input);
		input.click();
		input.click();
		input.click();
		input.click();
		input.click();
		CommonUtil.sendKeysLikeHuman( input , search );

		CommonWait.waitTillDisplayed(container,SEARCH_RESULT);
		CommonUtil.clickWebElement( driver, CommonUtil.getElement(container,SEARCH_RESULT) );

		CommonWait.waitTillElementContainsText( CommonUtil.getElement(container,By.id("selcategories")) , category );
	}

	public static void syncNow(WebDriver driver,ExtentTest etest)
	{
		CommonWait.waitTillPresent(driver,SYNC_NOW);
		CommonUtil.inViewPort(CommonUtil.getElement(driver,SYNC_NOW));
		CommonWait.waitTillDisplayed(driver,SYNC_NOW);
		CommonUtil.click(driver,SYNC_NOW);
		Tab.waitTillBanner(driver,"sync",Tab.SUCCESS_BANNER);

		etest.log(Status.INFO,"'Sync Now' was clicked at "+CommonUtil.timestamp());

		CommonUtil.sleep(2*60*1000);//it takes w min for syncing to take place

		driver.navigate().refresh();

		etest.log(Status.INFO,"waited till "+CommonUtil.timestamp()+" for desk articles to sync");	}
}
