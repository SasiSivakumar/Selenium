//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class Trigger1
{
	public static void clickAdd(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("automationcontent")));

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.className("automationcontent")).getAttribute("innerHTML").contains("trigger"))
                {
                	return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.className("automationcontent")).getText().contains("trigger"))
                {
                	return true;
                }
                return false;
            }
        });

        WebElement add = null;

        final WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"id","trouting");

        if(e.getAttribute("innerHTML").contains("data_row"))
        {
        	final int initial_count = e.findElements(By.className("data_row")).size();

        	add = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","autobtnadd"),"id","addrule");

        	add.click();

        	Tab.waitForLoading(driver,"addrule.do",etest);

        	wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	            	try
	            	{
		            	int final_count = e.findElements(By.className("data_row")).size();
		                if(final_count == initial_count+1)
		                {
		                	return true;
		                }
		            }
		            catch(StaleElementReferenceException e){}
	                return false;
	            }
	        });
        }
        else
        {
        	add = CommonUtil.elementfinder(driver,e,"id","addrule");

        	add.click();

        	Tab.waitForLoading(driver,"addrule.do",etest);

        	wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(e.findElements(By.className("data_row")).size() == 1)
	                {
	                	return true;
	                }
	                return false;
	            }
	        });
        }
	}

	public static void addRule(WebDriver driver,ExtentTest etest,String triggerevent,String column1,String column1_1,String column2,String column3,String column3_1,String action,String action_value) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("automationcontent")));

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.className("automationcontent")).getAttribute("innerHTML").contains("trigger"))
                {
                	return true;
                }
                return false;
            }
        });

        WebElement routing = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"id","trouting");

        final WebElement div = routing.findElements(By.className("data_row")).get(0);

        final String id = div.getAttribute("ruleid");

        selectInDropDown(driver,"triggerevent_"+id+"_div","triggerevent_"+id+"_ddown",triggerevent);

        selectInDropDown(driver,"prior"+id+"_col1_div","prior"+id+"_col1_ddown",column1);

        if(column1_1 != null)
        {
        	selectInDropDown(driver,"prior"+id+"_col4_div","prior"+id+"_col4_ddown",column1_1);
        }

        selectInDropDown(driver,"prior"+id+"_col2_div","prior"+id+"_col2_ddown",column2);

        WebElement values = CommonUtil.elfinder(driver,"id","prior"+id+"_col3");

        CommonUtil.elementfinder(driver,values,"id","col3_input1").sendKeys(column3);

        if(column3_1 != null)
        {
        	CommonUtil.elementfinder(driver,values,"id","col3_input2").sendKeys(column3_1);
        }
        if(action != null)
        {
        	selectInDropDown(driver,"action_"+id+"_div","action_"+id+"_ddown",action);
        }
        if(action_value != null)
        {
        	setActionValues(driver,id,action,action_value);
        }
        
    }

	public static void selectInDropDown(WebDriver driver,String div,final String dropDown,String value) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		CommonUtil.elfinder(driver,"id",div).click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	            	if(driver.findElement(By.id(dropDown)).getAttribute("style").contains("block"))
	            	{
	            		return true;
	            	}
	            }
	            catch(StaleElementReferenceException e){}
                return false;
            }
        });

        if(CommonUtil.elfinder(driver,"id",dropDown).getAttribute("innerHTML").contains("srchtxt"))
        {
        	CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",dropDown),"id","srchtxt"),"tagname","input").sendKeys(value);

        	wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	            	try
	            	{
		            	if(driver.findElement(By.id(dropDown)).findElements(By.tagName("li")).size() == 1)
		            	{
		            		return true;
		            	}
		            }
		            catch(StaleElementReferenceException e){}
	                return false;
	            }
	        });
        }

        List<WebElement> list1 = CommonUtil.elfinder(driver,"id",dropDown).findElements(By.tagName("li"));

        for(WebElement e : list1)
        {
        	CommonUtil.inViewPort(e);
        	if(e.getText().contains(value))
        	{
        		e.click();
        		break;
        	}
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	            	if(driver.findElement(By.id(dropDown)).getAttribute("style").contains("none"))
	            	{
	            		return true;
	            	}
	            }
	            catch(StaleElementReferenceException e){}
                return false;
            }
        });
	}

	public static void setActionValues(WebDriver driver,String id,String action,String action_value) throws Exception
	{
		switch (action)
		{
			case "Add to mailing list": 
				addToMailingList(driver,action_value);
				break;

			case "Glow button":
			
		}
	}

	public static void addToMailingList(WebDriver driver,String values) throws Exception 
	{
		FluentWait wait = CommonUtil.waitreturner(driver,8,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));

		// wait.until(new Function<WebDriver,Boolean>(){
  //           public Boolean apply(WebDriver driver)
  //           {
  //           	try
  //           	{
	 //            	if(driver.findElement(By.id("popupdiv")).getText().contains("Add visitors to the Campaign Mailing List"))
	 //            	{
	 //            		return true;
	 //            	}
	 //            }
	 //            catch(StaleElementReferenceException e){}
  //               return false;
  //           }
  //       });

		WebElement mailchimp_popup = HandleCommonUI.getPopupByInnerText(driver,"Add visitors to the Campaign Mailing List");
		com.zoho.livedesk.util.common.CommonWait.waitTillDisplayed(mailchimp_popup);

		String fields[] = values.split("/");

		if(fields[0].contains("Add to existing list"))
		{
			WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Add visitors to the Campaign Mailing List"); //CommonUtil.elfinder(driver,"id","popupdiv");

			CommonUtil.elementfinder(driver,popup,"id","cmpexisting").click();

			selectInDropDown(driver,"syncinput_div","syncinput_ddown",fields[1]);

			CommonUtil.getElement(driver,By.id("okbtn"));
		}
		else
		{
			final WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Add visitors to the Campaign Mailing List"); //CommonUtil.elfinder(driver,"id","popupdiv");

            final String initial_style = popup.getAttribute("style");

			try
			{
				CommonUtil.elementfinder(driver,popup,"id","cmpnew").click();

				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	try
		            	{
		            		String final_style = popup.getAttribute("style");
			            	if(!final_style.equals(initial_style))
			            	{
			            		return true;
			            	}
			            }
			            catch(StaleElementReferenceException e){}
		                return false;
		            }
		        });

		        CommonUtil.elementfinder(driver,popup,"id","cmpnew").click();

				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	try
		            	{
		            		if(!popup.findElement(By.id("createnewlist")).getAttribute("style").equals("none"))
			            	{
			            		return true;
			            	}
			            }
			            catch(StaleElementReferenceException e){}
		                return false;
		            }
		        });
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}

	        WebElement div = CommonUtil.elementfinder(driver,popup,"id","createnewlist");

	        CommonUtil.elementfinder(driver,div,"id","listname").sendKeys("L"+fields[1]);
	        CommonUtil.elementfinder(driver,div,"id","fromemail").sendKeys("email@"+fields[1]+".com");
	        CommonUtil.elementfinder(driver,div,"id","fromname").sendKeys("N"+fields[1]);
	        CommonUtil.elementfinder(driver,div,"id","fromabout").sendKeys("R"+fields[1]);
	        
	        if(fields[2].equals("Weekly"))
	        {
	        	CommonUtil.elementfinder(driver,popup,"id","custdept_1").click();
	        }
	        else if(fields[2].equals("Monthly"))
	        {
	        	CommonUtil.elementfinder(driver,popup,"id","custdept_2").click();
	        }
	        else
	        {
	        	CommonUtil.elementfinder(driver,popup,"id","custdept_0").click();
	        }

	        Thread.sleep(500);

	        HandleCommonUI.clickPositivePopupButton(popup);
	    }
	}

	public static void delete(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,8,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("automationcontent")));

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.className("automationcontent")).getAttribute("innerHTML").contains("trigger"))
                {
                	return true;
                }
                return false;
            }
        });

        final WebElement routing = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"id","trouting");

        if(!routing.getAttribute("innerHTML").contains("data_row"))
        {
        	return;
        }

        List<WebElement> list = routing.findElements(By.className("data_row"));

        final int initial_count = list.size();

        final WebElement div = list.get(0);

        final String id = div.getAttribute("ruleid");

        CommonUtil.mouseHover(driver,div);

        WebElement delete = CommonUtil.elementfinder(driver,div,"classname","sqico-delico");

        wait.until(ExpectedConditions.visibilityOf(delete));

        delete.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));

        PopUp.clickOkBtn(driver);

        Tab.waitForLoading(driver,"deleterule.do",etest);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(initial_count > 1)
            	{
	            	int final_count = routing.findElements(By.className("data_row")).size();
	            	if(final_count == initial_count-1)
	            	{
	            		return true;
	            	}
	            }
	            else
	            {
	            	if(!routing.getAttribute("innerHTML").contains("data_row"))
	            	{
	            		return true;
	            	}
	            }

	            return false;
            }
        });
	}
}
