//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class VendorWebhookConfiguration
{
    public static final By
    FIELD_VALUE_ELEMENT=By.cssSelector(".mT10.f14.fw500"),
    INSTALLED_BY=By.className("wh_instahdr"),
    VENDOR_CONSOLE=By.id("botconsole"),
    HEADER=By.id("platformheader"),
    PUBLISH=By.id("botpublish")
    ;

    public static final String
    PUBLISH_TEXT="Publish"
    ;

    public static void publish(WebDriver driver,ExtentTest etest,String name)
    {
        WebElement publish=CommonUtil.getElement(driver,PUBLISH);
        CommonWait.waitTillDisplayed(publish);
        CommonUtil.click(driver,publish);
        CommonWait.waitTillHidden(publish);
        etest.log(Status.INFO,"Bot '"+name+"' was published");
    }

    public static void close(WebDriver driver)
    {
        DelugeScript.close(driver);
    }

    public static boolean waitTillPageLoads(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,HEADER);
        WebElement header_ele=CommonUtil.getElement(driver,HEADER);
        return CommonUtil.waitTillTextFound(driver,header_ele,PUBLISH_TEXT);
    }

    public static String getConsole(WebDriver driver)
    {
        return CommonUtil.getElement(driver,VENDOR_CONSOLE).getAttribute("url").trim();
    }

    public static String getInstalledBy(WebDriver driver)
    {
        return CommonUtil.getElement(driver,INSTALLED_BY).getAttribute("innerText").trim();
    }

    public static String getServiceName(WebDriver driver)
    {
        return CommonUtil.getElements(driver,FIELD_VALUE_ELEMENT).get(0).getAttribute("innerText").trim();
    }

    public static String getVersion(WebDriver driver)
    {
        return CommonUtil.getElements(driver,FIELD_VALUE_ELEMENT).get(1).getAttribute("innerText").trim();
    }

    public static String getInstalledDate(WebDriver driver)
    {
        return CommonUtil.getElements(driver,FIELD_VALUE_ELEMENT).get(2).getAttribute("innerText").trim();
    }

    public static String getEmail(WebDriver driver)
    {
        return CommonUtil.getElements(driver,FIELD_VALUE_ELEMENT).get(3).getAttribute("innerText").trim();
    }

    public static String getWebsite(WebDriver driver)
    {
        return CommonUtil.getElements(driver,FIELD_VALUE_ELEMENT).get(4).getAttribute("innerText").trim();
    }
}
