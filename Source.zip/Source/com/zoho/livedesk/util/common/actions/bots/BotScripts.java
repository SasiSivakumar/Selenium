//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class BotScripts
{
    //works for pattern--><code-desc>_<handler>.<extension> e.g. botcode_mh.txt

    public static final String
    FILE_EXTENSION="txt",
    MESSAGE_HANDLER="mh",
    TRIGGER_HANDLER="th",
    CONTEXT_HANDLER="ch",
    TEMPLATE="template",
    TEXTAREA_URL="/bot_scripts/textarea.html"
    ;

    //file_names
    public static final String
    BOT_REPLY_CODE="basic_bot_reply",
    BASIC_ALL_HANDLERS_CODE="basic_all_handler_check",
    WIDGETS_CODE="widgets",
    MESSAGE_DUPLICATOR="message_duplicator",
    CRM_CODE="crm",
    GOOGLE_CALENDAR_CODE="googlecalendar"
    ;

    public static final String
    BOT_REPLY_MESSAGE="<bot_reply>",
    CONNECTION="<connection>",
    CONNECTION2="<connection2>",
    SETUP="<setup>",
    ARTICLEID1="<articleid_1>",
    ARTICLEID2="<articleid_2>",
    ARTICLEID3="<articleid_3>",
    FORWARD_TO_AGENT="<forward_to_agent>",
    FORWARD_TO_DEPT="<forward_to_dept>"
    ;

    public static final String BOT_SCRIPTS_PATH="/webapps/selenium/bot_scripts/";

    public static String getFileName(String code_description,String code_type)
    {
        return code_description+"_"+code_type+"."+FILE_EXTENSION;
    }

    public static String getBotFilesPath()
    {
        return FileUpload.getBuildRoot()+BOT_SCRIPTS_PATH;
    }

    public static String getBotCode(String code_description,String code_type) throws IOException
    {
        return FileUpload.getFileAsString(getBotFilesPath()+getFileName(code_description,code_type));
    }

    public static String getBotReplyCode(String reply_message) throws IOException
    {
        String code=getBotCode(BOT_REPLY_CODE,MESSAGE_HANDLER);
        return code.replace(BOT_REPLY_MESSAGE,reply_message);
    }

    public static String getBotWidgetsCode(String reply_message) throws IOException
    {
        String code=getBotCode(WIDGETS_CODE,MESSAGE_HANDLER);
        return code.replace(BOT_REPLY_MESSAGE,reply_message);      
    }

    public static String getBotMessageDuplicatorCode() throws IOException
    {
        String code=getBotCode(MESSAGE_DUPLICATOR,MESSAGE_HANDLER);
        return code;      
    }

    public static String getCRMCode(String connection_name,String connection_name2) throws IOException
    {
        String code=getBotCode(CRM_CODE,MESSAGE_HANDLER);
        code=code.replace(CONNECTION,connection_name);
        code=code.replace(CONNECTION2,connection_name2);
        String setup="localzoho";
        if(Util.isLocalBuild()==false)
        {
            setup="zoho";
        }
        code=code.replace(SETUP,setup);
        return code;
    }

    public static String getGoogleCalendar(String connection_name) throws IOException
    {
        String code=getBotCode(GOOGLE_CALENDAR_CODE,MESSAGE_HANDLER);
        code=code.replace(CONNECTION,connection_name);
        return code;
    }

    public static void copyCodeToClipboard(WebDriver driver,ExtentTest etest,String code_description,String code_type)
    {
        try
        {
            String url=getCodeURL(code_description,code_type);
            ExecuteStatements.openNewTab(driver,url);
            CommonUtil.copyAllToClipboard(driver,etest);
            CommonUtil.closeCurrentTab(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,e);
            CommonUtil.switchToTab(driver,0);
            throw new ZohoSalesIQRuntimeException("Unable to copy code to clipboard");
        }

        CommonUtil.switchToTab(driver,0);
    }

    public static String getCodeURL(String code_description,String code_type)
    {
        String root="http://"+Util.serverHostName+":"+Util.serverPortNumber;
        return root+"/bot_scripts/"+code_description+"_"+MESSAGE_HANDLER+".txt";
    }

    public static void copyToClipboard(WebDriver driver,ExtentTest etest,String code)
    {
        for(int i=0;i<=3;i++)
        {
            try
            {
                copyToClipboardAction(driver,etest,code);
                break;
            }
            catch(Exception e)
            {
                if(i==3)
                {
                    throw e;
                }
            }
        }
    }

    public static void copyToClipboardAction(WebDriver driver,ExtentTest etest,String code)
    {
        String url="http://"+Util.serverHostName+":"+Util.serverPortNumber+TEXTAREA_URL;

        try
        {

            ExecuteStatements.openNewTab(driver,url);
            CommonUtil.getElement(driver,By.id("txt")).click();

            CommonUtil.sendKeysByChar(driver,  CommonUtil.getElement(driver,By.id("txt")), code);
            // CommonUtil.getElement(driver,By.id("txt")).sendKeys(code);
            // CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("txt")),code);

            CommonUtil.copyToClipboardFromTextarea(driver,etest);
            CommonUtil.closeCurrentTab(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,e);
            CommonUtil.switchToTab(driver,0);
            throw new ZohoSalesIQRuntimeException("Unable to copy code to clipboard");
        }

        CommonUtil.switchToTab(driver,0);        
    }
}
