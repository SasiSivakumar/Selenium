//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class WebEmbed
{
    public static void addWebEmbed(WebDriver driver, String embedname)throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        Tab.navToEmbedTab(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonembedadd")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("buttonembedadd")));

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","buttonembedadd"),"tagname","span").click();

        WebElement ok = PopUp.getOkBtn(driver);
        
        WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        CommonUtil.elementfinder(driver,popup,"id","pop-femail").sendKeys(embedname+".com");

        ok.click();
        
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(popup)));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedconfigform")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedconfigform")));
    }

    public static void deleteEmbed(WebDriver driver, String embedname)throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        Tab.navToEmbedTab(driver);

        WebElement e = WebEmbed.getWebEmbed(driver,embedname);

        CommonUtil.mouseHover(driver,e);

        WebElement delete = CommonUtil.elementfinder(driver,e,"classname","list_lefticon");

        wait.until(ExpectedConditions.visibilityOf(delete));

        delete.click();

        WebElement ok = PopUp.getOkBtn(driver);

        ok.click();

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(popup.getAttribute("innerHTML").contains("list_lefticon"))
                {
                    return false;
                }
                return true;
            }
        });
    }
    
    public static List<WebElement> getWebsitesList(WebDriver driver) throws Exception
    {
        Tab.navToEmbedTab(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedlist")));
        
        WebElement div = CommonUtil.elfinder(driver,"id","embedlist");
        
        List<WebElement> list = div.findElements(By.className("list-row"));
        
        return list;
    }

    public static WebElement getWebEmbed(WebDriver driver,String embed, ExtentTest etest) throws Exception
    {
        Tab.navToEmbedTab(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));    
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedlist")));

        WebElement div = CommonUtil.elfinder(driver,"id","embedlist");

        List<WebElement> list = div.findElements(By.className("list-row"));
        for(WebElement e: list)
        {
            WebElement name = CommonUtil.elementfinder(driver, e, "classname", "txtelips");
            if(name.getText().equals(embed))
            {
                try
                {
                    CommonUtil.scrollIntoView(driver,false,e);
                    ((JavascriptExecutor) driver).executeScript("javascript:window.scrollBy(0,50)");
                }
                catch(Exception excep)
                {
                    CommonUtil.doNothing();
                }
                etest.log(Status.INFO,"Embed - "+embed+" is present");
                return e;
            }
        }
        etest.log(Status.INFO,"Embed - "+embed+" is not present");
        return null;
    }

    public static void clickWebEmbed(WebDriver driver,String embed,ExtentTest etest) throws Exception
    {
        getWebEmbed(driver,embed,etest).click();

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedconfigform")));    
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedconfigform")));

        etest.log(Status.INFO,"Embed - "+embed+" is clicked");
    }

    public static WebElement getWebEmbed(WebDriver driver,String embed) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));    
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedlist")));

        WebElement div = CommonUtil.elfinder(driver,"id","embedlist");

        List<WebElement> list = div.findElements(By.className("list-row"));
        for(WebElement e: list)
        {
            CommonUtil.inViewPort(e);
            WebElement name = CommonUtil.elementfinder(driver, e, "classname", "txtelips");
            if(name.getText().equals(embed))
            {
                return e;
            }
        }

        return null;
    }

    public static void clickWebEmbed(WebDriver driver,String embed) throws Exception
    {
        getWebEmbed(driver,embed).click();
    }
}
