//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class MissedChat
{
    public static boolean checkFirstVisitorInMissedList(WebDriver driver, String vname, String vemail, String vques, String agentName, ExtentTest etest) throws Exception
    {
        Tab.clickMissed(driver);
        
        WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","missed_mcontent"),"id","historylist").findElements(By.className("cursr-point")).get(0);
        
        String s1 = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","secnd-clm"),"tagname","h2").getText();
        String s2 = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","secnd-clm"),"tagname","div").getText();
        String s3 = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","thrd-clm"),"tagname","pre").getText();
        String s4 = CommonUtil.elementfinder(driver,div,"classname","four-clm").getAttribute("innerHTML");
        
        String expected[] = {vname,vemail,vques,agentName};
        String actual[] = {s1,s2,s3,s4};
        
        int fail = 0;
        
        for(int i = 0 ; i<expected.length;i++)
        {
            if(!actual[i].contains(expected[i]))
            {
                etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual"+actual[i]+"--");
                fail++;
            }
        }
        
        if(fail != 0)
        {
            return false;
        }
        
        return true;
    }
}
