//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;

public class BusinessHours
{

    /*Constants*/

    public static final By
    HOUR_GRID=By.className("lvdbs_ma"),
    SELECTION_CONTAINER=By.className("bhovrdiv"),
    SAVE_BUTTON=By.cssSelector("[onclick*=updateData]"),
    CANCEL_BUTTON=By.cssSelector("[onclick*='BH.hideActionUI']"),
    BUSINESS_HOURS_TABLE_CONTAINER=By.id("bhcontainer")
    ;
   
    /*Methods*/


    //day--> 1=sunday 7=saturday , time-->0.23 hrs
    public static WebElement getBusinessHourGrid(WebDriver driver,int day,int hour)
    {
        if(day<1 || day>7 || hour <0 || hour >23)
        {
            throw new ZohoSalesIQRuntimeException("Invalid day/hour value day:"+day+" hour:"+hour);
        }

        WebElement day_container=CommonUtil.getElement(driver,By.cssSelector("[mode='"+day+"']"));
        WebElement hour_container=CommonUtil.getElements(day_container,HOUR_GRID).get(hour);
        return hour_container;
    }

    public static void setBusinessHour(WebDriver driver,ExtentTest etest,int day,int hour)
    {
        int no_of_hour_containers_selected_before_click=driver.findElements(SELECTION_CONTAINER).size();
        WebElement grid=getBusinessHourGrid(driver,day,hour);
        CommonUtil.scrollToBottomOfPage(driver);
        CommonUtil.getElement(driver,BUSINESS_HOURS_TABLE_CONTAINER).click();
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonUtil.doubleClick(driver,grid);
        waitTillSelectedAreaCountChanges(driver,no_of_hour_containers_selected_before_click,true);
        etest.log(Status.INFO,"Business hours was set as day : "+day+" hour : "+hour);
    }

    public static boolean waitTillSelectedAreaCountChanges(WebDriver driver,int current_selectors,boolean isIncreased)
    {
        return CommonWait.waitTillElementsCountChange(driver,SELECTION_CONTAINER,current_selectors,isIncreased);
    }

    public static void setCurrentTimeAsBusinessHour(WebDriver driver,ExtentTest etest) throws Exception
    {
        Long time=System.currentTimeMillis();

        int day=getDay(time);
        int hour=getHour(time);

        clearAllBusinessHourConfiguration(driver);
        saveBusinessHourSettingsIfSaveButtonFound(driver,true);

        setBusinessHour(driver,etest,day,hour);
        setBusinessHour(driver,etest,day,(hour==23)?0:hour+1);//just in case
    }

    public static void setPastTimeAsBusinessHour(WebDriver driver,ExtentTest etest) throws Exception
    {
        Long time=System.currentTimeMillis();

        int day=getDay(time);
        int hour=getHour(time);

        clearAllBusinessHourConfiguration(driver);
        saveBusinessHourSettingsIfSaveButtonFound(driver,true);

        setBusinessHour(driver,etest,day,(hour==0)?23:hour-1);
    }

    public static int getDay(Long time_in_millis)
    {
        Calendar time = Calendar.getInstance();
        time.setTimeInMillis(time_in_millis);
        return time.get(Calendar.DAY_OF_WEEK);
    }

    public static int getHour(Long time_in_millis)
    {
        Calendar time = Calendar.getInstance();
        time.setTimeInMillis(time_in_millis);
        return time.get(Calendar.HOUR_OF_DAY);
    }

    public static boolean isBusinessHoursEmpty(WebDriver driver)
    {
        return CommonUtil.getElements(driver,SELECTION_CONTAINER).size()==0;        
    }

    public static boolean clearAllBusinessHourConfiguration(WebDriver driver)
    {
        List<WebElement> selected_areas=CommonUtil.getElements(driver,SELECTION_CONTAINER);

        int selectors_count_before_delete;

        for(WebElement selected_area : selected_areas)
        {
            selectors_count_before_delete=driver.findElements(SELECTION_CONTAINER).size();
            CommonUtil.inViewPort(selected_area);
            selected_area.click();
            new Actions(driver).sendKeys(selected_area,Keys.DELETE).perform();
            waitTillSelectedAreaCountChanges(driver,selectors_count_before_delete,false);
        }

        return (driver.findElements(SELECTION_CONTAINER).size()==0);
    }

    public static boolean cancelSave(WebDriver driver)
    {
        WebElement cancel_button=CommonUtil.getElement(driver,CANCEL_BUTTON);
        CommonUtil.inViewPort(cancel_button);
        cancel_button.click();
        return CommonWait.waitTillHidden(cancel_button);
    }

    public static void saveBusinessHourSettingsIfSaveButtonFound(WebDriver driver,boolean isPopup)
    {
        if(CommonWait.isDisplayed(driver,SAVE_BUTTON))
        {
            saveBusinessHourSettings(driver,isPopup);
        }
    }

    public static boolean saveBusinessHourSettings(WebDriver driver)
    {
        return saveBusinessHourSettings(driver,false);
    }

    public static boolean saveBusinessHourSettings(WebDriver driver,Boolean isPopup)
    {
        WebElement save_button=CommonUtil.getElement(driver,SAVE_BUTTON);
        CommonUtil.inViewPort(save_button);
        save_button.click();

        if(isPopup==null)
        {
            return true;
        }

        if(isPopup)
        {
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"standard work hours");
            CommonWait.waitTillDisplayed(popup);
            HandleCommonUI.clickPositivePopupButton(popup);
            return CommonWait.waitTillHidden(popup);
        }
        else
        {
            return CommonWait.waitTillHidden(save_button);
        }
    }
}
