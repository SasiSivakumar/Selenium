//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.VisitorDriverManager;

public class AppsComponent {

	 public static Hashtable < String, Boolean > result = new Hashtable();
	 public static ExtentTest etest;
	 public static Hashtable values = new Hashtable();
	 public static Hashtable etests = new Hashtable();
	 public static VisitorDriverManager visitor_driver_manager;
	 
	 static String label = CommonUtil.getUniqueMessage();
	 static String appName = "AppName_new";
	 static String appDescription = "AppDescription_" + CommonUtil.getUniqueMessage() + "_new";
	 static String vques = "Ques_" + label;
	 static String vphone = label;
	 static String vemail = "V" + label + "@email.com";
	 static String vname = "Name_" + label;

	 /*Constants*/
	 public static final By
	 GO_TO_APPS = By.id("menu_apps");
	

	 public static void gotoApps(WebDriver driver,ExtentTest etest) {
	  CommonWait.waitTillDisplayed(driver, GO_TO_APPS);
	  CommonUtil.click(driver, GO_TO_APPS);
	  etest.log(Status.INFO, "Navigated to Apps page.");
	  TakeScreenshot.infoScreenshot(driver, etest);
	  CommonUtil.switchToTab(driver, 1);
	  etest.log(Status.INFO, "Tab Switched to Apps page of SalesIQ portal");
	 }

	 
	 public static boolean checkisInComponentsPage(WebDriver driver, ExtentTest etest) {
		  try {	   
			  CommonUtil.switchToTab(driver, 1);
			 return CommonWait.isPresent(driver, By.cssSelector("[class*='app-compnt']"));			  
		  } catch (Exception e) {
		   etest.log(Status.FAIL, "Page is not in Components apge");
		   TakeScreenshot.screenshot(driver, etest, "Apps Components", "Components Page", "Not in Component Page", e);
		  }
		return false;
		 }

	 public static boolean clickComponents(WebDriver driver, ExtentTest etest) {
	  try {	  
	   CommonUtil.switchToTab(driver, 1);
	   CommonWait.isPresent(driver, By.cssSelector("[class*='fsiq-component']"));
	   if(CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='fsiq-component']"))) {
		   CommonUtil.clickWebElement(driver, By.cssSelector("[class*='fsiq-component']"));
		   etest.log(Status.PASS, "Components section found and cliked");
		   TakeScreenshot.infoScreenshot(driver, etest);   
	   }
	   else
	   {
		   etest.log(Status.FAIL, "Components - Couldn't click / not Found");
		   TakeScreenshot.infoScreenshot(driver, etest); 
		   return false;
	   }
	  
	  } catch (Exception e) {
	   etest.log(Status.FAIL, "Component may not be present");
	   TakeScreenshot.screenshot(driver, etest, "Apps Components", "Components section", "Component section details missing", e);
	  }
	return false;

	 }

	 public static boolean closeComponentsPage(WebDriver driver, ExtentTest etest) {
		  try {	
			  if(CommonWait.isPresent(driver, By.cssSelector("[class*='fsiq-close']"))){
				  CommonUtil.clickWebElement(driver, By.cssSelector("[class*='fsiq-close']"));
				  etest.log(Status.INFO, "Components Page Closed");
				  return true;
			  }		  
		  }
	       catch (Exception e) {
		   etest.log(Status.FAIL, "Component page is not closed");
		   TakeScreenshot.screenshot(driver, etest, "Apps Components", "Components section", "Component section details missing", e);
		  }
		return false;
		 }

 
	 public static boolean checkisInSettingsPage(WebDriver driver, ExtentTest etest) {
		  try {	   
			  CommonUtil.switchToTab(driver, 1);
			 return CommonWait.isPresent(driver, By.id("tabs"));			  
		  } catch (Exception e) {
		   etest.log(Status.FAIL, " Page is not in Settings apge");
		   TakeScreenshot.screenshot(driver, etest, "Apps Settings", "Settings Page", "Not in Settings Page", e);
		  }
		return false;
		 }
		 
}
