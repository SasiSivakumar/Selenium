//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;
import com.zoho.livedesk.client.bots.BotsWidgets;
import com.zoho.livedesk.client.SalesIQRestAPI.APIKeys;

public class ChatMonitor
{
    public static final By
    ADD=By.cssSelector("[href*='chatmonitor/add']"),
    ADD2=By.cssSelector("[documentclick='addChatMonitor']"),
    OPERATOR_DROPDOWN=By.id("cmsupportrepinput_ddown"),
    DISABLED_RULE=By.className("list_disable"),
    MONITOR_TYPE_ICON=By.className("cmn_dsplyinblk"),
    MONITOR_BY_OPERATOR=By.cssSelector(".cmn_dsplyinblk[title='Operator']"),
    MONITOR_BY_IP=By.cssSelector(".cmn_dsplyinblk[title='IP Address']"),
    MONITOR_BY_VISITOR_EMAIL=By.cssSelector(".cmn_dsplyinblk[title='Visitor Email Address']"),
    CHAT_MONITOR_VALUE=By.className("list_fchild"),
    CHAT_MONITOR_CONTAINER=By.className("list-row")
    ;
    
    public static final String
    ENABLED="ENABLED",
    TYPE="TYPE",
    VALUE="VALUE",
    OPERATOR="Operator",
    OPERATOR_ID="OPERATOR_ID",
    IP="IP Address",
    VISITOR_EMAIL="Visitor Email Address",
    VISITOR_EMAIL_KEY="visitor_email",
    OPERATOR_KEY="operator",
    VISITOR_IP_KEY="visitor_ip"
    ;

    public static boolean isOperatorFoundInChatMonitor(WebDriver driver,ExtentTest etest,String operator,boolean isPresent) throws Exception
    {
        Tab.navToCMTab(driver);
        clickAddChatMonitor(driver,etest);

        if(CommonWait.isPresent(driver,OPERATOR_DROPDOWN,By.cssSelector("[title='"+operator+"']"))==isPresent)
        {
            etest.log(Status.PASS,"Operator '"+operator+"' was "+(isPresent?"found":"NOT found")+" in the chat monitor operators list");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Operator '"+operator+"' was "+(isPresent?"NOT found":"found")+" in the chat monitor operators list");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static boolean clickAddChatMonitor(WebDriver driver,ExtentTest etest)
    {
        WebElement add=null;

        if(CommonWait.isDisplayed(driver,ADD))
        {
            add=CommonUtil.getElement(driver,ADD);
        }
        else if(CommonWait.isDisplayed(driver,ADD2))
        {
            add=CommonUtil.getElement(driver,ADD2);
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Add chat monitor button not found");
        }

        CommonUtil.mouseHoverAndClick(driver,add);
        etest.log(Status.INFO,"Add chat monitor button was clicked.");
        return CommonWait.waitTillHidden(add);
    }

    public static Hashtable<String,String> getInfo(WebDriver driver,String rule_id) throws Exception
    {
        Tab.navToCMTab(driver);

        WebElement chat_monitor_container=CommonUtil.getElement(driver,By.id(rule_id));

        if(chat_monitor_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Chat monitor with id "+rule_id+" was not found");
        }

        CommonUtil.scrollIntoView(driver,chat_monitor_container);

        Hashtable<String,String> rule_info=new Hashtable<String,String>();

        rule_info.put(ENABLED,"" + !CommonUtil.hasClass(chat_monitor_container,DISABLED_RULE));

        String monitor_tooltip=CommonUtil.getElement(chat_monitor_container,MONITOR_TYPE_ICON).getAttribute("title");

        String monitor_type=null;

        if(monitor_tooltip.equals(OPERATOR))
        {
            monitor_type=APIKeys.OPERATOR;
        }
        else if(monitor_tooltip.equals(IP))
        {
            monitor_type=APIKeys.VISITOR_IP;
        }
        else if(monitor_tooltip.equals(VISITOR_EMAIL))
        {
            monitor_type=APIKeys.VISITOR_EMAIL;
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid/Unconfigured Chat Monitor Type : "+monitor_tooltip);
        }

        String chat_monitor_value=CommonUtil.getElement(chat_monitor_container,CHAT_MONITOR_VALUE).getAttribute("innerText").trim();

        if(monitor_type.equals(APIKeys.OPERATOR))
        {
            chat_monitor_value=ExecuteStatements.getOperatorIDByAgentName(driver,chat_monitor_value);
        }

        rule_info.put(TYPE,monitor_type);
        rule_info.put(VALUE,chat_monitor_value);

        return rule_info;
    }

    public static boolean isChatMonitorFound(WebDriver driver,String id) throws Exception
    {
        Tab.navToCMTab(driver);
        return CommonWait.isPresent(driver,By.cssSelector("[id='"+id+"']"));
    }

    public static Hashtable<String,Integer> getCount(WebDriver driver) throws Exception
    {
        Tab.navToCMTab(driver);

        Hashtable<String,Integer> count_info=new Hashtable<String,Integer>();
        count_info.put(VISITOR_EMAIL_KEY, CommonUtil.getElements(driver,MONITOR_BY_VISITOR_EMAIL).size() );
        count_info.put(OPERATOR_KEY, CommonUtil.getElements(driver,MONITOR_BY_OPERATOR).size() );
        count_info.put(VISITOR_IP_KEY, CommonUtil.getElements(driver,MONITOR_BY_IP).size() );

        return count_info;
    }

    public static String getRuleIDOfFirstChatMonitor(WebDriver driver) throws Exception
    {
        Tab.navToCMTab(driver);
        return CommonUtil.getElement(driver,CHAT_MONITOR_CONTAINER).getAttribute("id");
    }

}
