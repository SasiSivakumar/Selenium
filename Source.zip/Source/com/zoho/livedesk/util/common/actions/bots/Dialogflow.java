//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class Dialogflow
{
    public static final By
    DIALOGFLOW_ICON=By.cssSelector("a[href='/api-client']"),
    GOOGLE_SIGNIN_BUTTON=By.cssSelector("a[href*='/authorize_url_google/']"),
    CREATE_AGENT_BUTTON=By.id("multi-button"),
    AGENT_NAME_INPUT=By.id("entity-name"),
    GOOGLE_PROJECT_DROPDOWN_CONTAINER=By.cssSelector("[ng-model*='cloudProjectId']"),
    GOOGLE_PROJECT_DROPDOWN=By.className("md-select-value"),
    GOOGLE_PROJECT_DROPDOWN_VALUES=By.cssSelector("[role='option'][ng-value='key']"),
    SEARCH_INTENT_INPUT=By.id("input-search-intents"),
    SEARCH_AGENT_INPUT=By.cssSelector("[ng-model='agentsFilter']"),
    SEARCH_AGENT_RESULTS=By.cssSelector("[ng-repeat*='filteredAgents']"),
    DELETE_AGENT_BUTTON=By.cssSelector("[ng-click='deleteAgent()']"),
    CONFIRM_DELETE_INPUT=By.id("confirm-user-input"),
    CONFIRM_DELETE_BUTTON=By.id("confirm-button-ok")
    ;

    public static final String
    CREATE_AGENT_URL="https://console.dialogflow.com/api-client/#/newAgent",
    AGENTS_LIST_URL="https://console.dialogflow.com/api-client/#/agents";

    public static boolean waitTillDialogflowPageLoads(WebDriver driver)
    {
        return CommonWait.waitTillDisplayed(driver,DIALOGFLOW_ICON);
    }

    public static void signIn(WebDriver driver,ExtentTest etest)
    {
    	signIn(driver,etest,ConfManager.getRealValue("bots_gmail_username"),ConfManager.getRealValue("bots_gmail_password"));
    }

    public static void signIn(WebDriver driver,ExtentTest etest,String email,String password)
    {
        waitTillDialogflowPageLoads(driver);

        if(CommonWait.isPresent(driver,GOOGLE_SIGNIN_BUTTON))
        {
            CommonWait.waitTillDisplayed(driver,GOOGLE_SIGNIN_BUTTON);
            WebElement signin_button=CommonUtil.getElement(driver,GOOGLE_SIGNIN_BUTTON);
            CommonUtil.clickWebElement(driver,signin_button);
            CommonWait.waitTillHidden(signin_button);
            GmailUtil.enterCredentialsInGoogleLoginPage(driver,etest,email,password);
            waitTillDialogflowPageLoads(driver);
            etest.log(Status.INFO,"Dialogflow gmail account was logged in successfully.");
        }
        else
        {
            etest.log(Status.INFO,"Dialogflow gmail account was already logged in.");
        }
    }

    public static void createAgent(WebDriver driver,ExtentTest etest,String agent_name)
    {
    	driver.get(CREATE_AGENT_URL);

    	CommonWait.waitTillDisplayed(driver,CREATE_AGENT_BUTTON);

    	WebElement name_input=CommonUtil.getElement(driver,AGENT_NAME_INPUT);
    	CommonUtil.sendKeysToWebElement(driver,name_input,agent_name);

        if(CommonWait.isPresent(driver,GOOGLE_PROJECT_DROPDOWN_CONTAINER,GOOGLE_PROJECT_DROPDOWN))
        {
            WebElement dropdown=CommonUtil.getElement(driver,GOOGLE_PROJECT_DROPDOWN_CONTAINER,GOOGLE_PROJECT_DROPDOWN);
            CommonWait.waitTillDisplayed(dropdown);
            CommonUtil.clickWebElement(driver,dropdown);


            //select the first value
            if(CommonWait.isPresent(driver,GOOGLE_PROJECT_DROPDOWN_VALUES))
            {
                CommonWait.waitTillDisplayed(driver,GOOGLE_PROJECT_DROPDOWN_VALUES);
                WebElement dropdown_value=CommonUtil.getElement(driver,GOOGLE_PROJECT_DROPDOWN_VALUES);
                CommonUtil.clickWebElement(driver,dropdown_value);
                CommonWait.waitTillHidden(dropdown_value);
            }
        }

    	TakeScreenshot.infoScreenshot(driver,etest);

    	WebElement create_button=CommonUtil.getElement(driver,CREATE_AGENT_BUTTON);
    	CommonUtil.clickWebElement(driver,create_button);
    	CommonWait.waitTillDisplayed(driver,SEARCH_INTENT_INPUT);

    	etest.log(Status.INFO,"Dialogflow agent '"+agent_name+"' was created in dialogflow console");
    	TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void deleteAgent(WebDriver driver,ExtentTest etest,String agent_name)
    {
    	driver.get(AGENTS_LIST_URL);

        CommonWait.waitTillDisplayed(driver,SEARCH_AGENT_INPUT);
        WebElement input=CommonUtil.getElement(driver,SEARCH_AGENT_INPUT);
        CommonUtil.sendKeysToWebElement(driver,input,agent_name);
        CommonWait.waitTillDisplayed(driver,SEARCH_AGENT_RESULTS);
        CommonUtil.click(driver,SEARCH_AGENT_RESULTS,By.tagName("a"));

        CommonWait.waitTillPresent(driver,DELETE_AGENT_BUTTON);
        WebElement delete_button=CommonUtil.getElement(driver,DELETE_AGENT_BUTTON);
        CommonUtil.scrollIntoView(driver,delete_button);
        CommonUtil.clickWebElement(driver,delete_button);
        CommonWait.waitTillDisplayed(driver,CONFIRM_DELETE_INPUT);

        WebElement confirm_delete=CommonUtil.getElement(driver,CONFIRM_DELETE_INPUT);
        CommonUtil.sendKeysToWebElement(driver,confirm_delete,"DELETE");
        CommonUtil.sleep(100);
        WebElement confirm_delete_button=CommonUtil.getElement(driver,CONFIRM_DELETE_BUTTON);
        CommonUtil.click(driver,confirm_delete_button);

        CommonWait.waitTillHidden(driver,DELETE_AGENT_BUTTON);

        etest.log(Status.INFO,"Dialogflow agent '"+agent_name+"' was deleted in dialogflow console.");
    }
}
