//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class AppsCommonElements
{
    /*Objects*/

    /*Constants*/
    public static final By
    CLOSE1=By.cssSelector("[navigationclick*='navigateClose']"),
    CLOSE2=By.cssSelector("[onclick*='window.history.back()']"),
    CLOSE3=By.cssSelector(".fsiq-close[onclick*='Nurl.setState']"),
    SELECTED=By.className("sel"),
    SAVE_BANNER=By.id("saveBanner"),
    SAVE_BUTTON=By.cssSelector("[documentclick='handleSettingSaveConfig']"),
    DONT_SAVE_BUTTON=By.cssSelector("[documentclick='handleSettingDontSaveConfig']")
    ;

    /*Methods*/
    public static boolean clickClose(WebDriver driver)
    {
        WebElement button=null;

        if(CommonWait.isPresent(driver,CLOSE3))
        {
            button=CommonUtil.getElement(driver,CLOSE3);
        }
        else if(CommonWait.isPresent(driver,CLOSE1))
        {
            button=CommonUtil.getElement(driver,CLOSE1);
        }
        else if(CommonWait.isPresent(driver,CLOSE2))
        {
            button=CommonUtil.getElement(driver,CLOSE2);
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Close button was not found");
        }

        CommonWait.waitTillDisplayed(button);
        CommonUtil.clickWebElement(driver,button);
        return CommonWait.waitTillHidden(button);
    }

    public static boolean isElementSelected(WebElement element)
    {
        return CommonUtil.hasClass(element,SELECTED);
    }

    public static boolean handleSaveBanner(WebDriver driver,ExtentTest etest,boolean isSave)
    {
        // CommonUtil.sleep(3000);//changes are not saved if clicked immediately
        CommonWait.waitTillDisplayed(driver,SAVE_BANNER);
        WebElement button=CommonUtil.getElement(driver,SAVE_BANNER, (isSave?SAVE_BUTTON:DONT_SAVE_BUTTON) );
        CommonWait.waitTillDisplayed(button);
        button.click();
        boolean isSuccess=CommonWait.waitTillHidden(button);
        etest.log(Status.INFO,"Changes were "+(isSave?"saved":"not saved"));
        return isSuccess;
    }

    public static void setInput(WebDriver driver,WebElement input,String content)
    {
        CommonUtil.inViewPort(input);
        CommonUtil.clickWebElement(driver,input);
        CommonUtil.sendKeysLikeHuman(input,content);
    }

    public static void setCheckbox(WebDriver driver,ExtentTest etest,WebElement checkbox,boolean isCheck)
    {
        setCheckbox(driver,etest,checkbox,isCheck,true);
    }

    public static void setCheckbox(WebDriver driver,ExtentTest etest,WebElement checkbox,boolean isCheck,Boolean isSave)
    {
        if(HandleCommonUI.isCheckboxChecked(checkbox)==isCheck)
        {
            return;
        }

        WebElement parent=CommonUtil.getParent(driver,checkbox);
        CommonUtil.inViewPort(parent);
        CommonUtil.clickWebElement(driver,parent);
        HandleCommonUI.waitTillCheckboxStateChange(checkbox,isCheck);

        if(isSave!=null)
        {
            handleSaveBanner(driver,etest,isSave);
        }
    }
}
