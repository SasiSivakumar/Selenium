//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;

public class ChatHistory
{

    /*Constants*/
    public static final String
    YET_TO_ASSIGN="Yet to Assign",
    ME="Me",
    XLSX="xlsx",
    CSV="csv"
    ;

    public static final By
    CHAT_HISTORY_CONTAINER=By.id("history_div"),
    REPLY_BUTTON=By.id("rplybtn"),
    MAIL_CONTAINER=By.id("replycontainer"),
    CHAT_HISTORY_TAB=By.id("suppm_history"),
    CHAT_HISTORY_TABLE_CONTAINER=By.id("historylist"),
    SHOW_ONLY_MY_CHATS=By.id("hismysupport")
    ;

    public static final By
    CHECKBOX_COLUMN=By.className("fst-clm"),
    NAME_COLUMN=By.className("secnd-clm"),
    QUESTION_AND_TIME_COLUMN=By.className("thrd-clm"),
    OWNER_COLUMN=By.className("four-clm"),
    CHECKBOX=By.cssSelector("[conf=bchbox]"),
    VISITOR_NAME=By.tagName("h2"),
    VISITOR_MAIL=By.cssSelector("[href*=mailto]"),
    CHAT_ID=By.className("lvst_idtxt"),
    VISITOR_QUESTION=By.className("grayee"),
    TIMESTAMP=By.className("time-stamp")
    ;

    public static final By
    CHAT_HISTORY_LOADING_DIV=By.id("nav"),
    DELETE_BUTTON=By.id("delete"),
    SELECT_ALL_BUTTON=By.id("blcksel"),
    EXPORT_DROPDOWN_BUTTON=By.id("expdrpdown"),
    EXPORT_POPUP_CONTAINER=By.id("dlgbox"),
    EXPORT_PASSWORD=By.id("inputpwd"),
    EXPORT_AUTHENTICATE_BUTTON=By.cssSelector("[tabindex='6']")
    ;

    public static final String
    VISITOR="visitor_name",
    MAIL="visitor_mail",
    QUESTION="visitor_question",
    ISCHECKED="is_checked",
    CH_ID="CHATID",
    STATUS="visitor_status",
    CHAT_TIME="visitor_chat_time",
    CHAT_DURATION="chat_duration",
    VISITOR_PHONE="visitor_phone",
    WEBSITE="website",
    FIRST_NAME="firstname",
    SECOND_NAME="secondname",
    DEPARTMENT="dept",
    OWNER="owner",
    EMBED="embed",
    CRM_TYPE="crm_type"
    ;

    public static final String
    NO_VISITORS_DESC = "No visitors found Track your visitors here. Visitors can access your websites where you have embedded the Chat code. They can connect with your operators after submitting the necessary details.",
    USERNAME = "usrname",
    HELP_TIP = "tooltip",
    CLEAR = "clear",
    ATTENDED_ONLINE = "Attended Online",
    DATEPICKER_NOT_IN_MONTH = "datepickerNotInMonth",
    NOT_AVAILABLE_IN_CRM = "Not Available in CRM",
    CRM_DEALS = "CRM Deals"
    ;
    
    public static final By
    CHAT_HISTORY_FILTER = By.id("cushistoryfilter"),
    HISTORY_DIV = By.id("history_mcontent"),
    CHAT_HISTORY_FILTER_DROPDOWN = By.className("combotitle"),
    FILTER_LIST = By.id("filterlist"),
    TOOLTIP = By.id("tooltip"),
    FILTER_CONTAINER = By.id("fdata"),
    FILTER_BY_OPERATOR = By.cssSelector("li#sagent"),
    FILTER_BY_STATUS = By.cssSelector("li#vstatus"),
    FILTER_BY_DEPT_ID = By.cssSelector("li#vdeptid"),
    FILTER_BY_EMBED = By.cssSelector("li#lsid"),
    FILTER_BY_DATE = By.cssSelector("li#timekey"),
    FILTER_BY_INTEG_STATUS = By.cssSelector("li#vintegstatus"),
    USER_IMAGE = By.id("userimage"),
    DATEPICKERDAYS = By.className("datepickerDays"),
    APPLY = By.id("lsdtpkrbtn"),
    FILTER_CLOSE_ICON = By.className("fltrclgmn"),
    FILTER_DESC = By.className("txtaln"),
    CHAT_INFO = By.id("info"),
    CHAT_INFO_HEAD = By.id("infohead"),
    CHAT_CONTACT_INFO = By.id("contactinfodiv"),
    CRM_DATA = By.id("crm_data"),
    CRM_INFO = By.className("crmld_infomn"),
    CRM_DEALS_DIV = By.id("associatedpotentialdiv")
    ;

    public static boolean isTabDisplayed(WebDriver driver)
    {
        return CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_CONTAINER,CHAT_HISTORY_TABLE_CONTAINER);
    }

    public static void clickReplyMailButton(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_CONTAINER,REPLY_BUTTON);
        CommonUtil.getElement(driver,CHAT_HISTORY_CONTAINER,REPLY_BUTTON).click();
        CommonWait.waitTillDisplayed(driver,MAIL_CONTAINER);
    }

    public static void navigateToChatHistoryTab(WebDriver driver)
    {
        //add this to Tab.java also
        CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_TAB);
        CommonUtil.getElement(driver,CHAT_HISTORY_TAB).click();
        CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_CONTAINER);
    }

    public static void clickLatestChatFromChatHistory(WebDriver driver)
    {
        navigateToChatHistoryTab(driver);
        WebElement chat=getLatestChat(driver);
        chat.click();
        CommonWait.waitTillHidden(chat);     
    }

    public static void openChatByLabel(WebDriver driver,String label)
    {
        WebElement chat=getChatContainerByUniqueKeyword(driver,label);
        chat.click();   
        CommonWait.waitTillHidden(chat);
    }

    public static WebElement getLatestChat(WebDriver driver)
    {
        return getChatsFromChatHistory(driver).get(1);
    }

    public static WebElement getChatContainerByUniqueKeyword(WebDriver driver,String keyword)//keyword can preferably be name or chat=id
    {
        navigateToChatHistoryTab(driver);
        return CommonUtil.getElementByAttributeValue(getChatsFromChatHistory(driver),"innerText",keyword);        
    }

    public static Hashtable<String,String> getChatData(WebDriver driver,String keyword)
    {
        WebElement chat=getChatContainerByUniqueKeyword(driver,keyword);
        return getChatData(chat);
    }

    public static Hashtable<String,String> getChatData(WebElement chat)
    {
        Hashtable<String,String> chat_data=new Hashtable<String,String>();

        String visitor_name,visitor_phone,visitor_mail,chatid,question,status_classname,chat_time,chat_duration,owner;
        ChatStatus status;
        String chatid_regex="#\\d+";

        visitor_name=CommonUtil.getElement(chat,NAME_COLUMN,VISITOR_NAME).getText();
        visitor_mail=CommonUtil.getElement(chat,NAME_COLUMN,VISITOR_MAIL).getText();
        chatid=CommonUtil.getElement(chat,QUESTION_AND_TIME_COLUMN,CHAT_ID).getText();
        chatid=chatid.replace("#","");

        question=CommonUtil.getElement(chat,QUESTION_AND_TIME_COLUMN,VISITOR_QUESTION).getText();
        question=question.replaceAll(chatid_regex,"");//remove chat id

        status_classname=CommonUtil.getElement(chat,QUESTION_AND_TIME_COLUMN,TIMESTAMP,By.tagName("em")).getAttribute("class");
        status=getChatStatus(status_classname);

        List<WebElement> time_info=CommonUtil.getElement(chat,QUESTION_AND_TIME_COLUMN,TIMESTAMP).findElements(By.tagName("span"));

        chat_time=time_info.get(0).getText();
        if(time_info.size() > 1)
        {
            chat_duration=time_info.get(1).getText();
        }
        else
        {
            chat_duration = "missed_chat";
        }

        if(CommonUtil.isNull(visitor_mail))
        {
            visitor_mail=null;   
        }

        String owner_text=CommonUtil.getElement(chat,OWNER_COLUMN).getText();

        if(owner_text.contains(YET_TO_ASSIGN))
        {
            owner=YET_TO_ASSIGN;
        }
        else if(owner_text.contains(ME))
        {
            owner=ME;
        }
        else
        {
            if(CommonUtil.getElement(chat,OWNER_COLUMN).getAttribute("innerHTML").length() == 0)
            {
                owner = "missed_chat";
            }
            else
            {
                owner=CommonUtil.getElement(chat,OWNER_COLUMN,By.tagName("div")).getAttribute("titletxt");
            }
        }

        chat_data.put(ISCHECKED,""+isChatSelected(chat));
        chat_data.put(VISITOR,visitor_name);
        chat_data.put(MAIL,visitor_mail);
        chat_data.put(CH_ID,chatid);
        chat_data.put(QUESTION,question);
        chat_data.put(STATUS,status.toString());
        chat_data.put(CHAT_TIME,chat_time);
        chat_data.put(CHAT_DURATION,chat_duration);
        chat_data.put(OWNER,owner);

        return chat_data;
    }

    public static Hashtable<String,String> getChatData(WebDriver driver,WebElement chat) throws Exception
    {
        Hashtable<String,String> chat_data = getChatData(chat);
        String dept,embed;

        CommonUtil.clickWebElement(driver,chat);
        Thread.sleep(1000);
        CommonWait.waitTillDisplayed(driver,CHAT_INFO);
        CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,CHAT_INFO));
        List<WebElement> dept_embed = CommonUtil.getElement(driver,CHAT_INFO_HEAD,By.tagName("table")).findElements(By.tagName("tr")).get(2).findElements(By.tagName("td"));

        if(dept_embed.get(0).getText().contains("Department"))
        {
            dept = dept_embed.get(1).getText();
            embed = dept_embed.get(3).getText();
        }
        else
        {
            dept = dept_embed.get(3).getText();
            embed = CommonUtil.getElement(driver,CHAT_INFO_HEAD,By.tagName("table")).findElements(By.tagName("tr")).get(3).findElements(By.tagName("td")).get(1).getText();
        }
        
        String crm_type = "CRM ";
        if(CommonUtil.getElement(driver,CHAT_CONTACT_INFO,CRM_DATA).getAttribute("innerHTML").length() != 0)
        {
            List<WebElement> crm_data = CommonUtil.getElement(driver,CHAT_CONTACT_INFO,CRM_DATA).findElements(CRM_INFO);
            crm_type += CommonUtil.getElementByAttributeValue(crm_data,"innerText","Type").getText().substring(4)+"s";
        }
        else
        {
            crm_type = NOT_AVAILABLE_IN_CRM;
        }
        if(CommonWait.isDisplayed(driver,CRM_DEALS_DIV))
        {
            crm_type += CRM_DEALS;
        }

        chat_data.put(DEPARTMENT,dept);
        chat_data.put(EMBED,embed);
        chat_data.put(CRM_TYPE,crm_type);
        navigateToChatHistoryTab(driver);

        return chat_data;
    }

    public static ChatStatus getChatStatus(String class_name)
    {
        ChatStatus[] chat_statuses=ChatStatus.values();

        for(ChatStatus chat_status : chat_statuses)
        {
            if(class_name.contains(chat_status.class_name))
            {
                return chat_status;
            }
        }

        return null;
    }

    public static boolean isChatSelected(WebElement chat)
    {
        return HandleCommonUI.isCheckboxChecked(chat);
    }

    public static List<WebElement> getChatsFromChatHistory(WebDriver driver)
    {
        return CommonUtil.getElement(driver,CHAT_HISTORY_CONTAINER,By.tagName("table")).findElements(By.tagName("tr"));
    }

    public static int getNoOfChats(WebDriver driver)
    {
        return (getChatsFromChatHistory(driver).size()-1);//0th element is column header, not a chat
    }

    public static String getMailInfo(WebDriver driver,String info)
    {
        String info_id=null;
        String mail_info=null;

        if(info.equals("from"))
        {
            info_id="frommaildiv";
            CommonUtil.getElement(driver,By.id(info_id)).click();
            CommonUtil.sleep(50);
        }
        else if(info.equals("cc"))
        {
            info_id="ccmail";
        }
        else if(info.equals("to"))
        {
            info_id="tomail";
        }

        WebElement element=CommonUtil.getElement(driver,By.id(info_id));

        if(info.equals("cc")==false)
        {
            return element.getText();
        }
        else
        {
            return element.getAttribute("value");
        }
    }

    public static void setShowOnlyMyChats(WebDriver driver,boolean isCheck)
    {
        WebElement checkbox=CommonUtil.getElement(driver,SHOW_ONLY_MY_CHATS);
        CommonWait.waitTillDisplayed(checkbox);
        HandleCommonUI.setCheckbox(checkbox,isCheck);     
    }

    public static boolean isShowOnlyMyChats(WebDriver driver)
    {
        WebElement checkbox=CommonUtil.getElement(driver,SHOW_ONLY_MY_CHATS);
        CommonWait.waitTillDisplayed(checkbox);
        return HandleCommonUI.isCheckboxChecked(checkbox);
    }

    public static boolean scrollToChatsLoadingDiv(WebDriver driver,ExtentTest etest)
    {
        int old_chat_count=getNoOfChats(driver);
        etest.log(Status.INFO,"No of chats before loading : "+old_chat_count);

        WebElement loading_div=CommonUtil.getElement(driver,CHAT_HISTORY_LOADING_DIV);

        ChatHistoryTests.checkLoadMoreButtonPresent(loading_div,etest);

        CommonUtil.inViewPortSafe(driver,loading_div,300);
        boolean isLoaded=waitTillChatsLoadedInChatHistoryTab(driver,old_chat_count);

        int new_chat_count=getNoOfChats(driver);
        etest.log(Status.INFO,"No of chats after loading : "+new_chat_count);

        return isLoaded;
    }

    public static boolean waitTillChatsLoadedInChatHistoryTab(final WebDriver driver,final int old_chat_count)
    {
        FluentWait wait=CommonUtil.waitreturner(driver,10,250);

        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(getNoOfChats(driver)>old_chat_count)
                    {
                        return true;
                    }
                    return false;
                }
            });
        }

        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    public static boolean selectChat(WebDriver driver,ExtentTest etest,String chat_info)
    {
        WebElement chat=getChatContainerByUniqueKeyword(driver,chat_info);
        CommonUtil.inViewPortSafe(driver,chat,10);
        WebElement checkbox=CommonUtil.getElement(driver,CHECKBOX);
        CommonUtil.mouseHover(driver,checkbox);
        CommonWait.waitTillDisplayed(checkbox);
        CommonUtil.clickWebElement(driver,checkbox);
        CommonUtil.sleep(250);

        etest.log(Status.INFO,"Chat with name '"+chat_info+"' was selected.");

        return isChatSelected(chat);
    }

    public static void selectAllChats(WebDriver driver,ExtentTest etest)
    {
        String name=CommonUtil.getElement(getLatestChat(driver),NAME_COLUMN,VISITOR_NAME).getText();
        selectChat(driver,etest,name);
        CommonWait.waitTillDisplayed(driver,SELECT_ALL_BUTTON);
        WebElement select_all_checkbox=CommonUtil.getElement(driver,SELECT_ALL_BUTTON);
        // HandleCommonUI.setCheckbox(select_all_checkbox,true);
        CommonUtil.clickWebElement(driver,select_all_checkbox);
        etest.log(Status.INFO,"All chat were selected");
    }

    public static boolean deleteChat(WebDriver driver,ExtentTest etest,String visitor_name)
    {
        selectChat(driver,etest,visitor_name);      
        deleteSelectedChats(driver,etest);

        WebElement deleted_chat=getChatContainerByUniqueKeyword(driver,visitor_name);

        return (deleted_chat==null);
    }

    public static void clickDeleteChatsButton(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,DELETE_BUTTON);
        WebElement delete=CommonUtil.getElement(driver,DELETE_BUTTON);
        CommonUtil.mouseHoverAndClick(driver,delete);        
    }

    public static void deleteSelectedChats(WebDriver driver,ExtentTest etest)
    {
        clickDeleteChatsButton(driver);

        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,Cleanup.DELETE_COMMON_TEXT);

        CommonSikuli.findInWholePage(driver,"UI343.png","UI343",etest); 

        ChatHistoryTests.checkDeleteChatPopup(popup,etest);

        HandleCommonUI.clickPositivePopupButton(popup);

        etest.log(Status.INFO,"Selected chats were deleted from chat history");
    }

    public static void scrollToChatsLoadingDivForNTimes(WebDriver driver,ExtentTest etest,int times_to_scroll)
    {
        for(int i=0;i<times_to_scroll;i++)
        {
            scrollToChatsLoadingDiv(driver,etest);
        }
    }

    public static void exportAs(WebDriver driver,String export_type)
    {
        exportAs(driver,export_type,null);
    }

    public static void exportAs(WebDriver driver,String export_type,String password)
    {
        String dropdown_text=null;

        if(export_type.equals(XLSX))
        {
            dropdown_text=ResourceManager.getRealValue("exportexcel");
        }
        else if(export_type.equals(CSV))
        {
            dropdown_text=ResourceManager.getRealValue("exportcsv");
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid export_type : "+export_type);
        }

        WebElement dropdown_button=CommonUtil.getElement(driver,EXPORT_DROPDOWN_BUTTON);
        CommonWait.waitTillDisplayed(dropdown_button);
        dropdown_button.click();
        CommonWait.waitTillDisplayed(driver,EXPORT_DROPDOWN_BUTTON,By.tagName("ul"));

        WebElement dropdown=CommonUtil.getElement(driver,EXPORT_DROPDOWN_BUTTON);
        HandleCommonUI.chooseFromDropdown(dropdown,dropdown_text,true,false);

        if(password!=null)
        {
            HandleCommonUI.authenticateFileDownloadPopup(driver,password);
        }

        CommonUtil.sleep(1000);//to wait till file downloaded
    }

    public static boolean checkHoverText(WebDriver driver,WebElement ele,ExtentTest etest) throws Exception
    {
        String username = CommonUtil.getElement(ele,USER_IMAGE).getAttribute(USERNAME);
        return HandleCommonUI.verifyTooltip(driver,etest,ele,USER_IMAGE,TOOLTIP,username);
    }

    public static boolean checkAllHoverText(WebDriver driver,ExtentTest etest) throws Exception
    {
        boolean notAChat = true;
        String status_classname;
        ChatStatus status;
        int failcount = 0;
        List<WebElement> chats = getChatsFromChatHistory(driver);
        for(WebElement chat : chats)
        {
            if(notAChat)
            {
                notAChat = false;
                continue;
            }
            status_classname=CommonUtil.getElement(chat,QUESTION_AND_TIME_COLUMN,TIMESTAMP,By.tagName("em")).getAttribute("class");
            status=getChatStatus(status_classname);
            
            if(status.toString().equals("ATTENDED_ONLINE"))
            {
                if(!checkHoverText(driver,chat,etest))
                {
                    TakeScreenshot.screenshot(driver,etest);
                    failcount++;
                }
                break;
            }
        }
        return CommonUtil.returnResult(failcount);
    }


    public static void closeFilter(WebDriver driver)
    {
        if(CommonWait.isDisplayed(driver,FILTER_CONTAINER))
        {
            CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,FILTER_CONTAINER,FILTER_CLOSE_ICON));
        }
    }

    public static WebElement getFilterBoxElement(WebDriver driver)
    {
        return CommonUtil.getElement(driver,CHAT_HISTORY_FILTER,CHAT_HISTORY_FILTER_DROPDOWN);
    }

    public static WebElement getFilter(WebDriver driver,By filterOption)
    {
        return CommonUtil.getElement(driver,FILTER_LIST,filterOption,By.tagName("select"));
    }

    public static boolean filterBy(WebDriver driver,By filter,String option,String chatData,ExtentTest etest) throws Exception
    {
        int failcount = 0;
        String filter_desc;

        WebElement dropdown = CommonUtil.getElement(driver,filter);
        filter_desc = CommonUtil.getElement(dropdown,FILTER_DESC).getText();
        CommonUtil.clickWebElement(driver,getFilter(driver,filter));
        if(!CommonWait.isDisplayed(dropdown))
        {
            navigateToChatHistoryTab(driver);
            CommonUtil.clickWebElement(driver,getFilterBoxElement(driver));
            CommonUtil.clickWebElement(driver,getFilter(driver,filter));
        }
        HandleCommonUI.chooseFromDropdown(dropdown,"select","option",option,false,false);
        CommonUtil.clickWebElement(driver,getFilterBoxElement(driver));
        if(option.equals(ATTENDED_ONLINE))
        {
            option = "ATTENDED_ONLINE";
        }
        List<WebElement> chats = getChatsFromChatHistory(driver);
        for(int i = 1; i < chats.size(); i++)
        {
            chats = getChatsFromChatHistory(driver);
            Hashtable<String,String> chat_data = getChatData(driver,chats.get(i));
            if(!CommonUtil.checkStringContainsAndLog(option,chat_data.get(chatData),filter_desc,etest))
            {
                etest.log(Status.FAIL,"For the chat id #"+chat_data.get(CH_ID));
                failcount++;
                return false;
            }
        }
        return CommonUtil.returnResult(failcount);
    }

    public static String getOption(WebDriver driver,By filter,int opt)
    {
        navigateToChatHistoryTab(driver);
        CommonUtil.clickWebElement(driver,getFilterBoxElement(driver));
        WebElement dropdown = CommonUtil.getElement(driver,filter);
        List<WebElement> options = CommonUtil.getElements(dropdown,By.tagName("option"));
        String option = CommonUtil.getElementByAttributeValue(options,"value",opt+"").getText();

        return option;
    }

    public static boolean filterByDateRange(WebDriver driver,int calendar,String findLabel,ExtentTest etest) throws Exception
    {
        WebElement lastDay = null;
        int failcount = 0,j;
        WebElement dropdown = CommonUtil.getElement(driver,FILTER_BY_DATE);
        String choose_range_opt = getOption(driver,FILTER_BY_DATE,4);
        CommonUtil.clickWebElement(driver,getFilter(driver,FILTER_BY_DATE));
        HandleCommonUI.chooseFromDropdown(dropdown,"select","option",choose_range_opt,false,false);

        List<WebElement> datePicker = CommonUtil.getElements(driver,DATEPICKERDAYS);
        List<WebElement> days = datePicker.get(calendar).findElements(By.tagName("td"));

        for(j = 7; j < days.size(); j++)
        {
            if(days.get(j).getAttribute("className").contains(DATEPICKER_NOT_IN_MONTH) && days.get(j).getText().contains("1"))
            {
                break;
            }
        }
        CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(days,"innerText","1"));
        datePicker = CommonUtil.getElements(driver,DATEPICKERDAYS);
        days = datePicker.get(calendar).findElements(By.tagName("td"));
        CommonUtil.clickWebElement(driver,days.get(j-1));
        CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,APPLY));
        CommonUtil.clickWebElement(driver,getFilterBoxElement(driver));
        etest.log(Status.INFO,"Date range was chosen as "+CommonUtil.getElement(driver,FILTER_CONTAINER).getText());

        if(calendar == 0)
        {
            if(!CommonUtil.getElement(driver,HISTORY_DIV).getText().contains(findLabel))
            {
                etest.log(Status.PASS,"Expected chat (V"+findLabel+") was not found for invalid range of date");
            }
            else
            {
                etest.log(Status.FAIL,"Expected chat (V"+findLabel+") was found for invalid range of date");
                failcount++;
            }
        }
        else if(calendar == 1)
        {
            if(CommonUtil.getElement(driver,HISTORY_DIV).getText().contains(findLabel))
            {
                etest.log(Status.PASS,"Expected chat (V"+findLabel+") was found for the given valid range of date");
            }
            else
            {
                etest.log(Status.FAIL,"Expected chat (V"+findLabel+") was not found for the given valid range of date");
                failcount++;
            }
        }
        return CommonUtil.returnResult(failcount);
    }

}
