//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;
import com.zoho.livedesk.client.bots.BotsWidgets;

public class IBMWatsonUI
{
    public static final By
    PAGE_LOAD_ELE=By.cssSelector("[href*=ibm]"),

    ASSISTANTS_PAGE = By.id("AssistantsPage"),

    LOGIN_WITH_IBM_ID=By.cssSelector("#bluemixSignInButton"),

    USER_ID=By.id("userid"),
    PASSWORD=By.id("password"),
    LOGIN=By.cssSelector("button[name='login']"),

    ASSISTANTS_TAB_HEADER=By.cssSelector("[href$='/assistants']"),
    CREATE_BUTTON=By.cssSelector(".HeaderContent__create-button"),

    ASSISTANT_NAME_INPUT=By.id("assistant_name"),
    CREATE_BUTTON2=By.cssSelector(".Panel__form--submit"),

    ADD_SKILL_BUTTON=By.cssSelector(".AssistantSkillPlaceholder__button"),
    ASSISTANT_HEADER=By.cssSelector("#SkillCard__name[title='"+BotsWidgets.BOT1+"']"),
    ASSISTANT_MORE_OPTIONS=By.cssSelector(".HeaderContent__overflow"),
    SETTINGS_DROPDOWN_VALUE=By.cssSelector("button[tabindex='-1'][index='0']"),
    DELETE_BUTTON_DROPDOWN_VALUE=By.cssSelector("button[tabindex='-1'][index='1']"),

    API_DETAILS_TAB_HEADER=By.cssSelector("#assistant-settings_show-apidetails-panel"),
    ASSISTANT_ID_VALUE=By.cssSelector("#assistant-settings-details_copy-id"),

    DELETE_INPUT=By.id("confirmationWord"),
    DELETE_SUBMIT=By.cssSelector(".AssistantDelete__submit")
    ;

    public static final String
    WATSON_URL="https://assistant-us-south.watsonplatform.net/instances"
    ;

    public static boolean waitTillPageLoads(WebDriver driver)
    {
        return CommonWait.waitTillPresent(driver,PAGE_LOAD_ELE);
    }

    //login
    public static boolean login(WebDriver driver,ExtentTest etest,String ibm_id,String password)
    {
    	waitTillPageLoads(driver);

    	CommonWait.waitTillDisplayed(driver,USER_ID);
    	WebElement id_input=CommonUtil.getElement(driver,USER_ID);
    	CommonUtil.sendKeysToWebElement(driver,id_input,ibm_id);

		CommonUtil.jsClick(driver,LOGIN);

    	CommonWait.waitTillDisplayed(driver,PASSWORD);
    	WebElement password_input=CommonUtil.getElement(driver,PASSWORD);
    	CommonUtil.sendKeysToWebElement(driver,password_input,password);

		CommonUtil.jsClick(driver,LOGIN);

		return CommonWait.waitTillHidden(password_input);
    }

    public static boolean login(WebDriver driver,ExtentTest etest)
    {
    	return login(driver,etest,ConfManager.getRealValue("ibm_username"),ConfManager.getRealValue("ibm_password"));
    }

    public static boolean goToWatsonPage(WebDriver driver)
    {
    	driver.get(WATSON_URL);

    	if(CommonWait.isPresent(driver,LOGIN_WITH_IBM_ID))
    	{
    		CommonUtil.jsClick(driver,LOGIN_WITH_IBM_ID);
    		CommonWait.waitTillHidden(driver,LOGIN_WITH_IBM_ID);
    	}

    	try
        {
            waitTillPageLoads(driver);
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }

        return CommonWait.waitTillDisplayed(driver,ASSISTANTS_PAGE); // to check if assistants page is loaded
    }

    //create new assistant and return assistant id
    public static String createAssistant(WebDriver driver,ExtentTest etest,String assistant_name)
    {
    	goToWatsonPage(driver);

    	CommonWait.waitTillPresent(driver,ASSISTANTS_TAB_HEADER);
    	CommonUtil.jsClick(driver,ASSISTANTS_TAB_HEADER);

    	CommonWait.waitTillDisplayed(driver,CREATE_BUTTON);
    	CommonUtil.jsClick(driver,CREATE_BUTTON);

    	CommonWait.waitTillDisplayed(driver,ASSISTANT_NAME_INPUT);
    	WebElement name_input=CommonUtil.getElement(driver,ASSISTANT_NAME_INPUT);
    	CommonUtil.sendKeysToWebElement(driver,name_input,assistant_name);
    	CommonUtil.sleep(5000);

    	CommonWait.waitTillDisplayed(driver,CREATE_BUTTON2);
    	CommonUtil.jsClick(driver,CREATE_BUTTON2);
    	CommonWait.waitTillHidden(driver,CREATE_BUTTON2);

    	CommonUtil.jsClick(driver,ADD_SKILL_BUTTON);

    	CommonWait.waitTillDisplayed(driver,ASSISTANT_HEADER);
    	CommonUtil.sleep(3000);
    	CommonUtil.clickWebElement(driver, CommonUtil.getElement(driver,ASSISTANT_HEADER) );

    	CommonWait.waitTillDisplayed(driver,ASSISTANT_MORE_OPTIONS);
    	CommonUtil.jsClick(driver,ASSISTANT_MORE_OPTIONS);

    	CommonWait.waitTillDisplayed(driver,SETTINGS_DROPDOWN_VALUE);
    	CommonUtil.jsClick(driver,SETTINGS_DROPDOWN_VALUE);

    	CommonWait.waitTillDisplayed(driver,API_DETAILS_TAB_HEADER);
    	CommonUtil.jsClick(driver,API_DETAILS_TAB_HEADER);

    	CommonWait.waitTillDisplayed(driver,ASSISTANT_ID_VALUE);

    	String assistant_id=CommonUtil.getElement(driver,ASSISTANT_ID_VALUE).getAttribute("innerText").trim();

    	etest.log(Status.INFO,"Watson assistant '"+assistant_name+"' was created successfully. Assitant ID : "+assistant_id);
    	TakeScreenshot.infoScreenshot(driver,etest);

    	return assistant_id;
    }

    //delete assistant
    public static boolean deleteAssistant(WebDriver driver,ExtentTest etest,String assistant_name)
    {
    	goToWatsonPage(driver);

    	CommonWait.waitTillPresent(driver,ASSISTANTS_TAB_HEADER);
    	CommonUtil.jsClick(driver,ASSISTANTS_TAB_HEADER);

    	if(CommonWait.isPresent(driver,By.cssSelector("[title='"+assistant_name+"']"))==false)
    	{
    		etest.log(Status.WARNING,"Could not delete watson assistant '"+assistant_name+"' as no such assistant exists");
    		TakeScreenshot.infoScreenshot(driver,etest);
    		return true;
    	}

    	CommonWait.waitTillDisplayed(driver,By.cssSelector("[title='"+assistant_name+"']"));
    	CommonUtil.jsClick(driver,By.cssSelector("[title='"+assistant_name+"']"));
    	CommonWait.waitTillHidden(driver,By.cssSelector("[title='"+assistant_name+"']"));

    	CommonWait.waitTillDisplayed(driver,ASSISTANT_MORE_OPTIONS);
    	CommonUtil.jsClick(driver,ASSISTANT_MORE_OPTIONS);

    	CommonWait.waitTillDisplayed(driver,DELETE_BUTTON_DROPDOWN_VALUE);
    	CommonUtil.jsClick(driver,DELETE_BUTTON_DROPDOWN_VALUE);

    	CommonWait.waitTillDisplayed(driver,DELETE_INPUT);
    	CommonUtil.sendKeysToWebElement(driver, CommonUtil.getElement(driver,DELETE_INPUT) , "DELETE" );
    	CommonUtil.sleep(5000);

    	CommonWait.waitTillDisplayed(driver,DELETE_SUBMIT);
    	CommonUtil.jsClick(driver,DELETE_SUBMIT);
    	CommonWait.waitTillHidden(driver,DELETE_SUBMIT);

    	etest.log(Status.INFO,"Watson assistant '"+assistant_name+"' was deleted successfully.");

    	return CommonWait.isPresent(driver,By.cssSelector("[title='"+assistant_name+"']"));
    }

}
