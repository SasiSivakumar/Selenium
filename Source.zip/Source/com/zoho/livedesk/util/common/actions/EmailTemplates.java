//$Id$
package com.zoho.livedesk.util.common.actions;

import java.util.List;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.Templates.EmailTemplateTests;

import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil;
import com.zoho.livedesk.util.common.actions.Articles;
import com.zoho.livedesk.util.common.actions.ChatHistory;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

public class EmailTemplates
{
	public static final String
	EMAIL_TEMPLATES_LOADED_CLASS = "loaded",
	AUTHTOKEN = "c5b3c06e100b8b299e1782f5b857ca36",
	FONT_COLOR = "background-color: rgb(255, 0, 0);",          // RED COLOR
	FONT_BACKGROUND = "background-color: rgb(254, 255, 51);"   // HIGHLIGHT COLOR
	;

	public static final String
	ACCOUNTID="5859288000000008002"
	;

	public static final By
    EMAIL_TEMPLATES_TAB=By.cssSelector("[data-tab='email']"),
    CONTENT_CONTAINER = By.id("articlewrap"),
    FORMAT_CLASS = By.className("ze_SCmb"),
    FORMAT_DROPDOWN = By.id("ze_dropdown"),
    TEMPLATES_OPTION = By.id("em_temp"),
    MAIL_TEMPLATE = By.id("mail-template"),
    MAIL_BODY = By.id("mail-tempbody"),
    REPLY_BUTTON = By.id("rplybtn"),
    TEXT = By.className("txtelips"),
    MAIL_USER_ITEM = By.className("mail-usr-item"),
    DELETE_ICON = By.className("sqico-delico"),
    MAIL_CONTAINER=By.id("replycontainer"),
    MISSED_TAB_CONTAINER = By.id("missed_div"),
    CHAT_HISTORY_CONTAINER=By.id("history_div"),
    SUGGESTIONS_DROPDOWN = By.cssSelector("[mode='autocomplete']"),
    PORTAL_EDIT_MODULE = By.id("portaleditmodule"),
    TEMPLATE_EMAIL_CONFIG = By.id("templatemailconfig"),
    TEMPLATES_LIST = By.id("faqlistview"),
    LIST_HEADER = By.className("list_header"),
    LIST_ROW = By.className("list-row"),
    LIST_CELL = By.className("list_cell"),
    SORT_ICON = By.className("sqico-toparrow"),
    PREVIEW = By.className("faqpreview"),
    SUBJECT_ID = By.id("cmsg"),
    TEMPLATE_TEXT = By.className("cmn_wordbr"),
    NO_OF_EMAILS_SENT = By.className("sqico-e-mail"),
    ERROR_MESSAGE = By.id("emcanmessage"),
    PREVIEW_CONTENT = By.className("zsiq-prev-content"),
    CLOSE_ICON = By.className("sqico-close")
    ;

    public static String setAccountId() throws Exception
	{
		WebDriver driver=Functions.setUp();
		String account_id=ZohoMailAPIUtil.getAccountId(driver,AUTHTOKEN);
		driver.quit();
		return account_id;
	}

	public static String getMailData(WebDriver driver,String label,ExtentTest etest)
	{
		try
		{
			// Hashtable<String,String> mail_info = ZohoMailAPIUtil.getMailInfoByUniqueKeyWord(driver,etest,AUTHTOKEN,ACCOUNTID,label);

            String mail_content_text=ZohoMailAPIUtil.searchMail(driver,AUTHTOKEN,ACCOUNTID,label);

			return mail_content_text;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			return "no data received";
		}
	}

    public static WebElement getEmailTemplatesTab(WebDriver driver)
    {       
        return CommonUtil.getElement(driver,EMAIL_TEMPLATES_TAB);
    }

    public static WebElement getEmailTemplatesDescriptionContainer(WebDriver driver)
    {
        return Articles.getArticlesDescriptionContainer(driver);
    }

    public static boolean isCurrentlyInEmailTemplatesTab(WebDriver driver)
    {
        return getEmailTemplatesTab(driver).getAttribute("class").contains(EMAIL_TEMPLATES_LOADED_CLASS);
    }

    public static boolean isEmailTemplatesHeaderFound(WebDriver driver,ExtentTest etest)
    {
        String actual=getEmailTemplatesTab(driver).getText();
        String expected=ResourceManager.getRealValue("email_templates_tab_header");
        return CommonUtil.checkStringContainsAndLog(expected,actual,"email templates header",etest);
    }

    public static boolean isEmailTemplatesDescriptionFound(WebDriver driver,ExtentTest etest)
    {
    	String expected_desc = ResourceManager.getRealValue("email_templates_desc");
		String actual_desc = getEmailTemplatesDescriptionContainer(driver).getText();
		return CommonUtil.checkStringContainsAndLog(expected_desc,actual_desc,"Email Tempaltes description",etest);
    }

    public static boolean checkErrorMessageShown(WebDriver driver,ExtentTest etest)
    {
    	String expected_error_message = ResourceManager.getRealValue("subject_empty_error_message");
    	String actual_error_message = CommonUtil.getElement(driver,ERROR_MESSAGE).getText();

    	return CommonUtil.checkStringContainsAndLog(expected_error_message,actual_error_message,"Error message",etest);
    }

    public static void createEmailTemplate(WebDriver driver,String label) throws Exception
    {
    	String subject = "subject_"+label;
    	String content = "content_"+label;

    	createEmailTemplateWithSubjAndContent(driver,subject,content);
    }
    public static void createEmailTemplateWithSubjAndContent(WebDriver driver,String subject,String content) throws Exception
    {
    	createEmailTemplateWithSubjAndContent(driver,subject,content,null);
    }
    public static void createEmailTemplateWithSubjAndContent(WebDriver driver,String subject,String content,String department) throws Exception
    {
    	Tab.navToEmailTemplatesTab(driver);
		Articles.clickAddButton(driver);
		Articles.setArticleName(driver,subject);
		Articles.setArticleContent(driver,content);

		if(department != null)
        {
            WebElement page = CommonUtil.getElement(driver,By.id("edu_type"));

    		WebElement depts = CommonUtil.getElement(page,By.id("seldepartment"));
            
            if(CommonWait.isDisplayed(depts))
            {
                List<WebElement> list = depts.findElements(By.className("field_div"));
                
                for(WebElement e : list)
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+e.getLocation().y+"-300)");
                    
                    if(department == null)
                    {
                        CommonUtil.clickWebElement(driver,CommonUtil.getElement(e,By.tagName("em")));
                        break;
                    }
                    if(department.contains(e.getText()))
                    {
                        CommonUtil.clickWebElement(driver,CommonUtil.getElement(e,By.tagName("em")));
                    }
                }
            }
        }

		Articles.publishArticle(driver);
    }

    public static void clickTemplatesInSendingEmail(WebDriver driver)
    {
    	CommonWait.waitTillDisplayed(driver,TEMPLATES_OPTION);
    	CommonUtil.clickWebElement(driver,TEMPLATES_OPTION);
    	CommonWait.waitTillDisplayed(driver,MAIL_TEMPLATE);
    }

    public static void selectEmailTemplateInChatHistory(WebDriver driver,String subject)
    {
    	WebElement templateElement = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,MAIL_TEMPLATE,MAIL_BODY).findElements(MAIL_USER_ITEM),"innerText",subject);
    	CommonUtil.clickWebElement(driver,CommonUtil.getElement(templateElement,TEXT));
    }

	public static void clickLatestChatFromMissed(WebDriver driver) throws Exception
	{
		Tab.clickMissed(driver);
		WebElement missedTabElement = CommonUtil.getElement(driver,MISSED_TAB_CONTAINER,By.tagName("table"));
		WebElement latestChat = missedTabElement.findElements(By.tagName("tr")).get(1);
		CommonUtil.clickWebElement(driver,latestChat);
		CommonWait.waitTillHidden(latestChat);
	}

	public static void clickReplyMailButtonInMissed(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,MISSED_TAB_CONTAINER,REPLY_BUTTON);
        CommonUtil.getElement(driver,MISSED_TAB_CONTAINER,REPLY_BUTTON).click();
        CommonWait.waitTillDisplayed(driver,MISSED_TAB_CONTAINER,MAIL_CONTAINER);
    }

    public static void clickLatestChatFromChatHistory(WebDriver driver) throws Exception
    {
        Tab.clickChatHistory(driver);
        WebElement chatHistoryTabElement = CommonUtil.getElement(driver,CHAT_HISTORY_CONTAINER,By.tagName("table"));
        WebElement latestChat = chatHistoryTabElement.findElements(By.tagName("tr")).get(1);
        CommonUtil.clickWebElement(driver,latestChat);
        CommonWait.waitTillHidden(latestChat);
    }

    public static void clickReplyMailButton(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_CONTAINER,REPLY_BUTTON);
        CommonUtil.getElement(driver,CHAT_HISTORY_CONTAINER,REPLY_BUTTON).click();
        CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_CONTAINER,MAIL_CONTAINER);
    }

    public static boolean isTemplatesOptionsShownInSendingMail(WebDriver driver)
    {
    	try
    	{
    		CommonWait.waitTillDisplayed(driver,TEMPLATES_OPTION);
    		return (CommonUtil.getElement(driver,TEMPLATES_OPTION) != null);
    	}
    	catch(Exception e)
    	{
    		return false;
    	}
    }

	public static boolean checkTemplateOptionShownInChatHistory(WebDriver driver)
	{
		try
		{
			clickLatestChatFromChatHistory(driver);
			ChatHistory.clickReplyMailButton(driver);
			return isTemplatesOptionsShownInSendingMail(driver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			return false;
		}
	}

	public static boolean checkTemplateOptionShownInMissedTab(WebDriver driver)
	{
		try
		{
			clickLatestChatFromMissed(driver);
			clickReplyMailButtonInMissed(driver);
			return isTemplatesOptionsShownInSendingMail(driver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			return false;
		}
	}

    public static boolean checkEmailTemplateInChatHistory(WebDriver driver, String subject,boolean isEnable)
	{
		try
		{
			clickLatestChatFromChatHistory(driver);
			ChatHistory.clickReplyMailButton(driver);
			return checkEmailTemplateShownInHistory(driver,subject,isEnable);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			return false;
		}
	}

	public static boolean checkEmailTemplateInMissedTab(WebDriver driver, String subject,boolean isEnable)
	{
		try
		{
			clickLatestChatFromMissed(driver);
			clickReplyMailButtonInMissed(driver);
			return checkEmailTemplateShownInHistory(driver,subject,isEnable);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			return false;
		}
	}

	public static boolean checkEmailTemplateShownInHistory(WebDriver driver,String subject,boolean isEnable)
	{
		try
		{
			clickTemplatesInSendingEmail(driver);
			return (isEmailTemplateFoundInChatHistory(driver,subject) == isEnable);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			return false;
		}
	}

	public static boolean isEmailTemplateFoundInChatHistory(WebDriver driver,String subject)
	{
		WebElement templateElement = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,MAIL_TEMPLATE,MAIL_BODY).findElements(MAIL_USER_ITEM),"innerText",subject);

		return (templateElement != null);
	}

    public static boolean checkEmailTemplateInList(WebDriver driver,String subject) throws Exception
    {
    	Tab.navToEmailTemplatesTab(driver);
    	return (Articles.getArticleContainerByName(driver,subject) != null);
    }

    public static String getTemplateContent(WebDriver driver)
    {
    	Articles.switchToArticleContainerFrame(driver);
		WebElement template_content_input = CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY);

		String content = template_content_input.getText();

		driver.switchTo().defaultContent();

		return content;
    }

    public static boolean checkEmailTemplate(WebDriver driver,String subject,String content,ExtentTest etest)
    {
    	if(!selectEmailTemplatesInList(driver,subject))
    	{
    		TakeScreenshot.screenshot(driver,etest);
    		return false;
    	}

    	String actualSubject = Articles.getArticleNameInputTag(driver).getText();
    	String actualContent = getTemplateContent(driver);

    	if(CommonUtil.checkStringContainsAndLog(subject,actualSubject,"template subject",etest) &&
    		CommonUtil.checkStringContainsAndLog(content,actualContent,"template content",etest))
    	{
    		return true;
    	}
    	else
    	{
    		TakeScreenshot.screenshot(driver,etest);
    		return false;
    	}
    }

    public static boolean selectEmailTemplatesInList(WebDriver driver,String subject)
    {
    	try
    	{
	    	Tab.navToEmailTemplatesTab(driver);

	    	WebElement templateElement = Articles.getArticleContainerByName(driver,subject).findElement(By.tagName("pre"));
	        
	        CommonUtil.clickWebElement(driver,templateElement);
        	
        	return CommonWait.waitTillDisplayed(driver,Articles.ARTICLES_EDIT_CONTAINER);
	    }
	    catch(Exception e)
	    {
	    	return false;
	    }
    }

    public static boolean isEmailTemplatePresentInList(WebDriver driver,String subject)
    {
    	try
    	{
    		Tab.navToEmailTemplatesTab(driver);

	    	WebElement templateElement = Articles.getArticleContainerByName(driver,subject).findElement(By.tagName("pre"));

	    	return (templateElement != null);
    	}
    	catch(Exception e)
    	{
    		return false;
    	}
    }

    public static boolean checkEmailTemplateEdit(WebDriver driver,String label,boolean isEditAdmin,boolean isEditSupervisor,boolean isEditAssociate,ExtentTest etest)
    {		
		boolean
        check1 = checkEmailTemplateEdit(driver,"subject_admin_"+label,isEditAdmin,etest),
        check2 = checkEmailTemplateEdit(driver,"subject_associate_"+label,isEditAssociate,etest),
		check3 = checkEmailTemplateEdit(driver,"subject_supervisor_"+label,isEditSupervisor,etest)
        ;

        return ( check1 && check2 && check3 );
    }

    public static boolean checkEmailTemplateEdit(WebDriver driver,String label,boolean isEdit,ExtentTest etest)
    {
        Cleanup.closeAllPopups(driver,etest);
    	selectEmailTemplatesInList(driver,label);
		if((isEditTemplateDisplayed(driver) == isEdit) && (!isPreviewDisplayed(driver) == isEdit))
		{
            etest.log(Status.PASS,"Operator was "+((isEdit)?"able":"not able")+" to edit the template created");
			return true;
		}
		else
		{
            etest.log(Status.FAIL,"Operator was "+((isEdit)?"not able":"able")+" to edit the template created");
            TakeScreenshot.screenshot(driver,etest);
			return false;
		}
    }

    public static boolean checkEmailTemplateDelete(WebDriver driver,String label,boolean isDeleteAdmin,boolean isDeleteSupervisor,boolean isDeleteAssociate,ExtentTest etest)
    {
        boolean
        check1 = checkEmailTemplateDelete(driver,"subject_admin_"+label,isDeleteAdmin,etest),
        check2 = checkEmailTemplateDelete(driver,"subject_associate_"+label,isDeleteAssociate,etest),
        check3 = checkEmailTemplateDelete(driver,"subject_supervisor_"+label,isDeleteSupervisor,etest)
        ;

        return ( check1 && check2 && check3 );
    }

    public static boolean checkEmailTemplateDelete(WebDriver driver,String subject,boolean isDelete,ExtentTest etest)
    {
        try
        {
            deleteTemplatesBySubject(driver,subject);
            if(!checkEmailTemplateInList(driver,subject) == isDelete)
            {
                etest.log(Status.PASS,"Operator was "+((isDelete)?"able":"not able")+" to delete the template created");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Operator was "+((isDelete)?"not able":"able")+" to delete the template created");
                TakeScreenshot.screenshot(driver,etest);
                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,e);
            return false;
        }
    }


    public static boolean isEditTemplateDisplayed(WebDriver driver)
    {
    	try
    	{
    		CommonWait.waitTillDisplayed(driver,SUBJECT_ID);
    		return CommonWait.isDisplayed(driver,SUBJECT_ID);
    	}
    	catch(Exception e)
    	{
    		CommonUtil.printStackTrace(e);
    		return false;
    	}
    }

    public static boolean isPreviewDisplayed(WebDriver driver)
    {
    	return ArticlesVisitorSide.waitTillArticlePreviewDisplayed(driver);
    }

    public static void deleteTemplatesBySubject(WebDriver driver,String subject)
    {
    	try
        {
        	WebElement elementToDelete = CommonUtil.getElementByAttributeValue(Articles.getArticleContainers(driver),"innerText",subject);
            WebElement delete = elementToDelete.findElement(DELETE_ICON);

            CommonUtil.mouseHover(driver,delete);

            try
            {
               CommonWait.waitTillDisplayed(delete);
            }
            catch(Exception exp)
            {
               CommonUtil.printStackTrace(exp);
            }

            delete.click();
            CommonUtil.sleep(250);
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,Cleanup.DELETE_COMMON_TEXT);
            HandleCommonUI.clickPositivePopupButton(popup);
            CommonUtil.sleep(1000);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
    }

    public static void deleteAllEmailTemplates(WebDriver driver) throws Exception
    {
    	Tab.navToEmailTemplatesTab(driver);
    	Cleanup.deleteAllRules(driver);
    }

    public static boolean isSuggestionsDisplayed(WebDriver driver,By containerId)
    {
    	WebElement container = CommonUtil.getElement(driver,containerId);
    	CommonWait.waitTillDisplayed(container,SUGGESTIONS_DROPDOWN);
    	return CommonWait.isDisplayed(container,SUGGESTIONS_DROPDOWN);
    }

    public static void selectPortalConfig(WebDriver driver,String option,ExtentTest etest) throws Exception
    {
        Tab.navToPortalTab(driver);
    	List<WebElement> inputElements = CommonUtil.getElement(driver,PORTAL_EDIT_MODULE,TEMPLATE_EMAIL_CONFIG).findElements(By.tagName("input"));
    	WebElement elementToSelect = CommonUtil.getElementByAttributeValue(inputElements,"fval",option);
    	CommonUtil.inViewPortSafe(driver,elementToSelect,400);
    	CommonUtil.clickWebElement(driver,elementToSelect);
    	Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
    }

    public static boolean checkAllDynamicText(WebDriver driver,Hashtable<Integer,String> key,Hashtable<String,String> expected_text,ExtentTest etest) throws Exception
	{
		int failcount=0;

		String content = getTemplateContent(driver).toLowerCase();

        int j = 0;
        while((!content.contains("content")) && (j++ < 10))
        {
            content = getTemplateContent(driver).toLowerCase();
        }
        
		for(int i=0;i<key.size();i++)
		{			
			if(content.contains(key.get(i)+":"+expected_text.get(key.get(i)).toLowerCase()))
			{
				etest.log(Status.PASS,"Dynamic text suggestion "+"%"+key.get(i)+"% is working as expected.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Dynamic text suggestion "+"%"+key.get(i)+"% is NOT working as expected("+expected_text.get(key.get(i))+").");
				TakeScreenshot.screenshot(driver,etest);
			}
		}

		if(content.contains("smart.timenow:Morning".toLowerCase()) || content.contains("smart.timenow:Afternoon".toLowerCase()) || content.contains("smart.timenow:Night".toLowerCase()) || content.contains("smart.timenow:Evening".toLowerCase()))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %smart.timenow% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %smart.timenow% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest);		
		}

        if(content.contains("visitor.referrer:"))
        {
            etest.log(Status.PASS,"Dynamic text suggestion %visitor.referrer% is working as expected.");
        }
        else
        {
            failcount++;
            etest.log(Status.FAIL,"Dynamic text suggestion %visitor.referrer% is NOT working as expected.");
            TakeScreenshot.screenshot(driver,etest);        
        }

        if(content.contains("search.engine:"))
        {
            etest.log(Status.PASS,"Dynamic text suggestion %search.engine% is working as expected.");
        }
        else
        {
            failcount++;
            etest.log(Status.FAIL,"Dynamic text suggestion %search.engine% is NOT working as expected.");
            TakeScreenshot.screenshot(driver,etest);        
        }

        if(content.contains("web.embed.name:"+ExecuteStatements.getDefaultEmbedName(driver).toLowerCase()))
        {
            etest.log(Status.PASS,"Dynamic text suggestion %web.embed.name% is working as expected.");
        }
        else
        {
            failcount++;
            etest.log(Status.FAIL,"Dynamic text suggestion %web.embed.name% is NOT working as expected.");
            TakeScreenshot.screenshot(driver,etest);        
        }

        if(content.contains("visitor.department:"+ExecuteStatements.getSystemGeneratedDepartment(driver).toLowerCase()))
        {
            etest.log(Status.PASS,"Dynamic text suggestion %visitor.department% is working as expected.");
        }
        else
        {
            failcount++;
            etest.log(Status.FAIL,"Dynamic text suggestion %visitor.department% is NOT working as expected.");
            TakeScreenshot.screenshot(driver,etest);        
        }

        content = content.replaceAll("\\n", "");

		if(content.matches(".+visitor.id:\\d+.+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion visitor.id is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion visitor.id is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest);		
		}

        if(content.matches(".+visitor.browser:.+"+expected_text.get("visitor.browser").toLowerCase()+".+") || content.matches(".+visitor.browser:"+expected_text.get("visitor.browser")+".+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %visitor.browser% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %visitor.browser% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest);		
		}

		if(content.matches(".+screen.resolution:\\d+\\s\\*\\s\\d+.+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %screen.resolution% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %screen.resolution% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest);		
		}

		String ip_matching_regex="(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";

		if(content.matches(".+visitor\\.ip:"+ip_matching_regex+".+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %visitor.ip% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %visitor.ip% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest);		
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkSort(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		for(int i = 1; i <= 2 ; i++)
		{
			List<WebElement> templatesList = Articles.getArticleContainers(driver);
			List<WebElement> templatesHeader = CommonUtil.getElement(driver,TEMPLATES_LIST,LIST_HEADER).findElements(LIST_CELL);
			WebElement header = templatesHeader.get(i);
			WebElement sortIcon = CommonUtil.getElement(header,SORT_ICON);
			if(sortIcon.isDisplayed())
			{
				etest.log(Status.PASS,"Sort icon was displayed in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header in Templates tab");
				CommonUtil.clickWebElement(driver,sortIcon);
				templatesList = CommonUtil.getElement(driver,TEMPLATES_LIST).findElements(LIST_ROW);
				String firstTemplate = CommonUtil.getElement(templatesList.get(0),TEMPLATE_TEXT).getText();
				String firstTemplateUsedCount = CommonUtil.getElement(templatesList.get(0),NO_OF_EMAILS_SENT).getText();
				String lastTemplateUsedCount = CommonUtil.getElement(templatesList.get(templatesList.size()-1),NO_OF_EMAILS_SENT).getText();
				String lastTemplateLastUsed = CommonUtil.getElement(templatesList.get(templatesList.size()-1)).findElements(LIST_CELL).get(2).getText();
				if((lastTemplateUsedCount.contains("0") && firstTemplate.contains(EmailTemplateTests.template1)) ||
					(firstTemplateUsedCount.contains("0") && lastTemplateLastUsed.contains("mins")))
				{
					etest.log(Status.PASS,"After clicking sort icon in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header the Templates list was sorted based on the number of chats the Templates was used");
				}
				else
				{
					etest.log(Status.FAIL,"After clicking sort icon in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header the Templates list was not sorted based on the number of chats the Templates was used");
					TakeScreenshot.screenshot(driver,etest);
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Sort icon was not displayed in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header in Templates tab");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkInnerElements(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		try
		{
			List<WebElement> templatesList = Articles.getArticleContainers(driver);
			for(WebElement template : templatesList)
			{
				if(CommonUtil.getElement(template,NO_OF_EMAILS_SENT).getText().contains("0"))
				{
					if(template.findElements(LIST_CELL).get(2).getText().contains("-"))
					{
						etest.log(Status.PASS,"The data present in the no of chats and last used for the templates ("+CommonUtil.getElement(template,TEMPLATE_TEXT).getText()+") was verified to be correct");
					}
					else
					{
						etest.log(Status.FAIL,"The data present in the no of chats and last used for the templates ("+CommonUtil.getElement(template,TEMPLATE_TEXT).getText()+") was incorrect.. Expected : '-' ~~~~ Found : '"+template.findElements(LIST_CELL).get(2).getText()+"'");
						TakeScreenshot.screenshot(driver,etest);
						failcount++;
					}
				}
				else if(CommonUtil.getElement(template,NO_OF_EMAILS_SENT).getText().contains("1") || CommonUtil.getElement(template,NO_OF_EMAILS_SENT).getText().contains("2"))
				{
					if(template.findElements(LIST_CELL).get(2).getText().contains("mins"))
					{
						etest.log(Status.PASS,"The data present in the no of chats and last used for the templates ("+CommonUtil.getElement(template,TEMPLATE_TEXT).getText()+") was verified to be correct");
					}
					else
					{
						etest.log(Status.FAIL,"The data present in the no of chats and last used for the templates ("+CommonUtil.getElement(template,TEMPLATE_TEXT).getText()+") was incorrect.. Expected: 'mins' ~~~~ Found : '"+template.findElements(LIST_CELL).get(2).getText()+"'");
						TakeScreenshot.screenshot(driver,etest);
						failcount++;
					}
				}
				else
				{
					etest.log(Status.FAIL,"The data present in the no of chats for the templates ("+CommonUtil.getElement(template,TEMPLATE_TEXT).getText()+") was incorrect.. Expected : '0' or '1' or '2' Found : '"+template.findElements(LIST_CELL).get(1).getText()+"'");
					TakeScreenshot.screenshot(driver,etest);
					failcount++;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void selectInFormattingMenu(WebDriver driver,By formatClass)
	{
		CommonUtil.clickWebElement(driver,CONTENT_CONTAINER,FORMAT_CLASS,formatClass);
		CommonUtil.sleep(1000);
	}

	public static void selectInFormattingDropdown(WebDriver driver,By format,String formatOption)
	{
		selectInFormattingMenu(driver,format);
		List<WebElement> fontElements = CommonUtil.getElement(driver,FORMAT_DROPDOWN).findElements(By.tagName("li"));

		switch(formatOption)
		{
			case "fontColor" :
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(fontElements,"style",FONT_COLOR));
				break;
			}
			case "fontBackground" :
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(fontElements,"style",FONT_BACKGROUND));
				break;
			}
			case "table" :
			{
				CommonUtil.clickWebElement(driver,By.xpath("//*[@data-col_num='2'][@data-row_num='2']"));
				break;
			}
			default :
			{
				for(WebElement fontElement : fontElements)
				{
					if(fontElement.getText().contains(formatOption))
					{
						CommonUtil.clickWebElement(driver,fontElement);
						break;
					}
				}
			}
		}
	}

	public static boolean checkFormatting(WebDriver driver,WebElement contentBody,String key,By formatTag,String formatStyle,String expected,boolean isExpected,ExtentTest etest)
	{
        WebElement expectedElement = null;
		try
        {
            if(formatStyle == null)
            {
                expectedElement = CommonUtil.getElement(contentBody,formatTag);
            }
            else
            {
                expectedElement = CommonUtil.getElementByAttributeValue(contentBody.findElements(formatTag),formatStyle,expected);
            }
        }
        catch(Exception e)
        {
            if(!isExpected)
            {
                etest.log(Status.PASS,KeyManager.getRealValue(key)+" -- SUCCESS");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,KeyManager.getRealValue(key)+" -- FAILED");
                TakeScreenshot.screenshot(driver,etest);
                return false;
            }
        }

		if(expectedElement == null)
		{
            if(!isExpected)
            {
                etest.log(Status.PASS,KeyManager.getRealValue(key)+" -- SUCCESS");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,KeyManager.getRealValue(key)+" -- FAILED");
                TakeScreenshot.screenshot(driver,etest);
                return false;
            }
		}
		else if(formatStyle == null)
		{
            etest.log(Status.PASS,KeyManager.getRealValue(key)+" -- SUCCESS");
			return true;
		}

		if(expectedElement.getAttribute(formatStyle).contains(expected) == isExpected)
		{
            etest.log(Status.PASS,KeyManager.getRealValue(key)+" -- SUCCESS");
			return true;
		}

        etest.log(Status.FAIL,KeyManager.getRealValue(key)+" -- FAILED");
        TakeScreenshot.screenshot(driver,etest);
		return false;
	}

    public static void editTemplatesContent(WebDriver driver,String content)
    {
        try
        {
            Articles.switchToArticleContainerFrame(driver);
            WebElement template_content = CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY);
            template_content.sendKeys(content);
            driver.switchTo().defaultContent();
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
    }

    public static void closePreviewWindow(WebDriver driver)
    {
        // WebElement close_button = (ArticlesVisitorSide.getArticlePreviewContainer(driver)).findElement(CLOSE_ICON);
        // CommonUtil.clickWebElement(driver,close_button);
        // CommonWait.waitTillHidden(close_button);

        WebElement popup = CommonUtil.getElement(driver,By.id("popupdiv"));
        HandleCommonUI.closePopup(popup);
    }
}
