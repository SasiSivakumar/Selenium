//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class AppsAdd
{
    /*Objects*/


    /*Constants*/
    public static final By
    CREATE=By.cssSelector("[documentclick*='createApp']"),
    NAME_INPUT=By.id("appname"),
    DESCRIPTION_INPUT=By.id("description"),
    DEPT_SELECT_CONTAINER=By.id("apps_department"),
    DEPT_ELEMENT=By.className("dib"),
    CLOSE_ICON=By.className("fsiq-close"),
    DEPARTMENT_SEARCH_INPUT=By.id("app_dept"),
    DEPARTMENT_SEARCH_RESULT=By.className("option-item"),
    DONE_BUTTON=By.cssSelector("[documentclick='addAdditionalInfo']");
    ;

    public static final String
    PAGE="'Apps add'"
    ;

    /*Methods*/
    public static boolean waitTillLoads(WebDriver driver)
    {
    	return CommonWait.waitTillDisplayed(driver,CREATE);
    }

    public static void sendKeysToNameInput(WebDriver driver,String app_name)
    {
        CommonWait.waitTillDisplayed(driver,NAME_INPUT);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,NAME_INPUT),app_name);
    }

    public static boolean clickCreate(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,CREATE);
        CommonUtil.click(driver,CREATE);
        return CommonWait.waitTillHidden(driver,CREATE);
    }

    public static void sendKeysToDescriptionInput(WebDriver driver,String app_desc)
    {
        CommonWait.waitTillDisplayed(driver,DESCRIPTION_INPUT);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,DESCRIPTION_INPUT),app_desc);
    }

    public static void selectDepartments(WebDriver driver,ExtentTest etest,List<String> department_names)
    {
        List<WebElement> dept_ele_list=CommonUtil.getElement(driver,DEPT_SELECT_CONTAINER).findElements(DEPT_ELEMENT);

        //remove random department to make search icon appear
        WebElement department0=dept_ele_list.get(0);
        clickDepartmentCloseIcon(driver,department0);

        //add required
        for(String department_name : department_names)
        {
            WebElement department_ele=CommonUtil.getElementByAttributeValue(dept_ele_list,"innerText",department_name);

            boolean isAlreadySelected=(department_ele!=null);

            if(isAlreadySelected==false)
            {
                selectDepartmentFromDropdown(driver,etest,department_name);
            }
        }

        //remove NOT required
       dept_ele_list=CommonUtil.getElement(driver,DEPT_SELECT_CONTAINER).findElements(DEPT_ELEMENT);

        for(WebElement department_ele : dept_ele_list)
        {
            String department_name=department_ele.getAttribute("innerText").trim();

            boolean isRemove=(CommonUtil.isListContains(department_names,department_name)==false);

            if(isRemove)
            {
                clickDepartmentCloseIcon(driver,department_ele);
            }
        }

        etest.log(Status.INFO,"Following departments were mapped for the website-->"+department_names.toString());
    }

    public static void clickDepartmentCloseIcon(WebDriver driver,WebElement department_ele)
    {
        WebElement close_icon=CommonUtil.getElement(department_ele,CLOSE_ICON);
        CommonUtil.mouseHoverAndClick(driver,close_icon);
        CommonWait.waitTillHidden(close_icon);
    }

    public static void selectDepartmentFromDropdown(WebDriver driver,ExtentTest etest,String department)
    {
        CommonWait.waitTillDisplayed(driver,DEPARTMENT_SEARCH_INPUT);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,DEPARTMENT_SEARCH_INPUT),department);
        CommonWait.waitTillDisplayed(driver,DEPT_SELECT_CONTAINER,DEPARTMENT_SEARCH_RESULT);
        List<WebElement> search_results=CommonUtil.getElement(driver,DEPT_SELECT_CONTAINER).findElements(DEPARTMENT_SEARCH_RESULT);

        WebElement expected_search_result=CommonUtil.getElementByAttributeValue(search_results,"innerText",department);

        if(expected_search_result==null)
        {
            throw new ZohoSalesIQRuntimeException("Department '"+department+"' was not found in search results");
        }

        CommonUtil.clickWebElement(driver,expected_search_result);
        CommonWait.waitTillHidden(expected_search_result);

        etest.log(Status.INFO,"Department '"+department+"' was selected from dropdown");
    }

    public static void clickDoneButton(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,DONE_BUTTON);
        CommonUtil.click(driver,DONE_BUTTON);
        CommonWait.waitTillHidden(driver,DONE_BUTTON);
    }

    public static List<String> getSelectedDepartments(WebDriver driver)
    {
        List<WebElement> dept_ele_list=CommonUtil.getElements(driver,DEPT_ELEMENT);
        return CommonUtil.getAttributesFromList(dept_ele_list,"innerText");
    }
}
