//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import org.apache.commons.lang3.StringUtils;

public class BotInfo
{
    public static final String
    NAME="NAME",
    DESCRIPTION="DESC",
    PUBLISH_ACTION="PUBLISH_ACTION",
    PUBLISH_STATUS="PUBLISH_STATUS",
    IS_ENABLED="IS_ENABLED",
    CONVERSED="CONVERSED",
    TRANSFERED_PERCENTAGE="TRANSFERED_PERCENTAGE",
    TRANSFERED_COUNT="TRANSFERED_COUNT",
    HOURS_WORKED="HOURS_WORKED",
    LAST_USED="LAST_USED",
    WEBSITE="WEBSITE",
    DEPARTMENTS="DEPTS",
    BUSINESS_HOUR="BUSINESS_HOUR_BOOL",
    IS_CONNECT_HUMAN="IS_CONNECT_HUMAN",
    SCRIPT_TYPE="SCRIPT_TYPE",
    SALESIQ_SCRIPT_TYPE="SALESIQ_SCRIPT",
    CREATE_AND_PUBLISH="CREATE_AND_PUBLISH",//works only during creation
    CREATE_ONLY="CREATE_ONLY",
    PUBLISH_TRIGGER_HANDLER="PUBLISH_TRIGGER_HANDLER",
    PUBLISH_MESSAGE_HANDLER="PUBLISH_MESSAGE_HANDLER",
    PUBLISH_CONTEXT_HANDLER="PUBLISH_CONTEXT_HANDLER",
    PUBLISH_ALL_HANDLERS="PUBLISH_ALL_HANDLERS",
    IS_MH_PUBLISHED="IS_MH_PUBLISHED",
    IS_CH_PUBLISHED="IS_CH_PUBLISHED",
    IS_TH_PUBLISHED="IS_TH_PUBLISHED",
    TYPING_DELAY="TYPING_DELAY"
    ;


    public static final String[]
    WORKING_HOURS_VALUES={null,"24x7","during_business_hours"}
    ;

    public static Hashtable<String,String> getBotInfoHashtable(String name,String publish_action,String website,String depts)
    {
        return getBotInfoHashtable(name,"bot_description value",publish_action,null,null,website,depts,null,null);
    }

    public static Hashtable<String,String> getBotInfoHashtable(WebDriver driver,String unique)
    {
        return getBotInfoHashtable("bot"+unique,"desc"+unique,null,null,null,ExecuteStatements.getDefaultEmbedName(driver),ExecuteStatements.getSystemGeneratedDepartment(driver),null,null);
    }

    public static Hashtable<String,String> getBotInfoHashtable(String name,String description,String publish_action,String publish_status,String is_enabled,String website,String depts,Integer business_hour_value,String is_connect_human)
    {
        Hashtable<String,String> bot_info=new Hashtable<String,String>();

        if(name!=null)
        {
            bot_info.put(NAME,name);
        }
        if(description!=null)
        {
            bot_info.put(DESCRIPTION,description);
        }
        if(publish_action!=null)
        {
            bot_info.put(PUBLISH_ACTION,publish_action);
        }
        if(publish_status!=null)
        {
            bot_info.put(PUBLISH_STATUS,publish_status);
        }
        if(is_enabled!=null)
        {
            bot_info.put(IS_ENABLED,is_enabled);
        }
        if(website!=null)
        {
            bot_info.put(WEBSITE,website);
        }
        if(depts!=null)
        {
            bot_info.put(DEPARTMENTS,depts);
        }
        if(business_hour_value!=null)
        {
            bot_info.put(BUSINESS_HOUR,""+business_hour_value);
        }
        if(is_connect_human!=null)
        {
            bot_info.put(IS_CONNECT_HUMAN,is_connect_human);
        }

        bot_info.put(SCRIPT_TYPE,SALESIQ_SCRIPT_TYPE);

        return bot_info;
    }

    public static String getBotPublishedStatus(WebElement bot)
    {
        WebElement publish_ele=CommonUtil.getElement(bot,BotsTab.BOT_PUBLISH_STATUS);

        if(publish_ele!=null)
        {
            return publish_ele.getAttribute("innerText").trim();
        }

        return null;
    }

    public static Hashtable<String,String> getBotConfig(WebDriver driver,ExtentTest etest,String bot_name)
    {
        return getBotConfig(driver,etest,bot_name,true);
    }

    public static Hashtable<String,String> getBotConfig(WebDriver driver,ExtentTest etest,String bot_name,boolean isSalesIQBot)
    {
        Tab.navToBotsTab(driver);

        WebElement bot=BotsTab.getListedBotElement(driver,bot_name);

        if(bot==null)
        {
            throw new ZohoSalesIQRuntimeException("Bot "+bot_name+" is not present.");
        }

        Hashtable<String,String> bot_info=new Hashtable<String,String>();

        etest.log(Status.INFO,"Bot '"+bot_name+"' configuration screenshots are attached below");

        TakeScreenshot.infoScreenshot(driver,etest);

        bot_info.put(NAME,bot_name);

        String bot_description=CommonUtil.getElement(bot,BotsTab.BOT_DESC).getAttribute("innerText").trim();
        bot_info.put(DESCRIPTION,bot_description);

        String bot_published_status=getBotPublishedStatus(bot);

        if(bot_published_status==null)
        {
            bot_published_status="null";
        }

        bot_info.put(PUBLISH_STATUS,bot_published_status);

        String is_enabled_value=BotsTab.isBotEnabled(bot)+"";
        bot_info.put(IS_ENABLED,is_enabled_value);

        String conversed_count=CommonUtil.getElement(bot,BotsTab.CONVERSED_COUNT).getAttribute("innerText").trim();
        bot_info.put(CONVERSED,conversed_count);

        String transfered_percentage=CommonUtil.getElement(bot,BotsTab.TRANSFERED_PERCENTAGE).getAttribute("innerText").trim();
        bot_info.put(TRANSFERED_PERCENTAGE,transfered_percentage);

        String transfered_count=CommonUtil.getElement(bot,BotsTab.TRANSFERED_PERCENTAGE).getAttribute("tooltip").trim();
        bot_info.put(TRANSFERED_COUNT,transfered_count);

        String hours_worked=CommonUtil.getElement(bot,BotsTab.HOURS_WORKED).getAttribute("innerText").trim();
        bot_info.put(HOURS_WORKED,hours_worked);

        String last_used=CommonUtil.getElement(bot,BotsTab.LAST_USED).getAttribute("innerText").trim();
        bot_info.put(LAST_USED,last_used);

        BotsTab.openBotConfiguration(driver,bot_name);

        String website=CommonUtil.getElement(driver,BotConfiguration.WEBSITE_DROPDOWN_CONTAINER).getAttribute("innerText").trim();
        bot_info.put(WEBSITE,website);

        String departments=CommonUtil.toCommaSeperatedString( BotConfiguration.getDepartments(driver) );
        bot_info.put(DEPARTMENTS,departments);

        WebElement bh_dropdown = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,BotConfiguration.BUSINESS_HOUR_RADIO_BTN).findElements(BotConfiguration.BUSINESS_HOUR_OPTIONS),"innerHTML","rdselected");
        String business_hour_value=bh_dropdown.findElement(By.tagName("input")).getAttribute("fval");
        bot_info.put(BUSINESS_HOUR,business_hour_value);

        WebElement connect_toggle=CommonUtil.getElement(driver,BotConfiguration.CONNECT_OPERATOR_TOGGLE);
        String connect_to_human=HandleCommonUI.isToggleEnabled(connect_toggle)+"";
        bot_info.put(IS_CONNECT_HUMAN,connect_to_human);

        String typing_delay=CommonUtil.getElement(driver,BotsTab.TYPING_DELAY).getAttribute("innerText").trim();
        bot_info.put(TYPING_DELAY,typing_delay);

        TakeScreenshot.infoScreenshot(driver,etest);

        if(!isSalesIQBot)
        {
            return bot_info;
        }

        BotConfiguration.clickOpenSalesIQScript(driver);

        DelugeScript.toggleHandlerDropdown(driver,true);

        bot_info.put(IS_MH_PUBLISHED,""+DelugeScript.isHandlerPublished(driver,DelugeScript.MESSAGE_HANDLER_DROPDOWN_ELEMENT));
        bot_info.put(IS_CH_PUBLISHED,""+DelugeScript.isHandlerPublished(driver,DelugeScript.CONTEXT_HANDLER_DROPDOWN_ELEMENT));
        bot_info.put(IS_TH_PUBLISHED,""+DelugeScript.isHandlerPublished(driver,DelugeScript.TRIGGER_HANDLER_DROPDOWN_ELEMENT));

        etest.log(Status.INFO,"Bot '"+bot_name+"' info is "+bot_info.toString());

        TakeScreenshot.infoScreenshot(driver,etest);

        DelugeScript.toggleHandlerDropdown(driver,false);

        DelugeScript.close(driver);

        return bot_info;
    }

    public static boolean isBotValuesFound(WebDriver driver,ExtentTest etest,Hashtable<String,String> expected_bot_info)
    {
        Hashtable<String,String> actual_bot_info=getBotConfig(driver,etest,expected_bot_info.get(NAME));

        //currently hardcoding all script types as salesiq script as not other type is present
        actual_bot_info.put(SCRIPT_TYPE,SALESIQ_SCRIPT_TYPE);

        Set<String> keys = expected_bot_info.keySet();

        int failcount=0;

        for(String key: keys)
        {

            try
            {
                if(checkBotValueIfKeyFound(driver,etest,key,expected_bot_info,actual_bot_info)==false)
                {
                    failcount++;
                }
            }

            catch(Exception e)
            {
                etest.log(Status.FAIL,"Exception occured when checking "+key);
                TakeScreenshot.screenshot(driver,etest,e);
                failcount++;
            }
        }

        if(CommonUtil.returnResult(failcount))
        {
            etest.log(Status.PASS,"All values were found.\nExpected bot info : "+expected_bot_info.toString()+"\nActual bot info : "+actual_bot_info.toString());
        }
        else
        {
            etest.log(Status.FAIL,"All values were NOT found.\nExpected bot info : "+expected_bot_info.toString()+"\nActual bot info : "+actual_bot_info.toString());
            TakeScreenshot.screenshot(driver,etest);
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean checkBotValueIfKeyFound(WebDriver driver,ExtentTest etest,String key,Hashtable<String,String> expected_bot_info,Hashtable<String,String> actual_bot_info)
    {
        if(expected_bot_info.containsKey(key)==false || key.equals(PUBLISH_ACTION))
        {
            //no  need to check
            return true;
        }

        String bot_name=actual_bot_info.get(NAME);

        if(actual_bot_info.containsKey(key)==false)
        {
            etest.log(Status.INFO,"Actual "+key+" of bot '"+bot_name+"' could not be found");
            return false;
        }

        String expected=expected_bot_info.get(key);
        String actual=actual_bot_info.get(key);

        if(key.equals(DEPARTMENTS))
        {
            return CommonUtil.compareList( Arrays.asList(expected.split(",")) , Arrays.asList(actual.split(",")) , key , etest );
        }
        else
        {
            return CommonUtil.checkStringContainsAndLog(expected,actual,key+" of bot '"+bot_name+"' ",etest);
        }
    }
}
