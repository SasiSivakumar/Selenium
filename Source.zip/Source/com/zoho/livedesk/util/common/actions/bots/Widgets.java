//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;
import com.zoho.livedesk.client.bots.BotsWidgets;

public class Widgets
{
    public static final String[]
    SLIDER_WIDGET_VALUES={"0","10","20","30","40"},
    RANGE_SLIDER_VALUES={"0","10","20","30","40","50","60","70","80","90"},
    HAPPINESS_RATING_LEVEL5_CLASS_NAMES={"angry","sad","cmpnt-rtng","good","great"},
    HAPPINESS_RATING_LEVEL5_VALUES={"Angry","Sad","Neutral","Good","Great"},
    SINGLE_SELECT_VALUE_SET1={"SalesIQ","Cliq","CRM","Desk","People","Connect","Mail","Docs","Writer","Projects"},
    SINGLE_SELECT_VALUE_SET2={"012345678901234567890123456789","Char limit usecase"},
    MULTISELECT_VALUE_SET1=SINGLE_SELECT_VALUE_SET1,//same as single    
    TIMESLOT_VALUES={"00:00","24:00","12:00","03:00","15:00"},
    TIMESLOT_CONTENT={"12:00 AM","12:00 AM","12:00 PM","03:00 AM","03:00 PM"},
    DATE_TIMESLOT_DAY1_VALUES={"12:00","03:00"},
    DATE_TIMESLOT_DAY1_CONTENT={"12:00 PM","03:00 AM"},
    DATE_TIMESLOT_DAY2_VALUES={"15:00"},
    DATE_TIMESLOT_DAY2_CONTENT={"03:00 PM"},
    DATE_TIMESLOT_DAY3_VALUES={"00:00","24:00"},
    DATE_TIMESLOT_DAY3_CONTENT={"12:00 AM","12:00 AM"},
    DATE_TIME_DATES={"31/12/2018","15/08/2018","01/01/2018"},
    CALENDAR_TIME1={"07","45","PM"},
    CONTEXT_HANDLER_SUGGESTIONS_FLOW1={"answer11","answer12"},
    CONTEXT_HANDLER_SUGGESTIONS_FLOW2={"answer41","answer42"}  
    ;

    public static final String
    INVOKE_CALENDAR1="INVOKE CALENDAR1",
    INVOKE_CALENDAR2="INVOKE CALENDAR2",
    INVOKE_RANGE_CALENDAR1="INVOKE RANGE CALENDAR1",
    INVOKE_RANGE_CALENDAR2="INVOKE RANGE CALENDAR2",
    INVOKE_SLIDER="INVOKE SLIDER",
    INVOKE_RANGE_SLIDER="INVOKE RANGE SLIDER",
    INVOKE_HAPPINESS_RATING_LEVEL3="INVOKE HAPPINESS RATING LEVEL3",
    INVOKE_HAPPINESS_RATING_LEVEL5="INVOKE HAPPINESS RATING LEVEL5",
    INVOKE_LIKE_SKIPPABLE="INVOKE LIKE SKIPPABLE",
    INVOKE_LIKE_UNSKIPPABLE="INVOKE LIKE UNSKIPPABLE",
    INVOKE_5STAR_RATING="INVOKE 5STAR RATING",
    INVOKE_10STAR_RATING="INVOKE 10STAR RATING",
    INVOKE_SINGLE_SELECT1="INVOKE SINGLE SELECT1",
    INVOKE_SINGLE_SELECT2="INVOKE SINGLE SELECT2",
    INVOKE_MULTISELECT1="INVOKE MULTISELECT1",
    INVOKE_MULTISELECT2="INVOKE MULTISELECT2",
    INVOKE_TIMESLOTS1="INVOKE TIMESLOTS1",
    INVOKE_TIMESLOTS2="INVOKE TIMESLOTS2",
    INVOKE_DATETIMESLOTS1="INVOKE DATETIMESLOTS1",
    INVOKE_DATETIMESLOTS2="INVOKE DATETIMESLOTS2",
    INVOKE_LINK="INVOKE LINK",
    INVOKE_IMAGE="INVOKE IMAGE",
    INVOKE_ARTICLES="INVOKE ARTICLES",
    INVOKE_CONTEXT_HANDLER_FLOW1="Context flow1",
    INVOKE_CONTEXT_HANDLER_FLOW2="Context flow2",
    INVOKE_CREATE_LEAD="Create",
    INVOKE_GET_LEAD="Get",
    INVOKE_GOOGLE_CALENDAR_WIDGET="Book",
    INVOKE_GOOGLE_CALENDAR_VERIFY="Get:<event_id>",
    INVOKE_FORWARD_TO_ALL="INVOKE_FORWARD_TO_ALL",
    INVOKE_FORWARD_TO_AGENT="INVOKE_FORWARD_TO_AGENT",
    INVOKE_FORWARD_TO_DEPARTMENT="INVOKE_FORWARD_TO_DEPARTMENT",
    INVOKE_OPERATOR_BUSY="INVOKE_OPERATOR_BUSY",
    INVOKE_BLOCK="INVOKE_BLOCK",
    INVOKE_END="INVOKE_END",
    INVOKE_STORE_NAME="STORE NAME",
    INVOKE_STORE_EMAIL="STORE EMAIL",
    INVOKE_STORE_PHONE="STORE PHONE",
    INVOKE_VALIDATE_EMAIL="VALIDATE EMAIL",
    INVOKE_VALIDATE_PHONE="VALIDATE PHONE",
    INVOKE_VALIDATE_WEBSITE="VALIDATE WEBSITE",
    INVOKE_VALIDATE_NUMBER="VALIDATE NUMBER",
    INVOKE_VALIDATE_STRING_N_M="VALIDATE STRING(5-10)",
    INVOKE_VALIDATE_NUMBER_N_M="VALIDATE NUMBER(5-10)",
    CRM_CREATE_API_KEY="Created_By",
    SMILEYS_CLASSNAME="cmpnt-rtng",
    LIKE="Like",
    DISLIKE="Dislike",
    DATA_VALUE="data-value",
    SELECT_CLASS_VALUE="sel",
    TIMEZONE="India Standard Time (Asia/Calcutta)",
    TIMESLOT_TIME=TIMESLOT_VALUES[4],
    TIMESLOT_EXPECTED_CONTENT=TIMESLOT_CONTENT[4],
    DATE_TIMESLOT_DATE=DATE_TIME_DATES[1],
    DATE_TIMESLOT_TIME=DATE_TIMESLOT_DAY2_VALUES[0],
    DATE_TIMESLOT_EXPECTED_TIME=DATE_TIMESLOT_DAY2_CONTENT[0],
    DATE_TIMESLOT_EXPECTED_DAY="Wednesday",
    DATE_TIMESLOT_EXPECTED_DATE="August 15",
    TIMESLOT_FORMAT="EEEE, MMMM d, yyyy 'at' hh:mm a",
    DATE_TIMESLOT_FORMAT="EEEE MMMM d, yyyy 'at' hh:mm a",
    SELECTED_DATE_CLASS="selectedday",
    SELECTED_RANGE_CLASS="selectedrange",
    ENABLED_DATE_CLASS="normalday",
    DISABLED_DATE_CLASS="disabledday",
    QUESTION1="question1?",
    QUESTION2="question2?",
    QUESTION3="question3?",
    QUESTION4="question4?",
    QUESTION5="question5?",
    QUESTION6="question6?",
    LINKS_HEADER_TEXT="Links",
    LINK1="https://www.google.com",
    LINK2="https://salesiq.zoho.com",
    LINK1_TEXT="1_<bot_reply>",
    LINK2_TEXT="2_<bot_reply>",
    LINK1_ICON="https://img.icons8.com/color/2x/google-logo.png",
    LINK2_ICON="https://image.freepik.com/free-icon/facebook_318-136394.jpg",
    IMAGE_WIDGET_URL="https://img.icons8.com/color/2x/google-logo.png",
    ARTICLE_ID_PARAM="article-id"
    ;

    public static final By
    SKIPPABLE=By.id("skipquestion"),
    RANGE_DISPLAY=By.id("range-display"),
    SUBMIT_SLIDER_VALUE=By.id("range-selected"),
    SMILEYS=By.className(SMILEYS_CLASSNAME),
    LIKE_RATING=By.id("like-rating"),
    DISLIKE_RATING=By.id("dislike-rating"),
    STAR=By.className("sqico-star"),
    MULTISELECT=By.id("multiselect"),
    SINGLESELECT=By.id("singleselect"),
    SELECT_VALUE=By.cssSelector("["+DATA_VALUE+"]"),
    MULTISELECT_CONFIRM_BUTTON=By.id("cnfmsel"),
    UNSELECTED_SELECT_VALUE=By.cssSelector("[data-value]:not([class*='sel'])"),
    DATE_ELEMENT=By.className("cmpnt-cal-date"),
    BACK_ARROW=By.className("sqico-larrow"),
    TIMEZONE_DROPDOWN=By.id("tz_drpdown"),
    TIMEZONE_SEARCH=By.className("zsiq-time-srch"),
    TIMEZONE_SEARCH_VALUES=By.cssSelector("[data-target='timezone']"),
    SCHEDULE_BUTTON_FOR_SLOT_WIDGET=By.id("bot_timeslot"),
    TIMESLOT_CONFIRM_BUTTON=By.id("confirm"),
    CALENDAR_CONTAINER=By.id("bot_calender"),
    DATE_PICKER_CONTAINER=By.id("datepicker_body"),
    SET_TIME=By.className("calndr-settime"),
    CALENDAR_SET_VALUE=By.className("calndr-setval"),
    ACTIVE_AM_PM=By.className("active"),
    CALENDAR_TIMEZONE=By.cssSelector("[data-target='showtzlist']"),
    CALENDAR_DATE=By.cssSelector("[data-target='date']"),
    CALENDAR_SCHEDULE_BUTTON=By.cssSelector("[data-target='schedule']"),
    LINKS_HEADER=By.className("cmpnt-desc"),
    LINKS_ELE=By.cssSelector("a[data-value]"),
    ARTICLES_DESCRIPTION=By.className("cmpnt-desc"),
    // ARTICLES_TITLE=By.className("cmpnt-hdln"),
    BOT_WIDGET_INNER=By.cssSelector("[id*=bot_widget]"),
    ARTICLE_NAME_CONTAINERS=By.cssSelector("span[article-id]")
    ;

    public static final int
    MAX_MULTISELECT_VALUE=5,
    SELECTED_DATE=0,
    ENABLED_DATE=1,
    DISABLED_DATE=2
    ;

    //Articles Widget
    public static boolean openArticle(WebDriver driver,ExtentTest etest,String label)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        List<WebElement> articles=CommonUtil.getElements(message,ARTICLE_NAME_CONTAINERS);
        WebElement article_link=CommonUtil.getElementByAttributeValue(articles,"innerText",label);

        if(article_link==null)
        {
            throw new ZohoSalesIQRuntimeException("Could not find article with label '"+label+"' in articles widget.");
        }

        CommonUtil.clickWebElement(driver,article_link);

        etest.log(Status.INFO,"Article '"+label+"' was opened from articles widget.");

        return ArticlesVisitorSide.waitTillArticlePreviewDisplayed(driver);
    }

    public static boolean isArticlePresent(WebDriver driver,ExtentTest etest,String article_id,boolean expectedIsDisplayed)
    {
        By locator=By.cssSelector("["+ARTICLE_ID_PARAM+"='"+article_id+"']");

        if(CommonWait.isDisplayed(driver,locator)==expectedIsDisplayed)
        {
            etest.log(Status.PASS,"Article with article id '"+article_id+"' was "+(expectedIsDisplayed?"found":"NOT found")+".");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Article with article id '"+article_id+"' was "+(expectedIsDisplayed?"NOT found":"found")+".");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static boolean checkArticlesWidgetContent(WebDriver driver,ExtentTest etest,String expected_heading,String expected_description)
    {
        int failcount=0;

        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        String heading=CommonUtil.getElement(message,ARTICLES_DESCRIPTION).getAttribute("innerText");
        String description=CommonUtil.getElement(message,BOT_WIDGET_INNER,ARTICLES_DESCRIPTION).getAttribute("innerText");

        if(CommonUtil.checkStringContainsAndLog(expected_heading,heading,"article heading",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_description,description,"article description",etest)==false)
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    //Image Widget
    public static boolean checkImageWidget(WebDriver driver,ExtentTest etest,String expected_image_text,String expected_image_src)
    {
        int failcount=0;

        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        String text=message.getAttribute("innerText");
        String image_src=CommonUtil.getElement(message,By.tagName("img")).getAttribute("src");

        if(CommonUtil.checkStringContainsAndLog(expected_image_text,text,"image text",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_image_src,image_src,"image src",etest)==false)
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    //Link Widget
    public static boolean checkLinkWidgetContent(WebDriver driver,ExtentTest etest,String expected_header)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        String actual_header=CommonUtil.getElement(message,LINKS_HEADER).getAttribute("innerText");
        return CommonUtil.checkStringContainsAndLog(expected_header,actual_header,"link widget header",etest);
    }

    public static boolean checkExpectedLinkFound(WebDriver driver,ExtentTest etest,int index,String expected_link_text,String expected_link_target,String expected_image_src)
    {
        int failcount=0;

        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        WebElement link=CommonUtil.getElements(message,LINKS_ELE).get(index);

        String link_text=link.getAttribute("innerText");
        String link_target=link.getAttribute("href");
        String image_src=CommonUtil.getElement(link,By.tagName("img")).getAttribute("src");

        if(CommonUtil.checkStringContainsAndLog(expected_link_text,link_text,"link text",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_link_target,link_target,"link href",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_image_src,image_src,"link icon src",etest)==false)
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    //Slider and Range Slider

    public static boolean checkSliderWidgetSelectValues(WebDriver driver,ExtentTest etest)
    {
        int failcount=0;

        WebElement slider=VisitorWindow.getLastAgentMessageElement(driver);

        etest.log(Status.INFO,"Selecting slider values from left to right now.");

        for(int i=0;i<SLIDER_WIDGET_VALUES.length;i++)
        {
            String slider_value=SLIDER_WIDGET_VALUES[i];

            if(clickSliderValue(driver,slider,slider_value))
            {
                etest.log(Status.PASS,"We are able to select slider value '"+slider_value+"' when selecting from left to right");
            }
            else
            {
                etest.log(Status.FAIL,"We are NOT able to select slider value '"+slider_value+"' when selecting from left to right");
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }

        //reset
        clickSliderValue(driver,slider,SLIDER_WIDGET_VALUES[0]);

        for(int i=(SLIDER_WIDGET_VALUES.length-1);i>=0;i--)
        {
            String slider_value=SLIDER_WIDGET_VALUES[i];

            if(clickSliderValue(driver,slider,slider_value))
            {
                etest.log(Status.PASS,"We are able to select slider value '"+slider_value+"' when selecting from right to left");
            }
            else
            {
                etest.log(Status.FAIL,"We are NOT able to select slider value '"+slider_value+"' when selecting from right to left");
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean clickSliderValue(WebDriver driver,WebElement slider,String value)
    {
        By locator=By.cssSelector(".range-dot[title='"+value+"']");
        WebElement element=CommonUtil.getElement(slider,locator);
        CommonWait.waitTillDisplayed(element);

        CommonUtil.mouseHoverAndClick(driver,element);

        WebElement range_display=CommonUtil.getElement(slider,RANGE_DISPLAY);
        return CommonUtil.waitTillWebElementContainsAttributeValue(range_display,"innerText",value);
    }

    public static boolean submitSliderValue(WebDriver driver,ExtentTest etest,String value)
    {
        WebElement slider=VisitorWindow.getLastAgentMessageElement(driver);
        clickSliderValue(driver,slider,value);

        WebElement submit=CommonUtil.getElement(slider,SUBMIT_SLIDER_VALUE);
        CommonUtil.mouseHoverAndClick(driver,submit);
        CommonWait.waitTillHidden(submit);

        CommonUtil.sleep(100);

        String visitor_message=VisitorWindow.getLastVisitorMessage(driver);

        return CommonUtil.checkStringContainsAndLog(value,visitor_message,"slider widget value sent as visitor message",etest);
    }

    public static boolean checkRangeSliderWidgetSelectValues(WebDriver driver,ExtentTest etest)
    {
        int failcount=0;

        WebElement slider=VisitorWindow.getLastAgentMessageElement(driver);

        etest.log(Status.INFO,"Selecting slider values from left to right now.");

        int start=2,end=RANGE_SLIDER_VALUES.length;

        for(int i=start;i<end;i++)
        {
            String slider_value=RANGE_SLIDER_VALUES[i];

            if(clickSliderValue(driver,slider,slider_value))
            {
                etest.log(Status.PASS,"We are able to select slider value '"+slider_value+"' when selecting from left to right");
            }
            else
            {
                etest.log(Status.FAIL,"We are NOT able to select slider value '"+slider_value+"' when selecting from left to right");
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }


        start=1;end=RANGE_SLIDER_VALUES.length-1;

        for(int i=start;i<end;i++)
        {
            String slider_value=RANGE_SLIDER_VALUES[i];

            if(clickSliderValue(driver,slider,slider_value))
            {
                etest.log(Status.PASS,"We are able to select slider value '"+slider_value+"' when selecting from left to right");
            }
            else
            {
                etest.log(Status.FAIL,"We are NOT able to select slider value '"+slider_value+"' when selecting from left to right");
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }

        start=RANGE_SLIDER_VALUES.length-3;end=0;

        for(int i=start;i>=end;i--)
        {
            String slider_value=RANGE_SLIDER_VALUES[i];

            if(clickSliderValue(driver,slider,slider_value))
            {
                etest.log(Status.PASS,"We are able to select slider value '"+slider_value+"' when selecting from right to left");
            }
            else
            {
                etest.log(Status.FAIL,"We are NOT able to select slider value '"+slider_value+"' when selecting from right to left");
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }


        start=RANGE_SLIDER_VALUES.length-2;end=1;

        for(int i=start;i>=end;i--)
        {
            String slider_value=RANGE_SLIDER_VALUES[i];

            if(clickSliderValue(driver,slider,slider_value))
            {
                etest.log(Status.PASS,"We are able to select slider value '"+slider_value+"' when selecting from right to left");
            }
            else
            {
                etest.log(Status.FAIL,"We are NOT able to select slider value '"+slider_value+"' when selecting from right to left");
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }


    public static boolean submitRangeSliderMaxValue(WebDriver driver,ExtentTest etest)
    {
        WebElement slider=VisitorWindow.getLastAgentMessageElement(driver);

        String value1=RANGE_SLIDER_VALUES[0];
        String value2=RANGE_SLIDER_VALUES[RANGE_SLIDER_VALUES.length-1];

        clickSliderValue(driver,slider,value1);
        clickSliderValue(driver,slider,value2);

        WebElement submit=CommonUtil.getElement(slider,SUBMIT_SLIDER_VALUE);
        CommonUtil.mouseHoverAndClick(driver,submit);
        CommonWait.waitTillHidden(submit);

        CommonUtil.sleep(100);

        String visitor_message=VisitorWindow.getLastVisitorMessage(driver);
        String expected=value1+" - "+value2;

        return CommonUtil.checkStringContainsAndLog(expected,visitor_message,"range slider widget value sent as visitor message",etest);
    }

    //Happiness Rating

    //check if expected smileys are displayed as per level value
    public static boolean checkHappinessRating(WebDriver driver,ExtentTest etest,int level)
    {
        int failcount=0;

        WebElement happiness_rating=VisitorWindow.getLastAgentMessageElement(driver);

        List<WebElement> smiley_elements=CommonUtil.getElements(happiness_rating,SMILEYS);

        if(smiley_elements.size()==level)
        {
            etest.log(Status.PASS,smiley_elements.size()+" smileys were found for happiness rating level "+level);
        }
        else
        {
            etest.log(Status.FAIL,smiley_elements.size()+" smileys were found for happiness rating level "+level);
            TakeScreenshot.infoScreenshot(driver,etest);
            failcount++;
        }

        if(level==5)
        {
            checkHappinessRatingSmileysSikuli(driver,etest);
        }

        int begin_index=level==5?0:2;

        for(int i=0;i<smiley_elements.size();i++)
        {
            WebElement smiley_element=smiley_elements.get(i);

            String expected_classname=HAPPINESS_RATING_LEVEL5_CLASS_NAMES[begin_index+i];

            if(CommonUtil.hasClass(smiley_element,expected_classname))
            {
                etest.log(Status.PASS,"Expected smiley class (actual : "+smiley_element.getAttribute("class")+" expected : "+expected_classname+") name was found for happiness rating level "+level);
            }
            else
            {       
                etest.log(Status.FAIL,"Expected smiley class (actual : "+smiley_element.getAttribute("class")+" expected : "+expected_classname+") name was NOT found for happiness rating level "+level);
                TakeScreenshot.screenshot(driver,etest);
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static void checkHappinessRatingSmileysSikuli(WebDriver driver,ExtentTest etest)
    {
        //for level 5 only
        CommonSikuli.findInWholePage(driver,"UI446.png","UI446",etest);
        CommonSikuli.findInWholePage(driver,"UI447.png","UI447",etest);
        CommonSikuli.findInWholePage(driver,"UI448.png","UI448",etest);
        CommonSikuli.findInWholePage(driver,"UI449.png","UI449",etest);
        CommonSikuli.findInWholePage(driver,"UI450.png","UI450",etest);
    }

    //select rating value
    public static boolean selectHappinessRatingValue(WebDriver driver,ExtentTest etest,int level,int value)
    {
        //enter value between 0-4

        int failcount=0;

        int begin_index=level==5?0:2;

        WebElement happiness_rating=VisitorWindow.getLastAgentMessageElement(driver);

        String classname=HAPPINESS_RATING_LEVEL5_CLASS_NAMES[begin_index+value];

        WebElement smiley=null;

        if(classname.equals(SMILEYS_CLASSNAME)==false)
        {
            smiley=CommonUtil.getElement(happiness_rating,By.className(classname));
        }
        else
        {
            //special case
            smiley=CommonUtil.getElement(happiness_rating,By.cssSelector("[class='"+classname+"']"));            
        }

        CommonUtil.mouseHoverAndClick(driver,smiley);

        CommonWait.waitTillHidden(smiley);

        CommonUtil.sleep(100);

        String visitor_message=VisitorWindow.getLastVisitorMessage(driver);
        String expected_value=HAPPINESS_RATING_LEVEL5_VALUES[begin_index+value];

        return CommonUtil.checkStringContainsAndLog(expected_value,visitor_message,"happiness-rating value sent as visitor message",etest);
    }

    //Like widget
    public static boolean selectLikeValue(WebDriver driver,ExtentTest etest,boolean isLike)
    {
        String value=isLike?LIKE:DISLIKE;

        WebElement like_widget=VisitorWindow.getLastAgentMessageElement(driver);

        By locator=isLike?LIKE_RATING:DISLIKE_RATING;

        WebElement button=CommonUtil.getElement(driver,locator);

        CommonUtil.mouseHoverAndClick(driver,button);

        CommonWait.waitTillHidden(button);

        CommonUtil.sleep(100);

        String visitor_message=VisitorWindow.getLastVisitorMessage(driver);

        return CommonUtil.checkStringContainsAndLog(value,visitor_message,"like rating value sent as visitor message",etest);

    }

    //Star rating widget

    //get no of stars
    public static int getStarsCount(WebDriver driver)
    {
        WebElement star_rating_message=VisitorWindow.getLastAgentMessageElement(driver);
        return CommonUtil.getElements(star_rating_message,STAR).size();
    }

    //check expected no of stars are found
    public static boolean checkStars(WebDriver driver,ExtentTest etest,int level)
    {        
        int no_of_stars=getStarsCount(driver);
        return CommonUtil.checkStringEqualsAndLog(level+"",no_of_stars+"","no of stars in star rating",etest);
    }

    //select star
    public static boolean selectStar(WebDriver driver,ExtentTest etest,int star_rating)
    {
        WebElement star_rating_message=VisitorWindow.getLastAgentMessageElement(driver);

        By locator=By.cssSelector("[star-count='"+star_rating+"']");

        WebElement star=CommonUtil.getElement(star_rating_message,locator);

        CommonUtil.scrollIntoView(driver,true,star);

        CommonUtil.sleep(500);

        CommonUtil.mouseHoverAndClick(driver,star);

        CommonWait.waitTillHidden(star);

        CommonUtil.sleep(100);

        String visitor_message=VisitorWindow.getLastVisitorMessage(driver);

        return CommonUtil.checkStringContainsAndLog(star_rating+"",visitor_message,"star rating value sent as visitor message",etest);        
    }

    //Common widget methods
    public static boolean checkSkippable(WebDriver driver,ExtentTest etest,boolean isSkippable)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        final String
        success_log=isSkippable?"found":"NOT found",
        failure_log=isSkippable?"NOT found":"found";

        if(CommonWait.isPresent(message,SKIPPABLE)==isSkippable)
        {
            etest.log(Status.PASS,"Skippable button was "+success_log+" after skippable was given as "+isSkippable);
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Skippable button was "+failure_log+" after skippable was given as "+isSkippable);
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    //select

    //check all values
    public static boolean checkAllSelectWidgetValues(WebDriver driver,ExtentTest etest,String[] expected_values)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        List<WebElement> select_elements=CommonUtil.getElements(message,SELECT_VALUE);
        List<String> select_values=CommonUtil.getAttributesFromList(select_elements,"innerText");
        return CommonUtil.compareList( Arrays.asList(expected_values) , select_values , "select widget values" , etest );
    }

    public static WebElement getSelectWidgetValueElement(WebElement message,String value)
    {
        By locator=By.cssSelector("[data-value='"+value+"']");

        return CommonUtil.getElement(message,locator);
    }

    //select a value
    public static boolean selectValue(WebDriver driver,ExtentTest etest,String value)
    {
        return selectValue(driver,null,etest,value);
    }

    public static boolean selectValue(WebDriver driver,WebElement message,ExtentTest etest,String value)
    {
        if(message==null)
        {
            message=VisitorWindow.getLastAgentMessageElement(driver);
        }
        
        WebElement value_ele=getSelectWidgetValueElement(message,value);
        CommonUtil.mouseHoverAndClick(driver,value_ele);

        etest.log(Status.INFO,value+" was selected from the select widget");

        if(isMultiSelect(message))
        {
            return CommonUtil.waitTillWebElementContainsAttributeValue(value_ele,"class",SELECT_CLASS_VALUE);
        }
        else
        {
            CommonWait.waitTillHidden(value_ele);

            CommonUtil.sleep(100);

            String message_value=VisitorWindow.getLastVisitorMessage(driver).trim();

            return CommonUtil.checkStringContainsAndLog(value,message_value,"single select value sent in message",etest);
        }
    }

    //for multiselect
    public static boolean unselectValue(WebDriver driver,ExtentTest etest,String value)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        WebElement value_ele=getSelectWidgetValueElement(message,value);
        boolean isSelectValueSelected=isSelectValueSelected(value_ele);
        CommonUtil.mouseHoverAndClick(driver,value_ele);

        if(isSelectValueSelected)
        {
            etest.log(Status.INFO,value+" was unselected from the select widget");
        }
        else
        {
            etest.log(Status.INFO,value+" was clicked in the select widget.");
        }

        return CommonUtil.waitTillWebElementDoesNotContainAttributeValue(message,"class",SELECT_CLASS_VALUE);
    }

    public static boolean isUnableToSelect(WebDriver driver,ExtentTest etest,String value)
    {
        return unselectValue(driver,etest,value);//same flow as unselect.
    }


    public static boolean isSingleSelect(WebDriver driver)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        return CommonWait.isPresent(message,SINGLESELECT);
    }

    public static boolean isMultiSelect(WebDriver driver)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        return isMultiSelect(message);
    }

    public static boolean isMultiSelect(WebElement message)
    {
        return CommonWait.isPresent(message,MULTISELECT);
    }

    //Multi select

    //select values
    public static boolean selectMultipleValuesAndPost(WebDriver driver,ExtentTest etest,String[] values_to_select,Integer bot_type)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        for(String value : values_to_select)
        {
            selectValue(driver,message,etest,value);
        }

        if(bot_type!=null)
        {
            String usecase=new String[] {"BOTS92","BOTS143","BOTS217","BOTS267","BOTS332"}[bot_type];

            if(bot_type==BotsWidgets.DIALOGFLOW_BOT)
            {
                if(values_to_select.length==MAX_MULTISELECT_VALUE && CommonUtil.isChecked(usecase,com.zoho.livedesk.client.bots.DialogflowBotsWidgets.result)==false)
                {
                    com.zoho.livedesk.client.bots.DialogflowBotsWidgets.result.put(usecase,checkUnableToSelectAfterMaxSelection(driver,etest));
                }
            }
            else if(bot_type==BotsWidgets.ZIA_BOT)
            {
                if(values_to_select.length==MAX_MULTISELECT_VALUE && CommonUtil.isChecked(usecase,com.zoho.livedesk.client.bots.ZiaTests.result)==false)
                {
                    com.zoho.livedesk.client.bots.ZiaTests.result.put(usecase,checkUnableToSelectAfterMaxSelection(driver,etest));
                }
            }
            else if(bot_type==BotsWidgets.SALESIQ_BOT)
            {
                if(values_to_select.length==MAX_MULTISELECT_VALUE && CommonUtil.isChecked(usecase,com.zoho.livedesk.client.bots.BotsWidgets.result)==false)
                {
                    com.zoho.livedesk.client.bots.BotsWidgets.result.put(usecase,checkUnableToSelectAfterMaxSelection(driver,etest));
                }
            }
        }

        WebElement confirm=CommonUtil.getElement(driver,MULTISELECT_CONFIRM_BUTTON);

        CommonUtil.mouseHoverAndClick(driver,confirm);

        CommonWait.waitTillHidden(confirm);  

        CommonUtil.sleep(100);
        
        String visitor_message=VisitorWindow.getLastVisitorMessage(driver).trim();

        List<String> actual_values=Arrays.asList(visitor_message.split(","));
        List<String> expected_values=Arrays.asList(values_to_select);

        int failcount=0;

        for(int i=0;i<expected_values.size();i++)
        {
            String expected_value=expected_values.get(i);
            String actual_value=actual_values.get(i);

            if(CommonUtil.checkStringContainsAndLog(expected_value,actual_value,"Multiselect values chosen by visitor",etest)==false)
            {
                failcount++;
            }
        }

        if(failcount>0)
        {
            TakeScreenshot.screenshot(driver,etest);
        }

        return CommonUtil.returnResult(failcount);
    } 

    //Select and unselect
    public static Hashtable<String,Boolean> checkSelectAndUnselectMultiselectWidget(WebDriver driver,ExtentTest etest)
    {
        Hashtable<String,Boolean> select_result=new Hashtable<String,Boolean>();

        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        String value=MULTISELECT_VALUE_SET1[0];

        WebElement select_value=getSelectWidgetValueElement(message,value);

        //select the value
        selectValue(driver,etest,value);

        select_result.put("IS_SELECTED",isSelectedStateIconFound(select_value,etest,true));

        unselectValue(driver,etest,value);

        select_result.put("IS_UNSELECTED",isSelectedStateIconFound(select_value,etest,false));

        TakeScreenshot.infoScreenshot(driver,etest);

        return select_result;
    }

    public static boolean isSelectValueSelected(WebElement element)
    {
        return CommonUtil.hasClass(element,SELECT_CLASS_VALUE);
    }

    public static boolean isSelectedStateIconFound(WebElement element,ExtentTest etest,boolean isSelected)
    {
        if(isSelectValueSelected(element)==isSelected)
        {
            etest.log(Status.PASS,(isSelected?"Selected":"Unselected")+" element was found with "+(isSelected?"Selected":"Unselected")+" state icon");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,(isSelected?"Selected":"Unselected")+" element was NOT found with "+(isSelected?"Selected":"Unselected")+" state icon"); 
            return false;
        }  
    }

    //Check unable to select
    public static boolean checkUnableToSelectAfterMaxSelection(WebDriver driver,ExtentTest etest)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        WebElement unselected_ele=CommonUtil.getElement(message,UNSELECTED_SELECT_VALUE);

        if(unselected_ele==null)
        {
            etest.log(Status.WARNING,"Unable to find any unselected element");
        }

        String unselected_value=unselected_ele.getAttribute("innerText").trim();

        if(isUnableToSelect(driver,etest,unselected_value))
        {
            etest.log(Status.PASS,"Unable to select any values after max selection limit was reached");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Able to select any values after max selection limit was reached");     
            TakeScreenshot.screenshot(driver,etest);     
            return false;  
        }
    }

    //check time-slot expected values are shown for dt and t slots
    public static boolean checkTimeSlotValues(WebDriver driver,ExtentTest etest,String[] values_added_in_code,String[] expected_contents)
    {
        int failcount=0;

        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        for(int i=0;i<values_added_in_code.length;i++)
        {
            String expected_content=expected_contents[i];

            String time_param=values_added_in_code[i];
            String actual_content=CommonUtil.getElement(message,By.cssSelector("[time='"+time_param+"']")).getAttribute("innerText");

            if(CommonUtil.checkStringContainsAndLog(expected_content,actual_content,"time value in time slots UI",etest)==false)
            {
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    //select a timezone,timeslot and check if selected value is posted
    public static Hashtable<String,Boolean> checkSelectTimeslot(WebDriver driver,ExtentTest etest,boolean isTimezoneEnabled)
    {
        Hashtable<String,Boolean> select_values_result=new Hashtable<String,Boolean>();

        int failcount=0;

        WebElement widget_message=VisitorWindow.getLastAgentMessageElement(driver);


        String timezone_param_usecase=isTimezoneEnabled?"BOTS96":"BOTS98";

        if(checkTimezoneParam(driver,etest,isTimezoneEnabled)==false)
        {
            select_values_result.put("IS_TIMEZONE_SHOWN",false);
        }
        else
        {
            select_values_result.put("IS_TIMEZONE_SHOWN",true);
        }

        if(isTimezoneEnabled)
        {
            if(selectTimeZone(driver,etest,TIMEZONE)==false)
            {
                select_values_result.put("IS_TIMEZONE_SELECTED",false);
            }
            else
            {
                select_values_result.put("IS_TIMEZONE_SELECTED",true);
            }
        }

        if(selectTimeSlot(driver,widget_message,etest,TIMESLOT_TIME)==false)
        {
            etest.log(Status.FAIL,"Timeslot value was not selected as "+TIMESLOT_TIME);
            TakeScreenshot.screenshot(driver,etest);
            failcount++;
        }

        clickConfirmButtonInSlotsWidget(driver);

        String message=VisitorWindow.getLastVisitorMessage(driver);

        if(checkTimeslotMessage(driver,etest,TIMESLOT_TIME,TIMESLOT_FORMAT,isTimezoneEnabled)==false)
        {
            failcount++;
        }

        if(isTimezoneEnabled)
        {
            if(CommonUtil.checkStringContainsAndLog(TIMEZONE,getTimeZoneNameFromMessage(message),"timezone value sent in message",etest)==false)
            {
                failcount++;
            }
        }

        String expected_day=DateTimeUtil.getCurrentTimeInFormat("EEEE");
        String expected_date=DateTimeUtil.getCurrentTimeInFormat("MMMM d");
        String expected_time=TIMESLOT_EXPECTED_CONTENT;


        if(CommonUtil.checkStringContainsAndLog(expected_day,message,"day value sent in message",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_date,message,"date value sent in message",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_time,message,"time value sent in message",etest)==false)
        {
            failcount++;
        }

        select_values_result.put("IS_TIMESLOTS_CHECKED",CommonUtil.returnResult(failcount));

        return select_values_result;
    }

    public static Hashtable<String,Boolean> checkSelectDateTimeslot(WebDriver driver,ExtentTest etest,boolean isTimezoneEnabled)
    {
        Hashtable<String,Boolean> select_result=new Hashtable<String,Boolean>();

        int failcount=0;

        WebElement widget_message=VisitorWindow.getLastAgentMessageElement(driver);

        if(checkTimezoneParam(driver,etest,isTimezoneEnabled)==false)
        {
            select_result.put("IS_TIMEZONE_SHOWN",false);
        }
        else
        {
            select_result.put("IS_TIMEZONE_SHOWN",true);            
        }
        if(isTimezoneEnabled)
        {
            if(selectTimeZone(driver,etest,TIMEZONE)==false)
            {
               failcount++;
            }
        }

        if(selectDateFromDateTimeSlot(driver,etest,DATE_TIMESLOT_DATE)==false)
        {
            failcount++;
        }

        if(selectTimeSlot(driver,widget_message,etest,DATE_TIMESLOT_TIME)==false)
        {
            etest.log(Status.FAIL,"Timeslot value was not selected as "+DATE_TIMESLOT_TIME);
            TakeScreenshot.screenshot(driver,etest);
            failcount++;
        }

        clickConfirmButtonInSlotsWidget(driver);

        String message=VisitorWindow.getLastVisitorMessage(driver);

        if(checkTimeslotMessage(driver,etest,DATE_TIMESLOT_TIME,DATE_TIMESLOT_FORMAT,isTimezoneEnabled)==false)
        {
            failcount++;
        }

        if(isTimezoneEnabled)
        {
            if(CommonUtil.checkStringContainsAndLog(TIMEZONE,getTimeZoneNameFromMessage(message),"timezone value sent in message",etest)==false)
            {
                failcount++;
            }
        }

        String expected_day=DATE_TIMESLOT_EXPECTED_DAY;
        String expected_date=DATE_TIMESLOT_EXPECTED_DATE;
        String expected_time=DATE_TIMESLOT_EXPECTED_TIME;

        if(CommonUtil.checkStringContainsAndLog(expected_day,message,"day value sent in message",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_date,message,"date value sent in message",etest)==false)
        {
            failcount++;
        }

        if(CommonUtil.checkStringContainsAndLog(expected_time,message,"time value sent in message",etest)==false)
        {
            failcount++;
        }

        select_result.put("IS_DATETIMESLOTS_CHECKED",CommonUtil.returnResult(failcount));

        return select_result;
    }


    public static boolean selectTimeSlot(WebDriver driver,WebElement message,ExtentTest etest,String time)
    {
        WebElement slot=CommonUtil.getElement(message,By.cssSelector("[time='"+time+"']"));
        CommonWait.waitTillDisplayed(slot);
        CommonUtil.scrollIntoView(driver,true,slot);
        CommonUtil.sleep(500);
        CommonUtil.mouseHoverAndClick(driver,slot);
        etest.log(Status.PASS,"Timeslot was selected as "+time);
        return CommonWait.waitTillHidden(slot);
    }

    public static boolean checkTimeslotMessage(WebDriver driver,ExtentTest etest,String time,String format,boolean isTimezoneEnabled)
    {
        String message=VisitorWindow.getLastVisitorMessage(driver);

        if(DateTimeUtil.isValidFormat(format,getDateAndTimeFromWidgetMessage(message)))
        {
            etest.log(Status.PASS,"Timeslot message was found with the expected date format");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Timeslot message was NOT found with the expected date format");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static boolean selectTimeZone(WebDriver driver,ExtentTest etest,String timezone)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        WebElement tz_dropdown=CommonUtil.getElement(message,TIMEZONE_DROPDOWN);
        CommonUtil.mouseHoverAndClick(driver,tz_dropdown);
        CommonWait.waitTillDisplayed(message,TIMEZONE_SEARCH);

        WebElement input=CommonUtil.getElement(message,TIMEZONE_SEARCH,By.tagName("input"));

        CommonUtil.sendKeysToWebElement(driver,input,timezone);

        CommonWait.waitTillDisplayed(message,TIMEZONE_SEARCH_VALUES);

        WebElement value=CommonUtil.getElement(message,TIMEZONE_SEARCH_VALUES);

        CommonUtil.mouseHoverAndClick(driver,value);

        CommonWait.waitTillHidden(value);

        tz_dropdown=CommonUtil.getElement(message,TIMEZONE_DROPDOWN);

        if(CommonUtil.waitTillWebElementContainsAttributeValue(tz_dropdown,"innerText",timezone))
        {
            etest.log(Status.PASS,"Timezone '"+timezone+"' was selected from the widget.");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Timezone '"+timezone+"' was NOT selected from the widget.");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    //check if timezone is shown
    public static boolean checkTimezoneParam(WebDriver driver,ExtentTest etest,boolean isTimezoneEnabled)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        //CommonWait.isDisplayed(message,TIMEZONE_DROPDOWN)==isTimezoneEnabled  
        if(CommonUtil.getElement(driver,TIMEZONE_DROPDOWN).getAttribute("innerText").contains("GMT")==isTimezoneEnabled)
        {
            etest.log(Status.PASS,"Timezone dropdown was "+(isTimezoneEnabled?"shown":"NOT shown")+" after tz param was set as "+isTimezoneEnabled);
            return true;
        }
        else
        {           
            etest.log(Status.FAIL,"Timezone dropdown was "+(isTimezoneEnabled?"NOT shown":"shown")+" after tz param was set as "+isTimezoneEnabled);
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    //select a date frod d&t slot
    public static boolean selectDateFromDateTimeSlot(WebDriver driver,ExtentTest etest,String date)
    {
        //date in dd/MM/yyyy format
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        By locator = By.cssSelector("[date='"+date+"']");
        WebElement date_ele=CommonUtil.getElement(message,locator);
        CommonUtil.scrollIntoView(driver,true,date_ele);
        CommonUtil.sleep(500);
        CommonUtil.mouseHoverAndClick(driver,date_ele);
        etest.log(Status.INFO,date+" was chosen as date in date-time slots widget");
        return CommonWait.waitTillHidden(date_ele);
    }

    public static boolean goToDateSelectFromTimeSelectForDateTimeSlot(WebDriver driver)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        WebElement back=CommonUtil.getElement(message,BACK_ARROW);
        CommonWait.waitTillDisplayed(back);
        CommonUtil.mouseHoverAndClick(driver,back);

        return CommonWait.waitTillHidden(back);
    }

    public static boolean clickScheduleButtonInSlotsWidget(WebDriver driver)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        WebElement schedule=CommonUtil.getElement(message,SCHEDULE_BUTTON_FOR_SLOT_WIDGET);
        CommonWait.waitTillDisplayed(schedule);
        CommonUtil.scrollIntoView(driver,true,schedule);
        CommonUtil.sleep(500);
        CommonUtil.mouseHoverAndClick(driver,schedule);
        return CommonWait.waitTillHidden(schedule);
    }

    public static boolean clickConfirmButtonInSlotsWidget(WebDriver driver)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        WebElement confirm=CommonUtil.getElement(message,TIMESLOT_CONFIRM_BUTTON);
        CommonWait.waitTillDisplayed(confirm);
        CommonUtil.mouseHoverAndClick(driver,confirm);
        return CommonWait.waitTillHidden(confirm);
    }

    //parse dates
    public static String getDateAndTimeFromWidgetMessage(String message)
    {       
        String dateAndTime=null;
        
        if(message.contains(" PM"))
        {
            dateAndTime=message.substring(0, message.lastIndexOf(" PM")+3 );
            
            if(dateAndTime.endsWith(" PM"))
            {
                return dateAndTime;
            }
        }
        
        else if(message.contains(" AM"))
        {
            dateAndTime=message.substring(0, message.lastIndexOf(" AM")+3 );
            
            if(dateAndTime.endsWith(" AM"))
            {
                return dateAndTime;
            }       
        }
        
        if(dateAndTime==null)
        {
            throw new ZohoSalesIQRuntimeException("Could not parse date and time from message : "+message);
        }

        return dateAndTime;
    }
    
    public static String getTimezoneFromMessage(String message)
    {       
        String dateAndTime=null;
        
        if(message.contains(" PM"))
        {           
            dateAndTime=message.substring( message.lastIndexOf(" PM")+4,message.length());
            return dateAndTime;         
        }
        
        else if(message.contains(" AM"))
        {
            dateAndTime=message.substring( message.lastIndexOf(" AM")+4,message.length());
            return dateAndTime;         
        }
        
        if(dateAndTime==null)
        {
            throw new ZohoSalesIQRuntimeException("Could not parse time zone from message : "+message);
        }

        return dateAndTime;
    }
    
    public static String getTimeZoneNameFromMessage(String message)
    {
        String tz=getTimezoneFromMessage(message).trim();
        return tz.substring(tz.indexOf(" ")+1, tz.length());
    }

    public static String getTimeZoneValueFromMessage(String message)
    {
        String tz=getTimezoneFromMessage(message).trim();
        return tz.substring(0,tz.indexOf(" "));
    }

    //Calendar

    //check label text
    public static boolean checkCalendarLabelText(WebDriver driver,ExtentTest etest,String expected_label_text)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        String calendar_text=CommonUtil.getElement(message,CALENDAR_CONTAINER).getAttribute("innerText");
        return CommonUtil.checkStringContainsAndLog(expected_label_text,calendar_text,"calendar text",etest);
    }

    //is calendar shown with given date, time and timezone

    public static boolean checkCalendarDate(WebDriver driver,ExtentTest etest)
    {
        String script="function getCurrentDate(){var today = new Date();var dd = today.getDate();var mm = today.getMonth()+1; var yyyy = today.getFullYear();if(dd<10) {dd='0'+dd;} if(mm<10) {mm='0'+mm;}var currentDate = yyyy + '/' + mm + '/' + dd;var mins = today.getMinutes();mins=(mins-(mins%5));if(mins<10) {    mins='0'+mins;}var hours = today.getHours();var meridiem = hours >= 12 ? 'PM' : 'AM';hours = ((hours + 11) % 12 + 1);if(hours<10) {hours='0'+hours;}var currentDateTime = hours + '##' + mins + '##' + meridiem + '###' + currentDate;return currentDateTime;} return getCurrentDate();";
        String time = (((JavascriptExecutor) driver).executeScript(script)).toString();

        etest.info( "Expected time in node " + time );

        String expected_date=time.split("###")[1];

        int mins=Integer.parseInt(time.split("###")[0].split("##")[1]);

        String[] expected_time={time.split("###")[0].split("##")[0],""+mins,time.split("###")[0].split("##")[2]};

        // String expected_date=DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/dd");

        // int mins=Integer.parseInt(DateTimeUtil.getCurrentTimeInFormat("mm"));

        // mins=(mins-(mins%5));//round to lower multiple of 5

        // String[] expected_time={DateTimeUtil.getCurrentTimeInFormat("hh"),""+mins,DateTimeUtil.getCurrentTimeInFormat("a")};
        String expected_timezone=TIMEZONE;
        return checkCalendarDate(driver,etest,expected_date,expected_time,expected_timezone);
    }


    public static boolean openDatePicker(WebDriver driver,ExtentTest etest)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);
        WebElement calendar=CommonUtil.getElement(message,CALENDAR_CONTAINER);
        CommonUtil.scrollIntoView(driver,true,calendar);
        CommonUtil.sleep(500);
        calendar.click();

        etest.log(Status.INFO,"Datepicker UI was opened from calendar widget");

        driver.switchTo().defaultContent();
        return CommonWait.isDisplayed(driver,DATE_PICKER_CONTAINER);
    }

    public static boolean checkCalendarDate(WebDriver driver,ExtentTest etest,String expected_date,String[] expected_time,String expected_timezone)
    {
        //date in yyyy/MM/dd format

        int failcount=0;

        if(expected_date!=null)
        {
            if(CommonUtil.checkStringContainsAndLog(expected_date,getCalendarDate(driver),"calendar date",etest)==false)
            {
                failcount++;
            }
        }

        if(expected_timezone!=null)
        {
            if(CommonUtil.checkStringContainsAndLog(expected_timezone,getCalendarTimezone(driver),"calendar timezone",etest)==false)
            {
                failcount++;
            }
        }
        else
        {
            driver.switchTo().defaultContent();

            if(CommonWait.isHidden(driver,DATE_PICKER_CONTAINER,CALENDAR_TIMEZONE))
            {
                etest.log(Status.PASS,"timezone menu was not found after timezone param was set as false");
            }
            else
            {
                etest.log(Status.FAIL,"timezone menu was found after timezone param was set as false"); 
                TakeScreenshot.screenshot(driver,etest);               
            }
        }

        if(expected_time!=null)
        {
            String[] actual_time=getCalendarTime(driver);

            for(int i=0;i<expected_time.length;i++)
            {
                if(CommonUtil.checkStringContainsAndLog(expected_time[i],actual_time[i],"actual time value",etest)==false)
                {
                    //Below line can be uncommented when hub and node time are same,Currently commented because time is round-off to its nearest 5's value, But the hub and node machines have different times, so tests will fail in grid setup if hub and node times are different
                    //failcount++;
                    etest.log(Status.WARNING,"Test may have failed due to hub time and node time mismatch.");
                }
            }
        }
        else
        {
            driver.switchTo().defaultContent();

            if(CommonWait.isHidden(driver,DATE_PICKER_CONTAINER,SET_TIME))
            {
                etest.log(Status.PASS,"time was not found after time param was set as false");
            }
            else
            {
                etest.log(Status.FAIL,"time was found after time param was set as false");
                TakeScreenshot.screenshot(driver,etest);
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static String getCalendarDate(WebDriver driver)
    {
        return CommonUtil.getElement( getDatePicker(driver) ,By.className(SELECTED_DATE_CLASS)).getAttribute("data");
    }

    public static String[] getCalendarTime(WebDriver driver)
    {
        String hour=null;
        String min=null;
        String am_pm=null;

        WebElement date_picker=getDatePicker(driver);

        List<WebElement> values_set=CommonUtil.getElements(CommonUtil.getElement(date_picker,SET_TIME),CALENDAR_SET_VALUE);

        hour=values_set.get(0).getAttribute("innerText");
        min=values_set.get(1).getAttribute("innerText");
        am_pm=CommonUtil.getElement(date_picker,ACTIVE_AM_PM).getAttribute("innerText");

        return new String[]{hour,min,am_pm};
    }

    public static String getCalendarTimezone(WebDriver driver)
    {
        WebElement date_picker=getDatePicker(driver);
        return CommonUtil.getElement(date_picker,CALENDAR_TIMEZONE).getAttribute("innerText");
    }

    public static WebElement getDatePicker(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        return CommonUtil.getElement(driver,DATE_PICKER_CONTAINER);
    }

    public static int getCalendarDateType(WebDriver driver,String date)
    {
        //date in yyyy/MM/dd format
        String date_class=CommonUtil.getElement( getDatePicker(driver), By.cssSelector("[data='"+date+"']") ).getAttribute("class");

        if(date_class.equals(ENABLED_DATE_CLASS))
        {
            return ENABLED_DATE;
        }
        else if(date_class.equals(DISABLED_DATE_CLASS))
        {
            return DISABLED_DATE;
        }
        else if(date_class.equals(SELECTED_DATE_CLASS) || date_class.equals(SELECTED_RANGE_CLASS))
        {
            return SELECTED_DATE;
        }


        throw new ZohoSalesIQRuntimeException("Unrecognized date class : "+date_class);
    }

    //is dates other than from to range are disabled

    public static boolean isDatesOutsideRangeDisabled(WebDriver driver,ExtentTest etest)
    {
        return isDatesOutsideRangeDisabled(driver,etest,5,5);
    }

    public static boolean isDatesOutsideRangeDisabled(WebDriver driver,ExtentTest etest,int from,int to)
    {


        int failcount=0;

        WebElement date_picker=getDatePicker(driver);
        List<WebElement> enabled_dates=CommonUtil.getElements(date_picker,CALENDAR_DATE);

        int enabled_dates_count = enabled_dates.size();

        int currentSelectedDate = Integer.parseInt(CommonUtil.getElement( getDatePicker(driver) ,By.className(SELECTED_DATE_CLASS)).getText());

        int expected_enabled_dates_count=from+to+1;

        CommonUtil.print("Enabled_Dates_count"+enabled_dates_count);

        if(currentSelectedDate < (from+1))
        {
            CommonUtil.clickWebElement(driver,By.className("calndr-detlvw"),By.className("siqico-larrow"));
            enabled_dates_count += CommonUtil.getElements(getDatePicker(driver),CALENDAR_DATE).size();
            CommonUtil.print("Enabled_Dates_count"+enabled_dates_count);
            etest.log(Status.INFO,"Previous month's view");
            TakeScreenshot.infoScreenshot(driver,etest);
            CommonUtil.clickWebElement(driver,By.className("calndr-detlvw"),By.className("siqico-rarrow"));
        }
        else if(enabled_dates_count < expected_enabled_dates_count)
        {
            CommonUtil.clickWebElement(driver,By.className("calndr-detlvw"),By.className("siqico-rarrow"));
            enabled_dates_count += CommonUtil.getElements(getDatePicker(driver),CALENDAR_DATE).size();
            CommonUtil.print("Enabled_Dates_count"+enabled_dates_count);
            etest.log(Status.INFO,"Next month's view");
            TakeScreenshot.infoScreenshot(driver,etest);
            CommonUtil.clickWebElement(driver,By.className("calndr-detlvw"),By.className("siqico-larrow"));
        }

        enabled_dates=CommonUtil.getElements(date_picker,CALENDAR_DATE);

        //when from and to is not given
        if(from==-1 || to==-1)
        {
            if(enabled_dates.size()>=28)
            {
                etest.log(Status.PASS,"All dates were enabled when from and to is not given");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"All dates were NOT enabled when from and to is not given");      
                return false;          
            }
        }

        //when from and to is given
        if(CommonUtil.checkStringEqualsAndLog(""+expected_enabled_dates_count,""+enabled_dates_count,"enabled dates count for calendar widget",etest)==false)
        {
            failcount++;
        }

        String current_date=DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/dd");

        String selected_date = CommonUtil.getElement( getDatePicker(driver) ,By.className(SELECTED_DATE_CLASS)).getAttribute("data");

        if(CommonUtil.checkStringEqualsAndLog(current_date,selected_date,"Selected date",etest))
        {
            etest.log(Status.PASS,"Only the dates given in the from/to param range was found to be enabled");
        }
        else
        {
            etest.log(Status.FAIL,"Additional dates other than in the from/to param range was found to be enabled");
            TakeScreenshot.screenshot(driver,etest);
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    //set date as
    public static boolean setCalendarDateAs(WebDriver driver,ExtentTest etest)
    {
        String date=DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/dd");
        return setCalendarDateAs(driver,etest,date);
    }

    public static boolean setCalendarDateAs(WebDriver driver,ExtentTest etest,String date)
    {

        WebElement date_picker=getDatePicker(driver);

        By locator=By.cssSelector("[data='"+date+"']");

        WebElement date_ele=CommonUtil.getElement(date_picker,locator);

        CommonUtil.mouseHoverAndClick(driver,date_ele);

        etest.log(Status.INFO,"Date '"+date+"' was selected.");

        date_ele=CommonUtil.getElement(date_picker,locator);

        return CommonUtil.waitTillWebElementContainsAttributeValue(date_ele,"class",SELECTED_DATE_CLASS);
    }

    public static boolean setRangeCalendarDateAs(WebDriver driver,ExtentTest etest)
    {
        return setRangeCalendarDateAs(driver,etest,DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/15"),DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/20"));
    }


    public static boolean setRangeCalendarDateAs(WebDriver driver,ExtentTest etest,String from,String to)
    {
        //from,to date MUST be from same month

        WebElement date_picker=null,date_ele=null;
        By locator=null;

        etest.log(Status.INFO,"Going to set from("+from+") and to date("+to+") now");

        date_picker=getDatePicker(driver);
        locator=By.cssSelector("[data='"+from+"']");
        date_ele=CommonUtil.getElement(date_picker,locator);
        CommonUtil.mouseHoverAndClick(driver,date_ele);
        etest.log(Status.INFO,"from date '"+from+"' was selected.");

        date_picker=getDatePicker(driver);
        locator=By.cssSelector("[data='"+to+"']");
        date_ele=CommonUtil.getElement(date_picker,locator);
        CommonUtil.mouseHoverAndClick(driver,date_ele);
        etest.log(Status.INFO,"to date '"+to+"' was selected.");

        int days=CommonUtil.getElements(driver,By.className(SELECTED_RANGE_CLASS)).size();

        int expected_days=1+Integer.parseInt(to.split("/")[2])-Integer.parseInt(from.split("/")[2]);

        return CommonUtil.checkStringEqualsAndLog(""+expected_days,""+days,"no of days selected",etest);
    }

    //set time as
    public static boolean setCalendarTimeAs(WebDriver driver,ExtentTest etest)
    {
        return setCalendarTimeAs(driver,etest,CALENDAR_TIME1);
    }

    public static boolean setCalendarTimeAs(WebDriver driver,ExtentTest etest,String[] time)
    {
        WebElement date_picker=getDatePicker(driver);

        WebElement hour_dropdown=CommonUtil.getElements(CommonUtil.getElement(date_picker,SET_TIME),CALENDAR_SET_VALUE).get(0);

        CommonUtil.mouseHoverAndClick(driver,hour_dropdown);
        By hour_locator=By.cssSelector("[data-target='hours'][data='"+time[0]+"']");
        CommonWait.waitTillDisplayed(driver,hour_locator);
        WebElement hour=CommonUtil.getElement(date_picker,hour_locator);
        CommonUtil.inViewPort(hour);
        CommonUtil.mouseHoverAndClick(driver,hour);
        CommonWait.waitTillHidden(hour);

        WebElement min_dropdown=CommonUtil.getElements(CommonUtil.getElement(date_picker,SET_TIME),CALENDAR_SET_VALUE).get(1);

        CommonUtil.mouseHoverAndClick(driver,min_dropdown);
        By min_locator=By.cssSelector("[data-target='minutes'][data='"+time[1]+"']");
        CommonWait.waitTillDisplayed(driver,min_locator);
        WebElement min=CommonUtil.getElement(date_picker,min_locator);
        // etest.log(Status.INFO,min_locator.toString()+",min-->"+min.getAttribute("innerHTML'"));
        CommonUtil.inViewPort(min);
        CommonUtil.mouseHoverAndClick(driver,min);
        CommonWait.waitTillHidden(min);

        WebElement am_pm=CommonUtil.getElement(date_picker,By.cssSelector("[data-target='meridiem'][data='"+time[2]+"']"));
        am_pm.click();

        etest.log(Status.INFO,"Time was selected as "+time[0]+":"+time[1]+" "+time[2]);

        am_pm=CommonUtil.getElement(date_picker,By.cssSelector("[data-target='meridiem'][data='"+time[2]+"']"));

        return CommonUtil.waitTillWebElementContainsAttributeValue(am_pm,"class","active");
    }

    public static boolean setRangeCalendarTimeAs(WebDriver driver,ExtentTest etest)
    {
        etest.log(Status.WARNING,"To-time is missing from range calendar widget. Issue in product side");

        return setCalendarTimeAs(driver,etest);
    }

    //set timezone as
    public static boolean selectCalendarTimeZone(WebDriver driver,ExtentTest etest)
    {
        return selectCalendarTimeZone(driver,etest,TIMEZONE);
    }

    public static boolean selectCalendarTimeZone(WebDriver driver,ExtentTest etest,String timezone)
    {
        WebElement date_picker=getDatePicker(driver);
        WebElement tz_dropdown=CommonUtil.getElement(date_picker,CALENDAR_TIMEZONE);
        CommonUtil.mouseHoverAndClick(driver,tz_dropdown);
        CommonWait.waitTillDisplayed(date_picker,TIMEZONE_SEARCH);

        WebElement input=CommonUtil.getElement(date_picker,TIMEZONE_SEARCH,By.tagName("input"));

        CommonUtil.sendKeysToWebElement(driver,input,timezone);

        CommonWait.waitTillDisplayed(date_picker,TIMEZONE_SEARCH_VALUES);

        WebElement value=CommonUtil.getElement(date_picker,TIMEZONE_SEARCH_VALUES);

        CommonUtil.mouseHoverAndClick(driver,value);

        CommonWait.waitTillHidden(value);

        tz_dropdown=CommonUtil.getElement(date_picker,CALENDAR_TIMEZONE);

        if(CommonUtil.waitTillWebElementContainsAttributeValue(tz_dropdown,"innerText",timezone))
        {
            etest.log(Status.PASS,"Timezone '"+timezone+"' was selected from the widget.");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Timezone '"+timezone+"' was NOT selected from the widget.");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }
    //click schedule and check selected time,timezone,date is posted in expected format
    public static boolean checkCalendarSchedule(WebDriver driver,ExtentTest etest)
    {
        return checkCalendarSchedule(driver,etest,DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/dd"),CALENDAR_TIME1,TIMEZONE);
    }

    public static boolean checkCalendarSchedule(WebDriver driver,ExtentTest etest,String date,String[] time,String timezone)
    {
        clickCalendarScheduleButton(driver,etest);

        etest.log(Status.PASS,"Message was posted after schedule button was clicked after dates were selected.");

        etest.log(Status.WARNING,"Posted date checking could not be automated because it is not posted in the expected format. It will be automated once the product issues regarding them are fixed");

        //not checked anything because of many issues in product,need to add after all issues are fixed

        return true;
    }

    public static boolean checkRangeCalendarSchedule(WebDriver driver,ExtentTest etest)
    {
        return checkRangeCalendarSchedule(driver,etest,null,null,null,null,null);
    }

    public static boolean checkRangeCalendarSchedule(WebDriver driver,ExtentTest etest,String from_date,String to_date,String[] from_time,String[] to_time,String timezone)
    {
        clickCalendarScheduleButton(driver,etest);

        etest.log(Status.PASS,"Message was posted after schedule button was clicked after dates were selected.");

        etest.log(Status.WARNING,"Posted date checking could not be automated because it is not posted in the expected format. It will be automated once the product issues regarding them are fixed");

        //not checked anything because of many issues in product,need to add after all issues are fixed

        return true;        
    }

    public static boolean clickCalendarScheduleButton(WebDriver driver,ExtentTest etest)
    {
        WebElement schedule=CommonUtil.getElement(getDatePicker(driver),CALENDAR_SCHEDULE_BUTTON);
        schedule.click();
        etest.log(Status.INFO,"Schedule button was clicked in calendar widget");
        return CommonWait.waitTillHidden(schedule);
    }

    public static String getEventIdFromCalendarCodeBotMessage(String message)
    {
        return message.split(",")[0];
    }
}
