//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class Zia
{
    public static final By
    ZIALOGO=By.className("zia_icons_zialogo"),
    CREATESKILL=By.cssSelector("a[href*='skills/create']"),
    SKILL_INPUT=By.id("skill-name"),
    SKILL_DESCRIPTION=By.id("skill-description"),
    SAVE_SKILL=By.cssSelector("[click*='save_button']"),
    MORE_OPTIONS=By.id("menu-icon"),
    MORE_OPTIONS_INNER=By.cssSelector("[click*='showHide(event)']"),
    DEACTIVATE=By.cssSelector("[data-value*='deactivate']"),
    DELETE=By.cssSelector("[data-value*='delete']"),
    ACCEPT=By.cssSelector("[click*='accept']")
    ;

    public static boolean waitTillLoads(WebDriver driver)
    {
        return CommonWait.waitTillDisplayed(driver,ZIALOGO);
    }

    public static void createSkill(WebDriver driver,ExtentTest etest,String skill_name)
    {
        CommonUtil.clickWebElement(driver,By.className("zia_icons_home"));
        try
        {
            CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("outlet")),"innerHTML","integrations-details-comp");
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }
        CommonUtil.jsClick(driver,CREATESKILL);

        CommonWait.waitTillDisplayed(driver,SKILL_INPUT);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,SKILL_INPUT),skill_name);

        CommonWait.waitTillDisplayed(driver,SKILL_DESCRIPTION);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,SKILL_DESCRIPTION),"description");

        WebElement save=CommonUtil.getElement(driver,SAVE_SKILL);
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonUtil.clickWebElement(driver,save);
        CommonWait.waitTillHidden(save);

        etest.log(Status.INFO,"A new skill '"+skill_name+"' was created successfully in zia console.");

        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static void deleteSkillInCurrentPage(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,MORE_OPTIONS,MORE_OPTIONS_INNER);
        CommonUtil.click(driver,MORE_OPTIONS,MORE_OPTIONS_INNER);

        CommonWait.waitTillDisplayed(driver,DEACTIVATE);
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonUtil.jsClick(driver,DEACTIVATE);

        CommonWait.waitTillDisplayed(driver,ACCEPT);
        WebElement accept=CommonUtil.getElement(driver,ACCEPT);
        CommonUtil.jsClick(driver,ACCEPT);
        CommonWait.waitTillHidden(accept);

        CommonWait.waitTillDisplayed(driver,MORE_OPTIONS,MORE_OPTIONS_INNER);
        CommonUtil.click(driver,MORE_OPTIONS,MORE_OPTIONS_INNER);

        CommonWait.waitTillDisplayed(driver,DELETE);
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonUtil.jsClick(driver,DELETE);

        CommonWait.waitTillDisplayed(driver,ACCEPT);
        accept=CommonUtil.getElement(driver,ACCEPT);
        CommonUtil.jsClick(driver,ACCEPT);
        CommonWait.waitTillHidden(accept);

        TakeScreenshot.infoScreenshot(driver,etest);

        etest.log(Status.INFO,"Zia skill was deleted successfully");
    }
}
