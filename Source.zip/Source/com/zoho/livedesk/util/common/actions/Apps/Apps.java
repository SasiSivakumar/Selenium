//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class Apps
{
    /*Objects*/

    /*Constants*/
    public static final By
    APPS_STATUS_CONTAINER=By.className("disc-info-wrp"),
    ADD_APP=By.cssSelector("[onclick*='apps/add']"),
    VIEW_APP=By.cssSelector("[onclick*='apps/view']"),
    COUNT_CONTAINER=By.className("disc-info-item"),
    INACTIVE_GLOBE=By.className("inactive"),
    COUNT_VALUE=By.className("disc-info-count")
    ;

    public static final String
    PAGE="'Apps'"
    ;

    public static final int
    ACTIVE=1,
    INACTIVE=0
    ;

    /*Methods*/
    public static boolean waitTillLoads(WebDriver driver)
    {
        return CommonWait.waitTillDisplayed(driver,APPS_STATUS_CONTAINER);
    }

    public static boolean clickView(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,VIEW_APP);
        WebElement view_button=CommonUtil.getElement(driver,VIEW_APP);
        CommonUtil.clickWebElement(driver,view_button);
        etest.log(Status.INFO,"View button was clicked in "+PAGE+" page");
        return AppsView.waitTillLoads(driver);
    }

    public static boolean clickAdd(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,ADD_APP);
        CommonUtil.click(driver,ADD_APP);
        etest.log(Status.INFO,"Add button was clicked in "+PAGE+" page");
        return AppsAdd.waitTillLoads(driver);
    }

    public static int getActiveAppCount(WebDriver driver)
    {
        Tab.goToApps(driver);
        return getCount(driver,ACTIVE);
    }

    public static int getInActiveAppCount(WebDriver driver)
    {
        Tab.goToApps(driver);
        return getCount(driver,INACTIVE);
    }

    public static int getCount(WebDriver driver,int count_type)
    {
        List<WebElement>  count_containers=CommonUtil.getElements(driver,COUNT_CONTAINER);

        for(WebElement count_container : count_containers)
        {
            if(count_type==INACTIVE && CommonWait.isPresent(count_container,INACTIVE_GLOBE))
            {
                return Integer.parseInt(CommonUtil.getElement(count_container,COUNT_VALUE).getAttribute("innerText").trim());
            }
            else if(count_type==ACTIVE && CommonWait.isPresent(count_container,INACTIVE_GLOBE)==false)
            {
                return Integer.parseInt(CommonUtil.getElement(count_container,COUNT_VALUE).getAttribute("innerText").trim());                
            }
        }

        throw new ZohoSalesIQRuntimeException("Unable to get count");
    }

    public static boolean createNewApp(WebDriver driver,ExtentTest etest,String app_name,String description,List<String> departments)
    {
        Tab.goToApps(driver);
        etest.log(Status.INFO,"Apps tab was opened");
        Apps.clickAdd(driver,etest);
        AppsAdd.sendKeysToNameInput(driver,app_name);
        etest.log(Status.INFO,"'"+app_name+"' was entered in app name input box");
        AppsAdd.clickCreate(driver);
        etest.log(Status.INFO,"Create button was clicked.");
        AppsAdd.sendKeysToDescriptionInput(driver,description);
        etest.log(Status.INFO,"'"+description+"' was entered in app description input box");
        AppsAdd.selectDepartments(driver,etest,departments);
        AppsAdd.clickDoneButton(driver);
        boolean isSuccess=AppsEdit.waitTillLoads(driver);
        etest.log(Status.INFO,"App '"+app_name+"' was successfully created.");

        return isSuccess;
    }

    public static void toggleApp(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        Tab.goToApps(driver);
        Apps.clickView(driver,etest);
        AppsView.toggleApp(driver,etest,app_name,isEnable);
    }

    public static boolean deleteApp(WebDriver driver,ExtentTest etest,String app_name)
    {
        Tab.goToApps(driver);
        Apps.clickView(driver,etest);
        return AppsView.deleteApp(driver,etest,app_name);        
    }

    public static void deleteAllAppsExcept(WebDriver driver,ExtentTest etest,String... app_names)
    {
        Tab.goToApps(driver);
        Apps.clickView(driver,etest);
        AppsView.deleteAllAppsExcept(driver,etest,app_names);        
    }

    public static boolean isAppFound(WebDriver driver,ExtentTest etest,String app_name)
    {
        Tab.goToApps(driver);
        Apps.clickView(driver,etest);
        return AppsView.isAppFound(driver,app_name);
    }

    public static String getAppDescription(WebDriver driver,ExtentTest etest,String app_name)
    {
        Tab.goToApps(driver);
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        return AppsEdit.getAppDescription(driver);
    }

    public static List<String> getAppDepartments(WebDriver driver,ExtentTest etest,String app_name)
    {
        Tab.goToApps(driver);
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickDeparmentCountButton(driver);
        return AppsSettings.getDeparments(driver);
    }

    public static boolean setTheme(WebDriver driver,ExtentTest etest,String app_name,String theme_type,String theme_name)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.openMessengerMenu(driver,etest);
        return AppsMessenger.setTheme(driver,etest,theme_type,theme_name);
    }

    public static boolean setWidgetContent(WebDriver driver,ExtentTest etest,String app_name,boolean isOnlineState,String line1,String line2)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.openMessengerMenu(driver,etest);
        return AppsMessenger.setWidgetContent(driver,etest,isOnlineState,line1,line2);
    }

    public static boolean setWaitingTimer(WebDriver driver,ExtentTest etest,String app_name,int waiting_time)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);
        return AppsSettings.setWaitingTimer(driver,etest,waiting_time);
    }

    public static void setEmailTranscript(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);
        AppsSettings.setEmailTranscript(driver,etest,isEnable);
    }

    public static void setConversationView(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);
        AppsSettings.setConversationView(driver,etest,isEnable);
    }

    public static void setEmojiSetting(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);
        AppsSettings.setEmojiSetting(driver,etest,isEnable);
    }

    public static void setShareFileSetting(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);
        AppsSettings.setShareFileSetting(driver,etest,isEnable);
    }

    public static void setShareScreenSetting(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);
        AppsSettings.setShareScreenSetting(driver,etest,isEnable);
    }

    public static void setCheckboxesGeneralTab(WebDriver driver,ExtentTest etest,String app_name,Boolean is_transcript,Boolean is_conversation,Boolean is_emoji,Boolean is_fileshare,Boolean is_screnshare)
    {
        Tab.goToApps(driver);        
        Apps.clickView(driver,etest);
        AppsView.openApp(driver,etest,app_name);
        AppsEdit.clickSettingsIcon(driver);

        if(is_transcript!=null)
        {
            AppsSettings.setEmailTranscript(driver,etest,is_transcript);
        }
        if(is_conversation!=null)
        {
            AppsSettings.setConversationView(driver,etest,is_transcript);
        }
        if(is_emoji!=null)
        {
            AppsSettings.setEmojiSetting(driver,etest,is_transcript);
        }
        if(is_fileshare!=null)
        {
            AppsSettings.setShareFileSetting(driver,etest,is_transcript);
        }
        if(is_screnshare!=null)
        {
            AppsSettings.setShareScreenSetting(driver,etest,is_transcript);
        }
    }
}
