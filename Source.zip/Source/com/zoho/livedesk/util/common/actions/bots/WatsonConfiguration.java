//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class WatsonConfiguration
{
    public static final String
    WATSON="Watson",
    POPUP=WATSON,
    INCORRECT="incorrect"
    ;

    public static final By
    HEADER=By.id("platformheader"),
    ASSOCIATE_ID_INPUT=By.id("associate_id"),
    CHANGE=By.id("changebotauth"),
    HOST_URL_INPUT=By.id("hosturl"),
    API_KEY_INPUT=By.id("token"),
    CONNECT_WITH_WATSON=DialogflowConfiguration.CONNECT_WITH_DIALOGFLOW
    ;

    public static boolean waitTillPageLoads(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,HEADER);
        WebElement header_ele=CommonUtil.getElement(driver,HEADER);
        return CommonUtil.waitTillTextFound(driver,header_ele,WATSON);
    }

    public static void enterAssistantID(WebDriver driver,String assistant_id)
    {
        CommonUtil.scrollIntoView(driver,ASSOCIATE_ID_INPUT);
        CommonWait.waitTillDisplayed(driver,ASSOCIATE_ID_INPUT);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,ASSOCIATE_ID_INPUT),assistant_id);
    }

    public static void setTriggerMessages(WebDriver driver,ExtentTest etest,String... trigger_messages)
    {
        DialogflowConfiguration.setTriggerMessages(driver,etest,trigger_messages);
    }

    public static boolean clickCreateBot(WebDriver driver)
    {
        return DialogflowConfiguration.clickCreateBot(driver);
    }

    public static boolean isBotPreviewChatInputDisplayed(WebDriver driver)
    {
        return DelugeScript.isBotPreviewChatInputDisplayed(driver);
    }

    public static void clickConsoleButton(WebDriver driver)
    {
        DialogflowConfiguration.clickConsoleButton(driver);
    }

    public static boolean clickAccessConsole(WebDriver driver,ExtentTest etest)
    {
        clickConsoleButton(driver);
        CommonUtil.sleep(5000);//sleep added due to selenium issue in linux machines which cause browser timeout
        CommonUtil.waitTillNewTabOpens(driver,1);
        CommonUtil.switchToTab(driver,1);
        TakeScreenshot.infoScreenshot(driver,etest);
        return IBMWatsonUI.waitTillPageLoads(driver);
    }

    public static boolean clickChangeButton(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,CHANGE);
        CommonUtil.click(driver,CHANGE);    
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,POPUP);
        TakeScreenshot.infoScreenshot(driver,etest);
        return CommonWait.waitTillDisplayed(popup);
    }

    public static String getHostURLFromPopup(WebDriver driver)
    {
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,POPUP);
        return CommonUtil.getElement(popup,HOST_URL_INPUT).getAttribute("value");
    }

    public static boolean authenticateWatsonNewAccount(WebDriver driver,ExtentTest etest,String host_url,String api_key)
    {
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,HOST_URL_INPUT),host_url);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,API_KEY_INPUT),api_key);
        etest.log(Status.INFO,"Following fields were entered. Host url : "+host_url+" API Key : "+api_key);
        return clickAuthenticateButton(driver);
    }

    public static String getAPIKeyFromPopup(WebDriver driver)
    {
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,POPUP);
        return CommonUtil.getElement(popup,API_KEY_INPUT).getAttribute("value");
    }

    public static boolean editWatsonAssistantCredentials(WebDriver driver,ExtentTest etest,String host_url,String api_key,boolean isValid)
    {
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,POPUP);
        CommonWait.waitTillDisplayed(popup);

        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(popup,HOST_URL_INPUT),host_url);
        CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(popup,API_KEY_INPUT),api_key);

        etest.log(Status.INFO,"The following data was entered. Host URL : "+host_url+" , API Key : "+api_key);

        CommonUtil.getElement(popup,HandleCommonUI.POSITIVE_BUTTON1).click();

        if(!isValid)
        {
            if(Tab.isBannerFound(driver,etest,INCORRECT,Tab.FAILURE_BANNER))
            {
                etest.log(Status.PASS,"Failure banner was found for invalid assistant credentials");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Failure banner was NOT found for invalid assistant credentials");
                return false;                
            }
        }
        else
        {
            if(CommonWait.waitTillHidden(popup))
            {
                etest.log(Status.PASS,"Popup was hidden after entering valid assistant credentials");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Popup was NOT hidden after entering valid assistant credentials");
                return false;
            }
        }
    }

    public static String getManagedByText(WebDriver driver)
    {
        return DialogflowConfiguration.getManagedByText(driver);
    }

    public static void close(WebDriver driver)
    {
        DelugeScript.close(driver);
    }

    public static boolean isConnectWithWatsonShown(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,CONNECT_WITH_WATSON);
    }

    public static boolean clickAuthenticateButton(WebDriver driver)
    {
        WebElement button=CommonUtil.getElement(driver,CONNECT_WITH_WATSON);
        CommonWait.waitTillDisplayed(button);
        CommonUtil.clickWebElement(driver,button);
        return CommonWait.waitTillHidden(button);
    }

    public static void clickEditBot(WebDriver driver)
    {
        DialogflowConfiguration.clickEditBot(driver); 
    }

    public static void clickSaveBot(WebDriver driver)
    {
        DialogflowConfiguration.clickSaveBot(driver);
    }


}
