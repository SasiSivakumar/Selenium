//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import java.util.ArrayList;

public class PortalConfig
{
    public static void changeValues(WebDriver driver, String id, String value, ExtentTest etest) throws Exception
    {
        Tab.navToPortalTab(driver);
        
        String div_id = id+"drpdwn_div";
        String dropdown_id = id+"drpdwn_ddown";
        
        WebElement div = CommonUtil.elfinder(driver,"id",div_id);
        WebElement dropdown = CommonUtil.elfinder(driver,"id",dropdown_id);
        
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+div.getLocation().y+"-300)");
        
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.visibilityOf(div));
        
        div.click();
        
        wait.until(ExpectedConditions.visibilityOf(dropdown));
        
        List<WebElement> list = dropdown.findElements(By.tagName("li"));
        
        for(WebElement e : list)
        {
            if(e.getAttribute("val").equals(value))
            {
                try
                {
                    CommonUtil.inViewPort(e);
                }
                catch(Exception exp){}

                if(CommonUtil.elementfinder(driver,e,"tagname","em").getAttribute("class").contains("sqico-tick"))
                {
                    e.click();
                    return;
                }
                
                e.click();
                break;
            }
        }
        
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(dropdown)));
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
    }

    public static void editCheckbox(WebDriver driver,final String radio_name,final String selected_radio_id)
    {
        WebElement checkbox=CommonUtil.getElement(driver,By.id(selected_radio_id));

        CommonUtil.inViewPortSafe(driver,checkbox,25);
        CommonUtil.mouseHoverAndClick(driver,checkbox);

        FluentWait wait=CommonUtil.waitreturner(driver,10,1000);

        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(isSelectedRadioCheckboxIdEquals(driver,radio_name,selected_radio_id))
                        {
                            return true;
                        }
                    }
                    catch (Exception e1)
                    {
                        
                    }

                    return false;
                }
            });
        }
        catch(Exception e)
        {
            e.printStackTrace();
            String stacktrace=SalesIQAutomationExceptionHandler.getStacktrace(e);
            throw new ZohoSalesIQRuntimeException("Portal settings checkbox state was not changed after clicking. Radio name : "+radio_name+", expected checkbox id : "+selected_radio_id+"\n\n"+stacktrace);
        }
    }

    public static void editToggleAndSetValue(WebDriver driver,final String id,final boolean is_enabled,String input_id,String value) throws Exception
    {
        editToggle(driver,id,is_enabled);
        if(is_enabled)
        {
           WebElement input=CommonUtil.getElement(driver,By.id(input_id));
           CommonUtil.inViewPortSafe(driver,input);
           input.clear();
           input.sendKeys(value);
           Tab.waitForLoadingLine(driver);
        }
    }

    public static void editToggle(WebDriver driver,final String id,final boolean is_enabled)
    {
        if(isToggleChecked(driver,id)==is_enabled)
        {
            return;
        }

        List<WebElement> toggle_buttons=driver.findElements(By.className(PortalSettingsConstants.TOGGLE_BUTTON_CLASS));
        WebElement toggle=CommonUtil.getElementByAttributeValue(toggle_buttons,"tbutid",id);

        CommonUtil.inViewPortSafe(driver,toggle,25);
        CommonUtil.mouseHoverAndClick(driver,toggle);

        if(id.contains("translate") && is_enabled)
        {
            WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Google translator");
            HandleCommonUI.clickPositivePopupButton(popup);
        }

        FluentWait wait=CommonUtil.waitreturner(driver,10,250);

        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(isToggleChecked(driver,id)==is_enabled)
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw new ZohoSalesIQRuntimeException("Portal settings toggle state was not changed after clicking. Toggle id : "+id+", expected is_checked : "+is_enabled+" ,Actual is_checked "+isToggleChecked(driver,id));
        }
    }

    public static void setInputValue(WebDriver driver,String eid,String value)
    {
        WebElement input_container=CommonUtil.getElement(driver,By.cssSelector(eid));
        WebElement input;

        if(input_container.getTagName().equals("input"))
        {
            input=input_container;
        }
        else
        {
            input=input_container.findElement(By.tagName("input"));
        }

        if(input==null)
        {
            throw new ZohoSalesIQRuntimeException("No portal input was found with eid : "+eid);
        }

        CommonWait.waitTillDisplayed(input);

        CommonUtil.inViewPort(input);

        CommonUtil.sendKeysToWebElement(driver,input,value);
    }

    public static boolean isToggleChecked(WebDriver driver,String id)
    {

        WebElement toggle=CommonUtil.getElement(driver,By.id(id));

        if(toggle==null)
        {
            throw new ZohoSalesIQRuntimeException("Toggle with id "+id+" was not found. html source\n\n"+driver.findElement(By.tagName("body")).getAttribute("innerHTML"));
        }

        String checked_attribute=toggle.getAttribute(PortalSettingsConstants.CHECKED_ATTRIBUTE);

        if(checked_attribute==null)
        {
            return false;
        }
        else if(checked_attribute.contains("true"))
        {
            return true;
        }

        return false;
    }

    public static boolean isSelectedRadioCheckboxIdEquals(WebDriver driver,String radio_name,String expected_checkbox_id)
    {
        return  (ExecuteStatements.getAttributeOfSelectedRadio(driver,radio_name,"id").equals(expected_checkbox_id));
    }

    public static String getCurrentPortalOwner(WebDriver driver) throws Exception
    {
        Tab.navToCompTab(driver);
        return CommonUtil.getElement(driver,By.className("detl_lab"),By.className("list-name")).getText();
    }

    public static void setCompanyFromEmailAndName(WebDriver driver,ExtentTest etest,String company_name,String company_email)
    {
        WebElement edit_mail=CommonUtil.getElement(driver,By.id("frommailid"));
        CommonUtil.inViewPortSafe(driver,edit_mail,100);
        CommonUtil.clickWebElement(driver,edit_mail);

        WebElement popup=HandleCommonUI.getPopupByAttribute(driver,"innerHTML","fnamediv");

        WebElement name_input=popup.findElement(By.id("fnamediv")).findElement(By.tagName("input"));
        CommonUtil.sendKeysToWebElement(driver,name_input,company_name);

        WebElement mail_input=popup.findElement(By.id("pop-femail"));
        CommonUtil.sendKeysToWebElement(driver,mail_input,company_email);

        HandleCommonUI.clickPositivePopupButton(popup);
        
        etest.log(Status.INFO,"From company settings updated in portal settings --> From company name : "+company_name+" , From company mail : "+company_email);
    }

    public static void setVisitorChatTranscript(WebDriver driver,String value)
    {
        System.out.println("~value"+value);

        WebElement visitor_transcript_dropdown=CommonUtil.getElement(driver,By.id("vischattranscript_div"));
        CommonUtil.inViewPortSafe(driver,visitor_transcript_dropdown);
        visitor_transcript_dropdown.click();

        WebElement visitor_transcript_dropdown_values_container=CommonUtil.getElement(driver,By.id("vischattranscript_ddown"));

        HandleCommonUI.chooseFromDropdown(visitor_transcript_dropdown_values_container,value);
        // List<WebElement> dropdown_values=CommonUtil.getElement(driver,By.id("vischattranscript_ddown"),By.tagName("ul")).findElements(By.tagName("li"));

        // System.out.println("~dropdown_values"+dropdown_values.toString());

        // WebElement dropdown=CommonUtil.getElementByAttributeValue(dropdown_values,"val",value);


        // // System.out.println("~dropdown"+dropdown.getAttribute("innerText"));

        // // CommonUtil.inViewPort(dropdown);
        // dropdown.click();

    }

    public static void clickResendConfirmationMail(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,By.id(PortalSettingsConstants.RESEND_MAIL_CONTAINER_ID));
        WebElement resend_button=CommonUtil.getElement(driver,By.id(PortalSettingsConstants.RESEND_MAIL_CONTAINER_ID),By.tagName("a"));
        CommonUtil.inViewPortSafe(driver,resend_button);
        resend_button.click();
        etest.log(Status.INFO,"Resend confirmation mail button was clicked.");
    }

    public static void changeOwner(WebDriver owner_driver,String new_owner_username,ExtentTest etest) throws Exception
    {
        //this method returns changes portal owner from owner_driver to admin_driver

        Tab.navToCompTab(owner_driver);

        if(new_owner_username.equals(getCurrentPortalOwner(owner_driver)))
        {
            return;
        }
        System.out.println("~~changeOwner "+ExecuteStatements.getUserName(owner_driver));
        CommonUtil.getElement(owner_driver,By.className("cp_owner")).click();
        CommonWait.waitTillDisplayed(owner_driver,By.id("popupdiv"),By.className("ownr-chngsubmn"));
        List<WebElement> admins=CommonUtil.getElement(owner_driver,By.id("popupdiv")).findElements(By.className("ownr-chngsubmn"));
        CommonUtil.getElementByAttributeValue(admins,"innerText",new_owner_username).click();
        CommonUtil.sleep(250);
        CommonUtil.getElement(owner_driver,By.id("okbtn")).click();
        CommonUtil.sleep(250);

        WebElement popup=HandleCommonUI.getPopupByInnerText(owner_driver,"You are about to change the company owner");
        // List<WebElement> popups=CommonUtil.getElement(owner_driver,By.id("popupdiv")).findElements(By.className("lvd_popupmn"));
        // WebElement popup = CommonUtil.getElementByAttributeValue(popups,"innerText","You are about to change the company owner");
        popup.findElement(By.id("okbtn")).click();
        CommonWait.waitTillHidden(popup);
    }

    public static WebElement getSelectedCheckbox(WebDriver driver,String eid)
    {
        List<WebElement> options=CommonUtil.getElement(driver,By.cssSelector("[eid="+eid+"]")).findElements(PortalSettingsConstants.CHECKBOX_CONTAINER);

        for(WebElement option : options)
        {
            if(CommonWait.isPresent(option,PortalSettingsConstants.SELECTED_CHECKBOX))
            {
                return option.findElement(By.tagName("input"));
            }
        }

        throw new ZohoSalesIQRuntimeException("No values were selected under checkbox for portal setting eid :"+eid);
    }

    public static String getAttributeOfSelectedCheckbox(WebDriver driver,String eid,String attribute)
    {
        return getSelectedCheckbox(driver,eid).getAttribute(attribute);
    } 

    public static ArrayList<String> getAssociatedPortals(WebDriver driver)
    {
        ArrayList<String> portals=new ArrayList<String>();

        driver.get(Util.siteNameout()+"/portal.do");

        List<WebElement> portal_containers=driver.findElements(By.className("textpart"));

        for(WebElement portal_container : portal_containers)
        {
            portals.add(CommonUtil.getElement(portal_container,By.tagName("h3")).getText().trim());
        }

        driver.get(Util.siteNameout());

        return portals;
    }
}
