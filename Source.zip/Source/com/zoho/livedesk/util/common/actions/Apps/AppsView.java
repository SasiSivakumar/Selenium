//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Arrays;

public class AppsView
{
    /*Objects*/


    /*Constants*/
    public static final By
    APP_CONTAINER=By.cssSelector("[documentclick*='viewAppDetail']"),
    APP_NAME_CONTAINER=By.className("module-list-desc"),
    APP_TOGGLE_BUTTON=By.cssSelector("[documentchange='enableApps']"),
    DELETE_APP=By.cssSelector("[documentclick='deleteApp']"),
    OK_POPUP=By.cssSelector("[btn='dig-box'][id='0']")
    ;

    public static final String
    ENABLED="Enabled",
    DISABLED="Disabled",
    TITLE="title"
    ;

    public static final String
    PAGE="'Apps list'"
    ;

    /*Methods*/
    public static boolean waitTillLoads(WebDriver driver)
    {
    	return CommonWait.waitTillDisplayed(driver,APP_CONTAINER);
    }

    public static boolean close(WebDriver driver)
    {
    	return AppsCommonElements.clickClose(driver);
    }

    public static WebElement getAppContainer(WebDriver driver,String app_name)
    {   
        List<WebElement> app_containers=CommonUtil.getElements(driver,APP_CONTAINER);

        for(WebElement app_container : app_containers)
        {
            String current_app_name=CommonUtil.getElement(app_container,APP_NAME_CONTAINER).getAttribute("innerText").trim();

            if(CommonUtil.isContains(app_name,current_app_name))
            {
                return app_container;
            }
        }

        return null;
    }

    public static boolean isAppFound(WebDriver driver,String app_name)
    {
        return (getAppContainer(driver,app_name)!=null);
    }

    public static boolean deleteApp(WebDriver driver,ExtentTest etest,String app_name)
    {
        WebElement app_container=getAppContainer(driver,app_name);
        CommonUtil.inViewPort(app_container);     
        WebElement delete=CommonUtil.getElement(app_container,DELETE_APP);
        CommonUtil.mouseHover(driver,delete);
        CommonWait.waitTillDisplayed(delete);
        CommonUtil.clickWebElement(driver,delete);
        CommonWait.waitTillDisplayed(driver,OK_POPUP);
        WebElement ok_button_popup=CommonUtil.getElement(driver,OK_POPUP);
        CommonUtil.clickWebElement(driver,ok_button_popup);
        boolean isSuccess=CommonWait.waitTillHidden(app_container);
        etest.log(Status.INFO,"App '"+app_name+"' was deleted successfully.");
        return isSuccess;
    }

    public static void deleteAllAppsExcept(WebDriver driver,ExtentTest etest,String... app_names)
    {
         List<WebElement> app_containers=CommonUtil.getElements(driver,APP_CONTAINER);

         List<String> app_names_list=Arrays.asList(app_names);

        for(WebElement app_container : app_containers)
        {
            String current_app_name=CommonUtil.getElement(app_container,APP_NAME_CONTAINER,By.tagName("p")).getAttribute("innerText").trim();

            if(CommonUtil.isListContains(app_names_list,current_app_name))
            {
                //don't delete, i.e. do nothing
                CommonUtil.doNothing();
            }
            else
            {
                //delete
                deleteApp(driver,etest,current_app_name);                
            }
        }   
    }

    public static void toggleApp(WebDriver driver,ExtentTest etest,String app_name,boolean isEnable)
    {
        WebElement app_container=getAppContainer(driver,app_name);

        if(getAppStatus(app_container)==isEnable)
        {
            etest.log(Status.INFO,"App '"+app_name+"' is already "+(isEnable?"enabled":"disabled"));
            TakeScreenshot.infoScreenshot(driver,etest);
            return;
        }

        WebElement toggle_button=CommonUtil.getElement(app_container,APP_TOGGLE_BUTTON);
        AppsCommonElements.setCheckbox(driver,etest,toggle_button,isEnable);


        // CommonUtil.inViewPort(toggle_button);
        // CommonUtil.clickWebElement(driver,toggle_button);

        // CommonWait.waitTillHidden(toggle_button);

        // app_container=getAppContainer(driver,app_name);
        // toggle_button=CommonUtil.getElement(app_container,APP_TOGGLE_BUTTON);

        // boolean isSuccess=CommonWait.waitTillElementContainsValue(toggle_button,TITLE, (isEnable?ENABLED:DISABLED) );

        etest.log(Status.INFO,"App '"+app_name+"' is successfully "+(isEnable?"enabled":"disabled"));
        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static boolean getAppStatus(WebElement app_container)
    {
        return HandleCommonUI.isCheckboxChecked(CommonUtil.getElement(app_container,APP_TOGGLE_BUTTON));
    }

    public static boolean openApp(WebDriver driver,ExtentTest etest,String app_name)
    {
        WebElement app_container=getAppContainer(driver,app_name);
        CommonUtil.clickWebElement(driver, CommonUtil.getElement(app_container,APP_NAME_CONTAINER) );
        return AppsEdit.waitTillLoads(driver);
    }
}
