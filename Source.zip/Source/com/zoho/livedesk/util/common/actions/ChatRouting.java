//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.actions.*;
import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Hashtable;
import com.zoho.livedesk.client.ChatRouting.ChatRoutingTests;



public class ChatRouting
{
    /*Constants*/
    public static final By
    RULE_CONTAINER=By.id("trouting"),
    // RULE_CLASS=By.className("trules"),
    INCOMING_CHAT_CONTAINER_ID=By.id("waitinglist"),
    EMPTY_STATE_CONTAINER=By.className("empty_slate"),
    CHAT_ROUTING_TAB_HEADER=By.className("autochatroutingtab"),
    CHAT_ROUTING_DESCRIPTION2=By.id("filterhd"),
    CHAT_ROUTING_DESCRIPTION1=By.className("innersub-titlemn");
    ;

    public static final String
    CHAT_ROUTING_CONTAINER_CLASS="chatroutingtab",
    PLUS_BUTTON_PARTIAL_HTML="Rules.populateAgentsDropDown(this,",
    EMPTY_STATE_DATA_TYPE_FOR_CHAT_ROUTING="chatrouting";

    /*Chat Routing Rule Values*/

    //Rule criteria
    public static final String
    CAMPAIGN_CONTENT="Campaign Content",
    CAMPAIGN_MEDIUM="Campaign Medium",
    CAMPAIGN_NAME="Campaign Name",
    CAMPAIGN_SOURCE="Campaign Source",
    CAMPAIGN_TERM="Campaign Term",
    CITY="City",
    COUNTRY="Country",
    CURRENT_PAGE_TITLE="Current Page Title",
    CURRENT_PAGE_URL="Current Page URL",
    CURRENT_VISIT_SOURCE="Current Visit Source",
    DEPARTMENT="Department",
    EMAIL="Email Address",
    LANDING_PAGE_TITLE="Landing Page Title",
    LANDING_PAGE_URL="Landing Page URL",
    NUMBER_OF_PAST_CHATS="Number of Past Chats",
    NUMBER_OF_VISITS="Number of Visits",
    REFERRER="Referrer",
    REGION="Region",
    SEARCH_ENGINE="Search Engine",
    STATE="State",
    VISITOR_INFO="Visitor Info",
    VISITOR_QUESTION="Visitor Question",
    VISITOR_SOURCE="Visitor Source",
    VISITOR_TYPE="Visitor Type";

    //Rule Condition
    public static final String
    BETWEEN="is between",
    EQUALS="is equal to",
    LESS="is less than",
    MORE="is more than",
    NOT_EQUALS="is not equal to",
    CONTAINS="contains";

    //Rule Values
    public static final String
    GOOGLE_SEARCH="Google",
    RETURNING="Returning";

    //Routing Action
    public static final String
    DO_NOT_ROUTE="Do not route",
    ONE_BY_ONE="Route one by one",
    LEAST_LOADED="Route to least loaded",
    SELECTED="Route to selected operators";

    //Routing Action Values
    public static final String
    ALL_AVAILABLE_OPERATORS="All Available operators",
    CRM_LEAD_OR_CONTACT_OWNER="CRM Lead/Contact Owner",
    LAST_CHAT_ATTENDER="Last Chat Attender";
    
    /*Objects*/
    public static class ChatRoutingRule
    {
        /*static values*/
        public String rule_criteria,rule_condition,rule_value1,rule_value2,routing_action;
        public ArrayList<String> routing_parameters;
        /*dynamic values*/
        public String rule_id,rule_container_id,rule_criteria_id,rule_condition_id,rule_value_id,routing_action_id,routing_parameters_id,routing_parameters_dropdown_id,rule_status_id;

        //Specific for Chat Routing Real Module ignore if not needed
        Boolean isConfigureCRMAsLead=null;//if false configure as contact

        public String
        rule_config_classname1="agntname",
        rule_config_classname2="txtelips";

        public By
        rule_config=By.cssSelector("."+rule_config_classname1+"."+rule_config_classname2),
        delete_button=By.className("sqico-delico"),
        disable_button=By.className("sqico-disable"),
        enable_button=By.className("sqico-enable"),
        do_not_route_container=By.className("notroute"),
        remove_routing_parameters_icon=By.className("gspritebg")
        ;

        final String
        AGENT_CONTAINER="agentcontainer",
        AGENT_MAIL="agentmail_",
        RULE_ENABLED_CLASS="sqico-enable",
        RULE_DISABLED_CLASS="sqico-disable",
        RULE_ENABLED="enable",
        RULE_DISABLED="disable";

        public ChatRoutingRule()
        {

        }

        public ChatRoutingRule(String rule_criteria,String rule_condition,String rule_value1,String rule_value2,String routing_action,ArrayList<String> routing_parameters)
        {
            this.rule_criteria=rule_criteria;
            this.rule_condition=rule_condition;
            this.rule_value1=rule_value1;
            this.rule_value2=rule_value2;
            this.routing_action=routing_action;
            this.routing_parameters=routing_parameters;
        }

        public ChatRoutingRule(String rule_criteria,String rule_condition,String rule_value1,String routing_action,ArrayList<String> routing_parameters)
        {
            this(rule_criteria,rule_condition,rule_value1,null,routing_action,routing_parameters);
        }

        @Override
        public String toString()
        {
            // String rule="Rule criteria : <criteria>\nRule condition : <condition>\nRule value : <value1> and <value2>\nRouting action : <action>\nRouting parameters : <parameters>";
            String rule="If <criteria> <condition> <value1> and <value2> then <action> for the following configuration <parameters>";
            rule=rule.replace("<criteria>",rule_criteria);
            rule=rule.replace("<condition>",rule_condition);
            rule=rule.replace("<value1>",rule_value1);
            if(rule_value2!=null)
            {
                rule=rule.replace("<value2>",rule_value2);
            }
            else
            {
                rule=rule.replace(" and <value2>","");               
            }

            rule=rule.replace("<action>",routing_action);

            if(routing_action.equals(DO_NOT_ROUTE))
            {
                rule=rule.replace("<parameters>","No routing parameters");
            }
            else
            {
                rule=rule.replace("<parameters>",routing_parameters.toString());
            }


            return rule;
        }

        public void setRuleId(String rule_id)
        {
            this.rule_id=rule_id;
            // this.rule_container_id="trules_"+rule_id;
            this.rule_criteria_id="prior"+rule_id+"_col1";
            this.rule_condition_id="prior"+rule_id+"_col2";
            this.rule_value_id="prior"+rule_id+"_col3";
            this.routing_action_id="info_"+rule_id;
            this.routing_parameters_id=AGENT_CONTAINER+rule_id;        
            this.routing_parameters_dropdown_id=(this.routing_parameters_id+"auto").replace(AGENT_CONTAINER,AGENT_MAIL);
            this.rule_status_id="stat_"+rule_id;
        }

        public WebElement getRuleStatus(WebDriver driver)
        {
            return CommonUtil.getElement(driver,By.id(rule_status_id));
        }

        public boolean isEnabled(WebDriver driver) throws ZohoSalesIQRuntimeException
        {
            String status_class_name=this.getRuleStatus(driver).getAttribute("class");
            if(status_class_name.contains(RULE_ENABLED_CLASS))
            {
                return true;
            }
            else if(status_class_name.contains(RULE_DISABLED_CLASS))
            {
                return false;
            }
            else
            {
                throw new ZohoSalesIQRuntimeException("Invalid classname for rule status element '"+status_class_name+"'. Was expecting one of these classes--->"+RULE_ENABLED_CLASS+","+RULE_DISABLED_CLASS+"\n Rule Id : "+this.rule_id+"\n Rule :"+this.toString());
            }
        }

        public static String getDivId(String element_id)
        {
            return element_id+"_div";
        }

        public static String getDropdownId(String element_id)
        {
            return element_id+"_ddown";
        }

        public WebElement getRuleContainer(WebDriver driver)
        {
            return getRuleContainer(driver,true);
        }

        public WebElement getRuleContainer(WebDriver driver,boolean isRulePopupClosed)
        {
            if(isRulePopupClosed)
            {
                return Rules.getRuleContainer(driver,this.rule_id);
            }
            else
            {
                return Rules.getRuleEditContainer(driver,this.rule_id);                
            }
        }

        public WebElement getDeleteButton(WebDriver driver)
        {
            return getRuleElement(driver,delete_button,true);
        }

        public WebElement getDisableButton(WebDriver driver)
        {
            return getRuleElement(driver,disable_button,true);
        }

        public WebElement getEnableButton(WebDriver driver)
        {
            return getRuleElement(driver,enable_button,true);
        }

        public WebElement getRuleElement(WebDriver driver,By locator)
        {
            return getRuleElement(driver,locator,false);
        }

        public WebElement getRuleElement(WebDriver driver,By locator,boolean isRulePopupClosed)
        {
            if(isRulePopupClosed)
            {
                return Rules.getRuleContainer(driver,this.rule_id).findElement(locator);
            }
            else
            {
                return Rules.getRuleEditContainer(driver,this.rule_id).findElement(locator);
            }
        }

        public WebElement getRuleCriteria(WebDriver driver)
        {
            return getRuleElement(driver, By.id(getDivId(this.rule_criteria_id)) );
        }
        public WebElement getRuleCriteriaDropdown(WebDriver driver)
        {
            return getRuleElement(driver, By.id(getDropdownId(this.rule_criteria_id)) );            
        }

        public WebElement getRuleCondition(WebDriver driver)
        {
            return getRuleElement(driver, By.id(getDivId(this.rule_condition_id)) );
        }
        public WebElement getRuleConditionDropdown(WebDriver driver)
        {
            return getRuleElement(driver, By.id(getDropdownId(this.rule_condition_id)) );            
        }

        public WebElement getRuleValue(WebDriver driver)
        {
            return getRuleElement(driver, By.id(this.rule_value_id) );
        }
        public WebElement getRuleValue(WebDriver driver,int rule_no)
        {        
           return getRuleValue(driver).findElements(By.tagName("input")).get(rule_no-1);          
        }
        public WebElement getRuleValue1(WebDriver driver)
        {
            return getRuleValue(driver,1);
        }
        public WebElement getRuleValue2(WebDriver driver)
        {
            return getRuleValue(driver,2);
        }

        public WebElement getRoutingAction(WebDriver driver)
        {
            return getRuleElement(driver, By.id(getDivId(this.routing_action_id)) );    
        }
        public WebElement getRoutingActionDropdown(WebDriver driver)
        {
            return getRuleElement(driver, By.id(getDropdownId(this.routing_action_id)) );    
        }

        public WebElement getRoutingParametersContainer(WebDriver driver)
        {
            WebElement routing_parameter_add_button=getRuleElement(driver,By.id(this.routing_parameters_id));

            if(routing_parameter_add_button.getAttribute("innerHTML").contains(PLUS_BUTTON_PARTIAL_HTML))
            {
                routing_parameter_add_button=routing_parameter_add_button.findElement(By.tagName("em"));
            }

            return routing_parameter_add_button;
        }
        public WebElement getRoutingParametersDropdown(WebDriver driver)
        {
           return getRuleElement(driver,By.id(this.routing_parameters_dropdown_id));
        }

        public boolean removeAllRoutingParameters(WebDriver driver)
        {
            for(int i=0;i<10;i++)
            {
                List<WebElement> list=getRuleContainer(driver,false).findElements(remove_routing_parameters_icon);
                WebElement delete_icon=CommonUtil.getElementByAttributeValue(list,"onclick","Rules.deleteAgent");

                if(delete_icon!=null)
                {
                    CommonUtil.mouseHover(driver,CommonUtil.getParent(driver,delete_icon));
                    // CommonUtil.mouseHover(driver,this.getCurrentConfigurationsElement(driver).get(0));
                    CommonUtil.sleep(100);
                    CommonUtil.mouseHoverAndClick(driver,delete_icon);
                }
                else
                {
                    return true;
                }
            }

            return false;
        }

        public List<WebElement> getCurrentConfigurationsElement(WebDriver driver)
        {
            if(getRuleContainer(driver,false).getAttribute("innerHTML").contains(rule_config_classname1) && getRuleContainer(driver,false).getAttribute("innerHTML").contains(rule_config_classname2))
            {
                 return getRuleContainer(driver,false).findElements(rule_config);   
            }

           return new ArrayList<WebElement>();
        }

        public List<String> getCurrentConfiguration(WebDriver driver)
        {
            ArrayList<String> rules_config = new ArrayList<String>();
            List<WebElement> routing_parameters=getCurrentConfigurationsElement(driver);
            for(WebElement routing_parameter : routing_parameters)
            {
                rules_config.add( routing_parameter.getAttribute("innerText") );  
            }
            return rules_config;
        }

        public boolean isRuleFoundWithExpectedValues(WebDriver driver,ExtentTest etest)
        {
            return isRuleFoundWithExpectedValues(driver,etest,this);
        }

        public boolean isRuleFoundWithExpectedValues(WebDriver driver,ExtentTest etest,ChatRoutingRule expected_rule)
        {
            int failcount=0;
            String expected=null,actual=null;
            Rules.openRuleEditView(driver,this.rule_id);
            if(expected_rule.rule_criteria!=null)
            {
                expected=expected_rule.rule_criteria;
                actual=this.getRuleCriteria(driver).getText();

                if(!CommonUtil.checkStringContainsAndLog(expected,actual,"rule criteria",etest))
                {
                    failcount++;
                }
            }

            if(expected_rule.rule_condition!=null)
            {
                expected=expected_rule.rule_condition;
                actual=this.getRuleCondition(driver).getText();

                if(!CommonUtil.checkStringContainsAndLog(expected,actual,"rule condition",etest))
                {
                    failcount++;
                }
            }

            if(expected_rule.rule_value1!=null)
            {
                expected=expected_rule.rule_value1;
                actual=this.getRuleValue1(driver).getAttribute("value");

                if(!CommonUtil.checkStringContainsAndLog(expected,actual,"rule value",etest))
                {
                    failcount++;
                }
            }

            if(expected_rule.rule_value2!=null)
            {
                expected=expected_rule.rule_value2;
                actual=this.getRuleValue1(driver).getAttribute("value");

                if(!CommonUtil.checkStringContainsAndLog(expected,actual,"rule value",etest))
                {
                    failcount++;
                }
            }

            if(expected_rule.routing_action!=null)
            {
                expected=expected_rule.routing_action;

                actual=this.getRoutingAction(driver).getText();

                if(!CommonUtil.checkStringContainsAndLog(expected,actual,"routing action",etest))
                {
                    failcount++;
                }
            }

            if(expected_rule.routing_parameters!=null)
            {
                List<String> actual_routing_parameters=this.getCurrentConfiguration(driver);

                if(!actual_routing_parameters.equals(expected_rule.routing_parameters))
                {
                    failcount++;
                    etest.log(Status.FAIL,"Expected routing parameters were not found Expected : "+expected_rule.routing_parameters.toString()+" Actual : "+actual_routing_parameters);
                }
                else
                {
                    etest.log(Status.PASS,"Expected routing parameters were found Expected : "+expected_rule.routing_parameters.toString()+" Actual : "+actual_routing_parameters);                    
                }
            }

            if(!CommonUtil.returnResult(failcount))
            {
                TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Failure","ChatRoutingRuleValues");  
            }
            Rules.cancelRule(driver,etest,this.rule_id);
            return CommonUtil.returnResult(failcount);
        }

        //Specific for Chat Routing Real Module ignore if not needed
        public void setConfigureCRMAsLead(Boolean isConfigureCRMAsLead)
        {
            this.isConfigureCRMAsLead=isConfigureCRMAsLead;
        }

        public Boolean getConfigureCRMAsLead()
        {
            return isConfigureCRMAsLead;
        }
    }

    /*Methods*/


    //Add Chat Routing Methods

    public static String addChatRoutingRule(WebDriver driver,ExtentTest etest,ChatRoutingRule rule) throws Exception
    {
        String rule_id=addNewRule(driver,etest);
        rule.setRuleId(rule_id);

        //will check only once
        if(CommonUtil.isChecked("CRRT3",ChatRoutingTests.result)==false)
        {
            ChatRoutingTests.result.put("CRRT3", rule.isRuleFoundWithExpectedValues(driver,etest,getDefaultRule()) );
        }

        editChatRoutingRule(driver,etest,rule);
        return rule_id;
    }

    public static void editChatRoutingRule(WebDriver driver,ExtentTest etest,ChatRoutingRule rule)
    {
        Rules.openRuleEditView(driver,rule.rule_id);
        editRuleCriteria(driver,rule);
        editRuleCondition(driver,rule);
        editRuleValues(driver,rule);
        editRoutingAction(driver,rule);

        if(CommonUtil.isChecked("CRRT7",ChatRoutingTests.result)==false && rule.routing_action.equals(DO_NOT_ROUTE))//will run only once during entire automation
        {
            WebElement do_not_route=rule.getRuleElement(driver,rule.do_not_route_container);

            if(do_not_route!=null && CommonUtil.checkStringContainsAndLog( ResourceManager.getRealValue("chat_routing_do_not_route") , do_not_route.getText() ,"do not route text" ,etest ))
            {
                ChatRoutingTests.result.put("CRRT7",true);                
            }
            else
            {
                ChatRoutingTests.result.put("CRRT7",false);
            }
        }

        if(rule.routing_action.equals(DO_NOT_ROUTE)==false)
        {
            editRoutingParameter(driver,rule);
        }

        try
        {
            Tab.clickChatRouting(driver);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        etest.log(Status.INFO,"Chat routing rule was set to "+rule.toString());
        Rules.saveRule(driver,etest,rule.rule_id);
    }

    public static void editRuleCriteria(WebDriver driver,ChatRoutingRule rule)
    {
        rule.getRuleCriteria(driver).click();     
        chooseFromDropdown(rule.getRuleCriteriaDropdown(driver),rule.rule_criteria);
    }

    public static void editRuleCondition(WebDriver driver,ChatRoutingRule rule)
    {
        rule.getRuleCondition(driver).click();    
        chooseFromDropdown(rule.getRuleConditionDropdown(driver),rule.rule_condition);
    }

    public static void editRoutingAction(WebDriver driver,ChatRoutingRule rule)
    {
        rule.getRoutingAction(driver).click();     
        chooseFromDropdown(rule.getRoutingActionDropdown(driver),rule.routing_action);
    }

    public static void editRuleValues(WebDriver driver,ChatRoutingRule rule)
    {
        if(rule.rule_value1!=null)
        {
            editRuleValue(driver,rule,rule.getRuleValue1(driver),rule.rule_value1);
        }
        if(rule.rule_value2!=null)
        {
            editRuleValue(driver,rule,rule.getRuleValue2(driver),rule.rule_value2);
        }
    }

    private static void editRuleValue(WebDriver driver,ChatRoutingRule rule,WebElement rule_input,String rule_value)
    {
        if(rule_value==null)
        {
            return;
        }

        rule.getRuleValue(driver).click();
        CommonUtil.sleep(500);

        
        WebElement dropdown_list=CommonUtil.getElement( rule.getRuleValue(driver) ,By.tagName("ul"));

        if(CommonWait.isDisplayed(dropdown_list))
        {
            //consider as dropdown type input
            chooseFromDropdown(rule.getRuleValue(driver),rule_value);
        }
        else
        {
            //consider as text only input
            rule_input.sendKeys(rule_value);
            rule.getRuleContainer(driver,false).click();
        }
    }

    public static void editRoutingParameter(WebDriver driver,ChatRoutingRule rule)
    {
        boolean isAllRoutingParametersDeleted=deleteAllCurrentRoutingParameters(driver,rule);

        if(!CommonUtil.isChecked("CRRT16",ChatRoutingTests.result))
        {
            ChatRoutingTests.result.put("CRRT16",isAllRoutingParametersDeleted);
        }

        for (String routing_parameter : rule.routing_parameters) 
        {
            addRoutingParameter(driver,rule,routing_parameter);
        }
    }

    public static boolean deleteAllCurrentRoutingParameters(WebDriver driver,ChatRoutingRule rule)
    {
        return rule.removeAllRoutingParameters(driver);        
    }

    private static void addRoutingParameter(WebDriver driver,final ChatRoutingRule rule,final String routing_parameter)
    {
        final int old_parameters_length=rule.getCurrentConfiguration(driver).size();

        CommonUtil.mouseHoverAndClick(driver,rule.getRoutingParametersContainer(driver));  
        CommonWait.waitTillDisplayed(driver,By.id(rule.routing_parameters_dropdown_id));
        chooseFromDropdown(rule.getRoutingParametersDropdown(driver),routing_parameter);

        try
        {
            FluentWait wait=CommonUtil.waitreturner(driver,10,250);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(rule.getCurrentConfiguration(driver).size()>old_parameters_length)
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            if(!CommonUtil.isChecked("CRRT17",ChatRoutingTests.result))
            {
                ChatRoutingTests.result.put("CRRT17",false);
            }

            throw new ZohoSalesIQRuntimeException("New routing paramter was not added after it was entered in the dropdown input. Expected rule : "+rule.toString()+" , Error occured while setting routing parameter : "+routing_parameter);
        }

        if(!CommonUtil.isChecked("CRRT17",ChatRoutingTests.result))
        {
            ChatRoutingTests.result.put("CRRT17",true);
        }
    }

    public static String addNewRule(WebDriver driver,ExtentTest etest) throws Exception
    {
        // //rule-id will be returned. which will be used to locate the added rule
        // List<String> rule_ids_before_adding=getCurrentChatRoutingRuleIds(driver);
        // clickAddButton(driver);
        // List<String> rule_ids_after_adding=getCurrentChatRoutingRuleIds(driver);
        // ArrayList<String> difference_list=new ArrayList<String>(getDifference(rule_ids_before_adding,rule_ids_after_adding));
        // String rule_id=difference_list.get(0);

        // return rule_id;

        Rules.clickAdd(driver,etest,CHAT_ROUTING_CONTAINER_CLASS,"Chat Routing");
        return Rules.getRuleId(driver,0);
    }

    public static boolean enableRule(WebDriver driver,ExtentTest etest,ChatRoutingRule rule)
    {
        return toggleRule(driver,etest,rule,true);
    }

    public static boolean disableRule(WebDriver driver,ExtentTest etest,ChatRoutingRule rule)
    {
        return toggleRule(driver,etest,rule,false);
    }

    public static boolean toggleRule(WebDriver driver,ExtentTest etest,ChatRoutingRule rule,boolean isEnable)
    {
        String toggle_status=isEnable?"enable":"disable";
        String expected_status=isEnable?rule.RULE_ENABLED:rule.RULE_DISABLED;

        WebElement ruleElement = Rules.getRuleContainer(driver,rule.rule_id);
        String rule_status = ruleElement.getAttribute("status");
        if(rule_status.equals(toggle_status))
        {
            return true;
        }
        else
        {
            WebElement toggle_button = CommonUtil.getElement(ruleElement,By.className("list_status"));
            CommonUtil.inViewPortSafe(driver,toggle_button);
            CommonUtil.mouseHover(driver,toggle_button);
            CommonWait.isDisplayed(toggle_button);
            CommonUtil.mouseHoverAndClick(driver,toggle_button);
            etest.log(Status.INFO,"Chat routing rule (ruleid:"+rule.rule_id+") was "+toggle_status+"d");
            return CommonUtil.waitTillWebElementContainsAttributeValue(ruleElement,"status",expected_status);
        }
    }

    public static boolean deleteRule(WebDriver driver,ExtentTest etest,ChatRoutingRule rule)
    {
        WebElement delete=rule.getDeleteButton(driver);
        CommonUtil.inViewPortSafe(driver,delete);
        CommonUtil.mouseHover(driver,delete);
        CommonWait.isDisplayed(delete);
        CommonUtil.mouseHoverAndClick(driver,delete);
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,com.zoho.livedesk.util.Cleanup.DELETE_COMMON_TEXT);
        HandleCommonUI.clickPositivePopupButton(popup);
        CommonUtil.sleep(250);
        etest.log(Status.PASS,"Chat routing rule (ruleid:"+rule.rule_id+") was deleted");
        
        try
        {
            CommonWait.isDisplayed(rule.getRuleContainer(driver));
            return false;
        }
        catch(Exception e)
        {
            return true;
        }
    }

    public static void deleteAllRules(WebDriver driver)
    {
        com.zoho.livedesk.util.Cleanup.deleteAllChatRouting(driver);
    }

    public static WebElement getRule(WebDriver driver,String rule_id) throws ZohoSalesIQRuntimeException
    {
        ChatRoutingRule rule = new ChatRoutingRule();
        rule.setRuleId(rule_id);
        return rule.getRuleContainer(driver);
    }

    // public static void clickAddButton(WebDriver driver)
    // {
    //     final int no_of_rules_before=CommonUtil.getElement(driver,RULE_CONTAINER).findElements(RULE_CLASS).size();

    //     Trigger.clickAddButtonAutomationTab(driver,CHAT_ROUTING_CONTAINER_CLASS);

    //     FluentWait wait=CommonUtil.waitreturner(driver,10,250);

    //     try
    //     {
    //         wait.until(new Function<WebDriver,Boolean>()
    //         {
    //             public Boolean apply(WebDriver driver)
    //             {
    //                 if(CommonUtil.getElement(driver,RULE_CONTAINER).findElements(RULE_CLASS).size()>no_of_rules_before)
    //                 {
    //                     return true;
    //                 }
    //                 return false;
    //             }
    //         });            

    //     }
    //     catch(Exception e)
    //     {
    //         throw new ZohoSalesIQRuntimeException("New chat routing rule was not added after chat routing button was clicked. Expected no of rules : "+(no_of_rules_before+1)+" Actual rules : "+no_of_rules_before);
    //     }

    // }

    public static boolean dragRuleToTop(WebDriver driver,ExtentTest etest,final ChatRoutingRule rule)
    {
        TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Before","ChatRoutingDragAndDrop",1);

        CommonUtil.dragAndDrop(driver,rule.getRuleContainer(driver),CommonUtil.getElement(driver,CHAT_ROUTING_TAB_HEADER));        

        FluentWait wait=CommonUtil.waitreturner(driver,10,250);
        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(getCurrentChatRoutingRuleIds(driver).get(0).equals(rule.rule_id))
                        {
                            return true;
                        }
                    }
                    catch(Exception e)
                    {
                        return false;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            etest.log(Status.FAIL,"Chat routing rule was NOT dragged to the top. Rule :"+rule.toString());
            TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"After","ChatRoutingDragAndDrop",e);
            e.printStackTrace();
            return false;
        }

        TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"After","ChatRoutingDragAndDrop",1);

        etest.log(Status.PASS,"Chat routing rule was dragged to the top. Rule :"+rule.toString());
        return true;
    }

    public static Collection getDifference(Collection old_collection,Collection new_collection)
    {
        new_collection.removeAll(old_collection);
        return new_collection;
    }

    public static List<String> getCurrentChatRoutingRuleIds(WebDriver driver) throws Exception
    {
        List<WebElement> rules = Rules.getList(driver);
        return CommonUtil.getAttributesFromList(rules,"ruleid");
        // return getCurrentRuleIds(driver,RULE_CONTAINER);
    }

    // public static List<String> getCurrentRuleIds(WebDriver driver,By container)
    // {
    //     List<WebElement> rules=CommonUtil.getElement(driver,container).findElements(RULE_CLASS);
    //     return CommonUtil.getAttributesFromList(rules,"ruleid");
    // }

    //RealTime Routed Chats Method

    public static boolean isWaitForIncomingChats(Long wait_starting_time)
    {
        int SECONDS_TO_WAIT=20;

        int milliseconds_to_wait=SECONDS_TO_WAIT*1000;

        Long current_time=new Long(System.currentTimeMillis());

        if(current_time<(wait_starting_time+milliseconds_to_wait))
        {
            return true;
        }

        return false;
    }

    public static boolean isChatRoutingAlreadyChecked(String user_name,Hashtable<String,Boolean> chat_routing_status) 
    {
        if(chat_routing_status.containsKey(user_name) && chat_routing_status.get(user_name)==true)
        {
            return true;
        }
        return false;
    }

    /*failure_case:Chat notification is not recieved*/
    public static Hashtable<String,Boolean> isChatRoutedToAgents(ExtentTest etest,WebDriver... drivers) throws Exception
    {
        Hashtable<String,Boolean> chat_routing_status=new Hashtable<String,Boolean>();

        Long wait_starting_time=new Long(System.currentTimeMillis());

        while(isWaitForIncomingChats(wait_starting_time))
        {
            int routed_count=0;

            for(WebDriver driver : drivers)
            {
                String user_name=ExecuteStatements.getUserName(driver);

                //below condition is to ignore check if it is incoming chat is already found, then we can ignore it and check ONLY for drivers who havent got yet.
                if(!isChatRoutingAlreadyChecked(user_name,chat_routing_status))
                {
                    if(isChatRoutedToAgent(driver))
                    {
                        etest.log(Status.INFO,"Chat was routed to agent '"+user_name+"'");
                        TakeScreenshot.screenshot(driver,etest,"ChatRouting","Routed",user_name,1);
                        chat_routing_status.put(user_name,true);
                        ChatWindow.ignoreChat(driver);
                        routed_count++;
                    }
                    else
                    {
                        chat_routing_status.put(user_name,false);
                    }
                }
            }

            //If this condition is true, Then chats have been routed to all drivers. So no need to wait anymore.
            if(routed_count==drivers.length)
            {
                break;
            }
        }

        //not routed screenshots
        for(WebDriver driver : drivers)
        {
            String user_name=ExecuteStatements.getUserName(driver);

            if(chat_routing_status.get(user_name)==false)
            {
                etest.log(Status.INFO,"Chat was NOT routed to agent '"+user_name+"'");
                TakeScreenshot.screenshot(driver,etest,"ChatRouting","NotRouted",user_name,1);
            }
        }

        return chat_routing_status;
    }

    public static void initiateChat(WebDriver visitor_driver,String widget_code,ExtentTest etest) throws Exception
    {
        String
        label=CommonUtil.getUniqueMessage(),
        visitor_name="name"+label,
        visitor_mail=label+"@email.com",
        visitor_question="question"+label;
        visitor_driver.navigate().refresh();

        VisitorWindow.createPage(visitor_driver,widget_code);
        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
    }

    public static boolean isChatRoutedToAgent(WebDriver driver)
    {
        if(CommonWait.waitTillDisplayed(driver,INCOMING_CHAT_CONTAINER_ID))
        {
            return (CommonUtil.getElement(driver,INCOMING_CHAT_CONTAINER_ID).getAttribute("innerHTML").length() != 0);
        }
        else
        {
            return false;
        }
    }

    public static Hashtable<String,Boolean> getExpectedRoutingStatus(ChatRoutingRule rule,WebDriver... drivers)
    {
        return null;
    }

    public static boolean checkHeaderAndDescription(WebDriver driver,ExtentTest etest)
    {
        int failcount=0;

        String expected=ResourceManager.getRealValue("chat_routing_tab_header");
        String actual=CommonUtil.getElement(driver,CHAT_ROUTING_TAB_HEADER).getText();

        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"chat routing tab header",etest))
        {
            failcount++;
            TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Failure","ChatRouting");  
        }

        expected=ResourceManager.getRealValue("chat_routing_description1");
        actual=CommonUtil.getElement(driver,CHAT_ROUTING_DESCRIPTION1).getText();

        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"chat routing description 1",etest))
        {
            failcount++;
            TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Failure","ChatRouting");  
        }

        expected=ResourceManager.getRealValue("chat_routing_description2");
        actual=CommonUtil.getElement(driver,CHAT_ROUTING_DESCRIPTION2).getText();

        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"chat routing description 2",etest))
        {
            failcount++;
            TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Failure","ChatRouting");  
        }       

        return CommonUtil.returnResult(failcount); 
    }

    public static boolean isExpectedEmptyStateDisplayed(WebDriver driver,ExtentTest etest)
    {
        try
        {
            WebElement empty_state=CommonUtil.getElementByAttributeValue(driver.findElements(EMPTY_STATE_CONTAINER),"data_type",EMPTY_STATE_DATA_TYPE_FOR_CHAT_ROUTING);
            
            if(CommonWait.isDisplayed(empty_state))
            {
                etest.log(Status.PASS,"Expected chat routing empty state was found after all chat routing rules were deleted");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Expected chat routing empty state was NOT found after all chat routing rules were deleted");
                TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Failure","Empty Chat Routing State Not Found");  
                return false;               
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"isExpectedEmptyStateDisplayed","Exception",e);
            e.printStackTrace();  
            return false; 
        }
    }

    public static ChatRoutingRule getDefaultRule()
    {
        return new ChatRoutingRule(NUMBER_OF_PAST_CHATS,MORE,"1",SELECTED,null);
    }

    //custom common functions
    public static void chooseFromDropdown(WebElement dropdown,String value)
    {
        HandleCommonUI.chooseFromDropdown(dropdown,value,true,true);
    }
}
