//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.CommonWait;

public class VisitorsOnline
{
    public static Boolean startedLeave = false;
    public static Boolean startedPresent = false;
    public static Boolean wmsStartedPresent = false;
    public static ExtentTest etestLeave = null;
    public static ExtentTest etestPresent = null;
    public static ExtentTest etestWMS = null;
    public static String messageLeave = "";
    public static String messagePresent = "";
    public static String initialNotLeaveMsg = "Visitor not left in the rings | *Portal name* - ";
    public static String initialNotPresentMsg = "Visitor not shown in the rings | *Portal name* - ";


    public static boolean waitTillVisitorTracked(final WebDriver driver,final WebDriver visitor_driver)
    {
        boolean isTracked=true;

        FluentWait wait = CommonUtil.waitreturner(driver,10,1);

        try
        {
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(isVisitorTracked(driver,visitor_driver))
                        {
                            return true;
                        }
                        return false;
                    }
                    catch(Exception e1)
                    {

                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            isTracked=false;
            e.printStackTrace();
        }

        return isTracked;
    }

    public static boolean isVisitorTracked(WebDriver driver,WebDriver visitor_driver) throws Exception
    {
        Tab.clickVisitorsOnline(driver);

        String visitor_id=VisitorWindow.getVisitorId(visitor_driver,ExecuteStatements.getPortal(driver));

        if(visitor_id==null || visitor_id.equals("Visitor id cannot be found from cookie"))
        {
            return false;
        }

        return isVisitorTracked(driver,visitor_id);
    }

    public static boolean isVisitorTracked(WebDriver driver,String visitor_id) throws Exception
    {
        return CommonWait.isDisplayed(driver,By.id("ldwrap"),By.id(visitor_id));
    }    

    public static void waitTillVisitorLeaves(WebDriver driver) throws Exception
    {
        Tab.clickVisitorsOnline(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,80,250);
        
        Exception expection = null;

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("ldwrap")).getAttribute("innerHTML").contains("visit_div"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            return;
        }
        catch(Exception e)
        {
            expection = e;
        }

        if(!startedLeave)
        {
            startedLeave = true;

            etestLeave = ComplexReportFactory.getTest("Visitor left the rings");
            ComplexReportFactory.setValues(etestLeave,"Automation","Issues");

            messageLeave = initialNotLeaveMsg;
        }

        WebElement div = CommonUtil.elfinder(driver,"id","ldwrap");

        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        String time = df.format(dateobj);

        String portal = ExecuteStatements.getPortal(driver);
        
        String userMail = ExecuteStatements.getUserMail(driver);
        
        System.out.println("Visitor in rings for portal "+portal+" in account "+userMail+" @"+time+" --- "+div.getAttribute("innerHTML"));

        List<WebElement> list = div.findElements(By.className("visit_div"));

        String ids = "";

        for(WebElement e : list)
        {
           ids += e.getAttribute("id")+"<><><>";
        }

        etestLeave.log(Status.FAIL,"Visitor in rings for portal "+portal+" in account "+userMail+getDetails(driver)+" @"+time+" --- "+ids);
        TakeScreenshot.screenshot(driver,etestLeave,"VisitorOnline","VisitorNotLeft","Error");

        if(messageLeave.contains(portal))
        {
          // to skip repetition in a single portal
        }
        else if(messageLeave.equals(initialNotLeaveMsg))
        {
            messageLeave+= portal;
        }
        else
        {
            messageLeave += ", "+portal;
        }

        throw expection;
    }

    public static void waitTillVisitorLeaves(WebDriver driver, final String id) throws Exception
    {
        Tab.clickVisitorsOnline(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,80,250);
        
        Exception expection = null;

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("ldwrap")).getAttribute("innerHTML").contains(id))
                    {
                        return true;
                    }
                    return false;
                }
            });

            return;
        }
        catch(Exception e)
        {
            expection = e;
        }

        if(!startedLeave)
        {
            startedLeave = true;

            etestLeave = ComplexReportFactory.getTest("Visitor left the rings");
            ComplexReportFactory.setValues(etestLeave,"Automation","Issues");

            messageLeave = initialNotLeaveMsg;
        }

        WebElement div = CommonUtil.elfinder(driver,"id","ldwrap");

        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        String time = df.format(dateobj);

        String portal = ExecuteStatements.getPortal(driver);
        
        String userMail = ExecuteStatements.getUserMail(driver);
        
        System.out.println("Visitor in rings for portal "+portal+" in account "+userMail+" @"+time+" --- "+div.getAttribute("innerHTML"));

        List<WebElement> list = div.findElements(By.className("visit_div"));

        etestLeave.log(Status.FAIL,"Visitor in rings for portal "+portal+" in account "+userMail+getDetails(driver)+" @"+time+" --- "+id);
        TakeScreenshot.screenshot(driver,etestLeave,"VisitorOnline","VisitorNotLeft","Error");

        if(messageLeave.contains(portal))
        {
          // to skip repetition in a single portal
        }
        else if(messageLeave.equals(initialNotLeaveMsg))
        {
            messageLeave+= portal;
        }
        else
        {
            messageLeave += ", "+portal;
        }

        throw expection;
    }

    public static void waitTillVisitorPresent(WebDriver driver,final String id) throws Exception
    {
        Tab.clickVisitorsOnline(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,80,250);

        String noID = "Visitor id cannot be found from cookie";
        
        if(noID.equals(id))
        {
            System.out.println(id.replace(null, "to break the flow"));
        }
        
        Exception exp = null;

        try
        {
          wait.until(new Function<WebDriver,Boolean>(){
              public Boolean apply(WebDriver driver)
              {
                  if(driver.findElement(By.id("ldwrap")).getAttribute("innerHTML").contains(id))
                  {
                      return true;
                  }
                  return false;
              }
          });

          WebElement visitor = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldwrap"),"id",id);

          wait.until(ExpectedConditions.visibilityOf(visitor));

          String initialStyle = visitor.getAttribute("style");
          Long t0 = new Long(System.currentTimeMillis());
          Long t1 = new Long(System.currentTimeMillis());

          for(;;)
          {
            String currentStyle = visitor.getAttribute("style");
            if(!initialStyle.equals(currentStyle))
            {
              initialStyle = currentStyle;
              t1 = new Long(System.currentTimeMillis());
            }
            else
            {
              Long t2 = new Long(System.currentTimeMillis());
              if(t2 - t1 > 2000 || t2 - t0 > 20000)
              {
                break;
              }
            }
          }

          return;
        }
        catch(Exception e)
        {
          exp = e;
        }
        
        wait = CommonUtil.waitreturner(driver,3,250);
        
        Boolean wmsPresence = false;
        
        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("lschatbar"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lschatbar")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lschatbar")));
            
            wmsPresence = true;
        }
        catch(Exception e){}
        
        if(!wmsPresence)
        {
            if(!wmsStartedPresent)
            {
                wmsStartedPresent = true;
                
                etestWMS = ComplexReportFactory.getTest("WMS Bar");
                ComplexReportFactory.setValues(etestWMS,"Automation","Issues");
            }
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String time = df.format(dateobj);
            
            String userMail = ExecuteStatements.getUserMail(driver);
            
            etestWMS.log(Status.FAIL,"WMS Bar not shown in account "+userMail+"@ "+time+"--");
            TakeScreenshot.screenshot(driver,etestWMS,"VisitorOnline","WMSBarNotPresent","Error");
            
            throw exp;
        }

        if(!startedPresent)
        {
            startedPresent = true;

            etestPresent = ComplexReportFactory.getTest("Visitor in the rings");
            ComplexReportFactory.setValues(etestPresent,"Automation","Issues");

            messagePresent = initialNotPresentMsg;
        }

        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        String time = df.format(dateobj);

        String portal = ExecuteStatements.getPortal(driver);

        String userMail = ExecuteStatements.getUserMail(driver);

        etestPresent.log(Status.FAIL,"Visitor not shown in rings for portal "+portal+" in account "+userMail+getDetails(driver)+"@ "+time+" --UVID--"+id);
        printDetails(driver,etestPresent,time);
        TakeScreenshot.screenshot(driver,etestPresent,"VisitorOnline","VisitorNotPresent","Error");

        if(messagePresent.contains(portal))
        {
          // to skip repetition in a single portal
        }
        else if(messagePresent.equals(initialNotPresentMsg))
        {
            messagePresent+= portal;
        }
        else
        {
            messagePresent += ", "+portal;
        }

        throw exp;
    }

    public static WebElement getVisitor(WebDriver driver,String visitor_id)
    {
        return CommonUtil.getElement(driver,By.id(visitor_id));
    }

    public static String getVisitorNameByVisitorId(WebDriver driver,String visitor_id) throws Exception
    {
        Tab.clickVisitorsOnline(driver);
        return CommonUtil.getElement(driver,By.id("name_"+visitor_id)).getText();
    }
    
    public static void clickVisitor(WebElement e) throws Exception
    {
        try
        {
            VisitorsOnline.waitTillVisitorStableInRings(e,"1");
            e.click();
        }
        catch(WebDriverException excep)
        {
            VisitorsOnline.waitTillVisitorStableInRings(e,"2");
            e.click();
        }
    }
    
    public static void waitTillVisitorStableInRings(WebElement e,String check) throws Exception
    {
        String s1 = e.getAttribute("style");
        
        Long t1 = new Long(System.currentTimeMillis());
        Long startingTime = new Long(System.currentTimeMillis());
        
        for(;;)
        {
            String s2 = e.getAttribute("style");
            
            if(!s2.equals(s1))
            {
                s1 = s2;
                t1 = new Long(System.currentTimeMillis());
            }
            
            Long t2 = new Long(System.currentTimeMillis());
            if(t2 - t1 > 1000)
            {
                System.out.println("waitTillVisitorStableInRings<1>"+check+"<>"+(t2-startingTime)+"<>");
                break;
            }
            if(t2 - startingTime > 5000)
            {
                System.out.println("waitTillVisitorStableInRings<2>"+check+"<>"+(t2-startingTime)+"<>");
                break;
            }
            
            Thread.sleep(200);
        }
    }

    public static void waitTillVisitorStableInRings(WebElement visitor) throws Exception
    {
        waitTillVisitorStableInRings(visitor,"");   
    }

    public static void printDetails(WebDriver driver, ExtentTest etest, String time) throws Exception
    {
        WebElement e = null;

        String content = "Email:"+ExecuteStatements.getUserMailWithoutExcep(driver)+", UTSHandler.counter:"+ExecuteStatements.getUTSHandlerCounterWithOutExcep(driver)
            +", UTSHandler.priority:"+ExecuteStatements.getUTSHandlerPriorityWithOutExcep(driver)+", UTSHandler.circlewidth:"+ExecuteStatements.getUTSHandlerCircleWidthWithOutExcep(driver)
            +", TrackingList.circleview:"+ExecuteStatements.getTrackingListCircleviewWithOutExcep(driver)+", UTSHandler.isTrackingPortal():"+ExecuteStatements.getUTSHandlerIsTrackingPortalWithOutExcep(driver);
        
        try
        {
            e = driver.findElement(By.id("ldwrap"));

            System.out.println(content+"<>InnerHTML of ldwrap @"+time+"<><>"+e.getAttribute("innerHTML"));
        }
        catch(NoSuchElementException excep)
        {
            System.out.println(content+"<>InnerHTML of ldwrap @"+time+"<><>Cant be found");
        }

        etest.log(Status.FAIL,content);
    }
    
    public static String getDetails(WebDriver driver) throws Exception
    {
        String msg = "";
        
        try
        {
            msg = "(RSid - "+ExecuteStatements.getRSid(driver);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return msg;
        }
        
        msg += ")";
        return msg;
    }

    public static void selectRingsViewInVisitorsOnline(WebDriver driver)
    {
        selectViewInVisitorsOnline(driver,"vo_ring");   
    }

    public static void selectListViewInVisitorsOnline(WebDriver driver)
    {
        selectViewInVisitorsOnline(driver,"vo_list");
    }

    public static void selectViewInVisitorsOnline(WebDriver driver,final String view_class_name)
    {
        try
        {
            CommonUtil.getElement(driver,By.id("customizeheader"),By.className("sqico-"+view_class_name)).click();
            FluentWait wait=CommonUtil.waitreturner(driver,5,100);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(CommonUtil.getElement(driver, By.id("customizeheader"),By.className("tgl_ticon")).getAttribute("class").toString().contains(view_class_name))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
