//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;


public class UsersTab
{
    public static void addUser(WebDriver driver, String username, String role, ArrayList<String> department, ExtentTest etest)throws Exception
    {
        String id = null;
        
        switch(role)
        {
            case "admin":id = "agentyp_admin";break;
            case "supervisor":id = "agentyp_super";break;
            case "associate":id = "agentyp_agent";break;
        }
        
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        Tab.clickSettings(driver);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonuseradd")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("buttonuseradd")));
        
        CommonUtil.elfinder(driver,"id","buttonuseradd").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("useraddpage")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("useraddpage")));
        
        WebElement page = CommonUtil.elfinder(driver,"id","useraddpage");
        
        CommonUtil.elementfinder(driver,page,"id","txtuname").sendKeys(username);
        
        CommonUtil.elementfinder(driver,page,"id",id).click();
        
        WebElement depts = CommonUtil.elementfinder(driver,page,"id","seldepartment");
        
        if(depts.isDisplayed())
        {
            List<WebElement> list = depts.findElements(By.className("field_div"));
            
            for(WebElement e : list)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+e.getLocation().y+"-300)");
                
                if(department == null)
                {
                    CommonUtil.elementfinder(driver,e,"tagname","em").click();
                    break;
                }
                if(department.contains(e.getText()))
                {
                    CommonUtil.elementfinder(driver,e,"tagname","em").click();
                }
            }
        }
        
        WebElement save = CommonUtil.elementfinder(driver,page,"id","useradd");
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+save.getLocation().y+"-300)");
        save.click();
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Operator added successfully","addportaluser.do",etest);
    }
    
    public static void deleteUser(WebDriver driver, String username, ExtentTest etest)throws Exception
    {
        WebElement e = getUser(driver,username);
        
        WebElement del = CommonUtil.elementfinder(driver,e,"classname","list_cmndlttxt");
        
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.visibilityOf(del));
        
        del.click();
        
        WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");
        
        wait.until(ExpectedConditions.visibilityOf(popup));
        
        WebElement ok = CommonUtil.elementfinder(driver,popup,"id","okbtn");
        
        wait.until(ExpectedConditions.visibilityOf(ok));
        
        ok.click();
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Operator deleted successfully","delportaluser.do",etest);
    }
    
    public static List<WebElement> getUsersList(WebDriver driver) throws Exception
    {
        Tab.clickSettings(driver);
        
        List<WebElement> list = CommonUtil.elfinder(driver,"id","ulisttable").findElements(By.className("list-row"));
        
        return list;
    }
    
    public static WebElement getUser(WebDriver driver, String username) throws Exception
    {
        List<WebElement> list = getUsersList(driver);
        
        for(WebElement e : list)
        {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+e.getLocation().y+"-300)");
            
            if(CommonUtil.elementfinder(driver,e,"classname","txtelips").getText().equals(username))
            {
                return e;
            }
        }
        
        return null;
    }

    public static void clickUser(WebDriver driver,String username) throws Exception
    {
        getUser(driver,username).findElement(By.className("txtelips")).click();
        WebElement userdetails=CommonUtil.getElement(driver,By.id("userdetails"));
        CommonUtil.waitTillWebElementDisplayed(driver,userdetails);
    }

    public static void clickEditProfile(WebDriver driver)
    {
        List<WebElement> buttons = driver.findElements(By.className("bt"));

        final String EDIT_BUTTON_HREF_REGEX=".+#(setting/user|user/myprofile).+edit.+";

        CommonUtil.getElementByAttributeValue(buttons,"href",EDIT_BUTTON_HREF_REGEX).findElement(By.tagName("span")).click();
        WebElement useredit=CommonUtil.getElement(driver,By.id("useredit"));
        CommonUtil.waitTillWebElementDisplayed(driver,useredit);
    }

    public static void selectConcurrentChatsValue(WebDriver driver,String value)
    {
        ConcurrentChatCommonFunctions.selectConcurrentChatsValue(driver,value);
    }

    public static void clickUpdateUserInfoButton(WebDriver driver)
    {
        WebElement update_info_button=CommonUtil.getElement(driver,By.id("useradd"));
        CommonUtil.scrollToBottomOfPage(driver);
        update_info_button.click();
        WebElement userdetails=CommonUtil.getElement(driver,By.id("userdetails"));
        CommonUtil.waitTillWebElementDisplayed(driver,userdetails);
    }

    public static String getRandomOperatorId(WebDriver driver) throws Exception
    {
        return getUsersList(driver).get(1).getAttribute("id");
    }
}
