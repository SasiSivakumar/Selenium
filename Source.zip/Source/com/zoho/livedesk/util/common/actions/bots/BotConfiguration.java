//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import com.zoho.livedesk.client.bots.BotsCRUD;


public class BotConfiguration
{
    public static final By
    SALESIQ_SCRIPT=By.id("dre"),
    DIALOGFLOW_CONFIG=By.id("dialogflow"),
    WATSON_CONFIG=By.id("watson"),
    ZIA_CONFIG=By.id("ziaplatform"),
    WEBHOOK_CONFIG=By.id("webhook"),
    BOT_NAME=By.id("botname"),
    BOT_DESCRIPTION=By.id("botdesc"),
    WEBSITE_DROPDOWN_CONTAINER=By.id("appdropdown"),
    WEBSITE_DROPDOWN=By.id("appdropdown_ddown"),
    // TOGGLE_DEPARTMENTS=By.cssSelector(".linkdisplay:not([style*=none])"),
    SHOW_DEPARTMENTS=By.id("showbotdept"),
    HIDE_DEPARTMENTS=By.id("hidebotdept"),
    DEPARTMENT_LIST=By.id("botappdeptlist"),
    DEPARTMENT_CONTAINER=By.cssSelector("[documentclick='selectBotDept']"),
    CLOSE=By.id("close-bot"),
    BUSINESS_HOUR_RADIO_BTN=By.id("workinghrs_rbtn"),
    BUSINESS_HOUR_DROPDOWN=By.id("workinghrs_dropdown_ddown"),
    BUSINESS_HOUR_CURRENT_VALUE_CONTAINER=By.cssSelector("span[val]"),
    CONNECT_OPERATOR_TOGGLE=By.id("enable_handoff"),
    SAVE=By.id("creathomebtn"),
    DEPARTMENT_SELECT_CHECKBOX=By.className("dept-sel"),
    ADD_TRIGGER=By.id("setbotcriteria"),
    REMOVE_TRIGGER=By.id("clearbotrule"),
    TRIGGER_CONTAINER=By.id("ldsettings"),
    TRIGGER_APPLY=By.cssSelector("[onclick*='applyAdvanceFilter']"),
    BOT_CONNECTION_CONTAINER=By.id("custombot"),
    BOT_CONNECTION_ERROR=By.className("err-txt"),
    BUSINESS_HOUR_OPTIONS = By.className("uprdowrap")
    ;

    public static final String
    TRIGGER_DROPDOWN_TEMPLATE=".combosubdrpdwnmn[id*='col<number>']",
    TRIGGER_DROPDOWN_CONTAINER_TEMPLATE="col<number>";
    ;

    public static final String
    ALL_TIME_BUSINESS_HOUR=ResourceManager.getRealValue("all_time_business_hour"),
    STANDARD_BUSINESS_HOUR=ResourceManager.getRealValue("standard_business_hour"),
    NON_BUSINESS_HOUR=ResourceManager.getRealValue("non_business_hour"),
    no_operator_during_business_hours=ResourceManager.getRealValue("no_operator_during_business_hours")
    ;

    public static final String[]
    BUSINESS_HOUR_VALUES={"DummyValue",ALL_TIME_BUSINESS_HOUR,STANDARD_BUSINESS_HOUR,NON_BUSINESS_HOUR,no_operator_during_business_hours}
    ;

    public static final int
    ALL_TIME_BUSINESS_HOUR_VALUE=1,
    STANDARD_BUSINESS_HOUR_VALUE=2,
    NON_BUSINESS_HOUR_VALUE=3,
    no_operator_during_business_hours_value=4
    ;

    public static boolean clickSave(WebDriver driver)
    {
        CommonWait.waitTillPresent(driver,SAVE);
        CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver,SAVE) );
        CommonWait.waitTillDisplayed(driver,SAVE);
        CommonUtil.getElement(driver,SAVE).click();
        return DelugeScript.waitTillBotUpdated(driver);
    }

    public static WebElement getBotNameInput(WebDriver driver)
    {
        CommonUtil.scrollIntoView(driver,BOT_NAME);
        CommonWait.waitTillDisplayed(driver,BOT_NAME);
        return CommonUtil.getElement(driver,BOT_NAME);
    }

    public static WebElement getBotDescriptionInput(WebDriver driver)
    {
        CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver,BOT_NAME) );
        CommonWait.waitTillDisplayed(driver,BOT_DESCRIPTION);
        return CommonUtil.getElement(driver,BOT_DESCRIPTION);
    }

    public static boolean checkPlaceHolders(WebDriver driver,ExtentTest etest)
    {
        int failcount=0;

        String expected=null,actual=null;

        actual=getBotNameInput(driver).getAttribute("placeholder");
        expected=ResourceManager.getRealValue("bot_name_placeholder");

        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"bot name placeholder",etest))
        {
            failcount++;
        }

        actual=getBotDescriptionInput(driver).getAttribute("placeholder");
        expected=ResourceManager.getRealValue("bot_desc_placeholder");
        
        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"bot description placeholder",etest))
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static void selectWebsite(WebDriver driver,String website)
    {
        CommonUtil.scrollIntoView(driver,BOT_NAME);
        CommonWait.waitTillDisplayed(driver,WEBSITE_DROPDOWN_CONTAINER);
        CommonUtil.getElement(driver,WEBSITE_DROPDOWN_CONTAINER).click();
        WebElement dropdown=CommonUtil.getElement(driver,WEBSITE_DROPDOWN);
        HandleCommonUI.chooseFromDropdown(dropdown,website,true,true);
    }

    public static boolean toggleDepartments(WebDriver driver,boolean isShowDepartment)
    {
        CommonUtil.scrollIntoView(driver,BOT_NAME);

        if(isShowDepartment && CommonWait.isPresent(driver,SHOW_DEPARTMENTS))
        {
            CommonWait.waitTillDisplayed(driver,SHOW_DEPARTMENTS);
            CommonUtil.getElement(driver,SHOW_DEPARTMENTS).click();
            return CommonWait.waitTillDisplayed(driver,DEPARTMENT_LIST);
        }
        else if(!isShowDepartment && CommonWait.isPresent(driver,HIDE_DEPARTMENTS))
        {
            CommonWait.waitTillDisplayed(driver,HIDE_DEPARTMENTS);
            CommonUtil.getElement(driver,HIDE_DEPARTMENTS).click();
            return CommonWait.waitTillHidden(driver,DEPARTMENT_LIST);
        }

        return true;
    }

    public static void selectDepartment(WebDriver driver,String... departments)
    {
        if(departments==null)
        {
            //function will throw exception/fail
            departments = new String[0];
        }

        showDepartments(driver);

        //first select given department,then we unselect departments not given in input in two loops. this is done because according to ui flow. when only one department is selected, it cant be deselected.

        List<WebElement> department_containers=CommonUtil.getElements(driver,DEPARTMENT_CONTAINER);

        for(WebElement department_container : department_containers)
        {
            String department=department_container.getAttribute("innerText").trim();

            boolean isDepartmentSelectedAlready=Boolean.parseBoolean(department_container.getAttribute("status"));

            CommonUtil.scrollIntoView(driver,department_container);
            CommonUtil.mouseHover(driver,department_container);

            //Select required depts which are unselected
            if(Arrays.asList(departments).contains(department) && !isDepartmentSelectedAlready)
            {
                CommonUtil.getElement(department_container,DEPARTMENT_SELECT_CHECKBOX).click();

                if(CommonUtil.waitTillWebElementContainsAttributeValue(department_container,"status","true")==false)
                {
                    throw new ZohoSalesIQRuntimeException("Department '"+department+"' was not selected after clicking.");
                }
            }
        }

        for(WebElement department_container : department_containers)
        {
            String department=department_container.getAttribute("innerText").trim();

            boolean isDepartmentSelectedAlready=Boolean.parseBoolean(department_container.getAttribute("status"));

            CommonUtil.scrollIntoView(driver,department_container);
            CommonUtil.mouseHover(driver,department_container);

            //unselect other depts which are selected
            if(Arrays.asList(departments).contains(department)==false && isDepartmentSelectedAlready)
            {

                CommonUtil.getElement(department_container,DEPARTMENT_SELECT_CHECKBOX).click();

                if(CommonUtil.waitTillWebElementContainsAttributeValue(department_container,"status","false")==false)
                {
                    throw new ZohoSalesIQRuntimeException("Department '"+department+"' was not deselected after clicking. (This will usually occur when only department '"+department+"' is currently enabled)");                    
                }
            }
        }
    }

    public static ArrayList<String> getDepartments(WebDriver driver)
    {
        CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver,BOT_NAME) );

        ArrayList<String> department_names=new ArrayList<String>();

        showDepartments(driver);

        List<WebElement> department_containers=CommonUtil.getElements(driver,DEPARTMENT_CONTAINER);


        for(WebElement department_container : department_containers)
        {
            boolean isDepartmentSelected=Boolean.parseBoolean(department_container.getAttribute("status"));

            if(isDepartmentSelected)
            {
                String department=department_container.getAttribute("innerText").trim();
                department_names.add(department);                
            }
        }

        return department_names;
    }

    public static void showDepartments(WebDriver driver)
    {
        if(CommonWait.isDisplayed(driver,DEPARTMENT_LIST)==false)
        {
            toggleDepartments(driver,true);
        }
    }

    public static boolean openDialogflowConfiguration(WebDriver driver)
    {
        CommonWait.waitTillPresent(driver,DIALOGFLOW_CONFIG);
        CommonUtil.scrollIntoView(driver,true,DIALOGFLOW_CONFIG);
        CommonWait.waitTillDisplayed(driver,DIALOGFLOW_CONFIG);
        CommonUtil.getElement(driver,DIALOGFLOW_CONFIG).click();
        return DialogflowConfiguration.waitTillPageLoads(driver);
    }

    public static boolean openZiaConfiguration(WebDriver driver)
    {
        CommonWait.waitTillPresent(driver,ZIA_CONFIG);
        CommonUtil.scrollIntoView(driver,true,ZIA_CONFIG);
        CommonWait.waitTillDisplayed(driver,ZIA_CONFIG);
        CommonUtil.getElement(driver,ZIA_CONFIG).click();
        return ZiaConfiguration.waitTillPageLoads(driver);
    }

    public static boolean openWatsonConfiguration(WebDriver driver)
    {
        CommonWait.waitTillPresent(driver,WATSON_CONFIG);
        CommonUtil.scrollIntoView(driver,true,WATSON_CONFIG);
        CommonWait.waitTillDisplayed(driver,WATSON_CONFIG);
        CommonUtil.getElement(driver,WATSON_CONFIG).click();
        return WatsonConfiguration.waitTillPageLoads(driver);
    }

    public static boolean openWebhookConfiguration(WebDriver driver)
    {
        CommonWait.waitTillPresent(driver,WEBHOOK_CONFIG);
        CommonUtil.scrollIntoView(driver,true,WEBHOOK_CONFIG);
        CommonWait.waitTillDisplayed(driver,WEBHOOK_CONFIG);
        CommonUtil.getElement(driver,WEBHOOK_CONFIG).click();
        return WebhookConfiguration.waitTillPageLoads(driver);
    }

    public static void clickOpenSalesIQScript(WebDriver driver)
    {
        clickOpenSalesIQScript(driver,true);
    }

    public static void clickOpenSalesIQScript(WebDriver driver,boolean isWait)
    {
        CommonWait.waitTillPresent(driver,SALESIQ_SCRIPT);
    CommonUtil.scrollIntoView(driver,true,SALESIQ_SCRIPT);
        CommonWait.waitTillDisplayed(driver,SALESIQ_SCRIPT);
        CommonUtil.getElement(driver,SALESIQ_SCRIPT).click();

        if(isWait)
        {
            DelugeScript.isManageConnectionsButtonDisplayed(driver,true);
        }
    }

    public static void checkSalesIQScriptUI(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillPresent(driver,SALESIQ_SCRIPT);
        CommonUtil.scrollIntoView(driver,true,CommonUtil.getElement(driver,SALESIQ_SCRIPT) );
        CommonWait.waitTillDisplayed(driver,SALESIQ_SCRIPT);
        CommonSikuli.findInWholePage(driver,"UI437.png","UI437",etest);
        CommonSikuli.findInWholePage(driver,"UI434.png","UI434",etest);
        CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver,BOT_NAME) );
    }


    //safer method to be used at end of tests
    public static boolean close(WebDriver driver)
    {
        if(CommonWait.isDisplayed(driver,CLOSE))
        {
            return closeBotConfigurationPage(driver);
        }

        return true;//already closed
    }

    public static boolean closeBotConfigurationPage(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,CLOSE);
        CommonUtil.getElement(driver,CLOSE).click();
        return CommonWait.waitTillHidden(driver,CLOSE);
    }

    public static boolean createBot(WebDriver driver,ExtentTest etest,Hashtable<String,String> bot_info)
    {
        Tab.navToBotsTab(driver);
        BotsTab.clickAddBot(driver);

        etest.log(Status.INFO,"Bot '"+bot_info.get(BotInfo.NAME)+"' is being created with below configuration.\n"+bot_info.toString());

        BotsCRUD.createBotSikuli(driver,etest);

        //set bot name
        editBotName(driver,bot_info.get(BotInfo.NAME));

        //set bot description
        editBotDescription(driver,bot_info.get(BotInfo.DESCRIPTION));

        //set bot website
        selectWebsite(driver,bot_info.get(BotInfo.WEBSITE));

        //set bot department
        String[] depts=bot_info.get(BotInfo.DEPARTMENTS).split(",");
        selectDepartment(driver,depts);

        clearCurrentTriggers(driver);

        //set business hours config
        if(bot_info.containsKey(BotInfo.BUSINESS_HOUR))
        {
            //NEED TO REIMPLEMENT THIS
            int business_hour_value=Integer.parseInt(bot_info.get(BotInfo.BUSINESS_HOUR));
            setBusinessHourConfig(driver,business_hour_value);
        }

        TakeScreenshot.infoScreenshot(driver,etest);

        //set script type
        if(bot_info.get(BotInfo.SCRIPT_TYPE).equals(BotInfo.SALESIQ_SCRIPT_TYPE))
        {
            clickOpenSalesIQScript(driver);

            //INCOMPLETE
            //if script path is given, set script for given handlers.

            if(bot_info.containsKey(BotInfo.PUBLISH_ACTION)==false)
            {
                bot_info.put(BotInfo.PUBLISH_ACTION,BotInfo.CREATE_ONLY);
            }

            if(bot_info.get(BotInfo.PUBLISH_ACTION).equals(BotInfo.CREATE_AND_PUBLISH))
            {
                //create and publish
                DelugeScript.clickPublish(driver);
            }
            else if(bot_info.get(BotInfo.PUBLISH_ACTION).equals(BotInfo.CREATE_ONLY))
            {
                //create bot
                DelugeScript.clickCreateBot(driver);
            }

            TakeScreenshot.infoScreenshot(driver,etest);

            BotsCRUD.checkBotPreviewLoaded(driver,etest);

            CommonSikuli.findInWholePage(driver,"UI443.png","UI443",etest);

            DelugeScript.close(driver);

            Tab.navToBotsTab(driver);
            TakeScreenshot.infoScreenshot(driver,etest);

            etest.log(Status.PASS,"Bot '"+bot_info.get(BotInfo.NAME)+"' is created");
        }

        return BotsTab.isBotPresent(driver,bot_info.get(BotInfo.NAME));     
    }

    public static boolean createDialogflowBot(WebDriver driver,ExtentTest etest,String name,String desc,String website,String department,String agent_name,String... trigger_messages)
    {
        Tab.navToBotsTab(driver);
        BotsTab.clickAddBot(driver);
        BotConfiguration.editBotName(driver,name);
        BotConfiguration.editBotDescription(driver,desc);
        BotConfiguration.selectWebsite(driver,website);
        BotConfiguration.selectDepartment(driver,department);

        clearCurrentTriggers(driver);

        BotConfiguration.openDialogflowConfiguration(driver);

        //if agent_name is null, then bot will be created with the preselected agent name.
        if(agent_name!=null)
        {
            DialogflowConfiguration.selectDialogflowAgent(driver,agent_name);
        }

        DialogflowConfiguration.setTriggerMessages(driver,etest,trigger_messages);
        DialogflowConfiguration.clickCreateBot(driver);
        etest.log(Status.INFO,"Dialogflow bot '"+name+"' was created");
        TakeScreenshot.infoScreenshot(driver,etest);
        close(driver);

        return true;
    }

    public static boolean createZiaBot(WebDriver driver,ExtentTest etest,String name,String desc,String website,String department,String agent_name,String trigger_message)
    {
        Tab.navToBotsTab(driver);
        BotsTab.clickAddBot(driver);
        BotConfiguration.editBotName(driver,name);
        BotConfiguration.editBotDescription(driver,desc);
        BotConfiguration.selectWebsite(driver,website);
        BotConfiguration.selectDepartment(driver,department);

        clearCurrentTriggers(driver);
        
        BotConfiguration.openZiaConfiguration(driver);

        //if agent_name is null, then bot will be created with the preselected agent name.
        if(agent_name!=null)
        {
            ZiaConfiguration.selectZiaAgent(driver,agent_name);
        }

        ZiaConfiguration.setTriggerMessage(driver,etest,trigger_message);
        DialogflowConfiguration.clickCreateBot(driver);
        etest.log(Status.INFO,"Zia bot '"+name+"' was created");
        TakeScreenshot.infoScreenshot(driver,etest);
        close(driver);

        return true;
    }

    public static boolean createWatsonBot(WebDriver driver,ExtentTest etest,String name,String desc,String website,String department,String assistant_id,String... trigger_messages)
    {
        Tab.navToBotsTab(driver);
        BotsTab.clickAddBot(driver);
        BotConfiguration.editBotName(driver,name);
        BotConfiguration.editBotDescription(driver,desc);
        BotConfiguration.selectWebsite(driver,website);
        BotConfiguration.selectDepartment(driver,department);
        clearCurrentTriggers(driver);
        BotConfiguration.openWatsonConfiguration(driver);

        WatsonConfiguration.enterAssistantID(driver,assistant_id);

        WatsonConfiguration.setTriggerMessages(driver,etest,trigger_messages);
        WatsonConfiguration.clickCreateBot(driver);
        etest.log(Status.INFO,"Watson bot '"+name+"' was created");
        TakeScreenshot.infoScreenshot(driver,etest);
        close(driver);

        return true;
    }

    public static void editBotName(WebDriver driver,String value)
    {
        CommonUtil.sendKeysToWebElement(driver,getBotNameInput(driver),value);       
    }

    public static void editBotDescription(WebDriver driver,String value)
    {
        CommonUtil.sendKeysToWebElement(driver,getBotDescriptionInput(driver),value);       
    }

    public static void setBusinessHourConfig(WebDriver driver,int business_hour_value)
    {
        WebElement radioButton = CommonUtil.getElement(driver,BUSINESS_HOUR_RADIO_BTN);
        CommonUtil.scrollIntoView(driver,radioButton);

        CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElements(radioButton,By.tagName("input")),"fval",""+business_hour_value));
    }

    public static void setConnectToHumanConfig(WebDriver driver,boolean isConnectToHuman)
    {
        WebElement toggle=CommonUtil.getElement(driver,CONNECT_OPERATOR_TOGGLE);
        CommonUtil.scrollIntoView(driver,SALESIQ_SCRIPT);
        CommonWait.waitTillDisplayed(toggle);
        HandleCommonUI.setToggle(toggle,isConnectToHuman);
    }

    public static void clearCurrentTriggers(WebDriver driver)
    {
        if(CommonWait.isDisplayed(driver,REMOVE_TRIGGER))
        {
            WebElement clear_button=CommonUtil.getElement(driver,REMOVE_TRIGGER);
            CommonUtil.scrollIntoView(driver,clear_button);
            CommonWait.waitTillDisplayed(clear_button);
            CommonUtil.clickWebElement(driver,clear_button);
            CommonWait.waitTillHidden(clear_button);            
        }
    }

    public static void clickAddTrigger(WebDriver driver)
    {
        clearCurrentTriggers(driver);
        CommonUtil.clickWebElement( driver, CommonUtil.getElement(driver,ADD_TRIGGER) );
        CommonWait.waitTillDisplayed(driver,TRIGGER_CONTAINER);
    }

    public static void setTriggerColumn(WebElement container,int column,String value)
    {
        WebElement dropdown_container=CommonUtil.getElement(container, By.className(TRIGGER_DROPDOWN_CONTAINER_TEMPLATE.replace("<number>",""+column)) );
        if(column == 3)
        {
            CommonUtil.getElement(dropdown_container,By.tagName("input")).click();
        }
        else
        {
            dropdown_container.click();
        }
        WebElement dropdown=CommonUtil.getElement(container,By.cssSelector( TRIGGER_DROPDOWN_TEMPLATE.replace("<number>",""+column) ) );
        HandleCommonUI.chooseFromDropdown(dropdown,value,true,true);
    }

    public static boolean triggerBotForAll(WebDriver driver,ExtentTest etest)
    {
        return triggerBot(driver,etest,ChatRouting.VISITOR_TYPE,ChatRouting.EQUALS,"All");
    }

    public static boolean triggerBot(WebDriver driver,ExtentTest etest,String field,String condition,String value)
    {
        clickAddTrigger(driver);

        WebElement container=CommonUtil.getElement(driver,TRIGGER_CONTAINER);

        setTriggerColumn(container,1,field);
        setTriggerColumn(container,2,condition);
        setTriggerColumn(container,3,value);

        TakeScreenshot.infoScreenshot(driver,etest);

        WebElement apply_button=CommonUtil.getElement(container,TRIGGER_APPLY);
        apply_button.click();

        CommonWait.waitTillHidden(container);

        etest.log(Status.INFO,"Trigger was set for the condition-->"+field+" "+condition+" "+value);

        return clickSave(driver);
    }

    public static boolean isBotCorrupt(WebDriver driver)
    {
        return CommonWait.isPresent(driver,BOT_CONNECTION_CONTAINER,BOT_CONNECTION_ERROR);
    }

    public static boolean isDialogflowBotCorrupt(WebDriver driver)
    {
        return isBotCorrupt(driver);
    }
}
