//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;

import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;


public class Status
{
    public static final String STATUS_ID="switch-bg";

    public static void changeStatus(WebDriver driver, String status, ExtentTest etest) throws Exception
    {
        String email = "email not found";
        String name = "username not found";
        
        try
        {
            email = ExecuteStatements.getUserMail(driver);
        }
        catch(Exception e){}
        try
        {
            name = ExecuteStatements.getUserName(driver);
        }
        catch(Exception e){}
        
        changeStatus(driver,status);
        
        etest.log(com.aventstack.extentreports.Status.INFO,"Status of "+email+"/"+name+" is changed to "+status);
    }
    
    public  static void changeStatus(WebDriver driver,String status) throws Exception
    {
      FluentWait wait = CommonUtil.waitreturner(driver,30,250);

      Thread.sleep(1000);

      try
      {
          if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("dnenable"))
          {
              driver.findElement(By.id("dnenable")).findElement(By.className("sqico-close")).click();
          }
      }
      catch(Exception e)
      {}
        
        final WebElement e = CommonUtil.elfinder(driver,"id","switch-bg");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!e.getAttribute("class").contains("switch-loadr"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e.getAttribute("class").contains("userstatus-"))
                {
                    return true;
                }
                return false;
            }
        });

      if(status.equals("available"))
      {
          if(!((CommonUtil.elfinder(driver,"id","switch-bg").getAttribute("class")).contains("userstatus-1")))
          {
              CommonUtil.elfinder(driver,"id","switch-bg").click();

              Thread.sleep(1000);

              wait.until(new Function<WebDriver,Boolean>(){
                  public Boolean apply(WebDriver driver)
                  {
                      if(getAgentStatus(driver)==AgentStatus.AVAILABLE || getAgentStatus(driver)==AgentStatus.ENGAGED)
                      {
                          return true;
                      }
                      return false;
                  }
              });
          }
      }
      else if(status.equals("busy"))
      {
          if(!((CommonUtil.elfinder(driver,"id","switch-bg").getAttribute("class")).contains("userstatus-3")))
          {
              CommonUtil.elfinder(driver,"id","switch-bg").click();

              Thread.sleep(1000);

              wait.until(new Function<WebDriver,Boolean>(){
                  public Boolean apply(WebDriver driver)
                  {
                       if(getAgentStatus(driver)==AgentStatus.BUSY || getAgentStatus(driver)==AgentStatus.ENGAGED)
                      {
                          return true;
                      }
                      return false;
                  }
              });
          }
      }
    }
    
    public static void waitTillAgentStatusChange(WebDriver driver, String agent, String status) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        String className = null;
        
        switch(status)
        {
            case "available": className = "sts-1";break;
            case "busy": className = "sts-3";break;
            case "offline": className = "sts-0";break;
        }
        
        WebElement icon = CommonUtil.elfinder(driver,"id","h_mycolleagues");
        WebElement div = CommonUtil.elfinder(driver,"id","mycolleagues");
        
        wait.until(ExpectedConditions.visibilityOf(icon));
        
        icon.click();
        
        wait.until(ExpectedConditions.visibilityOf(div));
        
        Long t1 = new Long(System.currentTimeMillis());
        Boolean result = false;
        Boolean agentPresence = false;
        
        int i = 0;
        
        for(;;)
        {
            String agentDiv = null;
            
            try
            {
                div = CommonUtil.elfinder(driver,"id","mycolleagues");
                
                List<WebElement> list = div.findElements(By.className("suprepmn"));
                
                for(WebElement e : list)
                {
                    String s = e.getAttribute("innerHTML");
                    
                    if(s.contains(">"+agent+"<"))
                    {
                        agentDiv = s;
                        agentPresence = true;
                    }
                }
                
                if(agentDiv != null && agentDiv.contains(className))
                {
                    System.out.println("waitTillAgentStatusChange<>0");
                    result = true;
                    break;
                }
            }
            catch(StaleElementReferenceException e)
            {
                /* div recreates when status changes*/
                
                i++;
                
                if(i == 5)
                {
                    System.out.println("waitTillAgentStatusChange<>"+agent+"<>3");
                    break;
                }
            }
            
            Long t2 = new Long(System.currentTimeMillis());
            if(t2 - t1 >= 60000)
            {
                System.out.println("waitTillAgentStatusChange<>"+agent+"<>"+agentDiv+"<>1");
                break;
            }
            
            if(t2 - t1 >= 5000 && !agentPresence)
            {
                System.out.println("waitTillAgentStatusChange<>"+agent+"<>2");
                break;
            }
            
            agentDiv = null;
        }
        
        if(!result)
        {
            "".replace(null,"to break the flow");
        }
        
        div = CommonUtil.elfinder(driver,"id","mycolleagues");
        
        icon.click();
        
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(div)));
    }

    public static AgentStatus getAgentStatus(WebDriver driver)
    {
        String status_class_name=CommonUtil.getElement(driver,By.id(STATUS_ID)).getAttribute("class");
        status_class_name = status_class_name.split(" ")[1];
        return ConcurrentChatConstants.getAgentStatusByClassName(status_class_name);
    }

    public static void waitTillCurrentAgentStatusChange(WebDriver driver,final AgentStatus expected_status)
    {
        FluentWait wait = CommonUtil.waitreturner(driver,5,50);

        wait.until(new Function<WebDriver,Boolean>()
        {
          public Boolean apply(WebDriver driver)
          {
              if(getAgentStatus(driver)==expected_status)
              {
                  return true;
              }
             return false;
          }
        });
    }

    public static boolean makeAgentAs(WebDriver driver,ExtentTest etest,AgentStatus status)
    {
      try
      {
        //if agent is offline, nav back one page
        if(status==AgentStatus.OFFLINE)
        {
          if(driver.getCurrentUrl().contains("salesiq"))
          {
              driver.get("https://www.google.com");
          }        
          return true;
        }

        if(driver.getCurrentUrl().contains("salesiq")==false)
        {
          CommonUtil.navigateToPreviousPage(driver);
        }

        AgentStatus current_status=getAgentStatus(driver);

        if(current_status==status)
        {
          return true;
        }

        //reset values if engaged
        if(current_status==AgentStatus.ENGAGED)
        {
          String user_name=ExecuteStatements.getUserName(driver);
          Portal portal = new Portal();
          User user = new User(user_name);
          ConcurrentChatCommonFunctions.setupAgentChatType(driver,etest,null,user);
          ConcurrentChatCommonFunctions.setupPortalChatType(driver,etest,null,portal);
          com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
        }

        //set statuses

        if(status==AgentStatus.AVAILABLE)
        {
          ChatWindow.closeAllChats(driver);
          com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
          return true;
        }

        if(status==AgentStatus.BUSY)
        {
          com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy",etest);
          return true;
        }

        if(status==AgentStatus.ENGAGED)
        {

          try
          {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
            String widget_code=ExecuteStatements.getWidgetCode(driver);
            Portal portal = new Portal("1",true,true);
            return ConcurrentChatCommonFunctions.setupPortalChatType(driver,etest,widget_code,portal);
          }
          catch(Exception e1)
          {
            if(getAgentStatus(driver)==AgentStatus.ENGAGED)
            {
              return true;
            }
            else
            {
              throw e1;
            }
          }
        }
      }
      catch(Exception e)
      {
        etest.log(com.aventstack.extentreports.Status.FAIL,"Could not set status as "+status);
        TakeScreenshot.screenshot(driver,etest,e);
        return  false;
      }

      return false;
    }
}
