//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.Triggers.CommonFunctions;
import com.zoho.livedesk.client.Triggers.ITRTime;
import com.zoho.livedesk.client.Triggers.VisitorSite;
import com.zoho.livedesk.client.VisitorRoutingRTTwo.CheckVisitorInUser;
import com.zoho.livedesk.client.VisitorRoutingRTTwo.CommonFunctionsVR;
import com.zoho.livedesk.client.VisitorRoutingRTTwo.visitorroutingRTTwo;
import com.zoho.livedesk.util.common.CommonUtil;

public class AutomationRuleCountCheck {
	
    public static boolean checkITRuleBrowser(WebDriver driver,ExtentTest etest, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            applyRule(driver,embedName,etest,"Lands on my website","Browser","is equal to","Google Chrome",null,"Invoke JS API","5 Seconds","test",null,true);
            visdriver = VisitorSite.createPage(widget_Code);            
            Thread.sleep(8000);
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the browser");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Browser","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Browser","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
    
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","Browser","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
	
	public static void getITRuleCount(WebDriver driver, ExtentTest etest) {
		try {		
			
                CommonWait.waitTillDisplayed(driver, By.id("rulelist"));     	   
				WebElement mouseHoverOnRule = CommonUtil.getElement(driver, By.className("data_subrow"));
				CommonUtil.mouseHover(driver, mouseHoverOnRule);
				etest.log(Status.INFO, "MouseOver On Rule");				
			WebElement getTriggerCount=CommonUtil.getElement(driver, By.className("sqico-trigger"));							
		
			etest.log(Status.INFO, "Trigger Count Check for Intelleigent Trigger is "+ getTriggerCount.getText());
			TakeScreenshot.infoScreenshot(driver, etest);	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "Intelligent Trigger-RT", "Trigger Rule Count Check", "Count not Checked", e);
		}
		
	}
		
	public static boolean checkITRuleCountCheck(WebDriver driver, ExtentTest etest) {
		try {
			
			  CommonWait.waitTillDisplayed(driver, By.id("rulelist"));     	   
				WebElement mouseHoverOnRule = CommonUtil.getElement(driver, By.className("data_subrow"));
				CommonUtil.mouseHover(driver, mouseHoverOnRule);
				etest.log(Status.INFO, "MouseOver On Rule");		
			    WebElement gettriggerCountCheck=CommonUtil.getElement(driver,  By.className("sqico-trigger"));
			    
			    if(!CommonUtil.checkStringContainsAndLog("1", gettriggerCountCheck.getText(), "Intelligent Trigger Rule Count Check", etest)) {					
					etest.log(Status.INFO, "Trigger Count Check is not Increased for Intelleigent Trigger is "+ gettriggerCountCheck.getText());
			    	TakeScreenshot.infoScreenshot(driver, etest);
			    	return false;
			    }
				etest.log(Status.INFO, "Trigger Count Check is Increased for Intelleigent Trigger is "+ gettriggerCountCheck.getText());
				TakeScreenshot.infoScreenshot(driver, etest);				
			    return true;		    
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "Intelligent Trigger-RT", "Trigger Rule Count Check", "Count not Checked", e);
		}	
		return false;		
	}
	
    public static boolean oneVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            WebDriver drivers[] = {driver1,driver2,driver3};

            if(!CommonFunctionsVR.waitTillVisitorLeaves(drivers))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRTTwo.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route to least loaded");
            
            return CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRTTwo.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    
    
	
	public static void getVRoutingRuleCount(WebDriver driver, ExtentTest etest) {
		try {			
                CommonWait.waitTillDisplayed(driver, By.id("rulelist"));     	   
				WebElement mouseHoverOnRule = CommonUtil.getElement(driver, By.className("data_subrow"));
				CommonUtil.mouseHover(driver, mouseHoverOnRule);
				etest.log(Status.INFO, "MouseOver On Rule");				
			WebElement getVRoutingCount=CommonUtil.getElement(driver, By.className("sqico-routed"));							
		
			etest.log(Status.INFO, "Trigger Count Check for VRouting is "+ getVRoutingCount.getText());
			TakeScreenshot.infoScreenshot(driver, etest);	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "VRouting", "Trigger Rule Count Check", "Count not Checked", e);
		}
		
	}
		
	public static boolean checkVRoutingRuleCountCheck(WebDriver driver, ExtentTest etest) {
		try {
			  CommonWait.waitTillDisplayed(driver, By.id("rulelist"));     	   
				WebElement mouseHoverOnRule = CommonUtil.getElement(driver, By.className("data_subrow"));
				CommonUtil.mouseHover(driver, mouseHoverOnRule);
				etest.log(Status.INFO, "MouseOver On Rule");		
			    WebElement getVRoutingCountCheck=CommonUtil.getElement(driver,  By.className("sqico-routed"));
			    
			    if(!CommonUtil.checkStringContainsAndLog("1", getVRoutingCountCheck.getText(), "Intelligent Trigger Rule Count Check", etest)) {					
					etest.log(Status.INFO, "Rule Count Check is not Increased for VRouting is "+ getVRoutingCountCheck.getText());
			    	TakeScreenshot.infoScreenshot(driver, etest);
			    	return false;
			    }
				etest.log(Status.INFO, "Rule Count Check is Increased for VRouting is "+ getVRoutingCountCheck.getText());
				TakeScreenshot.infoScreenshot(driver, etest);				
			    return true;		    
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "VRouting-RT", "Trigger Rule Count Check", "Count not Checked", e);
		}	
		return false;		
	}
	
	
	public static void getChatRoutingRuleCount(WebDriver driver, ExtentTest etest) {
		try {			
                CommonWait.waitTillDisplayed(driver, By.id("rulelist"));     	   
				WebElement mouseHoverOnRule = CommonUtil.getElement(driver, By.className("data_subrow"));
				CommonUtil.mouseHover(driver, mouseHoverOnRule);
				etest.log(Status.INFO, "MouseOver On Rule");				
			WebElement getChatRoutingCount=CommonUtil.getElement(driver, By.className("sqico-requested"));							
		
			etest.log(Status.INFO, "Trigger Count Check for ChatRouting is "+ getChatRoutingCount.getText());
			TakeScreenshot.infoScreenshot(driver, etest);	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "ChatRouting", "Trigger Rule Count Check", "Count not Checked", e);
		}
		
	}
		
	public static boolean checkChatRoutingRuleCountCheck(WebDriver driver, ExtentTest etest) {
		try {
			  CommonWait.waitTillDisplayed(driver, By.id("rulelist"));     	   
				WebElement mouseHoverOnRule = CommonUtil.getElement(driver, By.className("data_subrow"));
				CommonUtil.mouseHover(driver, mouseHoverOnRule);
				etest.log(Status.INFO, "MouseOver On Rule");		
			    WebElement getChatRoutingCountCheck=CommonUtil.getElement(driver,  By.className("sqico-requested"));
			    
			    if(!CommonUtil.checkStringContainsAndLog("1", getChatRoutingCountCheck.getText(), "Intelligent Trigger Rule Count Check", etest)) {					
					etest.log(Status.INFO, "Rule Count Check is not Increased for ChatRouting is "+ getChatRoutingCountCheck.getText());
			    	TakeScreenshot.infoScreenshot(driver, etest);
			    	return false;
			    }
				etest.log(Status.INFO, "Rule Count Check is Increased for ChatRouting is "+ getChatRoutingCountCheck.getText());
				TakeScreenshot.infoScreenshot(driver, etest);				
			    return true;		    
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "ChatRouting-RT", "Trigger Rule Count Check", "Count not Checked", e);
		}	
		return false;		
	}
	
	
    public static void applyRule(WebDriver driver,String embedName,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
       applyRule(driver,embedName,ITRTime.etest,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,true); 
    }
    public static void applyRule(WebDriver driver,String embedName,ExtentTest etest,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
        applyRule(driver,embedName,etest,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,false); 
    }
    
    public static void applyRule(WebDriver driver,String embedName,ExtentTest etest,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4,boolean isSelectEmbed) throws Exception
    {        
        Tab.navToITTab(driver);
        
        Trigger.clickAdd(driver,etest);
        
        String id = Trigger.getRuleId(driver,0);
       
        
        Boolean allTrue[] = {true,true,true,true,true,true,true,true,true};

        Trigger.openRuleEditView(driver,id);
        
        fillFields(driver,embedName,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,allTrue,isSelectEmbed);
        if(actionr1.equals("Add to mailing list"))
        {
            etest.log(Status.INFO,"Trigger is added");
            return;
        }

        id = Trigger.getRuleId(driver,0);

        boolean res = true;
        
        Boolean failed[] = CommonFunctions.checkValues(driver,etest,Status.INFO,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4);
        
        for(Boolean f : failed)
        {
            if(f)
            {
                res = false;
                break;
            }
        }
        
        if(res)
        {
            etest.log(Status.INFO,"Trigger is added");
        }
        else
        {
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggerRT","CheckRuleAdded","Error",0);
            
            etest.log(Status.INFO,"<pre>Second attempt ... </pre>");

            fillFields(driver, embedName,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,failed,isSelectEmbed);
            
            id = Trigger.getRuleId(driver,0);

            res = true;
            
            Boolean failed2[] = CommonFunctions.checkValues(driver,etest,Status.INFO,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4);
            
            for(Boolean f : failed2)
            {
                if(f)
                {
                    res = false;
                    break;
                }
            }
            
            if(res)
            {
                etest.log(Status.INFO,"Rule is added after second attempt");
                ITRTime.secondAttempt++;
                ITRTime.secondAttemptIds += id+";";
            }
            else
            {
                TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggerRT","CheckRuleAdded","Error");
                String s = null;
                s.replace("","to break the flow");
            }
        }
        
        Thread.sleep(3000);
    }
    
    public static void fillFields(WebDriver driver,String embedName, ExtentTest etest, String id, String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3, String actionr4, Boolean failed[]) throws Exception
    {
        fillFields(driver,embedName,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,failed,false);
    }
    
    public static void fillFields(WebDriver driver,String embedName, ExtentTest etest, String id, String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3, String actionr4, Boolean failed[],boolean isSelectEmbed) throws Exception
    {
        if(isSelectEmbed)
        {
            Rules.selectEmbed(driver, embedName);
            etest.log(Status.INFO, "EmbedName Founded : "+embedName);
        }

        if(failed[0])
        {
            Trigger.selectVisitorEvent(driver,id,event,etest);

            Trigger.saveRule(driver,etest,id);
            Trigger.openRuleEditView(driver,id);
        }

        Trigger.setRuleName(driver,id,com.zoho.livedesk.util.common.CommonUtil.getUniqueMessage());
        
        if(failed[1])
        {
            Trigger.selectCriteria(driver,id,ruler1,etest);
        }
                
        if(failed[2])
        {
            Trigger.selectCondition(driver,id,ruler2,etest);
        
        }
        
        if(failed[3] || failed[4])
        {
            Trigger.selectValues(driver,id,ruler3,ruler4,etest);
        }
        
        if(failed[5] || failed[6] || failed[7] || failed[8])
        {
            if((actionr1.equals("Open chat window"))||(actionr1.equals("Glow button"))||(actionr1.equals("Show bubble"))||(actionr1.equals("Show button")))
            {
                Trigger.selectAction(driver,id,actionr1,actionr2,etest);
            }
            else if((actionr1.equals("Send chat invite")) || (actionr1.equals("Invoke JS API")))
            {
                Trigger.selectAction(driver,id,actionr1,actionr2,actionr3,actionr4,etest);
            }
            else if(actionr1.equals("Animate button"))
            {
                Trigger.selectAction(driver,id,actionr1,actionr2,etest);
                Trigger.selectActionAnimate(driver,id,actionr3,etest);
            }
            else if(actionr1.equals("Add to mailing list"))
            {
            	CommonFunctions.selectActionMailingList(driver,id);
                Thread.sleep(1500);
    	    	WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"Add visitors to the Campaign Mailing List");
		    	com.zoho.livedesk.util.common.CommonWait.waitTillDisplayed(popup);
                Thread.sleep(1000); //to load completely
                etest.log(Status.INFO,"DESC "+popup.getText());
                HandleCommonUI.clickNegativePopupButton(popup);
            }
        }
        
        Trigger.saveRule(driver,etest,id);
        
        TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggerRT","Check","Before",0);
        
        Thread.sleep(10000);
        
        etest.log(Status.INFO,"Waited for 10 secs ...");
        
        driver.navigate().refresh();
    }
    	
	
}
