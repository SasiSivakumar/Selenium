//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import java.util.ArrayList;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;

public class GDPR
{
	public static final By
	GDPR_TOGGLE=By.id("isgdprenabled"),
	CHAT_LEARN_MORE_INPUT=By.id("chatlearnmorebanner"),
	LEARN_MORE_LINK_INPUT=By.id("learnmorebanner"),
    GDPR_CONFIG_CONTAINER=By.id("privacyconfig"),
    GDPR_TOGGLE_WEBSITES=By.id("ISGDPRENABLED0")
	;

	public static final String
	PASSWORD_PROTECTION_NAME="ispasswordprotected",
	GDPR_CHECKBOX_ATTRIBUTE="fval",
	TRACKING_NAME="trackingprivacyconfig",
	CHAT_NAME="chatprivacyconfig"
	;

	//method setTracking valid action params
	public static final String
	TRACKING_DO_NOT_NOTIFY="0",
	TRACKING_NOTIFY="1",
	TRACKING_NOTIFY_AND_PROVIDE_OPTOUT="2",
	CHAT_DO_NOT_NOTIFY="0",
	CHAT_NOTIFY="1",
    VISITOR_ACTION_GOT_IT="''Got it''",
    VISITOR_ACTION_DO_NOT_TRACK="'Do not track'",
    CHAT_GDPR_ACCEPT="I Accept",
    CHAT_GDPR_DECLINE="Decline"
    ;


    public static void toggleGDPR(WebDriver driver,ExtentTest etest,boolean isEnable) throws Exception
    {
		PortalInput portal_input=new PortalInput(PortalSetting.GDPR,isEnable);
		PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);
    }

    public static void enableGDPR(WebDriver driver,ExtentTest etest) throws Exception
    {
    	toggleGDPR(driver,etest,true);
    }

    public static void disableGDPR(WebDriver driver,ExtentTest etest) throws Exception
    {
    	toggleGDPR(driver,etest,false);
    }

    public static boolean setPasswordProtection(WebDriver driver,boolean isEnable)
    {
    	return selectGDPRCheckbox(driver,PASSWORD_PROTECTION_NAME,GDPR_CHECKBOX_ATTRIBUTE,""+isEnable);
    }

    public static boolean setTracking(WebDriver driver,String action)
    {
    	return selectGDPRCheckbox(driver,TRACKING_NAME,GDPR_CHECKBOX_ATTRIBUTE,action);
    }

    public static boolean setChatConsent(WebDriver driver,String action)
    {
    	return selectGDPRCheckbox(driver,CHAT_NAME,GDPR_CHECKBOX_ATTRIBUTE,action);
    }

    public static boolean setLearnMoreLink(WebDriver driver,ExtentTest etest,String link) throws Exception
    {
        try
        {
            WebElement input=CommonUtil.getElement(driver,LEARN_MORE_LINK_INPUT);

            if(input==null || CommonWait.isHidden(input))
            {
                etest.log(Status.INFO,"Learn more input was NOT found");
                return false;
            }

            input=CommonUtil.getElement(driver,LEARN_MORE_LINK_INPUT);//relocating element to avoid stale element
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+input.getLocation().y+"-400)");
            CommonUtil.inViewPort(input);
            CommonUtil.clickWebElement(driver,input);
            CommonUtil.sendKeysToWebElement(driver,input,link);
            Tab.clickPortalSettings(driver);
        }
        catch(Exception e)
        {
            etest.log(Status.WARNING,"Could not set tracking learn more link to "+link);
            TakeScreenshot.log(e,etest,Status.INFO);
            TakeScreenshot.infoScreenshot(driver,etest);
            return false;
        }

        return true;
    }

    public static boolean setChatConsentLearnMoreLink(WebDriver driver,ExtentTest etest,String link) throws Exception
    {
        try
        {
            WebElement input=CommonUtil.getElement(driver,CHAT_LEARN_MORE_INPUT);

            if(input==null || CommonWait.isHidden(input))
            {
                etest.log(Status.INFO,"Chat policy Learn more input was NOT found");
                return false;
            }

            input=CommonUtil.getElement(driver,CHAT_LEARN_MORE_INPUT);//relocating element to avoid stale element
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+input.getLocation().y+"-400)");
            CommonUtil.inViewPort(input);
            CommonUtil.clickWebElement(driver,input);
            CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,CHAT_LEARN_MORE_INPUT),link);
            Tab.clickPortalSettings(driver);
        }
        catch(Exception e)
        {
            etest.log(Status.WARNING,"Could not set chat GDPR learn more link to "+link);
            TakeScreenshot.log(e,etest,Status.INFO);
            TakeScreenshot.infoScreenshot(driver,etest);
            return false;
        }

        return true;
    }

    private static boolean selectGDPRCheckbox(final WebDriver driver,final String radio_name,final String checkbox_attribute,final String checkbox_attribute_value)
    {
        //variable radio_name is same as eid in this case
        final String eid=radio_name;

    	final By locator=By.cssSelector("[name='"+radio_name+"']["+checkbox_attribute+"='"+checkbox_attribute_value+"']");
    	WebElement checkbox=CommonUtil.getElement(driver,locator);
    	CommonUtil.inViewPortSafe(driver,checkbox);
    	CommonUtil.clickWebElement(driver,checkbox);

	    FluentWait wait=CommonUtil.waitreturner(driver,10,1000);

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                System.out.println("~~~PortalConfig.getAttributeOfSelectedCheckbox(driver,eid,checkbox_attribute)--->"+PortalConfig.getAttributeOfSelectedCheckbox(driver,eid,checkbox_attribute));

                if(PortalConfig.getAttributeOfSelectedCheckbox(driver,eid,checkbox_attribute).equals(checkbox_attribute_value))
                {
                    return true;
                }
                return false;
            }
        });

        return true;
    }

    // validate functions

    public static boolean isAllGDPROptionsFound(WebDriver driver,ExtentTest etest,boolean isGDPREnabled)
    {
        int not_found_count=0;

        PortalSetting[] gdpr_settings={PortalSetting.PASSWORD_PROTECTION,PortalSetting.COOKIE_POLICY_LINK,PortalSetting.CHAT_PRIVACY,PortalSetting.PRIVACY_POLICY_LINK};

        Status found_status=isGDPREnabled?Status.PASS:Status.FAIL;
        Status not_found_status=isGDPREnabled?Status.FAIL:Status.PASS;
        String gdpr_state=isGDPREnabled?"enabled":"disabled";

        for(PortalSetting gdpr_setting : gdpr_settings)
        {
            String eid=gdpr_setting.eid;

            if(CommonWait.isPresent(driver,By.cssSelector("[eid='"+eid+"']")))
            {
                CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.cssSelector("[eid='"+eid+"']")));
            }

            if(CommonWait.isDisplayed(driver,By.cssSelector("[eid='"+eid+"']")))
            {
                etest.log(found_status,"GDPR setting "+gdpr_setting+" was displayed after  GDPR toggle was "+gdpr_state);
            }
            else
            {
                etest.log(not_found_status,"GDPR setting "+gdpr_setting+" was NOT displayed after GDPR toggle was "+gdpr_state+", Expected eid : "+eid);
                not_found_count++;
            }
        }

        if(!isGDPREnabled)
        {
            return (not_found_count==0);
        }

        setPasswordProtection(driver,true);
        setTracking(driver,TRACKING_NOTIFY);
        setChatConsent(driver,CHAT_NOTIFY);

        String actual_text=CommonUtil.getElement(driver,GDPR_CONFIG_CONTAINER).getAttribute("innerText");

        for(int i=1;i<=12;i++)
        {
            String expected_text=ResourceManager.getRealValue("gdpr_config"+i);

            if(CommonUtil.checkStringContainsAndLog(expected_text,actual_text,"GDPR content",etest)==false)
            {
                not_found_count++;
            }
        }

        return (not_found_count==0);
    }

    public static boolean checkTrackingConsentBanner(WebDriver visitor_driver,ExtentTest etest,String tracking_action) throws Exception
    {
        boolean expected_is_banner_found=true;

        if(tracking_action.equals(TRACKING_DO_NOT_NOTIFY))
        {
            expected_is_banner_found=false;
        }

        return VisitorWindow.checkGDPRBannerDisplayed(visitor_driver,etest,expected_is_banner_found);
    }

    //log function
    public static String getTrackingSettingName(String setting_name)
    {
        if(setting_name.equals(GDPR.TRACKING_DO_NOT_NOTIFY))
        {
            return "'Do not notify'";
        }
        else if(setting_name.equals(GDPR.TRACKING_NOTIFY))
        {
            return "'Notify visitors'";
        }
        else if(setting_name.equals(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT))
        {
            return "'Notify and provide opt out'";
        }
        return null;
    }

    public static String getChatConsentSettingName(String setting_name)
    {
        if(setting_name.equals(GDPR.CHAT_DO_NOT_NOTIFY))
        {
            return "'Do not notify'";
        }
        else if(setting_name.equals(GDPR.CHAT_NOTIFY))
        {
            return "'Notify visitors'";
        }
        return null;
    }
}
