//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class DelugeScript
{
    public static final String
    BOT_SUCCESS_REGEX="Bot (created|updated) successfully",
    CHAT_PREVIEW_DATA_CLASS="close_preview",
    DELUGE_LHS_DATA_CLASS="close_menu",
    MESSAGE_HANDLER=ResourceManager.getRealValue("message_handler"),
    CONTEXT_HANDLER=ResourceManager.getRealValue("context_handler"),
    TRIGGER_HANDLER=ResourceManager.getRealValue("trigger_handler"),
    CODE_EMPTY_INNER_TEXT_VALUE="",
    CODE_INPUT_CONTAINER_ID="codemirror_div"
    ;

    public static final By
    MANAGE_CONNECTIONS=By.id("dreconnection"),
    CREATE_BOT=By.id("drecreate"),
    PUBLISH_BOT=By.id("drepublish"),
    BOT_PREVIEW_MESSAGE_INPUT=By.id("msgarea"),
    TOGGLE_MESSAGE_PREVIEW=By.cssSelector("[documentclick='handleEditorView'][data-class='close_preview']"),
    TOGGLE_DELUGE_BUTTONS=By.cssSelector("[documentclick='handleEditorView'][data-class='close_menu']"),
    TOGGLE_DIV=By.id("bottogglediv"),
    HANDLER_DROPDOWN_CONTAINER=By.id("handlerdropdown_div"),
    HANDLER_DROPDOWN=By.id("handlerdropdown_ddown"),
    RESET_CHAT_BUTTON=By.cssSelector("[documentclick='resetBotPreviewForm']"),
    VISITOR_MESSAGE=By.className("siq-visitor-message"),
    CODE_INPUT=By.cssSelector(".CodeMirror-lines[role='presentation']"),
    CODE_INPUT_INNER_DIV=By.className("CodeMirror-code"),
    CODE_LINE=By.className("CodeMirror-line"),
    CODE_INPUT_CONTAINER=By.id(CODE_INPUT_CONTAINER_ID),
    BOT_PREVIEW_WINDOW=By.id("botpreviewwindow"),
    MESSAGE_HANDLER_DROPDOWN_ELEMENT=By.cssSelector("li[val='message_handler']"),
    CONTEXT_HANDLER_DROPDOWN_ELEMENT=By.cssSelector("li[val='context_handler']"),
    TRIGGER_HANDLER_DROPDOWN_ELEMENT=By.cssSelector("li[val='trigger_handler']"),
    HANDLER_DROPDOWN_NOT_PUBLISHED_STAR=By.className("mL5")
    ;

    public static final String[]
    DELUGE_TASKS_BASIC={"set variable","add comment","info"},
    DELUGE_TASKS_CONDITION={"if","else if","else"},
    DELUGE_TASKS_NOTIFICATION={"send mail","post to chat"},
    DELUGE_TASKS_INTEGRATION={"webhook","zoho integration"},
    DELUGE_TASKS_SALESIQ_WIDGETS={"Calendar","Range Calendar","Slider","Range Slider","Happiness Rating","Star Rating","Likes","Single select","Multiple select","TimeSlots","Date TimeSlots"},
    DELUGE_TASKS_COLLECTION={"create collection","insert","get","update","delete","for each element"},

    DELUGE_TASKS_WIDGET_IDS={"calendar","rangecalendar","slider","rangeslider","happinessrating","starrating","like","singleselect","multipleselect","timeslots","datetimeslots"}
    // DELUGE_TASKS_WIDGET_IDS={"calendar","rangecalendar","slider"}
    ;

    public static final String
    BASIC_GROUP="Basic",
    CONDITION_GROUP="Condition",
    NOTIFICATION_GROUP="Notifications",
    INTEGRATION_GROUP="Integrations",
    WIDGETS_GROUP="SalesIQ_Widgets",
    COLLECTION_GROUP="Collection",
    DISCARD="Discard"
    ;


    public static boolean isManageConnectionsButtonDisplayed(WebDriver driver,boolean isWait)
    {
        if(isWait)
        {
            return CommonWait.waitTillDisplayed(driver,DelugeScript.MANAGE_CONNECTIONS);
        }
        else
        {
            return CommonWait.isDisplayed(driver,DelugeScript.MANAGE_CONNECTIONS);
        }
    }

    public static void sendMessage(WebDriver driver,String message)
    {
        WebElement input=CommonUtil.getElement(driver,BOT_PREVIEW_MESSAGE_INPUT);
        CommonUtil.sendKeysToWebElement(driver,input,message);
        CommonUtil.sendEnterKey(driver,input);
    }

    public static boolean isBotPreviewChatInputDisplayed(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,BOT_PREVIEW_MESSAGE_INPUT);
    }

    public static void clickCreateBot(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,CREATE_BOT);
        CommonUtil.getElement(driver,CREATE_BOT).click();
        waitTillBotUpdated(driver);
    }

    public  static void clickSave(WebDriver driver)
    {
        //same button only
        clickCreateBot(driver);
    }

    public  static void clickPublish(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,PUBLISH_BOT);
        CommonUtil.getElement(driver,PUBLISH_BOT).click();
        waitTillBotUpdated(driver);
    }
    
    public static boolean waitTillBotUpdated(WebDriver driver)
    {
        return Tab.waitTillBanner(driver,BOT_SUCCESS_REGEX,Tab.INFO_BANNER);
    }

    public static boolean close(WebDriver driver)
    {
        if(CommonWait.isDisplayed(driver,BotConfiguration.CLOSE))
        {
            return closeDelugeScriptPage(driver);
        }

        return true;//already closed
    }

    public static boolean closeDelugeScriptPage(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,BotConfiguration.CLOSE);
        CommonUtil.getElement(driver,BotConfiguration.CLOSE).click();

        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,DISCARD);

        if(popup!=null)
        {
            HandleCommonUI.clickNegativePopupButton(popup);
        }        

        return CommonWait.waitTillHidden(driver,BotConfiguration.CLOSE);
    }

    public static boolean verifyDelugeTasksByCategory(WebDriver driver,ExtentTest etest,String group_name,String[] expected_values)
    {
        etest.log(Status.INFO,"Checking if expected values are found for group '"+group_name+"' ");

        int failcount=0;

        List<WebElement> values=CommonUtil.getElements(driver,By.cssSelector("[group-name='"+group_name+"']"));

        for(WebElement value : values)
        {
            String content=value.getAttribute("innerText").trim();

            CommonUtil.inViewPort(value);

            if(CommonWait.isDisplayed(value))
            {

                if(Arrays.asList(expected_values).contains(content))
                {
                    etest.log(Status.PASS,"Expected value '"+content+"' was found under expected group '"+group_name+"'. (group values-->"+Arrays.asList(expected_values).toString()+")");
                }
                else
                {
                    failcount++;
                    etest.log(Status.FAIL,"Expected value '"+content+"' was NOT found under expected group '"+group_name+"'. (group values-->"+Arrays.asList(expected_values).toString()+")");
                }
            }
            else
            {
                etest.log(Status.WARNING,"Value '"+content+"' is hidden from UI");
            }          
        }

        if(failcount>0)
        {
            TakeScreenshot.screenshot(driver,etest);
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean toggleChatPreview(WebDriver driver,boolean isShow)
    {
        return toggleCommon(driver,TOGGLE_MESSAGE_PREVIEW,CHAT_PREVIEW_DATA_CLASS,isShow);
    }

    public static boolean toggleDelugeLHS(WebDriver driver,boolean isShow)
    {
        return toggleCommon(driver,TOGGLE_DELUGE_BUTTONS,DELUGE_LHS_DATA_CLASS,isShow);
    }
    

    private static boolean toggleCommon(WebDriver driver,By toggle_button,String expected_classname,boolean isEnable)
    {
        //logic--> if toggle_div has expected_classname it implies the UI is hidden

        WebElement toggle_div=CommonUtil.getElement(driver,TOGGLE_DIV);
        boolean currentIsEnable=(CommonUtil.hasClass(toggle_div,expected_classname)==false);

        if(currentIsEnable==isEnable)
        {
            return true;
        }

        WebElement button=CommonUtil.getElement(driver,toggle_button);
        CommonUtil.inViewPort(button);
        CommonUtil.mouseHoverAndClick(driver,button);

        if(isEnable)
        {
            return CommonUtil.waitTillWebElementDoesNotContainAttributeValue(toggle_div,"class",expected_classname);
        }
        else
        {
            return CommonUtil.waitTillWebElementContainsAttributeValue(toggle_div,"class",expected_classname);
        }
    }

    public static boolean toggleHandlerDropdown(WebDriver driver,boolean isOpen)
    {
        if(CommonWait.isDisplayed(driver,HANDLER_DROPDOWN)==isOpen)
        {
            return true;
        }

        CommonUtil.getElement(driver,HANDLER_DROPDOWN_CONTAINER).click();

        if(isOpen)
        {
            return CommonWait.waitTillDisplayed(driver,HANDLER_DROPDOWN);
        }
        else
        {
            return CommonWait.waitTillHidden(driver,HANDLER_DROPDOWN);
        }
    }

    public static boolean changeHandlerView(WebDriver driver,String handler)
    {
        if(CommonUtil.getElement(driver,HANDLER_DROPDOWN_CONTAINER).getAttribute("innerText").contains(handler))
        {
            return true;
        }

        toggleHandlerDropdown(driver,true);
        WebElement dropdown=CommonUtil.getElement(driver,HANDLER_DROPDOWN);
        HandleCommonUI.chooseFromDropdown(dropdown,handler);
        return CommonUtil.waitTillWebElementContainsAttributeValue( CommonUtil.getElement(driver,HANDLER_DROPDOWN_CONTAINER) , "innerText" ,handler );
    }

    public static void checkHandlerDropdown(WebDriver driver,ExtentTest etest)
    {  
        toggleHandlerDropdown(driver,true);

        WebElement dropdown=CommonUtil.getElement(driver,HANDLER_DROPDOWN);

        if(CommonWait.isPresent(dropdown,By.cssSelector("li[title='"+MESSAGE_HANDLER+"']")))
        {
            DelugeBasic.result.put("BOTS53",true);
            etest.log(Status.PASS,MESSAGE_HANDLER+" was found in handler dropdown");
        }
        else
        {
            DelugeBasic.result.put("BOTS53",false);
            etest.log(Status.FAIL,MESSAGE_HANDLER+" was NOT found in handler dropdown");
        }

        if(CommonWait.isPresent(dropdown,By.cssSelector("li[title='"+CONTEXT_HANDLER+"']")))
        {
            DelugeBasic.result.put("BOTS54",true);
            etest.log(Status.PASS,CONTEXT_HANDLER+" was found in handler dropdown");
        }
        else
        {
            DelugeBasic.result.put("BOTS54",false);
            etest.log(Status.FAIL,CONTEXT_HANDLER+" was NOT found in handler dropdown");
        }

        if(CommonWait.isPresent(dropdown,By.cssSelector("li[title='"+TRIGGER_HANDLER+"']")))
        {
            DelugeBasic.result.put("BOTS55",true);
            etest.log(Status.PASS,TRIGGER_HANDLER+" was found in handler dropdown");
        }
        else
        {
            DelugeBasic.result.put("BOTS55",false);
            etest.log(Status.FAIL,TRIGGER_HANDLER+" was NOT found in handler dropdown");
        }
    }

    public static boolean resetPreviewChat(WebDriver driver)
    {
        WebElement bot_message=CommonUtil.getElement(driver,BotsVisitorSide.BOT_FIRST_MESSAGE);
        CommonUtil.jsClick(driver,RESET_CHAT_BUTTON);
        return CommonWait.waitTillHidden(bot_message);
    }

    public static String getCurrentCode(WebDriver driver)
    {
        // String text=CommonUtil.getElement(driver,CODE_INPUT_CONTAINER).getAttribute("innerText").trim();

        String js="document.getElementById('"+CODE_INPUT_CONTAINER_ID+"').innerText.trim()";
        String text=ExecuteStatements.get(driver,js);
        text=text.replaceAll("\\d\\n","").trim();

        if(text.equals("1"))
        {
            text="";//1 is just the line number
        }

        return text;
    }

    // public static boolean clearScript(WebDriver driver)
    // {
    //     //click last line
    //     List<WebElement> lines=CommonUtil.getElements(driver,CODE_LINE);
    //     WebElement last_line=lines.get(lines.size()-1);

    //     Actions actions=null;      

    //     CommonUtil.scrollIntoView(driver,last_line);

    //     last_line.click();

    //     for (int i = 0; i < lines.size()+500; i++) 
    //     {
    //         actions= new Actions(driver);
    //         //pressing down key just as a precaution
    //         actions.sendKeys(Keys.ARROW_DOWN).perform();
    //     }

    //     //go to end of line
    //     for(int i=0;i<100;i++)
    //     {
    //         actions= new Actions(driver);
    //         actions.moveToElement(last_line);
    //         actions.sendKeys(Keys.ARROW_RIGHT);
    //         actions.build().perform();
    //     }

    //     actions = new Actions(driver);

    //     actions.moveToElement(last_line); 
    //     actions.click();       
    //     actions.keyDown(Keys.SHIFT).perform();

    //     for (int i = 0; i < lines.size()+500; i++) 
    //     {
    //         actions.sendKeys(Keys.ARROW_UP).perform();
    //     }

    //     actions.keyUp(Keys.SHIFT).perform();

    //     actions.sendKeys(Keys.DELETE).perform();

    //     if(waitTillCurrentCodeEmpty(driver)==false)
    //     {
    //         throw new ZohoSalesIQRuntimeException("Existing script code could not be cleared.");
    //     }

    //     return true;
    // }

    public static boolean clearScript(WebDriver driver)
    {
        int j=-1;

        for(j=0;j<10;j++)
        {

            try
            {
                removeAllCode(driver);
            }
            catch(Exception e)
            {
                e.printStackTrace();  
            }

            if(isCodeEmpty(driver))
            {
                break;
            }
        }

        if(waitTillCurrentCodeEmpty(driver)==false)
        {
            throw new ZohoSalesIQRuntimeException("Existing script code could not be cleared. Tried for "+j+" times");
        }

        return true;
    }

    public static void removeAllCode(WebDriver driver)
    {
        //click last line
        List<WebElement> lines=CommonUtil.getElements(driver,CODE_LINE);
        WebElement last_line=lines.get(lines.size()-1);

        Actions actions=null;      

        CommonUtil.scrollIntoView(driver,last_line);

        last_line.click();

        // last_line.sendKeys(Keys.ENTER);

        //go to end of line
        for(int i=0;i<100;i++)
        {
            actions= new Actions(driver);
            actions.moveToElement(last_line);
            actions.sendKeys(Keys.ARROW_RIGHT);
            actions.build().perform();
        }

        actions = new Actions(driver);

        actions.moveToElement(last_line); 
        actions.click();       
        actions.keyDown(Keys.SHIFT).perform();

        for (int i = 0; i < lines.size()+10; i++) 
        {
            actions.sendKeys(Keys.ARROW_UP).perform();
        }

        actions.keyUp(Keys.SHIFT).perform();

        actions.sendKeys(Keys.DELETE).perform();
    }

    public static boolean isCodeEmpty(final WebDriver driver)
    {
        final String code=getCurrentCode(driver).replaceAll("[^A-Za-z0-9]+","").trim();

        if(code.equals(CODE_EMPTY_INNER_TEXT_VALUE))
        {
            return true;
        }

        return false;
    }


    public static boolean waitTillCurrentCodeEmpty(final WebDriver driver)
    {
        return waitTillCurrentCodeEmpty(driver,true);
    }

    public static boolean waitTillCurrentCodeNotEmpty(final WebDriver driver)
    {
        return waitTillCurrentCodeEmpty(driver,false);
    }

    public static boolean waitTillCurrentCodeEmpty(final WebDriver driver,final boolean expected_is_empty)
    {
        boolean isEmpty=false;

        try
        {
            FluentWait wait=CommonUtil.waitreturner(driver,10,250);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    String code=getCurrentCode(driver).replaceAll("[^A-Za-z0-9]+","").trim();


                    if(isCodeEmpty(driver)==expected_is_empty)
                    {
                        return true;
                    }
                    return false;
                }
            });

            isEmpty=true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return isEmpty;
    }

    // public static boolean waitTillCurrentCodeEmpty(final WebDriver driver,final boolean expected_is_empty)
    // {
    //     boolean isEmpty=false;

    //     try
    //     {
    //         FluentWait wait=CommonUtil.waitreturner(driver,10,250);

    //         wait.until(new Function<WebDriver,Boolean>()
    //         {
    //             public Boolean apply(WebDriver driver)
    //             {
    //                 String code=getCurrentCode(driver).replaceAll("[^A-Za-z0-9]+","").trim();


    //                 if(code.equals(CODE_EMPTY_INNER_TEXT_VALUE)==expected_is_empty)
    //                 {
    //                     return true;
    //                 }
    //                 return false;
    //             }
    //         });

    //         isEmpty=true;
    //     }
    //     catch(Exception e)
    //     {
    //         e.printStackTrace();
    //     }

    //     return isEmpty;
    // }

    public static void sendKeysToScript(WebDriver driver,String code)
    {
        Actions actions= new Actions(driver);

        clearScript(driver);

        WebElement input=CommonUtil.getElement(driver,CODE_INPUT);
        
        // actions.moveToElement(input);
        // actions.click();
        // actions.sendKeys(code);
        // actions.build().perform();

        CommonUtil.sendKeysByChar(driver,input,code);
    }


    public static void pasteCodeInScript(WebDriver driver,ExtentTest etest)
    {
        Actions actions= new Actions(driver);

        clearScript(driver);

        WebElement input=CommonUtil.getElement(driver,CODE_INPUT);
        
        actions.moveToElement(input);
        actions.click();
        actions.build().perform();

        CommonUtil.pasteFromClipboard(driver,etest,input);
    }

    public static boolean checkLHSWidgetTemplate(WebDriver driver,ExtentTest etest,String template_id) throws IOException
    {
        clearScript(driver);
        
        WebElement widget=CommonUtil.getElement(driver,By.id(template_id));
        WebElement input=CommonUtil.getElement(driver,CODE_INPUT,CODE_INPUT_INNER_DIV);

        CommonUtil.doubleClick(driver,widget);

        etest.log(Status.INFO,template_id+" widget was selected.");

        waitTillCurrentCodeNotEmpty(driver);

        String actual_code=DelugeScript.getCurrentCode(driver);
        String expected_code=BotScripts.getBotCode(template_id,BotScripts.TEMPLATE);

        boolean isPass=CommonUtil.checkStringEqualsAndLog(expected_code,actual_code,"default code for "+template_id,etest);

        if(!isPass)
        {
            TakeScreenshot.screenshot(driver,etest);            
        }

        return isPass;
    }

    public static void updateChanges(WebDriver driver,boolean isPublish)
    {
        if(isPublish)
        {
            clickPublish(driver);
        }
        else
        {
            clickSave(driver);
        }
    }

    public static void publishHandler(WebDriver driver,String publish_type)
    {
        updateHandler(driver,publish_type,true);
    }

    public static void saveHandler(WebDriver driver,String publish_type)
    {
        updateHandler(driver,publish_type,false);
    }

    public static void updateHandler(WebDriver driver,String publish_type,boolean isPublish)
    {
        if(publish_type.equals(BotInfo.PUBLISH_ALL_HANDLERS) || publish_type.equals(BotInfo.PUBLISH_MESSAGE_HANDLER))
        {
            changeHandlerView(driver,MESSAGE_HANDLER);
            updateChanges(driver,isPublish);
        }
        if(publish_type.equals(BotInfo.PUBLISH_ALL_HANDLERS) || publish_type.equals(BotInfo.PUBLISH_TRIGGER_HANDLER))
        {
            changeHandlerView(driver,TRIGGER_HANDLER);
            updateChanges(driver,isPublish);
        }
        if(publish_type.equals(BotInfo.PUBLISH_ALL_HANDLERS) || publish_type.equals(BotInfo.PUBLISH_CONTEXT_HANDLER))
        {
            changeHandlerView(driver,CONTEXT_HANDLER);
            updateChanges(driver,isPublish);
        }
    }

    public static boolean clickManageConnections(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,MANAGE_CONNECTIONS);
        WebElement button=CommonUtil.getElement(driver,MANAGE_CONNECTIONS);
        CommonUtil.mouseHoverAndClick(driver,button);
        CommonUtil.waitTillNewTabOpens(driver,1);
        return true;//if function fails exception will be thrown
    }

    public static boolean isHandlerPublished(WebDriver driver,By handler_locator)
    {
        return CommonWait.isPresent(driver,handler_locator,HANDLER_DROPDOWN_NOT_PUBLISHED_STAR)==false;
    }
}
