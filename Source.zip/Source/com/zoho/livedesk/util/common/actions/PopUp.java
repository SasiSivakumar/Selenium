//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class PopUp
{
	public static WebElement getHeader(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("lvd_popuptitle"))
                {
                    return true;
                }
                return false;
            }
        });

        WebElement content = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"classname","lvd_popuptitle");
        
        return content;
    }

    public static WebElement getDesc(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("popupdesc"))
                {
                    return true;
                }
                return false;
            }
        });

        WebElement content = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","popupdesc");
        
        return content;
    }

    public static WebElement getOkBtn(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("okbtn"))
                {
                    return true;
                }
                return false;
            }
        });

        WebElement content = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","okbtn");
        
        return content;
    }

    public static void clickClose(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("dlgclose"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","dlgclose").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("dlgclose"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickOkBtn(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("okbtn"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","okbtn").click();
    }

    public static void clickCancelBtn(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("cancelbtn"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","cancelbtn").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("cancelbtn"))
                {
                    return true;
                }
                return false;
            }
        });

    }
}
