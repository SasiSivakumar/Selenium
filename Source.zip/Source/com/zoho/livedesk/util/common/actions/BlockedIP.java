//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.client.SalesIQRestAPI.Constants;

public class BlockedIP
{
    public static final By
    BLOCKEDIP_CONTAINER=By.className("list-row"),
    REJECT=By.cssSelector("em[onclick*='BlockedIPUI.remove(']"),
    ROW=By.className("list_cell"),
    BLOCKED_BY_ELE=By.cssSelector("a[href*='#setting/user']"),
    COMMENT=By.className("comment"),
    BLOCKED_IP_INFO_CONTAINER=By.id("configview"),
    COMMENTS_CONTAINER=By.id("commentlistcontainer")
    ;

    public static final int
    IP_INDEX=0,
    WEBSITE_INDEX=1,
    BLOCKED_BY_INDEX=2,
    ACTION_INDEX=3
    ;

    public static final String
    REJECT_CONTENT="Reject"
    ;

    public static final String
    IP="IP",
    STATUS="STATUS",
    BLOCKED_BY_OPERATOR_ID="BLOCKED_BY_OPERATOR_ID",
    APP_NAME="APP_NAME",
    APP_ID="APP_ID",
    NO_OF_COMMENTS="NO_OF_COMMENTS",
    COMMENTS="COMMENTS"
    ;

    public static void blockIP(WebDriver driver,ExtentTest etest,String ip,String comment,String embed)
    {
        try
        {
            Tab.navToBlockedIPTab(driver);
        }
        catch(Exception e)
        {

        }
        com.zoho.livedesk.client.BlockedIP.addIP(driver,ip,comment,embed);
        etest.log(Status.INFO,ip+" was blocked.");
    }
    public static void blockIP(WebDriver driver,ExtentTest etest,String ip)
    {
        blockIP(driver,etest,ip,null,null);
    }

    public static int getBlockedIPCount(WebDriver driver) throws Exception
    {
        Tab.navToBlockedIPTab(driver);
        return CommonUtil.getElements(driver,BLOCKEDIP_CONTAINER).size();
    }

    public static WebElement getBlockedIPContainer(WebDriver driver,String ip)
    {
        List<WebElement> ips=CommonUtil.getElements(driver,BLOCKEDIP_CONTAINER);
        return CommonUtil.getElementByAttributeValue(ips,"innerText",ip);
    }

    public static boolean isIPBlocked(WebDriver driver,String ip)
    {
        return getBlockedIPContainer(driver,ip)!=null;
    }

    public static void rejectAllIPs(WebDriver driver)
    {
        int MAX_ATTEMPTS=25;

        int no_of_attempts=0;

        while( CommonWait.isCssSelectorPresent(driver,REJECT) && no_of_attempts<MAX_ATTEMPTS )
        {
            try
            {
                WebElement reject=CommonUtil.getElement(driver,REJECT);

                CommonUtil.mouseHover(driver,reject);

                try
                {
                   CommonWait.waitTillDisplayed(reject);
                }
                catch(Exception exp)
                {
                   exp.printStackTrace(); 
                   break; 
                }

                reject.click();
                CommonUtil.sleep(250);
                WebElement popup=HandleCommonUI.getPopupByInnerText(driver,REJECT_CONTENT);
                HandleCommonUI.clickPositivePopupButton(popup);
                CommonUtil.sleep(1000);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            no_of_attempts++;
        }
    }

    public static Hashtable<String,String> getInfo(WebDriver driver,String rule_id) throws Exception
    {
        Tab.navToBlockedIPTab(driver);

        Hashtable<String,String> rule_info=new Hashtable<String,String>();

        WebElement blockedip_container=CommonUtil.getElement(driver,By.id(rule_id));

        if(blockedip_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Blocked IP with id "+rule_id+" was not found");
        }

        CommonUtil.scrollIntoView(driver,blockedip_container);

        List<WebElement> blockedip_rows=blockedip_container.findElements(ROW);

        rule_info.put(IP,blockedip_rows.get(IP_INDEX).getAttribute("innerText").trim());

        String status=blockedip_rows.get(ACTION_INDEX).getAttribute("innerText").trim();

        if(status.contains(ResourceManager.getRealValue("settings_unblock")))
        {
            status=Constants.BLOCKED;
        }
        else if(status.contains(ResourceManager.getRealValue("settings_block")))
        {
            status=Constants.UNBLOCKED;
        }
        else if(status.contains(ResourceManager.getRealValue("settings_approve")))
        {
            status=Constants.APPROVAL_REQUIRED;
        }

        rule_info.put(STATUS,status);

        String blocked_by_operator_id=CommonUtil.getElement(blockedip_rows.get(BLOCKED_BY_INDEX),BLOCKED_BY_ELE).getAttribute("href");
        blocked_by_operator_id=blocked_by_operator_id.split("/")[blocked_by_operator_id.split("/").length-1];

        rule_info.put(BLOCKED_BY_OPERATOR_ID,blocked_by_operator_id);

        String app_name=blockedip_rows.get(WEBSITE_INDEX).getAttribute("innerText").toLowerCase();
        rule_info.put(APP_NAME,app_name);

        rule_info.put(APP_ID, ExecuteStatements.getWebsiteIDFromEmbedName(driver,app_name) );    

        blockedip_rows.get(IP_INDEX).click();
        CommonWait.waitTillDisplayed(driver,BLOCKED_IP_INFO_CONTAINER);

        rule_info.put(NO_OF_COMMENTS, ""+CommonUtil.getElements(driver,COMMENT).size());

        rule_info.put(COMMENTS, CommonUtil.getElement(driver,COMMENTS_CONTAINER).getText());

        return rule_info;
    }

    public static boolean isBlockedIPFound(WebDriver driver,String id) throws Exception
    {
        Tab.navToBlockedIPTab(driver);
        return CommonWait.isPresent(driver,By.id(id));
    }

    public static String getRuleIDOfFirstBlockedIP(WebDriver driver) throws Exception
    {
        Tab.navToBlockedIPTab(driver);
        return CommonUtil.getElement(driver,BLOCKEDIP_CONTAINER).getAttribute("id");
    }
}
