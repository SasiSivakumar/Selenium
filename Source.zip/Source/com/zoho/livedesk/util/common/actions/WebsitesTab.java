//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.CommonSikuli;


import com.google.common.base.Function;

public class WebsitesTab
{
	public static void clickVisitorTracking(WebDriver driver,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@boxname='visitortracking']//em[contains(@class,'emhico')]")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@boxname='visitortracking']//em[contains(@class,'emhico')]")));

		CommonSikuli.findInWholePage(driver,"Visitortracking.png","UI1",etest);
		CommonUtil.elfinder(driver,"xpath","//div[@boxname='visitortracking']//em[contains(@class,'emhico')]").click();

		final WebElement page = CommonUtil.elfinder(driver,"tagname","body");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(page.getAttribute("innerHTML").contains("emconfigmain"))
                {
                    return true;
                }
                return false;
            }
        });

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emconfigmain")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emconfigmain")));

		etest.log(Status.INFO,"Visitor tracking is clicked");
	}

	public static void clickLiveChat(WebDriver driver,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@boxname='livechat']//em[contains(@class,'emhico')]")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@boxname='livechat']//em[contains(@class,'emhico')]")));

		CommonSikuli.findInWholePage(driver,"Livechat.png","UI2",etest);

		CommonUtil.elfinder(driver,"xpath","//div[@boxname='livechat']//em[contains(@class,'emhico')]").click();

		final WebElement page = CommonUtil.elfinder(driver,"tagname","body");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(page.getAttribute("innerHTML").contains("emconfigmain"))
                {
                    return true;
                }
                return false;
            }
        });

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emconfigmain")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emconfigmain")));

		etest.log(Status.INFO,"Live chat config is clicked");
	}

	public static void clickLiveChatMobile(WebDriver driver,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@boxname='livechatmobile']//em[contains(@class,'emhico')]")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@boxname='livechatmobile']//em[contains(@class,'emhico')]")));

		CommonSikuli.findInWholePage(driver,"Mobilechat.png","UI3",etest);		
		CommonUtil.elfinder(driver,"xpath","//div[@boxname='livechatmobile']//em[contains(@class,'emhico')]").click();

		final WebElement page = CommonUtil.elfinder(driver,"tagname","body");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(page.getAttribute("innerHTML").contains("sdk_topdiv"))
                {
                    return true;
                }
                return false;
            }
        });

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sdk_topdiv")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sdk_topdiv")));

		etest.log(Status.INFO,"Live chat mobile config is clicked");
	}

	public static void clickLiveChatEmail(WebDriver driver,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@boxname='livechatemail']//em[contains(@class,'emhico')]")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@boxname='livechatemail']//em[contains(@class,'emhico')]")));

		CommonWait.waitTillDisplayed(driver,By.className("addembx"));
		CommonSikuli.findInWholePage(driver,"Emailchat.png","UI4",etest);
		CommonUtil.elfinder(driver,"xpath","//div[@boxname='livechatemail']//em[contains(@class,'emhico')]").click();

		final WebElement page = CommonUtil.elfinder(driver,"tagname","body");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(page.getAttribute("innerHTML").contains("emconfigmain"))
                {
                    return true;
                }
                return false;
            }
        });

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emconfigmain")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emconfigmain")));

		etest.log(Status.INFO,"Live chat email config is clicked");
	}

	public static void clickInstallationInTracking(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@tabname='installation']//em")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@tabname='installation']//em")));

		CommonUtil.elfinder(driver,"xpath","//div[@tabname='installation']//em").click();

		waitTillLoaded(driver,"installationt");

		etest.log(Status.INFO,"Installation is clicked");
	}

	public static void clickInstallationInLiveChat(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@tabname='installation']//em")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@tabname='installation']//em")));

		CommonSikuli.findInWholePage(driver,"Installation.png","UI5",etest);

		CommonUtil.elfinder(driver,"xpath","//div[@tabname='installation']//em").click();

		waitTillLoaded(driver,"installationlc");
		
		etest.log(Status.INFO,"Installation is clicked");
	}

	public static void clickChatWindow(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@tabname='chatwindow']//em")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@tabname='chatwindow']//em")));

		CommonSikuli.findInWholePage(driver,"Chatwindow.png","UI7",etest);

		CommonUtil.elfinder(driver,"xpath","//div[@tabname='chatwindow']//em").click();

		waitTillLoaded(driver,"chatwindow");
		
		etest.log(Status.INFO,"Chat Window is clicked");
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("previewframe")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("previewframe")));
        
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        final WebElement body = CommonUtil.elfinder(driver,"tagname","body");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(body.getAttribute("innerHTML").contains("question"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement ques = Websites.getInputArea(driver,"question");
        
        wait.until(ExpectedConditions.visibilityOf(ques));
        
        driver.switchTo().defaultContent();
    }
	
	public static void clickWidget(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@tabname='widget']//em")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@tabname='widget']//em")));

		CommonSikuli.findInWholePage(driver,"Widget.png","UI6",etest);

		CommonUtil.elfinder(driver,"xpath","//div[@tabname='widget']//em").click();

		waitTillLoaded(driver,"widget","emrightnav");
		
		String current_widget="unknown";

		try
		{
			WebElement current_widget_element=CommonUtil.getElement(driver,By.cssSelector("span.sel.wdprv_main"));
			System.out.println(current_widget_element.getAttribute("innerHTML"));
			current_widget=current_widget_element.getAttribute("widget");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		etest.log(Status.INFO,"Widget is clicked. Currently selected widget type is "+current_widget);
	}

	public static void clickApperanceInWidget(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='apperance']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='apperance']")));

		CommonUtil.elfinder(driver,"xpath","//span[@subtab='apperance']").click();

		waitTillLoaded(driver,"apperance");
		
		etest.log(Status.INFO,"Apperance is clicked");
	}

	public static void clickContentFloat(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='content']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='content']")));

		CommonUtil.elfinder(driver,"xpath","//span[@subtab='content']").click();

		waitTillLoaded(driver,"float_content");
		
		etest.log(Status.INFO,"Content is clicked");
	}
    
    public static void clickContentButton(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='content']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='content']")));
        
        CommonUtil.elfinder(driver,"xpath","//span[@subtab='content']").click();
        
        waitTillLoaded(driver,"button_content");
        
        etest.log(Status.INFO,"Content is clicked");
    }
    
    public static void clickContentPersonalized(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='content']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='content']")));
        
        CommonUtil.elfinder(driver,"xpath","//span[@subtab='content']").click();
        
        waitTillLoaded(driver,"personalized_content");
        
        etest.log(Status.INFO,"Content is clicked");
    }

	public static void clickApperanceInChatWindow(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@documentclick='cwApperance']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@documentclick='cwApperance']")));

		CommonUtil.elfinder(driver,"xpath","//span[@documentclick='cwApperance']").click();

		waitTillLoaded(driver,"apperancecm");
		
		etest.log(Status.INFO,"Apperance is clicked");
	}

	public static void clickConfigurations(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='behaviourpreference']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='behaviourpreference']")));

		CommonUtil.elfinder(driver,"xpath","//span[@subtab='behaviourpreference']").click();

		waitTillLoaded(driver,"behaviourpreference");
		
		etest.log(Status.INFO,"Configurations is clicked");
	}

	public static void clickFields(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='forms']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='forms']")));

		CommonUtil.elfinder(driver,"xpath","//span[@subtab='forms']").click();

		waitTillLoaded(driver,"forms");
		
		etest.log(Status.INFO,"Fields is clicked");
	}

	public static void clickResponsemessage(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@subtab='message']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@subtab='message']")));

		CommonUtil.elfinder(driver,"xpath","//span[@subtab='message']").click();

		waitTillLoaded(driver,"message");
		
		etest.log(Status.INFO,"Response message is clicked");
	}

	public static void clickFloatWidget(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@widget='float']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@widget='float']")));

		CommonUtil.elfinder(driver,"xpath","//span[@widget='float']").click();

        waitTillLoaded(driver,"apperance");
        
        etest.log(Status.INFO,"Float widget is clicked");
        
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        final WebElement body = CommonUtil.elfinder(driver,"tagname","body");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(body.getAttribute("innerHTML").contains("zsiq_float"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));
        
        driver.switchTo().defaultContent();
        
        Websites.clickSave(driver,etest,false);
    }
    
    public static void clickButtonWidget(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@widget='button']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@widget='button']")));
        
        CommonUtil.elfinder(driver,"xpath","//span[@widget='button']").click();
        
        waitTillLoaded(driver,"button_apperance");
        
        etest.log(Status.INFO,"Button widget is clicked");
        
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        final WebElement body = CommonUtil.elfinder(driver,"tagname","body");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(body.getAttribute("innerHTML").contains("zsiqbtn"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiqbtn")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiqbtn")));
        
        driver.switchTo().defaultContent();
        
        Websites.clickSave(driver,etest,false);
    }
    
    public static void clickPersonalizedWidget(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@widget='personalized']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@widget='personalized']")));
        
        CommonUtil.elfinder(driver,"xpath","//span[@widget='personalized']").click();
        
        waitTillLoaded(driver,"personalized_apperance");
        
        etest.log(Status.INFO,"Personalized widget is clicked");
        
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        final WebElement body = CommonUtil.elfinder(driver,"tagname","body");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(body.getAttribute("innerHTML").contains("zsiqpersonalize"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiqpersonalize")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiqpersonalize")));
        
        driver.switchTo().defaultContent();
        
        Websites.clickSave(driver,etest,false);
    }

	public static WebElement getLeftNav(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emleftnav")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emleftnav")));

		return CommonUtil.elfinder(driver,"id","emleftnav");
	}

	public static WebElement getMiddleNav(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emmiddlenav")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emmiddlenav")));

		return CommonUtil.elfinder(driver,"id","emmiddlenav");
	}

	public static WebElement getRightNav(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emrightnav")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emrightnav")));

		return CommonUtil.elfinder(driver,"id","emrightnav");
	}

	public static void closeEmbedConfig(WebDriver driver,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emconfigmain")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emconfigmain")));

		CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","emconfigmain"),"classname","sqico-close").click();

		final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

		final WebElement page = CommonUtil.elfinder(driver,"tagname","body");

		for(int i = 1; i<=20;i++)
		{
			if(!popup.getAttribute("innerHTML").equals(""))
			{
				TakeScreenshot.screenshot(driver,etest,"Websites","CloseConfiguration","Error");
				PopUp.clickOkBtn(driver);

				wait = CommonUtil.waitreturner(driver,5,250);

				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(popup.getAttribute("innerHTML").equals(""))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });
			}
			if(!page.getAttribute("innerHTML").contains("emconfigmain"))
            {
                break;
            }
			
			Thread.sleep(500);
		}

		wait = CommonUtil.waitreturner(driver,2,250);

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!page.getAttribute("innerHTML").contains("emconfigmain"))
                {
                    return true;
                }
                return false;
            }
        });

        etest.log(Status.INFO,"Embed config - close is clicked");
	}

	public static void waitTillLoaded(WebDriver driver, String tab) throws Exception
    {
    	waitTillLoaded(driver,tab,"emmiddlenav");
    }
    
    public static void waitTillLoaded(WebDriver driver, String tab, String divId) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,4,250);

    	Long t1 = new Long(System.currentTimeMillis());

		String content = ResourceManager.getRealValue("embed_"+tab+"_header");

		String classname = null;

		Boolean presence = false;
        
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        
        int count = 0;
        
        for(;;)
		{
            Long time1 = new Long(System.currentTimeMillis());
            
            count++;
            
            try
			{
				WebElement div = CommonUtil.elfinder(driver,"id",divId);

				String s = div.getAttribute("innerHTML");
                
                if(s.contains("big-hdrtxt"))
				{
					classname = "big-hdrtxt";
				}
				else if(s.contains("hdrtxt"))
				{
					classname = "hdrtxt";
				}
				else
				{
					Long t2 = new Long(System.currentTimeMillis());

					if(t2 - t1 >= 20000)
					{
                        System.out.println("<>WebsitesTab<>waittillloaded<>1<>"+count+"<>");
						break;
					}
					
					continue;
				}
				
				String header = div.findElement(By.className(classname)).getText();

                if(header.contains(content))
	            {
                    presence = true;
	                break;
	            }
            }
			catch(Exception e)
			{
                classname = null;
            }
            
            Long t2 = new Long(System.currentTimeMillis());

			if((t2 - t1 >= 20000 && t2 - time1 < 5000) || (count > 50))
			{
                System.out.println("<>WebsitesTab<>waittillloaded<>2<>"+count+"<>");
                break;
			}
            
            Thread.sleep(500);
		}

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        
		if(presence)
		{
			Thread.sleep(500);
		}
		else
		{
			"tobreak".replace(null,"");
		}
		
    }

    public static void clickChatWindAppearance(WebDriver driver) throws Exception
    {
//    	final WebElement e = CommonUtil.elementfinder(driver,getRightNav(driver),"id","showactualsize");
//
//    	e.click();
//
//    	FluentWait wait = CommonUtil.waitreturner(driver,4,250);
//
//    	WebElement div = CommonUtil.elementfinder(driver,getRightNav(driver),"id","emactualPRV");
//
//    	wait.until(ExpectedConditions.visibilityOf(div));
    }
    
    public static void changePreviewWindowStatus(WebDriver driver, Boolean status, ExtentTest etest) throws Exception
    {
        final WebElement e = CommonUtil.elementfinder(driver,getRightNav(driver),"id","widgetstatus");
        final WebElement e1 = CommonUtil.elementfinder(driver,e,"id","widgetstatus_ddown");
        
        final String val = status?"online":"offline";
        
        FluentWait wait = CommonUtil.waitreturner(driver,4,250);

        if(!e1.getAttribute("style").contains("block"))
        {
            WebElement dp = CommonUtil.elementfinder(driver,e,"tagname","span");
            wait.until(ExpectedConditions.visibilityOf(dp));
            dp.click();
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e1.getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        List<WebElement> list = e1.findElements(By.tagName("li"));
        
        WebElement button1 = null;
        
        for(WebElement v : list)
        {
            if(v.getAttribute("val").equals(val))
            {
                button1 = v;
                break;
            }
        }
        
        Thread.sleep(500);
        
        button1.click();
        
        etest.log(Status.INFO,val+" is selected in Chat preview window");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e1.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickDesktopView(WebDriver driver) throws Exception
    {
    	final WebElement e = CommonUtil.elementfinder(driver,getRightNav(driver),"id","showwindowprv");

    	if(!e.getAttribute("class").contains("sel"))
    	{
    		e.click();
    	}

    	FluentWait wait = CommonUtil.waitreturner(driver,4,250);

    	WebElement div = CommonUtil.elementfinder(driver,getRightNav(driver),"id","window_prv");

    	wait.until(ExpectedConditions.visibilityOf(div));
    }

    public static void clickMobileView(WebDriver driver) throws Exception
    {
    	final WebElement e = CommonUtil.elementfinder(driver,getRightNav(driver),"xpath",".//em[@ismobile='true']");

    	if(!e.getAttribute("class").contains("sel"))
    	{
    		e.click();
    	}

    	FluentWait wait = CommonUtil.waitreturner(driver,4,250);

    	WebElement div = CommonUtil.elementfinder(driver,getRightNav(driver),"id","mobile_prv");

    	wait.until(ExpectedConditions.visibilityOf(div));
    }
    
    public static void clickArrowInTheme(WebDriver driver, final WebElement div, boolean left) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.visibilityOf(div));
        
        WebElement arrows = CommonUtil.elementfinder(driver,div,"classname","navarrow");
        
        CommonUtil.mouseHover(driver,div);
        
        WebElement leftArrow = CommonUtil.elementfinder(driver,arrows,"xpath",".//em[@isleft='true']");
        
        WebElement rightArrow = CommonUtil.elementfinder(driver,arrows,"xpath",".//em[@isleft='flase']");
        
        if(left)
        {
            wait.until(ExpectedConditions.visibilityOf(leftArrow));
            leftArrow.click();
        }
        else
        {
            wait.until(ExpectedConditions.visibilityOf(rightArrow));
            rightArrow.click();
        }
    }
}
