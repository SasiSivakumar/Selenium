//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatWindow
{
    /*Constants*/
    public static final By
    END_CHAT_BUTTON=By.id("endsession"),
    MYCHATS_CONTAINER=By.id("mycurrent_div"),
    CHAT_CONTAINER_CLASS=By.className("prelative"),
    VISIBLE_CHAT_UI_CLASS=By.className("ctrlcomp"),
    CLOSE_THIS_WINDOW_BUTTON=By.linkText(ResourceManager.getRealValue("closewindow")),
    MY_CHATS_CHAT_HEADER_CONTAINER=By.id("lschatheader"),
    AGENT_FILE=By.className("t-a-filecont"),
    VISITOR_FILE=By.className("t-v-filecont"),
    CRM_DATA_CONTAINER=By.id("crm_data"),
    CRM_DATA=By.className("crmld_infomn"),
    CRM_DATA_VALUE=By.className("crmld_infrht"),
    NOTES_DIV_CONTAINER=By.id("noteshead"),
    NOTE_CONTAINER=By.className("spt-ntsmn"),
    NOTE_CONTENT=By.className("nots-submsg"),
    NOTE_ADDED_BY=By.className("nots-msg"),
    NOTE_INPUT=By.id("notetxt"),
    SAVE_NOTE=By.cssSelector("[onclick*=submit]"),
    NOTES_LIST=By.id("notelist"),
    TYPING_STATUS_CONTENT=By.className("t-v-fcont"),
    INCOMING_CHAT_CONTAINER_ID = By.id("waitinglist")
    ;

    public static final String
    TYPING_STATUS_ID_TEMPLATE="<chatid>prdctmsg";

    public static final String
    INFO_VIEW_ID="info",
    CHAT_VIEW_ID="chat",
    NOTES_VIEW_ID="notes";

    public static final String
    TYPE="Type";

    public static final String
    MORE_ACTION_ID="moreaction",
    BLOCKED_IP=ResourceManager.getRealValue("chatsessionendopt3"),
    SHARE_URL_TEXT=ResourceManager.getRealValue("action_shareurl"),
    TRANSLATE_CHAT_TEXT=ResourceManager.getRealValue("action_translatechat"),
    SHARE_YOUR_SCREEN_TEXT=ResourceManager.getRealValue("action_share_screen"),
    ACTIONS_SEND_VISITOR_MAIL=ResourceManager.getRealValue("actions_mail"),
    ACTIONS_HISTORY=ResourceManager.getRealValue("actions_history"),
    SCREENSHARING_TEXT=ResourceManager.getRealValue("screenshare_agent_info"),
    BUTTONS_CLASS="cnfmbtm",
    SHARE_URL_CONFORM_BUTTON_ONCLICK="sendPushMessage",
    SHARE_URL_CANCEL_BUTTON_ONCLICK="closeDialog";
    ;

    public static final By
    FILE_UPLOAD_BUTTON=By.id("supportfileupl"),
    FILE_UPLOAD_CONTAINER=By.id("cfileshare"),
    FILE_UPLOAD_OPTIONS=By.id("attachmentoptions"),
    MORE_ACTION=By.id(MORE_ACTION_ID),
    DIV_CONTAINER=By.id("divcontainer"),
    CHAT_ACTION_DIALOG_BOX=By.id("dlgbox"),
    TRANSLATE_SEARCH_INPUT=By.id("trans_input"),
    TRANSLATE_DROPDOWN_CONTAINER=By.id("trans_inputauto"),
    TRANSLATE_INFO_BAR=By.id("confirmtranslate"),
    TRANSCRIPT_ACTION_DROPDOWN_CONTAINER=By.id("chatcusactions"),
    TRANSCRIPT_ACTION_DROPDOWN=By.id("combodiv"),
    TRANSCRIPT_ACTION_DROPDOWN_LIST=By.id("ulcontainer"),
    CHAT_NOTIFICATION_CONTAINER=By.id("waitinglist"),
    CHAT_NOTIFICATION=By.cssSelector("[id*=waitinfo_]"),
    BOT_IMAGE_IN_NOTIFICATION=By.cssSelector("img[src*='botagent']")
    ;



    public static boolean chatNotificationPresence(WebDriver driver, ExtentTest etest) throws Exception
    {
        return chatNotificationPresence(driver,etest,4);
    }
    
    public static boolean chatNotificationPresence(WebDriver driver, ExtentTest etest, int timeLimit) throws Exception
    {
        etest.info("test");
        FluentWait wait = CommonUtil.waitreturner(driver,timeLimit,200);
        
        String email = "email not found";
        String name = "username not found";
        
        try
        {
            email = ExecuteStatements.getUserMail(driver);
        }
        catch(Exception e){}
        try
        {
            name = ExecuteStatements.getUserName(driver);
        }
        catch(Exception e){}
        
        try
        {
            // CommonWait.waitTillDisplayed(driver,timeLimit,CHAT_NOTIFICATION);
            wait.until(ExpectedConditions.presenceOfElementLocated(CHAT_NOTIFICATION));
        }
        catch (Exception e) {
            etest.log(Status.INFO,"The chat notification is not present in "+email+"/"+name);
            return false;
        }
        
        try
        {
            // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));

            wait.until(ExpectedConditions.visibilityOfElementLocated(CHAT_NOTIFICATION));

            // CommonWait.waitTillDisplayed(driver,timeLimit,CHAT_NOTIFICATION);

            if(driver.findElement(INCOMING_CHAT_CONTAINER_ID).getAttribute("innerHTML").length() != 0)
            {
                etest.log(Status.INFO,"Chat notification is present in "+email+"/"+name);
            }
            else
            {
                etest.log(Status.INFO,"Chat notification is not present in "+email+"/"+name);
                return false;
            }
        }
        catch(Exception e)
        {
            etest.log(Status.INFO,"Chat notification not present in "+email+"/"+name);
            return false;
        }
        
        return true;
    }
    
    public static void acceptChat(WebDriver driver,ExtentTest etest) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            // loop was added to handle the chat notification not found exception
            for(int i = 0; i <= 2; i++)
            {
                try
                {
                    if(chatNotificationPresence(driver,etest,15))
                    {
                        break;
                    }
                }
                catch(Exception e)
                {
                    // System.out.println("attempt"+(i+1));
                }
                driver.navigate().refresh();
                if(i==2)
                {
                    throw new ZohoSalesIQRuntimeException("chat notification not found");
                }
            }

            Thread.sleep(1500);

            WebElement notification = CommonUtil.elfinder(driver,"id","waitinglist");

            String vid = CommonUtil.elementfinder(driver,notification,"tagname","div").getAttribute("id").replace("waitinfo_","");

            WebElement e = CommonUtil.elementfinder(driver,notification,"id","wpckup");

            TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatNotification","Before",0);

            e.click();

            Thread.sleep(500);

            for(int i = 1;i <= 20;i++)
            {
                Thread.sleep(500);
                
                WebElement chat = chatInMyChats(driver);
                
                if(chat == null)
                {
                    continue;
                }

                if(chat.getAttribute("innerHTML").contains(vid))
                {
                    break;
                }
            }
            
            WebElement chat = chatInMyChats(driver);

            WebElement txteditor = CommonUtil.elementfinder(driver,chat,"id","txteditor");

            wait.until(ExpectedConditions.visibilityOf(txteditor));
            
            TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatNotification","After",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.infoScreenshot(driver,etest);
            CommonUtil.printStackTrace(e);
            throw new ZohoSalesIQRuntimeException("chat notification not found");
        }
    }

    public static void ignoreAllIncomingChats(WebDriver driver)
    {
        try
        {
            for(int i=0;i<5;i++)
            {
                if(CommonWait.isPresent(driver,CHAT_NOTIFICATION))
                {
                    WebElement chat_notification=CommonUtil.getElement(driver,CHAT_NOTIFICATION);
                    CommonUtil.getElement(chat_notification,By.id("wcancel")).click();
                    CommonWait.waitTillHidden(chat_notification);
                }
                else
                {
                    return;
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }

    public static void ignoreChat(WebDriver driver) throws Exception
    {
        try
        {
            CommonWait.waitTillDisplayed(driver,CHAT_NOTIFICATION);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
        WebElement chat_notification=CommonUtil.getElement(driver,CHAT_NOTIFICATION);
        if(chat_notification != null)
        {
            CommonUtil.clickWebElement(driver,CommonUtil.getElement(chat_notification,By.id("wcancel")));
            CommonWait.waitTillHidden(chat_notification);
        }
    }

    public static WebElement chatInMyChats(WebDriver driver) throws Exception
    {
        List<WebElement> list = CommonUtil.elfinder(driver,"id","mycurrent_div").findElements(By.className("prelative"));

        WebElement chat = null;

        for(WebElement e : list)
        {
            if(e.getAttribute("style").contains("display: block;"))
                chat = e;
        }

        return chat;
    }

    public static WebElement chatInMyChats(WebDriver driver,String visname) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement header = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","mycurrent_div"),"xpath","//div[@id='innerheader']//ul[@id='lschatheader']");

        List<WebElement> headers = header.findElements(By.tagName("li"));

        WebElement chat_header = null;

        for(WebElement e : headers)
        {
            if(CommonUtil.elementfinder(driver,e,"tagname","span").getText().contains(visname))
                chat_header = e;
        }

        chat_header.click();

        final WebElement e1 = chat_header;

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e1.getAttribute("class").equals("sel"))
                {
                    return true;
                }
                return false;
            }
        });

        List<WebElement> list = CommonUtil.elfinder(driver,"id","mycurrent_div").findElements(By.className("prelative"));

        WebElement chat = null;

        for(WebElement e : list)
        {
            if(e.getAttribute("style").contains("display: block;"))
                chat = e;
        }

        return chat;
    }

    public static void clickClosethisWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);

        final WebElement e = CommonUtil.elementfinder(driver,chat,"id","infodiv");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!e.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,e,"linktext",ResourceManager.getRealValue("closewindow")).click();

        Thread.sleep(1000);

    }

    public static boolean isChatEnded(WebDriver driver,String visitor_name)
    {
        clickChatByVisitorName(driver,visitor_name);
        WebElement chat=getCurrentVisibleChat(driver);
        return CommonWait.isDisplayed(chat,By.id("infodiv"));
    }

    public static void endChat(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        CommonUtil.elementfinder(driver,chat,"id","endsession").click();

        WebElement e = CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue("endsession_endimd"));

        wait.until(ExpectedConditions.visibilityOf(e));

        e.click();
    }

    public static void endAndCloseChat(WebDriver driver) throws Exception
    {
        endChat(driver);
        clickClosethisWindow(driver);
    }

    public static void sentMessage(WebDriver driver,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        CommonUtil.elementfinder(driver,chat,"id","txteditor").click();
        CommonUtil.elementfinder(driver,chat,"id","txteditor").clear();        
        CommonUtil.elementfinder(driver,chat,"id","txteditor").sendKeys(msg);
        CommonUtil.elementfinder(driver,chat,"id","txteditor").sendKeys(Keys.RETURN);
    }

    public static void enterTextInMessageInChatInput(WebDriver driver,String message) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        WebElement chat = chatInMyChats(driver);
        CommonUtil.elementfinder(driver,chat,"id","txteditor").sendKeys(message);
    }
    
    public static WebElement getLastMessageInUserWindow(WebDriver driver, final String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        final WebElement chat = chatInMyChats(driver);
        
        final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,chat,"id","chatdivcontainer"),"id","msgtablediv");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getText().contains(msg))
                {
                    return true;
                }
                return false;
            }
        });
        
        Thread.sleep(500);
        
        List<WebElement> messages = div.findElements(By.tagName("tr"));
        
        WebElement e = messages.get(messages.size()-1);
        
        WebElement message = null;
        
        if(e.getAttribute("innerHTML").contains("trans-msg"))
        {
            System.out.println("getLastMessageInUserWindow<>trans-msg");
            message = CommonUtil.elementfinder(driver,e,"classname","trans-msg");
        }
        else
        {
            System.out.println("getLastMessageInUserWindow<>msgtxt");
            message = CommonUtil.elementfinder(driver,e,"classname","msgtxt");
        }
        
        wait.until(ExpectedConditions.visibilityOf(message));
                   
        return message;
    }
    
    public static boolean checkLastMessageInUserWindow(WebDriver driver,String user,final String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        final WebElement chat = chatInMyChats(driver);
        
        final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,chat,"id","chatdivcontainer"),"id","msgtablediv");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getText().contains(msg))
                {
                    return true;
                }
                return false;
            }
        });
        
        Thread.sleep(500);
        
        List<WebElement> messages = div.findElements(By.tagName("tr"));
        
        WebElement e = messages.get(messages.size()-1);
        
        if(e.getText().contains(user) && e.getText().contains(msg))
        {
            return true;
        }
        
        return false;
    }

    public static boolean checkMessageInUserWindow(WebDriver driver,String user,final String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        final WebElement chat = chatInMyChats(driver);

        final WebElement div = CommonUtil.elementfinder(driver,chat,"id","chatdivcontainer");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getText().contains(msg))
                {
                    return true;
                }
                return false;
            }
        });

        try
        {
            List<WebElement> messages = div.findElements(By.tagName("tr"));
            
            for(WebElement e : messages)
            {
                if(e.getText().contains(user) && e.getText().contains(msg))
                    return true;
            }
        }
        catch(StaleElementReferenceException excep)
        {
            Thread.sleep(1000);
            
            List<WebElement> messages = div.findElements(By.tagName("tr"));
            
            for(WebElement e : messages)
            {
                if(e.getText().contains(user) && e.getText().contains(msg))
                    return true;
            }
        }
        
        return false;
    }

    public static boolean waitTillMessageInChat(WebDriver driver,final String expected_text)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,10,250);

            final WebElement chat = chatInMyChats(driver);
            
            final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,chat,"id","chatdivcontainer"),"id","msgtablediv");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getText().contains(expected_text))
                    {
                        return true;
                    }
                    return false;
                }
            });

            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }


    public static void initiateChat(WebDriver driver,String id,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        Tab.clickVisitorsOnline(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsales")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsales")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
        
        WebElement e = CommonUtil.elfinder(driver,"id",id);
        
        VisitorsOnline.clickVisitor(e);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht"),"tagname","textarea").sendKeys(msg);

        WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");
        CommonUtil.elementfinder(driver,pelmt,"linktext",ResourceManager.getRealValue("rings_proactive")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".chatarea.ps-container")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".chatarea.ps-container")));

        Thread.sleep(1000);
    }

    public static boolean continueChat(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");
        CommonUtil.elementfinder(driver,pelmt,"linktext","Continue").click();

        Thread.sleep(2000);

        WebElement chat = chatInMyChats(driver);
        WebElement txteditor = CommonUtil.elementfinder(driver,chat,"id","txteditor");

        return CommonWait.waitTillDisplayed(txteditor);
    }

    public static boolean isMyChatsTabDisplayed(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,By.id("suppm_mycurrent"));
    }

    public static void closeAllChats(WebDriver driver) throws Exception
    {
        if(isMyChatsTabDisplayed(driver)==false)
        {
            return;
        }

        Tab.clickMyChats(driver);

        int max_chats_to_end=10;
        int chats_ended=0;

        while(isMyChatsTabDisplayed(driver) && chats_ended<max_chats_to_end)
        {
            closeCurrentVisibleChat(driver);
            chats_ended++;   
        }
    }

    public static void closeCurrentVisibleChat(WebDriver driver) throws Exception
    {
        WebElement current_visible_chat=getCurrentVisibleChat(driver);

        boolean continue_ending=false;

        if(current_visible_chat!=null)
        {
            if( current_visible_chat.findElements(END_CHAT_BUTTON).size()!=0 && current_visible_chat.findElement(END_CHAT_BUTTON).isDisplayed() )
            {
                endChat(driver);
                continue_ending=true;
            }
            if( (current_visible_chat.findElements(CLOSE_THIS_WINDOW_BUTTON).size()!=0 && current_visible_chat.findElement(CLOSE_THIS_WINDOW_BUTTON).isDisplayed()) || continue_ending )
            {
                clickClosethisWindow(driver);
                continue_ending=true;
            }
        }
    }

    public static WebElement getCurrentVisibleChat(WebDriver driver)
    {
        List<WebElement> chat_containers=driver.findElement(MYCHATS_CONTAINER).findElements(CHAT_CONTAINER_CLASS);        

        for(WebElement chat_container : chat_containers)
        {
            if(chat_container.getAttribute("id").matches("LD_\\d+_\\d+") && chat_container.getAttribute("style").contains("display: block"))
            {
                return chat_container;
            }
        }

        return null;
    }

    public static void clickChatByVisitorId(WebDriver driver,String visitor_id) throws Exception
    {
        String visitor_name=VisitorsOnline.getVisitorNameByVisitorId(driver,visitor_id);
        Tab.clickMyChats(driver);
        clickChatByVisitorName(driver,visitor_name);
    }

    public static void clickChatByVisitorName(WebDriver driver,String visitor_name)
    {
        List<WebElement> chats = CommonUtil.getElement(driver,MY_CHATS_CHAT_HEADER_CONTAINER).findElements(By.tagName("li"));
        CommonUtil.getElementByAttributeValue(chats,"innerText",visitor_name).click();
        CommonUtil.waitTillWebElementContainsAttributeValue(getCurrentVisibleChat(driver),"innerText",visitor_name);
    }
    public static boolean isFileUploadIconVisible(WebDriver driver)
    {
        List<WebElement> attach_icons=getCurrentVisibleChat(driver).findElements(FILE_UPLOAD_CONTAINER);

        if(attach_icons.size()==0)
        {   
            return false;
        }

        return attach_icons.get(0).isDisplayed();
    }

    public static boolean uploadFile(WebDriver driver,final FileType file_type)
    {
        WebElement attach_file_input=getCurrentVisibleChat(driver).findElement(FILE_UPLOAD_BUTTON);
        FileUpload.uploadFile(attach_file_input,file_type);

        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,10,200);
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(getCurrentVisibleChat(driver).findElements(AGENT_FILE).size()>0)
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
        
        return true;
    }

    public static WebElement getMoreActionDropdown(WebDriver driver)
    {
        List<WebElement> div_containers=getCurrentVisibleChat(driver).findElements(DIV_CONTAINER);
        WebElement dropdown_container=CommonUtil.getElementByAttributeValue(div_containers,"odivstatus",MORE_ACTION_ID);
        return dropdown_container;
    }

    public static void clickMoreAction(WebDriver driver)
    {
        getCurrentVisibleChat(driver).findElement(MORE_ACTION).click();
        waitTillMoreActionDropdownDisplayed(driver,true);
    }

    public static void waitTillMoreActionDropdownDisplayed(WebDriver driver,boolean isDisplayed)
    {
        CommonWait.waitTillDisplayed(getMoreActionDropdown(driver),isDisplayed);
    }

    public static WebElement getDropdownElement(WebDriver driver,String action_name)
    {
        List<WebElement> actions=getMoreActionDropdown(driver).findElement(By.tagName("ul")).findElements(By.tagName("li"));
        return CommonUtil.getElementByAttributeValue(actions,"innerText",action_name);             
    }

    public static void selectChatAction(WebDriver driver,String action_name)
    {
        clickMoreAction(driver);
        getDropdownElement(driver,action_name).click();
        if(action_name.equals(TRANSLATE_CHAT_TEXT))
        {
            return;
        }
        waitTillMoreActionDropdownDisplayed(driver,false); 
    }

    public static void shareURL(WebDriver driver,String url)
    {
        selectChatAction(driver,SHARE_URL_TEXT);
        CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,CHAT_ACTION_DIALOG_BOX));
        WebElement share_url_input=CommonUtil.getElement(driver,CHAT_ACTION_DIALOG_BOX).findElement(By.tagName("input"));
        share_url_input.clear();
        share_url_input.sendKeys(url);
        CommonUtil.getElementByAttributeValue( driver.findElement(CHAT_ACTION_DIALOG_BOX).findElements(By.className(BUTTONS_CLASS)) , "onclick", SHARE_URL_CONFORM_BUTTON_ONCLICK).click();
        CommonWait.waitTillHidden(driver,CHAT_ACTION_DIALOG_BOX);
    }

    public static void translateChatTo(WebDriver driver,String language,ExtentTest etest)
    {
        selectChatAction(driver,TRANSLATE_CHAT_TEXT);
        clickFromTranslationDropdown(driver,language);
    }

    public static boolean clickScreenSharing(WebDriver driver,ExtentTest etest) throws Exception
    {
        selectChatAction(driver,SHARE_YOUR_SCREEN_TEXT);
        WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Assist");
        if(popup != null)
        {
            etest.log(Status.WARNING,"Screen Sharing limit reached");
            TakeScreenshot.infoScreenshot(driver,etest);
            HandleCommonUI.clickPositivePopupButton(popup);
            return false;
        }
        else if(checkLastMessageInUserWindow(driver,"",SCREENSHARING_TEXT)==false)
        {
            throw new ZohoSalesIQRuntimeException("Screen sharing info message '"+SCREENSHARING_TEXT+"' was not found after agent clicked screensharing");
        }
        return true;
    }

    public static void blockIPFromChat(WebDriver driver,ExtentTest etest)
    {
        selectChatAction(driver,BLOCKED_IP);
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"Block an IP");
        HandleCommonUI.clickPositivePopupButton(popup);   
        etest.log(Status.INFO,"Visitor's IP was blocked.");
    }

    public static void clickFromTranslationDropdown(WebDriver driver,String language)
    {
        List<WebElement> language_lists=getDropdownElement(driver,TRANSLATE_CHAT_TEXT).findElements(By.tagName("ul"));
        List<WebElement> languages=CommonUtil.getChildElementsOfElementListBy(language_lists,By.tagName("li"));
        WebElement language_element=CommonUtil.getElementByAttributeValue(languages,"innerText",language);
        CommonUtil.inViewPort(language_element);
        CommonUtil.mouseHoverAndClick(driver,language_element);
        WebElement translate_info_bar=getCurrentVisibleChat(driver).findElement(TRANSLATE_INFO_BAR);
        CommonWait.waitTillDisplayed(translate_info_bar);
    }

    public static WebElement getChatTranscriptActionDropdownButton(WebDriver driver)
    {
        return getCurrentVisibleChat(driver).findElement(TRANSCRIPT_ACTION_DROPDOWN_CONTAINER).findElement(TRANSCRIPT_ACTION_DROPDOWN);
    }

    public static WebElement getChatTranscriptActionDropdownList(WebDriver driver)
    {
        return getChatTranscriptActionDropdownButton(driver).findElement(TRANSCRIPT_ACTION_DROPDOWN_LIST);
    }

    public static void waitTillChatTranscriptActionDropdownDisplayed(WebDriver driver,boolean isDisplayed)
    {
        CommonWait.waitTillDisplayed(getChatTranscriptActionDropdownList(driver),isDisplayed);
    }

    public static void clickChatTranscriptActionDropdown(WebDriver driver)
    {
        getChatTranscriptActionDropdownButton(driver).click();
        waitTillChatTranscriptActionDropdownDisplayed(driver,true);
    }

    public static void selectFromChatTranscriptActionDropdown(WebDriver driver,String value)
    {
        List<WebElement> dropdown_values=getChatTranscriptActionDropdownList(driver).findElement(By.tagName("ul")).findElements(By.tagName("li"));           
        CommonUtil.getElementByAttributeValue(dropdown_values,"innerText",value).click();
    }

    public static void clickSendVisitorInformationAsEmailButton(WebDriver driver,ExtentTest etest)
    {
        clickChatTranscriptActionDropdown(driver);
        selectFromChatTranscriptActionDropdown(driver,ACTIONS_SEND_VISITOR_MAIL);
        CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,CHAT_ACTION_DIALOG_BOX));
        etest.log(Status.INFO,"'Send visitor information as email button' was clicked");
    }

    public static void clickHistoryInChatTranscriptDropdown(WebDriver driver,ExtentTest etest)
    {
        clickChatTranscriptActionDropdown(driver);
        selectFromChatTranscriptActionDropdown(driver,ACTIONS_HISTORY);
        etest.log(Status.INFO,"History was clicked from chat transcript dropdown");
    }

    public static void clickContentButtonInSendEmailPopup(WebDriver driver)
    {
        CommonUtil.getElement(driver,CHAT_ACTION_DIALOG_BOX,By.className("addmailcnt")).click();
    }

    public static String getFromMailAddressInSendEmailPopup(WebDriver driver)
    {
        return CommonUtil.getElement(driver,CHAT_ACTION_DIALOG_BOX,By.className("frmname")).getText();
    }

    public static String getCRMType(WebDriver driver)
    {
        return CommonUtil.getElementByAttributeValue(  getCurrentVisibleChat(driver).findElement(CRM_DATA_CONTAINER).findElements(CRM_DATA) , "innerText" , TYPE ).findElement(CRM_DATA_VALUE).getText();
    }

    public static boolean confirmAutoTranslate(WebDriver driver,ExtentTest etest,boolean isConfirm)
    {
        By locator=isConfirm?By.id("confirmtrans"):By.id("canceltrans");
        String translate_status=isConfirm?"selected":"cancelled";

        WebElement button=CommonUtil.getElement(getCurrentVisibleChat(driver),locator);

        CommonUtil.mouseHoverAndClick(driver,button);
        etest.log(Status.INFO,"Auto translate was "+translate_status);

        return CommonWait.waitTillHidden(button);
    }

    public static boolean openVisitorInfo(WebDriver driver)
    {
        return openChatView(driver,INFO_VIEW_ID);
    }

    public static boolean openNotes(WebDriver driver)
    {
        return openChatView(driver,NOTES_VIEW_ID);
    }

    public static boolean openChatTranscript(WebDriver driver)
    {
        return openChatView(driver,CHAT_VIEW_ID);
    }

    public static boolean openChatView(WebDriver driver,String view_icon_id)
    {
        List<WebElement> icons=driver.findElements(By.id(view_icon_id));
        WebElement icon=CommonUtil.getVisibileWebElementFromList(icons);
        CommonUtil.mouseHoverAndClick(driver,icon);
        return CommonUtil.waitTillWebElementContainsAttributeValue(icon,"class","sel");
    }

    public static Hashtable<String,String> getAllVisitorInfo(WebDriver driver)
    {
        List<WebElement> info_containers=driver.findElements(By.id("subtabholder"));
        WebElement info_container=CommonUtil.getElementByAttributeValue(info_containers,"style","block");
        return ChatHistoryChat.getAllVisitorInfo(info_container);
    }

    public static WebElement getNotesContainer(WebDriver driver)
    {
        List<WebElement> note_containers=driver.findElements(NOTES_DIV_CONTAINER);
        return CommonUtil.getVisibileWebElementFromList(note_containers);
    }

    public static ArrayList<String> getNotesInfo(WebDriver driver)
    {
        return getNotesInfo(  getNotesContainer(driver).findElement(NOTES_LIST) );  
    }

    public static boolean containsNote(WebDriver driver,String note)
    {
        return CommonUtil.isListContains( getNotesInfo(driver) ,note);
    }

    public static ArrayList<String> getNotesInfo(WebElement notes_list_container)
    {
        ArrayList<String> notes_content=new ArrayList<String>();

        List<WebElement> notes=notes_list_container.findElements(NOTE_CONTAINER);

        for(WebElement note : notes)
        {
            notes_content.add(note.getText());
        }

        return notes_content;
    }

    public static boolean addNote(WebDriver driver,ExtentTest etest,String note)
    {
        WebElement notes_container=getNotesContainer(driver);
        WebElement note_input=CommonUtil.getElement(driver,NOTE_INPUT);

        CommonUtil.sendKeysToWebElement(driver,note_input,note);
        CommonUtil.getElement(notes_container,SAVE_NOTE).click();

        if(note.length()>2048)
        {
            com.zoho.livedesk.client.ChatHistory.ChatHistoryTests.checkNoteLengthCharLimit(driver,etest);
        }

        boolean isNoteAdded=CommonUtil.waitTillWebElementContainsAttributeValue(notes_container.findElement(NOTES_LIST),"innerText",note);

        if(isNoteAdded)
        {
            etest.log(Status.INFO,"Note '"+note+"' was added successfully.");
        }
        else
        {
            etest.log(Status.INFO,"Note '"+note+"' was NOT added successfully.");            
        }

        return isNoteAdded;
    }

    public static boolean isRecentChatsView(WebDriver driver)
    {
        WebElement rhs_view_container=ChatHistoryChat.getRHSVisitorDataContainer(driver);

        if(CommonWait.isDisplayed( CommonUtil.getElement(rhs_view_container,RHS_SHOW_VISITOR_INFO_BUTTON) ))
        {
            return true;
        }
        else if(CommonWait.isDisplayed( CommonUtil.getElement(rhs_view_container,RHS_SHOW_RECENT_CHATS_BUTTON) ))
        {
            return false;
        }

        throw new ZohoSalesIQRuntimeException("Invalid view type. Current view is neither visitor info nor recent chats. Exception may have occured due to UI changes");
    }

    public static boolean toggleRecentChatsRHSView(WebDriver driver)
    {
        return toggleRHSView(driver,true);
    }

    public static boolean toggleVisitorInfoRHSView(WebDriver driver)
    {
        return toggleRHSView(driver,false);
    }

    public static boolean toggleRHSView(WebDriver driver,boolean isRecentChatsView)
    {
        if(isRecentChatsView(driver)==isRecentChatsView)
        {
            return true;
        }

        By button_locator=isRecentChatsView?RHS_SHOW_RECENT_CHATS_BUTTON:RHS_SHOW_VISITOR_INFO_BUTTON;

        WebElement rhs_view_container=ChatHistoryChat.getRHSVisitorDataContainer(driver);

        WebElement button=CommonUtil.getElement(rhs_view_container,button_locator);

        CommonWait.waitTillDisplayed(button);
        button.click();
        CommonWait.waitTillHidden(button);

        CommonUtil.sleep(100);

        return (isRecentChatsView(driver)==isRecentChatsView);
    }

    //recent chats

    public static boolean openRecentChatByQuestion(WebDriver driver,String question)
    {
        toggleRecentChatsRHSView(driver);

        WebElement rhs_view_container=ChatHistoryChat.getRHSVisitorDataContainer(driver);
        WebElement recent_chats_container=CommonUtil.getElement(rhs_view_container,RECENT_CHATS_LIST_RHS_CONTAINER);
        List<WebElement> recent_chats=recent_chats_container.findElements(RECENT_CHAT_RHS_CONTAINER);
        WebElement recent_chat=CommonUtil.getElementByAttributeValue(recent_chats,"innerText",question);
        recent_chat.click();
        return CommonWait.waitTillDisplayed(rhs_view_container,RECENT_CHAT_HEADER_CONTAINER);
    }

    public static boolean closeRecentChat(WebDriver driver)
    {   
        WebElement recent_chats_header=CommonUtil.getVisibileWebElementFromList(driver.findElements(RECENT_CHAT_HEADER_CONTAINER));
        WebElement close_button=CommonUtil.getElement(recent_chats_header,CLOSE_ICON_RECENT_CHATS);
        CommonUtil.mouseHoverAndClick(driver,close_button);

        return CommonWait.isHidden(close_button);
    }

    public static WebElement getRecentChat(WebDriver driver)
    {
        return CommonUtil.getVisibileWebElementFromList(driver.findElements(RECENT_CHAT_DIV_CONTAINER));
    }

    public static final By
    RHS_SHOW_VISITOR_INFO_BUTTON=By.cssSelector("[onclick*=showVisitorInfo]"),
    RHS_SHOW_RECENT_CHATS_BUTTON=By.cssSelector("[onclick*=loadRecentVisits]"),
    RECENT_CHATS_LIST_RHS_CONTAINER=By.className("rcvisitsub"),
    RECENT_CHAT_RHS_CONTAINER=By.className("rcvstinrmn"),
    RECENT_CHAT_DIV_CONTAINER=By.className("rcvstexpndsub"),
    RECENT_CHAT_HEADER_CONTAINER=By.className("spt-tckthdr"),
    RECENT_CHAT_QUESTION=By.className("t-v-questionmn"),
    RECENT_CHAT_DEPARTMENT=By.className("pst_titdep"),
    RECENT_CHAT_VISITOR_NAME=By.id("chatvisname"),
    CLOSE_ICON_RECENT_CHATS=By.className("sptkt_close")
    ;

    public static Hashtable<String,String> getRecentChatInfo(WebDriver driver)
    {
        return getRecentChatInfo( getRecentChat(driver) );
    }

    public static Hashtable<String,String> getRecentChatInfo(WebElement recent_chat_container)
    {
        Hashtable<String,String> recent_chat_info=new Hashtable<String,String>();

        String chatid=CommonUtil.getElement(recent_chat_container,ChatHistoryChat.CHATID).getText().trim();
        String question=CommonUtil.getElement(recent_chat_container,RECENT_CHAT_QUESTION,By.tagName("h1")).getText().replace(chatid,"").trim();
        String department=CommonUtil.getElement(recent_chat_container,RECENT_CHAT_DEPARTMENT).getText();

        recent_chat_info.put(ChatHistory.CH_ID,chatid);
        recent_chat_info.put(ChatHistory.QUESTION,question);
        recent_chat_info.put(ChatHistory.DEPARTMENT,department);

        return recent_chat_info;
    }

    //history menu
    public static final By
    PREVIOUS_CHATS_CONTAINER_HISTORY_TAB_LHS=By.id("pcvisitors"),
    HISTORY_CHAT_HEADER=By.id("pcsubtab"),
    HISTORY_CHAT_CONTAINER=By.id("pcdata"),
    HISTORY_CHAT_HEADER_INNER_CONTAINER=By.className("grayee"),
    HISTORY_CHAT_QUESTION=RECENT_CHAT_QUESTION,
    HISTORY_CHAT_VISITOR_NAME=RECENT_CHAT_VISITOR_NAME,
    HISTORY_CHAT_VISITOR_EMAIL=By.id("chatvisemail"),
    HISTORY_CHAT_AGENT_NAME=By.className("phsupport"),
    AGENT_IMAGE=By.className("sptrep-info")
    ;

    public static WebElement getChatFromChatTranscriptHistoryByIndex(WebDriver driver,int index)
    {
        WebElement history_lhs=CommonUtil.getVisibileWebElementFromList(driver.findElements(PREVIOUS_CHATS_CONTAINER_HISTORY_TAB_LHS));
        WebElement chat=history_lhs.findElements(By.tagName("li")).get(index);
        return chat;        
    }

    public static boolean openChatFromChatTranscriptHistory(WebDriver driver,int index)
    {
        WebElement chat=getChatFromChatTranscriptHistoryByIndex(driver,index);

        CommonUtil.mouseHoverAndClick(driver,chat);
        CommonUtil.waitTillWebElementContainsAttributeValue(chat,"class","sel");
        return CommonUtil.hasClass(chat,"sel");
    }

    public static String getAgentNameChatTranscriptHistory(WebDriver driver,int index)
    {
        WebElement chat=getChatFromChatTranscriptHistoryByIndex(driver,index);
        return CommonUtil.getElement(driver,HISTORY_CHAT_AGENT_NAME).getText().trim();
    }

    public static boolean isAgentImagePresent(WebDriver driver)
    {
        return CommonWait.isPresent(driver,AGENT_IMAGE);
    }

    public static Hashtable<String,String> getHistoryChatData(WebDriver driver)
    {
        Hashtable<String,String> chat_data=new Hashtable<String,String>();

        WebElement history_header_container=CommonUtil.getVisibileWebElementFromList(driver.findElements(HISTORY_CHAT_HEADER));

        List<WebElement> value_containers=CommonUtil.getElement(history_header_container,HISTORY_CHAT_HEADER_INNER_CONTAINER).findElements(By.tagName("span"));

        chat_data.put(ChatHistory.VISITOR_PHONE,value_containers.get(0).getText());
        chat_data.put(ChatHistory.DEPARTMENT,value_containers.get(1).getText());
        chat_data.put(ChatHistory.WEBSITE,value_containers.get(2).getText());

        WebElement history_chat_container=CommonUtil.getVisibileWebElementFromList(driver.findElements(HISTORY_CHAT_CONTAINER));

        String chatid=CommonUtil.getElement(history_chat_container,ChatHistoryChat.CHATID).getText().trim();
        String question=CommonUtil.getElement(history_chat_container,HISTORY_CHAT_QUESTION,By.tagName("h1")).getText().replace(chatid,"").trim();

        chat_data.put(ChatHistory.CH_ID,chatid);
        chat_data.put(ChatHistory.QUESTION,question);

        String visitor_name=CommonUtil.getElement(history_chat_container,HISTORY_CHAT_VISITOR_NAME).getText();
        String visitor_mail=CommonUtil.getElement(history_chat_container,HISTORY_CHAT_VISITOR_EMAIL).getText();

        chat_data.put(ChatHistory.VISITOR,visitor_name);
        chat_data.put(ChatHistory.MAIL,visitor_mail);

        return chat_data;
    }

    public static String getSalesIQChatId(WebElement chat)
    {
        return chat.getAttribute("id");
    }

    public static boolean isLiveTypingStatus(WebDriver driver,ExtentTest etest,String typed_text)
    {

        String typing_id=getTypingStatusIdOfCurrentChat(driver);
        
        boolean isTypingStatusFound=CommonWait.waitTillDisplayed(driver,By.id(typing_id));

        if(isTypingStatusFound)
        {
            etest.log(Status.INFO,"Typing status container was found");
        }
        else
        {
            etest.log(Status.INFO,"Typing status container was NOT found");
            return false;
        }

        WebElement typing_container=CommonUtil.getElement(driver,By.id(typing_id),TYPING_STATUS_CONTENT);

        String typing_status_text=typing_container.getText();

        return HandleCommonUI.isLiveTypingStatus(typing_status_text,typed_text,etest);
    }

    public static String getTypingStatusIdOfCurrentChat(WebDriver driver)
    {
        WebElement chat=getCurrentVisibleChat(driver);
        String chat_id=getSalesIQChatId(chat);
        String typing_id=TYPING_STATUS_ID_TEMPLATE.replace("<chatid>",chat_id);
        return typing_id;
    }

    public static WebElement getAcceptChatContainer(WebDriver driver)
    {
        return CommonUtil.getElement(driver,CHAT_NOTIFICATION);
    }

    public static int getAverageRatingFromAcceptChatContainer(WebDriver driver)
    {

        CommonWait.waitTillDisplayed(driver,By.id("waitinglist"));

        final String RATING_PARTIAL_CLASSNAME="avgrat";

        WebElement accept_chat=getAcceptChatContainer(driver);
        WebElement rating_element=CommonUtil.getElement(accept_chat,By.id("avgrating"),By.tagName("em"));

        if(rating_element==null)
        {
            throw new ZohoSalesIQRuntimeException("No rating container found");
        }

        String rating_classes=rating_element.getAttribute("class");
        Pattern pattern = Pattern.compile(RATING_PARTIAL_CLASSNAME+"\\d");
        Matcher matcher = pattern.matcher(rating_classes);
        if (matcher.find())
        {
            String rating_classname=matcher.group(0);
            String rating=rating_classname.replace(RATING_PARTIAL_CLASSNAME,"");
            return Integer.parseInt(rating);
        }

        throw new ZohoSalesIQRuntimeException("Rating container was found. But it had invalid rating. class attribute value : "+rating_classes);
    }   

    public static String getEndChatInfoMessage(WebDriver driver)
    {
        WebElement chat=getCurrentVisibleChat(driver);

        if(CommonWait.isHidden(CommonUtil.getElement(chat,By.id("compdiv"))))
        {
            throw new ZohoSalesIQRuntimeException("End chat info message container is not found.");
        }

        return CommonUtil.getElement(driver,By.id("compdiv")).getText();
    }

    public static boolean isBotToHumanChatTransferNotification(WebDriver driver,ExtentTest etest)
    {
        CommonWait.waitTillDisplayed(driver,CHAT_NOTIFICATION_CONTAINER);

        int failcount=0;

        WebElement chat_notification=getAcceptChatContainer(driver);

        String actual_text=chat_notification.getAttribute("innerText");

        if(CommonUtil.checkStringContainsAndLog(ResourceManager.getRealValue(""),actual_text,"bot to human chat trasfer description",etest)==false)
        {
            failcount++;
        }

        if(CommonWait.isPresent(chat_notification,BOT_IMAGE_IN_NOTIFICATION))
        {
            etest.log(Status.PASS,"Bot image in bot to human transfer notification is found as expected.");
        }
        else
        {
            etest.log(Status.FAIL,"Bot image in bot to human transfer notification is NOT found.");
            failcount++;
        }

        if(failcount>0)
        {
            TakeScreenshot.screenshot(driver,etest);
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean isChatRequestReceived(WebDriver driver,ExtentTest etest,String visitor_name)
    {
        String username=ExecuteStatements.getUserName(driver);

        if(Tab.isMyChatsShown(driver))
        {
            try
            {
                Tab.clickMyChats(driver);
                clickChatByVisitorName(driver,visitor_name);

                WebElement chat=getCurrentVisibleChat(driver);

                if(CommonWait.isDisplayed( CommonUtil.getElement(chat,By.cssSelector("[onclick*='ForwardPickup']")) ))
                {
                    etest.log(Status.INFO,"Bot transfered chat request was received by "+username);
                    return true;
                }

                if(CommonWait.isDisplayed( CommonUtil.getElement(chat,By.id("txteditor")) ))
                {
                    etest.log(Status.INFO,"Bot transfered chat request was accepted by "+username);
                    return true;
                }
            }
            catch(Exception e)
            {
                etest.log(Status.INFO,"Chat Request may not be received");
                e.printStackTrace();
            }
        }

        etest.log(Status.INFO,"Bot transfered chat was NOT received by "+username);
        return false;      
    }

    public static boolean joinChat(WebDriver driver,ExtentTest etest)
    {
        String username=ExecuteStatements.getUserName(driver);

        WebElement chat=getCurrentVisibleChat(driver);

        CommonWait.waitTillDisplayed( CommonUtil.getElement(chat,By.cssSelector("[onclick*='ForwardPickup']")) );

        WebElement join=CommonUtil.getElement(chat, By.cssSelector("[onclick*='ForwardPickup']") );

        CommonUtil.clickWebElement(driver,join);

        CommonWait.waitTillHidden(join);

        etest.log(Status.INFO,username+" has joined the forwarded chat");
        TakeScreenshot.infoScreenshot(driver,etest);

        return CommonWait.waitTillDisplayed( CommonUtil.getElement(driver,By.id("txteditor")) );
    }

    public static boolean isBotTransferRequestReceived(WebDriver driver,ExtentTest etest,String visitor_name)
    {
        String username=ExecuteStatements.getUserName(driver);

        try
        {
            HandleCommonUI.waitTillPopupFound(driver,"innerText","transfer");
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"transfer");

            if(CommonUtil.checkStringContainsAndLog(visitor_name,popup.getAttribute("innerText"),"popup text",etest))
            {
                etest.log(Status.INFO,"Bot transfered chat request was received by "+username);
                return true;
            }
            else
            {
                etest.log(Status.INFO,"Bot transfered chat request was NOT received by "+username);
                return false;
            }

        }
        catch(Exception e)
        {
            etest.log(Status.INFO,"Chat Request may not be received");
            CommonUtil.printStackTrace(e);
        }


        etest.log(Status.INFO,"Bot transfered chat was NOT received by "+username);
        return false;
    }

    public static boolean handleBotTransfer(WebDriver driver,boolean isAccept)
    {
        HandleCommonUI.waitTillPopupFound(driver,"innerText","transfer");
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"transfer");
        HandleCommonUI.clickButtonInPopup(popup,isAccept);
        return CommonWait.waitTillHidden(popup);   
    }

    public static void waitTillAcceptTransferUI(WebDriver driver)
    {
         HandleCommonUI.waitTillPopupFound(driver,"innerText","transfer");   
    }

    public static boolean isAgentAcceptTransferUIShown(WebDriver driver)
    {
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"transfer");
        return CommonWait.isDisplayed(popup);
    }
}
