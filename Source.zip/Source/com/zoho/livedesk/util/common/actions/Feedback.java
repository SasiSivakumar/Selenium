//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.Select;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class Feedback
{
	public static List<WebElement> getFeedbacks(WebDriver driver) throws Exception
	{
		WebElement div = CommonUtil.elfinder(driver,"id","feedbacklist");
		return div.findElements(By.className("cursr-point"));
	}
	public static WebElement getFeedbackDiv(WebDriver driver,String content) throws Exception
	{
		List<WebElement> list = getFeedbacks(driver);
		for(WebElement e : list)
		{
			CommonUtil.inViewPort(e);
			if(e.getText().contains(content))
			{
				return e;
			}
		}
		return null;
	}

	public static WebElement getFeedbackDiv(WebDriver driver,int count) throws Exception
	{
		WebElement div = CommonUtil.elfinder(driver,"id","feedbacklist");

		List<WebElement> list = div.findElements(By.className("cursr-point"));

		return list.get(count);
	}

	public static void openFeedback(WebDriver driver,final String feedback) throws Exception
	{
		getFeedbackDiv(driver,feedback).click();
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(new Function<WebDriver,Boolean>(){
        public Boolean apply(WebDriver driver)
        {
            if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("fdbckdetail"))
            {
                return true;
            }
            return false;
        }
    });
    wait.until(new Function<WebDriver,Boolean>(){
        public Boolean apply(WebDriver driver)
        {
            if(driver.findElement(By.id("fdbckdetail")).findElement(By.tagName("h2")).getText().contains(feedback))
            {
                return true;
            }
            return false;
        }
    });
	}

	public static WebElement getFeedbackTabs(WebDriver driver,String tab) throws Exception
	{
		WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdetail"),"id","lvs_fdkmenuprt");
		List<WebElement> list = div.findElements(By.tagName("li"));
		for(WebElement e: list)
		{
			if(e.getAttribute("id").equals(tab))
			{
				return e;
			}
		}

		return null;
	}

	public static void clickFeedbackTabs(WebDriver driver,String tab) throws Exception
	{
		WebElement e = getFeedbackTabs(driver,tab);
		final String id = e.getAttribute("class");
		e.click();
		final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdetail"),"id","fdbckexcnt");
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getAttribute("innerHTML").contains(id))
                {
                    return true;
                }
                return false;
            }
        });
    Thread.sleep(1000);
	}

	public static void clickCloseInFeedback(WebDriver driver) throws Exception
	{
		CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdetail"),"classname","cclose").click();
	}

	public static void clickMyFeedback(WebDriver driver) throws Exception
	{
		CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","hismysupport").click();
	}

	public static void waitTillFeedbackLoading(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,5,250);
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
        public Boolean apply(WebDriver driver)
        {
		      if(driver.findElement(By.id("feedback_div")).getAttribute("innerHTML").contains("feedbackload"))
		      {
		          return true;
		      }
		      return false;
        }
  		});
	  }
		catch(Exception e)
		{}

		wait = CommonUtil.waitreturner(driver,10,250);

		wait.until(new Function<WebDriver,Boolean>(){
        public Boolean apply(WebDriver driver)
        {
            if(driver.findElement(By.id("feedback_div")).getText().contains("Loading"))
            {
							return false;
            }
            return true;
        }
    });
	}

	public static void selectFilter(WebDriver driver,String id,String value) throws Exception
	{
		final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","cushistoryfilter");
		CommonUtil.elementfinder(driver,div,"tagname","em").click();
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(new Function<WebDriver,Boolean>(){
        public Boolean apply(WebDriver driver)
        {
            if(div.findElement(By.id("ulcontainer")).getAttribute("style").contains("block"))
            {
                return true;
            }
            return false;
        }
    });
		Thread.sleep(1000);
    wait.until(ExpectedConditions.visibilityOf(div.findElement(By.id("ulcontainer"))));
		Thread.sleep(1000);
    WebElement values = CommonUtil.elementfinder(driver,div,"xpath",".//select[@id='"+id+"']");
    Select se = new Select(values);
    se.selectByVisibleText(value);
	}

	public static void clickCloseInFilter(WebDriver driver) throws Exception
	{
		CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","cushistoryfilter"),"classname","cclose").click();
	}

	public static String getDetails(WebDriver driver,WebElement fdb,String column,String path) throws Exception
	{
		//secnd-clm  h2 a thrd-clm pre span
		return CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,fdb,"classname",column),"tagname",path).getText();
	}

	public static String getUserName(WebDriver driver,WebElement fdb) throws Exception
	{
		return CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,fdb,"classname","four-clm"),"tagname","img").getAttribute("usrname");
	}

	public static String getStar(WebDriver driver,WebElement fdb) throws Exception
	{
		return CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,fdb,"classname","four-clm"),"classname","fb_star").getAttribute("class").replace("fb_star","");
	}

	public static WebElement getFeedbackByUniqueName(WebDriver driver,String name)
	{
		List<WebElement> feedbacks=CommonUtil.getElement(driver,By.id("feedbacklist")).findElements(By.className("cursr-point"));
		return CommonUtil.getElementByAttributeValue(feedbacks,"innerText",name);
	}

	public static String getOperatorNameFromFeedbackContainer(WebElement feedback)
	{
		return CommonUtil.getElement(feedback,By.id("userimage")).getAttribute("usrname");
	}
}
