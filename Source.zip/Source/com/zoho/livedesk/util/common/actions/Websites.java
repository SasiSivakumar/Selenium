//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.bots.BotsVisitorSide;

public class Websites
{
    public static String floatThemeName[] = {null,"Coin",null,"Unicorn","Dream","Twinkle","Dollar","Topaz","Link","Sassy","Noel","Bagel"};
    public static String buttonThemeName[] = {null,"Cord","Blue ivy","Zen","Atom","Coffee","Paradise","Meme","Leo","Ruby","Cookie","Fancy","Cent","Poppy","Apollo"};
    public static String personalizedThemeName[] = {null,"Phoenix","Snow","Fame"};
    public static String sizeName[] = {null,"Medium","Small","Large"};
    public static String sizeValue[] = {null,"height: 153px;","height: 183px;","height: 213px;"};
    public static String chatWindowThemeName[] = {null,null,null,null,"Lloyd",null,null,null,"Pattern","Pattern - Straight","Pattern - Curve"};
    
	public static String getCode(String s)
	{
		String code = s.split("widgetcode:\"")[1];
		
		code = code.split("\"")[0];
		
		return code;
	}

	public static Boolean getStatusOfToggle(WebElement e) throws Exception
	{
		return getStatusOfToggle(null,e);
	}

	public static Boolean getStatusOfToggle(WebDriver driver, WebElement e) throws Exception
	{
        CommonUtil.inViewPort(e);
        
		String classname = e.getAttribute("class");

		if(classname.contains("togglebtn") && classname.contains("set_off"))
		{
			return false;
		}
		else if(classname.contains("togglebtn") && classname.contains("set_on"))
		{
			return true;
		}
		else
		{
			return null;
		}
	}

	public static void setStatusOfToggle(WebDriver driver, String id, Boolean status, ExtentTest etest) throws Exception
	{
		WebElement e = CommonUtil.elfinder(driver,"id",id);
		
        setStatusOfToggle(driver,e,status,etest);
	}

	public static void setStatusOfToggle(WebDriver driver, final WebElement e, final Boolean status, ExtentTest etest) throws Exception
	{
		Boolean current = getStatusOfToggle(driver,e);

		String id = e.getAttribute("id");
		String usecase = status?"enabled":"disabled";

		if(current == status)
		{
			etest.log(Status.INFO,id+" is "+usecase);

			return;
		}
		else
		{
			try
			{
				CommonUtil.inViewPort(e);
			}
			catch(Exception exp)
			{
				exp.printStackTrace();
			}

			e.click();

			FluentWait wait = CommonUtil.waitreturner(driver,4,250);

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	            	try
	            	{
		                if(getStatusOfToggle(driver,e) == status)
		                {
		                    return true;
		                }
		            }
		            catch(Exception e){}
	                return false;
	            }
	        });

	        etest.log(Status.INFO,id+" is "+usecase);
		}
	}

	public static String divHeader(WebDriver driver, String path) throws Exception
	{
		WebElement e = CommonUtil.elfinder(driver,"xpath","//div[@prop_id='"+path+"']");

		CommonUtil.inViewPort(e);

		return CommonUtil.elementfinder(driver,e,"tagname","em").getText();
	}

	public static String divDesc(WebDriver driver, String path) throws Exception
	{
		WebElement e = CommonUtil.elfinder(driver,"xpath","//div[@prop_id='"+path+"']");

		CommonUtil.inViewPort(e);

		return CommonUtil.elementfinder(driver,e,"classname","clr_888").getText();
	}

	public static void clickShowAll(WebDriver driver, Boolean show, ExtentTest etest) throws Exception
	{
		//this method is disabled currently as the show all button which will appear in websites menu is removed from the product.
		if(true)
		return;

		final String propExpected = show?"hide":"show";

		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("show_tgl")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("show_tgl")));

		final WebElement e = CommonUtil.elfinder(driver,"classname","show_tgl");

		CommonUtil.inViewPort(e);

		String prop = e.getAttribute("prop");

		if(prop.equals(propExpected))
		{
			return;
		}

		e.click();

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(e.getAttribute("prop").equals(propExpected))
            	{
            		return true;
            	}
                return false;
            }
        });

        if(show)
        {
        	etest.log(Status.INFO,"Show all is clicked");
        }
        else
        {
        	etest.log(Status.INFO,"Show less is clicked");
        }
	}

	public static void clickShowAll(WebDriver driver, ExtentTest etest) throws Exception
	{
		clickShowAll(driver,true,etest);
	}

	public static void clickShowLess(WebDriver driver, ExtentTest etest) throws Exception
	{
		clickShowAll(driver,false,etest);
	}

	public static void clickSave(WebDriver driver, ExtentTest etest) throws Exception
	{
		clickSave(driver, etest, false);
	}

	public static void clickSave(WebDriver driver, ExtentTest etest, Boolean presence) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		final WebElement e = WebsitesTab.getMiddleNav(driver);

		if(!presence)
		{
			if(!e.getAttribute("innerHTML").contains("save_emconfig"))
        	{
        		etest.log(Status.INFO,"Save button is not shown. Changes may not be saved.");

        		return;
        	}
		}

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(e.getAttribute("innerHTML").contains("save_emconfig"))
            	{
            		return true;
            	}
                return false;
            }
        });
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("save_emconfig")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("save_emconfig")));

		final WebElement div = CommonUtil.elfinder(driver,"id","save_emconfig");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(div.getAttribute("style").contains("bottom: 0px;"))
            	{
            		return true;
            	}
                return false;
            }
        });

        WebElement update = CommonUtil.elementfinder(driver,div,"tagname","span");
        
        String updateContent = update.getText();
        
        update.click();
        
        if(updateContent.equals("Update in my website"))
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            
            CommonUtil.elfinder(driver,"id","okbtn").click();
        }

        Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
        
        Thread.sleep(1000);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(!e.getAttribute("innerHTML").contains("save_emconfig"))
            	{
            		return true;
            	}
                return false;
            }
        });

        etest.log(Status.INFO,"Save is clicked");
	}

	public static String getValueFromDropdown(WebDriver driver, String id) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));

		WebElement e = CommonUtil.elfinder(driver,"id",id);

		CommonUtil.inViewPort(e);

		wait.until(ExpectedConditions.visibilityOf(e));

		WebElement e1 = CommonUtil.elementfinder(driver,e,"id",id+"_div");

		return e1.getText();
	}

	public static void selectFromDropdown(WebDriver driver, String id, String value, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		if(getValueFromDropdown(driver,id).equals(value))
		{
            etest.log(Status.INFO,"Value - "+value+" is already selected for div - "+id);
			return;
		}

		WebElement e = CommonUtil.elfinder(driver,"id",id);

		WebElement e1 = CommonUtil.elementfinder(driver,e,"id",id+"_div");

		CommonUtil.elementfinder(driver,e1,"tagname","span").click();

		final WebElement e2 = CommonUtil.elementfinder(driver,e,"id",id+"_ddown");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(e2.getAttribute("style").contains("block"))
            	{
            		return true;
            	}
                return false;
            }
        });

		List<WebElement> list = CommonUtil.elementfinder(driver,e2,"tagname","ul").findElements(By.tagName("li"));

		for(WebElement v : list)
		{
			CommonUtil.inViewPort(v);
			if(v.getText().equals(value))
			{
				v.click();
				break;
			}
		}

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(e2.getAttribute("style").contains("none"))
            	{
            		return true;
            	}
                return false;
            }
        });

        etest.log(Status.INFO,"Value - "+value+" is selected for div - "+id);
	}

	public static void editResponseMessages(WebDriver driver, String div, String value, ExtentTest etest) throws Exception
	{
		try
		{
			WebElement textarea = responseMessagesTextArea(driver,div);

	        for(int attempt = 0; attempt < 3; attempt++)
	        {
	        	CommonUtil.sendKeysToWebElement(driver,textarea,value);

	        	CommonUtil.waitTillWebElementContainsAttributeValue(textarea,"value",value);

		        if(textarea.getAttribute("value").contains(value))
		        {
		        	break;
		        }
		    }

	        etest.log(Status.INFO,"Value - "+value+" is entered in "+div);

	        TakeScreenshot.infoScreenshot(driver,etest);

	        for(int attempt = 0; attempt < 3; attempt++)
	        {
	        	try
	            {
	            	CommonUtil.clickWebElement(driver,textarea);
	    
	            	CommonUtil.clickWebElement(driver,CommonUtil.getElement(responseMessagesDiv(driver,div),By.className("hdrtxt")));
	    
	            	CommonWait.waitTillHidden(textarea);
	    
	            	break;
	            }
	            catch(Exception e)
	            {
	            	if(attempt == 2)
	            	{
	            		e.printStackTrace();
	            	}
	            }
	        }

	        TakeScreenshot.infoScreenshot(driver,etest);
	        
	        checkChatWinAppearance1(driver,div,value);

	        WebElement e = responseMessagesDiv(driver,div);

	        CommonUtil.elementfinder(driver,e,"classname","hdrtxt").click();

	        for(int attempt = 0; attempt < 3; attempt++)
	        {
	        	try
		        {
		        	CommonUtil.clickWebElement(driver,CommonUtil.getElement(responseMessagesDiv(driver,div),By.className("hdrtxt")));

		        	final WebElement f = CommonUtil.elementfinder(driver,e,"classname","msgconf_box");

		        	FluentWait wait = CommonUtil.waitreturner(driver,20,250);
		        
					wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	if(f.getAttribute("style").equals("display: none;"))
		            	{
		            		return true;
		            	}
		                return false;
		            }
		        	});
				}
				catch(Exception excep)
				{
					if(attempt == 2)
					{
						excep.printStackTrace();
					}
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public static String getValueFromResponseMessages(WebDriver driver, String div) throws Exception
	{
		WebElement textarea = responseMessagesTextArea(driver,div);

        return textarea.getAttribute("value");
	}

	public static WebElement responseMessagesDiv(WebDriver driver, final String div) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		final WebElement w = WebsitesTab.getMiddleNav(driver);

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(w.getAttribute("innerHTML").contains(div))
            	{
            		return true;
            	}
                return false;
            }
        });
        
       	List<WebElement> list = w.findElements(By.id("msgconfmain"));

		for(WebElement e : list)
		{
			// CommonUtil.inViewPort(e);

			if(e.getAttribute("innerHTML").contains(div))
			{
				CommonUtil.inViewPort(e);

				return e;
			}
		}

		return null;
	}

	public static WebElement responseMessagesTextArea(WebDriver driver, final String div) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		WebElement element = responseMessagesDiv(driver,div);

		CommonUtil.clickWebElement(driver,CommonUtil.getElement(element,By.className("hdrtxt")));
		
		WebElement edit = CommonUtil.elementfinder(driver,element,"tagname","em");

		CommonUtil.inViewPort(edit);

		CommonUtil.clickWebElement(driver,edit);

		final WebElement f = CommonUtil.elementfinder(driver,element,"classname","msgconf_box");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(f.getAttribute("style").equals("display: block;"))
            	{
            		return true;
            	}
                return false;
            }
        });

        WebElement textarea = CommonUtil.elementfinder(driver,f,"tagname","textarea");

        wait.until(ExpectedConditions.visibilityOf(textarea));

        return textarea;
	}

	public static void editRatingMessages(WebDriver driver, String div, String value, ExtentTest etest) throws Exception
	{
		try
		{
			WebElement textarea = ratingMessagesTextArea(driver,div);

			for(int attempt = 0; attempt < 3; attempt++)
	        {
	        	CommonUtil.sendKeysToWebElement(driver,textarea,value);

	        	CommonUtil.waitTillWebElementContainsAttributeValue(textarea,"value",value);

	        	if(textarea.getAttribute("value").contains(value))
		        {
		        	break;
		        }
		    }
	        
	        etest.log(Status.INFO,"Value - "+value+" is entered in "+div);

	        TakeScreenshot.infoScreenshot(driver,etest);

	        for(int attempt = 0; attempt < 3; attempt++)
	        {
	        	try
	            {
	            	CommonUtil.clickWebElement(driver,textarea);
	    
	            	CommonUtil.clickWebElement(driver,CommonUtil.getElement(ratingMessagesDiv(driver,div),By.tagName("span")));
	    
	            	break;
	            }
	            catch(Exception e)
	            {
	            	if(attempt == 2)
	            	{
	            		e.printStackTrace();
	            	}
	            }
	        }

	        TakeScreenshot.infoScreenshot(driver,etest);
	        
	        checkChatWinAppearance2(driver,div,value);
	        
	        WebElement div2 = ratingMessagesDiv(driver,div);
	        
	        CommonUtil.elementfinder(driver,div2,"tagname","span").click();

	        CommonUtil.clickWebElement(driver,By.cssSelector("div.emfd_hdr.flotlft100.mT30"));
	    }
	    catch (Exception e) 
	    {
	    	e.printStackTrace();
	    }
	}

	public static String getValueFromRatingMessages(WebDriver driver, String div) throws Exception
	{
		WebElement textarea = ratingMessagesTextArea(driver,div);

        return textarea.getAttribute("value");
	}

	public static WebElement ratingMessagesDiv(WebDriver driver, final String div) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		final WebElement w = WebsitesTab.getMiddleNav(driver);

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(w.getAttribute("innerHTML").contains(div))
            	{
            		return true;
            	}
                return false;
            }
        });
        
       	List<WebElement> list = w.findElements(By.cssSelector("div.pTB20.bB1.flotlft100"));

		for(WebElement e : list)
		{
			// CommonUtil.inViewPort(e);

			if(e.getAttribute("innerHTML").contains(div))
			{
				CommonUtil.inViewPort(e);

				return e;
			}
		}

		return null;
	}

	public static WebElement ratingMessagesTextArea(WebDriver driver, final String div) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		WebElement element = ratingMessagesDiv(driver,div);
		
		WebElement textarea = CommonUtil.elementfinder(driver,element,"tagname","input");
        
        CommonUtil.inViewPort(textarea);

		wait.until(ExpectedConditions.visibilityOf(textarea));

        return textarea;
	}

	public static void clickPostChatFields(WebDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		WebElement header = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","big-hdrtxt");

		CommonUtil.inViewPort(header);

        WebElement e = CommonUtil.elfinder(driver,"xpath","//em[@prop='postchat']");

		wait.until(ExpectedConditions.visibilityOf(e));

		e.click();

		wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","postchat")));

		etest.log(Status.INFO,"Post-chat is clicked");
	}

	public static void clickOfflineResponse(WebDriver driver, ExtentTest etest) throws Exception
	{
		driver.switchTo().defaultContent();
		driver.switchTo().defaultContent();
		
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//em[@prop='offline']")));

		WebElement header = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","big-hdrtxt");

		CommonUtil.inViewPort(header);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//em[@prop='offline']")));

		CommonUtil.elfinder(driver,"xpath","//em[@prop='offline']").click();

		wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","offline-message")));

		etest.log(Status.INFO,"Offline messages is clicked");
	}

	public static WebElement getFieldEditButton(WebDriver driver, String id) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//em[@prop='"+id+"']")));

		WebElement e = CommonUtil.elfinder(driver,"xpath","//em[@prop='"+id+"']");
		
		CommonUtil.inViewPort(e);

		CommonUtil.mouseHover(driver,e);

		wait.until(ExpectedConditions.visibilityOf(e));

		return e;
	}

	public static Boolean getStatusFieldEditButton(WebElement e)
	{
		if(e.getAttribute("field").contains("disable"))
		{
			return true;
		}
		else if(e.getAttribute("field").contains("enable"))
		{
			return false;
		}

		return null;
	}

	public static void changeStatusFieldEditButton(WebDriver driver, String id, final Boolean add, ExtentTest etest) throws Exception
	{
		final WebElement e = getFieldEditButton(driver,id);

		String usecase = add?"added":"removed";

		if(getStatusFieldEditButton(e) == add)
		{
			etest.log(Status.INFO,"Field "+id+" is already "+usecase);
			return;
		}

		e.click();

		FluentWait wait = CommonUtil.waitreturner(driver,3,250);

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(getStatusFieldEditButton(e) == add)
				{
					return true;
				}
                return false;
            }
        });

        etest.log(Status.INFO,"Field "+id+" is "+usecase);
	}

	public static WebElement getMandatoryCheckbox(WebDriver driver, String id) throws Exception
	{
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		final WebElement div = getInputArea(driver,id);

		CommonUtil.mouseHover(driver,div);

		WebElement e = CommonUtil.elementfinder(driver,div,"tagname","em");
		
		wait.until(ExpectedConditions.visibilityOf(e));

		return e;
	}

	public static Boolean getStatusMandatoryAlert(WebDriver driver, String id) throws Exception
	{
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        WebElement e = CommonUtil.elfinder(driver,"id",id);
        
        if(e.getAttribute("data-validate").contains("required"))
		{
            driver.switchTo().defaultContent();
			return true;
		}
		else
		{
            driver.switchTo().defaultContent();
			return false;
		}
    }

	public static WebElement getInputArea(WebDriver driver, String id) throws Exception
	{
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));

		List<WebElement> list = driver.findElements(By.tagName("div"));

		for(WebElement e : list)
		{
			if(e.getAttribute("custom") != null && e.getAttribute("custom").equals(id))
			{
				return e;
			}
		}

		return null;
	}

	public static void changeStatusMandatoryCheckbox(WebDriver driver, final String id, final Boolean add, ExtentTest etest) throws Exception
	{
		WebsitesTab.clickChatWindAppearance(driver);

        String usecase = add?"added":"removed";
        
        if(getStatusMandatoryAlert(driver,"vis"+id) == add)
        {
            etest.log(Status.INFO,"Mandatory for "+id+" is already "+usecase);
            return;
        }
        
        final WebElement e = getMandatoryCheckbox(driver,id);

		e.click();

		FluentWait wait = CommonUtil.waitreturner(driver,3,500);

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
                {
                    if(getStatusMandatoryAlert(driver,"vis"+id) == add)
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });

        etest.log(Status.INFO,"Mandatory for "+id+" is "+usecase);
	}

	public static void selectPosition(WebDriver driver, String side, String position, ExtentTest etest) throws Exception
	{
		selectPosition(driver, side+"_"+position,etest);
	}

	public static void selectPosition(WebDriver driver, String position, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		WebElement e = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","widgetposition");

		CommonUtil.inViewPort(e);

		wait.until(ExpectedConditions.visibilityOf(e));

		final WebElement pos = CommonUtil.elementfinder(driver,e,"xpath",".//em[@align='"+position+"']");

		CommonUtil.inViewPort(pos);

		pos.click();
        
        etest.log(Status.INFO,position+" is clicked");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(pos.getAttribute("class") != null && pos.getAttribute("class").contains("sel"))
				{
					return true;
				}
                return false;
            }
        });
	}

	public static String getSelectedPosition(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		WebElement e = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","widgetposition");

		CommonUtil.inViewPort(e);

		List<WebElement> list = e.findElements(By.tagName("em"));

		for(WebElement f : list)
		{
			if(f.getAttribute("class") != null && f.getAttribute("class").contains("sel"))
			{
				return f.getAttribute("align");
			}
		}

		return "not found";
	}

	public static void changeStatusForEmbed(WebDriver driver, String div, final Boolean enable, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,20,250);

		final WebElement e = CommonUtil.elfinder(driver,"xpath","//div[@boxname='"+div+"']");

		final WebElement eye = CommonUtil.elementfinder(driver,e,"xpath",".//span[@documentclick='toggleEmbedStatus']");

        final String classname = enable?"enable":"disable";

		if(e.getAttribute("status").equals(classname))
		{
            etest.log(Status.INFO,div+" is already "+classname+"d");
			return;
		}

		eye.click();
        
        etest.log(Status.INFO,div+" - "+classname+"is clicked");

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	if(e.getAttribute("status").equals(classname))
				{
					return true;
				}
                return false;
            }
        });
	}
    
    public static void checkChatWinAppearance1(WebDriver driver, String div, final String value) throws Exception
    {
        driver.switchTo().defaultContent();

        WebElement textarea = responseMessagesTextArea(driver,div);

        CommonUtil.clickWebElement(driver,textarea);
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        final WebElement section = CommonUtil.getElement(driver,By.tagName("body"));
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        if(div.equals("Greeting Messages"))
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(section.getAttribute("innerHTML").contains("msgdiv"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            final WebElement grt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,section,"id","msgdiv"),"classname","agntmsg"),"classname","msgbx");
            
            wait.until(ExpectedConditions.visibilityOf(grt));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(grt.getText().equals(value))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        else if(div.equals("Waiting Message"))
        {
//            wait.until(new Function<WebDriver,Boolean>(){
//                public Boolean apply(WebDriver driver)
//                {
//                    if(section.getAttribute("innerHTML").contains("info_banr") && section.getAttribute("innerHTML").contains("timer"))
//                    {
//                        return true;
//                    }
//                    return false;
//                }
//            });
//            
//            final WebElement info = CommonUtil.elementfinder(driver,section,"classname","info_banr");
//
//            wait.until(ExpectedConditions.visibilityOf(info));
//            
//            wait.until(new Function<WebDriver,Boolean>(){
//                public Boolean apply(WebDriver driver)
//                {
//                    if(info.getText().equals(value+"00:53s") && info.getAttribute("class").contains("timer"))
//                    {
//                        return true;
//                    }
//                    return false;
//                }
//            });
//            
//            System.out.println(info.getText());
        }
        else if(div.equals("Feedback Message"))
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(section.getAttribute("innerHTML").contains("info_banr") && section.getAttribute("innerHTML").contains("sqico-star"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            final WebElement info = CommonUtil.elementfinder(driver,section,"classname","info_banr");
            
            wait.until(ExpectedConditions.visibilityOf(info));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(info.getText().equals(value))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            List<WebElement> list = section.findElements(By.className("sqico-star"));

            for(WebElement st : list)
            {
                wait.until(ExpectedConditions.visibilityOf(st));
            }
            
            wait.until(ExpectedConditions.visibilityOf(list.get(4)));
        }
        else
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(section.getAttribute("innerHTML").contains("info_banr"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            final WebElement info = CommonUtil.elementfinder(driver,section,"classname","info_banr");
            
            wait.until(ExpectedConditions.visibilityOf(info));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(info.getText().equals(value))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        
        driver.switchTo().defaultContent();
    }
    
    public static void checkChatWinAppearance2(WebDriver driver, String star, final String value) throws Exception
    {
        driver.switchTo().defaultContent();

        WebElement textarea = ratingMessagesTextArea(driver,star);

        CommonUtil.clickWebElement(driver,textarea);
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        final WebElement section = CommonUtil.elfinder(driver,"tagname","section");
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        Integer i = null;
        
        if(star.contains("1")){i=5;}
        else if(star.contains("2")){i=4;}
        else if(star.contains("3")){i=3;}
        else if(star.contains("4")){i=2;}
        else if(star.contains("5")){i=1;}
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(section.getAttribute("innerHTML").contains("info_banr") && section.getAttribute("innerHTML").contains("sqico-star"))
                {
                    return true;
                }
                return false;
            }
        });
        
        final WebElement fdb = CommonUtil.elementfinder(driver,section,"id","info_banr");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(fdb.getText().equals(value))
                {
                    return true;
                }
                return false;
            }
        });
        
//        List<WebElement> list = section.findElements(By.className("sqico-star"));
//        
//        Integer selected = null;
//        int j = 1;
//        
//        for(WebElement e : list)
//        {
//            if(e.getAttribute("class").contains("sel"))
//            {
//                selected = j;
//            }
//            
//            j++;
//        }
//        
//        if(i != selected)
//        {
//            "".replace(null,"to break the flow");
//        }
        
        driver.switchTo().defaultContent();
    }
    
    public static void checkChatWinAppearancePostChat(WebDriver driver, Boolean content, Boolean star) throws Exception
    {
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        final WebElement div = CommonUtil.elfinder(driver,"tagname","section");
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        if(star)
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("innerHTML").contains("sqico-star"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            List<WebElement> list = div.findElements(By.className("sqico-star"));
            
            for(int i = 0; i<5;i++)
            {
                wait.until(ExpectedConditions.visibilityOf(list.get(i)));
            }
        }
        else
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("innerHTML").contains("sqico-star"))
                    {
                        return false;
                    }
                    return true;
                }
            });
        }
        
        if(star==false && content==true)
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("innerHTML").contains("fdbkarea"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement textarea = CommonUtil.elfinder(driver,"id","fdbkarea");
            
            wait.until(ExpectedConditions.visibilityOf(textarea));
        }
                
        driver.switchTo().defaultContent();
    }
    
    public static void checkChatWinAppearanceColour(WebDriver driver, final String colour) throws Exception
    {
    	VisitorWindow.switchToChatWidget(driver);
        
        final WebElement section = CommonUtil.elfinder(driver,"id","zsiq_customcss");
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                String style = section.getAttribute("innerHTML").toLowerCase();
                String color_lowercase=colour.toLowerCase();
                

                if(style.contains(color_lowercase))
                {
                    return true;
                }
                return false;
            }
        });
        
        driver.switchTo().defaultContent();
    }
    
    public static void checkChatWinAppearanceDept(WebDriver driver, Boolean presence) throws Exception
    {
        driver.switchTo().defaultContent();
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        final WebElement body = CommonUtil.elfinder(driver,"tagname","body");
        
        if(presence)
        {
            WebElement e = CommonUtil.elementfinder(driver,body,"id","sqico-drpdwn");
            
            wait.until(ExpectedConditions.visibilityOf(e));
        }
        else
        {
        	try
        	{
        		if(CommonWait.waitTillDisplayed(driver,By.id("sqico-drpdwn")))
        		{
        			throw new ZohoSalesIQRuntimeException("Department dropdown was found");
        		}
        	}
        	catch(Exception e)
        	{
        		CommonUtil.doNothing();
        	}
            // wait.until(new Function<WebDriver,Boolean>(){
            //     public Boolean apply(WebDriver driver)
            //     {
            //         if(body.getAttribute("innerHTML").contains("sqico-drpdwn"))
            //         {
            //             return false;
            //         }
            //         return true;
            //     }
            // });
        }
        
        driver.switchTo().defaultContent();
    }
    
    public static void clickChatWidgetDefaultColour(WebDriver driver, final Boolean enable, ExtentTest etest) throws Exception
    {
        String status = getChatWidgetDefaultColourStatus(driver);
        
        String usecase = enable?"selected":"not selected";
        
        if((status != null && status.equals("true")) == enable)
        {
            etest.log(Status.INFO,"Chat widget - Default colour is already "+usecase);
            return;
        }
        
        WebElement nav = WebsitesTab.getMiddleNav(driver);
        
        final WebElement checkBox = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,nav,"id","usesamecolor"),"tagname","em");
        
        checkBox.click();
        
        etest.log(Status.INFO,"Chat widget - Default colour is "+usecase);
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    String status = getChatWidgetDefaultColourStatus(driver);
                    
                    if((status != null && status.equals("true")) == enable)
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                
                return false;
            }
        });
    }
    
    public static String getChatWidgetDefaultColourStatus(WebDriver driver) throws Exception
    {
        WebElement nav = WebsitesTab.getMiddleNav(driver);
        
        final WebElement checkBox = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,nav,"id","usesamecolor"),"tagname","em");
        
        String status = checkBox.getAttribute("ischecked");
        
        return status;
    }
    
    public static void clickChatWidgetColour(WebDriver driver, final String colour, ExtentTest etest) throws Exception
    {
        WebElement colourDiv2 = null;
        
        WebElement nav = WebsitesTab.getMiddleNav(driver);
        
        WebElement colours = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,nav,"id","embedcolorfield"),"classname","float-clr-pic");
        
        List<WebElement> list = colours.findElements(By.tagName("span"));
        
        for(WebElement e : list)
        {
            if(e.getAttribute("color").equals(colour))
            {
                colourDiv2 = e;
                break;
            }
        }
        
        final WebElement colourDiv = colourDiv2;
        colourDiv.click();
        
        etest.log(Status.INFO,"Chat widget - Colour "+colour+" is selected");
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(colourDiv.getAttribute("class").contains("sel"))
                {
                    return true;
                }
                
                return false;
            }
        });
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    String status = getChatWidgetColour(driver);
                    
                    if(status.equals(colour))
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                
                return false;
            }
        });
    }
    
    public static String getChatWidgetColour(WebDriver driver) throws Exception
    {
        WebElement nav = WebsitesTab.getMiddleNav(driver);
        
        WebElement colours = CommonUtil.elementfinder(driver,nav,"id","embedcolorfield");
        
        List<WebElement> list = colours.findElements(By.tagName("em"));
        
        WebElement e = list.get(1);
        
        if(!e.isDisplayed())
        {
            CommonUtil.inViewPort(list.get(1));
        }
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        wait.until(ExpectedConditions.visibilityOf(e));
        
        return list.get(1).getText();
    }
    
    public static void customizeMessageStatus(WebDriver driver, Boolean online, ExtentTest etest) throws Exception
    {
        WebElement e = WebsitesTab.getMiddleNav(driver);
        
        List<WebElement> list = e.findElements(By.xpath(".//em[@documentclick='toggleMessageConfig']"));
        
        String prop = online?"online":"offline";
        String id = online?"online-message":"offline-message";
        
        for(WebElement v : list)
        {
            if(v.getAttribute("prop").equals(prop))
            {
                v.click();
            }
        }
        
        etest.log(Status.INFO,prop+" is clicked");
        
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
    }
    
    public static void editCustomizeMessageInWidgetTab(WebDriver driver, Boolean online, String field, String value, ExtentTest etest) throws Exception
    {
    	for(int editTry = 0; editTry < 3; editTry++)
    	{
	        customizeMessageStatus(driver,online,etest);
	        
	        WebElement div = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"xpath",".//div[@field='"+field+"']");
	        CommonWait.waitTillDisplayed(div);

	        CommonUtil.mouseHover(driver,CommonUtil.getElement(div,By.cssSelector("[documentclick='floatMessageToggle']")));
	        
	        WebElement edit = CommonUtil.elementfinder(driver,div,"classname","sqico-edit");
	        final WebElement input = CommonUtil.elementfinder(driver,div,"tagname","input");
	        
	        FluentWait wait = CommonUtil.waitreturner(driver,3,500);
		
			CommonWait.waitTillDisplayed(edit);      
	        
	        edit.click();
	        
	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                String s = input.getAttribute("style");
	                if(!s.contains("none"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });
	        
	        ((JavascriptExecutor)driver).executeScript("arguments[0].value = \""+value+"\"",input);

	        CommonUtil.clickWebElement(driver,input);

	        TakeScreenshot.infoScreenshot(driver,etest);
	        
	        CommonUtil.elementfinder(driver,div,"tagname","span").click();

	        if(input.getAttribute("value").contains(value))
	        {
	        	etest.log(Status.INFO,value+" is entered"+" in "+field);
				wait.until(new Function<WebDriver,Boolean>(){
				public Boolean apply(WebDriver driver)
				{
					String s = input.getAttribute("style");
					if(s.contains("none"))
					{
					    return true;
					}
					return false;
					}
				});
				break;
	        }
	        else
	        {
	        	continue;
	        }
	    }
    }
    
    public static String getCustomizeMessageInWidgetTab(WebDriver driver, Boolean online, String field, ExtentTest etest) throws Exception
    {
        customizeMessageStatus(driver,online,etest);
        
        WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"xpath",".//div[@field='"+field+"']"),"classname","txtelips");
        
        return div.getAttribute("innerText");
    }
    
    public static void getCustomizeMessageInPreviewFloat(WebDriver driver, Boolean field1, final String value) throws Exception
    {
        try
        {
            final String field = field1?"zsiq_maintitle":"zsiq_byline";
            
            WebElement div = CommonUtil.elementfinder(driver,WebsitesTab.getRightNav(driver),"id","previewdiv");
            
            WebElement frame = CommonUtil.elementfinder(driver,div,"id","previewframe");
            
            driver.switchTo().frame(frame);
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        String content = CommonUtil.elfinder(driver,"id",field).getText();
                        
                        if(content.equals(value))
                        {
                            return true;
                        }
                    }
                    catch(Exception e){}
                    
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
        
        driver.switchTo().defaultContent();
    }
    
    public static void getCustomizeMessageInPreviewButton(WebDriver driver, Boolean field1, final String value) throws Exception
    {
        String content = null;
        try
        {
            final String field = field1?"span":"em";
            
            WebElement div = CommonUtil.elementfinder(driver,WebsitesTab.getRightNav(driver),"id","previewdiv");
            
            WebElement frame = CommonUtil.elementfinder(driver,div,"id","previewframe");
            
            driver.switchTo().frame(frame);
            
            final WebElement con = CommonUtil.elfinder(driver,"id","siqbtndiv");
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        String content = CommonUtil.elementfinder(driver,con,"tagname",field).getText();
                        
                        if(content.equals(value))
                        {
                            return true;
                        }
                    }
                    catch(Exception e){}
                    
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
        
        driver.switchTo().defaultContent();
    }
    
   	public static void selectTheme(WebDriver driver, final WebElement div, String themeId, ExtentTest etest) throws Exception
   	{

    	FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(ExpectedConditions.visibilityOf(div));

    	List<WebElement> themes=div.findElements(By.className("sml_emtm"));

    	int current_theme_id=Integer.parseInt(CommonUtil.getElementByAttributeValue(themes,"class","sml_emtm sel").getAttribute("themeid"));

    	boolean isClickRightArrow=true;

    	if(current_theme_id<Integer.parseInt(themeId))
    	{
    		isClickRightArrow=false;
    	}

    	for(int i=0;i<themes.size();i++)
    	{
    		if(current_theme_id==Integer.parseInt(themeId))
    		{
    			return;
    		}
    		else
    		{
	            WebsitesTab.clickArrowInTheme(driver,div,isClickRightArrow);
    	    	current_theme_id=Integer.parseInt(CommonUtil.getElementByAttributeValue(themes,"class","sml_emtm sel").getAttribute("themeid"));
    		}
    	}
    }

    public static void selectEmbedSize(WebDriver driver,String size,ExtentTest etest) throws Exception
    {

        WebElement embedSizeDiv = CommonUtil.getElement(driver,By.id("embedsizetoggle"));
        
        CommonUtil.inViewPort(embedSizeDiv);

    	List<WebElement> embedSize = embedSizeDiv.findElements(By.className("sml_emprv"));

    	List<WebElement> embedSizeDivElements = embedSizeDiv.findElements(By.className("em_sizemain"));

    	CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(embedSize,"size",size));

    	CommonUtil.waitTillWebElementContainsAttributeValue(embedSizeDivElements.get(Integer.parseInt(size)-2),"class","sel");

    	if(CommonUtil.getElementByAttributeValue(embedSizeDivElements,"class","sdk_prvico em_sizemain sel").getText().contains(sizeName[Integer.parseInt(size)]))
    	{
    		etest.log(Status.INFO,"Embed size --<b>"+sizeName[Integer.parseInt(size)]+"</b> was selected");
    	}
    }
    
    public static Boolean checkNewsletter(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        final WebElement div = CommonUtil.elfinder(driver,"id","prechat");
        
        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("innerHTML").contains("campaign"))
                    {
                        return true;
                    }
                    
                    return false;
                }
            });
            
            final WebElement e = CommonUtil.elementfinder(driver,div,"xpath",".//div[@field='campaign']");
            
            CommonUtil.inViewPort(e);
            
            wait.until(ExpectedConditions.visibilityOf(e));
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }
    
    public static void clickAddInNewsLetter(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        final WebElement div = CommonUtil.elfinder(driver,"id","prechat");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getAttribute("innerHTML").contains("campaign"))
                {
                    return true;
                }
                
                return false;
            }
        });
        
        final WebElement e = CommonUtil.elementfinder(driver,div,"xpath",".//div[@field='campaign']");
        
        CommonUtil.inViewPort(e);
        
        wait.until(ExpectedConditions.visibilityOf(e));
        
        WebElement add = CommonUtil.elementfinder(driver,e,"tagname","em");
        
        if(!getStatusFieldEditButton(add))
        {
        	CommonUtil.mouseHover(driver,add);
        	CommonWait.waitTillDisplayed(add);
            add.click();
            
            wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","popupdiv")));
            
            etest.log(Status.INFO,"Add is clicked in Newsletter");
        }
        else
        {
            etest.log(Status.INFO,"Add is already set in Newsletter");
        }
    }
    
    public static void clickRemoveInNewsLetter(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        final WebElement div = CommonUtil.elfinder(driver,"id","prechat");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getAttribute("innerHTML").contains("campaign"))
                {
                    return true;
                }
                
                return false;
            }
        });
        
        final WebElement e = CommonUtil.elementfinder(driver,div,"xpath",".//div[@field='campaign']");
        
        CommonUtil.inViewPort(e);
        
        wait.until(ExpectedConditions.visibilityOf(e));
        
        WebElement add = CommonUtil.elementfinder(driver,e,"tagname","em");
        
        if(getStatusFieldEditButton(add))
        {
        	CommonUtil.mouseHover(driver,add);
        	CommonWait.waitTillDisplayed(add);
            add.click();
            
            etest.log(Status.INFO,"Remove is clicked in Newsletter");
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
        }
        else
        {
            etest.log(Status.INFO,"Remove is already set in Newsletter");
        }
    }
    
    public static void editNewsLetter(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,3,250);
        
        final WebElement div = CommonUtil.elfinder(driver,"id","prechat");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(div.getAttribute("innerHTML").contains("campaign"))
                {
                    return true;
                }
                
                return false;
            }
        });
        
        final WebElement e = CommonUtil.elementfinder(driver,div,"xpath",".//div[@field='campaign']");
        
        WebElement add = CommonUtil.elementfinder(driver,e,"tagname","em");

        if(add.getAttribute("field").equals("disable"))//already enabled, so disable and enable again
        {
        	etest.log(Status.INFO,"Newletter was already enabled. So disabling and enabling again");
		    CommonUtil.inViewPort(add);     
			CommonUtil.mouseHover(driver,add);
			CommonWait.waitTillDisplayed(add);
        	add.click();
        	CommonUtil.waitTillWebElementContainsAttributeValue(add,"field","enable");
        	etest.log(Status.INFO,"Newletter was enable button was clicked.");
        	add=CommonUtil.getElement(e,By.tagName("em"));
        }

        CommonUtil.inViewPort(add);     
    	CommonUtil.mouseHover(driver,add);
    	CommonWait.waitTillDisplayed(add);
    	add.click();
    			      
        etest.log(Status.INFO,"enable button is clicked in Newsletter");
        
        wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","popupdiv")));
    }

    public static Boolean getGDPRSettingsForWebsite(WebDriver driver,ExtentTest etest,String embed) throws Exception
    {
	    Tab.navToEmbedTab(driver);    
        WebEmbed.clickWebEmbed(driver,embed,etest);
        WebsitesTab.clickLiveChat(driver,etest);
        WebsitesTab.clickInstallationInLiveChat(driver,etest);
        WebElement toggle=CommonUtil.getElement(driver,GDPR.GDPR_TOGGLE_WEBSITES);

        if(toggle==null)
        {
        	return null;
        }

        boolean toggle_status=getStatusOfToggle(toggle);

		WebsitesTab.closeEmbedConfig(driver,etest);

        return toggle_status;
    }

    public static void setGDPRSettingsForWebsite(WebDriver driver,ExtentTest etest,String embed,boolean isEnable) throws Exception
    {
	    Tab.navToEmbedTab(driver);    
        WebEmbed.clickWebEmbed(driver,embed,etest);
        WebsitesTab.clickLiveChat(driver,etest);
        WebsitesTab.clickInstallationInLiveChat(driver,etest);
        WebElement toggle=CommonUtil.getElement(driver,GDPR.GDPR_TOGGLE_WEBSITES);

        if(toggle==null)
        {
        	throw new ZohoSalesIQRuntimeException("GDPR toggle was not found settings of embed :"+embed);
        }

        Websites.setStatusOfToggle(driver,CommonUtil.getByValue(GDPR.GDPR_TOGGLE_WEBSITES),isEnable,etest);

        Websites.clickSave(driver,etest);

		WebsitesTab.closeEmbedConfig(driver,etest);
    }

    public static void selectAllowVisitorsToChooseDepartment(WebDriver driver,ExtentTest etest,String embed) throws Exception
    {
		Tab.navToEmbedTab(driver);

		WebEmbed.clickWebEmbed(driver,embed,etest);

		WebsitesTab.clickLiveChat(driver,etest);

		WebsitesTab.clickChatWindow(driver,etest);

		WebsitesTab.clickConfigurations(driver,etest);

		Websites.selectFromDropdown(driver,"emconfig_dept","Allow visitor to select department",etest);
        
		Websites.clickSave(driver,etest);

		WebsitesTab.closeEmbedConfig(driver,etest);

		etest.log(Status.INFO,"Allow visitors to select department was selected for embed : "+embed);
    }

    public static void setBotConfigForWebsite(WebDriver driver,ExtentTest etest,String embed,int mode) throws Exception
    {
  //   	String value=BotsVisitorSide.WEBSITE_VALUES[mode];

		// Tab.navToEmbedTab(driver);

		// WebEmbed.clickWebEmbed(driver,embed,etest);

		// WebsitesTab.clickLiveChat(driver,etest);

		// WebsitesTab.clickChatWindow(driver,etest);

		// WebsitesTab.clickConfigurations(driver,etest);

		// Websites.selectFromDropdown(driver,"emconfig_bot",value,etest);

		// TakeScreenshot.infoScreenshot(driver,etest);
        
		// Websites.clickSave(driver,etest);

		// WebsitesTab.closeEmbedConfig(driver,etest);

		// etest.log(Status.INFO,"Bot setting '"+value+"' was set for embed : "+embed);
    }
}
