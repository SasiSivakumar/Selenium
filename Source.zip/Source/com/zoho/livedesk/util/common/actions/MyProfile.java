//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;

public class MyProfile
{
    public static String getUserName(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,30,250);

    	Tab.clickMyProfile(driver);

        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
        WebElement elmt1 = CommonUtil.elfinder(driver,"id","test");

        WebElement userdetails = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt1,"classname","usr-mrgntp"),"id","userdetails");
        
        return userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
    }
}