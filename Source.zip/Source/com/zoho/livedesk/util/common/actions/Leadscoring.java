//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;
import java.util.Hashtable;
import java.util.ArrayList;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class Leadscoring
{
    public static final String
    STATUS="STATUS",
    POINTS="POINTS",
    CONDITION="CONDITION"
    ;

    public static boolean isRulePresent(WebDriver driver,String ruleid) throws Exception
    {
        Tab.navToLeadscoringTab(driver);
        return CommonWait.isPresent(driver,By.cssSelector(".data_row[ruleid='"+ruleid+"']"));
    }

    public static Hashtable<String,String> getRuleInfo(WebDriver driver,String ruleid) throws Exception
    {
    	Tab.navToLeadscoringTab(driver);

	    WebElement rule_container=CommonUtil.getElement(driver,By.cssSelector(".data_row[ruleid='"+ruleid+"']"));

	    if(rule_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Rule with id "+ruleid+" was not found");
        }

        CommonUtil.scrollIntoView(driver,rule_container);

        Hashtable<String,String> rule_info=new Hashtable<String,String>();
		
        String status=CommonUtil.hasClass(rule_container,By.className("disable"))?"disable":"enable";
		rule_info.put(STATUS,status);

		String points_in_words=CommonUtil.getElement(rule_container,By.cssSelector("[class*='scr_']")).getAttribute("innerText").trim();

		String points=( points_in_words.contains("Add") ? "":"-" ) + ( points_in_words.replaceAll("[^0-9]", "") );

		rule_info.put(POINTS,points);

		String condition=rule_container.getAttribute("innerText").trim().replace(points_in_words,"");

		rule_info.put(CONDITION,condition);

		return rule_info;
    }

    public static void setAdvancedConfiguration(WebDriver driver,ExtentTest etest,String value)
    {
        CommonUtil.scrollToBottomOfPage(driver);
        CommonUtil.click(driver,By.id("lsdeprdrpdwn"));
        CommonWait.waitTillDisplayed(driver,By.id("lsdeprdrpdwn_ddown"));
        WebElement dropdown=CommonUtil.getElement(driver,By.id("lsdeprdrpdwn_ddown"));
        HandleCommonUI.chooseFromDropdown(dropdown,value);
        CommonWait.waitTillHidden(dropdown);
        etest.log(Status.INFO,"Leadscoring configuration was set to : "+value);
    }

    public static String getAdvancedConfiguration(WebDriver driver) throws Exception
    {
        Tab.navToLeadscoringTab(driver);
        return CommonUtil.getElement(driver,By.id("lsdeprdrpdwn")).getAttribute("innerText").trim();
    }

    public static String toAPIValue(String ui_content)
    {
    	return RoutingRule.toAPIValue(ui_content);
    }

    public static String toUIValue(String api_value)
    {
    	return RoutingRule.toUIValue(api_value);
    }

    public static String getTopRuleId(WebDriver driver) throws Exception
    {
        return getRuleId(driver,false);
    }

    public static String getBottomRuleId(WebDriver driver) throws Exception
    {
        return getRuleId(driver,true);
    }

    public static String getRuleId(WebDriver driver,boolean isBottom) throws Exception
    {
        Tab.navToLeadscoringTab(driver);

        List<WebElement> rules=CommonUtil.getElements(driver,By.className("data_row"));

        int index;

        if(isBottom)
        {
            index=rules.size()-1;
        }
        else
        {
            index=0;
        }

        return rules.get(index).getAttribute("ruleid");
    }
}
