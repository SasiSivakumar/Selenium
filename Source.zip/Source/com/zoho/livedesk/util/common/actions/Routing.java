//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class Routing
{
    public static String getRuleId(WebDriver driver, int i) throws Exception
    {
        return Rules.getRuleId(driver,i);
    }
    public static boolean ruleExist(WebDriver driver)
    {
        FluentWait wait = CommonUtil.waitreturner(driver,2,250);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("trouting")).getAttribute("innerHTML").contains("data_row"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            return true;
        }
        catch(Exception e){}

        return false;
    }

    public static void clickAdd(WebDriver driver, ExtentTest etest) throws Exception
    {
        Rules.clickAdd(driver,etest,"routingrulestab","Routing");
        // FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        // ((JavascriptExecutor) driver).executeScript("document.getElementById('ldngtxt').innerHTML = '';document.getElementById('ldngtxt').className = 'loadingcntmn';");

        // final int count;

        // if(ruleExist(driver))
        // {
        //     count = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("trules")).size();

        //     CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","autobtnadd"),"id","addrule").click();
        // }
        // else
        // {
        //     count = 0;

        //     CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","autobtnadd"),"id","addrule").click();
        // }

        // Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addrule.do",etest);

        // wait.until(new Function<WebDriver,Boolean>()
        // {
        //     public Boolean apply(WebDriver driver)
        //     {
        //         int countF = driver.findElement(By.id("trouting")).findElements(By.className("trules")).size();
                
        //         if(countF == (count+1))
        //         {
        //             return true;
        //         }
        //         return false;
        //     }
        // });

        // if(count == 0)
        // {
        //     try
        //     {
        //         if(!CommonUtil.elfinder(driver,"id","track_suggest").getAttribute("style").contains("none"))
        //         {
        //             CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","track_suggest"),"classname","gspritebg").click();
        //             Thread.sleep(2000);
        //         }
        //     }
        //     catch(Exception e)
        //     {
        //         e.printStackTrace();
        //     }
        // }

        // etest.log(Status.INFO,"Routing - add button is clicked");
    }

    public static void selectCriteria(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        selectCriteria(driver,id,action,null,etest);
    }

    public static void selectCriteria(WebDriver driver, String id, String action, String action2, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        CommonUtil.elfinder(driver,"id","prior"+id+"_col1_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","prior"+id+"_col1_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown,"id","srchtxt"),"tagname","input").sendKeys(action);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown,"tagname","ul"),"tagname","li").click();

        etest.log(Status.INFO,action+" is clicked");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("none"))
                {
                    return true;
                }

                return false;
            }
        });

        if(action.equals("Visitor Info") && action2 == null)
        {
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").sendKeys("Current State");

            etest.log(Status.INFO,"Current State is entered");

            return;
        } 

        if(action2 == null)
        {
            return;
        }

        if(action.equals("Visitor Info"))
        {
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").sendKeys(action2);

            etest.log(Status.FAIL,action2+" is entered");

            return;
        }

        CommonUtil.elfinder(driver,"id","prior"+id+"_col4_div").click();

        final WebElement dropDown2 = CommonUtil.elfinder(driver,"id","prior"+id+"_col4_ddown");

        if(!action.equals("CRM Deal"))
        {
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown2,"id","srchtxt"),"tagname","input").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown2,"id","srchtxt"),"tagname","input").sendKeys(action2);
        }

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown2.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        List<WebElement> list = dropDown2.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action2))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action2+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action2+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Routing","SelectCriteria","Error");
    }

    public static String getCriteria(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col1_div").getText();
    }

    public static String getSubCriteria(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col4_div").getText();
    }

    public static void selectCondition(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        CommonUtil.elfinder(driver,"id","prior"+id+"_col2_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","prior"+id+"_col2_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Routing","SelectCondition","Error");
    }

    public static String getCondition(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col2_div").getText();
    }

    public static void selectValues(WebDriver driver, String id, String value, ExtentTest etest) throws Exception
    {
        selectValues(driver,id,value,null,etest);
    }

    public static void selectValues(WebDriver driver, String id, String value1, String value2, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,2,250);

        WebElement e = CommonUtil.elfinder(driver,"id","prior"+id+"_col3");

        e.click();

        CommonUtil.elementfinder(driver,e,"id","col3_input1").clear();
        CommonUtil.elementfinder(driver,e,"id","col3_input1").sendKeys(value1);

        etest.log(Status.INFO,value1+" is entered in Value 1");

        if(value2 == null)
        {
            return;
        }
        
        CommonUtil.elementfinder(driver,e,"id","col3_input2").clear();
        CommonUtil.elementfinder(driver,e,"id","col3_input2").sendKeys(value2);

        etest.log(Status.INFO,value2+" is entered in Value 2");
    }

    public static void selectValuesInDropDown(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,2,250);

        CommonUtil.elfinder(driver,"id","prior"+id+"_col3_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","prior"+id+"_col3_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Routing","SelectValuesInDropDown","Error");
    }

    public static String getValue1(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col3"),"id","col3_input1").getAttribute("value");
    }

    public static String getValue2(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col3"),"id","col3_input2").getAttribute("value");
    }

    public static String getValueFromDropDown(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col3_div").getText();
    }

    public static void selectAction(WebDriver driver, final String id, String action, String userList, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        CommonUtil.elfinder(driver,"id","info_"+id+"_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","info_"+id+"_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        boolean present = false;

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                present = true;

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });
            }
        }

        if(!present)
        {
            etest.log(Status.FAIL,action+" is not present");
            TakeScreenshot.screenshot(driver,etest,"Routing","SelectAction","Error");
            return;
        }
        
        deleteUsers(driver,id);

        if(!action.equals("Do not route"))
        {
            String[] users = userList.split("/");
            
            for(String user : users)
            {
                String a = user.substring(0,user.length()-1);

                final WebElement agent = CommonUtil.elfinder(driver,"id","agentcontainer"+id);

                if(agent.getAttribute("innerHTML").contains("agentmail_"+id))
                {
                    CommonUtil.elementfinder(driver,agent,"tagname","input").click();
                }
                else
                {
                    CommonUtil.elementfinder(driver,agent,"tagname","em").click();
                }

                CommonUtil.elementfinder(driver,agent,"tagname","input").sendKeys(a);
                
                CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","agentmail_"+id+"auto"),"tagname","li").click();

                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(agent.getAttribute("innerHTML").contains("agentmail_"+id+"auto") || agent.findElement(By.id("agentmail_"+id+"auto")).getAttribute("style").contains("none"))
                        {
                            return true;
                        }
                        return false;
                    }
                });

                Thread.sleep(1000);
            }
        }
    }

    public static String getAction(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","info_"+id+"_div").getText();
    }

    public static String getUsers(WebDriver driver, String id) throws Exception
    {
        WebElement e1 = CommonUtil.elfinder(driver,"id","info_"+id);

        WebElement usersDiv = CommonUtil.elementfinder(driver,e1,"xpath","../div[contains(@class,'ruleuserset')]");

        if(usersDiv.getAttribute("innerHTML").contains("notroute"))
        {
            return null;
        }
        
        if(!usersDiv.getAttribute("innerHTML").contains("position-relative"))
        {
            return null;
        }
        
        List<WebElement> users = usersDiv.findElements(By.className("position-relative"));

        String usersList = null;

        for(WebElement e : users)
        {
            WebElement f = CommonUtil.elementfinder(driver,e,"classname","agntname");

            String s = f.getAttribute("innerHTML");
            
            if(usersList != null)
            {
                usersList += "/"+s;
            }
            else
            {
                usersList = s;
            }
        }

        return usersList;
    }
    
    public static void deleteUsers(WebDriver driver, String id) throws Exception
    {
        WebElement e1 = CommonUtil.elfinder(driver,"id","info_"+id);
        
        final WebElement usersDiv = CommonUtil.elementfinder(driver,e1,"xpath","../div[contains(@class,'ruleuserset')]");
        
        if(usersDiv.getAttribute("innerHTML").contains("notroute"))
        {
            return;
        }
        
        if(!usersDiv.getAttribute("innerHTML").contains("position-relative"))
        {
            return;
        }
        
        List<WebElement> users = usersDiv.findElements(By.className("position-relative"));
        
        final int count = users.size();
        
        FluentWait wait = CommonUtil.waitreturner(driver,5,250);
        
        for(int i = 1; i <= count; i++)
        {
            WebElement e = null;
            
            if(CommonUtil.elementfinder(driver,usersDiv,"classname","position-relative").getAttribute("innerHTML").contains("img"))
            {
                e = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,usersDiv,"classname","position-relative"),"tagname","img");
            }
            else
            {
                e = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,usersDiv,"classname","position-relative"),"tagname","div");
            }
            
            CommonUtil.mouseHover(driver,e);
            
            WebElement delete = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,usersDiv,"classname","position-relative"),"tagname","em");
            
            wait.until(ExpectedConditions.visibilityOf(delete));
            
            delete.click();
            
            if(i == count)
            {
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(!usersDiv.getAttribute("innerHTML").contains("position-relative"))
                        {
                            return true;
                        }
                        
                        return false;
                    }
                });
            }
            else
            {
                final int s = i;
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        int k = usersDiv.findElements(By.className("position-relative")).size();
                        if(k == (count-s))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            
            Thread.sleep(1000);
        }
    }

    public static void deleteRule(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        List<WebElement> list = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("data_row"));
        
        final int count = list.size();
        
        WebElement elmtch = list.get(0);
        
        CommonUtil.mouseHover(driver,elmtch);
        
        CommonUtil.elementfinder(driver,elmtch,"classname","sqico-delico").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
        
        CommonUtil.elfinder(driver,"id","okbtn").click();
        
        final WebElement e = CommonUtil.elfinder(driver,"id","popupdiv");
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if(e.getAttribute("innerHTML").equals(""))
                           {
                               return true;
                           }
                           return false;
                       }
                   });
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Rule deleted Successfully","deleterule.do",etest);
        
        if(count == 1)
        {
            if(!ruleExist(driver))
            {
                return;
            }
        }
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           try
                           {
                               int finalCount = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("data_row")).size();
                               
                               if(finalCount == (count - 1))
                               {
                                   return true;
                               }
                           }
                           catch(Exception e)
                           {}
                           return false;
                       }
                   });
        
        Thread.sleep(500);
    }
}
