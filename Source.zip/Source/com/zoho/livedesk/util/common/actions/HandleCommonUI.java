//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.Cleanup;

public class HandleCommonUI
{

    //popup methods and constants
    public static final By
    POSITIVE_BUTTON1=By.id("okbtn"),
    NEGATIVE_BUTTON1=By.id("cancelbtn"),
    CLOSE_POPUP=By.id("dlgclose"),
    CHECKBOX_CHECKED=By.className("sqico-checkbox"),
    CHECKBOX_UNCHECKED=By.className("sqico-uncheckbox"),
    TOOLTIP=By.id("ldtooltip")
    ;

    public static final String
    CHAR_LIMIT_TEMPLATE_TEXT="$limit$",
    TOGGLE_ON_CLASSNAME="set_on",
    TOGGLE_OFF_CLASSNAME="set_off"
    ;

    public static final boolean IS_CHECK_SEASONAL_FLOAT=false;

    public static void waitTillPopupFound(WebDriver driver,String attribute,String value)
    {        
        FluentWait wait=CommonUtil.waitreturner(driver,20,250);

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(getPopupByAttribute(driver,attribute,value)!=null)
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static WebElement getPopupByAttribute(WebDriver driver,String attribute,String value)
    {
        if(Cleanup.isBodyContains(driver,"lvd_popupmn")==false)
        {
            return null;
        }

        List<WebElement> popups=CommonUtil.getElement(driver,By.id("popupdiv")).findElements(By.className("lvd_popupmn"));
        WebElement popup = CommonUtil.getElementByAttributeValue(popups,attribute,value);
        return popup;
    }

    public static void chooseFromDropdown(WebElement dropdown,String value)
    {
        chooseFromDropdown(dropdown,value,false,true);
    }

    public static void chooseFromDropdown(WebElement dropdown,String container_element,String inner_element,String value,boolean isWaitTillDisplayed,boolean isWaitTillHidden)
    {
        if(isWaitTillDisplayed)
        {
            CommonWait.waitTillDisplayed(dropdown);
        }
        
        List<WebElement> dropdown_value_sets=dropdown.findElements(By.tagName(container_element));
        List<WebElement> dropdown_values=CommonUtil.getChildElementsOfElementListBy(dropdown_value_sets,By.tagName(inner_element));  
        WebElement dropdown_value=CommonUtil.getElementByAttributeValue(dropdown_values,"innerText",value);
        CommonUtil.inViewPort(dropdown_value);
        dropdown_value.click();
        if(isWaitTillHidden)
        {
            CommonWait.waitTillHidden(dropdown_value);
        }
    }

    public static void chooseFromDropdown(WebElement dropdown,String value,boolean isWaitTillDisplayed,boolean isWaitTillHidden)
    {
        //pass the innermost element from dropdown
        chooseFromDropdown(dropdown,"ul","li",value,isWaitTillDisplayed,isWaitTillHidden);
    }

    public static WebElement getPopupByInnerText(WebDriver driver,String inner_text)
    {
        return getPopupByAttribute(driver,"innerText",inner_text);
    }

    public static void clickPositivePopupButton(WebElement popup)
    {
        clickButtonInPopup(popup,true);   
    }
    public static void clickNegativePopupButton(WebElement popup)
    {
        clickButtonInPopup(popup,false);
    }

    public static void clickButtonInPopup(WebElement popup,boolean isClickPositiveButton)
    {
        if(isClickPositiveButton)
        {
           if(popup.findElements(POSITIVE_BUTTON1).size()>0)
           {
                popup.findElement(POSITIVE_BUTTON1).click();
           } 
        }
        else
        {
           if(popup.findElements(NEGATIVE_BUTTON1).size()>0)
           {
                popup.findElement(NEGATIVE_BUTTON1).click();
           } 
        }

        CommonWait.waitTillHidden(popup);
    }

    public static boolean closePopup(WebElement popup)
    {
        CommonUtil.getElement(popup,CLOSE_POPUP).click();
        return CommonWait.waitTillHidden(popup);
    }

    public static void setCheckbox(WebElement checkbox,boolean isCheck)
    {
        CommonUtil.inViewPort(checkbox);

        if(isCheckboxChecked(checkbox)==isCheck)
        {
            return;
        }

        checkbox.click();

        waitTillCheckboxStateChange(checkbox,isCheck);
    }

    public static boolean waitTillCheckboxStateChange(final WebElement checkbox,final boolean isChecked)
    {
        FluentWait wait = new FluentWait(checkbox);
        wait.withTimeout(10,TimeUnit.SECONDS);
        wait.pollingEvery(250, TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        wait.ignoring(StaleElementReferenceException.class);

        wait.until(new Function<WebElement,Boolean>()
        {
            public Boolean apply(final WebElement checkbox)
            {
                if(isCheckboxChecked(checkbox)==isChecked)
                {
                    return true;
                }
                return false;
            }
        });

        return (isCheckboxChecked(checkbox)==isChecked);
    }

    public static boolean isCheckboxChecked(WebElement checkbox)
    {
        if(checkbox.getAttribute("checked")!=null)
        {
            if(checkbox.getAttribute("checked").equals("true") || checkbox.getAttribute("checked").equals("checked"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        if(CommonUtil.hasClass(checkbox,CHECKBOX_CHECKED))
        {
            return true;
        }
        else if(CommonUtil.hasClass(checkbox,CHECKBOX_UNCHECKED))
        {
            return false;
        }

        return false;
    }

    //Common validating functions

    public static boolean verifyAnchorTag(WebElement a_tag,ExtentTest etest,String text,String link)
    {
        int failcount=0;

        if(text!=null)
        {
            if(CommonUtil.checkStringContainsAndLog(text,a_tag.getText(),"anchor tag text",etest)==false)
            {
                failcount++;
            }
        }
        if(link!=null)
        {
            if(a_tag.getAttribute("href")!=null)
            {
                if(CommonUtil.checkStringContainsAndLog(link,a_tag.getAttribute("href"),"anchor tag link",etest)==false)
                {
                    failcount++;
                }
            }
            else
            {
                failcount++;
                etest.log(Status.FAIL,"'href' tag was not FOUND in anchor tag");
            }   
        }

        return CommonUtil.returnResult(failcount);
    }

    public static void sendKeys(WebElement input,String input_data)
    {
        CommonUtil.inViewPort(input);
        input.click();
        input.clear();
        input.sendKeys(input_data);
    }

    public static void sendKeysIfNotNull(WebElement input,String input_data)
    {
        if(input==null || input_data==null)
        {
            return;
        }
        
        sendKeys(input,input_data);
    }

    public static boolean verifyTooltip(WebDriver driver,ExtentTest etest,By tooltip_trigger_locator,By tooltip_container_locator,String expected_tooltip)
    {
        return verifyTooltip(driver,etest,CommonUtil.getElement(driver,By.tagName("body")),tooltip_trigger_locator,tooltip_container_locator,expected_tooltip);
    }

    public static boolean verifyTooltip(WebDriver driver,ExtentTest etest,WebElement ele,By tooltip_trigger_locator,By tooltip_container_locator,String expected_tooltip)
    {
        WebElement tooltip_trigger_element=CommonUtil.getElement(ele,tooltip_trigger_locator);
        CommonUtil.inViewPort(tooltip_trigger_element);
        CommonUtil.mouseHover(driver,tooltip_trigger_element);
        System.out.println("~~~WAiting for tooltip ");
        CommonWait.waitTillDisplayed(driver,tooltip_container_locator);

        WebElement tooltip_container=CommonUtil.getElement(driver,tooltip_container_locator);

        boolean result=CommonUtil.checkStringContainsAndLog(expected_tooltip,tooltip_container.getText(),"tooltip",etest);

        if(!result)
        {
            TakeScreenshot.screenshot(driver,etest);
        }

        CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,By.tagName("body")));
        CommonWait.waitTillHidden(tooltip_container);

        return result;
    }

    public static boolean checkCharLimitForInput(WebDriver driver,ExtentTest etest,WebElement input,WebElement char_limit_container,int char_limit,int check_frequency,String char_limit_template,String char_limit_exceeded_text,String input_description)
    {
        int failcount=0;

        String input_value="";

        int no_of_checks=(char_limit/check_frequency)+1;

        for(int i=0;i<=no_of_checks;i++)
        {
            int input_length=(i*check_frequency);

            input_value=getInputSample(input_length);

            etest.log(Status.INFO,"Sending '"+input_value+"'' to "+input_description);

            boolean isCharLimitExceeded=(input_length>char_limit);

            input.click();
            input.clear();
            input.sendKeys(input_value);

            int expected_char_limit=char_limit-input_length;
            String actual=char_limit_container.getText();
            String expected=char_limit_template.replace(char_limit_template,expected_char_limit+"");

            if(isCharLimitExceeded)
            {
                expected=char_limit_exceeded_text;
            }

            if(!CommonUtil.checkStringContainsAndLog(expected,actual,"character limit after sending "+input_length+" characters in "+input_description,etest))
            {
                failcount++;
                TakeScreenshot.screenshot(driver,etest);
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static String getInputSample(int string_size)
    {
        String input_value="";

        for(int i=0;i<string_size;i++)
        {
            input_value=input_value+"a";
        }

        return input_value;
    }

    public static boolean checkMessages(List<String> expected_messages,List<String> actual_messages,String description,ExtentTest etest)
    {
        try
        {
            int failcount=0;

        if(expected_messages.size()!=actual_messages.size())
        {
            etest.log(Status.WARNING,"No of messages in expected messages list and actual messages list are different. Expected messages size : "+expected_messages.size()+" Actual messages size : "+actual_messages.size());
        }

        for(int i=0;i<expected_messages.size();i++)
        {
            String expected_message=expected_messages.get(i);
            String actual_message=actual_messages.get(i);

            if(CommonUtil.checkStringContainsAndLog(expected_message,actual_message,description,etest)==false)
            {
                failcount++;
            }
        }

            return CommonUtil.returnResult(failcount);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            TakeScreenshot.log(e,etest);
            return false;
        }

    }

    public static boolean authenticateFileDownloadPopup(WebDriver driver)
    {
        return authenticateFileDownloadPopup(driver,null);
    }

    public static boolean authenticateFileDownloadPopup(WebDriver driver,String password)
    {
        if(password==null)
        {
            password=CommonUtil.getUniqueMessage();
        }

        CommonWait.waitTillDisplayed(driver,ChatHistory.EXPORT_POPUP_CONTAINER);
        WebElement popup=CommonUtil.getElement(driver,ChatHistory.EXPORT_POPUP_CONTAINER);
        CommonUtil.getElement(popup,ChatHistory.EXPORT_PASSWORD).sendKeys(password);
        CommonUtil.getElement(popup,ChatHistory.EXPORT_AUTHENTICATE_BUTTON).click();
        return CommonWait.waitTillHidden(popup);
    }

    public static boolean isLiveTypingStatus(String typing_status,String typed_text,ExtentTest etest)
    {
        if(CommonUtil.isCharMissing(typing_status,typed_text,etest))
        {
            int missing_char_length=CommonUtil.getMissingChar(typing_status,typed_text).length();
            if(missing_char_length>5)
            {
                etest.log(Status.FAIL,"Live status was not found. No of characters missing : "+missing_char_length);
                return false;
            }
            else
            {
                return true;
            }
        }

        return true;
    }

    public static boolean checkTitleChange(WebDriver driver,ExtentTest etest,String expectedText,String window)
    {
        try
        {
            WebDriverWait wait = new WebDriverWait(driver, 15);
            wait.until(ExpectedConditions.titleContains(expectedText));
            etest.log(Status.PASS,window+" title text was changed on receiving a message");
            return true;
        }
        catch(Exception e)
        {
            etest.log(Status.FAIL,window+" title text was not changed upon receiving a message");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static boolean setToggle(WebDriver driver,String tbutid,boolean isEnable)
    {
        WebElement checkbox=CommonUtil.getElement(driver,By.cssSelector("[tbutid='"+tbutid+"']"));
        CommonUtil.inViewPortSafe(driver,checkbox);
        hideSeasonalFloat(driver);
        return setToggle(checkbox,isEnable);
    }

    public static boolean setToggle(WebElement toggle,boolean isEnable)
    {
        if(isToggleEnabled(toggle)==isEnable)
        {
            return true;
        }

        CommonUtil.inViewPort(toggle);
        toggle.click();

        String expected_classname=isEnable?TOGGLE_ON_CLASSNAME:TOGGLE_OFF_CLASSNAME;

        return CommonUtil.waitTillWebElementContainsAttributeValue(toggle,"class",expected_classname);
    }

    public static boolean isToggleEnabled(WebElement toggle)
    {
        return CommonUtil.hasClass(toggle,TOGGLE_ON_CLASSNAME);
    }

    public static void hideSeasonalFloat(WebDriver driver)
    {
        if(!IS_CHECK_SEASONAL_FLOAT)
        {
            return;
        }

        try
        {
            ((JavascriptExecutor) driver).executeScript("document.getElementById('seasonal_float').style.visibility='hidden';");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
