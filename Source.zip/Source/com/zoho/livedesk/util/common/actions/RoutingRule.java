//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;
import java.util.Hashtable;
import java.util.ArrayList;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class RoutingRule
{
    public static final String
    NAME="NAME",
    REPLIED="REPLIED",
    TRIGGERED="TRIGGERED",
    ROUTED="ROUTED",
    CONNECTED="CONNECTED",
    TRANSFERED="TRANSFERED",
    MISSED="MISSED",
    REQUESTED="REQUESTED",
    ATTENDED="ATTENDED",
    STATUS="STATUS",
    ROUTING_TYPE="ROUTING_TYPE",
    ROUTING_CONDITION="ROUTING_CONDITION",
    ROUTING_ORDER="ROUTING_ORDER",
    WEBSITE="WEBSITE"
    ;

    //rule types
    public static final int
    VISITOR_ROUTING=0,
    CHAT_ROUTING=1,
    CALL_ROUTING=2
    ;

    public static boolean isRulePresent(WebDriver driver,String ruleid,int rule_type) throws Exception
    {
        navToRuleTab(driver,rule_type);
        return CommonWait.isPresent(driver,By.cssSelector(".data_row[ruleid='"+ruleid+"']"));
    }

    public static Hashtable<String,String> getRuleInfo(WebDriver driver,String ruleid,int rule_type) throws Exception
    {
        navToRuleTab(driver,rule_type);

        WebElement rule_container=CommonUtil.getElement(driver,By.cssSelector(".data_row[ruleid='"+ruleid+"']"));

        CommonUtil.scrollIntoView(driver,rule_container);

        if(rule_container==null)
        {
            throw new ZohoSalesIQRuntimeException("Rule with id "+ruleid+" was not found");
        }

        Hashtable<String,String> rule_info=new Hashtable<String,String>();

        rule_info.put(NAME,CommonUtil.getElement(rule_container,By.cssSelector("[dochover='setHelpTip'][class^='f']")).getAttribute("innerText").trim());        

        if(rule_type==VISITOR_ROUTING)
        {
            rule_info.put(REPLIED,CommonUtil.getElement(rule_container,By.className("sqico-replied")).getAttribute("innerText").trim());

            rule_info.put(TRIGGERED,CommonUtil.getElement(rule_container,By.className("sqico-triggered")).getAttribute("innerText").trim());

            rule_info.put(ROUTED,CommonUtil.getElement(rule_container,By.className("sqico-routed")).getAttribute("innerText").trim());
        }

        else if(rule_type==CHAT_ROUTING)
        {
            rule_info.put(CONNECTED,CommonUtil.getElement(rule_container,By.className("sqico-connected")).getAttribute("innerText").trim());

            rule_info.put(TRANSFERED,CommonUtil.getElement(rule_container,By.className("sqico-transferred")).getAttribute("innerText").trim());

            rule_info.put(REQUESTED,CommonUtil.getElement(rule_container,By.className("sqico-requested")).getAttribute("innerText").trim());

            rule_info.put(MISSED,CommonUtil.getElement(rule_container,By.className("sqico-missed")).getAttribute("innerText").trim());
        }

        else if(rule_type==CALL_ROUTING)
        {
            rule_info.put(MISSED,CommonUtil.getElement(rule_container,By.className("sqico-missed")).getAttribute("innerText").trim());

            rule_info.put(ATTENDED,CommonUtil.getElement(rule_container,By.className("sqico-attended")).getAttribute("innerText").trim());

            rule_info.put(ROUTED,CommonUtil.getElement(rule_container,By.className("sqico-routed")).getAttribute("innerText").trim());
        }

        rule_info.put(STATUS,rule_container.getAttribute("status"));

        CommonUtil.getElement(rule_container,By.cssSelector("[dochover='setHelpTip'][class^='f']")).click();
        CommonWait.waitTillDisplayed(driver,By.cssSelector("#rule_editmain[ruleid='"+ruleid+"']"));

        rule_container=CommonUtil.getElement(driver,By.cssSelector("#rule_editmain[ruleid='"+ruleid+"']"));

        rule_info.put(WEBSITE,CommonUtil.getElement(rule_container,By.id("ruleembed_edit")).getAttribute("innerText").trim());

        rule_info.put(ROUTING_TYPE,CommonUtil.getElement(rule_container,By.cssSelector("[id*='info_'][ruleid]")).getAttribute("innerText").trim());

        rule_info.put(ROUTING_CONDITION,CommonUtil.getElement(rule_container,By.cssSelector("[id*='prior'][id*='_col3']")).getAttribute("innerText").trim());

        rule_info.put(ROUTING_ORDER,getRoutingConditionOrder(rule_container));

        CommonUtil.getElement(rule_container,By.className("sqico-close")).click();

        CommonWait.waitTillHidden(rule_container);

        return rule_info;
    }

    public static String getRoutingConditionOrder(WebElement rule_container)
    {
        List<String> lsuids=CommonUtil.getAttributesFromList(CommonUtil.getElements(rule_container,By.cssSelector("[lsuid]")),"lsuid");
        return CommonUtil.toCommaSeperatedString(lsuids);
    }

    public static boolean isRouteRemainingVisitorsToAllEnabled(WebDriver driver) throws Exception
    {
        Tab.navToVRTab(driver);
        return HandleCommonUI.isCheckboxChecked(CommonUtil.getElement(driver,By.id("assignrules")));
    }

    public static String toAPIValue(String ui_content)
    {
        if(ui_content.contains("enable"))
        {
            return Constants.ENABLED;
        }
        else if(ui_content.contains("disable"))
        {
            return Constants.DISABLED;            
        }
        else
        {
            return ui_content;
        }
    }

    public static String toUIValue(String api_value)
    {
        if(api_value.equals(Constants.LAST_ATTENDER))
        {
            return "-2";
        }
        else if(api_value.equals("country"))
        {
            return "Country";
        }
        else if(api_value.equals("is_equal_to"))
        {
            return "is equal to";
        }
        else if(api_value.equals("India"))
        {
            return "India";
        }
        else if(api_value.equals("campaign_medium"))
        {
            return "Campaign Medium";
        }
        else if(api_value.equals("contains"))
        {
            return "contains";
        }
        else if(api_value.equals("utm_campaign_name"))
        {
            return "Campaign Name";
        }
        else if(api_value.equals("email"))
        {
            return "Email Address";
        }
        else
        {
            return api_value;
        }
    }

    public static String getRoutingTypeAPIKey(String ui_content)
    {
        if(ui_content.contains("Route to selected operators"))
        {
            return Constants.ROUTE_TO_SELECTED_USERS;
        }
        else
        {
            return ui_content;
        }
    }

    public static String getTopRoutingRuleId(WebDriver driver,int rule_type) throws Exception
    {
        return getRoutingRuleId(driver,rule_type,false);
    }

    public static String getBottomRoutingRuleId(WebDriver driver,int rule_type) throws Exception
    {
        return getRoutingRuleId(driver,rule_type,true);
    }

    public static String getRoutingRuleId(WebDriver driver,int rule_type,boolean isBottom) throws Exception
    {
        navToRuleTab(driver,rule_type);

        List<WebElement> rules=CommonUtil.getElements(driver,By.className("data_row"));

        int index;

        if(isBottom)
        {
            index=rules.size()-1;
        }
        else
        {
            index=0;
        }

        return rules.get(index).getAttribute("ruleid");
    }

    public static void navToRuleTab(WebDriver driver,int rule_type) throws Exception
    {
        Tab.clickVisitorsOnline(driver);

        if(rule_type==VISITOR_ROUTING)
        {
            Tab.navToVRTab(driver);
        }
        else if(rule_type==CHAT_ROUTING)
        {
            Tab.navToChatRoutingTab(driver);
        }
        else if(rule_type==CALL_ROUTING)
        {
            Tab.navToCallRoutingTab(driver);
        }
    }
}
