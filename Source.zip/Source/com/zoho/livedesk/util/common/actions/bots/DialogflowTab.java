//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class DialogflowTab
{
    public static final By
    DIALOGFLOW_CONSOLE_BUTTON=By.id("botconsole"),
    DIALOGFLOW_EMAIL=By.className("clr-mail")
    ;

    public static void openDialogflowConsole(WebDriver driver,ExtentTest etest)
    {
        openConsole(driver,etest,"Dialogflow");
    }

    public static void openConsole(WebDriver driver,ExtentTest etest,String console_type)
    {
        WebElement button=CommonUtil.getElement(driver,DIALOGFLOW_CONSOLE_BUTTON);
        CommonWait.waitTillDisplayed(button);
        CommonUtil.clickWebElement(driver,button);
        CommonUtil.waitTillNewTabOpens(driver,1);
        CommonUtil.switchToTab(driver,1);
        Dialogflow.waitTillDialogflowPageLoads(driver);
        etest.log(Status.INFO,console_type+" page was opened.");
        TakeScreenshot.infoScreenshot(driver,etest);
    }

    public static String getDialogFlowEmailId(WebDriver driver)
    {
        return getEmailId(driver);
    }

    public static String getEmailId(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,DIALOGFLOW_EMAIL);
        return CommonUtil.getElement(driver,DIALOGFLOW_EMAIL).getAttribute("innerText");
    }


}
