//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import java.util.ArrayList;

public class ChatHistoryChat
{
    /* Refer com.zoho.livedesk.util.common.actions.ChatWindow.java if any functions are missing here */

    /*@@*/
    /*Constants*/
    public static final String
    VISITOR_MESSAGE_LIST="visitor_messages",
    AGENT_MESSAGE_LIST="agent_messages"
    ;

    public static final String
    ACTIONS_SAVE_PDF=ResourceManager.getRealValue("actions_pdf");

    public static final By
    //Main locators
    CHAT_HISTORY_CHAT_CONTAINER=By.id("history_div"),
    CHAT_TRANSCRIPT_CONTAINER=By.id("zsmaincontainer"),
    RHS=By.id("visdatapar"),
    RHS_VISITOR_DATA=By.id("visitinfoholderdiv"),
    TRANSLATION_CONTAINER=By.id("shwtranstxt"),
    SHOW_TRANSLATED_BUTTON=By.id("enabletrans"),
    SHOW_ORIGINAL_BUTTON=By.id("canceltrans"),
    ACTIONS_CONTAINER=By.id("cusactions"),
    CHAT_ACTION_DROPDOWN=By.id("combodiv"),
    //Transcript related locators
    QUESTION_CONTAINER=By.id("msgques"),
    TRANSLATED_CHAT_CONTAINER=By.id("chathead"),

    TRANSCRIPT_CONTAINER=By.id("msgtable"),
    TRANSCRIPT_QUESTION=By.tagName("h1"),
    TRANSCRIPT_VISITOR_NAME=By.id("chatvisname"),
    TRANSCRIPT_VISITOR_EMAIL= By.id("chatvisemail"),
    CHATID=By.className("lvst_idtxt"),
    MESSAGE_TEXT=By.className("msgtxt"),
    AGENT_MESSAGE=By.id("rep"),
    VISITOR_MESSAGE=By.id("visitor"),
    //RHS visitor data
    RHS_EMAIL=By.id("cvemail"),
    RHS_PHONE=By.id("cvphone"),
    RHS_EDIT_ICON=By.cssSelector("[onclick*=editNameAndEmail]"),
    RHS_FNAME_INPUT=By.id("cvisfirstname"),
    RHS_SNAME_INPUT=By.id("cvisname"),
    RHS_EMAIL_INPUT=By.id("cvisemail"),
    RHS_PHONE_INPUT=By.id("cvisphone"),
    RHS_EDIT_SAVE_BUTTON=By.cssSelector("[onclick*=saveNameAndEmail]"),
    RHS_ERROR_INPUT=By.className("errorbdr"),
    //Visitor Info
    INFO_CONTAINER=By.id("displaydata"),
    NOTES_CONTAINER=By.id("noteshead"),

    //Misc
    RHS_DATA=By.className("rcvstinfotxt"),
    RHS_WEBSITE_IDENTIFIER=By.className("sqico-device-link"),
    CHAT_HISTORY_ANCHOR_CONTAINER=By.className("bcrumbs"),
    CHAT_HISTORY_ANCHOR_CUS_ACTIONS=By.cssSelector("[href*=portal/history]"),
    CURRENT_CHAT_VIEW_CONTAINER=By.cssSelector("[oprname]")
    ;

    public static void waitTillChatOpened(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,CHAT_HISTORY_CHAT_CONTAINER,CHAT_TRANSCRIPT_CONTAINER);
    }

    public static Hashtable<String,String> getChatData(WebDriver driver)
    {
        String
        chatid=null,
        question=null,
        visitor_mail=null,
        visitor_name=null
        ;

        waitTillChatOpened(driver);

        WebElement question_container=null;

        if(isTranscriptTranslated(driver))
        {
            question_container=CommonUtil.getElement(driver,TRANSLATED_CHAT_CONTAINER,By.tagName("tr"));
        }
        else
        {
            question_container=CommonUtil.getElement(driver,QUESTION_CONTAINER);
        }

        chatid=CommonUtil.getElement(question_container,CHATID).getText();

        question=CommonUtil.getElement(question_container,TRANSCRIPT_QUESTION).getText();

        question=question.replace(chatid,"");

        visitor_name=CommonUtil.getElement(question_container,TRANSCRIPT_VISITOR_NAME).getText();

        if(CommonUtil.getElement(question_container,TRANSCRIPT_VISITOR_EMAIL)!=null)
        {
            visitor_mail=CommonUtil.getElement(question_container,TRANSCRIPT_VISITOR_EMAIL).getText();
        }

        Hashtable<String,String> chat_data=new Hashtable<String,String>();

        chat_data.put(ChatHistory.VISITOR,visitor_name);
        chat_data.put(ChatHistory.QUESTION,question);
        chat_data.put(ChatHistory.MAIL,visitor_mail);
        chat_data.put(ChatHistory.CH_ID,chatid);

        return chat_data;
    }

    public static Hashtable<String,ArrayList<String>> getMessages(WebDriver driver)
    {
        ArrayList<String> visitor_messages=new ArrayList<String>();
        ArrayList<String> agent_messages=new ArrayList<String>();

        WebElement transcript=null;
        List<WebElement> messages=null;

        if(isTranscriptTranslated(driver))
        {
            transcript=CommonUtil.getElement(driver,TRANSLATED_CHAT_CONTAINER);
            messages=transcript.findElements(By.tagName("tr"));
            messages.remove(0);
        }
        else
        {
            transcript=CommonUtil.getElement(driver,TRANSCRIPT_CONTAINER);
            messages=transcript.findElements(By.tagName("tr"));
        }


        for(WebElement message : messages)
        {
            String message_text=CommonUtil.getElement(message,MESSAGE_TEXT).getText();

            if(isVisitorMessage(message))
            {
                visitor_messages.add(message_text);
            }
            else
            {
                agent_messages.add(message_text);
            }
        }

        Hashtable<String,ArrayList<String>> categorised_messages=new Hashtable<String,ArrayList<String>>();

        categorised_messages.put(VISITOR_MESSAGE_LIST,visitor_messages);
        categorised_messages.put(AGENT_MESSAGE_LIST,agent_messages);

        return categorised_messages;
    }

    public static Hashtable<String,String> getChatDataRHS(WebDriver driver)
    {
        Hashtable<String,String> chat_data=new Hashtable<String,String>();

        WebElement visitor_info_container=CommonUtil.getElement(driver,RHS,RHS_VISITOR_DATA);

        CommonWait.waitTillDisplayed(driver,RHS_EMAIL);
        addTextToHashtable(chat_data,ChatHistory.MAIL, CommonUtil.getElement(driver,RHS_EMAIL) );
        CommonWait.waitTillDisplayed(driver,RHS_PHONE);
        addTextToHashtable(chat_data,ChatHistory.VISITOR_PHONE, CommonUtil.getElement(driver,RHS_PHONE) );
        addTextToHashtable(chat_data,ChatHistory.WEBSITE, getRHSWebsiteContainer(driver) );

        clickEditRHSDataIcon(driver);

        addTextToHashtable(chat_data,ChatHistory.FIRST_NAME, getRHSVisitorDataContainer(driver).findElement(RHS_FNAME_INPUT));
        addTextToHashtable(chat_data,ChatHistory.SECOND_NAME, getRHSVisitorDataContainer(driver).findElement(RHS_SNAME_INPUT));

        clickRHSSaveButton(driver);

        return chat_data;
    }

    public static boolean verifyChatData(WebDriver driver,ExtentTest etest,String fname,String sname,String mail,String phone)
    {
        int failcount=0;

        Hashtable<String,String> chat_data=getChatDataRHS(driver);

        ChatHistoryTests.checkMailToLink(driver,etest);

        if(fname!=null && verifyChatData(ChatHistory.FIRST_NAME,chat_data,fname,etest)==false)
        {
            failcount++;
        }
        if(sname!=null && verifyChatData(ChatHistory.SECOND_NAME,chat_data,sname,etest)==false)
        {
            failcount++;
        }
        if(mail!=null && verifyChatData(ChatHistory.MAIL,chat_data,mail,etest)==false)
        {
            failcount++;
        }
        if(phone!=null && verifyChatData(ChatHistory.VISITOR_PHONE,chat_data,phone,etest)==false)
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }


    private static boolean verifyChatData(String key,Hashtable<String,String> chat_data,String expected_value,ExtentTest etest)
    {
        return CommonUtil.checkStringContainsAndLog(expected_value,chat_data.get(key),key,etest);
    }

    public static WebElement getRHSWebsiteContainer(WebDriver driver)
    {
        List<WebElement> visitor_infos=CommonUtil.getElement(driver,RHS,RHS_VISITOR_DATA).findElements(RHS_DATA);

        for(WebElement visitor_info : visitor_infos)
        {
            if(visitor_info.findElements(RHS_WEBSITE_IDENTIFIER).size()>0)
            {
                return visitor_info;
            }
        }

        return null;
    }

    public static WebElement getRHSVisitorDataContainer(WebDriver driver)
    {
        List<WebElement> rhs_list=CommonUtil.getElements(driver,RHS);
        WebElement rhs=CommonUtil.getVisibileWebElementFromList(rhs_list);
        // return rhs;
        return CommonUtil.getElement(rhs,RHS_VISITOR_DATA);
    }

    public static boolean setRHSData(WebDriver driver,ExtentTest etest,String first_name,String second_name,String mail,String phone)
    {
        clickEditRHSDataIcon(driver);

        CommonSikuli.findInWholePage(driver,"UI348.png","UI348",etest);
        CommonSikuli.findInWholePage(driver,"UI349.png","UI349",etest);

        WebElement rhs_visitor_data=getRHSVisitorDataContainer(driver);

        HandleCommonUI.sendKeysIfNotNull(CommonUtil.getElement(rhs_visitor_data,RHS_FNAME_INPUT),first_name);
        HandleCommonUI.sendKeysIfNotNull(CommonUtil.getElement(rhs_visitor_data,RHS_SNAME_INPUT),second_name);
        HandleCommonUI.sendKeysIfNotNull(CommonUtil.getElement(rhs_visitor_data,RHS_EMAIL_INPUT),mail);
        HandleCommonUI.sendKeysIfNotNull(CommonUtil.getElement(rhs_visitor_data,RHS_PHONE_INPUT),phone);

        etest.log(Status.INFO,"Visitor data was edited.");

        return clickRHSSaveButton(driver);
    }

    public static boolean clickRHSSaveButton(WebDriver driver)
    {
        WebElement rhs_visitor_data=getRHSVisitorDataContainer(driver);
        WebElement save_button=CommonUtil.getElement(rhs_visitor_data,RHS_EDIT_SAVE_BUTTON);
        save_button.click();
        return CommonWait.waitTillHidden(save_button,30);
    }

    public static boolean isRHSInputInvalid(WebDriver driver)
    {
        int error_inputs=CommonUtil.getElements(getRHSVisitorDataContainer(driver),RHS_ERROR_INPUT).size();

        if(error_inputs>0)
        {
            return true;
        }

        return false;
    }   

    public static void clickEditRHSDataIcon(WebDriver driver)
    {
        WebElement email_icon=CommonUtil.getElement(getRHSVisitorDataContainer(driver),RHS_EMAIL);
        CommonUtil.mouseHover(driver,email_icon);
        CommonUtil.sleep(100);
        WebElement edit_icon=CommonUtil.getElement(getRHSVisitorDataContainer(driver),RHS_EDIT_ICON,By.tagName("span"));
        CommonWait.waitTillDisplayed(edit_icon);
        CommonUtil.mouseHoverAndClick(driver,edit_icon);
        CommonWait.waitTillHidden(edit_icon);
    }

    public static void addTextToHashtable(Hashtable<String,String> hashtable,String key,WebElement element)
    {
        if(element!=null)
        {
            String value=null;
            if(element.getTagName().equals("input"))
            {
                value=element.getAttribute("value");
            }
            else
            {
                value=element.getAttribute("innerText");

            }


            if(value==null)
            {
                return;
            }

            hashtable.put(key,value);
        }
        else
        {
            hashtable.put(key,null);
        }
    }

    public static boolean isVisitorMessage(WebElement message_element)
    {
        if(message_element.findElements(VISITOR_MESSAGE).size()>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public static void setTranslationTo(WebDriver driver,ExtentTest etest,boolean isTranslate)
    {
        if(isTranscriptTranslated(driver)==isTranslate)
        {
            ChatHistoryTests.checkTranslationBanner(driver,etest,isTranslate);
            return;
        }

        WebElement translate_button=CommonUtil.getElement(driver,TRANSLATION_CONTAINER,By.tagName("a"));
        translate_button.click();
        CommonWait.waitTillHidden(translate_button);

        ChatHistoryTests.checkTranslationBanner(driver,etest,isTranslate);
    }

    public static boolean isTranscriptTranslated(WebDriver driver)
    {
        if(CommonWait.isPresent(driver,TRANSLATION_CONTAINER))
        {
            String translation_container_text=CommonUtil.getElement(driver,TRANSLATION_CONTAINER).getText();

            if(translation_container_text.contains(ResourceManager.getRealValue("view_original")))
            {
                return true;
            }
            else if(translation_container_text.contains(ResourceManager.getRealValue("view_translated")))
            {
                return false;
            }
            else
            {
                throw new ZohoSalesIQRuntimeException("Invalid translation banner state, innerText : "+translation_container_text);
            }
        }
        else
        {
            return false;
        }
    }

    public static void selectActionFromDropdown(WebDriver driver,String action)
    {
        WebElement dropdown=CommonUtil.getElement(driver,ACTIONS_CONTAINER,CHAT_ACTION_DROPDOWN);
        dropdown.click();
        HandleCommonUI.chooseFromDropdown(dropdown,action,false,false);
    }

    public static void openVisitorInfo(WebDriver driver)
    {
        ChatWindow.openVisitorInfo(driver);
    }

    public static Hashtable<String,String> getAllVisitorInfo(WebElement info_container)
    {
        Hashtable<String,String> visitor_data=new Hashtable<String,String>();

        List<WebElement> table_rows=info_container.findElements(By.tagName("tr"));

        for(WebElement table_row : table_rows)
        {
            visitor_data.putAll( getVisitorInfoFromTableRowElement(table_row) );
        }

        return visitor_data;
    }

    public static Hashtable<String,String> getAllVisitorInfo(WebDriver driver)
    {
        WebElement info_container=CommonUtil.getElement(driver,INFO_CONTAINER);
        return getAllVisitorInfo(info_container);
    }

    public static Hashtable<String,String> getVisitorInfoFromTableRowElement(WebElement table_row)
    {
        Hashtable<String,String> visitor_data=new Hashtable<String,String>();

        final By label=By.className("label");

        List<WebElement> table_datas=table_row.findElements(By.tagName("td"));

        String key=null,value=null;

        for(int i=0;i<table_datas.size();i++)
        {
            WebElement table_data=table_datas.get(i);


            if((i%2)==0)
            {
                key=null;

                if(CommonUtil.hasClass(table_data,label))
                {
                    key=table_data.getText().trim();
                }
                else
                {
                    throw new ZohoSalesIQRuntimeException("class '"+CommonUtil.getByValue(label)+"' was NOT found in visitor info key webelement");
                }
            }
            else
            {
                value=null;

                if(!CommonUtil.hasClass(table_data,label))
                {
                    value=table_data.getText().trim();
                }
                else
                {
                    throw new ZohoSalesIQRuntimeException("class '"+CommonUtil.getByValue(label)+"' was found in visitor info value webelement");
                }
            }

            if(key!=null && value!=null)
            {
                visitor_data.put(key,value);
            }
        }

        return visitor_data;
    }

    public static boolean clickChatHistoryInCustomerActionsContainer(WebDriver driver)
    {
        WebElement chat_history_anchor_tag=CommonUtil.getElement(driver,CHAT_HISTORY_ANCHOR_CONTAINER,By.tagName("h1"),By.tagName("a"));
        chat_history_anchor_tag.click();
        return CommonWait.waitTillHidden(chat_history_anchor_tag);   
    }

    public static boolean openChatView(WebDriver driver,String view_icon_id)
    {
        ChatWindow.openChatView(driver,view_icon_id);
        return isChatViewOpened(driver,view_icon_id);
    }

    public static WebElement getCurrentChatViewContainer(WebDriver driver)
    {
        List<WebElement> containers=driver.findElements(CURRENT_CHAT_VIEW_CONTAINER);
        return CommonUtil.getVisibileWebElementFromList(containers);        
    }

    public static boolean isChatViewOpened(WebDriver driver,String view_id)
    {
        WebElement chat_view_container=getCurrentChatViewContainer(driver);
        String chat_view_container_type=chat_view_container.getAttribute("oprname");
        return CommonUtil.isEquals(view_id,chat_view_container_type);
    }

    public static String getAgentName(WebDriver driver)
    {
        WebElement chat_view_container=getCurrentChatViewContainer(driver);
        return CommonUtil.getElement(chat_view_container,AGENT_MESSAGE).getAttribute("innerText").trim();
    }
}
