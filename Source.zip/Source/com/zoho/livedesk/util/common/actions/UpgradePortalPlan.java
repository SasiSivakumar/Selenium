//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.Cleanup;
import org.openqa.selenium.support.ui.Select;
import com.zoho.livedesk.util.ChatUtil;

public class UpgradePortalPlan
{
    public static final String
    BASIC="2206",
    PROFESSIONAL="2207",
    ENTERPRISE="2208";

    public static final String
    PAYMENTS_ADMIN_CONSOLE="https://payments.localzoho.com/store/admin.do",
    SALESIQ_SELECT_VALUE="2201",
    SOID_SELECT_VALUE="zoid",
    YEAR="YEAR",
    INTERNAL_USAGE="2"
    ;

    public static final By
    PRODUCT_DROPDOWN=By.id("service"),
    SEARCH_KEY=By.id("searchKey"),
    SEARCH_BUTTON=By.id("searchBtn"),
    UPDATE_BUTTON=By.cssSelector("[action='Update']"),
    PAY_PERIOD_DROPDOWN=By.className("payPeriod"),
    PLAN_DROPDOWN=By.className("plan"),
    REASON_DROPDOWN=By.id("nonStoreReasondropdown"),
    DESCRIPTION=By.cssSelector("[id^='adminDescription']"),
    SUCCESS_POPUP=By.id("ConfirmPopupBtn"),
    ADD_PROFILE=By.cssSelector("[value='Add Profile']")
    ;

    public static boolean upgrade(WebDriver driver)
    {
        return upgrade(driver,ENTERPRISE);
    }

    public static boolean upgrade(WebDriver driver,String plan)
    {
        if(Util.isLocalBuild()==false)
        {
            //no supported for non local deployments
            return false;
        }

        ExtentTest etest=null;
        WebDriver admin_driver=null;
        int failcount=0;

        try
        {
            String SOID=ExecuteStatements.getSOID(driver);
            String PORTAL=ExecuteStatements.getPortal(driver);

            etest=ComplexReportFactory.getTest("Upgrade plan for "+PORTAL+", SOID : "+SOID);
            ComplexReportFactory.setValues(etest,"Cleanup","Cleanup");

            admin_driver=Functions.setUp();
            Functions.login(admin_driver,"admin_console");
            admin_driver.get(PAYMENTS_ADMIN_CONSOLE);

            CommonWait.waitTillDisplayed(admin_driver,PRODUCT_DROPDOWN);

            WebElement dropdown_container=CommonUtil.getElement(admin_driver,PRODUCT_DROPDOWN);
            select(dropdown_container,SALESIQ_SELECT_VALUE);

            dropdown_container=CommonUtil.getElement(admin_driver,SEARCH_KEY);
            select(dropdown_container,SOID_SELECT_VALUE);

            CommonUtil.getElement(admin_driver,By.id("searchValue")).sendKeys(SOID);

            CommonUtil.getElement(admin_driver,SEARCH_BUTTON).click();
            CommonWait.waitTillDisplayed(admin_driver,By.id(SALESIQ_SELECT_VALUE));

            dropdown_container=CommonUtil.getElement(admin_driver,PAY_PERIOD_DROPDOWN);
            CommonUtil.inViewPort(dropdown_container);
            select(dropdown_container,YEAR);

            dropdown_container=CommonUtil.getElement(admin_driver,PLAN_DROPDOWN);
            CommonUtil.inViewPort(dropdown_container);
            select(dropdown_container,plan);

            dropdown_container=CommonUtil.getElement(admin_driver,REASON_DROPDOWN);
            CommonUtil.inViewPort(dropdown_container);
            select(dropdown_container,INTERNAL_USAGE);

            CommonUtil.getElement(admin_driver,DESCRIPTION).sendKeys("for automation");

            CommonUtil.getElement(admin_driver,DESCRIPTION).sendKeys("for automation");

            WebElement add_profile=CommonUtil.getElement(admin_driver,ADD_PROFILE);
            CommonUtil.inViewPort(add_profile);
            CommonWait.waitTillDisplayed(add_profile);
            add_profile.click();

            CommonWait.waitTillDisplayed(admin_driver,SUCCESS_POPUP);

            TakeScreenshot.infoScreenshot(admin_driver,etest);

            CommonUtil.sleep(5000);

            etest.log(Status.PASS,"Plan "+plan+" was successfully activated for portal "+PORTAL);

            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"Plan");
            TakeScreenshot.infoScreenshot(driver,etest);
            HandleCommonUI.clickPositivePopupButton(popup);

            driver.navigate().refresh();

            ComplexReportFactory.closeTest(etest);

            ChatUtil.postToAutomationDevChannel("Portal '"+PORTAL+"' (SOID : "+SOID+") was renewed to plan "+plan+" automatically");
        }
        catch(Exception e)
        {
            failcount++;
            e.printStackTrace();
        }

        try
        {
            Functions.logout(admin_driver);
        }
        catch(Exception e1)
        {

        }

        try
        {
            if(CommonUtil.returnResult(failcount)==false)
            {
                etest.log(Status.FAIL,plan+" was NOT successfully activated.");
            }

            ComplexReportFactory.closeTest(etest);
        }
        catch(Exception e2)
        {

        }

        TakeScreenshot.infoScreenshot(driver,etest);
        TakeScreenshot.infoScreenshot(admin_driver,etest);

        return CommonUtil.returnResult(failcount);
    }

    public static void select(WebElement select_tag,String value)
    {
        Select select = new Select(select_tag);
        select.selectByValue(value);
    }
}
