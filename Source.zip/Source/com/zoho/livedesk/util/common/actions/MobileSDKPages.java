//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.google.common.base.Function;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.MobileSDK.MobileSDK;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

public class MobileSDKPages {

 public static String bundleID = "com.livedesk.com";
 static String label = CommonUtil.getUniqueMessage();
 static String mailid = CommonUtil.getUniqueMessage() + "@" + label + ".com";
 public static final String
 DELETE_ICONS_CLASS_1 = "sqico-delico";
 public static final By
 DELETE_ICONS_1 = By.className(DELETE_ICONS_CLASS_1);

 public static void clickLiveChatMobile(WebDriver driver, ExtentTest etest) throws Exception {
  FluentWait wait = CommonUtil.waitreturner(driver, 20, 250);

  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@boxname='livechatmobile']//em[contains(@class,'emhico')]")));
  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@boxname='livechatmobile']//em[contains(@class,'emhico')]")));

  CommonUtil.elfinder(driver, "xpath", "//div[@boxname='livechatmobile']//em[contains(@class,'emhico')]").click();

  final WebElement page = CommonUtil.elfinder(driver, "tagname", "body");

  wait.until(new Function < WebDriver, Boolean > () {
   public Boolean apply(WebDriver driver) {
    if (page.getAttribute("innerHTML").contains("sdk_topdiv")) {
     return true;
    }
    return false;
   }
  });

  wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sdk_topdiv")));
  wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sdk_topdiv")));

  etest.log(Status.INFO, "Live chat mobile config is clicked");
 }

 public static void gotoSDKHome(WebDriver driver) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_home"));
  CommonUtil.clickWebElement(driver, By.id("sdk_home"));
 }

 public static boolean isSDKHomepageRHSDescriptionFound(WebDriver driver, ExtentTest etest) {
  gotoSDKHome(driver);
  CommonWait.waitTillDisplayed(driver, By.className("sdk_heading"));
  String actual = CommonUtil.getElement(driver, By.className("sdk_heading")).getText();
  String expected = ResourceManager.getRealValue("mobileSDK-RHS");
  return CommonUtil.checkStringContainsAndLog(expected, actual, "RHS_Description", etest);

 }

 public static boolean isSDKHomepageLHSDescriptionHeaderFound(WebDriver driver, ExtentTest etest) {
  gotoSDKHome(driver);
  CommonWait.waitTillDisplayed(driver, By.id("sdk_middle_tile"));
  String actual = CommonUtil.getElement(driver, By.id("sdk_middle_tile")).findElement(By.className("emconfig_heding")).getText();
  String expected = ResourceManager.getRealValue("mobileSDK-LHSHeading");
  return CommonUtil.checkStringContainsAndLog(expected, actual, "LHS_Description", etest);
 }


 public static boolean isIOSpageLHSDescriptionFound(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_ios_home"));
  String actual = CommonUtil.getElement(driver, By.className("emconfig_heding")).getText();
  String expected = ResourceManager.getRealValue("mobileIOS-LHSHeading");
  return CommonUtil.checkStringContainsAndLog(expected, actual, "LHS_Heading", etest);
 }

 public static boolean isIOSpageLHSsubDescriptionFound(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_ios_home"));
  String actual = CommonUtil.getElement(driver, By.className("emconfig_subheding")).getText();
  String expected = ResourceManager.getRealValue("mobileIOS-LHSSubHeading");
  return CommonUtil.checkStringContainsAndLog(expected, actual, "LHSSubHeading", etest);
 }

 public static boolean isAndriodpageLHSDescriptionFound(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_android_home"));
  String actual = CommonUtil.getElement(driver, By.className("emconfig_heding")).getText();
  String expected = ResourceManager.getRealValue("mobileAndriod-LHSHeading");
  return CommonUtil.checkStringContainsAndLog(expected, actual, "LHSSubHeading", etest);
 }

 public static boolean isAndriodpageLHSsubDescriptionFound(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_android_home"));
  String actual = CommonUtil.getElement(driver, By.className("emconfig_subheding")).getText();
  String expected = ResourceManager.getRealValue("mobileAndriod-LHSSubHeading");
  return CommonUtil.checkStringContainsAndLog(expected, actual, "LHSSubHeading", etest);
 }



 public static boolean isGenerateTokenButtonEnablesIOS(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_bundle_id"));
  if (CommonWait.isPresent(driver, By.className("emconfig_disablebtn"))) {
   etest.log(Status.INFO, "Generate Token button is Disabled");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
  etest.log(Status.FAIL, "Generate Token button is Disabled");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Generate Button", "Exception");
  return false;

 }


 public static boolean isGenerateTokenButtonEnablesAndriod(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_package"));
  if (CommonWait.isPresent(driver, By.className("emconfig_disablebtn"))) {
   etest.log(Status.PASS, "Generate Token button is Disabled");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
  etest.log(Status.FAIL, "Generate Token button is Enabled");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Generate Button-Enabled", "Exception");
  return false;

 }

 public static void clickGenerateButtonIOS(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("sdk_bundle_id"));
  WebElement enterBundleID = CommonUtil.getElement(driver, By.id("sdk_bundle_id"));
  CommonUtil.sendKeysToWebElement(driver, enterBundleID, bundleID);
  etest.log(Status.INFO, "Input data -BundleID is given");
  TakeScreenshot.infoScreenshot(driver, etest);
  CommonUtil.clickWebElement(driver, By.id("sdk_generatebtn"));
  etest.log(Status.INFO, "Generate Button Clicked");
 }
 public static void clickGenerateButtonAndriod(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_package"));
  WebElement enterBundleID = CommonUtil.getElement(driver, By.id("sdk_package"));
  CommonUtil.sendKeysToWebElement(driver, enterBundleID, bundleID);
  etest.log(Status.INFO, "Input data -BundleID is given");
  TakeScreenshot.infoScreenshot(driver, etest);
  CommonUtil.clickWebElement(driver, By.id("sdk_generatebtn"));
  etest.log(Status.INFO, "Generate Button Clicked");
 }

 public static boolean checkTokenGeneratedDetailsPresent(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_middletile_container"));
  CommonWait.waitTillDisplayed(driver, By.id("sdk_tokens"));

  String actual_text = CommonUtil.getElement(driver, By.id("sdk_website")).getText();
  String expected_text = "Token generated for ";

  if (CommonUtil.isEquals(expected_text, actual_text)) {
   etest.log(Status.INFO, "Token Generated text displays");
   return true;
  }

  String actual_bundleid = CommonUtil.getElement(driver, By.className("emconfig_bundleid")).getText();
  String expected_bundleid = bundleID;

  if (CommonUtil.isEquals(expected_bundleid, actual_bundleid)) {
   etest.log(Status.INFO, "BundleID '" + bundleID + "' is present");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }else {
  etest.log(Status.FAIL, "Token Generated for bundleID :" + bundleID + " is not present");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Token Generated details", "Not Found - Exception");
  return false;
  }
 }

 public static boolean checkAppKeyPresent(WebDriver driver, ExtentTest etest) {
  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_appkeyhead"))) {
   CommonWait.waitTillDisplayed(driver, By.id("sdk_appkey"));
   etest.log(Status.INFO, "App key is Generted and Displayed");
   return true;
  }
  etest.log(Status.FAIL, "App key is not Generted ");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "App Key", "Not Found - Exception");
  return false;
 }
 public static boolean checkAccessKeyPresent(WebDriver driver, ExtentTest etest) {
  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='accesskey']"))) {
   CommonWait.waitTillDisplayed(driver, By.id("sdk_accesskey"));
   etest.log(Status.INFO, "Access key is Generted and Displayed");
   return true;
  }
  etest.log(Status.FAIL, "Access key is not Generted ");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Access key", "Not Found - Exception");
  return false;
 }

 public static boolean isRegenerateButtonFound(WebDriver driver) {
  return CommonWait.isPresent(driver, By.id("sdk_regenerate"));
 }

 public static boolean clickRegenerteButton(WebDriver driver, ExtentTest etest) {

  if (CommonWait.isPresent(driver, By.id("sdk_regenerate"))) {
   CommonUtil.clickWebElement(driver, By.id("sdk_regenerate"));
   etest.log(Status.INFO, "Regenerate Button Clicked");
   return true;
  } else {
   etest.log(Status.FAIL, "Regenerate Button not found and not Clicked");
   TakeScreenshot.screenshot(driver, "Mobile SDK", "Regeneration", "Exception");
   return false;
  }

 }

 public static boolean checkIsSinglAccessKey(WebDriver driver, ExtentTest etest) { 
	    CommonWait.waitTillDisplayed(driver, By.id("sdk_tokens"));
	    CommonWait.waitTillDisplayed(driver, By.id("sdk_singleaccess"));
	    	etest.log(Status.INFO, "Single Access Key for a Token Found");
	    	TakeScreenshot.infoScreenshot(driver, etest);	   
	    return true;
 }
	 
 
	
 public static void clickSingleAccessMail(WebDriver driver, ExtentTest etest) {
	 CommonWait.waitTillDisplayed(driver, By.id("sdk_mail"));
	 CommonUtil.clickWebElement(driver, By.id("sdk_mail"));
     CommonWait.waitTillDisplayed(driver, By.id("sdk_mailwindow"));
     etest.log(Status.PASS, "Single Access Key Found");  
	 TakeScreenshot.infoScreenshot(driver, etest);
 }



 public static boolean checkRegenerateAccesskeyOne(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_multipleaccess"));
  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_accesstokens"))) {
   WebElement accesskey1 = CommonUtil.getElement(driver, By.id("sdk_accesskey1"));
   CommonUtil.mouseHover(driver, accesskey1);
   etest.log(Status.INFO, "Access Key Regenerated (Regeneration-One)");
   return true;
  }
  etest.log(Status.FAIL, "Regenerated Access key not Found");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Acess key", "Exception");
  return false;
 }

 public static boolean checkRegenerateAccesskeyTwo(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_multipleaccess"));
  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_accesstokens"))) {
   WebElement accesskey2 = CommonUtil.getElement(driver, By.id("sdk_accesskey2"));
   CommonUtil.mouseHover(driver, accesskey2);
   etest.log(Status.INFO, "Access Key Regenerated (Regeneration-Two)");
   return true;
  }
  etest.log(Status.FAIL, "Regenerated Access key not Found");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Acess key", "Exception");
  return false;
 }

 public static boolean checkRegenerateAccesskeyThree(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_multipleaccess"));
  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_accesstokens"))) {
   WebElement accesskey3 = CommonUtil.getElement(driver, By.id("sdk_accesskey3"));
   CommonUtil.mouseHover(driver, accesskey3);
   etest.log(Status.INFO, "Access Key Regenerated (Regeneration-Three)");
   return true;
  }
  etest.log(Status.FAIL, "Regenerated Access key not Found");
  TakeScreenshot.screenshot(driver, "Mobile SDK", "Acess key", "Exception");
  return false;
 }



 public static boolean enableDisablekeys(WebDriver driver, ExtentTest etest) {


  if (checkRegenerateAccesskeyOne(driver, etest)) {
   if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='sdk_accesskey1'][class$=with_bdr]"))) {
    etest.log(Status.INFO, "Enable Icon is Found - Token is Enabled ");
    TakeScreenshot.infoScreenshot(driver, etest);
    CommonUtil.getElement(driver, By.id("sdk_accesskey1")).findElement(By.className("sqico-enable")).click();
    CommonUtil.clickWebElement(driver, By.id("okbtn"));
    etest.log(Status.INFO, "Disable Icon is Found - Token Disabled");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='sdk_accesskey1'][class$=emconfig_disable]"))) {
    etest.log(Status.INFO, "Disable Icon is Found - Token is Disabled ");
    TakeScreenshot.infoScreenshot(driver, etest);
    CommonUtil.getElement(driver, By.id("sdk_accesskey1")).findElement(By.className("sqico-disable")).click();
    CommonUtil.clickWebElement(driver, By.id("okbtn"));
    etest.log(Status.INFO, "Enable Icon is Found  Token Enabled");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
  }

  if (checkRegenerateAccesskeyTwo(driver, etest)) {

   if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='sdk_accesskey2'][class$=with_bdr]"))) {
    etest.log(Status.INFO, "Enable Icon is Found - Token is Enabled ");
    TakeScreenshot.infoScreenshot(driver, etest);
    CommonUtil.getElement(driver, By.id("sdk_accesskey2")).findElement(By.className("sqico-enable")).click();
    CommonUtil.clickWebElement(driver, By.id("okbtn"));
    etest.log(Status.INFO, "Disable Icon is Found = Token Disabled");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='sdk_accesskey2'][class$=emconfig_disable]"))) {
    etest.log(Status.INFO, "Disable Icon is Found - Token is Disabled ");
    TakeScreenshot.infoScreenshot(driver, etest);
    CommonUtil.getElement(driver, By.id("sdk_accesskey2")).findElement(By.className("sqico-disable")).click();
    CommonUtil.clickWebElement(driver, By.id("okbtn"));
    etest.log(Status.INFO, "Enable Icon is Found  Token Enabled");
    return true;
   }
   
  if (MobileSDKPages.checkIsSinglAccessKey(driver, etest)) {
	   if (CommonWait.waitTillDisplayed(driver, By.className("sqico-enable"))) {
	    etest.log(Status.INFO, "Enable Icon is Found - Token is Enabled ");
	    TakeScreenshot.infoScreenshot(driver, etest);
	    CommonUtil.clickWebElement(driver, By.id("sdk_libstatus"));
	    CommonUtil.clickWebElement(driver, By.id("okbtn"));
	    etest.log(Status.INFO, "Disable Icon is Found = Token Disabled");
	    TakeScreenshot.infoScreenshot(driver, etest);
	   } else if (CommonWait.waitTillDisplayed(driver, By.className("sqico-disable"))) {
	    etest.log(Status.INFO, "Disable Icon is Found - Token is Disabled ");
	    TakeScreenshot.infoScreenshot(driver, etest);
	    CommonUtil.clickWebElement(driver, By.id("sdk_libstatus"));
	    CommonUtil.clickWebElement(driver, By.id("okbtn"));
	    etest.log(Status.INFO, "Enable Icon is Found  Token Enabled");
	    TakeScreenshot.infoScreenshot(driver, etest);
	    return true;
	   } else {
	    etest.log(Status.FAIL, "Enable and Disable keys is not displayed");
	    TakeScreenshot.screenshot(driver, "Mobile SDK", "Enable Disable Keys ", "Exception");
	    return false;
	   }
	  }
  }
  return false;
 }



 public static boolean deletekeys(WebDriver driver, ExtentTest etest) {

  if (MobileSDKPages.checkRegenerateAccesskeyOne(driver, etest)) {

   CommonUtil.getElement(driver, By.id("sdk_accesskey1")).findElement(By.className("sqico-delico")).click();
   etest.log(Status.INFO, "Delete Button is Found and Clicked ");
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.clickWebElement(driver, By.id("okbtn"));
   etest.log(Status.PASS, "Access Key 1 is Deleted");
   TakeScreenshot.infoScreenshot(driver, etest);

  }
  if (MobileSDKPages.checkRegenerateAccesskeyTwo(driver, etest)) {
   CommonUtil.getElement(driver, By.id("sdk_accesskey2")).findElement(By.className("sqico-delico")).click();
   etest.log(Status.INFO, "Delete Button is Found and Clicked ");
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.clickWebElement(driver, By.id("okbtn"));
   etest.log(Status.PASS, "Access Key 2 is Deleted");
   TakeScreenshot.infoScreenshot(driver, etest);

  }
  if (MobileSDKPages.checkRegenerateAccesskeyThree(driver, etest)) {
   CommonUtil.getElement(driver, By.id("sdk_accesskey3")).findElement(By.className("sqico-delico")).click();
   etest.log(Status.INFO, "Delete Button is Found and Clicked ");
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.clickWebElement(driver, By.id("okbtn"));
   etest.log(Status.PASS, "Access Key 3 is Deleted");
   TakeScreenshot.infoScreenshot(driver, etest);

  }

  if (MobileSDKPages.checkIsSinglAccessKey(driver, etest)) {
   CommonWait.isPresent(driver, By.id("sdk_singleaccess"));
   CommonUtil.clickWebElement(driver, By.id("sdk_libdelete"));
   etest.log(Status.INFO, "Delete Button is Found and Clicked ");
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.clickWebElement(driver, By.id("okbtn"));
   etest.log(Status.PASS, "Single Acess Key is Deleted");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
  return false;

 }

 public static void sentMailTemplate(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("sdk_mailwindow"));

  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='emmail_main']"))) {
   etest.log(Status.INFO, "Mail Template Found");
   WebElement sentmailID = CommonUtil.getElement(driver, By.id("sdk_toemail"));
   CommonUtil.sendKeysToWebElement(driver, sentmailID, mailid);
   CommonWait.waitTillDisplayed(driver, By.id("sdk_sendmail"));
   CommonUtil.clickWebElement(driver, By.id("sdk_sendmail"));
   etest.log(Status.INFO, "Mail Sent Successfully");
   TakeScreenshot.infoScreenshot(driver, etest);
  }
 }


 public static boolean isAdvancedSettingShowPresent(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("sdk_showsettings"));
  CommonUtil.clickWebElement(driver, By.id("sdk_showsettings"));
  etest.log(Status.INFO, "Advanced Settings Displayed");
  TakeScreenshot.infoScreenshot(driver, etest);
  return CommonWait.waitTillDisplayed(driver, By.id("sdk_advsettings"));
 }

 public static boolean isAdvancedSettingPresent(WebDriver driver, ExtentTest etest) {

  if (isAdvancedSettingShowPresent(driver, etest)) {
   if (CommonWait.waitTillDisplayed(driver, By.id("sdk_environment"))) {
    etest.log(Status.INFO, "Advanced Settings displays");
   } else {
    etest.log(Status.FAIL, "Advanced Settings not displayed");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings ", "Exception");
    return false;
   }  
  }
  return false;
 }



 public static boolean enablePushNotificationIOS(WebDriver driver, ExtentTest etest) {

  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='production_noti_status'][class$='set_off']"))) {
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.clickWebElement(driver, By.id("production_noti_status"));
   etest.log(Status.INFO, "Push Notification ON");
   TakeScreenshot.infoScreenshot(driver, etest);
   return CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='production_noti_status'][class$='set_on']"));
  }
  return false;
 }

 public static boolean checkAPNsinPushNotificationIOS(WebDriver driver, ExtentTest etest) {

  if(!enablePushNotificationIOS(driver, etest)) {
	  etest.log(Status.FAIL, "Push notification is not Enabled");
	  TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings-Push Notification ", "Exception");
      return false;
  }
  CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver, By.id("production_pushnoti_container")));
  if (CommonWait.waitTillDisplayed(driver, By.id("production_pushnoti_container"))) {
   CommonWait.waitTillDisplayed(driver, By.id("sdk_apncert"));
   etest.log(Status.INFO, "APN Certificate (P12) Upload link Found");
  }

  String actual1 = CommonUtil.getElement(driver, By.id("sdk_prodapncert")).getText();
  String expected1 = ResourceManager.getRealValue("pushnotificationAPNCertificate");
  if (CommonUtil.isEquals(expected1, actual1)) {
   CommonUtil.clickWebElement(driver, By.id("sdk_prodapncert"));
   etest.log(Status.PASS, "APN Certificate Generate Section Displays");
   TakeScreenshot.infoScreenshot(driver, etest);
   return CommonWait.waitTillDisplayed(driver, By.id("sdk_prodprocedurehide"));
  }

  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_production_password"))) {
   WebElement password = CommonUtil.getElement(driver, By.id("sdk_production_password"));
   CommonUtil.sendKeysToWebElement(driver, password, label);
   etest.log(Status.PASS, "APN Password Section Displays");
  }

  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_production_noregdevices"))) {
   CommonUtil.clickWebElement(driver, By.linkText("How to Register?")); 
   etest.log(Status.PASS, "How to Register section is Displayed");
   TakeScreenshot.infoScreenshot(driver, etest);
   return  CommonWait.waitTillDisplayed(driver, By.id("sdk_production_hideinstructions"));
  }

  if (CommonWait.waitTillDisplayed(driver, By.id("production_testmsg"))) {
	  CommonSikuli.findInWholePage(driver, "mobileSDKIOS_textmessage.png", "MOBSDK17", etest);
   WebElement message = CommonUtil.getElement(driver, By.id("production_testmsg"));
   CommonUtil.sendKeysToWebElement(driver, message, label);
   CommonUtil.clickWebElement(driver, By.id("sdk_testnoti"));
   etest.log(Status.PASS, "Message Box Displays and Works");
   TakeScreenshot.infoScreenshot(driver, etest);
   
  }

  return false;
 }

 public static boolean enablePushNotificationAndriod(WebDriver driver, ExtentTest etest) {

  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='sdk_noti_status'][class$='set_off']"))) {
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.clickWebElement(driver, By.id("sdk_noti_status"));
   etest.log(Status.INFO, "Push Notification ON");
   TakeScreenshot.infoScreenshot(driver, etest);
  return CommonWait.waitTillDisplayed(driver, By.cssSelector("[id='sdk_noti_status'][classs$='set_on']"));
  }
  return false;
 }
 public static boolean checkAPNsinPushNotificationAndriod(WebDriver driver, ExtentTest etest) {

  if(enablePushNotificationAndriod(driver, etest)) {
	  etest.log(Status.FAIL, "Push notification is not Enabled");
	  TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings-Push Notification ", "Exception");
      return false;
  }
  CommonUtil.scrollIntoView(driver, CommonUtil.getElement(driver, By.id("sdk_generategcm")));
  String actual1 = CommonUtil.getElement(driver, By.id("sdk_generategcm")).getText();
  String expected1 = ResourceManager.getRealValue("pushNotificationFCMCertificate");
  if (CommonUtil.isEquals(expected1, actual1)) {
   CommonUtil.clickWebElement(driver, By.id("sdk_generategcm"));
   etest.log(Status.PASS, "FCM Certificate Generate Section Displays");
   TakeScreenshot.infoScreenshot(driver, etest);
   return CommonWait.waitTillDisplayed(driver, By.className("emconfig_hidelink"));
  }

  if (CommonWait.waitTillDisplayed(driver, By.id("gcm_password"))) {
   WebElement password = CommonUtil.getElement(driver, By.id("gcm_password"));
   CommonUtil.sendKeysToWebElement(driver, password, label);
   etest.log(Status.PASS, "FCM Password Section Displays");
   return true;
  }

  if (CommonWait.waitTillDisplayed(driver, By.id("sdk_production_noregdevices"))) {
   CommonUtil.clickWebElement(driver, By.linkText("How to Register?"));
   etest.log(Status.PASS, "How to Register section is Displayed");
   TakeScreenshot.infoScreenshot(driver, etest);
   return CommonWait.waitTillDisplayed(driver, By.id("sdk_production_hideinstructions"));
  }

  if (CommonWait.waitTillDisplayed(driver, By.id("production_testmsg"))) {
   CommonSikuli.findInWholePage(driver, "mobileSDKAndriod_textmessage.png", "MOBSDK18", etest);
   WebElement message = CommonUtil.getElement(driver, By.id("production_testmsg"));
   CommonUtil.sendKeysToWebElement(driver, message, label);
   CommonUtil.clickWebElement(driver, By.id("sdk_testnoti"));
   etest.log(Status.PASS, "Message Box Displays and Works");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }

  return false;
 }


 public static void saveAdvancedNotifiction(WebDriver driver) {
  CommonUtil.clickWebElement(driver, By.id("sdk_savesettings"));
 }



 public static void clickLearntoInstallLink(WebDriver driver, ExtentTest etest) {
  if (CommonWait.isPresent(driver, By.id("sdk_right_tile"))) {
	  CommonUtil.clickWebElement(driver, By.id("sdk_install"));
   etest.log(Status.INFO, "Learn to Install Link Clicked");
   TakeScreenshot.infoScreenshot(driver, etest);  
  }    
 }

 public static boolean isLearnToInstallPageFoundIOS(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.className("api-content-inner-wrap"));
  String actualTitle = driver.getTitle();
  String expectedTitle = ResourceManager.getRealValue("learnToInstallPageTitleIOS");
  return CommonUtil.checkStringContainsAndLog(actualTitle, expectedTitle, "", etest);
 }


 public static boolean isLearnToInstallPageFoundAndriod(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.className("api-content-inner-wrap"));
  String actualTitle = driver.getTitle();
  String expectedTitle = ResourceManager.getRealValue("learnToInstallPageTitleAndriod");
  return CommonUtil.checkStringContainsAndLog(actualTitle, expectedTitle, "", etest);
 }

 public static boolean clickShowChatButton(WebDriver driver, ExtentTest etest) {
  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='sdk_smprv']"))) {
   CommonUtil.clickWebElement(driver, By.id("sdk_livechat"));
   etest.log(Status.INFO, "Show Chat Button is Clicked");
   return true;
  }
  return false;
 }

 public static boolean clickHideChatButton(WebDriver driver, ExtentTest etest) {
  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='sdk_smprv']"))) {
   CommonUtil.clickWebElement(driver, By.id("sdk_tracking"));
   etest.log(Status.INFO, "Hide Chat Button is Clicked");
   return true;
  }
  return false;
 }


}