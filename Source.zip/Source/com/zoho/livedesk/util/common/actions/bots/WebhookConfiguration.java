//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class WebhookConfiguration
{
    public static final String
    WEBHOOK="Webhook"
    ;

    public static final By
    HEADER=By.id("platformheader"),
    URL_INPUT=By.id("webhookurl"),
    UPDATE_URL_BUTTON=By.id("urlaction_button"),
    URL_STATUS=By.className("wh_status"),
    URL_ACTIVATED=By.className("sqico-tick"),
    URL_ERROR=By.className("sqico-del"),
    INTRO_CONTAINER=By.cssSelector(".lH22.font15"),
    INSTRUCTIONS_CONTAINER=By.className("webhk-intro"),
    SECURE_WEBHOOK_INSTRUCTIONS_CONTAINER=By.cssSelector(".lH26.c666"),
    PUBLISH=By.id("botpublish"),
    SECURE_WEBHOOK_TOGGLE=By.id("enable_security"),
    PUBLIC_KEY_CONTAINER=By.className("emconfig_genkey"),
    USED_FLAG=By.className("genkey-inuse"),
    PUBLIC_KEY=By.cssSelector("[documentclick='copyCode']"),
    DELETE_KEY=By.id("key_delete"),
    GENERATE_KEY=By.id("generate_key"),
    COPY_TO_CLIPBOARD=By.cssSelector("[documentclick='copyWebhookKey']")
    ;

    public static void close(WebDriver driver)
    {
    	DelugeScript.close(driver);
    }

    public static boolean waitTillPageLoads(WebDriver driver)
    {
    	CommonWait.waitTillDisplayed(driver,HEADER);
    	WebElement header_ele=CommonUtil.getElement(driver,HEADER);
    	return CommonUtil.waitTillTextFound(driver,header_ele,WEBHOOK);
    }

    public static Boolean setURL(WebDriver driver,ExtentTest etest,String url)
    {
    	CommonUtil.scrollIntoView(driver,URL_INPUT);
    	CommonWait.waitTillDisplayed(driver,URL_INPUT);
    	WebElement input=CommonUtil.getElement(driver,URL_INPUT);
    	CommonUtil.click(driver,input);
    	CommonUtil.sendKeysToWebElement(driver,input,url);
    	WebElement button=CommonUtil.getElement(driver,UPDATE_URL_BUTTON);
    	CommonUtil.click(driver,button);
    	CommonWait.waitTillHidden(button);
    	return isURLActivated(driver,etest);
    }

    public static Boolean isURLActivated(WebDriver driver,ExtentTest etest)
    {
    	WebElement status_element=CommonUtil.getElement(driver,URL_STATUS);
    	String current_url=getCurrentURL(driver);

    	if(CommonUtil.hasClass(status_element,URL_ACTIVATED))
    	{
    		etest.log(Status.INFO,"URL "+current_url+" is activated.");
    		return true;
    	}
    	else if(CommonUtil.hasClass(status_element,URL_ERROR))
    	{
    		etest.log(Status.INFO,"URL "+current_url+" is NOT activated. Error is shown");
    		return false;
    	}
    	else
    	{
    		etest.log(Status.INFO,"URL "+current_url+" activation itself not started. Update/Create button may not have been clicked");
    		return null;
    	}
    }

    public static String getCurrentURL(WebDriver driver)
    {
    	return CommonUtil.getElement(driver,URL_INPUT).getAttribute("value");
    }

    public static void publish(WebDriver driver)
    {
    	CommonWait.waitTillDisplayed(driver,PUBLISH);
    	WebElement publish=CommonUtil.getElement(driver,PUBLISH);
    	CommonUtil.click(driver,PUBLISH);
    	CommonWait.waitTillHidden(publish);
    }

    public static boolean verifyIntroductionContent(WebDriver driver,ExtentTest etest)
    {
    	int failcount=0;

    	String actual=CommonUtil.getElement(driver,INTRO_CONTAINER).getAttribute("innerText");
    	String expected=ResourceManager.getRealValue("webhook_intro");

        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"webhook introduction",etest))
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean verifyInstructionContent(WebDriver driver,ExtentTest etest)
    {
    	int failcount=0;

    	String actual=CommonUtil.getElement(driver,INSTRUCTIONS_CONTAINER).getAttribute("innerText");

    	String expected=ResourceManager.getRealValue("webhook_inst1");
        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"webhook instruction 1",etest))
        {
            failcount++;
        }

    	expected=ResourceManager.getRealValue("webhook_inst2");
        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"webhook instruction 2",etest))
        {
            failcount++;
        }

    	expected=ResourceManager.getRealValue("webhook_inst3");
        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"webhook instruction 3",etest))
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean verifySecureWebhookContent(WebDriver driver,ExtentTest etest)
    {
    	int failcount=0;

    	String actual=CommonUtil.getElement(driver,SECURE_WEBHOOK_INSTRUCTIONS_CONTAINER).getAttribute("innerText");
    	String expected=ResourceManager.getRealValue("webhook_secure");

        if(!CommonUtil.checkStringContainsAndLog(expected,actual,"secure your webhook content",etest))
        {
            failcount++;
        }

        return CommonUtil.returnResult(failcount);
    }

    public static void setSecureToggle(WebDriver driver,ExtentTest etest,boolean isEnable)
    {
        WebElement toggle=CommonUtil.getElement(driver,SECURE_WEBHOOK_TOGGLE);
        HandleCommonUI.setToggle(toggle,isEnable);
        etest.log(Status.INFO,"'Secure your webhook' toggle is "+( (isEnable)?"enabled":"disabled" ) );
    }

    public static void copyKeyToClipboard(WebDriver driver,ExtentTest etest,boolean in_use)
    {
        WebElement container=getPublicKeyContainer(driver,in_use);
        WebElement copy_icon=CommonUtil.getElement(container,COPY_TO_CLIPBOARD);

        CommonUtil.click(driver,copy_icon);
        etest.log(Status.INFO,(in_use?"Current in-use key":"Unused key")+"was copied to clipboard");
    }

    public static String getUsedPublicKey(WebDriver driver,ExtentTest etest)
    {
        String key=CommonUtil.getElement( getPublicKeyContainer(driver,true) ,PUBLIC_KEY).getAttribute("innerText");
        etest.log(Status.INFO,"Public key in-use was found as "+key);
        return key;
    }

    public static String getUnusedPublicKey(WebDriver driver,ExtentTest etest)
    {
        String key=CommonUtil.getElement( getPublicKeyContainer(driver,false) ,PUBLIC_KEY).getAttribute("innerText");
        etest.log(Status.INFO,"Public key in-use was found as "+key);
        return key;
    }

    public static boolean createKey(WebDriver driver,ExtentTest etest)
    {
        WebElement generate_key=CommonUtil.getElement(driver,GENERATE_KEY);

        if(generate_key==null)
        {
            etest.log(Status.INFO,"COULD NOT CREATE NEW KEY AS CREATE KEY BUTTON WAS NOT FOUND");
            return false;
        }

        CommonUtil.click(driver,generate_key);

        etest.log(Status.INFO,"New key was created.");

        return CommonWait.waitTillHidden(generate_key);
    }

    public static boolean deleteKey(WebDriver driver,ExtentTest etest,boolean in_use)
    {
        WebElement container=getPublicKeyContainer(driver,in_use);
        WebElement delete=CommonUtil.getElement(container,DELETE_KEY);

        if(delete==null)
        {   
            etest.log(Status.INFO,"COULD NOT DELETE KEY AS DELETE BUTTON WAS NOT FOUND");
        }

        CommonUtil.click(driver,delete);

        etest.log(Status.INFO,(in_use?"Current in-use key":"Unused key")+"was deleted.");

        return CommonWait.waitTillHidden(container);
    }

    public static boolean isInUseFlagFoundForCurrentKey(WebDriver driver,ExtentTest etest)
    {
        WebElement container=getPublicKeyContainer(driver,true);

        if(CommonWait.isPresent(container,USED_FLAG))
        {
            etest.log(Status.PASS,"Used flag was found for currently used key");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"Used flag was NOT found for currently used key");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }

    public static WebElement getPublicKeyContainer(WebDriver driver,boolean in_use)
    {
        List<WebElement> containers=CommonUtil.getElements(driver,PUBLIC_KEY_CONTAINER);

        for(WebElement container : containers)
        {
            if(CommonWait.isPresent(container,USED_FLAG) && in_use)
            {
                return container;
            }
            else if(!CommonWait.isPresent(container,USED_FLAG) && !in_use)
            {
                return container;
            }
        }

        throw new ZohoSalesIQRuntimeException("Could NOT find public key with in-use : "+in_use);
    }
}
