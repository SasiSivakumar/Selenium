//$Id$
package com.zoho.livedesk.util.common.actions.Apps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;

public class AppsEdit
{
    /*Objects*/


    /*Constants*/
    private static final By
    SETTINGS_ICON=By.className("fsiq-settings"),
    DESC=By.id("description"),
    DEPARTMENT_COUNT_BUTTON=By.className("app-deprtmnt"),
    NAME_DESC_CONTAINER=By.className("info-field"),
    SHOW_SETTING=By.cssSelector("[documentclick='showSettings']"),
    PRIVACY_CONFIG=By.cssSelector("[data-key='privacy']"),
    WAITING_CONFIG=By.cssSelector("[data-key='general']:not([class*='deprtmnt'])")
    ;

    public static final String
    PAGE="'Apps edit'"
    ;

    public static final String
    INSTALLATION_ONCLICK="installation",
    COMPONENTS_ONCLICK="components",
    MESSENGER_ONCLICK="messanger",
    RESPONSE_ONCLICK="response",
    EMAIL_SIGNATURE_ONCLICK="emailconfig"
    ;

    /*Methods*/
    public static boolean waitTillLoads(WebDriver driver)
    {
    	return CommonWait.waitTillDisplayed(driver,SETTINGS_ICON);
    }

    public static boolean close(WebDriver driver)
    {
    	return AppsCommonElements.clickClose(driver);
    }
    
    public static String getAppDescription(WebDriver driver)
    {
        return CommonUtil.getElement(driver,DESC).getAttribute("innerText").trim();
    }

    public static boolean clickAppName(WebDriver driver)
    {
        WebElement app_name=CommonUtil.getElement(driver,NAME_DESC_CONTAINER,SHOW_SETTING);
        CommonUtil.clickWebElement(driver,app_name);
        return AppsSettings.waitTillLoads(driver);
    }

    public static boolean clickAppDescription(WebDriver driver)
    {
        WebElement app_desc=CommonUtil.getElement(driver,DESC);
        CommonUtil.clickWebElement(driver,app_desc);
        return AppsSettings.waitTillLoads(driver);
    }

    public static boolean clickPrivacyConfig(WebDriver driver)
    {
        WebElement ele=CommonUtil.getElement(driver,PRIVACY_CONFIG);
        CommonUtil.clickWebElement(driver,ele);
        return AppsSettings.waitTillLoads(driver);
    }

    public static boolean clickWaitingConfig(WebDriver driver)
    {
        WebElement ele=CommonUtil.getElement(driver,WAITING_CONFIG);
        CommonUtil.clickWebElement(driver,ele);
        return AppsSettings.waitTillLoads(driver);
    }

    public static boolean clickSettingsIcon(WebDriver driver)
    {
        WebElement ele=CommonUtil.getElement(driver,SETTINGS_ICON);
        CommonUtil.clickWebElement(driver,ele);
        return AppsSettings.waitTillLoads(driver);
    }

    public static boolean clickDeparmentCountButton(WebDriver driver)
    {
        WebElement department_count_button=CommonUtil.getElement(driver,DEPARTMENT_COUNT_BUTTON);
        CommonUtil.clickWebElement(driver,department_count_button);
        return AppsSettings.waitTillLoads(driver);
    }
    
    public static boolean openInstallationMenu(WebDriver driver,ExtentTest etest)
    {
        return clickMenuBox(driver,etest,INSTALLATION_ONCLICK);
    }
    public static boolean openComponentsMenu(WebDriver driver,ExtentTest etest)
    {
        return clickMenuBox(driver,etest,COMPONENTS_ONCLICK);
    }
    public static boolean openMessengerMenu(WebDriver driver,ExtentTest etest)
    {
        return clickMenuBox(driver,etest,MESSENGER_ONCLICK);
    }
    public static boolean openResponseMenu(WebDriver driver,ExtentTest etest)
    {
        return clickMenuBox(driver,etest,RESPONSE_ONCLICK);
    }
    public static boolean openEmailSignatureMenu(WebDriver driver,ExtentTest etest)
    {
        return clickMenuBox(driver,etest,EMAIL_SIGNATURE_ONCLICK);
    }

    public static boolean clickMenuBox(WebDriver driver,ExtentTest etest,String onclick_uniques_value)
    {
        By locator=By.cssSelector(".app-lst-itm[onclick*='"+onclick_uniques_value+"']");

        WebElement menubox_inner_element=CommonUtil.getElement(driver,locator,By.tagName("p"));
        CommonUtil.inViewPort(menubox_inner_element);
        CommonUtil.clickWebElement(driver,menubox_inner_element);
        boolean isSuccess=CommonWait.waitTillHidden(menubox_inner_element);
        etest.log(Status.INFO,onclick_uniques_value+" was opened from App Edit page");
        return isSuccess;
    }
}
