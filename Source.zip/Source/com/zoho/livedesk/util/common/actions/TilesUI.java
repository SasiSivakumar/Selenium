//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.Keys;

public class TilesUI
{
    public static final String
    VISITOR_DETAILS_TEMPLATE="visitdetails_<visitor_id>";

    public static final By
    TILESUI_CONTAINER=By.id("ldsettings"),
    FLAG_CONTAINER=By.className("gb_flag");

    public static void clickVisitor(WebDriver driver,String visitor_id) throws Exception
    {
        VisitorsOnline.clickVisitor(CommonUtil.getElement(driver,By.id(visitor_id)));
        CommonWait.waitTillDisplayed(driver,TILESUI_CONTAINER);
    }

    public static WebElement getVisitorDetailsContainer(WebDriver driver,String visitor_id)
    {
        String visitor_details_id=VISITOR_DETAILS_TEMPLATE.replace("<visitor_id>",visitor_id);
        CommonWait.waitTillDisplayed(driver,By.id(visitor_details_id));
        return CommonUtil.getElement(driver,By.id(visitor_details_id));
    }

    public static String getVisitorCountry(WebDriver driver,String visitor_id)
    {
        return CommonUtil.getElement(driver,TILESUI_CONTAINER,FLAG_CONTAINER).getAttribute("title");
    }

    public static void closeTilesUI(WebDriver driver,String visitor_id)
    {
        By input_id=By.id("textarea_"+visitor_id);

        WebElement tilesui_input=CommonUtil.getElement(driver,TILESUI_CONTAINER,input_id);
        CommonUtil.mouseHover(driver,tilesui_input);
        tilesui_input.sendKeys(Keys.ESCAPE); 
        CommonWait.waitTillHidden(tilesui_input);
    }

    public static void forceCloseTilesUI(WebDriver driver)
    {
        com.zoho.livedesk.client.Tracking.CommonFunctions.closeTilesUI(driver);
    }
}
