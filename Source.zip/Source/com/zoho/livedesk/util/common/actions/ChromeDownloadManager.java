//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.SCPUtil;

public class ChromeDownloadManager
{
    public static final String
    DOWNLOADS_URL="chrome://downloads/",
    GET_LATEST_DOWNLOADED_FILE_CONTAINER="return document.querySelector('downloads-manager').shadowRoot.querySelector('#mainContainer').getElementsByTagName('downloads-item')[0].shadowRoot.querySelector('[id=content]')",
    GET_LATEST_DOWNLOADED_FILE_CONTAINER_TEXT=GET_LATEST_DOWNLOADED_FILE_CONTAINER+".innerText",
    GET_LATEST_FILE_NAME=GET_LATEST_DOWNLOADED_FILE_CONTAINER+".querySelector('[id=file-link]').innerText"
    ;

    public static void goToChromeDownloadsPage(WebDriver driver)
    {
        driver.get(DOWNLOADS_URL);
    }

    public static String getLatestDownloadedFilePath(WebDriver driver,ExtentTest etest)
    {
        return SCPUtil.getDownloadDirectory(driver)+getLatestDownloadedFileName(driver,etest);
    }

    public static String getLatestDownloadedFileName(WebDriver driver,ExtentTest etest)
    {
        return getDownloadInfo(driver,etest,GET_LATEST_FILE_NAME);
    }

    public static String getLatestDownloadText(WebDriver driver,ExtentTest etest)
    {
        return getDownloadInfo(driver,etest,GET_LATEST_DOWNLOADED_FILE_CONTAINER_TEXT);
    }

    public static String getDownloadInfo(WebDriver driver,ExtentTest etest,String script)
    {
        String old_url=driver.getCurrentUrl();

        String download_text=null;

        try
        {
            goToChromeDownloadsPage(driver);
            TakeScreenshot.infoScreenshot(driver,etest);
            download_text=(((JavascriptExecutor) driver).executeScript(script)).toString();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        driver.get(old_url);

        return download_text;
    }

    public static boolean isNewFileDownloaded(WebDriver driver,ExtentTest etest,String old_file_container_text)
    {
        String new_file=getLatestDownloadText(driver,etest);
        String old_file=old_file_container_text;

        if( (new_file!=null && old_file==null) || (old_file.equals(new_file)==false) )
        {
            etest.log(Status.PASS,"New file was downloaded.");
            return true;
        }
        else
        {
            etest.log(Status.FAIL,"New file was NOT downloaded.");
            TakeScreenshot.screenshot(driver,etest);
            return false;
        }
    }
}
