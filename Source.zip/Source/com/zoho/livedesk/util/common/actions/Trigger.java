//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.CommonWait;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class Trigger
{
    public static final By
    TRIGGER_RULES_CONTAINER=By.id("trouting"),
    TRIGGER_RULES_LIST_CONTAINER=By.id("rulelist"),
    TRIGGER_RULE_CONTAINER=By.className("data_row"),
    RULE_NAME_INPUT=By.id("ruletitle_edit"),
    BUTTONS=By.className("rg-button"),
    ENABLE_DISABLE_BUTTON_CLASS=By.className("list_status"),
    TRIGGER_RULE_EDIT_CONTAINER = By.className("rule_editmain"),
    POPUP_DIV = By.id("popupcontent"),
    TRIGGER_COUNT = By.className("sqico-trigger"),
    TRIGGER_SEEN = By.className("sqico-seen"),
    TRIGGER_REPLIED = By.className("sqico-replied"),
    TRIGGER_FAILED = By.className("sqico-failed"),
    AGENT_IMAGE = By.className("rul_uimg"),
    SENDER = By.cssSelector("[key='sendername']"),
    SENDER_MESSAGE = By.cssSelector("[key='message']"),
    TIME = By.cssSelector("[key='time']"),
    ANIMATE_TYPE = By.cssSelector("[key='animatetype']")
    ;

    public static final String
    RULEID="ruleid",
    RULEID_EDIT_MODE_CLASS="rule_sel",
    SAVE_BUTTON_ONCLICK="handleRuleUpdate",
    CANCEL_BUTTON_ONCLICK = "hideEditRule",
    ENABLE_DISABLE_BUTTON_DOCUMENT_CLICK="handleRuleStatus",
    RULE_ENABLE_CLASS="enable"
    ;

    public static final String
    TITLE="TITLE",
    EVENT_TYPE="EVENT_TYPE",
    TRIGGERED_COUNT="TRIGGERED_COUNT",
    SEEN_COUNT="SEEN_COUNT",
    REPLIED_COUNT="REPLIED_COUNT",
    FAILED_COUNT="FAILED_COUNT",
    CREATOR_ID="CREATOR_ID",
    ACTION_TYPE="ACTION_TYPE",
    SENDER_NAME="SENDER_NAME",
    SENDER_VALUE="SENDER_VALUE",
    POSITION="POSITION",
    DIRECTION="DIRECTION",
    APPID="APPID",
    ENABLED="ENABLED",
    CONDITION="CONDITION",
    SECONDS = "SECONDS"
    ;

    public static Hashtable<String,String> getInfo(WebDriver driver,String id) throws Exception
    {
        String pos = "1";
        Tab.navToITTab(driver);

        Hashtable<String,String> info=new Hashtable<String,String>();

        List<WebElement> rule_list = CommonUtil.getElement(driver,By.id("rulelist")).findElements(By.className("data_row"));

        for(int i = 0; i < rule_list.size(); i++)
        {
            if(rule_list.get(i).getAttribute("ruleid").contains(id))
            {
                pos = (i+1)+"";
                break;
            }
        }

        info.put(POSITION,pos);

        WebElement trigger_container=CommonUtil.getElement(driver,By.cssSelector("[ruleid='"+id+"']"));

        String isEnabled = (trigger_container.getAttribute("status").contains("enable"))?"true":"false";

        info.put(ENABLED,isEnabled);

        WebElement title=CommonUtil.getElement(trigger_container,By.cssSelector("[dochover='setHelpTip'][class^='f']"));

        info.put(TITLE,title.getAttribute("innerText").trim());

        info.put(TRIGGERED_COUNT,CommonUtil.getElement(trigger_container,TRIGGER_COUNT).getAttribute("innerText").trim());
        info.put(SEEN_COUNT,CommonUtil.getElement(trigger_container,TRIGGER_SEEN).getAttribute("innerText").trim());
        info.put(REPLIED_COUNT,CommonUtil.getElement(trigger_container,TRIGGER_REPLIED).getAttribute("innerText").trim());
        info.put(FAILED_COUNT,CommonUtil.getElement(trigger_container,TRIGGER_FAILED).getAttribute("innerText").trim());

        String agent_photo_src = CommonUtil.getElement(trigger_container,AGENT_IMAGE).getAttribute("src");
        String agent_id = agent_photo_src.substring(agent_photo_src.indexOf("_")+1,agent_photo_src.indexOf("/photo.ls"));

        info.put(CREATOR_ID,agent_id);

        CommonUtil.click(driver,title);
        CommonWait.waitTillDisplayed(driver,By.className("triggerevent"));

        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"trigger");

        String action_id = "action_"+id+"_div";
        String action_area = "actionarea_"+id;

        if(CommonUtil.getElement(popup,By.id(action_area)).getAttribute("innerHTML").contains("sendername"))
        {
            info.put(SENDER_NAME,CommonUtil.getElement(popup,SENDER).getAttribute("value").trim());
        }
        else
        {
            info.put(SENDER_NAME,"$");
        }

        if(CommonUtil.getElement(popup,By.id(action_area)).getAttribute("innerHTML").contains("message"))
        {
            info.put(SENDER_VALUE,CommonUtil.getElement(popup,SENDER_MESSAGE).getAttribute("value").trim());
        }
        else
        {
            info.put(SENDER_VALUE,"$");
        }

        if(CommonUtil.getElement(popup,By.id(action_area)).getAttribute("innerHTML").contains("time"))
        {
            info.put(SECONDS,CommonUtil.getElement(popup,TIME).getAttribute("value").trim());
        }
        else
        {
            info.put(SECONDS,"$");
        }

        if(CommonUtil.getElement(popup,By.id(action_area)).getAttribute("innerHTML").contains("animatetype"))
        {
            info.put(DIRECTION,CommonUtil.getElement(popup,ANIMATE_TYPE).getAttribute("value").trim());
        }
        else
        {
            info.put(DIRECTION,"$");
        }

        String app_id = CommonUtil.getElement(popup,By.id("ruleembed_edit_div"),By.className("txtelips")).getAttribute("val");

        info.put(APPID,app_id);

        info.put(CONDITION,CommonUtil.getElement(popup,By.className("col3input")).getAttribute("innerText").trim().toLowerCase());

        info.put(ACTION_TYPE,CommonUtil.getElement(popup,By.id(action_id)).getAttribute("innerText").trim().replaceAll(" ","_").toLowerCase());

        info.put(EVENT_TYPE,CommonUtil.getElement(popup,By.className("triggerevent")).getAttribute("innerText").trim().replaceAll(" ","_").replaceAll("my_","").toLowerCase().replaceAll("accesses","access"));

        cancelRule(driver,null,id);

        return info;
    }

    public static String getRuleId(WebDriver driver, int i) throws Exception
    {
        return CommonUtil.getElement(driver,TRIGGER_RULES_CONTAINER,TRIGGER_RULES_LIST_CONTAINER).findElements(TRIGGER_RULE_CONTAINER).get(i).getAttribute(RULEID);
    }
    
    public static List<WebElement> getList(WebDriver driver) throws Exception
    {
        return CommonUtil.getElement(driver,TRIGGER_RULES_CONTAINER,TRIGGER_RULES_LIST_CONTAINER).findElements(TRIGGER_RULE_CONTAINER);
    }

    public static boolean isRuleEnabled(WebDriver driver,String ruleid) throws ZohoSalesIQRuntimeException
    {
        try
        {
            return getRuleContainer(driver,ruleid).getAttribute("status").equals("enable");
        }
        catch(Exception e)
        {
            throw new ZohoSalesIQRuntimeException("Attribute 'status' could not be found at run time for ruleid:"+ruleid);
        }
    }

    public static boolean ruleExist(WebDriver driver)
    {
        FluentWait wait = CommonUtil.waitreturner(driver,2,250);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(com.zoho.livedesk.util.Cleanup.isEmptySlate(driver)==false)
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            return true;
        }
        catch(Exception e){}

        return false;
    }

    public static void clickAdd(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        ((JavascriptExecutor) driver).executeScript("document.getElementById('ldngtxt').innerHTML = '';document.getElementById('ldngtxt').className = 'loadingcntmn';");

        clickAddButtonAutomationTab(driver,"triggerstab");

        WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Select a website");

        saveRule(driver,etest,"0");

        etest.log(Status.INFO,"Trigger - add button is clicked");
    }

    public static void clickAddButtonAutomationTab(WebDriver driver,String type)
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));
        
        WebElement e = CommonUtil.getElement(driver,By.className(type)).findElement(By.id("autobtnadd")); //CommonUtil.elfinder(driver,"id","autobtnadd");
        
        if(!CommonWait.isDisplayed(e))
        {
           WebElement action=CommonUtil.getElement(driver,By.className(type)).findElement(By.className("add_btn"));
           action.click();
        }
        else
        {
            e.click(); 
        }
    }

    public static WebElement getRuleContainer(WebDriver driver,String id)
    {
        List<WebElement> rules=CommonUtil.getElement(driver,TRIGGER_RULES_CONTAINER,TRIGGER_RULES_LIST_CONTAINER).findElements(TRIGGER_RULE_CONTAINER);
        WebElement rule=CommonUtil.getElementByAttributeValue(rules,RULEID,id);
        return rule;
    }

    public static WebElement  getRuleEditContainer(WebDriver driver,String id)
    {
        WebElement rule = HandleCommonUI.getPopupByAttribute(driver,"innerHTML",id).findElement(TRIGGER_RULE_EDIT_CONTAINER);
        return rule;
    }

    public static boolean saveRule(WebDriver driver,ExtentTest etest,String id)
    {
        WebElement save_button=CommonUtil.getElementByAttributeValue( getRuleEditContainer(driver,id).findElements(BUTTONS) ,"documentclick",SAVE_BUTTON_ONCLICK );
        CommonUtil.inViewPort(save_button);
        save_button.click();
        etest.log(Status.INFO,"Rule (ruleid:"+id+") save button was clicked");
        return CommonWait.waitTillHidden(save_button);
    }

    public static boolean cancelRule(WebDriver driver,ExtentTest etest,String id)
    {
        WebElement cancel_button=CommonUtil.getElementByAttributeValue( getRuleEditContainer(driver,id).findElements(BUTTONS) ,"documentclick",CANCEL_BUTTON_ONCLICK );
        CommonUtil.inViewPort(cancel_button);
        cancel_button.click();
        if(etest != null)
        {
            etest.log(Status.INFO,"Rule (ruleid:"+id+") cancel button was clicked");
        }
        return CommonWait.waitTillHidden(cancel_button);
    }

    public static void openRuleEditView(WebDriver driver,String id)
    {
        getRuleContainer(driver,id).click();
        CommonUtil.waitTillWebElementContainsAttributeValue(getRuleContainer(driver,id),"class",RULEID_EDIT_MODE_CLASS);
    }

    public static WebElement getToggleEnableDisableButton(WebDriver driver,String ruleid)
    {
        List<WebElement> buttons=getRuleContainer(driver,ruleid).findElements(ENABLE_DISABLE_BUTTON_CLASS);
        WebElement toggle_enable_disable_button=CommonUtil.getElementByAttributeValue(buttons,"documentclick",ENABLE_DISABLE_BUTTON_DOCUMENT_CLICK);
        return toggle_enable_disable_button;
    }

    public static void toggleRuleStatus(WebDriver driver,String ruleid)
    {
        WebElement toggle_button=getToggleEnableDisableButton(driver,ruleid);
        CommonUtil.mouseHover(driver,toggle_button);
        CommonWait.waitTillDisplayed(toggle_button);
        CommonUtil.clickWebElement(driver,toggle_button);
    }

    public static void setRuleName(WebDriver driver,String id,String rule_name)
    {
        WebElement rule_name_element=getRuleEditContainer(driver,id).findElement(RULE_NAME_INPUT);
        CommonUtil.clickWebElement(driver,rule_name_element);
        CommonUtil.sendKeysToWebElement(driver,rule_name_element,rule_name);
    }

    public static void selectVisitorEvent(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,5,250);

        CommonUtil.elfinder(driver,"id","triggerevent_"+id+"_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","triggerevent_"+id+"_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Trigger","SelectVisitorEvent","Error");
    }

    public static String getVisitorEvent(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","triggerevent_"+id+"_div").getText();
    }

    public static void selectCriteria(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        selectCriteria(driver,id,action,null,etest);
    }

    public static void selectCriteria(WebDriver driver, String id, String action, String action2, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        CommonUtil.elfinder(driver,"id","prior"+id+"_col1_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","prior"+id+"_col1_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown,"id","srchtxt"),"tagname","input").sendKeys(action);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown,"tagname","ul"),"tagname","li").click();

        etest.log(Status.INFO,action+" is clicked");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("none"))
                {
                    return true;
                }

                return false;
            }
        });

        if(action.equals("Visitor Info") && action2 == null)
        {
            Thread.sleep(1000);
            
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").sendKeys("Current State");

            etest.log(Status.INFO,"Current State is entered");

            return;
        }

        if(action2 == null)
        {
            return;
        }

        if(action.equals("Visitor Info"))
        {
            Thread.sleep(1000);
            
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col4"),"classname","col4input"),"tagname","input").sendKeys(action2);

            etest.log(Status.FAIL,action2+" is entered");

            return;
        }

        Thread.sleep(1000);
        
        CommonUtil.elfinder(driver,"id","prior"+id+"_col4_div").click();

        final WebElement dropDown2 = CommonUtil.elfinder(driver,"id","prior"+id+"_col4_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown2.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        if(!action.equals("CRM Deal"))
        {
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown2,"id","srchtxt"),"tagname","input").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,dropDown2,"id","srchtxt"),"tagname","input").sendKeys(action2);
        }

        List<WebElement> list = dropDown2.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action2))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action2+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Trigger","SelectCriteria","Error");
    }

    public static String getCriteria(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col1_div").getText();
    }

    public static String getSubCriteria(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col4_div").getText();
    }

    public static void selectCondition(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        CommonUtil.elfinder(driver,"id","prior"+id+"_col2_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","prior"+id+"_col2_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Trigger","SelectCondition","Error");
    }

    public static String getCondition(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col2_div").getText();
    }

    public static Boolean selectValues(WebDriver driver, String id, String value, ExtentTest etest) throws Exception
    {
        return selectValues(driver,id,value,null,false,etest);
    }
    
    public static Boolean selectValues(WebDriver driver, String id, String value, String value2, ExtentTest etest) throws Exception
    {
        return selectValues(driver,id,value,value2,false,etest);
    }

    public static Boolean selectValues(WebDriver driver, String id, String value, Boolean dropDownPresence, ExtentTest etest) throws Exception
    {
        return selectValues(driver,id,value,null,dropDownPresence,etest);
    }

    public static Boolean selectValues(WebDriver driver, String id, String value1, String value2, Boolean dropDownPresence,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,2,250);

        WebElement e = CommonUtil.elfinder(driver,"id","prior"+id+"_col3");

        e.click();

        CommonUtil.elementfinder(driver,e,"id","col3_input1").clear();
        CommonUtil.elementfinder(driver,e,"id","col3_input1").sendKeys(value1);

        etest.log(Status.INFO,value1+" is entered in Value 1");

        CommonUtil.getElement(driver,By.id("col3_input1")).click();

        if(dropDownPresence)
        {
            final WebElement dropDown = CommonUtil.elementfinder(driver,e,"id","col3_div");

            try
            {
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("block"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return true;
            }
            catch(TimeoutException excep)
            {
                return false;
            }
        }
        else if(value2 == null)
        {
            return true;
        }
        
        CommonUtil.elementfinder(driver,e,"id","col3_input2").clear();
        CommonUtil.elementfinder(driver,e,"id","col3_input2").sendKeys(value2);

        etest.log(Status.INFO,value2+" is entered in Value 2");

        return true;
    }

    public static void selectValuesInDropDown(WebDriver driver, String id, String action, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,2,250);

        CommonUtil.elfinder(driver,"id","prior"+id+"_col3_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","prior"+id+"_col3_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });

                return;
            }
        }

        etest.log(Status.FAIL,action+" is not present");
        TakeScreenshot.screenshot(driver,etest,"Trigger","SelectValuesInDropDown","Error");
    }

    public static String getValue1(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col3"),"id","col3_input1").getAttribute("value");
    }

    public static String getValue2(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col3"),"id","col3_input2").getAttribute("value");
    }

    public static String getValueFromDropDown(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","prior"+id+"_col3_div").getText();
    }

    public static void selectAction(WebDriver driver, String id, String action, String time, ExtentTest etest) throws Exception
    {
        selectAction(driver,id,action,time,null,null,etest);
    }

    public static void selectAction(WebDriver driver, String id, String action, String time, String value, ExtentTest etest) throws Exception
    {
        selectAction(driver,id,action,time,value,null,etest);
    }

    public static void selectAction(WebDriver driver, String id, String action, String time, String value1, String value2, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);

        CommonUtil.elfinder(driver,"id","action_"+id+"_div").click();

        final WebElement dropDown = CommonUtil.elfinder(driver,"id","action_"+id+"_ddown");

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }

                return false;
            }
        });

        boolean present = false;

        List<WebElement> list = dropDown.findElements(By.tagName("li"));

        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(action))
            {
                CommonUtil.inViewPort(e);

                e.click();

                etest.log(Status.INFO,action+" is clicked");

                present = true;

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(dropDown.getAttribute("style").contains("none"))
                        {
                            return true;
                        }

                        return false;
                    }
                });
            }
        }

        if(!present)
        {
            etest.log(Status.FAIL,action+" is not present");
            TakeScreenshot.screenshot(driver,etest,"Trigger","SelectAction","Error");
            return;
        }

        List<WebElement> inputs = CommonUtil.elfinder(driver,"id","actionarea_"+id).findElements(By.className("attrigger"));

        WebElement e = inputs.get(inputs.size()-1);
        
        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,e,"tagname","input").clear();
        CommonUtil.elementfinder(driver,e,"tagname","input").sendKeys(time);

        etest.log(Status.INFO,time+" is entered");

        if(value1 != null)
        {
            e = inputs.get(0);
            
            Thread.sleep(1000);
            
            CommonUtil.elementfinder(driver,e,"tagname","input").clear();
            CommonUtil.elementfinder(driver,e,"tagname","input").sendKeys(value1);

            etest.log(Status.INFO,value1+" is entered");
        }

        if(value2 != null)
        {
            e = inputs.get(1);

            Thread.sleep(1000);
            
            CommonUtil.elementfinder(driver,e,"tagname","input").clear();
            CommonUtil.elementfinder(driver,e,"tagname","input").sendKeys(value2);

            etest.log(Status.INFO,value2+" is entered");
        }
    }
    
    public static void selectActionAnimate(WebDriver driver, String id, String value, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        
        WebElement div = CommonUtil.elfinder(driver,"id","actionarea_"+id);
        
        CommonUtil.elementfinder(driver, div, "id","undefined_div").click();
        
        final WebElement dropDown = CommonUtil.elementfinder(driver, div,"id","undefined_ddown");
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if(dropDown.getAttribute("style").contains("block"))
                           {
                               return true;
                           }
                           
                           return false;
                       }
                   });
        
        boolean present = false;
        
        List<WebElement> list = dropDown.findElements(By.tagName("li"));
        
        for(WebElement e : list)
        {
            if(e.getAttribute("innerHTML").contains(value))
            {
                CommonUtil.inViewPort(e);
                
                e.click();
                
                etest.log(Status.INFO,value+" is clicked");
                
                present = true;
                
                wait.until(new Function<WebDriver,Boolean>()
                           {
                               public Boolean apply(WebDriver driver)
                               {
                                   if(dropDown.getAttribute("style").contains("none"))
                                   {
                                       return true;
                                   }
                                   
                                   return false;
                               }
                           });
            }
        }
        
        if(!present)
        {
            etest.log(Status.FAIL,value+" is not present");
            TakeScreenshot.screenshot(driver,etest,"Trigger","SelectActionAnimate","Error");
            return;
        }
    }

    public static String getAction(WebDriver driver, String id) throws Exception
    {
        return CommonUtil.elfinder(driver,"id","action_"+id+"_div").getText();
    }

    public static String getActionTime(WebDriver driver, String id) throws Exception
    {
        WebElement e = CommonUtil.elfinder(driver,"id","actionarea_"+id);

        List<WebElement> inputs = e.findElements(By.className("attrigger"));

        WebElement f = inputs.get(inputs.size()-1);

        return CommonUtil.elementfinder(driver,f,"tagname","input").getAttribute("value");
    }

    public static String getActionValue1(WebDriver driver, String id) throws Exception
    {
        WebElement e = CommonUtil.elfinder(driver,"id","actionarea_"+id);

        List<WebElement> inputs = e.findElements(By.className("attrigger"));

        WebElement f = inputs.get(0);

        return CommonUtil.elementfinder(driver,f,"tagname","input").getAttribute("value");
    }

    public static String getActionValue2(WebDriver driver, String id) throws Exception
    {
        WebElement e = CommonUtil.elfinder(driver,"id","actionarea_"+id);

        List<WebElement> inputs = e.findElements(By.className("attrigger"));

        WebElement f = inputs.get(1);

        return CommonUtil.elementfinder(driver,f,"tagname","input").getAttribute("value");
    }
    
    public static String getActionValueAnimate(WebDriver driver, String id) throws Exception
    {
        WebElement e = CommonUtil.elfinder(driver,"id","actionarea_"+id);
        
        return CommonUtil.elementfinder(driver,e,"id","undefined_div").getText();
    }
    
    public static void deleteAllRule(WebDriver driver, ExtentTest etest)
    {
        try
        {
            Tab.navToITTab(driver);
            
            for(int i=0;i<=10;i++)
            {
                if(ruleExist(driver))
                {
                    deleteRule(driver,etest);
                }
                else
                {
                    break;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        }
    }
    
    public static void deleteRule(WebDriver driver, ExtentTest etest) throws Exception
    {
        WebElement delete_button=CommonUtil.getElement(driver,By.cssSelector("[documentclick=deleteNewRule]"));
        CommonUtil.inViewPort(delete_button);
        CommonUtil.mouseHover(driver,delete_button);
        CommonWait.waitTillDisplayed(delete_button);
        delete_button.click();
        CommonUtil.sleep(100);
        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"trigger");
        HandleCommonUI.clickPositivePopupButton(popup);
        CommonWait.waitTillHidden(delete_button);
    }
    
    public static void addTrigger(WebDriver driver,ExtentTest etest,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
        com.zoho.livedesk.client.Triggers.CommonFunctions.applyRule(driver,etest,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4);
    }
    
    public static void fillFields(WebDriver driver, ExtentTest etest, String id, String event,String ruler1,String ruler1A,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3, String actionr4, Boolean failed[]) throws Exception
    {
        if(failed[0])
        {
            selectVisitorEvent(driver,id,event,etest);Tab.clickIntelligentTrigger(driver);
        }
        
        if(failed[1])
        {
            selectCriteria(driver,id,ruler1,ruler1A,etest);Tab.clickIntelligentTrigger(driver);
        }
        
        
        if(failed[2])
        {
            selectCondition(driver,id,ruler2,etest);Tab.clickIntelligentTrigger(driver);
            
        }
        
        if(failed[3] || failed[4])
        {
            selectValues(driver,id,ruler3,ruler4,etest);Tab.clickIntelligentTrigger(driver);
        }
        
        if(failed[5] || failed[6] || failed[7] || failed[8])
        {
            if((actionr1.equals("Open chat window"))||(actionr1.equals("Glow button"))||(actionr1.equals("Show bubble"))||(actionr1.equals("Show button")))
            {
                selectAction(driver,id,actionr1,actionr2,etest);
            }
            else if(actionr1.equals("Send chat invite"))
            {
                selectAction(driver,id,actionr1,actionr2,actionr3,actionr4,etest);
            }
            else if(actionr1.equals("Animate button"))
            {
                selectAction(driver,id,actionr1,actionr2,etest);Tab.clickIntelligentTrigger(driver);
                selectActionAnimate(driver,id,actionr3,etest);
            }
        }
        
        Tab.clickIntelligentTrigger(driver);
        
        TakeScreenshot.screenshot(driver,etest,"IntelligentTrigger","Check","Before",0);
        
        Thread.sleep(10000);
        
        etest.log(Status.INFO,"Waited for 10 secs ...");
        
        Tab.clickVisitorRouting(driver);
        Tab.clickIntelligentTrigger(driver);
    }
    
    public static Boolean[] checkValues(WebDriver driver, ExtentTest etest, Status log, String id,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
        Boolean failed[] = {false,false,false,false,false,false,false,false,false};
        
        String actualVisitorEvent = getVisitorEvent(driver,id);
        String actualCriteria = getCriteria(driver,id);
        String actualConditon = getCondition(driver,id);
        String actualValue = getValue1(driver,id);
        String actualAction = getAction(driver,id);
        String actualTime = getActionTime(driver,id);
        
        String actualValue2 = null;
        String actualValue3 = null;
        String actualValue4 = null;
        
        if(ruler4 != null)
        {
            actualValue2 = getValue2(driver,id);
        }
        
        if(actionr3 != null)
        {
            if(actionr1.equals("Animate button"))
            {
                actualValue3 = getActionValueAnimate(driver,id);
            }
            else
            {
                actualValue3 = getActionValue1(driver,id);
            }
        }
        
        if(actionr4 != null)
        {
            actualValue4 = getActionValue2(driver,id);
        }
        
        String expected[] = {event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4};
        String actual[] = {actualVisitorEvent,actualCriteria,actualConditon,actualValue,actualValue2,actualAction,actualTime,actualValue3,actualValue4};
        
        for(int i = 0 ; i < actual.length; i++)
        {
            if(expected[i] == null)
            {
                continue;
            }
            
            if(!actual[i].equals(expected[i]))
            {
                etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                failed[i] = true;
            }
            else
            {
                etest.log(Status.INFO,expected[i]+" is present");
            }
        }
        
        return failed;
    }

    public static void selectActionMailingList(WebDriver driver,String rule_id)
    {
        com.zoho.livedesk.client.Triggers.CommonFunctions.selectActionMailingList(driver,rule_id);
    }

    // public static boolean isBotPresentUnderInvokeBot(WebDriver driver,ExtentTest etest,String bot_name) throws Exception
    // {
    //     Tab.navToITTab(driver);    
    //     Trigger.clickAdd(driver,etest);
    //     String id = Trigger.getRuleId(driver,0);

    //     CommonUtil.getElement(driver,By.id("action_"+id+"_div")).click();

    //     CommonWait.waitTillDisplayed(driver,By.id("action_"+id+"_ddown"));

    //     WebElement action_ddown=CommonUtil.getElement(driver,By.id("action_"+id+"_ddown"));
    //     HandleCommonUI.chooseFromDropdown(action_ddown,"Invoke Bot");

    //     CommonWait.waitTillDisplayed(driver,By.cssSelector("[ruleid='0'][documentclick='showEditRule']"),By.cssSelector("[key='bots']"));

    //     WebElement bot_list_dropdown=CommonUtil.getElement(driver, By.cssSelector("[ruleid='0'][documentclick='showEditRule']"),By.cssSelector("[key='bots']") );
    //     bot_list_dropdown.click();
        
    //     return CommonWait.isPresent(driver,By.cssSelector("li[title='"+bot_name+"']"));
    // }

}
