//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class DialogflowConfiguration
{
	public static final String
	DIALOGFLOW="Dialogflow"
	;

    public static final By
    HEADER=By.id("platformheader"),
    ACCESS_DF_CONSOLE_BUTTON=By.id("botconsole"),
    AGENT_SELECT_DROPDOWN=By.id("associate_id_dropdown"),
    AGENT_SELECT_DROPDOWN_VALUES=By.id("associate_id_dropdown_ddown"),
    TRIGGER_CONTAINER=By.className("dflow-edt-fld"),
    // ADD_TRIGGER=By.cssSelector("[data-type='addtrigger']"),
    CREATE=By.id("create"),
    EDIT=By.id("boteditor"),
    REMOVE_TRIGGER=By.cssSelector("[data-type='removetrigger']"),
    SAVE=By.id("boteditor_save"),
    CHANGE=By.id("changebotauth"),
    MANAGED_BY=By.id("botconnectedwith"),
    CONNECT_WITH_DIALOGFLOW=By.id("botconnection"),
    DIALOGFLOW_DESC=By.id("bot_desc")
    ;

    public static boolean waitTillPageLoads(WebDriver driver)
    {
    	CommonWait.waitTillDisplayed(driver,HEADER);
    	WebElement header_ele=CommonUtil.getElement(driver,HEADER);
    	return CommonUtil.waitTillTextFound(driver,header_ele,DIALOGFLOW);
    }

    public static void clickConsoleButton(WebDriver driver)
    {
        CommonWait.waitTillDisplayed(driver,ACCESS_DF_CONSOLE_BUTTON);
        WebElement button=CommonUtil.getElement(driver,ACCESS_DF_CONSOLE_BUTTON);
        CommonUtil.clickWebElement(driver,button);
    }

    public static boolean clickAccessDialogflowConsole(WebDriver driver,ExtentTest etest)
    {
        clickConsoleButton(driver);
        CommonUtil.waitTillNewTabOpens(driver,1);
        CommonUtil.switchToTab(driver,1);
        TakeScreenshot.infoScreenshot(driver,etest);
    	return Dialogflow.waitTillDialogflowPageLoads(driver);
    }

    public static boolean clickChangeButton(WebDriver driver,ExtentTest etest)
    {
    	CommonWait.waitTillDisplayed(driver,CHANGE);
    	CommonUtil.click(driver,CHANGE);
    	CommonUtil.waitTillNewTabOpens(driver,1);
    	CommonUtil.sleep(5000);
    	CommonUtil.switchToTab(driver,1);
    	TakeScreenshot.infoScreenshot(driver,etest);
    	return GmailUtil.isGoogleThirdpartyLoginPage(driver);
    }

    public static boolean isDialogflowAgentPresent(WebDriver driver,String agent_name)
    {
    	return CommonWait.isPresent(driver,By.cssSelector("li[val][title*='"+agent_name+"']"));
    }

    public static boolean selectDialogflowAgent(WebDriver driver,String agent_name)
    {
    	if(isDialogflowAgentPresent(driver,agent_name))
    	{
    		CommonUtil.click(driver,AGENT_SELECT_DROPDOWN);
    		WebElement dropdown_values=CommonUtil.getElement(driver,AGENT_SELECT_DROPDOWN_VALUES);
    		HandleCommonUI.chooseFromDropdown(dropdown_values,agent_name);
    	}
    	else
    	{
    		throw new ZohoSalesIQRuntimeException("Expected agent '"+agent_name+"' was not found in salesiq bot console");
    	}

    	return true;
    }

    public static void setTriggerMessages(WebDriver driver,ExtentTest etest,String... trigger_messages)
    {
    	// removeAllTriggers(driver);

        String json_format_text = "";
        
        for(String trigger_message : trigger_messages)
        {
            json_format_text += ",{\"text\":\""+trigger_message+"\"}";
        }
        
        json_format_text = json_format_text.replaceFirst(",", "");  // to get rid of the first ','

        String trigger_json = "{ \"replies\": [ "+json_format_text+" ] }"; // proper json format

        addTrigger(driver,etest,trigger_json);
    }

    public static void addTrigger(final WebDriver driver,ExtentTest etest,final String trigger_message)
    {
   //  	List<WebElement> triggers=CommonUtil.getElements(driver,TRIGGER_CONTAINER);
   //  	final int list_size=triggers.size();

   //  	if(CommonUtil.getElement(triggers.get(0),By.tagName("textarea")).getAttribute("value").trim().equals("")==false)
   //  	{
   //  		CommonUtil.click(driver,ADD_TRIGGER);

			// FluentWait wait=CommonUtil.waitreturner(driver,5,100);
			// wait.until(new Function<WebDriver,Boolean>()
			// {
			// 	public Boolean apply(WebDriver driver)
			// 	{
			// 		if(CommonUtil.getElements(driver,TRIGGER_CONTAINER).size()>list_size)
			// 		{
			// 			return true;
			// 		}
			// 		return false;
			// 	}
			// });    		
   //  	}
    	// triggers=CommonUtil.getElements(driver,TRIGGER_CONTAINER);
    	// WebElement trigger=triggers.get(triggers.size()-1);
        WebElement trigger=CommonUtil.getElement(driver,TRIGGER_CONTAINER);

    	WebElement trigger_input=CommonUtil.getElement(trigger,By.tagName("textarea"));

    	CommonUtil.sendKeysToWebElement(driver,trigger_input,trigger_message);

    	etest.log(Status.INFO,"'"+trigger_message+"' was added as a bot trigger message");
    }

    // public static void removeAllTriggers(WebDriver driver)
    // {	
    // 	for(int i=0;i<5;i++)
    // 	{
	   //  	List<WebElement> triggers=CommonUtil.getElements(driver,TRIGGER_CONTAINER);
	   //  	int list_size=triggers.size();
	   //  	WebElement trigger=triggers.get(triggers.size()-1);

	   //  	if(list_size<=1)
	   //  	{
	   //  		CommonUtil.getElement(trigger,By.tagName("textarea")).clear();
	   //  		break;
	   //  	}

	   //  	CommonUtil.mouseHover(driver,trigger);
	   //  	WebElement remove_button=CommonUtil.getElement(trigger,REMOVE_TRIGGER);
	   //  	CommonUtil.mouseHoverAndClick(driver,remove_button);
	   //  	CommonWait.waitTillHidden(remove_button);
    // 	}
    // }

    public static boolean clickCreateBot(WebDriver driver)
    {
    	CommonUtil.scrollIntoView(driver,CREATE);
    	CommonWait.waitTillDisplayed(driver,CREATE);
    	CommonUtil.click(driver,CREATE);
    	DelugeScript.waitTillBotUpdated(driver);
    	return CommonWait.waitTillHidden(driver,CREATE);
    }

    public static void clickEditBot(WebDriver driver)
    {
    	CommonUtil.scrollIntoView(driver,EDIT);
    	CommonWait.waitTillDisplayed(driver,EDIT);
    	CommonUtil.click(driver,EDIT);
    	DelugeScript.waitTillBotUpdated(driver);
    	CommonWait.waitTillHidden(driver,EDIT);
    	CommonWait.waitTillDisplayed(driver,AGENT_SELECT_DROPDOWN);
    }

    public static void clickSaveBot(WebDriver driver)
    {
    	CommonUtil.scrollIntoView(driver,SAVE);
    	CommonWait.waitTillDisplayed(driver,SAVE);
    	CommonUtil.click(driver,SAVE);
    	DelugeScript.waitTillBotUpdated(driver);
    	CommonWait.waitTillHidden(driver,SAVE);
    }

    public static boolean isBotPreviewChatInputDisplayed(WebDriver driver)
    {
    	return DelugeScript.isBotPreviewChatInputDisplayed(driver);
    }

    public static void close(WebDriver driver)
    {
    	DelugeScript.close(driver);
    }

    public static String getManagedByText(WebDriver driver)
    {
    	return CommonUtil.getElement(driver,MANAGED_BY).getAttribute("innerText");
    }

    public static boolean isConnectWithDialogflowButtonShown(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,CONNECT_WITH_DIALOGFLOW);
    }

    public static boolean clickConnectWithDialogflow(WebDriver driver,ExtentTest etest)
    {
        WebElement connect=CommonUtil.getElement(driver,CONNECT_WITH_DIALOGFLOW);
        CommonWait.waitTillDisplayed(driver,CONNECT_WITH_DIALOGFLOW);
        CommonUtil.click(driver,connect);
        CommonUtil.waitTillNewTabOpens(driver,1);
        CommonUtil.switchToTab(driver,1);


        CommonUtil.sleep(5000);

        driver.navigate().refresh();
        TakeScreenshot.infoScreenshot(driver,etest);
        return GmailUtil.isGoogleThirdpartyLoginPage(driver);
    }
}
