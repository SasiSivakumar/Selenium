//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class EmailSchedule
{
    public static void clickAddSchedule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));
        WebElement e = CommonUtil.elfinder(driver,"id","autobtnadd");
        if(!e.getAttribute("style").contains("none"))
        {
            e.click();
        }
        else
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addsch")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addsch")));
            CommonUtil.elfinder(driver,"id","addsch").click();
        }
        
        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
    }
    
    public static void clickScheduleInAddWindowAndDontWait(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("savedialog")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("savedialog")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","savedialog");
        e.click();
    }
    
    public static void clickScheduleInAddWindow(WebDriver driver, int i, ExtentTest etest) throws Exception
    {
        clickScheduleInAddWindowAndDontWait(driver);
        
        if(i == 0)
        {
            Tab.waitForLoading(driver,"addreportsscheduler.do",etest);
        }
        else
        {
            Tab.waitForLoading(driver,"updatereportsscheduler.do",etest);
        }
        
        waitTillDialogBoxGoesInvisible(driver);
    }
    
    public static void waitTillDialogBoxGoesInvisible(WebDriver driver) throws Exception
    {
        int i = 1;
        
        while(i++ <= 10)
        {
            try
            {
                Tab.clickEmailSchedule(driver);
                
                break;
            }
            catch(WebDriverException e)
            {
                if(i == 10)
                {
                    throw e;
                }
            }
            
            Thread.sleep(500);
        }
    }
    
    public static void clickCancelInAddWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("savedialog")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("savedialog")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"css","div.cnfmbtm.mrgnlft_twenty");
        e.click();
        
        waitTillDialogBoxGoesInvisible(driver);
    }
    public static void clickCloseWindow(WebDriver driver) throws Exception
    {
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"classname","modal-header"),"classname","close").click();
        waitTillDialogBoxGoesInvisible(driver);
    }
    
    public static WebElement getListFromDropdowninAddNewSchedule(WebDriver driver,String listname) throws Exception
    {
        WebElement e = null;
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listdiv_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("listdiv_div")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listdiv_ddown")));
        
        if(!CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","listdiv_ddown").getAttribute("style").contains("block"))
        {
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","listdiv_div").click();
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("listdiv_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        List<WebElement> list = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","listdiv_ddown"),"tagname","ul").findElements(By.tagName("li"));
        
        for(WebElement element: list)
        {
            CommonUtil.inViewPort(element);
            if(element.getText().equals(listname))
            {
                e = element;
                break;
            }
        }
        
        return e;
    }
    
    public static void clickListFromDropdowninAddNewSchedule(WebDriver driver,String listname) throws Exception
    {
        getListFromDropdowninAddNewSchedule(driver,listname).click();
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("listdiv_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static WebElement getFrequencyFromDropdowninAddNewSchedule(WebDriver driver,String freq) throws Exception
    {
        WebElement e = null;
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("schd_range_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("schd_range_div")));
        
        if(!CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","schd_range_ddown").getAttribute("style").contains("block"))
        {
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","schd_range_div").click();
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("schd_range_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        List<WebElement> list = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","schd_range_ddown"),"tagname","ul").findElements(By.tagName("li"));
        
        for(WebElement element: list)
        {
            CommonUtil.inViewPort(element);
            if(element.getText().equals(freq))
            {
                e = element;
                break;
            }
        }
        
        return e;
    }
    
    public static void clickFrequencyFromDropdowninAddNewSchedule(WebDriver driver,String freq) throws Exception
    {
        getFrequencyFromDropdowninAddNewSchedule(driver,freq).click();
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("schd_range_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static String getFrequencyContentInBox(WebDriver driver) throws Exception
    {
        return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","schd_range_div").getText();
    }
    
    public static String getFileType(WebDriver driver) throws Exception
    {
        String filetype = "";
        
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rdfiletype")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdfiletype")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","rdfiletype");
        
        List<WebElement> list = e.findElements(By.className("uprdowrap"));
        
        for(WebElement type : list)
        {
            if(CommonUtil.elementfinder(driver,type,"tagname","span").getAttribute("class").contains("rdselected"))
            {
                filetype = CommonUtil.elementfinder(driver,type,"tagname","input").getAttribute("id");
                break;
            }
        }
        return filetype;
    }
    
    public static void selectFileType(WebDriver driver,String type) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rdfiletype")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdfiletype")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","rdfiletype"),"id",type);
        e.click();
    }
    
    public static String getClassNameForFileType(WebDriver driver,String type) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rdfiletype")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdfiletype")));
        
        WebElement e = null;
        
        List<WebElement> list =  CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","rdfiletype").findElements(By.className("uprdowrap"));
        
        for(WebElement r : list)
        {
            if(r.getText().contains(type))
            {
                e = CommonUtil.elementfinder(driver,r,"tagname","span");
            }
        }
        
        return e.getAttribute("class");
    }
    public static String getNotesinAddNewSchedule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("connector")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("connector")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("connector")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","connector").getText();
    }
    
    public static void sendKeysfortoemail(WebDriver driver,String toemail) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("toemail")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("toemail")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","toemail");
        
        e.click();
        e.clear();
        Thread.sleep(1000);
        e.sendKeys(toemail);
    }
    
    public static void clickccInAddWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("savedialog")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("savedialog")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"css","a.ccemail.lvsundrlne");
        e.click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccemailid")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ccemailid")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccemail")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ccemail")));
    }
    
    public static void sendKeysforccemail(WebDriver driver,String ccemail) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccemail")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ccemail")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","ccemail");
        
        e.click();
        e.clear();
        
        Thread.sleep(1000);
        e.sendKeys(ccemail);
    }
    
    public static String getSubject(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("subject")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("subject")));
        
        WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"id","subject");
        
        System.out.println("readonly:"+e.getAttribute("readonly"));
        
        if(e.getAttribute("readonly").equals("readonly") || e.getAttribute("readonly").equals("true"))
        {
            return e.getAttribute("value");
        }
        return "Subject is editable";
    }
    
    public static String getBodyContent(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"classname","ze_area"));
        
        WebElement e = CommonUtil.elfinder(driver,"tagname","body");
        String bodyContent = e.getAttribute("innerHTML");
        System.out.println(bodyContent);
        
        driver.switchTo().defaultContent();
        return bodyContent;
    }
    
    public static void setBodyContent(WebDriver driver,String content) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"classname","ze_area"));
        
        WebElement e = CommonUtil.elfinder(driver,"tagname","body");
        e.click();
        e.clear();
        e.sendKeys(content);
        
        driver.switchTo().defaultContent();
    }
    
    public static String getSubjectFromList(WebDriver driver,WebElement e) throws Exception
    {
        return CommonUtil.elementfinder(driver,e,"css","span.txtelips.dsply_inblk").getText();
    }
    
    public static String getScheduleContentInLists(WebDriver driver,WebElement e) throws Exception
    {
        String s = "";
        
        s = getSubjectFromList(driver,e);
        
        s += "#"+CommonUtil.elementfinder(driver,e,"css","div.list_cell.txtelips").getText();
        
        s += "#"+CommonUtil.elementfinder(driver,e,"css","div.list_cell.txtelips.schfrq").getText();
        
        s += "#"+CommonUtil.elementfinder(driver,e,"css","div.list_cell.txtelips.schcrby").getText();
        
        return s;
    }
    
    public static String getScheduleContentInUpdate(WebDriver driver) throws Exception
    {
        String s = "";
        
        s = getSubject(driver);
        
        s += "#"+getBodyContent(driver);
        
        s += "#"+getFrequencyContentInBox(driver);
        
        s += "#"+getFileType(driver);
        
        System.out.println("Contents in Update Schedule Window:"+s);
        
        return s;
    }
    
    public static WebElement lastScheduleInList(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        Tab.clickEmailSchedule(driver);
        
        List<WebElement> list = CommonUtil.elfinder(driver,"id","schedulerwrap").findElements(By.className("list-row"));
        
        return list.get(list.size()-1);
    }
    
    public static boolean clickDelete(WebDriver driver,ExtentTest etest) throws Exception
    {
        return clickDelete(driver,lastScheduleInList(driver),etest);
    }
    
    public static boolean clickDelete(WebDriver driver,WebElement e,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        String actual[] = {"header","desc","okbtn","cancelbtn"};
        
        for(int i = 0;i<actual.length;i++)
        {
            actual[i] = ResourceManager.getRealValue("delete_schedule_"+actual[i]);
        }
        
        actual[1] = actual[1].replace("$LIST$","\""+getSubjectFromList(driver,e)+"\"");
        
        final int initial = CommonUtil.elfinder(driver,"id","schedulerwrap").findElements(By.className("list-row")).size();
        
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+e.getLocation().y+"-300)");
        
        CommonUtil.elementfinder(driver,e,"classname","deletescr").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));
        
        final WebElement dialog = CommonUtil.elfinder(driver,"id","popupdiv");
        
        String header = CommonUtil.elementfinder(driver,dialog,"classname","lvd_popuptitle").getText();
        String desc = CommonUtil.elementfinder(driver,dialog,"id","popupdesc").getText();
        String okbtn = CommonUtil.elementfinder(driver,dialog,"id","okbtn").getText();
        String cancelbtn = CommonUtil.elementfinder(driver,dialog,"id","cancelbtn").getText();
        
        String expected[] = {header,desc,okbtn,cancelbtn};
        
        for(int i = 0;i< 4;i++)
        {
            if(!actual[i].equals(expected[i]))
            {
                etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]);
                return false;
            }
        }
        
        CommonUtil.elementfinder(driver,dialog,"id","okbtn").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!dialog.isDisplayed())
                {
                    return true;
                }
                return false;
            }
        });
        
        Tab.waitForLoading(driver,"deletereportsscheduler.do",etest);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(initial-1 == 0)
                    {
                        WebElement e = driver.findElement(By.id("schedulerwrap"));
                        if(e.getText().contains(ResourceManager.getRealValue("no_schedule_header")))
                        {
                            return true;
                        }
                    }
                    else if(initial-1 == driver.findElement(By.id("schedulerwrap")).findElements(By.className("list-row")).size())
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });
        
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0)");
        
        return true;
    }
    
    public static String frequencyInList(String freq)
    {
        switch(freq)
        {
            case "Every day":return "Daily";
            case "day":return "Daily";
            case "Daily":return "Daily";
            case "Every week":return "Weekly";
            case "week":return "Weekly";
            case "Weekly":return "Weekly";
            case "Every month":return "Monthly";
            case "month":return "Monthly";
            case "Monthly":return "Monthly";
        }
        
        return "Cannot determine";
    }
    
    public static boolean checkContentInScheduleList(ExtentTest etest,String actual,String subject,String toemail,String frequency,String createdBy)
    {
        ArrayList<String> list = new ArrayList<String>(Arrays.asList(actual.split("#")));
        
        frequency = frequencyInList(frequency);
        
        String[] expected = {subject,toemail,frequency,createdBy};
        
        for(int i = 0;i < list.size();i++)
        {
            if(!list.get(i).equals(expected[i]))
            {
                etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+list.get(i));
                return false;
            }
        }
        
        return true;
    }
    
    public static boolean addSchedule(WebDriver driver,ExtentTest etest,String listname,String toemail,boolean cc,String ccemail,boolean changeBody,String bodyContent,String frequency,String filetype,String username) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        Tab.clickEmailSchedule(driver);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("schedulerwrap")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("schedulerwrap")));
        
        
        int initial = 0;
        WebElement e = CommonUtil.elfinder(driver,"id","schedulerwrap");
        if(!e.getText().contains(ResourceManager.getRealValue("no_schedule_header")))
        {
            initial = e.findElements(By.className("list-row")).size();
        }
        
        clickAddSchedule(driver);
        
        clickListFromDropdowninAddNewSchedule(driver,listname);
        sendKeysfortoemail(driver,toemail);
        
        if(cc)
        {
            clickccInAddWindow(driver);
            sendKeysforccemail(driver,ccemail);
        }
        
        if(changeBody)
        {
            setBodyContent(driver,bodyContent);
        }
        
        clickFrequencyFromDropdowninAddNewSchedule(driver,frequency);
        selectFileType(driver,filetype);
        clickScheduleInAddWindow(driver,0,etest);
        
        final int finalcount = initial+1;
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(finalcount == driver.findElement(By.id("schedulerwrap")).findElements(By.className("list-row")).size())
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });
        
        String s1 = getScheduleContentInLists(driver,lastScheduleInList(driver));
        
        boolean inList = checkContentInScheduleList( etest, s1,"List of "+listname, toemail, frequency,username);
        
        return inList;
    }
}