//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;
import java.util.Arrays;
import com.zoho.livedesk.client.bots.DelugeBasic;
import java.io.*;

public class ManageConnections
{
	public static final String
	LINK_NAME="link-name",
	ZOHO_SERVICE="zoho",
	GOOGLE_SERVICE="google",
	SERVICE_CLASS="dre-service-box",
	ZOHO_CRM_SCOPE="ZohoCRM/crmapi",
	GOOGLE_CALENDAR_SCOPE="https://www.googleapis.com/auth/calendar",
    ZOHO_OAUTH="zlabs_integration",
    CRM_OAUTH_SCOPE1="ZohoCRM.modules.ALL",
    CRM_OAUTH_SCOPE2="ZohoCRM.crmapi.ALL"
	;

	public static final By
	ADD_BUTTON=By.id("dreCSAddConnectionBtn"),
	ADD_ICON=By.className("dre-util-add-icon"),
	DELETE_CONNECTION=By.className("dre-cs-ic-trash-white"),
	YES_DELETE=By.className("dre-cs-delete-btn-delete"),
	CONNECTION_ELEMENT=By.cssSelector(".dre-cxn-connection[link-name]"),
	SERVICE_ELEMENT=By.className(SERVICE_CLASS),
	CONNECTION_NAME_INPUT=By.id("dreConnectionName"),
	CREATE_CONNECTION_BUTTON=By.className("dre-cs-btn-create"),
	CLOSE_ICON=By.className("dre-util-close"),
	CONNECT_ICON=By.className("dre-cs-ic-plug-red"),
    NO_CONNECTION=By.id("dreNoConnection"),
    OAUTH_CONNECTION_SUBMIT=By.cssSelector("[onclick='submitApproveForm()']")
	;


    public static void switchToManageConnectionsTab(WebDriver driver)
    {
        CommonUtil.switchToTab(driver,1);
    }

    //click add connection
    public static void clickAddConnectionButton(WebDriver driver,ExtentTest etest)
    {
    	CommonWait.waitTillDisplayed(driver,ADD_BUTTON,ADD_ICON);
    	WebElement add_icon=CommonUtil.getElement(driver,ADD_BUTTON,ADD_ICON);
    	CommonUtil.mouseHoverAndClick(driver,add_icon);
        CommonWait.waitTillDisplayed(driver,CONNECTION_ELEMENT);
    	etest.log(Status.INFO,"Add connection button was clicked in manage connections page");
	}    

    public static WebElement getConnectionElement(WebDriver driver,String connection_name)
    {
    	return CommonUtil.getElement(driver,By.cssSelector("[link-name='"+connection_name.toLowerCase()+"']"));
    }

    //delete connection
    public static boolean deleteConnection(WebDriver driver,ExtentTest etest,String connection)
    {
    	WebElement connection_ele=getConnectionElement(driver,connection);
    	CommonUtil.mouseHover(driver,connection_ele);
    	CommonWait.waitTillDisplayed(connection_ele,DELETE_CONNECTION);
    	WebElement delete=CommonUtil.getElement(connection_ele,DELETE_CONNECTION);
    	CommonUtil.mouseHoverAndClick(driver,delete);
    	CommonWait.waitTillDisplayed(driver,YES_DELETE);
    	WebElement yes=CommonUtil.getElement(driver,YES_DELETE);
    	CommonUtil.mouseHoverAndClick(driver,yes);
    	etest.log(Status.INFO,"Connection '"+connection+"' was deleted");
    	return CommonWait.waitTillHidden(yes);
    }

    //delete all connections
    public static boolean deleteAllConnections(WebDriver driver,ExtentTest etest)
    {
    	int connection_length=CommonUtil.getElements(driver,CONNECTION_ELEMENT).size();

    	for(int i=0;i<connection_length+5;i++)
    	{

    		try
    		{
	    		WebElement connection_element=CommonUtil.getElement(driver,CONNECTION_ELEMENT);
	    		if(connection_element==null)
	    		{
	    			break;//all connections already deleted
	    		}
	    		String connection_name=connection_element.getAttribute(LINK_NAME);
	    		deleteConnection(driver,etest,connection_name);
    		}
    		catch(Exception e)
    		{
    			etest.log(Status.INFO,"Exception occured when deleting all connections");
    			TakeScreenshot.log(e,etest,Status.INFO);
    		}
    	}

    	connection_length=CommonUtil.getElements(driver,CONNECTION_ELEMENT).size();

    	if(connection_length==0)
    	{
    		etest.log(Status.PASS,"All connections were successfully deleted");
    		return true;
    	}
    	else
    	{
    		etest.log(Status.FAIL,"All connections were not successfully deleted");
    		return false;
    	}
    }

    //select connection
    public static boolean selectService(WebDriver driver,ExtentTest etest,String link_name)
    {
    	WebElement service=CommonUtil.getElement(driver,By.cssSelector("."+SERVICE_CLASS+"[link-name='"+link_name.toLowerCase()+"']"));
    	CommonUtil.inViewPortSafe(driver,service,50);
    	CommonWait.waitTillDisplayed(service);
    	CommonUtil.mouseHoverAndClick(driver, CommonUtil.getElement(service,By.tagName("img")) );
    	etest.log(Status.INFO,"Service '"+link_name+"' was opened");
    	return CommonWait.waitTillDisplayed(driver,CONNECTION_NAME_INPUT);
    }

    //set connection name
    public static void setConnectionName(WebDriver driver,ExtentTest etest,String connection_name)
    {
    	CommonUtil.sendKeysToWebElement(driver, CommonUtil.getElement(driver,CONNECTION_NAME_INPUT) ,connection_name);
    }

    //select scope
    public static void selectScope(WebDriver driver,ExtentTest etest,String scope)
    {
        CommonUtil.jsClick(driver,By.cssSelector("[value='"+scope+"']"));
    	// HandleCommonUI.setCheckbox( CommonUtil.getElement(driver,By.cssSelector("[value='"+scope+"']")) ,true );
    	etest.log(Status.INFO,"Scope was set for connection as "+scope);
    }

    //connect connection
    public static boolean clickCreateAndConnectButton(WebDriver driver,ExtentTest etest)
    {
    	CommonWait.waitTillDisplayed(driver,CREATE_CONNECTION_BUTTON);
    	WebElement connect_button=CommonUtil.getElement(driver,CREATE_CONNECTION_BUTTON);
    	CommonUtil.mouseHoverAndClick(driver,connect_button);
    	etest.log(Status.INFO,"Create and connect button was clicked");
    	return CommonWait.waitTillHidden(connect_button);
    }

    public static boolean closeOverlappingUI(WebDriver driver)
    {
    	CommonWait.waitTillDisplayed(driver,CLOSE_ICON);
    	WebElement close=CommonUtil.getElement(driver,CLOSE_ICON);
    	CommonUtil.mouseHoverAndClick(driver,close);
    	return CommonWait.waitTillHidden(close);
    }

    public static boolean connectConnection(WebDriver driver,ExtentTest etest,String connection_name,boolean isNewTab)
    {
    	if(isConnected(driver,connection_name)==false)
    	{
    		return clickConnectIcon(driver,connection_name,isNewTab);
    	}
    	else
    	{
			etest.log(Status.INFO,"Connection '"+connection_name+"' is already connected");
			return true;    		
    	}
    }

    //click accept for crm
    public static boolean clickAcceptForCRMConnection(WebDriver driver)
    {
        try
        {
            if(driver.findElement(By.tagName("body")).getAttribute("innerText").contains("Continue to sign in"))
            {
                CommonUtil.clickWebElement(driver,By.className("btn"));
            }
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }
    	return true;
		//no need    	
    }

    //click accept for google
    public static boolean clickAcceptForGoogle(WebDriver driver,ExtentTest etest)
    {
        try
        {
            if(driver.findElement(By.tagName("body")).getAttribute("innerText").contains("Continue to sign in"))
            {
                CommonUtil.clickWebElement(driver,By.className("btn"));
            }
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }
    	return GmailUtil.connectGoogleConnectionFromBots(driver,etest);
    }

    public static void clickAcceptForZohoOAuth(WebDriver driver,ExtentTest etest)
    {
        try
        {
            if(driver.findElement(By.tagName("body")).getAttribute("innerText").contains("Continue to sign in"))
            {
                CommonUtil.clickWebElement(driver,By.className("btn"));
            }
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }
        handleNewAccountUI(driver,etest);
        CommonWait.waitTillDisplayed(driver,OAUTH_CONNECTION_SUBMIT);
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonUtil.clickWebElement(driver, CommonUtil.getElement(driver,OAUTH_CONNECTION_SUBMIT) );
        etest.log(Status.INFO,"Accept button was clicked for crm oauth connection authentication");
    }

    //check if connection is connected
    public static boolean isConnected(WebDriver driver,String connection_name)
    {
    	WebElement connection=getConnectionElement(driver,connection_name);
    	CommonUtil.mouseHover(driver,connection);
    	return (CommonWait.isDisplayed(connection,CONNECT_ICON)==false);
    }

    //click connect connection button
    public static boolean clickConnectIcon(WebDriver driver,String connection_name,boolean isNewTab)
    {
    	WebElement connection=getConnectionElement(driver,connection_name);
    	CommonUtil.mouseHover(driver,connection);
    	CommonWait.waitTillDisplayed(driver,CONNECT_ICON);

    	WebElement connect_icon=CommonUtil.getElement(connection,CONNECT_ICON);

    	CommonUtil.mouseHoverAndClick(driver,connect_icon);

    	if(isNewTab)
    	{
    		CommonUtil.waitTillNewTabOpens(driver,2);
	    	return true;
    	}
    	else
    	{
    		return CommonWait.waitTillHidden(connect_icon);
    	}
    }

    public static boolean addCRMConnection(WebDriver driver,ExtentTest etest,String name)
    {
    	clickAddConnectionButton(driver,etest);
    	selectService(driver,etest,ZOHO_SERVICE);
    	setConnectionName(driver,etest,name);
    	selectScope(driver,etest,ZOHO_CRM_SCOPE);
    	clickCreateAndConnectButton(driver,etest);
    	closeOverlappingUI(driver);
    	connectConnection(driver,etest,name,false);

    	if(isConnected(driver,name)==false)
    	{
    		TakeScreenshot.screenshot(driver,etest);
    		throw new ZohoSalesIQRuntimeException("Unable to connect CRM connection. (connection-name : '"+name+"') ");
    	}

    	CommonUtil.closeCurrentTab(driver);
    	CommonUtil.switchToTab(driver);

    	etest.log(Status.PASS,"CRM connection with the name '"+name+"' was successfully created.");
        TakeScreenshot.infoScreenshot(driver,etest);

    	return true;//will throw exception if it fails
    }

    //for create lead usecase
    public static boolean addCRMConnection2(WebDriver driver,ExtentTest etest,String name)
    {
        clickAddConnectionButton(driver,etest);
        selectService(driver,etest,ZOHO_OAUTH);
        setConnectionName(driver,etest,name);
        selectScope(driver,etest,CRM_OAUTH_SCOPE1);
        // selectScope(driver,etest,CRM_OAUTH_SCOPE2);
        clickCreateAndConnectButton(driver,etest);

        boolean isNewTabOpen=false;

        try
        {
            CommonUtil.waitTillNewTabOpens(driver,2);
            isNewTabOpen=true;
        }
        catch(Exception e)
        {

        }

        if(isNewTabOpen==false)
        {
            closeOverlappingUI(driver);
            connectConnection(driver,etest,name,true);
        }

        CommonUtil.switchToTab(driver,2);

        clickAcceptForZohoOAuth(driver,etest);

        CommonUtil.waitTillTabCloses(driver,3);

        CommonUtil.switchToTab(driver,1);

        closeOverlappingUI(driver);

        if(isConnected(driver,name)==false)
        {
            TakeScreenshot.screenshot(driver,etest);
            throw new ZohoSalesIQRuntimeException("Unable to connect CRM OAuth connection. (connection-name : '"+name+"') ");
        }

        CommonUtil.closeCurrentTab(driver);
        CommonUtil.switchToTab(driver);

        etest.log(Status.PASS,"CRM OAuth connection with the name '"+name+"' was successfully created.");

        return true;//will throw exception if it fails
    }

    public static boolean addGoogleConnection(WebDriver driver,ExtentTest etest,String name)
    {
    	clickAddConnectionButton(driver,etest);
    	selectService(driver,etest,GOOGLE_SERVICE);
    	setConnectionName(driver,etest,name);
    	selectScope(driver,etest,GOOGLE_CALENDAR_SCOPE);
    	clickCreateAndConnectButton(driver,etest);

    	boolean isNewTabOpen=false;

    	try
    	{
    		CommonUtil.waitTillNewTabOpens(driver,2);
    		isNewTabOpen=true;
    	}
    	catch(Exception e)
    	{

    	}

    	if(isNewTabOpen==false)
    	{
	    	closeOverlappingUI(driver);
	    	connectConnection(driver,etest,name,true);
    	}

    	CommonUtil.switchToTab(driver,2);

    	clickAcceptForGoogle(driver,etest);

    	CommonUtil.switchToTab(driver,1);

    	if(isConnected(driver,name)==false)
    	{
    		TakeScreenshot.screenshot(driver,etest);
    		throw new ZohoSalesIQRuntimeException("Unable to connect Google connection. (connection-name : '"+name+"') ");
    	}

    	CommonUtil.closeCurrentTab(driver);
    	CommonUtil.switchToTab(driver);

    	etest.log(Status.PASS,"Google connection with the name '"+name+"' was successfully created.");

    	return true;//will throw exception if it fails
    }

    public static void handleNewAccountUI(WebDriver driver,ExtentTest etest)
    {
        boolean isNewAccountUI=false;

        try
        {
            CommonWait.waitTillPresent(driver,By.id("newAcccount"));
            isNewAccountUI=true;
        }
        catch(Exception e)
        {

        }

        if(isNewAccountUI)
        {
            etest.log(Status.INFO,"Use already existing connection UI was shown. So we are clicking 'New Account' button");
            TakeScreenshot.infoScreenshot(driver,etest);
            CommonWait.waitTillDisplayed(driver,By.id("newAcccount"));
            WebElement new_account=CommonUtil.getElement(driver,By.id("newAcccount"));
            CommonUtil.mouseHoverAndClick(driver,new_account);
            CommonWait.waitTillHidden(new_account);
            etest.log(Status.INFO,"New Account button was clicked");
        }
    }
}
