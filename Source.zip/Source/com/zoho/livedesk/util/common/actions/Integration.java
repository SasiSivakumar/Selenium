//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

public class Integration
{
	public static WebElement getIntegApp(WebDriver driver,String app) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("integ_li")));

		List<WebElement> otherapps = driver.findElements(By.className("integ_li"));
		for(WebElement e: otherapps)
		{
			CommonUtil.inViewPort(e);
			if(e.getText().contains(app))
			{
				return e;
			}
		}

		return null;
	}

	public static void selectIntegApp(WebDriver driver,final String app) throws Exception
	{
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("integhome")).getAttribute("style").contains("opacity: 1;"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("integrationmain")).getAttribute("style").contains("opacity: 1;"))
                {
                    return true;
                }
                return false;
            }
        });
        
        getIntegApp(driver,app).click();

		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("integhome")).getAttribute("style").contains("opacity: 1;"))
                {
                	return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("integrationmain")).getAttribute("style").contains("opacity: 1;"))
                {
                	return true;
                }
                return false;
            }
        });
        
        WebElement page = CommonUtil.elfinder(driver,"id","integrationmain");
        
        wait.until(ExpectedConditions.visibilityOf(page));
        
        final WebElement header = CommonUtil.elementfinder(driver,page,"classname","integ_header");
        
        wait.until(ExpectedConditions.visibilityOf(header));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(header.getText().equals("Connect with "+app))
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static boolean checkDisable(WebDriver driver) throws Exception
	{
		return checkDisable(driver,null);
	}
	public static boolean checkDisable(WebDriver driver,String app) throws Exception
	{
		String checkId;
		if(app != null && (app.equals("Zoho Desk") || app.equals("Zendesk")))
		{
			checkId = "zsuppintegdiv";
		}
		else
		{
			checkId = "disablecontainer";
		}

		WebElement div = CommonUtil.elfinder(driver,"id","rightintegbtn");
		
		WebElement button = CommonUtil.elementfinder(driver,div,"tagname","span");

		boolean result = true;

		if(div.getAttribute("innerHTML").contains("documentclick"))
		{
			if(!button.getAttribute("documentclick").equals("enableinteg"))
			{
				result = false;
			}
		}
		else if(div.getAttribute("innerHTML").contains("purpose"))
		{
			if(!button.getAttribute("purpose").equals("enableinteg"))
			{
				result = false;
			}
		}

		if(button.getText().equals("Enable") && result && button.getAttribute("class").equals("rg-button cmn_gbutclor cmn_cntbx"))
		{
			if(CommonUtil.elfinder(driver,"id",checkId).getAttribute("class").contains("crm_intgopt"))
			{
				return true;
			}
		}

		return false;
	}

	public static void clickDisableIntegration(WebDriver driver,final String banner, ExtentTest etest) throws Exception
	{
		clickDisableIntegration(driver,banner,false,null,etest);
	}
	public static void clickDisableIntegration(WebDriver driver,final String banner, String app, ExtentTest etest) throws Exception
	{
		clickDisableIntegration(driver,banner,false,app,etest);
	}
	public static void clickDisableIntegration(WebDriver driver,final String banner, Boolean popup, ExtentTest etest) throws Exception
	{
		clickDisableIntegration(driver,banner,popup,null,etest);
	}
	public static void clickDisableIntegration(WebDriver driver,final String banner, Boolean popup, String app, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightintegbtn")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightintegbtn")));

		if(checkDisable(driver,app))
		{
			return;
		}

		WebElement div = CommonUtil.elfinder(driver,"id","rightintegbtn");
		
		WebElement button = CommonUtil.elementfinder(driver,div,"tagname","span");

		button.click();

		if(popup)
		{
			PopUp.clickOkBtn(driver);
		}
		
		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                	if(checkDisable(driver,app))
                	{
                		return true;
                	}
                }
                catch(Exception e){}

                return false;
            }
        });

        Tab.waitForLoadingSuccessWithBanner(driver,banner,"disableinteg.do",etest);
	}

	public static boolean checkEnable(WebDriver driver) throws Exception
	{
		return checkEnable(driver,null);
	}

	public static boolean checkEnable(WebDriver driver,String app) throws Exception
	{
		String checkId;
		if(app != null && (app.equals("Zoho Desk") || app.equals("Zendesk")))
		{
			checkId = "zsuppintegdiv";
		}
		else
		{
			checkId = "disablecontainer";
		}

		WebElement div = CommonUtil.elfinder(driver,"id","rightintegbtn");
		WebElement button = CommonUtil.elementfinder(driver,div,"tagname","span");

		boolean result = true;

		if(div.getAttribute("innerHTML").contains("documentclick"))
		{
			if(!button.getAttribute("documentclick").equals("disableinteg"))
			{
				result = false;
			}
		}
		else if(div.getAttribute("innerHTML").contains("purpose"))
		{
			if(!button.getAttribute("purpose").equals("disableinteg"))
			{
				result = false;
			}
		}

		if(button.getText().equals("Disable") && result && button.getAttribute("class").equals("rg-button cmn_cntbx cmn_redbut"))
		{
			if(!CommonUtil.elfinder(driver,"id",checkId).getAttribute("class").contains("crm_intgopt"))
			{
				return true;
			}
		}

		return false;
	}

	public static void clickEnableIntegration(WebDriver driver,final String banner, ExtentTest etest) throws Exception
	{
		clickEnableIntegration(driver,banner,null,etest);
	}

	public static void clickEnableIntegration(WebDriver driver,final String banner,String app, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightintegbtn")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightintegbtn")));

		
		if(checkEnable(driver,app))
		{
			return;
		}

		WebElement div = CommonUtil.elfinder(driver,"id","rightintegbtn");
		WebElement button = CommonUtil.elementfinder(driver,div,"tagname","span");

		button.click();
		
		wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	            	if(checkEnable(driver,app))
	            	{
	            		return true;
	            	}
	            }
	            catch(Exception e){}

            	return false;
            }
        });

        Tab.waitForLoadingSuccessWithBanner(driver,banner,"enableinteg.do",etest);
    }

	public static void enableByDisablingOther(WebDriver driver,final String banner,int position, ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);

		if(position == 1)
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightintegbtn")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightintegbtn")));

			
			if(checkEnable(driver))
			{
				return;
			}

			WebElement div = CommonUtil.elfinder(driver,"id","rightintegbtn");
			WebElement button = CommonUtil.elementfinder(driver,div,"tagname","span");

			button.click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));

		}
		if(position == 2)
		{
			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","okbtn").click();
		
			 wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(!driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("okbtn"))
					{
						return true;
					}
	                return false;
	            }
	        });

			Tab.waitForLoadingSuccessWithBanner(driver,banner,"disableinteg.do",etest);
	    }
	}
}
