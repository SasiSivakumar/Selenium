//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.zoho.livedesk.util.common.VisitorWindow;

public class ExecuteStatements
{
  
    public static String getUserMail(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return CurrentUser.getEmailID();")).toString();
    }
    
    public static String getUserName(WebDriver driver)
    {
        return (((JavascriptExecutor) driver).executeScript("return CurrentUser.getNickname();")).toString();
    }
    
    public static String getPortal(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return PortalUI.getScreenName();")).toString();
    }
    
    public static String getRSid(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return LSMessanger.getRSid();")).toString();
    }
    
    public static String getSid(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return LSMessanger.getSid();")).toString();
    }
    public static String getPortalRegisteredStatus(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return PortalUI.register;")).toString();
    }
    public static String getUTSHandlerCounter(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return UTSHandler.counter;")).toString();
    }
    public static String getUTSHandlerPriority(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return UTSHandler.priority;")).toString();
    }
    public static String getUTSHandlerCircleWidth(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return UTSHandler.circleWidth;")).toString();
    }
    public static String getTrackingListCircleview(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return TrackingList.circleview;")).toString();
    }
    public static String getUTSHandlerIsTrackingPortal(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return UTSHandler.isTrackingPortal();")).toString();
    }
    public static String getIntegFieldCRMObject(WebDriver driver) throws Exception
    {
        return (((JavascriptExecutor) driver).executeScript("return Integ.fieldsobj.ZohoCRM;")).toString();
    }

    public static Boolean isAdministrator(WebDriver driver) throws Exception
    {
     return (Boolean) (((JavascriptExecutor) driver).executeScript("return CurrentUser.isAdministrator()"));

    }

    public static Boolean isOwner(WebDriver driver) throws Exception
    {
        return (Boolean) (((JavascriptExecutor) driver).executeScript("return CurrentUser.isOwner()"));
    }

    public static Boolean isSupervisor(WebDriver driver) throws Exception
    {
        return (Boolean) (((JavascriptExecutor) driver).executeScript("return CurrentUser.isSupervisor()"));
    }

    public static Boolean isAssociate(WebDriver driver) throws Exception
    {
        return (Boolean) (((JavascriptExecutor) driver).executeScript("return CurrentUser.isAssociate()"));
    }

    public static String getRadioValue(WebDriver driver,String radio_name)
    {
        return (((JavascriptExecutor) driver).executeScript("return document.querySelector(\"input[name='"+radio_name+"']:checked\").value;")).toString();
    }
    
    public static String getWidgetCodeFromEmbedName(WebDriver driver,String embed_name) throws Exception
    {
        /*
        Formatted script code

        function getWidgetCodeFromEmbedName(embed_name)
        {
            var websites = EmbedChats.list;
            for (var property in websites)
            {
                if (websites.hasOwnProperty(property))
                {
                    if (websites[property].UNIQUENAME == embed_name)
                    {
                        return websites[property].WIDGETCODE;
                    }
                }
            }
            return null;
        }

        return getWidgetCodeFromEmbedNameScript(embed_name);

        */
        
        String getWidgetCodeFromEmbedNameScript="function getWidgetCodeFromEmbedName(embed_name) { var websites=EmbedChats.list; for (var property in websites) { if (websites.hasOwnProperty(property)) { if(websites[property].UNIQUENAME==embed_name) { return websites[property].WIDGETCODE; } } } return null;}return getWidgetCodeFromEmbedName(\""+embed_name+"\");";
        return (((JavascriptExecutor) driver).executeScript(getWidgetCodeFromEmbedNameScript)).toString();        
    }

    public static String getEmbedNameFromWidgetCode(WebDriver driver,String code)
    {
        /*
        
        var temp_code=code

        function getEmbedNameFromWidgetCode(code)
        {
            var websites = EmbedChats.list;
            for (var property in websites)
            {
                if (websites.hasOwnProperty(property))
                {
                    if (websites[property].WIDGETCODE == code)
                    {
                        return websites[property].NAME;
                    }
                }
            }
            return null;
        }

         getEmbedNameFromWidgetCode(temp_code);
        */

        String script="function getEmbedNameFromWidgetCode(code) { var websites = EmbedChats.list; for (var property in websites) { if (websites.hasOwnProperty(property)) { if (websites[property].WIDGETCODE == code) { return websites[property].NAME; } } } return null; } return getEmbedNameFromWidgetCode(\""+code+"\");";
        return (((JavascriptExecutor) driver).executeScript(script)).toString();
    }

    public static String getWebsiteIDFromEmbedName(WebDriver driver,String embed_name) throws Exception
    {

        /*
        function getWebsiteIDFromEmbedName(embed_name)
        {
            var websites = EmbedChats.list;

            for (var property in websites)
            {
                if (websites.hasOwnProperty(property))
                {
                    if (websites[property].UNIQUENAME == embed_name)
                    {
                        return property
                    }
                }
            }
            return null;
        }

         return getWebsiteIDFromEmbedName(embed_name);
         */   

        String getWebsiteIDFromEmbedNameScript="function getWebsiteIDFromEmbedName(embed_name) { var websites = EmbedChats.list; for (var property in websites) { if (websites.hasOwnProperty(property)) { if (websites[property].UNIQUENAME == embed_name) { return property } } } return null; } return getWebsiteIDFromEmbedName('"+embed_name+"');";
        return (((JavascriptExecutor) driver).executeScript(getWebsiteIDFromEmbedNameScript)).toString();        
    }

    public static String getDepartmentID(WebDriver driver,String department_name)
    {
        /*
        Formatted script code

        function getDepartmentID(department_name)
        {
            var departments = DepartmentDB.alldepts;
            for (var property in departments)
            {
                if (departments.hasOwnProperty(property))
                {
                    if (departments[property].NAME == department_name)
                    {
                        return property;
                    }
                }
            }
            return null;
        }

        return getDepartmentID(department_name);
        */
        
        String getDepartmentIDScript="function getDepartmentID(department_name) { var departments = DepartmentDB.alldepts; for (var property in departments) { if (departments.hasOwnProperty(property)) { if (departments[property].NAME == department_name) { return property; } } } return null; } return getDepartmentID('"+department_name+"');";
        return (((JavascriptExecutor) driver).executeScript(getDepartmentIDScript)).toString();        
    }

    public static String getSystemGeneratedDepartment(WebDriver driver)
    {
        /*
        Formatted script code

        function getSystemGeneratedDepartment()
        {
            var departments = DepartmentDB.alldepts;
            for (var property in departments)
            {
                if (departments.hasOwnProperty(property))
                {
                    if (departments[property].TYPE == "SYSTEM")
                    {
                        return departments[property].NAME;
                    }
                }
            }
            return null;
        }

        return getSystemGeneratedDepartment();

        */
        
        String getSystemGeneratedDepartmentScript="function getSystemGeneratedDepartment() { var departments = DepartmentDB.alldepts; for (var property in departments) { if (departments.hasOwnProperty(property)) { if (departments[property].TYPE == 'SYSTEM') { return departments[property].NAME; } } } return null; }return getSystemGeneratedDepartment();";
        return (((JavascriptExecutor) driver).executeScript(getSystemGeneratedDepartmentScript)).toString();        
    }

    public static String getRandomDepartment(WebDriver driver)
    {
        /*
        Formatted script code

        function getRandomDepartment()
        {
            var departments = DepartmentDB.alldepts;
            for (var property in departments)
            {
                if (departments.hasOwnProperty(property))
                {
                    if (departments[property].TYPE != "SYSTEM")
                    {
                        return departments[property].NAME;
                    }
                }
            }
            return null;
        }

        return getRandomDepartment();

        */
        
        String getRandomDepartmentScript="function getRandomDepartment() { var departments = DepartmentDB.alldepts; for (var property in departments) { if (departments.hasOwnProperty(property)) { if (departments[property].TYPE != 'SYSTEM') { return departments[property].NAME; } } } return null; } return getRandomDepartment();";
        return (((JavascriptExecutor) driver).executeScript(getRandomDepartmentScript)).toString();        
    }
    
    public static String getDepartmentId(WebDriver driver,String department_name) throws Exception
    {

        /*
            function getDepartmentId(dept_name)
            {
                var departments = DepartmentDB.alldepts;
                for (var property in departments)
                {
                    if (departments.hasOwnProperty(property))
                    {
                        if (departments[property].NAME == dept_name)
                        {
                            return departments[property].DTID;
                        }
                    }
                }
                return null;
            }

             return getDepartmentId("Department Name Here");
         */   

        String getDepartmentIdScript=" function getDepartmentId(dept_name) { var departments = DepartmentDB.alldepts; for (var property in departments) { if (departments.hasOwnProperty(property)) { if (departments[property].NAME == dept_name) { return departments[property].DTID; } } } return null; } return getDepartmentId('"+department_name+"');";
        return (((JavascriptExecutor) driver).executeScript(getDepartmentIdScript)).toString();        
    }

    public static String getRandomWebsiteName(WebDriver driver) throws Exception
    {
        //returns a random website name that is not equal to default website

        /*
        Formatted script code
        function getRandomWebsiteName()
        {
            var websites = EmbedChats.list;

            for (var property in websites)
            {
                if (websites.hasOwnProperty(property))
                {
                    if (websites[property].UNIQUENAME != WelcomePageUI.embed)
                    {
                        return websites[property].UNIQUENAME;
                    }
                }
            }
            return null;
        }
        return getRandomWebsiteName();

        */
        
        String getRandomWebsiteNameScript="function getRandomWebsiteName(){var websites = EmbedChats.list;for (var property in websites){if (websites.hasOwnProperty(property)){if (websites[property].UNIQUENAME != WelcomePageUI.embed){return websites[property].UNIQUENAME;}}}return null;}return getRandomWebsiteName();";
        return (((JavascriptExecutor) driver).executeScript(getRandomWebsiteNameScript)).toString();        
    }

    public static String getRandomAssociateOperatorID(WebDriver driver) throws Exception
    {
        /*
        Formatted script code

        function getRandomAssociateOperatorID()
        {
            var reps = AgentDB.reps;

            for (var property in reps)
            {
                if (reps.hasOwnProperty(property))
                {
                    if (reps[property].ROLE=='Agent' && reps[property].EMAIL != CurrentUser.getEmailID())
                    {
                        return property;
                    }
                }
            }
            return null;
        }
        return getRandomAssociateOperatorID()
        
        */
        
        String getRandomAssociateOperatorID=" function getRandomAssociateOperatorID() { var reps = AgentDB.reps; for (var property in reps) { if (reps.hasOwnProperty(property)) { if (reps[property].ROLE=='Agent' && reps[property].EMAIL != CurrentUser.getEmailID()) { return property; } } } return null; } return getRandomAssociateOperatorID()";
        return (((JavascriptExecutor) driver).executeScript(getRandomAssociateOperatorID)).toString();        
    }

     public static String getOperatorIDByAgentName(WebDriver driver,String agentname) throws Exception
    {
        /*
        Formatted script code

        function getOperatorIDByAgentName(agentname)
        {
            var reps = AgentDB.reps;

            for (var property in reps)
            {
                if (reps.hasOwnProperty(property))
                {
                    if (reps[property].DNAME==agentname)
                    {
                        return property;
                    }
                }
            }
            return null;
        }
        return getOperatorIDByAgentName("agentname")
        */
        
        String getOperatorIDByAgentName=" function getOperatorIDByAgentName(agentname) { var reps = AgentDB.reps; for (var property in reps) { if (reps.hasOwnProperty(property)) { if (reps[property].DNAME==agentname) { return property; } } } return null; } return getOperatorIDByAgentName('"+agentname+"')";
        return (((JavascriptExecutor) driver).executeScript(getOperatorIDByAgentName)).toString();        
    }

    public static String getAgentNameByEmailID(WebDriver driver,String email) throws Exception
    {
        /*
        Formatted script code

        function getAgentNameByEmailID(email)
        {
            var reps = AgentDB.reps;

            for (var property in reps)
            {
                if (reps.hasOwnProperty(property))
                {
                    if (reps[property].EMAIL==email)
                    {
                        return reps[property].DNAME;
                    }
                }
            }
            return null;
        }
        return getAgentNameByEmailID("email")
        */
        
        String getAgentNameByEmailID="function getAgentNameByEmailID(email) { var reps = AgentDB.reps; for (var property in reps) { if (reps.hasOwnProperty(property)) { if (reps[property].EMAIL==email) { return reps[property].DNAME; } } } return null; } return getAgentNameByEmailID('"+email+"') ";
        return (((JavascriptExecutor) driver).executeScript(getAgentNameByEmailID)).toString();        
    }

    public static String getRandomAgentName(WebDriver driver) throws Exception
    {
        /*
        Formatted script code
        function getRandomAgentName()
        {
            var reps = AgentDB.reps;

            for (var property in reps)
            {
                if (reps.hasOwnProperty(property))
                {
                    if (reps[property].EMAIL != CurrentUser.getEmailID())
                    {
                        return reps[property].DNAME;
                    }
                }
            }
            return null;
        }
        return getRandomAgentName();
        */
        
        String getRandomAgentNameScript="function getRandomAgentName() { var reps = AgentDB.reps; for (var property in reps) { if (reps.hasOwnProperty(property)) { if (reps[property].EMAIL != CurrentUser.getEmailID()) { return reps[property].DNAME; } } } return null; } return getRandomAgentName();";
        return (((JavascriptExecutor) driver).executeScript(getRandomAgentNameScript)).toString();        
    }

    public static String[] getAllAgentNames(WebDriver driver)
    {
        /*
        Formatted script code
        function getAllAgentNames()
        {
            var agents="";

            var reps = AgentDB.reps;

            for (var property in reps)
            {
                if (reps.hasOwnProperty(property))
                {
                    var seperator=(agents!="")?",":"";

                   agents=reps[property].DNAME+seperator+agents;
                
                }
            }
            return agents;
        }
        return getAllAgentNames();
        */

        String getAllAgentNamesScript="function getAllAgentNames() { var agents=''; var reps = AgentDB.reps; for (var property in reps) { if (reps.hasOwnProperty(property)) { var seperator=(agents!='')?',':''; agents=reps[property].DNAME+seperator+agents; } } return agents; } return getAllAgentNames();";
        String all_agent_names=(((JavascriptExecutor) driver).executeScript(getAllAgentNamesScript)).toString();
        String[] all_agent_names_array= all_agent_names.split(",");
        return all_agent_names_array;
    }

    public static String getAttributeOfSelectedRadio(WebDriver driver,String radio_name,String attribute)
    {
        return (((JavascriptExecutor) driver).executeScript("return document.querySelector(\"[name=\'"+radio_name+"\']:checked\").getAttribute(\""+attribute+"\");")).toString();        
    }

    public static String getWidgetCode(WebDriver driver)
    {
        return (((JavascriptExecutor) driver).executeScript("return WelcomePageUI.widgetcode;")).toString();        
    }

    public static String getWidgetCodeFromVisitorSite(WebDriver visitor_driver)
    {
        return (((JavascriptExecutor) visitor_driver).executeScript("return $zoho.salesiq.widgetcode;")).toString();     
    }

    public static String getDefaultEmbedName(WebDriver driver)
    {
        return (((JavascriptExecutor) driver).executeScript("return WelcomePageUI.embed;")).toString();        
    }
    
    public static String getUserMailWithoutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getUserMail(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }
    public static String getUTSHandlerCounterWithOutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getUTSHandlerCounter(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }
    public static String getUTSHandlerPriorityWithOutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getUTSHandlerPriority(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }
    public static String getUTSHandlerCircleWidthWithOutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getUTSHandlerCircleWidth(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }
    public static String getTrackingListCircleviewWithOutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getTrackingListCircleview(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }
    public static String getUTSHandlerIsTrackingPortalWithOutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getUTSHandlerIsTrackingPortal(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }
    
    public static String getIntegFieldCRMObjectWithOutExcep(WebDriver driver) throws Exception
    {
        try
        {
            return getIntegFieldCRMObject(driver);
        }
        catch (WebDriverException e)
        {
            return "Cannot find";
        }
    }

    public static boolean isFreePlan(WebDriver driver) throws Exception
    {
        return (Boolean) (((JavascriptExecutor) driver).executeScript("return License.isFreePlan()"));
    }

    public static String getCurrentPlanName(WebDriver driver)
    {
        return (((JavascriptExecutor) driver).executeScript("return License.plannames[License.getCurrentPlanID()];")).toString(); 
    }

    public static String getZUID(WebDriver driver) throws Exception
    {
        return get(driver,"_LOGINZUID");
    }

    public static String getWMSID(WebDriver driver) throws Exception
    {
        return get(driver,"CurrentUser.getWMSID()");
    }

    public static String getPortalCreatedTime(WebDriver driver) throws Exception
    {
        return get(driver,"portalcreatedtime");
    }

    public static String getOperatorId(WebDriver driver) throws Exception
    {
        return get(driver,"CurrentUser.getLSUID()");
        
    }

    public static String getOperatorAttribute(WebDriver driver,String known_attribute,String known_attribute_value,String attribute)
    {
        /*
        function getOperatorAttribute(known_attribute, known_attribute_value, attribute)
        {

            var reps = AgentDB.reps;

            for (var rep in reps)
            {
                if (reps[rep][known_attribute] == known_attribute_value)
                {
                    return reps[rep][attribute];
                }

            }

        }
        */

        String script="function getOperatorAttribute(known_attribute, known_attribute_value, attribute) { var reps = AgentDB.reps; for (var rep in reps) { if (reps[rep][known_attribute] == known_attribute_value) { return reps[rep][attribute]; } } } return getOperatorAttribute('"+known_attribute+"','"+known_attribute_value+"','"+attribute+"');";

        return (((JavascriptExecutor) driver).executeScript(script)).toString();
    }

    public static String getPortalOwnerId(WebDriver driver) throws Exception
    {
        return get(driver,"CurrentPortal.ownerid");
    }

    public static String getPortalOwnerZUID(WebDriver driver) throws Exception
    {
        return get(driver,"AgentDB.reps[CurrentPortal.ownerid]['ZUID']");
    }

    public static int getNoOfDepartmentsInVisitorSide(WebDriver visitor_driver)
    {
        visitor_driver.switchTo().defaultContent();
        final String script="$ZSIQWidget.getEmbedObject().einfo.embedstatus.DEPTLIST.length";
        int count=Integer.parseInt(get(visitor_driver,script));
        return count;
    }

    public static String getSOID(WebDriver driver)
    {
        return get(driver,"CurrentPortal.getSOID()");
    }

    public static boolean isBotGoingToPickupChat(WebDriver visitor_driver)
    {
        //Use this only after selecting department (if department dropdown is shown)
        try
        {
            VisitorWindow.switchToChatWidget(visitor_driver);
            String script="$Support.getBotUser();";
            String bot_id=get(visitor_driver,script);

            if(bot_id!=null && !bot_id.contains("null"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }

    public static boolean isDepartmentDropdownExpectedToBeDisplayed(WebDriver visitor_driver)
    {
        try
        {
            VisitorWindow.switchToChatWidget(visitor_driver);
            String script="$Support.EmbedObj.deptlist.length";
            int count=Integer.parseInt(get(visitor_driver,script));

            if(count>1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return true;        
    }

    public static String isWMSDown(WebDriver driver)
    {
        return get(driver,"_WMSDOWN");
    }

    //Depracated due to new bots UI flow
    // public static int getWebsiteBotSetting(WebDriver visitor_driver)
    // {
    //     visitor_driver.switchTo().defaultContent();
    //     String script="JSON.parse(  $ZSIQWidget.getEmbedObject().einfo.props.isbotenabled  )[1].mode";
    //     return Integer.parseInt(get(visitor_driver,script));
    // }

    public static void openNewTab(WebDriver driver)
    {
        openNewTab(driver,Util.siteNameout());
    }

    public static void openNewTab(WebDriver driver,String url)
    {
        String script="window.open('"+url+"','_blank');";

        int current_tabs=CommonUtil.getTabsCount(driver);

        ((JavascriptExecutor) driver).executeScript(script);

        CommonUtil.waitTillNewTabOpens(driver,current_tabs);

        CommonUtil.switchToTab(driver);     
    }

    public static void loadDomainAPIJS(WebDriver driver,String code)
    {
        String script="function loadDomainWidget() { $zoho = {}; $zoho.salesiq = $zoho.salesiq || { widgetcode: '"+code+"', values: {}, ready: function() {$zoho.salesiq.domain('"+com.zoho.livedesk.util.Util.getDomainName()+"');} }; var d = document; s = d.createElement('script'); s.type = 'text/javascript'; s.id = 'zsiqscript'; s.defer = true; s.src = '"+com.zoho.livedesk.util.Util.siteNameout()+"/widget'; t = d.getElementsByTagName('script')[0]; t.parentNode.insertBefore(s, t); } loadDomainWidget()";
        run(driver,script);
    }

    public static void run(WebDriver driver,String js)
    {
        ((JavascriptExecutor) driver).executeScript(js); 
    }

    public static String get(WebDriver driver,String js)
    {
        return (((JavascriptExecutor) driver).executeScript("return "+js)).toString(); 
    }
}
