//$Id$
package com.zoho.livedesk.util.common.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.actions.*;
import com.google.common.base.Function;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Hashtable;
import com.zoho.livedesk.client.ChatRouting.ChatRoutingTests;
import com.zoho.livedesk.client.Articles.ArticlesTests;
import com.zoho.livedesk.util.common.CommonSikuli;
import java.util.Arrays;

public class Articles
{


    public static final int
    KNOWLEDGE_REPOSITORY_CHAR_LIMIT=15,
    ARTICLE_TITLE_CHAR_LIMIT=150;


    public static final String CHAR_LIMIT_TEMPLATE="$limit$ characters left";
    public static final String CHAR_LIMIT_EXCEEDED_TEXT="Character limit exceeds, only "+KNOWLEDGE_REPOSITORY_CHAR_LIMIT+" characters allowed.";
    public static final String ARTICLE_TITLE_CHAR_LIMIT_EXCEEDED_TEXT="Character limit exceeds, only "+ARTICLE_TITLE_CHAR_LIMIT+" characters allowed.";

    public static final String
    CREATED_BY="Created by $text$",
    MODIFIED_BY="Modified by $text$",
    ARTICLES_EDIT_SAVED="Draft saved",
    ARTICLES_EDIT_PUBLISHED="Updated",
    ARTICLES_MENU_TIME="Just now",
    ARTICLE_PREVIEW_CLASS="faqpreview"
    ;

    /*DOM Constants*/   
    public static final String
    ARTICLES_LOADED_CLASS="loaded",
    ARTICLE_ID_ATTRIBUTE="cannedid",
    ALL_DEPTS_TEXT="All Departments",
    WEBSITE_SETTINGS_TOGGLE_ID="FAQ_ACCESS2",
    RED_TEXT_CLASS="redtxt",
    TEXT_EDIT_ICON_SELECTED_CLASS="ze_esel",
    SELECTED_TEXT="Selected Text",
    EMAIL_ADDRESS="Email address",
    WEB_ADDRESS="Web address",
    SUBJECT="Subject",
    SYNCED_FROM_DESK="Synced from Zoho Desk",
    IS_PUBLISHED="IS_PUBLISHED"
    ;

    /*Dummy Constants*/
    public static final String
    SAVE="saved",
    PUBLISH="published",
    CANCEL="cancelled",
    NAME="NAME",
    CONTENT="CONTENT",
    CATEGORY="CATEGORY",
    TIME="TIME",
    ISDRAFT="ISDRAFT",
    VIEWS="VIEWS",
    CHATS="CHATS",
    DISLIKES="DISLIKES",
    LIKES="LIKES",
    SORT_TYPE_CHAT="CHAT",
    SORT_TYPE_VIEWS="VIEWS",
    SORT_TYPE_LIKES="LIKES",
    SORT_TYPE_DISLIKES="DISLIKES",
    SORT_DIR_ASCENDING="ASC",
    SORT_DIR_DESCENDING="DESC",
    SORTBY_ATTRIBUTE="sortby",
    SORT_DIR_ATTRIBUTE="sortdir";
    ;


    /*Agent Side*/
    public static final By
    ARTICLES_TAB=By.cssSelector("[data-tab='article']"),
    ARTICLES_CONTAINER=By.className("automationcontent"),
    ARTICLES_DESCRIPTION=By.className("innersubinfotxt"),
    ARTICLES_LIST_CONTAINER=By.id("faqlistview"),
    ARTICLE_CONTAINER=By.className("list-row"),
    EMPTY_SLATE=By.id("emptyslate"),
    ADD_BUTTON=By.id("addcannmsg"),
    EMPTY_STATE_ADD_BUTTON=By.className("add_btn"),
    ARTICLES_EDIT_CONTAINER=By.id("edu_type"),
    ARTICLE_NAME_TEXTAREA=By.id("cmsg"),
    ARTICLE_CONTENT_CONTAINER=By.id("articlewrap"),
    ARTICLE_CONTENT_FRAME=By.className("ze_area"),
    ARTICLE_TEXT_BODY=By.className("ze_body"),
    ARTICLE_DEPT_SELECT=By.id("candeptslct"),
    ARTICLE_DEPT_DROPDOWN=By.id("candeptslct_ddown"),
    ARTICLE_CATEGORY_SELECT=By.id("cannedcat"),
    ARTICLE_CATEGORY_DROPDOWN=By.id("cannedcat_ddown"),
    CATEGORY_TOGGLE=By.id("toggle"),
    CATEGORY_ADD_INPUT_CONTAINER=By.id("addcatdiv"),
    SAVE_ARTICLE_BUTTON=By.id("draft"),
    PUBLISH_ARTICLE_BUTTON=By.id("template"),
    CANCEL_ARTICLE_BUTTON=By.id("btncancel"),
    DELETE_ICON=By.className("sqico-delico"),
    WEBSITE_SETTINGS_TOGGLE=By.id(WEBSITE_SETTINGS_TOGGLE_ID),
    CATEGORISE_ARTICLE_CHECKBOX_WEBSITE_SETTINGS=By.id("faq_category"),
    EDIT_KNOWLEDGE_REPO_BUTTON=By.cssSelector("[documentclick='configedit']"),
    KNOWLEDGE_REPO_NAME_INPUT=By.id("faqname"),
    KNOWLEDGE_REPO_NAME_INPUT_CHAR_LIMIT=By.className("messagecount"),
    ARTICLE_NAME_INPUT_CHAR_LIMIT=By.id("cmessagecount"),
    ARTICLE_TITLE_HELP_ICON=By.cssSelector(".sqico-help[onmouseover*='article.subject.title']"),
    ARTICLE_CONTENT_TOOLTIP_HELP_ICON=By.cssSelector(".sqico-help[onmouseover*='article.editor.title']"),
    ARTICLE_WEBSITES_TOOLTIP_HELP_ICON=By.cssSelector(".sqico-help[onmouseover*='cannedmessages.choosewebsite.helptext']"),
    ARTICLE_DEPARTMENTS_TOOLTIP_HELP_ICON=By.cssSelector(".sqico-help[onmouseover*='cannedmessages.choosedepartment.helptext']"),
    ARTICLE_CATEGORY_TOOLTIP_HELP_ICON=By.cssSelector(".sqico-help[onmouseover*='cannedmessages.choosecategory.helptext']"),
    COMMON_TOOLTIP_CONTAINER=By.id("ldtooltip"),
    TEXT_EDIT_OPTIONS_CONTAINER=By.className("ze_SCmb"),
    BOLD_ICON=By.cssSelector("b[title*='Bold']"),
    ITALICS_ICON=By.cssSelector("b[title*='Italic']"),
    UNDERLINE_ICON=By.cssSelector("b[title*='Underline']"),
    INSERT_LINK_ICON=By.className("zei-link"),
    HORIZONTAL_LINE_ICON=By.className("zei-line"),
    PREVIEW=By.id("faqpreview"),
    INSERT_LINK_CONTAINER=By.id("ze_link"),
    INSERT_LINK_FORM_CONTAINER=By.className("ze_ptble"),
    INSERT_URL_CHECKBOX=By.id("ze_link_url"),
    INSERT_EMAIL_CHECKBOX=By.cssSelector("input#ze_link_email"),
    INSERT_LINK_BUTTON_CONTAINER=By.className("zep_PUbtm"),
    LINK_CONTAINER_OK=By.className("sel"),
    LINK_CONTAINER_CANCEL=By.cssSelector("span[data-val='Cancel']"),
    ARTICLE_TIME=By.className("agntimage"),
    DESK_ARTICLE_PREVIEW_SAVE=By.cssSelector("[documentclick='saveDeskArticle']")
    ;

    public static final By
    DRAFT_LABEL=By.className("cdraft"),
    ARTICLE_VIEWS=By.className("sqico-seen"),
    ARTICLE_CHATS=By.className("sqico-chatbubble"),
    ARTICLE_DISLIKES=By.className("sqico-dislike"),
    ARTICLE_LIKES=By.className("sqico-like"),
    ARTICLE_SAVED_INFO_CONTAINER_ARTICLE_TAB=By.className("mT15"),
    ARTICLE_SAVED_INFO_CONTAINER_ARTICLE_EDIT=By.id("canneddraft"),
    SORT_ARROW=By.className("sqico-toparrow"),
    ARTICLE_NAME_CONTAINER=By.className("cmn_wordbr"),
    ZOHODESK_ICON=By.className("zdesk")
    ;


    public static final String
    BOLD="BOLD",
    ITALIC="ITALIC",
    UNDERLINE="UNDERLINE",
    HORIZONTAL_LINE="HORIZONTAL_LINE",
    INSERT_LINK="INSERT_LINK";

    public static final int
    sort_by_chats=1,
    sort_by_views=2,
    sort_by_likes=3,
    sort_by_dislikes=4;

    /*Functions*/

    /*Get WebElements*/
    public static WebElement getArticlesTab(WebDriver driver)
    {       
        return CommonUtil.getElement(driver,ARTICLES_TAB);
    }

    public static WebElement getArticlesDescriptionContainer(WebDriver driver)
    {
        return CommonUtil.getElement(driver,ARTICLES_CONTAINER,ARTICLES_DESCRIPTION);
    }

    public static List<WebElement> getArticleContainers(WebDriver driver)
    {
        if(CommonWait.isPresent(driver,ARTICLES_LIST_CONTAINER)==false)
        {
            return new ArrayList<WebElement>();
        }

        System.out.println("getArticleContainers"+CommonUtil.getElement(driver,ARTICLES_LIST_CONTAINER).getText());

        return CommonUtil.getElement(driver,ARTICLES_LIST_CONTAINER).findElements(ARTICLE_CONTAINER);
    }

    public static WebElement getAddButton(WebDriver driver)
    {
        if(isEmptySlate(driver))
        {
            return CommonUtil.getElement(driver,EMPTY_STATE_ADD_BUTTON);   
        }
        else
        {
            return CommonUtil.getElement(driver,ADD_BUTTON);
        }
    }  

    public static WebElement getArticleNameInputTag(WebDriver driver)
    {
        return CommonUtil.getElement(driver,ARTICLE_NAME_TEXTAREA);
    }

    public static WebElement getArticleContentContainer(WebDriver driver)
    {
        return CommonUtil.getElement(driver,ARTICLE_CONTENT_CONTAINER);
    }

    public static Hashtable<String,String> getArticleDataByLabel(String label)
    {
        Hashtable<String,String> article_data=new Hashtable<String,String>();

        article_data.put(NAME,"art"+label);
        article_data.put(CONTENT,"content"+label);
        article_data.put(CATEGORY,"category"+label);

        return article_data;
    }

    public static WebElement getArticleContainerByName(WebDriver driver,String name)
    {
        return CommonUtil.getElementByAttributeValue( getArticleContainers(driver) ,"innerText",name);
    }

    public static WebElement getTooltip(WebDriver driver) throws ZohoSalesIQRuntimeException
    {
        //The tooltip container would not exist in DOM if no tooltips have been triggered. So this funciton returns the tooltip container if it exists.else it hovers over the article name help icon and returns the tooltip container after it has been created in DOM.

        WebElement tooltip=CommonUtil.getElement(driver,COMMON_TOOLTIP_CONTAINER);

        if(tooltip==null)
        {   
            CommonUtil.mouseHover(driver, CommonUtil.getElement(driver,ARTICLE_TITLE_HELP_ICON) );
            CommonUtil.sleep(50);
            tooltip=CommonUtil.getElement(driver,COMMON_TOOLTIP_CONTAINER);

            if(tooltip==null)
            {
                throw new ZohoSalesIQRuntimeException("tooltip container not found");
            }
        }

        return tooltip;
    }

    /*Validate*/
    public static boolean isArticlesHeaderFound(WebDriver driver,ExtentTest etest)
    {
        String actual=getArticlesTab(driver).getText();
        String expected=ResourceManager.getRealValue("articles_tab_header");
        return CommonUtil.checkStringContainsAndLog(expected,actual,"articles header",etest);
    }

    public static boolean isArticlesDescriptionFound(WebDriver driver,ExtentTest etest)
    {
        String actual=getArticlesDescriptionContainer(driver).getText();
        String expected=ResourceManager.getRealValue("articles_tab_description");
        return CommonUtil.checkStringContainsAndLog(expected,actual,"articles description",etest);
    }

    public static boolean isCurrentlyInArticlesTab(WebDriver driver)
    {
        return getArticlesTab(driver).getAttribute("class").contains(ARTICLES_LOADED_CLASS);
    }

    public static boolean isEmptySlate(WebDriver driver)
    {
        return CommonWait.isDisplayed(driver,EMPTY_SLATE);
    }

    public static boolean isExpectedCategoryFound(WebDriver driver,ExtentTest etest,String expected_category)
    {
        String actual=CommonUtil.getElement(driver,ARTICLE_CATEGORY_SELECT,By.tagName("span")).getAttribute("title");

        return CommonUtil.checkStringContainsAndLog(expected_category,actual,"article category",etest);
    }

    /*Operations*/

    public static void enableArticlesForWebsite(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
    {
        toggleArticlesForWebsite(driver,etest,embed_name,true,true,null);
    }

    public static void disableArticlesForWebsite(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
    {
        toggleArticlesForWebsite(driver,etest,embed_name,false,true,null);
    }

    public static void toggleCategories(WebDriver driver,ExtentTest etest,String embed_name,Boolean isCategorise) throws Exception
    {
        toggleArticlesForWebsite(driver,etest,embed_name,true,isCategorise,null);
    }

    public static void setKnowledgeRepositoryName(WebDriver driver,ExtentTest etest,String embed_name,String knowledge_repository_name) throws Exception
    {
        toggleArticlesForWebsite(driver,etest,embed_name,true,true,knowledge_repository_name);
    } 

    public static void toggleArticlesForWebsite(WebDriver driver,ExtentTest etest,String embed_name,Boolean isEnable,Boolean isCategorise) throws Exception
    {
        toggleArticlesForWebsite(driver,etest,embed_name,isEnable,isCategorise,null);
    }


    public static void toggleArticlesForWebsite(WebDriver driver,ExtentTest etest,String embed_name,Boolean isEnable,Boolean isCategorise,String knowledge_repository_name) throws Exception
    {
        Tab.navToEmbedTab(driver);   
        WebEmbed.clickWebEmbed(driver,embed_name,etest);  
        WebsitesTab.clickLiveChat(driver,etest);
        WebsitesTab.clickChatWindow(driver,etest);
        WebsitesTab.clickConfigurations(driver,etest);    
        Websites.clickShowAll(driver,etest);
        toggleArticlesInWebsiteSettings(driver,etest,isEnable);
        checkToggleArticleInPreviewWindow(driver,etest,embed_name,isEnable);//if isEnable null check for popup ,wont run if already checked

        if(isEnable!=null && isEnable==true)
        {
            setCategoriseYourArticlesInWebsiteSettings(driver,etest,isCategorise);
            setKnowledgeRepositoryNameInWebsitesTab(driver,etest,knowledge_repository_name);
        }

        driver.switchTo().defaultContent();

        // if(isEnable==null)
        // {
        //     return;
        // }

        Websites.clickSave(driver,etest,false);//'false' is passed to return if already saved        
        WebsitesTab.closeEmbedConfig(driver,etest);
    }

    //isEnable is null if no articles are present
    public static void checkToggleArticleInPreviewWindow(WebDriver driver,ExtentTest etest,String embed_name,Boolean isEnable) throws Exception
    {
        try
        {
            if(isEnable==null && !CommonUtil.isChecked("ART3",ArticlesTests.result))
            {
                String no_article_popup_text=ResourceManager.getRealValue("websites_tab_no_article_popup");

                WebElement popup=HandleCommonUI.getPopupByInnerText(driver,no_article_popup_text);

                if(popup!=null)
                {
                    ArticlesTests.result.put("ART3",true);
                    etest.log(Status.PASS,"Popup text '"+no_article_popup_text+"' was found when enable articles button was clicked without any articles");

                    HandleCommonUI.clickPositivePopupButton(popup);

                    if(CommonWait.waitTillDisplayed(driver,ARTICLES_EDIT_CONTAINER))
                    {
                        etest.log(Status.PASS,"Edit article page was opened when 'Create Now' was clicked from the popup.");
                        ArticlesTests.result.put("ART10",true);
                    }
                    else
                    {
                        ArticlesTests.result.put("ART10",false);
                        etest.log(Status.FAIL,"Edit article page was NOT opened when 'Create Now' was clicked form the popup");
                        TakeScreenshot.screenshot(driver,etest);        
                    }
                }
                else
                {
                    ArticlesTests.result.put("ART3",false);
                    etest.log(Status.FAIL,"Popup text '"+no_article_popup_text+"' was NOT found when enable articles button was clicked without any articles");
                    TakeScreenshot.screenshot(driver,etest);        
                }

                //restore website state as it was.
                Tab.navToEmbedTab(driver);   
                WebEmbed.clickWebEmbed(driver,embed_name,etest);  
                WebsitesTab.clickLiveChat(driver,etest);
                WebsitesTab.clickChatWindow(driver,etest);
                WebsitesTab.clickConfigurations(driver,etest);    
                Websites.clickShowAll(driver,etest);
            }

            else if(isEnable!=null && (!CommonUtil.isChecked("ART4",ArticlesTests.result) && isEnable ) || (!CommonUtil.isChecked("ART6",ArticlesTests.result) && !isEnable) )
            {
                String usecase=isEnable?"ART4":"ART6";
                String expected_pass_status=isEnable?" found ":" NOT found ";
                String expected_fail_status=(!isEnable)?" found ":" NOT found ";                
                String action_performed=isEnable?" enabled ":" disabled ";

                if(VisitorWindow.isArticlesTabFound(driver)==isEnable)
                {
                    etest.log(Status.PASS,"Article tab was "+expected_pass_status+"in preview after it was"+action_performed);
                    ArticlesTests.result.put(usecase,true);
                }
                else
                {
                    ArticlesTests.result.put(usecase,false);
                    etest.log(Status.FAIL,"Article tab was "+expected_fail_status+"in preview after it was"+action_performed);
                    TakeScreenshot.screenshot(driver,etest);        
                }
            }

            driver.switchTo().defaultContent();
        }
        catch (Exception e) 
        {
            driver.navigate().refresh();
            driver.switchTo().defaultContent();
            Tab.navToArticlesTab(driver);
            throw e;
        }
    }

    public static void toggleArticlesInWebsiteSettings(WebDriver driver,ExtentTest etest,Boolean isEnable) throws Exception
    {
        boolean isThrowException=true;

        if(isEnable==null)
        {
            isEnable=true;
            isThrowException=false;//because toggle will not be activated when no articles are present
        }

        try
        {
            Websites.setStatusOfToggle(driver,WEBSITE_SETTINGS_TOGGLE_ID,isEnable,etest);

            if(isEnable)
            {
                CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,WEBSITE_SETTINGS_TOGGLE));
                ((JavascriptExecutor) driver).executeScript("javascript:(document.getElementById(\"emmiddlenav\").getElementsByTagName(\"div\")[0]).scrollBy(0,50)");
                CommonSikuli.findInWholePage(driver,"UI331.png","UI331",etest);
                // CommonSikuli.findInWholePage(driver,"UI331_1.png","UI331_1",etest);
                // CommonSikuli.findInWholePage(driver,"UI331_2.png","UI331_2",etest);
            }
        }
        catch(Exception e)
        {
            if(isThrowException)
            {
                throw e;
            }
        }
    }

    public static void setCategoriseYourArticlesInWebsiteSettings(WebDriver driver,ExtentTest etest,Boolean isEnable)
    {
        WebElement checkbox=CommonUtil.getElement(driver,CATEGORISE_ARTICLE_CHECKBOX_WEBSITE_SETTINGS);

        if(Boolean.parseBoolean(checkbox.getAttribute("checked"))==isEnable)
        {
            return;
        }
        else
        {
            CommonUtil.inViewPort(checkbox);
            checkbox.click();
            CommonUtil.waitTillWebElementContainsAttributeValue(checkbox,"checked",isEnable+"");
        }
    }

    public static void setKnowledgeRepositoryNameInWebsitesTab(WebDriver driver,ExtentTest etest,String knowledge_repository_name) throws Exception
    {
        if(knowledge_repository_name!=null)
        {
            WebElement edit_button=CommonUtil.getElement(driver,EDIT_KNOWLEDGE_REPO_BUTTON);
            CommonUtil.inViewPort(edit_button);
            edit_button.click();
            CommonWait.waitTillHidden(edit_button);

            ArticlesTests.checkKnowledgeRepositoryCharLimit(driver,etest);

            WebElement input=CommonUtil.getElement(driver,KNOWLEDGE_REPO_NAME_INPUT);
            input.clear();
            input.sendKeys(knowledge_repository_name);
            Websites.clickSave(driver,etest);
            ArticlesTests.checkKnowledgeRepositoryName(driver,etest,"ART21",knowledge_repository_name);
        }
    }

    public static String getArticleIdByLabel(WebDriver driver,String label) throws Exception
    {
        Tab.navToArticlesTab(driver);
        return getArticleContainerByName(driver,label).getAttribute("cannedid");
    }

    public static void quickPublishArticle(WebDriver driver,ExtentTest etest,String label) throws Exception
    {
        Hashtable<String,String> article_data = getArticleDataByLabel(label);
        String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
        addNewArticle(driver,etest,article_data.get(NAME),article_data.get(CONTENT),new String[]{department},article_data.get(CATEGORY),PUBLISH);
    }

    public static void clickAddButton(WebDriver driver)
    {
        getAddButton(driver).click();
        CommonWait.waitTillDisplayed(driver,ARTICLES_EDIT_CONTAINER);        
    }

    public static void addNewArticle(WebDriver driver,ExtentTest etest,String article_name,String article_content,String[] departments,String article_category,String action)
    {
        clickAddButton(driver);

        CommonSikuli.findInWholePage(driver,"UI325.png","UI325",etest);
        CommonSikuli.findInWholePage(driver,"UI326.png","UI326",etest);
        CommonSikuli.findInWholePage(driver,"UI327.png","UI327",etest);
        CommonSikuli.findInWholePage(driver,"UI328.png","UI328",etest);
        CommonSikuli.findInWholePage(driver,"UI329.png","UI329",etest);
        CommonSikuli.findInWholePage(driver,"UI330.png","UI330",etest);


        setupArticle(driver,etest,article_name,article_content,departments,article_category,action);
    }

    public static void setupArticle(WebDriver driver,ExtentTest etest,String name,String content,String[] departments,String category,String action)
    {
        setArticleName(driver,name);
        setArticleContent(driver,content);
        selectArticlesDepartment(driver,departments[0]);
        selectArticleCategory(driver,category,true);

        if(action.equals(SAVE))
        {
            saveArticle(driver);
        }
        else if(action.equals(PUBLISH))
        {
            publishArticle(driver);
        }
        else if(action.equals(CANCEL))
        {
            cancelArticle(driver);
        }
        logArticle(etest,name,content,departments,category,action);
    }

    public static void logArticle(ExtentTest etest,String name,String content,String[] departments,String category,String action)
    {
        String departments_str="none";

        if(departments==null)
        {
            departments_str=Arrays.toString(departments);
        }

        etest.log(Status.INFO,"Article was "+action+" with the following configurations \nname:"+name+"\ncontent:"+content+"\nDepartment :"+departments_str+"\ncategory:"+category);
    }

    public static void setArticleName(WebDriver driver,String article_name)
    {
        WebElement article_name_input=getArticleNameInputTag(driver);
        CommonUtil.sendKeysToWebElement(driver,article_name_input,article_name);
    }

    public static void setArticleContent(WebDriver driver,String content)
    {
        try
        {
            switchToArticleContainerFrame(driver);
            WebElement article_content_input=CommonUtil.getElement(driver,ARTICLE_TEXT_BODY);
            CommonUtil.sendKeysToWebElement(driver,article_content_input,content);
            driver.switchTo().defaultContent();
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
    }

    public static void selectArticlesDepartment(WebDriver driver,String dept)
    {
        if(dept==null)
        {
            dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
        }

        CommonUtil.getElement(driver,ARTICLE_DEPT_SELECT).click();
        CommonWait.waitTillDisplayed(driver,ARTICLE_DEPT_DROPDOWN);
        WebElement dropdown=CommonUtil.getElement(driver,ARTICLE_DEPT_DROPDOWN);
        HandleCommonUI.chooseFromDropdown(dropdown,dept);
    }

    public static final By
    WEBSITE_DROPDOWN_CONTAINER=By.id("tempwebsite_div"),
    WEBSITE_DROPDOWN=By.id("tempwebsite_ddown"),
    SELECTED_WEBSITE_CONTAINER=By.id("selectedapps"),
    SELECTED_WEBSITE=By.className("artle-tag-div"),
    REMOVE_WEBSITE=By.className("sqico-close")
    ;

    public static final String
    ALL_WEBSITES="All Websites"
    ;

    public static boolean selectArticleWebsitesAll(WebDriver driver,ExtentTest etest)
    {
        return selectArticleWebsites(driver,etest,ALL_WEBSITES);
    }

    public static boolean selectArticleWebsites(WebDriver driver,ExtentTest etest,String... websites)
    {
        //check if values already selected, then remove them
        if(getSelectedWebsiteCount(driver)>0)
        {
            TakeScreenshot.infoScreenshot(driver,etest);
            removeAllWebsitesFromList(driver);
            etest.log(Status.INFO,"All websites were removed.");
            TakeScreenshot.infoScreenshot(driver,etest);
        }

        int failcount=0;

        //select values from dropdown
        for(String website : websites)
        {
            if(selectArticlesWebsite(driver,etest,website)==false)
            {
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean selectArticlesWebsite(WebDriver driver,ExtentTest etest,String website)
    {
        CommonUtil.click(driver,WEBSITE_DROPDOWN_CONTAINER);
        CommonWait.waitTillDisplayed(driver,WEBSITE_DROPDOWN);

        WebElement dropdown=CommonUtil.getElement(driver,WEBSITE_DROPDOWN);

        etest.log(Status.INFO,"dropdown-->"+dropdown.getAttribute("innerText"));
        etest.log(Status.INFO,"website-->"+website);

        HandleCommonUI.chooseFromDropdown(dropdown,website);

        etest.log(Status.INFO,"Website '"+website+"' was selected for article");

        return CommonWait.waitTillHidden(dropdown);
    }

    public static int getSelectedWebsiteCount(WebDriver driver)
    {
        return CommonUtil.getElement(driver,SELECTED_WEBSITE_CONTAINER).findElements(SELECTED_WEBSITE).size();
    }

    public static void removeAllWebsitesFromList(WebDriver driver)
    {
        List<WebElement> websites=CommonUtil.getElement(driver,SELECTED_WEBSITE_CONTAINER).findElements(SELECTED_WEBSITE);

        for(WebElement website : websites)
        {
            CommonUtil.mouseHover(driver,website);
            CommonWait.waitTillDisplayed(website,REMOVE_WEBSITE);
            CommonUtil.clickWebElement(driver, CommonUtil.getElement(website,REMOVE_WEBSITE) );
            CommonWait.waitTillHidden(website);
            CommonUtil.sleep(250);
        }
    }

    public static void selectArticleCategory(WebDriver driver,String category,Boolean isNewCategory)
    {
        if(isNewCategory)
        {
            CommonUtil.getElement(driver,CATEGORY_TOGGLE).click();
            CommonWait.waitTillDisplayed(driver,CATEGORY_ADD_INPUT_CONTAINER);
            WebElement input=CommonUtil.getElement(driver,CATEGORY_ADD_INPUT_CONTAINER).findElement(By.tagName("input"));
            CommonUtil.sendKeysToWebElement(driver,input,category);
        }

        else
        {
            CommonUtil.getElement(driver,ARTICLE_CATEGORY_SELECT).click();
            CommonWait.waitTillDisplayed(driver,ARTICLE_CATEGORY_DROPDOWN);
            WebElement dropdown=CommonUtil.getElement(driver,ARTICLE_CATEGORY_DROPDOWN).findElement(By.tagName("ul"));
            HandleCommonUI.chooseFromDropdown(dropdown,category);
        }
    }

    public static void saveArticle(WebDriver driver)
    {
        updateArticle(driver,SAVE_ARTICLE_BUTTON);
    }

    public static void publishArticle(WebDriver driver)
    {
        updateArticle(driver,PUBLISH_ARTICLE_BUTTON);
    }

    public static void cancelArticle(WebDriver driver)
    {
        updateArticle(driver,CANCEL_ARTICLE_BUTTON);
    }

    public static void updateArticle(WebDriver driver,By button_locator)
    {
        WebElement button=CommonUtil.getElement(driver,button_locator);
        CommonUtil.inViewPortSafe(driver,button);
        button.click();
        driver.switchTo().defaultContent();
        try
        {
            CommonWait.waitTillDisplayed(driver,ADD_BUTTON);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void switchToArticleContainerFrame(WebDriver driver)
    {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(CommonUtil.getElement(driver,ARTICLE_CONTENT_FRAME));
    }

    public static List<String> getCurrentCannedIds(WebDriver driver)
    {
        List<WebElement> articles=getArticleContainers(driver);
        return CommonUtil.getAttributesFromList(articles,ARTICLE_ID_ATTRIBUTE);
    }

    public static boolean openEditArticle(WebDriver driver,ExtentTest etest,String name) throws Exception
    {
        return openEditArticle(driver,etest,name,false);
    }

    public static boolean openDeskArticle(WebDriver driver,ExtentTest etest,String name) throws Exception
    {
        return openEditArticle(driver,etest,name,true);
    }

    public static boolean openEditArticle(WebDriver driver,ExtentTest etest,String name,boolean isDeskArticle) throws Exception
    {
        Tab.navToArticlesTab(driver);

        WebElement article=getArticleContainerByName(driver,name).findElement(By.tagName("pre"));
        
        CommonUtil.inViewPort(article);

        CommonUtil.mouseHover(driver,article);
        CommonUtil.sleep(50);

        if(!isDeskArticle)
        {
            CommonSikuli.findInWholePage(driver,"UI319.png","UI319",etest);
            CommonSikuli.findInWholePage(driver,"UI320.png","UI320",etest);
            CommonSikuli.findInWholePage(driver,"UI321.png","UI321",etest);
            CommonSikuli.findInWholePage(driver,"UI322.png","UI322",etest);
        }

        article.click();

        if(!isDeskArticle)
        {
            return CommonWait.waitTillDisplayed(driver,ARTICLES_EDIT_CONTAINER);        
        }
        else
        {
            return CommonWait.waitTillDisplayed(driver,DESK_ARTICLE_PREVIEW_SAVE);        
        }
    }

    public static boolean deleteArticle(WebDriver driver,ExtentTest etest,String name)
    {
        int no_of_articles=getArticleContainers(driver).size();
        boolean isLastArticle=(no_of_articles==1);

        WebElement delete=getArticleContainerByName(driver,name).findElement(DELETE_ICON);
        CommonUtil.inViewPort(delete);
        CommonUtil.mouseHover(driver,delete);
        CommonWait.waitTillDisplayed(delete);
        delete.click();
        if(isLastArticle)
        {
            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,Cleanup.DELETE_COMMON_TEXT);

            if(!CommonUtil.isChecked("ART25",ArticlesTests.result))
            {
                if(popup!=null)
                {
                    ArticlesTests.result.put("ART25",true);
                    etest.log(Status.PASS,"Warning popup was found when deleting the last article of the portal");
                    TakeScreenshot.infoScreenshot(driver,etest);
                }
                else
                {
                    ArticlesTests.result.put("ART25",false);
                    etest.log(Status.FAIL,"Warning popup was NOT found when deleting the last article of the portal");
                    TakeScreenshot.screenshot(driver,etest);                    
                }              
            }

            HandleCommonUI.clickPositivePopupButton(popup);            
        }
        etest.log(Status.INFO,"Article "+name+" was deleted.");
        TakeScreenshot.infoScreenshot(driver,etest);

        return (!CommonWait.isDisplayed(delete));//checking if delete button of deleted article is not present in DOM,        
    }

    //text editor methods

    public static void addContentWithTextEmphasisOptions(WebDriver driver,ExtentTest etest,String text_emphasis_type,String text,Boolean isSelect)
    {
        if(text_emphasis_type.equals(BOLD) || text_emphasis_type.equals(ITALIC) || text_emphasis_type.equals(UNDERLINE))
        {
            selectTextEmphasis(driver,etest,text_emphasis_type,isSelect);
            etest.log( Status.INFO,text_emphasis_type+" text edit option was "+ (isSelect?"enabled":"disabled") );
            editArticleContent(driver,etest,text);
            ArticlesTests.checkTextEmphasisInTextEditor(driver,etest,text_emphasis_type,text,isSelect);

        }

        else if(text_emphasis_type.equals(HORIZONTAL_LINE))
        {
            CommonUtil.getElement(driver,HORIZONTAL_LINE_ICON).click();
            etest.log(Status.INFO,"Insert Horizontal Line icon was clicked");
            ArticlesTests.checkHorizontalLine(driver,etest);
        }
    }

    public static void editArticleContent(WebDriver driver,ExtentTest etest,String text)
    {
        try
        {
            switchToArticleContainerFrame(driver);
            WebElement article_content_input=CommonUtil.getElement(driver,ARTICLE_TEXT_BODY);
            article_content_input.sendKeys(Keys.RETURN);
            article_content_input.sendKeys(text);
            driver.switchTo().defaultContent();
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
    }

    public static boolean selectTextEmphasis(WebDriver driver,ExtentTest etest,String text_emphasis_type,Boolean isSelect)
    {
        By icon_locator=null;

        if(text_emphasis_type.equals(BOLD))
        {
            icon_locator=BOLD_ICON; 
        }
        else if(text_emphasis_type.equals(ITALIC))
        {
            icon_locator=ITALICS_ICON;
        }
        else if(text_emphasis_type.equals(UNDERLINE))
        {
            icon_locator=UNDERLINE_ICON;
        }

        WebElement icon=CommonUtil.getElement(driver,TEXT_EDIT_OPTIONS_CONTAINER,icon_locator);

        if(isTextEditOptionSelected(icon)==isSelect)
        {
            return true;
        }

        CommonUtil.inViewPort(icon);
        icon.click();
        CommonUtil.sleep(50);

        boolean isSelected=(isTextEditOptionSelected(icon)==isSelect);

        if(!CommonUtil.isChecked(ArticlesTests.getTextEmphasisUsecase("ICON",text_emphasis_type,isSelect),ArticlesTests.result))
        {
            ArticlesTests.result.put( ArticlesTests.getTextEmphasisUsecase("ICON",text_emphasis_type,isSelect) ,isSelected );
        }

        return isSelected;
    }

    public static boolean isTextFoundUnderGivenTag(WebDriver driver,String text,By tag)
    {
        try
        {
            switchToArticleContainerFrame(driver);
            WebElement article_content_input=CommonUtil.getElement(driver,ARTICLE_TEXT_BODY);
            WebElement element=CommonUtil.getElementByAttributeValue( article_content_input.findElements(tag), "innerText", text);
            driver.switchTo().defaultContent();
            return (element!=null);
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
    }

    public static boolean isTextFoundUnderGivenTag(WebElement element_container,String text,By tag)
    {
        WebElement element=CommonUtil.getElementByAttributeValue( element_container.findElements(tag), "innerText", text);
        return (element!=null);
    }

    public static boolean isTextEditOptionSelected(WebElement element)
    {
        if(element==null)
        {
            throw new ZohoSalesIQRuntimeException("Text edit option button was found as null");
        }

        return ( (element.getAttribute("class")!=null) && element.getAttribute("class").contains(TEXT_EDIT_ICON_SELECTED_CLASS));
    }

    public static void clickPreviewButton(WebDriver driver)
    {
        CommonUtil.getElement(driver,PREVIEW).click();
        ArticlesVisitorSide.waitTillArticlePreviewDisplayed(driver);
    }


    public static void clickAddLinkButtonInArticleEdit(WebDriver driver)
    {
        CommonUtil.getElement(driver,INSERT_LINK_ICON).click();
        CommonWait.waitTillDisplayed(driver,INSERT_LINK_CONTAINER);
    }

    public static WebElement getLinkContainerElementByText(WebDriver driver,String text)
    {   
        List<WebElement> elements = CommonUtil.getElement(driver,INSERT_LINK_FORM_CONTAINER).findElements(By.tagName("tr"));
        WebElement element=CommonUtil.getElementByAttributeValue(elements,"innerText",text);

        if(element==null)
        {
            throw new ZohoSalesIQRuntimeException("Could not find link container element with text "+text);
        }

        return element;
    }

    public static void addURLToArticle(WebDriver driver,ExtentTest etest,String text,String url)
    {
        addLinkToArticle(driver,etest,text,url,null);
    }

    public static void addLinkToArticle(WebDriver driver,ExtentTest etest,String text,String address,String subject)
    {
        boolean isEmail=(subject!=null)?true:false;

        By checkbox_locator=isEmail?INSERT_EMAIL_CHECKBOX:INSERT_URL_CHECKBOX;
        String
        text_field_name=isEmail?SELECTED_TEXT:SELECTED_TEXT,
        address_field_name=isEmail?EMAIL_ADDRESS:WEB_ADDRESS,
        subject_field_name=isEmail?SUBJECT:null;

        clickAddLinkButtonInArticleEdit(driver);

        WebElement checkbox=CommonUtil.getElement(driver,checkbox_locator);

        HandleCommonUI.setCheckbox(checkbox,true);

        getLinkContainerElementByText(driver,text_field_name).findElement(By.tagName("input")).sendKeys(text);
        getLinkContainerElementByText(driver,address_field_name).findElement(By.tagName("input")).sendKeys(address);
        if(isEmail)
        {
            getLinkContainerElementByText(driver,subject_field_name).findElement(By.tagName("input")).sendKeys(subject);
        }

        clickButtonInInsertLinkContainer(driver,true);

        ArticlesTests.checkIfLinkIsAdded(driver,etest,"EDITOR",text,address,subject);
    }   

    public static void clickButtonInInsertLinkContainer(WebDriver driver,Boolean isOkayButton)
    {
        WebElement button=null;
        WebElement link_buttons_container=CommonUtil.getElement(driver,INSERT_LINK_BUTTON_CONTAINER);

        if(isOkayButton)
        {
            button=CommonUtil.getElement(link_buttons_container,LINK_CONTAINER_OK);
        }
        else
        {
            button=CommonUtil.getElement(link_buttons_container,LINK_CONTAINER_CANCEL);
        }

        button.click();
        CommonWait.waitTillHidden(button);
    }

    public static boolean isAnchorTagFoundInContainer(WebDriver driver,WebElement container,ExtentTest etest,String href,String text)
    {
        List<WebElement> a_tags=container.findElements(By.tagName("a"));

        WebElement a_tag=CommonUtil.getElementByAttributeValue(a_tags,"href",href);

        if(a_tag!=null)
        {
            if(CommonUtil.checkStringContainsAndLog(text,a_tag.getText(),"anchor tag text",etest))
            {
                return true;
            }
        }
        else
        {
            etest.log(Status.FAIL,"Anchor tag was not found with href '"+href+"' and text '"+text+"'");
        }

        TakeScreenshot.screenshot(driver,etest);

        return false;
    }

    public static void checkArticleSavedInfoFound(WebDriver driver,ExtentTest etest,String check_in,String article_name,Boolean isPublished,Boolean isModified)
    {

        String saved_by_usecase=ArticlesTests.getSaveArticlesUseCase(check_in,"SAVED_BY",isPublished,isModified);
        String saved_at_usecase=ArticlesTests.getSaveArticlesUseCase(check_in,"SAVED_AT",isPublished,isModified);

        etest.log(Status.INFO,"~~Now checking "+saved_by_usecase+" "+saved_at_usecase);

        etest.log(Status.INFO,"Now checking use cases '"+KeyManager.getRealValue(saved_by_usecase)+"' & '"+KeyManager.getRealValue(saved_at_usecase)+"'");

        String saved_by_template=isModified?MODIFIED_BY:CREATED_BY,saved_at=ARTICLES_MENU_TIME;

        String save_type_text=isPublished?ARTICLES_EDIT_PUBLISHED:ARTICLES_EDIT_SAVED;

        // String saved_at_template="Just Now";
        // saved_at_template=(check_in.equals("EDIT_MENU"))?(save_type_text+" "+saved_at_template):saved_at_template;
        // String saved_at_regex=".*\\d (min|mins) ago.*";
        String saved_at_regex=".*(\\d (min|mins) ago|Just now).*";

        WebElement article_info_container=null;

        if(check_in.equals("TAB"))
        {
            article_info_container=getArticleContainerByName(driver,article_name).findElement(ARTICLE_SAVED_INFO_CONTAINER_ARTICLE_TAB);            
        }
        else if(check_in.equals("EDIT_MENU"))
        {
            article_info_container=CommonUtil.getElement(driver,ARTICLE_SAVED_INFO_CONTAINER_ARTICLE_EDIT);
        }

        String expected_saved_by=saved_by_template.replace("$text$","you");

        Hashtable<String,Boolean> result=isArticleSavedInfoFound(driver,article_info_container,etest,check_in,article_name,expected_saved_by,saved_at_regex,isPublished);

        if(result.get("SAVED_BY"))
        {
            ArticlesTests.result.put(saved_by_usecase,true);
        }
        else
        {
            ArticlesTests.result.put(saved_by_usecase,false);
            TakeScreenshot.screenshot(driver,etest);
        }

        if(result.get("SAVED_AT"))
        {
            ArticlesTests.result.put(saved_at_usecase,true);
        }
        else
        {
            ArticlesTests.result.put(saved_at_usecase,false);
            TakeScreenshot.screenshot(driver,etest);
        }

        if(check_in.equals("TAB"))
        {
            String draft_use_case=ArticlesTests.getSaveArticlesUseCase(check_in,"IS_DRAFT",isPublished,isModified);

            etest.log(Status.INFO,"~~Now checking "+draft_use_case);

            etest.log(Status.INFO,"Now checking use cases '"+KeyManager.getRealValue(draft_use_case));

            if(result.get("IS_DRAFT"))
            {
                ArticlesTests.result.put(draft_use_case,true);
            }
            else
            {
                ArticlesTests.result.put(draft_use_case,false);
                TakeScreenshot.screenshot(driver,etest);
            }            
        }
    }

    public static boolean isDraftLabelInArticlesTab(WebDriver driver,ExtentTest etest,String article_name,Boolean isPublish)
    {
        boolean isDraft=Boolean.parseBoolean(Articles.getArticleStats(driver,article_name).get(Articles.ISDRAFT));
        String pass_status=isPublish?"NOT found":"found";
        String fail_status=isPublish?"found":"NOT found";
        String action=isPublish?PUBLISH:SAVE;

       if(isDraft!=isPublish)
       {
            etest.log(Status.PASS,action+" article '"+article_name+"' was "+pass_status+" with 'Draft' label");
            return true;
       }
       else
       {

            etest.log(Status.FAIL,action+" article '"+article_name+"' was "+fail_status+" with 'Draft' label");
            TakeScreenshot.screenshot(driver,etest);
            return false;
       }
    }

    private static Hashtable<String,Boolean> isArticleSavedInfoFound(WebDriver driver,WebElement container,ExtentTest etest,String container_description,String article_name,String saved_by,String saved_at,Boolean isPublished)
    {
        Hashtable<String,Boolean> result=new Hashtable<String,Boolean>();

        String actual_text=container.getText();

        result.put("SAVED_BY", CommonUtil.checkStringContainsAndLog(saved_by,actual_text,"saved by("+container_description+")",etest) );

        String trimmed_saved_at=CommonUtil.format(saved_at);
        String trimmed_actual_text=CommonUtil.format(actual_text);

        result.put("SAVED_AT", CommonUtil.matchStringAndLog(trimmed_saved_at,trimmed_actual_text,"saved at("+container_description+")",etest) );

        if(container_description.equals("TAB"))
        {
            result.put("IS_DRAFT",isDraftLabelInArticlesTab(driver,etest,article_name,isPublished));
        }

        return result;
    }

    public static Hashtable<String,String> getArticleStats(WebDriver driver,String name)
    {
        Hashtable<String,String> stats=new Hashtable<String,String>();

        WebElement container=getArticleContainerByName(driver,name);

        if(container==null)
        {   
            throw new ZohoSalesIQRuntimeException("No article exists by the name '"+name+"'");
        }

        stats.put(NAME,name);
        stats.put(TIME, CommonUtil.getElement(container,ARTICLE_TIME).getText());

        boolean isDraft=(container.findElements(DRAFT_LABEL).size()>0);

        stats.put(ISDRAFT,isDraft+"");
        stats.put(VIEWS, CommonUtil.getElement(container,ARTICLE_VIEWS).getText());
        stats.put(CHATS, CommonUtil.getElement(container,ARTICLE_CHATS).getText());
        stats.put(DISLIKES, CommonUtil.getElement(container,ARTICLE_DISLIKES).getText());
        stats.put(LIKES, CommonUtil.getElement(container,ARTICLE_LIKES).getText());

        return stats;
    }

    public static void setupArticleWithStats(WebDriver driver,ExtentTest etest,String widget_code,Hashtable<String,String> article_data,int views,int likes,int dislikes) throws Exception
    {
        WebDriver visitor_driver=null;

        try
        {
            if( (likes+dislikes) > views)
            {
                throw new ZohoSalesIQRuntimeException("Invalid condition --> likes+dislikes > views (likes:"+likes+" dislikes:"+dislikes+" views:"+views+")");
            }

            VisitorDriverManager visitor_driver_manager=new VisitorDriverManager();

            int
            remaining_likes=likes,
            remaining_dislikes=dislikes;

            for(int i=1;i<=views;i++)
            {
                boolean isVoted=false;//just to check some use cases. not needed for flow

                visitor_driver=visitor_driver_manager.getDriver(driver);
                VisitorWindow.createPage(visitor_driver,widget_code);
                VisitorWindow.clickChatButton(visitor_driver);
                ArticlesVisitorSide.openArticle( visitor_driver ,etest,article_data.get(Articles.NAME),article_data.get(Articles.CATEGORY),ExecuteStatements.getSystemGeneratedDepartment(driver) );

                ArticlesTests.checkArticlesVoteContent(visitor_driver,etest,0);

                if(remaining_likes>0)
                {
                    ArticlesVisitorSide.likeArticle(visitor_driver);
                    isVoted=true;
                    remaining_likes--;
                }
                else if(remaining_dislikes>0)
                {
                    ArticlesVisitorSide.dislikeArticle(visitor_driver);
                    isVoted=true;
                    remaining_dislikes--;
                }

                if(isVoted)
                {
                    ArticlesTests.checkArticlesVoteContent(visitor_driver,etest,1);

                    if(CommonUtil.isChecked("ART107",ArticlesTests.result)==false)
                    {
                        ArticlesVisitorSide.closeArticle(visitor_driver);
                        ArticlesVisitorSide.openArticle( visitor_driver ,etest,article_data.get(Articles.NAME),article_data.get(Articles.CATEGORY),ExecuteStatements.getSystemGeneratedDepartment(driver) );
                        ArticlesTests.checkArticlesVoteContent(visitor_driver,etest,2);
                    }
                }

                ArticlesVisitorSide.closeArticle(visitor_driver);
            }

            visitor_driver_manager.terminateAllDriverSessions();

            if(remaining_likes!=0 || remaining_dislikes!=0)
            {
                throw new ZohoSalesIQRuntimeException("Articles was not set with the given configuration. remaining_likes :"+remaining_likes+" remaining_dislikes : "+remaining_dislikes);
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visitor_driver,etest,ArticlesTests.MODULE_NAME,"Exception","Exception",e);
            throw e;
        }

        etest.log(Status.INFO,"Aritcle "+article_data.get(Articles.NAME)+" was setup with "+views+" views, "+likes+" likes and "+dislikes+" dislikes");
    }

    public static int getArticleIndex(WebDriver driver,String name)
    {
        List<WebElement> article_containers=getArticleContainers(driver);

        for(int i=0;i<article_containers.size();i++) 
        {
            WebElement article_container=article_containers.get(i);

            if(article_container.getText().contains(name))
            {
                return (i+1);
            }
        }

        throw new ZohoSalesIQRuntimeException("No article was found by the name of '"+name+"'");
    }

    public static Hashtable<String,Integer> getArticleIndexes(WebDriver driver)
    {
        Hashtable<String,Integer> indexes=new Hashtable<String,Integer>();

        List<WebElement> articles=getArticleContainers(driver); 

        for(WebElement article : articles)
        {
            String article_name=article.findElement(ARTICLE_NAME_CONTAINER).getText().replaceAll("\\s+","");//remove all spaces
            int article_index=getArticleIndex(driver,article_name);
            indexes.put(article_name,article_index);
        }

        return indexes;
    }

    public static void sortBy(WebDriver driver,ExtentTest etest,String sort_type,String sort_order)
    {
        WebElement sort_button=getSortButtonContainerBySortType(driver,sort_type).findElement(SORT_ARROW);
        sort_button.click();
        CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,ARTICLES_LIST_CONTAINER),SORTBY_ATTRIBUTE,""+getSortKeyByType(sort_type));
        CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,ARTICLES_LIST_CONTAINER),SORT_DIR_ATTRIBUTE,sort_order);
        etest.log(Status.INFO,"Articles were sorted by '"+sort_type+"' in '"+sort_order+"' order");
        ArticlesTests.checkSortIconInUI(driver,etest,sort_order);
    }

    public static WebElement getSortButtonContainerBySortType(WebDriver driver,String sort_type)
    {
        int sort_key=getSortKeyByType(sort_type);

        return CommonUtil.getElement(driver,By.cssSelector("[sort-key='"+sort_key+"']"));
    }

    public static int getSortKeyByType(String sort_type)
    {
        if(sort_type.equals(SORT_TYPE_CHAT))
        {
            return sort_by_chats;
        }
        else if(sort_type.equals(SORT_TYPE_VIEWS))
        {
            return sort_by_views;
        }
        else if(sort_type.equals(SORT_TYPE_LIKES))
        {
            return sort_by_likes;
        }
        else if(sort_type.equals(SORT_TYPE_DISLIKES))
        {
            return sort_by_dislikes;
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid sort type '"+sort_type+"'");
        }
    }

    public static Hashtable<String,String> getSortType(WebDriver driver)
    {
        Hashtable<String,String> sort_info=new Hashtable<String,String>();

        WebElement list_view=CommonUtil.getElement(driver,ARTICLES_LIST_CONTAINER);

        String sort_by=list_view.getAttribute(SORTBY_ATTRIBUTE);
        String sort_dir=list_view.getAttribute(SORT_DIR_ATTRIBUTE);

        if(sort_by==null)
        {
            throw new ZohoSalesIQRuntimeException("Element "+ARTICLES_LIST_CONTAINER.toString()+" currently does not have the attribute '"+SORTBY_ATTRIBUTE+"'");
        }
        if(sort_dir==null)
        {
            throw new ZohoSalesIQRuntimeException("Element "+ARTICLES_LIST_CONTAINER.toString()+" currently does not have the attribute '"+SORT_DIR_ATTRIBUTE+"'");
        }

        if(sort_by.equals(sort_by_chats+""))
        {
            sort_info.put("type",SORT_TYPE_CHAT);
        }
        else if(sort_by.equals(sort_by_views+""))
        {
            sort_info.put("type",SORT_TYPE_VIEWS);
        }
        else if(sort_by.equals(sort_by_likes+""))
        {
            sort_info.put("type",SORT_TYPE_LIKES);
        }
        else if(sort_by.equals(sort_by_dislikes+""))
        {
            sort_info.put("type",SORT_TYPE_DISLIKES);
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid sort type '"+sort_by+"'");
        }

        if(sort_dir.equals(SORT_DIR_ASCENDING))
        {
            sort_info.put("order",SORT_DIR_ASCENDING);
        }
        else if(sort_dir.equals(SORT_DIR_DESCENDING))
        {
            sort_info.put("order",SORT_DIR_DESCENDING);
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Invalid sort dir '"+sort_dir+"'");
        }

        return sort_info;
    }

    public static boolean isArticleFound(WebDriver driver,String article_name) throws Exception
    {
        Tab.navToArticlesTab(driver);

        List<WebElement> name_elements=CommonUtil.getElements(driver,By.className("cmn_wordbr"));
        return (CommonUtil.getElementByAttributeValue(name_elements,"innerText",article_name)!=null);
    }

    //all code below is related to desk articles sync

    public static boolean isAtleastOneDeskSyncedArticleFound(WebDriver driver) throws Exception
    {
        Tab.navToArticlesTab(driver);
        return CommonWait.isPresent(driver,ZOHODESK_ICON);
    }

    public static boolean isSyncedFromDeskIcon(WebDriver driver,String article_name)
    {
        WebElement article_container=getArticleContainerByName(driver,article_name);
        return CommonWait.isPresent(article_container,ZOHODESK_ICON);
    }

    public static boolean isSyncedFromDeskText(WebDriver driver,String article_name)
    {
        String article_container_text=getArticleContainerByName(driver,article_name).getAttribute("innerText");
        return CommonUtil.isContains(SYNCED_FROM_DESK,article_container_text);
    }

    public static Hashtable<String,String> getDeskArticleInfoFromPreview(WebElement article_container)
    {
        Hashtable<String,String> article_info=new Hashtable<String,String>();

        String error_text="Not found due to exception";

        try
        {
            String value=CommonUtil.getElement(article_container,ArticlesVisitorSide.ARTICLE_HEADER).getText();
            article_info.put(ArticlesVisitorSide.HEADER,value);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            article_info.put(ArticlesVisitorSide.HEADER,error_text);
        }

        try
        {
            String value=CommonUtil.getElement(article_container,ArticlesVisitorSide.ARTICLE_CONTENT).getText();
            article_info.put(ArticlesVisitorSide.CONTENT,value);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            article_info.put(ArticlesVisitorSide.CONTENT,error_text);
        }

        try
        {
            String value=CommonUtil.getElement(article_container,DESK_ARTICLE_PREVIEW_SAVE).getText();
            article_info.put(IS_PUBLISHED, ""+value.contains("Draft") );
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
            article_info.put(IS_PUBLISHED,error_text);
        }

        return article_info;
    }

    public static boolean verifyDeskArticlePreviewData(ExtentTest etest,Hashtable<String,String> expected,Hashtable<String,String> actual)
    {
        int failcount=0;

        Set<String> keys = expected.keySet();

        for(String key: keys)
        {
            if(expected.get(key).equals("null")==false && CommonUtil.checkStringEqualsAndLog(expected.get(key),actual.get(key),key,etest)==false)
            {
                failcount++;
            }
        }

        return CommonUtil.returnResult(failcount);
    }

    public static Hashtable<String,String> getExpectedDeskPreviewArticleInfo(String title,String content,String isPublished)
    {
        Hashtable<String,String> expected_article_info=new Hashtable<String,String>();

        expected_article_info.put(ArticlesVisitorSide.HEADER,title);
        expected_article_info.put(ArticlesVisitorSide.CONTENT,content);
        expected_article_info.put(IS_PUBLISHED,""+isPublished);
    
        return expected_article_info;
    }

    public static boolean closeDeskArticlePreview(WebDriver driver)
    {
        WebElement container=HandleCommonUI.getPopupByAttribute(driver,"class",ARTICLE_PREVIEW_CLASS);
        return HandleCommonUI.closePopup(container);
    }

    public static boolean toggleDeskArticlePublishStatusFromPreview(WebElement container,ExtentTest etest,boolean isPublish)
    {
        boolean isPublished=Boolean.parseBoolean(getDeskArticleInfoFromPreview(container).get(IS_PUBLISHED));

        if(isPublished==isPublish)
        {
            etest.log(Status.INFO,"Article is already "+(isPublish?"published":"saved as draft"));
            return true;
        }

        CommonUtil.getElement(container,DESK_ARTICLE_PREVIEW_SAVE).click();

        etest.log(Status.INFO,"Article was "+(isPublish?"published":"saved as draft"));

        return CommonWait.waitTillHidden(container);
    }
}
