//$Id$
package com.zoho.livedesk.util.common.actions.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import java.util.Calendar;
import org.openqa.selenium.interactions.Actions;

public class BotsVisitorSide
{
    // public static final int
    // BOT_ANSWERS_NONE=0,
    // BOT_ANSWERS_ALL=1,
    // BOT_ANSWERS_WHEN_BUSY=2
    // ;

    public static final String
    // NONE="None",
    // ALL="Let bot answer all chats",
    // WHEN_BUSY="Let bot answer when operators are offline",
    DISABLED_ATTRIB="disabled",
    BOT_FORWARDED_INFO_MESSAGE_CONTENT="forwarding the chat"
    ;

    // public static final String[]
    // WEBSITE_VALUES={NONE,ALL,WHEN_BUSY};
    // ;

    public static final By
    BOT_DP=By.id("bottype_msg"),
    CONNECT_TO_HUMAN=By.cssSelector("[documentclick='transferchat']"),
    DONT_CONNECT_TO_HUMAN=By.cssSelector("[documentclick='hidetransferoption']"),
    BOT_FIRST_MESSAGE=By.cssSelector("[frstmsg='true']"),
    BOT_TYPING=By.className("type-loadr"),
    DISABLED_INPUT=By.cssSelector("[disabled='disabled']"),
    SUGGESTIONS=By.cssSelector("[prop='suggestions']")
    ;

    public static boolean isBotPickup(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        
        return CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.tagName("header")),"header-type","bot");
    }

    public static boolean isBotChat(final WebDriver driver)
    {
        return isBotChat(driver,null);
    }

    public static boolean isBotChat(final WebDriver driver,String bot_name)
    {
        VisitorWindow.switchToChatWidget(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(isBotPickup(driver) || VisitorWindow.isWaitingDivShown(driver))
                {
                    return true;
                }
                return false;
            }
            });
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        if(VisitorWindow.isWaitingDivShown(driver))
        {
            return false;
        }
        if(bot_name!=null)
        {
            return getBotName(driver).equals(bot_name);
        }
        if(isBotPickup(driver))
        {
            return true;
        }

        return false;
    }

    public static boolean waitTillBotPicksUp(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        try
        {
            CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.tagName("header")),"header-type","bot");
            try
            {
                CommonWait.waitTillHidden(CommonUtil.getElement(driver,BOT_TYPING));
            }
            catch(Exception e)
            {
                CommonUtil.doNothing();
            }
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }
        return CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.tagName("header")),"header-type","bot");
    }

    public static String getBotName(WebDriver driver)
    {
        if(!isBotPickup(driver))
        {
            throw new ZohoSalesIQRuntimeException("Could not get bot name in visitor side as the chat attender is not a bot. (or no message was receieved from the bot)");
        }

        return CommonUtil.getElement(driver,VisitorWindow.ATTENDER_NAME).getAttribute("innerText").trim();
    }

    public static String getBotDesc(WebDriver driver)
    {
        return CommonUtil.getElement(driver,VisitorWindow.ATTENDER_ABOUT_ME).getAttribute("innerText");
    }

    public static boolean isConnectToHumanShown(WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);
        return CommonWait.isDisplayed(driver,CONNECT_TO_HUMAN);
    }

    public static void setConnectToHuman(WebDriver driver,ExtentTest etest,boolean isConnectToHuman)
    {
        setConnectToHuman(driver,isConnectToHuman);
    }

    public static boolean setConnectToHuman(WebDriver driver,boolean isConnectToHuman)
    {
        CommonWait.waitTillDisplayed(driver,CONNECT_TO_HUMAN);

        if(isConnectToHumanShown(driver)==false)
        {
            throw new ZohoSalesIQRuntimeException("Connect to human text is not shown at visitor side");
        }

        VisitorWindow.switchToChatWidget(driver);

        By locator=isConnectToHuman?CONNECT_TO_HUMAN:DONT_CONNECT_TO_HUMAN;

        WebElement button=CommonUtil.getElement(driver,locator);
        button.click();

        return CommonWait.waitTillHidden(button);
    }

    public static void waitTillBotReplies(final WebDriver driver)
    {
        VisitorWindow.switchToChatWidget(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,30,500);

        wait.until(new Function<WebDriver,Boolean>()
        {
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if( VisitorWindow.isLastMessageAgentMessage(driver) && (CommonWait.isPresent(driver,BOT_TYPING)==false) )
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });

        // CommonWait.waitTillNotPresent(driver,DISABLED_INPUT);
    }

    public static void waitTillInputIsEnabled(WebDriver driver)
    {
        CommonWait.waitTillElementDoesNotContains( CommonUtil.getElement(driver,VisitorWindow.MESSAGE_AREA) , DISABLED_ATTRIB);
        CommonUtil.sleep(500);//just to avoid invalid state exception in case code runs too fast
    }

    public static List<String> getSuggestions(WebElement message)
    {
        List<WebElement> suggestions=CommonUtil.getElements(message,SUGGESTIONS);
        return CommonUtil.getAttributesFromList(suggestions,"innerText");
    }

    public static boolean isSuggestionsFound(WebDriver driver,ExtentTest etest,String... expected_suggestions)
    {
        int failcount=0;

        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        List<String> suggestions=getSuggestions(message);

        for(String expected_suggestion : expected_suggestions)
        {
            if(CommonUtil.checkStringContainsAndLog(expected_suggestion,suggestions.toString(),"expected suggestion",etest)==false)
            {
                failcount++;
            }
        }

        if(failcount>0)
        {
            TakeScreenshot.screenshot(driver,etest);
        }

        return CommonUtil.returnResult(failcount);
    }

    public static boolean selectSuggestion(WebDriver driver,ExtentTest etest,String suggestion)
    {
        WebElement message=VisitorWindow.getLastAgentMessageElement(driver);

        By locator= By.cssSelector("[prop='suggestions'][val='"+suggestion+"']");

        VisitorWindow.switchToChatWidget(driver);

        CommonWait.waitTillDisplayed(message,locator);

        WebElement suggestion_ele=CommonUtil.getElement(message,locator);

        CommonUtil.scrollIntoView(driver,true,suggestion_ele);
        CommonUtil.sleep(500);

        CommonUtil.mouseHoverAndClick(driver,suggestion_ele);

        etest.log(Status.INFO,"Suggestion '"+suggestion+"' was clicked.");

        return CommonWait.waitTillHidden(suggestion_ele);
    }

    public static boolean isBotForwardedInfoMessageShown(WebDriver driver)
    {
        return VisitorWindow.isInfoMessageShown(driver,BOT_FORWARDED_INFO_MESSAGE_CONTENT);
    }
}
