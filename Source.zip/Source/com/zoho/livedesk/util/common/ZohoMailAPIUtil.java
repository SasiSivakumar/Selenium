//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.List;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
// import com.fasterxml.jackson.databind.JsonNode;
// import com.fasterxml.jackson.databind.ObjectMapper;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil.ZohoMailAPI;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil.Api;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil.RequestType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.util.Hashtable;

import org.jsoup.*;
import org.jsoup.helper.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;

public class ZohoMailAPIUtil
{
	//JSON PATHS
	public static final String
	ACCOUNTID="data[0]/accountId";

	public static final String
	SEARCH_ENTIRE_MAIL="entire:",
	SEARCH_KEY="searchKey"
	;

	public enum RequestType
	{
		GET,
		POST,
		PUT,
		DELETE;

	    public String toString()
	    {
	        return this.name().toLowerCase();
	    }
	}

	public static final String
	ACCOUNTID_DELIMITER="<ACCOUNTID>",
	FOLDERID_DELIMITER="<FOLDERID>",
	MESSAGEID_DELIMITER="<MESSAGEID>"
	;

	public enum Api
	{
		GETACCOUNTDETAILS("https://mail.zoho.com/api/accounts",RequestType.GET),
		SEARCH_MAIL("https://mail.zoho.com/api/accounts/"+ACCOUNTID_DELIMITER+"/messages/search",RequestType.GET),
		GET_METADATA("https://mail.zoho.com/api/accounts/"+ACCOUNTID_DELIMITER+"/folders/"+FOLDERID_DELIMITER+"/messages/"+MESSAGEID_DELIMITER+"/details",RequestType.GET),
		GET_CONTENT("https://mail.zoho.com/api/accounts/"+ACCOUNTID_DELIMITER+"/folders/"+FOLDERID_DELIMITER+"/messages/"+MESSAGEID_DELIMITER+"/content",RequestType.GET),
		GET_HEADERS("https://mail.zoho.com/api/accounts/"+ACCOUNTID_DELIMITER+"/folders/"+FOLDERID_DELIMITER+"/messages/"+MESSAGEID_DELIMITER+"/header",RequestType.GET)
		;

		public String api;
		public RequestType requestType;

		Api(String api,RequestType requestType)
		{
			this.api=api;
			this.requestType=requestType;
		}
	}

	public static class ZohoMailAPI
	{
		String mail_api=null;
		String authtoken=null,setup=null;
		Api mail_api_format=null;
		String payload=null;

		ZohoMailAPI(Api mail_api_format,String authtoken,String setup)
		{
			this.mail_api_format=mail_api_format;
			this.mail_api=mail_api_format.api;
			this.authtoken=authtoken;
			this.setup=setup;
		}

		ZohoMailAPI(Api mail_api_format,String authtoken)
		{
			this(mail_api_format,authtoken,"idc");
		}

		public void setURLParameter(String parameter_key,String parameter_value)
		{
			mail_api=mail_api.replaceAll(parameter_key,parameter_value);
		}

		public void addQueryParameter(String key,String value)
		{
			this.mail_api=SalesIQRestAPICommonFunctions.addParam(mail_api,key,value);
		}

		public void setPayload(String payload)
		{
			this.payload=payload;
		}

		public String getPayload()
		{
			return payload;
		}
	}

	public String getAPIBySetup(String api)
	{
		if(ConfManager.getSetup().contains("localzoho"))
		{
	        api = api.replace("mail.zoho.com","mail.localzoho.com");
		}
		if(ConfManager.getSetup().contains("pre"))
		{
	        api = api.replace("mail.zoho.com","premail.zoho.com");
		}

		return api;	
	}

	public static void openAPIPage(WebDriver driver)
	{
		driver.get(SalesIQRestAPIModule.APITesterURL);
	}

	public static void setAuthToken(WebDriver driver,String authtoken)
	{
		CommonUtil.getElement(driver,By.id("tkn")).sendKeys(authtoken);;
	}

	public static String getAccountId(WebDriver driver,String authtoken) throws Exception
	{
		openAPIPage(driver);
		ZohoMailAPI accounts_api=new ZohoMailAPI(Api.GETACCOUNTDETAILS,authtoken);
		configureAPI(driver,accounts_api);
		SalesIQRestAPICommonFunctions.sendAPIRequest(driver);
		String response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);
		return jPath(response,ACCOUNTID);
	}

	public static String searchMail(WebDriver driver,String authtoken,String account_id,String search_keyword) throws Exception
	{
		openAPIPage(driver);
		ZohoMailAPI search_api=new ZohoMailAPI(Api.SEARCH_MAIL,authtoken);
		search_api.setURLParameter(ACCOUNTID_DELIMITER,account_id);
		String mail_search_syntax=null;
		if(search_keyword.contains(":"))
		{
			mail_search_syntax="";//because mail_search_syntax already added
		}
		else
		{
			mail_search_syntax=SEARCH_ENTIRE_MAIL;//add search entire mail syntax
		}

		search_keyword=mail_search_syntax+search_keyword;

		search_api.addQueryParameter(SEARCH_KEY,search_keyword);
		configureAPI(driver,search_api);
		SalesIQRestAPICommonFunctions.sendAPIRequest(driver);
		String response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

		return response;
	}

	public static int getResultsLengthOfSearchMailAPI(String response) throws Exception
	{
		JSONObject json=convertToJSON(response);
		return json.getJSONArray("data").length();
	}

	public static ZohoMailAPI getMailInfoAPIObject(WebDriver driver,Api api_value,String authtoken,String account_id,String folder_id,String message_id)
	{
		ZohoMailAPI api=new ZohoMailAPI(api_value,authtoken);
		api.setURLParameter(ACCOUNTID_DELIMITER,account_id);
		api.setURLParameter(FOLDERID_DELIMITER,folder_id);
		api.setURLParameter(MESSAGEID_DELIMITER,message_id);
		return api;
	}

	public static String getMetaData(WebDriver driver,String authtoken,String account_id,String folder_id,String message_id) throws Exception
	{
		ZohoMailAPI api=getMailInfoAPIObject(driver,Api.GET_METADATA,authtoken,account_id,folder_id,message_id);
		return getMailInfo(driver,api);
	}

	public static String getMailContent(WebDriver driver,String authtoken,String account_id,String folder_id,String message_id) throws Exception
	{
		ZohoMailAPI api=getMailInfoAPIObject(driver,Api.GET_CONTENT,authtoken,account_id,folder_id,message_id);
		return getMailInfo(driver,api);
	}

	public static String getMailHeader(WebDriver driver,String authtoken,String account_id,String folder_id,String message_id) throws Exception
	{
		ZohoMailAPI api=getMailInfoAPIObject(driver,Api.GET_HEADERS,authtoken,account_id,folder_id,message_id);
		return getMailInfo(driver,api);
	}

	public static String getMailInfo(WebDriver driver,ZohoMailAPI api) throws Exception
	{
		openAPIPage(driver);
		configureAPI(driver,api);
		SalesIQRestAPICommonFunctions.sendAPIRequest(driver);
		String response = SalesIQRestAPICommonFunctions.getRawAPIResponse(driver);
		return response;
	}

	public static void configureAPI(WebDriver driver,ZohoMailAPI zoho_mail_api) throws Exception
	{
		SalesIQRestAPICommonFunctions.configureAPI(driver,"access",zoho_mail_api.mail_api_format.requestType.toString());
		setAuthToken(driver,zoho_mail_api.authtoken);
		SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,zoho_mail_api.mail_api);
	}

	// public static int getJSONArrayLengthByjPath(String json,String jPath)
	// {
	// 	JSONArray json_array = new JSONArray(jPath(json,jPath));
	// 	return json_array.length();
	// }

	public static String jPath(String json_string,String jPath) throws Exception
	{
        JSONObject JSONResponse = convertToJSON(json_string);

		String[] jPath_elements=jPath.split("/");

		for(int i=0;i<jPath_elements.length;i++)
		{
			boolean isLastElementInLoop=i==(jPath_elements.length-1);

			String jPath_element=jPath_elements[i];
		
			//get array index if its an array
			int jPathArrayIndex=getjPathArrayIndex(jPath_element);

			if(!isLastElementInLoop)
			{
				//if jpath is a json object, get the json object
				if(jPathArrayIndex==-1)
				{
					JSONResponse=JSONResponse.getJSONObject(jPath_element);
				}
				//if jpath is a json array, get the json array
				else
				{
					JSONResponse=JSONResponse.getJSONArray(getjPathKey(jPath_element)).getJSONObject(jPathArrayIndex);
				}
			}
			else
			{
				//if last element in loop return

				//if last element is a json object, return the json object
				if(jPathArrayIndex==-1)
				{
					return JSONResponse.get(jPath_element).toString();
				}
				//if last element is a json array, return the json array
				else
				{
					return JSONResponse.getJSONArray(getjPathKey(jPath_element)).get(jPathArrayIndex).toString();
				}
			}
		}

		return null;
	}

	public static String extractTextFromHTML(String html)
	{
		Document doc = Jsoup.parse(html);
		return doc.body().text();
	}
	
	public static String getElementAttribute(String html,String css_selector,String attribute)
	{
		Document doc=Jsoup.parse(html);
		Element element=getElementByCssSelector(doc,css_selector);
		System.out.println("~~getElementAttribute "+element.toString());		
		return element.attr(attribute);
	}

	public static Element getElementByCssSelector(Document doc,String css_selector)
	{
		return doc.select(css_selector).first();
	}


	public static String
	FOLDERID="data[0]/folderId",
	MESSAGEID="data[0]/messageId",
	FROMADDRESS="data/fromAddress",
	SUBJECT="data/subject",
	SUMMARY="data/summary",
	SENDER="data/sender",
	HEADER_CONTENT="data/headerContent",
	MAIL_CONTENT="data/content"	
	;

	public static Hashtable<String,String> getMailInfoByUniqueKeyWord(WebDriver driver,ExtentTest etest,String authtoken,String account_id,String keyword) throws Exception
	{
		Hashtable<String,String> email_data=new Hashtable<String,String>();

		String search_result_json=ZohoMailAPIUtil.searchMail(driver,authtoken,account_id,keyword);

		int no_of_results=ZohoMailAPIUtil.getResultsLengthOfSearchMailAPI(search_result_json);

		if(no_of_results == 0)
		{
			etest.info("No data present in the response");
			TakeScreenshot.infoScreenshot(driver,etest);
			return null;
		}
		// no_of_results=no_of_results-1;//zoho mail returns one empty response
		no_of_results=no_of_results-1;//json array index starts from 0, so we subtract 1

		TakeScreenshot.debug(driver,etest);

		String message_id_locator=MESSAGEID;
		String folder_id_locator=FOLDERID;

		if(no_of_results>1)
		{
			message_id_locator=message_id_locator.replaceAll("data\\[0\\]","data["+no_of_results+"]");
			folder_id_locator=folder_id_locator.replaceAll("data\\[0\\]","data["+no_of_results+"]");
		}

		String message_id=ZohoMailAPIUtil.jPath(search_result_json,message_id_locator);
		String folder_id=ZohoMailAPIUtil.jPath(search_result_json,folder_id_locator);

		email_data.put("message_id",message_id);
		email_data.put("folder_id",folder_id);

		String meta_data_json=ZohoMailAPIUtil.getMetaData(driver,authtoken,account_id,folder_id,message_id);

		email_data.put("from",ZohoMailAPIUtil.jPath(meta_data_json,FROMADDRESS));
		email_data.put("subject",ZohoMailAPIUtil.jPath(meta_data_json,SUBJECT));
		email_data.put("sender",ZohoMailAPIUtil.jPath(meta_data_json,SENDER));
		email_data.put("summary",ZohoMailAPIUtil.jPath(meta_data_json,SUMMARY));

		String mail_header_json=ZohoMailAPIUtil.getMailHeader(driver,authtoken,account_id,folder_id,message_id);

		email_data.put("header",ZohoMailAPIUtil.jPath(mail_header_json,HEADER_CONTENT));

		//parsing to addresses from header
		String to_mails_comma_seperated=email_data.get("header").split("\\r\\nTo: ")[1].split("Content-Type: ")[0].replaceAll("[ \\t\\n\\r]","");
		to_mails_comma_seperated=to_mails_comma_seperated.split("Message-ID:")[0];
		System.out.println("~~~~to_mails_comma_seperated "+to_mails_comma_seperated);

		email_data.put("to",to_mails_comma_seperated);

		String mail_content_json=null;

		mail_content_json=ZohoMailAPIUtil.getMailContent(driver,authtoken,account_id,folder_id,message_id);

		try
		{
			//added in try catch due to invalid JSON response from Mail API
			email_data.put("content",ZohoMailAPIUtil.jPath(mail_content_json,MAIL_CONTENT));
		}
		catch(Exception e)
		{

			email_data.put("content",parseJSONKey(mail_content_json,"content"));
		}
		
		email_data.remove("header");//unparsed data.

		return email_data;
	}

	public static String parseJSONKey(String json,String key)
	{
		//unsafe implementation. use at risk
		System.out.println("~~Parsing '"+key+"' in the following json \n"+json);
		return json.split("\""+key+"\": \"")[1].split("\"\n")[0];
	}

	public static int getjPathArrayIndex(String jPathElement)
	{
		try
		{
			return Integer.parseInt(jPathElement.split("\\[")[1].split("\\]")[0]);
		}
		catch(Exception e)
		{
			return -1;
		}
	}

	public static String getjPathKey(String jPathElement)
	{
		return jPathElement.split("\\[")[0];
	}

	public static JSONObject convertToJSON(String str) throws Exception
	{
		str=escapeJSON(str);

		JSONObject json;
		json = new JSONObject(str);	
		return json;
	}

	public static String escapeJSON(String str)
	{
		// str=str.replaceAll("","\\n");//remove line breaks in json keys only here

		return str;
	}
}
