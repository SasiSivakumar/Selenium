//$Id$
package com.zoho.livedesk.util.common.objects;

public enum Integration
{
    GA("PDF25","Google Analytics",false),
    CLICKY("PDF26","Clicky",false),
    KISSMETRICS("PDF27","KissMetrics",false),
    OPTIMIZELY("PDF28","Optimizely",false),
    WOOPRA("PDF29","Woopra",false),
    MATAMO("PDF30","Matomo",false),
    MIXPANEL("PDF31","MixPanel",false),
    HUBSPOT("PDF32","HubSpot",false),
    GOOGLETAGMANAGER("PDF33","Google Tag Manager",false),
    CRM("PDF15","Zoho CRM",true),
    DESK("PDF16","Zoho Desk",true),
    CAMPAIGN("PDF34","Zoho Campaigns",true),
    CLEARBITR("PDF35","Clearbit (Reveal)",true),
    CLEARBITE("PDF36","Clearbit (Enrichment)",true),
    SALESFORCE("PDF37","Salesforce",true),
    ZENDESK("PDF38","Zendesk",true),
    MAILCHIMP("PDF39","MailChimp",true),
    AWEBER("PDF40","Aweber",true),
    ACTIVECAMPAIGN("PDF41","Active Campaign",true),
    BRONTO("PDF42","Bronto",true),
    CAMPAIGNMONITOR("PDF43","Campaign Monitor",true),
    CAMPAIGNMASTER("PDF44","Campaignmaster",true),
    DOTMAILER("PDF45","dotMailer",true),
    GETRESPONSE("PDF46","GetResponse",true),
    ICONTACT("PDF47","Icontact",true),
    AUREA("PDF48","Aurea (Lyris)",true),
    MADMIMI("PDF49","Mad Mimi",true),
    VERTICALRESPONSE("PDF50","Vertical Response",true),
    WHATCOUNTS("PDF51","Whatcounts",true),
    CONTANTCONTACT("PDF52","Constant contact",true),
    ;

    public final String
    usecase_key,
    header
    ;

    public final boolean isAccessible;//for free plan

    Integration(String usecase_key,String header,boolean isAccessible)
    {
          this.usecase_key=usecase_key;
          this.header=header;
          this.isAccessible=isAccessible;
    }
}