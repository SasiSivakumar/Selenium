//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.List;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;

public class CommonWait 
{

	public static boolean waitTillDisplayed(WebDriver driver,By... by_objects)
	{
		return waitTillDisplayed(CommonUtil.getElement(driver,by_objects));	
	}	
	public static boolean waitTillHidden(WebDriver driver,By... by_objects)
	{
		return waitTillHidden(CommonUtil.getElement(driver,by_objects));	
	}	
	public static boolean waitTillDisplayed(WebElement element,By... by_objects)
	{
		return waitTillDisplayed(CommonUtil.getElement(element,by_objects));	
	}	
	public static boolean waitTillHidden(WebElement element,By... by_objects)
	{
		return waitTillHidden(CommonUtil.getElement(element,by_objects));	
	}	
	public static boolean waitTillDisplayed(WebElement ele)
	{
		return waitTillDisplayed(ele,true);
	}
	public static boolean waitTillHidden(WebElement ele)
	{
		return waitTillDisplayed(ele,false);
	}
	public static boolean waitTillDisplayed(final WebElement web_element,int waitFor,final boolean isDisplayed)
	{
		if(web_element==null)
		{
			if(isDisplayed)
			{
				return false;//not displayed as its null
			}
			else
			{
				return true;//hidden as its null
			}
		}
		
		FluentWait wait = new FluentWait(web_element);
		wait.withTimeout(waitFor,TimeUnit.SECONDS);
		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		wait.until(new Function<WebElement,Boolean>()
		{
			public Boolean apply(final WebElement web_element)
			{
				if(isDisplayed(web_element)==isDisplayed)
				{
					return true;
				}
				return false;
			}
		});

		return (isDisplayed(web_element)==isDisplayed);
	}

	//waiting for a period of time
	public static boolean waitTillDisplayed(WebDriver driver,int waitFor,By... by_objects)
	{
		return waitTillDisplayed(CommonUtil.getElement(driver,by_objects),waitFor);
	}	
	public static boolean waitTillHidden(WebDriver driver,int waitFor,By... by_objects)
	{
		return waitTillHidden(CommonUtil.getElement(driver,by_objects),waitFor);
	}	
	public static boolean waitTillDisplayed(WebElement element,int waitFor,By... by_objects)
	{
		return waitTillDisplayed(CommonUtil.getElement(element,by_objects),waitFor);
	}	
	public static boolean waitTillHidden(WebElement element,int waitFor,By... by_objects)
	{
		return waitTillHidden(CommonUtil.getElement(element,by_objects),waitFor);
	}
	public static boolean waitTillDisplayed(WebElement ele,int waitFor)
	{
		return waitTillDisplayed(ele,waitFor,true);
	}
	public static boolean waitTillHidden(WebElement ele,int waitFor)
	{
		return waitTillDisplayed(ele,waitFor,false);
	}
	public static boolean waitTillDisplayed(final WebElement web_element,final boolean isDisplayed)
	{
		return waitTillDisplayed(web_element,10,isDisplayed);
	}

	public static boolean waitTillPresent(final WebDriver driver,final By... by_objects)
	{
		return waitTillPresent(driver,true,by_objects);
	}

	public static boolean waitTillNotPresent(final WebDriver driver,final By... by_objects)
	{
		return waitTillPresent(driver,false,by_objects);
	}

	public static boolean waitTillPresent(final WebDriver driver,final boolean expected_is_present,final By... by_objects)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);

		wait.until(new Function<WebDriver,Boolean>()
		{
            public Boolean apply(WebDriver driver)
            {
                if(isPresent(driver,by_objects)==expected_is_present)
                {
                    return true;
                }
                return false;
            }
        });

        //exception will be throw if element not present
        return true;
	}

	public static boolean isDisplayed(WebDriver driver,By... by_objects)
	{
		if(isPresent(driver,by_objects)==false)
		{
			return false;
		}
		return isDisplayed(CommonUtil.getElement(driver,by_objects));
	}

	public static boolean isDisplayed(WebElement element,By... by_objects)
	{
		if(isPresent(element,by_objects)==false)
		{
			return false;
		}
		return isDisplayed(CommonUtil.getElement(element,by_objects));
	}

	public static boolean isDisplayed(WebElement element)
	{
		try
		{
			if(element==null)
			{
				return false;
			}
			if(isStale(element))
			{
				return false;
			}
			// if(element.getAttribute("style")!=null && element.getAttribute("style").contains("hidden"))
			// {
			// 	System.out.println("styte FALSE");
			// 	return false;	
			// }			
			// if(element.getAttribute("style")!=null && element.getAttribute("style").contains("block"))
			// {
			// 	return true;	
			// }
			return element.isDisplayed();
		}
		catch(StaleElementReferenceException e)
		{
			return false;
		}		
	}

	public static boolean isHidden(WebElement element)
	{
		return (!isDisplayed(element));
	}

	public static boolean isHidden(WebDriver driver,By... by_objects)
	{
		return (!isDisplayed(driver,by_objects));
	}

	public static boolean isPresent(WebDriver driver,By... by_objects)
	{
		WebElement container_element=driver.findElement(By.tagName("body"));
		return isPresent(container_element,by_objects);
	}

	public static boolean isPresent(WebElement container_element,By... by_objects)
	{
		WebElement web_element=null;

		try
		{
			for(By by_object : by_objects)
			{
				String by_value=CommonUtil.getByValue(by_object);

				String by_type=CommonUtil.getByType(by_object);

				boolean isCheckInnerHTML=true;

				if(by_type.equals("xpath") || by_type.equals("cssSelector") || by_type.equals("tagName"))
				{
					isCheckInnerHTML=false;
				}

				if(isCheckInnerHTML && container_element.getAttribute("innerHTML").contains(by_value)==false)
				{
					return false;
				}

				if(by_object == by_objects[0])
				{
					web_element=container_element.findElement(by_object);
				}
				else
				{
					List<WebElement> web_elements=web_element.findElements(by_object);

					if(web_elements.size()==0)
					{
						return false;
					}
					else
					{	
						web_element=web_elements.get(0);
					}			
				}
			}		
		}
		catch(Exception e)
		{
			return false;
		}

		if(web_element!=null)
		{
			return true;
		}

		return false;
	}

	public static boolean isCssSelectorPresent(WebDriver driver,By css_selector)
	{
		return (CommonUtil.getCssSelectorCount(driver,css_selector)>0);
	}

	public static boolean isStale(WebElement element)
	{
		try
		{
			element.isEnabled();//triggering any webelement method will trigger a staleness check
		}
		catch(StaleElementReferenceException e)
		{
			return true;
		}
		return false;
	}

	public static String waitTillURLChanges(final WebDriver driver,final String current_url)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,10,250);
		wait.until(new Function<WebDriver,Boolean>()
		{
            public Boolean apply(WebDriver driver)
            {
                if(driver.getCurrentUrl().equals(current_url)==false)
                {
                    return true;
                }
                return false;
            }
        });

        return driver.getCurrentUrl();
	}

	public static boolean waitTillElementsCountChange(final WebDriver driver,final By locator,final int current_count,final boolean waitTillIncrease)
	{
		return waitTillElementsCountChange(driver.findElement(By.tagName("body")),locator,current_count,waitTillIncrease);
	}


	public static boolean waitTillElementsCountChange(final WebElement element,final By locator,final int current_count,final boolean waitTillIncrease)
	{
		FluentWait wait = new FluentWait(element);
		wait.withTimeout(10,TimeUnit.SECONDS);
		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		if(waitTillIncrease)
		{
			wait.until(new Function<WebElement,Boolean>()
			{
				public Boolean apply(final WebElement web_element)
				{
					if(CommonUtil.getOccurences(element.getAttribute("innerHTML"),CommonUtil.getByValue(locator))>current_count)
					{
						return true;
					}
					return false;
				}
			});
		}
		else
		{
			if(current_count==0)
			{
				return true;
			}

			wait.until(new Function<WebElement,Boolean>()
			{
				public Boolean apply(final WebElement web_element)
				{
					if(CommonUtil.getOccurences(element.getAttribute("innerHTML"),CommonUtil.getByValue(locator))<current_count)
					{
						return true;
					}
					return false;
				}
			});
		}

		return true;//exception will occur if not true
	}

	public static boolean waitTillElementContains(final WebElement element,final String attribute)
	{
		return waitTillElementContains(element,attribute,true);
	}

	public static boolean waitTillElementDoesNotContains(final WebElement element,final String attribute)
	{
		return waitTillElementContains(element,attribute,false);
	}

	public static boolean waitTillElementContains(final WebElement element,final String attribute,boolean isWaitTillContains)
	{
		FluentWait wait = new FluentWait(element);
		wait.withTimeout(10,TimeUnit.SECONDS);
		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		wait.until(new Function<WebElement,Boolean>()
		{
			public Boolean apply(final WebElement web_element)
			{
				if( (element.getAttribute(attribute)!=null) == isWaitTillContains  )
				{
					return true;
				}
				return false;
			}
		});

		return true;
	}

	public static boolean waitTillElementContainsHTML(final WebElement element,String value)
	{
		return waitTillElementContainsValue(element,"innerHTML",value);
	}

	public static boolean waitTillElementContainsText(final WebElement element,String value)
	{
		return waitTillElementContainsValue(element,"innerText",value);
	}

	public static boolean waitTillElementContainsValue(final WebElement element,final String attribute,String value)
	{
		return waitTillElementContainsValue(element,attribute,value,true);
	}

	public static boolean waitTillElementContainsValue(final WebElement element,final String attribute,String value,boolean isWaitTillContains)
	{
		FluentWait wait = new FluentWait(element);
		wait.withTimeout(15,TimeUnit.SECONDS);
		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(StaleElementReferenceException.class);

		wait.until(new Function<WebElement,Boolean>()
		{
			public Boolean apply(final WebElement web_element)
			{
				if( element.getAttribute(attribute)==null && !isWaitTillContains)
				{
					return true;
				}
				else if( element.getAttribute(attribute)!=null && isWaitTillContains)
				{
					if(element.getAttribute(attribute).contains(value))
					{
						return true;
					}
				}

				return false;
			}
		});

		return true;
	}

}
