//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.ArrayList;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.zoho.livedesk.util.common.DistributedTest;


public class Distributor
{

    /*

    This class is used to split a module into multiple threads.
    
    To use this class, the test case class must implement DistributedTest interface.
    The code which is to be run in threads must be called inside the startThread method of the implemented class.

    To start the thread, create an object of the class and pass it into the Distributor object constructor. Then call the initate function of the distributor object

    Example:

    DistributedTestImplementedClass object = new DistributedTestImplementedClass();
    Distributor distributor = new Distributor(object,<no-of-simantaneous-threads>);
    distributor.initiate();

    */

    public DistributedTest distributed_test;
    public int no_of_threads;

    public Distributor(DistributedTest distributed_test,int no_of_threads)
    {
        this.distributed_test=distributed_test;
        this.no_of_threads=no_of_threads;
    }

    public void initiate()
    {
        ExecutorService executor = Executors.newFixedThreadPool(100);
         
        for (int i = 0; i < no_of_threads; i++)
        {
              Runnable worker = new MyRunnable(i);
              executor.execute(worker);
        }

        executor.shutdown();
          // Wait until all threads are finish
        while (!executor.isTerminated()) 
        {

        }

    }

    public class MyRunnable implements Runnable 
    {
        private int thread_number;
        
        MyRunnable(int thread_number) {
            this.thread_number = thread_number;
        }
        
        @Override
        public void run() {
            
            try
            {
                distributed_test.startThread(thread_number);
            }

            catch (Exception e)
            {
                System.out.println("Status: Exception  : "+e);
                e.printStackTrace();
            }
            System.out.println("Status: Success");
        }
    }


}
