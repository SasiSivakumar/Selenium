//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Action;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.List;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import java.util.Hashtable;
import java.util.Set;

import java.util.Collection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.lang3.StringUtils;
import java.util.UUID;
import org.openqa.selenium.Keys;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml4;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.Date;

public class DateTimeUtil
{
	public static boolean isToday(String time_in_millis)
	{
		Date date_obj = new Date(Long.parseLong(time_in_millis));
		return isToday(date_obj);
	}

	public static boolean isToday(Date date) 
	{
        return isSameDay(date, Calendar.getInstance().getTime());
    }

	public static boolean isSameDay(Date date1, Date date2) 
	{
        if (date1 == null || date2 == null) 
        {
            throw new IllegalArgumentException("The dates must not be null");
        }

        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);

        return isSameDay(cal1, cal2);
    }

     public static boolean isSameDay(Calendar cal1, Calendar cal2) 
    {
		if (cal1 == null || cal2 == null) 
		{
			throw new IllegalArgumentException("The dates must not be null");
        }

        return (cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) &&
                cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR));
    }

	public static String getCurrentTimeInFormat(String date_format)
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(date_format);  
		LocalDateTime now = LocalDateTime.now();  
		return dtf.format(now);
	}

	public static boolean isValidFormat(String format, String value) 
	{
		Locale locale=Locale.ENGLISH;
	    LocalDateTime ldt = null;
	    DateTimeFormatter fomatter = DateTimeFormatter.ofPattern(format, locale);

	    try 
	    {
	        ldt = LocalDateTime.parse(value, fomatter);
	        String result = ldt.format(fomatter);
	        return result.equals(value);
	    }

	    catch (DateTimeParseException e) 
	    {
	        try 
	        {
	            LocalDate ld = LocalDate.parse(value, fomatter);
	            String result = ld.format(fomatter);
	            return result.equals(value);
	        }
	        catch (DateTimeParseException exp) 
	        {
	            try
	            {
	                LocalTime lt = LocalTime.parse(value, fomatter);
	                String result = lt.format(fomatter);
	                return result.equals(value);
	            }
	            catch (DateTimeParseException e2) 
	            {
	                e2.printStackTrace();
	            }
	        }
	    }

	    return false;
	}
}
