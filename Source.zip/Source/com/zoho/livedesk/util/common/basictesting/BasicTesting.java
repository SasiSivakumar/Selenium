//$Id$
package com.zoho.livedesk.util.common.basictesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Method;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class BasicTesting extends Thread
{
  public static String test = "";
  public static String failureMessage = "";
  public static boolean TABS_RESULT = false;
  public static boolean BUSY_RESULT = false;
  public static boolean AVAILABLE_RESULT = false;
  public static boolean VISITOR_IN_RINGS = false;
  public static boolean INITIATE_AND_END_CHAT = false;
  public static boolean MISS_CHAT = false;
  public static boolean PROACTIVE_CHAT = false;
  public static boolean VISITORLEFT = false;

  public static boolean testInit() throws Exception
  {
    BasicTesting obj[] = {null,null,null};
    failureMessage = "";

    try
    {
      String username[] = {"integration","crm","webembed_real_time"};
      String embed[] = {"automation5","embed2","embed2"};
      String portal[] = {"automation5","ldautomation1","ldautomation2"};

      //Initaiting object
      for(int i = 0; i < 3;i++)
      {
        WebDriver driver = null;

        ExtentTest etest = ComplexReportFactory.getTest("Basic testing in Account - "+(i+1));
        ComplexReportFactory.setValues(etest,"Automation","Basic Testing");

        obj[i] = new BasicTesting(driver,etest,username[i],embed[i],portal[i]);
      }

      TABS_RESULT = check(obj,"Tab");

      if(!TABS_RESULT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      VISITOR_IN_RINGS = check(obj, "Visitor in rings");
      CheckVisitor.closeDriver();

      if(!VISITOR_IN_RINGS)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      Long t1 = new Long(System.currentTimeMillis());
      INITIATE_AND_END_CHAT = check(obj, "Chat Attended");
      CheckChat.closeDriver();

      if(!INITIATE_AND_END_CHAT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      for(;INITIATE_AND_END_CHAT;)
      {
        Long t2 = new Long(System.currentTimeMillis());
        if(t2 - t1 >= 200000)
        {
          break;
        }
      }

      MISS_CHAT = check(obj, "Chat Missed");
      CheckMiss.closeDriver();

      if(!MISS_CHAT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      PROACTIVE_CHAT = check(obj, "Pro-active chat");
      CheckProActive.closeDriver();

      if(!PROACTIVE_CHAT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      VISITORLEFT = check(obj, "Visitor leave the rings");

      if(!VISITORLEFT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      BUSY_RESULT = check(obj,"Status-Busy");

      if(!BUSY_RESULT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      AVAILABLE_RESULT = check(obj, "Status-Available");

      if(!AVAILABLE_RESULT)
      {
        failureMessage += "Out of 3 portals, basic testing failed in "+getResult(obj)+" portals\\n";
        logout(obj);
        return false;
      }

      logout(obj);

      return true;

    }
    catch(Exception e)
    {
      e.printStackTrace();
      return false;
    }
  }

  public static boolean check(BasicTesting obj[], String check) throws Exception
  {
    int result = 0;

    test = check;

    //Stopping current thread and re-initialising it
    for(int j=0;j<3;j++)
    {
      stopThread(obj[j]);
      obj[j] = new BasicTesting(obj[j].driver,obj[j].etest,obj[j].username,obj[j].embed,obj[j].portal,obj[j].loggedIn);
    }

    //Initaiting test
    for(int j=0;j<3;j++)
    {
      obj[j].start();
    }

    //Wait till atleast in 4 accounts gets passed
    for(int i =1;i<=300;i++)
    {
      result = 0;

      for(int j=0;j<3;j++)
      {
        if(obj[j].TESTRESULT)
        {
          result++;
        }
      }

      if(result >=2)
      {
        break;
      }
      if(obj[0].ENDED && obj[1].ENDED && obj[2].ENDED)
      {
        break;
      }
      Thread.sleep(1000);
    }

    //Wait till threads stopped
    for(int i =1;i<=60;i++)
    {
      if(obj[0].ENDED && obj[1].ENDED && obj[2].ENDED)
      {
        break;
      }

      Thread.sleep(1000);
    }

    if(result >= 2)
    {
      return true;
    }

    return false;
  }

  public static void stopThread(BasicTesting e) throws Exception
  {
      Method m = Thread.class.getDeclaredMethod( "stop0" , new Class[]{Object.class} );
      m.setAccessible( true );
      m.invoke( e , new ThreadDeath() );
  }

  public static void logout(BasicTesting obj[]) throws Exception
  {
    //Logout and end test
    for(int i = 0; i <3;i++)
    {
      Functions.logout(obj[i].driver);
      ComplexReportFactory.closeTest(obj[i].etest);
    }
  }

  public static int getResult(BasicTesting obj[]) throws Exception
  {
    int count = 0;
    //Logout and end test
    for(int i = 0; i <3;i++)
    {
      if(!obj[i].TESTRESULT)
      {
        count++;
      }
    }

    return count;
  }

  public WebDriver driver = null;
  public ExtentTest etest = null;
  public String embed = "";
  public String portal = "";
  public String username = "";
  public boolean loggedIn = false;
  public boolean ENDED = false;
  public boolean ENDTEST = false;
  public boolean TESTRESULT = false;

  BasicTesting(WebDriver driver, ExtentTest etest, String username, String embed, String portal)
  {
    this.driver = driver;
    this.etest = etest;
    this.username = username;
    this.embed = embed;
    this.portal = portal;
  }

  BasicTesting(WebDriver driver, ExtentTest etest, String username, String embed, String portal, boolean loggedIn)
  {
    this.driver = driver;
    this.etest = etest;
    this.username = username;
    this.embed = embed;
    this.portal = portal;
    this.loggedIn = loggedIn;
  }

  public void login() throws Exception
  {
    if(!loggedIn)
    {
      driver = Functions.setUp();
      loggedIn = Functions.login(driver,username);
    }
  }

  public void run()
  {
    try
    {
      this.login();

      if(test.equals("Tab"))
      {
        CheckTabs.TabTesting(this);
      }
      if(test.equals("Status-Busy"))
      {
        TESTRESULT = CheckStatus.checkStatus(this,"busy");
      }
      if(test.equals("Status-Available"))
      {
        TESTRESULT = CheckStatus.checkStatus(this,"available");
      }
      if(test.equals("Visitor in rings"))
      {
        TESTRESULT = CheckVisitor.checkVisitor(this);
      }
      if(test.equals("Chat Attended"))
      {
        TESTRESULT = CheckChat.checkChat(this);
      }
      if(test.equals("Chat Missed"))
      {
        TESTRESULT = CheckMiss.checkMiss(this);
      }
      if(test.equals("Pro-active chat"))
      {
        TESTRESULT = CheckProActive.checkProActive(this);
      }
      if(test.equals("Visitor leave the rings"))
      {
        TESTRESULT = CheckVisitorLeft.checkVisitorLeft(this);
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    this.ENDED = true;
  }
}
