//$Id$
package com.zoho.livedesk.util.common.basictesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class CheckVisitor
{
  public static Set<WebDriver> visDrivers = new HashSet();

  public static boolean checkVisitor(BasicTesting obj) throws Exception
  {
    WebDriver driver = obj.driver;
    ExtentTest etest = obj.etest;
    boolean result = false;
    int count = 0;

    for(int i = 1; i <= 5 ; i++)
    {
      try
      {
        WebDriver visDriver = Functions.setUp();
        visDrivers.add(visDriver);
        String id = "";
        try
        {
          VisitorWindow.createPage(visDriver,obj.embed,obj.portal);
          id = VisitorWindow.getVisitorId(visDriver,obj.portal);
          if(!id.contains("-"))
          {
            etest.log(Status.FAIL,"Incorrect visitor id - "+id);
            TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckVisitorInRings","Error");
            visDriver.quit();
            continue;
          }
        }
        catch(Exception e)
        {
          TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckVisitorInRings","Error",e);
          visDriver.quit();
          continue;
        }

        Tab.clickVisitorsOnline(driver);
        VisitorsOnline.waitTillVisitorPresent(driver,id);
        count++;
        visDriver.quit();
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(driver,etest,"BasicTesting","CheckVisitorInRings","Error",e);
      }
    }
    if(count >= 4)
    {
      etest.log(Status.INFO,"Visitor showing in rings is checked");
      return true;
    }
    return false;
  }

  public static void closeDriver() throws Exception
  {
    for(WebDriver driver : visDrivers)
    {
      try
      {
        driver.quit();
      }
      catch(Exception e)
      {}
    }

    visDrivers = new HashSet();
  }
}
