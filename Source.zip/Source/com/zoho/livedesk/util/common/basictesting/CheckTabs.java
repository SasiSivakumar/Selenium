//$Id$
package com.zoho.livedesk.util.common.basictesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class CheckTabs
{
  public static void TabTesting(BasicTesting obj) throws Exception
  {
    if(obj.loggedIn)
    {
      String content = checkAllTabs(obj);
      if(content.equals("Passed"))
      {
        obj.TESTRESULT = true;
      }
      else if(content.contains("COUNT"))
      {
        if(content.split("/")[0].equals("Passed"))
        {
          obj.TESTRESULT = true;
        }
      }
    }
    else
    {
      TakeScreenshot.screenshot(obj.driver,obj.etest,"BasicTesting","Login-"+obj.username,"Error");
    }
  }

  public static String checkAllTabs(BasicTesting obj) throws Exception
  {
    WebDriver driver = obj.driver;
    ExtentTest etest = obj.etest;
    String TABSTATUS = "Passed";
    int count = 0;

    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickSettings(driver);
      etest.log(Status.INFO,"Settings Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","OperatorsSettingsTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Operators Tab"):TABSTATUS+", Operators Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickAutomation(driver);
      etest.log(Status.INFO,"Chat monitor Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","ChatMonitorTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","ChatMonitor Tab"):TABSTATUS+", ChatMonitor Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickVisitorsOnline(driver);
      etest.log(Status.INFO,"Visitors Online Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","VisitorsOnlineTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Visitors Online Tab"):TABSTATUS+", Visitors Online Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickVisitorHistory(driver);
      etest.log(Status.INFO,"Visitor history Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","VisitorHistoryTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Visitor History Tab"):TABSTATUS+", Visitor History Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickChatHistory(driver);
      etest.log(Status.INFO,"Chat history Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","ChatHistoryTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Chat History Tab"):TABSTATUS+", Chat History Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickFeedback(driver);
      etest.log(Status.INFO,"Feedback Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","FeedbackTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Feebback Tab"):TABSTATUS+", Feebback Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickReports(driver);
      etest.log(Status.INFO,"Reports Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","ReportsTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Reports Tab"):TABSTATUS+", Reports Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickMyProfile(driver);
      etest.log(Status.INFO,"My Profile Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","MyProfileTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","My Profile Tab"):TABSTATUS+", My Profile Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToCompTab(driver);
      etest.log(Status.INFO,"Company Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","CompanyTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Company Tab"):TABSTATUS+", Company Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToDeptTab(driver);
      etest.log(Status.INFO,"Department Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","DepartmentTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Department Tab"):TABSTATUS+", Department Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToPortalTab(driver);
      etest.log(Status.INFO,"Portal Settings Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","PortalTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Portal Tab"):TABSTATUS+", Portal Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToBlockedIPTab(driver);
      etest.log(Status.INFO,"BlockedIP Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","BlockedIPTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","BlockedIP Tab"):TABSTATUS+", BlockedIP Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToEmbedTab(driver);
      etest.log(Status.INFO,"Web Embed Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","WebEmbedTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","WebEmbed Tab"):TABSTATUS+", WebEmbed Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToITTab(driver);
      etest.log(Status.INFO,"Triggers Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","TriggersTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Triggers Tab"):TABSTATUS+", Triggers Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToVRTab(driver);
      etest.log(Status.INFO,"Routing Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","RoutingTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Routing Tab"):TABSTATUS+", Routing Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.navToSchedulesTab(driver);
      etest.log(Status.INFO,"Schedules Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","SchedulesTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Schedules Tab"):TABSTATUS+", Schedules Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickLeadScoring(driver);
      etest.log(Status.INFO,"Lead scoring Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","LeadScoringTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","LeadScoring Tab"):TABSTATUS+", LeadScoring Tab";
    }
    try
    {
      if(obj.ENDTEST)
      {
        return TABSTATUS+"/COUNT-"+count;
      }
      Tab.clickInteg(driver);
      etest.log(Status.INFO,"Integration Tab is checked");
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","IntegrationTab","Error",e);
      TABSTATUS = TABSTATUS.contains("Passed")?TABSTATUS.replace("Passed","Integration Tab"):TABSTATUS+", Integration Tab";
    }

    return TABSTATUS;
  }
}
