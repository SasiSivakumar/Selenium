//$Id$
package com.zoho.livedesk.util.common.basictesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class CheckProActive
{
  public static Set<WebDriver> visDrivers = new HashSet();

  public static boolean checkProActive(BasicTesting obj) throws Exception
  {
    WebDriver driver = obj.driver;
    ExtentTest etest = obj.etest;
    boolean result = false;

    try
    {
      WebDriver visDriver = Functions.setUp();
      visDrivers.add(visDriver);
      String id = "";
      Long t = new Long(System.currentTimeMillis());

      try
      {
        VisitorWindow.createPage(visDriver,obj.embed,obj.portal);
        id = VisitorWindow.getVisitorId(visDriver,obj.portal);
        if(!id.contains("-"))
        {
          TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckProActiveChat","Error");
          return false;
        }
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckProActiveChat","Error",e);
        visDriver.quit();
        return false;
      }

      Tab.clickVisitorsOnline(driver);
      ChatWindow.initiateChat(driver,id,"Welcome!");

      try
      {
        VisitorWindow.sentMessage(visDriver,"Q"+t);
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckProActiveChat","Error",e);
        visDriver.quit();
        return false;
      }

      ChatWindow.continueChat(driver);
      ChatWindow.sentMessage(driver,"A"+t);

      try
      {
        if(!VisitorWindow.checkMessageInVisitorWindow(visDriver,"","A"+t))
        {
          etest.log(Status.FAIL,"A"+t+" is not visible");
          TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckProActiveChat","Error");
          return false;
        }
        VisitorWindow.sentMessage(visDriver,"VM"+t);
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckProActiveChat","Error",e);
        visDriver.quit();
        return false;
      }

      if(!ChatWindow.checkMessageInUserWindow(driver,"","VM"+t))
      {
        etest.log(Status.FAIL,"VM"+t+" is not visible");
        TakeScreenshot.screenshot(driver,etest,"BasicTesting","CheckProActiveChat","Error");
      }

      ChatWindow.endChat(driver);
      ChatWindow.clickClosethisWindow(driver);

      etest.log(Status.INFO,"Pro active chat is checked");
      visDriver.quit();
      return true;
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","CheckProActiveChat","Error",e);
        try
        {
            Functions.refreshSiteAndWaitForRSID(driver);
        }
        catch(Exception ee){}
    }

    return false;
  }

  public static void closeDriver() throws Exception
  {
    for(WebDriver driver : visDrivers)
    {
      try
      {
        driver.quit();
      }
      catch(Exception e)
      {}
    }

    visDrivers = new HashSet();
  }
}
