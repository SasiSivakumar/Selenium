//$Id$
package com.zoho.livedesk.util.common.basictesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class CheckMiss
{
  public static Set<WebDriver> visDrivers = new HashSet();

  public static boolean checkMiss(BasicTesting obj) throws Exception
  {
    WebDriver driver = obj.driver;
    ExtentTest etest = obj.etest;
    boolean result = false;
    Long t = new Long(System.currentTimeMillis());

    try
    {
      WebDriver visDriver = Functions.setUp();
      visDrivers.add(visDriver);
      String id = "";
      try
      {
        VisitorWindow.createPage(visDriver,obj.embed,obj.portal);
        VisitorWindow.initiateChatVis(visDriver,"V"+t,"email@"+t+".com",null,"Q"+t,etest);
        VisitorWindow.waitTillChatisMissed(visDriver);
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckChatMissed","Error",e);
        visDriver.quit();
        return false;
      }

      Thread.sleep(4000);

      Tab.clickSettings(driver);
      Tab.clickMissed(driver);
      WebElement e = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","missed_mcontent"),"classname","cursr-point");
      if(e.getText().contains("V"+t))
      {
        etest.log(Status.INFO,"Chat missed is checked");
        visDriver.quit();
        return true;
      }
      else
      {
        etest.log(Status.FAIL,"V"+t+" is not present");
        TakeScreenshot.screenshot(driver,etest,"BasicTesting","CheckChatMissed","Error");
      }
      visDriver.quit();
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","CheckChatMissed","Error",e);
    }

    return false;
  }

  public static void closeDriver() throws Exception
  {
    for(WebDriver driver : visDrivers)
    {
      try
      {
        driver.quit();
      }
      catch(Exception e)
      {}
    }

    visDrivers = new HashSet();
  }
}
