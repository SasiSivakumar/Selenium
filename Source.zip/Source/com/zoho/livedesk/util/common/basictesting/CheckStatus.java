//$Id$
package com.zoho.livedesk.util.common.basictesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class CheckStatus
{
  public static boolean checkStatus(BasicTesting obj,String status) throws Exception
  {
    WebDriver driver = obj.driver;
    ExtentTest etest = obj.etest;
    boolean result = false;

    try
    {
      com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status);
      etest.log(Status.INFO,"Status is changed to "+status);
      Thread.sleep(5000);
      WebDriver visDriver = Functions.setUp();
      try
      {
        VisitorWindow.createPage(visDriver,obj.embed,obj.portal);
        result = VisitorWindow.checkChatWidgetOffline(visDriver);
        if(status.equals("available") && result)
        {
          TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckChangeStatus","Error");
          visDriver.quit();
          return false;
        }
        else if(status.equals("busy") && !result)
        {
          TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckChangeStatus","Error");
          visDriver.quit();
          return false;
        }

        visDriver.quit();
        etest.log(Status.INFO,"Status changed to "+status+" is checked");
        return true;
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(visDriver,etest,"BasicTesting","CheckChangeStatus","Error",e);
      }

      visDriver.quit();
      return false;
    }
    catch(Exception e)
    {
      TakeScreenshot.screenshot(driver,etest,"BasicTesting","CheckChangeStatus","Error",e);
    }

    return false;
  }
}
