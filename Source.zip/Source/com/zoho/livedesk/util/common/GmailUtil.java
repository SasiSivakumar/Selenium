//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

import java.util.List;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;


public class GmailUtil 
{
	public static void login(WebDriver driver,String login_key)
	{
        String mail = ConfManager.getRealValue(login_key+"_username");
        String password = ConfManager.getRealValue(login_key+"_password");
		login(driver,mail,password);
	}

	public static void login(WebDriver driver,String mail,String password)
	{

		if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("<input id=\"Email\""))
		{
			CommonWait.waitTillDisplayed(driver,By.id("Email"));
			CommonUtil.getElement(driver,By.id("Email")).sendKeys(mail);

			CommonWait.waitTillDisplayed(driver,By.id("next"));
			CommonUtil.getElement(driver,By.id("next")).click();

			CommonWait.waitTillDisplayed(driver,By.id("Passwd"));
			CommonUtil.getElement(driver,By.id("Passwd")).sendKeys(password);

			CommonWait.waitTillDisplayed(driver,By.id("signIn"));
			CommonUtil.getElement(driver,By.id("signIn")).click();
		}
		else
		{
			CommonWait.waitTillDisplayed(driver,By.id("identifierId"));
			CommonUtil.getElement(driver,By.id("identifierId")).sendKeys(mail);

			CommonWait.waitTillDisplayed(driver,By.cssSelector(".RveJvd.snByac"));
			CommonUtil.getElement(driver,By.cssSelector(".RveJvd.snByac")).click();

			CommonWait.waitTillDisplayed(driver,By.name("password"));
			CommonUtil.getElement(driver,By.name("password")).sendKeys(password);

			CommonWait.waitTillDisplayed(driver,By.id("signIn"));
			CommonUtil.getElement(driver,By.cssSelector(".RveJvd.snByac")).click();
		}
	}

	public static WebElement searchAndGetMail(WebDriver driver,String search_key)
	{
		List<WebElement> input_tags=driver.findElements(By.tagName("input"));
		WebElement search_input=CommonUtil.getElementByAttributeValue(input_tags,"aria-label","Search");
		CommonWait.waitTillDisplayed(search_input);
		search_input.sendKeys(search_key);

		WebElement search_button=CommonUtil.getElementByAttributeValue(input_tags,"aria-label","Search Gmail");
		CommonWait.waitTillDisplayed(search_button);
		search_button.click();

		WebElement search_result=CommonUtil.getElement(driver,By.xpath("//*[@role='main']"));
		CommonWait.waitTillDisplayed(search_result);
		search_result.click();

		CommonWait.waitTillDisplayed(driver,By.xpath("//*[@role='list']"));

		return CommonUtil.getElement(driver,By.xpath("//*[@role='list']"));
	}

	public static boolean connectGoogleConnectionFromBots(WebDriver driver,ExtentTest etest)
	{
		etest.log(Status.INFO,"inner-->"+driver.findElement(By.tagName("body")).getAttribute("innerText"));

		com.zoho.livedesk.util.common.actions.bots.ManageConnections.handleNewAccountUI(driver,etest);

		enterCredentialsInGoogleLoginPage(driver,etest,ConfManager.getRealValue("bots_gmail_username"),ConfManager.getRealValue("bots_gmail_password"));

		etest.log(Status.INFO,"Password was entered in google");
		TakeScreenshot.infoScreenshot(driver,etest);

		CommonWait.waitTillPresent(driver,By.id("submit_approve_access"));
		CommonWait.waitTillDisplayed(driver,By.id("submit_approve_access"));
		WebElement allow=CommonUtil.getElement(driver,By.id("submit_approve_access"));

		CommonUtil.mouseHoverAndClick(driver,allow);

		etest.log(Status.INFO,"Submit was clicked in google");
		TakeScreenshot.infoScreenshot(driver,etest);

		return true;
	}

	public static void enterCredentialsInGoogleLoginPage(WebDriver driver,ExtentTest etest,String email,String password)
	{
		CommonWait.waitTillPresent(driver,By.cssSelector("input[type='email']"));
		CommonWait.waitTillDisplayed(driver,By.cssSelector("input[type='email']"));
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.cssSelector("input[type='email']")),email);
		CommonUtil.mouseHoverAndClick(driver, CommonUtil.getElement(driver,By.cssSelector("#identifierNext[role='button']")) );

		etest.log(Status.INFO,"Username was entered in google");
		TakeScreenshot.infoScreenshot(driver,etest);

		CommonWait.waitTillPresent(driver,By.cssSelector("input[type='password']"));
		CommonUtil.sleep(5000);
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.cssSelector("input[type='password']")),password);
		CommonUtil.mouseHoverAndClick(driver, CommonUtil.getElement(driver,By.cssSelector("#passwordNext[role='button']")) );
	}

	public static boolean isGoogleThirdpartyLoginPage(WebDriver driver)
	{
		return CommonWait.waitTillDisplayed(driver,By.cssSelector("[data-third-party-email*='@zohocorp.com']"));
	}
}
