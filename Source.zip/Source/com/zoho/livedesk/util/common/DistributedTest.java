//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;

public interface DistributedTest
{    
    public void startThread(int thread_number) throws Exception;
}
