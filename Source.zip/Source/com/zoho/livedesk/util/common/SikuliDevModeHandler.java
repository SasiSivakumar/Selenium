//$Id$
package com.zoho.livedesk.util.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;


public class SikuliDevModeHandler
{
    /***

    To use this class set "sikuli_development_mode" as true in livedeskconf.properties file

    Purpose : This class is used to filter the right sikuli screenshot for the usecase during development.

    To use this

    1. Take multiple screenshots (max : 5) of the UI which is under test and name it in the following format <image-name>_<index>. 
    For example for image "UI747.png" name the images as "UI747_1.png","UI747_2.png","UI747_3.png","UI747_4.png","UI747_5.png"

    Now when the test is run with "sikuli_develeopment_mode" as true. The screenshots which are passed will be filtered in a seperate folder.

    Once development is completed. set "sikuli_development_mode" as false.

    ***/

    public static boolean isSikuliDevMode()
    {
        String dev_mode=ConfManager.getRealValue("sikuli_development_mode");
        return Boolean.parseBoolean(dev_mode);
    }

    public static void findInWholePage(WebDriver driver,String imageName,String key,ExtentTest etest)
    {
        try
        {
            for(int i=1;i<=5;i++)
            {

                String loop_image=imageName.split(".png")[0];
                loop_image=loop_image+"_"+i+".png";

                String loop_key=key+"_"+i;

                String img_url=CommonSikuli.getImageURL(driver,loop_image);

                if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(img_url)==false)
                {
                    etest.log(Status.INFO,"Image does not exist : "+img_url);
                    break;
                }

                Boolean isPass=CommonSikuli.findInWholePageAndLog(driver,loop_image,loop_key,etest);

                String source=CommonSikuli.getImagePath(driver,loop_image);
                String destination=FileUpload.getBuildRoot()+"/webapps/selenium/Sikuliimages/DevModeFiltered/"+CommonSikuli.getFolderName(driver)+"/"+imageName;

                if(isPass)
                {
                    FileUpload.copyFile(source,destination);
                    etest.log(Status.PASS,"Screenshot is fit for checkin : "+source);
                }
                else
                {
                    etest.log(Status.INFO,"Screenshot is NOT fit for checkin : "+source);                
                }

                if(isPass)
                {
                    break;
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,e);
            e.printStackTrace();
        }
    }

}
