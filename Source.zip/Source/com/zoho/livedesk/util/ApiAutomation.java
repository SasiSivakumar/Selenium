//$Id$
package com.zoho.livedesk.util;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import java.net.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.yaml.snakeyaml.Yaml;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

import javax.mail.internet.MimeMessage;
import java.util.Properties;

import javax.mail.internet.InternetAddress;
import javax.mail.*;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.*;
import javax.activation.*;

import com.zoho.livedesk.server.ConfManager;

public class ApiAutomation
{
    private static final Logger LOGGER = Logger.getLogger(ApiAutomation.class.getName());
    public static String meetingKey;
    public static String ticket;
    public static String apiKey="ba9117d6d1235a2ccc9f7e902c257bb5";
    public static String mailId="anand.ramachandran@zohocorp.com";
    public static String topic;
    public static String userTimeZone;
    public static String webserver="https://salesiq.localzoho.com";
    public static String responseUrl;
    public static String userName="anand.ramachandran@zohocorp.com";
    public static String password="Ravar@420";
    public static String accountUrl="https://accounts.localzoho.com/";
    public static StringBuffer result = new StringBuffer("<b><u>API Automation:</u></b><br><br><b>Results :</b><br><br>"); // no i18n
    public static boolean success = true;
    public static String author="anand.ramachandran@zohocorp.com";
    private static int scount = 0;
    private static int fcount = 0;
    private static int tcount = 0;
    
    public void ApiAutomation()
    {
        
    }
    
    @BeforeClass
    public static void setUpClass() throws Exception
    {
        String data = "LOGIN_ID="+userName+"&PASSWORD="+password+"&FROM_AGENT=true&service=ZohoSalesIQ";//No I18N
        String url1 = accountUrl+"login";//No I18N
        // Send the request
        URL url = new URL(url1);//No I18N
        URLConnection conn = url.openConnection();//No I18N
        conn.setDoOutput(true);//No I18N
        
        OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());//No I18N
        
        //write parameters
        writer.write(data);//No I18N
        writer.flush();//No I18N
        
        // Get the response
        Properties clientProperties = new Properties ( ) ;//No I18N
        clientProperties.load ( conn.getInputStream ( ) ) ;//No I18N
        ticket = (String) clientProperties.get ("TICKET");//No I18N
        
        System.out.println(clientProperties);
        System.out.println(ticket);
    }
    
    @AfterClass
    public static void tearDownClass() throws Exception
    {
        String data = "ticket="+ticket;//No I18N
        String url1 = accountUrl+"logout";//No I18N
        // Send the request
        URL url = new URL(url1);//No I18N
        URLConnection conn = url.openConnection();//No I18N
        conn.setDoOutput(true);//No I18N
        OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());//No I18N
        
        //write parameters
        writer.write(data);//No I18N
        writer.flush();//No I18N
        
        Properties clientProperties = new Properties ( ) ;//No I18N
        clientProperties.load ( conn.getInputStream ( ) );//No I18N
        clientProperties.get ( "RESULT" );//No I18N
        sendMail(result.toString());//No I18N
    }
    
    public static void sendMail(String msg)
    {
        try{
            int i = 1;//No I18N
            while (i <= 1 )
            {
                
                String host = "smtp"; //NO i18N
                
                Properties properties = System.getProperties();
                
                properties.put("mail.smtp.host", host); //NO i18N
                properties.put("mail.smtp.auth","true");
                properties.put("mail.debug", "true");
                
                Authenticator auth = new Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication("anand-3214", "Anand_619");
                    }
                };
                
                Session session = Session.getDefaultInstance(properties,auth);
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress("anand.ramachandran@zohocorp.com"));//No I18N
                String[] members = author.split(",");
                InternetAddress[] address = new InternetAddress[members.length];
                for(int j=0;j<members.length;j++)
                {
                    if(members[j].indexOf("@")!= -1)
                    {
                        System.out.println(members[j]);
                        address[j] =new InternetAddress(members[j]);
                    }
                }
                
                message.addRecipients(Message.RecipientType.TO,address);
                
                System.out.println(address);
                
                int srate = (scount*100)/tcount;
                int frate = 100-srate;
                //int frate = (fcount*100)/tcount;
                String setUp;
                if(webserver.contains("labsalesiq"))
                {
                    setUp = "LabSalesIQ";
                }
                else if(webserver.contains("localzoho"))
                {
                    setUp = "LocalZoho";
                }
                else if(webserver.contains("presalesiq"))
                {
                    setUp = "PreIDC";
                }
                else if(webserver.contains("i18nsalesiq"))
                {
                    setUp = "I18N";
                }
                else
                {
                    setUp = "IDC";
                }
                
                
                String subject = "SalesIQ API Automation - "+setUp+" - Success - "+srate+"% | Failure - "+frate+"%";
                
                String imgurl = "https://www.zoho.com/salesiq/images/icon-salesiq.png";
                
                String chmsg = "{\"message\":\"API Automation\",\"formattedmsg\":[{\"type\"=\"table\",\"title\":\"Summary:\",\"data\":{\"headers\":[\"Total Use Cases\",\"Success\",\"Failure\",\"Success(%)\",\"Failure(%)\",\"Setup\"],\"rows\":[{\"Total Use Cases\":\""+tcount+"\",\"Success\":\""+scount+"\",\"Failure\":\""+fcount+"\",\"Success(%)\":\""+srate+"%\",\"Failure(%)\":\""+frate+"%\",\"Setup\":\""+setUp+"\"}]}}],\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\""+imgurl+"\",\"custom_message\":\"true\",\"msg_title\": \""+subject+"\",\"thumbnail_url\": \""+imgurl+"\"}";;
                
                sendResultAsChatMessage(chmsg);
                
                message.setSubject("SalesIQ API Automation - "+setUp+" - Success - "+srate+"% | Failure - "+frate+"%");//No I18N
                message.setContent(msg,"text/html;charset=UTF-8");//No I18N
                Transport.send(message);
                i++;
            }
        }
        catch(Exception e)
        {
            result.append("mail send ").append(" -> Failure<br>").append(e).append("<br><br>");//No I18N
            success=false;
            LOGGER.log(Level.SEVERE,"Exception in sendMail :",e);
        }
    }
    
    public static void sendResultAsChatMessage(String chmsg)
    {
        OutputStream os = null;
        
        try
        {
            String chID = ConfManager.getChannelID();
            String aToken = ConfManager.getAuthToken();
            
            URL url = new URL("https://chat.zoho.com/v1/channels/"+chID+"/message?authtoken="+aToken+"&scope=InternalAPI");
            System.out.println("Chat Util - URL : "+url+" Channel ID - "+chID+" Auth Token - "+aToken);
            
            HttpURLConnection httpcon = (HttpURLConnection) (url.openConnection());
            httpcon.setRequestMethod("POST");
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Content-Type", "application/json");
            
            //String outputBytes = "{\"message\":\""+chmsg+"\"}";//URLEncoder.encode(chmsg, "UTF-8")
            //String outputBytes = "{\"message\":{\"table\":\\"+chmsg+"\"}}";
            String outputBytes = chmsg;
            os = httpcon.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            //os.write(.URLEncoder.encode(data, "UTF-8"));
            os.flush();
            System.out.println("Chat Util - Response Code : "+httpcon.getResponseCode());
        }
        catch(Exception exp)
        {
            exp.printStackTrace();
        }
        finally
        {
            try
            {
                os.close();
            }
            catch(Exception exp)
            {
                exp.printStackTrace();
            }
        }
    }
    
    public void jsonPostTestAPI(String data1,String apiName)
    {
        try{
            String data = data1;
            // Send the request
            String url1 = webserver + data;
            
            URL url = new URL(url1);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            //write parameters
            //writer.write(data);
            writer.flush();
            
            // Get the response
            StringBuilder answer = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                answer.append(line);
            }
            writer.close();
            reader.close();
            
            //Output the response
            String body = answer.toString();
            
            System.out.println(body);
            
            JSONObject jso = new JSONObject(body);
            JSONObject out = (JSONObject) jso.get("RESPONSE");
            String status = jso.get("STATUSMSG").toString();
            
            System.out.println(out);
            System.out.println(status);
            
            if (status.equals("Success")) {
                //out = (JSONObject) out.get("welcomesalesi");
                LOGGER.log(Level.INFO, "{0} -> Success", apiName);
                result.append("JSON ").append(apiName).append(" -> Success<br><br>");
                success=true;
                scount++;
            } else if (out.has("error")) {//No I18N
                out = (JSONObject) out.get("error");
                LOGGER.log(Level.INFO, "{0} -> Failure", apiName+"   "+out.get("message"));
                result.append("JSON ").append(apiName).append(" -> Failure<br>").append(out.get("message")).append("<br><br>");//No I18N
                success=false;
                fcount++;
            } else {
                LOGGER.log(Level.INFO, "{0} -> Failure", apiName);
                result.append("JSON ").append(apiName).append(" -> Failure<br><br>");//No I18N
                success=false;
                fcount++;
            }
        }
        catch(Exception e)
        {
            result.append("JSON ").append(apiName).append(" -> Failure<br>").append(e).append("<br><br>");//No I18N
            success=false;
            fcount++;
            LOGGER.log(Level.SEVERE,"Exception in josnPostTest : ",e);
        }
    }
    
    public void jsonPostTestINT(String data1,String apiName)
    {
        try{
            String data = data1;
            // Send the request
            String url1 = webserver + data;
            
            URL url = new URL(url1);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            //write parameters
            //writer.write(data);
            writer.flush();
            
            // Get the response
            StringBuilder answer = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                answer.append(line);
            }
            writer.close();
            reader.close();
            
            //Output the response
            String body = answer.toString();
            
            System.out.println(body);
            
            JSONArray jso = new JSONArray(body);
            JSONObject out = (JSONObject) jso.get(0);
            String status = jso.get(0).toString();
            
            System.out.println(out);
            System.out.println(status);
            
            if (out.has("module")) {
                out = (JSONObject) out.get("objString");
                LOGGER.log(Level.INFO, "{0} -> Success", apiName);
                result.append("JSON ").append(apiName).append(" -> Success<br><br>");
                success=true;
                scount++;
            } else if (out.has("error")) {//No I18N
                out = (JSONObject) out.get("error");
                LOGGER.log(Level.INFO, "{0} -> Failure", apiName+"   "+out.get("message"));
                result.append("JSON ").append(apiName).append(" -> Failure<br>").append(out.get("message")).append("<br><br>");//No I18N
                success=false;
                fcount++;
            } else {
                LOGGER.log(Level.INFO, "{0} -> Failure", apiName);
                result.append("JSON ").append(apiName).append(" -> Failure<br><br>");//No I18N
                success=false;
                fcount++;
            }
        }
        catch(Exception e)
        {
            result.append("JSON ").append(apiName).append(" -> Failure<br>").append(e).append("<br><br>");//No I18N
            success=false;
            fcount++;
            LOGGER.log(Level.SEVERE,"Exception in josnPostTest : ",e);
        }
    }
    
    @Test
    public void portalListAPI()
    {
        tcount++;
        String data =  "/getportallist.api?ticket=" + ticket;
        jsonPostTestAPI(data,"API PortalList");//No I18N
        tcount++;
        data = "/getportallist.int?ticket=" + ticket;
        jsonPostTestINT(data,"INT PortalList");
    }
    
    @Test
    public void visitorInfoAPI()
    {
        tcount++;
        String data =  "/portaltest/getvisitorinfo.int?visitorid=4504000000264113&ticket=" + ticket;//4504000000264113
        jsonPostTestINT(data,"INT VisitorInfo");
        tcount++;
        data =  "/portaltest/getvisitorinfo.api?visitorid=4504000000264113&ticket=" + ticket;//4504000000264113
        jsonPostTestAPI(data,"API VisitorInfo");
    }
    
    @Test
    public void trackingFilterAPI()
    {
        tcount++;
        String data =  "/portaltest/gettrackingfilters.int?ticket=" + ticket;
        jsonPostTestINT(data,"INT TrackingFilters");
        /*tcount++;
         data =  "/portaltest/gettrackingfilters.api?ticket=" + ticket;
         jsonPostTestAPI(data,"API TrackingFilters");*/
    }	
}
