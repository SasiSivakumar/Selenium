//$Id$
package com.zoho.livedesk.util.stats;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ScheduledTask{
    
    public static String fromDateYMD = "2017-07-06";
    public static String toDateYMD = "2017-07-12";
    
    public static String fromDateSlashDMY = "06/07/2017";
    public static String toDateSlashDMY = "12/07/2017";
    
    public static String toDateMonth = "12-Jul-2017";
    public static String fromDateMonth = "05-Jul-2017";
    
    static Hashtable<String, String> fieldNames = new Hashtable<>();
    static ArrayList<String> responseValuesList = new ArrayList<>();
    static String responseBody = "";
    
    static String testChannel = "P1775998000000180083";//SalesIQ Test "P1775998000000180083"
    static String issuesChannel = "T1775998000000180099";
    static String performanceChannel = "T1775998000000334001";
    static String months[] = {null,"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    
    public static void runScheduledTask(){
        
        testChannel = "P1775998000000180083";
        issuesChannel = "P1775998000000180083";
        performanceChannel = "P1775998000000180083";
        
        String responseValues[] = {"5-6 sec","6-7 sec","7-8 sec","8-9 sec","9-10 sec","10-20 sec","20-30 sec","30-40 sec","40-50 sec","50-60 sec","1-10 min","11-20 min","21-30 min","31-40 min","41-50 min","51-60 min","1-2 hr"};
        
        fieldNames = new Hashtable<>();
        responseValuesList = new ArrayList<>();
        responseBody = "";
        
        int fieldNumber = 1;
        
        for(String s : responseValues)
        {
            fieldNames.put(s,"field"+(fieldNumber++));
            responseValuesList.add(s);
        }
        
        Calendar nowFrom = Calendar.getInstance();
        nowFrom.add(Calendar.DAY_OF_MONTH,-7);
        
        Calendar nowTo = Calendar.getInstance();
        nowTo.add(Calendar.DAY_OF_MONTH,-1);
        
        Calendar now = Calendar.getInstance();
        
        String[] date = getDate(nowFrom);
        fromDateYMD = date[2]+"-"+date[1]+"-"+date[0];
        
        date = getDate(nowTo);
        toDateYMD = date[2]+"-"+date[1]+"-"+date[0];
        
        date = getDate(nowFrom);
        fromDateSlashDMY = date[0]+"/"+date[1]+"/"+date[2];
        
        date = getDate(nowTo);
        toDateSlashDMY = date[0]+"/"+date[1]+"/"+date[2];
        
        date = getDate(nowFrom);
        fromDateMonth = date[0]+"-"+months[Integer.parseInt(date[1])]+"-"+date[2];
        
        date = getDate(now);
        toDateMonth = date[0]+"-"+months[Integer.parseInt(date[1])]+"-"+date[2];
        
        if(true){
            
            System.out.println(fromDateYMD);
            System.out.println(toDateYMD);
            System.out.println(fromDateSlashDMY);
            System.out.println(toDateSlashDMY);
            System.out.println(fromDateMonth);
            System.out.println(toDateMonth);
            
            try{
                
                String service="SalesIQ";
                String appid="36064526";
                String logsauth="2587f11456665213cdbe8914bd67b5e7";
                
                String aToken = "950da1ec26a20432c4aed79124a9283e";
                
                String gettotalcount1="";
                
                try{
                    String surl12 = "https://us3-logs.zoho.com/api/stats/statuscodestats/day/?total=true&service="+service+"&appid="+appid+"&date="+fromDateYMD+"&date="+toDateYMD+"&authtoken="+logsauth;
                    System.out.println("surl12<>"+surl12);
                    URL url12 = new URL(surl12);
                    
                    HttpURLConnection httpcon12 = (HttpURLConnection)(url12.openConnection());
                    httpcon12.setRequestMethod("GET");
                    httpcon12.setDoOutput(true);
                    httpcon12.setRequestProperty("Accept", "application/json");
                    InputStream in12 =  httpcon12.getInputStream();
                    String encoding12 = httpcon12.getContentEncoding();
                    encoding12 = encoding12 == null ? "UTF-8" : encoding12;
                    String body12 = IOUtils.toString( in12 , encoding12);
                    
                    
                    JSONParser parser12 = new JSONParser();
                    JSONObject json12 = (JSONObject) parser12.parse(body12);
                    JSONArray list12 = (JSONArray) json12.get("result");
                    ArrayList < String > mylist17 = new ArrayList < String > ();
                    ArrayList < String > mylist18 = new ArrayList < String > ();
                    ArrayList < String > mylist19 = new ArrayList < String > ();
                    
                    Hashtable<String, String> result7 = null;
                    Hashtable<String, String> result8 = null;
                    Hashtable<String, String> result9 = null;
                    
                    result7 = new Hashtable<String, String>();
                    
                    
                    result7.put("rs1", "");
                    result7.put("rs2", "");
                    
                    result8 = new Hashtable<String, String>();
                    result8.put("rs1", "");
                    result8.put("rs2", "");
                    
                    result9 = new Hashtable<String, String>();
                    result9.put("rs1", "");
                    result9.put("rs2", "");
                    
                    for (int i = 0; i < list12.size(); i++) {
                        
                        JSONObject exn12 = (JSONObject) list12.get(i);
                        String excep12 = exn12.get("STATUS_CODE").toString();
                        String excepone12 = exn12.get("STATUS_NAME").toString();
                        String exceptwo12 = exn12.get("COUNT").toString();
                        
                        
                        if(excep12.equals("500")){
                            result7.put("rs1",excep12);
                            result8.put("rs1",excepone12);
                            result9.put("rs1",exceptwo12);
                            
                        }
                        else if(excep12.equals("505")){
                            result7.put("rs2",excep12);
                            result8.put("rs2",excepone12);
                            result9.put("rs2",exceptwo12);
                        }
                    }
                    
                    for(int i=1;i<=2;i++){
                        System.out.println(result9.get("rs"+i));
                        if(result9.get("rs"+i) != ""){
                            mylist19.add((String) result9.get("rs"+i));
                            mylist17.add((String) result7.get("rs"+i));
                            mylist18.add((String) result8.get("rs"+i));
                            
                        }
                    }
                    
                    String totalCountURL = "https://us3-logs.zoho.com/search?service="+service+"&fromDateTime="+fromDateSlashDMY+"%2000:00&toDateTime="+toDateSlashDMY+"%2023:59&order=desc&range=1-100&appid="+appid+"&query=logtype%3D%22access%22&authtoken="+logsauth;
                    System.out.println("totalCountURL<>"+totalCountURL);
                    gettotalcount1= totalcount(totalCountURL);
                    
                    int hash121 = Integer.parseInt(mylist19.get(0));
                    int hash122 = Integer.parseInt(mylist19.get(1));
                    int hash124 = Integer.parseInt(gettotalcount1);
                    
                    float diff121=(((float)hash121/hash124))*100;
                    float diff122=(((float)hash122/hash124))*100;
                    
                    DecimalFormat dfff = new DecimalFormat("#.000000000000000");
                    String diff125=dfff.format(diff121);
                    String diff126=dfff.format(diff122);
                    
                    String getrecone= getrecord(toDateMonth);
                    
                    if(getrecone.equals("Success")){
                        System.out.println("update executed");
                        updaterecord(diff125,diff126,toDateMonth);
                    }
                    
                    Hashtable<String, String> getrectwo= getrecordtwo(fromDateMonth);
                    
                    String hash1=getrectwo.get("ct1").toString();
                    String hash2=getrectwo.get("ct2").toString();
                    
                    float hash7 = Float.parseFloat(hash1);
                    float hash8 = Float.parseFloat(hash2);
                    
                    float hash127 = Float.parseFloat(diff125);
                    float hash128 = Float.parseFloat(diff126);
                    
                    float diff1=(((float)hash127-hash7)/hash7)*100;
                    float diff2=(((float)hash128-hash8)/hash8)*100;
                    
                    DecimalFormat df = new DecimalFormat("#.00");
                    String diff4=df.format(diff1);
                    String diff5=df.format(diff2);
                    
                    ArrayList < String > mylist21 = new ArrayList < String > ();
                    mylist21.add(diff4);
                    mylist21.add(diff5);
                    
                    ArrayList < String > mylist27 = new ArrayList < String > ();
                    for(int i=0;i<2;i++){
                        String key="\u2191";
                        if(mylist21.get(i).equals("-")){
                            mylist27.add(mylist21.get(i));
                        }
                        else if(mylist21.get(i).contains("-")){
                            mylist27.add(mylist21.get(i).replaceAll("-", "\u2193"));
                        }
                        
                        else{
                            mylist27.add(key.concat(mylist21.get(i)));
                        }
                        
                    }
                    
                    String table_cont12 = "";
                    for (int i = 0; i < mylist17.size(); i++) {
                        if (!table_cont12.equals("")) {
                            table_cont12 += ",{";
                        }
                        
                        table_cont12 += "\"Status code\":\"" + mylist17.get(i) + "\",\"Status name\":\"" + mylist18.get(i) + "\",\"Count\":\"" + mylist19.get(i) + "\",\"Weekly difference\":\"" + mylist27.get(i) +" %"+ "\"";
                        
                        if (!(i == mylist17.size() - 1)) {
                            table_cont12 += "}";
                        }
                        
                    }
                    
                    System.out.println(table_cont12);
                    
                    
                    //                    String  content12 = "{\"message\":\"*Total accessed url count - "+gettotalcount1+"*\",\"formattedmsg\":[{\"type\":\"table\",\"title\":\" Status stats\",\"data\":{\"headers\":[\"Status code\",\"Status name\",\"Count\",\"Weekly difference\"],\"rows\":[{" + table_cont12 + "},]}}]"
                    //                    +",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/chat/images/icon-chat.png\",\"custom_message\":\"true\"}";
                    
                    String  content12 = "{\"message\":\"Status Stats | Weekly Diff | Total accessed url count - "+gettotalcount1+"\",\"formattedmsg\":[{\"type\":\"table\",\"title\":\" Status stats\",\"data\":{\"headers\":[\"Status code\",\"Status name\",\"Count\",\"Weekly difference\"],\"rows\":[{" + table_cont12 + "},]}}]"
                    +",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/chat/images/icon-chat.png\",\"custom_message\":\"true\"}";
                    
                    String chID12 = issuesChannel;
                    
                    OutputStream os13 = null;
                    URL url13 = new URL("https://cliq.zoho.com/api/v1/channels/" + chID12 + "/message?authtoken=" + aToken + "&scope=InternalAPI");
                    
                    HttpURLConnection httpcon13 = (HttpURLConnection)(url13.openConnection());
                    httpcon13.setRequestMethod("POST");
                    httpcon13.setDoOutput(true);
                    httpcon13.setRequestProperty("Content-Type", "application/json");
                    
                    String outputBytes13 = content12;
                    os13 = httpcon13.getOutputStream();
                    os13.write(outputBytes13.getBytes("UTF-8"));
                    
                    os13.flush();
                    System.out.println("Chat Util Initial Message - Response Code : " + httpcon13.getResponseCode());
                    
                }catch(Exception e){System.out.println("Status code stats---"+e);e.printStackTrace();}
                
                try{
                    
                    String chIDpost = issuesChannel;
                    
                    String tble1=sendChat("https://us3-logs.zoho.com/search?service="+service+"&fromDateTime="+fromDateSlashDMY+"%2000:00&toDateTime="+toDateSlashDMY+"%2023:59&order=desc&range=1-100&appid="+appid+"&query=logtype%3D%22access%22%20AND%20status%3D%22500%22%20GROUPBY%20request_uri&authtoken="+logsauth);
                    String tble2=sendChat("https://us3-logs.zoho.com/search?service="+service+"&fromDateTime="+fromDateSlashDMY+"%2000:00&toDateTime="+toDateSlashDMY+"%2023:59&order=desc&range=1-100&appid="+appid+"&query=logtype%3D%22access%22%20AND%20status%3D%22505%22%20GROUPBY%20request_uri&authtoken="+logsauth);
                    
                    postChat(tble1,tble2,"Status code - 500:Internal Server Error","Status code - 505:HTTP Version not supported",aToken,chIDpost);
                    
                    
                }catch(Exception e){System.out.println("Detailed status code stats---"+e);e.printStackTrace();}
                
                String surl1 = "https://us3-logs.zoho.com/api/stats/responsetimestats/day/?total=true&service="+service+"&appid="+appid+"&date="+fromDateYMD+"&date="+toDateYMD+"&authtoken="+logsauth;
                System.out.println("surl1<>"+surl1);
                URL url1 =  new URL(surl1);
                HttpURLConnection httpcon1 = (HttpURLConnection)(url1.openConnection());
                httpcon1.setRequestMethod("GET");
                httpcon1.setDoOutput(true);
                httpcon1.setRequestProperty("Accept", "application/json");
                InputStream in =  httpcon1.getInputStream();
                String encoding = httpcon1.getContentEncoding();
                encoding = encoding == null ? "UTF-8" : encoding;
                String body = IOUtils.toString( in , encoding);
                
                responseBody = body;
                
                JSONParser parser3 = new JSONParser();
                JSONObject json3 = (JSONObject) parser3.parse(body);
                JSONArray list3 = (JSONArray) json3.get("result");
                
                ArrayList < String > mylist1 = new ArrayList < String > ();
                ArrayList < String > mylist2 = new ArrayList < String > ();
                
                ArrayList < String > testing1 = new ArrayList < String > ();
                ArrayList < String > testing2 = new ArrayList < String > ();
                
                try{
                    for (int i = list3.size()-1; i >=list3.size()-10; i--) {
                        
                        JSONObject exn3test = (JSONObject) list3.get(i);
                        String exceptest = exn3test.get("FORMATTED_TIME").toString();
                        String exceponetest = exn3test.get("COUNT").toString();
                        
                        testing1.add(exceptest);
                        testing2.add(exceponetest);
                        
                    }
                    String testing3= testChannel;
                    postchatfive(testing1,testing2,testing3,aToken);
                    
                } catch(Exception e){e.printStackTrace();}
                
                
                ArrayList < String > starttym = new ArrayList < String > ();
                ArrayList < String > responsetym = new ArrayList < String > ();
                
                try{
                    for (int i = list3.size()-1; i >=list3.size()-20; i--) {
                        
                        JSONObject exn3 = (JSONObject) list3.get(i);
                        String excep = exn3.get("FORMATTED_TIME").toString();
                        String excepone = exn3.get("COUNT").toString();
                        String sttime = exn3.get("START_TIME").toString();
                        String resptime = exn3.get("RESPONSE_TIME").toString();
                        
                        if(responseValuesList.contains(excep)){
                            mylist1.add(excep);
                            mylist2.add(excepone);
                            
                            starttym.add(sttime);
                            responsetym.add(resptime);
                            
                            if(mylist1.size()==10){
                                System.out.println("size--"+10);
                                break;
                            }
                        }
                    }
                    
                }catch(Exception e){System.out.println("Exception in getting data");e.printStackTrace();}
                
                int hash221 = Integer.parseInt(mylist2.get(0));
                int hash222 = Integer.parseInt(mylist2.get(1));
                int hash223 = Integer.parseInt(mylist2.get(2));
                int hash224 = Integer.parseInt(mylist2.get(3));
                int hash225 = Integer.parseInt(mylist2.get(4));
                int hash226 = Integer.parseInt(mylist2.get(5));
                int hash227 = Integer.parseInt(mylist2.get(6));
                int hash228 = Integer.parseInt(mylist2.get(7));
                int hash229 = Integer.parseInt(mylist2.get(8));
                int hash230 = Integer.parseInt(mylist2.get(9));
                int hash231 = Integer.parseInt(gettotalcount1);
                
                
                float diff221=(((float)hash221/hash231))*100;
                float diff222=(((float)hash222/hash231))*100;
                float diff223=(((float)hash223/hash231))*100;
                float diff224=(((float)hash224/hash231))*100;
                float diff225=(((float)hash225/hash231))*100;
                float diff226=(((float)hash226/hash231))*100;
                float diff227=(((float)hash227/hash231))*100;
                float diff228=(((float)hash228/hash231))*100;
                float diff229=(((float)hash229/hash231))*100;
                float diff230=(((float)hash230/hash231))*100;
                
                DecimalFormat dfff2 = new DecimalFormat("#.000000000000000");
                String diff241=dfff2.format(diff221);
                String diff242=dfff2.format(diff222);
                String diff243=dfff2.format(diff223);
                String diff244=dfff2.format(diff224);
                String diff245=dfff2.format(diff225);
                String diff246=dfff2.format(diff226);
                String diff247=dfff2.format(diff227);
                String diff248=dfff2.format(diff228);
                String diff249=dfff2.format(diff229);
                String diff250=dfff2.format(diff230);
                
                ArrayList < String > starttym3 = new ArrayList < String > ();
                starttym3.add(diff241);
                starttym3.add(diff242);
                starttym3.add(diff243);
                starttym3.add(diff244);
                starttym3.add(diff245);
                starttym3.add(diff246);
                starttym3.add(diff247);
                starttym3.add(diff248);
                starttym3.add(diff249);
                starttym3.add(diff250);
                
                String getrecthree= getrecordthree(toDateMonth);
                
                System.out.println("getrecthree<>"+getrecthree+"<>");
                
                if(getrecthree.equals("Success")){
                    
                    
                    updaterecordtwo(mylist1,starttym3,toDateMonth);
                    
                }
                
                Hashtable<String, String> getrecfour= getrecordfour(mylist1,fromDateMonth);
                
                
                
                String hash21=getrecfour.get("ct1").toString();
                String hash22=getrecfour.get("ct2").toString();
                String hash23=getrecfour.get("ct3").toString();
                String hash24=getrecfour.get("ct4").toString();
                String hash25=getrecfour.get("ct5").toString();
                String hash26=getrecfour.get("ct6").toString();
                String hash27=getrecfour.get("ct7").toString();
                String hash28=getrecfour.get("ct8").toString();
                String hash29=getrecfour.get("ct9").toString();
                String hash30=getrecfour.get("ct10").toString();
                
                
                
                
                float hash41=0,hash42=0,hash43=0,hash44=0,hash45=0,hash46=0,hash47=0,hash48=0,hash49=0,hash50=0;
                
                hash41 = Float.parseFloat(starttym3.get(0));
                hash42 = Float.parseFloat(starttym3.get(1));
                hash43 = Float.parseFloat(starttym3.get(2));
                hash44 = Float.parseFloat(starttym3.get(3));
                hash45 = Float.parseFloat(starttym3.get(4));
                hash46 = Float.parseFloat(starttym3.get(5));
                hash47 = Float.parseFloat(starttym3.get(6));
                hash48 = Float.parseFloat(starttym3.get(7));
                hash49 = Float.parseFloat(starttym3.get(8));
                hash50 = Float.parseFloat(starttym3.get(9));
                
                
                
                
                
                float hash61=0,hash62=0,hash63=0,hash64=0,hash65=0,hash66=0,hash67=0,hash68=0,hash69=0,hash70=0;
                
                hash61 = Float.parseFloat(hash21);
                hash62 = Float.parseFloat(hash22);
                hash63 = Float.parseFloat(hash23);
                hash64 = Float.parseFloat(hash24);
                hash65 = Float.parseFloat(hash25);
                hash66 = Float.parseFloat(hash26);
                hash67 = Float.parseFloat(hash27);
                hash68 = Float.parseFloat(hash28);
                hash69 = Float.parseFloat(hash29);
                hash70 = Float.parseFloat(hash30);
                
                
                float diff61=0,diff62=0,diff63=0,diff64=0,diff65=0,diff66=0,diff67=0,diff68=0,diff69=0,diff70=0;
                diff61=((float)(hash41-hash61)/hash61)*100;
                diff62=((float)(hash42-hash62)/hash62)*100;
                diff63=((float)(hash43-hash63)/hash63)*100;
                diff64=((float)(hash44-hash64)/hash64)*100;
                diff65=((float)(hash45-hash65)/hash65)*100;
                diff66=((float)(hash46-hash66)/hash66)*100;
                diff67=((float)(hash47-hash67)/hash67)*100;
                diff68=((float)(hash48-hash68)/hash68)*100;
                diff69=((float)(hash49-hash69)/hash69)*100;
                diff70=((float)(hash50-hash70)/hash70)*100;
                
                
                
                DecimalFormat df1 = new DecimalFormat("#.00");
                String diff81=df1.format(diff61);
                String diff82=df1.format(diff62);
                String diff83=df1.format(diff63);
                String diff84=df1.format(diff64);
                String diff85=df1.format(diff65);
                String diff86=df1.format(diff66);
                String diff87=df1.format(diff67);
                String diff88=df1.format(diff68);
                String diff89=df1.format(diff69);
                String diff90=df1.format(diff70);
                
                System.out.println("diff----");
                System.out.println(diff81);
                System.out.println(diff82);
                System.out.println(diff83);
                System.out.println(diff84);
                System.out.println(diff85);
                System.out.println(diff86);
                System.out.println(diff87);
                System.out.println(diff88);
                System.out.println(diff89);
                System.out.println(diff90);
                
                
                
                ArrayList < String > mylist101 = new ArrayList < String > ();
                mylist101.add(diff81);
                mylist101.add(diff82);
                mylist101.add(diff83);
                mylist101.add(diff84);
                mylist101.add(diff85);
                mylist101.add(diff86);
                mylist101.add(diff87);
                mylist101.add(diff88);
                mylist101.add(diff89);
                mylist101.add(diff90);
                
                
                ArrayList < String > mylist102 = new ArrayList < String > ();
                for(int i=0;i<10;i++){
                    if(mylist101.get(i).contains(".")){
                        mylist102.add(mylist101.get(i)+" %");
                    }
                    else{
                        mylist102.add("-");
                    }
                }
                
                
                ArrayList < String > mylist107 = new ArrayList < String > ();
                for(int i=0;i<10;i++){
                    String key="\u2191";
                    if(mylist102.get(i).equals("-")){
                        mylist107.add(mylist102.get(i));
                    }
                    else if(mylist102.get(i).contains("-")){
                        mylist107.add(mylist102.get(i).replaceAll("-", "\u2193"));
                    }
                    
                    else{
                        mylist107.add(key.concat(mylist102.get(i)));
                    }
                    
                }
                
                String table_content = "";
                for (int i = 0; i < mylist1.size(); i++) {
                    
                    
                    if (!table_content.equals("")) {
                        table_content += ",{";
                    }
                    if(!mylist1.get(i).equals("0")){
                        table_content += "\"Response time\":\"" + mylist1.get(i) + "\",\"Count\":\"" + mylist2.get(i) + "\",\"Weekly difference\":\"" + mylist107.get(i) + "\"";
                    }
                    if (!(i == mylist1.size() - 1)) {
                        table_content += "}";
                    }
                    
                    
                }
                System.out.println(table_content);
                
                String  content2 = "{\"message\":\"Response Time Stats | Weekly Diff | Total accessed url count - "+gettotalcount1+"\",\"formattedmsg\":[{\"type\":\"table\",\"title\":\" Last 7 days response time stats\",\"data\":{\"headers\":[\"Response time\",\"Count\",\"Weekly difference\"],\"rows\":[{" + table_content + "},]}}]"
                +",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/chat/images/icon-chat.png\",\"custom_message\":\"true\"}";
                
                
                String chID2 = performanceChannel;
                OutputStream os2 = null;
                URL url5 = new URL("https://cliq.zoho.com/api/v1/channels/" + chID2 + "/message?authtoken=" + aToken + "&scope=InternalAPI");
                System.out.println("Chat Util - URL : "+url5+" chat ID - "+chID2+" Auth Token - "+aToken);
                
                HttpURLConnection httpcon5 = (HttpURLConnection)(url5.openConnection());
                httpcon5.setRequestMethod("POST");
                httpcon5.setDoOutput(true);
                httpcon5.setRequestProperty("Content-Type", "application/json");
                
                String outputBytes2 = content2;
                os2 = httpcon5.getOutputStream();
                os2.write(outputBytes2.getBytes("UTF-8"));
                
                os2.flush();
                System.out.println("Chat Util Initial Message - Response Code : " + httpcon5.getResponseCode());
                
                String chIDpostresurl = performanceChannel;
                
                Hashtable<String, String> tableValues5 = new Hashtable<String, String>();
                
                for(int i=0;i<10;i++){
                    
                    String tble4=sendChat2("Response time:"+mylist1.get(i),"https://us3-logs.zoho.com/search?service="+service+"&fromDateTime="+fromDateSlashDMY+"%2000:00&toDateTime="+toDateSlashDMY+"%2023:59&order=desc&range=1-100&appid="+appid+"&query=logtype%3D%22access%22%20AND%20time_taken%3E%3D"+starttym.get(i)+"%20AND%20time_taken%3C%3D"+responsetym.get(i)+"%20GROUPBY%20request_uri&authtoken="+logsauth);
                    tableValues5.put("Response time:"+mylist1.get(i),tble4);
                }
                System.out.println("<><>"+tableValues5);
                
                String headloop= "" ;
                
                for(int i = 0; i<mylist1.size();i++)
                {
                    if(mylist1.get(i).equals("0"))
                    {
                        continue;
                    }
                    
                    String hdloop = "Response time:"+mylist1.get(i);
                    String contloop = tableValues5.get(hdloop);
                    
                    String  headloop1="{\"type\":\"table\",\"title\":\""+hdloop+" \",\"data\":{\"headers\":[\"Request_uri\",\"Count\"],\"rows\":[" + contloop + "]}}";
                    
                    if(!headloop.equals(""))
                    {
                        headloop += ","+headloop1;
                    }
                    else
                    {
                        headloop += headloop1;
                    }
                    
                }
                
                
                OutputStream os8=null;
                String  content8="";
                
                content8 = "{\"message\":\"Detailed response time stats\",\"theme\":\"1\""
		            		+ ",\"formattedmsg\":["
                //		            		+ "{\"type\":\"list\",\"title\":\"Duration\",\"data\":[\""+fromDateSlashDMY+" 00:00 hrs to "+toDateSlashDMY+" 23:59 hrs\"]},"
		            		+headloop+"]"
                +",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/chat/images/icon-chat.png\",\"custom_message\":\"true\"}";
                
                System.out.println("<><>"+content8);
                
                URL url77 = new URL("https://cliq.zoho.com/api/v1/channels/" + chIDpostresurl + "/message?authtoken=" + aToken + "&scope=InternalAPI");
                
                HttpURLConnection httpcon77 = (HttpURLConnection)(url77.openConnection());
                httpcon77.setRequestMethod("POST");
                httpcon77.setDoOutput(true);
                httpcon77.setRequestProperty("Content-Type", "application/json");
                
                String outputBytes8 = content8;
                
                os8 = httpcon77.getOutputStream();
                os8.write(outputBytes8.getBytes("UTF-8"));
                
                os8.flush();
                System.out.println("Chat Util Initial Message - Response Code : " + httpcon77.getResponseCode());
                
                
            }catch(Exception e){System.out.println("Response time stats---"+e);e.printStackTrace();}
            
            
            
        }
        
        
        
    }
    
    public static Hashtable<String, String> getrecordfour(ArrayList<String> list,String dt2) {
        Hashtable<String, String> result = null;
        
        try {
            result = new Hashtable<String, String>();
            
            String urlParameters = "authtoken=1059521783101aeafc90e4797c7132f2";
            URL url = new URL("https://creator.zoho.com/api/json/salesiq-logs-analysis/view/SalesIQ_performance_stats_Report");
            URLConnection conn = url.openConnection();
            
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            writer.write(urlParameters);
            writer.flush();
            
            InputStream in =  conn.getInputStream();
            String encoding = conn.getContentEncoding();
            encoding = encoding == null ? "UTF-8" : encoding;
            String body = IOUtils.toString( in , encoding);
            
            body = body.replace("var zohorenganathan.kview79 = ", "");
            body = body.replace("};", "}");
            
            JSONParser parser3 = new JSONParser();
            JSONObject json3 = (JSONObject) parser3.parse(body);
            JSONArray list3 = (JSONArray) json3.get("SalesIQ_performance_stats");
            
            JSONObject currentValues = null;
            
            for(int i = 0; i < list3.size();i++)
            {
                JSONObject s = (JSONObject) list3.get(i);
                
                if(s.get("Last_Updated_Date").equals(dt2))
                {
                    currentValues = s;
                    break;
                }
            }
            
            int i = 1;
            
            for(String s : list)
            {
                if(currentValues.get(fieldNames.get(s)) == null || currentValues.get(fieldNames.get(s)).equals(""))
                {
                    result.put("ct"+(i++), "0.0");
                }
                else
                {
                    result.put("ct"+(i++), (String) currentValues.get(fieldNames.get(s)));
                }
                
            }
            
            writer.close();
            
            return result;
        } catch (Exception exp) {
            exp.printStackTrace();
            System.out.println("Exception occurred");
            return null;
            
        }
    }
    
    
    public static String totalcount(String chmsg) {
        
        String total_count = "";
        try {
            URL url2 =  new URL(chmsg);
            HttpURLConnection httpcon2 = (HttpURLConnection)(url2.openConnection());
            httpcon2.setRequestMethod("GET");
            httpcon2.setDoOutput(true);
            httpcon2.setRequestProperty("Accept", "application/json");
            InputStream inn =  httpcon2.getInputStream();
            String encoding2 = httpcon2.getContentEncoding();
            encoding2 = encoding2 == null ? "UTF-8" : encoding2;
            String body2 = IOUtils.toString( inn , encoding2);
            
            
            JSONParser parser4 = new JSONParser();
            JSONObject json4 = (JSONObject) parser4.parse(body2);
            
            String excep5 = json4.get("numFound").toString();
            total_count = excep5;
            return total_count;
            
            
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
        
    }
    
    public static String getrecordthree(String dt) {
        String check1="";
        try {
            
            
            String urlParameters = "authtoken=1059521783101aeafc90e4797c7132f2";
            URL url = new URL("https://creator.zoho.com/api/json/salesiq-logs-analysis/view/SalesIQ_performance_stats_Report");
            URLConnection conn = url.openConnection();
            
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            writer.write(urlParameters);
            writer.flush();
            
            InputStream in =  conn.getInputStream();
            String encoding = conn.getContentEncoding();
            encoding = encoding == null ? "UTF-8" : encoding;
            String body = IOUtils.toString( in , encoding);
            
            body = body.replace("var zohorenganathan.kview79 = ", "");
            body = body.replace("};", "}");
            
            JSONParser parser3 = new JSONParser();
            JSONObject json3 = (JSONObject) parser3.parse(body);
            JSONArray list3 = (JSONArray) json3.get("SalesIQ_performance_stats");
            
            ArrayList < String > mylist1 = new ArrayList < String > ();
            
            for (int i = 0; i <=list3.size()-1; i++) {
                
                JSONObject exn3 = (JSONObject) list3.get(i);
                
                String excepfour = exn3.get("Last_Updated_Date").toString();
                
                mylist1.add(excepfour);
                
                
            }
            
            writer.close();
            
            
            if(mylist1.contains(dt)){
                check1="Failure";
                System.out.println("failure");
            }
            else{
                check1="Success";
                System.out.println("success");
            }
            return check1;
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
    }
    
    public static void updaterecordtwo(ArrayList<String> list1, ArrayList<String> list2, String dt) {
        
        try {
            String params = "";
            
            for(int i = 0; i< list1.size(); i++)
            {
                String field = fieldNames.get(list1.get(i));
                String param = list2.get(i);
                
                params += "&"+field+"="+param;
            }
            String urlParameters = "authtoken=1059521783101aeafc90e4797c7132f2"+params+"&Last_Updated_Date="+dt;
            URL url = new URL("https://creator.zoho.com/api/renganathan.k/json/salesiq-logs-analysis/form/SalesIQ_performance_stats/record/add/");
            
            URLConnection conn = url.openConnection();
            
            conn.setDoOutput(true);
            
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            writer.write(urlParameters);
            writer.flush();
            
            String line;
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            writer.close();
            reader.close();
            
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    public static Hashtable<String, String> getrecordtwo(String dt2) {
        Hashtable<String, String> result = null;
        String excep="";
        String exceptwo="";
        
        try {
            result = new Hashtable<String, String>();
            
            String urlParameters = "authtoken=1059521783101aeafc90e4797c7132f2";
            URL url = new URL("https://creator.zoho.com/api/json/salesiq-logs-analysis/view/SalesIQ_issue_stats_Report");
            URLConnection conn = url.openConnection();
            
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            writer.write(urlParameters);
            writer.flush();
            
            InputStream in =  conn.getInputStream();
            String encoding = conn.getContentEncoding();
            encoding = encoding == null ? "UTF-8" : encoding;
            String body = IOUtils.toString( in , encoding);
            
            body = body.replace("var zohorenganathan.kview80 = ", "");
            body = body.replace("};", "}");
            
            JSONParser parser3 = new JSONParser();
            JSONObject json3 = (JSONObject) parser3.parse(body);
            JSONArray list3 = (JSONArray) json3.get("Status_Code_Stats");
            
            
            for (int i = 0; i <=list3.size()-1; i++) {
                
                JSONObject exn3 = (JSONObject) list3.get(i);
                String excepfour = exn3.get("Last_Updated_Date").toString();
                
                if(excepfour.equals(dt2)){
                    excep = exn3.get("field500").toString();
                    exceptwo = exn3.get("field505").toString();
                }
                
            }
            
            writer.close();
            result.put("ct1",excep);
            result.put("ct2",exceptwo);
            
            return result;
        } catch (Exception exp) {
            exp.printStackTrace();
            System.out.println("Exception occurred");
            return null;
            
        }
    }
    
    
    public static String getrecord(String dt) {
        String check1="";
        try {
            
            
            String urlParameters = "authtoken=1059521783101aeafc90e4797c7132f2";
            URL url = new URL("https://creator.zoho.com/api/json/salesiq-logs-analysis/view/SalesIQ_issue_stats_Report");
            URLConnection conn = url.openConnection();
            
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            writer.write(urlParameters);
            writer.flush();
            
            InputStream in =  conn.getInputStream();
            String encoding = conn.getContentEncoding();
            encoding = encoding == null ? "UTF-8" : encoding;
            String body = IOUtils.toString( in , encoding);
            
            body = body.replace("var zohorenganathan.kview80 = ", "");
            body = body.replace("};", "}");
            
            JSONParser parser3 = new JSONParser();
            JSONObject json3 = (JSONObject) parser3.parse(body);
            JSONArray list3 = (JSONArray) json3.get("Status_Code_Stats");
            
            ArrayList < String > mylist4 = new ArrayList < String > ();
            
            for (int i = 0; i <=list3.size()-1; i++) {
                
                JSONObject exn3 = (JSONObject) list3.get(i);
                
                String excepfour = exn3.get("Last_Updated_Date").toString();
                
                mylist4.add(excepfour);
                
            }
            
            writer.close();
            
            
            if(mylist4.contains(dt)){
                check1="Failure";
                System.out.println("failure");
            }
            else{
                check1="Success";
                System.out.println("success");
            }
            return check1;
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
    }
    
    public static void updaterecord(String count1,String count2,String dt) {
        
        try {
            
            
            String urlParameters = "authtoken=1059521783101aeafc90e4797c7132f2&field500="+count1+"&field505="+count2+"&Last_Updated_Date="+dt;
            URL url = new URL("https://creator.zoho.com/api/renganathan.k/json/salesiq-logs-analysis/form/Status_Code_Stats/record/add/");
            
            URLConnection conn = url.openConnection();
            
            conn.setDoOutput(true);
            
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            
            writer.write(urlParameters);
            writer.flush();
            
            String line;
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            writer.close();
            reader.close();
            
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    public static String sendChat2(String val,String chmsg) {
        
        System.out.println("sendChat2<>"+val+"<>"+chmsg);
        String table_cont = "{";
        try {
            URL url2 =  new URL(chmsg);
            HttpURLConnection httpcon2 = (HttpURLConnection)(url2.openConnection());
            httpcon2.setRequestMethod("GET");
            httpcon2.setDoOutput(true);
            httpcon2.setRequestProperty("Accept", "application/json");
            InputStream inn =  httpcon2.getInputStream();
            String encoding2 = httpcon2.getContentEncoding();
            encoding2 = encoding2 == null ? "UTF-8" : encoding2;
            String body2 = IOUtils.toString( inn , encoding2);
            
            
            JSONParser parser4 = new JSONParser();
            JSONObject json4 = (JSONObject) parser4.parse(body2);
            JSONArray list4 = (JSONArray) json4.get("tableValues");
            
            ArrayList < String > mylist3 = new ArrayList < String > ();
            ArrayList < String > mylist4 = new ArrayList < String > ();
            for (int i = 0; i <list4.size(); i++) {
                
                JSONObject exn5 = (JSONObject) list4.get(i);
                String excep5 = exn5.get("groupby(request_uri)").toString();
                String excep6 = exn5.get("count").toString();
                mylist3.add(excep5);
                mylist4.add(excep6);
                
            }
            
            
            for (int i = 0; i < mylist3.size(); i++) {
                if (!table_cont.equals("{")) {
                    table_cont += ",{";
                }
                
                table_cont += "\"Request_uri\":\"" + mylist3.get(i) + "\",\"Count\":\"" + mylist4.get(i) + "\"";
                
                table_cont += "}";
            }
            
            return table_cont;
            
            
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
        
    }
    
    public static String sendChat(String chmsg) {
        
        String table_cont = "";
        try {
            System.out.println("sendChat<>"+chmsg);
            URL url2 =  new URL(chmsg);
            HttpURLConnection httpcon2 = (HttpURLConnection)(url2.openConnection());
            httpcon2.setRequestMethod("GET");
            httpcon2.setDoOutput(true);
            httpcon2.setRequestProperty("Accept", "application/json");
            InputStream inn =  httpcon2.getInputStream();
            String encoding2 = httpcon2.getContentEncoding();
            encoding2 = encoding2 == null ? "UTF-8" : encoding2;
            String body2 = IOUtils.toString( inn , encoding2);
            
            
            JSONParser parser4 = new JSONParser();
            JSONObject json4 = (JSONObject) parser4.parse(body2);
            JSONArray list4 = (JSONArray) json4.get("tableValues");
            
            ArrayList < String > mylist3 = new ArrayList < String > ();
            ArrayList < String > mylist4 = new ArrayList < String > ();
            for (int i = 0; i <list4.size(); i++) {
                
                JSONObject exn5 = (JSONObject) list4.get(i);
                String excep5 = exn5.get("groupby(request_uri)").toString();
                String excep6 = exn5.get("count").toString();
                mylist3.add(excep5);
                mylist4.add(excep6);
                
            }
            
            
            for (int i = 0; i < mylist3.size(); i++) {
                if (!table_cont.equals("")) {
                    table_cont += ",{";
                }
                
                table_cont += "\"Request_uri\":\"" + mylist3.get(i) + "\",\"Count\":\"" + mylist4.get(i) + "\"";
                
                if (!(i == mylist3.size() - 1)) {
                    table_cont += "}";
                }
                
            }
            return table_cont;
            
            
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
        
    }
    
    
    public static void postChat(String table_cont1,String table_cont2,String heading1,String heading2,String tok,String chidpost) {
        OutputStream os = null;
        
        try {
            //fromDateSlashDMY+" 00:00 hrs to "+toDateSlashDMY+" 23:59 hrs
            String  content = "{\"message\":\"Detailed Status code stats\",\"theme\":\"1\",\"formattedmsg\":["
            + "{\"type\":\"table\",\"title\":\""+heading1+" \",\"data\":{\"headers\":[\"Request_uri\",\"Count\"],\"rows\":[{" + table_cont1 + "},]}},"
            + "{\"type\":\"table\",\"title\":\""+heading2+" \",\"data\":{\"headers\":[\"Request_uri\",\"Count\"],\"rows\":[{" + table_cont2 + "},]}},"
            + "]}}]"
            +",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/chat/images/icon-chat.png\",\"custom_message\":\"true\"}";
            
            
            System.out.println(content);
            
            URL url7 = new URL("https://cliq.zoho.com/api/v1/channels/" + chidpost + "/message?authtoken=" + tok + "&scope=InternalAPI");
            
            HttpURLConnection httpcon7 = (HttpURLConnection)(url7.openConnection());
            httpcon7.setRequestMethod("POST");
            httpcon7.setDoOutput(true);
            httpcon7.setRequestProperty("Content-Type", "application/json");
            
            String outputBytes = content;
            os = httpcon7.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            //os.write(.URLEncoder.encode(data, "UTF-8"));
            os.flush();
            System.out.println("Chat Util Initial Message - Response Code : " + httpcon7.getResponseCode());
            
            
            
        } catch (Exception exp) {
            exp.printStackTrace();
        } finally {
            try {
                os.close();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
        }
    }
    
    public static void postchatfive(ArrayList<String> res5, ArrayList<String> res6,String chidpost,String tok) {
        OutputStream os = null;
        
        try {
            
            String  content = "{\"message\":\""+res5+res6+"\",\"theme\":\"1\",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/chat/images/icon-chat.png\",\"custom_message\":\"true\"}";
            
            
            
            
            URL url7 = new URL("https://cliq.zoho.com/api/v1/channels/" + chidpost + "/message?authtoken=" + tok + "&scope=InternalAPI");
            
            HttpURLConnection httpcon7 = (HttpURLConnection)(url7.openConnection());
            httpcon7.setRequestMethod("POST");
            httpcon7.setDoOutput(true);
            httpcon7.setRequestProperty("Content-Type", "application/json");
            
            String outputBytes = content;
            os = httpcon7.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            
            os.flush();
            System.out.println("Chat Util Initial Message - Response Code : " + httpcon7.getResponseCode());
            
            
            
        } catch (Exception exp) {
            exp.printStackTrace();
        } finally {
            try {
                os.close();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
        }
        
    }
    
    public static String[] getDate(Calendar now)
    {
        String year = "", month = "", day = "";
        
        year = ""+now.get(Calendar.YEAR);
        if(now.get(Calendar.MONTH)+1 <= 9)
        {
            month = "0"+(now.get(Calendar.MONTH)+1);
        }
        else
        {
            month = ""+(now.get(Calendar.MONTH)+1);
        }
        if(now.get(Calendar.DAY_OF_MONTH) <= 9)
        {
            day = "0"+now.get(Calendar.DAY_OF_MONTH);
        }
        else
        {
            day = ""+now.get(Calendar.DAY_OF_MONTH);
        }
        
        String date[] = {day,month,year};
        return date;
    }
}
