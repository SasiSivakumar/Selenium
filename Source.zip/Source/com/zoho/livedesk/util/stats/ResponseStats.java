//$Id$
package com.zoho.livedesk.util.stats;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Set;

import com.zoho.livedesk.util.*;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ResponseStats {
    
    public static String service = "SalesIQ";
    public static String appid = "36064526";
    public static String logsAuth = "4b84566c486219e023dc94e8ce5a308f";
    public static String logsURL = "us3-logs.zoho.com";
    
    public static String fromDate = null;
    public static String toDate = null;
    
    public static String fromDateYMD = null;
    
    public static String fromTime = null;
    public static String toTime = null;
    
    public static ArrayList<String> responseValues = new ArrayList<>(Arrays.asList("1-2 hr","51-60 min","41-50 min","31-40 min","21-30 min","11-20 min","1-10 min","50-60 sec","40-50 sec","30-40 sec","20-30 sec","10-20 sec","9-10 sec","8-9 sec","7-8 sec"
                                                                                   //			,"6-7 sec","5-6 sec"
                                                                                   ));
    
    public static Hashtable<String, String> startTime = null;
    public static Hashtable<String, String> endTime = null;
    
    public static Hashtable<String, JSONArray> formattedTimeHourValues = null;
    public static Hashtable<String, Long> formattedTimeCount = null;
    
    public class RSDummyClass2 extends Thread{
        
        public Long t11;
        public Long t12;
        
        public RSDummyClass2(Long t21, Long t22) {
            System.out.println("RSDummyClass2<>t21<>"+t21);
            System.out.println("RSDummyClass2<>t22<>"+t22);
            t11 = t21;
            t12 = t22;
        }
        
        public void run()
        {
            try
            {
                Thread.sleep(60000*60);
                callResponseStats(t11, t12);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String args[]) throws Exception
    {
        Long automationStartTime = new Long(System.currentTimeMillis()-(60000*60*24));
        Long automationEndTime = new Long(System.currentTimeMillis());
        
        ResponseStats rs = new ResponseStats();
        rs.new RSDummyClass2(automationStartTime, automationEndTime).start();
    }
    
    public static void callResponseStats(Long automationStartTime, Long automationEndTime) throws Exception
    {
        System.out.println("callResponseStats<>started");
        
        Boolean local = true;
        startTime = new Hashtable<>();
        endTime = new Hashtable<>();
        
        formattedTimeHourValues = new Hashtable<>();
        formattedTimeCount = new Hashtable<>();
        
        Calendar now1 = Calendar.getInstance();
        now1.setTimeInMillis(automationStartTime);
        String dateF[] = getDate(now1);
        
        Calendar now2 = Calendar.getInstance();
        now2.setTimeInMillis(automationEndTime);
        String dateT[] = getDate(now2);
        
        fromDate = dateF[0]+"/"+dateF[1]+"/"+dateF[2];
        toDate = dateT[0]+"/"+dateT[1]+"/"+dateT[2];
        
        fromTime = dateF[3]+":"+dateF[4];
        toTime = dateT[3]+":"+dateT[4];
        
        fromDateYMD = dateF[2]+"-"+dateF[1]+"-"+dateF[0];
        
        System.out.println(fromDate+"-"+fromTime);
        System.out.println(toDate+"-"+toTime);
        System.out.println(fromDateYMD);
        
        if(local)
        {
            logsAuth = "ed82b10938606db3d5b4b78ca2789d8a";
            logsURL = "solrlogs.localzoho.com";
            appid = "10772528";
        }
        
        getResponseStats();
        addValues(automationStartTime, automationEndTime);
        
        System.out.println(formattedTimeCount);
        
        sentDetailedResponse();
    }
    
    public static void getResponseStats() throws Exception
    {
        String surl1= "https://"+logsURL+"/api/stats/responsetimestats/hour/?total=true&service="+service+"&appid="+appid+"&date="+fromDateYMD+"&authtoken="+logsAuth;
        
        System.out.println("getResponseStats<>"+surl1);
        URL url1 =  new URL(surl1);
        HttpURLConnection httpcon1 = (HttpURLConnection)(url1.openConnection());
        httpcon1.setRequestMethod("GET");
        httpcon1.setDoOutput(true);
        httpcon1.setRequestProperty("Accept", "application/json");
        InputStream in =  httpcon1.getInputStream();
        String encoding = httpcon1.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString( in , encoding);
        
        System.out.println("getResponseStats<>"+body);
        System.out.println("getResponseStats<><><>");
        
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(body);
        
        JSONArray list = (JSONArray) json.get("result");
        
        for(int i = 0; i<list.size();i++)
        {
            JSONObject s = (JSONObject) list.get(i);
            
            String formatted_time = s.get("FORMATTED_TIME").toString();
            String st = s.get("START_TIME").toString();
            String r = s.get("RESPONSE_TIME").toString();
            JSONArray listValues = (JSONArray) s.get("List");
            if(responseValues.contains(formatted_time))
            {
                formattedTimeHourValues.put(formatted_time, listValues);
                startTime.put(formatted_time, st);
                endTime.put(formatted_time, r);
            }
        }
    }
    
    public static void addValues(Long t1, Long t2) throws Exception
    {
        Set<String> formattedTimes = formattedTimeHourValues.keySet();
        for(String s : formattedTimes)
        {
            JSONArray list = formattedTimeHourValues.get(s);
            for(int i = 0; i < list.size(); i++)
            {
                JSONObject val = (JSONObject) list.get(i);
                
                Long t = (Long) val.get("_TIME");
                Long count = (Long) val.get("COUNT");
                
                if(count == 0)
                {
                    continue;
                }
                
                if(t > t1-(3600000) && t < t2+(3600000))
                {
                    Long oldCount = formattedTimeCount.get(s);
                    
                    if(oldCount == null)
                    {
                        oldCount = 0L;
                    }
                    
                    count += oldCount;
                    
                    formattedTimeCount.put(s,count);
                }
            }
        }
        
        
        String tablecontent = "";
        
        for(String s : responseValues)
        {
            Long content = formattedTimeCount.get(s);
            
            if(content == null)
            {
                continue;
            }
            
            String row = "\"Response time\":\""+s+"\",\"Count\":\""+content+"\"";
            
            if(tablecontent.equals(""))
            {
                tablecontent = "{"+row+"}";
            }
            else
            {
                tablecontent += ",{"+row+"}";
            }
        }
        
        String  content = "{\"text\":\"Response Time Stats\",\"slides\":[{\"type\":\"table\",\"title\":\" Response time stats during Automation\",\"data\":{\"headers\":[\"Response time\",\"Count\"],\"rows\":["+tablecontent+"]}}]"
        +","
        +"\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/chat/images/icon-chat.png\"}}";
        
        ChatUtil.sendResultAsChatMessageForException(content);
    }
    
    public static void sentDetailedResponse() throws Exception
    {
        String headloop = "";
        
        Hashtable<String, String> tableContents = new Hashtable<>();
        
        for(String s : responseValues)
        {
            String stTime = startTime.get(s);
            
            if(stTime == null)
            {
                continue;
            }
            
            Long count = formattedTimeCount.get(s);
            
            if(count == null)
            {
                continue;
            }
            
            String eTime = endTime.get(s);
            
            String url = "https://"+logsURL+"/search?service="+service+"&fromDateTime="+fromDate+"%20"+fromTime+"&toDateTime="+toDate+"%20"+toTime+"&order=desc&range=1-100&appid="+appid+"&query=logtype%3D%22access%22%20AND%20time_taken%3E%3D"+stTime+"%20AND%20time_taken%3C%3D"+eTime+"%20GROUPBY%20request_uri&authtoken="+logsAuth;
            
            tableContents.put("Response time:"+s,detailedResponse(url));
        }
        
        int tableCount = 0;
        for(String s : responseValues)
        {
            String hdloop = "Response time:"+s;
            String contloop = tableContents.get(hdloop);
            
            if(contloop == null)
            {
                continue;
            }
            
            if(contloop.equals(""))
            {
                continue;
            }
            
            String  headloop1="{\"type\":\"table\",\"title\":\""+hdloop+" \",\"data\":{\"headers\":[\"Request_uri\",\"Count\"],\"rows\":[" + contloop + "]}}";
            
            if(!headloop.equals(""))
            {
                headloop += ","+headloop1;
            }
            else
            {
                headloop = headloop1;
            }
            
            tableCount++;
            
            if(tableCount == 10)
            {
                break;
            }
        }
        
        String content = "{\"text\":\"Detailed response time stats\","
        +"\"card\":{\"theme\":\"1\"}"
        + ",\"formattedmsg\":["
        +headloop+"]"
        +","
        +"\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/chat/images/icon-chat.png\"}}";
        
        ChatUtil.sendResultAsChatMessageForException(content);
    }
    
    public static String detailedResponse(String surl) {
        
        String table_cont = "";
        try {
            URL url =  new URL(surl);
            HttpURLConnection httpcon = (HttpURLConnection)(url.openConnection());
            httpcon.setRequestMethod("GET");
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Accept", "application/json");
            InputStream in =  httpcon.getInputStream();
            String encoding = httpcon.getContentEncoding();
            encoding = encoding == null ? "UTF-8" : encoding;
            String body = IOUtils.toString( in , encoding);
            
            
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(body);
            
            System.out.println(surl);
            System.out.println(body);
            System.out.println("<><>");
            
            JSONArray list = (JSONArray) json.get("tableValues");
            
            for (int i = 0; i <list.size(); i++) {
                
                JSONObject exn5 = (JSONObject) list.get(i);
                String uri = exn5.get("groupby(request_uri)").toString();
                String count = exn5.get("count").toString();
                
                if (table_cont.equals("")) {
                    table_cont = "{";
                }
                else{
                    table_cont += ",{";
                }
                
                table_cont += "\"Request_uri\":\"" + uri + "\",\"Count\":\"" + count + "\"";
                
                table_cont += "}";
            }
            
            
            return table_cont;
            
            
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
        
    }
    
    public static String[] getDate(Calendar now)
    {
        String year = "", month = "", day = "", hour = "", minute = "";
        year = ""+now.get(Calendar.YEAR);
        if(now.get(Calendar.MONTH)+1 <= 9){
            month = "0"+(now.get(Calendar.MONTH)+1);
        }
        else{
            month = ""+(now.get(Calendar.MONTH)+1);
        }
        if(now.get(Calendar.DAY_OF_MONTH) <= 9){
            day = "0"+now.get(Calendar.DAY_OF_MONTH);
        }
        else{
            day = ""+now.get(Calendar.DAY_OF_MONTH);
        }
        if(now.get(Calendar.HOUR_OF_DAY) <= 9){
            hour = "0"+now.get(Calendar.HOUR_OF_DAY);
        }
        else{
            hour = ""+now.get(Calendar.HOUR_OF_DAY);
        }
        
        if(now.get(Calendar.MINUTE) <= 9){
            minute = "0"+now.get(Calendar.MINUTE);
        }
        else{
            minute = ""+now.get(Calendar.MINUTE);
        }
        String date[] = {day,month,year,hour,minute};
        return date;
    }
}
