//$Id$
package com.zoho.livedesk.util.stats;

import java.util.ArrayList;
import java.util.Calendar;

public class ScheduledMain {
    
    public static Boolean status = false;
    
    public static void callMain() throws Exception {
        
        status = true;
        
        ArrayList<String> date = new ArrayList<>();
        
        for(;;)
        {
            Calendar now = Calendar.getInstance();
            
            int currentDay = now.get(Calendar.DAY_OF_WEEK);
            int currentHour = now.get(Calendar.HOUR_OF_DAY);
            int currentMinute = now.get(Calendar.MINUTE);
            String currentDate[] = ScheduledTask.getDate(now);
            String s = currentDate[0]+"-"+currentDate[1]+"-"+currentDate[2];
            
            if(currentDay == 2 && currentHour == 8 && (currentMinute >= 1 && currentMinute <= 10) && !date.contains(s))
            {
                System.out.println("currentHour:"+currentHour);
                System.out.println("currentMinute:"+currentMinute);
                System.out.println("currentDay:"+currentDay);
                System.out.println("currentDate:"+s);
                
                date.add(s);
                ScheduledTask.runScheduledTask();
            }
            
            if(!status)
            {
                break;
            }
            
            Thread.sleep(60000*5);
        }
    }
    
    public class RSDummyClass3 extends Thread{
        
        public RSDummyClass3() {
        }
        
        public void run()
        {
            try
            {
                callMain();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
