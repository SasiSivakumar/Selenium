//$Id$
package com.zoho.livedesk.util;

import com.beust.testng.TestNG;

import com.zoho.qa.server.CommondMethods;

import com.zoho.qa.server.TestNGreportGen;
import com.zoho.qa.server.WebdriverApiHub;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.WebdriverTestContainer;

import com.zoho.qa.server.WebdriverTestServer;
import com.zoho.qa.server.WebdriverTestsuite;
import com.zoho.qa.server.WebdriverTestsuiteProvider;
//import com.zoho.writer.TestSuite;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;

import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;

import java.util.List;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import org.testng.ITestNGListener;

import org.testng.TestListenerAdapter;
import org.testng.xml.XmlClass;

import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import com.zoho.livedesk.util.ChatUtil;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.Date;
import com.zoho.livedesk.client.ComplexReportFactory;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import com.zoho.livedesk.util.common.CommonUtil;

public class VerifySignature extends HttpServlet 
{
	public static final String X_SIGNATURE = "x-siqsignature";	//No I18N
	public static String PUBLICKEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn2ytU+hTKItEQ2eqthH7O824zKAzmZlufSElFA2BW7y+8BDNIeTpdaOugZDbrqEBPukQJbIJp+ZDEjl0DVaneZlxU5dVR/MwdIV9ks2WL2x2M3Pm7JPhuM5NBJBflDJoAWKiY4diSaW6VNJN7yNJPF0Pj0g8cU1FN27bCV5UV1gwQ/Jpe6Kg5Ilk5XGKr8GHh/Z7Ry+dnGh0m3iP0BaRmfllhT7uAgFI1fdzlyD8QV+/LN8zbVWHNZhiuLxMx52S554ubAeDfSs0688qQkdWcoJXmYhQdCfBtm1fefXwNbLRCbbv4y7ljSVmfvWWSYRU3boSMEp2+f/BD8HFGBR14wIDAQAB";	// NO I18N
	private static final String KEYPAIR_ALGORITHM = "RSA";	// No I18N
	private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";	// No I18N
	private static final String CHARSETNAME = "UTF-8";	// No I18N

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse http_response) throws ServletException, IOException 
	{
		try
		{
			http_response.setIntHeader("Refresh", 5);
			http_response.setContentType("text/html");
			PrintWriter out = http_response.getWriter();

			String method = request.getMethod();
			if("HEAD".equals(method))
			{
				return;
			}

			String payload_str=getInputStream(request);
			String sign = request.getHeader(X_SIGNATURE);
			boolean isSignatureVerified=verifySignature(payload_str, PUBLICKEY, sign);

			JSONObject response=getServerResponse(isSignatureVerified);

			Util.print(response.toString());
			out.print(response.toString());
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}


	public JSONObject getServerResponse(boolean isSignatureVerified) throws Exception
	{
		JSONObject response=new JSONObject();
		response.put("action","reply");
		JSONArray replies=new JSONArray();

		if(isSignatureVerified)
		{
			replies.put("Signature was verified succesfully with public key --> "+PUBLICKEY);
		}
		else
		{
			replies.put("Signature was NOT verified succesfully with public key --> "+PUBLICKEY);			
		}

		response.put("replies", replies);

		return response;
	}

	public static PublicKey getPublicKey(String public_key) throws Exception
	{
		//Base64.Decoder decoder = Base64.getDecoder();
		//byte[] bytes = decoder.decode(public_key);
		
		byte[] bytes = Base64.decodeBase64(public_key);
		
		X509EncodedKeySpec ks = new X509EncodedKeySpec(bytes);
		KeyFactory kf = KeyFactory.getInstance(KEYPAIR_ALGORITHM);
		return kf.generatePublic(ks);
	}

	public String getInputStream(HttpServletRequest request) throws Exception
	{
		StringWriter writer = new StringWriter();
        IOUtils.copy(request.getInputStream(), writer, "UTF-8");
        String requestBody = writer.toString();
        return requestBody;
	}

	 private String getRequestBody(HttpServletRequest request) throws IOException 
	 {
	    StringBuilder sb = new StringBuilder();
	    String line;

	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null) 
	    {
	      sb.append(line);
	    }

	    return sb.toString();
  	}

	public static boolean verifySignature(String payload_str, String public_key_str, String signature_str) throws Exception
	{
		try
		{
			if(signature_str == null || payload_str==null || payload_str.isEmpty())
			{
				Util.print("return false due to null ?");
				return false;
			}

			PublicKey public_key = getPublicKey(public_key_str);
			
			Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
			signature.initVerify(public_key);
			signature.update(payload_str.getBytes(CHARSETNAME));

			byte[] signatureBytes = Base64.decodeBase64(signature_str);
			
			return signature.verify(signatureBytes);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return false;
	}	  

	public static void setBotPublicKey(String public_key)
	{
		PUBLICKEY=public_key;
	}
}