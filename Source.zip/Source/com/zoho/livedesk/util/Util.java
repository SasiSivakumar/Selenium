//$Id$
package com.zoho.livedesk.util;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.TimeUnit;
import java.net.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.OutputStream;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.AppendAndExportData;

import com.zoho.livedesk.LiveDeskTesting;
import com.zoho.livedesk.SalesIQTestSV;
import com.zoho.livedesk.SalesIQTestAsso;
import com.zoho.livedesk.util.ApiAutomation;
import com.zoho.livedesk.client.CleanUp.ClearPortals;
import com.zoho.livedesk.client.checkStaticVersion;
import com.zoho.livedesk.client.MobileTesting.MobileUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.basictesting.*;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.stats.*;
import com.zoho.livedesk.util.stats.ResponseStats.RSDummyClass2;
import com.zoho.livedesk.util.stats.ScheduledMain;
import com.zoho.livedesk.util.stats.ScheduledMain.RSDummyClass3;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.KeysCountManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;

import java.text.SimpleDateFormat;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Arrays;
import com.mysql.jdbc.PreparedStatement;

import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.common.base.Function;
import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.BuildChangeSetAnalyser.BuildUpdateSQLUtil;

import com.zoho.quick.livedesk.util.CleanupQuick;
import com.zoho.quick.livedesk.util.SalesIQTestOthersQuick;
import com.zoho.quick.livedesk.util.SalesIQTestChatWidgetQuick;
import com.zoho.quick.livedesk.util.SalesIQTestBasicTestCasesQuick;
import com.zoho.livedesk.util.exceptions.ExceptionTracker;
import com.zoho.livedesk.util.ImageProcessor.ImageBreakageDetector;
import com.zoho.livedesk.util.BuildChangeSetAnalyser.AutomationResultAnalyser;
import com.zoho.livedesk.util.exceptions.WMSDownDetector;

public class Util extends TestCase{
    private static final int MYTHREADS = 200;
    private static int ncount = 0;
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    public Hashtable result;
    public Hashtable servicedown;
    public Hashtable res;
    public Hashtable modules_result = new Hashtable();
    public static boolean isstarted = false;
    public static boolean isended = false;

    public static String buildnamed = "";
    public static String sitenamed = "";
    public static String CSVPath = "";
    public static String setUpTrack = "";

    public static String timeOutVal = "";
    public static String channelID = "";
    public static String authToken = "";
    public static String toEmailID = "";
    
    public static int bugNum = 0;
    public static int sikuliUseCases = 0;
    public static String bugModuleName = "";
    public static String bugModuleURL = "";
    public static int bugFail = 0;
    public static int bugTotalUseCase = 0;

    public static String oldbuild="";
    public static String oldnewbuild="NotValid";
    public static String newbuild="";
    public static Set<String> failset = new HashSet<String>();
    public static String fail_message = "No modules failed more than 25%";
    public static String modules_results = "";
    public static String modulesInMail = "";
    
    public static String serverHostName = "";
    public static String serverPortNumber = "";
    
    public static Boolean logoutBlankPage = true;
    public static Boolean logoutWebsitesUI = true;

    public static boolean statusOfModules[];

    public static boolean isQuickAutomation = false;

    public static boolean isRunChat = false;
    public static String runChatEmail = "";
    public static String runChatPwd = "";
    public static String runChatTimes = "";

    public static long starttime;
    public static long endtime = 0L;
    String browser = "";
    Hashtable report;
    String url = "";
    public static long etime = 0L;
    ArrayList<String> modules = new ArrayList(Arrays.asList("SU1","SU2","SC1","SC2","SD1","SD2","SP1","SP2","SB1","SB2","SW1","SW2","SCM1","SCM2","SI1","SI2","SI3","CM1","CM2","CM3","Login","STR1","STR2","STR3","STR4","AFH1","AFH2","AFH3","KBSK1","KBSK2","KBSK3","PER1","PER2","TRC1","TRC2","CHAT1","CHAT5","CHAT6","CHAT7","CHAT9","CHAT15","CHAT22","CHAT23","CHAT26","CHAT29","CHAT30","CHAT34","CHAT49","CHAT62","CHAT73","CHAT79","CHAT82","CHAT101"));

    public static ArrayList<String> modules_to_run_from_api=null;

    Hashtable showstopper;

    public static boolean isAutomationRunning=false;
    public static boolean isCleanupRunning=false;

    public static void setIsAutomationRunning(boolean isRunning)
    {
        if(isAutomationRunning() && isRunning)
        {
            throw new ZohoSalesIQRuntimeException(CommonUtil.timestamp()+" : Automation is already running in this server. isAutomationRunning : "+isAutomationRunning());
        }

        isAutomationRunning=isRunning;
    }

    public static boolean isQuickAutomationSet()
    {
        return isQuickAutomation;
    }

    public static boolean isRunChatSet()
    {
        return isRunChat;
    }

    public static String getRunChatEmail()
    {
        return runChatEmail;
    }

    public static String getRunChatPwd()
    {
        return runChatPwd;
    }

    public static String getRunChatTimes()
    {
        return runChatTimes;
    }


    public static boolean isAutomationRunning()
    {
        return isAutomationRunning;
    }

    public static void setIsCleanupRunning(boolean isRunning)
    {
        isCleanupRunning=isRunning;
    }

    public static boolean isCleanupRunning()
    {
        return isCleanupRunning;
    }

    public void firefoxUtil() throws Exception
    {
        DesiredCapabilities capability=null;
        capability= DesiredCapabilities.firefox();
        ConfManager.init();
        capability.setBrowserName("firefox");
        //capability.setVersion("38.0.5");
        FirefoxProfile profile = new ProfilesIni().getProfile("Auto");
        capability.setCapability(FirefoxDriver.PROFILE,profile);
        //driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    public void chromeUtil() throws Exception
    {
        DesiredCapabilities capability=null;

        capability= DesiredCapabilities.chrome();
        ConfManager.init();
        if(ncount == 0)
        {
            capability.setBrowserName("chrome");
            ncount++;
        }
        if(ncount == 1)
        {
            capability.setBrowserName("chrome");
            ncount++;
        }
        if(ncount == 2)
        {
            capability.setBrowserName("chrome");
            ncount++;
        }
        if(ncount == 3)
        {
            capability.setBrowserName("chrome");
            ncount++;
        }
        if(ncount == 4)
        {
            capability.setBrowserName("chrome");
            ncount++;
        }
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //driver.manage().window().maximize();
        driver.switchTo().window(driver.getWindowHandle());

        Point targetPosition = new Point(0, 0);
        driver.manage().window().setPosition(targetPosition);

        Dimension targetSize = new Dimension(2560,1440);     //Imac - 2560*1440  Mac - 1440*900
        driver.manage().window().setSize(targetSize);

        driver.quit();
    }

    @Override
    public void setUp() throws Exception
    {
        browser = WebdriverQAUtil.getCurrentBrowser();
        if(browser == null)
        {
            ConfManager.init();
            browser = ConfManager.getBrowser();
        }
        if(browser.contains("chrome"))
        {
            chromeUtil();
        }
        else if(browser.contains("firefox"))
        {
            firefoxUtil();
        }
        ConfManager.setBrowser(browser);
    }

    public boolean testingStarted() throws Exception
    {
        return isstarted;
    }

    public boolean testingEnded() throws Exception
    {
        return isended;
    }

    public static void print(String text) 
    {
        java.io.PrintStream out = System.out;
        out.println(text);
    }

    public class MyRunnable implements Runnable {
        private int fnum;

        MyRunnable(int fnum) {
            this.fnum = fnum;
        }

        @Override
        public void run() {

            //String result = "";
            int code = 200;
            try
            {             
                res = new Hashtable();
                result = new Hashtable();
                servicedown = new Hashtable();
                report = new Hashtable();
                showstopper = new Hashtable();
                starttime = System.currentTimeMillis();
                boolean isloggedin = false;
                boolean isloggedout;
                //setUp();
                if(fnum == 0)
                {
                    SalesIQTestBasicTestCases s1 = new SalesIQTestBasicTestCases();
                    s1.testInit();
                    Hashtable hashtable = s1.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum0",hashtable.get("SalesIQTestBasicTestCases"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 1)
                {
                    SalesIQTestAutomations s2 = new SalesIQTestAutomations();
                    s2.testInit();
                    Hashtable hashtable = s2.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum1",hashtable.get("SalesIQTestAutomations"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 2)
                {
                    SalesIQTestChatWidget s3 = new SalesIQTestChatWidget();
                    s3.testInit();
                    Hashtable hashtable = s3.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum2",hashtable.get("SalesIQTestChatWidget"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 3)
                {
                    SalesIQTestIntegrations s4 = new SalesIQTestIntegrations();
                    s4.testInit();
                    Hashtable hashtable = s4.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum3",hashtable.get("SalesIQTestIntegrations"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 4)
                {
                    SalesIQTestOthers s5 = new SalesIQTestOthers();
                    s5.testInit();
                    Hashtable hashtable = s5.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum4",hashtable.get("SalesIQTestOthers"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 5)
                {
                    SalesIQTestCRMPlus s6 = new SalesIQTestCRMPlus();
                    s6.testInit();
                    Hashtable hashtable = s6.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum5",hashtable.get("SalesIQTestCRMPlus"));
                    print("RESULT : "+result);
                    print("SDOWN : "+servicedown);
                }
                else if(fnum == 6)
                {
                    // com.zoho.livedesk.util.exceptions.WMSDownDetector.start();
                }
                else
                {
//                    for(int i = 0;i <=7200;i++)
//                    {
//                        if(i%1200 == 0)
//                        {
//                            String sites[];
//
//                            boolean[] status = new boolean[4];
//                            Arrays.fill(status, true);
//
//                            if(buildlabel().contains("local"))
//                            {
//                                sites  = new String[]{"https://accounts.localzoho.com","https://salesiq.localzoho.com","https://crm.localzoho.com","https://campaigns.localzoho.com"};
//                            }
//                            else if(buildlabel().contains("pre"))
//                            {
//                                sites  = new String[]{"https://accounts.zoho.com","https://presalesiq.zoho.com","https://crm.zoho.com","https://campaigns.zoho.com"};
//                            }
//                            else
//                            {
//                                 sites  = new String[]{"https://accounts.zoho.com","https://salesiq.zoho.com","https://crm.zoho.com","https://campaigns.zoho.com"};
//                            }
//
//                            for(int count = 0;count<4 ;count++)
//                            {
//                                Long t1 = System.currentTimeMillis(),t2;
//                                System.out.print(sites[count]+":");
//                                URLConnection conn = new URL(sites[count]).openConnection();
//
//                                if(200 == ((HttpURLConnection) conn).getResponseCode())
//                                {
//                                    t2 = System.currentTimeMillis();
//                                    System.out.println(" False"+(float)(t2-t1)/1000);
//                                    status[count] = true;
//                                }
//                                else
//                                {
//                                    t2 = System.currentTimeMillis();
//                                    if(status[count])
//                                    {
//                                        System.out.println(sites[count]+" is down");
//                                        String message = "{\"message\":\""+sites[count]+" is down\",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\",\"custom_message\":\"true\"}";
//
//                                        ChatUtil.sendResultAsChatMessageForException(message);
//                                    }
//                                    System.out.println(" --- "+(float)(t2-t1)/1000+" secs");
//                                    status[count] = false;
//                                }
//                            }
//                        }
//
//                        if(statusOfModules[0] && statusOfModules[1] && statusOfModules[2] && statusOfModules[3] && statusOfModules[4])
//                        {
//                            break;
//                        }
//                        Thread.sleep(500);
//                    }
                }
            }
            catch (Exception e)
            {
                System.out.println("Status: Exception  : "+e);
                e.printStackTrace();
                //result = "->Red<-\t";
            }
            statusOfModules[fnum] = true;
            System.out.println("Status: Success");
        }
    }

    public class MyRunnableQuick implements Runnable {
        private int fnum;

        MyRunnableQuick(int fnum) {
            this.fnum = fnum;
        }

        @Override
        public void run() {

            //String result = "";
            int code = 200;
            try
            {             
                res = new Hashtable();
                result = new Hashtable();
                servicedown = new Hashtable();
                report = new Hashtable();
                showstopper = new Hashtable();
                starttime = System.currentTimeMillis();
                boolean isloggedin = false;
                boolean isloggedout;
                if(fnum == 0)
                {
                    SalesIQTestBasicTestCasesQuick s1 = new SalesIQTestBasicTestCasesQuick();
                    s1.testInit();
                    Hashtable hashtable = s1.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum0",hashtable.get("SalesIQTestBasicTestCasesQuick"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 1)
                {
                    SalesIQTestChatWidgetQuick s2 = new SalesIQTestChatWidgetQuick();
                    s2.testInit();
                    Hashtable hashtable = s2.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum2",hashtable.get("SalesIQTestChatWidgetQuick"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 2)
                {
                    SalesIQTestOthersQuick s3 = new SalesIQTestOthersQuick();
                    s3.testInit();
                    Hashtable hashtable = s3.sendResult();
                    result.putAll((Hashtable) hashtable.get("result"));
                    servicedown.putAll((Hashtable) hashtable.get("servicedown"));
                    modules_result.put("fnum4",hashtable.get("SalesIQTestOthersQuick"));
                    System.out.println("RESULT : "+result);
                    System.out.println("SDOWN : "+servicedown);
                }
                else if(fnum == 3)
                {
                    // com.zoho.livedesk.util.exceptions.WMSDownDetector.start();
                }
            }
            catch (Exception e)
            {
                System.out.println("Status: Exception  : "+e);
                e.printStackTrace();
                //result = "->Red<-\t";
            }
            statusOfModules[fnum] = true;
            System.out.println("Status: Success");
        }
    }

    public void testInit() throws Exception
    {
        System.out.println("\nThreads Starting at "+CommonUtil.timestamp());

        initializeTestVariables();
        setModules();
        printServerInfo();

        isQuickAutomation = WebdriverQAUtil.isQuickAutomationSet();

        isRunChat = WebdriverQAUtil.isRunChatSet();
        runChatEmail = WebdriverQAUtil.getRunChatEmail();
        runChatPwd = WebdriverQAUtil.getRunChatPwd();
        runChatTimes = WebdriverQAUtil.getRunChatTimes();


        setIsAutomationRunning(true);

        if(isDBUpdate())
        {
            BuildUpdateSQLUtil.addLabel();
            BuildUpdateSQLUtil.setIsAutomationStarted();
        }

        SalesIQAutomationExceptionHandler.setIsFatalErrorOccurred(false);//initializing value


        if(!ScheduledMain.status)
        {
            System.out.println("ScheduledMain.status<>"+ScheduledMain.status+"<>");
            ScheduledMain rs = new ScheduledMain();
            RSDummyClass3 rsdc = rs.new RSDummyClass3();
            rsdc.start();
            Thread.sleep(500);
            System.out.println("ScheduledMain.status<>"+ScheduledMain.status+"<>");
        }
        
        oldbuild="";
        oldnewbuild="NotValid";
        newbuild="";
        
        logoutBlankPage = false;
        logoutWebsitesUI = false;
        
        Calendar now = Calendar.getInstance();
        
        int currentDay = now.get(Calendar.DAY_OF_WEEK);
        
//        if(currentDay == 1 || currentDay == 7)
        if(true)
        {
            logoutBlankPage = true;
            logoutWebsitesUI = true;
        }

        Functions.login_success = true;
        VisitorsOnline.startedLeave = false;
        VisitorsOnline.startedPresent = false;
        VisitorsOnline.wmsStartedPresent = false;
        Tab.request_uri = new Hashtable<>();
        Tab.started = false;
        Tab.etestName = new Hashtable<>();
        Tab.etestCategory = new Hashtable<>();
        Tab.etestNameNotPresent = "";
        Tab.etestCategoryNotPresent = "";
        
        serverHostName = InetAddress.getLocalHost().getHostName();
        serverPortNumber = "9090";

        buildnamed = WebdriverQAUtil.getBuildlable();//buildlabel();
        sitenamed = WebdriverQAUtil.getCurrentSetupURL();

        setChannelIDForRunningAutomation(ConfManager.getChannelID());
        setAuthTokenForRunningAutomation(ConfManager.getAuthToken());
        toEmailID = ConfManager.getToEmailAddr();
        timeOutVal = ConfManager.getScheduleTimeOut();

        if(WebdriverQAUtil.getEmailID() != null && !WebdriverQAUtil.getEmailID().equals(""))
        {
            toEmailID = WebdriverQAUtil.getEmailID();
        }

        if(WebdriverQAUtil.getChannelID() != null && !WebdriverQAUtil.getChannelID().equals(""))
        {
            channelID = WebdriverQAUtil.getChannelID();
        }

        if(WebdriverQAUtil.getTimeOutVal() != null && !WebdriverQAUtil.getTimeOutVal().equals(""))
        {
            timeOutVal = WebdriverQAUtil.getTimeOutVal();
        }

        System.out.println("Params updated as :\n>>>>>Build Label : <"+buildnamed+">\n>>>>>Setup : <"+sitenamed+">\n>>>>>ChannelID : <"+channelID+">\n>>>>>EmailID : <"+toEmailID+">\n>>>>>TimeOut : <"+timeOutVal+">\n");
        CommonUtil.print("isQuickAutomationSet() : <"+isQuickAutomationSet()+">");
        
        buildnamed = buildnamed.replace("/ZohoLiveSupport.zip","");
        
        boolean needToWait = false;
        
        if(buildnamed.contains("http://"))
        {
            needToWait = true;
        }
        else
        {
            buildnamed = "http://"+buildnamed;
        }
        
        ComplexReportFactory.renameReportFileIfAlreadyExists();
        ComplexReportFactory.reporterInit();        

        if(!isTestingBuild())//check is added to not send mail when only some modules are run
        {
            // MailUtil.sendAutomationInitiatedMail(buildnamed,sitenamed);
        }

        if(needToWait)
        {
            Thread.sleep(Integer.parseInt(timeOutVal)*1000);
        }
        
        Long automationStartTime = new Long(System.currentTimeMillis());
        
        String staticVersion="Not Found";

        if((isModulesChosenInClient()==false) && (!isRunChatSet())) //check is added to not check static when only some modules are run
        {
            staticVersion = checkStaticVersion.test();
        }

        testingChatMessage("start",staticVersion);
        
        if(ConfManager.getRealValue("basictesting").equals("true"))
        {
            if(!BasicTesting.testInit())
            {
                System.out.println("Failed");

                System.out.println(BasicTesting.failureMessage);

                String msg = BasicTesting.failureMessage;

//                msg += "Hence the automation is stoppped."+
                msg +=  "For more info, click [here!]("+ComplexReportFactory.extentreportLink+")";

                String s = "{\"text\":\""+msg+"\",\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";

                ChatUtil.sendResultAsChatMessageForException(s);

//                if(VisitorWindow.started)
//                {
//                    VisitorWindow.started = false;
//                    ComplexReportFactory.closeTest(VisitorWindow.etest);
//                }
//                if(VisitorsOnline.startedLeave)
//                {
//                    VisitorsOnline.startedLeave = false;
//                    ComplexReportFactory.closeTest(VisitorsOnline.etestLeave);
//                }
//                if(VisitorsOnline.startedPresent)
//                {
//                    VisitorsOnline.startedPresent = false;
//                    ComplexReportFactory.closeTest(VisitorsOnline.etestPresent);
//                }
//                
//                ComplexReportFactory.closeReport();
//
//                return ;
            }
        }


        fail_message = "No modules failed more than "+ConfManager.getMaximumFailPercent()+"%";
        modules_results = "";
        VisitorWindow.last5ChatsInPortal = new Hashtable<String, Stack>();

        ExecutorService executor = Executors.newFixedThreadPool(MYTHREADS);

        statusOfModules = new boolean[6];
        Arrays.fill(statusOfModules, false);

        if(isQuickAutomationSet())
        {
            for (int i = 0; i <= 3; i++)
            {
                Runnable worker = new MyRunnableQuick(i);
                executor.execute(worker);
            }
        }
        else
        {
            for (int i = 0; i <= 6; i++)
            {
                Runnable worker = new MyRunnable(i);
                executor.execute(worker);
            }
        }
        executor.shutdown();

        ArrayList<Integer> browser_count = new ArrayList<Integer>();
        ArrayList<Integer> drivers_count = new ArrayList<Integer>();

        // Wait until all threads are finish
        while (!executor.isTerminated()) 
        {
            if(SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
            {
                break;
            }
            if( (System.currentTimeMillis()%(60*1000))==0 )//to check every minute
            {
                browser_count.add(SeleniumGridUtil.getBusySlotsCount());
                drivers_count.add(Driver.getDriversCount());
            }
        }


        if(isDBUpdate() && !SalesIQAutomationExceptionHandler.isFatalErrorOccurred())
        {
            BuildUpdateSQLUtil.setIsAutomationEnded();
        }

        try
        {
            if(!isCleanupOnly())
            {
                ExceptionTracker.printExceptionStats();
            }

            System.out.println("~~No of browser instances during automation (checked every minute)"+browser_count.toString());

            System.out.println("~~Max no of browsers open at a time "+Collections.max(browser_count));

            CommonUtil.print("~~No of driver instances during automation (checked every minute)"+drivers_count.toString());
            CommonUtil.print("~~Max no of drivers open at a time "+Collections.max(drivers_count));
        }
        catch(Exception browser_count_exception)
        {

        }
        
        
        Hashtable sikuliresult = CommonSikuli.sendResult();
        sikuliUseCases = sikuliresult.size();
        result.putAll(sikuliresult);
        Hashtable hashtable = CommonSikuli.finalResult();
        result.putAll((Hashtable) hashtable.get("result"));
        modules_result.put("fnum6",hashtable.get("SalesIQTestUIAutomation"));

        Driver.closeAllDriversOpenedDuringAutomation();

        KeyManager.logSkippedUsecases(result);

        System.out.println("Modules failed more than "+ConfManager.getMaximumFailPercent()+"%:"+fail_message);
        System.out.println("Modules Results:"+modules_results);
        System.out.println(" Result Hash >>>"+result);
        System.out.println(" Service down Hash >>>"+servicedown);
        System.out.println(" Report Hash >>> "+report);
        System.out.println("\nFinished all threads at "+CommonUtil.timestamp());

        endtime = System.currentTimeMillis();
        calculateReport(result,endtime-starttime);

        boolean isAnalyseResult=false;

        try
        {
            isAnalyseResult=(isDBUpdate() && (int)report.get("Success_per")>=85 && (!isQuickAutomationSet()));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        if(isAnalyseResult)
        {
            BuildUpdateSQLUtil.setResult(KeyManager.getDBResultHashtable(result));

            ChatUtil.postEntireAutomationHistoryReportInOneMessage(3,ConfManager.getRealValue("automation_dev_channel2"));
            ChatUtil.postEntireAutomationHistoryReportInOneMessage(10,ConfManager.getRealValue("automation_dev_channel2"));
            ChatUtil.postEntireAutomationHistoryReportInOneMessage(25,ConfManager.getRealValue("automation_dev_channel2"));

            if(AutomationResultAnalyser.isReportPostedToday()==false)
            {
                ChatUtil.postAutomationHistoryReport(5,ConfManager.getRealValue("team_automation_channel"));
                AutomationResultAnalyser.setReportedPostedTime();
            }
        }

        addAnalyzedResultToReport(KeyManager.getDBResultHashtable(result));
        
        if(!isTestingBuild())//check is added to not send mail when only some modules are being being run
        {
            // MailUtil.sendReport(report,res,showstopper,servicedown);//,"Complete");
        }

        String filePath = FileUtil.sendFileReport(report,res,showstopper,servicedown);

        filePath = ComplexReportFactory.extentreportLink;

        report.put("ModuleResult",modules_result);
        ChatUtil.sendChatResult(report,res,showstopper,servicedown,filePath,"",true);
        CSVPath = CSVUtil.createCSV(report,result,showstopper,servicedown);
        reportPush(report,CSVPath);

        String afterReport = "";

        if(VisitorWindow.started)
        {
            VisitorWindow.started = false;
            ComplexReportFactory.closeTest(VisitorWindow.etest);
        }
        if(VisitorsOnline.startedLeave)
        {
            VisitorsOnline.startedLeave = false;
            ComplexReportFactory.closeTest(VisitorsOnline.etestLeave);

            afterReport = VisitorsOnline.messageLeave;
        }
        if(VisitorsOnline.startedPresent)
        {
            VisitorsOnline.startedPresent = false;
            ComplexReportFactory.closeTest(VisitorsOnline.etestPresent);

            if(afterReport.equals(""))
            {
              afterReport = VisitorsOnline.messagePresent;
            }
            else
            {
              afterReport += "\\n"+VisitorsOnline.messagePresent;
            }
        }
        if(VisitorsOnline.wmsStartedPresent)
        {
            VisitorsOnline.wmsStartedPresent = false;
            ComplexReportFactory.closeTest(VisitorsOnline.etestWMS);
        }
        if(Tab.started)
        {
            Tab.started = false;
            ComplexReportFactory.closeTest(Tab.etest);
        }
        
        if(!afterReport.equals(""))
        {
            String messageContent = "{\"text\":\""+afterReport+ "\",\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";
            
            ChatUtil.sendChatMessage(messageContent);
        }
        
        PostIssuesInChannel.postMessage();
        BuildRejector.postToChat();
        
        try
        {
            System.out.println("Tab.etestNameNotPresent<>"+Tab.etestNameNotPresent+"<>");
            System.out.println("Tab.etestCategoryNotPresent<>"+Tab.etestCategoryNotPresent+"<>");
            
            Tab.etestNameNotPresent = "";
            Tab.etestCategoryNotPresent = "";
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        setIsCleanupRunning(true);

        // ClearPortals cp = new ClearPortals();
        // cp.portalClear();
       
	if( ( isModulesChosenInClient() && isTest(null,"Cleanup") ) || (isModulesChosenInClient()==false) || isQuickAutomationOnly())
        {
            if(isQuickAutomationSet())
            {
                CleanupQuick.startCleanup();
            }
            else
            {
                Cleanup.startCleanup();
            }
            Driver.closeAllDriversOpenedDuringAutomation();
        }

        SalesIQAutomationExceptionHandler.postWMSErrorsInfoToChannel();

        setIsCleanupRunning(false);
        setIsAutomationRunning(false);

        /*

        if(isModulesChosenInClient()==true)//check is added to not perform below operations when only some modules are being run        
        {
            setIsAutomationRunning(false);
            return;
        }
        
        if(Boolean.parseBoolean(ConfManager.getRealValue("mobile_automation")) && setUptracking().equals("local"))
        {
            DummyClass3 d3 = new DummyClass3();
            d3.start();
            
            Long t1 = new Long(System.currentTimeMillis());
            
            for(;;)
            {
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2 - t1 > (60*60000))
                {
                    break;
                }
                if(d3.status)
                {
                    break;
                }
                Thread.sleep(30000);
            }
        }
        
        ComplexReportFactory.closeReport();
        
        DummyClass1 d = null;
        String sd = null;
        
        if(setUptracking().equals("local"))
        {
            if(true)
            {
                sd = "local";
            }
        }
        else if(setUptracking().equals("pre"))
        {
            if(true)
            {
                sd = "pre";
            }
        }
        
        if(sd != null)
        {
            d = new DummyClass1(result,sd);
        
            d.start();
        }
        
        Long upgradeStartingTime = new Long(System.currentTimeMillis());
        
        try
        {
            Tab.printDetails();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        try
        {
            Stack<String> contents = Tab.contents;
            
            for(String cs : contents)
            {
                System.out.println(cs);
            }
            
            Tab.contents = new Stack<>();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        Long automationEndTime = new Long(System.currentTimeMillis());
        
        if(!setUptracking().contains("local"))
        {
            setIsAutomationRunning(false);
            return;
        }
        else
        {
            ResponseStats rs = new ResponseStats();
            RSDummyClass2 rsdc = rs.new RSDummyClass2(automationStartTime,automationEndTime);
            rsdc.start();
        }
        
        String buildLabel1 = WebdriverQAUtil.getBuildlable();
        
        if(buildLabel1.contains("http://"))
        {
            buildLabel1 = buildLabel1.replace("http://","");
        }
        
        Long upgradeEndingTime = new Long(System.currentTimeMillis());
        
        int waitingTime = 16*60;
        
        while(upgradeEndingTime - upgradeStartingTime <= waitingTime*1000)
        {
            Thread.sleep(1000);
            
            upgradeEndingTime = new Long(System.currentTimeMillis());
        }
        
        if(!d.status)
        {
            setIsAutomationRunning(false);
            return;
        }
        
        upgradeStartingTime = new Long(System.currentTimeMillis());
        upgradeEndingTime = new Long(System.currentTimeMillis());
        
        boolean toContinue = false;
        
        String current = "";
        
        while(upgradeEndingTime - upgradeStartingTime <= 60000)
        {
            String s = "us3_pre_production";
            
            current = getCurrentBuild(s).replace("http://","");
            
            System.out.println("<><>"+current+"<><>");
            System.out.println("<><>"+buildLabel1+"<><>");
            
            if(current.contains(buildLabel1))
            {
                toContinue = true;
                break;
            }
            
            Thread.sleep(1000);
            
            upgradeEndingTime = new Long(System.currentTimeMillis());
        }
        
        if(!toContinue)
        {
            setIsAutomationRunning(false);
            System.out.println("Automation is stopped due to build updation failed in "+Util.setUptracking());
            return;
        }
        
        String automationURL = "http://"+serverHostName+":"+serverPortNumber+"/selenium/apiwebdriver?select-url1=<URL>&select-dependency=&select-servername=salesiq&buildURL=<BUILD_LABEL>&testStr=&webtestStr=&webselect-type1=0&select-browser=firefox&zaproxy=&toaddresswebdriver=&innerts=&innerts=&rerunDatas=&getLoginName=&getPassword=&getPortalName=&getChannelID=&getEmailID=&getTimeout=&contributors=";
        
        automationURL = automationURL.replace("<BUILD_LABEL>",buildLabel1);
        
        automationURL = automationURL.replace("<URL>","presalesiq.zoho.com");
        
        System.out.println(automationURL);
        
        DummyClass2 d2 = new DummyClass2(automationURL);
        d2.start();

	setIsAutomationRunning(false);


    */

    }

    public void setEndTime() throws Exception
    {
        try
        {
            etime = System.currentTimeMillis();
        }
        catch(Exception e)
        {}
    }

    public long getEndTime() throws Exception
    {
        return etime;
    }

    private boolean upgrade(Hashtable result, String currentSetup)
    {
        boolean statusB = false;
        
        int size = result.size();
        int success = 0;
        
        String paramSetup = "us3_pre_production";
        String upgradeSetup = "Pre";
        
        if(currentSetup.equals("pre"))
        {
            paramSetup = "us3_i18n_test";
            upgradeSetup = "i18n";
        }

        Set<String> keys = result.keySet();
        for(String key: keys){
            if((boolean) (""+result.get(key)).equals("true"))
            {
                success++;
            }
        }
        
        int totalUsecases = 0;
        
        // if(currentSetup.contains("local"))
        // {
        if(isQuickAutomationSet())
        {
            totalUsecases = (Integer.parseInt(ConfManager.getRealValue("totalUsecasesLocalQuick")));
        }
        else if(isModulesChosenInClient())
        {
            totalUsecases = getSelectedModulesTotalUsecases();
        }
        else
        {
            totalUsecases = (Integer.parseInt(ConfManager.getRealValue("totalUsecasesLocal")));   
        }
        // }
        // else
        // {
        //     totalUsecases = (Integer.parseInt(ConfManager.getRealValue("totalUsecasesPre")));
        // }

        int success_per = (success*100)/totalUsecases;

        String status = "Failed";
        
        int success_expected ;
        if(isQuickAutomationSet())
        {
            success_expected = Integer.parseInt(ConfManager.getRealValue("totalThreshQuick"));
        }
        else
        {
            success_expected = Integer.parseInt(ConfManager.getRealValue("totalThresh"+currentSetup));
        }
        int maxFailPercent = Integer.parseInt(ConfManager.getMaximumFailPercent());

        String upgradeMsg = "*Build:* "+buildlabel()+"\\n*Total Use Cases:* "+size+"\\n*Success Use Cases:* "+success+"("+success_expected+")\\n*Success Percentage:* "+success_per+"%"+"\\n*Modules failed more than "+maxFailPercent+"%:* "+fail_message.replace("Below modules failed more than "+maxFailPercent+"%:","")+"\\n*Push the build to "+upgradeSetup+" setup:* ";
        
        Date now = new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateformat = new SimpleDateFormat("EEEE");
        
        System.out.println("<><>"+success+"<><>"+success_expected+"<><>");
        System.out.println("<><>"+fail_message+"<><>"+"No modules failed more than "+maxFailPercent+"%"+"<><>");
        System.out.println("<><>"+Functions.login_success+"<><>");

        System.out.println("<><>"+ConfManager.getRealValue("push_to_pre_exceptional_days")+"<><>"+simpleDateformat.format(now)+"<><>");
        
        if(success >= success_expected && fail_message.equals("No modules failed more than "+maxFailPercent+"%") && Functions.login_success)
        {
            if(ConfManager.getRealValue("push_to_pre_exceptional_days").contains(simpleDateformat.format(now)) || ConfManager.getRealValue("push_to_pre_exceptional_days").toLowerCase().contains("all"))
            {
                upgradeMsg += "No (Exceptional days - "+ConfManager.getRealValue("push_to_pre_exceptional_days")+")";
            }
            else
            {
                upgradeMsg += "Yes";
                
                HttpURLConnection httpcon = null;
                
                try
                {
                    String params = "authtoken=8514d56742ab433bfd275f7c00a824d0bef3&product=ZOHOLIVESUPPORT&bType="+paramSetup;
                    
                    String upgradeURL = "http://sd/api/startupgrade?"+params;
                    
                    System.out.println(upgradeSetup+"-Setup Update - URL : "+upgradeURL+" AND Params : "+params);
                    
                    URL url = new URL(upgradeURL);
                    
                    httpcon = (HttpURLConnection) (url.openConnection());
                    httpcon.setRequestMethod("GET");
                    httpcon.setConnectTimeout(900000);
                    
                    System.out.println(upgradeSetup+"-Setup Upgrade - Response Code : "+httpcon.getResponseCode()+" <><> "+httpcon.getResponseMessage());
 
//                    Just to print the content in chat
//                    String testmsg = "{\"message\":\"*Upgrade URL*: "+upgradeURL+"\",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\",\"custom_message\":\"false\"}";
//                    
//                    ChatUtil.sendResultAsChatMessageForException(testmsg);
                    
                    status = "Success";
                    
                    statusB = true;
                }
                catch(Exception exp)
                {
                    exp.printStackTrace();
                }
                finally
                {
                    try
                    {
                        httpcon.disconnect();
                    }
                    catch(Exception exp)
                    {
                        exp.printStackTrace();
                    }
                }
                
                upgradeMsg += "\\n*"+upgradeSetup+"-Setup Upgrade - Response Status :* "+status;
            }
        }
        else
        {
            upgradeMsg += "No";
        }

        String message = "{\"text\":\""+upgradeMsg+"\",\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";

        ChatUtil.sendResultAsChatMessageForException(message);
        
        return statusB;
    }

    private void calculateReport(Hashtable result, long timetaken)
    {
        timetaken = timetaken/1000;
        String time = "";

        if(timetaken > 60)
        {
            long m = (timetaken / 60) % 60;
            long h = (timetaken / (60 * 60));
            
            if(h > 9)
            {
                time = ""+h;
            }
            else
            {
                time = "0"+h;
            }
            
            if(m > 9)
            {
                time += ":"+m;
            }
            else
            {
                time += ":0"+m;
            }
        }
        else
        {
            time = timetaken + " secs";
        }

        report.put("TimeTaken", time);

        int size = result.size();
        int success = 0;
        report.put("TotalUseCases", size);
        Set<String> keys = result.keySet();
        for(String key: keys){
            if((boolean) (""+result.get(key)).equals("true"))
            {
                success++;
            }
            else
            {
                res.put(KeyManager.getRealValue(key),"fail");
                if(modules.contains(key))
                {
                    showstopper.put(KeyManager.getRealValue(key),"failed");
                }
            }
        }
        report.put("Success", success);
        report.put("Failure", size-success);
        
        String setup = siteNameout();
        
        if(setup.contains("labsalesiq"))
        {
            report.put("Setup", "LabSalesIQ");
        }
        else if(setup.contains("localzoho"))
        {
            report.put("Setup", "LocalZoho");
        }
        else if(setup.contains("presalesiq"))
        {
            report.put("Setup", "Pre Setup");
        }
        else if(setup.contains(".zoho"))
        {
            report.put("Setup", "IDC");
        }
        else
        {
            report.put("Setup", "-");
        }
        
        int totalUsecases = 0 ;

        if(isQuickAutomationSet())
        {
            totalUsecases = (Integer.parseInt(ConfManager.getRealValue("totalUsecasesLocalQuick")));
        }
        else if(isModulesChosenInClient())
        {
            totalUsecases = getSelectedModulesTotalUsecases();
        }
        else 
        {
            totalUsecases = (Integer.parseInt(ConfManager.getRealValue("totalUsecasesLocal")));
        }

        if(totalUsecases < size)
        {
            totalUsecases = size;
        }
        
        int success_per = (int)Math.round((float)(success*100)/totalUsecases);
        
        report.put("Success_per", success_per);
        report.put("Failure_per", 100-success_per);
        if(browser.contains("chrome"))
        {
            report.put("Browser", "chrome");
        }
        else if(browser.contains("firefox"))
        {
            report.put("Browser", "firefox");
        }
        else
        {
            report.put("Browser", "IE");
        }
        
        report.put("URL", setup+"/automation");
        //String build = WebdriverQAUtil.getBuildlable();
        String build = buildlabel();

        report.put("Build", build);
    }
    @Override
    public void tearDown() throws Exception
    {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    public static String buildlabel()
    {
        return buildnamed;
    }

    public static void goToSalesIQ(WebDriver driver)
    {
        driver.get(siteNameout());
    }

    public static String siteNameout()
    {
        return sitenamed;
    }

    public static String getDomainName()
    {
        return siteNameout().split("salesiq.")[1];
    }

    public static String getCliqURL()
    {
        return getOtherServiceURL("cliq");
    }

    public static String getPeopleURL()
    {
        return getOtherServiceURL("people");
    }

    public static String getOtherServiceURL(String service)
    {
        return siteNameout().replace("salesiq.",service+".");
    }

    public static String getToEmailuser()
    {
        return toEmailID;
    }

    public static void setAuthTokenForRunningAutomation(String authToken)
    {
        Util.authToken=authToken;
    }

    public static String getAuthTokenForRunningAutomation()
    {
        return authToken;
    }

    public static void setChannelIDForRunningAutomation(String channelID)
    {
        Util.channelID=channelID;
    }

    public static String getChannelIDForRunningAutomation()
    {
        return channelID;
    }

    public static boolean isLocalBuild()
    {
        return setUptracking().equals("local");
    }

    public static String setUptracking()
    {
        String ccheck = siteNameout();

        if(ccheck.contains("labsalesiq"))
        {
            setUpTrack = "lab";
        }
        else if(ccheck.contains("localzoho"))
        {
            setUpTrack = "local";
        }
        else if(ccheck.contains("presalesiq"))
        {
            setUpTrack = "pre";
        }
        else
        {
            setUpTrack = "idc";
        }

        return setUpTrack;
    }

    public static void buggyFinder(Hashtable bugReport,String moduleName,String moduleURL)
    {
        int fcount = (int) bugReport.get("Failure_per");
        int tcount = (int) bugReport.get("TotalUseCases");

        if(bugNum == 0)
        {
            bugModuleName = moduleName;
            bugModuleURL = moduleURL;

            bugFail = fcount;
            bugTotalUseCase = tcount;

            bugNum++;
        }
        else
        {
            if(fcount > bugFail)
            {
                bugModuleName = moduleName;
                bugModuleURL = moduleURL;

                bugNum++;
            }
            else if((fcount == bugFail)&&(tcount < bugTotalUseCase))
            {
                bugModuleName = moduleName;
                bugModuleURL = moduleURL;

                bugNum++;
            }
        }
    }

    public static void testingChatMessage(String statusmsg, String staticVersion)
    {
        try{
        String build = buildlabel();

        String setup = siteNameout();
        //String setup = ConfManager.getSetup();
        if(setup.contains("labsalesiq"))
        {
            setup = "LabSalesIQ";
        }
        else if(setup.contains("localzoho"))
        {
            setup = "LocalZoho";
        }
        else if(setup.contains("presalesiq"))
        {
            setup = "Pre Setup";
        }
        else if(setup.contains(".zoho"))
        {
            setup = "IDC";
        }
        else
        {
            setup = "-";
        }

        String imgurl = "https://www.zoho.com/salesiq/images/icon-salesiq.png";

//        String contributors = "";
//
//        if(WebdriverQAUtil.getContributors() != null && !WebdriverQAUtil.getContributors().equals(""))
//        {
//            contributors = "\\n*Contributors*: "+WebdriverQAUtil.getContributors();
//        }

        String subject = "";

//        subject = "*SalesIQ Automation - "+setup+" - Automation Testing Started*\\n\\n*Build*:  "+buildnamed+"\\n*URL*: "+siteNameout()+contributors+staticVersion;
        String quick = isQuickAutomationSet()?"Quick":"";
            
        subject = "*SalesIQ "+quick+" Automation - "+setup+" - Automation Testing Started*\\n\\n*Build*:  "+buildnamed+"\\n*URL*: "+siteNameout()+staticVersion;

        String formattedMsg = "";//"\"formattedmsg\":[{\"type\": \"list\",\"title\": \"Modules:\",\"data\": "+all_modules+"}],";

        String filePath = ComplexReportFactory.extentreportLink;
        String content = "{\"text\":\""+subject+"\","+formattedMsg+"\"bot\":{\"name\":\"Automation\",\"image\":\""+imgurl+"\"},\"buttons\" : [{ \"label\" : \"View Results\", \"hint\" : \"Click here to view the automation results\", \"type\" : \"\", \"action\" : { \"type\" : \"open.url\", \"data\" : { \"web\" : \""+filePath+"\" } } }]}";

        ChatUtil.sendChatMessage(content);

        try
        {
            newbuild = buildlabel();
            if(!(newbuild.contains("ZOHOLIVESUPPORT") || newbuild.contains("default")))
            {
                System.out.println("Dummy build");
                return;
            }
            
            if(!setUptracking().contains("local"))
            {
                System.out.println("Exceptions not need for "+setUptracking());
                return;
            }

            System.out.println("Entering data in DB:");

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://zcliq-opti-u12:3306/team","root","Latitude@1234");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM salesiq");
            newbuild = buildlabel();

            String a = "ZOHOLIVESUPPORT";//"ZOHOLIVESUPPORT_REVIEWED";

            if(newbuild.contains("default"))
            {
                a = "default";
            }

            String[] parts = newbuild.split(a);
            newbuild = a+parts[parts.length-1];
            newbuild = newbuild.replaceAll("/","_");

            String urlser = siteNameout()+"/";

            String time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
            String srv = "";
            if(urlser.contains("pre"))
            {
                srv = urlser.substring(11, urlser.indexOf("."));
            }
            if(!urlser.contains("pre"))
            {
                srv=urlser.substring(8, urlser.indexOf("."));
            }

            int count = 0;
            while(rs.next())
            {
                count++;
            }

            rs.last();

            String strarr[]=new String[count];
            String strarray[]=new String[count];

            System.out.println("<<>>"+count);

            for(int i=count-1;i>=0;i--)
            {
                strarr[i]=rs.getString(3);
                strarray[i]=rs.getString(4);
                System.out.println("<<>>"+strarr[i]+"<<>>"+strarray[i]+"<<>>"+srv+"<<>>"+urlser+"<<>>");
                if(strarr[i].equals(srv) && strarray[i].equals(urlser))
                {
                    oldbuild=rs.getString(2);
                    System.out.println("Last Build before executing "+newbuild+" is "+oldbuild);
                    oldnewbuild="Valid";
                    break;
                }
                rs.previous();
            }

            Statement stm=con.createStatement();

            String ins = "INSERT INTO salesiq(Build_label,Service,Setup,Time)" + "VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = (PreparedStatement) con.prepareStatement(ins);
            preparedStatement.setString(1, newbuild);
            preparedStatement.setString(2, srv);
            preparedStatement.setString(3, urlser);
            preparedStatement.setString(4, time);
            preparedStatement.executeUpdate();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("Exception while updating build in database:");
            e.printStackTrace();
        }
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    }

    public static void reportPush(Hashtable report,String filePath)
    {
        try
        {
            String setup = report.get("Setup").toString();

            System.out.println("<<<<<<<<<<<<<<<<<<<<< Got setup as  : "+setup+" >>>>>>>>>>>>>>>>>>>>>");

            if(setup.contains("IDC"))
            {
                setup = "live";
            }
            if(setup.contains("LabSalesIQ"))
            {
                setup = "lab";
            }
            else if(setup.contains("LocalZoho"))
            {
                setup = "local";
            }
            else if(setup.contains("Pre"))
            {
                setup = "pre";
            }
            else
            {
                setup = "-";
            }

            System.out.println("<<<<<<<<<<<<<<<<<<<<< Results pushing to setup : "+setup+" >>>>>>>>>>>>>>>>>>>>>");
            AppendAndExportData.callImportData("salesiq",filePath,setup);
            AppendAndExportData.callNewDataToMasterTable("salesiq",filePath,setup);
            System.out.println("<<<<<<<<<<<<<<<<<<<<< Results pushed to reports.zoho.com >>>>>>>>>>>>>>>>>>>>>");
        }
        catch(Exception ex)
        {
            System.out.println("Exception while pushing reports to reports.zoho.com : "+ex);
            ex.getMessage();
        }
    }

    public static TestSuite suite()
    {
        TestSuite suite = new TestSuite();
        suite.addTestSuite(Util.class);
        return suite;
    }

    public static void main(String[] args)
    {
        ConfManager.init();
        junit.textui.TestRunner.run(suite());
    }

    public static void getModulesResult(Hashtable<String,Boolean> result,String module)
    {
        synchronized (failset)
        {
            try
            {
                int i = 0 , count = 0;

                for(Map.Entry m : result.entrySet())
                {
                     if(m.getValue().equals(false))
                     {
                         i++;
                     }
                     count++;
                }

                int maximumFailPercent = Integer.parseInt(ConfManager.getMaximumFailPercent());

                if(count != 0)
                {
                    int fail_percent = (i*100)/count;

                    modules_results += module+"-"+i+"-"+count+"-"+fail_percent+"/";
                    System.out.println(module+"-"+i+"-"+count+"-"+fail_percent);

                    if(fail_percent >= maximumFailPercent)
                    {
                        if(fail_message.contains("No modules failed more than"))
                        {
                            fail_message = "Below modules failed more than "+ConfManager.getMaximumFailPercent()+"%:"+module+"("+fail_percent+"%)";
                        }
                        else
                        {
                            fail_message += ","+module+"("+fail_percent+"%)";
                        }
                    }
                }
                else
                {
                    modules_results += module+"-"+i+"-"+count+"/";
                    System.out.println(module+"-"+i+"-"+count);
                }
            }
            catch(Exception e)
            {
                modules_results += "Error while finding result for module:"+module+"/";
                System.out.println("Error while finding result for module:"+module);
                e.printStackTrace();
            }
        }
    }   
    
    public class DummyClass1 extends Thread{
        
        public Hashtable result;
        public String setup;
        public Boolean status = false;
        
        public DummyClass1(Hashtable result, String setup) {
            this.result = result;
            this.setup = setup;
        }
        
        public void run()
        {
            status = upgrade(result,setup);
        }
    }
    
    public class DummyClass2 extends Thread{
        
        public String url;
        
        public DummyClass2(String url) {
            this.url = url;
        }
        
        public void run()
        {
            try
            {
                HttpURLConnection httpcon = null;
                
                URL urlConn = new URL(url);
                
                httpcon = (HttpURLConnection) (urlConn.openConnection());
                httpcon.setRequestMethod("GET");
                
                System.out.println("Automation :"+httpcon.getResponseCode()+" <><> "+httpcon.getResponseMessage());
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public class DummyClass3 extends Thread{
        
        public Boolean status = false;
        public DummyClass3() {
        }
        
        public void run()
        {
            /*
            try
            {

                String messageContent = "{\"text\":\"SalesIQ Mobile Automation Started\",\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";
                
                ChatUtil.sendResultAsChatMessageForException(messageContent);
                
                Long t1 = new Long(System.currentTimeMillis());
                
                Hashtable mobileResults = MobileUtil.test();
                
                System.out.println("<>MobileAutomation<>"+mobileResults);
                
                Long t2 = new Long(System.currentTimeMillis());
                
                Set<String> keys = mobileResults.keySet();
                
                int success = 0;
                int total = 0;
                
                for(String s : keys)
                {
                    if((Boolean)mobileResults.get(s))
                    {
                        success++;
                    }
                    
                    total++;
                }
                
                int sucPer = (success*100)/total;
                
                messageContent = "{\"text\":\"SalesIQ Mobile Automation - Success Rate - "+(sucPer)+"% | Failure Rate - "+(100-sucPer)+"%"
                +"\\nTime taken:"+((t2-t1)/(60000))
                +"\","
                +"\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";
                
                ChatUtil.sendResultAsChatMessageForException(messageContent);
                
                status = true;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
                status = true;
            }

            */
        }
    }
    
    public static String getCurrentBuild(String setup) throws Exception
    {    
        String url = "https://sd.csez.zohocorpin.com/rest/getLatestDeployedBuild?product=ZOHOLIVESUPPORT&bType="+setup+"&authtoken=8514d56742ab433bfd275f7c00a824d0bef3";
        String build = null;
        
        URL urlConn=new URL(url);
        
        HttpURLConnection httpcon = null;
        
        httpcon = (HttpURLConnection) (urlConn.openConnection());
        httpcon.setRequestMethod("GET");
        
        InputStream in = httpcon.getInputStream();
        String encoding = httpcon.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(body);
        
        JSONArray list = (JSONArray)json.get("info");
        
        JSONObject e = (JSONObject) list.get(0);
        
        build = e.get("CurrentUrl").toString();
        
        return build;
    }

    public static void initializeTestVariables()
    {
        WMSDownDetector.init();
        AutomationPauser.init();
        com.zoho.livedesk.util.exceptions.ExceptionTracker.init();
        CommonSikuli.initializeSikuliResultHashtable();
        Driver.initializeDriverList();
        SalesIQAutomationExceptionHandler.init();
        BuildRejector.init();
        ImageBreakageDetector.init();
        com.zoho.livedesk.client.SalesIQRestAPI.AccessTokenManager.init();
        Functions.init();
        CommonUtil.init();

        try
        {
            BuildUpdateSQLUtil.BuildUpdateDBInit();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            ChatUtil.postToAutomationDevChannel("Automation DB could not be initialized--> "+e.toString());
        }
    }

    public static String getChannelID()
    {
        return WebdriverQAUtil.getChannelID();
    }

    public static String getAuthToken()
    {
        return WebdriverQAUtil.getAuthToken();
    }

    public static String getOnAutomationSuccessAction()
    {
        return WebdriverQAUtil.getOnAutomationSuccessAction();
    }

    public static List<String> getModule()
    {
        return modules_to_run_from_api;
    }

    public static void setModules()
    {
        if(WebdriverQAUtil.getModule()!=null)
        {
            modules_to_run_from_api=new ArrayList<String>(Arrays.asList((WebdriverQAUtil.getModule()).split(",")));
        }
        else
        {
            modules_to_run_from_api=null;
        }
    }

    public static void printServerInfo()
    {
        try
        {
            System.out.println("~~getChannelId"+getChannelID()+" getAuthToken"+getAuthToken()+" getOnAutomationSuccessAction"+getOnAutomationSuccessAction());
            System.out.println("~ getModule isEmptey"+getModule().isEmpty()+" to str "+getModule().toString());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static int getSelectedModulesTotalUsecases()
    {
        List<String> modules = getModule();
        int totalKeys = 0;
        for(int i = 0; i < modules.size(); i++)
        {
            totalKeys += Integer.parseInt(KeysCountManager.getRealValue(modules.get(i).replace(" ","_")));
        }
        totalKeys += sikuliUseCases;
        return totalKeys;
    }

    public static boolean isCleanupOnly()
    {
        if(isModulesChosenInClient() && getModule().size()==1 && getModule().get(0).equals("Cleanup"))
        {
            return true;
        }

        return false;
    }

    public static boolean isQuickAutomationOnly()
    {
        // if(isModulesChosenInClient() && getModule().size()==1 && getModule().get(0).equals("Quick Automation"))
        // {
        //     return true;
        // }
        // return false;

        return (isQuickAutomationSet() && !isModulesChosenInClient());
    }

    public static boolean isModulesChosenInClient()
    {
        return (getModule()!=null && getModule().isEmpty()==false && getModule().get(0).equals("")==false);
    }

    public static boolean isFullAutomation()
    {
        return !isModulesChosenInClient();
    }

    public static boolean isTest(String module_name,List<String> modules_to_run)
    {
        ArrayList<String> modules_to_ignore = new ArrayList<String>(Arrays.asList((ConfManager.ignoreModules()).split(",")));

        if(isModulesChosenInClient() && !isQuickAutomationOnly())
        {

            if(getModule().contains(module_name))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        if(modules_to_run!=null)
        {
            if(modules_to_run.contains(module_name) || (modules_to_run.contains("all")) && !(modules_to_ignore.contains(module_name)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        return false;
    }

    public static boolean isTest(List<String> modules_to_run,String... modules)
    {
        for(String module : modules)
        {
            if(isTest(module,modules_to_run))
            {
                return true;
            }
        }
        
        return false;
    }

    public static boolean isDummyBuildLabel()
    {
        String build=WebdriverQAUtil.getBuildlable();
        return (build.contains("build/zoho/")==false);
    }

    public static boolean isDBUpdate()
    {
        return isTestingBuild();
    }

    public static boolean isTestingBuild()
    {
        return ( ( !isDummyBuildLabel() )  && !isModulesChosenInClient() );
    }

    public static void addAnalyzedResultToReport(Hashtable result)
    {
        ArrayList<String> failed_keys = new ArrayList<String>();
        ArrayList<String> skipped_keys = new ArrayList<String>();

        ExtentTest etest = null;
        Set<String> keys = result.keySet();

        for(String key: keys)
        {
            if(result.get(key).equals("fail"))
            {
                failed_keys.add(key);
            }
            else if(result.get(key).equals("skipped"))
            {
                skipped_keys.add(key);
            }
        }

        if((skipped_keys.size() > 0) && (!isModulesChosenInClient() && !isQuickAutomationSet()))
        {
            etest = ComplexReportFactory.getTest("Skipped usecases in Automation");
            ComplexReportFactory.setValues(etest,"Report Analysis","Report Analysis");
            addTestCasesToReport(etest,skipped_keys);
            ComplexReportFactory.closeTest(etest);
        }

        if(failed_keys.size() > 0)
        {
            etest = ComplexReportFactory.getTest("Failed usecases in Automation");
            ComplexReportFactory.setValues(etest,"Report Analysis","Report Analysis");
            addTestCasesToReport(etest,failed_keys);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void addTestCasesToReport(ExtentTest etest,ArrayList<String> keys)
    {
        Collections.sort(keys);
        for(String key : keys)
        {
            etest.log(Status.INFO,key+" -- "+KeyManager.getRealValue(key));
        }
    }
}
