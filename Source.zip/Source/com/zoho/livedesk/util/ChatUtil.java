//$Id$
package com.zoho.livedesk.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.io.OutputStreamWriter;
import java.io.OutputStream;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import java.util.ArrayList;
import java.util.Arrays;

import java.io.InputStream;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.google.gson.JsonElement;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.Arrays;
import org.apache.commons.io.IOUtils;

// import com.aventstack.extentreports.ExtentReports;
// import com.aventstack.extentreports.ExtentTest;
// import com.aventstack.extentreports.Status;


import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.qa.server.WebdriverQAUtil;

import java.util.Hashtable;
import java.util.Iterator;

import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.util.BuildChangeSetAnalyser.AutomationResultAnalyser;


public class ChatUtil
{
	// public static String extentReportsLoc=null;
	// public static ExtentReports extent= null;
    
    public static void sendChatResult(Hashtable report, Hashtable result, Hashtable showstopper, Hashtable servicedown,String filePath,String mname,boolean finResult)
    {
        try
        {
            ///       ENDS HERE  ///////////////////////////////////////////////////////
            
            String report_template = WebdriverQAUtil.getAttachmentPath("ldreport_mail.html");
			report_template = report_template.replace("null", "salesiq");
			String content = getMailString(report_template);
			
			content=content.replace("$TOTALUSECASE", ""+report.get("TotalUseCases"));
			content=content.replace("$TIMETAKEN", (""+report.get("TimeTaken")));
			content=content.replace("$SUCCESS", ""+report.get("Success"));
			content=content.replace("$FAILURE", ""+report.get("Failure"));
			content=content.replace("$SUCESSPER", (""+report.get("Success_per")+"%"));
			content=content.replace("$FAILPER", (""+report.get("Failure_per")+"%"));
			content=content.replace("$BROWSER", ""+report.get("Browser"));
			content=content.replace("$SETUP", ""+report.get("Setup"));
			content=content.replace("$URL", ""+report.get("URL"));
			content=content.replace("$BUILD", ""+report.get("Build"));
            
			String data = "<table cellspacing='0'><tbody><tr><td style='width: 321px; vertical-align: top; font-family: 'Liberation Serif';font-size: 12pt;'> No failed use case</td></tbody></table>";
			if(result.size() > 0)
			{
				data = "<table cellspacing='0'><tbody><tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: middle; height:26px;'><div style='position: relative; padding: 4px; width: 313px; height:26px; font-weight: bold;font-family: 'Liberation Serif';font-size: 12pt;'>&nbsp;Use Cases</div></td>";
				data += "<td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: middle; height:26px;'><div style='position: relative; padding: 4px; width: 313px; height:22px; font-weight: bold;font-family: 'Liberation Serif';font-size: 12pt;'>&nbsp;Status</div></td></tr>";
				Set<String> keys = result.keySet();
                for(String key: keys){
                    data += "<tr style='height: 40px;'><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:26px;'>  "+key+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:26px;'>  "+result.get(key)+"</div></td></tr>";
                }
				data += "</tbody></table>";
			}
            content = content.replace("$REPORT", data);
            
			String sdata = "<table cellspacing='0'><tbody><tr><td style='width: 321px; vertical-align: top; font-family: 'Liberation Serif';font-size: 12pt;'> No show stopper issues </td></tbody></table>";
			if(showstopper.size() > 0)
			{
				sdata = "<table cellspacing='0'><tbody>";
				Set<String> keys = showstopper.keySet();
				int i = 1;
				for(String key: keys){
					if(i == 1)
					{
						sdata += "<tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+key+"</div></td><td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+showstopper.get(key)+"</div></td></tr>";
					}
					else
					{
						sdata += "<tr><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+key+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+showstopper.get(key)+"</div></td></tr>";
					}
					i++;
				}
				sdata += "</tbody></table>";
                
			}
			content = content.replace("$SHOWSTOPPER", sdata);
            
			String serdatastyle = "display:none;";
			String serdata = "";
			if(servicedown.size() > 0)
			{
				SimpleDateFormat format = new SimpleDateFormat("d MMM yyyy, h:mm:ss a ");
				serdatastyle = "display:block;";
				serdata = "<table cellspacing='0'><tbody>";
				Set<String> keys = servicedown.keySet();
				int i = 1;
				for(String key: keys){
					Date date = new Date(Long.parseLong(""+servicedown.get(key)));
					String value = format.format(date);
					if(i == 1)
					{
						serdata += "<tr><td style='width: 321px; border-width: 1px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+KeyManager.getRealValue(key)+"</div></td><td style='width: 321px; border-width: 1px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+value+"</div></td></tr>";
					}
					else
					{
						serdata += "<tr><td style='width: 321px; border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+KeyManager.getRealValue(key)+"</div></td><td style='width: 321px; border-width: 0px 1px 1px 0px; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top;'><div style='position: relative; padding: 4px; width: 313px; height:22px;'>  "+value+"</div></td></tr>";
					}
					i++;
				}
				serdata += "</tbody></table>";
                
			}
			content = content.replace("$SERVICEDOWNSTYLE", serdatastyle);
			content = content.replace("$SERVICEDOWN", serdata);
            
            
			String modules = "";
			if((ConfManager.getModules()).equals("all"))
			{
				ArrayList<String> ignore_list = new ArrayList<String>(Arrays.asList((ConfManager.ignoreModules()).split(",")));
				ArrayList<String> mod = new ArrayList<String>(Arrays.asList((ConfManager.getModuleNames()).split(",")));
				for(int i=0;i<mod.size();i++)
				{
					if(!(ignore_list.contains(""+mod.get(i))))
					{
						modules += mod.get(i)+",";
					}
				}
                
                ArrayList<String> supermod = new ArrayList<String>(Arrays.asList((ConfManager.getSuperModuleNames()).split(",")));
                for(int i=0;i<supermod.size();i++)
				{
					if(!(ignore_list.contains(""+supermod.get(i))))
					{
						modules += supermod.get(i)+",";
					}
				}
                
                ArrayList<String> assomod = new ArrayList<String>(Arrays.asList((ConfManager.getAssoModuleNames()).split(",")));
                for(int i=0;i<assomod.size();i++)
				{
					if(!(ignore_list.contains(""+assomod.get(i))))
					{
						modules += assomod.get(i)+",";
					}
				}
                
			}
			else
			{
				modules = "Admin - Portal Owner : "+ConfManager.getModules()+"<div><span>&nbsp;</span></div>";
                modules += "SuperVisor : "+ConfManager.getSuperModules()+"<div><span>&nbsp;</span></div>";
                modules += "Associate : "+ConfManager.getAssoModules();
			}
            
			char comma = ",".charAt(0);
			if(comma == modules.charAt(modules.length()-1))
			{
				modules = modules.substring(0,modules.length()-1);
			}
			modules = modules.replaceAll(",", "\", \"");
			String modulestestedstyle = "display:none;";
            
			if(!(modules.equals("")))
			{
				modulestestedstyle = "display:block;";
			}
			content = content.replace("$MODULESTESTEDSTYLE", modulestestedstyle);
			content = content.replace("$MODULESTESTED", modules);
            
            ///       ENDS HERE  ///////////////////////////////////////////////////////
            
            String subject = getSubject(report);
            // Util.print("SUBJECT : "+subject);
            
            String imgurl = "https://www.zoho.com/salesiq/images/icon-salesiq.png";//"https://www.zoho.com/salesiq/img/favicon.ico";
            
            String modules_result ="";

            if(!(Integer.parseInt(""+report.get("Success_per"))>=95))
            {
	            try
	            {
	            	Hashtable m = (Hashtable)report.get("ModuleResult");
	            	// Util.print(m);
					for(int i = 0,j = 1;i<=6;i++)
		            {
		            	if(m.get("fnum"+i)!=null)
	                    {
		            		modules_result = modules_result+"\\n"+ j++ +")"+m.get("fnum"+ i);
		            	}
		            }
		        }
		        catch(Exception e)
		        {
		        	// Util.print("Exception in chat util module results :");
		        	e.printStackTrace();
		        }

		        modules_result = "\\nModule : "+mname+modules_result;
            }
            
            String totalUsecases = "";
            
        	if(Util.isQuickAutomationSet())
            {
            	totalUsecases = ConfManager.getRealValue("totalUsecasesLocalQuick");
            }
            else if(Util.isModulesChosenInClient())
            {
                totalUsecases = Util.getSelectedModulesTotalUsecases()+"";
            }
            else
            {
            	totalUsecases = ConfManager.getRealValue("totalUsecasesLocal");
            }

            int executedUseCase = Integer.parseInt(report.get("TotalUseCases").toString());
            int totalUsecaseCount = Integer.parseInt(totalUsecases);

            if(totalUsecaseCount < executedUseCase)
            {
            	totalUsecases = report.get("TotalUseCases").toString();
            }
            
            // content = "{\"text\":\"Build : "+report.get("Build")+"\\nURL : "+report.get("URL")+modules_result+"\",\"slides\":[{\"type\":\"table\",\"title\":\"Summary :\",\"data\":{\"headers\":[\"Total Use Cases\",\"Executed Use Cases\",\"Time Taken\",\"Success\",\"Failure\",\"Success(%)\",\"Failure(%)\",\"Browser\",\"Setup\"],\"rows\":[{\"Total Use Cases\":\""+totalUsecases+"\",\"Executed Use Cases\":\""+report.get("TotalUseCases")+"\",\"Time Taken\":\""+report.get("TimeTaken")+"\",\"Success\":\""+report.get("Success")+"\",\"Failure\":\""+report.get("Failure")+"\",\"Success(%)\":\""+report.get("Success_per")+"%\",\"Failure(%)\":\""+report.get("Failure_per")+"%\",\"Browser\":\""+report.get("Browser")+"\",\"Setup\":\""+report.get("Setup")+"\"}]}}],\"buttons\" : [{ \"label\" : \"View Results\", \"hint\" : \"Click here to view the automation results\", \"type\" : \"\", \"action\" : { \"type\" : \"open.url\", \"data\" : { \"web\" : \""+filePath+"\" } } }],\"bot\":{\"name\":\"Automation\",\"image\":\""+imgurl+"\"},\"card\":{\"title\": \""+subject+"\",\"theme\":\"0\",\"thumbnail\": \""+imgurl+"\"}}";
            content = "{\"text\":\"Build : "+report.get("Build")+"\\nURL : "+report.get("URL")+"\",\"slides\":[{\"type\":\"table\",\"title\":\"Summary :\",\"data\":{\"headers\":[\"Total Use Cases\",\"Executed Use Cases\",\"Time Taken\",\"Success\",\"Failure\",\"Success(%)\",\"Failure(%)\",\"Browser\",\"Setup\"],\"rows\":[{\"Total Use Cases\":\""+totalUsecases+"\",\"Executed Use Cases\":\""+report.get("TotalUseCases")+"\",\"Time Taken\":\""+report.get("TimeTaken")+"\",\"Success\":\""+report.get("Success")+"\",\"Failure\":\""+report.get("Failure")+"\",\"Success(%)\":\""+report.get("Success_per")+"%\",\"Failure(%)\":\""+report.get("Failure_per")+"%\",\"Browser\":\""+report.get("Browser")+"\",\"Setup\":\""+report.get("Setup")+"\"}]}}],\"buttons\" : [{ \"label\" : \"View Results\", \"hint\" : \"Click here to view the automation results\", \"type\" : \"\", \"action\" : { \"type\" : \"open.url\", \"data\" : { \"web\" : \""+filePath+"\" } } }],\"bot\":{\"name\":\"Automation\",\"image\":\""+imgurl+"\"},\"card\":{\"title\": \""+subject+"\",\"theme\":\"0\",\"thumbnail\": \""+imgurl+"\"}}";
            
            // Util.print("CONTENT : "+content);
            
            if(finResult)
            {
                // Util.print("Comes here for final result with content : ");
                sendResultAsChatMessage(content);
            }
            else
            {
            	String quick = Util.isQuickAutomationSet()?"Quick":"";
                subject = "SalesIQ "+quick+" Automation - "+mname+" : Total Test Cases : "+report.get("TotalUseCases")+", Failure : "+report.get("Failure")+" ("+report.get("Failure_per")+"%) [Details]("+filePath+")";
                content = "{\"text\":\""+subject+"\",\"bot\":\"name\":\"Automation\",\"image\":\""+imgurl+"\"}}";
                
                sendChatMessage(content);
            }

            // to post to crmplus-salesiq channel the automation must be
            // full automation 
            // not a quick automation
            // automation must be started in updates channel
            // force stop should not have been occurred
            if( !Util.isQuickAutomationSet() && Util.isFullAutomation() && (ConfManager.getChannelID().equals("updatesv")) && !(SalesIQAutomationExceptionHandler.isFatalErrorOccurred()) )
            {
            	Hashtable m = (Hashtable)report.get("ModuleResult");
            	String crmplus_module_result = "\\n"+m.get("fnum5");

            	crmplus_module_result = "\\n"+crmplus_module_result;
				content = "{\"text\":\"Build : "+report.get("Build")+"\\nURL : "+report.get("URL")+crmplus_module_result+"\",\"slides\":[{\"type\":\"table\",\"title\":\"Summary :\",\"data\":{\"headers\":[\"Total Use Cases\",\"Executed Use Cases\",\"Time Taken\",\"Success\",\"Failure\",\"Success(%)\",\"Failure(%)\",\"Browser\",\"Setup\"],\"rows\":[{\"Total Use Cases\":\""+totalUsecases+"\",\"Executed Use Cases\":\""+report.get("TotalUseCases")+"\",\"Time Taken\":\""+report.get("TimeTaken")+"\",\"Success\":\""+report.get("Success")+"\",\"Failure\":\""+report.get("Failure")+"\",\"Success(%)\":\""+report.get("Success_per")+"%\",\"Failure(%)\":\""+report.get("Failure_per")+"%\",\"Browser\":\""+report.get("Browser")+"\",\"Setup\":\""+report.get("Setup")+"\"}]}}],\"buttons\" : [{ \"label\" : \"View Results\", \"hint\" : \"Click here to view the automation results\", \"type\" : \"\", \"action\" : { \"type\" : \"open.url\", \"data\" : { \"web\" : \""+filePath+"\" } } }],\"bot\":{\"name\":\"Automation\",\"image\":\""+imgurl+"\"},\"card\":{\"title\": \""+subject+"\",\"theme\":\"0\",\"thumbnail\": \""+imgurl+"\"}}";
            	sendChatMessage(content,ConfManager.getRealValue("crmplus_channel"));
            }
//            if(true)
//            {
//                String m = "{\"message\":\"MailChimp and Zendesk Integration module are commented due to an open issue\",\"custom_sender_name\":\"Automation\",\"custom_sender_imageurl\":\""+imgurl+"\",\"custom_message\":\"false\"}";
//                
//                sendChatMessage(m);
//            }
            try
            {
            	// Util.print("Finding New Exceptions");

            	// URL location = ChatUtil.class.getProtectionDomain().getCodeSource().getLocation();
	            // Util.print(location.getFile());
	            // extentReportsLoc = location.getFile();
	            // extentReportsLoc = extentReportsLoc.replaceAll("/lib/livedesk-webdriver.jar","/webapps/selenium/reports/");
	            // Util.print(extentReportsLoc);
	   //          String bLabel = Util.buildlabel();
	            
	   //          if(bLabel==null||bLabel=="")
	   //          {
	   //              bLabel = "UnknownLabel";
	   //          }
	            
	   //          if(bLabel.contains("/"))
	   //          {
	   //              bLabel = bLabel.replaceAll("/","_");
	   //          }
            
    //         	extentReportsLoc = extentReportsLoc+bLabel;

    //         	extentReportsLoc =extentReportsLoc+"/ComplexReportException.html";

				// extent=new ExtentReports(extentReportsLoc, true, DisplayOrder.NEWEST_FIRST);

    //             // Util.print("Comes here in file writing");
    //             extentReportsLoc =  "http://"+Util.serverHostName+":"+Util.serverPortNumber+"/reports/"+bLabel+"/ComplexReportException.html";
	            
				// if(Util.oldnewbuild.equals("Valid"))
				// {
				// 	String authtoken = "db5aa90877e60536f02bbce23ae6a030";
				// 	String logsURL = "https://logs.zoho.com";
				// 	String appid = "36064526";
				// 	String setUp = "IDC";

				// 	if(Util.siteNameout().contains("local"))
				// 	{
				// 		authtoken = "ed82b10938606db3d5b4b78ca2789d8a";
				// 		logsURL = "https://solrlogs.localzoho.com";
				// 		appid = "10772528";
				// 		setUp = "LocalZoho";
				// 	}
					
				// 	Util.oldnewbuild = "NotValid";

				// 	// Util.print("Finding New Exceptions");

				// 	URL url1=new URL(logsURL+"/api/stats/buildstats/?service=SalesIQ&appid="+appid+"&authtoken="+authtoken);	
				// 	HttpURLConnection httpcon1 = (HttpURLConnection) (url1.openConnection());
		  //           httpcon1.setRequestMethod("GET");
		  //           httpcon1.setDoOutput(true);
		  //           httpcon1.setRequestProperty("Accept", "application/json");
		  //           InputStream in = httpcon1.getInputStream();
		  //   		String encoding = httpcon1.getContentEncoding();
		  //   		encoding = encoding == null ? "UTF-8" : encoding;
		  //   		String body = IOUtils.toString(in, encoding);
	    	
	   //      		JSONParser parser = new JSONParser();
		  //   		JSONObject json = (JSONObject) parser.parse(body);
		  //   		JSONArray list = (JSONArray)json.get("result");
				// 	String oldid="";
				// 	String newid="";
	    			
	   //  			for(int i=0;i<list.size();i++)
	   //  			{
	   //  				JSONObject ext3 = (JSONObject)list.get(i);
			 //    		JSONArray list2 = (JSONArray)ext3.get("value");
			 //    		for(int j=0;j<list2.size();j++)
			 //    		{
	   //  					JSONObject ext4 = (JSONObject)list2.get(j);
				// 			if(ext4.get("BUILD_LABEL").equals(Util.oldbuild))
	   //  					{
	   //  						oldid=ext4.get("BUILD_ID").toString();
	   //  					}
					
				// 			if(ext4.get("BUILD_LABEL").equals(Util.newbuild))
	   //  					{
				// 				newid=ext4.get("BUILD_ID").toString();
				// 			}
	   //  				}
	   //  			}
					
				// 	URL url3=new URL(logsURL+"/api/stats/buildexceptionstats/?service=SalesIQ&oldbuildid="+oldid+"&newbuildid="+newid+"&appid="+appid+"&authtoken="+authtoken);
				// 	HttpURLConnection httpcon3 = (HttpURLConnection) (url3.openConnection());
		  //           httpcon3.setRequestMethod("GET");
		  //           httpcon3.setDoOutput(true);
		  //           httpcon3.setRequestProperty("Accept", "application/json");
		  //           InputStream in3 = httpcon3.getInputStream();
		  //   		String encoding3 = httpcon3.getContentEncoding();
		  //   		encoding3 = encoding3 == null ? "UTF-8" : encoding3;
		  //   		String body3 = IOUtils.toString(in3, encoding3);
		    	
		  //       	JSONParser parser3 = new JSONParser();
		  //   		JSONObject json3 = (JSONObject) parser3.parse(body3);
		  //   		JSONArray list3 = (JSONArray)json3.get("result");
				// 	ArrayList<String> mylist = new ArrayList<String>();
		  //   	   	ArrayList<Integer> mylist1 = new ArrayList<Integer>();
				// 	ExtentTest test=null;
				// 	for(int i=0;i<list3.size();i++)
				// 	{
				// 		String count="true";
				// 		JSONObject exn3 = (JSONObject)list3.get(i);
				//    		String excep=exn3.get("EXCEPTION_NAME").toString();
				// 		String excepc=exn3.get("COUNT").toString();
				// 		String excepcl=exn3.get("CLASS_NAME").toString();
				// 		int y = Integer.parseInt(excepc);
				// 		mylist1.add(y);
				// 		if(i!=0)
				// 		{
				// 	 		if(!mylist.contains(excep))
				// 	 		{
		  //   					extent.endTest(test);
				// 				extent.flush();
				// 				// Util.print("Complex Report for exceptions at "+extentReportsLoc);
				// 			}
				// 			else if(mylist.contains(excep))
				// 			{
				// 				count="false";
				// 			}
				// 		}
		  //   			if(count.equals("false"))
		  //   			{
				// 			test.log(Status.FAIL,excepcl+"---"+excepc);
				// 		}
				// 		else if(count.equals("true"))
				// 		{
				// 			test=extent.startTest(excep);
				// 			test.assignCategory("Logs - New Exceptions");
				// 			test.log(Status.FAIL,excepcl+"---> Count : "+excepc);
				// 			mylist.add(excep);
				// 		}
				// 	}
				// 	extent.endTest(test);
				// 	extent.flush();
				// 	int temp;
				// 	int p=mylist1.size();
				// 	int m1[] = new int[p];

				// 	for(int i=0;i<p;i++)
				// 	{
				// 		m1[i]=mylist1.get(i);
				// 	}
				//    	for (int k = 0; k < p; k++) 
			 //        {
			 //            for (int j = k + 1; j < p; j++) 
			 //            {
			 //            	if (m1[k]<m1[j])
			 //                {
			 //                	temp = m1[k];
			 //                    m1[k] = m1[j];
			 //                    m1[j] = temp;
			 //                } 
			 //            }
			 //        }
			 //       	ArrayList<Integer> mylist2 = new ArrayList<Integer>();
	   //      	   	ArrayList<String> mylist3 = new ArrayList<String>();
	   // 				ArrayList<String> mylist4 = new ArrayList<String>();
   	// 				ArrayList<String> mylist5 = new ArrayList<String>();
   	// 				try
   	// 				{
			 //        	for(int g = 0; g < 5; g++) 
			 //        	{
			 //        		mylist2.add(m1[g]);
			 //        	}
			 //    	}
			 //    	catch(Exception e){}
			    	
			 //    	try
			 //    	{
			 //        	for(int k=0;k<5;k++)
			 //        	{
			 //       			for(int i=0;i<list3.size();i++)
			 //       			{
				//  				JSONObject exncount = (JSONObject)list3.get(i);
		  //  						String exce=exncount.get("EXCEPTION_NAME").toString();
				// 				String excec=exncount.get("COUNT").toString();
				// 				String excecl=exncount.get("CLASS_NAME").toString();
				// 				int z = Integer.parseInt(excec);
				// 				String check="";
				// 				if(k!=0)
				// 				{
				// 					for(int m=0;m<mylist5.size();m++)
				// 					{
				// 	 					if(mylist5.get(m).equals(excec) && mylist4.get(m).equals(excecl) && mylist3.get(m).equals(exce))
				// 	 					{
				// 	   						check="valid";
				// 	  					}
				// 	  				}
				// 		  			if(check.equals("valid"))
				// 		  			{
				// 		  				continue;
				// 		  			}
				// 	  			}
				// 				if(mylist2.get(k).equals(z))
				// 				{
				// 					mylist3.add(k,exce);
				// 					mylist4.add(k,excecl);
				// 					mylist5.add(k,excec);
				// 					break;
				// 				}
				// 			}
				// 		}
				// 	}
				// 	catch(Exception e){}
					
				// 	String f[]=new String[mylist3.size()];
				// 	String h[]=new String[mylist4.size()];
				// 	String w[]=new String[mylist5.size()];
					
				// 	for(int i=0;i<mylist5.size();i++)
				// 	{
				// 		// Util.print("Exc--->"+mylist3.get(i)+" classname--->"+mylist4.get(i)+" count--->"+mylist5.get(i));
				// 		f[i]=mylist3.get(i);
				// 		h[i]=mylist4.get(i);
				// 		w[i]=mylist5.get(i);
				// 	}
					
				// 	int count=mylist5.size();
				// 	String table_content = "";
				// 	for(int i = 0;i<count;i++)
				// 	{
				// 		if(!table_content.equals(""))
				// 		{
				// 			table_content += ",{";
				// 		}
					
				// 		table_content += "\"Exceptions\":\""+f[i]+"\",\"Classname\":\""+h[i]+"\",\"Count\":\""+w[i]+"\"";
						
				// 		if(!(i == count-1))
				// 		{
				// 			table_content += "}";
				// 		}
				// 	}
                    
    //                 String table = "",newexcep = "";
                    
    //                 if(count == 0)
    //                 {
    //                    newexcep = "{\"text\":\"*No new exceptions found in testing build - "+setUp+"*\\nBuild : "+report.get("Build")+"\\nDifference Build: "+Util.oldbuild+"\",\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";
    //                 }
    //                 else
    //                 {
    //                     table = ",\"slides\":[{\"type\":\"table\",\"title\":\"Exceptions :\",\"data\":{\"headers\":[\"Exceptions\",\"Classname\",\"Count\"],\"rows\":[{"+table_content+"}]}}]";
                        
    //                     newexcep = "{\"text\":\"*Top "+count+"/5 new exceptions in testing build - "+setUp+"*\\nBuild : "+report.get("Build")+"\\nDifference Build: "+Util.oldbuild+"\""+table+",\"buttons\" : [{ \"label\" : \"View New Exceptions\", \"hint\" : \"Click here to view the new exceptions\", \"type\" : \"\", \"action\" : { \"type\" : \"open.url\", \"data\" : { \"web\" : \""+extentReportsLoc+"\" } } }],\"bot\":{\"name\":\"Automation\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"}}";
    //                 }
                    
                    
    //                 // Util.print("Exception Message:"+newexcep);
                    
				// 	sendResultAsChatMessageForException(newexcep);	
				// }
			}
			catch(Exception e)
			{
				// Util.print("Exception while ");
				e.printStackTrace();
			}

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    private static String getSubject(Hashtable report)
    {
    	String quick = Util.isQuickAutomationSet()?"Quick":"";
        String subject = "SalesIQ "+quick+" Automation - "+report.get("Setup")+" - Success Rate - "+report.get("Success_per")+"% | Failure Rate - "+report.get("Failure_per")+"%";
        
        //String subject1 = "\\n<<<<<< Total Use Case : "+report.get("TotalUseCases")+" >>>>>> "+"\\n<<<<<< Time Taken : "+report.get("TimeTaken")+" >>>>>>";
        
        //String subject2 = "\\n<<<<<< Success : "+report.get("Success")+" >>>>>> "+"\\n<<<<<< Failure : "+report.get("Failure")+" >>>>>>";
        
        //String subject3 = "\\n<<<<<< Success % : "+report.get("Success_per")+"% >>>>>> "+"\\n<<<<<< Failure % : "+report.get("Failure_per")+"% >>>>>>";
        
        //String subject4 = "\\n<<<<<< Browser : "+report.get("Browser")+" >>>>>>\\n<<<<<< Setup : "+report.get("Setup")+" >>>>>>\\n<<<<<< URL : "+report.get("URL")+" >>>>>>\\n<<<<<< Build : "+report.get("Build")+" >>>>>>\\n*************************************************************************************************";
        
        //subject = subject + subject1 + subject2 + subject3 + subject4 ;
        
        return subject;
    }
    
    private static String getMailString(String path) throws Exception
	{
        BufferedReader reader = null;
        try
        {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(path),"UTF-8"));
            String line = null;
            StringBuffer st = new StringBuffer();
            while((line = reader.readLine())!=null)
            {
                st.append(line);
                st.append("\r\n");//No i18N
            }
            return st.toString();
        }
        finally
        {
            try{if(reader!=null){reader.close();}}catch(Exception e){Util.print("Unable to close the reader");}
        }
	}
    
    public static void sendResultAsChatMessage(String chmsg)
    {
        OutputStream os = null;
        
        try
        {
            String channelName = ConfManager.getChannelID();
            String aToken = ConfManager.getAuthToken();
            
            URL url = new URL("https://cliq.zoho.com/api/v2/channelsbyname/"+channelName+"/message?authtoken="+aToken+"&scope=InternalAPI");
            Util.print("Chat Util - URL : "+url+" Channel ID - "+channelName+" Auth Token - "+aToken);
            Util.print("Message:"+chmsg);
            
            HttpURLConnection httpcon = (HttpURLConnection) (url.openConnection());
            httpcon.setRequestMethod("POST");
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Content-Type", "application/json");
            
            //String outputBytes = "{\"message\":\""+chmsg+"\"}";//URLEncoder.encode(chmsg, "UTF-8")
            //String outputBytes = "{\"message\":{\"table\":\\"+chmsg+"\"}}";
            String outputBytes = chmsg;
            os = httpcon.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            //os.write(.URLEncoder.encode(data, "UTF-8"));
            os.flush();
            Util.print("Chat Util - Response Code : "+httpcon.getResponseCode());
        }
        catch(Exception exp)
        {
            exp.printStackTrace();
        }
        finally
        {
            try
            {
                os.close();
            }
            catch(Exception exp)
            {
                exp.printStackTrace();
            }
        }
    }

    public static void sendResultAsChatMessageForException(String chmsg)
    {
        OutputStream os = null;
        
        try
        {
            String channelName = ConfManager.getChannelID();
            
            if(channelName.equals("updatesv"))
            {
                channelName = "automation";
            }
            else
            {
                channelName = ConfManager.getRealValue("automation_dev_channel");
            }
            
            String aToken = ConfManager.getAuthToken();
            
            URL url = new URL("https://cliq.zoho.com/api/v2/channelsbyname/"+channelName+"/message?authtoken="+aToken+"&scope=InternalAPI");
            Util.print("Chat Util - URL : "+url+" Channel ID - "+channelName+" Auth Token - "+aToken);
            Util.print("Message:"+chmsg);
            
            HttpURLConnection httpcon = (HttpURLConnection) (url.openConnection());
            httpcon.setRequestMethod("POST");
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Content-Type", "application/json");
            
            String outputBytes = chmsg;
            os = httpcon.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            os.flush();
            Util.print("Chat Util - Response Code : "+httpcon.getResponseCode());
        }
        catch(Exception exp)
        {
            exp.printStackTrace();
        }
        finally
        {
            try
            {
                os.close();
            }
            catch(Exception exp)
            {
                exp.printStackTrace();
            }
        }
    }
    
    public static void sendChatMessage(String chmsg)
    {
        OutputStream os = null;
        
        try
        {
            String channelName = ConfManager.getChannelID();
            String aToken = ConfManager.getAuthToken();
            
            URL url = new URL("https://cliq.zoho.com/api/v2/channelsbyname/"+channelName+"/message?authtoken="+aToken+"&scope=InternalAPI");
            Util.print("Chat Util - URL : "+url+" Channel ID - "+channelName+" Auth Token - "+aToken);
            Util.print("Message:"+chmsg);
            
            HttpURLConnection httpcon = (HttpURLConnection) (url.openConnection());
            httpcon.setRequestMethod("POST");
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Content-Type", "application/json");
            
            //String outputBytes = "{\"message\":\""+chmsg+"\"}";//URLEncoder.encode(chmsg, "UTF-8")
            //String outputBytes = "{\"message\":{\"table\":\\"+chmsg+"\"}}";
            String outputBytes = chmsg;
            os = httpcon.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            //os.write(.URLEncoder.encode(data, "UTF-8"));
            os.flush();
            Util.print("Chat Util Initial Message - Response Code : "+httpcon.getResponseCode());
        }
        catch(Exception exp)
        {
            exp.printStackTrace();
        }
        finally
        {
            try
            {
                os.close();
            }
            catch(Exception exp)
            {
                exp.printStackTrace();
            }
        }
    }

    public static void sendChatMessage(String chmsg,String channelName)
    {
    	sendChatMessage(chmsg,channelName,false);
    }

    public static void sendChatMessage(String chmsg,String channelName,String authToken)
    {
    	sendChatMessage(chmsg,channelName,authToken,false);
    }

    public static void sendChatMessage(String chmsg,String channelName,boolean isChat)
    {
    	sendChatMessage(chmsg,channelName,null,isChat);
    }

    public static void sendChatMessage(String chmsg,String channelName,String aToken,boolean isChat)
    {
        OutputStream os = null;
        
        try
        {
        	if(aToken==null)
        	{
        		aToken=ConfManager.getAuthToken();
        	}
        	   
            URL url = null;

            if(!isChat)
            {
            	url=new URL("https://cliq.zoho.com/api/v2/channelsbyname/"+channelName+"/message?authtoken="+aToken+"&scope=InternalAPI");
            }
            else
            {
            	String chatid=channelName;

            	url=new URL("https://cliq.zoho.com/api/v2/chats/"+chatid+"/message?authtoken="+aToken+"&scope=InternalAPI");
            }

            Util.print("Chat Util - URL : "+url+" Channel ID - "+channelName+" Auth Token - "+aToken);
            Util.print("Message:"+chmsg);
            
            HttpURLConnection httpcon = (HttpURLConnection) (url.openConnection());
            httpcon.setRequestMethod("POST");
            httpcon.setDoOutput(true);
            httpcon.setRequestProperty("Content-Type", "application/json");
            
            //String outputBytes = "{\"message\":\""+chmsg+"\"}";//URLEncoder.encode(chmsg, "UTF-8")
            //String outputBytes = "{\"message\":{\"table\":\\"+chmsg+"\"}}";
            String outputBytes = chmsg;
            os = httpcon.getOutputStream();
            os.write(outputBytes.getBytes("UTF-8"));
            //os.write(.URLEncoder.encode(data, "UTF-8"));
            os.flush();
            Util.print("Chat Util Initial Message - Response Code : "+httpcon.getResponseCode());
        }
        catch(Exception exp)
        {
            exp.printStackTrace();
        }
        finally
        {
            try
            {
                os.close();
            }
            catch(Exception exp)
            {
                exp.printStackTrace();
            }
        }
    }

    public static void postCollapsedMessage(String channel,String title,String message)
    {
    	postCollapsedMessage(channel,title,message,false);
    }

    public static void postCollapsedMessage(String channel,String title,String message,boolean isChat)
    {
    	postCollapsedMessage(channel,title,message,"Automation",isChat);
    }

    public static void postCollapsedMessage(String channel,String title,String message,String sender)
    {
    	postCollapsedMessage(channel,title,message,sender,false);
    }

    public static void postCollapsedMessage(String channel,String title,String message,String sender,boolean isChat)
    {
		String  formatmsg="{\"type\":\"label\",\"title\":\"\",\"data\":[{\"\":\""+message+"\"}]}";
		String imgurl="https://www.zoho.com/salesiq/images/icon-salesiq.png";
		String content = "{\"text\":\"*"+title+"*\",\"card\":{\"theme\":\"1\"}" + ",\"slides\":["+formatmsg+"]"+",\"bot\":{\"name\":\""+sender+"\",\"image\":\"" + imgurl + "\"}}";

        ChatUtil.sendChatMessage(content,channel,isChat);
    }

   	public static void postToChannel(String message,String channel,String authToken)
	{
		postToCliq(message,"Automation",channel,authToken,false);
	}

    public static void postToCliq(String message)
    {
    	postToCliq(message,ConfManager.getChannelID());
    }

    public static void postToAutomationDevChannel(String message)
    {
    	postToCliq(message,ConfManager.getRealValue("automation_dev_channel"));
    }

   	public static void postToCliq(String message,String channel)
   	{
   		postToCliq(message,"Automation",channel);
   	}

   	public static void postToCliq(String message,String sender,String channel)
	{
		postToCliq(message,sender,channel,false);
	}

   	public static void postToCliq(String message,String sender,String channel,boolean isChat)
   	{
   		postToCliq(message,sender,channel,null,isChat);
   	}

   	public static void postToCliq(String message,String sender,String channel,String authToken,boolean isChat)
	{
        String messageContent = "{\"text\":\""+message+"\",\"bot\":{\"name\":\""+sender+"\",\"image\":\"https://www.zoho.com/salesiq/images/icon-salesiq.png\"},\"card\" :{\"theme\" : \"0\",\"title\" : \"\"}}";
        ChatUtil.sendChatMessage(messageContent,channel,authToken,isChat);
	}

	public static void postAutomationHistoryReport(int past_runs_count,String channel) throws Exception
	{
		try
		{
			AutomationResultAnalyser.postAutomationHistoryReport(past_runs_count,channel);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void postEntireAutomationHistoryReportInOneMessage(int past_runs_count,String channel) throws Exception
	{
		try
		{
			AutomationResultAnalyser.postEntireAutomationHistoryReportInOneMessage(past_runs_count,channel);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
