//$Id$
package com.zoho.livedesk;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;

import com.zoho.livedesk.client.AgentsSettings;
import com.zoho.livedesk.client.BlockedIP;
import com.zoho.livedesk.client.CompanyInfo;
import com.zoho.livedesk.client.Department;
import com.zoho.livedesk.client.PortalSettings;
import com.zoho.livedesk.client.CannedMessages;
import com.zoho.livedesk.client.AskForHelp;
import com.zoho.livedesk.client.KeyboardShortcuts;
import com.zoho.livedesk.client.Personalize;
import com.zoho.livedesk.client.MyColleagueChatBar;
import com.zoho.livedesk.client.MyProfile;
import com.zoho.livedesk.client.ReportsModule;
import com.zoho.livedesk.client.Plan.PlanDifference;

import com.zoho.livedesk.client.NewAccount.NewAccountUtil;
import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.server.ConfManager;

public class LiveDeskTesting {

	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	public static ArrayList<String> tested_modules = new ArrayList<String>();
	public static String modulesstr = ConfManager.getModules();
	public static ArrayList<String> list = new ArrayList<String>(Arrays.asList(modulesstr.split(",")));
	public static Hashtable report = new Hashtable();

	public static final String[] modules={"Operators Settings","Company Settings","BlockedIP Settings","Department Settings","Portal Settings","Canned Message","Ask for Help","Keyboard Shortcuts","Personalize","Chat Bar-My Colleagues","MyProfile","Reports","Plan Difference"};

	public static Hashtable test(WebDriver driver, long starttime)
	{
		tested_modules = new ArrayList<String>();
		result = new Hashtable();
		report.put("starttime", starttime);
		if(isTest("Operators Settings"))
		{
			hashtable = AgentsSettings.agentsConfig(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Operators Settings");
		}

		if(isTest("Company Settings"))
	    {
			hashtable = CompanyInfo.companydetails(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Company Settings");
		}
        if(isTest("BlockedIP Settings"))
        {
            hashtable = BlockedIP.blockedIP(driver);
            result.putAll((Hashtable) hashtable.get("result"));
            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
            tested_modules.add("BlockedIP Settings");
        }

        if(isTest("Department Settings"))
		{
			hashtable = Department.department(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Department Settings");
		}

        if(isTest("Portal Settings"))
		{
			hashtable = PortalSettings.portalSettings(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Portal Settings");
		}

        if(isTest("Canned Message"))
		{
			// have navigated this to canned response module
			
			// hashtable = CannedMessages.cannedMsgConfig(driver);
			// result.putAll((Hashtable) hashtable.get("result"));
			// servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			// tested_modules.add("Canned Message");
		}

        if(isTest("Ask for Help"))
		{
			// added need help instead of this so commented below

			// hashtable = AskForHelp.askforhelp(driver);;
			// result.putAll((Hashtable) hashtable.get("result"));
			// servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			// tested_modules.add("Ask for Help");
		}
		if(isTest("Keyboard Shortcuts"))
		{
			hashtable = KeyboardShortcuts.shortcutkeys(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Keyboard Shortcuts");
		}
		if(isTest("Personalize"))
		{
			hashtable = Personalize.personalizeSett(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Personalize");
		}
		if(isTest("Chat Bar-My Colleagues"))
		{
			hashtable = MyColleagueChatBar.chatBarConfig(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("Chat Bar-My Colleagues");
		}
		if(isTest("MyProfile"))
		{
			hashtable = MyProfile.myProfile(driver);
			result.putAll((Hashtable) hashtable.get("result"));
			servicedown.putAll((Hashtable) hashtable.get("servicedown"));
			tested_modules.add("MyProfile");
		}
		if(isTest("Reports"))
        {
            hashtable = ReportsModule.genReport(driver);
            result.putAll((Hashtable) hashtable.get("result"));
            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
            tested_modules.add("Reports");
        }
		if(isTest("Plan Difference"))
        {
            hashtable = PlanDifference.plandiff(driver);
            result.putAll((Hashtable) hashtable.get("result"));
            servicedown.putAll((Hashtable) hashtable.get("servicedown"));
            tested_modules.add("Plan Difference");
        }

        hashtable = new Hashtable();
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	public static boolean isTest(String... module_names)
	{
		return Util.isTest(list,module_names);
	}

	public static Hashtable clear(WebDriver driver)
	{
		if(list.contains("Operators Settings") || list.contains("all"))
		{
			result.put("clearAgentSettings", AgentsSettings.clearAgentSettings(driver));
		}
		if(list.contains("Company Settings") || list.contains("all"))
		{
			result.put("clearCompanyInfo", CompanyInfo.clearCompanyInfo(driver));
		}
		if(list.contains("Department Settings") || list.contains("all"))
		{
			result.put("clearDepartment", Department.clearDepts(driver));
		}
		if(list.contains("Portal Settings") || list.contains("all"))
		{
			result.put("clearPortalSettings", PortalSettings.clearPortalSetings(driver));
		}
		if(list.contains("BlockedIP Settings") || list.contains("all"))
		{
			result.put("clearBlockedIP", BlockedIP.clearBlockedIPs(driver));
		}
		if(list.contains("Canned Message") || list.contains("all"))
		{
			result.put("clearCannedMessages", CannedMessages.clearCannedMessages(driver));
		}
		return result;
	}
	
	//Status report 
	public static Hashtable getReport()
	{
		report.put("Tested_Modules",tested_modules);
		report.put("Use_Cases", result);
		return report;
	}
}
