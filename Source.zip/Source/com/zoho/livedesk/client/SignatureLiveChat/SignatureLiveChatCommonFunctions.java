//$Id$
package com.zoho.livedesk.client.SignatureLiveChat;

import java.util.List;
import java.util.Hashtable;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;

import org.sikuli.script.Screen;
import org.sikuli.script.Pattern;


import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.*;

public class SignatureLiveChatCommonFunctions
{
	public static By INCOMING_CHAT_CONTAINER_ID=By.id("waitinglist");

	public static void init(WebDriver driver)throws Exception
	{
		new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
		new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("menu_setting")),5);
		Tab.clickSettings(driver);
		Tab.clickEmbedTab(driver);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("embedlist"),By.className("list-row")));
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("embedhomepage")),5);
	}

	public static void sigLiveChat(WebDriver driver)throws Exception
	{
		init(driver);
		WebElement element = getLiveChatElement(driver);
		CommonUtil.clickWebElement(driver,element);
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emrightnav")),5);
	}

	public static WebElement getLiveChatElement(WebDriver driver) throws Exception
	{
		List<WebElement> addEmbed = CommonUtil.getElement(driver,By.id("embedhomepage")).findElements(By.className("addembx"));
		WebElement element = CommonUtil.getElementByAttributeValue(addEmbed,"boxname","livechatemail");
		return element;
	}

	public static boolean isElementDisplayed(WebElement element) throws Exception
	{
		try
		{
			if(element.isDisplayed())
			{
				return true;
			}
			return false;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static boolean checkContent(WebElement element,String content,ExtentTest etest) throws Exception
	{
		if(CommonUtil.checkStringcontains(element.getText().toLowerCase(),content.toLowerCase(),etest))
		{
			return true;
		}
		return false;
	}

	public static void toggleOFF(WebDriver driver,String id) throws Exception
	{
		if(CommonUtil.getElement(driver,By.id(id)).getAttribute("class").contains("set_on"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(id)));
		}
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id(id)),"class","set_off");
	}

	public static boolean clickToggle(WebElement element,ExtentTest etest) throws Exception
	{
		String beforeClass = element.getAttribute("class");
		if(isElementDisplayed(element))
		{
			etest.log(Status.PASS,"Toggle button was displayed");
			element.click();
			Thread.sleep(500);
			if(!element.getAttribute("class").toLowerCase().contains(beforeClass))
			{
				etest.log(Status.PASS,"Toggle Button clicked");
				element.click();
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Toggle button was not clickable");
				return false;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Toggle button was not displayed");
			return false;
		}
	}

	public static boolean checkUpdateAndCancelButton(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","save_emconfig"),5);
			if(isElementDisplayed(CommonUtil.elfinder(driver,"id","save_emconfig")))
			{
				etest.log(Status.PASS,"Update and cancel div were displayed");
				return true;
			}
			etest.log(Status.FAIL,"Update and cancel div were not displayed");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkUpdateAndCancelButton","Operator window screenshot");
			return false;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static void clickUpdate(WebDriver driver) throws Exception
	{
		List<WebElement> updateAndCancelButtons = CommonUtil.getElement(driver,By.id("save_emconfig")).findElements(By.tagName("span"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(updateAndCancelButtons,"documentclick","saveEmbedConfig"));
	}

	public static void clickCancel(WebDriver driver) throws Exception
	{
		List<WebElement> updateAndCancelButtons = CommonUtil.getElement(driver,By.id("save_emconfig")).findElements(By.tagName("span"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(updateAndCancelButtons,"documentclick","cancelEmbedConfig"));
	}

	public static boolean checkForgotSomethingDiv(WebDriver driver,ExtentTest etest) throws Exception
	{
		if(isElementDisplayed(CommonUtil.elfinder(driver,"classname","lvd_popupsub")))
		{
			if(checkContent(CommonUtil.elfinder(driver,"classname","lvd_popuptitle"),"Forgot Something",etest))
			{
				etest.log(Status.PASS,"Forgot something popup displayed");
				if(isElementDisplayed(CommonUtil.elfinder(driver,"id","popupftr")))
				{
					etest.log(Status.PASS,"Save and cancel buttons are found in forgot something popup");
				}
				else
				{
					etest.log(Status.FAIL,"Save and cancel buttons are not found in forgot something popup");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkForgotSomethingDiv","Operator window screenshot");
					return false;
				}
				if(isElementDisplayed(CommonUtil.elfinder(driver,"id","dlgclose")))
				{
					etest.log(Status.PASS,"Close icon was found in the popup");
				}
				else
				{
					etest.log(Status.FAIL,"Close icon was not found in the popup");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkForgotSomethingDiv","Operator window screenshot");
					return false;
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkForgotSomethingDiv","Operator window screenshot");
				return false;
			}
		}
		else
		{
			etest.log(Status.FAIL,"No popup displayed on closing without saving the changes made");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkForgotSomethingDiv","Operator window screenshot");
			return false;
		}
		return true;
	}

	public static void clickCancelInForgotSomethingDiv(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("cancelbtn")),5);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("cancelbtn")));
	}

	public static void clickSaveInForgotSomethingDiv(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("okbtn")),5);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("okbtn")));
	}

	public static void clickInLHS(WebDriver driver,String code) throws Exception
	{
		CommonWait.waitTillDisplayed(driver,By.id("emconfigmain"));
		List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
		WebElement tab = CommonUtil.getElementByAttributeValue(leftTabElements,"tabname",code);
		CommonWait.waitTillDisplayed(tab);
		CommonUtil.clickWebElement(driver,tab);
		Thread.sleep(1000);
		CommonWait.waitTillDisplayed(driver,By.id("stikerlistmain"));
	}

	public static void clickInRHS(WebDriver driver,String signature) throws Exception
	{
		List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
		WebElement signatureTab = CommonUtil.getElementByAttributeValue(leftTabElements,"tabname","signature");
		CommonWait.waitTillDisplayed(signatureTab);
		CommonUtil.clickWebElement(driver,signatureTab);
		CommonWait.waitTillDisplayed(driver,By.id("emrightnav"));
		List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav"),By.className("talign_cn")).findElements(By.tagName("span"));
		WebElement icon = CommonUtil.getElementByAttributeValue(rightTabElements,"signature",signature);
		CommonWait.waitTillDisplayed(icon);
		CommonUtil.clickWebElement(driver,icon);
		Thread.sleep(1000);
		CommonWait.waitTillDisplayed(driver,By.id("stikerlistmain"));
	}

	public static void clickInChatCode(WebDriver driver,String tabName) throws Exception
	{
		SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
		List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
		WebElement chatCodeSubElements = leftTabElements.get(2);
		CommonUtil.waitTillWebElementDisplayed(driver,chatCodeSubElements,5);
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(chatCodeSubElements))
		{
			WebElement tab = CommonUtil.getElementByAttributeValue(chatCodeSubElements.findElements(By.tagName("span")),"subtab",tabName);
			CommonUtil.clickWebElement(driver,tab);
			if(tabName.contains("apperance"))
			{
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.id("CLOGO5")),5);
			}
			else
			{
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.id("openseparate")),5);
			}
		}
	}

	public static void clickInOperatorCode(WebDriver driver,String tabName) throws Exception
	{
		SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
		List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
		WebElement chatCodeSubElements = leftTabElements.get(4);
		CommonUtil.waitTillWebElementDisplayed(driver,chatCodeSubElements,5);
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(chatCodeSubElements))
		{
			WebElement tab = CommonUtil.getElementByAttributeValue(chatCodeSubElements.findElements(By.tagName("span")),"subtab",tabName);
			CommonUtil.clickWebElement(driver,tab);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.id("CLOGO5")),5);
		}
	}

	public static WebElement getShowPreviewElement(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emrightnav")),5);
		List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav")).findElements(By.tagName("span"));
		WebElement showPreviewElement = CommonUtil.getElementByAttributeValue(rightTabElements,"documentclick","toggelSignaturePreview");
		return showPreviewElement;
	}

	public static boolean checkSignatureIconPreviewOnline(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		CommonWait.waitTillDisplayed(CommonUtil.getElement(driver,By.id("signaturemailimage")));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("signaturemailimage"))))
		{
			etest.log(Status.PASS,"Signature live chat icon was displayed in preview screen");
			if(CommonUtil.getElement(driver,By.id("signaturemailimage")).getAttribute("src").contains("1.png") || 
				CommonUtil.getElement(driver,By.id("signaturemailimage")).getAttribute("src").contains("ssticker_online"))
			{
				etest.log(Status.PASS,"Online signature live chat icon was displayed in preview screen");
			}
			else
			{
				etest.log(Status.FAIL,"Online signature live chat icon was not displayed in preview screen");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureIconPreviewOnline","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Signature icon was not displayed in preview screen");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureIconPreviewOnline","Operator window screenshot");
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkSignatureIconPreviewOffline(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		CommonWait.waitTillDisplayed(CommonUtil.getElement(driver,By.id("signaturemailimage")));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("signaturemailimage"))))
		{
			etest.log(Status.PASS,"Signature live chat icon was displayed in preview screen");
			if(CommonUtil.getElement(driver,By.id("signaturemailimage")).getAttribute("src").contains("0.png") || 
				CommonUtil.getElement(driver,By.id("signaturemailimage")).getAttribute("src").contains("ssticker_offline"))
			{
				etest.log(Status.PASS,"Offline signature live chat icon was displayed in preview screen");
			}
			else
			{
				etest.log(Status.FAIL,"Offline signature live chat icon was not displayed in preview screen");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureIconPreviewOffline","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Signature icon was not displayed in preview screen");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureIconPreviewOffline","Operator window screenshot");
			failcount++;
		}
		return returnResult(failcount);
	}

	public static void clickMaxIcon(WebDriver driver,WebElement maxIcon,ExtentTest etest) throws Exception
	{
		CommonSikuli.findInWholePage(driver,"maxicon.png","UI425",etest);
		((JavascriptExecutor) driver).executeScript("EmbedConfig.signatureFullPreview(arguments[0])",maxIcon);
		CommonWait.waitTillDisplayed(driver,By.id("sendmaildiv"));
	}

	public static boolean checkClickHere(WebDriver driver,ExtentTest etest)throws Exception
	{
		int failcount = 0;
		WebElement clickHereElement = CommonUtil.getElement(driver,By.id("emrightnav"),By.className("linkdisplay"));
		if(isElementDisplayed(clickHereElement) && checkContent(clickHereElement,"Click here",etest))
		{
			etest.log(Status.PASS,"'Click here' link text was displayed in the right nav of signature live chat");
			CommonUtil.clickWebElement(driver,clickHereElement);
			CommonWait.waitTillDisplayed(driver,By.id("signature_url"));
			WebElement signatureLinkUrl = CommonUtil.getElement(driver,By.id("signature_url"));
			CommonUtil.waitTillWebElementDisplayed(driver,signatureLinkUrl,5);
			if(isElementDisplayed(signatureLinkUrl) && checkContent(signatureLinkUrl,"does not support the html code",etest))
			{
				etest.log(Status.PASS,"'Click here' link text was clicked and the respective tab was opened");
				if(checkContent(signatureLinkUrl,"Image Url",etest))
				{
					etest.log(Status.PASS,"Image Url box was displayed");
				}
				else
				{
					etest.log(Status.FAIL,"Image Url box was not displayed");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkClickHere","Operator window screenshot");
					failcount++;
				}
				if(checkContent(signatureLinkUrl,"Link Url",etest))
				{
					etest.log(Status.PASS,"Link url box was displayed");
				}
				else
				{
					etest.log(Status.FAIL,"Link Url box was not displayed");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkClickHere","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"'CLick here' link text gives a click error");
				failcount++;
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkClickHere","Operator window screenshot");
			}
		}
		else
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkClickHere","Operator window screenshot");
		}
		return returnResult(failcount);
	}

	public static String getWebsiteName(WebDriver driver) throws Exception
	{
		WebElement embedConfigElement = CommonUtil.getElement(driver,By.id("embedconfigform"));
		List<WebElement> embedSpanELements = embedConfigElement.findElements(By.tagName("span"));
		WebElement websiteNameElement = CommonUtil.getElementByAttributeValue(embedSpanELements,"prop","websitename");
		return websiteNameElement.getText();
	}

	public static boolean isSetON(WebElement ele) throws Exception
	{
		CommonWait.waitTillDisplayed(ele);
		if(ele.getAttribute("class").contains("set_on"))
		{
			return true;
		}
		return false;
	}

	public static void initVisitorEnd(WebDriver driver) throws Exception
	{
		// String windowHandle = driver.getWindowHandle();
		// List<WebElement> icons = CommonUtil.getElement(driver,By.id("trackconfigmin")).findElements(By.tagName("em"));
		// CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(icons,"appname","zmail"));
		// CommonUtil.switchToTab(driver,1);
		// driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/signaturelivechat.html");
		// CommonUtil.switchToTab(driver,0);

		driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/signaturelivechat.html");
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("htmlcode")),5);
	}

	public static void initVisitorEndSignatureIcon(WebDriver visitor_driver,String sigCode)throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("htmlcode")),5);
		CommonUtil.sendKeysToWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("htmlcode")),sigCode);
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("convert")));
		CommonUtil.waitTillWebElementDisplayed(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("output")),5);
	}

	public static void initChat(WebDriver driver,ExtentTest etest)throws Exception
	{
		new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
		new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
		sigLiveChat(driver);
		clickInChatCode(driver,"behaviourpreference");
		if(CommonUtil.getElement(driver,By.id("openseperate")).getAttribute("class").contains("set_off"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("openseperate")));
			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickUpdate(driver);
				etest.log(Status.PASS,"Details changed were updated");
			}
		}
	}

	public static Hashtable<String,Boolean> isChatRoutedToAgents(ExtentTest etest,WebDriver... drivers) throws Exception
	{
		return ChatRouting.isChatRoutedToAgents(etest,drivers);
	}

	public static void initiateChat(WebDriver visitor_driver,ExtentTest etest) throws Exception
	{
		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="question"+label;

		VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
	}

	public static boolean returnResult(int failcount)
	{
		return CommonUtil.returnResult(failcount);
	}

}
