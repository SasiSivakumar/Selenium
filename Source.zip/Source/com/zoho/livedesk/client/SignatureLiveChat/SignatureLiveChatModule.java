//$Id$
package com.zoho.livedesk.client.SignatureLiveChat;

import java.util.List;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.SignatureLiveChat.SignatureLiveChatCommonFunctions;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

public class SignatureLiveChatModule
{

	public static Hashtable finalResult = new Hashtable();
	public static Hashtable visitor_details = new Hashtable();
	public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String portal_name=null;
	public static String embed_name=null;

    public static String department="";

    public static String 
    COMPANY_ADDR = "ABC STREET,XYZ",
    COMPANY_DESC = "Just another company",
    WEBSITE_NAME = "https://www.zoho.com";

    public static String sigLinkCode = "";
    public static boolean isClogo = false;
    public static boolean isContact_details = false;
    public static boolean isAboutCompany = false;

    public static String widget_code="";
    public static String behaviourheading = "Choose the way you want to open your chat window";

	public static Hashtable test(WebDriver driver1) throws Exception
	{
		try
		{
			if(embed_name==null)
			{
				embed_name=ExecuteStatements.getDefaultEmbedName(driver1);
			}

			widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver1,embed_name);
			portal_name=ExecuteStatements.getPortal(driver1);

            TestResults = new Hashtable<String,Boolean>();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLC1"));
			ComplexReportFactory.setValues(etest,"Automation","SignatureLiveChat");

			try
			{
		        init(driver1);
				TestResults.put("SLC1",checkLiveChatForEmails(driver1));            
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver1,etest);
			}

            ComplexReportFactory.closeTest(etest);

         	etest=ComplexReportFactory.getTest("Signature Live Chat Page");
			ComplexReportFactory.setValues(etest,"Automation","SignatureLiveChat");

			try
			{
				checkSignatureLiveChatPage(driver1);
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver1,etest);
			}

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Signature Live Chat - Chat code");
			ComplexReportFactory.setValues(etest,"Automation","SignatureLiveChat");

			try
			{
				checkChatCode(driver1);
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver1,etest);
			} 


            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Signature Live Chat - Operator code");
			ComplexReportFactory.setValues(etest,"Automation","SignatureLiveChat");

			try
			{
				checkOperatorCode(driver1);
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver1,etest);
			}

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Signature Live Chat - Visitor end");
			ComplexReportFactory.setValues(etest,"Automation","SignatureLiveChat");

			try
			{
				checkVisitorEnd(driver1);
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver1,etest);
			}

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Signature Live Chat - Disabled");
			ComplexReportFactory.setValues(etest,"Automation","SignatureLiveChat");

			try
			{
				checkSignatureLiveChatDisabled(driver1);
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest);
				TakeScreenshot.screenshot(driver1,etest);
			}
			
            ComplexReportFactory.closeTest(etest);
   		}
		catch(Exception e)
		{
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            TakeScreenshot.screenshot(driver1,etest);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);

			finalResult.put("result",TestResults);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}
	}

	public static void init(WebDriver driver) throws Exception
	{
		SignatureLiveChatCommonFunctions.init(driver);
		etest.log(Status.INFO,"Website name was found in embed tab in settings");
		// Tab.clickCompany(driver);
		// CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("companyaddress")),COMPANY_ADDR);
		// etest.log(Status.INFO,"Company contact information was changed to '"+COMPANY_ADDR+"'");
		// CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("companydesc")),COMPANY_DESC);
		// etest.log(Status.INFO,"Company description was changed to '"+COMPANY_DESC+"'");
		SignatureLiveChatCommonFunctions.sigLiveChat(driver);
		SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
		navigateToEbonyTheme(driver);
		SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
		if(CommonUtil.getElement(driver,By.id("openseperate")).getAttribute("class").contains("set_off"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("openseperate")));
			CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("openseperate")),"class","set_on");
		
			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickUpdate(driver);
			}
		}
		new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
		new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
	}

	public static boolean checkLiveChatForEmails(WebDriver driver) throws Exception
	{
		int failcount = 0;
		WebElement liveChatElement;
		SignatureLiveChatCommonFunctions.init(driver);
		liveChatElement = SignatureLiveChatCommonFunctions.getLiveChatElement(driver);
		try
		{
			if(SignatureLiveChatCommonFunctions.checkContent(liveChatElement,"Live chat for emails",etest))
			{
				etest.log(Status.PASS,"Live Chat for emails tab was found in embed tab");
			}
			else
			{
				etest.log(Status.FAIL,"Live chat for emails tab was not found in embed tab");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Exception",e);
			failcount++;
		}
		try
		{
			CommonUtil.scrollToBottomOfPage(driver);
			if(!liveChatElement.getText().contains("Enabled"))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(liveChatElement,By.className("stus_tglbtn"),By.tagName("em")));
				CommonUtil.mouseHover(driver,liveChatElement);
				CommonUtil.waitTillWebElementContainsAttributeValue(liveChatElement,"status","enable");
			}

			if(SignatureLiveChatCommonFunctions.checkContent(liveChatElement.findElement(By.className("stus_tglbtn")),"Enabled",etest))
			{
				etest.log(Status.PASS,"Live chat for emails was enabled");
				CommonUtil.mouseHover(driver,CommonUtil.getElement(liveChatElement,By.className("stus_tglbtn"),By.tagName("em")));
				CommonUtil.waitTillWebElementContainsAttributeValue(liveChatElement.findElement(By.className("stus_tglbtn")),"innerText","Disable");
				if(SignatureLiveChatCommonFunctions.checkContent(liveChatElement.findElement(By.className("stus_tglbtn")),"Disable",etest))
				{
					etest.log(Status.PASS,"In Live chat for emails, On hovering over 'Enabled' it changed to 'Disable'");
					TestResults.put("SLC2",true);
				}
				else
				{
					TestResults.put("SLC2",false);
					etest.log(Status.FAIL,"Hovering over button failed");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.INFO,"Live chat for emails was not enabled");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Operator window screenshot");
				failcount++;
			}
			CommonUtil.mouseHover(driver,liveChatElement);
			Thread.sleep(1000);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(liveChatElement,By.className("stus_tglbtn"),By.tagName("em")));
			CommonUtil.mouseHover(driver,liveChatElement);
			CommonUtil.waitTillWebElementContainsAttributeValue(liveChatElement,"status","disable");
			if(SignatureLiveChatCommonFunctions.checkContent(liveChatElement.findElement(By.className("stus_tglbtn")),"Disabled",etest))
			{
				etest.log(Status.PASS,"Live chat for emails was disabled");
				CommonUtil.mouseHover(driver,CommonUtil.getElement(liveChatElement,By.className("stus_tglbtn"),By.tagName("em")));
				CommonUtil.waitTillWebElementContainsAttributeValue(liveChatElement.findElement(By.className("stus_tglbtn")),"innerText","Enable");
				if(SignatureLiveChatCommonFunctions.checkContent(liveChatElement.findElement(By.className("stus_tglbtn")),"Enable",etest))
				{
					etest.log(Status.PASS,"In Live chat for emails, On hovering over 'Disabled' it changed to 'Enable'");
					TestResults.put("SLC3",true);
				}
				else
				{
					TestResults.put("SLC3",false);
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Operator window screenshot");
					failcount++;
				}	
			}
			else
			{
				etest.log(Status.INFO,"Live chat for emails was not disabled");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Operator window screenshot");
				failcount++;		
			}
			CommonUtil.mouseHover(driver,liveChatElement);
			Thread.sleep(1000);
			if(!liveChatElement.getText().contains("Enabled"))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(liveChatElement,By.className("stus_tglbtn"),By.tagName("em")));
				CommonUtil.mouseHover(driver,liveChatElement);
				CommonUtil.waitTillWebElementContainsAttributeValue(liveChatElement,"status","enable");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLiveChatForEmails","Exception",e);
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkSignatureLiveChatPage(WebDriver driver)
	{
		int failcount = 0;
		try
		{
			SignatureLiveChatCommonFunctions.sigLiveChat(driver);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emconfigmain"))) &&
				SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emrightnav"),By.className("signr_title")),"Signature Live Chat",etest))
			{
				etest.log(Status.PASS,"Signature live chat page was displayed");
			}
			else
			{
				etest.log(Status.FAIL,"Signature live chat page was not displayed");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Exception",e);
			failcount++;
		}
		try
		{
			boolean closeflag = true;
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emrightnav"),By.className("sqico-close"))))
			{
				etest.log(Status.PASS,"Close icon was displayed in the signature live chat page");
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("emrightnav"),By.className("sqico-close")));
				CommonWait.waitTillDisplayed(driver,By.id("embedhomepage"));
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("embedhomepage"))))
				{
					etest.log(Status.PASS,"Signature live chat page closes on clicking close icon");
				}
				else
				{
					etest.log(Status.FAIL,"Signature live chat page doesnot close on clicking close icon");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
					closeflag = false;
					failcount++;
				}

				CommonUtil.clickWebElement(driver,SignatureLiveChatCommonFunctions.getLiveChatElement(driver));
				CommonWait.waitTillDisplayed(driver,By.id("emconfigmain"));
				new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
				new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
				CommonWait.waitTillDisplayed(driver,By.id("embedhomepage"));
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("embedhomepage"))))
				{
					etest.log(Status.PASS,"Signature live chat page closes on pressing Escape key");
				}
				else
				{
					etest.log(Status.FAIL,"Signature live chat page doesnot close on pressing escape key");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
					closeflag = false;
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Close icon was not displayed in the signature live chat page");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
				closeflag = false;
				failcount++;
			}
			if(closeflag)
			{
				TestResults.put("SLC5",true);
			}
			else
			{
				TestResults.put("SLC5",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Exception",e);
			failcount++;
			TestResults.put("SLC5",false);
		}
		try
		{
			CommonUtil.clickWebElement(driver,SignatureLiveChatCommonFunctions.getLiveChatElement(driver));
			CommonWait.waitTillDisplayed(driver,By.id("emconfigmain"));
			List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
			WebElement chatCode = CommonUtil.getElementByAttributeValue(leftTabElements,"tabname","chatcode");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(chatCode))
			{
				etest.log(Status.PASS,"Chat code icon was displayed on the left tab");
				CommonWait.waitTillDisplayed(chatCode);
				CommonUtil.clickWebElement(driver,chatCode);
				CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Signature Live Chat");
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"))) &&
					SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Signature Live Chat",etest))
				{
					etest.log(Status.PASS,"On clicking chat code on the LHS, it navigates to signature live chat code page");
					TestResults.put("SLC6",true);
				}
				else
				{
					etest.log(Status.FAIL,"On clicking chat code on the LHS, it doesnot navigates to signature live chat code page");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Chat code icon was not displayed on the left tab");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
				failcount++;
				TestResults.put("SLC6",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Exception",e);
			failcount++;
			TestResults.put("SLC6",false);
		}
		try
		{
			List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
			WebElement userCode = CommonUtil.getElementByAttributeValue(leftTabElements,"tabname","usercode");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(userCode))
			{
				etest.log(Status.PASS,"Operator code icon was displayed on the left tab");
				CommonWait.waitTillDisplayed(userCode);
				CommonUtil.clickWebElement(driver,userCode);
				CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Agent Specific Chat");
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"))) &&
					SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Agent Specific Chat",etest))
				{
					etest.log(Status.PASS,"On clicking Operator code on the LHS, it navigates to Agent specific chat code page");
					TestResults.put("SLC7",true);
				}
				else
				{
					etest.log(Status.FAIL,"On clicking Operator code on the LHS, it doesnot navigates to agent specific chat code page");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Operator code icon was not displayed on the left tab");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
				failcount++;
				TestResults.put("SLC7",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Exception",e);
			failcount++;
			TestResults.put("SLC7",false);
		}
		try
		{
			List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
			WebElement signatureTab = CommonUtil.getElementByAttributeValue(leftTabElements,"tabname","signature");
			CommonWait.waitTillDisplayed(signatureTab);
			CommonUtil.clickWebElement(driver,signatureTab);
			CommonWait.waitTillDisplayed(driver,By.id("emrightnav"));

			List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav"),By.className("talign_cn")).findElements(By.tagName("span"));
			WebElement sigLiveChatCode = CommonUtil.getElementByAttributeValue(rightTabElements,"signature","chat");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigLiveChatCode) &&
				SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(sigLiveChatCode,By.className("big-hdrtxt")),"Signature Live Chat Code",etest))
			{
				etest.log(Status.PASS,"Signature live chat code icon was displayed on the right tab");
				CommonWait.waitTillDisplayed(sigLiveChatCode);
				CommonUtil.clickWebElement(driver,sigLiveChatCode);
				CommonWait.waitTillDisplayed(driver,By.id("emmiddlenav"));
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"))) &&
					SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Signature Live Chat",etest))
				{
					etest.log(Status.PASS,"On clicking Signature live chat code from the signature live chat page, it navigates to signature live chat code page");
					TestResults.put("SLC8",true);
				}
				else
				{
					etest.log(Status.FAIL,"On clicking Signature live chat code from the signature live chat page, it doesnot navigates to signature live chat code page");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Signature live code icon was not displayed on the right tab");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
				failcount++;
				TestResults.put("SLC8",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Exception",e);
			TestResults.put("SLC8",false);
			failcount++;
		}
		try
		{
			List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
			WebElement signatureTab = CommonUtil.getElementByAttributeValue(leftTabElements,"tabname","signature");
			CommonWait.waitTillDisplayed(signatureTab);
			CommonUtil.clickWebElement(driver,signatureTab);
			CommonWait.waitTillDisplayed(driver,By.id("emrightnav"));

			List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav"),By.className("talign_cn")).findElements(By.tagName("span"));
			WebElement agentLiveChatCode = CommonUtil.getElementByAttributeValue(rightTabElements,"signature","user");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(agentLiveChatCode) &&
				SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(agentLiveChatCode,By.className("big-hdrtxt")),"Agent Specific Live Chat Code",etest))
			{
				etest.log(Status.PASS,"Agent specific live chat code icon was displayed on the right tab");
				CommonWait.waitTillDisplayed(agentLiveChatCode);
				CommonUtil.clickWebElement(driver,agentLiveChatCode);
				CommonWait.waitTillDisplayed(driver,By.id("emmiddlenav"));
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"))) &&
					SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Agent Specific Chat",etest))
				{
					etest.log(Status.PASS,"On clicking Agent specific live chat code from the signature live chat page, it navigates to Agent specific chat code page");
					TestResults.put("SLC9",true);
				}
				else
				{
					etest.log(Status.FAIL,"On clicking Agent specific live chat code from the signature live chat page, it doesnot navigates to Agent specific chat code page");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Agent Specific live code icon was not displayed on the right tab");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Operator window screenshot");
				failcount++;
				TestResults.put("SLC9",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatPage","Exception",e);
			TestResults.put("SLC9",false);
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkChatCode(WebDriver driver) throws Exception
	{
		int failcount = 0;
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Signature Live Chat");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"))) &&
				SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Signature Live Chat",etest))
			{
				etest.log(Status.PASS,"On clicking chat code from the signature live chat page, it navigates to signature live chat code page");
				TestResults.put("SLC10",true);
			}
			else
			{
				etest.log(Status.FAIL,"On clicking chat code from the signature live chat page, it doesnot navigates to signature live chat code page");
				TestResults.put("SLC10",false);
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;			
			TestResults.put("SLC10",false);
		}
		try
		{
			boolean subEleFound = true;
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
			WebElement chatCodeSubElements = leftTabElements.get(2);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(chatCodeSubElements))
			{
				etest.log(Status.PASS,"Sub elements were found in chat code tab in signature live chat");
				WebElement appearanceTab = CommonUtil.getElementByAttributeValue(chatCodeSubElements.findElements(By.tagName("span")),"subtab","apperance");
				WebElement behaviourTab = CommonUtil.getElementByAttributeValue(chatCodeSubElements.findElements(By.tagName("span")),"subtab","behaviourpreference");
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(appearanceTab) &&
					SignatureLiveChatCommonFunctions.checkContent(appearanceTab,"Appearance",etest))
				{
					etest.log(Status.PASS,"Appearance tab was found in the LHS of signature live chat code");
					CommonWait.waitTillDisplayed(appearanceTab);
					CommonUtil.clickWebElement(driver,appearanceTab);
					CommonWait.waitTillDisplayed(driver,By.id("emmiddlenav"));
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.id("CLOGO5"))))
					{
						etest.log(Status.PASS,"On clicking appearance tab in chat code in signature live chat, it navigates to its respective page");
					}
					else
					{
						etest.log(Status.FAIL,"On clicking appearance tab in chat code in signature live chat, it doesnot navigates to its respective page");
						subEleFound = false;
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Operator window screenshot");
					}
				}
				else
				{
					etest.log(Status.FAIL,"Appearance tab was not found in the LHS of signature live chat code");
					subEleFound = false;
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Operator window screenshot");
				}
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(behaviourTab) &&
					SignatureLiveChatCommonFunctions.checkContent(behaviourTab,"Behaviour",etest))
				{
					etest.log(Status.PASS,"Behaviour tab was found in the LHS of signature live chat code");
					CommonWait.waitTillDisplayed(behaviourTab);
					CommonUtil.clickWebElement(driver,behaviourTab);
					CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),behaviourheading);
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt"))) &&
						SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),behaviourheading,etest))
					{
						etest.log(Status.PASS,"On clicking behaviour tab in chat code in signature live chat, it navigates to its respective page");
					}
					else
					{
						etest.log(Status.FAIL,"On clicking behaviour tab in chat code in signature live chat, it doesnot navigates to its respective page");
						subEleFound = false;
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Operator window screenshot");
					}
				}
				else
				{
					etest.log(Status.FAIL,"Behaviour tab was not found in the LHS of signature live chat code");
					subEleFound = false;
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Operator window screenshot");
				}
			}
			else
			{
				etest.log(Status.FAIL,"Sub elements were not displayed in chat code in signature live chat");
				subEleFound = false;
				failcount++;
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Operator window screenshot");
			}

			if(subEleFound)
			{
				TestResults.put("SLC11",true);
			}
			else
			{
				TestResults.put("SLC11",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;		
			TestResults.put("SLC11",false);	
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC12",checkWidgetCode(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC12",false);		
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC13",checkThemeNavigation(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.INFO,"Details changed were updated");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
			TestResults.put("SLC13",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC14",checkShowPreview(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC14",false);	
		}
		try
		{
			TestResults.put("SLC15",checkShowPreviewHoverText(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC15",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC16",checkPreviewMaximizeIcon(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC16",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC17",checkPreview(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC17",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC18",checkExitPreview(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC18",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC19",checkThemeOnline(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.INFO,"Details changed were updated");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC19",false);
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC20",checkThemeOffline(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.INFO,"Details changed were updated");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC20",false);
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC21",checkCustomTheme(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC21",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC22",checkLinkUrl(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC22",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC23",checkImageUrl(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC23",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC24",checkHideOption(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC24",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC25",checkIcon(driver,"zmail","Zoho Mail"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC25",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC26",checkIcon(driver,"zdesk","Zoho Desk"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC26",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC27",checkIcon(driver,"zcrm","Zoho CRM"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC27",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC28",checkIcon(driver,"gmail","Gmail"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC28",false);
		}try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			TestResults.put("SLC29",checkIcon(driver,"ymail","Outlook"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC29",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"apperance");
			TestResults.put("SLC30",checkPreviewWindow(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC30",false);
		}
		try
		{
			etest.log(Status.INFO,"Initial condition toggling off all elements in appearance tab elements");
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"apperance");
			SignatureLiveChatCommonFunctions.toggleOFF(driver,"CLOGO5");
			SignatureLiveChatCommonFunctions.toggleOFF(driver,"SHOWABOUTCOMPANY5");
			SignatureLiveChatCommonFunctions.toggleOFF(driver,"SHOWCONTACT5");
			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickUpdate(driver);
			}
			new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
			new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
			CommonWait.waitTillDisplayed(driver,By.id("embedhomepage"));
			SignatureLiveChatCommonFunctions.sigLiveChat(driver);	
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"apperance");
			TestResults.put("SLC31",checkAppearanceTabElements(driver,"CLOGO5","Display your company logo","Company logo","logo"));
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
		 	failcount++;
		 	TestResults.put("SLC31",false);
		}
		try
		{
			TestResults.put("SLC32",checkAppearanceTabElements(driver,"SHOWABOUTCOMPANY5","Include about your company","Company details",COMPANY_DESC));
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
		 	failcount++;
		 	TestResults.put("SLC32",false);
		}
		try
		{
			TestResults.put("SLC33",checkAppearanceTabElements(driver,"SHOWCONTACT5","Include your contact details","Contact details",COMPANY_ADDR));
			try
			{
				CommonUtil.sleep(1000);
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancel(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
		 	failcount++;
		 	try
		 	{
		 		if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
		 	TestResults.put("SLC33",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"apperance");
			TestResults.put("SLC34",checkAppearanceTabBackgroundImage(driver));
			try
			{
				CommonUtil.sleep(1000);
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancel(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			failcount++;
			TestResults.put("SLC34",false);
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
			TestResults.put("SLC35",checkSignatureChatWebPage(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			TestResults.put("SLC35",false);
			failcount++;
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
			TestResults.put("SLC36",checkSignatureChatTakeMeToMyWebsite(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatCode","Exception",e);
			TestResults.put("SLC36",false);
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkOperatorCode(WebDriver driver) throws Exception
	{
		int failcount = 0;
		try
		{
			CommonUtil.refreshPage(driver);
			SignatureLiveChatCommonFunctions.sigLiveChat(driver);
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			try
			{
				SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
			}
			catch(Exception e)
			{
				System.out.println("page navigated without popup");
			}
			CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Agent Specific Chat");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"))) &&
				SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("big-hdrtxt")),"Agent Specific Chat",etest))
			{
				etest.log(Status.PASS,"On clicking Operator code on the LHS, it navigates to Agent specific chat code page");
				TestResults.put("SLC37",true);
			}
			else
			{
				etest.log(Status.FAIL,"On clicking Operator code on the LHS, it doesnot navigates to agent specific chat code page");
				TestResults.put("SLC37",false);
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC37",false);	
		}
		try
		{
			boolean subEleFound = true;
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			List<WebElement> leftTabElements = CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.tagName("div"));
			WebElement userCodeSubElements = leftTabElements.get(4);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(userCodeSubElements))
			{
				etest.log(Status.PASS,"Sub elements were found in Operator code tab in signature live chat");
				WebElement appearanceTab = CommonUtil.getElementByAttributeValue(userCodeSubElements.findElements(By.tagName("span")),"subtab","apperance");
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(appearanceTab) &&
					SignatureLiveChatCommonFunctions.checkContent(appearanceTab,"Appearance",etest))
				{
					etest.log(Status.PASS,"Appearance tab was found in the LHS of signature live chat code");
					CommonWait.waitTillDisplayed(appearanceTab);
					CommonUtil.clickWebElement(driver,appearanceTab);
					CommonWait.waitTillDisplayed(driver,By.id("emmiddlenav"));
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emmiddlenav"),By.id("CLOGO5"))))
					{
						etest.log(Status.PASS,"On clicking appearance tab in Operator code in signature live chat, it navigates to its respective page");
					}
					else
					{
						etest.log(Status.FAIL,"On clicking appearance tab in Operator code in signature live chat, it doesnot navigates to its respective page");
						subEleFound = false;
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Operator window screenshot");
					}
				}
				else
				{
					etest.log(Status.FAIL,"Appearance tab was not found in the LHS of signature live chat code");
					subEleFound = false;
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Operator window screenshot");
				}
			}
			else
			{
				etest.log(Status.FAIL,"Sub elements were not displayed in Operator code in signature live chat");
				subEleFound = false;
				failcount++;
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Operator window screenshot");
			}

			if(subEleFound)
			{
				TestResults.put("SLC38",true);
			}
			else
			{
				TestResults.put("SLC38",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;			
			TestResults.put("SLC38",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC39",checkWidgetCode(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC39",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC40",checkThemeNavigation(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.INFO,"Details changed were updated");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
			TestResults.put("SLC40",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC41",checkShowPreview(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC41",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC42",checkShowPreviewHoverText(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC42",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC43",checkPreviewMaximizeIcon(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC43",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC44",checkPreview(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC44",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC45",checkExitPreview(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC45",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC46",checkThemeOnline(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.INFO,"Details changed were updated");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC46",false);
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC47",checkThemeOffline(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.INFO,"Details changed were updated");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC47",false);
			try
			{
				if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC48",checkCustomTheme(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC48",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC49",checkLinkUrl(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC49",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC50",checkImageUrl(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC50",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC51",checkHideOption(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC51",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC52",checkIcon(driver,"zmail","Zoho Mail"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC52",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC53",checkIcon(driver,"zdesk","Zoho Desk"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC53",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC54",checkIcon(driver,"zcrm","Zoho CRM"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC54",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC55",checkIcon(driver,"gmail","Gmail"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC55",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			TestResults.put("SLC56",checkIcon(driver,"ymail","Outlook"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC56",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInOperatorCode(driver,"apperance");
			TestResults.put("SLC57",checkPreviewWindow(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
			failcount++;
			TestResults.put("SLC57",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInOperatorCode(driver,"apperance");
			TestResults.put("SLC58",checkAppearanceTabElements(driver,"CLOGO5","Display your company logo","Company logo","Logo"));
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
		 	failcount++;
		 	TestResults.put("SLC58",false);
		}
		try
		{
			TestResults.put("SLC59",checkAppearanceTabElements(driver,"SHOWABOUTCOMPANY5","Include about your company","Company details",COMPANY_DESC));
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
		 	failcount++;
		 	TestResults.put("SLC59",false);
		}
		try
		{
			TestResults.put("SLC60",checkAppearanceTabElements(driver,"SHOWCONTACT5","Include your contact details","Contact details",COMPANY_ADDR));
		}
		catch(Exception e)
		{
		 	TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
		 	failcount++;
		 	TestResults.put("SLC60",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInOperatorCode(driver,"apperance");
			TestResults.put("SLC61",checkAppearanceTabBackgroundImage(driver));
			try
			{
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancel(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TestResults.put("SLC61",false);
			failcount++;
		 	try
		 	{
		 		if(SignatureLiveChatCommonFunctions.checkForgotSomethingDiv(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickCancelInForgotSomethingDiv(driver);
					etest.log(Status.INFO,"Details changed were ignored");
				}
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkOperatorCode","Exception",e);
		}
		return returnResult(failcount);
	}

	public static boolean checkVisitorEnd(WebDriver driver) throws Exception
	{
		String sigCode = "";
		WebDriver visitor_driver = Functions.setUp();
		CommonUtil.refreshPage(driver);
		SignatureLiveChatCommonFunctions.sigLiveChat(driver);
		SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
		if(!CommonUtil.getElement(driver,By.id("customsticker")).getAttribute("class").contains("set_on"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("customsticker")));
			CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customsticker")),"class","set_on");
		}
		if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
		{
			SignatureLiveChatCommonFunctions.clickUpdate(driver);
		}
		SignatureLiveChatCommonFunctions.initVisitorEnd(visitor_driver);
		int failcount = 0;
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
			if(checkSignatureIconVisitorEnd(driver,visitor_driver,sigCode,true))
			{
				etest.log(Status.PASS,"Signature live chat icon was displayed in the visitor end");
				TestResults.put("SLC62",true);
			}
			else
			{
				etest.log(Status.FAIL,"Signature live chat icon was not displayed in the visitor end");
				TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureIconVisitorEnd","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			failcount++;			
			TestResults.put("SLC62",false);
		}
		try
		{
			TestResults.put("SLC63",checkSignatureChatWebPageVisitorEnd(driver,visitor_driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			TestResults.put("SLC63",false);	
			failcount++;
		}
		try
		{
			TestResults.put("SLC64",checkWebsiteVisitorEnd(driver,visitor_driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			TestResults.put("SLC64",false);
			failcount++;
		}
		try
		{
			TestResults.put("SLC65",checkSignatureChatWebPageDetails(driver,visitor_driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			TestResults.put("SLC65",false);
			failcount++;
		}
		try
		{
			TestResults.put("SLC66",checkChatWindowVisitorEnd(driver,visitor_driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			TestResults.put("SLC66",false);
			failcount++;
		}
		SignatureLiveChatCommonFunctions.initChat(driver,etest);

		WebDriver agentDriver = Functions.setUp();
		Functions.login(agentDriver,"signature_chat_2");

		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
			SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
			TestResults.put("SLC67",checkChatRouting(driver,agentDriver,visitor_driver,true));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			TestResults.put("SLC67",false);
			failcount++;
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"usercode");
			sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
			SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
			TestResults.put("SLC68",checkChatRouting(driver,agentDriver,visitor_driver,false));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkVisitorEnd","Exception",e);
			TestResults.put("SLC68",false);
			failcount++;
		}

		Functions.logout(agentDriver);

		return returnResult(failcount);
	}

	public static boolean checkSignatureLiveChatDisabled(WebDriver driver) throws Exception
	{
		WebDriver visitor_driver = Functions.setUp();
		int failcount = 0;
		try
		{
			new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
			new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
			SignatureLiveChatCommonFunctions.init(driver);
			WebElement liveChatElement = SignatureLiveChatCommonFunctions.getLiveChatElement(driver);
			CommonUtil.scrollToBottomOfPage(driver);
			if(liveChatElement.getText().contains("Enabled"))
			{
				etest.log(Status.INFO,"Live chat for emails was enabled");
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(liveChatElement,By.className("stus_tglbtn"),By.tagName("em")));
				CommonUtil.mouseHover(driver,liveChatElement);
				Thread.sleep(1000);
				etest.log(Status.INFO,"Disabling the Live chat for emails");
				CommonUtil.waitTillWebElementContainsAttributeValue(liveChatElement,"status","disable");
			}
			SignatureLiveChatCommonFunctions.sigLiveChat(driver);
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			if(checkPreviewMaximizeIcon(driver))
			{
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emrightsubdiv"),By.id("signaturemailimage"))))
				{
					etest.log(Status.PASS,"Live chat for emails was disabled -- Signature icon was found in the preview window from show preview -- chat code -- signature live chat");
					TestResults.put("SLC69",true);
				}
				else
				{
					etest.log(Status.FAIL,"Live chat for emails was disabled -- Signature icon was not found in the preview window from show preview -- chat code -- signature live chat");
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatDisabled","operator window screenshot");
					TestResults.put("SLC69",false);
				}
			}
			else
			{
				failcount++;
				TestResults.put("SLC69",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatDisabled","Exception",e);
			failcount++;
			TestResults.put("SLC69",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInChatCode(driver,"apperance");
			if(checkPreviewWindow(driver))
			{
				CommonWait.waitTillDisplayed(driver,By.id("previewframe"));
				driver.switchTo().frame("previewframe");
				CommonWait.waitTillDisplayed(driver,By.tagName("body"));
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.className("siqsig_leftnav"))))
				{
					etest.log(Status.PASS,"Preview window screen was found in Appearance tab in chat code");
					TestResults.put("SLC70",true);
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Preview window screen shows error page in appearance tab in chat code");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatDisabled","Operator window screenshot");
					TestResults.put("SLC70",false);
				}
				driver.switchTo().defaultContent();
			}
			else
			{
				failcount++;
				TestResults.put("SLC70",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureLiveChatDisabled","Exception",e);
			failcount++;
			TestResults.put("SLC70",false);
		}
		try
		{
			SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
			String sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
			SignatureLiveChatCommonFunctions.initVisitorEnd(visitor_driver);
			SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
			if(checkSignatureIconVisitorEnd(driver,visitor_driver,sigCode,false))
			{
				etest.log(Status.FAIL,"Signature live chat icon was disabled but signature icon was found on visitor end");
				TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureLiveChatDisabled","operator window screenshot");
				TestResults.put("SLC71",false);
				failcount++;
			}
			else
			{
				TestResults.put("SLC71",true);
				etest.log(Status.PASS,"Signature live chat icon was disabled and signature icon was hidden on visitor end");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureLiveChatDisabled","Exception",e);
			failcount++;			
			TestResults.put("SLC71",false);
		}
		return returnResult(failcount);
	}

	public static boolean checkWidgetCode(WebDriver driver) throws Exception
	{
		int failcount = 0;
		boolean sigCodeFound = true;
		WebElement sigCodeElement = CommonUtil.getElement(driver,By.id("signature_code"));
		CommonWait.waitTillDisplayed(sigCodeElement);
		CommonWait.waitTillDisplayed(driver,By.id("emrightnav"));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emrightnav"))) &&
			SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("emrightnav"),By.className("big-hdrtxt")),"Signature Live Chat Code",etest))
		{
			etest.log(Status.PASS,"right nav tab was displayed");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigCodeElement) && 
				SignatureLiveChatCommonFunctions.checkContent(sigCodeElement,widget_code,etest))
			{
				etest.log(Status.PASS,"Signature live chat code was displayed in operator code and the widget code was verified");
			}
			else
			{
				etest.log(Status.FAIL,"Signature live chat code was not displayed or widget code was wrong");
				sigCodeFound = false;
				failcount++;
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkWidgetCode","Operator window screenshot");
			}
		}
		else
		{
			etest.log(Status.FAIL,"Right nav tab was not displayed in operator code");
			sigCodeFound = false;
			failcount++;
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkWidgetCode","Operator window screenshot");
		}
		return returnResult(failcount);
	}

	public static boolean checkThemeNavigation(WebDriver driver) throws Exception
	{
		int failcount = 0;
		String themeHeader = "";
		List<WebElement> mainContents = CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("togl_main")).findElements(By.className("emconf_tgl"));
		WebElement sigThemeElement = CommonUtil.getElementByAttributeValue(mainContents,"prop_id","customsticker").findElement(By.className("valin_mdl"));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigThemeElement) &&
			SignatureLiveChatCommonFunctions.checkContent(sigThemeElement,"Choose your Signature Theme",etest))
		{
			etest.log(Status.PASS,"Signature theme element was displayed");
		}
		else
		{
			etest.log(Status.FAIL,"signature theme element was not displayed");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeNavigation","Operator window screenshot");
			failcount++;
		}
		if(!SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("customsticker")),etest))
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeNavigation","Operator window screenshot");
			failcount++;
		}
		if(!CommonUtil.getElement(driver,By.id("customsticker")).getAttribute("class").contains("set_on"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("customsticker")));
			CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customsticker")),"class","set_on");
		}
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("stikerlistmain"))))
		{
			etest.log(Status.PASS,"Themes were displayed in the signature live chat code");
			CommonWait.waitTillDisplayed(driver,By.id("embedthemelist"));
			List<WebElement> themeList = CommonUtil.getElement(driver,By.id("embedthemelist")).findElements(By.tagName("div"));
			themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
			CommonUtil.mouseHover(driver,themeList.get(0));
			Thread.sleep(1000);
			WebElement nextNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","flase");
			WebElement prevNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","true");
			etest.log(Status.INFO,"<==> Navigating towards next in theme <==>");
			for(int i = 0; i < themeList.size(); i++)
			{
				CommonWait.waitTillDisplayed(nextNav);
				CommonUtil.clickWebElement(driver,nextNav);
				CommonUtil.waitTillWebElementContainsAttributeValue(themeList.get(i),"class","prevsel");
				if(themeList.get(i).getAttribute("class").contains("prevsel") &&
					themeList.get((i+1)%themeList.size()).getAttribute("class").contains("sel") &&
					themeList.get((i+2)%themeList.size()).getAttribute("class").contains("nextsel"))
				{
					etest.log(Status.PASS,"Theme navigated from '"+themeHeader+"' in signature live chat");
				}
				else
				{
					etest.log(Status.FAIL,"Theme doesnot navigate from '"+themeHeader+"' in signature live chat");
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeNavigation","Operator window screenshot");
					return false;
				}
				themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
				CommonUtil.mouseHover(driver,themeList.get((i+1)%9));
			}

			etest.log(Status.INFO,"<==> Navigating previous theme <==>");
			for(int i = themeList.size()-1; i >= 0 ; i--)
			{
				CommonUtil.clickWebElement(driver,prevNav);
				CommonUtil.waitTillWebElementContainsAttributeValue(themeList.get((i+1)%themeList.size()),"class","nextsel");
				if(themeList.get((i-1+themeList.size())%themeList.size()).getAttribute("class").contains("prevsel") &&
					themeList.get(i).getAttribute("class").contains("sel") &&
					themeList.get((i+1)%themeList.size()).getAttribute("class").contains("nextsel"))
				{
					etest.log(Status.PASS,"Theme navigated from '"+themeHeader+"' in signature live chat");
				}
				else
				{
					etest.log(Status.FAIL,"Theme doesnot navigate from '"+themeHeader+"' in signature live chat");
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeNavigation","Operator window screenshot");
					return false;
				}
				themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
			}

		}
		else
		{
			etest.log(Status.FAIL,"Themes were not displayed in the signature live chat code");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeNavigation","Operator window screenshot");
			failcount++;
		}

		return returnResult(failcount);
	}

	public static boolean navigateToEbonyTheme(WebDriver driver) throws Exception
	{
		int failcount = 0;
		String themeHeader = "";
		List<WebElement> mainContents = CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("togl_main")).findElements(By.className("emconf_tgl"));
		WebElement sigThemeElement = CommonUtil.getElementByAttributeValue(mainContents,"prop_id","customsticker").findElement(By.className("valin_mdl"));
		if(!SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("customsticker")),etest))
		{
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeNavigation","Operator window screenshot");
			failcount++;
		}
		if(!CommonUtil.getElement(driver,By.id("customsticker")).getAttribute("class").contains("set_on"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("customsticker")));
			CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customsticker")),"class","set_on");
		}
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("stikerlistmain"))))
		{
			CommonWait.waitTillDisplayed(driver,By.id("embedthemelist"));
			List<WebElement> themeList = CommonUtil.getElement(driver,By.id("embedthemelist")).findElements(By.tagName("div"));
			themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
			CommonWait.waitTillDisplayed(driver,By.id("stikerlistmain"));
			WebElement nextNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","flase");
			int i = Integer.parseInt(CommonUtil.getElementByAttributeValue(themeList,"class","prevsel").getAttribute("themeid"));
			CommonUtil.mouseHover(driver,themeList.get(i%themeList.size()));
			for(; i < themeList.size(); i++)
			{
				CommonWait.waitTillDisplayed(nextNav);
				CommonUtil.clickWebElement(driver,nextNav);
				CommonUtil.mouseHover(driver,themeList.get((i+1)%themeList.size()));
			}
			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickUpdate(driver);
				etest.log(Status.PASS,"Navigated to EBONY theme");
			}
		}
		return returnResult(failcount);
	}

	public static boolean checkShowPreview(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emrightnav")),5);
		List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav")).findElements(By.tagName("span"));
		Thread.sleep(1000);
		CommonUtil.waitTillWebElementDisplayed(driver,rightTabElements.get(rightTabElements.size()-1));
		WebElement showPreviewElement = CommonUtil.getElementByAttributeValue(rightTabElements,"documentclick","toggelSignaturePreview");
		// WebElement showPreviewElement = SignatureLiveChatCommonFunctions.getShowPreviewElement(driver);
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(showPreviewElement) &&
			SignatureLiveChatCommonFunctions.checkContent(showPreviewElement,"Show Preview",etest))
		{
			CommonSikuli.findInWholePage(driver,"showpreviewelement.png","UI424",etest);
			etest.log(Status.PASS,"Show preview was displayed in signature live chat");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Show preview was not displayed in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkShowPreview","Operator window screenshot");
			return false;
		}
	}

	public static boolean checkShowPreviewHoverText(WebDriver driver) throws Exception
	{
		int failcount = 0;
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emrightnav")),5);
		List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav")).findElements(By.tagName("span"));
		Thread.sleep(1000);
		CommonUtil.waitTillWebElementDisplayed(driver,rightTabElements.get(rightTabElements.size()-1));
		WebElement showPreviewElement = CommonUtil.getElementByAttributeValue(rightTabElements,"documentclick","toggelSignaturePreview");
		// WebElement showPreviewElement = SignatureLiveChatCommonFunctions.getShowPreviewElement(driver);
		WebElement showPreviewHover = CommonUtil.getElement(driver,By.id("emrightsubdiv"),By.className("sig_prvmask"));
		CommonUtil.clickWebElement(driver,showPreviewElement);
		CommonWait.waitTillDisplayed(driver,By.id("emrightsubdiv"));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emrightsubdiv"))))
		{
			etest.log(Status.PASS,"Preview element was displayed in signature live chat");
			CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,By.id("emrightsubdiv")));
			Thread.sleep(1000);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(showPreviewHover) && 
				SignatureLiveChatCommonFunctions.checkContent(showPreviewHover,"Preview",etest))
			{
				etest.log(Status.PASS,"Preview element in signature live chat was hovered and the hover text (Preview) was verified");
			}
			else
			{
				etest.log(Status.FAIL,"Preview element was not hovered in signature live chat");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkShowPreviewHoverText","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Preview element was not displayed in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkShowPreviewHoverText","Operator window screenshot");
			failcount++;
		}

		return returnResult(failcount);
	}

	public static boolean checkPreviewMaximizeIcon(WebDriver driver) throws Exception
	{
		int failcount = 0;
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("emrightnav")),5);
		List<WebElement> rightTabElements = CommonUtil.getElement(driver,By.id("emrightnav")).findElements(By.tagName("span"));
		Thread.sleep(1000);
		CommonUtil.waitTillWebElementDisplayed(driver,rightTabElements.get(rightTabElements.size()-1));
		WebElement showPreviewElement = CommonUtil.getElementByAttributeValue(rightTabElements,"documentclick","toggelSignaturePreview");
		// WebElement showPreviewElement = SignatureLiveChatCommonFunctions.getShowPreviewElement(driver);
		CommonUtil.clickWebElement(driver,showPreviewElement);
		CommonWait.waitTillDisplayed(driver,By.id("emrightsubdiv"));
		WebElement showPreviewHover = CommonUtil.getElement(driver,By.id("emrightsubdiv"),By.className("sig_prvmask"));
		WebElement maxIcon = CommonUtil.getElement(driver,By.id("emrightsubdiv"),By.className("sqico-maximize"));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("emrightsubdiv"))))
		{
			etest.log(Status.PASS,"Preview element was displayed in signature live chat");
			CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,By.id("emrightsubdiv")));
			Thread.sleep(1000);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(showPreviewHover) && 
				SignatureLiveChatCommonFunctions.checkContent(showPreviewHover,"Preview",etest))
			{
				etest.log(Status.PASS,"Preview element in signature live chat was hovered");
				SignatureLiveChatCommonFunctions.clickMaxIcon(driver,maxIcon,etest);
				CommonWait.waitTillDisplayed(driver,By.id("emrightsubdiv"));
				if(!CommonUtil.getElement(driver,By.id("emrightsubdiv")).getAttribute("class").contains("sig_smlpre"))
				{
					etest.log(Status.PASS,"Preview screen was maximized on clicking maximize icon");
				}
				else
				{
					etest.log(Status.FAIL,"Preview screen was not maximized on clicking maximize icon");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreviewMaximizeIcon","Operator window screenshot");
					failcount++;
				}				
			}
			else
			{
				etest.log(Status.FAIL,"Preview element in signature live chat was not hovered");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreviewMaximizeIcon","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Preview element was not displayed in the signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreviewMaximizeIcon","Operator window screenshot");
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkPreview(WebDriver driver) throws Exception
	{
		int failcount = 0;
		checkShowPreviewHoverText(driver);
		CommonWait.waitTillDisplayed(driver,By.id("emrightsubdiv"));
		WebElement maxIcon = CommonUtil.getElement(driver,By.id("emrightsubdiv"),By.className("sqico-maximize"));
		SignatureLiveChatCommonFunctions.clickMaxIcon(driver,maxIcon,etest);
		CommonWait.waitTillDisplayed(driver,By.id("emrightsubdiv"));
		if(!CommonUtil.getElement(driver,By.id("emrightsubdiv")).getAttribute("class").contains("sig_smlpre"))
		{
			etest.log(Status.PASS,"Preview screen was maximized on clicking maximize icon");
			if(CommonUtil.getElement(driver,By.id("widgetstatus")).getText().contains("Online"))
			{
				if(SignatureLiveChatCommonFunctions.checkSignatureIconPreviewOnline(driver,etest))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("widgetstatus_div")));
					CommonWait.waitTillDisplayed(driver,By.id("widgetstatus0"));
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("widgetstatus0"))))
					{
						etest.log(Status.PASS,"Dropdown list box displayed on clicking ONLINE in preview screen");
						CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("widgetstatus0")).findElements(By.tagName("li")),"val","offline"));
						if(!SignatureLiveChatCommonFunctions.checkSignatureIconPreviewOffline(driver,etest))
						{
							failcount++;
						}
					}
					else
					{
						etest.log(Status.FAIL,"Dropdown list box was not displayed on clicking ONLINE in preview screen");
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreview","Operator window screenshot");
						failcount++;
					}
				}
				else
				{
					failcount++;
				}
			}
			else if(CommonUtil.getElement(driver,By.id("widgetstatus")).getText().contains("Offline"))
			{
				if(SignatureLiveChatCommonFunctions.checkSignatureIconPreviewOffline(driver,etest))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("widgetstatus_div")));
					CommonWait.waitTillDisplayed(driver,By.id("widgetstatus0"));
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("widgetstatus0"))))
					{
						etest.log(Status.PASS,"Dropdown list box displayed on clicking OFFLINE in preview screen");
						CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("widgetstatus0")).findElements(By.tagName("li")),"val","online"));
						if(!SignatureLiveChatCommonFunctions.checkSignatureIconPreviewOnline(driver,etest))
						{
							failcount++;
						}
					}
					else
					{
						etest.log(Status.FAIL,"Dropdown list box was not displayed on clicking OFFLINE in preview screen");
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreview","Operator window screenshot");
						failcount++;
					}
				}
				else
				{
					failcount++;
				}
			}
		}
		else
		{
			etest.log(Status.FAIL,"Preview screen was not maximized on clicking maximize icon");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreview","Operator window screenshot");
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkExitPreview(WebDriver driver) throws Exception
	{
		int failcount = 0;
		if(checkPreviewMaximizeIcon(driver))
		{
			WebElement exitPreviewElement =  CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("emrightsubdiv")).findElements(By.tagName("em")),"innerText","Exit Preview");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(exitPreviewElement))
			{
				etest.log(Status.PASS,"Exit preview element was displayed in preview screen");
				CommonUtil.clickWebElement(driver,exitPreviewElement);
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("emrightsubdiv")),"class","sig_smlpre");
				if(CommonUtil.getElement(driver,By.id("emrightsubdiv")).getAttribute("class").contains("sig_smlpre"))
				{
					etest.log(Status.PASS,"Exit preview element was clicked in the preview screen");
				}
				else
				{
					etest.log(Status.FAIL,"Exit preview element in the preview screen gives a click error");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkExitPreview","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Exit preview element was not displayed in the preview screen");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkExitPreview","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkThemeOnline(WebDriver driver) throws Exception
	{
		int failcount = 0;
		String themeHeader = "",themeid = "";
		List<WebElement> mainContents = CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("togl_main")).findElements(By.className("emconf_tgl"));
		CommonUtil.waitTillWebElementDisplayed(driver,mainContents.get(mainContents.size()-1),5);
		WebElement sigThemeElement = CommonUtil.getElementByAttributeValue(mainContents,"prop_id","customsticker").findElement(By.className("valin_mdl"));
		if(checkPreviewMaximizeIcon(driver))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("widgetstatus_div")));
			CommonWait.waitTillDisplayed(driver,By.id("widgetstatus0"));
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("widgetstatus0")).findElements(By.tagName("li")),"val","online"));
			CommonWait.waitTillDisplayed(sigThemeElement);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigThemeElement) &&
				SignatureLiveChatCommonFunctions.checkContent(sigThemeElement,"Choose your Signature Theme",etest))
			{
				etest.log(Status.PASS,"Signature theme element was displayed");
			}
			else
			{
				etest.log(Status.FAIL,"signature theme element was not displayed");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOnline","Operator window screenshot");
				failcount++;
			}
			if(!SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("customsticker")),etest))
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOnline","Operator window screenshot");
				failcount++;
			}
			if(!CommonUtil.getElement(driver,By.id("customsticker")).getAttribute("class").contains("set_on"))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("customsticker")));
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customsticker")),"class","set_on");
			}
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("stikerlistmain"))))
			{
				etest.log(Status.PASS,"Themes were displayed in the signature live chat code");
				CommonWait.waitTillDisplayed(driver,By.id("embedthemelist"));
				List<WebElement> themeList = CommonUtil.getElement(driver,By.id("embedthemelist")).findElements(By.tagName("div"));
				themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
				CommonUtil.mouseHover(driver,themeList.get(0));
				Thread.sleep(1000);
				WebElement nextNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","flase");
				WebElement prevNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","true");
				for(int i = 0; i < themeList.size(); i++)
				{
					CommonUtil.clickWebElement(driver,nextNav);
					CommonUtil.waitTillWebElementContainsAttributeValue(themeList.get(i),"class","prevsel");
					if(themeList.get(i).getAttribute("class").contains("prevsel") &&
						themeList.get((i+1)%themeList.size()).getAttribute("class").contains("sel") &&
						themeList.get((i+2)%themeList.size()).getAttribute("class").contains("nextsel"))
					{
						etest.log(Status.PASS,"Theme navigated from '"+themeHeader+"' in signature live chat");
						if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("signaturemailimage"))))
						{
							etest.log(Status.PASS,"Signature live chat icon was displayed in preview screen");
							themeid = themeList.get((i+1)%themeList.size()).getAttribute("themeid");
							if(CommonUtil.getElement(driver,By.id("signaturemailimage")).getAttribute("src").contains(themeid+".1.png"))
							{
								etest.log(Status.PASS,"Online signature live chat icon for ("+themeHeader+") was displayed in preview screen");
							}
							else
							{
								etest.log(Status.FAIL,"Online signature live chat icon for ("+themeHeader+") was not displayed in preview screen");
								TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOnline","Operator window screenshot");
								failcount++;
							}
						}
						else
						{
							etest.log(Status.FAIL,"Signature icon was not displayed in preview screen");
							TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOnline","Operator window screenshot");
							failcount++;
						}
					}
					else
					{
						etest.log(Status.FAIL,"Theme doesnot navigate from '"+themeHeader+"' in signature live chat");
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOnline","Operator window screenshot");
						return false;
					}
					themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
					CommonUtil.mouseHover(driver,themeList.get((i+1)%9));
					Thread.sleep(1000);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Themes were not displayed in the signature live chat code");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOnline","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkThemeOffline(WebDriver driver) throws Exception
	{
		int failcount = 0;
		String themeHeader = "",themeid = "";
		List<WebElement> mainContents = CommonUtil.getElement(driver,By.id("emmiddlenav"),By.className("togl_main")).findElements(By.className("emconf_tgl"));
		WebElement sigThemeElement = CommonUtil.getElementByAttributeValue(mainContents,"prop_id","customsticker").findElement(By.className("valin_mdl"));
		if(checkPreviewMaximizeIcon(driver))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("widgetstatus_div")));
			CommonWait.waitTillDisplayed(driver,By.id("widgetstatus0"));
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("widgetstatus0")).findElements(By.tagName("li")),"val","offline"));
			CommonWait.waitTillDisplayed(sigThemeElement);
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigThemeElement) &&
				SignatureLiveChatCommonFunctions.checkContent(sigThemeElement,"Choose your Signature Theme",etest))
			{
				etest.log(Status.PASS,"Signature theme element was displayed");
			}
			else
			{
				etest.log(Status.FAIL,"signature theme element was not displayed");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOffline","Operator window screenshot");
				failcount++;
			}
			if(!SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("customsticker")),etest))
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOffline","Operator window screenshot");
				failcount++;
			}
			if(!CommonUtil.getElement(driver,By.id("customsticker")).getAttribute("class").contains("set_on"))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("customsticker")));
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customsticker")),"class","set_on");
			}
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("stikerlistmain"))))
			{
				etest.log(Status.PASS,"Themes were displayed in the signature live chat code");
				CommonWait.waitTillDisplayed(driver,By.id("embedthemelist"));
				List<WebElement> themeList = CommonUtil.getElement(driver,By.id("embedthemelist")).findElements(By.tagName("div"));
				themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
				CommonUtil.mouseHover(driver,themeList.get(0));
				Thread.sleep(1000);
				WebElement nextNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","flase");
				WebElement prevNav = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("stikerlistmain"),By.className("navarrow")).findElements(By.tagName("em")),"isleft","true");
				for(int i = 0; i < themeList.size(); i++)
				{
					CommonUtil.clickWebElement(driver,nextNav);
					CommonUtil.waitTillWebElementContainsAttributeValue(themeList.get(i),"class","prevsel");
					if(themeList.get(i).getAttribute("class").contains("prevsel") &&
						themeList.get((i+1)%themeList.size()).getAttribute("class").contains("sel") &&
						themeList.get((i+2)%themeList.size()).getAttribute("class").contains("nextsel"))
					{
						etest.log(Status.PASS,"Theme navigated from '"+themeHeader+"' in signature live chat");
						if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("signaturemailimage"))))
						{
							etest.log(Status.PASS,"Signature live chat icon was displayed in preview screen");
							themeid = themeList.get((i+1)%themeList.size()).getAttribute("themeid");
							if(CommonUtil.getElement(driver,By.id("signaturemailimage")).getAttribute("src").contains(themeid+".0.png"))
							{
								etest.log(Status.PASS,"Offline signature live chat icon for ("+themeHeader+") was displayed in preview screen");
							}
							else
							{
								etest.log(Status.FAIL,"Offline signature live chat icon for ("+themeHeader+") was not displayed in preview screen");
								TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOffline","Operator window screenshot");
								failcount++;
							}
						}
						else
						{
							etest.log(Status.FAIL,"Signature icon was not displayed in preview screen");
							TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOffline","Operator window screenshot");
							failcount++;
						}
					}
					else
					{
						etest.log(Status.FAIL,"Theme doesnot navigate from '"+themeHeader+"' in signature live chat");
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOffline","Operator window screenshot");
						return false;
					}
					themeHeader = CommonUtil.getElement(driver,By.id("themeid_header")).getText();
					CommonUtil.mouseHover(driver,themeList.get((i+1)%9));
					Thread.sleep(1000);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Themes were not displayed in the signature live chat code");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkThemeOffline","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkLinkUrl(WebDriver driver)throws Exception
	{
		int failcount = 0;

		if(SignatureLiveChatCommonFunctions.checkClickHere(driver,etest))
		{
			WebElement signatureLink = CommonUtil.getElement(driver,By.id("signature_link"));
			sigLinkCode = signatureLink.getText();
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(signatureLink))
			{
				etest.log(Status.PASS,"Link url was displayed in signature live chat");
				if(SignatureLiveChatCommonFunctions.checkContent(signatureLink,widget_code,etest))
				{
					etest.log(Status.PASS,"Widget code present in the 'link url' was verified");
				}
				else
				{
					etest.log(Status.FAIL,"Widget code present in the 'link url' was incorrect");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLinkUrl","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"'Link url' was not displayed in signature live chat");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkLinkUrl","Operator window screenshot");
				failcount++;

			}
		}
		else
		{
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkImageUrl(WebDriver driver)throws Exception
	{
		int failcount = 0;

		if(SignatureLiveChatCommonFunctions.checkClickHere(driver,etest))
		{
			WebElement signatureImageLink = CommonUtil.getElement(driver,By.id("signature_userurl"));
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(signatureImageLink))
			{
				etest.log(Status.PASS,"Image url was displayed in signature live chat");
				if(SignatureLiveChatCommonFunctions.checkContent(signatureImageLink,widget_code,etest))
				{
					etest.log(Status.PASS,"Widget code present in the 'Image url' was verified");
				}
				else
				{
					etest.log(Status.FAIL,"Widget code present in the 'Image url' was incorrect");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkImageUrl","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"'Image url' was not displayed in signature live chat");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkImageUrl","Operator window screenshot");
				failcount++;

			}
		}
		else
		{
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkHideOption(WebDriver driver)throws Exception
	{
		int failcount = 0;

		if(SignatureLiveChatCommonFunctions.checkClickHere(driver,etest))
		{
			WebElement hideLink = CommonUtil.getElement(driver,By.id("signature_url"),By.className("show_tgl"));
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(hideLink))
			{
				etest.log(Status.PASS,"'hide link text' was displayed in the signature live chat");
				CommonUtil.clickWebElement(driver,hideLink);
				CommonWait.waitTillDisplayed(driver,By.id("signature_htmlcode"));
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("signature_htmlcode"))))
				{
					etest.log(Status.PASS,"'hide link text' in signature live chat was clicked and it works properly");
				}
				else
				{
					etest.log(Status.FAIL,"'hide link text' in signature live chat gives a click error");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkHideOption","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"'hide link text' was not displayed in the signature live chat");
				failcount++;
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkHideOption","Operator window screenshot");
			}
		}
		else
		{
			failcount++;
		}

		return returnResult(failcount);
	}

	public static boolean checkIcon(WebDriver driver,String appname,String imageName)throws Exception
	{
		int failcount = 0;
		String windowHandle = driver.getWindowHandle();
		List<WebElement> icons = CommonUtil.getElement(driver,By.id("trackconfigmin")).findElements(By.tagName("em"));
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElementByAttributeValue(icons,"appname",appname)))
		{
			etest.log(Status.PASS,imageName+" icon was found in the signature live chat");
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(icons,"appname",appname));
			CommonUtil.switchToTab(driver,1);
			CommonWait.waitTillDisplayed(driver,By.id("block-system-main"));
			if(driver.getCurrentUrl().contains("salesiq/help/signature-chat.html"))
			{
				etest.log(Status.PASS,"On clicking '"+imageName+"', help document for signature live chat opened");
			}
			else
			{
				etest.log(Status.FAIL,"On clicking '"+imageName+"', help document for signature live chat didnot opened");
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkIcon","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,imageName+" was not found in the signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkIcon","Operator window screenshot");
			failcount++;
		}
		driver.close();
		driver.switchTo().window(windowHandle);
		Thread.sleep(1000);
		return returnResult(failcount);
	}

	public static boolean checkPreviewWindow(WebDriver driver)throws Exception
	{
		WebElement previewWindowElement = CommonUtil.getElement(driver,By.id("window_prv"));

		if(SignatureLiveChatCommonFunctions.isElementDisplayed(previewWindowElement))
		{
			etest.log(Status.PASS,"Preview window was found in appearance tab in the signature live chat");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Preview window was not displayed in appearance tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkPreviewWindow","Operator window screenshot");
			return false;
		}
	}

	public static boolean checkAppearanceTabElements(WebDriver driver,String id,String desc,String icon,String checkText)throws Exception
	{
		int failcount = 0;
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement customizeELement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id",id);
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(customizeELement) &&
			SignatureLiveChatCommonFunctions.checkContent(customizeELement,desc,etest))
		{
			etest.log(Status.PASS,desc+" element was displayed in appearance tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id(id)),etest))
			{
				if(CommonUtil.getElement(driver,By.id(id)).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(id)));
					CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id(id)),"class","set_on");
				}
				CommonWait.waitTillDisplayed(driver,By.id("previewframe"));
				driver.switchTo().frame("previewframe");
				CommonWait.waitTillDisplayed(driver,By.className("siqsig_leftnav"));
				List<WebElement> previewWindowLeftNavElements = CommonUtil.getElement(driver,By.className("siqsig_leftnav")).findElements(By.xpath(".//*"));
				WebElement previewWindowIcon = CommonUtil.getElementByAttributeValue(previewWindowLeftNavElements,"data-type",id);
				if(SignatureLiveChatCommonFunctions.isElementDisplayed(previewWindowIcon))
				{
					etest.log(Status.PASS,icon+" icon (toggled on) was verified in the preview window in appearance tab -- signature live chat");
					if(!id.contains("CLOGO5"))
					{
						if(SignatureLiveChatCommonFunctions.checkContent(previewWindowIcon,checkText,etest))
						{
							etest.log(Status.PASS,icon+" details was verified to be correct in signature live chat ");
						}
						else
						{
							etest.log(Status.FAIL,icon+" details was verified to be incorrect in signature live chat");
							TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabElements","Operator window screenshot");
							failcount++;
						}
					}
				}
				else
				{
					etest.log(Status.FAIL,icon+" icon was not found in the preview window in appearance tab -- signature live chat");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabElements","Operator window screenshot");
					failcount++;
				}
				driver.switchTo().defaultContent();
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(id)));
				driver.switchTo().frame("previewframe");
				CommonWait.waitTillDisplayed(driver,By.className("siqsig_leftnav"));
				List<WebElement> previewWindowLeftNavElements2 = CommonUtil.getElement(driver,By.className("siqsig_leftnav")).findElements(By.xpath(".//*"));
				WebElement previewWindowIcon2 = CommonUtil.getElementByAttributeValue(previewWindowLeftNavElements2,"data-type",id);
				if(!SignatureLiveChatCommonFunctions.isElementDisplayed(previewWindowIcon2))
				{
					etest.log(Status.PASS,icon+" icon (toggled off) was verified in the preview window in appearance tab -- signature live chat");
				}
				else
				{
					etest.log(Status.FAIL,icon+" icon was found inspite of removing the logo in the preview window in appearance tab -- signature live chat");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabElements","Operator window screenshot");
					failcount++;
				}
				driver.switchTo().defaultContent();
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabElements","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,desc+" element was not displayed in appearance tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabElements","Operator window screenshot");
			failcount++;

		}
		return returnResult(failcount);
	}
	
	public static boolean checkAppearanceTabBackgroundImage(WebDriver driver)throws Exception
	{
		String imageId = "";
		int failcount = 0;
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement customizeELement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","GALLERY5");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(customizeELement) &&
			SignatureLiveChatCommonFunctions.checkContent(customizeELement,"Customize the background of your landing page",etest))
		{
			etest.log(Status.PASS,"Customize the background of your landing page element was displayed in appearance tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("GALLERY5")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("GALLERY5")).getAttribute("class").contains("set_on"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("GALLERY5")));
				}
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customgaller")),"style","none");
				if(CommonUtil.getElement(driver,By.id("GALLERY5")).getAttribute("class").contains("set_off"))
				{
					etest.log(Status.PASS,"Background image customization in signature live chat was toggled OFF");
					if(!SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("customgaller"))))
					{
						etest.log(Status.PASS,"Customize background image setting in signature live chat was toggled OFF and the Image gallery was hidden");						
					}
					else
					{
						etest.log(Status.FAIL,"Customize background image settings in signature live chat was toggled OFF but Image gallery was not hidden");
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
					}
				}
				else
				{
					etest.log(Status.FAIL,"Background image customization in signature live chat was not toggled OFF");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
					failcount++;
				}
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("GALLERY5")));
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id("customgaller")),"style","block");
				if(CommonUtil.getElement(driver,By.id("GALLERY5")).getAttribute("class").contains("set_on"))
				{
					etest.log(Status.PASS,"Background image customization in signature live chat was toggled ON");
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(driver,By.id("customgaller"))) &&
						SignatureLiveChatCommonFunctions.checkContent(CommonUtil.getElement(driver,By.id("customgaller")),"Image Gallery",etest))
					{
						etest.log(Status.PASS,"Customize background image setting in signature live chat was toggled ON and the Image gallery was displayed");
						List<WebElement> galleryImages = CommonUtil.getElement(driver,By.id("customgaller"),By.className("glry_list")).findElements(By.className("glry_em"));
						for(int i = 0; i < 4; i++)
						{
							CommonUtil.clickWebElement(driver,galleryImages.get(i));
							CommonUtil.waitTillWebElementContainsAttributeValue(galleryImages.get(i),"class","sel");
							imageId = galleryImages.get(i).getAttribute("imgid");
							CommonWait.waitTillDisplayed(driver,By.id("previewframe"));
							driver.switchTo().frame("previewframe");
							CommonWait.waitTillDisplayed(driver,By.className("siqsig_leftnav"));
							if(CommonUtil.getElement(driver,By.tagName("body")).getAttribute("signature_bg").contentEquals(imageId))
							{
								etest.log(Status.PASS,"Background image was changed and it was effected in the preview window in signature live chat ");
							}
							else
							{
								etest.log(Status.FAIL,"Background image was changed but it was not effected in the preview window in signature live chat");
								TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
								failcount++;
							}
							driver.switchTo().defaultContent();
						}
					}
					else
					{
						etest.log(Status.FAIL,"Customize background image settings in signature live chat was toggled ON but Image gallery was not displayed");
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
					}
				}
				else
				{
					etest.log(Status.FAIL,"Backround image settings in signature live chat window customization was toggled but gives a click error");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Customize the background of your landing page element was not displayed in appearance tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkAppearanceTabBackgroundImage","Operator window screenshot");
			failcount++;

		}
		return returnResult(failcount);
	}

	public static boolean checkSignatureChatWebPage(WebDriver driver) throws Exception
	{
		String imageId = "";
		int failcount = 0;
		String signatureWebPageUrl = Util.siteNameout()+"/signaturesupport.ls";
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement sigWebPageElement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","openseperate");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigWebPageElement) &&
			SignatureLiveChatCommonFunctions.checkContent(sigWebPageElement,"Open in your Signature Chat Webpage",etest))
		{
			etest.log(Status.PASS,"Open in your Signature Chat Webpage element was displayed in Behaviour tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("openseperate")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("openseperate")).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("openseperate")));
					if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
					{
						SignatureLiveChatCommonFunctions.clickUpdate(driver);
						etest.log(Status.PASS,"Details changed were updated");
					}
				}
				if(checkWidgetCode(driver))
				{
					WebElement sigCodeElement = CommonUtil.getElement(driver,By.id("signature_code"));
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigCodeElement) && 
						SignatureLiveChatCommonFunctions.checkContent(sigCodeElement,signatureWebPageUrl,etest))
					{
						etest.log(Status.PASS,"Signature live chat was configured to open in signature chat webpage");
					}
					else
					{
						etest.log(Status.FAIL,"Signature live chat was not configured properly to open in signature chat webpage");
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPage","Operator window screenshot");
					}
				}
				else
				{
					failcount++;
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPage","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Open in your Signature Chat Webpage element was not displayed in behaviour tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPage","Operator window screenshot");
			failcount++;

		}
		return returnResult(failcount);
	}

	public static boolean checkSignatureChatTakeMeToMyWebsite(WebDriver driver) throws Exception
	{
		String imageId = "";
		int failcount = 0;
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement sigWebPageElement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","takemywebsite");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigWebPageElement) &&
			SignatureLiveChatCommonFunctions.checkContent(sigWebPageElement,"Take me to my Website",etest))
		{
			etest.log(Status.PASS,"Take me to my Website element was displayed in behaviour tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("takemywebsite")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("takemywebsite")).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("takemywebsite")));
				}
				CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("takemywebsiteurl"),By.tagName("input")),WEBSITE_NAME);
				if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
				{
					SignatureLiveChatCommonFunctions.clickUpdate(driver);
					etest.log(Status.PASS,"Details changed were updated");
				}
				if(checkWidgetCode(driver))
				{
					WebElement sigCodeElement = CommonUtil.getElement(driver,By.id("signature_code"));
					if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigCodeElement) && 
						SignatureLiveChatCommonFunctions.checkContent(sigCodeElement,WEBSITE_NAME,etest))
					{
						etest.log(Status.PASS,"Signature live chat was configured to open in users webpage");
					}
					else
					{
						etest.log(Status.FAIL,"Signature live chat was not configured properly to open in users webpage");
						failcount++;
						TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatTakeMeToMyWebsite","Operator window screenshot");
					}
				}
				else
				{
					failcount++;
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatTakeMeToMyWebsite","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Take me to my Website element was not displayed in behaviour tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatTakeMeToMyWebsite","Operator window screenshot");
			failcount++;

		}
		if(!CommonUtil.getElement(driver,By.id("takemywebsite")).getAttribute("class").contains("set_off"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("takemywebsite")));
			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickUpdate(driver);
				etest.log(Status.PASS,"Details changed were updated");
			}
		}
		return returnResult(failcount);
	}

	public static boolean checkSignatureIconVisitorEnd(WebDriver driver,WebDriver visitor_driver,String sigCode,boolean isIconDisplayed)throws Exception
	{
		SignatureLiveChatCommonFunctions.clickInLHS(driver,"chatcode");
		SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
		WebElement sigIcon = CommonUtil.getElement(visitor_driver,By.id("output"),By.tagName("img"));
		return CommonSikuli.findInWholePage(visitor_driver,"signatureicon.png");
	}

	public static boolean checkSignatureChatWebPageVisitorEnd(WebDriver driver,WebDriver visitor_driver)throws Exception
	{
		int failcount = 0;
		SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement sigWebPageElement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","openseperate");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigWebPageElement) &&
			SignatureLiveChatCommonFunctions.checkContent(sigWebPageElement,"Open in your Signature Chat Webpage",etest))
		{
			etest.log(Status.PASS,"Open in your Signature Chat Webpage element was displayed in Behaviour tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("openseperate")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("openseperate")).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("openseperate")));
					if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
					{
						SignatureLiveChatCommonFunctions.clickUpdate(driver);
						etest.log(Status.PASS,"Details changed were updated");
					}
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Open in your Signature Chat Webpage element was not displayed in behaviour tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
			failcount++;
		}
		String sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
		if(SignatureLiveChatCommonFunctions.checkClickHere(driver,etest))
		{
			sigLinkCode = CommonUtil.getElement(driver,By.id("signature_link")).getText();
		}
		SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("output"),By.tagName("img")));
		Thread.sleep(1000);
		CommonUtil.switchToTab(visitor_driver,1);
		visitor_driver.switchTo().frame("siqiframe");
		CommonWait.waitTillDisplayed(visitor_driver,By.id("window-ribbon"));
		if(sigLinkCode.contains(visitor_driver.getCurrentUrl()))
		{
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(visitor_driver,By.id("window-ribbon"))))
			{
				etest.log(Status.PASS,"Signature live chat web page was opened on clicking the signature live chat icon from visitor end");
			}
			else
			{
				etest.log(Status.FAIL,"Signature live chat web page was not opened on clicking the signature live chat icon from the visitor end");
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
			}
		}
		else
		{
			etest.log(Status.FAIL,"Signature live chat web page didnot open -- url mismatch");
			TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
			failcount++;
		}
		visitor_driver.close();
		CommonUtil.switchToTab(visitor_driver,0);
		return returnResult(failcount);
	}

	public static boolean checkWebsiteVisitorEnd(WebDriver driver,WebDriver visitor_driver)throws Exception
	{
		int failcount = 0;
		SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement websiteElement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","takemywebsite");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(websiteElement) &&
			SignatureLiveChatCommonFunctions.checkContent(websiteElement,"Take me to my Website",etest))
		{
			etest.log(Status.PASS,"Take me to my Website element was displayed in Behaviour tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("takemywebsite")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("takemywebsite")).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("takemywebsite")));
					if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
					{
						SignatureLiveChatCommonFunctions.clickUpdate(driver);
						etest.log(Status.PASS,"Details changed were updated");
					}
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkWebsiteVisitorEnd","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Take me to my Website element was not displayed in behaviour tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkWebsiteVisitorEnd","Operator window screenshot");
			failcount++;
		}
		String sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
		SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("output"),By.tagName("img")));
		Thread.sleep(2000);
		CommonUtil.switchToTab(visitor_driver,1);
		if(visitor_driver.getCurrentUrl().contains(WEBSITE_NAME))
		{
			etest.log(Status.PASS,"Respective website was opened on clicking the signature icon from visitor end");
		}
		else
		{
			etest.log(Status.FAIL,"Website didnot open on clicking the signature icon from the visitor end -- url mismatch");
			TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkWebsiteVisitorEnd","Operator window screenshot");
			failcount++;
		}
		visitor_driver.close();
		CommonUtil.switchToTab(visitor_driver,0);
		return returnResult(failcount);
	}

	public static boolean checkSignatureChatWebPageDetails(WebDriver driver,WebDriver visitor_driver)throws Exception
	{
		int failcount = 0;
		SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
		SignatureLiveChatCommonFunctions.initVisitorEnd(visitor_driver);
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement sigWebPageElement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","openseperate");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigWebPageElement) &&
			SignatureLiveChatCommonFunctions.checkContent(sigWebPageElement,"Open in your Signature Chat Webpage",etest))
		{
			etest.log(Status.PASS,"Open in your Signature Chat Webpage element was displayed in Behaviour tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("openseperate")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("openseperate")).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("openseperate")));
					if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
					{
						SignatureLiveChatCommonFunctions.clickUpdate(driver);
						etest.log(Status.PASS,"Details changed were updated");
					}
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Open in your Signature Chat Webpage element was not displayed in behaviour tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
			failcount++;
		}
		String sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
		if(SignatureLiveChatCommonFunctions.checkClickHere(driver,etest))
		{
			sigLinkCode = CommonUtil.getElement(driver,By.id("signature_link")).getText();
		}
		checkSigWebPageDetails(driver);
		SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("output"),By.tagName("img")));
		Thread.sleep(1000);
		CommonUtil.switchToTab(visitor_driver,1);
		visitor_driver.switchTo().frame("siqiframe");
		CommonWait.waitTillDisplayed(visitor_driver,By.id("window-ribbon"));
		if(sigLinkCode.contains(visitor_driver.getCurrentUrl()))
		{
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(visitor_driver,By.id("window-ribbon"))))
			{
				etest.log(Status.PASS,"Signature live chat web page was opened on clicking the signature live chat icon from visitor end");
				if(!checkDetails(driver,visitor_driver,"CLOGO5","logo","Company Logo"))
				{
					failcount++;
				}
				if(!checkDetails(driver,visitor_driver,"SHOWABOUTCOMPANY5",COMPANY_DESC,"Company details"))
				{
					failcount++;
				}
				if(!checkDetails(driver,visitor_driver,"SHOWCONTACT5",COMPANY_ADDR,"Contact details"))
				{
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Signature live chat web page was not opened on clicking the signature live chat icon from the visitor end");
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
			}
		}
		else
		{
			etest.log(Status.FAIL,"Signature live chat web page didnot open -- url mismatch");
			TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkSignatureChatWebPageVisitorEnd","Operator window screenshot");
			failcount++;
		}
		visitor_driver.close();
		CommonUtil.switchToTab(visitor_driver,0);
		return returnResult(failcount);
	}

	public static boolean checkDetails(WebDriver user_driver,WebDriver driver,String id,String checkText,String icon)throws Exception
	{
		int failcount = 0;
		SignatureLiveChatCommonFunctions.clickInChatCode(user_driver,"apperance");
		WebElement ele = CommonUtil.getElement(user_driver,By.id(id));
		boolean isEle = SignatureLiveChatCommonFunctions.isSetON(ele);
		if(!isEle)
		{
			CommonUtil.clickWebElement(user_driver,ele);
			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(user_driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickUpdate(user_driver);
				etest.log(Status.PASS,"Details changed were updated");
			}
		}
		driver.close();
		CommonUtil.switchToTab(driver,0);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("output"),By.tagName("img")));
		Thread.sleep(1000);
		CommonUtil.switchToTab(driver,1);
		CommonWait.waitTillDisplayed(driver,By.className("siqsig_leftnav"));
		List<WebElement> previewWindowLeftNavElements = CommonUtil.getElement(driver,By.className("siqsig_leftnav")).findElements(By.xpath(".//*"));
		WebElement sigWebPageIcon = CommonUtil.getElementByAttributeValue(previewWindowLeftNavElements,"data-type",id);
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigWebPageIcon))
		{
			etest.log(Status.PASS,icon+" icon (toggled on) was verified in the Signature live chat web page on clicking signature icon from visitor end");
			if(!id.contains("CLOGO5"))
			{
				if(SignatureLiveChatCommonFunctions.checkContent(sigWebPageIcon,checkText,etest))
				{
					etest.log(Status.PASS,icon+" details was verified to be correct in signature live chat web page on clicking signature icon from visitor end");
				}
				else
				{
					etest.log(Status.FAIL,icon+" details was verified to be incorrect in signature live chat web page on clicking signature icon from visitor end");
					TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkDetails","Operator window screenshot");
					TakeScreenshot.screenshot(user_driver,etest,"Signature Live Chat","checkDetails","Operator window screenshot");
					failcount++;
				}
			}
		}
		else
		{
			etest.log(Status.FAIL,icon+" icon was not found in the Signature live chat web page on clicking signature icon from visitor end");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkDetails","Operator window screenshot");
			TakeScreenshot.screenshot(user_driver,etest,"Signature Live Chat","checkDetails","Operator window screenshot");
			failcount++;
		}
		CommonUtil.clickWebElement(user_driver,ele);
		if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(user_driver,etest))
		{
			SignatureLiveChatCommonFunctions.clickUpdate(user_driver);
			etest.log(Status.PASS,"Details changed were updated");
		}
		driver.close();
		CommonUtil.switchToTab(driver,0);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("output"),By.tagName("img")));
		Thread.sleep(1000);
		CommonUtil.switchToTab(driver,1);
		CommonWait.waitTillDisplayed(driver,By.className("siqsig_leftnav"));
		List<WebElement> previewWindowLeftNavElements2 = CommonUtil.getElement(driver,By.className("siqsig_leftnav")).findElements(By.xpath(".//*"));
		WebElement previewWindowIcon2 = CommonUtil.getElementByAttributeValue(previewWindowLeftNavElements2,"data-type",id);
		if(!SignatureLiveChatCommonFunctions.isElementDisplayed(previewWindowIcon2))
		{
			etest.log(Status.PASS,icon+" icon (toggled off) was verified in the Signature live chat web page on clicking signature icon from visitor end");
		}
		else
		{
			etest.log(Status.FAIL,icon+" icon was found inspite of toggling off the icon from Signature live chat web page on clicking signature icon from visitor end");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkDetails","Operator window screenshot");
			TakeScreenshot.screenshot(user_driver,etest,"Signature Live Chat","checkDetails","Operator window screenshot");

			failcount++;
		}
		return returnResult(failcount);
	}

	public static void checkSigWebPageDetails(WebDriver driver) throws Exception
	{
		SignatureLiveChatCommonFunctions.clickInChatCode(driver,"apperance");
		WebElement clogo = CommonUtil.getElement(driver,By.id("CLOGO5"));
		WebElement about_company = CommonUtil.getElement(driver,By.id("SHOWABOUTCOMPANY5"));
		WebElement contact_details = CommonUtil.getElement(driver,By.id("SHOWCONTACT5"));
		isClogo = SignatureLiveChatCommonFunctions.isSetON(clogo);
		isAboutCompany = SignatureLiveChatCommonFunctions.isSetON(about_company);
		isContact_details = SignatureLiveChatCommonFunctions.isSetON(contact_details);
	}

	public static boolean checkChatWindowVisitorEnd(WebDriver driver,WebDriver visitor_driver) throws Exception
	{
		int failcount = 0;
		SignatureLiveChatCommonFunctions.clickInChatCode(driver,"behaviourpreference");
		List<WebElement> middleTabElements = CommonUtil.getElement(driver,By.id("emmiddlenav")).findElements(By.tagName("div"));
		WebElement sigWebPageElement = CommonUtil.getElementByAttributeValue(middleTabElements,"prop_id","openseperate");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(sigWebPageElement) &&
			SignatureLiveChatCommonFunctions.checkContent(sigWebPageElement,"Open in your Signature Chat Webpage",etest))
		{
			etest.log(Status.PASS,"Open in your Signature Chat Webpage element was displayed in Behaviour tab in signature live chat");
			if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("openseperate")),etest))
			{
				if(CommonUtil.getElement(driver,By.id("openseperate")).getAttribute("class").contains("set_off"))
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("openseperate")));
					if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
					{
						SignatureLiveChatCommonFunctions.clickUpdate(driver);
						etest.log(Status.PASS,"Details changed were updated");
					}
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatWindowVisitorEnd","Operator window screenshot");
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Open in your Signature Chat Webpage element was not displayed in behaviour tab in signature live chat");
			TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkChatWindowVisitorEnd","Operator window screenshot");
			failcount++;
		}
		String sigCode = CommonUtil.getElement(driver,By.id("signature_code")).getText();
		if(SignatureLiveChatCommonFunctions.checkClickHere(driver,etest))
		{
			sigLinkCode = CommonUtil.getElement(driver,By.id("signature_link")).getText();
		}
		SignatureLiveChatCommonFunctions.initVisitorEndSignatureIcon(visitor_driver,sigCode);
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("output"),By.tagName("img")));
		Thread.sleep(1000);
		CommonUtil.switchToTab(visitor_driver,1);
		visitor_driver.switchTo().frame("siqiframe");
		CommonWait.waitTillDisplayed(visitor_driver,By.id("window-ribbon"));
		if(sigLinkCode.contains(visitor_driver.getCurrentUrl()))
		{
			etest.log(Status.PASS,"Signature live chat web page was opened on clicking the signature live chat icon from visitor end");
			if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(visitor_driver,By.id("window-ribbon"))))
			{
				etest.log(Status.PASS,"Chat window was found in the signature live chat web page on clicking the signature live chat icon from the visitor end");
			}
			else
			{
				etest.log(Status.FAIL,"Chat window was not found in the signature live chat web page on clicking the signature live chat icon from the visitor end");
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkChatWindowVisitorEnd","Operator window screenshot");
			}
		}
		else
		{
			etest.log(Status.FAIL,"Signature live chat web page didnot open -- url mismatch");
			TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkChatWindowVisitorEnd","Operator window screenshot");
			failcount++;
		}
		visitor_driver.close();
		CommonUtil.switchToTab(visitor_driver,0);
		return returnResult(failcount);
	}

	public static boolean checkChatRouting(WebDriver driver,WebDriver agentDriver,WebDriver visitor_driver,boolean general) throws Exception
	{
		Hashtable<String,Boolean> chatRoutingStatus = new Hashtable<String,Boolean>();
		int failcount = 0;
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("output"),By.tagName("img")));
		Thread.sleep(1000);
		CommonUtil.switchToTab(visitor_driver,1);
		CommonWait.waitTillDisplayed(driver,By.className("siqsig_leftnav"));
		visitor_driver.switchTo().frame("siqiframe");
		if(SignatureLiveChatCommonFunctions.isElementDisplayed(CommonUtil.getElement(visitor_driver,By.id("showsiqchatui"))))
		{
			CommonWait.waitTillDisplayed(visitor_driver,By.id("showsiqchatui"));
			CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id("showsiqchatui")));
		}
		SignatureLiveChatCommonFunctions.initiateChat(visitor_driver,etest);
		chatRoutingStatus = SignatureLiveChatCommonFunctions.isChatRoutedToAgents(etest,driver,agentDriver);
		String driver_name = ExecuteStatements.getUserName(driver);
		String agentDriver_name = ExecuteStatements.getUserName(agentDriver);

		if(chatRoutingStatus.get(driver_name))
		{
			if(general)
			{
				if(chatRoutingStatus.get(agentDriver_name))
				{
					etest.log(Status.PASS,"chat routed to all the agents (Signature live chat code was executed)");
				}
				else
				{
					etest.log(Status.FAIL,"Chat didnot route to all the agents (signature live chat code was executed)");
					TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkChatRouting","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				if(!chatRoutingStatus.get(agentDriver_name))
				{
					etest.log(Status.PASS,"Chat routed to specific agent (agent specific live chat code was executed)");
				}
				else
				{
					etest.log(Status.FAIL,"Chat was not routed to specific agent (agent specific live chat code was executed)");
					failcount++;
					TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkChatRouting","Operator window screenshot");
				}
			}
		}
		else
		{
			etest.log(Status.FAIL,"Chat didnot route to all the agents (signature live chat code was executed)");
			TakeScreenshot.screenshot(visitor_driver,etest,"Signature Live Chat","checkChatRouting","Operator window screenshot");
			failcount++;
		}

		CommonUtil.sleep(50000); // wait till chat ends

		visitor_driver.switchTo().frame("siqiframe");
		visitor_driver.close();
		CommonUtil.switchToTab(visitor_driver,0);
		SignatureLiveChatCommonFunctions.sigLiveChat(driver);
		return returnResult(failcount);
	}

	public static boolean checkCustomTheme(WebDriver driver)throws Exception
	{
		int failcount = 0;
		WebElement onlineUploadElement = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("userstikermain")).findElements(By.tagName("div")),"prop","online");
		WebElement offlineUploadElement = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("userstikermain")).findElements(By.tagName("div")),"prop","offline");
		CommonUtil.scrollToBottomOfPage(driver);
		if(SignatureLiveChatCommonFunctions.clickToggle(CommonUtil.getElement(driver,By.id("choosestickers")),etest))
		{
			CommonWait.waitTillDisplayed(driver,By.id("choosestickers"));
			while(CommonUtil.getElement(driver,By.id("choosestickers")).getAttribute("class").contains("set_off"))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("choosestickers")));
				Thread.sleep(1000);
			}
			FileUpload.uploadFile(CommonUtil.getElement(onlineUploadElement,By.id("ssticker-file")),FileType.IMAGE);
			Thread.sleep(1000);
			driver.switchTo().frame("sstickeriframe");
			try
			{
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.tagName("head")),"innerText","JPEG.jpg");
				etest.log(Status.FAIL,"Larger Size image was uploaded");
				failcount++;
				TakeScreenshot.screenshot(driver,etest,"Signature Live Chat","checkCustomTheme","Operator window screenshot");
			}
			catch(Exception e)
			{
				etest.log(Status.PASS,"Larger size image was not uploaded");
			}

			driver.switchTo().defaultContent();
			
			FileUpload.uploadFile(CommonUtil.getElement(onlineUploadElement,By.id("ssticker-file")),FileType.SMALL_IMAGE);
			Thread.sleep(1000);
			driver.switchTo().frame("sstickeriframe");
			CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.tagName("head")),"innerText","image.png");
			driver.switchTo().defaultContent();
			
			checkPreviewMaximizeIcon(driver);
			Thread.sleep(1000);
			CommonSikuli.findInWholePage(driver,"image.png","UI427",etest);
			if(CommonSikuli.sendResult().containsKey("UI427"))
			{
				if(CommonSikuli.result.get("UI427"))
				{
					etest.log(Status.PASS,"Custom theme was uploaded and was verified in the preview window ");
				}
				else
				{
					etest.log(Status.FAIL,"Custom theme was uploaded but was not found in the preview window");
					TakeScreenshot.screenshot(driver,etest);
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Custom theme uploaded was not found in the preview window");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			if(SignatureLiveChatCommonFunctions.checkUpdateAndCancelButton(driver,etest))
			{
				SignatureLiveChatCommonFunctions.clickCancel(driver);
				etest.log(Status.PASS,"Details changed were ignored");
			}
		}
		else
		{
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean returnResult(int failcount)
	{
		if(failcount > 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
