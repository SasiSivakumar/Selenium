//$Id$
package com.zoho.livedesk.client;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class ADepartment
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    private static String mailid = "";
    private static String url = "";
	public static ExtentTest etest; 
    
	public static Hashtable department(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD1"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
			url = ConfManager.requestURL();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Department view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            
		 	etest.log(Status.PASS,"Department Tab is found");

            result.put("ASD1", true);
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD2"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");

            result.put("ASD2", isPageAvail(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD3"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");

            result.put("ASD3", isAddPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            //etest=ComplexReportFactory.getTest("Check Editable Contents In Department Page - Associate");
            //ComplexReportFactory.setValues(etest,"Automation","Department-Associate");

            checkDept(driver);

            //ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorDepartmentTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","DepartmentTab","ErrorWhileCheckingDepartmentTab",e);

            result.put("ASD1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorDepartmentTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","DepartmentTab","ErrorWhileCheckingDepartmentTab",e);

            result.put("ASD1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	//Check Department Header
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
			
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
		 	
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("setting_department")+"')]")));
			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("setting_department")+"')]"));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
            
			if((driver.findElement(By.className("innersubinfotxt")).getText()).equals(ResourceManager.getRealValue("settings_department_desc")))
		 	{
				etest.log(Status.PASS,"Department Page is checked");

                return true;
			}
            else{
                TakeScreenshot.screenshot(driver,etest,"Department-Associate","DepartmentPage","MismatchDescription");
            }
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","DepartmentPage","ErrorWhileCheckingDepartmentPage",e);

            System.out.println("Exception while checking if department settings page is available in Associate login : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","DepartmentPage","ErrorWhileCheckingDepartmentPage",e);

            System.out.println("Exception while checking if department settings page is available in Associate login : "+e);
        }
		return false;
	}
    
    //Check for presence of add button
    private static boolean isAddPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            
            try
            {
                driver.findElement(By.id("buttonadddept")).click();
                TakeScreenshot.screenshot(driver,etest,"Department-Associate","AddButton","AddButtonIsPresent");
                return false;
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,"Add Button is not found");

                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","AddButton","ErrorWhileCheckingAddButton",e);
            System.out.println("Exception while checking if add button is present in department settings page in Associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","AddButton","ErrorWhileCheckingAddButton",e);
            System.out.println("Exception while checking if add button is present in department settings page in Associate login : "+e);
            return false;
        }
    }
    
    //Click department and check for present and not present elements
    private static void checkDept(WebDriver driver)
    {
        try
        {
            result.put("ASD4",false);
            result.put("ASD5",false);
            result.put("ASD6",false);
            result.put("ASD7",false);
            result.put("ASD8",false);
            result.put("ASD9",false);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD4"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            
            List<WebElement> elmts = driver.findElement(By.id("module-list")).findElement(By.className("cmn_listviewer")).findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                if((elmt.findElements(By.className("list_cell")).get(0).getText()).equals("Automation"))
                {
                    elmt.click();
                }
            }
            
            try
            {
                //Check name editable
                driver.findElement(By.xpath("//div[@class=\"asso_txt\"]")).click();
                driver.findElement(By.xpath("//div[@class=\"asso_txt\"]")).sendKeys("RENAMED");
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD4"),"DepartmentCanBeRenamed");
                result.put("ASD4",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD4")+"is checked");

                result.put("ASD4",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD5"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");
            
            try
            {
                //Check department type editable
                driver.findElement(By.id("private")).click();
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD5"),"DeptTypeIsEditeable");
                result.put("ASD5",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD5")+"is checked");

                result.put("ASD5",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD6"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");
            
            try
            {
                //check description editable
                driver.findElement(By.cssSelector("div#desc")).click();
                driver.findElement(By.cssSelector("div#desc")).sendKeys("Description edited");
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD6"),"DeptDescriptionIsEditable");
                result.put("ASD6",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD6")+"is checked");

                result.put("ASD6",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD7"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");
            
            try
            {
                //check for disable button
                driver.findElement(By.cssSelector("span.rg-button.cmn_cntbx")).click();
                Thread.sleep(500);
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD7"),"DisableButtonIsPresent");
                result.put("ASD7",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD7")+"is checked");

                result.put("ASD7",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD8"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");
            
            try
            {
                //check for department email config
                driver.findElement(By.id("deptconfig"));
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD8"),"EmailConfiqIsPresent");
                result.put("ASD8",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD8")+"is checked");

                result.put("ASD8",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD9"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");
            
            try
            {
                //check remove agent button
                List<WebElement> elmts1 = driver.findElement(By.id("associatedusers")).findElements(By.tagName("span"));
                elmts1.get(0).findElement(By.tagName("img"));
                mouseOver(driver,(elmts1.get(0).findElement(By.tagName("img"))));
                elmts1.get(0).findElement(By.tagName("em")).click();
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD9"),"OperatorRemoveButtonIsPresent");
                result.put("ASD9",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD9")+"is checked");

                result.put("ASD9",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASD10"));
            ComplexReportFactory.setValues(etest,"Automation","Department - Associate");
            
            try
            {
                //check for add user button
                driver.findElement(By.id("associatedusers")).findElement(By.id("adduserinput")).findElement(By.tagName("em")).click();
                TakeScreenshot.screenshot(driver,etest,"Department-Associate",KeyManager.getRealValue("ASD10"),"AddUseButtonIsPresent");
                result.put("ASD10",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASD10")+"is checked");

                result.put("ASD10",true);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","CheckDepartmentPage","ErrorWhileCheckingDepartmentPage",e);

            System.out.println("Exception while checking department elements in department settings page in Associate login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Department-Associate","CheckDepartmentPage","ErrorWhileCheckingDepartmentPage",e);

            System.out.println("Exception while checking department elements in department settings page in Associate login : "+e);
        }
        ComplexReportFactory.closeTest(etest);
    }
    
    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
}
