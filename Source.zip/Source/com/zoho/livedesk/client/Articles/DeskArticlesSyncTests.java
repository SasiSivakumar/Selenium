//$Id$
package com.zoho.livedesk.client.Articles;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;

public class DeskArticlesSyncTests
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Desk Articles Sync";
	public static String widget_code="",website_name="";

	public static final String
	DESK_DEPARTMENT1="A_Department",
	DESK_DEPARTMENT2="B_Department"
	;

	public static String title1,content1;
	public static String title2,content2;

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            website_name=ExecuteStatements.getDefaultEmbedName(driver);
            widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website_name);

			etest=ComplexReportFactory.getTest("Portal Setup");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            forceSetup(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check if desk articles are synced, Check for synced from desk icon and synced from text found");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkIsDeskArticlesSynced(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check if articles synced from desk are NOT published automatically");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkIsAddedAsDraft(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check article title,content,category and article preview close icon");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticlePreviewInPortal(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check articles published from Zoho Desk not found in visitor side without publishing from SalesIQ");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSyncedArticleNotFoundInVisitor(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Publish desk article and check in portal side and visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			publishAndCheck(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Unpublish desk article and check in portal side and visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			unpublishAndCheck(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Visitor side - Create an article with category Category A in desk portal, In SalesIQ select Category A for website 1 and Category B for website 2 and check in visitor side if created article is shown for website 1 and NOT shown for website 2");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCategoryConfig(driver,etest);
            ComplexReportFactory.closeTest(etest);            

			etest=ComplexReportFactory.getTest("Edit desk article from Zoho Desk and check if changes are affected in SalesIQ after clicking Sync Now");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			editDeskArticleAndCheckPreviewInPortal(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check if desk synced articles are not found after disabling zoho desk integration");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkIsDeskArticlesNotSynced(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check if desk synced article is deletable from SalesIQ");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDeskArticleDeletedFromSalesIQ(driver,etest);
            ComplexReportFactory.closeTest(etest);         

			etest=ComplexReportFactory.getTest("Delete desk article in Zoho Desk, click sync now in SalesIQ, check if deleted article is NOT found in SalesIQ");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteFromDeskAndCheck(driver,etest);
            ComplexReportFactory.closeTest(etest);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            
		return finalResult;
	}

	public static void forceSetup(WebDriver driver,ExtentTest etest) throws Exception
	{
		for(int i=0;i<=3;i++)
		{
			try
			{
				setup(driver,etest);
				Util.goToSalesIQ(driver);
				break;
			}
			catch(Exception e)
			{				
				if(i>=3)
				{
					etest.log(Status.FAIL,"Portal setup failed");
					CommonUtil.printStackTrace(e);
					TakeScreenshot.screenshot(driver,etest,e);
				}
				else
				{
					etest.log(Status.WARNING,"Portal setup failed. retrying again.");
				}
			}
		}
	}

	public static void setup(WebDriver driver,ExtentTest etest) throws Exception
	{
		title1=null;
		content1=null;
		title2=null;
		content2=null;

		Cleanup.deleteAllArticles(driver);

		ZohoDeskIntegration.enable(driver,etest);

		ExecuteStatements.openNewTab(driver);
		ZohoDeskUI.goToDesk(driver,etest);
		ZohoDeskUI.deleteAllArticles(driver,etest);

		title1="Title1"+CommonUtil.getUniqueMessage();
		content1="Content1"+CommonUtil.getUniqueMessage();
		ZohoDeskUI.createArticle(driver,etest,title1,DESK_DEPARTMENT1,content1);

		title2="Title2"+CommonUtil.getUniqueMessage();
		content2="Content2"+CommonUtil.getUniqueMessage();
		ZohoDeskUI.createArticle(driver,etest,title2,DESK_DEPARTMENT2,content2);

		CommonUtil.switchToTab(driver,0);

		ZohoDeskIntegration.goToPage(driver);

		//map article category to website
		ZohoDeskIntegration.clearCategoryForWebsite(driver,website_name);
		ZohoDeskIntegration.addCategoryForWebsite(driver,etest,website_name,DESK_DEPARTMENT1);
		ZohoDeskIntegration.addCategoryForWebsite(driver,etest,website_name,DESK_DEPARTMENT2);

		ZohoDeskIntegration.syncNow(driver,etest);

		etest.log(Status.PASS,"portal was setup for desk-sync module");
	}

	public static void checkDeskArticleDeletedFromSalesIQ(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			CommonUtil.switchToTab(driver,0);
			try
			{
				Tab.navToArticlesTab(driver);
				Articles.deleteArticle(driver,etest,title2);	

				result.put("DESKART11",true);
				etest.log(Status.PASS,"Desk article was deleted from SalesIQ");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			catch(Exception e1)
			{
				result.put("DESKART11",false);
				etest.log(Status.FAIL,"Desk article could not be deleted from SalesIQ");
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void checkIsDeskArticlesSynced(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;



		try
		{
			CommonUtil.switchToTab(driver,0);

			Tab.navToArticlesTab(driver);

			//check if desk article is shown
			boolean isSyncedFromDeskIcon1=Articles.isSyncedFromDeskIcon(driver,title1);

			if(isSyncedFromDeskIcon1)
			{
				result.put("DESKART1",true);
				etest.log(Status.PASS,"Desk articles sync worked after enabling zoho desk integration");
			}
			else
			{
				result.put("DESKART1",false);
				etest.log(Status.FAIL,"Desk articles sync did NOT work after enabling zoho desk integration");
				TakeScreenshot.screenshot(driver,etest);
			}

			// Check if synced from Zoho Desk and desk icon is displayed for the articles synced from Zoho Desk
			boolean isSyncedFromDeskIcon2=Articles.isSyncedFromDeskIcon(driver,title2);
			boolean isSyncedFromDeskText1=Articles.isSyncedFromDeskText(driver,title1);
			boolean isSyncedFromDeskText2=Articles.isSyncedFromDeskText(driver,title2);

			if(isSyncedFromDeskIcon1 && isSyncedFromDeskIcon2 && isSyncedFromDeskText1 && isSyncedFromDeskText2)
			{
				result.put("DESKART2",true);
				etest.log(Status.PASS,"Synced with desk icon and text was found for articles synced with desk");
			}
			else
			{
				result.put("DESKART2",false);
				etest.log(Status.FAIL,"Synced with desk icon and text was NOT found for articles synced with desk");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void checkIsDeskArticlesNotSynced(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		ZohoDeskIntegration.disable(driver,etest);

		try
		{
			CommonUtil.switchToTab(driver,0);
			Tab.navToArticlesTab(driver);

			//check if desk article is shown
			boolean isSyncedFromDeskIcon=Articles.isAtleastOneDeskSyncedArticleFound(driver);

			if(isSyncedFromDeskIcon)
			{
				result.put("DESKART12",true);
				etest.log(Status.PASS,"Desk synced article was NOT found after disabling zoho desk integration");
			}
			else
			{
				result.put("DESKART12",false);
				etest.log(Status.FAIL,"Desk synced article was found even after disabling zoho desk integration");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
		finally
		{
			ZohoDeskIntegration.enable(driver,etest);
		}
	}

	public static void checkIsAddedAsDraft(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;



		try
		{
			CommonUtil.switchToTab(driver,0);
			Tab.navToArticlesTab(driver);

			// Check if article created in desk portal is not published automatically in SalesIQ
			if(Articles.isDraftLabelInArticlesTab(driver,etest,title1,false))
			{
				result.put("DESKART3",true);
				etest.log(Status.PASS,"Articles from desk were added as draft");			
			}
			else
			{
				result.put("DESKART3",false);
				etest.log(Status.FAIL,"Articles from desk were NOT added as draft");	
				TakeScreenshot.screenshot(driver,etest);		
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void checkArticlePreviewInPortal(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;



		try
		{
			CommonUtil.switchToTab(driver,0);
			Tab.navToArticlesTab(driver);
			//check preview content and category
			Articles.openDeskArticle(driver,etest,title1);
			WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);

			Hashtable<String,String> expected_article=Articles.getExpectedDeskPreviewArticleInfo(title1,content1,"false");
			Hashtable<String,String> actual_article=Articles.getDeskArticleInfoFromPreview(article_container);

			if(Articles.verifyDeskArticlePreviewData(etest,expected_article,actual_article))
			{
				result.put("DESKART4",true);
			}
			else
			{
				result.put("DESKART4",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			// Check if desk article preview closed on clicking the close preview button
			if(Articles.closeDeskArticlePreview(driver))
			{
				etest.log(Status.PASS,"Desk article preview container was closed after clicking close button");
				result.put("DESKART5",true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk article preview container was NOT closed after clicking close button");
				result.put("DESKART5",false);		
				TakeScreenshot.screenshot(driver,etest);		
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void checkSyncedArticleNotFoundInVisitor(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;



		try
		{
			CommonUtil.switchToTab(driver,0);
			//Check if desk article is not published to visitor side without clicking publish now button in preview
			CommonUtil.sleep(1*60*1000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,title1);

			if(!isFound)
			{
				etest.log(Status.PASS,"Desk synced articles published from Zoho Desk (but not published from SalesIQ) "+title1+" was NOT found in visitor side");
				result.put("DESKART6",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Desk synced articles published from Zoho Desk (but not published from SalesIQ) "+title1+" was found in visitor side");
				result.put("DESKART6",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void publishAndCheck(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;



		try
		{
			CommonUtil.switchToTab(driver,0);
			//publish desk article
			Articles.openDeskArticle(driver,etest,title1);
			WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);
			Articles.toggleDeskArticlePublishStatusFromPreview(article_container,etest,true);

			if(Articles.isDraftLabelInArticlesTab(driver,etest,title1,true))
			{
				result.put("DESKART9",true);
				etest.log(Status.PASS,"Articles from desk was published");			
			}
			else
			{
				result.put("DESKART9",false);
				etest.log(Status.FAIL,"Articles from desk was NOT published");			
				TakeScreenshot.screenshot(driver,etest);		
			}

			//Check if desk article is published to visitor side after clicking publish now button in preview
			CommonUtil.sleep(1*60*1000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,title1);

			if(isFound)
			{
				etest.log(Status.PASS,"Desk synced articles published from Zoho Desk (and published from SalesIQ) "+title1+" was found in visitor side");
				result.put("DESKART7",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Desk synced articles published from Zoho Desk (and published from SalesIQ) "+title1+" was NOT found in visitor side");
				result.put("DESKART7",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void unpublishAndCheck(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			CommonUtil.switchToTab(driver,0);
			//un-publish desk article
			Articles.openDeskArticle(driver,etest,title1);
			WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);
			Articles.toggleDeskArticlePublishStatusFromPreview(article_container,etest,false);

			if(Articles.isDraftLabelInArticlesTab(driver,etest,title1,false))
			{
				result.put("DESKART10",true);
				etest.log(Status.PASS,"Articles from desk was unpublished");			
			}
			else
			{
				result.put("DESKART10",false);
				etest.log(Status.FAIL,"Articles from desk was NOT unpublished");			
				TakeScreenshot.screenshot(driver,etest);		
			}

			//Check if desk article is unpublished after clicking "Save as Draft" button In preview
			CommonUtil.sleep(1*60*1000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,title1);

			if(!isFound)
			{
				etest.log(Status.PASS,"Desk synced articles published from Zoho Desk (and unpublished from SalesIQ) "+title1+" was NOT found in visitor side");
				result.put("DESKART8",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Desk synced articles published from Zoho Desk (and unpublished from SalesIQ) "+title1+" was found in visitor side");
				result.put("DESKART8",false);	
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void deleteFromDeskAndCheck(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{

			CommonUtil.switchToTab(driver,1);
			ZohoDeskUI.deleteArticle(driver,etest,title1);

			CommonUtil.switchToTab(driver,0);

			ZohoDeskIntegration.goToPage(driver);
			ZohoDeskIntegration.syncNow(driver,etest);

			Tab.navToArticlesTab(driver);

			if(Articles.isArticleFound(driver,title1)==false)
			{
				result.put("DESKART13",true);
				etest.log(Status.PASS,"Article '"+title1+"' deleted from desk was NOT found in SalesIQ");			
			}
			else
			{
				result.put("DESKART13",false);
				etest.log(Status.FAIL,"Aritcle '"+title1+"' deleted from desk was FOUND in SalesIQ");			
				TakeScreenshot.screenshot(driver,etest);		
			}

			//Check if desk article is unpublished after clicking "Save as Draft" button In preview
			CommonUtil.sleep(1*60*1000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,title1);

			if(!isFound)
			{
				etest.log(Status.PASS,"Desk synced articles deleted from Zoho Desk "+title1+" was NOT found in visitor side");
				result.put("DESKART14",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Desk synced articles deleted from Zoho Desk "+title1+" was found in visitor side");
				result.put("DESKART14",false);	
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void editDeskArticleAndCheckPreviewInPortal(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			//reassign values
			CommonUtil.switchToTab(driver,1);

			String old_name=title1;
			title1="Title"+label;
			content1="Content"+label;
			ZohoDeskUI.editArticle(driver,etest,old_name,title1,DESK_DEPARTMENT2,content1);

			CommonUtil.switchToTab(driver,0);

			ZohoDeskIntegration.goToPage(driver);
			ZohoDeskIntegration.syncNow(driver,etest);

			Tab.navToArticlesTab(driver);
			//check preview content and category
			Articles.openDeskArticle(driver,etest,title1);
			WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);

			Hashtable<String,String> expected_article=Articles.getExpectedDeskPreviewArticleInfo(title1,content1,"null");
			Hashtable<String,String> actual_article=Articles.getDeskArticleInfoFromPreview(article_container);

			if(Articles.verifyDeskArticlePreviewData(etest,expected_article,actual_article))
			{
				result.put("DESKART15",true);
			}
			else
			{
				result.put("DESKART15",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			Articles.closeDeskArticlePreview(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static void checkCategoryConfig(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{

			CommonUtil.switchToTab(driver,0);

			String website1_name=website_name;
			String website1_code=widget_code;

			String website2_name=ExecuteStatements.getRandomWebsiteName(driver);
			String website2_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website2_name);


			//publish desk articles
			Articles.openDeskArticle(driver,etest,title1);
			WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);
			Articles.toggleDeskArticlePublishStatusFromPreview(article_container,etest,true);

			Articles.openDeskArticle(driver,etest,title2);
			article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);
			Articles.toggleDeskArticlePublishStatusFromPreview(article_container,etest,true);

			ZohoDeskIntegration.goToPage(driver);
			//map article category to website
			ZohoDeskIntegration.clearCategoryForWebsite(driver,website1_name);
			ZohoDeskIntegration.addCategoryForWebsite(driver,etest,website1_name,DESK_DEPARTMENT1);
			ZohoDeskIntegration.clearCategoryForWebsite(driver,website2_name);
			ZohoDeskIntegration.addCategoryForWebsite(driver,etest,website2_name,DESK_DEPARTMENT2);

			ZohoDeskIntegration.syncNow(driver,etest);

			//Check if desk article is published to visitor side after clicking publish now button in preview
			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isDept1ArticleFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,title1);
			ArticlesVisitorSide.closeArticle(visitor_driver);
			boolean isDept2ArticleFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,title2);

			if(isDept1ArticleFound)
			{
				etest.log(Status.PASS,"Assigned desk article '"+title1+"' from desk department '"+DESK_DEPARTMENT1+"' was found in visitor side");
				result.put("DESKART16",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Assigned desk article '"+title1+"' from desk department '"+DESK_DEPARTMENT1+"' was NOT found in visitor side");
				result.put("DESKART16",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(!isDept2ArticleFound)
			{
				etest.log(Status.PASS,"Unassigned desk article '"+title2+"' from desk department '"+DESK_DEPARTMENT2+"' was NOT found in visitor side");
				result.put("DESKART17",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Unassigned desk article '"+title2+"' from desk department '"+DESK_DEPARTMENT2+"' was found in visitor side");
				result.put("DESKART17",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		Driver.quitDriver(visitor_driver);
	}
}