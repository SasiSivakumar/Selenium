//$Id$
package com.zoho.livedesk.client.Articles;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;

public class ArticlesTests
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Articles";
	public static String WIDGET_CODE="",WEBSITE_NAME="";
	public static final String
	WEBSITE1 = "website1",
	WEBSITE2 = "website2",
	DEPARTMENT1 = "department1",
	DEPARTMENT2 = "department2"
	;

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest("Articles Tab Content");

			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkArticlesTab(driver,etest);
            ComplexReportFactory.closeTest(etest);

			Cleanup.deleteAllArticles(driver);

			etest=ComplexReportFactory.getTest("Enable Article");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("ART5",checkToggleArticle(driver,etest,WEBSITE_NAME,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Disable Article");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("ART7",checkToggleArticle(driver,etest,WEBSITE_NAME,false));
            ComplexReportFactory.closeTest(etest);

			Cleanup.deleteAllArticles(driver);

			etest=ComplexReportFactory.getTest("Enable Article without any created articles");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkToggleArticle(driver,etest,WEBSITE_NAME,null);
            ComplexReportFactory.closeTest(etest);

			Cleanup.deleteAllArticles(driver);

			etest=ComplexReportFactory.getTest("Create and Delete Article, Check in portal and visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCreateAndDeleteArticle(driver,etest,WEBSITE_NAME);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Disable Categories");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCategory(driver,etest,WEBSITE_NAME,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Enable Categories");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCategory(driver,etest,WEBSITE_NAME,true);
            ComplexReportFactory.closeTest(etest);

            String stats_usecase_label=CommonUtil.getUniqueMessage();

			etest=ComplexReportFactory.getTest("Check Article Stats");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleStatsRealTime(driver,etest,WEBSITE_NAME,stats_usecase_label,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check knowledge repository in websites preview(check char limit also) and visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkKnowledgeRepository(driver,etest,WEBSITE_NAME);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check article edit menu tooltips and char limit");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkAritclesEditView(driver,etest,WEBSITE_NAME);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Articles Content Editor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkAritclesContentEditor(driver,etest,WEBSITE_NAME);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Modify Existing Article and Save");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSave(driver,etest,WEBSITE_NAME,false,true);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Modify Existing Article and Publish");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSave(driver,etest,WEBSITE_NAME,true,true);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Article and Save");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSave(driver,etest,WEBSITE_NAME,false,false);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Article and Publish");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSave(driver,etest,WEBSITE_NAME,true,false);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Search FAQ");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSearch(driver,etest,WEBSITE_NAME);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Articles Website Configuration");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleWebsite(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Article Stats");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleStatsRealTime(driver,etest,WEBSITE_NAME,stats_usecase_label,true);
            ComplexReportFactory.closeTest(etest);

			Cleanup.deleteAllArticles(driver);

            String sorting_usecase_label=CommonUtil.getUniqueMessage();

			etest=ComplexReportFactory.getTest("Check Article Sorting");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSorting(driver,etest,WEBSITE_NAME,sorting_usecase_label,false);
            ComplexReportFactory.closeTest(etest);          

			driver.navigate().refresh();
			CommonUtil.sleep(15*60*1000);//wait for stats to load in portal

			etest=ComplexReportFactory.getTest("Check Article Sorting");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkArticleSorting(driver,etest,WEBSITE_NAME,sorting_usecase_label,true);
            ComplexReportFactory.closeTest(etest);

			Cleanup.deleteAllArticles(driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}            
	}

	public static void checkArticlesTab(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			Tab.navToArticlesTab(driver);
			result.put("ART1",Articles.isArticlesHeaderFound(driver,etest));
			result.put("ART2",Articles.isArticlesDescriptionFound(driver,etest));
			if(CommonUtil.isFail(result,"ART1","ART2"))
			{
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Mismatch","Failure");
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	//Check Enable : isEnable true Check Disable : isEnable false
	public static Boolean checkToggleArticle(WebDriver driver,ExtentTest etest,String embed_name,Boolean isEnable) throws Exception
	{
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);

			if(isEnable!=null)
			{
				Articles.quickPublishArticle(driver,etest,label);
			}

			Articles.toggleArticlesForWebsite(driver,etest,embed_name,isEnable,isEnable);

			if(isEnable==null)
			{
				return null;
			}	

	        String expected_pass_status=isEnable?" found ":" NOT found ";
		    String expected_fail_status=(!isEnable)?" found ":" NOT found ";                
			String action_performed=isEnable?" enabled ":" disabled ";
		
			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			if(VisitorWindow.isArticlesTabFound(visitor_driver)==isEnable)
			{
				etest.log(Status.PASS,"Article tab was "+expected_pass_status+"in visitor side after it was"+action_performed);
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Article tab was "+expected_fail_status+"in visitor side after it was"+action_performed);
				TakeScreenshot.screenshot(driver,etest);
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkCreateAndDeleteArticle(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);

			if(Articles.isEmptySlate(driver))
			{
				etest.log(Status.PASS,"Empty state div was found when no articles are present.");
				result.put("ART15",true);
			}
			else
			{
				result.put("ART15",false);
				etest.log(Status.FAIL,"Empty state div was NOT found when no articles are present.");
				TakeScreenshot.screenshot(driver,etest);
			}

	        Hashtable<String,String> article_data=Articles.getArticleDataByLabel(label);

			Articles.quickPublishArticle(driver,etest,label);

			Articles.toggleArticlesForWebsite(driver,etest,embed_name,true,true);
		
			Tab.navToArticlesTab(driver);

			if(Articles.getArticleContainerByName(driver,article_data.get(Articles.NAME))!=null)
			{
				etest.log(Status.PASS,"Created article "+article_data.get(Articles.NAME)+" was found in articles tab");		
				result.put("ART11",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Created article "+article_data.get(Articles.NAME)+" was NOT found in articles tab");		
				result.put("ART11",false);
				TakeScreenshot.screenshot(driver,etest);					
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle( visitor_driver ,etest,article_data.get(Articles.NAME),article_data.get(Articles.CATEGORY),ExecuteStatements.getSystemGeneratedDepartment(driver) );

			if(isFound)
			{
				etest.log(Status.PASS,"Created article "+article_data.get(Articles.NAME)+" was found in visitor side");		
				result.put("ART12",true);	
				result.put("ART14",true);
				result.put("ART26",true);

				Hashtable<String,String> expected_article=new Hashtable<String,String>();
				Hashtable<String,String> actual_article=new Hashtable<String,String>();

				WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(visitor_driver);
				etest.log(Status.PASS,"article_container"+article_container.getText());

		        CommonSikuli.findInWholePage(visitor_driver,"UI334.png","UI334",etest);
		        CommonSikuli.findInWholePage(visitor_driver,"UI335.png","UI335",etest);
		        CommonSikuli.findInWholePage(visitor_driver,"UI336.png","UI336",etest);

				expected_article=ArticlesVisitorSide.getExpectedArticleInfo(article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),"0","0","true");
				actual_article=ArticlesVisitorSide.getArticleInfo(article_container);

				if(ArticlesVisitorSide.verifyArticleData(etest,expected_article,actual_article))
				{
					result.put("ART13",true);
				}
				else
				{
					result.put("ART13",false);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Created article "+article_data.get(Articles.NAME)+" was NOT found in visitor side");
				result.put("ART12",false);
				result.put("ART14",false);										
				result.put("ART26",false);
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			Tab.navToArticlesTab(driver);

			if(Articles.deleteArticle(driver,etest,article_data.get(Articles.NAME)))
			{
				etest.log(Status.PASS,"Deleted article "+article_data.get(Articles.NAME)+" was NOT found in articles tab");
				result.put("ART8",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Deleted article "+article_data.get(Articles.NAME)+" was found in articles tab");
				result.put("ART8",false);		
				TakeScreenshot.screenshot(driver,etest);				
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,article_data.get(Articles.NAME));


			if(!isFound)
			{
				etest.log(Status.PASS,"Deleted article "+article_data.get(Articles.NAME)+" was NOT found in visitor side");
				result.put("ART9",true);
		        CommonSikuli.findInWholePage(visitor_driver,"UI333.png","UI333",etest);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted article "+article_data.get(Articles.NAME)+" was found in visitor side");
				result.put("ART9",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);						
		}
		finally
		{

		}
	}

	public static boolean checkCategory(WebDriver driver,ExtentTest etest,String embed_name,boolean isCategoryEnabled) throws Exception
	{
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);

			Articles.quickPublishArticle(driver,etest,label);

			Articles.toggleCategories(driver,etest,embed_name,isCategoryEnabled);

	        String expected_pass_status=isCategoryEnabled?" categorised ":" NOT categorised ";
		    String expected_fail_status=(!isCategoryEnabled)?" NOT categorised ":" categorised ";                
			String action_performed=isCategoryEnabled?" enabling 'Categorise your articles' checkbox ":" disabling 'Categorise your articles' checkbox ";
			String usecase=isCategoryEnabled?"ART18":"ART19";

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

	        ArticlesVisitorSide.clickArticlesTab(visitor_driver);
	        CommonUtil.sleep(1000);
            CommonSikuli.findInWholePage(visitor_driver,"UI332.png","UI332",etest);
            // CommonSikuli.findInWholePage(visitor_driver,"UI337.png","UI337",etest);

			// ArticlesVisitorSide.openDepartment(visitor_driver,ExecuteStatements.getSystemGeneratedDepartment(driver));

			if(ArticlesVisitorSide.isArticlesCategorised(visitor_driver)==isCategoryEnabled)
			{
				etest.log(Status.PASS,"Articles were"+expected_pass_status+"after "+action_performed);
				result.put(usecase,true);
			}
			else
			{
				failcount++;
				result.put(usecase,false);
				etest.log(Status.FAIL,"Articles were"+expected_fail_status+"after "+action_performed);	
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);			
			}

			if(isCategoryEnabled)
			{

				//visitor side
				String article_name=Articles.getArticleDataByLabel(label).get(Articles.NAME);
				String category=Articles.getArticleDataByLabel(label).get(Articles.CATEGORY);
				try
				{
					ArticlesVisitorSide.getCategoryContainer(visitor_driver,category);
					etest.log(Status.PASS,"New category "+category+" was created in visitor side.");
					result.put("ART17",true);
				}
				catch(ZohoSalesIQRuntimeException e)
				{
					failcount++;
					e.printStackTrace();
					etest.log(Status.FAIL,"New category "+category+" was NOT created in visitor side. ");
					result.put("ART17",false);
				}

				//agent side
				Articles.openEditArticle(driver,etest,article_name);

				if(Articles.isExpectedCategoryFound(driver,etest,category))
				{
					result.put("ART20",true);//article found under category usecase
					result.put("ART16",true);//category found usecase
				}
				else
				{
					result.put("ART20",false);//article found under category usecase
					result.put("ART16",false);//category found usecase
					TakeScreenshot.screenshot(driver,etest);
				}
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkKnowledgeRepository(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String knowledge_repository_name=label.substring(label.length()-5);

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);
			Tab.navToArticlesTab(driver);
			Articles.quickPublishArticle(driver,etest,label);
			Articles.setKnowledgeRepositoryName(driver,etest,embed_name,knowledge_repository_name);
			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);
			checkKnowledgeRepositoryName(visitor_driver,etest,"ART22",knowledge_repository_name);
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static void checkAritclesEditView(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		final String
		title_usecase="ART29",
		content_usecase="ART30",
		department_usecase="ART43",
		category_usecase="ART44";

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);
			Tab.navToArticlesTab(driver);
	        Articles.clickAddButton(driver);
	        result.put( title_usecase , HandleCommonUI.verifyTooltip( driver, etest, Articles.ARTICLE_TITLE_HELP_ICON, Articles.COMMON_TOOLTIP_CONTAINER, ResourceManager.getRealValue("articles_title_tooltip") ));
	        
	        // result.put( department_usecase , HandleCommonUI.verifyTooltip( driver, etest, Articles.ARTICLE_WEBSITES_TOOLTIP_HELP_ICON, Articles.COMMON_TOOLTIP_CONTAINER, ResourceManager.getRealValue("articles_websites_tooltip") ));
	        result.put( department_usecase , HandleCommonUI.verifyTooltip( driver, etest, Articles.ARTICLE_DEPARTMENTS_TOOLTIP_HELP_ICON, Articles.COMMON_TOOLTIP_CONTAINER, ResourceManager.getRealValue("articles_department_tooltip") ));

	        result.put( content_usecase , HandleCommonUI.verifyTooltip( driver, etest, Articles.ARTICLE_CONTENT_TOOLTIP_HELP_ICON, Articles.COMMON_TOOLTIP_CONTAINER, ResourceManager.getRealValue("articles_content_tooltip") ));

	        result.put( category_usecase , HandleCommonUI.verifyTooltip( driver, etest, Articles.ARTICLE_CATEGORY_TOOLTIP_HELP_ICON, Articles.COMMON_TOOLTIP_CONTAINER, ResourceManager.getRealValue("articles_category_tooltip") ));

	        WebElement
	        article_name_input=Articles.getArticleNameInputTag(driver),
	        article_name_char_limit_container=CommonUtil.getElement(driver,Articles.ARTICLE_NAME_INPUT_CHAR_LIMIT);

	        boolean isCharLimitPassed=HandleCommonUI.checkCharLimitForInput(driver,etest,article_name_input,article_name_char_limit_container,Articles.ARTICLE_TITLE_CHAR_LIMIT,10,Articles.CHAR_LIMIT_TEMPLATE,Articles.ARTICLE_TITLE_CHAR_LIMIT_EXCEEDED_TEXT,"article title input");
			result.put("ART27",isCharLimitPassed);
			result.put("ART28",isCharLimitPassed);
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static void checkAritclesContentEditor(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		final String
		bold_text="Bold"+label,
		not_bold_text="Bold!"+label,
		italics_text="Italics"+label,
		not_italics_text="Italics!"+label,
		underline_text="underline"+label,
		not_underline_text="underline!"+label;

		WebDriver visitor_driver=null;

		final String
		title_usecase="ART29",
		content_usecase="ART30",
		department_usecase="ART43",
		category_usecase="ART44";

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);
			Tab.navToArticlesTab(driver);
	        Articles.clickAddButton(driver);

	        String
	        name="name"+label,
	        dept=ExecuteStatements.getSystemGeneratedDepartment(driver),
	        category="cat"+label,
	        link_text="link"+label,
	        link_url="www."+label+".com",
	        email_text="email"+label,
	        email=label+"@email.com",
	        email_subject="sub"+label
	        ;

	        Articles.setArticleName(driver,name);

	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.BOLD,bold_text,true);
	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.BOLD,not_bold_text,false);

	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.ITALIC,italics_text,true);
	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.ITALIC,not_italics_text,false);

	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.UNDERLINE,underline_text,true);
	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.UNDERLINE,not_underline_text,false);

	        Articles.addContentWithTextEmphasisOptions(driver,etest,Articles.HORIZONTAL_LINE,null,null);

	        Articles.addURLToArticle(driver,etest,link_text,link_url);
	        Articles.addLinkToArticle(driver,etest,email_text,email,email_subject);

            // Articles.selectArticleWebsitesAll(driver,etest);
            Articles.selectArticlesDepartment(driver,null);
	        Articles.selectArticleCategory(driver,category,true);
		    etest.log(Status.INFO,"Article was "+name+" published");

		    Articles.publishArticle(driver);
		    TakeScreenshot.infoScreenshot(driver,etest);

		    Articles.openEditArticle(driver,etest,name);
	        Articles.clickPreviewButton(driver);

	        checkTextEmphasisArticlePreview(driver,etest,Articles.BOLD,bold_text,true,false);
	        checkTextEmphasisArticlePreview(driver,etest,Articles.BOLD,not_bold_text,false,false);
	        checkTextEmphasisArticlePreview(driver,etest,Articles.ITALIC,italics_text,true,false);
	        checkTextEmphasisArticlePreview(driver,etest,Articles.ITALIC,not_italics_text,false,false);
	        checkTextEmphasisArticlePreview(driver,etest,Articles.UNDERLINE,underline_text,true,false);
		    checkTextEmphasisArticlePreview(driver,etest,Articles.UNDERLINE,not_underline_text,false,false);

		    checkIfLinkIsAdded(driver,etest,"PREVIEW",link_text,link_url,null);
		    checkIfLinkIsAdded(driver,etest,"PREVIEW",email_text,email,email_subject);

		    ArticlesVisitorSide.closeArticle(driver);

		    Articles.publishArticle(driver);

		    CommonUtil.sleep(5000);//for article to load in visitor side

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			ArticlesVisitorSide.openArticle(visitor_driver,etest,name,category,dept);

	        checkTextEmphasisArticlePreview(visitor_driver,etest,Articles.BOLD,bold_text,true,true);
	        checkTextEmphasisArticlePreview(visitor_driver,etest,Articles.BOLD,not_bold_text,false,true);
	        checkTextEmphasisArticlePreview(visitor_driver,etest,Articles.ITALIC,italics_text,true,true);
	        checkTextEmphasisArticlePreview(visitor_driver,etest,Articles.ITALIC,not_italics_text,false,true);
	        checkTextEmphasisArticlePreview(visitor_driver,etest,Articles.UNDERLINE,underline_text,true,true);
		    checkTextEmphasisArticlePreview(visitor_driver,etest,Articles.UNDERLINE,not_underline_text,false,true);

		    checkIfLinkIsAdded(visitor_driver,etest,"VISITOR",link_text,link_url,null);
		    checkIfLinkIsAdded(visitor_driver,etest,"VISITOR",email_text,email,email_subject);

	        TakeScreenshot.infoScreenshot(visitor_driver,etest);

		    ArticlesVisitorSide.closeArticle(visitor_driver);
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			

		}
		finally
		{

		}
	}

	public static void checkArticleSave(WebDriver driver,ExtentTest etest,String embed_name,boolean isPublish,boolean isModified) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);

		    Hashtable<String,String> article_data=Articles.getArticleDataByLabel(label);
		    String website=ExecuteStatements.getDefaultEmbedName(driver);
		    String action=isPublish?Articles.PUBLISH:Articles.SAVE;

		    Articles.addNewArticle(driver,etest,article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),new String[]{website},article_data.get(Articles.CATEGORY),action);

		    if(isModified)
		    {
		    	Articles.openEditArticle(driver,etest,article_data.get(Articles.NAME));
    	        Articles.setArticleContent(driver,"edited"+article_data.get(Articles.CONTENT));

    	        if(action.equals(Articles.PUBLISH))
    	        {
    	        	Articles.publishArticle(driver);
    	        }
    	        else if(action.equals(Articles.SAVE))
    	        {
    	        	Articles.saveArticle(driver);
    	        }
		    }

        	Tab.navToArticlesTab(driver);
        	Articles.checkArticleSavedInfoFound(driver,etest,"TAB",article_data.get(Articles.NAME),isPublish,isModified);

	    	Articles.openEditArticle(driver,etest,article_data.get(Articles.NAME));
        	Articles.checkArticleSavedInfoFound(driver,etest,"EDIT_MENU",article_data.get(Articles.NAME),isPublish,isModified);

        	if(isPublish && !isModified)
        	{
        		TakeScreenshot.infoScreenshot(driver,etest);
				Articles.openEditArticle(driver,etest,article_data.get(Articles.NAME));
    	        Articles.setArticleContent(driver,"edited"+article_data.get(Articles.CONTENT));
    	        Articles.saveArticle(driver);

        		CommonUtil.sleep(2*60*1000);

				visitor_driver=visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widget_code);
				VisitorWindow.clickChatButton(visitor_driver);

				boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,article_data.get(Articles.NAME));

				if(isFound)
				{
					WebElement articlesContainer = ArticlesVisitorSide.getArticlePreviewContainer(visitor_driver);
					String articleContent = articlesContainer.getAttribute("innerText");
					if(CommonUtil.checkStringContainsAndLog(article_data.get(Articles.NAME),articleContent,"article name",etest) && CommonUtil.checkStringContainsAndLog(article_data.get(Articles.CONTENT),articleContent,"article content",etest))
					{
						etest.log(Status.PASS,"Previously published details for Article "+article_data.get(Articles.NAME)+" was found in visitor side after the article was drafted");
						result.put("ART112",true);
					}
					else
					{
						etest.log(Status.FAIL,"Previously published details for Article "+article_data.get(Articles.NAME)+" was not found in visitor side after the article was drafted");
						result.put("ART112",false);
					}
				}
				else
				{
					etest.log(Status.FAIL,"Article "+article_data.get(Articles.NAME)+" was NOT found in articles search results");
					result.put("ART112",false);
					TakeScreenshot.screenshot(driver,etest);				
					TakeScreenshot.screenshot(visitor_driver,etest);
				}

        	}

		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}
	
	public static void checkArticleSearch(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		try
		{
			//Cleanup.deleteAllArticles(driver);

	        Hashtable<String,String> article_data=Articles.getArticleDataByLabel(label);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);
			Articles.quickPublishArticle(driver,etest,label);
			TakeScreenshot.infoScreenshot(driver,etest);

			CommonUtil.sleep(2*60*1000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,article_data.get(Articles.NAME));


			if(isFound)
			{
				etest.log(Status.PASS,"Article "+article_data.get(Articles.NAME)+" was found in articles search results");
				result.put("ART86",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Article "+article_data.get(Articles.NAME)+" was NOT found in articles search results");
				result.put("ART86",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

  	public static void checkArticleWebsite(WebDriver driver,ExtentTest etest) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		try
		{
		    Hashtable<String,String> article_data=Articles.getArticleDataByLabel(label);
		    String website = WEBSITE1;
		    String website2 = WEBSITE2;
		    String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
		    String website2_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website2);

		    Tab.navToArticlesTab(driver);
		    Articles.addNewArticle(driver,etest,article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),new String[]{DEPARTMENT1},article_data.get(Articles.CATEGORY),Articles.PUBLISH);
			TakeScreenshot.infoScreenshot(driver,etest);

			Articles.toggleArticlesForWebsite(driver,etest,website,true,true);
			Articles.toggleArticlesForWebsite(driver,etest,website2,true,true);

			CommonUtil.sleep(2*60*1000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.clickChatButton(visitor_driver);

			boolean isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,article_data.get(Articles.NAME));

			if(isFound)
			{
				etest.log(Status.PASS,"Article "+article_data.get(Articles.NAME)+" was found in added website : "+website);
				result.put("ART108",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Article "+article_data.get(Articles.NAME)+" was NOT found in added website : "+website);
				result.put("ART108",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website2_code);
			VisitorWindow.clickChatButton(visitor_driver);

			isFound=ArticlesVisitorSide.openArticle(visitor_driver,etest,article_data.get(Articles.NAME));

			if(!isFound)
			{
				etest.log(Status.PASS,"Article "+article_data.get(Articles.NAME)+" was NOT found in website : "+website);
				result.put("ART109",true);						
			}
			else
			{
				etest.log(Status.FAIL,"Article "+article_data.get(Articles.NAME)+" was found in website : "+website);
				result.put("ART109",false);		
				TakeScreenshot.screenshot(driver,etest);				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			// articles is changed from embed based to department based hence removed the below usecases
			// Articles.openEditArticle(driver,etest,article_data.get(Articles.NAME));

			// //adding website ussecase
			// if(Articles.selectArticleWebsites(driver,etest,new String[]{website,website2}))
			// {
			// 	result.put("ART110",true);
			// 	etest.log(Status.PASS,"Website was succesfully added to article after selecting them from dropdown");
			// }
			// else
			// {
			// 	result.put("ART110",true);
			// 	etest.log(Status.FAIL,"Website was NOT succesfully added to article after selecting them from dropdown");
			// 	TakeScreenshot.screenshot(driver,etest);			
			// }

			// //removing website ussecase
			// if(Articles.selectArticleWebsites(driver,etest,new String[]{website,website2}))
			// {
			// 	result.put("ART111",true);
			// 	etest.log(Status.PASS,"Website was succesfully removed from article after clicking close button");
			// }
			// else
			// {
			// 	result.put("ART111",true);
			// 	etest.log(Status.FAIL,"Website was NOT succesfully removed from article after clicking close button");
			// 	TakeScreenshot.screenshot(driver,etest);			
			// }

	        // Articles.saveArticle(driver);
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			CommonUtil.doNothing();
		}
	}

	public static void checkArticleStatsRealTime(WebDriver driver,ExtentTest etest,String embed_name,String label,boolean isContinue) throws Exception
	{
		boolean isStart=(!isContinue);

		WebDriver visitor_driver=null;

		int
		views=2,
		likes=1,
		dislikes=1,
		expected_likes_percentage=(likes*100)/views,
		expected_dislikes_percentage=(dislikes*100)/views;

		try
		{
			//Cleanup.deleteAllArticles(driver);

	        Hashtable<String,String> article_data=Articles.getArticleDataByLabel(label);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);

			if(isStart)
			{

				//here usecases to check before and after voting,likes,dislikes increased in visitor side will be executed in method Articles.setupArticleWithStats
				String voting_usecase_label=CommonUtil.getUniqueMessage();
				Articles.quickPublishArticle(driver,etest,voting_usecase_label);
				Articles.toggleArticlesForWebsite(driver,etest,embed_name,true,true);
				TakeScreenshot.infoScreenshot(driver,etest);
				Articles.setupArticleWithStats(driver,etest,widget_code,Articles.getArticleDataByLabel(voting_usecase_label),views,likes,dislikes);

				//setup actual article for "checkArticleStatsRealTime" usecase
				Tab.navToArticlesTab(driver);
				Articles.quickPublishArticle(driver,etest,label);
				Articles.toggleArticlesForWebsite(driver,etest,embed_name,true,true);
				TakeScreenshot.infoScreenshot(driver,etest);
				Articles.setupArticleWithStats(driver,etest,widget_code,article_data,views,likes,dislikes);
			}

			else if(isContinue)
			{
				Hashtable<String,String> article_stats=Articles.getArticleStats(driver,article_data.get(Articles.NAME));

				if(CommonUtil.checkStringEqualsAndLog(views+"",article_stats.get(Articles.VIEWS),"articles views",etest))
				{
					result.put("ART89",true);
				}
				else
				{
					result.put("ART89",false);
					TakeScreenshot.screenshot(driver,etest);
				}

				if(CommonUtil.checkStringContainsAndLog(expected_likes_percentage+"%",article_stats.get(Articles.LIKES),"articles likes",etest))
				{
					result.put("ART90",true);
				}
				else
				{
					result.put("ART90",false);
					TakeScreenshot.screenshot(driver,etest);
				}

				if(CommonUtil.checkStringContainsAndLog(expected_dislikes_percentage+"%",article_stats.get(Articles.DISLIKES),"articles dislikes",etest))
				{
					result.put("ART91",true);
				}
				else
				{
					result.put("ART91",false);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);					
		}
		finally
		{

		}
	}

	public static void checkArticleSorting(WebDriver driver,ExtentTest etest,String embed_name,String label,boolean isContinue) throws Exception
	{
		boolean isStart=(!isContinue);

		WebDriver visitor_driver=null;

		int
		views1=7,
		views2=6,
		views3=5,

		likes1=4,
		likes2=3,
		likes3=2,

		dislikes1=1,
		dislikes2=2,
		dislikes3=3,

		expected_likes_percentage1=(likes1/views1)*100,
		expected_dislikes_percentage1=(dislikes1/views1)*100,

		expected_likes_percentage2=(likes2/views2)*100,
		expected_dislikes_percentage2=(dislikes2/views2)*100,

		expected_likes_percentage3=(likes3/views3)*100,
		expected_dislikes_percentage3=(dislikes3/views3)*100
		;

		String
		label1="1"+label,
		label2="2"+label,
		label3="3"+label;

        Hashtable<String,String> article_data1=Articles.getArticleDataByLabel(label1);
        Hashtable<String,String> article_data2=Articles.getArticleDataByLabel(label2);
        Hashtable<String,String> article_data3=Articles.getArticleDataByLabel(label3);

		try
		{
			//Cleanup.deleteAllArticles(driver);

			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed_name);

			Tab.navToArticlesTab(driver);

			if(isStart)
			{
				Articles.quickPublishArticle(driver,etest,label1);
				Articles.quickPublishArticle(driver,etest,label2);
				Articles.quickPublishArticle(driver,etest,label3);
				Articles.toggleArticlesForWebsite(driver,etest,embed_name,true,true);
				TakeScreenshot.infoScreenshot(driver,etest);
				Articles.setupArticleWithStats(driver,etest,widget_code,article_data1,views1,likes1,dislikes1);
				Articles.setupArticleWithStats(driver,etest,widget_code,article_data2,views2,likes2,dislikes2);
				Articles.setupArticleWithStats(driver,etest,widget_code,article_data3,views3,likes3,dislikes3);
			}

			else if(isContinue)
			{
				String[] article_names={article_data1.get(Articles.NAME),article_data2.get(Articles.NAME),article_data3.get(Articles.NAME)};
				Integer[] article_indexes=null;

				Articles.sortBy(driver,etest,Articles.SORT_TYPE_VIEWS,Articles.SORT_DIR_ASCENDING);
				article_indexes=new Integer[]{3,2,1};
				result.put("ART92", checkArticleIndexes(driver,etest,article_names,article_indexes));

				Articles.sortBy(driver,etest,Articles.SORT_TYPE_VIEWS,Articles.SORT_DIR_DESCENDING);
				article_indexes=new Integer[]{1,2,3};
				result.put("ART93", checkArticleIndexes(driver,etest, article_names , article_indexes ) );

				Articles.sortBy(driver,etest,Articles.SORT_TYPE_LIKES,Articles.SORT_DIR_ASCENDING);
				article_indexes=new Integer[]{3,2,1};
				result.put("ART94", checkArticleIndexes(driver,etest,article_names , article_indexes ) );

				Articles.sortBy(driver,etest,Articles.SORT_TYPE_LIKES,Articles.SORT_DIR_DESCENDING);
				article_indexes=new Integer[]{1,2,3};
				result.put("ART95", checkArticleIndexes(driver,etest, article_names , article_indexes ) );

				Articles.sortBy(driver,etest,Articles.SORT_TYPE_DISLIKES,Articles.SORT_DIR_ASCENDING);
				article_indexes=new Integer[]{1,2,3};
				result.put("ART96", checkArticleIndexes(driver,etest, article_names , article_indexes ) );

				Articles.sortBy(driver,etest,Articles.SORT_TYPE_DISLIKES,Articles.SORT_DIR_DESCENDING);
				article_indexes=new Integer[]{3,2,1};
				result.put("ART97", checkArticleIndexes(driver,etest, article_names , article_indexes) );
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);					
		}
		finally
		{

		}
	}

	public static boolean checkArticleIndexes(WebDriver driver,ExtentTest etest,String[] article_names,Integer[] article_indexes)
	{
		int failcount=0;

		Hashtable<String,Integer> indexes=Articles.getArticleIndexes(driver);

		for(int i=0;i<article_names.length;i++)
		{
			String article_name=article_names[i];
			int index=article_indexes[i];

			if(indexes.get(article_name).equals(index))
			{
				etest.log(Status.PASS,"Article '"+article_name+"' was found with expected index "+index);
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Article '"+article_name+"' was NOT found with expected index "+index+" actual index : "+indexes.get(article_name));
				TakeScreenshot.screenshot(driver,etest);
			}
		}

		return CommonUtil.returnResult(failcount);
	}


	//checks during other cases
	public static void checkKnowledgeRepositoryName(WebDriver visitor_driver,ExtentTest etest,String use_case,String expected_name) throws Exception
	{
        if(!CommonUtil.isChecked(use_case,ArticlesTests.result))
        {
            if(CommonUtil.checkStringEqualsAndLog(expected_name,ArticlesVisitorSide.getKnowledgeRepositoryName(visitor_driver),"knowledge repository",etest))
            {
	            ArticlesTests.result.put(use_case,true);
	            TakeScreenshot.infoScreenshot(visitor_driver,etest);
            }
            else
            {
            	TakeScreenshot.screenshot(visitor_driver,etest);
	            ArticlesTests.result.put(use_case,false);            	
            }
        }
	}

	public static void checkKnowledgeRepositoryCharLimit(WebDriver driver,ExtentTest etest)
	{
		try
		{
	        if(!CommonUtil.isChecked("ART23",ArticlesTests.result))
	        {	
	        	WebElement input=CommonUtil.getElement(driver,Articles.KNOWLEDGE_REPO_NAME_INPUT);
	        	CommonUtil.inViewPort(input);

	        	String input_value="";

	        	int failcount=0;

	        	for(int i=0;i<=(Articles.KNOWLEDGE_REPOSITORY_CHAR_LIMIT+1);i++)
	        	{

	        		etest.log(Status.INFO,"Sending '"+input_value+"'' to knowledge repo input.");

	        		boolean isCharLimitExceeded=(i>Articles.KNOWLEDGE_REPOSITORY_CHAR_LIMIT);

		        	input.click();
		        	input.clear();
				CommonUtil.clickWebElement(driver, By.id("faqtab"));		        	
				input.sendKeys(input_value);

		        	int expected_char_limit=Articles.KNOWLEDGE_REPOSITORY_CHAR_LIMIT-i;
	        		String actual=CommonUtil.getElement(driver,Articles.KNOWLEDGE_REPO_NAME_INPUT_CHAR_LIMIT).getText();
	       			String expected=Articles.CHAR_LIMIT_TEMPLATE.replace("$limit$",expected_char_limit+"");

	        		if(isCharLimitExceeded)
	        		{
		        		expected=Articles.CHAR_LIMIT_EXCEEDED_TEXT;
	        		}

		        	if(!CommonUtil.checkStringContainsAndLog(expected,actual,"character limit after sending "+i+" characters in knowledge repo name",etest))
		        	{
		        		failcount++;
		        		TakeScreenshot.screenshot(driver,etest);
		        	}
		        	else
		        	{
		        		if(isCharLimitExceeded)//for putting char limit exceeded result in its key
		        		{
		        			ArticlesTests.result.put("ART24",true);
		        		}
		        		else
		        		{
		        			ArticlesTests.result.put("ART24",false);
		        		}
		        	}

		        	input_value=input_value+"a";//increasing 1 char per loop after checking
	        	}

	        	if(CommonUtil.returnResult(failcount))
	        	{
	        		ArticlesTests.result.put("ART23",true);
	        	}
	        	else
	        	{
	        		ArticlesTests.result.put("ART23",false);
	        	}
	        }
		}
		catch(Exception e)
		{

		}
	}

	public static String getTextEmphasisUsecase(String usecase_type,String emphasis_type,boolean isSelect)
	{
		if(usecase_type.equals("ICON"))
		{
			if(emphasis_type.equals(Articles.BOLD) && isSelect)
			{
				return "ART31";
			}
			if(emphasis_type.equals(Articles.BOLD) && !isSelect)
			{
				return "ART32";
			}

			if(emphasis_type.equals(Articles.UNDERLINE) && isSelect)
			{
				return "ART33";
			}
			if(emphasis_type.equals(Articles.UNDERLINE) && !isSelect)
			{
				return "ART34";
			}

			if(emphasis_type.equals(Articles.ITALIC) && isSelect)
			{
				return "ART35";
			}
			if(emphasis_type.equals(Articles.ITALIC) && !isSelect)
			{
				return "ART36";
			}
		}

		if(usecase_type.equals("EDITOR"))
		{
			if(emphasis_type.equals(Articles.BOLD) && isSelect)
			{
				return "ART46";
			}

			if(emphasis_type.equals(Articles.BOLD) && !isSelect)
			{
				return "ART47";
			}

			if(emphasis_type.equals(Articles.UNDERLINE) && isSelect)
			{
				return "ART48";
			}
			if(emphasis_type.equals(Articles.UNDERLINE) && !isSelect)
			{
				return "ART49";
			}

			if(emphasis_type.equals(Articles.ITALIC) && isSelect)
			{
				return "ART50";
			}
			if(emphasis_type.equals(Articles.ITALIC) && !isSelect)
			{
				return "ART51";
			}
		}

		if(usecase_type.equals("PREVIEW"))
		{
			if(emphasis_type.equals(Articles.BOLD) && isSelect)
			{
				return "ART37";
			}

			if(emphasis_type.equals(Articles.BOLD) && !isSelect)
			{
				return "ART52";
			}

			if(emphasis_type.equals(Articles.UNDERLINE) && isSelect)
			{
				return "ART38";
			}
			if(emphasis_type.equals(Articles.UNDERLINE) && !isSelect)
			{
				return "ART53";
			}

			if(emphasis_type.equals(Articles.ITALIC) && isSelect)
			{
				return "ART39";
			}
			if(emphasis_type.equals(Articles.ITALIC) && !isSelect)
			{
				return "ART54";
			}
		}

		if(usecase_type.equals("VISITOR"))
		{
			if(emphasis_type.equals(Articles.BOLD) && isSelect)
			{
				return "ART40";
			}

			if(emphasis_type.equals(Articles.BOLD) && !isSelect)
			{
				return "ART55";
			}

			if(emphasis_type.equals(Articles.UNDERLINE) && isSelect)
			{
				return "ART41";
			}
			if(emphasis_type.equals(Articles.UNDERLINE) && !isSelect)
			{
				return "ART56";
			}

			if(emphasis_type.equals(Articles.ITALIC) && isSelect)
			{
				return "ART42";
			}
			if(emphasis_type.equals(Articles.ITALIC) && !isSelect)
			{
				return "ART57";
			}
		}				

		return null;
	}

	public static String getSaveArticlesUseCase(String checked_in,String param_to_check,boolean isPublished,boolean isModified)
	{
		if(checked_in.equals("TAB"))
		{
			if(param_to_check.equals("SAVED_BY"))
			{				
				if(!isPublished && !isModified)
				{
					return "ART68";
				}
				if(!isPublished && isModified)
				{
					return "ART69";
				}
				if(isPublished && !isModified)
				{
					return "ART70";
				}
				if(isPublished && isModified)
				{
					return "ART71";
				}
			}
			else if(param_to_check.equals("SAVED_AT"))
			{
				if(!isPublished && !isModified)
				{
					return "ART66";
				}
				if(!isPublished && isModified)
				{
					return "ART72";
				}
				if(isPublished && !isModified)
				{
					return "ART67";
				}
				if(isPublished && isModified)
				{
					return "ART73";
				}
			}
			else if(param_to_check.equals("IS_DRAFT"))
			{
				if(!isPublished && !isModified)
				{
					return "ART82";
				}
				if(!isPublished && isModified)
				{
					return "ART83";
				}
				if(isPublished && !isModified)
				{
					return "ART84";
				}
				if(isPublished && isModified)
				{
					return "ART85";
				}				
			}
		}

		if(checked_in.equals("EDIT_MENU"))
		{
			if(param_to_check.equals("SAVED_BY"))
			{				
				if(!isPublished && !isModified)
				{
					return "ART76";
				}
				if(!isPublished && isModified)
				{
					return "ART77";
				}
				if(isPublished && !isModified)
				{
					return "ART78";
				}
				if(isPublished && isModified)
				{
					return "ART79";
				}
			}
			else if(param_to_check.equals("SAVED_AT"))
			{
				if(!isPublished && !isModified)
				{
					return "ART74";
				}
				if(!isPublished && isModified)
				{
					return "ART80";
				}
				if(isPublished && !isModified)
				{
					return "ART75";
				}
				if(isPublished && isModified)
				{
					return "ART81";
				}
			}
		}

		return null;
	}

	public static void checkHorizontalLine(WebDriver driver,ExtentTest etest)
	{
		try
		{
            Articles.switchToArticleContainerFrame(driver);
			WebElement article_content_input=CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY);

			if(article_content_input.findElements(By.tagName("hr")).size()>0)
			{
				etest.log(Status.PASS,"Horizontal line was found in content editor after 'Insert Horizontal Line' button was clicked");
				result.put("ART45",true);
			}
			else
			{
				result.put("ART45",false);
				etest.log(Status.FAIL,"Horizontal line was NOT found in content editor after 'Insert Horizontal Line' button was clicked");
				TakeScreenshot.screenshot(driver,etest);
			}

			driver.switchTo().defaultContent();         
		}
		catch(Exception e)
		{
			driver.switchTo().defaultContent();
			throw e;
		}
	}

	public static void checkTextEmphasisInTextEditor(WebDriver driver,ExtentTest etest,String text_emphasis_type,String text,boolean isSelect)
	{
		String use_case=getTextEmphasisUsecase("EDITOR",text_emphasis_type,isSelect);


		if(!CommonUtil.isChecked(use_case,result))
		{
			String action=isSelect?"selected":"NOT selected";
			String pass_status=isSelect?"found":"NOT found";
			String fail_status=isSelect?"NOT found":"found";

			By text_container=null;

	        if(text_emphasis_type.equals(Articles.BOLD))
	        {
	            text_container=By.tagName("b");
	        }
	        else if(text_emphasis_type.equals(Articles.ITALIC))
	        {
	            text_container=By.tagName("i");
	        }
	        else if(text_emphasis_type.equals(Articles.UNDERLINE))
	        {
	            text_container=By.tagName("u");
	        }

			if(Articles.isTextFoundUnderGivenTag(driver,text,text_container)==isSelect)
			{
				result.put(use_case,true);
 				etest.log(Status.PASS,"Entered text '"+text+"' was "+pass_status+" in "+text_emphasis_type+" after "+text_emphasis_type+" option was "+action);
			}
			else
			{
				result.put(use_case,false);
				etest.log(Status.FAIL,"Entered text '"+text+"' was "+fail_status+" in "+text_emphasis_type+" after "+text_emphasis_type+" option was "+action);
				TakeScreenshot.screenshot(driver,etest);
			}
		}
	}
	
	public static void checkTextEmphasisArticlePreview(WebDriver driver,ExtentTest etest,String text_emphasis_type,String text,boolean isSelect,boolean isVisitorWindow)
	{
		String use_case_type=isVisitorWindow?"VISITOR":"PREVIEW";
		String use_case=getTextEmphasisUsecase(use_case_type,text_emphasis_type,isSelect);

		if(!CommonUtil.isChecked(use_case,result))
		{
			String action=isSelect?"selected":"NOT selected";
			String pass_status=isSelect?"found":"NOT found";
			String fail_status=isSelect?"NOT found":"found";
			String site=isVisitorWindow?"visitor side":"articles preview";

			By text_container=null;

	        if(text_emphasis_type.equals(Articles.BOLD))
	        {
	            text_container=By.tagName("b");
	        }
	        else if(text_emphasis_type.equals(Articles.ITALIC))
	        {
	            text_container=By.tagName("i");
	        }
	        else if(text_emphasis_type.equals(Articles.UNDERLINE))
	        {
	            text_container=By.tagName("u");
	        }

	        WebElement article_container=ArticlesVisitorSide.getArticlePreviewContainer(driver);

			if(Articles.isTextFoundUnderGivenTag(article_container,text,text_container)==isSelect)
			{
				result.put(use_case,true);
 				etest.log(Status.PASS,"Entered text '"+text+"' was "+pass_status+" in "+text_emphasis_type+" after "+text_emphasis_type+" option was "+action+" in "+site);
			}
			else
			{
				result.put(use_case,false);
				etest.log(Status.FAIL,"Entered text '"+text+"' was "+fail_status+" in "+text_emphasis_type+" after "+text_emphasis_type+" option was "+action+" in "+site);
				TakeScreenshot.screenshot(driver,etest);
			}
		}		
	}

	public static void checkIfLinkIsAdded(WebDriver driver,ExtentTest etest,String check_in,String text,String address,String subject)
	{
        String usecase=null;
        boolean isEmail=(subject!=null)?true:false;

		if(check_in.equals("EDITOR"))
		{
			usecase=isEmail?"ART59":"ART58";
		}
		else if(check_in.equals("VISITOR"))
		{
			usecase=isEmail?"ART63":"ART62";
		}
		else if(check_in.equals("PREVIEW"))
		{
			usecase=isEmail?"ART61":"ART60";
		}

		if(CommonUtil.isChecked(usecase,result))
		{
			return;
		}

        WebElement container=null;

        String expected_href=isEmail?"mailto:"+address+"?subject="+subject:address;

        try
        {
			if(check_in.equals("EDITOR"))
			{
				Articles.switchToArticleContainerFrame(driver);
				container=CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY);
			}
			else if(check_in.equals("PREVIEW") || check_in.equals("VISITOR"))
			{
				container=ArticlesVisitorSide.getArticlePreviewContainer(driver);
			}

	        result.put(usecase, Articles.isAnchorTagFoundInContainer(driver,container,etest,expected_href,text));
        }
        catch(Exception e)
        {
        	driver.switchTo().defaultContent();
        	throw e;
        }

        driver.switchTo().defaultContent();
	}

	public static void checkArticlesVoteContent(WebDriver visitor_driver,ExtentTest etest,int state)
	{
		/*
		state allowed values
		0 before voting
		1 after voting 
		2 after voting and reopening article
		*/

		String usecase=null;

		if(state==0)
		{
			usecase="ART105";
		}
		else if(state==1)
		{
			usecase="ART106";
		}
		else if(state==2)
		{
			usecase="ART107";
		}

		if(CommonUtil.isChecked(usecase,result))
		{
			return;
		}

		boolean isVotingContainerFound=CommonWait.isPresent(visitor_driver,ArticlesVisitorSide.VOTE_CONTAINER);

		if(state!=2 && isVotingContainerFound)
		{
			WebElement voting_container=CommonUtil.getElement(visitor_driver,ArticlesVisitorSide.VOTE_CONTAINER);
			String voting_container_text=voting_container.getText();
			String expected_voting_text=null;
			String state_description=null;

			if(state==0)
			{
				expected_voting_text=ArticlesVisitorSide.BEFORE_VOTING_TEXT;
				state_description="before";
			}
			else if(state==1)
			{
				expected_voting_text=ArticlesVisitorSide.AFTER_VOTING_TEXT;
				state_description="after";
			}

			boolean isTextFound=CommonUtil.checkStringContainsAndLog(expected_voting_text,voting_container_text,state_description+" voting text",etest);

			if(isTextFound)
			{
				result.put(usecase,true);
			}
			else
			{
				result.put(usecase,false);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		else if(state!=2 && !isVotingContainerFound)
		{
			throw new ZohoSalesIQRuntimeException("Voting container was not found. state : "+state);
		}

		else if(state==2 && !isVotingContainerFound)
		{
			result.put(usecase,true);
			etest.log(Status.PASS,"Voting container was not found after visitor voted and reopened the article.");
		}
		else if(state==2 && isVotingContainerFound)
		{
			result.put(usecase,false);
			etest.log(Status.FAIL,"Voting container was found after visitor voted and reopened the article.");
			TakeScreenshot.screenshot(visitor_driver,etest);
		}

	}

	public static void checkSortIconInUI(WebDriver driver,ExtentTest etest,String sort_order)
	{

		CommonUtil.mouseHover(driver,Articles.getArticlesTab(driver));
		CommonUtil.sleep(250);

		String usecase=null;

		if(sort_order.equals(Articles.SORT_DIR_ASCENDING))
		{
			usecase="UI323";
		}
		else if(sort_order.equals(Articles.SORT_DIR_DESCENDING))
		{
			usecase="UI324";
		}

        CommonSikuli.findInWholePage(driver,usecase+".png",usecase,etest);
	}
}
