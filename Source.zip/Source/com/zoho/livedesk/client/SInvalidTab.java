//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class SInvalidTab
{
    public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    
    private static String url = "";
    public static ExtentTest etest; 
    
    public static Hashtable invalidtab(WebDriver driver)
    {
        try
        {
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT1"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            url = ConfManager.requestURL();
            
            result.put("SSIT1",false);
            result.put("SSIT2",false);
            result.put("SSIT3",false);
            result.put("SSIT4",false);
            result.put("SSIT5",false);
            
            result.put("SSIT1", checkTab(driver,"settings_portal"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT2"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            result.put("SSIT2", checkTab(driver,"settings_leadscoring"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT3"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            //result.put("SSIT3", checkTab(driver,"settings_integration"));
            result.put("SSIT3", checkIntegTab(driver,"settings_integration"));
            
            ComplexReportFactory.closeTest(etest);


            Tab.clickSettings(driver);
            Tab.clickAutomation(driver);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT4"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            result.put("SSIT4", checkInnerTab(driver,"triggers"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT5"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            result.put("SSIT5", checkInnerTab(driver,"routingrules"));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT6"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            result.put("SSIT6", checkInnerTab(driver,"chatrouting"));
            
            ComplexReportFactory.closeTest(etest);


            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT7"));
            // ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            // result.put("SSIT7", checkInnerTab(driver,"callrouting"));
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSIT8"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Supervisor");

            result.put("SSIT8", checkInnerTab(driver,"chatmonitor"));
            
            ComplexReportFactory.closeTest(etest);
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.FATAL,"ErrorInvalidTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","InvalidTab","ErrorWhileCheckingInvalidtab",e);

            result.put("SSIT1",false);
            result.put("SSIT2",false);
            result.put("SSIT3",false);
            result.put("SSIT4",false);
            result.put("SSIT5",false);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorInvalidTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","InvalidTab","ErrorWhileCheckingInvalidtab",e);

            result.put("SSIT1",false);
            result.put("SSIT2",false);
            result.put("SSIT3",false);
            result.put("SSIT4",false);
            result.put("SSIT5",false);
        }
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    //check main tabs
    private static boolean checkTab(WebDriver driver,String tname)
    {
        try
        {
            Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue(tname))).click();
            
            Thread.sleep(1000);
            
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","InvalidTab:"+ResourceManager.getRealValue(tname),"TabIsPresent");

            return false;
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.PASS,ResourceManager.getRealValue(tname)+" is not present");

            return true;
        }
        catch(Exception e)
        {
            etest.log(Status.PASS,ResourceManager.getRealValue(tname)+" is not present");

            return true;
        }
    }
    
    //check inner tabs
    private static boolean checkInnerTab(WebDriver driver,String data_tab)
    {
        boolean isTabEnabledExpected=(data_tab.equals("chatmonitor"))?true:false;

        try
        {
            WebElement tab_header=CommonUtil.getElement(driver,By.cssSelector("[data-tab='"+data_tab+"']"));
            
            boolean isTabEnabled=!(tab_header.getAttribute("class").contains("disabled"));

            if(isTabEnabled==isTabEnabledExpected)
            {
                etest.log(Status.PASS,"Expected tab state was found for "+data_tab+" tab.");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Expected tab state was NOT found for "+data_tab+" tab.(Expected isEnabled:"+isTabEnabledExpected+" Actual isEnabled: "+isTabEnabled+")");
                TakeScreenshot.screenshot(driver,etest);
                return false;
            }   
        }
        catch(Exception e)
        {
            e.printStackTrace();
            etest.log(Status.FAIL,"Expected tab state was NOT found for "+data_tab+" tab.(Expected isEnabled:"+isTabEnabledExpected+")");
            TakeScreenshot.screenshot(driver,etest,e);
            return false;
        }
    }

    //check integration tabs
    private static boolean checkIntegTab(WebDriver driver,String mtname) throws InterruptedException
    {
        try
        {
            Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue(mtname))).click();
            
            Thread.sleep(3000);
            
            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();
            
            Thread.sleep(1000);
            
            String errtxt = driver.findElement(By.id("popupdiv")).findElement(By.id("popupdesc")).getText();
            
            System.out.println("Supervisor error Desc CRM : "+errtxt + "Equals : "+ResourceManager.getRealValue("crm_supervisorerror"));
            
            if(errtxt.contains(ResourceManager.getRealValue("crm_supervisorerror")))
            {
                driver.findElement(By.id("okbtn")).click();
                
                Thread.sleep(2000);
                
                Coordinates ord = ((Locatable)driver.findElement(By.xpath("//div[text()='Zoho Desk']"))).getCoordinates();
                
                ord.inViewPort();

                driver.findElement(By.xpath("//div[text()='Zoho Desk']")).click();
                
                Thread.sleep(1000);
                
                errtxt = driver.findElement(By.id("popupdiv")).findElement(By.id("popupdesc")).getText();
                
                System.out.println("Supervisor error Desc Supp : "+errtxt + "Equals : "+ResourceManager.getRealValue("crm_supervisorerror"));
                
                if(errtxt.contains(ResourceManager.getRealValue("crm_supervisorerror")))
                {
                    etest.log(Status.PASS,ResourceManager.getRealValue(mtname)+" is present");

                    driver.findElement(By.id("okbtn")).click();
                    
                    return true;
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","ValidTab:"+ResourceManager.getRealValue(mtname),"MismatchcontentOnZohoDesk:"+ResourceManager.getRealValue("crm_supervisorerror"));

                }
            }
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","InvalidTab:"+ResourceManager.getRealValue(mtname),"Mismatchcontent:"+ResourceManager.getRealValue("crm_supervisorerror"));

            driver.findElement(By.id("okbtn")).click();
            
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","ValidTab:"+ResourceManager.getRealValue(mtname),"Error",e);

            driver.navigate().refresh();
            Thread.sleep(6000);

            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Supervisor","ValidTab:"+ResourceManager.getRealValue(mtname),"Error",e);

            driver.navigate().refresh();
            Thread.sleep(6000);
            
            return false;
        }
    }
}
