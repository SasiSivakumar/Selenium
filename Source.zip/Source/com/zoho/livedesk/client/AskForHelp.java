//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.google.common.base.Function;

import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.util.common.Functions;

public class AskForHelp
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    public static ExtentTest etest;
	public static String url = "";
	public static final String MODULE_NAME = "Ask For Help";

	public static Hashtable askforhelp(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            System.out.println("<<< Ask for help 1 >>");
			url = ConfManager.requestURL();
			
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AFH1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			try
			{
				Functions.closeBannersAfterLogin(driver);
			}
			catch(Exception e){}

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("hdrprt")));

			driver.findElement(By.id("hdrdrpdwntop")).click();
            
            Thread.sleep(1000);
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			result.put("AFH1", false);

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_askforhelp")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("AFH1")+" is Checked");
					result.put("AFH1", true);
				}
			}
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AFH2"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("AFH2", isWindowAvail(driver,etest));
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AFH3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("AFH3", closeWindow(driver,etest));
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Fields in Ask For Help");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Hashtable values = new Hashtable();
			values.put("Name", getUserName(driver));
			values.put("Phone", "232323221");
			values.put("Subject", "Ask for help");
			values.put("Description", "Queries on the product");
			editFields(driver, values,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
            System.out.println("~~Module breakage occurred");
			result.put("AFH1", false);
		}
		catch(Exception e)
		{
            System.out.println("~~Module breakage occurred");
			result.put("AFH1", false);
		}

		driver.navigate().refresh();

		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	private static boolean isWindowAvail(WebDriver driver,ExtentTest etest)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_askforhelp")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("pfeedback"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement header = form.findElement(By.className("modal-header"));
					if((header.getText()).contains(ResourceManager.getRealValue("common_askforhelp")))
					{
						WebElement submit = form.findElement(By.className("lv-ftr")).findElement(By.tagName("span"));
						if(((submit.getText()).equals(ResourceManager.getRealValue("common_submit"))) && (submit.getAttribute("type")).equals("submit"))
						{
							header.findElement(By.className("sqico-close")).click();
							etest.log(Status.PASS,KeyManager.getRealValue("AFH2")+" is Checked");
							return true;
						}
					}
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Exception while checking if ask for help window is available : "+e);
			e.printStackTrace();
		}
		catch(Exception e)
		{
            System.out.println("Exception while checking if ask for help window is available : "+e);
            e.printStackTrace();
		}
		return false;
	}

	private static boolean closeWindow(WebDriver driver,ExtentTest etest)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_askforhelp")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("pfeedback"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement header = form.findElement(By.className("modal-header"));
					header.findElement(By.className("sqico-close")).click();

					try
					{
						driver.findElement(By.id("pfeedback")).click();
					}
					catch(Exception exp)
					{
						etest.log(Status.PASS,KeyManager.getRealValue("AFH3")+" is Checked");
						return true;
					}
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Exception while trying to close the ask for help window : "+e);
			e.printStackTrace();
		}
		catch(Exception e)
		{
            System.out.println("Exception while trying to close the ask for help window : "+e);
            e.printStackTrace();
		}
		return false;
	}

	private static void editFields(WebDriver driver, Hashtable values,ExtentTest etest)
	{
		try
		{
			result.put("AFH4", false);
			result.put("AFH5", false);
			result.put("AFH6", false);
			result.put("AFH7", false);
			result.put("AFH8", false);
			result.put("AFH9", false);
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));
			int i = 5;

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_askforhelp")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("pfeedback"));
					WebElement form = window.findElement(By.tagName("form"));

					WebElement fld = form.findElement(By.className("lv-fedbktmn"));
					List<WebElement> fields = fld.findElements(By.className("lv-fedbkmn"));
					
					for(WebElement field:fields)
					{
						String fieldname = field.findElement(By.className("lvfedbk-lft")).getText();
						WebElement fieldval = field.findElement(By.className("lvfedbk-rht"));

						if(fieldname.equals(ResourceManager.getRealValue("common_name")))
						{
							if((fieldval.findElement(By.tagName("span")).getText()).equals(values.get(fieldname)))
							{
								etest.log(Status.PASS,KeyManager.getRealValue("AFH4")+" is Checked");
								result.put("AFH4", true);
							}
						}
						else if((fieldname.equals(ResourceManager.getRealValue("common_phone"))) || (fieldname.equals(ResourceManager.getRealValue("common_subject"))) || (fieldname.equals(ResourceManager.getRealValue("common_desc"))))
						{
							String key = "AFH"+i;
							WebElement inp;
							if(fieldname.equals(ResourceManager.getRealValue("common_desc")))
							{
								inp = fieldval.findElement(By.tagName("textarea"));
							}
							else
							{
								inp = fieldval.findElement(By.tagName("input"));
							}
							inp.click();
							inp.clear();
							inp.sendKeys(""+values.get(fieldname));
							Thread.sleep(1000);
							etest.log(Status.PASS,KeyManager.getRealValue(key)+" is Checked");
							result.put(key, true);
							form.click();
							i++;
						}
						else if(fieldname.equals(ResourceManager.getRealValue("askforhelp_status")))
						{
							WebElement selectbox = fieldval.findElement(By.id("severity"));
							List<WebElement> options = selectbox.findElements(By.tagName("option"));
							int j=9;
							for(WebElement opt:options)
							{
								String val="AFH"+j;
								Thread.sleep(1000);
								opt.click();
								Thread.sleep(1000);
								j++;
								if(j == 13)
								{
									etest.log(Status.PASS,KeyManager.getRealValue("AFH9")+" is Checked");
									result.put("AFH9", true);
								}
							}
						}
						else
						{
							if((fieldval.getText()).contains(ResourceManager.getRealValue("common_attachfile")))
							{
								etest.log(Status.PASS,KeyManager.getRealValue("AFH8")+" is Checked");
								result.put("AFH8", true);
							}
						}
					}

					WebElement header = form.findElement(By.className("modal-header"));
					header.findElement(By.className("sqico-close")).click();

					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Exception while checking if the fields are clickable and editable in ask for help window : "+e);
			e.printStackTrace();
		}
		catch(Exception e)
		{
            System.out.println("Exception while checking if the fields are clickable and editable in ask for help window : "+e);
            e.printStackTrace();
		}
	}

	private static String getUserName(WebDriver driver)
	{
		String knownas = "";
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings")));

            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_myprofile"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
			WebElement elmt = driver.findElement(By.id("userdetails"));
			List<WebElement> userdetails = elmt.findElements(By.tagName("div"));
            for(WebElement ele:userdetails)
            {
                List<WebElement> ells= ele.findElements(By.tagName("div"));
                knownas = ells.get(1).getText();
                break;
            }
			//knownas = userdetails.get(1).findElement(By.tagName("h2")).getText();
            System.out.println("USERNAME ------------------------------------"+knownas);
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while getting username in ask for help window : "+e);
            e.printStackTrace();
        }
		catch(Exception e)
		{
            System.out.println("Exception while getting username in ask for help window : "+e);
            e.printStackTrace();
        }
		return knownas;
	}
}

