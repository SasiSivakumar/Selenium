//$Id$
package com.zoho.livedesk.client;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


import com.google.common.base.Function;

public class WebEmbedSettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
    public static ExtentTest etest;
    public static String embedname = "chatops";

	public static Hashtable webembedSettings(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW1"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			url = ConfManager.requestURL();
			
            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

			result.put("SW1", true);
			etest.log(Status.PASS,"WebEmbed Tab is present");

            ComplexReportFactory.closeTest(etest);
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW2"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW2", isPageAvail(driver));

			ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW3"));
//			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
//
//			result.put("SW3", addWebEmbed(driver, "Embedname1", "Allow visitor to select department"));
//
//			ComplexReportFactory.closeTest(etest);
//
//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW4"));
//			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
//
//			result.put("SW4", addWebEmbed(driver,"Embedname2","Automation"));
//
//			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW5"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW5", disableWebEmbed(driver,embedname));

			ComplexReportFactory.closeTest(etest);
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW6"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW6", enableWebEmbed(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW7"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW7", editWaitingTime(driver, embedname,"45 seconds"));

			ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest("Configure Messages In WebEmbedSettings Page");
//			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
//
//			configureMessages(driver, embedname);
//
//			ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW8"));
//			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
//
//			result.put("SW8", configureWelcomeMsg(driver, embedname,"Configure welcome message"));
//
//			ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW9"));
//			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
//
//			result.put("SW9", configureRestrictURL(driver,embedname));
//
//			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW10"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW10", webEmbedFloatCode(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW11"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW11", webEmbedCode(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW12"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW12", webEmbedChatCode(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW13"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW13", personalisedChatCode(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW14"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW14", enableSignatureChat(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW15"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW15", disableSignatureChat(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW16"));
			ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW16", sendToWebMaster(driver,embedname));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Disable ChatWindowActions And Check");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
            
            disableChatWindowActions(driver,embedname);
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest("Enable ChatWindowActions And Check");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

            enableChatWindowActions(driver,embedname);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable ChatWindow VisitorInfo and Mandatory And Check");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
            
            enableWindowVisInfo1(driver,embedname);
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest("Disable ChatWindow VisitorInfo And Check");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

            disableWindowVisInfo(driver,embedname);

			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest("Enable ChatWindow VisitorInfo And Check");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
            
            enableWindowVisInfo2(driver,embedname);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW17"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");

			result.put("SW17", floatButtonAlignment(driver,embedname,"topright"));

			ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SW18"));
//            ComplexReportFactory.setValues(etest,"Automation","Web Embed Settings");
//
//            result.put("SW18", deleteWebEmbed(driver,"Embedname2"));
//			ComplexReportFactory.closeTest(etest);

        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorWebEmbedTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WebEmbedTab","ErrorWebEmbedTab",e);

			result.put("SW1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorWebEmbedTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WebEmbedTab","ErrorWebEmbedTab",e);

			result.put("SW1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check Web embed Settings Header
	private static boolean isPageAvail(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);
            
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));

			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));

            System.out.println(text.get(0).getText()+"  --------  "+text.get(1).getText());

			if(((text.get(0).getText()).equals(ResourceManager.getRealValue("setting_webembed_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("setting_webembed_desc2"))))
		 	{
				etest.log(Status.PASS,"WebEmbed Description is Verified");

                return true;
			}
			etest.log(Status.FAIL,"WebEmbed Description is Mismatched");
        }
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WebEmbedPage","ErrorWhileCheckingWebEmbedPageAvailable",e);
            System.out.println("Exception while checking if web embed settings page is available : "+e);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WebEmbedPage","ErrorWhileCheckingWebEmbedPageAvailable",e);
            System.out.println("Exception while checking if web embed settings page is available : "+e);
			return false;
		}
		TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WebEmbedPage","MismatchWebEmbedDescriptionContent");

		return false;
	}

	//Add Web Embed
	public static boolean addWebEmbed(WebDriver driver, String embed, String department)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Thread.sleep(1000);
			
            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);
            
		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonembedadd")));

		 	driver.findElement(By.id("buttonembedadd")).click();

            Thread.sleep(1000);
		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emname")));

		 	driver.findElement(By.id("emname")).click();
		 	driver.findElement(By.id("emname")).clear();
		 	driver.findElement(By.id("emname")).sendKeys(embed);

            Thread.sleep(500);

			driver.findElement(By.id("departmentselect_div")).click();
			WebElement select = driver.findElement(By.id("departmentselect_ddown"));
			List<WebElement> lis=select.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
				WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(department))
				{
					element.click();
					break;
				}
			}

			Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("ipsavebtn"))).getLocation().y+")");

			driver.findElement(By.id("ipsavebtn")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Generated successfully",null,etest);

			return checkAddedEmbed(driver, embed, department);
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","AddEmbed","ErrorWhileAddingWebEmbed",e);
            System.out.println("Exception while adding web embed in web embed settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","AddEmbed","ErrorWhileAddingWebEmbed",e);
            System.out.println("Exception while adding web embed in web embed settings page : "+e);
			return false;
		}
	}

	//Check added embed
	private static boolean checkAddedEmbed(WebDriver driver, String id, String department)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

			WebElement elmt1 = driver.findElement(By.id("embedlist"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				if(data.equals(id))
				{
					List<WebElement> em = elmt.findElements(By.tagName("em"));
					if(department.equals(em.get(2).getText()))
					{
						etest.log(Status.PASS,"Added WebEmbed is Verified");

                		return true;
					}
				}
			}
			etest.log(Status.FAIL,"Added WebEmbed is not present");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckAddedWebEmbed","AddedWebEmbedIsNotListed");
			return false;
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while checking added web embed in web embed settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckAddedWebEmbed","ErrorWhileCheckingAddedWebEmbed",e);
			return false;
        }
		catch(Exception e)
		{
            System.out.println("Exception while checking added web embed in web embed settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckAddedWebEmbed","ErrorWhileCheckingChatCodeInAddedWebEmbed",e);
			return false;
        }

	}

	//Disable embed
    private static boolean disableWebEmbed(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnstsupd")));

            if("false".equals(driver.findElement(By.id("btnstsupd")).getAttribute("stid")))
            {
                driver.findElement(By.id("btnstsupd")).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("btnstsupd")).getAttribute("stid")).equals("true"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                Thread.sleep(1000);
            }

            driver.findElement(By.id("btnstsupd")).click();

            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("btnstsupd")).getAttribute("stid")).equals("false"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            if("true".equals(driver.findElement(By.id("btnstsupd")).getAttribute("stid")))
            {
            	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableWebEmbed","WebEmbedIsNotDisabled");

                return false;
            }

            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

            WebElement elmt1 = driver.findElement(By.id("embedlist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                if(data.equals(embedname) && elmt.getAttribute("class").contains("list_disable"))
                {
                    etest.log(Status.PASS,"WebEmbed is disabled");

                    return true;
                }
            }
            etest.log(Status.FAIL,"WebEmbed is not disabled");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableWebEmbed","WebEmbedIsNotDisabled");
			return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while disabling added web embed in web embed settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableWebEmbed","ErrorWhileDisablingAddedWebEmbed",e);
			return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while disabling added web embed in web embed settings page : "+e);
        	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableWebEmbed","ErrorWhileDisablingAddedWebEmbed",e);
			return false;
        }
    }

    //Enable web embed
    private static boolean enableWebEmbed(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnstsupd")));

            if("true".equals(driver.findElement(By.id("btnstsupd")).getAttribute("stid")))
            {
                driver.findElement(By.id("btnstsupd")).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("btnstsupd")).getAttribute("stid")).equals("false"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                Thread.sleep(1000);
            }

            driver.findElement(By.id("btnstsupd")).click();

            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("btnstsupd")).getAttribute("stid")).equals("true"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            if("false".equals(driver.findElement(By.id("btnstsupd")).getAttribute("stid")))
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableWebEmbed","EmbedIsNotDisabled");

                return false;
            }

            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

            WebElement elmt1 = driver.findElement(By.id("embedlist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                if(data.equals(embedname) && elmt.getAttribute("class").contains("list_disable"))
                {
                	etest.log(Status.FAIL,"WebEmbed is not enabled");

                	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableWebEmbed","EmbedIsNotEnabled");

                    return false;
                }
            }
            etest.log(Status.PASS,"WebEmbed is enabled");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableWebEmbed","ErrorWhileEnablingWebEmbed",e);
            System.out.println("Exception while enabling added web embed in web embed settings page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableWebEmbed","ErrorWhileEnablingWebEmbed",e);
            System.out.println("Exception while enabling added web embed in web embed settings page : "+e);
            return false;
        }
    }

    //Delete web embed
    public static boolean deleteWebEmbed(WebDriver driver, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);
            
            WebElement elmt1 = driver.findElement(By.id("embedlist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                if(data.equals(value))
                {
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    mouseOver(driver,em.get(0));
                    em.get(0).click();
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                    driver.findElement(By.id("okbtn")).click();
                    break;
                }
            }

            Thread.sleep(3000);
			
            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

            if((driver.findElement(By.id("embedlist")).getText()).contains(value))
            {
            	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DeleteWebEmbed","DeletedWebEmbedIsPresent-"+value);

                return false;
            }
            etest.log(Status.PASS,"Deleted WebEmbed is not Listed");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DeleteWebEmbed","ErrorWhileDeletingAddedWebEmbed",e);

            System.out.println("Exception while deleting added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DeleteWebEmbed","ErrorWhileDeletingAddedWebEmbed",e);

            System.out.println("Exception while deleting added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    //Mouse Over for hidden element
    public static void mouseOver1(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).perform();
    }

	//change waiting time
	public static boolean editWaitingTime(WebDriver driver,String embedname, String waitingtime)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedhdertxt")));

		 	//driver.findElement(By.id("ewtime")).click();
            mouseOver(driver,(driver.findElement(By.id("ewtime"))));
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_edit"))).click();
            new Select(driver.findElement(By.xpath(".//select[@id='wtime'][@class='embedit-select']"))).selectByVisibleText(waitingtime);
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

          Tab.waitForLoadingLine(driver);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedhdertxt")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ewtime")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ewtime")));

            String time = driver.findElement(By.id("ewtime")).getText();

		    if(waitingtime.equals(time))
		    {
		    	etest.log(Status.PASS,"Edited Waiting Time is Verified");

                return true;
		    }

		    etest.log(Status.FAIL,"Edited Waiting Time is mismatch.Expected:"+waitingtime+"--Actual:"+time+"--");

		    TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditWaitingTime","MismatchEditedWaitingTime");
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditWaitingTime","ErrorWhileEditingWaitingTime",e);

            System.out.println("Exception while editing waiting time in added web embed in web embed settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditWaitingTime","ErrorWhileEditingWaitingTime",e);

            System.out.println("Exception while editing waiting time in added web embed in web embed settings page : "+e);
        }
		return false;
	}

	//Configure messages
	public static void configureMessages(WebDriver driver, String embedname)
	{
		try
		{
			configureMsg(driver, embedname, "ewaitingmsg", "waitingmsg", "Waiting message");
			result.put("SW19", checkConfigureMsg(driver, embedname, "ewaitingmsg", "Waiting message"));

			configureMsg(driver, embedname, "eofflinemsg", "offlinemsg", "Offline message");
			result.put("SW20", checkConfigureMsg(driver, embedname, "eofflinemsg", "Offline message"));

			configureMsg(driver, embedname, "ebusymsg", "busymsg", "Busy message");
			result.put("SW21", checkConfigureMsg(driver, embedname, "ebusymsg", "Busy message"));

			configureMsg(driver, embedname, "ethanksmsg", "thanksmsg", "Thanks message");
			result.put("SW22", checkConfigureMsg(driver, embedname, "ethanksmsg", "Thanks message"));

			configureMsg(driver, embedname, "eofflinerespmsg", "offlinerespmsg", "Offline Response message");
			result.put("SW23", checkConfigureMsg(driver, embedname, "eofflinerespmsg", "Offline Response message"));

			configureMsg(driver, embedname, "ebusyrespmsg", "busyrespmsg", "Busy Response message");
			result.put("SW24", checkConfigureMsg(driver, embedname, "ebusyrespmsg", "Busy Response message"));

			configureMsg(driver, embedname, "eengagedmsg", "engagedmsg", "Operator Engaged. Try later");
			result.put("SW53", checkConfigureMsg(driver, embedname, "eengagedmsg", "Operator Engaged. Try later"));

			configureMsg(driver, embedname, "eengagedrespmsg", "engagedrespmsg", "Operator Engaged message");
			result.put("SW54", checkConfigureMsg(driver, embedname, "eengagedrespmsg", "Operator Engaged message"));
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while editing configure messages in added web embed in web embed settings page : "+e);
        }
		catch(Exception e)
		{
            System.out.println("Exception while editing configure messages in added web embed in web embed settings page : "+e);
        }
	}

	//Check Configure messages
    private static boolean checkConfigureMsg(WebDriver driver, String embedname, String id, String message)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("webembed_configuremessages"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("webembed_configuremessages"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));

            String msg = driver.findElement(By.id(id)).getText();

            if(msg.equals(message))
            {
            	etest.log(Status.PASS,"ConfigureMessages-"+message+" is Verified");
                return true;
            }
            etest.log(Status.FAIL,"ConfigureMessages-"+message+" is Failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","MismatchConfiguredMessage"+message);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileCheckingConfiguredMessageFor"+message,e);

            System.out.println("Exception while checking configure messages in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileCheckingConfiguredMessageFor"+message,e);

            System.out.println("Exception while checking configure messages in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Configure messages
    private static void configureMsg(WebDriver driver, String embedname, String id, String txtid, String message)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("webembed_configuremessages"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("webembed_configuremessages"))).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

            driver.findElement(By.id(id)).click();
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_edit"))).click();
            driver.findElement(By.id(txtid)).click();
            driver.findElement(By.id(txtid)).clear();
            driver.findElement(By.id(txtid)).sendKeys(message);
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(1000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditConfigureMessages","ErrorWhileEditingConfigureMessagesFor"+message,e);

            System.out.println("Exception while editing configure messages in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditConfigureMessages","ErrorWhileEditingConfigureMessagesFor"+message,e);

            System.out.println("Exception while editing configure messages in added web embed in web embed settings page : "+e);
        }
    }

    //Configure welcome message
    private static boolean configureWelcomeMsg(WebDriver driver, String embedname,String message)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cegreet")));

            mouseOver(driver, driver.findElement(By.id("cegreet")));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_edit"))).click();

            WebElement elmt = driver.findElement(By.id("segreet")).findElement(By.tagName("textarea"));
            elmt.click();
            elmt.clear();
            elmt.sendKeys(message);//"Configure welcome message");
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Tab.waitForLoadingLine(driver);

            Thread.sleep(2000);
			
            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cegreet")));

            if(message.equals(driver.findElement(By.id("egreet")).getText()))
            {
            	etest.log(Status.PASS,"ConfigureMessage-Welcome is verified");

                return true;
            }
            etest.log(Status.FAIL,"ConfigureMessage-Welcome is Mismatched");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","configureMessage-Welcome","MismatchConfiguredWelcomeMessage");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessage-Welcome","ErrorWhileConfiguringWelcomeMessage",e);

            System.out.println("Exception while configuring welcome message in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages-Welcome","ErrorWhileConfiguringWelcomeMessage",e);

            System.out.println("Exception while configuring welcome message in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Configure restrict url
    private static boolean configureRestrictURL(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("erestr")));

            mouseOver(driver, driver.findElement(By.id("erestr")));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_edit"))).click();

            WebElement elmt = driver.findElement(By.id("serestr")).findElement(By.tagName("input"));
            elmt.click();
            elmt.clear();
            elmt.sendKeys("http://www.restricturl.com");

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Tab.waitForLoadingLine(driver);

            Thread.sleep(2000);
			
            Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("erestr")));

            if("http://www.restricturl.com".equals(driver.findElement(By.id("erestr")).getText()))
            {
                etest.log(Status.PASS,"RestrictURL is verified");

                return true;
            }
            etest.log(Status.FAIL,"RestrictURL is failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditRestrictURL","MismatchEditedRestrictURL");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditRestrictURL","ErrorWhileEditingRestrictedURL",e);

            System.out.println("Exception while checking restrict url in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EditRestrictURL","ErrorWhileEditingRestrictedURL",e);

            System.out.println("Exception while checking restrict url in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //check float code
    private static boolean webEmbedFloatCode(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fltsnippet")));

            String floatcode = driver.findElement(By.id("fltsnippet")).getAttribute("value");
            
            System.out.println("webEmbedFloatCode<>"+floatcode+"<>");

            if(floatcode.contains("float.ls") && floatcode.contains(embedname.toLowerCase()))
            {
                etest.log(Status.PASS,"WebEmbedFloat is verified");

                return true;
            }
            etest.log(Status.FAIL,"WebEmbedFloat Code is failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","FloatCodeInAddedWebEmbed","MismatchFloatcodeInAddedWebEmbed");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","FloatCodeInAddedWebEmbed","ErrorWhileCheckingFloatCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking float code in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","FloatCodeInAddedWebEmbed","ErrorWhileCheckingFloatCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking float code in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //check embed code
    private static boolean webEmbedCode(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btsnippet")));

            String floatcode = driver.findElement(By.id("btsnippet")).getAttribute("value");
            
            System.out.println("webEmbedCode<>"+floatcode+"<>");

            if(floatcode.contains("button.ls") && floatcode.contains(embedname.toLowerCase()))
            {
                etest.log(Status.PASS,"WebEmbedCode is verified");

                return true;
            }
            etest.log(Status.FAIL,"WebEmbedCode is failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ButtonCodeInAddedWebEmbed","MismatchButtonCodeInAddedWebEmbed");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ButtonCodeInAddedWebEmbed","ErrorWhileCheckingButtonCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking button code in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ButtonCodeInAddedWebEmbed","ErrorWhileCheckingButtonCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking button code in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Web embed chat code check
    private static boolean webEmbedChatCode(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chsnippet")));

            String floatcode = driver.findElement(By.id("chsnippet")).getAttribute("value");

            System.out.println("webEmbedChatCode<>"+floatcode+"<>");
            
            if(floatcode.contains("chat.ls") && floatcode.contains(embedname.toLowerCase()))
            {
                etest.log(Status.PASS,"WebEmbedChatCode is verified");

                return true;
            }
            etest.log(Status.FAIL,"WebEmbedChatCode is failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatCodeInWebEmbed","MismatchChatCodeInAddedWebEmbed");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatCodeInWebEmbed","ErrorWhileCheckingChatCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking chat code in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatCodeInWebEmbed","ErrorWhileCheckingChatCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking chat code in added web embed in web embed settings page : "+e);
        }
        return false;
    }


    //check personalised chat code
    private static boolean personalisedChatCode(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("personalizesnippet")));

            String floatcode = driver.findElement(By.id("personalizesnippet")).getAttribute("value");

            System.out.println("personalisedChatCode<>"+floatcode+"<>");
            
            if(floatcode.contains("agentschat.ls") && floatcode.contains(embedname.toLowerCase()))
            {
                etest.log(Status.PASS,"PersonalisedChatCode is verified");

                return true;
            }
            etest.log(Status.FAIL,"PersonalizedChatCode is failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","PersonalisedChatCode","MismatchPersonalizedChatCodeInAddedWebEmbed");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","PersonalisedChatCode","ErrorWhileCheckingPersonalizedChatCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking personalised chat code in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","PersonalisedChatCode","ErrorWhileCheckingPersonalizedChatCodeInAddedWebEmbed",e);

            System.out.println("Exception while checking personalised chat code in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //enable Signature chat
    private static boolean enableSignatureChat(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cesignaturechat")));

            if((driver.findElement(By.id("cesignaturechat")).getText()).contains(ResourceManager.getRealValue("common_disabled")))
            {
                driver.findElement(By.id("cesignaturechat")).click();
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_edit"))).click();
                driver.findElement(By.id("signaturechat")).click();
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("cesignaturechat")).getAttribute("style")).contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                Thread.sleep(1000);
            }
            if((driver.findElement(By.id("cesignaturechat")).getText()).contains(ResourceManager.getRealValue("common_enabled")))
            {
                String floatcode = driver.findElement(By.id("schtmlcode")).getAttribute("value");
                
                System.out.println("enableSignatureChat<>"+floatcode+"<>");
                
                if(floatcode.contains("signature.ls") && floatcode.contains(embedname.toLowerCase()))
                {
                    String imgcode = driver.findElement(By.id("scimgcode")).getAttribute("value");
                    String linkcode = driver.findElement(By.id("sclinkcode")).getAttribute("value");
                    String loginurl = Util.siteNameout()+"/"+"chatops";//ConfManager.getLoginURL();
                    
                    System.out.println("enableSignatureChat<>"+loginurl+"<>");
                    System.out.println("enableSignatureChat<>"+imgcode+"<>");
                    System.out.println("enableSignatureChat<>"+linkcode+"<>");
                    
                    loginurl = loginurl.replace("livedesk","salesiq");
                    //loginurl = loginurl.replace("automation",ConfManager.getWEportal());
                    if(imgcode.contains("signature.ls") && imgcode.contains("&t=1") && linkcode.contains(loginurl+"/support"))
                    {
                        System.out.println("Comes here 11124412");
                        etest.log(Status.PASS,"SignatureLinkAndImageCode is verified");

                        return true;
                    }
                    etest.log(Status.FAIL,"SignatureLinkAndImageCode is Mismatched");
					TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SignatureLinkAndImageCode","MismatchSignatureLinkOrImageCodeInAddedWebEmbed");
                }
                else{
                	etest.log(Status.FAIL,"SignatureChatCode is Mismatched");
                	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SignatureLinkAndImageCode","MismatchSignatureChatCodeInAddedWebEmbed");
                }
            }
            else{
            	etest.log(Status.PASS,"ContentInChatSignatureEnableButton is Mismatched");
            	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SignatureLinkAndImageCode","MismatchContentInChatSignatureEnableButton");
            }
            System.out.println("Comes here 111555");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SignatureLinkAndImageCode","ErrorWhileEnablingSignatureChat",e);

            System.out.println("Exception while enabling signature chat in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SignatureLinkAndImageCode","ErrorWhileEnablingSignatureChat",e);

            System.out.println("Exception while enabling signature chat in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //diable Signature chat
    private static boolean disableSignatureChat(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cesignaturechat")));

            if((driver.findElement(By.id("cesignaturechat")).getText()).contains(ResourceManager.getRealValue("common_enabled")))
            {
                driver.findElement(By.id("cesignaturechat")).click();
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_edit"))).click();
                driver.findElement(By.id("signaturechat")).click();
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("cesignaturechat")).getAttribute("style")).contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                Thread.sleep(1000);
            }
            if((driver.findElement(By.id("cesignaturechat")).getText()).contains(ResourceManager.getRealValue("common_disabled")))
            {
                etest.log(Status.PASS,"DisableSignatureChat is verified");

                return true;
            }
            etest.log(Status.PASS,"DisableSignatureChat is failed");

            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableSignatureChat","MismatchContentAfterDisablingSignatureChat");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableSignatureChat","ErrorWhileDisablingSignatureChatInAddedWebEmbed",e);

            System.out.println("Exception while disabling signature chat in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableSignatureChat","ErrorWhileDisablingSignatureChatInAddedWebEmbed",e);

            System.out.println("Exception while disabling signature chat in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Send code to web master
    private static boolean sendToWebMaster(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fltsnippet")));

            String code_snippet=driver.findElement(By.id("fltsnippet")).getAttribute("value");

            WebElement elmt = driver.findElement(By.className("flt-embdbtnprvmn"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("a"))).getLocation().y+"-400)");

            elmt.findElement(By.tagName("a")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sendmailembedcode")));

            if((driver.findElement(By.id("sendmailembedcode")).getText()).contains(ResourceManager.getRealValue("webembed_sendtowebmasterheading")))
            {
                driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='ze_area']")));
                String script = driver.findElement(By.tagName("blockquote")).getText();

                System.out.println("sendToWebMaster"+script+"<>");
                System.out.println("sendToWebMaster"+code_snippet+"<>");

                if(code_snippet.equals(script))
                {
                    driver.switchTo().defaultContent();
                    WebElement dialogbox = driver.findElement(By.id("dlgbox"));
                    driver.findElement(By.id("toemail")).sendKeys("rajkumar.natarajan+automation@zohocorp.com");
                    driver.findElement(By.id("sendmailembedcode")).click();
                    dialogbox.findElement(By.className("cnfmbtm")).click();
					Tab.waitForLoadingSuccessWithBanner(driver,"Mail sent successfully","shareembedcode.do",etest);
                    etest.log(Status.PASS,"SentToWebMaster is verified");

                    return true;
                }
                else{
                	etest.log(Status.FAIL,"FloatCode in SentToWebMasterWindow is matched");
                	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SentToWebMaster","MismatchFloatCodeinSentToWebMasterWindow");
                }
            }
            else{
            	etest.log(Status.FAIL,"Mismatch Heading");
            	TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SentToWebMaster","MismatchSentToWebmasterHeading");
            }
            driver.switchTo().defaultContent();
            driver.findElement(By.id("sendmailembedcode")).findElement(By.cssSelector("div.mrgnlft_twenty[onclick='CommonUtil.closeDialog()']")).click();

            Thread.sleep(1000);

            return false;

        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SentToWebMaster","ErrorWhileCheckingSentToWebmaster",e);

            System.out.println("Exception while checking send to webmaster in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","SentToWebMaster","ErrorWhileCheckingSentToWebmaster",e);

            System.out.println("Exception while checking send to webmaster in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //change chat window appearance
    private static void enableChatWindowActions(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("caddem2")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            if(driver.findElement(By.id("hdrcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4).click();

                Thread.sleep(1000);

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("hdrcnfg")).getAttribute("style")).contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }

            enableActions(driver, "cprint");
            enableActions(driver, "cmail");
            enableActions(driver, "cfile");
            enableActions(driver, "cfeedback");
            enableActions(driver, "csound");
            enableActions(driver, "clogo");
            enableActions(driver, "cphoto");
            enableActions(driver, "caddress");

            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("actn-btn-base"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("span"))).getLocation().y+"-400)");
            elmt.findElement(By.tagName("span")).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(2000);
            
            chooseEmbed(driver,embedname);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            if(driver.findElement(By.id("hdrcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("hdrcnfg")).getAttribute("style")).contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }

            result.put("SW25", checkChatWindowActions(driver,"enable","cprint"));
            result.put("SW26", checkChatWindowActions(driver,"enable","cmail"));
            result.put("SW27", checkChatWindowActions(driver,"enable","cfile"));
            result.put("SW28", checkChatWindowActions(driver,"enable","cfeedback"));
            result.put("SW29", checkChatWindowActions(driver,"enable","csound"));
            result.put("SW30", checkChatWindowActions(driver,"enable","clogo"));
            result.put("SW31", checkChatWindowActions(driver,"enable","cphoto"));
            result.put("SW32", checkChatWindowActions(driver,"enable","caddress"));
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableChatActionsInWebEmbedSettings","ErrorWhileCheckingEnableChatWindowActionsInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking enable chat window actions in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableChatActionsInWebEmbedSettings","ErrorWhileCheckingEnableChatWindowActionsInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking enable chat window actions in added web embed in web embed settings page : "+e);
        }
    }

    //Enable chat window appearance actions
    private static void enableActions(WebDriver driver, final String id)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(driver.findElement(By.id(id)).getAttribute("class").contains("embchk-yes"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("class")).contains("embchk-no"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            if(driver.findElement(By.id(id)).getAttribute("class").contains("embchk-no"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("class")).contains("embchk-yes"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableChatWindowActions-"+id,"ErrorWhileEnablingChatWindowActionsFor"+id,e);

            System.out.println("Exception while enabling chat window actions in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableChatWindowActions-"+id,"ErrorWhileEnablingChatWindowActionsFor"+id,e);

            System.out.println("Exception while enabling chat window actions in added web embed in web embed settings page : "+e);
        }
    }

    //change chat window appearance
    private static void disableChatWindowActions(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("caddem2")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addem2")));

            if(driver.findElement(By.id("hdrcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("hdrcnfg")).getAttribute("style")).contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }

            disableActions(driver, "cprint");
            disableActions(driver, "cmail");
            disableActions(driver, "cfile");
            disableActions(driver, "cfeedback");
            disableActions(driver, "csound");
            disableActions(driver, "clogo");
            disableActions(driver, "cphoto");
            disableActions(driver, "caddress");

		 	WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("actn-btn-base"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("span"))).getLocation().y+"-400)");

            elmt.findElement(By.tagName("span")).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(2000);
            
            chooseEmbed(driver,embedname);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addem2")));

            if(driver.findElement(By.id("hdrcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(4).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("hdrcnfg")).getAttribute("style")).contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }

            result.put("SW33", checkChatWindowActions(driver,"disable","cprint"));
            result.put("SW34", checkChatWindowActions(driver,"disable","cmail"));
            result.put("SW35", checkChatWindowActions(driver,"disable","cfile"));
            result.put("SW36", checkChatWindowActions(driver,"disable","cfeedback"));
            result.put("SW37", checkChatWindowActions(driver,"disable","csound"));
            result.put("SW38", checkChatWindowActions(driver,"disable","clogo"));
            result.put("SW39", checkChatWindowActions(driver,"disable","cphoto"));
            result.put("SW40", checkChatWindowActions(driver,"disable","caddress"));
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableChatWindowActions","ErrorWhileCheckingDisableChatWindowActionsInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking disable chat window actions in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableChatWindowActions","ErrorWhileCheckingDisableChatWindowActionsInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking disable chat window actions in added web embed in web embed settings page : "+e);
        }
    }

    //disable chat window appearance actions
    private static void disableActions(WebDriver driver, final String id)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(driver.findElement(By.id(id)).getAttribute("class").contains("embchk-no"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("class")).contains("embchk-yes"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            if(driver.findElement(By.id(id)).getAttribute("class").contains("embchk-yes"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("class")).contains("embchk-no"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableChatWindowActions-"+id,"ErrorWhileDisablingChatWindowActionsFor"+id,e);

            System.out.println("Exception while disabling chat window actions in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableChatWindowActions-"+id,"ErrorWhileDisablingChatWindowActionsFor"+id,e);

            System.out.println("Exception while disabling chat window actions in added web embed in web embed settings page : "+e);
        }
    }

    //Check chat window appearance actions
    private static boolean checkChatWindowActions(WebDriver driver, String status, String id)
    {
        try
        {
            Thread.sleep(1000);

            if(status.equals("enable"))
	            if((status.equals("enable")) && driver.findElement(By.id(id)).getAttribute("class").contains("embchk-yes"))
	            {
	                etest.log(Status.PASS,"Enable Chat Window Actions For "+id+" is Verified");

	                return true;
	            }
	            else{
	            	etest.log(Status.FAIL,"Enable Chat Window Actions For "+id+" is failed");

	                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckEnableChatWindowActionFor-"+id,"MismatchEnabledStatusFor"+id);
	            }
	        if(status.equals("disable"))
	            if((status.equals("disable")) && driver.findElement(By.id(id)).getAttribute("class").contains("embchk-no"))
	            {
	            	etest.log(Status.PASS,"Disable Chat Window Actions For "+id+" is Verified");

	                return true;
	            }
	            else{
	            	etest.log(Status.FAIL,"Disable Chat Window Actions For "+id+" is failed");

	                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDisableChatWindowActionFor-"+id,"MismatchDisabledStatusFor"+id);
	            }

        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckStatusChatWindowActionFor-"+id,"ErrorWhileCheckingStatusForAction-"+id,e);

            System.out.println("Exception while checking chat window actions in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckStatusChatWindowActionFor-"+id,"ErrorWhileCheckingStatusForAction-"+id,e);

            System.out.println("Exception while checking chat window actions in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Chat window Visitor Informations
    private static void enableWindowVisInfo1(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("caddem2")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();

                Thread.sleep(2000);
                /*wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });*/
            }

            enableChatVisInfo(driver, "ishowname");
            enableChatVisInfo(driver, "ishowemail");
            enableChatVisInfo(driver, "ishowphone");
            enableChatVisInfo(driver, "namemandatory");
            enableChatVisInfo(driver, "emailmandatory");
            enableChatVisInfo(driver, "phonemandatory");

            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("actn-btn-base"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("span"))).getLocation().y+"-400)");

            elmt.findElement(By.tagName("span")).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(2000);

            chooseEmbed(driver,embedname);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();

                Thread.sleep(2000);
                /*wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });*/
            }

            result.put("SW41", checkChatWindowVisInfo(driver,"enable","ishowname"));
            result.put("SW42", checkChatWindowVisInfo(driver,"enable","ishowemail"));
            result.put("SW43", checkChatWindowVisInfo(driver,"enable","ishowphone"));
            result.put("SW44", checkChatWindowVisInfo(driver,"enable","namemandatory"));
            result.put("SW45", checkChatWindowVisInfo(driver,"enable","emailmandatory"));
            result.put("SW46", checkChatWindowVisInfo(driver,"enable","phonemandatory"));
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableVisInfoInWebEmbedSettings","ErrorWhileCheckingEnableVisitorInfoInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking enable visitor information in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableVisInfoInWebEmbedSettings","ErrorWhileCheckingEnableVisitorInfoInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking enable visitor information in added web embed in web embed settings page : "+e);
        }
    }

    //Chat window Visitor Informations
    private static void enableWindowVisInfo2(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("caddem2")));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("caddem2")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));
            
            if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");
                
                driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();
                
                Thread.sleep(2000);
                /*wait.until(new Function<WebDriver,Boolean>()
                 {
                 public Boolean apply(WebDriver driver)
                 {
                 if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("block"))
                 {
                 return true;
                 }
                 return false;
                 }
                 });*/
            }
            
            enableChatVisInfo(driver, "ishowname");
            enableChatVisInfo(driver, "ishowemail");
            enableChatVisInfo(driver, "ishowphone");
//            enableChatVisInfo(driver, "namemandatory");
//            enableChatVisInfo(driver, "emailmandatory");
//            enableChatVisInfo(driver, "phonemandatory");
            
            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("actn-btn-base"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("span"))).getLocation().y+"-400)");
            
            elmt.findElement(By.tagName("span")).click();
            
            Tab.waitForLoadingLine(driver);
            Thread.sleep(2000);
            
            chooseEmbed(driver,embedname);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("caddem2")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));
            
            if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");
                
                driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();
                
                Thread.sleep(2000);
                /*wait.until(new Function<WebDriver,Boolean>()
                 {
                 public Boolean apply(WebDriver driver)
                 {
                 if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("block"))
                 {
                 return true;
                 }
                 return false;
                 }
                 });*/
            }
            
            result.put("SW41", checkChatWindowVisInfo(driver,"enable","ishowname"));
            result.put("SW42", checkChatWindowVisInfo(driver,"enable","ishowemail"));
            result.put("SW43", checkChatWindowVisInfo(driver,"enable","ishowphone"));
//            result.put("SW44", checkChatWindowVisInfo(driver,"enable","namemandatory"));
//            result.put("SW45", checkChatWindowVisInfo(driver,"enable","emailmandatory"));
//            result.put("SW46", checkChatWindowVisInfo(driver,"enable","phonemandatory"));
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableVisInfoInWebEmbedSettings","ErrorWhileCheckingEnableVisitorInfoInWebEmbedSettingsPage",e);
            
            System.out.println("Exception while checking enable visitor information in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableVisInfoInWebEmbedSettings","ErrorWhileCheckingEnableVisitorInfoInWebEmbedSettingsPage",e);
            
            System.out.println("Exception while checking enable visitor information in added web embed in web embed settings page : "+e);
        }
    }

    //Chat window Visitor Informations
    private static void disableWindowVisInfo(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("caddem2")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");
            Thread.sleep(500);

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));
            Thread.sleep(500);

            if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");

                Thread.sleep(500);

                driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();

                Thread.sleep(2000);
                /*wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });*/
            }

            disableChatVisInfo(driver, "ishowname");
            disableChatVisInfo(driver, "ishowemail");
            disableChatVisInfo(driver, "ishowphone");

            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("actn-btn-base"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("span"))).getLocation().y+"-400)");

            elmt.findElement(By.tagName("span")).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(2000);

            chooseEmbed(driver,embedname);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));
            if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("none"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");

                driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();

                Thread.sleep(2000);
                /*wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("vcnfg")).getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                        return false;
                    }
                });*/
            }

            result.put("SW47", checkChatWindowVisInfo(driver,"disable","ishowname"));
            result.put("SW48", checkChatWindowVisInfo(driver,"disable","ishowemail"));
            result.put("SW49", checkChatWindowVisInfo(driver,"disable","ishowphone"));
            result.put("SW50", checkChatWindowVisInfo(driver,"disable","namemandatory"));
            result.put("SW51", checkChatWindowVisInfo(driver,"disable","emailmandatory"));
            result.put("SW52", checkChatWindowVisInfo(driver,"disable","phonemandatory"));
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableVisInfoInWebEmbedSettings","ErrorWhileCheckingDisableVisitorInfoInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking disable visitor information in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableVisInfoInWebEmbedSettings","ErrorWhileCheckingDisableVisitorInfoInWebEmbedSettingsPage",e);

            System.out.println("Exception while checking disable visitor information in added web embed in web embed settings page : "+e);
        }
    }

    //Check chat window visitor informations
    private static boolean checkChatWindowVisInfo(WebDriver driver, String status, String id)
    {
        try
        {
            Thread.sleep(1000);

            if(status.equals("enable"))
	            if((status.equals("enable")) && driver.findElement(By.id(id)).getAttribute("checked") !=null)
	            {
	                etest.log(Status.PASS,"Enable Chat Window VisitorInfo For "+id+" is Verified");

	                return true;
	            }
	            else{
	            	etest.log(Status.FAIL,"Enable Chat Window VisitorInfo For "+id+" is Failed");

	                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableChatWindowVisInfoFor"+id,"MismatchEnabledStatusFor"+id);
				}
			if(status.equals("disable"))
	            if((status.equals("disable")) && driver.findElement(By.id(id)).getAttribute("checked") == null)
	            {
	                etest.log(Status.PASS,"Disable Chat Window VisitorInfo For "+id+" is Verified");

	                return true;
	            }
	            else{
	            	etest.log(Status.FAIL,"Disable Chat Window VisitorInfo For "+id+" is Failed");

	                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableChatWindowVisInfoFor"+id,"MismatchDisabledStatusFor"+id);
	            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckStatusForChatWindowVisInfoFor-"+id,"ErrorWhileCheckingStatusForAction"+id,e);

            System.out.println("Exception while checking chat window visitor information in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckStatusForChatWindowVisInfoFor"+id,"ErrorWhileCheckingStatusForAction"+id,e);

            System.out.println("Exception while checking chat window visitor information in added web embed in web embed settings page : "+e);
        }
        return false;
    }

    //Enable chat window visitor informations
    private static void enableChatVisInfo(WebDriver driver, final String id)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(driver.findElement(By.id(id)).getAttribute("checked") != null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("checked")) == null)
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            if(driver.findElement(By.id(id)).getAttribute("checked") == null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("checked")) != null)
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableVisInfoInWebEmbedSettingsFor"+id,"ErrorWhileEnablingVisitorInformationInWebEmbedSettingsPage",e);

            System.out.println("Exception while enabling visitor information in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","EnableVisInfoInWebEmbedSettingsFor"+id,"ErrorWhileEnablingVisitorInformationInWebEmbedSettingsPage",e);

            System.out.println("Exception while enabling visitor information in added web embed in web embed settings page : "+e);
        }
    }

    //Disable chat window visitor informations
    private static void disableChatVisInfo(WebDriver driver, final String id)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(driver.findElement(By.id(id)).getAttribute("checked") == null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("checked")) != null)
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            if(driver.findElement(By.id(id)).getAttribute("checked") != null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                driver.findElement(By.id(id)).click();

                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id(id)).getAttribute("checked")) == null)
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableVisInfoInWebEmbedSettingsFor"+id,"ErrorWhileDisablingVisitorInformationInWebEmbedSettingsPage",e);

            System.out.println("Exception while disabling visitor information in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableVisInfoInWebEmbedSettingsFor"+id,"ErrorWhileDisablingVisitorInformationInWebEmbedSettingsPage",e);

            System.out.println("Exception while disabling visitor information in added web embed in web embed settings page : "+e);
        }
    }

    //Change button alignment
    private static boolean floatButtonAlignment(WebDriver driver, String embedname, String align)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            chooseEmbed(driver,embedname);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("caddem3")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem3"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem3")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addem3")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fltposition")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("fltposition"))).getLocation().y+"-400)");

            WebElement select = driver.findElement(By.id("fltposition"));
            Select dropDown = new Select(select);
            List<WebElement> Options = dropDown.getOptions();
            for(WebElement option:Options)
            {
                if((option.getAttribute("value")).equals(align))
                {
                    option.click();
                }
            }


            WebElement elmt = driver.findElement(By.id("addem3")).findElement(By.className("actn-btn-base"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.tagName("span"))).getLocation().y+"-400)");

            elmt.findElement(By.tagName("span")).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(2000);

            chooseEmbed(driver,embedname);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem3"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem3")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addem3")));

            if(align.equals(driver.findElement(By.id("fltposition")).getAttribute("value")))
            {
                etest.log(Status.PASS,"FloatButtomAlignment is Verified");

                return true;
            }
            else{
            	etest.log(Status.FAIL,"FloatButtomAlignment is Mismatched");

                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","FloatButtomAlignment","MismatchAlign");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","FloatButtomAlignment","ErrorWhileCheckingFloatButtonAlignment",e);

            System.out.println("Exception while checking float button alignment in added web embed in web embed settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","FloatButtomAlignment","ErrorWhileCheckingFloatButtonAlignment",e);

            System.out.println("Exception while checking float button alignment in added web embed in web embed settings page : "+e);
        }
        return false;
    }

	//clear web embed
	public static boolean clearWebEmbed(WebDriver driver)
	{
		try
		{
			deleteWebEmbed(driver,"Embedname1");
			deleteWebEmbed(driver,"Embedname2");
			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ClearWebEmbed","ErrorWhileClearingDataInWebEmbed",e);

            System.out.println("Exception while clearing data in web embed settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ClearWebEmbed","ErrorWhileClearingDataInWebEmbed",e);

            System.out.println("Exception while clearing data in web embed settings page : "+e);
        }
		return false;
	}
    
    public static WebDriver chooseEmbed(WebDriver driver,String emname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Functions.createTabAndCloseCurrent(driver);
            Tab.navToEmbedTab(driver);
            
            List<WebElement> elists = driver.findElement(By.id("embedlist")).findElements(By.className("list-row"));
            
            Thread.sleep(1000);
            
            for(WebElement elist:elists)
            {
                Thread.sleep(500);
                
                if((elist.findElement(By.className("list_cell")).getText()).equals(emname))
                {
                    elist.findElement(By.className("list_cell")).click();
                    
                    Thread.sleep(1000);
                    
                    break;
                }
            }
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embeddetail")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embeddetail")));
            
            Thread.sleep(1000);
            
            return driver;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChooseEmbed","ErrorWhileChoosingEmbed",e);
            
            System.out.println("Exception while choosing embed in real time float widget check : " + e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChooseEmbed","ErrorWhileChoosingEmbed",e);
            
            System.out.println("Exception while choosing embed in real time float widget check : " + e);
        }
        return driver;
    }
}
