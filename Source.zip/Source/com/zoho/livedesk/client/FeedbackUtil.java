//$Id$
package com.zoho.livedesk.client;

import java.util.*;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.*;
import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;


public class FeedbackUtil
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	public static Hashtable<String,String> dept_visitor = new Hashtable<String,String>();
	public static Hashtable<String,String> embed_visitor = new Hashtable<String,String>();
	public static Set<WebDriver> visDrivers = new HashSet();
    public static Boolean notCancel = false;
	public static String embed = "embed_fb";
	public static String portal = "ldautomation12";
	public static String dept = "ldautomation12";
	public static String dept2 = "Department2";
	public static String embed1 = "embed_fb";
	public static String embed2 = "embed_fb2";
	public static String user_name = "Admin1";
	public static String user_name2 = "Supervisor1";
	private static final String[] numNames = {"",	"one",	"two",	"three",	"four","five"};

	public static ExtentTest etest;

	public static Hashtable fdk(WebDriver driver) throws Exception
	{
		try
		{
			etest=ComplexReportFactory.getTest("Portat setup for feedback module");
			ComplexReportFactory.setValues(etest,"Automation","Feedback");
			Websites.selectAllowVisitorsToChooseDepartment(driver,etest,embed1);
			Websites.selectAllowVisitorsToChooseDepartment(driver,etest,embed2);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}

        notCancel = false;
		WebDriver driver2 = null;
		embed = embed1;

		try
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB1"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      driver2 = Functions.setUp();
			Functions.login(driver2,"feedback2");

			result = new Hashtable();
			dept_visitor = new Hashtable();
			dept_visitor.put(dept,"No visitor");
			dept_visitor.put(dept2,"No visitor");
			embed_visitor = new Hashtable();
			embed_visitor.put(embed1,"No visitor");
			embed_visitor.put(embed2,"No visitor");

      Tab.clickFeedback(driver);
      result.put("FB1",true);
			etest.log(Status.PASS,"Checked");

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB2"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB2",isPageAvail(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB3"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

			embed = embed2;
      result.put("FB3",checkFeedback(driver,4,true));
			embed = embed1;

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB4"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB4",checkFeedback(driver,2,false));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB25"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

			result.put("FB25",checkEmbedInFilter(driver,embed1,""+embed_visitor.get(embed1),""+embed_visitor.get(embed2)));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB26"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB26",checkEmbedInFilter(driver,embed2,""+embed_visitor.get(embed2),""+embed_visitor.get(embed1)));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB27"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB27",checkEmbedInFilter(driver,"All",""+embed_visitor.get(embed1)+","+embed_visitor.get(embed2),""));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB5"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB5",checkSideWindow(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB6"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB6",checkSideWindow(driver,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB11"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB11",checkDept(driver,dept));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB12"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB12",checkDept(driver,dept2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB21"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB21",checkMyFeedback(driver,user_name,user_name2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB18"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB18",checkUserInFilter(driver,user_name,user_name,user_name2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB19"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB19",checkUserInFilter(driver,user_name2,user_name2,user_name));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB20"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB20",checkUserInFilter(driver,"All",user_name+","+user_name2,""));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB22"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB22",checkDeptInFilter(driver,dept,""+dept_visitor.get(dept),""+dept_visitor.get(dept2)));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB23"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB23",checkDeptInFilter(driver,dept2,""+dept_visitor.get(dept2),""+dept_visitor.get(dept)));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB24"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB24",checkDeptInFilter(driver,"All",""+dept_visitor.get(dept)+","+dept_visitor.get(dept2),""));

			ComplexReportFactory.closeTest(etest);

            notCancel = true;
			checkFeedbackResponse(driver);
            notCancel = false;
            
			checkRatingInFilter(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB17"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB17",checkRatingInFilter(driver,"All","star-1,star-2,star-3,star-4,star-5",""));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB7"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB7",checkWithOutEmail(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB8"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB8",checkChatTab(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB9"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB9",checkNotesTab(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB10"));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB10",checkReturningVisitor(driver));

            Functions.logout(driver2);
            
            ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"Feedback","Tab","Error",e);
			result.put("FB1",false);
		}

		ComplexReportFactory.closeTest(etest);
		closeDriver();
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	public static boolean isPageAvail(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			Tab.clickFeedback(driver);
			final WebElement div = CommonUtil.elfinder(driver,"id","feedback_div");
			String header = CommonUtil.elementfinder(driver,div,"tagname","h1").getText();
			WebElement myfdb = CommonUtil.elementfinder(driver,div,"id","hismysupport");
			WebElement filter = CommonUtil.elementfinder(driver,div,"id","cushistoryfilter");
			final WebElement export = CommonUtil.elementfinder(driver,div,"id","expdrpdown");
			if(!header.equals("Feedback"))
			{
				etest.log(Status.FAIL,"Mismatch content:Expected:"+header+"--Actual:"+header+"--");
				TakeScreenshot.screenshot(driver,etest,"Feedback","Page","Error");
				return false;
			}
			if(myfdb == null)
			{
				etest.log(Status.FAIL,"My Feedback is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","Page","Error");
				return false;
			}
			if(filter == null)
			{
				etest.log(Status.FAIL,"Filter is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","Page","Error");
				return false;
			}
			if(export == null)
			{
				etest.log(Status.FAIL,"Export is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","Page","Error");
				return false;
			}

			WebElement fdb = CommonUtil.elementfinder(driver,div,"classname","un-sel");
			String column1 = Feedback.getDetails(driver,fdb,"secnd-clm","div");
			String column2 = Feedback.getDetails(driver,fdb,"thrd-clm","div");
			String column3 = Feedback.getDetails(driver,fdb,"four-clm","div");

			if(!(column1.equals("Name & Email Address") && column2.equals("Feedback & Time") && column3.equals("Owner")))
			{
				etest.log(Status.FAIL,"Expected:Name & Email Address--Feedback & Time--Owner--Actual:"+column1+"--"+column2+"--"+column3+"--");
				TakeScreenshot.screenshot(driver,etest,"Feedback","Page","Error");
				return false;
			}

			CommonUtil.elementfinder(driver,export,"classname","combodrparw").click();
			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(export.findElement(By.id("expdrpdowncntnt")).getAttribute("style").contains("block"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });
      List<WebElement> list = export.findElements(By.tagName("li"));
      if(list.get(0).getText().equals("Export as .xlsx") && list.get(1).getText().equals("Export as .csv"))
      {
      	CommonUtil.elementfinder(driver,export,"classname","combodrparw").click();
				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(export.findElement(By.id("expdrpdowncntnt")).getAttribute("style").contains("none"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });
      	etest.log(Status.PASS,"Checked");
      	return true;
      }

      etest.log(Status.FAIL,"Expected:Export as .xlsx--Export as .csv--Actual:"+list.get(0)+"--"+list.get(1)+"--");
      TakeScreenshot.screenshot(driver,etest,"Feedback","Page","Error");
      CommonUtil.elementfinder(driver,export,"classname","combodrparw").click();
			wait.until(new Function<WebDriver,Boolean>(){
          public Boolean apply(WebDriver driver)
          {
              if(export.findElement(By.id("expdrpdowncntnt")).getAttribute("style").contains("none"))
              {
                  return true;
              }
              return false;
          }
      });
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","Tab","Error",e);
		}
		return false;
	}

	public static boolean checkFeedback(WebDriver driver,int star,boolean fdbcontent) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());

			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			String agentMsg = "A"+t;
			String vismsg = "VM"+t;

			if(!initiateAndEnd(driver,visDriver,t,star,fdbcontent))
			{
				return false;
			}
			if(!fdbcontent)
			{
				fdb = "No Feedback given";
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
			Tab.clickFeedback(driver);
			WebElement div = Feedback.getFeedbackDiv(driver,0);
			//secnd-clm  h2 a thrd-clm pre span
			String name = Feedback.getDetails(driver,div,"secnd-clm","h2");
			String email = Feedback.getDetails(driver,div,"secnd-clm","a");
			String feedback = Feedback.getDetails(driver,div,"thrd-clm","pre");
			String time = Feedback.getDetails(driver,div,"thrd-clm","span");
			String user = Feedback.getUserName(driver,div);
			String rating = Feedback.getStar(driver,div);
            
            if(star > 3)
            {
                star = 3 - (star - 3);
            }
            else if(star < 3)
            {
                star = 3 + (3 - star);
            }

			String actual[] = {name,email,feedback,user,rating};
			String expected[] = {vname,vemail,fdb,user_name," star-"+star};

			for(int i = 0;i<actual.length;i++)
			{
				if(!actual[i].equals(expected[i]))
				{
					etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEnteredValue","Error");
					return false;
				}
			}

			embed_visitor.put(embed,vname);
			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEnteredValue","Error",e);
		}
		return false;
	}

	public static boolean checkSideWindow(WebDriver driver) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver,visDriver,t,3,true))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			WebElement div = CommonUtil.elfinder(driver,"id","fdbckdetail");

			WebElement name = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vname);
			WebElement email = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vemail);

			if(name == null)
			{
				etest.log(Status.FAIL,vname+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(email == null)
			{
				etest.log(Status.FAIL,vemail+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			WebElement chat = Feedback.getFeedbackTabs(driver,"fdbckchattrans");
			WebElement notes = Feedback.getFeedbackTabs(driver,"fdbcknotes");
			WebElement reply = Feedback.getFeedbackTabs(driver,"fdbckvissct");
			WebElement enquireuser = Feedback.getFeedbackTabs(driver,"fdbckagentsct");

			if(chat == null)
			{
				etest.log(Status.FAIL,"Chat is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(notes == null)
			{
				etest.log(Status.FAIL,"Notes is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(reply == null)
			{
				etest.log(Status.FAIL,"Reply to visitor is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(enquireuser != null)
			{
				etest.log(Status.FAIL,"Enquire user is present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			Feedback.clickCloseInFeedback(driver);
			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error",e);
		}
		return false;
	}

	public static boolean checkSideWindow(WebDriver driver,WebDriver driver2) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver2,visDriver,t,3,true))
			{
				return false;
			}

			Tab.clickVisitorsOnline(driver);
            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			WebElement div = CommonUtil.elfinder(driver,"id","fdbckdetail");

			WebElement name = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vname);
			WebElement email = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vemail);

			if(name == null)
			{
				etest.log(Status.FAIL,vname+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(email == null)
			{
				etest.log(Status.FAIL,vemail+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			WebElement chat = Feedback.getFeedbackTabs(driver,"fdbckchattrans");
			WebElement notes = Feedback.getFeedbackTabs(driver,"fdbcknotes");
			WebElement reply = Feedback.getFeedbackTabs(driver,"fdbckvissct");
			WebElement enquireuser = Feedback.getFeedbackTabs(driver,"fdbckagentsct");

			if(chat == null)
			{
				etest.log(Status.FAIL,"Chat is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(notes == null)
			{
				etest.log(Status.FAIL,"Notes is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(reply == null)
			{
				etest.log(Status.FAIL,"Reply to visitor is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(enquireuser == null)
			{
				etest.log(Status.FAIL,"Enquire user is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			Feedback.clickCloseInFeedback(driver);
			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error",e);
		}
		return false;
	}

	public static boolean checkWithOutEmail(WebDriver driver) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver,visDriver,t,3,true,false))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			WebElement div = CommonUtil.elfinder(driver,"id","fdbckdetail");

			WebElement name = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vname);

			if(name == null)
			{
				etest.log(Status.FAIL,vname+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			WebElement chat = Feedback.getFeedbackTabs(driver,"fdbckchattrans");
			WebElement notes = Feedback.getFeedbackTabs(driver,"fdbcknotes");
			WebElement reply = Feedback.getFeedbackTabs(driver,"fdbckvissct");

			if(chat == null)
			{
				etest.log(Status.FAIL,"Chat is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(notes == null)
			{
				etest.log(Status.FAIL,"Notes is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(reply != null)
			{
				etest.log(Status.FAIL,"Reply to visitor is present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			Feedback.clickCloseInFeedback(driver);
			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckSideWindow","Error",e);
		}
		return false;
	}

	public static boolean checkChatTab(WebDriver driver) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver,visDriver,t,3,true))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdetail"),"id","displaydata");

			WebElement header = CommonUtil.elementfinder(driver,div,"classname","t-v-questionmn");

			String ques = CommonUtil.elementfinder(driver,header,"tagname","h1").getText();
			String visname = CommonUtil.elementfinder(driver,header,"id","chatvisname").getText();
			String visemail = CommonUtil.elementfinder(driver,header,"id","chatvisemail").getText();

			WebElement msgs = CommonUtil.elementfinder(driver,div,"id","msgtable");
			List<WebElement> list = msgs.findElements(By.tagName("tr"));
			String agent = list.get(0).findElements(By.tagName("td")).get(0).getText();
			String agent_msg = list.get(0).findElements(By.tagName("td")).get(1).getText();
			String visitor = list.get(1).findElements(By.tagName("td")).get(0).getText();
			String visitor_msg = list.get(1).findElements(By.tagName("td")).get(1).getText();

			String expected[] = {vname,vemail,question,user_name,"A"+t,vname,"VM"+t};
			String actual[] = {visname,visemail,ques,agent,agent_msg,visitor,visitor_msg};

			for(int i = 0; i < expected.length;i++)
			{
				if(!actual[i].contains(expected[i]))
				{
					etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckChatTab","Error");
					return false;
				}
			}

			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckChatTab","Error",e);
		}

		return false;
	}

	public static boolean checkNotesTab(WebDriver driver) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver,visDriver,t,star,true))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			Feedback.clickFeedbackTabs(driver,"fdbcknotes");

			WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdetail"),"id","notelist");

			List<WebElement> list = div.findElements(By.className("spt-ntsmn"));
			String content = CommonUtil.elementfinder(driver,list.get(0),"classname","nots-msg").getText();
			String fdbmsg = CommonUtil.elementfinder(driver,list.get(0),"classname","nots-submsg").getText();
			String rating = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,list.get(0),"classname","vist_fmsg"),"tagname","div").getAttribute("class");

			String actual[] = {content,fdbmsg,rating};
			String expected[] = {"Visitor has left a feedback message",fdb,"star-"+star};

			for(int i = 0; i < expected.length;i++)
			{
				if(!actual[i].contains(expected[i]))
				{
					etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckNotesTab","Error");
					return false;
				}
			}

			Feedback.clickCloseInFeedback(driver);
			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckNotesTab","Error",e);
		}

		return false;
	}

	public static boolean checkReturningVisitor(WebDriver driver) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			final Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			final String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver,visDriver,t,star,true))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			if(!initiateAndEnd(driver,visDriver,t,star,true,true,"Returning visitor feedback "+t))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,"Returning visitor feedback "+t);

			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","fdbckdetail"),"id","fblftcont");

			wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	            if(div.findElements(By.tagName("li")).size() == 2)
	            {
	                return true;
	            }
	            return false;
	        }
	    });

			List<WebElement> list = div.findElements(By.tagName("li"));

			list.get(1).click();

			wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	            if(driver.findElement(By.id("fdbckdetail")).findElement(By.tagName("h2")).getText().contains(fdb))
	            {
	                return true;
	            }
	            return false;
	        }
	    });

			list.get(0).click();

			wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	            if(driver.findElement(By.id("fdbckdetail")).findElement(By.tagName("h2")).getText().contains("Returning visitor feedback "+t))
	            {
	                return true;
	            }
	            return false;
	        }
	    });

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckReturningVisitor","Error",e);
		}

		return false;
	}

	public static boolean checkRatingInFilter(WebDriver driver,String filter,String present,final String notpresent) throws Exception
	{
		Hashtable values = new Hashtable();
		List<WebElement> list = null;
		try
		{
			if(!notpresent.equals(""))
			{
				String value1[] = notpresent.split(",");
				for(String s : value1)
				{
					values.put(s,false);
				}
			}
			if(!present.equals(""))
			{
				String value2[] = present.split(",");
				for(String s : value2)
				{
					values.put(s,false);
				}
			}
			Tab.clickSettings(driver);
			Tab.clickFeedback(driver);

			Feedback.selectFilter(driver,"rating",filter);

			if(!filter.equals("All"))
			{
				Feedback.waitTillFeedbackLoading(driver);

				Feedback.clickCloseInFilter(driver);

				list = Feedback.getFeedbacks(driver);

				for(WebElement e : list)
				{
					CommonUtil.inViewPort(e);
					String star = Feedback.getStar(driver,e);
					star = star.replace(" ","");
					System.out.println("<><>"+star+"<><>");
					
					CommonSikuli.findInWholePage(driver,CommonSikuli.getImageNameBasedstar(star),CommonSikuli.getKeyValueBasedstar(star),etest);

					if(!present.contains(star))
					{
						etest.log(Status.FAIL,present+" is expected."+star+" is present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckRatingInFilter","Error");
						return false;
					}
					if(notpresent.contains(star))
					{
						etest.log(Status.FAIL,notpresent+" is not expected."+star+" is present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckRatingInFilter","Error");
						return false;
					}
				}

				WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","fdata");

				String header = CommonUtil.elementfinder(driver,div,"css","div.fltrmn.sqico-filter").getText();

				CommonSikuli.findInWholePage(driver,"FBfilterpin.png","UI283",etest);
				CommonSikuli.findInWholePage(driver,"FBfilterclose.png","UI284",etest);
				
				if(!header.contains("Rating "+filter))
				{
					etest.log(Status.FAIL,"Expected:Rating "+filter+"--Actual:"+header+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckRatingInFilter","Error");
					return false;
				}

				CommonUtil.elementfinder(driver,div,"classname","fltrclgmn").click();

				FluentWait wait = CommonUtil.waitreturner(driver,10,250);
				wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {
		            if(driver.findElement(By.id("feedback_div")).findElement(By.id("fdata")).getAttribute("style").contains("none"))
		            {
		                return true;
		            }
		            return false;
		        }
		    });
			}
			Feedback.waitTillFeedbackLoading(driver);

			if(filter.equals("All"))
			{
				Feedback.clickCloseInFilter(driver);
			}

			list = Feedback.getFeedbacks(driver);

			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				String star = Feedback.getStar(driver,e).replace(" ","");
				values.put(star,true);
			}

			System.out.println(values);
			Set<String> keys = values.keySet();
      for(String key: keys){
        if(!((boolean)values.get(key)))
				{
					etest.log(Status.FAIL,key+" is not present after removing filter");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckRatingInFilter","Error");
					return false;
				}
      }

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckRatingInFilter","Error",e);
		}

		return false;
	}

	public static boolean checkUserInFilter(WebDriver driver,String filter,String present,final String notpresent) throws Exception
	{
		Hashtable values = new Hashtable();
		List<WebElement> list = null;
		try
		{
			if(!notpresent.equals(""))
			{
				String value1[] = notpresent.split(",");
				for(String s : value1)
				{
					values.put(s,false);
				}
			}
			if(!present.equals(""))
			{
				String value2[] = present.split(",");
				for(String s : value2)
				{
					values.put(s,false);
				}
			}

			Tab.clickSettings(driver);
			Tab.clickFeedback(driver);

			Feedback.selectFilter(driver,"sagent",filter);

			if(!filter.equals("All"))
			{
				Feedback.waitTillFeedbackLoading(driver);

				Feedback.clickCloseInFilter(driver);

				list = Feedback.getFeedbacks(driver);

				for(WebElement e : list)
				{
					CommonUtil.inViewPort(e);
					String user = Feedback.getUserName(driver,e);
					System.out.println("<><>"+user+"<><>");
					if(!present.contains(user))
					{
						etest.log(Status.FAIL,present+" is expected."+user+" is present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckOperatorInFilter","Error");
						return false;
					}
					if(notpresent.contains(user))
					{
						etest.log(Status.FAIL,notpresent+" is not expected."+user+" is present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckOperatorInFilter","Error");
						return false;
					}
				}

				WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","fdata");

				String header = CommonUtil.elementfinder(driver,div,"css","div.fltrmn.sqico-filter").getText();

				if(!header.contains(filter))
				{
					etest.log(Status.FAIL,"Expected:"+filter+"--Actual:"+header+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckUserInFilter","Error");
					return false;
				}

				CommonUtil.elementfinder(driver,div,"classname","fltrclgmn").click();

				FluentWait wait = CommonUtil.waitreturner(driver,10,250);
				wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {
		            if(driver.findElement(By.id("feedback_div")).findElement(By.id("fdata")).getAttribute("style").contains("none"))
		            {
		                return true;
		            }
		            return false;
		        }
		    });
			}
			Feedback.waitTillFeedbackLoading(driver);

			if(filter.equals("All"))
			{
				Feedback.clickCloseInFilter(driver);
			}

			list = Feedback.getFeedbacks(driver);

			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				String user = Feedback.getUserName(driver,e);
				values.put(user,true);
			}

			System.out.println(values);
			Set<String> keys = values.keySet();
      for(String key: keys){
        if(!((boolean)values.get(key)))
				{
					etest.log(Status.FAIL,key+" is not present after removing filter");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckOperatorInFilter","Error");
					return false;
				}
      }

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckOperatorInFilter","Error",e);
		}

		return false;
	}

	public static boolean checkMyFeedback(WebDriver driver,String present,final String notpresent) throws Exception
	{
		Hashtable values = new Hashtable();
		List<WebElement> list = null;
		try
		{
			if(!notpresent.equals(""))
			{
				String value1[] = notpresent.split(",");
				for(String s : value1)
				{
					values.put(s,false);
				}
			}
			if(!present.equals(""))
			{
				String value2[] = present.split(",");
				for(String s : value2)
				{
					values.put(s,false);
				}
			}

			Tab.clickSettings(driver);
			Tab.clickFeedback(driver);
            
            TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","Before",0);
            
			Feedback.clickMyFeedback(driver);

            Feedback.waitTillFeedbackLoading(driver);

            TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","After",0);
            
			list = Feedback.getFeedbacks(driver);

			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				String user = Feedback.getUserName(driver,e);
				System.out.println("<><>"+user+"<><>");
				if(!present.contains(user))
				{
					etest.log(Status.FAIL,present+" is expected."+user+" is present");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","Error");
                    
                    Thread.sleep(10000);
                    TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","After2",0);
                    
                    return false;
				}
				if(notpresent.contains(user))
				{
					etest.log(Status.FAIL,notpresent+" is not expected."+user+" is present");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","Error");
                    
                    Thread.sleep(10000);
                    TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","After2",0);
                    
                    return false;
				}
			}
            
            WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","fdata");

			String header = CommonUtil.elementfinder(driver,div,"css","div.fltrmn.sqico-filter").getText();

			if(!header.contains(present))
			{
				etest.log(Status.FAIL,"Expected:"+present+"--Actual:"+header+"--");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","Error");
				return false;
			}

			Feedback.clickMyFeedback(driver);

			Feedback.waitTillFeedbackLoading(driver);

			list = Feedback.getFeedbacks(driver);

			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				String user = Feedback.getUserName(driver,e);
				values.put(user,true);
			}

			System.out.println(values);
			Set<String> keys = values.keySet();
			for(String key: keys){
				if(!((boolean)values.get(key)))
				{
					etest.log(Status.FAIL,key+" is not present after removing filter");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","Error");
					return false;
				}
			}

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckMyFeedback","Error",e);
		}

		return false;
	}

	public static boolean checkDept(WebDriver driver,String department) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			String vname = "V"+t;
			String vemail = "email@"+t+".com";
			String phone = "12345";
			String question = "Q"+t;
			String fdb = "F"+t;
			int star = 3;

			if(!initiateAndEnd(driver,visDriver,t,3,true,true,null,department))
			{
				return false;
			}

            Thread.sleep(5000);// It takes some time to update in Feedback
            Tab.clickFeedback(driver);

			Feedback.openFeedback(driver,fdb);

			WebElement div = CommonUtil.elfinder(driver,"id","fdbckdetail");

			WebElement name = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vname);
			WebElement email = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","lvsagnt_detailmn"),"linktext",vemail);

			if(name == null)
			{
				etest.log(Status.FAIL,vname+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartment","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			if(email == null)
			{
				etest.log(Status.FAIL,vemail+" is not present");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartment","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			CommonSikuli.findInWholePage(driver,"FBdepartment.png","UI281",etest);
			String d = CommonUtil.elementfinder(driver,div,"id","fdbckdpmt").getText();

			if(!d.equals(department))
			{
				etest.log(Status.FAIL,"Department mismatch.Expected:"+department+"--Actual:"+d+"--");
				TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartment","Error");
				Feedback.clickCloseInFeedback(driver);
				return false;
			}

			dept_visitor.put(department,vname);
			CommonSikuli.findInWholePage(driver,"FBclose.png","UI282",etest);
			Feedback.clickCloseInFeedback(driver);
			visDriver.quit();
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartment","Error",e);
		}
		return false;
	}

	public static boolean checkDeptInFilter(WebDriver driver,String filter,String present,String notpresent) throws Exception
	{
		Hashtable values = new Hashtable();
		try
		{
			if(present.equals("No visitor") || notpresent.equals("No visitor"))
			{
				etest.log(Status.FAIL,"Feedback - Department - Usecase failed");
				return false;
			}
			Tab.clickSettings(driver);
			Tab.clickFeedback(driver);

			Feedback.selectFilter(driver,"vdeptid",filter);

			if(!filter.equals("All"))
			{
				Feedback.waitTillFeedbackLoading(driver);

				Feedback.clickCloseInFilter(driver);

				WebElement page = CommonUtil.elfinder(driver,"id","feedback_div");

				if(!notpresent.equals(""))
				{
					String value1[] = notpresent.split(",");
					for(String s : value1)
					{
						if(page.getText().contains(s))
						{
							etest.log(Status.FAIL,s+" is present");
							TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartmentInFilter","Error");
							return false;
						}
					}
				}
				if(!present.equals(""))
				{
					String value2[] = present.split(",");
					for(String s : value2)
					{
						if(!page.getText().contains(s))
						{
							etest.log(Status.FAIL,s+" is not present");
							TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartmentInFilter","Error");
							return false;
						}
					}
				}

				WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","fdata");

				String header = CommonUtil.elementfinder(driver,div,"css","div.fltrmn.sqico-filter").getText();

				if(!header.contains(filter))
				{
					etest.log(Status.FAIL,"Expected:"+filter+"--Actual:"+header+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartmentInFilter","Error");
					return false;
				}

				CommonUtil.elementfinder(driver,div,"classname","fltrclgmn").click();

				FluentWait wait = CommonUtil.waitreturner(driver,10,250);
				wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {
		            if(driver.findElement(By.id("feedback_div")).findElement(By.id("fdata")).getAttribute("style").contains("none"))
		            {
		                return true;
		            }
		            return false;
		        }
		    });
			}
			Feedback.waitTillFeedbackLoading(driver);

			if(filter.equals("All"))
			{
				Feedback.clickCloseInFilter(driver);
			}

			WebElement page = CommonUtil.elfinder(driver,"id","feedback_div");

			if(!present.equals(""))
			{
				String values1[] = present.split(",");
				for(String s : values1)
				{
					if(!page.getText().contains(s))
					{
						etest.log(Status.FAIL,s+" is not present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartmentInFilter","Error");
						return false;
					}
				}
			}

			if(!present.equals(""))
			{
				String values2[] = notpresent.split(",");
				for(String s : values2)
				{
					if(!page.getText().contains(s))
					{
						etest.log(Status.FAIL,s+" is not present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartmentInFilter","Error");
						return false;
					}
				}
			}

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckDepartmentInFilter","Error",e);
		}

		return false;
	}

	public static boolean checkEmbedInFilter(WebDriver driver,String filter,String present,String notpresent) throws Exception
	{
		Hashtable values = new Hashtable();
		try
		{
			if(present.equals("No visitor") || notpresent.equals("No visitor"))
			{
				etest.log(Status.FAIL,"Feedback - Embed - Usecase failed");
				return false;
			}

			Tab.clickSettings(driver);
			Tab.clickFeedback(driver);

			Feedback.selectFilter(driver,"lsid",filter);

			if(!filter.equals("All"))
			{
				Feedback.waitTillFeedbackLoading(driver);

				Feedback.clickCloseInFilter(driver);

				WebElement page = CommonUtil.elfinder(driver,"id","feedback_div");

				if(!notpresent.equals(""))
				{
					String value1[] = notpresent.split(",");
					for(String s : value1)
					{
						if(page.getText().contains(s))
						{
							etest.log(Status.FAIL,s+" is present");
							TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEmbedInFilter","Error");
							return false;
						}
					}
				}
				if(!present.equals(""))
				{
					String value2[] = present.split(",");
					for(String s : value2)
					{
						if(!page.getText().contains(s))
						{
							etest.log(Status.FAIL,s+" is not present");
							TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEmbedInFilter","Error");
							return false;
						}
					}
				}

				WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","feedback_div"),"id","fdata");

				String header = CommonUtil.elementfinder(driver,div,"css","div.fltrmn.sqico-filter").getText();

				if(!header.contains(filter))
				{
					etest.log(Status.FAIL,"Expected:"+filter+"--Actual:"+header+"--");
					TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEmbedInFilter","Error");
					return false;
				}

				CommonUtil.elementfinder(driver,div,"classname","fltrclgmn").click();

				FluentWait wait = CommonUtil.waitreturner(driver,10,250);
				wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {
		            if(driver.findElement(By.id("feedback_div")).findElement(By.id("fdata")).getAttribute("style").contains("none"))
		            {
		                return true;
		            }
		            return false;
		        }
		    });
			}
			Feedback.waitTillFeedbackLoading(driver);

			if(filter.equals("All"))
			{
				Feedback.clickCloseInFilter(driver);
			}

			WebElement page = CommonUtil.elfinder(driver,"id","feedback_div");

			if(!present.equals(""))
			{
				String values1[] = present.split(",");
				for(String s : values1)
				{
					if(!page.getText().contains(s))
					{
						etest.log(Status.FAIL,s+" is not present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEmbedInFilter","Error");
						return false;
					}
				}
			}

			if(!present.equals(""))
			{
				String values2[] = notpresent.split(",");
				for(String s : values2)
				{
					if(!page.getText().contains(s))
					{
						etest.log(Status.FAIL,s+" is not present");
						TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEmbedInFilter","Error");
						return false;
					}
				}
			}

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckEmbedInFilter","Error",e);
		}

		return false;
	}

	public static WebDriver setUp() throws Exception
	{
		WebDriver d = Functions.setUp();
		visDrivers.add(d);
		return d;
	}

	public static void closeDriver() throws Exception
	{
		for(WebDriver d : visDrivers)
		{
			try
			{
				d.quit();
			}
			catch(Exception e){}
		}
	}

	public static boolean initiateAndEnd(WebDriver driver,WebDriver visDriver,Long t,int star,boolean fdbcontent) throws Exception
	{
		return initiateAndEnd(driver,visDriver,t,star,fdbcontent,true);
	}

	public static boolean initiateAndEnd(WebDriver driver,WebDriver visDriver,Long t,int star,boolean fdbcontent,boolean withemail) throws Exception
	{
		return initiateAndEnd(driver,visDriver,t,star,fdbcontent,withemail,null);
	}

	public static boolean initiateAndEnd(WebDriver driver,WebDriver visDriver,Long t,int star,boolean fdbcontent,boolean withemail,String feedbackmessage) throws Exception
	{
		return initiateAndEnd(driver,visDriver,t,star,fdbcontent,withemail,feedbackmessage,dept);
	}
	public static boolean initiateAndEnd(WebDriver driver,WebDriver visDriver,Long t,int star,boolean fdbcontent,boolean withemail,String feedbackmessage,String department) throws Exception
	{

		String vname = "V"+t;
		String vemail = "email@"+t+".com";
		String phone = "12345";
		String question = "Q"+t;
		String fdb = "F"+t;
		String agentMsg = "A"+t;
		String vismsg = "VM"+t;

		try
		{
            String WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			VisitorWindow.createPage(visDriver,WIDGET_CODE);
			if(withemail)
			{
				VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,phone,department,question,etest);
			}
			else
			{
				VisitorWindow.initiateChatVisTheme(visDriver,vname,null,phone,dept,question,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(visDriver,etest,"Feedback","CheckEnteredValue","Error",e);
			return false;
		}

		ChatWindow.acceptChat(driver,etest);
		ChatWindow.sentMessage(driver,agentMsg);
		try
		{
			VisitorWindow.checkAgentMessageInChatWindow(visDriver,user_name,agentMsg,1);
			VisitorWindow.sentMessageInTheme(visDriver,vismsg);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(visDriver,etest,"Feedback","CheckEnteredValue","Error",e);
			return false;
		}

		ChatWindow.checkMessageInUserWindow(driver,vname,vismsg);
		ChatWindow.endAndCloseChat(driver);

		try
		{
			if(fdbcontent)
			{
				if(feedbackmessage == null)
				{
                    fdb = notCancel?null:fdb;
                    
					VisitorWindow.enterFeedbackInTheme(visDriver,fdb,""+star,notCancel,etest);
				}
				else
				{
                    feedbackmessage = notCancel?null:feedbackmessage;
                    
                    VisitorWindow.enterFeedbackInTheme(visDriver,feedbackmessage,""+star,notCancel,etest);
				}
			}
			else
			{
				VisitorWindow.enterFeedbackInTheme(visDriver,null,""+star,notCancel,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(visDriver,etest,"Feedback","CheckEnteredValue","Error",e);
			return false;
		}

        return true;
	}

	public static boolean checkFeedbackResponse(WebDriver driver,int star) throws Exception
	{
		try
		{
			WebDriver visDriver = setUp();
			Long t = new Long(System.currentTimeMillis());
			if(!initiateAndEnd(driver,visDriver,t,star,true))
			{
				return false;
			}
			try
			{
                String actual = VisitorWindow.getInfoMessage(visDriver);
                
                if(star > 3)
                {
                    star = 3 - (star - 3);
                }
                else if(star < 3)
                {
                    star = 3 + (3 - star);
                }
                
                String expected = ResourceManager.getRealValue("feedback_response_star"+star);
				
                if(expected.equals(actual))
				{
					etest.log(Status.PASS,"Checked");
					visDriver.quit();
					return true;
				}
				etest.log(Status.FAIL,"Expected"+expected+"--Actual:"+actual+"--");
				TakeScreenshot.screenshot(visDriver,etest,"Feedback","CheckFeedbackResponse","Error");
				visDriver.quit();
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"Feedback","CheckFeedbackResponse","Error",e);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Feedback","CheckFeedbackResponse","Error",e);
		}

		return false;
	}

	public static void checkFeedbackResponse(WebDriver driver) throws Exception
	{
		for(int i = 1; i<=5;i++)
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB"+(35+i)));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB"+(35+i),checkFeedbackResponse(driver,i));

			ComplexReportFactory.closeTest(etest);
		}
	}

	public static void checkRatingInFilter(WebDriver driver) throws Exception
	{
		String values = "star-1,star-2,star-3,star-4,star-5";
		for(int i = 1; i<=5;i++)
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("FB"+(30+i)));
			ComplexReportFactory.setValues(etest,"Automation","Feedback");

      result.put("FB"+(30+i),checkRatingInFilter(driver,""+i,"star-"+i,values.replace(",star-"+i,"").replace("star-"+i+",","")));

			ComplexReportFactory.closeTest(etest);
		}
	}
}
