//$Id$
package com.zoho.livedesk.client.ZohoDesk;

import java.util.Hashtable;
import java.util.*;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;


public class ZohoDeskUtil
{	
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	public static Hashtable<String,String> search_visitor = new Hashtable();
		
	public static Hashtable<String,Set<WebDriver>> visitor_drivers_by_portal = new Hashtable();

	public static WebDriver d1,d2,d3,d4;

	public static final String DESK_ACCOUNT_OWNER="LDAutomation";

	public static String department1 = "Department1";
    public static String department2 = "Department2";
    public static int i =0;


    public static Hashtable zohodesk(WebDriver driver)
	{
		ExtentTest etest = null;

		d1 = driver;
		d2 = null;
		d3=null;
		d4=null;
		
		try
		{
			result = new Hashtable();
			hashtable = new Hashtable();
			servicedown = new Hashtable();
			search_visitor = new Hashtable();
			
			i = 0;

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ZD1"));
			ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

			d2 = Functions.setUp();
			d3 = Functions.setUp();
			d4 = Functions.setUp();

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Desk");
			etest.log(Status.PASS,"Zoho Desk Integration is present");

			result.put("ZD1", true);
			
			if(Functions.login(d2,"desk2") && Functions.login(d3,"desk3") && Functions.login(d4,"desk4"))
			{

				try
	            {
	            	FluentWait wait = CommonUtil.waitreturner(d2,30,200);
	            	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dnenable")));
	            	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dnenable")));
	                d2.findElement(By.id("dnenable")).findElement(By.className("sqico-close")).click();
	                Thread.sleep(2000);
	            }
	            catch(Exception e)
	            {
	                System.out.println("Exception while closing the top banner : "+e);
	            }
                
                ComplexReportFactory.closeTest(etest);
                
                new ZohoDeskUtil().initiate();

                if(Util.logoutBlankPage)
                {
                    Functions.logout(d2);
                }
			}
			else
			{
				Functions.logout(d2);
				
				etest.log(Status.FAIL,"Login fail");

				result.put("ZD1", false);
				
				ComplexReportFactory.closeTest(etest);
			}
            
        }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorUser(s)Tab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","DeskNotFound","Error",e);
			result.put("ZD1", false);
		}
        
        ComplexReportFactory.closeTest(etest);
        
        closeAllDrivers();
        
        System.out.println("<><><><><><><>"+search_visitor);
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}    

    public static void closeAllDrivers(String portalname)
    {
        for(WebDriver visitor_driver : visitor_drivers_by_portal.get(portalname))
        {
            try
            {
            }
            catch(Exception e){}
        }
    }

    public static void closeAllDrivers()
    {
    	Set<String> portals = visitor_drivers_by_portal.keySet();
        for(String portal : portals)
        {
        	closeAllDrivers(portal);
        }
    }

    public static void addVisitorDriverToHashable(WebDriver visitor_driver,String portalname)
    {
    	if(visitor_drivers_by_portal.get(portalname)==null)
    	{
    		visitor_drivers_by_portal.put(portalname,new HashSet());
    	}

    	visitor_drivers_by_portal.get(portalname).add(visitor_driver);
    }

	public static void checkDeskPart1(WebDriver driver,ExtentTest etest) throws Exception
	{
		String portalname=ExecuteStatements.getPortal(driver);

		String useCase[] = { "All Visitors/Open/"+department1+"/No/true/Ticket Created/true",
							 "All Visitors/Open/"+department2+"/No/false/Ticket Created/no",
							 "All Visitors/Closed/"+department1+"/All/true/Ticket Created/false",
							 "All Visitors/Closed/"+department2+"/Mapped/false/Ticket Created/no",
							 "All Visitors/Open/Choose on Demand/No/true/Create Ticket",
							 "All Visitors/Closed/Choose on Demand/No/true/Create Ticket",
							 "All Visitors/Open/Choose on Demand/No/false/Create Ticket",
							 "All Visitors/Closed/Choose on Demand/No/false/Create Ticket",
							 "All Visitors/Open/No Integration/No/true/No Ticket",
							 "All Visitors/Open/No Integration/No/false/No Ticket",
							 "All Visitors/Open/Read-only/No/true/No Ticket",
							 "All Visitors/Open/Read-only/No/false/No Ticket"
							};

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ZD2"));
		ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

		result.put("ZD2", checkDisable(driver,etest));

		ComplexReportFactory.closeTest(etest);

		String salesiqDept=ExecuteStatements.getSystemGeneratedDepartment(driver);

		if((boolean)result.get("ZD2"))
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ZD4"));
			ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

			result.put("ZD4", addDepartment(driver,etest));

			ComplexReportFactory.closeTest(etest);

			//outer loop is for retrying failed usecases
			for(int i=0;i<=2;i++)
			{
				for(String s : useCase)
				{
					//check if not run yet or if its failed
					boolean isRun=CommonUtil.isFail(result,useCase(s));

					if(isRun)
					{
						Boolean feedBack = null;
						
						etest=ComplexReportFactory.getTest(useCase(s)+"--Attempt "+ (i+1) );
						ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

						if(s.split("/").length == 7)
						{
							if(s.split("/")[6].equals("true"))
							{
								feedBack = true;
							}
							else if(s.split("/")[6].equals("false"))
							{
								feedBack = false;
							}
						}

						result.put(useCase(s),checkDesk(driver,etest,portalname,s.split("/")[0],s.split("/")[1],feedBack,salesiqDept,s.split("/")[2],s.split("/")[3],s.split("/")[4],s.split("/")[5]));

						if((boolean)result.get(useCase(s)))
						{
							if(i>0)
							{
								etest.log(Status.WARNING,"Passed After "+i+" Attempts");
							}
							else
							{
								etest.log(Status.PASS,"Passed");
							}
						}
						else
						{
							etest.log(Status.FAIL,"Failed");							
						}

						ComplexReportFactory.closeTest(etest);
					}
				}
			}
		}
			
	}

	public static void checkDeskPart2(WebDriver driver,ExtentTest etest) throws Exception
	{
		String portalname=ExecuteStatements.getPortal(driver);


		String useCase[] = { "Missed/Open/"+department1+"/No/true/Create Ticket",
							 "Missed/Open/"+department2+"/No/false/Ticket Created",
							 "Missed/Closed/"+department1+"/All/true/Create Ticket",
							 "Missed/Closed/"+department2+"/Mapped/false/Ticket Created",
							 "Missed/Open/Choose on Demand/No/true/Create Ticket",
							 "Missed/Open/Choose on Demand/No/false/Create Ticket",
							 "Missed/Closed/Choose on Demand/No/true/Create Ticket",
							 "Missed/Closed/Choose on Demand/No/false/Create Ticket",
							 "Missed/Open/No Integration/No/true/No Ticket",
							 "Missed/Open/No Integration/No/false/No Ticket",
							 "Missed/Open/Read-only/No/true/No Ticket",
							 "Missed/Open/Read-only/No/false/No Ticket",
							};

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ZD3"));
		ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

		result.put("ZD3", checkAnonymous(driver,etest));

		ComplexReportFactory.closeTest(etest);

		String salesiqDept=ExecuteStatements.getSystemGeneratedDepartment(driver);

		//outer loop is for retrying failed usecases
		for(int i=0;i<=2;i++)
		{
			for(String s : useCase)
			{
				//check if not run yet or if its failed
				boolean isRun=CommonUtil.isFail(result,useCase(s));

				if(isRun)
				{
					Boolean feedBack = null;
					
					etest=ComplexReportFactory.getTest(useCase(s)+"--Attempt "+ (i+1) );
					ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

					result.put(useCase(s),checkDesk(driver,etest,portalname,s.split("/")[0],s.split("/")[1],feedBack,salesiqDept,s.split("/")[2],s.split("/")[3],s.split("/")[4],s.split("/")[5]));

					if((boolean)result.get(useCase(s)))
					{
						if(i>0)
						{
							etest.log(Status.WARNING,"Passed After "+i+" Attempts");
						}
						else
						{
							etest.log(Status.PASS,"Passed");
						}
					}
					else
					{
						etest.log(Status.FAIL,"Failed");							
					}

					ComplexReportFactory.closeTest(etest);
				}
			}
		}	
	}

	public static void checkDeskPart3(WebDriver driver,ExtentTest etest) throws Exception
	{
		String portalname=ExecuteStatements.getPortal(driver);

		String useCase[] = { "Attended/Open/"+department1+"/No/true/Ticket Created",
							 "Attended/Open/"+department2+"/No/false/Create Ticket",
							 "Attended/Closed/"+department1+"/All/true/Ticket Created",
							 "Attended/Closed/"+department2+"/Mapped/false/Create Ticket",
							 "Attended/Open/Choose on Demand/No/true/Create Ticket",
							 "Attended/Open/Choose on Demand/No/false/Create Ticket",
							 "Attended/Closed/Choose on Demand/No/true/Create Ticket",
							 "Attended/Closed/Choose on Demand/No/false/Create Ticket",
							 "Attended/Open/No Integration/No/true/No Ticket",
							 "Attended/Open/No Integration/No/false/No Ticket",
							 "Attended/Open/Read-only/No/true/No Ticket",
							 "Attended/Open/Read-only/No/false/No Ticket",
							};

		boolean isEnabled=false;

		String salesiqDept=ExecuteStatements.getSystemGeneratedDepartment(driver);



		//outer loop is for retrying failed usecases
		for(int i=0;i<=2;i++)
		{
			for(String s : useCase)
			{
				//check if not run yet or if its failed
				boolean isRun=CommonUtil.isFail(result,useCase(s));

				if(isRun)
				{
					Boolean feedBack = null;
					
					etest=ComplexReportFactory.getTest(useCase(s)+"--Attempt "+ (i+1) );

					if(!isEnabled)
					{
						IntegrationSettings.enableDeskInteg(driver,etest);
						isEnabled=true;
					}

					ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

					if(s.split("/").length == 7)
					{
						if(s.split("/")[6].equals("true"))
						{
							feedBack = true;
						}
						else if(s.split("/")[6].equals("false"))
						{
							feedBack = false;
						}
					}

					result.put(useCase(s),checkDesk(driver,etest,portalname,s.split("/")[0],s.split("/")[1],feedBack,salesiqDept,s.split("/")[2],s.split("/")[3],s.split("/")[4],s.split("/")[5]));

					if((boolean)result.get(useCase(s)))
					{
						if(i>0)
						{
							etest.log(Status.WARNING,"Passed After "+i+" Attempts");
						}
						else
						{
							etest.log(Status.PASS,"Passed");
						}
					}
					else
					{
						etest.log(Status.FAIL,"Failed");							
					}

					ComplexReportFactory.closeTest(etest);
				}
			}
		}		
			
	}

	public static void checkDeskPart4(WebDriver driver,ExtentTest etest) throws Exception
	{
		String portalname=ExecuteStatements.getPortal(driver);

		String useCase[] = { "None/Open/"+department1+"/No/true/Create Ticket",
							 "None/Open/"+department2+"/No/false/Create Ticket",
							 "None/Closed/"+department1+"/All/true/Create Ticket",
							 "None/Closed/"+department2+"/Mapped/false/Create Ticket",
							 "None/Open/Choose on Demand/No/true/Create Ticket",
							 "None/Open/Choose on Demand/No/false/Create Ticket",
							 "None/Closed/Choose on Demand/No/true/Create Ticket",
							 "None/Closed/Choose on Demand/No/false/Create Ticket",
							 "None/Open/No Integration/No/true/No Ticket",
							 "None/Open/No Integration/No/false/No Ticket",
							 "None/Open/Read-only/No/true/No Ticket",
							 "None/Open/Read-only/No/false/No Ticket",
							};
		boolean isEnabled=false;

		String salesiqDept=ExecuteStatements.getSystemGeneratedDepartment(driver);


		//outer loop is for retrying failed usecases
		for(int i=0;i<=2;i++)
		{
			for(String s : useCase)
			{
				//check if not run yet or if its failed
				boolean isRun=CommonUtil.isFail(result,useCase(s));

				if(isRun)
				{
					Boolean feedBack = null;
					
					etest=ComplexReportFactory.getTest(useCase(s)+"--Attempt "+ (i+1) );

					if(!isEnabled)
					{
						IntegrationSettings.enableDeskInteg(driver,etest);
						isEnabled=true;
					}

					ComplexReportFactory.setValues(etest,"Automation","Zoho Desk Integration");

					result.put(useCase(s),checkDesk(driver,etest,portalname,s.split("/")[0],s.split("/")[1],feedBack,salesiqDept,s.split("/")[2],s.split("/")[3],s.split("/")[4],s.split("/")[5]));

					if((boolean)result.get(useCase(s)))
					{
						if(i>0)
						{
							etest.log(Status.WARNING,"Passed After "+i+" Attempts");
						}
						else
						{
							etest.log(Status.PASS,"Passed");
						}
					}
					else
					{
						etest.log(Status.FAIL,"Failed");							
					}

					ComplexReportFactory.closeTest(etest);
				}
			}
		}


			
	}


	public static boolean checkDesk(WebDriver driver,ExtentTest etest,String portalname,String chatType,String status,Boolean feedBack,String salesiqDept,String deskConfig,String allDept1,String accept1,String ticketStage)throws Exception
	{
		Boolean allDept = null;
		boolean accept = false;
		if(allDept1.equals("Mapped"))
		{
			allDept = false;
		}
		else if(allDept1.equals("All"))
		{
			allDept = true;
		}
		if(accept1.equals("true"))
		{
			accept = true;
		}
		Long time = new Long(System.currentTimeMillis());
		String time_string = ""+time;
				
		if(!deskConfig.equals("Choose on Demand") && !deskConfig.equals("No Integration") && !deskConfig.equals("Read-only"))
		{
			if(search_visitor.get(chatType) == null)
			{
				search_visitor.put(chatType,time_string);
			}
			else
			{
				time_string = search_visitor.get(chatType);
			}
		}
		etest.log(Status.INFO,"--V"+time_string);
		if(!checkDesk(driver,etest,portalname,chatType,status,feedBack,salesiqDept,deskConfig,allDept,accept,time_string,ticketStage))
		{
			return false;
		}

		return true;
	}

	public static boolean checkDesk(WebDriver driver,ExtentTest etest,String portalname,String chatType,String status,Boolean feedBack,String salesiqDept,String deskConfig,Boolean allDept,boolean accept,String time,String ticketStage)throws Exception
	{
		WebDriver visDriver = null;
		try
		{
			String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String department = null;
			if(deskConfig.equals(department1))
			{
				department = department1;
			}
			else if(deskConfig.equals(department2))
			{
				department = department2;
			}
		
			String embedname = portalname;
			
			String deskDept = null;
			if(deskConfig.equals(department))
			{
				deskDept = department;
			}
			String vname = "V"+time;
			String vemail = "email@"+time+".com";
			String vphone = "54321";
			String vques = "Ques"+time;
			String agent_message1 = "AM1"+time;
			String visitor_message = "visitor message";
			String agent_message2 = "AM2"+time;
			String fdkmsg = "Feedback "+time;
			
            Functions.createTabAndCloseCurrent(driver);

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Desk");

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_suppheader")+"')]")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_suppheader")+"')]")));
            
            Thread.sleep(1000);
            
            if(!IntegrationSettings.deskintegconfig1(driver,"convertrequest_div_div","convertrequest_div_ddown",chatType,etest))
			{
				return false;
			}
			if(status != null)
			{
				if(!IntegrationSettings.deskintegconfig1(driver,"attendreqstatus_div_div","attendreqstatus_div_ddown",status,etest))
				{
					return false;
				}
			}
			if(!CommonFunctions.mapDept(driver,salesiqDept,deskConfig,etest))
			{
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","DeskDeptConfig","Error"+(i++));
				return false;
			}
			if(feedBack != null)
			{
				System.out.println("<><><><><><>");
				CommonFunctions.setFeedBackConfig(driver,feedBack,etest);
			}
			System.out.println("<><><><><><>");
			if(allDept != null)
			{
				if(allDept)
				{
					if(!IntegrationSettings.deskReqInLD1(driver,0,"reqcriteria_all",etest))
					{
						return false;
					}
				}
				else
				{
					if(!IntegrationSettings.deskReqInLD1(driver,1,"reqcriteria_mdept",etest))
					{
						return false;
					}
				}
			}
			
			Thread.sleep(5000);

			visDriver = Functions.setUp();
			
			if(visitor_drivers_by_portal.get(portalname)==null)
			{
				visitor_drivers_by_portal.put(portalname,new HashSet());
			}

            closeAllDrivers(portalname);
            addVisitorDriverToHashable(visDriver,portalname);
        
            try
			{
				VisitorWindow.createPage(visDriver,WIDGET_CODE);

				System.out.println(VisitorWindow.getVisitorId(visDriver,portalname));

				VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,vphone,vques,etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","VisistorSetUp","Error"+(i++),e);
				return false;
			}
			
			if(accept)
			{
				ChatWindow.acceptChat(driver,etest);
				ChatWindow.sentMessage(driver,agent_message1);

				try
				{
					if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,ExecuteStatements.getUserName(driver),agent_message1,1))
					{
						TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++));
						return false;
					}

					VisitorWindow.sentMessageInTheme(visDriver,visitor_message);
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","VisitorWindow","Error"+(i++),e);
					return false;
				}

				if(!ChatWindow.checkMessageInUserWindow(driver,"V"+time,visitor_message))
				{
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","VisitorMessageInAgentWindow","Error"+(i++));
					return false;
				}

				ChatWindow.sentMessage(driver,agent_message2);

				try
				{
					if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,ExecuteStatements.getUserName(driver),agent_message2,2))
					{
						TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++));
						return false;
					}
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++),e);
					return false;
				}

				ChatWindow.endChat(driver);
				ChatWindow.clickClosethisWindow(driver);

				if(feedBack != null)
				{
					try
					{
						VisitorWindow.enterFeedbackInTheme(visDriver,fdkmsg,"3");
					}
					catch(Exception e)
					{
						TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","Feedback","Error"+(i++),e);
						return false;
					}
				}
			}
			else
			{
				try
				{
					ChatWindow.ignoreChat(driver);
				}
				catch(Exception e)
				{
					CommonUtil.doNothing();
				}

				try
				{
					VisitorWindow.waitTillChatisMissedInTheme(visDriver);
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","WaitTillChatMissed","Error"+(i++),e);
					return false;
				}
			}

			Thread.sleep(5000);
			
			Tab.clickSettings(driver);
		
			String id = "history_div";

			if(!accept && ticketStage.equals("Ticket Created"))
			{
				for(int trial = 1; trial <= 12; trial++)
				{
					Tab.clickSettings(driver);
					Tab.clickMissed(driver);

					WebElement missed_list = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","missed_div"),"id","historylist");
					
					if(!missed_list.getAttribute("innerHTML").contains(vname))
					{
						etest.log(Status.INFO,"Trial count - "+trial);
						break;
					}

					Thread.sleep(5000);
					driver.navigate().refresh();
					Thread.sleep(5000);
				}
			}

			Tab.clickSettings(driver);

			driver.navigate().refresh();
			Thread.sleep(5000);
			
			if(accept || ticketStage.equals("Ticket Created"))
			{
				Tab.clickChatHistory(driver);
			}
			else
			{
				id = "missed_div";
				Tab.clickMissed(driver);
			}

			List<WebElement> visitor_list = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","historylist").findElements(By.className("cursr-point"));

			// WebElement visitor_name = CommonUtil.elementfinder(driver,visitor_list.get(0),"partiallinktext",vname);
			WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));
			
			if(visitor_name == null)
			{
				etest.log(Status.FAIL,vname+" is not present");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
				return false;
			}
			
            visitor_list = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","historylist").findElements(By.className("cursr-point"));

			visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

			visitor_name.click();

			WebElement chat = CommonUtil.elfinder(driver,"id",id);

			final WebElement elmt = CommonUtil.elementfinder(driver,chat,"id","visdatapar");

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(elmt.findElement(By.className("rcvstlftxt")).getText().contains("Visitor Info"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });
	        
	        Thread.sleep(1000);

	        if(ticketStage.equals("Create Ticket"))
	        {
	        	if(!CommonFunctions.createTicketPresence(driver,elmt))
	        	{
	        		etest.log(Status.FAIL,"Convert to Ticket is not present");
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        		return false;
	        	}
	        	else
	        	{
	        		etest.log(Status.PASS,"Convert to ticket is present");
	        	}
	        }
	        else if(ticketStage.equals("Ticket Created"))
	        {
	        	if(!CommonFunctions.createdTicketPresence(driver,elmt))
	        	{
	        		etest.log(Status.FAIL,"Ticket is not created");
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        		return false;
	        	}
	        	else
	        	{
	        		etest.log(Status.PASS,"Ticket is created");
	        	}
	        }
	        else
	        {
	        	if(CommonFunctions.createTicketPresence(driver,elmt))
	        	{
	        		etest.log(Status.FAIL,"Convert to Ticket is present");
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        		return false;
	        	}
	        	else
	        	{
	        		etest.log(Status.PASS,"Convert to Ticket is not present");
	        	}
	        	if(CommonFunctions.createdTicketPresence(driver,elmt))
	        	{
	        		etest.log(Status.FAIL,"Ticket is created");
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        		return false;
	        	}
	        	else
	        	{
	        		etest.log(Status.PASS,"Ticket is not created");
	        	}
	        	if(deskConfig.equals("No Integration"))
	        	{
	        		if(CommonFunctions.relatedTicketPresence(driver,elmt))
		        	{
		        		etest.log(Status.FAIL,"Related Ticket is present");
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		        		return false;
		        	}
		        	else
		        	{
		        		etest.log(Status.PASS,"Related ticket is not present");
		        	}
	        	}
	     
	        	visDriver.quit();
	        	return true;
	        }

	        if(allDept != null)
	        {
	        	if(!CommonFunctions.relatedTicketPresence(driver,elmt))
	        	{
	        		etest.log(Status.FAIL,"Related Ticket is not present");
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        		return false;
	        	}
	        	else
	        	{
	        		etest.log(Status.PASS,"Related Ticket is present");
	        	}

	        	List<WebElement>  list = CommonUtil.elementfinder(driver,elmt,"id","recentrequest").findElements(By.className("spt_tktdatamn"));

	        	if(allDept)
	        	{
	        		if(list.size() < 2)
	        		{
		        		etest.log(Status.FAIL,"Mismatch related number of tickets");
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		        		return false;
		        	}
		        	else
		        	{
		        		etest.log(Status.PASS,"check Related number of tickets -- checked");
		        	}
	        	}
	        	else
	        	{
	        		if(list.size() < 1)
	        		{
		        		etest.log(Status.FAIL,"Mismatch related number of tickets");
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		        		return false;
		        	}
		        	else
		        	{
		        		etest.log(Status.PASS,"Check related number of tickets -- checked");
		        	}
	        	}

	        	String id1 = "newreqdiv";

	        	if(ticketStage.equals("Ticket Created"))
	        	{
	        		id1 = "associatedreq";
	        	}

	        	CommonUtil.sleep(60000); //need to wait for a minute for the current ticket to be updated in the ticket db

	        	CommonUtil.refreshPage(driver);

	        	System.out.println(id+"<><><><>"+id1);

	        	TicketDetails.clickSearch(driver,id,id1);

	        	TicketDetails.sentSearchKey(driver,id,vemail);

	        	if(allDept)
	        	{
	        		List<WebElement> searchlist = TicketDetails.getSearchList(driver,id,2);

	        		if(searchlist.size() < 2)
		        	{
		        		etest.log(Status.FAIL,"Mismatch search tickets.Expected:2--Actual:"+searchlist.size()+"--");
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		        		return false;
		        	}
		        	else
		        	{
		        		etest.log(Status.PASS,"Check search tickets -- checked");
		        	}
	        	}
	        	else
	        	{
	        		List<WebElement> searchlist = TicketDetails.getSearchList(driver,id,1);

	        		if(searchlist.size() < 1)
		        	{
		        		etest.log(Status.FAIL,"Mismatch search tickets.Expected:1--Actual:"+searchlist.size()+"--");
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		        		return false;
		        	}
		        	else
		        	{
		        		etest.log(Status.PASS,"Check search tickets -- checked");
		        	}
	        	}

	        	TicketDetails.getBackToDetails(driver,id);
         	}
	        
	        if(ticketStage.equals("Create Ticket"))
			{
				final WebElement convert = CommonUtil.elementfinder(driver,elmt,"id","zsrightbtn");
		        final WebElement details = CommonUtil.elementfinder(driver,elmt,"id","zsaddreqdiv");

		        if(!details.getAttribute("style").contains("none"))
		        {
                    etest.log(Status.FAIL,"Style attribute for zsaddreqdiv.Expected:not none--Actual"+details.getAttribute("style")+"--");
		        	TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		            return false;
		        }

		        String convert_content = convert.getText();
		        
		        if(!convert_content.contains("Convert chat as Ticket"))
		        {
		        	etest.log(Status.FAIL,"Convert chat as Ticket mismatch content");
		        	TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
		            return false;
		        }

		        CommonUtil.elementfinder(driver,convert,"tagname","span").click();

		        wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(convert.getAttribute("style").contains("none") && !details.getAttribute("style").contains("none"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

		        List<WebElement> list = details.findElements(By.className("crmld_infomn"));
		        String lhs[] = {"Priority","Status","Classification","Department"};

		        for(String dropDown : lhs)
		        {
		        	String dd_id = dropDown.toLowerCase();
		        	
		        	boolean presence = CommonFunctions.checkDropDownPresence(driver,list,dropDown);
		        	boolean expected = true;

		        	if(dropDown.equals("Department") && deskConfig.equals(department))
		        	{
		        		expected = false;
		        	}
		        	else if(dropDown.equals("Department") && !deskConfig.equals(department))
		        	{
		        		String temp = CommonUtil.elementfinder(driver,details,"id",dd_id).getAttribute("value");
		        		deskDept = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,details,"id",dd_id),"xpath","//option[@value='"+temp+"']").getAttribute("innerHTML");
					}
		        	if(dropDown.equals("Status") && !accept)
		        	{
		        		expected = false;
		        	}
		        	if(presence != expected)
		        	{
		        		etest.log(Status.FAIL,"Mismatch in presence of Dropdown - "+dropDown);
			        	TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
			            return false;
		        	}
		        	if(expected)
		        	{
		        		CommonUtil.elementfinder(driver,details,"id",dd_id).getAttribute("value");
		        	}
		        }

		        CommonUtil.elementfinder(driver,details,"classname","rg-button").click();

                Tab.waitForLoading(driver,"invokeaction.do",etest);
		        
		        final WebElement ticket_div = CommonUtil.elementfinder(driver,elmt,"id","associatedreq");

		        wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(ticket_div.getAttribute("innerHTML").contains("spt_tktdatamn"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

		    }

		    if(feedBack != null)
		    {
		    	Thread.sleep(60000);
		    }

		    chat = CommonUtil.elfinder(driver,"id",id);

		    WebElement ticket = CommonFunctions.getRelatedTicket(driver,chat);

			if(!CommonUtil.elementfinder(driver,ticket,"classname","spt_tktdatatxt").getText().contains(vques))
 			{
 				visDriver.quit();
 				etest.log(Status.FAIL,vques+" - mismatch content in ticket");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        	return false;
 			}

 			TicketDetails.openTicket(driver,ticket,id);

 			WebElement ticket_view = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","zsreqdetail");

 			String expected_status = "Open";

 			if(ticketStage.equals("Ticket Created") && status.equals("Closed") && accept)
 			{
 				expected_status = "Closed";
 			}

 			String ticket_status = TicketDetails.getStatusInTicket(driver,ticket_view);

 			if(!ticket_status.equals(expected_status))
 			{
 				visDriver.quit();
 				etest.log(Status.FAIL,"Mismatch ticket status");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        	return false;
 			}

 			if(feedBack != null)
 			{
 				Thread.sleep(1000);

 				TicketDetails.clickChatHeaderInTicket(driver,ticket_view);

				if(!(TicketDetails.checkMessageInChatTranscriptInTicket(driver,ticket_view,1,ExecuteStatements.getUserName(driver),agent_message1)
					&&TicketDetails.checkMessageInChatTranscriptInTicket(driver,ticket_view,2,vname,visitor_message)
					  && TicketDetails.checkMessageInChatTranscriptInTicket(driver,ticket_view,3,ExecuteStatements.getUserName(driver),agent_message2)))
				{
                    etest.log(Status.FAIL,"Mismatch Chat Messages.Expected:"+agent_message1+","+agent_message2+","+visitor_message+"--");
					TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        			return false;
				}

 				if(feedBack)
 				{
 					TicketDetails.clickFeedBackHeaderInTicket(driver,ticket_view);

 					if(!(TicketDetails.checkFeedBackInChatTranscriptInTicket(driver,ticket_view,fdkmsg)))
 					{
                        etest.log(Status.FAIL,"Mismatch Feedback Messages.Expected:"+fdkmsg+"--");
 						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        				return false;
 					}
 				}
 				else
 				{
					if(TicketDetails.clickFeedBackHeaderInTicket(driver,ticket_view))
					{
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","FeedbackPresenceMismatch","Error"+(i++));
						return false;
 					}
				}
 			}
 			else
 			{
 				TicketDetails.clickMoreInTicket(driver,ticket_view);

	 			String details_lhs[] = {"Department","Email Address","Created by","Phone Number"};
	 			String expected_details[] = {deskDept,vemail,DESK_ACCOUNT_OWNER,vphone};
	 			int i = 0;
	 			for(String s : details_lhs)
	 			{
	 				String present = TicketDetails.getDetailsInTicket(driver,ticket_view,s);
	 				System.out.println(present+"---"+expected_details[i]+"---");
	 				if(!(present != null && present.equals(expected_details[i++])))
	 				{
	 					visDriver.quit();
		 				etest.log(Status.FAIL,"Mismatch Content - "+s);
						TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
			        	return false;
	 				}
	 			}

	 			TicketDetails.clickHideInTicket(driver,ticket_view);
 			}

 			TicketDetails.clickCloseWindowInTicket(driver,ticket_view);

 			ticket = CommonFunctions.getRelatedTicket(driver,chat);

 			String toChangeStatus = expected_status.equals("Open") ? "Closed" : "Open";

 			TicketDetails.changeStatus(driver,ticket,toChangeStatus,etest);

 			TicketDetails.openTicket(driver,ticket,id);

 			ticket_view = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","zsreqdetail");

 			ticket_status = TicketDetails.getStatusInTicket(driver,ticket_view);

 			if(!ticket_status.equals(toChangeStatus))
 			{
 				visDriver.quit();
 				etest.log(Status.FAIL,"Mismatch ticket status");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
	        	return false;
 			}

 			TicketDetails.clickCloseWindowInTicket(driver,ticket_view);
            
//            boolean ticket_title = false;
//            
//            if(ticketStage.equals("Ticket Created") && chatType.equals("All Visitors"))
//            {
//                for(int ii = 1;ii<=5;ii++)
//                {
//                    driver.navigate().refresh();
//                    Thread.sleep(10000);
//                    
//                    Tab.clickSettings(driver);
//                    Tab.clickChatHistory(driver);
//                    
//                    visitor_list = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","history_div"),"id","historylist").findElements(By.className("cursr-point"));
//                    
//                    WebElement icon = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,visitor_list.get(0),"classname","thrd-clm"),"tagname","em");
//                    String class_name = icon.getAttribute("class");
//                    String title = icon.getAttribute("title");
//                    if(class_name.equals("visitstatus7") && title.equals("Converted as Ticket"))
//                    {
//                        ticket_title = true;
//                        break;
//                    }
//                    if(ii==5)
//                    {
//                        etest.log(Status.FAIL,"Mismatch Content.Expected:visitstatus7--Converted as Ticket--Actual:"+class_name+"--"+title+"--");
//                        TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
//                    }
//                }
//            }
//            
// 			return ticket_title;
            
            visDriver.quit();
            return true;
		}
		catch(Exception e)
		{
		    TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++),e);
		    if(visDriver != null)
		    {
		    	visDriver.quit();
		    }
		}

		return false;
	}

	public static boolean checkDisable(WebDriver driver,ExtentTest etest) throws Exception 
	{
		try
		{
			String portalname=ExecuteStatements.getPortal(driver);

			String embedname = portalname;

			String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);

			IntegrationSettings.disableDeskInteg(driver,etest);

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			Long time = new Long(System.currentTimeMillis());

			String vname = "V"+time;
			String vemail = "email@"+time+".com";
			String vphone = "54321";
			String vques = "Ques"+time;
			String agent_message1 = "AM1"+time;
			String visitor_message = "visitor message";
			String agent_message2 = "AM2"+time;
			String fdkmsg = "Feedback "+time;
			
			driver.navigate().refresh();
			Thread.sleep(5000);

			WebDriver visDriver = Functions.setUp();
			addVisitorDriverToHashable(visDriver,portalname);

			try
			{
				VisitorWindow.createPage(visDriver,WIDGET_CODE);

				System.out.println(VisitorWindow.getVisitorId(visDriver,portalname));

				VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,vphone,vques,etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","VisitorSetUp","Error"+(i++),e);
				return false;
			}
			
			ChatWindow.acceptChat(driver,etest);
			ChatWindow.sentMessage(driver,agent_message1);

			try
			{
				if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,ExecuteStatements.getUserName(driver),agent_message1,1))
				{
					TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++));
					return false;
				}

				VisitorWindow.sentMessageInTheme(visDriver,visitor_message);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","VisitorWindow","Error"+(i++),e);
				return false;
			}

			if(!ChatWindow.checkMessageInUserWindow(driver,"V"+time,visitor_message))
			{
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","VisitorMessageInAgentWindow","Error"+(i++));
				return false;
			}

			ChatWindow.sentMessage(driver,agent_message2);

			try
			{
				if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,ExecuteStatements.getUserName(driver),agent_message2,2))
				{
					TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++));
					return false;
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++),e);
				return false;
			}

			ChatWindow.endChat(driver);
			ChatWindow.clickClosethisWindow(driver);

			Thread.sleep(5000);
			
			Tab.clickSettings(driver);
			Tab.clickChatHistory(driver);
		
			String id = "history_div";

			List<WebElement> visitor_list = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","historylist").findElements(By.className("cursr-point"));

			// WebElement visitor_name = CommonUtil.elementfinder(driver,visitor_list.get(0),"partiallinktext",vname);
			WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));
			
			visitor_name.click();

			WebElement chat = CommonUtil.elfinder(driver,"id",id);

			final WebElement elmt = CommonUtil.elementfinder(driver,chat,"id","visdatapar");

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(elmt.findElement(By.className("rcvstlftxt")).getText().contains("Visitor Info"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });
	        
        	if(CommonFunctions.createTicketPresence(driver,elmt))
        	{
        		etest.log(Status.FAIL,"Convert to Ticket is present");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
        	}
        	if(CommonFunctions.createdTicketPresence(driver,elmt))
        	{
        		etest.log(Status.FAIL,"Ticket is created");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
        	}
	        
	        visDriver.quit();
	        etest.log(Status.PASS,"Checked");
	        if(IntegrationSettings.enableDeskInteg(driver,etest))
	        {
	        	driver.navigate().refresh();
	        	Thread.sleep(5000);
	        	return true;
	        }
	        driver.navigate().refresh();
	       	Thread.sleep(5000);
	        return false;
		}
		catch(Exception e)
		{
		    TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++),e);
		}

		return false;
	}

	public static boolean checkAnonymous(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String portalname=ExecuteStatements.getPortal(driver);
			String salesiqDept=ExecuteStatements.getSystemGeneratedDepartment(driver);

			String embedname = portalname;
			String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			Long time = new Long(System.currentTimeMillis());

			String vname = "V"+time;
			String vemail = "email@"+time+".com";
			String vphone = "54321";
			String vques = "Ques"+time;
			String agent_message1 = "AM1"+time;
			String visitor_message = "visitor message";
			String agent_message2 = "AM2"+time;
			String fdkmsg = "Feedback "+time;
			
			driver.navigate().refresh();
			Thread.sleep(5000);

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Desk");

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_suppheader")+"')]")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_suppheader")+"')]")));
            
            Thread.sleep(1000);
            
            if(!IntegrationSettings.deskintegconfig1(driver,"convertrequest_div_div","convertrequest_div_ddown","All Visitors",etest))
			{
				return false;
			}
			if(!CommonFunctions.mapDept(driver,salesiqDept,"Choose on Demand",etest))
			{
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","DeskDeptConfiguration","Error"+(i++));
				return false;
			}

			Thread.sleep(5000);

			WebDriver visDriver = Functions.setUp();
			addVisitorDriverToHashable(visDriver,portalname);
			try
			{
				VisitorWindow.createPage(visDriver,WIDGET_CODE);

				System.out.println(VisitorWindow.getVisitorId(visDriver,portalname));

				VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,vques,etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","VisitorSetUp","Error"+(i++),e);
				return false;
			}
			
			ChatWindow.acceptChat(driver,etest);
			ChatWindow.sentMessage(driver,agent_message1);

			try
			{
				if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,ExecuteStatements.getUserName(driver),agent_message1,1))
				{
					TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","AgentMessageInVisitorWindow","Error"+(i++));
					return false;
				}

				VisitorWindow.sentMessageInTheme(visDriver,visitor_message);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoDeskInteg","VisitorWindow","Error"+(i++),e);
				return false;
			}

			ChatWindow.endChat(driver);
			ChatWindow.clickClosethisWindow(driver);

			Thread.sleep(5000);
			
			Tab.clickSettings(driver);
			Tab.clickChatHistory(driver);
		
			String id = "history_div";

			List<WebElement> visitor_list = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","historylist").findElements(By.className("cursr-point"));

			WebElement visitor_name = CommonUtil.elementfinder(driver,visitor_list.get(0),"xpath","//td[@class='secnd-clm']//h2");
			
			visitor_name.click();

			WebElement chat = CommonUtil.elfinder(driver,"id",id);

			final WebElement elmt = CommonUtil.elementfinder(driver,chat,"id","visdatapar");

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(elmt.findElement(By.className("rcvstlftxt")).getText().contains("Visitor Info"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });
	        
        	if(CommonFunctions.createTicketPresence(driver,elmt))
        	{
        		etest.log(Status.FAIL,"Convert to Ticket is present");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
        	}
        	if(CommonFunctions.createdTicketPresence(driver,elmt))
        	{
        		etest.log(Status.FAIL,"Ticket is created");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
        	}
	        
	        final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","visitordata");
	        WebElement div1 = CommonUtil.elementfinder(driver,div,"classname","rcvstinfolftxt");
	        CommonUtil.mouseHover(driver,CommonUtil.elementfinder(driver,div,"tagname","span"));
	        wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,div,"tagname","a")));

	        CommonUtil.elementfinder(driver,div,"tagname","a").click();

	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(div.getAttribute("style").contains("none"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        final WebElement visitorinfo = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","visdatapar");

	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(visitorinfo.getAttribute("innerHTML").contains("cvisname") && visitorinfo.getAttribute("innerHTML").contains("cvisemail"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        WebElement name = CommonUtil.elementfinder(driver,visitorinfo,"id","cvisname");
	        WebElement email = CommonUtil.elementfinder(driver,visitorinfo,"id","cvisemail");

	        wait.until(ExpectedConditions.visibilityOf(name));
	        wait.until(ExpectedConditions.visibilityOf(email));

	        name.click();
	        name.sendKeys(vname);
	        email.click();
	        email.sendKeys(vemail);

	        CommonUtil.elementfinder(driver,visitorinfo,"css","span.rg-button.cmn_gbutclor").click();
	        
	        Tab.waitForLoading(driver,"updatevistdata.do",etest);

	        if(!CommonFunctions.createTicketPresence(driver,elmt))
        	{
        		etest.log(Status.FAIL,"Convert to Ticket is present");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
        	}

	        visDriver.quit();
	        etest.log(Status.PASS,"Checked");
	        return true;
		}
		catch(Exception e)
		{
		    TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++),e);
		}

		return false;
	}

	public static boolean addDepartment(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String salesiqDept=ExecuteStatements.getSystemGeneratedDepartment(driver);

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			Long time = new Long(System.currentTimeMillis());

			if(!Department.addDept(driver,"D"+time,"depttype_publi",ExecuteStatements.getUserName(driver),etest))
			{
				etest.log(Status.FAIL,"Department is not added");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
			}
            
            etest.log(Status.INFO,"D"+time+" is added");

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Desk");

			if(!CommonFunctions.mapDept(driver,"D"+time,"Choose on Demand",etest))
			{
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","DeskDeptConfiguration","Error"+(i++));
				return false;
			}

			if(!Department.deleteDepartment(driver,"D"+time,salesiqDept,etest))
			{
				etest.log(Status.FAIL,"Department is not deleted");
				TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++));
        		return false;
			}

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
		    TakeScreenshot.screenshot(driver,etest,"ZohoDeskInteg","Error","Error"+(i++),e);
		}

		return false;
	}

	public static String useCase(String s)
	{
		try
		{
			String parts[] = s.split("/");

			String usecase = "Zoho Desk Integration - $CHATTYPE(Chat Type) - $STATUS(Status) - $DESKCONFIG(Desk Department Mapping) - $DEPARTMENT(SalesIQ Depts) - $FDB(Feedback) - Chat Attended - Check $TICKETSTAGE";
            
            if(parts[4].equals("false"))
            {
                usecase = usecase.replace("Attended","Missed");
            }
            
            if(parts.length == 7)
			{
				if(parts[6].equals("true"))
				{
					usecase = usecase.replace("$FDB","Enabled");
				}
				else if(parts[6].equals("false"))
				{
					usecase = usecase.replace("$FDB","Disabled");
				}
                else
                {
                    usecase = usecase.replace("- $FDB(Feedback) ","");
                }
                
			}
			else
			{
				usecase = usecase.replace("- $FDB(Feedback) ","");
			}

			usecase = usecase.replace("$CHATTYPE",parts[0]);
			usecase = usecase.replace("$STATUS",parts[1]);
			if(parts[2].equals(department1))
			{
				usecase = usecase.replace("$DESKCONFIG","Desk Dept 1");
			}
			else if(parts[2].equals(department2))
			{
				usecase = usecase.replace("$DESKCONFIG","Desk Dept 2");
			}
			else
			{
				usecase = usecase.replace("$DESKCONFIG",parts[2]);

			}
			if(parts[3].equals("No"))
			{
				usecase = usecase.replace("- $DEPARTMENT(SalesIQ Depts) ","");
			}
			else
			{
				usecase = usecase.replace("$DEPARTMENT",parts[3]);
			}
			
            usecase = usecase.replace("$TICKETSTAGE",parts[5]);

			return usecase;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		return s;
	}

	public class MyRunnable implements Runnable {
        private int fnum;
        
        MyRunnable(int fnum) {
            this.fnum = fnum;
        }
        
        @Override
        public void run() {
            
            try
            {
                if(fnum == 0)
                {
                	ExtentTest etest = null;
                	checkDeskPart1(d1,etest);
                }
                else if(fnum == 1)
                {
                	ExtentTest etest = null;
                	checkDeskPart2(d2,etest);
                }
                else if(fnum == 2)
                {
                	ExtentTest etest = null;
                	checkDeskPart3(d3,etest);
                }
                else if(fnum == 3)
                {
                	ExtentTest etest = null;
                	checkDeskPart4(d4,etest);
                }

            }
            catch (Exception e)
            {
                System.out.println("Status: Exception  : "+e);
                e.printStackTrace();
                //result = "->Red<-\t";
            }
            System.out.println("Status: Success");
        }
    }

    public void initiate()
    {
            ExecutorService executor = Executors.newFixedThreadPool(100);
             
            for (int i = 0; i < 4; i++)
            {
                  Runnable worker = new MyRunnable(i);
                  executor.execute(worker);
            }
            executor.shutdown();
              // Wait until all threads are finish
            while (!executor.isTerminated()) {
              }

    }
}
