//$Id$
package com.zoho.livedesk.client.ZohoDesk;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


public class TicketDetails
{
	public static void openTicket(WebDriver driver,final WebElement ticket,final String id) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        // ticket.click();

        CommonUtil.clickWebElement(driver,CommonUtil.getElement(ticket,By.className("spt_tktdatatxt")));

        final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",id),"id","zsreqdetail");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!div.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(1000);
    }

    public static void clickCloseWindowInTicket(WebDriver driver,final WebElement ticket) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        CommonUtil.elementfinder(driver,ticket,"classname","sptkt_close").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(1000);
    }

    public static void clickMoreInTicket(WebDriver driver,final WebElement ticket) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.findElement(By.xpath("//span[@id='morelink']")).getText().equals("More"))
                {
                    return true;
                }
                return false;
            }
        });
        
        CommonUtil.elementfinder(driver,ticket,"xpath","//span[@id='morelink']//a").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.findElement(By.xpath("//span[@id='morelink']")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!ticket.findElement(By.xpath("//span[@id='hidelink']")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!ticket.findElement(By.xpath("//div[@id='morecontent']")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,ticket,"xpath","//div[@class='spt_tktcntinfotit'][contains(text(),'Ticket Information')]");
	}

	public static void clickHideInTicket(WebDriver driver,final WebElement ticket) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        CommonUtil.elementfinder(driver,ticket,"xpath","//span[@id='hidelink']//a").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.findElement(By.xpath("//span[@id='hidelink']")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!ticket.findElement(By.xpath("//span[@id='morelink']")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.findElement(By.xpath("//div[@id='morecontent']")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static String getDetailsInTicket(WebDriver driver,WebElement ticket,String lhs) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        List<WebElement> list = CommonUtil.elementfinder(driver,ticket,"id","morecontent").findElements(By.className("spt-tktmoredetlmn"));

        for(WebElement e : list)
        {
        	if(CommonUtil.elementfinder(driver,e,"classname","spt-tktmoredetlft").getText().contains(lhs))
        	{
        		return CommonUtil.elementfinder(driver,e,"classname","spt-tktmoredetrht").getText();
        	}
        }

        return null;
	}

	public static String getStatusInTicket(WebDriver driver,WebElement ticket) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        return CommonUtil.elementfinder(driver,ticket,"css","div.spt-tktsts.txtelips").getText();
	}

	public static void clickChatHeaderInTicket(WebDriver driver,WebElement ticket) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        final WebElement chat = ticket.findElements(By.className("spt-tktmsgmn")).get(0);

        if(chat.getAttribute("class").contains("spt-sel"))
        {
            WebElement e = CommonUtil.elementfinder(driver,chat,"classname","spt-tktmsgemdt");
            wait.until(ExpectedConditions.visibilityOf(e));
        	e.click();
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!chat.findElement(By.id("messagediv")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static boolean clickFeedBackHeaderInTicket(WebDriver driver,WebElement ticket) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        List<WebElement> list = ticket.findElements(By.className("spt-tktmsgmn"));

        if(list.size() <= 1)
        {
        	return false;
        }

        final WebElement chat = list.get(1);

        if(chat.getAttribute("class").contains("spt-sel"))
        {
            WebElement e = CommonUtil.elementfinder(driver,chat,"classname","spt-tktmsgemdt");
            wait.until(ExpectedConditions.visibilityOf(e));
            e.click();
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!chat.findElement(By.id("messagediv")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        return true;
	}

	public static boolean checkMessageInChatTranscriptInTicket(WebDriver driver,WebElement ticket,int line,String sender,String message) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        CommonWait.waitTillDisplayed(ticket,By.id("messagediv"));
        
        WebElement msgdiv = CommonUtil.getElement(ticket,By.id("messagediv"));

        if(!msgdiv.getAttribute("innerHTML").contains("Question"))
        {
            return false;
        }

        List<WebElement> list = CommonUtil.elementfinder(driver,msgdiv,"tagname","tbody").findElements(By.tagName("tr"));

        List<WebElement> msg = list.get(line).findElements(By.tagName("td"));

        System.out.println("<><><><><><>"+msg.get(0).getText()+"<><><><><><>"+msg.get(1).getText());

        if(msg.get(0).getText().contains(sender) && msg.get(1).getText().contains(message))
        {
        	return true;
        }

        return false;
	}

    public static boolean checkFeedBackInChatTranscriptInTicket(WebDriver driver,WebElement ticket,String feedback) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        List<WebElement> list1 = ticket.findElements(By.className("spt-tktmsgmn"));

        if(list1.size() <= 1)
        {
            return false;
        }

        final WebElement chat = list1.get(1);

        CommonWait.waitTillDisplayed(chat,By.id("messagediv"));
        
        WebElement msgdiv = CommonUtil.elementfinder(driver,chat,"id","messagediv");

        if(!CommonWait.isDisplayed(msgdiv))
        {
            return false;
        }

        List<WebElement> list = CommonUtil.elementfinder(driver,msgdiv,"tagname","tbody").findElements(By.tagName("tr"));

        WebElement msg = list.get(0);

        System.out.println("<><><><><><>"+msg.getText());

        if(msg.getText().contains(feedback))
        {
            return true;
        }

        return false;
    }

    public static void changeStatus(WebDriver driver,final WebElement ticket,String status,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        CommonUtil.elementfinder(driver,ticket,"classname","sptsts_arw").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.findElement(By.className("sptsts_drp")).getAttribute("style").contains("block") || !ticket.findElement(By.className("sptsts_drp")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,ticket,"classname","sptsts_drp"),"xpath","//li[@val='"+status+"']").click();

        Tab.waitForLoading(driver,"updateinteg.do",etest);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(ticket.findElement(By.className("sptsts_drp")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    public static WebElement getSearchIcon(WebDriver driver,String chat,String id) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        WebElement search = CommonUtil.elfinder(driver,"xpath","//div[@id='"+chat+"']//div[@id='visdatapar']//div[@id='"+id+"']//div[@id='searicodiv']");

        //CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",chat),"id",id),"xpath","//div[@id='searicodiv']");

        wait.until(ExpectedConditions.visibilityOf(search));

        return search;
    }

    public static void clickSearch(WebDriver driver,final String chat,String id) throws Exception
    {
        getSearchIcon(driver,chat,id).click();

        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id(chat)).findElement(By.id("vinfosearchdiv")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id(chat)).findElement(By.id("vinfodetaildiv")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(500);
    }

    public static void sentSearchKey(WebDriver driver,String chat,String key) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        WebElement search = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",chat),"xpath","//div[@id='vinfosearchdiv']//div[@id='seardiv']//input");

        wait.until(ExpectedConditions.visibilityOf(search));

        search.click();
        Thread.sleep(1000);

        search.sendKeys(key);
        search.sendKeys(Keys.RETURN);
    }

    public static List<WebElement> getSearchList(WebDriver driver,final String chat,final int count) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",chat),"xpath","//div[@id='vinfosearchdiv']//div[@id='listdata']");
        
        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("innerHTML").contains("spt_tktdatamn"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.findElements(By.className("spt_tktdatamn")).size() == count)
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            CommonUtil.doNothing();
        }

        return div.findElements(By.className("spt_tktdatamn"));
    }

    public static void getBackToDetails(WebDriver driver,final String chat) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        CommonUtil.clickWebElement(driver,By.id("vinfosearchdiv"),By.className("rcvstbtmbtn"),By.tagName("span"));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id(chat)).findElement(By.id("vinfosearchdiv")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id(chat)).findElement(By.id("vinfodetaildiv")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(500);
    }

    public static void openDeskPage(WebDriver driver,WebElement ticket) throws Exception 
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        CommonUtil.elementfinder(driver,ticket,"id","wopen").click();
    }
}
