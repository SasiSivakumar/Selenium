//$Id$
package com.zoho.livedesk.client.Apps;

import java.util.Hashtable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.Apps.AppsComponent;
import com.zoho.livedesk.util.common.actions.Apps.AppsView;

public class AppsComponentsModuleTests {
 public static Hashtable < String, Boolean > result = new Hashtable();
 public static Hashtable < String, Hashtable < String, Boolean >> hashtable = new Hashtable();
 public static Hashtable < String, Boolean > servicedown = new Hashtable();
 public static ExtentTest etest;
 public static VisitorDriverManager visitor_driver_manager;
 public static String moduleName = "";
 public static String widgetCode = "", websiteName = "", embedName = "";;
 /*Constants*/
 public static final By
 VIEW_APP = By.cssSelector("[onclick*='apps/view']"),
 GO_TO_APPS = By.id("menu_apps");

 public static Hashtable test(WebDriver driver) {
  try {

   visitor_driver_manager = new VisitorDriverManager();
   result = new Hashtable < String, Boolean > ();

   websiteName = ExecuteStatements.getDefaultEmbedName(driver);
   widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver, websiteName);
   embedName = ExecuteStatements.getEmbedNameFromWidgetCode(driver, widgetCode);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM1"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM1", enableLivechat(driver, etest, widgetCode, embedName));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM2"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM2", disableLivechat(driver, etest, widgetCode));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM3"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM3", enableVisitorTracking(driver, etest, widgetCode,embedName));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM4"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM4", disableVisitorTracking(driver, etest, widgetCode));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM5"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM5", enableArticle(driver, etest, widgetCode));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM6"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM6", disableArticle(driver, etest, widgetCode));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM7"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM7", enableWebsite(driver, etest, widgetCode));
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPSCOM9"));
   ComplexReportFactory.setValues(etest, "Automation", moduleName);
   result.put("APPSCOM9", disableWebsite(driver, etest, widgetCode));
   ComplexReportFactory.closeTest(etest);

   visitor_driver_manager.terminateAllDriverSessions();


  } catch (Exception e) {
   etest.log(Status.FATAL, "Apps Components Module error");
   etest.log(Status.FATAL, "Module breakage occurred " + e);
   TakeScreenshot.screenshot(driver, etest, "Apps Components", "Exception", "Module breakage", e);
  }
  hashtable.put("result", result);
  hashtable.put("servicedown", servicedown);
  return hashtable;
 }


 public static boolean enableLivechat(WebDriver driver, ExtentTest etest, String widgetCode, String embedName) throws Exception {
  try {
   AppsComponent.gotoApps(driver, etest);
   AppsView.openApp(driver, etest, embedName);
   AppsComponent.clickComponents(driver, etest);
   if (isWebContentdisplayed(driver)) {
    checkEnableLivechat(driver, etest);
    CommonUtil.switchToTab(driver, 0);
    etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
    WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    VisitorWindow.createPage(visitor_driver, widgetCode);
    etest.log(Status.PASS, "LiveChat from visitor side is displayed.");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
   }
   return true;
  } catch (Exception e) {
   etest.log(Status.FAIL, "Live chat is not enabled");
   TakeScreenshot.screenshot(driver, etest, "App Components", " Live Chat Off", "Exception", e);
  }
  return false;
 }


 public static boolean disableLivechat(WebDriver driver, ExtentTest etest, String widgetCode) throws Exception {
  try {
   //Switch Tab
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page of SalesIQ portal to disable livechat");
   if (isWebContentdisplayed(driver)) {
    checkdisableLivechat(driver, etest);
    CommonUtil.switchToTab(driver, 0);
    WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    VisitorWindow.createPage(visitor_driver, widgetCode, false);
    TakeScreenshot.infoScreenshot(visitor_driver, etest);

    if (VisitorWindow.isFloatWidgetFound(visitor_driver) == false) {
     etest.log(Status.PASS, "LiveChat from visitor side is not displayed ");
     return true;
    } else {
     etest.log(Status.FAIL, "Live chat is displayed");
     return false;
    }
   }
  } catch (Exception e) {
   etest.log(Status.FAIL, "Live chat is displayed");
   TakeScreenshot.screenshot(driver, etest, "App Components", " Live Chat On", "Exception", e);
  }
  return false;
 }


 public static boolean enableVisitorTracking(WebDriver driver, ExtentTest etest, String widgetCode,String embedName) throws Exception {

  try {
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page of SalesIQ portal");
   checkenablevisitorTracking(driver, etest);
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   VisitorWindow.createPage(visitor_driver, widgetCode);
   etest.log(Status.PASS, "LiveChat from visitor side is displayed ");
   CommonWait.waitTillDisplayed(driver, By.id("suppm_tracking"));
   CommonUtil.getElement(driver, By.id("suppm_tracking")).click();
   CommonWait.waitTillDisplayed(driver, By.id("ldwrap"));
   String visitorId = visitor_driver.manage().getCookieNamed(embedName+"-_zldt").getValue().toString();
   WebElement isVisitordisplayed = CommonUtil.getElement(driver, By.id(visitorId));
   CommonUtil.sleep(2000);
   if (isVisitordisplayed.isDisplayed()) {
    etest.log(Status.PASS, "Visitor online is Tracked in rings ");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   } else {
    etest.log(Status.FAIL, "Visitor online is not Tracked in rings ");
    TakeScreenshot.infoScreenshot(driver, etest);
    return false;
   }
  } catch (Exception e) {
   etest.log(Status.FAIL, "Live chat is not enabled");
   TakeScreenshot.screenshot(driver, etest, "App Components", " Live Chat Off", "Exception", e);
  }
  return false;
 }


 public static boolean disableVisitorTracking(WebDriver driver, ExtentTest etest, String widgetCode) throws Exception {

  try {
   //Switch Tab 
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page of SalesIQ portal");
   checkdisablevisitorTracking(driver, etest);
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesI portal");
   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   VisitorWindow.createPage(visitor_driver, widgetCode);
   if (CommonWait.waitTillDisplayed(driver, By.id("suppm_tracking"))) {
    CommonUtil.getElement(driver, By.id("suppm_tracking")).click();
    CommonWait.waitTillDisplayed(driver, By.id("ldwrap"));
    etest.log(Status.PASS, "Visitor online is not Tracked in rings as Tracking-Off");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
  } catch (Exception e) {
   etest.log(Status.FAIL, "Live chat is not enabled");
   TakeScreenshot.screenshot(driver, etest, "App Components", " Visiotr Online is displaying in rings", "Exception", e);
  }
  return false;
 }


 public static boolean enableArticle(WebDriver driver, ExtentTest etest, String widgetCode) throws Exception {

  try {
   //Switch Tab 
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page of SalesIQ portal");

   checkenableArticle(driver, etest);
   etest.log(Status.INFO, "Articles Enabled");
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   VisitorWindow.createPage(visitor_driver, widgetCode);
   VisitorWindow.clickChatButton(visitor_driver);
   if (VisitorWindow.isArticlesTabFound(visitor_driver)) {
    etest.log(Status.PASS, "Articles tab in Visitor Window is Displayed");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    return true;
   } else {
    etest.log(Status.FAIL, "Articles tab in Visitor Window is Not Found");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    return false;
   }
  } catch (Exception e) {
   etest.log(Status.FAIL, "Articles is not enabled");
   TakeScreenshot.screenshot(driver, etest, "App Components", " Articles Off", "Exception", e);
  }
  return false;
 }


 public static boolean disableArticle(WebDriver driver, ExtentTest etest, String widgetCode) throws Exception {

  try {
   //Switch Tab
   CommonUtil.switchToTab(driver, 1);
   if (isWebContentdisplayed(driver)) {
    checkdisableArticle(driver, etest);
    etest.log(Status.INFO, "Articles Disabled");
    CommonUtil.switchToTab(driver, 0);
    etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
    WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    VisitorWindow.createPage(visitor_driver, widgetCode);
    VisitorWindow.clickChatButton(visitor_driver);
    checkdisableArticlesTab(visitor_driver);
    etest.log(Status.PASS, "Articles tab in visitor window is Disabled / OFF");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    return true;
   }
  } catch (Exception e) {
   etest.log(Status.FAIL, "Articles is  enabled");
   TakeScreenshot.screenshot(driver, etest, "App Components", " Articles On", "Exception", e);
  }
  return false;
 }


 public static boolean enableWebsite(WebDriver driver, ExtentTest etest, String widgetCode) throws Exception {
  try {
   clickInstallation(driver, etest);
   CommonWait.waitTillDisplayed(driver, By.className("app-lst-item"));
   CommonUtil.getElement(driver, By.cssSelector("div[state='website']"));
   if (isWebsiteoff(driver)) {
    etest.log(Status.INFO, "Website is disabled/off by default");
    CommonUtil.getElement(driver, By.className("switch-crcl")).click();
    etest.log(Status.PASS, "Website is Enabled now");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.PASS, "Website is Enabled now");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='fsiq-close']"));
   CommonUtil.getElement(driver, By.cssSelector("[class*='fsiq-close']")).click();

   if (enableLivechat(driver, etest, widgetCode, embedName)) {
    result.put(KeyManager.getRealValue("APPSCOM8"), true);
    etest.log(Status.PASS, "Website is Enabled and live chat is enabled in components page of apps");
    etest.log(Status.PASS, "Website is Enabled and chat widget is shown in visitor side");
    return true;
   }

  } catch (Exception e) {
   etest.log(Status.FAIL, "Website is not enabled");
   TakeScreenshot.screenshot(driver, etest, "App Website", " Website Off", "Exception", e);
  }
  return false;
 }

 public static boolean disableWebsite(WebDriver driver, ExtentTest etest, String widgetCode) throws Exception {
  try {
   //Switch Tab
   clickInstallation(driver, etest);
   CommonWait.waitTillDisplayed(driver, By.className("app-lst-item"));
   CommonUtil.getElement(driver, By.cssSelector("div[state='website'][data-key='website']"));
   if (isWebsiteOn(driver)) {
    etest.log(Status.INFO, "Website is On / Enabled by default");
    CommonUtil.getElement(driver, By.className("switch-crcl")).click();
    etest.log(Status.PASS, "Website is Disabled now");
    TakeScreenshot.screenshot(driver, "App Website", "Website Disabled", "Pass");
   } else {
    etest.log(Status.PASS, "Website is Disabled now");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='fsiq-close']"));
   CommonUtil.getElement(driver, By.cssSelector("[class*='fsiq-close']")).click();
   TakeScreenshot.infoScreenshot(driver, etest);
   AppsComponent.clickComponents(driver, etest);
   if (disableLivechat(driver, etest, widgetCode)) {
    result.put(KeyManager.getRealValue("APPSCOM10"), true);
    etest.log(Status.PASS, "Website is Disabled and live chat is disabled / Off in components page of apps");
    etest.log(Status.PASS, "Website is Disabled and chat widget is hidden in visitor side");
    return true;
   }
  } catch (Exception e) {
   etest.log(Status.FAIL, "Website is not enabled");
   TakeScreenshot.screenshot(driver, etest, "App Website", " Website On", "Exception", e);
  }
  return false;
 }




 public static boolean checkEnableLivechat(WebDriver driver, ExtentTest etest) {
  CommonUtil.switchToTab(driver, 1);
  CommonWait.isPresent(driver, By.cssSelector("[class*='fsiq-component']"));
  if (CommonUtil.getElement(driver, By.cssSelector("[class='cmpnt-switch-wrap '][id='website_chat']")).isDisplayed()) {
   etest.log(Status.PASS, "LiveChat in Website was Enabled / ON");
   TakeScreenshot.infoScreenshot(driver, etest);
   
  } else if (CommonUtil.getElement(driver, By.cssSelector("[class$='switch-off'][id='website_chat']")).isDisplayed()) {
   CommonUtil.getElement(driver, By.id("website_chat")).findElement(By.cssSelector("div[data-key='chat']")).click();
   etest.log(Status.PASS, "LiveChat in Website is Enabled");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
  return false;
 }

 public static boolean checkdisableLivechat(WebDriver driver, ExtentTest etest) {
  CommonUtil.switchToTab(driver, 1);
  CommonWait.isPresent(driver, By.cssSelector("[class*='fsiq-component']"));
  CommonUtil.getElement(driver, By.id("website_chat")).findElement(By.cssSelector("div[data-key='chat']")).click();
  if (CommonUtil.getElement(driver, By.cssSelector("[class$='switch-off'][id='website_chat']")).isDisplayed()) {
   etest.log(Status.PASS, "LiveChat in Website was Diabled / OFF");
   TakeScreenshot.infoScreenshot(driver, etest);
  } else {
   CommonUtil.getElement(driver, By.id("website_chat")).click();
   etest.log(Status.PASS, "LiveChat in Website is Disabled");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
  return false;
 }


 public static boolean isWebContentdisplayed(WebDriver driver) {
  return CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='instl-web-cont']"));
 }

 public static void checkenablevisitorTracking(WebDriver driver, ExtentTest etest) {


  if (CommonUtil.getElement(driver, By.cssSelector("[class$='switch-off'][id='website_chat']")).isDisplayed()) {

   CommonUtil.getElement(driver, By.id("website_chat")).click();
   etest.log(Status.PASS, "LiveChat in Website was Enabled / ON");
   TakeScreenshot.infoScreenshot(driver, etest);
  }
  if (CommonUtil.getElement(driver, By.cssSelector("div[class*='cmpnt-switch-wrap'][id='website_proactive']")).isDisplayed()) {
   etest.log(Status.INFO, "Visitor Tracking in Website was Enabled / ON");
   TakeScreenshot.infoScreenshot(driver, etest);
  } else {
   CommonUtil.getElement(driver, By.id("website_proactive")).findElement(By.cssSelector("[documentclick='switchComponent']")).click();
   etest.log(Status.INFO, "Visitor Tracking in Website was Enabled / ON");
   TakeScreenshot.infoScreenshot(driver, etest);
  }
 }


 public static void checkdisablevisitorTracking(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='instl-web-cont']"));
  CommonUtil.getElement(driver, By.id("website_proactive")).findElement(By.cssSelector("[documentclick='switchComponent']")).click();

  if (CommonUtil.getElement(driver, By.cssSelector("div[class$='switch-off'][id='website_proactive']")).isDisplayed()) {
   etest.log(Status.INFO, "Visitor Tracking in Website was Disabled / OFF");
   TakeScreenshot.infoScreenshot(driver, etest);
  } else {
   CommonUtil.getElement(driver, By.id("website_proactive")).findElement(By.cssSelector("[documentclick='switchComponent']")).click();
   etest.log(Status.INFO, "Visitor Tracking in Website was Disabled / OFF");
   TakeScreenshot.infoScreenshot(driver, etest);
  }

 }

 public static void checkenableArticle(WebDriver driver, ExtentTest etest) {

  CommonUtil.getElement(driver, By.id("website_faq")).findElement(By.cssSelector("[documentclick='switchComponent']")).click();
  etest.log(Status.INFO, "Articles in Website was Enabled / ON");
  TakeScreenshot.infoScreenshot(driver, etest);
 }
 public static void checkdisableArticle(WebDriver driver, ExtentTest etest) {

  CommonUtil.getElement(driver, By.id("website_faq")).findElement(By.cssSelector("[documentclick='switchComponent']")).click();
  etest.log(Status.INFO, "Articles in Website was Disabled / OFF");
  TakeScreenshot.infoScreenshot(driver, etest);
 }


 public static boolean clickInstallation(WebDriver driver, ExtentTest etest) {
  try {
   //Switch Tab 
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page of SalesIQ portal");
   clickClose(driver, etest);
   CommonWait.waitTillDisplayed(driver, By.cssSelector("[onclick*='/installation')]"));
   CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='fsiq-installation']"));
   CommonUtil.getElement(driver, By.cssSelector("[class*='fsiq-installation']")).click();
   etest.log(Status.PASS, "Page navigated to Installation");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  } catch (Exception e) {
   etest.log(Status.FAIL, "Installation may not be present");
   TakeScreenshot.screenshot(driver, etest, "Apps Installation", "Installation section", "Installation section details missing", e);
  }
  return false;
 }

 public static boolean checkdisableArticlesTab(WebDriver driver) {
  return CommonWait.waitTillDisplayed(driver, By.className("clearfix"));
 }

 public static boolean isWebsiteoff(WebDriver driver) {
  return CommonWait.waitTillDisplayed(driver, By.cssSelector("[data-val='false'][data-key='website']"));
 }

 public static boolean isWebsiteOn(WebDriver driver) {
  return CommonWait.waitTillDisplayed(driver, By.cssSelector("[data-val='true'][data-key='website'"));
 }

 public static void clickClose(WebDriver driver, ExtentTest etest) {
  CommonWait.isPresent(driver, By.cssSelector("[class*='fsiq-close']"));
  CommonUtil.getElement(driver, By.cssSelector("[class*='fsiq-close']")).click();
  etest.log(Status.INFO, "Current page closed");
 }
}