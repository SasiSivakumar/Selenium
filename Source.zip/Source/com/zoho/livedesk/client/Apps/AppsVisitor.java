//$Id$
package com.zoho.livedesk.client.Apps;

import java.util.Hashtable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.Test;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Apps.Apps;
import com.zoho.livedesk.util.common.actions.Apps.AppsComponent;
import com.zoho.livedesk.util.common.actions.Apps.AppsEdit;
import com.zoho.livedesk.util.common.actions.Apps.AppsView;
import com.zoho.livedesk.util.common.actions.Apps.AppsComponent;

public class AppsVisitor 
{
	
 public static Hashtable < String, Boolean > result = new Hashtable();
 public static Hashtable < String, Hashtable < String, Boolean >> hashtable = new Hashtable();
 public static Hashtable < String, Boolean > servicedown = new Hashtable();
 public static ExtentTest etest;
 public static VisitorDriverManager visitor_driver_manager;
 public static String module_name = "Apps Visitor";
 public static String widget_code = "", website_name = "", embed_name = "";
 static String visitorId;
 static String label = CommonUtil.getUniqueMessage();
 static String appName = "AppName_new";
 static String appDescription = "AppDescription_" + CommonUtil.getUniqueMessage() + "_new";
 static String vques = "Ques_" + label;
 static String vphone = label;
 static String vemail = "V" + label + "@email.com";
 static String vname = "Name_" + label;
 static String vmessage = "Visitor-Message_" + label;
 static String amessage = "Agent-Message_" + label;
 static String addDept = "Dept_" + label;
 static WebDriver driver1;

 /*Constants*/
 public static final By
  INCOMING_CHAT_CONTAINER_ID = By.id("waitinglist"),
  VIEW_APP = By.cssSelector("[onclick*='apps/view']"),
  GO_TO_APPS = By.id("menu_apps");


 public static Hashtable test(WebDriver driver) {
  try {

   driver1 = Functions.setUp();
   Functions.login(driver1, "appsvis1");
   Hashtable < String, Boolean > expected_result = null;

   visitor_driver_manager = new VisitorDriverManager();
   result = new Hashtable < String, Boolean > ();

   website_name = ExecuteStatements.getDefaultEmbedName(driver);
   widget_code = ExecuteStatements.getWidgetCodeFromEmbedName(driver, website_name);
   embed_name = ExecuteStatements.getEmbedNameFromWidgetCode(driver, widget_code);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPS19"));
   result.put("APPS19", checkInitiateProactivechat(driver, etest, widget_code, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPS20"));
   result.put("APPS20", checkEndchat(driver, etest, widget_code));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPS24"));
   result.put("APPS24", CheckifChatRoutedtoDepartments(driver, driver1, etest, widget_code, expected_result, AgentStatus.AVAILABLE));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPS25"));
   result.put("APPS25", checkChatwithOperatorsOffline(driver, etest, widget_code));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPS26"));
   result.put("APPS26", checkMissedChat(driver, etest, widget_code));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("APPS27"));
   result.put("APPS27", checkConfigureAppswithSingleDepartment(driver, etest, widget_code));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   Functions.logout(driver1);
   driver1.quit();

   visitor_driver_manager.terminateAllDriverSessions();
  } catch (Exception e) {
   etest.log(Status.FATAL, "Apps Visitor Module error");
   etest.log(Status.FATAL, "Module breakage occurred " + e);
   TakeScreenshot.screenshot(driver, etest, "Apps Visitor", "Exception", "Module breakage", e);

  }
  hashtable.put("result", result);
  hashtable.put("servicedown", servicedown);
  return hashtable;
 }



 public static boolean checkInitiateProactivechat(WebDriver driver, ExtentTest etest, String widget_code, String embed_name) throws Exception {
  try {
   AppsComponent.gotoApps(driver, etest);
   Apps.clickView(driver, etest);
   AppsView.openApp(driver, etest, embed_name);
   AppsComponent.clickComponents(driver, etest);
   AppsComponentsModuleTests.checkEnableLivechat(driver, etest);
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   VisitorWindow.createPage(visitor_driver, widget_code);
   if(!VisitorWindow.isFloatWidgetFound(visitor_driver)) {
  	 etest.log(Status.FAIL, "Chat Widget not Found");
       TakeScreenshot.screenshot(visitor_driver, etest, "Visitor Window", "Chat Widget- not Found", "Exception");       
  	  return false;
  }
   etest.log(Status.PASS, "LiveChat from visitor side is displayed ");
   String visitor_id = VisitorWindow.getVisitorId(visitor_driver, ExecuteStatements.getPortal(driver));
   CommonUtil.refreshPage(driver);
   CommonUtil.sleep(2000);
   ChatWindow.initiateChat(driver, visitor_id, amessage);
 
  if(!VisitorWindow.isChatWindowDisplayed(visitor_driver)) {
	  etest.log(Status.FAIL, "Chat Window is not Displayed");
	    TakeScreenshot.screenshot(visitor_driver, "Chat Initiate", "Visitor Window", "Window not Opened");
	  return false;
  }
  
    VisitorWindow. switchToChatWidget(driver);
    
    CommonWait.waitTillDisplayed(visitor_driver, By.xpath(ResourceManager.getRealValue("Theme.msgcontainer")));
    CommonWait.waitTillDisplayed(visitor_driver, By.xpath(ResourceManager.getRealValue("Theme.agentmsg")));
    CommonWait.waitTillDisplayed(visitor_driver, By.xpath(ResourceManager.getRealValue("Theme.agentname")));
    WebElement agentmsg= CommonUtil.getElement(visitor_driver, By.xpath(ResourceManager.getRealValue("Theme.agentmsg")));
   String actual= agentmsg.getText();    
    if(!CommonUtil.checkStringEqualsAndLog(amessage, actual, "Agent message in visitor chat window", etest)) {
        etest.log(Status.FAIL, "Agent message is not displayed in visitor chat");
        TakeScreenshot.screenshot(visitor_driver, "App Visitor", "Agent message in Vistior chat window", "not found");
        return false;
    }
    etest.log(Status.PASS, "Agent message displayed in visitor chat");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    result.put(KeyManager.getRealValue("APPS22"), true);
    VisitorWindow.sentMessageInTheme(visitor_driver, vmessage);
    ChatWindow.acceptChat(driver, etest);
    etest.log(Status.PASS, "Visitor Message displays in Agent window");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   

  } catch (Exception e) {
   etest.log(Status.FAIL, "Exception in Initiating Proactive Chat");
   TakeScreenshot.screenshot(driver, etest, "Apps", "Proactive Chat Initiate", "Exception in Finding Proactive chat/Visitor in rings", e);
  }
  return false;
 }

 public static boolean checkEndchat(WebDriver driver, ExtentTest etest, String widget_code) throws Exception {
  try {

   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to SalesIQ main page to Apps Page");

   if(!AppsComponent.checkisInComponentsPage(driver, etest)) {	   
	   CommonUtil.switchToTab(driver, 0);
	   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
	   AppsComponent.gotoApps(driver, etest);
	   Apps.clickView(driver, etest);
	   AppsView.openApp(driver, etest, embed_name);
	   AppsComponent.clickComponents(driver, etest);
	   return false;
   }
     
   AppsComponentsModuleTests.checkEnableLivechat(driver, etest);
    CommonUtil.switchToTab(driver, 0);
    etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");  
   
    WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    VisitorWindow.createPage(visitor_driver, widget_code);
    VisitorWindow.initiateChatVisTheme(visitor_driver, vname, vemail, vphone, vques, etest);
    if(!VisitorWindow.isChatWindowDisplayed(visitor_driver)) {
  	  etest.log(Status.FAIL, "Chat Window is not Displayed");
  	    TakeScreenshot.screenshot(visitor_driver, "Chat Initiate", "Visitor Window", "Window not Opened");
  	  return false;
    }
    ChatWindow.acceptChat(driver, etest);
    etest.log(Status.PASS, "Chat Accepted in Chat window");
    TakeScreenshot.infoScreenshot(driver, etest);
    CommonUtil.sleep(1000);
    ChatWindow.endChat(driver);
    etest.log(Status.PASS, "Chat Ended in Chat window");
    TakeScreenshot.infoScreenshot(driver, etest);
    
    VisitorWindow.checkChatEndedInTheme(visitor_driver);
    etest.log(Status.PASS, "Chat Ended in Visitor Chat");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    VisitorWindow.enterFeedbackInTheme(visitor_driver, "ThankYou", "3");
    if (VisitorWindow.isChatEnded(visitor_driver)) {
     VisitorWindow.continueChat(visitor_driver);
     etest.log(Status.PASS, "Chat Restarted in Visitor Window");
     TakeScreenshot.infoScreenshot(visitor_driver, etest);
     ChatWindow.acceptChat(driver, etest);
     etest.log(Status.PASS, "Chat Accepted in Chat window");
     TakeScreenshot.infoScreenshot(driver, etest);
     VisitorWindow.endChatVisitor(visitor_driver);
     etest.log(Status.PASS, "Chat Ended in Visitor Chat");
     TakeScreenshot.infoScreenshot(visitor_driver, etest);
     result.put(KeyManager.getRealValue("APPS21"), true);
     return true;
    }
   
  } catch (Exception e) {
   etest.log(Status.FAIL, "Chat is not ended");
   TakeScreenshot.screenshot(driver, etest, "Apps", "End Chat ", "Exception", e);
  }
  return false;
 }

 public static boolean CheckifChatRoutedtoDepartments(WebDriver driver, WebDriver driver1, ExtentTest etest, String widget_code, Hashtable < String, Boolean > expected_result, AgentStatus driver_status) throws Exception {

  int failcount = 0;
  Hashtable < String, Boolean > actual_result = null;
  try {
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");

   if (!Department.addDept(driver, addDept, "depttype_publi", ExecuteStatements.getUserName(driver), etest)) {
    etest.log(Status.FAIL, "Department is not added");
    TakeScreenshot.screenshot(driver, etest, "Apps", "Add dept", "Error");
    return false;
   }
   etest.log(Status.INFO, "Department '" + addDept + "' is added");
   TakeScreenshot.infoScreenshot(driver, etest);
   
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page from SalesIQ main page");

   if(AppsComponent.checkisInComponentsPage(driver, etest)) 
   {  	   
	   AppsComponent.closeComponentsPage(driver, etest);
   }  
   
   AppsEdit.clickSettingsIcon(driver);
   CommonUtil.refreshPage(driver);
 
   if (!isOnlyDefaultDeptPresentinApps(driver, etest)) {
	   etest.log(Status.FAIL, "Only Single Department is Configured");
		  TakeScreenshot.screenshot(driver, etest, "Apps", "Mutiple Departments configured", "App Exception");
		  return false;
	  }	

   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");

   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   Hashtable < String, String > visitor_details = ConversationViewCommonFunctions.addVisitorDetails("V" + label, "V" + label + "@email.com", null, ExecuteStatements.getSystemGeneratedDepartment(driver), "Q" + label + "?", "fb" + label, "3");
   ConversationViewCommonFunctions.setupChatType(driver, visitor_driver, etest, widget_code, ChatType.INITIATED, visitor_details, null);
   if(!VisitorWindow.isChatWindowDisplayed(visitor_driver)) {
		  etest.log(Status.FAIL, "Chat Window is not Displayed");
		    TakeScreenshot.screenshot(visitor_driver, "Chat Initiate", "Visitor Window", "Window not Opened");
		  return false;
	  }
   etest.log(Status.PASS, "Chat Initiated - Message sent from Visitor Window");
   TakeScreenshot.infoScreenshot(visitor_driver, etest);

   if (isChatRoutedToAgent(driver) || isChatRoutedToAgent(driver1)) {

    etest.log(Status.PASS, "Chat Routed to Username  '" + ExecuteStatements.getUserName(driver) + "' & '" + ExecuteStatements.getUserName(driver1) + "'.");
    TakeScreenshot.infoScreenshot(driver, etest);
    TakeScreenshot.infoScreenshot(driver1, etest);

   } else if (!isChatRoutedToAgent(driver)) {

    ChatWindow.acceptChat(driver, etest);
    etest.log(Status.INFO, "Chat accepted by '" + ExecuteStatements.getUserName(driver) + "' in respective department");
    TakeScreenshot.infoScreenshot(driver, etest);
    return false;
   } else if (!isChatRoutedToAgent(driver1)) {

    ChatWindow.acceptChat(driver1, etest);
    etest.log(Status.INFO, "Chat accepted by '" + ExecuteStatements.getUserName(driver1) + "' in respective department");
    TakeScreenshot.infoScreenshot(driver1, etest);
    return false;
   }

        Department.deleteDepartment(driver, addDept, ExecuteStatements.getSystemGeneratedDepartment(driver), etest);
   if (!Department.deleteDepartment(driver, addDept, ExecuteStatements.getSystemGeneratedDepartment(driver), etest)) {
    etest.log(Status.FAIL, "Department is not deleted");
    TakeScreenshot.screenshot(driver, etest, "Apps", "Delete Dept", "Error");
    return false;
   }
   etest.log(Status.PASS, "Department Added - Chat routed to respective Department - Department Deleted");
   return true;


  } catch (Exception e) {
   etest.log(Status.FAIL, "Exception in Adding Department");
   TakeScreenshot.screenshot(driver, etest, "Apps", "Department Routing", "Exception", e);
  }
  return false;

 }

 public static boolean checkChatwithOperatorsOffline(WebDriver driver, ExtentTest etest, String widget_code) throws Exception {
  try {
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");

   if (com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver) == AgentStatus.AVAILABLE) {
    com.zoho.livedesk.util.common.actions.Status.makeAgentAs(driver, etest, AgentStatus.BUSY);
    etest.log(Status.INFO, "Operators status changed to Busy");
    TakeScreenshot.infoScreenshot(driver, etest);
   }

   if (com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver1) == AgentStatus.AVAILABLE) {
    com.zoho.livedesk.util.common.actions.Status.makeAgentAs(driver1, etest, AgentStatus.BUSY);
    etest.log(Status.INFO, "Operators status changed to Busy");
    TakeScreenshot.infoScreenshot(driver1, etest);
   }

   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   VisitorWindow.createPage(visitor_driver, widget_code);

   if (!VisitorWindow.checkChatWidgetOffline(visitor_driver)) {
    etest.log(Status.FAIL, "Float Widget is in Online");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    return false;
   }
   etest.log(Status.PASS, "Float Widget is in Offline");
   TakeScreenshot.infoScreenshot(visitor_driver, etest);

   if (com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver1) == AgentStatus.BUSY) {
    com.zoho.livedesk.util.common.actions.Status.makeAgentAs(driver1, etest, AgentStatus.AVAILABLE);
    etest.log(Status.INFO, "Operators status changed to Available");
    TakeScreenshot.infoScreenshot(driver1, etest);

   }

  } catch (Exception e) {
   etest.log(Status.FAIL, "Operators maynot be in offilne");
   TakeScreenshot.screenshot(driver, etest, "Apps", "Proactive Chat Initiate", "Exception in Finding Proactive chat/Visitor in rings", e);
  }
  return false;
 }

 public static boolean checkMissedChat(WebDriver driver, ExtentTest etest, String widget_code) throws Exception {
  try {
   CommonUtil.switchToTab(driver, 0);
   etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
   VisitorWindow.createPage(visitor_driver, widget_code);
   
   if(VisitorWindow.checkMandatoryFields(visitor_driver, "department")) {
	   
	   VisitorWindow.initiateChatVisTheme(visitor_driver, vname, vemail, vphone,ExecuteStatements.getSystemGeneratedDepartment(driver), vques, etest);
   }else {
   VisitorWindow.initiateChatVisTheme(visitor_driver, vname, vemail, vphone, vques, etest);
   }
   if(!VisitorWindow.isChatWindowDisplayed(visitor_driver)) {
		  etest.log(Status.FAIL, "Chat Window is not Displayed");
		    TakeScreenshot.screenshot(visitor_driver, "Chat Initiate", "Visitor Window", "Window not Opened");
		  return false;
	  }
   etest.log(Status.PASS, "Chat Initiated from Visitor");
   TakeScreenshot.infoScreenshot(visitor_driver, etest);
   if (ChatWindow.chatNotificationPresence(driver, etest, 35)) {
    ChatWindow.ignoreChat(driver);
    etest.log(Status.PASS, "Accept chat window is waited till it missed");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);
    checkVisitorPresentInMissedList(driver, etest);
    etest.log(Status.PASS, "Chat found in Missed chat");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }

  } catch (Exception e) {
   etest.log(Status.FAIL, "Exception in Initiating Proactive Chat");
   TakeScreenshot.screenshot(driver, etest, "Apps", "Proactive Chat Initiate", "Exception in Finding Proactive chat/Visitor in rings", e);
  }
  return false;
 }

 public static boolean checkConfigureAppswithSingleDepartment(WebDriver driver, ExtentTest etest, String widget_code) {

  try {
   CommonUtil.switchToTab(driver, 1);
   etest.log(Status.INFO, "Tab Switched to Apps page from SalesIQ main page");
   
   if(AppsComponent.checkisInSettingsPage(driver, etest)) 
   {	   
	   CommonWait.waitTillDisplayed(driver, By.id("department_block"));
   }      
   CommonUtil.refreshPage(driver);
   if (isOnlyDefaultDeptPresentinApps(driver, etest)) {
	   etest.log(Status.PASS, "Only single Department Configured");
	    TakeScreenshot.infoScreenshot(driver, etest);
	   
	   }else {
		   etest.log(Status.FAIL, "Multiple Departments Configured");
		   TakeScreenshot.screenshot(driver, etest, "Apps", "Mutiple Departments configured", "App  Exception");
	   }
    CommonUtil.switchToTab(driver, 0);
    etest.log(Status.INFO, "Tab Switched to main page of SalesIQ portal");
    
    WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    VisitorWindow.createPage(visitor_driver, widget_code);
    if(!VisitorWindow.isFloatWidgetFound(visitor_driver)) {
    	 etest.log(Status.FAIL, "Chat Widget not Found");
         TakeScreenshot.screenshot(visitor_driver, etest, "Visitor Window", "Chat Widget- not Found", "Exception");       
    	  return false;
    }
    if (VisitorWindow.checkMandatoryFields(visitor_driver, "department")) {
     etest.log(Status.FAIL, "Multiple Departments are configured in Apps.- Department Field Present in Visitor Chat");
     TakeScreenshot.screenshot(driver, etest, "Apps", "Mutiple Departments configured", "App  Exception");
     return false;
    }
    etest.log(Status.PASS, "");
    TakeScreenshot.infoScreenshot(driver, etest);
    VisitorWindow.initiateChatVisTheme(visitor_driver, vname, vemail, vphone, vques, etest);
    if(!VisitorWindow.isChatWindowDisplayed(visitor_driver)) {
  	  etest.log(Status.FAIL, "Chat Window is not Displayed");
  	    TakeScreenshot.screenshot(visitor_driver, "Chat Initiate", "Visitor Window", "Window not Opened");
  	  return false;
    }
    etest.log(Status.PASS, "Chat Initiated from Visitor");
    TakeScreenshot.infoScreenshot(visitor_driver, etest);    
    if (!isChatRoutedToAgent(driver)) {
     ChatWindow.acceptChat(driver, etest);
     etest.log(Status.FAIL, "Chat is not routed to '" + ExecuteStatements.getUserName(driver) + "' in respective department");
     TakeScreenshot.infoScreenshot(driver, etest);
     return false;
     
    }
    etest.log(Status.PASS, "Chat Routed and  accepted by '" + ExecuteStatements.getUserName(driver) + "' in respective department");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
  } catch (Exception e) {
   etest.log(Status.FAIL, "Exception in Code");
   TakeScreenshot.screenshot(driver, etest, "Apps", "Exception in Code", "App  Exception");
  }
  return false;
 }


 public static boolean isOnlyDefaultDeptPresentinApps(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("department_block"));
  CommonUtil.getElement(driver, By.id("department_block")).findElement(By.id("departments_tagtitle"));

  if (CommonWait.isPresent(driver, By.className("fsiq-close hide"))) {
   etest.log(Status.INFO, "Only default Department is Configured");
   TakeScreenshot.infoScreenshot(driver, etest);  
  }
  return true; 
 }
 

 public static boolean checkVisitorPresentInMissedList(WebDriver driver, ExtentTest etest) throws Exception {
  Tab.clickMissed(driver);
  if (CommonUtil.elementfinder(driver, CommonUtil.elfinder(driver, "id", "missed_mcontent"), "id", "historylist").findElements(By.className("cursr-point")).get(0) != null) {
   return true;
  }
  return false;
 }

 public static boolean isChatRoutedToAgent(WebDriver driver) {
  return CommonWait.waitTillDisplayed(driver, INCOMING_CHAT_CONTAINER_ID);
 }

}