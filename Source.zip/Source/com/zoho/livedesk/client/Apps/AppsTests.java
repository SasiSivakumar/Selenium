//$Id$
package com.zoho.livedesk.client.Apps;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.actions.Apps.*;

public class AppsTests
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Apps",DEPT1="Department1",DEPT2="Department2";
	public static String widget_code="",website_name="",global_unique="",test_app_name="";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            global_unique=CommonUtil.getUniqueMessage();
            test_app_name="app_"+global_unique;

            website_name=ExecuteStatements.getDefaultEmbedName(driver);
            widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website_name);

			etest=ComplexReportFactory.getTest("Setup portal");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			setup(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check add app & view app button");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkButton(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check enable app & disable app");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEnableDisableApp(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check active and inactive apps count");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkActiveInactiveCount(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Create App");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCreateApp(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Edit Page Buttons");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEditAppPageTabs(driver,etest);
            ComplexReportFactory.closeTest(etest);

            for(String theme : VisitorWindow.FLOAT_THEME_LIST)
            {
            	if(theme!=null)
            	{
					etest=ComplexReportFactory.getTest("Apps-Check Float Theme-"+theme);
					ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
					checkTheme(driver,etest,VisitorWindow.FLOAT_THEME,theme);
		            ComplexReportFactory.closeTest(etest);
            	}
            }

            for(String theme : VisitorWindow.BUTTON_THEME_LIST)
            {
            	if(theme!=null)
            	{
					etest=ComplexReportFactory.getTest("Apps-Check Button Theme-"+theme);
					ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
					checkTheme(driver,etest,VisitorWindow.BUTTON_THEME,theme);
		            ComplexReportFactory.closeTest(etest);
            	}
            }

            int[] waiting_times={30,45,60,90,120};

            for(int waiting_time : waiting_times)
            {
				etest=ComplexReportFactory.getTest("Apps-Check Waiting Time-"+waiting_time+" Seconds");
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				result.put("apps_waiting_"+waiting_time, checkWaitingTimer(driver,etest,waiting_time) );
	            ComplexReportFactory.closeTest(etest);
            }

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("APPS17")+" and "+KeyManager.getRealValue("APPS18"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDepartment(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Apps-Settings-Enable transcript,conversations,emojis,fileshare and screenshare for visitor and check in visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkGeneralSettingsTabCheckboxes(driver,etest,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Apps-Settings-Disable transcript,conversations,emojis,fileshare and screenshare for visitor and check in visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkGeneralSettingsTabCheckboxes(driver,etest,false);
            ComplexReportFactory.closeTest(etest);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            
		return finalResult;
	}

	public static void setup(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Util.goToSalesIQ(driver);

			String user1=ExecuteStatements.getUserName(driver);

			if(Department.isDepartmentNamePresent(driver,DEPT1)==false)
			{
				Department.addDept(driver,DEPT1,"depttype_publi",user1,etest);
			}	
			if(Department.isDepartmentNamePresent(driver,DEPT2)==false)
			{
				Department.addDept(driver,DEPT2,"depttype_publi",user1,etest);
			}	

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
	}

	public static void checkButton(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			Util.goToSalesIQ(driver);

			Tab.goToApps(driver);

			//click view app button
			if(Apps.clickView(driver,etest))
			{
				etest.log(Status.PASS,AppsView.PAGE+" page was opened after clicking view button");
				result.put("APPS1",true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,AppsView.PAGE+" page was NOT opened after clicking view button");
				result.put("APPS1",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			AppsView.close(driver);

			//click add app button
			if(Apps.clickAdd(driver,etest))
			{
				etest.log(Status.PASS,AppsAdd.PAGE+" page was opened after clicking view button");
				result.put("APPS2",true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,AppsAdd.PAGE+" page was NOT opened after clicking view button");
				result.put("APPS2",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			AppsView.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	//check active and inactive
	public static void checkEnableDisableApp(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name1=test_app_name,
			app_desc1="desc1_"+unique,
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			ArrayList<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Tab.goToApps(driver);

			//create an app1
			if(Apps.isAppFound(driver,etest,app_name1)==false)
			{
				Apps.createNewApp(driver,etest,app_name1,app_desc1,departments);
			}

			//get the widget code
			Util.goToSalesIQ(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,app_name1);

			Apps.toggleApp(driver,etest,app_name1,false);

			Util.goToSalesIQ(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code,false);

			if(VisitorWindow.isFloatWidgetFound(visitor_driver)==false)
			{
				result.put("APPS4",true);
				etest.log(Status.PASS,"App '"+app_name1+"' was NOT found in visitor side after it was disabled");
			}
			else
			{
				result.put("APPS4",false);
				etest.log(Status.FAIL,"App '"+app_name1+"' was found in visitor side after it was disabled");		
				TakeScreenshot.screenshot(visitor_driver,etest);		
			}

			Apps.toggleApp(driver,etest,app_name1,true);

			Util.goToSalesIQ(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code,false);

			if(VisitorWindow.isFloatWidgetFound(visitor_driver))
			{
				result.put("APPS3",true);
				etest.log(Status.PASS,"App '"+app_name1+"' was found in visitor side after it was enabled");
			}
			else
			{
				result.put("APPS3",false);
				etest.log(Status.FAIL,"App '"+app_name1+"' was NOT found in visitor side after it was enabled");		
				TakeScreenshot.screenshot(visitor_driver,etest);		
			}

			Apps.deleteApp(driver,etest,app_name1);

			if(Apps.isAppFound(driver,etest,app_name1)==false)
			{
				etest.log(Status.PASS,"Deleted app '"+app_name1+"' was NOT found in apps page after it was deleted");
				result.put("APPS5",true);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted app '"+app_name1+"' was found in apps page after it was deleted");
				TakeScreenshot.screenshot(driver,etest);
				result.put("APPS5",false);
			}

			Util.goToSalesIQ(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code,false);

			if(VisitorWindow.isFloatWidgetFound(visitor_driver)==false)
			{
				result.put("APPS6",true);
				etest.log(Status.PASS,"App '"+app_name1+"' was NOT loaded in visitor side after it was deleted");
			}
			else
			{
				result.put("APPS6",false);
				etest.log(Status.FAIL,"App '"+app_name1+"' was loaded in visitor side after it was deleted");		
				TakeScreenshot.screenshot(visitor_driver,etest);		
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	//check active and inactive count
	public static void checkActiveInactiveCount(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name1=test_app_name,
			app_desc1="desc1_"+unique,
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			ArrayList<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Tab.goToApps(driver);

			//create an app1
			if(Apps.isAppFound(driver,etest,app_name1)==false)
			{
				Apps.createNewApp(driver,etest,app_name1,app_desc1,departments);
			}

			//get the widget code
			Util.goToSalesIQ(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,app_name1);

			Apps.toggleApp(driver,etest,app_name1,false);

			int active_count=Apps.getActiveAppCount(driver);

			if(active_count==1)
			{
				result.put("APPS7",true);
				etest.log(Status.PASS,"Active apps count was correctly found");
			}
			else
			{
				result.put("APPS7",false);
				etest.log(Status.FAIL,"Active apps count was NOT correctly found. Expected : 1  Actual : "+active_count);				
			}

			int inactive_count=Apps.getInActiveAppCount(driver);

			if(inactive_count==1)
			{
				result.put("APPS8",true);
				etest.log(Status.PASS,"Inactive apps count was correctly found");
			}
			else
			{
				result.put("APPS8",false);
				etest.log(Status.FAIL,"Inactive apps count was NOT correctly found. Expected : 1  Actual : "+inactive_count);				
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	//create app
	public static void checkCreateApp(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name="app1_"+unique,
			app_desc="desc1_"+unique,
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			List<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Tab.goToApps(driver);

			//create an app1
			Apps.createNewApp(driver,etest,app_name,app_desc,departments);

			//check description
			if(CommonUtil.checkStringContainsAndLog(app_desc,Apps.getAppDescription(driver,etest,app_name),"app description",etest)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);		
			}

			//check department
			List<String> actual_departments=Apps.getAppDepartments(driver,etest,app_name);

			if(CommonUtil.compareList(departments,actual_departments,"departments",etest)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);
			}

			result.put("APPS9", CommonUtil.returnResult(failcount) );

			Util.goToSalesIQ(driver);

			String private_dept="PrivateDept"+unique;
			Department.addDept(driver,private_dept,"depttype_privat",ExecuteStatements.getUserName(driver),etest);

			departments=new ArrayList<String>();
			departments.add(private_dept);

	        Tab.goToApps(driver);
	        etest.log(Status.INFO,"Apps tab was opened");
	        Apps.clickAdd(driver,etest);
	        AppsAdd.sendKeysToNameInput(driver,app_name);
	        etest.log(Status.INFO,"'"+app_name+"' was entered in app name input box");
	        AppsAdd.clickCreate(driver);
	        etest.log(Status.INFO,"Create button was clicked.");

	        try
	        {
		        AppsAdd.selectDepartments(driver,etest,departments);
		        result.put("APPS10",false);
		        etest.log(Status.FAIL,"Private department was found in create app department select dropdown");
		        TakeScreenshot.screenshot(driver,etest);
	        }
	        catch(ZohoSalesIQRuntimeException e)
	        {
	        	result.put("APPS10",true);
		        etest.log(Status.PASS,"Private department was NOT found in create app department select dropdown");
		        TakeScreenshot.infoScreenshot(driver,etest);
	        }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	//check all tabs in Apps-->Edit tab are opening
	public static void checkEditAppPageTabs(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name=test_app_name,
			app_desc="desc1_"+unique,
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			List<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Tab.goToApps(driver);

			if(Apps.isAppFound(driver,etest,app_name)==false)
			{
				Apps.createNewApp(driver,etest,app_name,app_desc,departments);
			}

	        Tab.goToApps(driver);
	        Apps.clickView(driver,etest);
	        AppsView.openApp(driver,etest,app_name);

	        AppsEdit.clickAppName(driver);

	        if(AppsSettings.isTabOpen(driver,AppsSettings.ABOUT))
	        {
	        	result.put("APPS11",true);
	        	etest.log(Status.PASS,"About tab was opened after the app name was clicked in Apps Edit page");
	        }
	        else
	        {
	        	result.put("APPS11",false);
	        	etest.log(Status.FAIL,"About tab was opened after the app name was clicked in Apps Edit page");	    
	        	TakeScreenshot.screenshot(driver,etest);    	
	        }

	        AppsSettings.close(driver);


	        AppsEdit.clickAppDescription(driver);

	        if(AppsSettings.isTabOpen(driver,AppsSettings.ABOUT))
	        {
	        	result.put("APPS12",true);
	        	etest.log(Status.PASS,"About tab was opened after the app description was clicked in Apps Edit page");
	        }
	        else
	        {
	        	result.put("APPS12",false);
	        	etest.log(Status.FAIL,"About tab was opened after the app description was clicked in Apps Edit page");	    
	        	TakeScreenshot.screenshot(driver,etest);    	
	        }

	        AppsSettings.close(driver);


	        AppsEdit.clickDeparmentCountButton(driver);

	        if(AppsSettings.isTabOpen(driver,AppsSettings.GENERAL))
	        {
	        	result.put("APPS13",true);
	        	etest.log(Status.PASS,"General tab was opened after the department count was clicked in Apps Edit page");
	        }
	        else
	        {
	        	result.put("APPS13",false);
	        	etest.log(Status.FAIL,"General tab was opened after the department count was clicked in Apps Edit page");	    
	        	TakeScreenshot.screenshot(driver,etest);    	
	        }

	        AppsSettings.close(driver);


	        AppsEdit.clickPrivacyConfig(driver);

	        if(AppsSettings.isTabOpen(driver,AppsSettings.PRIVACY))
	        {
	        	result.put("APPS14",true);
	        	etest.log(Status.PASS,"Privacy tab was opened after the privacy button was clicked in Apps Edit page");
	        }
	        else
	        {
	        	result.put("APPS14",false);
	        	etest.log(Status.FAIL,"Privacy tab was opened after the privacy button was clicked in Apps Edit page");	    
	        	TakeScreenshot.screenshot(driver,etest);    	
	        }

	        AppsSettings.close(driver);


	        AppsEdit.clickWaitingConfig(driver);

	        if(AppsSettings.isTabOpen(driver,AppsSettings.GENERAL))
	        {
	        	result.put("APPS15",true);
	        	etest.log(Status.PASS,"General tab was opened after the waiting config was clicked in Apps Edit page");
	        }
	        else
	        {
	        	result.put("APPS15",false);
	        	etest.log(Status.FAIL,"General tab was opened after the waiting config was clicked in Apps Edit page");	    
	        	TakeScreenshot.screenshot(driver,etest);    	
	        }

	        AppsSettings.close(driver);


	        AppsEdit.clickSettingsIcon(driver);

	        if(AppsSettings.isTabOpen(driver,AppsSettings.GENERAL))
	        {
	        	result.put("APPS16",true);
	        	etest.log(Status.PASS,"General tab was opened after the settings icon was clicked in Apps Edit page");
	        }
	        else
	        {
	        	result.put("APPS16",false);
	        	etest.log(Status.FAIL,"General tab was opened after the settings icon was clicked in Apps Edit page");	    
	        	TakeScreenshot.screenshot(driver,etest);    	
	        }

	        AppsSettings.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	//check theme
	public static void checkTheme(WebDriver driver,ExtentTest etest,String theme_type,String theme_name)
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			final String
			usecase1="apps_"+theme_type+"_"+theme_name+"_basic",
			usecase2="apps_"+theme_type+"_"+theme_name+"_online_content",
			usecase3="apps_"+theme_type+"_"+theme_name+"_offline_content"
			;

			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name="themecheck"+global_unique,
			app_desc="desc",
			department=ExecuteStatements.getSystemGeneratedDepartment(driver),
			online_line1="ON1"+unique,
			online_line2="ON2"+unique,
			offline_line1="OF1"+unique,
			offline_line2="OF2"+unique
			;

			List<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name,app_name);

			Tab.goToApps(driver);

			if(Apps.isAppFound(driver,etest,app_name)==false)
			{
				Apps.createNewApp(driver,etest,app_name,app_desc,departments);
			}

			Apps.setTheme(driver,etest,app_name,theme_type,theme_name);

			Apps.setWidgetContent(driver,etest,app_name,true,online_line1,online_line2);
			Apps.setWidgetContent(driver,etest,app_name,false,offline_line1,offline_line2);

			//get the widget code
			Util.goToSalesIQ(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,app_name);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);

			String actual_theme_type=VisitorWindow.getCurrentStickerThemeType(visitor_driver);
			String actual_theme_name=VisitorWindow.getCurrentStickerThemeName(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(theme_type,actual_theme_type,"expected chat sticker theme type",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(theme_name,actual_theme_name,"expected chat sticker theme name",etest)==false)
			{
				failcount++;
			}

			result.put(usecase1, CommonUtil.returnResult(failcount) );

			if(VisitorWindow.checkStickerContent(visitor_driver,etest,online_line1,online_line2))
			{
				result.put(usecase2,true);
			}
			else
			{
				result.put(usecase2,false);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");
			etest.log(Status.INFO,"User status is set to busy");

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);

			if(VisitorWindow.checkChatWidgetOffline(visitor_driver))
			{
				result.put(usecase3,true);
				etest.log(Status.PASS,"Chat was widget was found as offline when users are busy.");
			}
			else
			{
				result.put(usecase3,false);
				etest.log(Status.FAIL,"Chat was widget was NOT found as offline when users are busy.");				
				TakeScreenshot.screenshot(driver,etest);
			}

			if(VisitorWindow.checkStickerContent(visitor_driver,etest,offline_line1,offline_line2)==false)
			{
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);	
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		try
		{
			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			etest.log(Status.INFO,"User status is set to online");
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);	
		}
	}

	//check waiting
	public static boolean checkWaitingTimer(WebDriver driver,ExtentTest etest,int waiting_time)
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name=test_app_name,
			app_desc="desc",
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			List<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Tab.goToApps(driver);

			if(Apps.isAppFound(driver,etest,app_name)==false)
			{
				Apps.createNewApp(driver,etest,app_name,app_desc,departments);
			}

			Apps.setWaitingTimer(driver,etest,app_name,waiting_time);

			//get the widget code
			Util.goToSalesIQ(driver);
			Articles.toggleArticlesForWebsite(driver,etest,app_name,false,false);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,app_name);


			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);

			int timer_start_value=waiting_time-1;

			int min=timer_start_value/60;
			int sec=timer_start_value%60;

            if(VisitorWindow.checkWaitingTimer(visitor_driver,min,sec))
            {
            	etest.log(Status.PASS,"Waiting timer in visitor side was found as "+waiting_time);
				return true;
            }
            else
            {
            	failcount++;
            	etest.log(Status.FAIL,"Waiting timer in visitor side was NOT found as "+waiting_time);
            	TakeScreenshot.screenshot(driver,etest);
            }
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);	
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		return CommonUtil.returnResult(failcount);
	}

	//check dept
	public static void checkDepartment(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name=test_app_name,
			app_desc="desc",
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			List<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Tab.goToApps(driver);

			if(Apps.isAppFound(driver,etest,app_name)==false)
			{
				Apps.createNewApp(driver,etest,app_name,app_desc,departments);
			}

			//get the widget code
			Util.goToSalesIQ(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,app_name);

			String shown_dept_id=ExecuteStatements.getDepartmentID(driver,DEPT1);
			String hidden_dept_id=ExecuteStatements.getDepartmentID(driver,DEPT2);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);

			VisitorWindow.clickChatButton(visitor_driver);

			if(VisitorWindow.isDepartmentFound(visitor_driver,shown_dept_id))
			{
				result.put("APPS17",true);
				etest.log(Status.PASS,"Department configured to app '"+app_name+"' was shown in visitor side department select dropdown");
			}
			else
			{
				result.put("APPS17",false);
				etest.log(Status.FAIL,"Department configured to app '"+app_name+"' was NOT shown in visitor side department select dropdown");	
				TakeScreenshot.screenshot(visitor_driver,etest);			
			}

			if(VisitorWindow.isDepartmentFound(visitor_driver,hidden_dept_id)==false)
			{
				result.put("APPS18",true);
				etest.log(Status.PASS,"Department NOT configured to app '"+app_name+"' was not shown in visitor side department select dropdown");	
			}
			else
			{
				result.put("APPS18",false);
				TakeScreenshot.screenshot(visitor_driver,etest);			
				etest.log(Status.FAIL,"Department NOT configured to app '"+app_name+"' was shown in visitor side department select dropdown");
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);	
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}

	//check general settings tab checkboxes
	public static void checkGeneralSettingsTabCheckboxes(WebDriver driver,ExtentTest etest,boolean isEnable)
	{
		WebDriver visitor_driver=null;

		try
		{
			Util.goToSalesIQ(driver);	

			String
			unique=CommonUtil.getUniqueMessage(),
			app_name=test_app_name,
			app_desc="desc",
			department=ExecuteStatements.getSystemGeneratedDepartment(driver)
			;

			String usecase=(isEnable?"enable":"disable");

			List<String> departments=new ArrayList<String>();
			departments.add(department);departments.add(DEPT1);

			// Apps.deleteAllAppsExcept(driver,etest,website_name,test_app_name);

			Tab.goToApps(driver);

			if(Apps.isAppFound(driver,etest,app_name)==false)
			{
				Apps.createNewApp(driver,etest,app_name,app_desc,departments);
			}

			Apps.setCheckboxesGeneralTab(driver,etest,app_name,isEnable,isEnable,isEnable,isEnable,isEnable);

			//get the widget code
			Util.goToSalesIQ(driver);
			Articles.toggleArticlesForWebsite(driver,etest,app_name,false,false);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,app_name);

			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			ChatWindow.acceptChat(driver,etest);
        	VisitorWindow.endChatVisitor(visitor_driver);

        	unique=CommonUtil.getUniqueMessage();

			VisitorWindow.createPage(visitor_driver,widget_code);

			if(com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions.isConversationViewContainerDisplayed(visitor_driver)==isEnable)
			{
				result.put("apps_setting_conversations_"+usecase,true);
				etest.log(Status.PASS,"'Conversations' tabs was "+(isEnable?"found":"NOT found")+" in visitor side after conversations option was "+(isEnable?"enabled":"disabled")+" in app settings");
			}
			else
			{
				result.put("apps_setting_conversations_"+usecase,false);
				etest.log(Status.FAIL,"'Conversations' tab was "+(isEnable?"NOT found":"found")+" in visitor side after conversations option was "+(isEnable?"enabled":"disabled")+" in app settings");				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			ChatWindow.acceptChat(driver,etest);

			if(VisitorWindow.isSendMailButtonFound(visitor_driver)==isEnable)
			{
				result.put("apps_setting_transcript_"+usecase,true);
				etest.log(Status.PASS,"'Send Mail' button was "+(isEnable?"found":"NOT found")+" in visitor side after transcript option was "+(isEnable?"enabled":"disabled")+" in app settings");
			}
			else
			{
				result.put("apps_setting_transcript_"+usecase,false);
				etest.log(Status.FAIL,"'Send Mail' button was "+(isEnable?"NOT found":"found")+" in visitor side after transcript option was "+(isEnable?"enabled":"disabled")+" in app settings");				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(VisitorWindow.isSmileyFound(visitor_driver)==isEnable)
			{
				result.put("apps_setting_emoji_"+usecase,true);
				etest.log(Status.PASS,"'Emojis' button was "+(isEnable?"found":"NOT found")+" in visitor side after emoji setting was "+(isEnable?"enabled":"disabled")+" in app settings");
			}
			else
			{
				result.put("apps_setting_emoji_"+usecase,false);
				etest.log(Status.FAIL,"'Emojis' button was "+(isEnable?"NOT found":"found")+" in visitor side after emoji setting was "+(isEnable?"enabled":"disabled")+" in app settings");				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(VisitorWindow.isFileUploadFound(visitor_driver)==isEnable)
			{
				result.put("apps_setting_fileshare_"+usecase,true);
				etest.log(Status.PASS,"'Attach' button was "+(isEnable?"found":"NOT found")+" in visitor side after file share option was "+(isEnable?"enabled":"disabled")+" in app settings");
			}
			else
			{
				result.put("apps_setting_fileshare_"+usecase,false);
				etest.log(Status.FAIL,"'Attach' button was "+(isEnable?"NOT found":"found")+" in visitor side after file share option was "+(isEnable?"enabled":"disabled")+" in app settings");				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(VisitorWindow.isScreenShareButtonFound(visitor_driver)==isEnable)
			{
				result.put("apps_setting_screenshare_"+usecase,true);
				etest.log(Status.PASS,"'Screenshare' button was "+(isEnable?"found":"NOT found")+" in visitor side after screensharing option was "+(isEnable?"enabled":"disabled")+" in app settings");
			}
			else
			{
				result.put("apps_setting_screenshare_"+usecase,false);
				etest.log(Status.FAIL,"'Screenshare' button was "+(isEnable?"NOT found":"found")+" in visitor side after screensharing option was "+(isEnable?"enabled":"disabled")+" in app settings");				
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

        	VisitorWindow.endChatVisitor(visitor_driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);	
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
	}
}