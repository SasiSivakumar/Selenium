//$Id$
package com.zoho.livedesk.client;

import java.io.PrintStream;
import java.util.*;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class ACannedMessages
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
    public static ExtentTest etest;

	public static Hashtable cannedMsgConfig(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM1"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

            url = ConfManager.requestURL();
			
            try
			{
				Functions.closeBannersAfterLogin(driver);
			}
            catch(NoSuchElementException e){}
			catch(Exception e){}

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));

			etest.log(Status.PASS,"CannedMessage Tab is present");

			result.put("AVCM1", true);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM2"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM2", isMessageTabPresent(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM3"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM3", isCategoryTabPresent(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM4"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM4", isCategoryActionPresent(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM5"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM5", checkDeptddown(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM6"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM6", addCannedCategory(driver, "Asso Category @ 1"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM7"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM7", addCannedMessage(driver, "Asso Canned Message 1", "Automation", "Asso Category @ 1"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM8"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM8", addCannedMessage(driver, "Asso Canned Message 2", "Automation", "Asso Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM9"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM9", editCannedMessage(driver,"Asso Canned Message 2","Edited asso canned message 2", "Automation", "Asso Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM10"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM10", editCannedCategory(driver, "Asso Category @ 2", "Asso edited Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM11"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM11", checkCannedMessages(driver,"Asso edited Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM12"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM12", deleteCannedMessage(driver, "Asso Canned Message 1"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("AVCM13"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessage - Associate");

			result.put("AVCM13", addCannedWithoutCategory(driver));

			ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorCannedMessageTab");

			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CannedMessageTab","ErrorWhileCheckingCannedMessageTab",e);

			result.put("AVCM1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorCannedMessageTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CannedMessageTab","ErrorWhileCheckingCannedMessageTab",e);

			result.put("AVCM1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown",servicedown);
		return hashtable;
	}

    //check if message tab is present
	private static boolean isMessageTabPresent(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
			
			
			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));

			if( text.get(0).getText().equals( ResourceManager.getRealValue("cannedmessages_desc1") ) )
			{
				etest.log(Status.PASS,"CannedMessage Page is checked");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","MessageTab","MismatchDescription");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","MessageTab","ErrorWhileCheckingMessageTab",e);

			System.out.println("Exception while checking if message tab is present in canned messages in Associate login : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","MessageTab","ErrorWhileCheckingMessageTab",e);

			System.out.println("Exception while checking if message tab is present in canned messages in Associate login : "+e);
		}
		return false;
	}

    //check if category tab is present
	private static boolean isCategoryTabPresent(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));

			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));
			Thread.sleep(1000);

			if(((text.get(0).getText()).equals(ResourceManager.getRealValue("cannedcategory_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("cannedcategory_desc2"))))
			{
				etest.log(Status.PASS,"CannedMessage Category Tab is checked");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CategoryTab","MismatchDescription");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CategoryTab","ErrorWhileCheckingCategoryTab",e);

			System.out.println("Exception while checking if categories tab is available in canned messages in Associate login : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CategoryTab","ErrorWhileCheckingCategoryTab",e);

			System.out.println("Exception while checking if categories tab is available in canned messages in Associate login : "+e);
		}
		return false;
	}

    //check if category action is present
    private static boolean isCategoryActionPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));

            if(((driver.findElement(By.id("ccategorylist")).getText()).contains("Action"))||((driver.findElement(By.id("ccategorylist")).getText()).contains("Delete")))
            {
            	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CategoryTab","ActionsIsPresent");

                return false;
            }
            else
            {
                etest.log(Status.PASS,"CannedMessage Cateory Tab Actions is not present");

				return true;
            }
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CategoryTab","ErrorWhileCheckingCategoryTab",e);
            System.out.println("Exception while checking if categories action is present in canned messages in Associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CategoryTab","ErrorWhileCheckingCategoryTab",e);
            System.out.println("Exception while checking if categories action is present in canned messages in Associate login : "+e);
            return false;
        }
    }

    //check for all departments in department dropdown
    private static boolean checkDeptddown(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            driver.findElement(By.id("addcannmsg")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));

            driver.findElement(By.id("candeptslct_div")).click();

            Thread.sleep(500);

            if((driver.findElement(By.id("candeptslct_ddown")).getText()).contains("All Departments"))
            {
            	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DepartmentDropDown","All Departments is present");

                return false;
            }
            else
            {
            	etest.log(Status.PASS,"All Departments is not present");

                return true;
            }
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DepartmentDropDown","ErrorWhileCheckingDepartmentDropdown",e);
            System.out.println("Exception while checking if all departments is present in add canned messages in Associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DepartmentDropDown","ErrorWhileCheckingDepartmentDropdown",e);
            System.out.println("Exception while checking if all departments is present in add canned messages in Associate login : "+e);
            return false;
        }
    }

    //Add canned category
	private static boolean addCannedCategory(WebDriver driver, String category)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));

			if(driver.findElement(By.id("emptycannedcategory")).getAttribute("style").equals("display: none;"))
			{
				driver.findElement(By.id("ccaddbtn")).findElement(By.tagName("span")).click();
				Thread.sleep(1000);
			}
			else
			{
				driver.findElement(By.id("emptycannedcategory")).findElement(By.tagName("a")).click();
				Thread.sleep(1000);
			}

			driver.findElement(By.id("category")).click();
			driver.findElement(By.id("category")).sendKeys(category);

			List<WebElement> btns = driver.findElement(By.id("categorydlgbox")).findElements(By.className("cnfmbtm"));

			btns.get(0).click();

            Tab.waitForLoadingLine(driver);
            Thread.sleep(3000);                                 //Remove and uncomment the previous code to find this test case as issue

			String username = getUserName(driver);

			Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

			List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

			for(WebElement webelmt:list)
			{
				String data = webelmt.findElement(By.className("cmn_wordbr")).getText();
				List<WebElement> elmts1 = webelmt.findElements(By.className("list_cell"));
				if((category.equals(elmts1.get(0).getText())) && (username.equals(elmts1.get(2).getText())))
				{
					etest.log(Status.PASS,"Added Category is present");

                	return true;
				}
			}
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedCategory","AddedCategoryIsNotPresent");
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedCategory","ErrorWhileCheckingAddedCategory",e);
			System.out.println("Exception while adding canned category in canned messages in Associate login : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedCategory","ErrorWhileCheckingAddedCategory",e);
            System.out.println("Exception while adding canned category in canned messages in Associate login : "+e);
		}
		return false;
	}

	private static boolean addCannedMessage(WebDriver driver, String message, String department, String category)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

			try
			{
				driver.findElement(By.id("showempty")).click();
				Thread.sleep(1000);
				driver.findElement(By.linkText(ResourceManager.getRealValue("canned_message_addbtn"))).click();
				Thread.sleep(1000);
			}
			catch(NoSuchElementException e)
			{
				driver.findElement(By.id("cmsgbtn")).findElement(By.tagName("span")).click();
				Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));
			}
			driver.findElement(By.id("cmsg")).click();
			driver.findElement(By.id("cmsg")).clear();
			driver.findElement(By.id("cmsg")).sendKeys(message);

			driver.findElement(By.id("candeptslct_div")).click();
			WebElement webelement = driver.findElement(By.id("candeptslct_ddown"));
			List<WebElement> list = webelement.findElements(By.tagName("li"));

			for(int i=0;i<list.size();i++)
			{
				WebElement webelement2 = (WebElement)list.get(i);
				WebElement webelement4 = webelement2.findElement(By.tagName("div"));
				WebElement webelement6 = webelement4.findElement(By.tagName("span"));
				if((webelement6.getAttribute("title")).equals(department))
				{
					webelement2.click();
					break;
				}
			}
			if(category == null)
			{
				category = "Basic";
				driver.findElement(By.id("toggle")).click();
				Thread.sleep(1000);
				driver.findElement(By.id("addtxtbox")).click();
				driver.findElement(By.id("addtxtbox")).clear();
				driver.findElement(By.id("addtxtbox")).sendKeys(category);
			}
			else
			{
                int ch=0;
				driver.findElement(By.id("cannedcat_div")).click();
				WebElement webelement1 = driver.findElement(By.id("cannedcat_ddown"));
				List<WebElement> list1 = webelement1.findElements(By.tagName("li"));
				for(int i=0;i<list1.size();i++)
				{
					WebElement webelement7 = list1.get(i);
					WebElement webelement8 = webelement7.findElement(By.tagName("div"));
					WebElement webelement9 = webelement8.findElement(By.tagName("span"));
                    if((webelement9.getAttribute("title")).equals(category))
					{
						webelement7.click();
						break;
					}
                    ch++;
                    if(ch==list1.size())
                    {
                        driver.findElement(By.id("toggle")).click();
                        Thread.sleep(1000);
                        driver.findElement(By.id("addtxtbox")).click();
                        driver.findElement(By.id("addtxtbox")).clear();
                        driver.findElement(By.id("addtxtbox")).sendKeys(category);
                    }
				}
			}

			driver.findElement(By.id("btnsubmit")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Canned Message is added Successfully","addcannmsg.do",etest);
            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

			WebElement elmt1 = driver.findElement(By.id("cmsglist"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("cmn_wordbr")).getText();
				List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
				if((data.equals(message)) && (category.equals(elmts1.get(1).getText())) && (department.equals(elmts1.get(2).getText())))
				{
					Thread.sleep(1000);
                    
                    Tab.clickCannedMessagesCategory(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

					List<WebElement> clist = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

					for(WebElement cwebelement:clist)
					{
						List<WebElement> celmts = cwebelement.findElements(By.className("list_cell"));
						String cdata = celmts.get(0).getText();
						if(cdata.equals(category))
						{
							cwebelement.click();
							break;
						}
					}

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

					WebElement elmt2 = driver.findElement(By.id("cmsglist"));
					List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

					for(WebElement elmt3:elmts2)
					{
						data = elmt3.findElement(By.className("cmn_wordbr")).getText();
						List<WebElement> elmts3 = elmt3.findElements(By.className("list_cell"));
						if((data.equals(message)) && (category.equals(elmts3.get(1).getText())) && (department.equals(elmts3.get(2).getText())))
						{
							etest.log(Status.PASS,"Added Message is present");

                			return true;
						}
					}
					TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessage","AddedCannedMessageIsNotPresentInCategory");
					Thread.sleep(1000);
                    
                    Tab.clickCannedMessages(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));
				}
			}
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessage","AddedCannedMessageIsNotPresent");
			return false;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessage","ErrorWhileCheckingAddedCannedMessage",e);
			System.out.println("Exception while adding canned message in canned message tab in Associate login : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessage","ErrorWhileCheckingAddedCannedMessage",e);
			System.out.println("Exception while adding canned message in canned message tab in Associate login : "+e);
		}
		return false;
	}

    private static boolean addCannedWithoutCategory(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            try
            {
                driver.findElement(By.id("showempty")).click();
                Thread.sleep(1000);
                driver.findElement(By.linkText(ResourceManager.getRealValue("canned_message_addbtn"))).click();
                Thread.sleep(1000);
            }
            catch(NoSuchElementException e)
            {
                driver.findElement(By.id("cmsgbtn")).findElement(By.tagName("span")).click();
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));
            }

            driver.findElement(By.id("cmsg")).click();
            driver.findElement(By.id("cmsg")).clear();
            driver.findElement(By.id("cmsg")).sendKeys("Message 4");

            driver.findElement(By.id("toggle")).click();
            Thread.sleep(1000);

            driver.findElement(By.id("btnsubmit")).click();
            Thread.sleep(1000);

            if(ResourceManager.getRealValue("cannedmessages_validcat").equals(driver.findElement(By.id("emnewcancategory")).getText()))
            {
                etest.log(Status.PASS,"CannedMessage is added without category and checked");

                return true;
            }
            else{
            	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessageWithoutCategory","MismatchAlertContent");
            }
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessageWithoutCategory","ErrorWhileCheckingAddCannedMessageWithoutCategory",e);
            System.out.println("Exception while adding canned message without category in canned message tab in Associate login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","AddCannedMessageWithoutCategory","ErrorWhileCheckingAddCannedMessageWithoutCategory",e);
            System.out.println("Exception while adding canned message without category in canned message tab in Associate login : "+e);
        }
        return false;
    }

    private static boolean deleteCannedMessage(WebDriver driver, String message)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt1 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            if(elmts.size() > 0)
            {
                try
                {
                    for(WebElement elmt:elmts)
                    {
						List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
						if(message.equals(elmts1.get(0).getText()))
						{
							String category = elmts1.get(1).getText();
							elmts1.get(0).click();

                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btncancel")));
							driver.findElement(By.id("btncancel")).click();

                            Thread.sleep(1000);
							wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

							driver.findElement(By.id("okbtn")).click();
                            Thread.sleep(1000);
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

							WebElement elmt2 = driver.findElement(By.id("cmsglist"));
							List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

							for(WebElement elmt3:elmts2)
							{
								String data = elmt3.findElement(By.className("cmn_wordbr")).getText();
								List<WebElement> elmts3 = elmt3.findElements(By.className("list_cell"));
								if((data.equals(message)) && (category.equals(elmts3.get(1).getText())))
								{
									TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DeleteCannedMessage","DeletedCannedMessageIsListed");
									return false;
								}
							}

							Thread.sleep(1000);
                            
                            Tab.clickCannedMessagesCategory(driver);

                            Thread.sleep(1000);
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

							try
							{
								driver.findElement(By.linkText(category)).click();
								Thread.sleep(1000);
							}
							catch(NoSuchElementException exp)
							{
								etest.log(Status.PASS,"CannedMessage is deleted");

                				return true;
							}

                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));
							WebElement elmt3 = driver.findElement(By.id("cmsglist"));
							List<WebElement> elmts3 = elmt3.findElements(By.className("list-row"));

							if(elmts3.size()>0)
							{

								for(WebElement elmt4:elmts3)
								{
									String data = elmt4.findElement(By.className("cmn_wordbr")).getText();
									List<WebElement> elmts4 = elmt4.findElements(By.className("list_cell"));
									if((data.equals(message)) && (category.equals(elmts4.get(1).getText())))
									{
										TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DeleteCannedMessage","DeletedCannedMessageIsListed");
										return false;
									}
								}
							}
						}
						Thread.sleep(1000);
                        
                        Tab.clickCannedMessages(driver);

                        Thread.sleep(1000);
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
					}
                }
                catch(StaleElementReferenceException exp)
                {
                    etest.log(Status.PASS,"CannedMessage is deleted");

                	return true;
                }
            }
            etest.log(Status.PASS,"CannedMessage is deleted");

            return true;
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DeleteCannedMessage","ErrorWhileCheckingDeletedCannedMessage",e);
            System.out.println("Exception while deleting canned message in canned message tab in Associate login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","DeleteCannedMessage","ErrorWhileCheckingDeletedCannedMessage",e);
            System.out.println("Exception while deleting canned message in canned message tab in Associate login : "+e);
        }
        return false;
    }

    private static String getUserName(WebDriver driver)
    {
        String name = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings")));

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_myprofile"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("test")));

            WebElement elmt = driver.findElement(By.id("test"));
            WebElement userdetails = elmt.findElement(By.className("usr-mrgntp")).findElement(By.id("userdetails"));
            name = userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","GetOperatorsName","Error",e);
            System.out.println("Exception getting operatorname in canned message tab in Associate login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","GetOperatorsName","Error",e);
            System.out.println("Exception getting operatorname in canned message tab in Associate login : "+e);
        }
        return name;
    }

    private static boolean editCannedCategory(WebDriver driver, String category, String newcategory)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            //WebElement elmt1 = driver.findElement(By.id("ccategorylist"));
            List<WebElement> elmts = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));


            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                List<WebElement> celmts = elmt.findElements(By.className("list_cell"));
                if(data.equals(category))
                {
                    mouseOver(driver, celmts.get(0).findElement(By.tagName("em")));
                    celmts.get(0).findElement(By.tagName("em")).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("category")));

                    driver.findElement(By.id("category")).click();
                    driver.findElement(By.id("category")).clear();
                    driver.findElement(By.id("category")).sendKeys(newcategory);

                    List<WebElement> btns = driver.findElement(By.id("categorydlgbox")).findElements(By.className("cnfmbtm"));
                    btns.get(0).click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Category updated successfully","upcanncategory.do",etest);
                    break;
                }
            }

            Thread.sleep(1000);
            
			Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            List<WebElement> list1 = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

            for(WebElement webelement:list1)
            {
                String data = webelement.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(newcategory))
                {
                    Thread.sleep(1000);
                    
                    Tab.clickCannedMessages(driver);
                    
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                    WebElement elmt2 = driver.findElement(By.id("cmsglist"));
                    List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

                    for(WebElement elmt:elmts2)
                    {
                        String data1 = elmt.findElement(By.className("cmn_wordbr")).getText();
                        List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
                        if((data1.equals("Edited asso canned message 2")) && (newcategory.equals(elmts1.get(1).getText())))
                        {
                            etest.log(Status.PASS,"Category is edited");

                			return true;
                        }
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","EditCannedCategory","EditedCategoryIsNotPresent");
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","EditCannedCategory","ErrorWhileCheckingEditedCategory",e);
            System.out.println("Exception while editing canned category in canned message tab in Associate login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","EditCannedCategory","ErrorWhileCheckingEditedCategory",e);
            System.out.println("Exception while editing canned category in canned message tab in Associate login : "+e);
        }
        return false;
    }

    private static boolean checkCannedMessages(WebDriver driver, String category)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt1 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            Hashtable canmsgs = new Hashtable();
            int i = 0;

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
                if(category.equals(elmts1.get(1).getText()))
                {
                    canmsgs.put(data,elmts1.get(2).getText());
                }
            }

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

            for(WebElement webelement:list)
            {
                String data = webelement.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(category))
                {
                    webelement.click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                    WebElement elmt2 = driver.findElement(By.id("cmsglist"));
                    List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

                    if((elmts2.size())==(canmsgs.size()))
                    {
                        for(WebElement elmt3:elmts2)
                        {
                            String msg = elmt3.findElement(By.className("cmn_wordbr")).getText();
                            List<WebElement> elmts3 = elmt3.findElements(By.className("list_cell"));
                            if((canmsgs.containsKey(msg)) && ((elmts3.get(2).getText()).equals(canmsgs.get(msg))))
                            {
                                i++;
                            }
                        }
                    }
                    break;
                }
            }
            if(i == canmsgs.size())
            {
                etest.log(Status.PASS,"Canned message is checked in message and category tab");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CheckCannedMessages","MismatchCountInMessageAndCategoryTab");
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CheckCannedMessages","ErrorWhileCheckingCannedMessage",e);
            System.out.println("Exception while checking canned messages in canned messages tab in Associate login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","CheckCannedMessages","ErrorWhileCheckingCannedMessage",e);
            System.out.println("Exception while checking canned messages in canned messages tab in Associate login : "+e);
        }
        return false;
    }

    private static boolean editCannedMessage(WebDriver driver, String oldmessage, String message, String department, String category)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt1 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(oldmessage))
                {
                    mouseOver(driver, elmt.findElements(By.tagName("em")).get(0));
                    elmt.findElements(By.tagName("em")).get(0).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));

                    driver.findElement(By.id("cmsg")).click();
                    driver.findElement(By.id("cmsg")).clear();
                    driver.findElement(By.id("cmsg")).sendKeys(message);

                    driver.findElement(By.id("candeptslct_div")).click();
                    WebElement webelement = driver.findElement(By.id("candeptslct_ddown"));
                    List<WebElement> list = webelement.findElements(By.tagName("li"));

                    for(int i=0;i<list.size();i++)
                    {
                        WebElement webelement2 = (WebElement)list.get(i);
                        WebElement webelement4 = webelement2.findElement(By.tagName("div"));
                        WebElement webelement6 = webelement4.findElement(By.tagName("span"));
                        if((webelement6.getAttribute("title")).equals(department))
                        {
                            webelement2.click();
                            break;
                        }
                    }

                    driver.findElement(By.id("cannedcat_div")).click();
                    WebElement webelement1 = driver.findElement(By.id("cannedcat_ddown"));
                    List<WebElement> list1 = webelement1.findElements(By.tagName("li"));
                    int ch1=0;
                    for(int i=0;i<list1.size();i++)
                    {
                        WebElement webelement7 = list1.get(i);
                        WebElement webelement8 = webelement7.findElement(By.tagName("div"));
                        WebElement webelement9 = webelement8.findElement(By.tagName("span"));
                        if((webelement9.getAttribute("title")).equals(category))
                        {
                            webelement7.click();
                            break;
                        }
                        ch1++;
                        if(ch1==list1.size()-1)
                        {
                            driver.findElement(By.id("toggle")).click();
                            Thread.sleep(1000);
                            driver.findElement(By.id("addtxtbox")).click();
                            driver.findElement(By.id("addtxtbox")).clear();
                            driver.findElement(By.id("addtxtbox")).sendKeys(category);
                        }
                    }
                    driver.findElement(By.id("btnsubmit")).click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Canned Message is updated Successfully","upcannmsg.do",etest);
                    break;
                }
            }

            Thread.sleep(1000);
            
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt3 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts3 = elmt3.findElements(By.className("list-row"));

            for(WebElement elmt:elmts3)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));

                if((data.equals(message)) && (category.equals(elmts1.get(1).getText())) && (department.equals(elmts1.get(2).getText())))
                {
                    Thread.sleep(1000);
                    
                    Tab.clickCannedMessagesCategory(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

                    List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

                    for(WebElement webelmt:list)
                    {
                        String cdata = webelmt.findElement(By.className("cmn_wordbr")).getText();
                        if(category.equals(cdata))
                        {
                            webelmt.click();

                            Thread.sleep(1000);
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                            WebElement elmt2 = driver.findElement(By.id("cmsglist"));
                            List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

                            for(WebElement elmt4:elmts2)
                            {
                                data = elmt4.findElement(By.className("cmn_wordbr")).getText();
                                List<WebElement> elmts4 = elmt4.findElements(By.className("list_cell"));
                                if((data.equals(message)) && (category.equals(elmts4.get(1).getText())) && (department.equals(elmts4.get(2).getText())))
                                {
                                    etest.log(Status.PASS,"Canned Message is edited");

                					return true;
                                }
                            }
                            break;
                        }
                    }
                    Thread.sleep(1000);
                    
                    Tab.clickCannedMessages(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));
                }
            }
            TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","EditCannedMessage","EditedCannedMessageIsNotPresnt");
            return false;
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","EditCannedMessage","ErrorWhileCheckingEditedCannedMessage",e);
            System.out.println("Exception while editing canned message in canned message tab in Associate login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessage-Associate","EditCannedMessage","ErrorWhileCheckingEditedCannedMessage",e);
            System.out.println("Exception while editing canned message in canned message tab in Associate login : "+e);
        }
        return false;
    }

    public static void mouseOver(WebDriver driver, WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    public static boolean clearCannedMessages(WebDriver driver)
    {
        try
        {
            /*
             editCannedCategory(driver, "Test two", "Test one");
             deleteCannedMessage(driver, "Message2");
             deleteCannedCategory(driver, "Basic");
             deleteCannedMessage(driver, "Edited message 2");
             deleteCannedMessage(driver, "Message1");
             deleteCannedCategory(driver, "Basic");
             deleteCannedMessage(driver, "Message3");
             deleteCannedCategory(driver, "Category @ 1");
             deleteCannedCategory(driver, "Category @ 2");
             deleteCannedCategory(driver, "Test one");*/
            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clearing data in canned message tab in associate login : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in canned message tab in associate login : "+e);
        }
        return false;
    }
}
