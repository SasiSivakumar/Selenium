//$Id$
package com.zoho.livedesk.client.PortalSettingsRealTime;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.MissedChat.MissedChatCommonFunctions;
import com.zoho.livedesk.client.MissedChat.MissedChatModule;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.PortalSettingsRealTime.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.util.common.ZohoMailAPIUtil;
import com.zoho.livedesk.client.ConcurrentChats.*;

public class PortalSettingsRealTimeTests{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Portal Settings Real Time";
	public static String WIDGET_CODE="";
	public static String PORTAL_NAME="";
	public static String WEBSITE_NAME="";

	public static VisitorDriverManager visitor_driver_manager;

	public static final String
	EMAIL="muzamil.y+<mail_identifier>@zohocorp.com",
	AUTHTOKEN="c5b3c06e100b8b299e1782f5b857ca36";

	public static final String
	COMPANY_NAME="C"+CommonUtil.getUniqueMessage(),
	COMPANY_EMAIL=getMail(COMPANY_NAME),
	DEFAULT_FROM_EMAIL="systemgenerated@zohosalesiq.com",
	EXPECTED_SENDER="SalesIQ"
	;

	public static String
	ACCOUNTID="5859288000000008002",
	VISITOR_EMAIL_FOR_EMAIL_CONFIGURATION_USECASE=null;

	public static final String
	TRANSCRIPT="PSR38",
	MISSED="PSR39",
	FEEDBACK="PSR40",
	BLOCKEDIP="PSR41",
	COMPANY_MAIL="company_mail",
	EMAIL_COPIER="email_copier",
	VISITOR_TRANSCRIPT="PSR42"
	;

	public static boolean isCompanyEmailConformed=false;

	public static Hashtable<String,Hashtable<String,String>> email_configuration_usecase_info=null;

	public static String ATTENDER_MAIL=null,ASSOCIATE_MAIL=null;

	public static Hashtable test(WebDriver driver) throws Exception
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();
            WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            PORTAL_NAME=ExecuteStatements.getPortal(driver);     
            ATTENDER_MAIL=ExecuteStatements.getUserName(driver);    

            WebDriver associate_driver=Functions.setUp();
            Functions.login(associate_driver,"portal_settings_associate");
            ASSOCIATE_MAIL=ExecuteStatements.getUserName(associate_driver);
            
			etest=ComplexReportFactory.getTest("Check Email Configuration");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            setIdleTimeToNever(driver,etest);//set idle time to never to avoid unexpected idle status during automation
			ACCOUNTID=setAccountId();
			triggerEmailConfigurationEmails(driver,associate_driver,etest,WIDGET_CODE);
			etest.log(Status.INFO,"All emails were triggered.");
            ComplexReportFactory.closeTest(etest);

            Functions.logout(associate_driver);

            com.zoho.livedesk.util.Cleanup.deleteAllBlockedIP(driver);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR1", checkAgentTypingStatus(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR2"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR2", checkAgentTypingStatus(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR3", checkFileSharing(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR4"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR4", checkFileSharing(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR5"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR5", checkShareURL(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR6", checkShareURL(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR7"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR7", checkTranslation(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR8"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR8", checkTranslation(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR9", checkScreenSharing(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR10", checkScreenSharing(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR11", checkEmailVisitorInformation(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR12"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR12", checkEmailVisitorInformation(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);   

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR13"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR13", checkUserIdleTime(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR14"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR14", checkUserIdleTime(driver,etest,WIDGET_CODE,true));
            setIdleTimeToNever(driver,etest);//to prevent unexpected user idle state during automation
            ComplexReportFactory.closeTest(etest);        

            WebDriver driver2=Functions.setUp();
            Functions.login(driver2,"portal_settings2");

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR15"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR15", checkChangeOwner(driver,driver2,etest));
            ComplexReportFactory.closeTest(etest);    

            Functions.logout(driver2);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR16"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR16", checkSendMailButtonFromDropdown(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			driver.navigate().refresh();
			CommonUtil.sleep(10000);

            PortalSetting email_input=null;

            email_input=PortalSetting.EMAIL_COPIER;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR24","PSR25");
            ComplexReportFactory.closeTest(etest);

            email_input=PortalSetting.DAILY_STATISTICS;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR26","PSR27");
            ComplexReportFactory.closeTest(etest);

            email_input=PortalSetting.WEEKLY_REPORT;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR28","PSR29");
            ComplexReportFactory.closeTest(etest);

            email_input=PortalSetting.BLOCKED_IP_MAIL;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR30","PSR31");
            ComplexReportFactory.closeTest(etest);

            email_input=PortalSetting.VISITOR_FEEDBACK_MAIL;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR32","PSR33");
            ComplexReportFactory.closeTest(etest);

            email_input=PortalSetting.CHAT_TRANSCRIPT_MAIL;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR34","PSR35");
            ComplexReportFactory.closeTest(etest);
            
            email_input=PortalSetting.MISSED_VISITOR_MAIL;
			etest=ComplexReportFactory.getTest("Email Input -"+email_input);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailInputs(driver,etest,WIDGET_CODE,email_input,"PSR36","PSR37");
            ComplexReportFactory.closeTest(etest);

			driver.navigate().refresh();
			CommonUtil.sleep(10000);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR18"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR18", checkEmailConfiguration(driver,etest,WIDGET_CODE,PortalSettingsConstants.COMPANY));
            ComplexReportFactory.closeTest(etest);

			driver.navigate().refresh();
			CommonUtil.sleep(10000);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR19"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR19", checkEmailConfiguration(driver,etest,WIDGET_CODE,PortalSettingsConstants.OPERATOR));
            ComplexReportFactory.closeTest(etest);

			driver.navigate().refresh();
			CommonUtil.sleep(10000);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PSR20"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("PSR20", checkEmailConfiguration(driver,etest,WIDGET_CODE,PortalSettingsConstants.BOTH));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Email Configuration");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmails(email_configuration_usecase_info,etest);
            ComplexReportFactory.closeTest(etest);

            visitor_driver_manager.terminateAllDriverSessions();
       }
		catch(Exception e)
		{
			e.printStackTrace();
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static String setAccountId() throws Exception
	{
		WebDriver driver=Functions.setUp();
		String account_id=ZohoMailAPIUtil.getAccountId(driver,AUTHTOKEN);
		driver.quit();
		return account_id;
	}

	public static boolean checkAgentTypingStatus(WebDriver driver,ExtentTest etest,String widget_code,boolean isTypingStatusEnabled) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.SHOW_TYPING_STATUS,isTypingStatusEnabled);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);
			String unique_id=setupOngoingChat(driver,visitor_driver,etest,widget_code);

    		ChatWindow.enterTextInMessageInChatInput(driver,"typing_check"+label);
    		try
    		{
				ConversationViewCommonFunctions.waitTillExpectedLastMessageShown(visitor_driver,ChatType.ONGOING,unique_id,ConversationViewConstants.TYPING_STATUS_KEYWORD);
    		}
    		catch(Exception e){}

			String actual_status=ConversationViewCommonFunctions.getLastMessage(visitor_driver,ChatType.ONGOING,unique_id);

			String log_condition=isTypingStatusEnabled?"":"NOT";

			if(CommonUtil.compareStringAndLog(ConversationViewConstants.TYPING_STATUS_KEYWORD,actual_status,"typing status",false,false,etest)==isTypingStatusEnabled)
			{
				etest.log(Status.PASS,"Expected agent typing status was found.");		
			}
			else
			{
			    failcount++;	
				etest.log(Status.FAIL,"Expected agent typing status was NOT found. Expected : "+log_condition+" "+ConversationViewConstants.TYPING_STATUS_KEYWORD+" , Actual : "+actual_status);	
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
				TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");		
			}
			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkAgentTypingStatus","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkAgentTypingStatus","Exception",e);
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkFileSharing(WebDriver driver,ExtentTest etest,String widget_code,boolean isFileSharingEnabled) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.SEND_FILE_TO_VISITOR,isFileSharingEnabled);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);
			String unique_id=setupOngoingChat(driver,visitor_driver,etest,widget_code);

			String log_condition=isFileSharingEnabled?"":"NOT";

			if(ChatWindow.isFileUploadIconVisible(driver)==isFileSharingEnabled)
			{
				etest.log(Status.PASS,"Expected file upload icon was found.");						
				if(isFileSharingEnabled)
				{
					CommonUtil.clickWebElement(driver,CommonUtil.getElement(ChatWindow.getCurrentVisibleChat(driver),ChatWindow.FILE_UPLOAD_CONTAINER));
					if(CommonUtil.checkStringContainsAndLog(CommonUtil.getElement(ChatWindow.getCurrentVisibleChat(driver),ChatWindow.FILE_UPLOAD_OPTIONS).getText(),ResourceManager.getRealValue("attachment_options"),"Attachment options",etest))
					{
						result.put("PSR43",true);
					}
					else
					{
						result.put("PSR43",false);
						TakeScreenshot.screenshot(driver,etest);
					}
				}
			}
			else
			{
			    failcount++;	
				etest.log(Status.FAIL,"Expected file upload icon was NOT found.");	
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
				TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");		
			}

			if(isFileSharingEnabled)
			{
				if(ChatWindow.uploadFile(driver,FileType.IMAGE))
				{
					etest.log(Status.PASS,"File was successfully uploaded in agent side.");
				}
				else
				{
				    failcount++;	
					etest.log(Status.FAIL,"File was not uploaded from agent side.");	
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
				}

				if(VisitorWindow.checkFileRecievedInVisitorSide(visitor_driver,etest)==false)
				{
					failcount++;
				}
			}
		
			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkFileSharing","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkFileSharing","Exception",e);
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkShareURL(WebDriver driver,ExtentTest etest,String widget_code,boolean isShareURLEnabled) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		String url="https://www.zoho.com";

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.SHARE_URL,isShareURLEnabled);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);
			String unique_id=setupOngoingChat(driver,visitor_driver,etest,widget_code);


			String log_condition=isShareURLEnabled?"":"NOT";

			try
			{
				ChatWindow.shareURL(driver,url);

				if(!isShareURLEnabled)
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was able to share url after it was disabled in portal settings");
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
				}
			}
			catch(Exception e)
			{
				if(!isShareURLEnabled)
				{
					etest.log(Status.PASS,"Agent was unable to share url after it was disabled in portal settings");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was unable to share url after it was enabled in portal settings");					
					throw e;
				}
			}

			if(isShareURLEnabled)
			{
				if(VisitorWindow.isURLShared(visitor_driver,url))
				{
					etest.log(Status.PASS,"Shared URL was recieved in visitor side");						
				}
				else
				{
				    failcount++;	
					etest.log(Status.FAIL,"Shared URL was NOT recieved in visitor side");	
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
					TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");		
				}				
			}
		
			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkShareURL","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkShareURL","Exception",e);
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkTranslation(WebDriver driver,ExtentTest etest,String widget_code,boolean isTranslateEnabled) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		final String
		ORIGINAL_TEXT="Dansk",
		DANISH_TRANSLATED_TEXT="Danish",
		TRANSLATION_LANGUAGE="Danish";

		String
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question=ORIGINAL_TEXT;


		try
		{
			String username=ExecuteStatements.getUserName(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.GOOGLE_TRANSLATION,isTranslateEnabled);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);

			String log_condition=isTranslateEnabled?"":"NOT";

			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
	        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

			try
			{
				ChatWindow.translateChatTo(driver,TRANSLATION_LANGUAGE,etest);

				if(!isTranslateEnabled)
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was able to select translate chat after it was disabled in portal settings");
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
				}
			}
			catch(Exception e)
			{
				if(!isTranslateEnabled)
				{
					etest.log(Status.PASS,"Agent was unable to translate chat after it was disabled in portal settings");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was unable to translate chat after it was enabled in portal settings");					
					throw e;
				}
			}

			if(isTranslateEnabled)
			{

				VisitorWindow.sentMessageInTheme(visitor_driver,ORIGINAL_TEXT);

				if(ChatWindow.checkMessageInUserWindow(driver,visitor_name,DANISH_TRANSLATED_TEXT))
				{
					etest.log(Status.PASS,"Chat messages sent by the visitor was translated to the agent successfully");						
				}
				else
				{
				    failcount++;	
					etest.log(Status.FAIL,"Chat messages sent by the visitor was NOT translated to the agent successfully");	
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
					TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");		
				}

				ChatWindow.sentMessage(driver,DANISH_TRANSLATED_TEXT);

				if(PortalSettingsRealTimeCommonFunctions.isMessageRecievedByVisitor(visitor_driver,username,ORIGINAL_TEXT))
				{
					etest.log(Status.PASS,"Chat messages sent by the agent was translated to the visitor successfully");						
				}
				else
				{
				    failcount++;	
					etest.log(Status.FAIL,"Chat messages sent by the agent was NOT translated to the visitor successfully");	
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
					TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");		
				}				
			}
		
			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkTranslation","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkTranslation","Exception",e);
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkScreenSharing(WebDriver driver,ExtentTest etest,String widget_code,boolean isScreenSharingEnabled) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		String
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="q"+label;

		try
		{
			String username=ExecuteStatements.getUserName(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.ALLOW_SCREEN_SHARING,isScreenSharingEnabled);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);

			String log_condition=isScreenSharingEnabled?"":"NOT";

			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
	        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

			try
			{
				boolean isScreenShared = ChatWindow.clickScreenSharing(driver,etest);

				if(!isScreenSharingEnabled)
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was able to select screen sharing after it was disabled in portal settings");
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
				}

				String expected_info_message=PortalSettingsConstants.VISITOR_SCREENSHARING_INVITE_TEXT.replace("<agent>",username);

				if(isScreenShared)
				{
					try
					{
						VisitorWindow.waitTillMessageInChat(visitor_driver,expected_info_message);
						etest.log(Status.PASS,"Screen sharing info message '"+expected_info_message+"' was found in visitor side");
					}	
					catch(Exception exp)
					{
						exp.printStackTrace();
						etest.log(Status.FAIL,"Screen sharing info message '"+expected_info_message+"' was NOT found in visitor side");
						TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");		
					}
				}
			}
			catch(Exception e)
			{

				e.printStackTrace();

				if(!isScreenSharingEnabled)
				{
					etest.log(Status.PASS,"Agent was unable to select screen sharing after it was disabled in portal settings");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was unable to select screen sharing after it was enabled in portal settings");					
					throw e;
				}
			}

			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkTranslation","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkTranslation","Exception",e);
			driver.navigate().refresh();
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkEmailVisitorInformation(WebDriver driver,ExtentTest etest,String widget_code,boolean isEmailVisitorInformationEnabled) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		String
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="q"+label;

		try
		{
			String username=ExecuteStatements.getUserName(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.EMAIL_THE_VISITOR_INFORMATION,isEmailVisitorInformationEnabled);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);

			String log_condition=isEmailVisitorInformationEnabled?"":"NOT";

			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
	        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

			try
			{
				ChatWindow.clickSendVisitorInformationAsEmailButton(driver,etest);

				if(!isEmailVisitorInformationEnabled)
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was able to select email visitor option after it was disabled in portal settings");
					TakeScreenshot.screenshot(driver,etest);		
				}
				else
				{
					etest.log(Status.PASS,"Agent was able to select email visitor option after it was enabled in portal settings");										
				}
			}
			catch(Exception e)
			{
				if(!isEmailVisitorInformationEnabled)
				{
					etest.log(Status.PASS,"Agent was unable to select email visitor option after it was disabled in portal settings");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Agent was unable to select email visitor option after it was enabled in portal settings");					
					throw e;
				}
			}

			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkEmailVisitorInformation","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkEmailVisitorInformation","Exception",e);
		}
		finally
		{
			driver.navigate().refresh();
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkUserIdleTime(WebDriver driver,ExtentTest etest,String widget_code,boolean isTreatIdleUsersAsOffline) throws Exception
	{

		WebDriver visitor_driver=null;
		int failcount=0;
		String label=CommonUtil.getUniqueMessage();

		String
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="q"+label;

		try
		{
			String username=ExecuteStatements.getUserName(driver);

			PortalInput portal_input=new PortalInput(PortalSetting.SET_OPERATOR_IDLE_TIME,PortalSettingsConstants.MINUTES5);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);

			if(isTreatIdleUsersAsOffline)
			{
				PortalInput treat_idle_as_offline=new PortalInput(PortalSetting.IDLE_USERS_AS_OFFLINE,true);
				PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,treat_idle_as_offline,etest);
				etest.log(Status.INFO,"~~Log status : isTreatIdleUsersAsOffline is true set");
			}

			CommonUtil.sleep(6*60*1000);//waiting for 6 minutes

			AgentStatus expected_status=AgentStatus.IDLE;

			if(CommonUtil.checkStringEqualsAndLog(expected_status.toString(),com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver).toString(),"agent status",etest)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);
			}

			if(isTreatIdleUsersAsOffline)
			{
				visitor_driver=visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widget_code);

				if(VisitorWindow.checkChatWidgetOffline(visitor_driver))
				{
					etest.log(Status.PASS,"Idle user was treated as offline after 'Treat idle users as offline' was enabled in portal settings");
				}
				else
				{
					etest.log(Status.FAIL,"Idle user was NOT treated as offline after 'Treat idle users as offline' was enabled in portal settings");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);										
				}
			}

			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkEmailVisitorInformation","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkEmailVisitorInformation","Exception",e);
		}
		finally
		{
			driver.navigate().refresh();
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkChangeOwner(WebDriver driver,WebDriver driver2,ExtentTest etest) throws Exception
	{
		int failcount=0;

		WebDriver current_owner_driver=null,new_owner_driver=null;

		try
		{
			if(ExecuteStatements.isOwner(driver))
			{
				current_owner_driver=driver;
				new_owner_driver=driver2;	
			}
			else if(ExecuteStatements.isOwner(driver2))
			{
				current_owner_driver=driver2;
				new_owner_driver=driver;	
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Both agents are not owners!!");
			}

			String new_owner_username=ExecuteStatements.getUserName(new_owner_driver);
			PortalConfig.changeOwner(current_owner_driver,new_owner_username,etest);

			current_owner_driver.navigate().refresh();

			String current_owner=PortalConfig.getCurrentPortalOwner(current_owner_driver);

			if(CommonUtil.checkStringEqualsAndLog(new_owner_username,current_owner,"portal owner",etest)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(current_owner_driver,etest);
				TakeScreenshot.screenshot(new_owner_driver,etest);
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(current_owner_driver,etest,MODULE_NAME,"checkChangeOwner","Exception",e);
			TakeScreenshot.screenshot(new_owner_driver,etest,MODULE_NAME,"new_owner_driver","Exception",e);
		}
		finally
		{
			driver.navigate().refresh();
			return CommonUtil.returnResult(failcount);
		}
	}

	public static String getMail(String mail_identifier)
	{
		return EMAIL.replaceAll("<mail_identifier>",mail_identifier);
	}	

	public static boolean triggerEmailConfigurationEmails(WebDriver driver,WebDriver associate_driver,ExtentTest etest,String widget_code) throws Exception
	{
		int failcount=0;

		try
		{

			Hashtable<String,Hashtable<String,String>> email_configuration_info=getEmailConfigurationVisitorInfo();

			email_configuration_usecase_info=email_configuration_info;//assigning to global variable

			final String label=CommonUtil.getUniqueMessage();

			final String
			TRANSCRIPT_EMAIL=email_configuration_info.get(TRANSCRIPT).get("portal_email"),
			MISSED_EMAIL=email_configuration_info.get(MISSED).get("portal_email"),
			FEEDBACK_EMAIL=email_configuration_info.get(FEEDBACK).get("portal_email"),
			BLOCKEDIP_EMAIL=getMail("IP"+label),
			EMAIL_COPIER=getMail("EC"+label),
			AUTOMATED_VISITOR_CHAT_TRANSCRIPT=getMail("VCT"+label)
			;

			PortalInput transcript_mail=new PortalInput(PortalSetting.CHAT_TRANSCRIPT_MAIL,true,TRANSCRIPT_EMAIL);
			PortalInput missed_mail=new PortalInput(PortalSetting.MISSED_VISITOR_MAIL,true,MISSED_EMAIL);
			PortalInput feedback_mail=new PortalInput(PortalSetting.VISITOR_FEEDBACK_MAIL,true,FEEDBACK_EMAIL);
			PortalInput blockedip_mail=new PortalInput(PortalSetting.BLOCKED_IP_MAIL,true,BLOCKEDIP_EMAIL);

			PortalInput email_copier=new PortalInput(PortalSetting.EMAIL_COPIER,true,EMAIL_COPIER);
			PortalInput automated_visitor_chat_transcript=new PortalInput(PortalSetting.AUTOMATED_VISITOR_CHAT_TRANSCRIPT,PortalSettingsConstants.AUTOMATED);

			PortalSettingsRealTimeCommonFunctions.setPortalType(driver,etest,automated_visitor_chat_transcript,email_copier,feedback_mail,transcript_mail,missed_mail,blockedip_mail);
			
			setupEmailConfiguration(driver,associate_driver,etest,widget_code,email_configuration_info);//transcript,feedback,missed,blockedip,visitor transcript

			etest.log(Status.INFO,"Mails are Triggered");

			
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkEmailVisitorInformation","Exception",e);
			throw e;
		}
		finally
		{
			driver.navigate().refresh();
			return CommonUtil.returnResult(failcount);
		}
	}

	public static void checkEmails(Hashtable<String,Hashtable<String,String>> email_data,ExtentTest etest) throws Exception
	{
		WebDriver driver=Functions.setUp();

		try
		{
			Set<String> keys = email_data.keySet();
		    for(String key: keys)
		    {
		    	etest.log(Status.INFO,"Now checking use case--> "+KeyManager.getRealValue(key));
		    	result.put(key,checkEmail(driver,etest,key,email_data.get(key)));
		    }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
			e.printStackTrace();
		}

		driver.quit();
	}

	public static boolean checkEmail(WebDriver driver,ExtentTest etest,String usecase,Hashtable<String,String> email_data)
	{

		int failcount=0;

		try
		{
			String visitor_website="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html";

			String label=email_data.get("label");

			Hashtable<String,String> mail_info=ZohoMailAPIUtil.getMailInfoByUniqueKeyWord(driver,etest,AUTHTOKEN,ACCOUNTID,label);

			TakeScreenshot.addExpandableLog(etest,Status.INFO,"Visitor Info From API -  Click here to expand",mail_info.toString());

			email_data.put("email",DEFAULT_FROM_EMAIL);

			if(CommonUtil.checkStringEqualsAndLog(email_data.get("email"),mail_info.get("from"),"from email address",etest)==false)
			{
				failcount++;
			}

			if(usecase.contains(FEEDBACK) || usecase.contains(TRANSCRIPT) || usecase.contains(MISSED))
			{
				if(mail_info.get("sender").equals(EXPECTED_SENDER) || mail_info.get("sender").equals(DEFAULT_FROM_EMAIL))
				{
					etest.log(Status.PASS,"Expected sender was found.");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Expected sender was Not found. Expected : "+EXPECTED_SENDER+" / "+DEFAULT_FROM_EMAIL+" Actual : "+mail_info.get("sender"));
				}				
			}

			if(usecase.contains(VISITOR_TRANSCRIPT)==false)
			{
				if(CommonUtil.checkStringContainsAndLog(email_data.get("portal_email"),mail_info.get("to"),"configured to address",etest)==false)
				{
					failcount++;
				}
			}

			if(usecase.contains(FEEDBACK) || usecase.contains(TRANSCRIPT) || usecase.contains("Visitor Chat Transcript") || usecase.contains(MISSED))
			{
				String mail_content_text=ZohoMailAPIUtil.extractTextFromHTML(mail_info.get("content"));

				if(CommonUtil.checkStringContainsAndLog(email_data.get("name"),mail_content_text,"name",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.checkStringContainsAndLog(email_data.get("question"),mail_content_text,"question",etest)==false)
				{
					failcount++;
				}
			}

			if(usecase.contains(BLOCKEDIP))
			{
				String mail_content_text=ZohoMailAPIUtil.extractTextFromHTML(mail_info.get("content"));

				String expected_subject="Zoho SalesIQ - "+ASSOCIATE_MAIL+" has blocked a customer IP.";

				if(CommonUtil.checkStringContainsAndLog(expected_subject,mail_info.get("subject"),"subject",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.checkStringContainsAndLog("Blocked By: "+ASSOCIATE_MAIL,mail_content_text,"blocked ip content",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.compareStringAndLog("Click here for more details about this visitor",mail_content_text,"internal link (only shown for portal members)",false,false,etest))
				{
					// failcount++;
					etest.log(Status.WARNING,"'To know more about this visitor click here' is shown for non portal member.(Issue-id : ZLS-3294)");
				}										

				
			}

			if(usecase.contains(FEEDBACK))
			{
				String mail_content_text=ZohoMailAPIUtil.extractTextFromHTML(mail_info.get("content"));

				if(CommonUtil.checkStringContainsAndLog(PortalSettingsConstants.FEEDBACK_EMAIL_SUBJECT,mail_info.get("subject"),"subject",etest)==false)
				{
					failcount++;
				}

				String expected_feedback="Visitor Feedback "+email_data.get("feedback");
				if(CommonUtil.checkStringContainsAndLog(expected_feedback,mail_content_text,"feedback",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.checkStringContainsAndLog("f="+email_data.get("rating")+".jpg",mail_info.get("content"),"rating",etest)==false)
				{
					failcount++;
				}

				if(CommonUtil.checkStringContainsAndLog("Operator: "+ATTENDER_MAIL,mail_content_text,"attender",etest)==false)
				{
					failcount++;
				}				
			}
			if(usecase.contains(VISITOR_TRANSCRIPT))
			{
				String expected_subject="Chat with "+email_data.get("name");

				if(CommonUtil.checkStringContainsAndLog(expected_subject,mail_info.get("subject"),"subject",etest)==false)
				{
					failcount++;
				}
			}
			if(usecase.contains(TRANSCRIPT) || usecase.contains(VISITOR_TRANSCRIPT))
			{
				String mail_content_text=ZohoMailAPIUtil.extractTextFromHTML(mail_info.get("content"));

				if(CommonUtil.checkStringContainsAndLog("Chat Transcript",mail_content_text,"header",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.checkStringContainsAndLog("Attended By : "+ATTENDER_MAIL,mail_content_text,"attender",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.compareStringAndLog("To view chat transcript click here",mail_content_text,"internal link (only shown for portal members)",false,false,etest))
				{
					// failcount++;
					etest.log(Status.WARNING,"'To view chat transcript click here' is shown for non portal member.(Issue-id : ZLS-3294)");
				}
				if(CommonUtil.checkStringContainsAndLog(visitor_website,mail_content_text,"website",etest)==false)
				{
					failcount++;
				}					
			}

			if(usecase.contains(MISSED))
			{
				String mail_content_text=ZohoMailAPIUtil.extractTextFromHTML(mail_info.get("content"));

				if(CommonUtil.checkStringContainsAndLog("Missed Visitor Alert",mail_content_text,"header",etest)==false)
				{
					failcount++;
				}				
				if(CommonUtil.checkStringContainsAndLog(visitor_website,mail_content_text,"website",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.compareStringAndLog("To know more about this visitor click here",mail_content_text,"internal link (only shown for portal members)",false,false,etest))
				{
					failcount++;
					etest.log(Status.WARNING,"'To know more about this visitor click here' is shown for non portal member.(Issue-id : ZLS-3294)");
				}										
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.addStacktraceToReport(etest,e);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void setupEmailConfiguration(WebDriver driver,WebDriver associate_driver,ExtentTest etest,String widget_code,Hashtable<String,Hashtable<String,String>> email_configuration_info) throws Exception
	{
		//here we are checking email configuration for Transcript mail,Missed Visitor Notifications mail,Visitor Feedback mail,BlockedIP report,Company mail address verification mail,Email Copier
		WebDriver visitor_driver=null;
		int failcount=0;
		String unique_id=null;
		Hashtable<String,String> visitor_details=null;

		try
		{
			try
			{
				visitor_details=email_configuration_info.get(TRANSCRIPT);
				visitor_driver=visitor_driver_manager.getDriver(driver);
		        unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);
		       	visitor_driver.navigate().refresh();
		       	etest.log(Status.INFO,"Portal chat transcript mail was triggered.");
			}
			catch(Exception e1)
			{
				etest.log(Status.INFO,"Portal chat transcript mail was NOT triggered.");
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"setupEmailConfiguration","Exception",e1);
			}

			try
			{
				visitor_details=email_configuration_info.get(FEEDBACK);
				visitor_driver=visitor_driver_manager.getDriver(driver);
		        unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);
		       	visitor_driver.navigate().refresh();
		       	etest.log(Status.INFO,"Portal feedback mail was triggered.");
			}
			catch(Exception e2)
			{
				etest.log(Status.INFO,"Portal feedback mail was NOT triggered.");
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"setupEmailConfiguration","Exception",e2);
			}

			try
			{
				visitor_details=email_configuration_info.get(MISSED);
				visitor_driver=visitor_driver_manager.getDriver(driver);
		        unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.MISSED,visitor_details,null);
		       	visitor_driver.navigate().refresh();
		       	etest.log(Status.INFO,"Portal missed chat mail was triggered.");
			}
			catch(Exception e3)
			{
				etest.log(Status.INFO,"Portal missed chat mail was NOT triggered.");
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"setupEmailConfiguration","Exception",e3);
			}

			try
			{
				visitor_details=email_configuration_info.get(VISITOR_TRANSCRIPT);
				visitor_driver=visitor_driver_manager.getDriver(driver);
		        unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);
		       	visitor_driver.navigate().refresh();
		       	etest.log(Status.INFO,"Visitor chat transcript mail was triggered.");
			}
			catch(Exception e4)
			{
				etest.log(Status.INFO,"Visitor chat transcript mail was NOT triggered.");
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"setupEmailConfiguration","Exception",e4);
			}

			try
			{
				visitor_details=email_configuration_info.get(BLOCKEDIP);	       	
				visitor_driver=visitor_driver_manager.getDriver(driver);
		        unique_id=ConversationViewCommonFunctions.setupChatType(associate_driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);
		       	ChatWindow.blockIPFromChat(associate_driver,etest);
		       	etest.log(Status.INFO,"Portal blocked ip mail was triggered.");
			}
			catch(Exception e5)
			{
				etest.log(Status.INFO,"Portal blocked ip mail was NOT triggered.");
				TakeScreenshot.screenshot(associate_driver,etest,MODULE_NAME,"setupEmailConfiguration","Exception",e5);
				TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"setupEmailConfiguration","Exception",e5);
			}


			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(visitor_driver,etest);
			throw e;
		}
	}

	public static void checkEmailInputs(WebDriver driver,ExtentTest etest,String widget_code,PortalSetting portal_setting,String invalid_email_alert_usecase,String remaining_email_info_usecase)
	{

		String email=CommonUtil.getUniqueMessage()+"@email.com";
        String info_message_template=" more Emails to go";
        int remaining_emails_usecase_failcount=0;

		try
		{
			Tab.navToPortalTab(driver);

	        for(int i=1;i<=5;i++)
	        {
	        	etest.log(Status.INFO,"Entering "+i+" emails in "+portal_setting+" to check for info message.");
		        PortalSettingsRealTimeCommonFunctions.enterTextInMailInput(driver,portal_setting,getNEmails(email,i));

		        String expected_message=5-i+info_message_template;
		        String actual_message=PortalSettingsRealTimeCommonFunctions.getRemainingEmailCount(driver,portal_setting);

		        if(i==5)
		        {
		        	expected_message="Oops! You just reached your Max Email Address count limit";	
		        }

		        if(CommonUtil.checkStringContainsAndLog(expected_message,actual_message,"remaining emails count message",etest)==false)
		        {
		        	remaining_emails_usecase_failcount++;
		        	TakeScreenshot.screenshot(driver,etest);
		        }
	        }

	        result.put(remaining_email_info_usecase,CommonUtil.returnResult(remaining_emails_usecase_failcount));

	        PortalSettingsRealTimeCommonFunctions.enterTextInMailInput(driver,portal_setting,"InvalidEmail");
	        Tab.clickPortalSettings(driver);//to save setting and trigger alert

	        CommonUtil.sleep(500);

	        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"invalid Email");

			if(popup!=null)
			{
		        result.put(invalid_email_alert_usecase,true);
		        etest.log(Status.PASS,"Alert was found after invalid email was entered in "+portal_setting);
				try
				{
					HandleCommonUI.clickPositivePopupButton(popup);
				}
				catch(Exception e)
				{
					CommonUtil.refreshPage(driver);
				}
			}        
			else
			{
		        etest.log(Status.FAIL,"Alert was NOT found after invalid email was entered in "+portal_setting);
		        result.put(invalid_email_alert_usecase,false);			
			}
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkEmailInputs","Exception",e);
		}
		finally
		{
			
		}
	}

	public static String getNEmails(String email,int count)
	{
		String emails="";

		for(int i=1;i<=count;i++)
		{
			String comma=",";

			if(i==count)
			{
				comma="";
			}
			emails=emails+i+email+comma;
		}

		return emails;
	}

	public static boolean checkEmailConfiguration(WebDriver driver,ExtentTest etest,String widget_code,String email_setting)
	{
		final String
		confirm_email_and_check_use_case="PSR23",
		confirmation_mail_use_case="PSR17",
		email_copier_use_case="PSR21",
		resend_mail_use_case="PSR22";

		WebDriver visitor_driver=null;
		WebDriver api_driver=null;

		int failcount=0;

		PortalInput email_configuration=null;
		PortalInput company_mail=null;

		boolean isChatInitiated=false;

		if(VISITOR_EMAIL_FOR_EMAIL_CONFIGURATION_USECASE==null)
		{
			VISITOR_EMAIL_FOR_EMAIL_CONFIGURATION_USECASE=CommonUtil.getUniqueMessage()+"@email.com";
		}
		else
		{
			isChatInitiated=true;
		}

		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=VISITOR_EMAIL_FOR_EMAIL_CONFIGURATION_USECASE,
		visitor_question="question"+label;

		String email_copier_email=null;

		try
		{
			if(email_setting.equals(PortalSettingsConstants.COMPANY))
			{
				email_configuration=new PortalInput(PortalSetting.EMAIL_CONFIGURATION,PortalSettingsConstants.COMPANY);
				company_mail=new PortalInput(PortalSetting.PORTAL_FROM_EMAIL,true,COMPANY_EMAIL);
				company_mail.addAdditionalInfo("company_name",COMPANY_NAME);
			}
			else if(email_setting.equals(PortalSettingsConstants.OPERATOR))
			{
				email_configuration=new PortalInput(PortalSetting.EMAIL_CONFIGURATION,PortalSettingsConstants.OPERATOR);
			}
			else if(email_setting.equals(PortalSettingsConstants.BOTH))
			{
				email_configuration=new PortalInput(PortalSetting.EMAIL_CONFIGURATION,PortalSettingsConstants.BOTH);
			}

			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,email_configuration,etest);

			if(!result.containsKey(email_copier_use_case))
			{
				email_copier_email=getMail("CPY"+label);		
				PortalInput email_copier=new PortalInput(PortalSetting.EMAIL_COPIER,true,email_copier_email);
				PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,email_copier,etest);	
			}

			if( !isCompanyEmailConformed && ( email_setting.equals(PortalSettingsConstants.COMPANY) || email_setting.equals(PortalSettingsConstants.BOTH )) )
			{
				PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,company_mail,etest);

				etest.log(Status.INFO,"Waiting for 15 seconds to recieve confirmation email.");
				CommonUtil.sleep(15*1000);

				if(!result.containsKey(resend_mail_use_case))
				{
					PortalConfig.clickResendConfirmationMail(driver,etest);
				}

				etest.log(Status.INFO,"Waiting for 120 seconds to recieve resend confirmation email.");
				CommonUtil.sleep(120*1000);

				if(!result.containsKey(resend_mail_use_case))
				{
					api_driver=visitor_driver_manager.getDriver();

					int no_of_confirmation_mails=ZohoMailAPIUtil.getResultsLengthOfSearchMailAPI(ZohoMailAPIUtil.searchMail(api_driver,AUTHTOKEN,ACCOUNTID,COMPANY_NAME));
					
					no_of_confirmation_mails=no_of_confirmation_mails-1;//because Zoho Mail API sends an extra empty response

					if(no_of_confirmation_mails==2)
					{
						etest.log(Status.PASS,"Confirmation mail was recieved after resend confirmation mail was clicked.");
						result.put(resend_mail_use_case,true);	
					}
					else
					{
						failcount++;
						result.put(resend_mail_use_case,false);	
						etest.log(Status.FAIL,"Confirmation mail was NOT recieved after resend confirmation mail was clicked. Expected confirmation mails : 2 Actual :"+no_of_confirmation_mails);
					}
				}

				if(PortalSettingsRealTimeCommonFunctions.confirmMailAddress(COMPANY_NAME,AUTHTOKEN,ACCOUNTID,etest))
				{
					etest.log(Status.PASS,"Company email "+COMPANY_EMAIL+" is confirmed.");
					isCompanyEmailConformed=true;
					result.put(confirm_email_and_check_use_case,true);
					result.put(confirmation_mail_use_case,true);
				}
				else
				{
					etest.log(Status.FAIL,"Company email "+COMPANY_EMAIL+" is NOT confirmed.");
					result.put(confirmation_mail_use_case,false);
					result.put(confirm_email_and_check_use_case,false);
				}
			}

			if(!isChatInitiated)
			{
				visitor_driver=visitor_driver_manager.getDriver(driver);
				Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);
				ChatWindow.endAndCloseChat(driver);
				driver.navigate().refresh();
			}

			// GlobalSearch.searchAndOpenChat(driver,VISITOR_EMAIL_FOR_EMAIL_CONFIGURATION_USECASE);
			ChatHistory.clickLatestChatFromChatHistory(driver);

			ChatHistory.clickReplyMailButton(driver);

			String
			from_email=ChatHistory.getMailInfo(driver,"from"),
			to_email=ChatHistory.getMailInfo(driver,"to"),
			cc_email=ChatHistory.getMailInfo(driver,"cc");

			if(!result.containsKey(email_copier_use_case))
			{	
				if(CommonUtil.checkStringContainsAndLog(email_copier_email,cc_email,"email copier mail",etest)==false)
				{
					result.put(email_copier_use_case,false);
					failcount++;
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"CCMismatch","Failure");
				}
				else
				{
					result.put(email_copier_use_case,true);
				}
			}


			String company_email=null,agent_email=null;

			if(email_setting.equals(PortalSettingsConstants.OPERATOR))
			{
				agent_email=ExecuteStatements.getUserMail(driver);
				company_email="";
			}

			else if(email_setting.equals(PortalSettingsConstants.COMPANY))
			{
				agent_email="";
				company_email=COMPANY_EMAIL;
			}
			else if(email_setting.equals(PortalSettingsConstants.BOTH))
			{
				
				agent_email=ExecuteStatements.getUserMail(driver);
				company_email=COMPANY_EMAIL;
				clickSecondaryEmail(driver, etest);
			}

			if(from_email.contains(agent_email) && from_email.contains(company_email))
			{
				etest.log(Status.PASS,"Expected from email(s) were found for mails which are to be sent from the send mail button");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Expected from email(s) were NOT found for mails which are to be sent from the send mail button. Expected :"+agent_email+" "+company_email+" Actual:"+from_email);
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkSendMailButtonFromDropdown","Failure");
			}

			TakeScreenshot.infoScreenshot(driver,etest);

			driver.navigate().refresh();
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkSendMailButtonFromDropdown","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkSendMailButtonFromDropdown","Exception",e);
		}
		finally
		{
			Driver.quitDriver(api_driver);
			driver.navigate().refresh();
			return CommonUtil.returnResult(failcount);
		}

	}
	
	public static void clickSecondaryEmail(WebDriver driver,ExtentTest etest) {		
		CommonWait.waitTillDisplayed(driver, By.id("sendmailfrm"));
		CommonUtil.clickWebElement(driver, By.xpath("//*[@id='frommaildiv_div']/em"));
		CommonWait.waitTillDisplayed(driver, By.id("frommaildiv_ddown"));
		CommonUtil.clickWebElement(driver, By.xpath("//*[@id='frommaildiv_ddown']/div/ul[2]"));
		etest.log(Status.INFO, "Agent email for From is clicked");
		TakeScreenshot.infoScreenshot(driver, etest);
	}
	
	
	public static boolean checkSendMailButtonFromDropdown(WebDriver driver,ExtentTest etest,String widget_code)
	{
		//from dropdown near notes icon

		int failcount=0;

		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver();

			String
			label=CommonUtil.getUniqueMessage(),
			visitor_name="name"+label,
			visitor_mail=label+"@email.com",
			visitor_question="question"+label;

			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);

	        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

			ChatWindow.clickSendVisitorInformationAsEmailButton(driver,etest);	
			ChatWindow.clickContentButtonInSendEmailPopup(driver);

			String from_email=ChatWindow.getFromMailAddressInSendEmailPopup(driver);

			String agent_email=ExecuteStatements.getUserMail(driver);

			if(CommonUtil.checkStringContainsAndLog(agent_email,from_email,"from email(popup opened by clicking dropdown near notes icon)",etest)==false)
			{
				failcount++;
			}

			driver.navigate().refresh();

			ConcurrentChatCommonFunctions.closeAllMyChats(driver,etest);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkSendMailButtonFromDropdown","Exception",e);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkSendMailButtonFromDropdown","Exception",e);
		}
		finally
		{
			driver.navigate().refresh();
			return CommonUtil.returnResult(failcount);
		}
	}
	/*
	//dummy function
	public static Hashtable<String,Hashtable<String,String>> getEmailConfigurationVisitorInfo()
	{
		Hashtable<String,Hashtable<String,String>> email_configuration_info=new Hashtable<String,Hashtable<String,String>>();

		String label=CommonUtil.getUniqueMessage();

		// final String
		// TRANSCRIPT_EMAIL=email_configuration_info.get(TRANSCRIPT).get("portal_email"),
		// MISSED_EMAIL=email_configuration_info.get(MISSED).get("portal_email"),
		// FEEDBACK_EMAIL=email_configuration_info.get(FEEDBACK).get("portal_email"),
		// BLOCKEDIP_EMAIL=getMail("IP"+label),
		// COMPANY_NAME="C"+label,
		// COMPANY_EMAIL=getMail(COMPANY_NAME),
		// EMAIL_COPIER=getMail("EC"+label),
		// AUTOMATED_VISITOR_CHAT_TRANSCRIPT=getMail("VCT"+label)
		;





		String
		visitor_name=null,
		visitor_mail=null,
		visitor_question=null;

		Hashtable<String,String> usecase_details=null;

		usecase_details=new Hashtable<String,String>();
		label="1517829841575";
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		usecase_details.put("label",label);
		usecase_details.put("portal_email",getMail("CT"+label));
		email_configuration_info.put(TRANSCRIPT,usecase_details);

		usecase_details=new Hashtable<String,String>();
		CommonUtil.sleep(1);//to make sure label is unique
		label="1517829841579";
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		usecase_details.put("label",label);
		usecase_details.put("portal_email",getMail("M"+label));
		email_configuration_info.put(MISSED,usecase_details);

		usecase_details=new Hashtable<String,String>();		
		CommonUtil.sleep(1);
		label="1517829841580";
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,"F"+label,"3");
		usecase_details.put("label",usecase_details.get("feedback"));
		usecase_details.put("portal_email",getMail("FB"+label));
		email_configuration_info.put(FEEDBACK,usecase_details);

		// usecase_details=new Hashtable<String,String>();
		// usecase_details.put(BLOCKEDIP,"199.188.1.2");
		// usecase_details.put("label","199.188.1.2");
		// email_configuration_info.put(BLOCKEDIP,usecase_details);

		// usecase_details=new Hashtable<String,String>();
		// CommonUtil.sleep(1);
		// label="1517826597047";
		// usecase_details=new Hashtable<String,String>();
		// visitor_mail=label+"@email.com";
		// usecase_details.put("label",label);
		// usecase_details.put(COMPANY_MAIL,visitor_mail);
		// email_configuration_info.put(COMPANY_MAIL,usecase_details);

		// usecase_details=new Hashtable<String,String>();		
		// CommonUtil.sleep(1);
		// label="1517826597047";
		// usecase_details=new Hashtable<String,String>();
		// visitor_mail=label+"@email.com";
		// usecase_details.put("label",label);
		// usecase_details.put(EMAIL_COPIER,visitor_mail);
		// email_configuration_info.put(EMAIL_COPIER,usecase_details);

		return email_configuration_info;
	}
	*/
	
	public static Hashtable<String,Hashtable<String,String>> getEmailConfigurationVisitorInfo()
	{
		Hashtable<String,Hashtable<String,String>> email_configuration_info=new Hashtable<String,Hashtable<String,String>>();

		String label=null;

		String
		visitor_name=null,
		visitor_mail=null,
		visitor_question=null;

		Hashtable<String,String> usecase_details=null;

		usecase_details=new Hashtable<String,String>();
		label=CommonUtil.getUniqueMessage();
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		usecase_details.put("label",label);
		usecase_details.put("portal_email",getMail("CT"+label));
		email_configuration_info.put(TRANSCRIPT,usecase_details);


		usecase_details=new Hashtable<String,String>();
		CommonUtil.sleep(1);
		label=CommonUtil.getUniqueMessage();
		visitor_name="V"+label;
		visitor_mail=getMail(visitor_name);
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		usecase_details.put("label","to:"+visitor_name);
		email_configuration_info.put(VISITOR_TRANSCRIPT,usecase_details);

		usecase_details=new Hashtable<String,String>();
		CommonUtil.sleep(1);//to make sure label is unique
		label=CommonUtil.getUniqueMessage();
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		usecase_details.put("label",label);
		usecase_details.put("portal_email",getMail("MC"+label));
		email_configuration_info.put(MISSED,usecase_details);

		usecase_details=new Hashtable<String,String>();		
		CommonUtil.sleep(1);
		label=CommonUtil.getUniqueMessage();
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,"F"+label,"3");
		usecase_details.put("label",usecase_details.get("feedback"));
		usecase_details.put("portal_email",getMail("FB"+label));
		email_configuration_info.put(FEEDBACK,usecase_details);

		usecase_details=new Hashtable<String,String>();
		CommonUtil.sleep(1);
		label=CommonUtil.getUniqueMessage();
		visitor_name="V"+label;
		visitor_mail=label+"@email.com";
		visitor_question="Q"+label;
		usecase_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		usecase_details.put("portal_email",getMail("IP"+label));
		usecase_details.put("label","IP"+label);
		email_configuration_info.put(BLOCKEDIP,usecase_details);

		// usecase_details=new Hashtable<String,String>();
		// CommonUtil.sleep(1);
		// label=CommonUtil.getUniqueMessage();
		// usecase_details=new Hashtable<String,String>();
		// visitor_mail=label+"@email.com";
		// usecase_details.put("label",label);
		// usecase_details.put(COMPANY_MAIL,visitor_mail);
		// email_configuration_info.put(COMPANY_MAIL,usecase_details);

		// usecase_details=new Hashtable<String,String>();		
		// CommonUtil.sleep(1);
		// label=CommonUtil.getUniqueMessage();
		// usecase_details=new Hashtable<String,String>();
		// visitor_mail=label+"@email.com";
		// usecase_details.put("label",label);
		// usecase_details.put(EMAIL_COPIER,visitor_mail);
		// email_configuration_info.put(EMAIL_COPIER,usecase_details);

		return email_configuration_info;
	}

	public static String setupOngoingChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code) throws Exception
	{
		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="question"+label;

		Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

        return unique_id;
	}

	public static void setIdleTimeToNever(WebDriver driver,ExtentTest etest)
	{
		try
		{
	        PortalInput portal_input=new PortalInput(PortalSetting.SET_OPERATOR_IDLE_TIME,PortalSettingsConstants.NEVER);
	        PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);
	        etest.log(Status.PASS,"User idle time was set to "+PortalSettingsConstants.NEVER);
		}
		catch(Exception e)
		{
	        etest.log(Status.WARNING,"User idle time was NOT set to "+PortalSettingsConstants.NEVER);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"setIdleTimeToNever","Exception",e);
		}
	}
}
