//$Id$
package com.zoho.livedesk.client.PortalSettingsRealTime;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Arrays;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonUtil;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.WebsitesTab;
import com.zoho.livedesk.util.common.actions.Websites;

import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import java.util.Hashtable;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;
import com.zoho.livedesk.server.ResourceManager;

public class PortalSettingsConstants
{
	public static final String
	FEEDBACK_EMAIL_SUBJECT="ZOHO SalesIQ - Chat Session Feedback",
	BLOCKED_IP_SUBJECT="Zoho SalesIQ - $agent$ has blocked a customer IP."
	;

	/*DOM CONSTANTS*/
	public static final String
	CHECKED_ATTRIBUTE="checked",
	OPERATOR_CHECKBOX_ID="fromiduser",
	COMPANY_CHECKBOX_ID="fromidcompany",
	BOTH_CHECKBOX_ID="fromidboth",
	TOGGLE_BUTTON_CLASS="togglebtn",
	VISITOR_SCREENSHARING_INVITE_TEXT=ResourceManager.getRealValue("screenshare_visitor_info"),
	RESEND_MAIL_CONTAINER_ID="errfromemailid"
	;

	public static final By
	CHECKBOX_CONTAINER=By.className("uprdowrap"),
	SELECTED_CHECKBOX=By.className("rdselected");

	/*VARIABLE CONSTANTS*/
	public static final String
	NONE="None",
	AUTOMATED="Automated",
	BOTH="Both",
	MANUAL="Manual",
	NEVER="Never",
	MINUTES5="5 Minutes",
	MINUTES10="10 Minutes",
	MINUTES15="15 Minutes",
	MINUTES30="30 Minutes",
	HOUR1="1 Hour",
	OPERATOR="Operator",
	COMPANY="Company",
	ABYSS="Abyss",
	BLAST="Blast",
	EBONY="Ebony",
	ECLIPSE="Eclipse",
	ECSTASY="Ecstasy",
	LUNA="Luna",
	WILDERNESS="Wilderness";


	
	/*ENUMS*/
	public enum InputType
	{
		DROPDOWN,
		TOGGLE,
		TOGGLE_WITH_INPUT,
		CHECKBOX,
		SPECIAL,
		INPUT_ONLY;
	}

	public enum PortalSetting
	{
		SHOW_TYPING_STATUS("showtyping"),
		SEND_FILE_TO_VISITOR("filetransfer"),
		SHARE_URL("pushpage"),
		EMAIL_THE_VISITOR_INFORMATION("emailtranscripts"),
		GOOGLE_TRANSLATION("translate"),
		ALLOW_SCREEN_SHARING("screensharing"),
		IDLE_USERS_AS_OFFLINE("idleasoffline"),
		SET_OPERATOR_IDLE_TIME("inactiveperiod"),
		EMAIL_CONFIGURATION("frommailconfig"),
		EMAIL_COPIER("ccemailaddr"),
		DAILY_STATISTICS("dailystatics"),
		WEEKLY_REPORT("weeklystats"),
		BLOCKED_IP_MAIL("sendemailforipblockto"),
		VISITOR_FEEDBACK_MAIL("visitorfeedback"),
		CHAT_TRANSCRIPT_MAIL("sendtranasemail"),
		MISSED_VISITOR_MAIL("offbusymsg"),
		EMAILSIGNATURE("semailsignature"),
		PORTAL_FROM_EMAIL("frommailidmain"),
		AUTOMATED_VISITOR_CHAT_TRANSCRIPT("chattranscript"),
		GDPR("isgdprenabled"),
		PASSWORD_PROTECTION("ispasswordprotected"),
		COOKIE_POLICY_LINK("cookiepolicyurl"),
		CHAT_PRIVACY("chatprivacyconfig"),
		PRIVACY_POLICY_LINK("chatcookiepolicyurl")
		;

		/*eid it the name of the custom parameter in salesiq dom*/

		public String eid,input_id,remaining_emails_count_id;

		PortalSetting(String eid)
		{
			this.eid=eid;
			this.input_id="s"+eid;
			this.remaining_emails_count_id="count_"+this.input_id;
		}
	}	
	/*Constant related functions*/
	public static InputType getInputType(PortalSetting portal_setting)
	{
		PortalSetting[] toggles = {PortalSetting.GDPR,PortalSetting.SHOW_TYPING_STATUS,PortalSetting.SEND_FILE_TO_VISITOR,PortalSetting.SHARE_URL,PortalSetting.EMAIL_THE_VISITOR_INFORMATION,PortalSetting.ALLOW_SCREEN_SHARING,PortalSetting.IDLE_USERS_AS_OFFLINE};
		PortalSetting[] dropdowns = {PortalSetting.SET_OPERATOR_IDLE_TIME,PortalSetting.EMAILSIGNATURE,PortalSetting.GOOGLE_TRANSLATION};
		PortalSetting[] toggle_with_inputs = {PortalSetting.EMAIL_COPIER,PortalSetting.DAILY_STATISTICS,PortalSetting.WEEKLY_REPORT,PortalSetting.BLOCKED_IP_MAIL,PortalSetting.VISITOR_FEEDBACK_MAIL,PortalSetting.CHAT_TRANSCRIPT_MAIL,PortalSetting.MISSED_VISITOR_MAIL};
		PortalSetting[] checkboxes = {PortalSetting.PASSWORD_PROTECTION,PortalSetting.CHAT_PRIVACY,PortalSetting.EMAIL_CONFIGURATION};
		PortalSetting[] special_inputs = {PortalSetting.PORTAL_FROM_EMAIL,PortalSetting.AUTOMATED_VISITOR_CHAT_TRANSCRIPT};
		PortalSetting[] input_only = {PortalSetting.COOKIE_POLICY_LINK,PortalSetting.PRIVACY_POLICY_LINK};

		if(Arrays.asList(toggles).contains(portal_setting))
		{
			return InputType.TOGGLE;
		}
		else if(Arrays.asList(toggle_with_inputs).contains(portal_setting))
		{
			return InputType.TOGGLE_WITH_INPUT;
		}
		else if(Arrays.asList(dropdowns).contains(portal_setting))
		{
			return InputType.DROPDOWN;
		}
		else if(Arrays.asList(checkboxes).contains(portal_setting))
		{
			return InputType.CHECKBOX;
		}
		else if(Arrays.asList(special_inputs).contains(portal_setting))
		{
			return InputType.SPECIAL;
		}
		else if(Arrays.asList(input_only).contains(portal_setting))
		{
			return InputType.INPUT_ONLY;			
		}
		else
		{
			throw new ZohoSalesIQRuntimeException("Invalid PortalSetting (in case,any new PortalSetting enum has been added, Please configure it in this method)"+portal_setting);
		}
	}

	/*Objects*/
	public static class PortalInput
	{
		Boolean is_enable=null;
		PortalSetting portal_setting=null;
		String value=null;
		InputType input_type=null;

		Hashtable<String,String> additional_info=null;

		public PortalInput(PortalSetting portal_setting,Boolean is_enable,String value)
		{
			this.portal_setting=portal_setting;
			this.is_enable=is_enable;
			this.value=value;
			this.input_type=getInputType(portal_setting);
		}
		public PortalInput(PortalSetting portal_setting,Boolean is_enable)
		{
			this(portal_setting,is_enable,null);
		}
		public PortalInput(PortalSetting portal_setting,String value)
		{
			this(portal_setting,null,value);
		}

		public void addAdditionalInfo(String key,String value)
		{
			if(additional_info==null)
			{
				additional_info=new Hashtable<String,String>();
			}

			additional_info.put(key,value);
		}

		public String getAdditionalInfo(String key)
		{
			return additional_info.get(key);
		}	
    }
}
