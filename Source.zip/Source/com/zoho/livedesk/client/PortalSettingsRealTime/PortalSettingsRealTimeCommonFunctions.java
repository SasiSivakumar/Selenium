//$Id$
package com.zoho.livedesk.client.PortalSettingsRealTime;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Hashtable;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonUtil;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import org.openqa.selenium.TimeoutException;

import com.zoho.livedesk.client.ChatTransfer.CommonFunctionsTC;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.client.ConcurrentChats.*;

import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.PortalSettingsRealTime.*;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.InputType;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;


public class PortalSettingsRealTimeCommonFunctions
{
    public static void setPortalType(WebDriver driver,ExtentTest etest,PortalInput... portal_inputs) throws Exception
    {
    	for(PortalInput portal_input : portal_inputs)
		{
			setPortalSetting(driver,portal_input,etest);
		}
    }

    public static boolean isPortalSettingMenuOpen(WebDriver driver)
    {
        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("portaleditmodule"))
        {
            return CommonWait.isDisplayed(driver,By.id("portaleditmodule"));
        }

        return false;
    }

    public static void setPortalSetting(WebDriver driver,PortalInput portal_input,ExtentTest etest) throws Exception
    {
        String portal_setting_log=null;

        if(portal_input.portal_setting==PortalSetting.SET_OPERATOR_IDLE_TIME)
        {
            if(portal_input.value!=null && portal_input.value.equals(PortalSettingsConstants.NEVER))
            {
                portal_input.value="-1";
            }
            else
            {
                portal_input.value=""+Integer.parseInt(portal_input.value.replaceAll("[^0-9]", ""));
            }
        }

        if(isPortalSettingMenuOpen(driver)==false)
        {
            CommonUtil.refreshPage(driver);
            CommonUtil.sleep(2000);
            Tab.navToPortalTab(driver);
        }

    	if(portal_input.input_type==InputType.TOGGLE)
    	{
    		PortalConfig.editToggle(driver,portal_input.portal_setting.eid,portal_input.is_enable);
            portal_setting_log="Portal setting : "+portal_input.portal_setting+"\n"+" was set as "+portal_input.is_enable;
    	}
        else if(portal_input.portal_setting==PortalSetting.GOOGLE_TRANSLATION)
        {
            CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id("googletranslateconfig_div")));
            CommonUtil.click(driver,By.id("googletranslateconfig_div"));
            By locator=By.cssSelector("li[title='"+portal_input.value+"']");
            CommonWait.waitTillDisplayed(driver,locator);
            CommonUtil.click(driver,locator);
            CommonWait.waitTillHidden(driver,locator);
        }
		else if(portal_input.input_type==InputType.DROPDOWN)
		{
			PortalConfig.changeValues(driver,portal_input.portal_setting.eid,portal_input.value,etest);
            portal_setting_log="Portal setting : "+portal_input.portal_setting+"\n"+" was set as "+portal_input.value;
		}
		else if(portal_input.input_type==InputType.TOGGLE_WITH_INPUT)
		{
    		PortalConfig.editToggleAndSetValue(driver,portal_input.portal_setting.eid,portal_input.is_enable,portal_input.portal_setting.input_id,portal_input.value);
            portal_setting_log="Portal setting : "+portal_input.portal_setting+"\n"+" was set as "+portal_input.is_enable+" with value "+portal_input.value;
		}
		else if(portal_input.input_type==InputType.CHECKBOX)
		{

            String checkbox_id=null;
            
            if(portal_input.portal_setting==PortalSetting.EMAIL_CONFIGURATION)
            {
                if(portal_input.value.contains(PortalSettingsConstants.COMPANY))
                {
                    checkbox_id="fromidcompany";
                }   
                else if(portal_input.value.contains(PortalSettingsConstants.OPERATOR))
                {
                    checkbox_id="fromiduser";
                }
                else if(portal_input.value.contains(PortalSettingsConstants.BOTH))
                {
                    checkbox_id="fromidboth";
                }
            }

			PortalConfig.editCheckbox(driver,portal_input.portal_setting.eid,checkbox_id);
            portal_setting_log="Portal setting : "+portal_input.portal_setting+"\n"+" was set as "+portal_input.value;
		}
        else if(portal_input.input_type==InputType.SPECIAL)
        {
            if(portal_input.portal_setting==PortalSetting.PORTAL_FROM_EMAIL)
            {
                PortalConfig.setCompanyFromEmailAndName(driver,etest,portal_input.getAdditionalInfo("company_name"),portal_input.value);
                portal_setting_log="Portal setting : "+portal_input.portal_setting+"\n"+" was set with company mail -->"+portal_input.value+" and company name --> "+portal_input.getAdditionalInfo("company_name");
            }
            if(portal_input.portal_setting==PortalSetting.AUTOMATED_VISITOR_CHAT_TRANSCRIPT)
            {
                PortalConfig.setVisitorChatTranscript(driver,portal_input.value);
                portal_setting_log="Portal setting : "+portal_input.portal_setting+"\n"+" was set as "+portal_input.value;
            }
        }
        else if(portal_input.input_type==InputType.INPUT_ONLY)
        {
            PortalConfig.setInputValue(driver,portal_input.portal_setting.eid,portal_input.value);
        }
		else
		{
			throw new ZohoSalesIQRuntimeException("Unexpected 'PortalInput' input_type  : "+portal_input.input_type);
		}

        CommonUtil.clickWebElement(driver,By.id("setting_sm_configration"),By.tagName("a"));
        CommonUtil.sleep(3000);
        CommonUtil.clickWebElement(driver,By.id("setting_sm_configration"),By.tagName("a"));

        TakeScreenshot.infoScreenshot(driver,etest);
        
        Tab.clickPortalSettings(driver);

        CommonUtil.refreshPage(driver);

       etest.log(Status.INFO,portal_setting_log);
       TakeScreenshot.screenshot(driver,etest,"PortalSetting","Set","Saved",1);
    }

    public static boolean isMessageRecievedByVisitor(WebDriver driver,String name,String message)
    {
    	message=name+"\n"+message;
    	try
    	{
	    	VisitorWindow.waitTillMessageInChat(driver,message);
	    	return true;
    	}
    	catch(Exception e)
    	{
    		System.out.println("~~~OUR MESSAGE STR ->"+message);
    		System.out.println("~~~IS RECIEVED ->"+CommonUtil.getElement(driver,By.className("siqembed")).getText());
    		return false;
    	}
    }

    public static boolean confirmMailAddress(String company_name,String authtoken,String account_id,ExtentTest etest) throws Exception
    {
        WebDriver driver=Functions.setUp();
        etest.log(Status.INFO,"Searching for company_name "+company_name);
        Hashtable<String,String> mail_info=ZohoMailAPIUtil.getMailInfoByUniqueKeyWord(driver,etest,authtoken,account_id,company_name);
        String confirmation_link=getConfirmationLink(mail_info.get("content"));
        confirmation_link=confirmation_link.substring(2, confirmation_link.length() - 2);//remove following chars at beg and end --> "\
        String confirmation_code=ZohoMailAPIUtil.extractTextFromHTML(mail_info.get("content")); 
        confirmation_code=confirmation_code.split("Click Here Confirm Code ")[1].split(" This link is valid until you click and get registered")[0];
        confirmation_code = confirmation_code.replace("\\t", "").replace("\\r","").replace("\\n", "");
 
        etest.log(Status.INFO,"Confirmation code was retrieved from the mail as "+confirmation_code+", confirmation url was retreieved as "+confirmation_link);

        driver.get(confirmation_link);

        CommonUtil.getElement(driver,By.id("code")).sendKeys(confirmation_code);
        CommonUtil.getElement(driver,By.className("rg-button")).click();

        boolean isConfirmed=CommonUtil.waitTillWebElementContainsAttributeValue(driver.findElement(By.tagName("body")),"innerText","Mail confirmed");

        TakeScreenshot.screenshot(driver,etest,"PortalSetting","MailConfirmation",isConfirmed+"",1);   

        driver.quit();

        return isConfirmed;
    }

    public static String getConfirmationLink(String html)
    {
        return ZohoMailAPIUtil.getElementAttribute(html,"a[href*=mailconfirm.sas]","href");
    }

    public static void enterTextInMailInput(WebDriver driver,PortalSetting portal_setting,String text)
    {
        WebElement mail_input=CommonUtil.getElement(driver,By.id(portal_setting.input_id));
        CommonUtil.inViewPortSafe(driver,mail_input,100);
        mail_input.click();
        mail_input.clear();
        mail_input.sendKeys(text);        
    }

    public static String getRemainingEmailCount(WebDriver driver,PortalSetting portal_setting)
    {
        WebElement count_container=CommonUtil.getElement(driver,By.id(portal_setting.remaining_emails_count_id));
        CommonWait.waitTillDisplayed(count_container);
        return count_container.getText();
    }

    //to be added in commonutil
    public static void log(ExtentTest etest,String log)
    {
    	if(etest!=null)
    	{
    		etest.log(Status.INFO,log);
    	}
    }

}
