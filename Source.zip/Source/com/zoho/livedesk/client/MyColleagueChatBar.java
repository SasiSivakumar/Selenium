//$Id$

package com.zoho.livedesk.client;

import java.util.Hashtable;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class MyColleagueChatBar {

	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	public static ExtentTest etest; 
	
	public static Hashtable chatBarConfig(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CB1"));
            ComplexReportFactory.setValues(etest,"Automation","My Colleague ChatBar");
			
			url = ConfManager.requestURL();
			
            result.put("CB1", false);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lschatbar")));

			etest.log(Status.PASS,"ChatBar is present");

			result.put("CB1", true);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CB2"));
            ComplexReportFactory.setValues(etest,"Automation","My Colleague ChatBar");

			result.put("CB2", checkMyColleagues(driver));
			
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CB3"));
            ComplexReportFactory.setValues(etest,"Automation","My Colleague ChatBar");

			result.put("CB3", checkMessageBoard(driver));
			
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CB4"));
            ComplexReportFactory.setValues(etest,"Automation","My Colleague ChatBar");

			result.put("CB4", checkNotifications(driver));
			
			ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorMyColleagueChatBar");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");			
			TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","Presence Of ChatBar","ErrorWhileCheckingChatBar",e);

			result.put("CB1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorMyColleagueChatBar");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","Presence Of ChatBar","ErrorWhileCheckingChatBar",e);

			result.put("CB1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	private static boolean checkMyColleagues(WebDriver driver)
	{
		try
		{
			driver.findElement(By.id("h_mycolleagues")).click();

			WebElement elmt = driver.findElement(By.id("mycolleagues"));

			if((elmt.findElement(By.id("ctitle")).getText()).equals(ResourceManager.getRealValue("common_mycolleagues")))
			{
				elmt.findElement(By.id("ctitle")).click();
				etest.log(Status.PASS,"MyColleague Window title matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","MyColleaguesWindow","MismatchTitle");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","MyColleaguesWindow","ErrorWhileCheckingMyColleaguesWindow",e);

			System.out.println("Exception while checking my colleagues in My colleague chat bar : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","MyColleaguesWindow","ErrorWhileCheckingMyColleaguesWindow",e);

            System.out.println("Exception while checking my colleagues in My colleague chat bar : "+e);
		}
		return false;
	}

	private static boolean checkMessageBoard(WebDriver driver)
	{
		try
		{
			WebElement chatbar = driver.findElement(By.id("barhead"));
			chatbar.findElement(By.className("msgboard")).click();

			WebElement bar = driver.findElement(By.id("barcontent"));
	
			WebElement elmt = bar.findElements(By.className("cwindow")).get(1);

			if((elmt.findElement(By.id("ctitle")).getText()).equals(ResourceManager.getRealValue("common_messageboard")))
			{
				elmt.findElement(By.id("ctitle")).click();
				etest.log(Status.PASS,"MessageBoard Window title matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","MessageBoard","MismatchTitle");
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","MessageBoard","ErrorWhileCheckingMessagesBoard",e);

            System.out.println("Exception while checking message board in My colleague chat bar : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","MessageBoard","ErrorWhileCheckingMessagesBoard",e);

            System.out.println("Exception while checking message board in My colleague chat bar : "+e);
		}
		return false;
	}

	private static boolean checkNotifications(WebDriver driver)
	{
		try
		{
			driver.findElement(By.id("h_offlinemsg")).click();

			WebElement elmt = driver.findElement(By.id("offlinemsg"));

			if((elmt.findElement(By.id("ctitle")).getText()).equals(ResourceManager.getRealValue("common_notifications")))
			{
				elmt.findElement(By.id("ctitle")).click();
				etest.log(Status.PASS,"Notifications Window title matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","NotificationsWindow","MismatchTitle");
			}

		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","NotificationsWindow","ErrorWhileCheckingNotificationsWindow",e);

            System.out.println("Exception while checking notifications in My colleague chat bar : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"My Colleague ChatBar","NotificationsWindow","ErrorWhileCheckingNotificationsWindow",e);

            System.out.println("Exception while checking notifications in My colleague chat bar : "+e);
		}
		return false;
	}
}
