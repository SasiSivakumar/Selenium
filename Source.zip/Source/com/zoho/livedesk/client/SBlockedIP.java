//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class SBlockedIP
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
    public static ExtentTest etest;

	public static Hashtable blockedIP(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB1"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

            url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			//BLOCKED IP VIEW
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			etest.log(Status.PASS,"BlockIp Tab is checked");

			result.put("SSB1", true);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB2"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB2", isPageAvail(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB3"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB3", addInvalidIP(driver,"1234",null,null));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB4"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB4", addIP(driver,"155.1.1.1",null,null,"SSB4"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB5"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB5", addIP(driver,"155.1.1.2","Comment added 1",null,"SSB5"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB6"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB6", addIP(driver,"155.1.1.3",null,ConfManager.getPortalName(),"SSB6"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB7"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB7", addIP(driver,"155.1.1.4","Comment added 2",ConfManager.getPortalName(),"SSB7"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB8"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB8", checkEmbedforIP(driver,"155.1.1.4",ConfManager.getPortalName()));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB9"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB9", addComment(driver,"155.1.1.3"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB10"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB10", deleteBlockedIP(driver,"155.1.1.1"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB11"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB11", unblockIP(driver,"155.1.1.3"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSB12"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Supervisor");

			result.put("SSB12", blockIP(driver,"155.1.1.3"));

			ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorBlockedIP tab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockedIPTab","ErrorWhileCheckingBlockedTab",e);

			result.put("SSB1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorBlockedIP tab");

			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockedIPTab","ErrorWhileCheckingBlockedTab",e);

			result.put("SSB1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check BlockedIP Header
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_blockedips")+"')]")));
			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_blockedips")+"')]"));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));

			if(((text.get(0).getText()).equals(ResourceManager.getRealValue("settings_blockip_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("settings_blockip_desc2"))))
			{
				etest.log(Status.PASS,"BlockedIp Page is checked");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockedIpPage","MismatchDescription");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockedIpPage","ErrorWhileCheckingBlockedIpPage",e);
            System.out.println("Exception while checking if blockedIP settings page is available in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockedIpPage","ErrorWhileCheckingBlockedIpPage",e);
            System.out.println("Exception while checking if blockedIP settings page is available in supervisor login : "+e);
			return false;
		}
		return false;
	}

	//Check adding invalid IP
	private static boolean addInvalidIP(WebDriver driver, String ip, String comment, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtipname")));

		 	driver.findElement(By.id("txtipname")).clear();
		    driver.findElement(By.id("txtipname")).sendKeys(ip);

		    if(comment != null)
		    {
		    	driver.findElement(By.id("txtcomment")).clear();
			    driver.findElement(By.id("txtcomment")).sendKeys(comment);
		    }

		    if(embed != null)
		    {
		    	WebElement select = driver.findElement(By.id("getembedchats"));
			    Select dropDown = new Select(select);
			    List<WebElement> Options = dropDown.getOptions();
			    for(WebElement option:Options){
			    	if(option.getText().equals(embed)){
                        option.click();
                    }
			    }
		    }

		    driver.findElement(By.id("ipsavebtn")).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emnewcancategory")));

            if(driver.findElement(By.id("emnewcancategory")).getAttribute("style").equals("visibility: hidden;"))
            {
                driver.findElement(By.id("btncancel")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

                return false;
            }

		    driver.findElement(By.id("btncancel")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modulelist")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
		    etest.log(Status.PASS,"Add Invalid BlockIp is checked");

			return true;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","AddInvalidIP","ErrorWhileAddingInvalidIP",e);
            System.out.println("Exception while adding invalid IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","AddInvalidIP","ErrorWhileAddingInvalidIP",e);
            System.out.println("Exception while adding invalid IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}


	//Add IP
	private static boolean addIP(WebDriver driver, String ip, String comment, String embed,String useCase)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtipname")));

		 	driver.findElement(By.id("txtipname")).clear();
		    driver.findElement(By.id("txtipname")).sendKeys(ip);
		    Thread.sleep(300);

		    if(comment != null)
		    {
		    	driver.findElement(By.id("txtcomment")).clear();
			    driver.findElement(By.id("txtcomment")).sendKeys(comment);
		    }

		    if(embed != null)
		    {
		    	WebElement select = driver.findElement(By.id("embedchatsid"));
                select.findElement(By.className("txtelips")).click();
			    List<WebElement> Options = select.findElements(By.tagName("li"));
			    for(WebElement option:Options){
			    	if(option.findElement(By.tagName("span")).getText().equals(embed)){
                        option.click();
                    }
			    }
		    }

		    CommonWait.waitTillDisplayed(driver,By.id("embedchatsid"));
		    CommonUtil.sleep(2000);
		    driver.findElement(By.id("ipsavebtn")).click();

		    try
		    {
		    	CommonWait.waitTillHidden(driver,30,By.id("ipsavebtn"));
		    }
		    catch(Exception e)
		    {
		    	CommonUtil.doNothing();
		    }

            Tab.waitForLoadingSuccessWithBanner(driver,"Added successfully","blockip.do",etest);

		    return findIP(driver,ip,comment,embed,useCase);
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","AddIP","ErrorWhileAddingIP",e);
            System.out.println("Exception while adding IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","AddIP","ErrorWhileAddingIP",e);
            System.out.println("Exception while adding IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//find Blocked IP
	private static boolean findIP(WebDriver driver, String ip, String comment, String embed,String useCase)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));

            if(comment == null&& embed == null)
            	etest.log(Status.PASS,"Added BlockIp without embed and comment is checked");

		 	boolean istrue = true;

		 	if(comment != null)
		 	{
		 		istrue = false;
		 		WebElement div1 = driver.findElement(By.id("commentlistcontainer"));
			    List<WebElement> div2 = div1.findElements(By.tagName("div"));
			    List<WebElement> div3 = div2.get(0).findElements(By.tagName("div"));
			    List<WebElement> div4 = div3.get(0).findElements(By.tagName("div"));

			    if((div4.get(0).getText()).contains(comment))
			    {
			    	etest.log(Status.PASS,"Added BlockIp with comment is checked");
					istrue = true;
			    }
			    else{
			    	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckAddedIP","AddedIPDoesnotContainsAddedComments");
                }
           	}
		 	if(embed != null)
		 	{
		 		istrue = false;
		 		driver.findElement(By.xpath("//div[text()='"+embed+"']"));
			    etest.log(Status.PASS,"Added BlockIp with embed is checked");
				istrue = true;
		 	}

		 	return istrue;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckAddedIP","ErrorWhileCheckingAddedIP",e);
            System.out.println("Exception while finding IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckAddedIP","ErrorWhileCheckingAddedIP",e);
            System.out.println("Exception while finding IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//Check Embed for Blocked IP
	private static boolean checkEmbedforIP(WebDriver driver, String ip, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));

		 	driver.findElement(By.xpath("//div[text()='"+embed+"']"));
			etest.log(Status.PASS,"Check Embed For BlockIp is checked");
			return true;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckEmbedForIP","ErrorWhileCheckingEmbedForIP",e);
            System.out.println("Exception while checking embed for IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckEmbedForIP","ErrorWhileCheckingEmbedForIP",e);
            System.out.println("Exception while checking embed for IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//Add comment for already added IP
	private static boolean addComment(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			String comment = "Blocked IP Comment added at "+System.currentTimeMillis();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt1 = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));

			((JavascriptExecutor) driver).executeScript("document.getElementById('commenttxt').value = '"+comment+"';");
			((JavascriptExecutor) driver).executeScript("document.getElementById('savcommbtn').click();");

            Thread.sleep(3000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='"+comment+"']")));
			driver.findElement(By.xpath("//div[text()='"+comment+"']"));
            etest.log(Status.PASS,"Add Comment for BlockIp is checked");
			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","AddCommentForIP","ErrorWhileCheckingAddCommentForIP",e);
            System.out.println("Exception while adding comment to IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","AddCommentForIP","ErrorWhileCheckingAddCommentForIP",e);
            System.out.println("Exception while adding comment to IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//Delete Blocked IP
	private static boolean deleteBlockedIP(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					mouseOver(driver, elmts2.get(0));
					elmts2.get(0).click();
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
					driver.findElement(By.id("okbtn")).click();
                    Tab.waitForLoadingSuccessWithBanner(driver,"Deleted successfully","delblockedip.do",etest);
          	break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			elmt = driver.findElement(By.id("listview"));
			elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","DeleteBlockedIP","DeletedIPisListed");

					return false;
				}
			}
			etest.log(Status.PASS,"Delete BlockIp is checked");

			return true;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","DeleteBlockedIP","ErrorWhileDeletingBlockedIP",e);
            System.out.println("Exception while deleting blocked IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","DeleteBlockedIP","ErrorWhileDeletingBlockedIPBlockedIP",e);
            System.out.println("Exception while deleting blocked IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//Unblock IP
	private static boolean unblockIP(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(3).findElements(By.tagName("em"));
					elmts2.get(0).click();
					break;
				}
			}

			return isIPUnblocked(driver, ip,true);
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","UnBlockBlockedIP","ErrorWhileUnBlockingBlockedIP",e);
            System.out.println("Exception while unblocking blocked IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","UnBlockBlockedIP","ErrorWhileUnBlockingBlockedIP",e);
            System.out.println("Exception while unblocking blocked IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//Check IP blocked or unblocked
	private static boolean isIPUnblocked(WebDriver driver, String ip,boolean screenshot)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					String classname = welmt.getAttribute("class");
					if(classname.contains("list_disable"))
					{
						if(!screenshot)
						{
							TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckIPisUNBlockedorNot","IPIsUnBlocked");
						}
						else
						{
							etest.log(Status.PASS,"IP is Unblocked");
	            			return true;
						}
					}
				}
			}
			if(screenshot)
			{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckIPisUNBlockedorNot","IPIsBlocked");
			}
			else
			{
				etest.log(Status.PASS,"IP is Blocked");
			}
            return false;

		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckIPisUNBlockedorNot","Error",e);
            System.out.println("Exception while checking if IP is unblocked in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","CheckIPisUNBlockedorNot","Error",e);
            System.out.println("Exception while checking if IP is unblocked in blockedIP settings page in supervisor login : "+e);
			return false;
		}

	}

	//Block IP
	private static boolean blockIP(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(3).findElements(By.tagName("em"));
					elmts2.get(0).click();
					break;
				}
			}

			return !(isIPUnblocked(driver,ip,false));
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockUnBlockedIP","Error",e);
            System.out.println("Exception while blocking unblocked IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Supervisor","BlockUnBlockedIP","Error",e);
            System.out.println("Exception while blocking unblocked IP in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	public static boolean clearBlockedIPs(WebDriver driver)
	{
		try
		{
			deleteBlockedIP(driver,"155.1.1.1");
			deleteBlockedIP(driver,"155.1.1.2");
			deleteBlockedIP(driver,"155.1.1.3");
			deleteBlockedIP(driver,"155.1.1.4");

			return true;
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while clearing blocked IP settings in blockedIP settings page in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            System.out.println("Exception while clearing blocked IP settings in blockedIP settings page in supervisor login : "+e);
			return false;
		}
	}

	//Mouse over hidden element
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		new Actions(driver).moveToElement(element).perform();
	}
}
