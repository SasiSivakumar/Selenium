//$Id$
package com.zoho.livedesk.client.VisitorRoutingRTTwo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import java.lang.reflect.Method;
import com.google.common.base.Function;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.Status;

public class CheckVisitorInUser {

    public static String lastVisitorPresentIn = "";

    public static class checkVisitorInUser extends Thread 
    {
       public WebDriver driver;
       public String name;
       private String visitorid;
       private boolean presence = false;
       
        checkVisitorInUser(WebDriver d,String n,String id)
        {
           driver = d;
           name = n;
           visitorid = id;
        }
       
        public void run()
        {
           try
           {
                presence = false;

                CommonFunctionsVR.clickVisitorsOnline(driver);

                FluentWait wait = CommonUtilVR.waitreturner(driver,30,250);

                try
                {
        
                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.id("ldwrap")).getAttribute("innerHTML").contains(visitorid))
                            {
                                return true;
                            }
                            return false;
                        }
                    });

                    presence = true;
                }
                catch(Exception e){}

                if(presence)
                {
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(visitorid)));
                }
           }
           catch(Exception e)
           {
                System.out.println("Exception while checking for "+name);
                TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingVisitorInRings","Error",e);
           } 
        }

        public boolean getPresence()
        {
            return presence;
        }
    }

    public static String getUUID(WebDriver driver,String id)
    {
        try
        {
            return (((JavascriptExecutor) driver).executeScript("return UTSHandler.visitors[\""+id+"\"].data[\"uuid\"];")).toString();
        }
        catch(Exception e)
        {
            System.out.println("Exception while getting uuid for id-"+id);
            return "Not found";
        }
    }

    public static String checkVisitorPresenceInUser(WebDriver[] drivers,String visitorid) throws Exception
    {
        String user = "";
        int  length = drivers.length;

        visitorroutingRTTwo.etest.log(Status.INFO,"Checking the presence of visitor with id - "+visitorid);

        if(length >0)
        {
            checkVisitorInUser[] e = new checkVisitorInUser [length];

            for(int i = 0; i < length; i++ )
            {
                e[i] = new checkVisitorInUser(drivers[i],visitorroutingRTTwo.getUserNameFromDriver.get(drivers[i]),visitorid);
                e[i].start();
            }

            boolean toBreak = false;
            int count = 1;
            
            while(!toBreak)
            {
                for(int i = 0; i < length ; i++ )
                {
                    if(!e[i].isAlive() || e[i].getPresence() || count++ >= 70)
                    {
                        toBreak = true;
                        break;
                    }
                }

                Thread.sleep(500);
            }

            Thread.sleep(5000);

            for(int i = 0; i < length; i++ )
            {
                if(e[i].isAlive())
                {
                    System.out.println("Stopping:"+e[i].name+"--"+e[i].getPresence());
                    stopThread(e[i]);
                }
            }

            for(int i = 0; i < length; i++ )
            {
                if(e[i].getPresence())
                {
                    System.out.println("Presence:"+e[i].name+"--"+e[i].getPresence());
                    user = user+visitorroutingRTTwo.getUserNameFromDriver.get(e[i].driver)+"/";
                }
            }
        }

        if(user.equals(""))
        {
            user = "no  rings";
        }
        return user;
    }

    public static void stopThread(checkVisitorInUser e) throws Exception
    {
        Method m = Thread.class.getDeclaredMethod( "stop0" , new Class[]{Object.class} );
        m.setAccessible( true );
        m.invoke( e , new ThreadDeath() );
    }

    
    
    public static boolean checkVisitorInUser(WebDriver drivers[],int count,String users,String notusers,int repeatAt) throws Exception
    {
        boolean sameuser = true;

        if(users.equals(""))
        {
            sameuser = false;
        }
        for(int i = 1 ; i <= count ; i++)
        {
            String visitorid = VisitorSite.getVisitorId();

            String user = checkVisitorPresenceInUser(drivers,visitorid).replace("/","");

            lastVisitorPresentIn = user;

            if(count == 1)
            {
                visitorroutingRTTwo.etest.log(Status.INFO,"Visitor is present in "+ user);
            }
            else
            {
                visitorroutingRTTwo.etest.log(Status.INFO,"Visitor-"+i+" is present in "+ user);
            }
            
            if(CommonFunctionsVR.visitorsInUsers(user))
            {
                visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor is not present in any rings/Visitor is present more than one rings");
                CommonFunctionsVR.takeScreenshot(drivers,"CheckingInRings");
                return false;
            }
            
            if(notusers.contains(user))
            {
                visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor should not present in "+notusers);
                CommonFunctionsVR.takeScreenshot(drivers,"CheckingInRings");
                return false;
            }

            if(sameuser)
            {
                if(!users.contains(user))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor is not present in "+user);
                    CommonFunctionsVR.takeScreenshot(drivers,"CheckingInRings");
                    return false;
                }
            }
            else if(repeatAt > i)
            {
                if(users.contains(user))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor should not present in "+user);
                    CommonFunctionsVR.takeScreenshot(drivers,"CheckingInRings");
                    return false;
                }

                users += user+"/";
            }
        }

        return true;
    }

    public static boolean checkVisitorInUserWithExistingVisitor(WebDriver drivers[],int count,String users,String notusers,int repeatAt,WebDriver visDrivers[]) throws Exception
    {
        boolean sameuser = true;

        if(users.equals(""))
        {
            sameuser = false;
        }
        for(int i = 1 ; i <= count ; i++)
        {
            String visitorid = VisitorSite.getVisitorId(visDrivers[i-1]);

            String user = checkVisitorPresenceInUser(drivers,visitorid).replace("/","");

            lastVisitorPresentIn = user;

            if(count == 1)
            {
                visitorroutingRTTwo.etest.log(Status.INFO,"Visitor is present in "+ user);
            }
            else
            {
                visitorroutingRTTwo.etest.log(Status.INFO,"Visitor-"+i+" is present in "+ user);
            }

            if(notusers.contains(user))
            {
                visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor should not present in "+notusers);
                CommonFunctionsVR.takeScreenshot(drivers,"CheckingInRings");
                return false;
            }

            if(sameuser)
            {
                if(!users.contains(user))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor is not present in "+user);
                    TakeScreenshot.screenshot(visitorroutingRTTwo.getDriverFromUserName.get(user),visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingInRings","Error");
                    return false;
                }
            }
            else if(repeatAt != i)
            {
                if(users.contains(user))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor should not present in "+user);
                    TakeScreenshot.screenshot(visitorroutingRTTwo.getDriverFromUserName.get(user),visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingInRings","Error");
                    return false;
                }

                users += user+"/";
            }

            if(CommonFunctionsVR.visitorsInUsers(user))
            {
                visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor is not present in any rings/Visitor is present more than one rings");
                CommonFunctionsVR.takeScreenshot(drivers,"CheckingInRings");
                return false;
            }
        }

        return true;
    }

    public static boolean checkVisitorInSelectedUser(WebDriver drivers[],String users,String notusers) throws Exception
    {
        String visitorid = VisitorSite.getVisitorId();

        String user = checkVisitorPresenceInUser(drivers,visitorid).replace("/","");

        visitorroutingRTTwo.etest.log(Status.INFO,"Visitor is present in "+ user);

        if(notusers != null)
        {
            String notuserList[] = notusers.split("/");

            for(String s : notuserList)
            {
                if(user.contains(s))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor should not present in "+s);
                    TakeScreenshot.screenshot(visitorroutingRTTwo.getDriverFromUserName.get(s),visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingInRings","Error");
                    return false;
                }
            }
        }

        if(users != null)
        {
            String userList[] = users.split("/");
            
            for(String s : userList)
            {
                if(!user.contains(s))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor is not present in "+s);
                    TakeScreenshot.screenshot(visitorroutingRTTwo.getDriverFromUserName.get(s),visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingInRings","Error");
                    return false;
                }
            }
        }

        return true;
    }

    public static boolean checkVisitorInSelectedUserWithExistingVisitor(WebDriver drivers[],String users,String notusers,WebDriver visDriver) throws Exception
    {
        String visitorid = VisitorSite.getVisitorId(visDriver);

        String user = checkVisitorPresenceInUser(drivers,visitorid).replace("/","");

        visitorroutingRTTwo.etest.log(Status.INFO,"Visitor is present in "+ user);

        if(notusers != null)
        {
            String notuserList[] = notusers.split("/");

            for(String s : notuserList)
            {
                if(user.contains(s))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor should not present in "+s);
                    TakeScreenshot.screenshot(visitorroutingRTTwo.getDriverFromUserName.get(s),visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingInRings","Error");
                    return false;
                }
            }
        }

        if(users != null)
        {
            String userList[] = users.split("/");
            
            for(String s : userList)
            {
                if(!user.contains(s))
                {
                    visitorroutingRTTwo.etest.log(Status.FAIL,"Visitor is not present in "+s);
                    TakeScreenshot.screenshot(visitorroutingRTTwo.getDriverFromUserName.get(s),visitorroutingRTTwo.etest,"VisitorRoutingRT","CheckingInRings","Error");
                    return false;
                }
            }
        }

        return true;
    }
}