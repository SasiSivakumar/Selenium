//$Id$
package com.zoho.livedesk.client.VisitorRoutingRTTwo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.client.TakeScreenshot;

import com.google.common.base.Function;

public class CommonUtilVR {

		
	private static int trycnt = 0;

	public static FluentWait waitreturner(WebDriver driver,int timeOut,int polling)
	{
		FluentWait wait = new FluentWait(driver);
		wait.withTimeout(timeOut,TimeUnit.SECONDS);
		wait.pollingEvery(polling, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);

		return wait;
	}

	public static WebElement elfinder(WebDriver driver,String by,String finder) throws Exception
	{
		WebElement elmt = null;
		FluentWait wtr = waitreturner(driver, 30, 200);

		try
		{
			switch(by)
			{
			case "id":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.id(finder)));
				elmt = driver.findElement(By.id(finder));
				break;
			case "name":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.name(finder)));
				elmt = driver.findElement(By.name(finder));
				break;
			case "partiallinktext":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(finder)));
				elmt = driver.findElement(By.partialLinkText(finder));
				break;
			case "linktext":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.linkText(finder)));
				elmt = driver.findElement(By.linkText(finder));
				break;
			case "tagname":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.tagName(finder)));
				elmt = driver.findElement(By.tagName(finder));
				break;
			case "classname":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.className(finder)));
				elmt = driver.findElement(By.className(finder));
				break;
			case "css":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(finder)));
				elmt = driver.findElement(By.cssSelector(finder));
				break;
			case "xpath":
				//Thread.sleep(1000);
				wtr.until(ExpectedConditions.presenceOfElementLocated(By.xpath(finder)));
				elmt = driver.findElement(By.xpath(finder));
				break;
			default:
				//Thread.sleep(1000);
				System.out.println("Invalid Finder");
				break;
			}
		}
		catch(StaleElementReferenceException e)
		{
			if(trycnt>3)
			{
				trycnt = 0;
				throw e;
			}
			else
			{
				trycnt++;
				Thread.sleep(2000);
				elfinder(driver, by, finder);
			}
		}
		return elmt;
	}
	
	public static WebElement elementfinder(WebDriver driver,final WebElement elmtr,String by,final String finder) throws Exception
	{
		WebElement elmt = null;
		FluentWait wtr = waitreturner(driver, 30, 200);

		try
		{
			switch(by)
			{
			case "id":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.id(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.id(finder));
				break;
			case "name":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.name(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.name(finder));
				break;
			case "partiallinktext":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.partialLinkText(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.partialLinkText(finder));
				break;
			case "linktext":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.linkText(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.linkText(finder));
				break;
			case "tagname":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.tagName(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.tagName(finder));
				break;
			case "classname":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.className(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.className(finder));
				break;
			case "css":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.cssSelector(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.cssSelector(finder));
				break;
			case "xpath":
				//Thread.sleep(1000);
				wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(elmtr.findElement(By.xpath(finder))!=null)
						{
							return true;
						}
						return false;
					}
				});
				elmt = elmtr.findElement(By.xpath(finder));
				break;
			default:
				//Thread.sleep(1000);
				System.out.println("Invalid Finder");
				break;
			}
		}
		catch(StaleElementReferenceException e)
		{
			if(trycnt>3)
			{
				trycnt = 0;
				throw e;
			}
			else
			{
				trycnt++;
				Thread.sleep(2000);
				elfinder(driver, by, finder);
			}
		}
		return elmt;
	}
	
	public static void mouseHover(WebDriver driver,WebElement element)
	{
		new Actions(driver).moveToElement(element).build().perform();
	}
	public static void inViewPort(WebElement e)
	{
		Coordinates ord = ((Locatable)e).getCoordinates();
		ord.inViewPort();
	}
}
