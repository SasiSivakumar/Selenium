//$Id$
package com.zoho.livedesk.client.VisitorRoutingRTTwo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Cookie;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.Routing;

import org.openqa.selenium.StaleElementReferenceException;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.List;
import java.util.Set;
import java.lang.reflect.Method;
import com.google.common.base.Function;

import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class CommonFunctionsVR 
{
    public static void waitTillVisitorLeaves(WebDriver driver) throws Exception
    {
        VisitorsOnline.waitTillVisitorLeaves(driver);
    }

    public static boolean waitTillVisitorLeaves(WebDriver driver, String id) throws Exception
    {
        try
        {
            VisitorsOnline.waitTillVisitorLeaves(driver,id);
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT","WaitTillVisitorLeaves","Error",e);
            return false;
        }
    }

    public static boolean waitTillVisitorLeaves(WebDriver drivers[]) throws Exception
    {
        WebDriver driver = null;
            
        try
        {
            for(WebDriver d : drivers)
            {
                driver = d;
                waitTillVisitorLeaves(d);
            }

            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT","WaitTillVisitorLeaves","Error",e);
            return false;
        }
    }
    
    public static String getVisitorIdFromVisDriver(WebDriver driver) throws Exception
    {
        String portalname = visitorroutingRTTwo.portal;
        
        return VisitorWindow.getVisitorId(driver,portalname);
    }
    
    public static String getVisitorIdFromVisDriverAndNav(WebDriver driver) throws Exception
    {
        String portalname = visitorroutingRTTwo.portal;

        String id = VisitorWindow.getVisitorId(driver,portalname);
        
        try
        {
            driver.get("https://www.zoho.com/");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT","InitiateChat","Error",e);
        }
        
        return id;
    }

    public static void clearVisitorDrivers(Set<WebDriver> visitors)
    {
        for(WebDriver driver : visitors)
        {
            if(driver!=null)
            {
                driver.quit();
            }
        }
    }

    public static void clearVisitorDrivers(WebDriver driver) throws Exception
    {
        clearVisitorDrivers(visitorroutingRTTwo.visitors);
        deleteVisitorRouting(driver);
    }
    
    public static void clickSettings(WebDriver driver) throws Exception
	{
        clickVisitorsOnline(driver);
		FluentWait wait = CommonUtilVR.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
		WebElement settings = CommonUtilVR.elfinder(driver,"id","menu_setting");
		settings.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
	}
	
	public static void clickVisitorsOnline(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilVR.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilVR.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_monitor")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visitor_monitor")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
    }
    
    public static void navToAutomationTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);
        clickAutomation(driver);
	}

    public static void clickAutomation(WebDriver driver) throws Exception 
    {
        FluentWait wait = CommonUtilVR.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
        WebElement e = CommonUtilVR.elfinder(driver,"id","setting_sm_automation");
        e.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationtabs")));
    
    }

	public static void navToVisitorRoutingTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
        clickVisitorRouting(driver);
	}

    public static void clickVisitorRouting(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilVR.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoroutingrulestab")));
        WebElement e = CommonUtilVR.elfinder(driver,"classname","autoroutingrulestab");
        e.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }  

    public static WebDriver setUp() throws Exception
    {
        return Functions.setUp();
    }

    public static void acceptChat(WebDriver driver) throws Exception
    {
        ChatWindow.acceptChat(driver,visitorroutingRTTwo.etest);
    }

    public static void addVisitorRouting(WebDriver driver,ExtentTest etest,String userList,String cond,String cond1,String qual,String val1,String val2,String act)throws Exception
    {
        if(userList == null || userList.equals(""))
        {
            userList = "No users";
        }
        
        Tab.navToVRTab(driver);
        
        Routing.clickAdd(driver,etest);
        
        String id = Routing.getRuleId(driver,0);
        
        etest.log(Status.INFO,"Id - "+id);
        
        Boolean allTrue[] = {true,true,true,true,true,true,true};
        
        fillFields(driver, etest, id, cond, cond1, qual, val1, val2, act, userList, allTrue);
        
        Boolean res = true;
        
        Boolean failed[] = checkValues(driver,etest,Status.INFO,id,cond,cond1,qual, val1, val2, act, userList);
        
        for(Boolean f : failed)
        {
            if(f)
            {
                res = false;
                break;
            }
        }
        
        if(res)
        {
            etest.log(Status.INFO,"Rule is added");
        }
        else
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckRule","Error",0);
            
            etest.log(Status.INFO,"<pre>Second attempt ... </pre>");
            
            fillFields(driver, etest, id, cond, cond1, qual, val1, val2, act, userList, failed);
            
            res = true;
            
            Boolean failed2[] = checkValues(driver,etest,Status.FAIL,id,cond,cond1,qual, val1, val2, act, userList);
            
            for(Boolean f : failed2)
            {
                if(f)
                {
                    res = false;
                    break;
                }
            }
            
            if(res)
            {
                etest.log(Status.INFO,"Rule is added after second attempt");
                visitorroutingRTTwo.secondAttempt++;
                visitorroutingRTTwo.secondAttemptIds += id+";";
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckRule","Error2");
                String s = null;
                s.replace("","to break the flow");
            }
        }
        
//        int useCaseCovered = visitorroutingRTTwo.result.size();
//        
//        if(useCaseCovered <= 15)
//        {
//            Thread.sleep(65000);
//            etest.log(Status.INFO,"Waited for 65 secs");
//        }
//        else
//        {
            Thread.sleep(15000);
            etest.log(Status.INFO,"Waited for 15 secs");
//        }
    }
    
    public static void fillFields(WebDriver driver, ExtentTest etest, String id, String cond,String cond1,String qual,String val1,String val2,String act,String userList,Boolean[] failed) throws Exception
    {
        Rules.openRuleEditView(driver,id);
        Trigger.setRuleName(driver,id,CommonUtil.getUniqueMessage());
        if(failed[0] || failed[1])
        {
            if(cond1.equals("No Value"))
            {
                Routing.selectCriteria(driver,id,cond,etest);Rules.clickHeader(driver,id);
            }
            else
            {
                Routing.selectCriteria(driver,id,cond,cond1,etest);Rules.clickHeader(driver,id);
            }
            Thread.sleep(1500);
        }
        
        if(failed[2])
        {
            Routing.selectCondition(driver,id,qual,etest);Rules.clickHeader(driver,id);
            Thread.sleep(1500);
        }
        
        if(failed[3] || failed[4])
        {
            if(val2.equals("No Value"))
            {
                Routing.selectValues(driver,id,val1,etest);Rules.clickHeader(driver,id);
            }
            else
            {
                Routing.selectValues(driver,id,val1,val2,etest);Rules.clickHeader(driver,id);
            }
            Thread.sleep(1500);
        }
        
        if(failed[5] || failed[6])
        {
            Routing.selectAction(driver,id,act,userList,etest);Rules.clickHeader(driver,id);
            Thread.sleep(1500);
        }
        
        TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckRule","BeforeClickingSettings",0);
        
        Thread.sleep(10000);
        
        etest.log(Status.INFO,"Waited for 10 secs ...");
        Rules.saveRule(driver,etest,id);
        
        Tab.clickIntelligentTrigger(driver);
        Tab.clickVisitorRouting(driver);
    }
    
    public static Boolean[] checkValues(WebDriver driver, ExtentTest etest, Status log,String id, String cond,String cond1,String qual,String val1,String val2,String act,String userList) throws Exception
    {
        Rules.openRuleEditView(driver,id);
        if(userList.contains("CRM Lead") && !userList.contains("CRM Lead/Contact Owner"))
        {
            userList = userList.replace("CRM Lead","CRM Lead/Contact Owner");
        }
        
        String expected[] = {cond,cond1,qual,val1,val2,act,userList};
        
        String actualCriteria = Routing.getCriteria(driver,id);
        String actualConditon = Routing.getCondition(driver,id);
        String actualValue = Routing.getValue1(driver,id);
        String actualAction = Routing.getAction(driver,id);
        String actualUser = Routing.getUsers(driver,id);
        
        if(actualUser == null)
        {
            actualUser = "No users";
        }
        
        String actualSubCriteria = "No Value";
        String actualValue2 = "No Value";
        
        if(!cond1.equals("No Value"))
        {
            actualSubCriteria = Routing.getSubCriteria(driver,id);
        }
        if(!val2.equals("No Value"))
        {
            actualValue2 = Routing.getValue2(driver,id);
        }
        
        String actual[] = {actualCriteria,actualSubCriteria,actualConditon,actualValue,actualValue2,actualAction,actualUser};
        Boolean failed[] = {false,false,false,false,false,false,false};
        
        for(int i = 0 ; i<expected.length; i++)
        {
            if(expected[i].equals("No Value"))
            {
                continue;
            }
            
            if(!actual[i].equals(expected[i]))
            {
                etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                failed[i] = true;
            }
            else
            {
                etest.log(Status.INFO,expected[i]+" is present");
            }
        }

        Rules.saveRule(driver,etest,id);

        return failed;
    }

    public static boolean visitorsInUsers(String present)
    {
        String userList = "Admin1/Supervisor1/Associate1/";

        present = present.replace("/","");

        String users[] = userList.split("/");

        for(int i = 0;i <= users.length-2;i++)
        {
            for(int j = i+1;j<=users.length-1;j++)
            {
                if(!(users[i].contains(present) && users[j].contains(present)) && (users[i].contains(present) || users[j].contains(present)))
                {
                    return false;
                }
            }
        }
        
        return true;
    }

    public static void deleteVisitorRouting(final WebDriver driver) throws Exception
    {
        // FluentWait wait = CommonUtilVR.waitreturner(driver,30,250);
        
        // navToVisitorRoutingTab(driver);
        
        // int count = 1;
        
        // while(ruleExistVR(driver) && count == 1)
        // {
        //     final int initialcount = driver.findElement(By.id("trouting")).findElements(By.className("trules")).size();
            
        //     Thread.sleep(1000);
            
        //     WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("trules"));
            
        //     CommonUtilVR.mouseHover(driver,elmtch);
            
        //     elmtch.findElement(By.className("routeto")).findElement(By.className("sqico-delico")).click();
            
        //     wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
        //     driver.findElement(By.id("okbtn")).click();
            
        //     if(initialcount == 1)
        //     {
        //         for(int i = 1;i <= 40;i++)
        //         {
        //             if(!ruleExistVR(driver))
        //             {
        //                 visitorroutingRTTwo.etest.log(Status.INFO,"All visitor routing rule is deleted");
        //                 return;
        //             }
        //             Thread.sleep(500);
        //         }
                
        //         count = 0;
        //     }
        //     else
        //     {
        //         wait.until(new Function<WebDriver,Boolean>(){
        //             public Boolean apply(WebDriver driver)
        //             {
        //                 if(initialcount-1 == driver.findElement(By.id("trouting")).findElements(By.className("trules")).size())
        //                 {
        //                     return true;
        //                 }
        //                 return false;
        //             }
        //         });
        //     }
        // }
        
        // if(count != 1)
        // {
        //     visitorroutingRTTwo.etest.log(Status.FAIL,"Rule not deleted");
            
        //     String s = null;
        //     s.replace("","to break the flow");
        // }
        com.zoho.livedesk.util.Cleanup.deleteAllVisitorRouting(driver);
        
        visitorroutingRTTwo.etest.log(Status.INFO,"All visitor routing rule is deleted");
    }
    
    public static boolean ruleExistVR(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtilVR.waitreturner(driver,3,250);

            try
            {
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(driver.findElement(By.id("trouting")).getAttribute("innerHTML").contains("data_row"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                return true;
            }
            catch(Exception e){}

            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if data is cleared in VR : "+e);
        }
        return false;
    }

    public static void takeScreenshot(WebDriver drivers[],String failure) throws Exception
    {
        for(WebDriver driver : drivers)
        {
            TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT",failure,"Error");
        }
    }

    public static void changeStatus(WebDriver driver,String status) throws Exception
    {
        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status);
            // FluentWait wait = CommonUtilVR.waitreturner(driver,30,250);
            
            // Thread.sleep(1000);
            
            // try
            // {
            //     if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("dnenable"))
            //     {
            //         driver.findElement(By.id("dnenable")).findElement(By.className("sqico-close")).click();
            //     }
            // }
            // catch(Exception e)
            // {}
            
            // if(status.equals("available"))
            // {
            //     if(!((CommonUtilVR.elementfinder(driver,CommonUtilVR.elfinder(driver,"id","headerdropdiv"),"id","hdrstatus").getAttribute("class")).equals("userstatus-1")))
            //     {
            //         CommonUtilVR.elementfinder(driver,CommonUtilVR.elfinder(driver,"classname","hdrprt"),"id","hdrdrpdwntop").click();
                    
            //         Thread.sleep(1000);
                    
            //         CommonUtilVR.elementfinder(driver,CommonUtilVR.elementfinder(driver,CommonUtilVR.elementfinder(driver,CommonUtilVR.elfinder(driver,"id","headerdropdiv"),"id","ustatus"),"tagname","a"),"tagname","span").click();
                    
            //         Thread.sleep(1000);
                    
            //         wait.until(new Function<WebDriver,Boolean>(){
            //             public Boolean apply(WebDriver driver)
            //             {
            //                 if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-1"))
            //                 {
            //                     return true;
            //                 }
            //                 return false;
            //             }
            //         });
            //     }
            // }
            // else if(status.equals("busy"))
            // {
            //     if(!((CommonUtilVR.elementfinder(driver,CommonUtilVR.elfinder(driver,"id","headerdropdiv"),"id","hdrstatus").getAttribute("class")).equals("userstatus-3")))
            //     {
            //         CommonUtilVR.elementfinder(driver,CommonUtilVR.elfinder(driver,"classname","hdrprt"),"id","hdrdrpdwntop").click();
                    
            //         Thread.sleep(1000);
                    
            //         CommonUtilVR.elementfinder(driver,CommonUtilVR.elementfinder(driver,CommonUtilVR.elementfinder(driver,CommonUtilVR.elfinder(driver,"id","headerdropdiv"),"id","ustatus"),"tagname","a"),"tagname","span").click();
                    
            //         Thread.sleep(1000);
                    
            //         wait.until(new Function<WebDriver,Boolean>(){
            //             public Boolean apply(WebDriver driver)
            //             {
            //                 if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-3"))
            //                 {
            //                     return true;
            //                 }
            //                 return false;
            //             }
            //         });
            //     }
            // }
            
            visitorroutingRTTwo.etest.log(Status.INFO,"Status of user "+visitorroutingRTTwo.getUserNameFromDriver.get(driver)+" is changed to "+status);
            
            Thread.sleep(1000);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT","ChangeStatusTo"+status,"Error",e);
        }
    }

    public static boolean initiateAndEndChat(WebDriver driver,WebDriver visDriver,boolean checkcrm) throws Exception
    {
        boolean check = true;
        Long t1 = new Long(System.currentTimeMillis());
        String s1 = t1.toString();

        try
        {
            VisitorSite.initiateChatVis(visDriver,"V"+s1,"email@"+s1+".com","321","Q"+s1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visDriver,visitorroutingRTTwo.etest,"VisitorRoutingRT","InitiateChat","Error",e);
            return false;
        }
        CommonFunctionsVR.acceptChat(driver);
        
        if(checkcrm)
        {
            FluentWait wait = CommonUtilVR.waitreturner(driver,30,250);

            try
            {
                wait.until(new Function<WebDriver, Boolean>() {
                   public Boolean apply(WebDriver driver) {
                       try
                       {
                           if((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true"))
                               return true;
                       }
                       catch (Exception e) {}
                       return false;
                   }
                });
            }
            catch(Exception e){}

            if(!((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                visitorroutingRTTwo.etest.log(Status.FAIL,"CRM div is not present");
                TakeScreenshot.screenshot(driver,visitorroutingRTTwo.etest,"VisitorRoutingRT","PushAttendedLeadEnabled","Error");
                check = false;
            }
        }

        ChatWindow.endAndCloseChat(driver);

        try
        {
            VisitorWindow.clickCloseChatWidget(visDriver);
            
            Thread.sleep(4000);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visDriver,visitorroutingRTTwo.etest,"VisitorRoutingRT","InitiateChat","Error",e);
            return false;
        }
        
        if(checkcrm)
        {
            return check;
        }

        return true;
    }
}
