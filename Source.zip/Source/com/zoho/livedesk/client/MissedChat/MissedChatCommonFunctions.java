//$Id$
package com.zoho.livedesk.client.MissedChat;


import com.zoho.livedesk.*;


import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.Augmenter;
import com.zoho.livedesk.server.ResourceManager;
import com.aventstack.extentreports.ExtentTest;



import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

import com.zoho.livedesk.client.AAgentsSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Hashtable;

import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.util.common.CommonUtil;

public class MissedChatCommonFunctions
{
	public static boolean isMessageFromUserRecievedInClientSideResult=false,isMessageFromClientRecievedInUserSideResult=false,isSalesIqInternalMessageRecievedResult=false;

	public static void initiateChatInClientSide(WebDriver driver,String name,String email_id,String message) throws Exception
	{
		VisitorWindow.clickChatButton(driver);
		VisitorWindow.initiateChatVisTheme(driver,name,email_id,null,"ldautomation12",message,MissedChatModule.etest);
	}

	public static void waitForClockToSetToZero_ClientSide(WebDriver driver) throws Exception
	{
		VisitorWindow.waitTillChatisMissedInTheme(driver);						
	}




	public static boolean isMissedChatTabFound(WebDriver driver,String expected_text) throws Exception
	{
		boolean isPlusDisplayed=false;

		if(expected_text.contains("+"))
		{
			expected_text = expected_text.replace("+", "");
			isPlusDisplayed=true;
		}

		int expected_int=Integer.parseInt(expected_text)+1;

		//expected_int=expected_int>100?100:expected_int;

		expected_text=expected_int+"";
		try
		{
			BasicSeleniumFunctions.waitTillElementDisplayed(driver,"//*[@id='suppm_missed']");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		if(isPlusDisplayed==false)
		{
			BasicSeleniumFunctions.waitTillTextFound(driver,"//li[@id='suppm_missed']//span[contains(@class,'grayish')]", expected_text);
		}



		if(CommonUtil.elfinder(driver,"xpath","//li[@id='suppm_missed']//span[contains(@class,'grayish')]").getText().contains(expected_text) || isPlusDisplayed==true || CommonUtil.elfinder(driver,"xpath","//li[@id='suppm_missed']//span[contains(@class,'grayish')]").getText().contains("+"))
		{
			return true;
		}
		else
		{
			MissedChatModule.etest.log(Status.FAIL,"Fail : Expected:"+expected_int+" Found:"+CommonUtil.elfinder(driver,"xpath","//li[@id='suppm_missed']//span[contains(@class,'grayish')]").getText());			
			return false;
		}	
	}

	public static String getMissedChatTabText(WebDriver driver) throws Exception
	{
		try
		{
			if(driver.findElements(By.xpath("//li[@id='suppm_missed']//span[contains(@class,'grayish')]")).size()==0)
			{
				return "0";
			}
		}
		catch(Exception e)
		{
			return "0";
		}

		String headerText="";
		BasicSeleniumFunctions.waitTillElementDisplayed(driver,"//*[@id='suppm_missed']");
		try
		{
			headerText=CommonUtil.elfinder(driver,"xpath","//li[@id='suppm_missed']//span[contains(@class,'grayish')]").getText().toString();
			return headerText;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return "0";
	}

	public static boolean isMissedChatHeaderFound(WebDriver driver) throws Exception
	{
		AAgentsSettings.mouseOver(driver,CommonUtil.elfinder(driver,"id","suppm_missed"));
		CommonUtil.elfinder(driver,"id","suppm_missed").click();

		return BasicSeleniumFunctions.waitTillTextFound(driver,"//div[@id='missed_div']//*[@id='innerheader']","Missed Chats");
	}

	public static WebElement getHistoryListItemByName(WebDriver driver,String name) throws Exception
	{
		//List<WebElement> chat_history_items;

		if(!(BasicSeleniumFunctions.waitTillTextFoundFor5Seconds(driver,"(//div[@id='historylist']//td[contains(@class,'secnd-clm')]//h2[contains(text(),'"+name+"')])[1]",name)))
		{
			return null;
		}

		//chat_history_items=driver.findElement(By.id("historylist")).findElements(By.className("cursr-point"));

		for(int i=0;i<driver.findElements(By.id("historylist")).get(0).findElements(By.className("cursr-point")).size();i++)
		{
			if(driver.findElements(By.id("historylist")).get(0).findElements(By.className("cursr-point")).get(i).findElement(By.className("secnd-clm")).findElement(By.tagName("h2")).getText().contains(name))
			{
				return driver.findElements(By.id("historylist")).get(0).findElements(By.className("cursr-point")).get(i);
			}
		}

		return null;
	}

	public static WebElement getHistoryListItemByName(WebDriver driver,String name,String tab_id) throws Exception
	{
		//List<WebElement> chat_history_items;

		if(!(BasicSeleniumFunctions.waitTillTextFoundFor5Seconds(driver,"(//*[@id='"+tab_id+"']//div[@id='historylist']//td[contains(@class,'secnd-clm')]//h2[contains(text(),'"+name+"')])[1]",name)))
		{
			return null;
		}

		//chat_history_items=driver.findElement(By.id("historylist")).findElements(By.className("cursr-point"));

		for(int i=0;i<driver.findElement(By.id(tab_id)).findElements(By.id("historylist")).get(0).findElements(By.className("cursr-point")).size();i++)
		{
			if(driver.findElement(By.id(tab_id)).findElements(By.id("historylist")).get(0).findElements(By.className("cursr-point")).get(i).findElement(By.className("secnd-clm")).findElement(By.tagName("h2")).getText().contains(name))
			{
				return driver.findElement(By.id(tab_id)).findElements(By.id("historylist")).get(0).findElements(By.className("cursr-point")).get(i);
			}
		}

		return null;
	}	

	

	public static void clickMissedChatsTab(WebDriver driver) throws Exception
	{
		AAgentsSettings.mouseOver(driver,CommonUtil.elfinder(driver,"id","suppm_missed"));
		CommonUtil.elfinder(driver,"id","suppm_missed").click();
	}

	public static boolean isVisitorDetailsAppended(WebDriver driver,Hashtable<String,String> visitor_details) throws Exception
	{
		int passcount=0;
		String UserName1="the agent";
		String visitor_name,visitor_mail,visitor_question;

		visitor_name=CommonUtil.elementfinder(driver,getHistoryListItemByName(driver,visitor_details.get("name")),"classname","secnd-clm").getText();

		if(visitor_name.contains(visitor_details.get("name")))
		{
			MissedChatModule.etest.log(Status.PASS,"The name of the missed visitor was successfully found in missed chats tab after "+UserName1+" missed the chat of "+visitor_details.get("name"));
			passcount++;
		}

		else
		{
			MissedChatModule.etest.log(Status.FAIL,"The name of the missed visitor was NOT found(expected:'"+visitor_details.get("name")+"'  found:'"+visitor_name+"') in missed chats tab after "+UserName1+" missed the chat of "+visitor_name);

		}

		if(visitor_details.get("mail")=="")
		{
			passcount++;
		}


		else
		{
			visitor_mail=CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,getHistoryListItemByName(driver,visitor_details.get("name")),"classname","secnd-clm"),"xpath",".//a[contains(@href,'mailto:')]").getText();

			if(visitor_mail.toLowerCase().contains(visitor_details.get("mail").toLowerCase()))
			{
				MissedChatModule.etest.log(Status.PASS,"The email address of the missed visitor was successfully found in missed chats tab after "+UserName1+" missed the chat of "+visitor_details.get("name"));
				passcount++;
			}

			else
			{
				MissedChatModule.etest.log(Status.FAIL,"The email address of the missed visitor was NOT found(expected:'"+visitor_details.get("mail")+"'  found:'"+visitor_mail+"') in missed chats tab after "+UserName1+" missed the chat of "+visitor_details.get("name"));
			}

		}


		visitor_question=CommonUtil.elementfinder(driver,getHistoryListItemByName(driver,visitor_details.get("name")),"classname","thrd-clm").getText();

		if(visitor_question.contains(visitor_details.get("question")))
		{
			MissedChatModule.etest.log(Status.PASS,"The question asked by the missed visitor was successfully found in missed chats tab after "+UserName1+" missed the chat of "+visitor_details.get("name"));			
			passcount++;
		}

		else
		{
			MissedChatModule.etest.log(Status.FAIL,"The question asked by the missed visitor was NOT found(expected:'"+visitor_details.get("question")+"'  found:'"+visitor_question+"') in missed chats tab after "+UserName1+" missed the chat of "+visitor_details.get("name"));			
		}

		if(passcount==3)
		{
			return true;
		}

		else
		{
			return false;
		}

	}

	public static boolean isAssignDropdownDisplayed(WebDriver driver,int index) throws Exception
	{
		if(driver.findElements(By.className("assigncls")).get(index).isDisplayed())
		{
			return true;
		}
		return false;
	}

	public static void assignMissedOfVisitorChatTo(WebDriver driver,final String visitor_name,String assignedUser) throws Exception
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(getHistoryListItemByName(driver,visitor_name).findElements(By.xpath(".//span[contains(@class,'assigncls')]")).get(0)).click().build().perform();
		//wait till dropdown opens
		FluentWait wait=CommonUtil.waitreturner(driver,10,250);
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
             
                	try
                	{
       
	                    if(getHistoryListItemByName(driver,visitor_name).findElement(By.id("assigndropdown")).isDisplayed())
	                    {
	                        return true;
	                    }

                	}
                	catch(Exception e)
                	{
                	}
                    return false;
                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		Thread.sleep(1000);

		actions.moveToElement(getHistoryListItemByName(driver,visitor_name).findElement(By.id("assigndropdown")).findElement(By.xpath(".//a[contains(text(),'"+assignedUser+"')]"))).click().build().perform();

		Tab.waitForLoading(driver,"missedassign.do",MissedChatModule.etest);
    }
    
	public static void openChatDetailsFromHistory(WebDriver driver,final String visitor_name) throws Exception
	{
		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,getHistoryListItemByName(driver,visitor_name),"classname","secnd-clm"),"tagname","h2"));

		FluentWait wait=CommonUtil.waitreturner(driver,10,250);
		//wait till loaded
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                	try
                	{
	                   if(CommonUtil.elfinder(driver,"id","chatvistitle").isDisplayed() && CommonUtil.elfinder(driver,"id","chatvistitle").getText().contains(visitor_name))
	                    {
	                        return true;
	                    }
	                    return false;	              
                	}
                	catch(Exception exp)
                	{
                		return false;
                	}


                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	//for chat history tab
	public static void openChatDetailsFromHistory(WebDriver driver,final String visitor_name,String tab_id) throws Exception
	{
		

		

		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,getHistoryListItemByName(driver,visitor_name,tab_id),"classname","secnd-clm"),"tagname","h2"));

		FluentWait wait=CommonUtil.waitreturner(driver,10,250);
		//wait till loaded
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {

                	try
                	{
	                    if(CommonUtil.elfinder(driver,"id","chatvistitle").isDisplayed() && CommonUtil.elfinder(driver,"id","chatvistitle").getText().contains(visitor_name))
	                    {
	                        return true;
	                    }
	                    return false;
	 
                	}
                	catch(Exception e)
                	{
                		return false;
                	}
                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}


	

	public static boolean checkOwnerOfVisitor(WebDriver driver,String expectedOwner) throws Exception
	{
		try
		{
			BasicSeleniumFunctions.waitTillElementDisplayed(driver,"//*[@id='leftcontainer']//*[@id='userimage' and contains(@usrname,'"+expectedOwner+"')]");
			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","leftcontainer"),"id","userimage").getAttribute("usrname").contains(expectedOwner))
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


		return false;
	}

	public static void clickNotesIconInChat(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.clickElementById(driver,"notes");
		BasicSeleniumFunctions.FluentWaitTillAtleastOneElementFromIdPresentInHTML(driver,"notesbase");
	}

	public static boolean checkTicketAssignationMessageInNotes(WebDriver driver,String assignedBy,String assignedTo) throws Exception
	{
		//pass You and yourself for self assignation

		String expected_text=assignedBy+" has assigned this ticket to "+assignedTo;
		try
		{
			BasicSeleniumFunctions.FluentWaitTillAtleastOneElementFromClassPresentInHTML(driver,"nots-msg");

			if(assignedBy=="You" && assignedTo=="yourself")
			{
				expected_text="You have assigned the ticket to yourself";
			}

			if(driver.findElements(By.className("nots-msg")).get(0).getText().contains(expected_text))
			{
				return true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static void toggleShowOnlyMyChats(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.FluentWaitTillAtleastOneElementFromIdPresentInHTML(driver,"mismysupport");
		CommonUtil.elfinder(driver,"id","mismysupport").click();
		Thread.sleep(250);
	}

	public static boolean checkChatPresentInHistory(WebDriver driver,String visitor_name) throws Exception
	{
		if(getHistoryListItemByName(driver,visitor_name)!=null)
		{
			return true;
		}
		return false;
	}

	public static boolean checkChatPresentInHistory(WebDriver driver,String visitor_name,String tab_id) throws Exception
	{
		if(getHistoryListItemByName(driver,visitor_name,tab_id)!=null)
		{
			return true;
		}
		return false;
	}


	public static boolean checkChatAssignationStatusInChatHistory(WebDriver driver,String visitor_name,String expectedOwner) throws Exception
	{
		try
		{
			return CommonUtil.elementfinder(driver,getHistoryListItemByName(driver,visitor_name),"classname","assigncls").getText().contains(expectedOwner);
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static boolean checkShowOnlyMyChatsCheckbox(WebDriver driver,boolean isChecked) throws Exception
	{
		try
		{
			String condition_class=isChecked?"sqico-checkbox":"sqico-uncheckbox";
			BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"mismysupport");
			if(CommonUtil.elfinder(driver,"id","mismysupport").getAttribute("class").contains(condition_class))
			{
				return true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		return false;
	}

	public static boolean checkShowOnlyMyChats(WebDriver driver) throws Exception
	{
		String expected_text="";
		for(int i=0;i<driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).size();i++)
		{
			expected_text=driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(i).findElements(By.className("assigncls")).get(0).getText();
			if(expected_text.contains("Me")==false)
			{																																							
				return false;
			}
		}

		return true;
	}

	//with screenshot
	public static boolean checkShowOnlyMyChats(WebDriver driver,int unused_int) throws Exception
	{
		String expected_text="";
		for(int i=0;i<driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).size();i++)
		{
			expected_text=driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(i).findElements(By.className("assigncls")).get(0).getText();
			if(expected_text.contains("Me")==false)
			{
				CommonUtil.inViewPort(driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(i));
				TakeScreenshot.screenshot(driver,MissedChatModule.etest,Util.buildlabel(),"Failure","Show only my chats not working");
				try
				{
					CommonUtil.inViewPort(driver.findElement(By.id("hdrdname")));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
																																							
				return false;
			}
		}

		return true;
	}


	public static boolean checkSendMailButtonPresentInChatDetails(WebDriver driver) throws Exception
	{
		return BasicSeleniumFunctions.isElementTextFoundById(driver,"rplybtn","Send Email");
	}

	public static boolean checkCloseChatButtonPresentInChatDetails(WebDriver driver) throws Exception
	{

		try
		{
			BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"closebtn");
			return BasicSeleniumFunctions.isElementTextFoundById(driver,"closebtn","Close");
		}	
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}	
	}

	public static WebElement getRandomChatAssignedTo(WebDriver driver,String assignedTo)
	{	
		for(int i=0;i<driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).size();i++)
		{
			if(driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(i).findElements(By.className("assigncls")).get(0).getText().toLowerCase().contains(assignedTo.toLowerCase()) &&
			 driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(i).findElement(By.className("secnd-clm")).findElement(By.xpath(".//a[contains(@href,'mailto')]")).isDisplayed())
			{
				return driver.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(i);
			}
		}
		return null;
	}

	public static void openRandomChatAssignedTo(WebDriver driver,String assignedTo) throws Exception
	{
		CommonUtil.inViewPort(getRandomChatAssignedTo(driver,assignedTo));

		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,getRandomChatAssignedTo(driver,assignedTo),"classname","secnd-clm"),"tagname","h2"));

		FluentWait wait=CommonUtil.waitreturner(driver,10,250);
		//wait till loaded
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                	try
                	{
	                    if(CommonUtil.elfinder(driver,"id","chatvistitle").isDisplayed())
	                    {
	                        return true;
	                    }
	                    return false;
                	}
                	catch(Exception exp)
                	{
                		return false;
                	}
                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	public static void clickSendMailToVisitorButton(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elfinder(driver,"id","rplybtn"));
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"sendmailfrm");		
	}

	public static void clickCloseChatOfVisitorButton(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"closebtn");
		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elfinder(driver,"id","closebtn"));
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"popupftr");
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"okbtn");
		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elfinder(driver,"id","okbtn"));

		Tab.waitForLoading(driver,"missedclose.do",MissedChatModule.etest);
    }

	public static void sendMailToVisitor(WebDriver driver,String mail_content,boolean sendAndClose) throws Exception
	{
		String mail_action=(sendAndClose==true)?"Send & Close":"Send";

		BasicSeleniumFunctions.FluentWaitTillAtleastOneElementFromClassPresentInHTML(driver,"ze_area");

		driver.switchTo().defaultContent();	
		driver.switchTo().frame(CommonUtil.elfinder(driver,"classname","ze_area"));

		Actions builder = new Actions(driver);  
		for(int i=0;i<50;i++)
		{
			builder.moveToElement(CommonUtil.elfinder(driver,"classname","ze_body")).sendKeys(Keys.ARROW_UP).build().perform();	
		}
		builder.moveToElement(CommonUtil.elfinder(driver,"classname","ze_body")).sendKeys(mail_content).build().perform();

		driver.switchTo().defaultContent();	

		BasicSeleniumFunctions.clickXpathElement(driver,"//form[@id='sendmailfrm']//div[contains(@class,'zme_btndiv')]//span[contains(@class,'rg-button') and text()='"+mail_action+"']");

		//this function does not wait till the the action is completed
	}

	public static boolean isNotesIconChangedAfterMail(WebDriver driver) throws Exception
	{
		try
		{
			BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"notes");
		}
		catch(Exception e)
		{
			return false;
		}

		//wait till notes icon changes
		FluentWait wait=CommonUtil.waitreturner(driver,10,100);
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                	try
                	{
	                    if(CommonUtil.elfinder(driver,"id","notes").getAttribute("class").toString().contains("note_email"))
	                    {
	                        return true;
	                    }
	                    return false;

                	}
                	catch(Exception exp)
                	{
                		return false;
                	}
                	
                }
            });

		}
		catch(Exception e)
		{

			e.printStackTrace();
		}


		return CommonUtil.elfinder(driver,"id","notes").getAttribute("class").toString().contains("note_email");
	}

	public static boolean isMailReplyEventAddedInNotesTab(WebDriver driver,String userName) throws Exception
	{
		try
		{
			String expected_text="has replied to the visitor via Email";

			BasicSeleniumFunctions.FluentWaitTillAtleastOneElementFromClassPresentInHTML(driver,"nots-msg");

			Thread.sleep(500);

			if(driver.findElements(By.className("nots-msg")).get(0).getText().contains(expected_text) && driver.findElements(By.className("nots-msg")).get(0).getText().contains(userName))
			{
				return true;
			}
		}
		catch(Exception e)
		{
			return false;
		}
		return false;

	}

	public static boolean checkForIconInChatHistory(WebDriver driver,String visitor_name,String icon_class) throws Exception
	{
		try
		{
			return getHistoryListItemByName(driver,visitor_name,"history_div").findElement(By.className("thrd-clm")).findElements(By.className("time-stamp")).get(0).findElements(By.className(icon_class)).size()==1?true:false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	public static boolean checkAssignDropdownDisplayedForSpecificUser(WebDriver driver,String visitor_name,String tab_id) throws Exception
	{
		String expected_text="Yet to Assign";

		if(getHistoryListItemByName(driver,visitor_name,tab_id).findElement(By.className("four-clm")).findElements(By.className("assigncls")).get(0).isDisplayed() && getHistoryListItemByName(driver,visitor_name,tab_id).findElement(By.className("four-clm")).findElements(By.className("assigncls")).get(0).getText().toLowerCase().contains(expected_text.toLowerCase()))
		{
			return true;
		}
		return false;
	}

	public static void selectAChatFromHistory(WebDriver driver,String visitor_name,String tab_id) throws Exception
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(getHistoryListItemByName(driver,visitor_name,tab_id)).build().perform();

		BasicSeleniumFunctions.clickWebElement(driver,getHistoryListItemByName(driver,visitor_name,tab_id).findElement(By.className("fst-clm")).findElement(By.className("mratmn")).findElement(By.xpath(".//*[contains(@class,'sqico-checkbox') or contains(@class,'sqico-uncheckbox')]")));
		CommonUtil.sleep(1000);
	}

	public static void performActionForSelectedChats(WebDriver driver,String visitor_name,String action,String tab_id) throws Exception
	{
		String action_id = (action.contains("select"))?"blcksel":(action.contains("close")?"closemissed":(action.contains("delete")?"delete":"INVALID_SELECTOR_EXCEPTION_WILL_OCCUR"));
		BasicSeleniumFunctions.waitTillWebElementDisplayed(driver,driver.findElement(By.id(tab_id)).findElement(By.id("fcontainer")).findElement(By.id("blukoption")).findElement(By.id(action_id)));

		Thread.sleep(1000);
		BasicSeleniumFunctions.clickWebElement(driver,driver.findElement(By.id(tab_id)).findElement(By.id("fcontainer")).findElement(By.id("blukoption")).findElement(By.id(action_id)));
	}

	public static void clickOKInPopUpConfirmation(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"popupftr");
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"okbtn");
		BasicSeleniumFunctions.clickWebElement(driver,CommonUtil.elfinder(driver,"id","okbtn"));
	}

	public static void endChatFromAgentSide(WebDriver driver) throws Exception
	{
		ChatWindow.endChat(driver);
	}

	public static void restartChatAfterEndingSession(WebDriver driver,ExtentTest etest) throws Exception
	{
        VisitorWindow.enterFeedbackInTheme(driver,null,null);
        
        VisitorWindow.continueChat(driver);

        VisitorWindow.switchToChatWidget(driver);
        CommonWait.waitTillDisplayed(driver,By.id("msgarea"));
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).click();
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).clear();
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.question")).sendKeys("Missed chat");

        TakeScreenshot.screenshot(driver,etest,"VisitorWindow","InitiateChat","Before",0);
        CommonUtil.elfinder(driver,"xpath",ResourceManager.getRealValue("Theme.initiatechat")).click();
        Thread.sleep(500);
        TakeScreenshot.screenshot(driver,etest,"VisitorWindow","InitiateChat","After",0);
        
        VisitorWindow.checkWaitingDiv(driver);
	}

	public static void clickMyNotifications(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"h_offlinemsg");
		BasicSeleniumFunctions.clickWebElement(driver,driver.findElement(By.id("h_offlinemsg")).findElement(By.className("sqico-notify")));
	}

	public static void clickMissedVisitorNotifications(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"offlinemsg");
		BasicSeleniumFunctions.clickWebElement(driver,driver.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp")).findElement(By.xpath(".//div[contains(@class,'unread-infomsg')]//a[contains(@href,'me')]")));
	}

	public static void clickUnassignedVisitorNotifications(WebDriver driver) throws Exception
	{
		BasicSeleniumFunctions.FluentWaitTillElementByIdIsDisplayed(driver,"offlinemsg");
		BasicSeleniumFunctions.clickWebElement(driver,driver.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp")).findElement(By.xpath(".//div[contains(@class,'unread-infomsg')]//a[contains(@href,'unassigned')]")));
	}

















}
