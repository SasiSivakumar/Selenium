//$Id$
package com.zoho.livedesk.client.MissedChat;

import com.zoho.livedesk.*;


import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.Augmenter;



import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;

import com.zoho.livedesk.util.common.CommonUtil;


public class BasicSeleniumFunctions
{
	
	public static void FluentWaitTillAtleastOneElementFromClassPresentInHTML(WebDriver driver,final String class_name) throws Exception
	{
		FluentWait globalWait = new FluentWait(driver);
		globalWait.withTimeout(5,TimeUnit.SECONDS);
		globalWait.pollingEvery(250, TimeUnit.MILLISECONDS);
		globalWait.ignoring(NoSuchElementException.class);
		globalWait.ignoring(StaleElementReferenceException.class);


		// try
		// {
			globalWait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElements(By.className(class_name)).size()>0)
                    {
                        return true;
                    }
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}

	public static void FluentWaitTillAtleastOneElementFromIdPresentInHTML(WebDriver driver,final String id) throws Exception
	{
		FluentWait globalWait = new FluentWait(driver);
		globalWait.withTimeout(5,TimeUnit.SECONDS);
		globalWait.pollingEvery(250, TimeUnit.MILLISECONDS);
		globalWait.ignoring(NoSuchElementException.class);
		globalWait.ignoring(StaleElementReferenceException.class);

		// try
		// {
			globalWait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElements(By.id(id)).size()>0)
                    {
                        return true;
                    }
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}

	public static void FluentWaitTillXPathPresentInHTML(WebDriver driver, final String xpathExpression) throws Exception
	{
		FluentWait globalWait = new FluentWait(driver);
		globalWait.withTimeout(5,TimeUnit.SECONDS);
		globalWait.pollingEvery(250, TimeUnit.MILLISECONDS);
		globalWait.ignoring(NoSuchElementException.class);
		globalWait.ignoring(StaleElementReferenceException.class);

		// try
		// {
			globalWait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElements(By.xpath(xpathExpression)).size()>0)
                    {
                        return true;
                    }
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}

	public static void FluentWaitTillXpathAttributeContainsValueInHTML(WebDriver driver,final String xpathExpression,final String attributeString,final String containsString) throws Exception
	{
		FluentWait globalWait = new FluentWait(driver);
		globalWait.withTimeout(5,TimeUnit.SECONDS);
		globalWait.pollingEvery(250, TimeUnit.MILLISECONDS);
		globalWait.ignoring(NoSuchElementException.class);
		globalWait.ignoring(StaleElementReferenceException.class);
		globalWait.ignoring(Exception.class);

		// try
		// {
			globalWait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath(xpathExpression)).getAttribute(attributeString).contains(containsString))
                    {
                        return true;
                    }
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}

	public static void FluentWaitTillElementByIdIsDisplayed(WebDriver driver,final String id) throws Exception
	{
		//WARNING:When this function is used in zoho salesiq,It may fail as there are multiple elements present with the same id.
		
		FluentWait globalWait = new FluentWait(driver);
		globalWait.withTimeout(5,TimeUnit.SECONDS);
		globalWait.pollingEvery(250, TimeUnit.MILLISECONDS);
		globalWait.ignoring(NoSuchElementException.class);
		globalWait.ignoring(StaleElementReferenceException.class);

		// try
		// {
			globalWait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id(id)).isDisplayed())
                    {
                        return true;
                    }
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}	



	public static void clickXpathElement(WebDriver driver,String xpathExpression) throws Exception
 	{
 		try
 		{
	 		Actions actions = new Actions(driver);
			FluentWait wait=CommonUtil.waitreturner(driver,5,250);
		    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathExpression)));
		    Thread.sleep(1000);
			actions.moveToElement(driver.findElement(By.xpath(xpathExpression)));
		    actions.moveToElement(driver.findElement(By.xpath(xpathExpression))).click().build().perform();
 		}
 		catch(Exception e)
 		{
 			e.printStackTrace();
 		}
	}

	public static void clickElementById(WebDriver driver,String id)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);
 	    wait.until(ExpectedConditions.elementToBeClickable(By.id(id)));

		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.id(id))).click().build().perform();
	}

	public static void clickWebElement(WebDriver driver,WebElement element)
	{
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		// wait.until(ExpectedConditions.elementToBeClickable(element));		
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().build().perform();
	}


	public static void sendKeysById(WebDriver driver,String id,String message)
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.id(id))).click().build().perform();
		actions.moveToElement(driver.findElement(By.id(id))).sendKeys(message).build().perform();
	}

	public static void waitTillElementDisplayed(WebDriver driver,final String finder) throws Exception
	{

		FluentWait wait=CommonUtil.waitreturner(driver,7,250);

		// try
		// {
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
               
                	try
                	{
      
	                    if(driver.findElement(By.xpath(finder)).isDisplayed())
	                    {
	                        return true;
	                    }

                	}
                	catch(Exception e)
                	{
                	}
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}

	public static void waitTillWebElementDisplayed(WebDriver driver,final WebElement ele,final boolean isDisplayed) throws Exception
	{

		FluentWait wait=CommonUtil.waitreturner(driver,10,250);

		// try
		// {
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(ele.isDisplayed()==isDisplayed)
                    {
                        return true;
                    }
                    return false;
                }
            });

		// }
		// catch(Exception e)
		// {
		// 	e.printStackTrace();
		// }

	}

	public static void waitTillWebElementDisplayed(WebDriver driver,WebElement ele) throws Exception
	{
		waitTillWebElementDisplayed(driver,ele,true);
	}	



	public static boolean isElementTextFoundById(WebDriver driver,final String id,final String expected_text)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);

		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id(id)).isDisplayed() && driver.findElement(By.id(id)).getText().toLowerCase().contains(expected_text.toLowerCase()))
                    {
                        return true;
                    }
                    return false;
                }
            });

            if(driver.findElement(By.id(id)).isDisplayed() && driver.findElement(By.id(id)).getText().toLowerCase().contains(expected_text.toLowerCase()))
            {
            	return true;
            }
            return false;

		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}


	public static boolean waitTillTextFound(WebDriver driver,final String finder,final String expected_text) throws Exception
	{
		waitTillElementDisplayed(driver,finder);

		FluentWait wait=CommonUtil.waitreturner(driver,10,250);

		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                	WebElement ele=null;
                	try
                	{
                		ele = driver.findElement(By.xpath(finder));
                	}
                	catch(Exception e)
                	{
                	}

                    if(ele.getText().toLowerCase().contains(expected_text.toLowerCase()))
                    {
                        return true;
                    }
                    return false;
                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		return true;

	}

	public static boolean waitTillTextFoundFor5Seconds(WebDriver driver,final String finder,final String expected_text) throws Exception
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);

		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                	try
                	{
                		
		                    if(driver.findElement(By.xpath(finder)).getText().toLowerCase().contains(expected_text.toLowerCase()))
		                    {
		                        return true;
		                    }
		                    return false;

                	}
                	catch(Exception e)
                	{
                		return false;
                	}

                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		return true;

	}


}



		
