//$Id$
package com.zoho.livedesk.client.MissedChat;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.VisitorWindow;



public class BrowserConfiguration 
{
	
	public static void CloseBrowser(WebDriver driver)
	{
		driver.quit();
	}

	public static void refreshPage(WebDriver driver)
	{	
		driver.navigate().refresh();
	}

	public static void navigateToSalesIq(WebDriver driver)
	{
		driver.get("https://www.zoho.com/salesiq/login.html"); //get url and open in the session	
	}

	public static void navigateToClientSite(WebDriver driver) throws Exception
	{
		VisitorWindow.createPage(driver,MissedChatModule.WIDGET_CODE);
	}
}


		
