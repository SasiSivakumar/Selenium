//$Id$
package com.zoho.livedesk.client.MissedChat;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;


	
	
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Websites;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import com.zoho.livedesk.util.common.CommonSikuli;


import com.zoho.livedesk.util.common.CommonUtil;

public class MissedChatModule{

	public static Hashtable finalResult = new Hashtable();

	static WebDriver driver1,driver3;	
	public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
	public static ExtentTest etest; 
	static public ExtentReports extent;


	public static String organisation_name=ConfManager.getRealValue("missedchatagent1_portal");
	public static String embed_name="missed";


	public static String WIDGET_CODE=null;
    
    public static Hashtable test(WebDriver driver1) throws Exception
	{
		try
		{
			try
			{
				etest=ComplexReportFactory.getTest("Portal setup for missed chat module");
				ComplexReportFactory.setValues(etest,"Automation","Missed chat");
				Websites.selectAllowVisitorsToChooseDepartment(driver1,etest,embed_name);
				ComplexReportFactory.closeTest(etest);
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}

			WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver1,embed_name);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC1"));
			ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            
            TestResults.put("MC1", checkMissedChat(driver1));
            
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC2"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            
            TestResults.put("MC2", checkVisitorDetails(driver1));        
            
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC3"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");

            TestResults.put("MC3", checkAssignDropdown(driver1));        

            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC5"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC5", checkAssignMissedChatToSelf(driver1));        
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC6"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
			driver3=Functions.setUp();
			if(!(Functions.login(driver3,"missedchatagent2")))
			{
				TestResults.put("Login",false);
	            finalResult.put("result",TestResults);
	            finalResult.put("servicedown",new Hashtable());
	            return finalResult;
			} 
            TestResults.put("MC6", checkReAssignMissedChat(driver1,driver3));        
            ComplexReportFactory.closeTest(etest);




			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC7"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC7", checkShowOnlyMyChats(driver1));        
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC8"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC8", checkUnassignedChatsNotification(driver1));        
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC9"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC9", checkToggleShowOnlyMyChats(driver1));        
            ComplexReportFactory.closeTest(etest); 

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC10"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC10", checkSendMailAndCloseButton(driver1,"Me"));        
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC4"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC4", checkAssignMissedChatToAgent(driver1));        
            ComplexReportFactory.closeTest(etest);            

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC11"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC11", checkSendMailAndCloseButton(driver1,ConfManager.getRealValue("missedchatagent2_name")));        
            ComplexReportFactory.closeTest(etest);  
     
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC12"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC12", checkSendMailChangesNotes(driver1));        
            ComplexReportFactory.closeTest(etest);  

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC13_1"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC13_1", checkSendMailWithoutMail(driver1));        
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC13_2"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC13_2", checkSendMailAndCloseActionWithMail(driver1));        
            ComplexReportFactory.closeTest(etest);

 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC14"));
            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
            TestResults.put("MC14", checkChatHistoryForClose(driver1));        
            ComplexReportFactory.closeTest(etest);

	 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC15"));
	            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
	            TestResults.put("MC15", checkChatHistoryCloseIcon(driver1));        
	            ComplexReportFactory.closeTest(etest);

	 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC16_1"));
	            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
	            TestResults.put("MC16_1", checkChatHistoryMailSentAndCloseIcon(driver1));        
	            ComplexReportFactory.closeTest(etest);

	 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC16_2"));
	            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
	            TestResults.put("MC16_2", checkChatHistoryMailSentIcon(driver1));        
	            ComplexReportFactory.closeTest(etest);

		 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC17"));
		            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
		            TestResults.put("MC17", checkAssignDropdownChatHistory(driver1));        
		            ComplexReportFactory.closeTest(etest);

		 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC19"));
		            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
		            TestResults.put("MC19", miss1ChatAndDelete(driver1));        
		            ComplexReportFactory.closeTest(etest);

		 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC20"));
		            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
		            TestResults.put("MC20", miss2ChatAndDelete(driver1));        
		            ComplexReportFactory.closeTest(etest);


		 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC21"));
		            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
		            TestResults.put("MC21", miss1ChatAndClose(driver1));        
		            ComplexReportFactory.closeTest(etest);

		 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC22"));
		            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
		            TestResults.put("MC22", miss2ChatAndClose(driver1));        
		            ComplexReportFactory.closeTest(etest);


		 			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MC18"));
		            ComplexReportFactory.setValues(etest,"Automation","Missed chat");
		            TestResults.put("MC18", checkMissedAfterContinueChat(driver1));        
		            ComplexReportFactory.closeTest(etest);
         
           
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			System.out.println("FATAL_ERROR_OCCURRED_DURING_MISSEDCHAT_MODULE");
			e.printStackTrace();
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);

			finalResult.put("result",TestResults);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static boolean checkMissedChat(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";



		int passcount=0;

		try
		{	

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			String missedChatCountBefore="+";
			try
			{
				missedChatCountBefore=MissedChatCommonFunctions.getMissedChatTabText(driver);
			}
			catch(Exception e)
			{
				missedChatCountBefore="+";
			}

            try
            {
                MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);                
            }
            catch(Exception exp)
            {
                TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
                return false;
            }

			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' ),Now checking missed chat tab and header");

			if(MissedChatCommonFunctions.isMissedChatTabFound(driver,missedChatCountBefore))
			{
				etest.log(Status.PASS,"Missed chat tab found after "+UserName1+" missed a chat from a visitor");

				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Missed chat tab was NOT found after "+UserName1+" missed a chat from a visitor");
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Failure","visitor window screenshot");
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");
			}

			if(MissedChatCommonFunctions.isMissedChatHeaderFound(driver))
			{
				etest.log(Status.PASS,"Missed chat header was found with  after "+UserName1+" clicked missed chat tab.");

				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Missed chat header was NOT found with  after "+UserName1+" clicked missed chat tab.");	
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Failure","visitor window screenshot");
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");			
			}


		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkMissedChat","Error in checking missed chats test",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public static boolean checkVisitorDetails(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		int passcount=0;

		try
		{
			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' ),Now checking visitor details in missed chats");

			MissedChatCommonFunctions.clickMissedChatsTab(driver);
			
			Hashtable<String,String> visitor_details = new Hashtable<String,String>();

			visitor_details.put("name",visitor_name);
			visitor_details.put("mail",visitor_mail);
			visitor_details.put("question",visitor_question);

			if(MissedChatCommonFunctions.isVisitorDetailsAppended(driver,visitor_details))
			{
				etest.log(Status.PASS,"The details of the missed visitor was successfully found in missed chats tab after "+UserName1+" missed the chat of "+visitor_name);
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"The details of the missed visitor was NOT found in missed chats tab after "+UserName1+" missed the chat of "+visitor_name);
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Failure","visitor window screenshot");
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkVisitorDetails","Error in checking visitor details in  missed chats tab",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		if(passcount==1)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public static boolean checkAssignDropdown(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		
		int passcount=0;
		int no_of_checks=2;

		try
		{
			Tab.clickMissed(driver);

			for(int i=0;i<no_of_checks;i++)
			{
				if(MissedChatCommonFunctions.isAssignDropdownDisplayed(driver,i))
				{
					passcount++;
				}
			}

			if(passcount==no_of_checks)
			{
				etest.log(Status.PASS,"Assign dropdown was found in Missed chat tab for "+UserName1);
				return true;
			}

			else
			{
				etest.log(Status.FAIL,"Assign dropdown was NOT found in Missed chat tab for "+UserName1);
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");	
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkAssignDropdown","Error in checking visitor details in  missed chats tab",e);
			return false;
		}

		finally
		{
		}

	}

	public static boolean checkAssignMissedChatToAgent(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";				
		int passcount=0;

		try
		{
			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");
			Tab.clickMissed(driver);

			MissedChatCommonFunctions.assignMissedOfVisitorChatTo(driver,visitor_name,ConfManager.getRealValue("missedchatagent2_name"));
			etest.log(Status.INFO,UserName1+" assigned missed chat from visitor(visitor name : '"+visitor_name+"' ) to "+ConfManager.getRealValue("missedchatagent2_name"));

			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name);
			etest.log(Status.INFO,UserName1+" opened details of visitor(visitor name : '"+visitor_name+"' ) from chat history.");

			if(MissedChatCommonFunctions.checkOwnerOfVisitor(driver,ConfManager.getRealValue("missedchatagent2_name")))
			{
				etest.log(Status.PASS,ConfManager.getRealValue("missedchatagent2_name")+" was found as the owner of visitor(visitor name : '"+visitor_name+"' )");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,ConfManager.getRealValue("missedchatagent2_name")+" was NOT found as the owner of visitor(visitor name : '"+visitor_name+"' )");
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");	
			}

			MissedChatCommonFunctions.clickNotesIconInChat(driver);

			if(MissedChatCommonFunctions.checkTicketAssignationMessageInNotes(driver,UserName1,ConfManager.getRealValue("missedchatagent2_name")))
			{
				passcount++;
				etest.log(Status.PASS,"Ticket assignation message was found by "+UserName1+" in the notes tab of visitor(visitor name : '"+visitor_name+"' )");
			}
			else
			{
				etest.log(Status.FAIL,"Ticket assignation message was NOT found by "+UserName1+" in the notes tab of visitor(visitor name : '"+visitor_name+"' )");				
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");		
			}



		

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkAssignMissedChatToAgent","Error in checking assign dropdowm",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public static boolean checkAssignMissedChatToSelf(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";

		
		int passcount=0;

		try
		{
			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");
			Tab.clickMissed(driver);

			MissedChatCommonFunctions.assignMissedOfVisitorChatTo(driver,visitor_name,"Me");
			etest.log(Status.INFO,UserName1+" assigned missed chat from visitor(visitor name : '"+visitor_name+"' ) to himself.");

			MissedChatCommonFunctions.toggleShowOnlyMyChats(driver);
			etest.log(Status.INFO,UserName1+" checked 'Show Only My Chats' checkbox.");			

			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name))
			{
				etest.log(Status.PASS,UserName1+" found chat(chat which is assigned to himself) of visitor(visitor name : '"+visitor_name+"' ) after checking 'Show Only My Chats' checkbox.");			
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" did NOT find chat(chat which is assigned to himself) of visitor(visitor name : '"+visitor_name+"' ) after checking 'Show Only My Chats' checkbox.");			
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");		
			}

			MissedChatCommonFunctions.toggleShowOnlyMyChats(driver);
			etest.log(Status.INFO,UserName1+" unchecked 'Show Only My Chats' checkbox.");						

			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name))
			{
				etest.log(Status.PASS,UserName1+" found chat(chat which is assigned to himself) of visitor(visitor name : '"+visitor_name+"' ) after unchecking 'Show Only My Chats' checkbox.");							 
				passcount++;
			}
			else
			{
				etest.log(Status.PASS,UserName1+" found chat(chat which is assigned to himself) of visitor(visitor name : '"+visitor_name+"' ) after unchecking 'Show Only My Chats' checkbox.");			
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure","Operator window screenshot");		
			}

		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkAssignMissedChatToSelf","Error in checking missed chat owner",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public static boolean checkReAssignMissedChat(WebDriver driver1,WebDriver driver2) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver1);
		String UserName2=ExecuteStatements.getUserName(driver2);

		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";
		
		int passcount=0;

		try
		{
			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Tab.clickMissed(driver1);
			MissedChatCommonFunctions.assignMissedOfVisitorChatTo(driver1,visitor_name,UserName2);
			etest.log(Status.INFO,UserName1+" assigned missed chat from visitor(visitor name : '"+visitor_name+"' ) to "+UserName2);			

			Tab.clickMissed(driver2);			
			MissedChatCommonFunctions.assignMissedOfVisitorChatTo(driver2,visitor_name,UserName1);
			etest.log(Status.INFO,UserName2+" reassigned missed chat from visitor(visitor name : '"+visitor_name+"' ) back to "+UserName1);			

			MissedChatCommonFunctions.toggleShowOnlyMyChats(driver1);
			etest.log(Status.INFO,UserName1+" checked 'Show Only My Chats' checkbox.");									



			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver1,visitor_name))
			{ 
				etest.log(Status.PASS,UserName1+" found chat of visitor(visitor name : '"+visitor_name+"' ) in missed chats tab after checking 'Show Only My Chats' checkbox.");									
				passcount++;

				if(MissedChatCommonFunctions.checkChatAssignationStatusInChatHistory(driver1,visitor_name,"Me"))
				{
					etest.log(Status.PASS,UserName1+" found chat of visitor(visitor name : '"+visitor_name+"' ) assigned to himself.");									
					passcount++;
				}
				else
				{
					etest.log(Status.FAIL,UserName1+"did NOT find chat of visitor(visitor name : '"+visitor_name+"' ) assigned to himself.");														
					TakeScreenshot.screenshot(driver1,etest,"Missed Chats","Failure",UserName1+" window screenshot");
					TakeScreenshot.screenshot(driver2,etest,"Missed Chats","Failure",UserName2+" window screenshot");		
				}

			}
			else
			{
				etest.log(Status.FAIL,UserName1+" did NOT find chat of visitor(visitor name : '"+visitor_name+"' ) in missed chats tab after checking 'Show Only My Chats' checkbox.");									
				TakeScreenshot.screenshot(driver1,etest,"Missed Chats","Failure",UserName1+" window screenshot");
				TakeScreenshot.screenshot(driver2,etest,"Missed Chats","Failure",UserName2+" window screenshot");		
			}
		

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver1,etest,"Missed Chats","checkReAssignMissedChat","Error in checking missed chats owner 1",e);
			TakeScreenshot.screenshot(driver2,etest,"Missed Chats","checkReAssignMissedChat","Error in checking missed chats owner 2",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);			
			Functions.logout(driver2);			
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public static boolean checkShowOnlyMyChats(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);

		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";

		
		int passcount=0;
	


		try
		{	
			Tab.clickMissed(driver);
			// MissedChatCommonFunctions.toggleShowOnlyMyChats(driver);
			// etest.log(Status.INFO,UserName1+" checked 'Show Only My Chats' checkbox.");
	
	// /*

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
			
			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Tab.clickMissed(driver);
			MissedChatCommonFunctions.assignMissedOfVisitorChatTo(driver,visitor_name,"Me");
			etest.log(Status.INFO,UserName1+" assigned missed chat from visitor(visitor name : '"+visitor_name+"' ) to himself.");
	// */			
			Tab.clickChatHistory(driver);



			MissedChatCommonFunctions.clickMyNotifications(driver);
			MissedChatCommonFunctions.clickMissedVisitorNotifications(driver);
			MissedChatCommonFunctions.clickMyNotifications(driver);

			Thread.sleep(2000);

			if(MissedChatCommonFunctions.checkShowOnlyMyChatsCheckbox(driver,true))
			{
				etest.log(Status.PASS,"'Show Only My Chats' checkbox was checked after "+UserName1+" clicked missed chats from notification.");								
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"'Show Only My Chats' checkbox was NOT checked after "+UserName1+" clicked missed chats from notification.");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");													
			}



			if(MissedChatCommonFunctions.checkShowOnlyMyChats(driver,0))
			{
				etest.log(Status.PASS,"Only "+UserName1+" chat's were displayed after he clicked missed chats from notification.");								
				passcount++; 
			}
			else
			{
				etest.log(Status.FAIL,"Only "+UserName1+" chat's were NOT displayed after he clicked missed chats from notification.");	
			}
		
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkShowOnlyMyChats","Error in checking Show Only My Chats",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	
	public static boolean checkUnassignedChatsNotification(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);

		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";

		
		int passcount=0;
	


		try
		{	
			Tab.clickMissed(driver);

			// MissedChatCommonFunctions.toggleShowOnlyMyChats(driver);
			// etest.log(Status.INFO,UserName1+" checked 'Show Only My Chats' checkbox.");

			// /*
	
			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			// */
			
			Tab.clickChatHistory(driver);



			MissedChatCommonFunctions.clickMyNotifications(driver);
			MissedChatCommonFunctions.clickUnassignedVisitorNotifications(driver);
			MissedChatCommonFunctions.clickMyNotifications(driver);

			Thread.sleep(2000);

			if(MissedChatCommonFunctions.checkShowOnlyMyChatsCheckbox(driver,false))
			{
				etest.log(Status.PASS,"'Show Only My Chats' checkbox was NOT checked after "+UserName1+" clicked unassigned chats from notification.");								
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"'Show Only My Chats' checkbox was checked after "+UserName1+" clicked missed chats from notification.");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");													
			}



			if(MissedChatCommonFunctions.checkShowOnlyMyChats(driver)==false) 
			{
				etest.log(Status.PASS,"All chat's were displayed after "+UserName1+" clicked unassigned chats from notification.");								
				passcount++; 
			}
			else
			{
				etest.log(Status.FAIL,"All chat's were NOT displayed after "+UserName1+" clicked unassigned chats from notification.");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");													
			}
		
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkUnassignedChatsNotification","Error in checking unassigned chats in notification",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}


	public static boolean checkToggleShowOnlyMyChats(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);

		int passcount=0;

		try
		{	
			Tab.clickMissed(driver);
			MissedChatCommonFunctions.toggleShowOnlyMyChats(driver);
			etest.log(Status.INFO,UserName1+" checked 'Show Only My Chats' checkbox.");						

			if(MissedChatCommonFunctions.checkShowOnlyMyChats(driver))
			{
				etest.log(Status.PASS,"Only "+UserName1+" chat's were displayed after he checked 'Show Only My Chats' checkbox.");								
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"All chat's were displayed for "+UserName1+" in missed chats tab after unchecked 'Show Only My Chats' checkbox.");												
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																
			}

			MissedChatCommonFunctions.toggleShowOnlyMyChats(driver);
			etest.log(Status.INFO,UserName1+" unchecked 'Show Only My Chats' checkbox.");						

			if(!(MissedChatCommonFunctions.checkShowOnlyMyChats(driver)))
			{
				passcount++;
				etest.log(Status.PASS,"All chat's were displayed for "+UserName1+" in missed chats tab after unchecked 'Show Only My Chats' checkbox.");												
			}
			else
			{
				etest.log(Status.FAIL,"All chat's were NOT displayed for "+UserName1+" in missed chats tab after unchecked 'Show Only My Chats' checkbox.");	
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																
			}


		
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkToggleShowOnlyMyChats","Error in checking Show Only My Chats test",e);
		}
		finally
		{
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	//s

	public static boolean checkSendMailAndCloseButton(WebDriver driver,String assignedTo) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		String assignedMemberName=(assignedTo=="Me")?"himself":assignedTo; // for report
		int passcount=0;

		try
		{
			Tab.clickMissed(driver);
			Thread.sleep(4000);			
			MissedChatCommonFunctions.openRandomChatAssignedTo(driver,assignedTo);
			etest.log(Status.INFO,UserName1+" opened a chat assigned to "+assignedMemberName);

			if(assignedTo=="Me")
			{
				CommonSikuli.findInWholePage(driver,"Sendemail.png","UI298",etest);
				if(MissedChatCommonFunctions.checkSendMailButtonPresentInChatDetails(driver))
				{
					etest.log(Status.PASS,UserName1+" found 'Send Email' button for visitor assigned to "+assignedMemberName);
					passcount++;
				}
				else
				{
					etest.log(Status.FAIL,UserName1+" did NOT find 'Send Email' button for visitor assigned to "+assignedMemberName);				
					TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																
				}
				if(MissedChatCommonFunctions.checkCloseChatButtonPresentInChatDetails(driver))
				{
					etest.log(Status.PASS,UserName1+" found 'Close' button for visitor assigned to "+assignedMemberName);				
					passcount++;
				}
				else
				{
					etest.log(Status.FAIL,UserName1+" did NOT find 'Close' button for visitor assigned to "+assignedMemberName);								
					TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
				}

			}

			else
			{
					CommonSikuli.findInWholePage(driver,"Sendemail.png","UI298",etest);
					if(MissedChatCommonFunctions.checkSendMailButtonPresentInChatDetails(driver))
					{
						etest.log(Status.PASS,UserName1+" found 'Send Email' button for visitor assigned to "+assignedMemberName);
						passcount++;
					}
					else
					{
						etest.log(Status.FAIL,UserName1+" did NOT find 'Send Email' button for visitor assigned to "+assignedMemberName);				
						TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																
					}
					if(MissedChatCommonFunctions.checkCloseChatButtonPresentInChatDetails(driver)==false)
					{
						etest.log(Status.PASS,UserName1+" did not find 'Close' button for visitor assigned to "+assignedMemberName);				
						passcount++;
					}
					else
					{
						etest.log(Status.FAIL,UserName1+" found 'Close' button for visitor assigned to "+assignedMemberName);								
						TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																			
					}

			}


		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkSendMailAndCloseButton","Error in checking send mail and close button chats test",e);
		}
		finally
		{
		}

		return returnResult(passcount,2);
	}


	public static boolean checkSendMailChangesNotes(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		try
		{
			Tab.clickMissed(driver);
			Thread.sleep(4000);			
			MissedChatCommonFunctions.openRandomChatAssignedTo(driver,"Me");
			etest.log(Status.INFO,UserName1+" opened details of visitor assigned to himself");			
			MissedChatCommonFunctions.clickSendMailToVisitorButton(driver);
			MissedChatCommonFunctions.sendMailToVisitor(driver,"Hello,We will get back to you shortly.",false);
			etest.log(Status.INFO,UserName1+" sent a mail to visitor");
	
			Thread.sleep(2000);						

			if(MissedChatCommonFunctions.checkCloseChatButtonPresentInChatDetails(driver))
			{
				etest.log(Status.PASS,"Close button was found for "+UserName1+" after he sent a mail to his visitor.");							
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Close button was NOT found for "+UserName1+" after he sent a mail to his visitor.");											
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			CommonUtil.refreshPage(driver);

			if(MissedChatCommonFunctions.isNotesIconChangedAfterMail(driver))
			{
				etest.log(Status.PASS,"Notes icon was changed for "+UserName1+" after he sent a mail to his visitor.");											
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Notes icon was NOT changed for "+UserName1+" after he sent a mail to his visitor.");															
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			MissedChatCommonFunctions.clickNotesIconInChat(driver);

			if(MissedChatCommonFunctions.isMailReplyEventAddedInNotesTab(driver,UserName1))
			{
				passcount++;
				etest.log(Status.PASS,"Mail reply event was added in notes of respective visitor for "+UserName1+" after he sent a mail to his visitor.");															
			}
			else
			{
				etest.log(Status.FAIL,"Mail reply event was NOT added in notes of respective visitor for "+UserName1+" after he sent a mail to his visitor.");																			
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																			
			}



		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkSendMailChangesNotes","Error in checking notes icon",e);
		}
		finally
		{
		}

		return returnResult(passcount,3);
	}

	//s
	public static boolean checkSendMailWithoutMail(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();


		try
		{
			Tab.clickMissed(driver);		

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,"","Hello,What are the available discounts?");
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' ) without mail address");
			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name);
			etest.log(Status.INFO,UserName1+" opened details of unassigned visitor(visitor name : '"+visitor_name+"' )");
			commonIconsVerifyinMissedtab(driver);
			if(MissedChatCommonFunctions.checkSendMailButtonPresentInChatDetails(driver)==false)
			{
				etest.log(Status.PASS,UserName1+" did NOT find 'Send Email' button for unassigned visitor(visitor name : '"+visitor_name+"' ) without email address");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found 'Send Email' button for unassigned visitor(visitor name : '"+visitor_name+"' ) without email address");
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																
			}

			

		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkSendMailWithoutMail","Error in checking send mail button",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}

	public static boolean checkSendMailAndCloseActionWithMail(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
	

		try
		{
			Tab.clickMissed(driver);		

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");
			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name);
			etest.log(Status.INFO,UserName1+" opened details of unassigned visitor(visitor name : '"+visitor_name+"' )");			
			MissedChatCommonFunctions.clickSendMailToVisitorButton(driver);
			MissedChatCommonFunctions.sendMailToVisitor(driver,"Hello,We are closing this chat.Goodbye!!",true);
			etest.log(Status.INFO,UserName1+" sent a mail to visitor and closed the chat by clicking 'Send & Close' button");
			Thread.sleep(3000);

			Tab.clickMissed(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name)==false)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Missed' tab");				
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Missed' tab");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			Tab.clickChatHistory(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name,"history_div"))
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");								
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");												
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}


		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkSendMailAndCloseActionWithMail","Error in checking send mail and close button",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,2);
	}

	public static boolean checkChatHistoryForClose(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
	

		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(5000);

			Tab.clickChatHistory(driver);			

			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name,"history_div");
			etest.log(Status.INFO,UserName1+" opened details of unassigned visitor(visitor name : '"+visitor_name+"' ) from chat history tab");


				if(MissedChatCommonFunctions.checkCloseChatButtonPresentInChatDetails(driver))
				{
					etest.log(Status.PASS,UserName1+" found 'Close' button for visitor(visitor name : '"+visitor_name+"' ) after opening visitor details from chat history tab");				
					passcount++;
				}
				else
				{
					etest.log(Status.FAIL,UserName1+" did NOT find 'Close' button for visitor(visitor name : '"+visitor_name+"' ) after opening visitor details from chat history tab");				
					TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");
				}


		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkChatHistoryForClose","Error in checking chat history for close",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}

	public static boolean checkChatHistoryCloseIcon(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
	

		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name,"history_div");
			MissedChatCommonFunctions.clickCloseChatOfVisitorButton(driver);

			etest.log(Status.INFO,UserName1+" closed the chat of visitor(visitor name : '"+visitor_name+"' )");

			Tab.clickMissed(driver);			

			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			if(MissedChatCommonFunctions.checkForIconInChatHistory(driver,visitor_name,"visitstatus0"))
			{
				CommonSikuli.findInWholePage(driver,"MCclose.png","UI300",etest);
				passcount++;
				etest.log(Status.PASS,"Chat closed icon was found by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");
			}
			else
			{
				etest.log(Status.FAIL,"Chat closed icon was NOT found by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");	
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");							
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkChatHistoryCloseIcon","Error in checking chat history for close icon",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}

	
	public static boolean checkChatHistoryMailSentAndCloseIcon(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name);
			etest.log(Status.INFO,UserName1+" opened details of unassigned visitor(visitor name : '"+visitor_name+"' )");			

			MissedChatCommonFunctions.clickSendMailToVisitorButton(driver);
			MissedChatCommonFunctions.sendMailToVisitor(driver,"Hello,We will get back to you shortly.",true);
			etest.log(Status.INFO,UserName1+" sent a mail to visitor and closed the chat");						

			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			Thread.sleep(3000);		

			if(MissedChatCommonFunctions.checkForIconInChatHistory(driver,visitor_name,"visitstatus-2"))
			{
				CommonSikuli.findInWholePage(driver,"MCattendbyemail.png","UI299",etest);
				passcount++;
				etest.log(Status.PASS,"'Attended by Email' icon was found by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");
			}
			else
			{
				etest.log(Status.FAIL,"'Attended by Email' icon was NOT found by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");	
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");							
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkChatHistoryMailSentAndCloseIcon","Error in checking chat history for mail and close icon",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}

	public static boolean checkChatHistoryMailSentIcon(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			MissedChatCommonFunctions.openChatDetailsFromHistory(driver,visitor_name);
			etest.log(Status.INFO,UserName1+" opened details of unassigned visitor(visitor name : '"+visitor_name+"' )");			

			MissedChatCommonFunctions.clickSendMailToVisitorButton(driver);
			MissedChatCommonFunctions.sendMailToVisitor(driver,"Hello,We will get back to you shortly.",false);
			etest.log(Status.INFO,UserName1+" sent a mail to visitor.");						

			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			Thread.sleep(3000);						

			if(MissedChatCommonFunctions.checkForIconInChatHistory(driver,visitor_name,"visitstatus-1"))
			{
				passcount++;
				etest.log(Status.PASS,"'Missed' icon was found by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");
			}
			else
			{
				etest.log(Status.FAIL,"'Missed' icon was NOT found by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");	
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");							
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkChatHistoryMailSentIcon","Error in checking chat history for mail sent icon",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}

	//s

	public static boolean checkAssignDropdownChatHistory(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			Thread.sleep(3000);						

			if(MissedChatCommonFunctions.checkAssignDropdownDisplayedForSpecificUser(driver,visitor_name,"history_div"))
			{
				passcount++;
				etest.log(Status.PASS,"Assign dropdown was found with text 'Yet to Assign' by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");
			}
			else
			{
				etest.log(Status.FAIL,"Assign dropdown was NOT found with text 'Yet to Assign' by "+UserName1+" for visitor(visitor name : '"+visitor_name+"' ) in chat history tab");
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");							
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkAssignDropdownChatHistory","Error in checking assign dropdown in chat history",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}


	public static boolean miss1ChatAndDelete(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			Thread.sleep(4000);

			MissedChatCommonFunctions.selectAChatFromHistory(driver,visitor_name,"history_div");
			CommonSikuli.findInWholePage(driver,"MCdelete.png","UI301",etest);
			MissedChatCommonFunctions.performActionForSelectedChats(driver,visitor_name,"delete","history_div");
			MissedChatCommonFunctions.clickOKInPopUpConfirmation(driver);

			etest.log(Status.INFO,UserName1+" deleted visitor(visitor name : '"+visitor_name+"' ) from chat history tab");

			Thread.sleep(3000);			

			Tab.clickMissed(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name)==false)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Missed' tab");				
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Missed' tab");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			Tab.clickChatHistory(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name,"history_div")==false)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");																
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","miss1ChatAndDelete","Error in deleting missed chats test",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,2);
	}

	public static boolean miss2ChatAndDelete(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";

		Thread.sleep(247);

		String vstr2=getUniqueMessage();
		String visitor_name2="V_"+vstr2;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		visitor_name2=visitor_name2.toUpperCase();
		String visitor_mail2=visitor_name2+"@salesiqautomation.com";
		String visitor_question2="Hello I am "+visitor_name2+",What are the available discounts?";

		try
		{
			Tab.clickMissed(driver);


			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
				etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name2,visitor_mail2,visitor_question2);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
				etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name2+"' )");

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}






			Thread.sleep(3000);

			Tab.clickChatHistory(driver);

			Thread.sleep(3000);

			MissedChatCommonFunctions.selectAChatFromHistory(driver,visitor_name,"history_div");
			MissedChatCommonFunctions.selectAChatFromHistory(driver,visitor_name2,"history_div");

			MissedChatCommonFunctions.performActionForSelectedChats(driver,visitor_name,"delete","history_div");
			MissedChatCommonFunctions.clickOKInPopUpConfirmation(driver);

			etest.log(Status.INFO,UserName1+" deleted visitor(visitor name : '"+visitor_name+"' ) and visitor(visitor name : '"+visitor_name2+"' ) from chat history tab");

			Thread.sleep(4000);			

			Tab.clickChatHistory(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name,"history_div")==false)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");																
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name2,"history_div")==false)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name2+"' ) in 'Chat History' tab");																
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found details of visitor(visitor name : '"+visitor_name2+"' ) in 'Chat History' tab");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","miss2ChatAndDelete","Error in deleting missed chats test",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,2);
	}

//starts

	public static boolean miss1ChatAndClose(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(2000);

			Tab.clickMissed(driver);

			Thread.sleep(2000);

			MissedChatCommonFunctions.selectAChatFromHistory(driver,visitor_name,"missed_div");
			CommonSikuli.findInWholePage(driver,"Mclose.png","UI302",etest);
			MissedChatCommonFunctions.performActionForSelectedChats(driver,visitor_name,"close","missed_div");
			MissedChatCommonFunctions.clickOKInPopUpConfirmation(driver);

			etest.log(Status.INFO,UserName1+" closed chat of visitor(visitor name : '"+visitor_name+"' ) from chat history tab");

			Thread.sleep(5000);

			Tab.clickMissed(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name)==false)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Missed' tab");				
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Missed' tab");								
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			Tab.clickChatHistory(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name,"history_div")==true)
			{
				etest.log(Status.PASS,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");								
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");																
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","miss1ChatAndClose","Error in closing missed chats test",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,2);
	}
	
	public static boolean miss2ChatAndClose(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";

		Thread.sleep(247);

		String vstr2=getUniqueMessage();
		String visitor_name2="V_"+vstr2;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		visitor_name2=visitor_name2.toUpperCase();
		String visitor_mail2=visitor_name2+"@salesiqautomation.com";
		String visitor_question2="Hello I am "+visitor_name2+",What are the available discounts?";

		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
				etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name2,visitor_mail2,visitor_question2);
				MissedChatCommonFunctions.waitForClockToSetToZero_ClientSide(visitor_driver);
				etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name2+"' )");

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}


			Thread.sleep(2000);

			Tab.clickMissed(driver);

			Thread.sleep(2000);

			MissedChatCommonFunctions.selectAChatFromHistory(driver,visitor_name,"missed_div");
			MissedChatCommonFunctions.selectAChatFromHistory(driver,visitor_name2,"missed_div");

			MissedChatCommonFunctions.performActionForSelectedChats(driver,visitor_name,"close","missed_div");
			MissedChatCommonFunctions.clickOKInPopUpConfirmation(driver);

			etest.log(Status.INFO,UserName1+" closed chat of visitor(visitor name : '"+visitor_name+"' ) and visitor(visitor name : '"+visitor_name2+"' ) from chat history tab");

			Thread.sleep(5000);

			Tab.clickChatHistory(driver);
			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name,"history_div")==true)
			{
				etest.log(Status.PASS,UserName1+" found details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");								
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name+"' ) in 'Chat History' tab");																
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

			if(MissedChatCommonFunctions.checkChatPresentInHistory(driver,visitor_name2,"history_div")==true)
			{
				passcount++;
				etest.log(Status.PASS,UserName1+" found details of visitor(visitor name : '"+visitor_name2+"' ) in 'Chat History' tab");								
			}
			else
			{
				etest.log(Status.FAIL,UserName1+" did NOT find details of visitor(visitor name : '"+visitor_name2+"' ) in 'Chat History' tab");																
				TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");																																							
			}

		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","miss2ChatAndClose","Error in closing missed chats test",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,2);
	}

	public static boolean checkMissedAfterContinueChat(WebDriver driver) throws Exception
	{
		String UserName1=ExecuteStatements.getUserName(driver);
		int passcount=0;

		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr;//"v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();

		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello I am "+visitor_name+",What are the available discounts?";
		try
		{
			Tab.clickMissed(driver);

			try
			{
				visitor_driver=Functions.setUp();
				BrowserConfiguration.navigateToClientSite(visitor_driver);
				MissedChatCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);

			}	
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,UserName1+" started chat from visitor(visitor name : '"+visitor_name+"' )");						
			ChatWindow.endChat(driver);
			etest.log(Status.INFO,UserName1+" ended chat from visitor(visitor name : '"+visitor_name+"' )");			

            try
            {
                MissedChatCommonFunctions.restartChatAfterEndingSession(visitor_driver,etest);
                etest.log(Status.INFO,"Visitor(visitor name : '"+visitor_name+"' ) clicked 'Start Chat' after ending chat with"+UserName1);
                VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
            }
            catch(Exception exp)
            {
                TakeScreenshot.screenshot(visitor_driver,etest,"Missed Chats","Visitor Failure","Error at Visitor Window",exp);
                return false;
            }
            
			etest.log(Status.INFO,UserName1+" missed a chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(1000);
			Tab.clickMissed(driver);

				if(MissedChatCommonFunctions.checkChatAssignationStatusInChatHistory(driver,visitor_name,"Me"))
				{
					etest.log(Status.PASS,UserName1+" found chat of visitor(visitor name : '"+visitor_name+"' ) assigned to "+UserName1+"(previously attended agent)");									
					passcount++;
				}
				else
				{
					etest.log(Status.FAIL,UserName1+" did NOT find chat of visitor(visitor name : '"+visitor_name+"' ) assigned to "+UserName1+"(previously attended agent)");									
					TakeScreenshot.screenshot(driver,etest,"Missed Chats","Failure",UserName1+" window screenshot");
				}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Missed Chats","checkMissedAfterContinueChat","Error in checking missed chats test",e);
		}
		finally
		{
			BrowserConfiguration.CloseBrowser(visitor_driver);
		}

		return returnResult(passcount,1);
	}	














	public static boolean returnResult(int passcount,int expected_passcount)
	{
		if(passcount==expected_passcount)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static String getUniqueMessage()
	{
		return ""+new Long(System.currentTimeMillis());
	}

	public static void closeBannersAfterLogin(WebDriver driver) throws Exception
    {
    	Functions.closeBannersAfterLogin(driver);
    }

   public static void commonIconsVerifyinMissedtab(WebDriver driver)
    {
        try
        {
           //checkChatActions
          CommonSikuli.findInWholePage(driver,"Notes.png","UI290",etest);
          CommonSikuli.findInWholePage(driver,"Chat.png","UI292",etest);
          CommonSikuli.findInWholePage(driver,"Chatinfo.png","UI291",etest);
		  WebElement editicon = CommonUtil.elfinder(driver,"id","cvemail");
          CommonUtil.mouseHover(driver,editicon);  
          CommonSikuli.findInWholePage(driver,"Visitoredit.png","UI293",etest);
          CommonSikuli.findInWholePage(driver,"Visitordept.png","UI294",etest);
          CommonSikuli.findInWholePage(driver,"Visitordevice.png","UI295",etest);

          WebElement browser = driver.findElement(By.xpath(".//*[contains(@class, '_browser')]"));
          WebElement os = driver.findElement(By.xpath(".//*[contains(@class, '_os')]"));

        if (browser.getAttribute("class").contains("browser"))
         {
           System.out.println(CommonSikuli.getBrowsername(browser));
           CommonSikuli.findInWholePage(driver,CommonSikuli.getBrowsername(browser),"UI297",etest);
         }
                  
         if (os.getAttribute("class").contains("os"))
         {     
            System.out.println(CommonSikuli.getOSname(os));
            CommonSikuli.findInWholePage(driver,CommonSikuli.getOSname(os),"UI296",etest);
         }
        }
        catch(Exception e)
        {
            System.out.println("Exception while Check commonIcons in MissedChat Tab");
        }
    }

}
