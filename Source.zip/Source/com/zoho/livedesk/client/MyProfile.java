//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.util.common.CommonUtil;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class MyProfile
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	public static ExtentTest etest; 
	
	public static Hashtable myProfile(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MP1"));
            ComplexReportFactory.setValues(etest,"Automation","My Profile");

			url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            result.put("MP1", false);

			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));

			driver.findElement(By.id("menu_user")).click();

			etest.log(Status.PASS,"MyProfile Tab is present");

			result.put("MP1", true);
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MP2"));
            ComplexReportFactory.setValues(etest,"Automation","My Profile");

			result.put("MP2", isWindowAvail(driver));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MP3"));
            ComplexReportFactory.setValues(etest,"Automation","My Profile");

			result.put("MP3", checkMyProfileOptions(driver));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MP4"));
            ComplexReportFactory.setValues(etest,"Automation","My Profile");

			result.put("MP4", performanceReportData(driver));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MP5"));
            ComplexReportFactory.setValues(etest,"Automation","My Profile");

			result.put("MP5", performanceReportActions(driver));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MP6"));
            ComplexReportFactory.setValues(etest,"Automation","My Profile");

			result.put("MP6", performanceReportDate(driver));	

            ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorMyProfileTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"MyProfile","MyProfileTab","ErrorWhileCheckingMyProfileTab",e);

			result.put("MP1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorMyProfileTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"MyProfile","MyProfileTab","ErrorWhileCheckingMyProfileTab",e);

			result.put("MP1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	private static boolean isWindowAvail(WebDriver driver)
	{
		try
		{
			String knownAs = getUserName(driver);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
			//WebDriverWait wait = new WebDriverWait(driver, 20);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));

			driver.findElement(By.id("menu_user")).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_sm_myprofile")));

			driver.findElement(By.id("user_sm_myprofile")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

			String username = "";

			if(ResourceManager.getRealValue("myprofile_desc").equals(driver.findElement(By.className("innersubinfotxt")).getText()))
			{
				etest.log(Status.PASS,"MyProfile Description matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"MyProfile","MyProfilePage","DescriptionMatched");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"MyProfile","MyProfilePage","ErrorWhileCheckingMyProfilePage",e);

			System.out.println("Exception while checking if myprofile tab is available : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","MyProfilePage","ErrorWhileCheckingMyProfilePage",e);

            System.out.println("Exception while checking if myprofile tab is available : "+e);
		}
		return false;
	}

	private static boolean checkMyProfileOptions(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
			//WebDriverWait wait = new WebDriverWait(driver, 20);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));

			driver.findElement(By.id("menu_user")).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_sm_myprofile")));

			driver.findElement(By.id("user_sm_myprofile")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

			WebElement elmt = driver.findElement(By.id("test")).findElement(By.className("innerbtnmn"));

			List<WebElement> elmts = elmt.findElements(By.tagName("span"));

			if((ResourceManager.getRealValue("settings_edit").equals(elmts.get(0).getText())) && (ResourceManager.getRealValue("settings_newpersonalize").equals(elmts.get(1).getText())))
			{
				driver.findElement(By.id("userdetails")).click();
				WebElement performancerep = driver.findElement(By.id("myprp-tab")).findElement(By.tagName("a"));

				if(ResourceManager.getRealValue("myprofile_performancerep").equals(performancerep.getText()))
				{
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+performancerep.getLocation().y+"-400)");
					performancerep.click();
				}
				if(ResourceManager.getRealValue("myprofile_hideperformancerep").equals(performancerep.getText()))
				{
                   			 etest.log(Status.PASS,"Performance is present");

					return true;
				}
				else{
					TakeScreenshot.screenshot(driver,etest,"MyProfile","Options","HidePerformanceReportContentMismatch");
				}
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"MyProfile","Options","EditProfileOrSounds-ThemesContentMismatch");
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","Options","ErrorWhileCheckingOptions",e);

            System.out.println("Exception while checking myprofile options in MyProfile page : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","Options","ErrorWhileCheckingOptions",e);

            System.out.println("Exception while checking myprofile options in MyProfile page : "+e);
		}
		return false;
	}

	private static boolean performanceReportData(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));

			driver.findElement(By.id("menu_user")).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_sm_myprofile")));

			driver.findElement(By.id("user_sm_myprofile")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

			WebElement performancerep = driver.findElement(By.id("myprp-tab")).findElement(By.tagName("a"));

			if(ResourceManager.getRealValue("myprofile_performancerep").equals(performancerep.getText()))
			{
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+performancerep.getLocation().y+"-400)");
				performancerep.click();
			}
            
			WebElement elmt = driver.findElement(By.id("reportdiv"));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-400)");
			elmt.click();

			if((ResourceManager.getRealValue("performancerep_usractivity").equals(elmt.findElement(By.id("userh1")).getText())) && (ResourceManager.getRealValue("performancerep_usractivityratio").equals(elmt.findElement(By.id("userh2")).getText())) && (ResourceManager.getRealValue("performancerep_usrattendedchats").equals(elmt.findElement(By.id("userh3")).getText())) && (ResourceManager.getRealValue("performancerep_usrrating").equals(elmt.findElement(By.id("userh4")).getText())))
			{
				etest.log(Status.PASS,"Reports Contents are checked");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"MyProfile","Reports","MismatchOperatorActivityOrOperatorActivityRatioContent");
			}

		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","Reports","ErrorWhileCheckingReports",e);

            System.out.println("Exception while checking performance report data in MyProfile page : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","Reports","ErrorWhileCheckingReports",e);

            System.out.println("Exception while checking performance report data in MyProfile page : "+e);
		}
		return false;
	}

	private static boolean performanceReportActions(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));

			driver.findElement(By.id("menu_user")).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_sm_myprofile")));

			driver.findElement(By.id("user_sm_myprofile")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

			WebElement performancerep = driver.findElement(By.id("myprp-tab")).findElement(By.tagName("a"));

			if(ResourceManager.getRealValue("myprofile_performancerep").equals(performancerep.getText()))
			{
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+performancerep.getLocation().y+"-400)");
				performancerep.click();
			}
            
			WebElement elmt = driver.findElement(By.id("reportdiv"));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-400)");
			elmt.click();

			driver.findElement(By.id("cmbothact")).click();
			Thread.sleep(1000);

			WebElement elmt1 = driver.findElement(By.id("murothact"));

			List<WebElement> elmts = elmt1.findElement(By.id("othact")).findElements(By.tagName("li"));

			if((ResourceManager.getRealValue("actions_pdf").equals(elmts.get(0).getText())) && (ResourceManager.getRealValue("actions_mail").equals(elmts.get(1).getText())) && (ResourceManager.getRealValue("actions_excel").equals(elmts.get(2).getText())) && (ResourceManager.getRealValue("actions_csv").equals(elmts.get(3).getText()))) 
			{
				etest.log(Status.PASS,"MyProfile Tab is present");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"MyProfile","ActionsDropDown","MismatchContent");
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","ActionsDropDown","ErrorWhileCheckingActionsDropDown",e);

            System.out.println("Exception while checking performance report actions in MyProfile page : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","ActionsDropDown","ErrorWhileCheckingActionsDropDown",e);

            System.out.println("Exception while checking performance report actions in MyProfile page : "+e);
		}
		return false;
	}

	private static boolean performanceReportDate(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));

			driver.findElement(By.id("menu_user")).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_sm_myprofile")));

			driver.findElement(By.id("user_sm_myprofile")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

			WebElement performancerep = driver.findElement(By.id("myprp-tab")).findElement(By.tagName("a"));

			if(ResourceManager.getRealValue("myprofile_performancerep").equals(performancerep.getText()))
			{
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+performancerep.getLocation().y+"-400)");
				performancerep.click();
			}

			WebElement elmt2 = driver.findElement(By.id("reportdiv"));
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt2.getLocation().y+"-400)");
            elmt2.click();
            
			Thread.sleep(1000);
			CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id("murstimeselector")));
			CommonUtil.clickWebElement(driver,By.id("murstimeselector"));

			WebElement elmt1 = driver.findElement(By.id("murtimeselector")).findElement(By.tagName("ul"));
			
			List<WebElement> elmts = elmt1.findElements(By.tagName("li"));

			String[] expectedDate = ResourceManager.getRealValue("myprofile_performance_date").split(",");
			int i = 0;

			for(WebElement elmt : elmts)
			{
				String date = elmt.getText();

				CommonUtil.clickWebElement(driver,elmt);
				Thread.sleep(1000);

				String selectedtxt = driver.findElement(By.id("cmbtimeselector")).getText();

				if(!(selectedtxt.equals(date)) && expectedDate[i++].equals(date))
				{
					TakeScreenshot.screenshot(driver,etest,"MyProfile","Date","MismatchDate");

					return false;
				}
				else
				{
					etest.log(Status.PASS,"<b style='color:red'>"+date+"</b> is selected from dropdown and is checked if it was selected");
				}

				CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id("murstimeselector")));
				CommonUtil.clickWebElement(driver,By.id("murstimeselector"));
			}
			etest.log(Status.PASS,"Date Dropdown is checked");

			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","Date","ErrorWhileCheckingDate",e);

            System.out.println("Exception while checking performance report based on date in MyProfile page : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"MyProfile","Date","ErrorWhileCheckingDate",e);

            System.out.println("Exception while checking performance report based on date in MyProfile page : "+e);
		}
		return false;
	}


	private static String getUserName(WebDriver driver)
	{
		String knownas = "";
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("menu_user")));
            
			driver.findElement(By.id("menu_user")).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_sm_myprofile")));
            
			driver.findElement(By.id("user_sm_myprofile")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("test")));
            
			WebElement elmt = driver.findElement(By.id("test"));
			WebElement userdetails = elmt.findElement(By.className("usr-mrgntp")).findElement(By.id("userdetails"));
			knownas = userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while getting Operatorname in MyProfile page : "+e);
        }
		catch(Exception e)
		{
            System.out.println("Exception while getting Operatorname in MyProfile page : "+e);
        }
		return knownas;
	}
}
