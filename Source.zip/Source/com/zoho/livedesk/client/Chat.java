//$Id$
package com.zoho.livedesk.client;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.interactions.Actions;

import java.util.Set;
import java.util.List;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.CompanyInfo;
import com.zoho.livedesk.util.Util;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;

public class Chat
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
      public static final String EMBED = "Embed";
	public static String name = "Anand R";
	public static String email = "rajkumar.natarajan+2@zohocorp.com";
	public static String phno = "9788123456";
	public static String dept = "Automation";
	public static String ques = "Hai there?";
	public static String user = "";
	public static String feedbackmsg = "";
	public static String visitorid = "";
	public static String time = "";
    public static ExtentTest etest;
    public static WebDriver driver1 = null;
    public static WebDriver visDriver = null;
    public static WebDriver driver = null;
    
	public static Hashtable testchat(WebDriver d)
	{
        try
		{
            result = new Hashtable();
            driver = d;
            driver1 = driver;
        
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT1"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Condition check and details for Widget
            driver.navigate().refresh();Thread.sleep(5000);
            
			disableBusinessHour(driver);
			user = getUserName(driver);
            Thread.sleep(1000);
            addDepartment(driver, "TestDepartment", "depttype_publi");
			Thread.sleep(2000);
			driver.navigate().refresh();
			Thread.sleep(2000);

            etest.log(Status.PASS,"Check Chat Widget Available");
            //Chat widget availability check
            result.put("CHAT1", isChatWidgetAvailable(driver));

			//Basic chat check

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Fields In Visitor Chat Widget");
            ComplexReportFactory.setValues(etest,"Automation","Chat");
            
            driver = visDriver;
            checkFields(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Check Visitor Data"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            acceptChat1(driver);
			checkVisitorData(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT21"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            result.put("CHAT21", checkVisitorSideAftrAttend(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT100"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT100", chatReply(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT22"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            result.put("CHAT22", checkReplyMessageOnVisitorSide(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT23"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT23", checkReplyMessageOnAgentSide(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT29"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT29", checkChatsTab(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT30"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");
            
            driver = driver1;
            result.put("CHAT30", checkVisitorsTab(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT101"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT101", endChat(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT24"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT24", agentChatEndWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT25"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            result.put("CHAT25", visitorChatEndWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT26"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");
            
            driver = visDriver;
            result.put("CHAT26", feedbackAndRating(driver));
			Thread.sleep(2000);

            ComplexReportFactory.closeTest(etest);

            driver = driver1;
            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT34"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Join chat check
            driver = visDriver;
            initiateChat(driver);
			acceptChat1(driver);

            driver = driver1;
            result.put("CHAT34", joinChat(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT102"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            result.put("CHAT102", endChatVisSide(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Add Notes");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            addNote(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT28"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            checkAndClearVisitors(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT103"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //End Chat with timer(Chat ends after timer runs out)
            driver = visDriver;
            initiateChat(driver);
			acceptChat1(driver);
            
            driver = driver1;
            result.put("CHAT103", endChatWithTimer(driver));

            //endChat(driver);
		result.put("CHAT28", closeThisWindow(driver));
            Thread.sleep(2000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT45"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT45", checkHistoryTab(driver));
			Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT104"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //End chat with timer(Chat ends before timer runs out)
            driver = visDriver;
            initiateChat(driver);
			acceptChat1(driver);
            
            driver = driver1;
            result.put("CHAT104", endChatWithTimerImd(driver));

            //endChat(driver);
		result.put("CHAT28", closeThisWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Chat Actions");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            checkChatActions(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Add Notes Tab");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            checkAddNoteTab(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Visitor Info");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            checkVisitorInfo(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check History Tab");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            checkChatTab(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Sent Email Dialog Box");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            checkSendAsMail(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Chat History");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            checkPastHistory(driver);
			Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT105"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //End chat Timer and then continue it
            driver = visDriver;
            initiateChat(driver);
			acceptChat1(driver);

            driver = driver1;
            result.put("CHAT105", endChatWithTimerCont(driver));

            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT35"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Chat without email,name
            driver = visDriver;
            result.put("CHAT35", initiateChatNoNameEmail(driver));

            driver = driver1;
            result.put("CHAT101", endChat(driver));

            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT36"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Chat without name
            driver = visDriver;
            result.put("CHAT36", initiateChatNoName(driver));

            driver = driver1;
            result.put("CHAT101", endChat(driver));

            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT16"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Chat without department and without question
            driver = visDriver;
            result.put("CHAT16", chatwithoutDept(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT17"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            result.put("CHAT17", chatwithoutQues(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Chat With Department and Check Question");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            chatWithDeptQues(driver);

            driver = driver1;
            result.put("CHAT101", endChat(driver));

            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest("Check Ignore CHat Notification");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Dynamic Canned Messages
            driver = visDriver;
            initiateChat(driver);

            driver = driver1;
            checkIgnoreChatNotify(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT112"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT112", addDynamicCannedMessage(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT113"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT113", addDynamicCannedMessage1(driver,"Hai Anand R, Welcome to SalesIQ"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT114"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT114", addDynamicCannedMessage2(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT115"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT115", addDynamicCannedMessage1(driver,"Hello Anand R"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT32"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT32", endChatWithTimerATimer(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT31"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT31", endChatWithTimerAImd(driver));

            driver = driver1;
            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            checkAndClearVisitors(driver);

            //Check Chat actions
            driver = visDriver;
            initiateChat(driver);
		
            driver = driver1;
            acceptChat1(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT107"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT107", checkActionsBlockIP(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT108"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT108", checkActionsShareURL(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT109"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT109", checkActionsTransferChat(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT110"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT110", checkActionsSound(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT111"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT111", checkActionsVShareMail(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("End Chat");
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            endChat(driver);

            result.put("CHAT28", closeThisWindow(driver));
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT40"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Check all Actions
            driver = visDriver;
            initiateChat(driver);
		
            driver = driver1;
            acceptChat1(driver);

            driver = driver1;
            result.put("CHAT40", checkAllEndOptions(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT41"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT41", checkMoreActions(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT42"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = visDriver;
            result.put("CHAT42", checkOptionsVisSide(driver));
            changeWindow(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT43"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT43", checkCannedMessageSugg1(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT44"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT44", checkCannedMessageSugg2(driver));

            driver = driver1;
            result.put("CHAT101", endChat(driver));

            result.put("CHAT28", closeThisWindow(driver));
            Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT37"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //Final Check conditions
            driver = driver1;
            deleteDepartment(driver,"TestDepartment");

            result.put("CHAT37", chatWithSingleDepartment(driver,"CHAT37"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT38"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            addDepartment(driver, "TestDepartment", "depttype_privat");

            result.put("CHAT38", chatWithSingleDepartment(driver,"CHAT38"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT39"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            result.put("CHAT39", chatWithNoDept(driver));

            endChat(driver);

            closeThisWindow(driver);
		Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT116"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            result.put("CHAT116", checkAttachmentInTilesUI(driver,etest));

            ComplexReportFactory.closeTest(etest);

            checkAndClearVisitors(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT98"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            //chat widget offline/online check
            driver = driver1;
            result.put("CHAT98", checkWidgetOffline(driver));
            Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHAT99"));
            ComplexReportFactory.setValues(etest,"Automation","Chat");

            driver = driver1;
            result.put("CHAT99", checkWidgetOnline(driver));

            visDriver.quit();
            
            ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorChatWindow"+e.toString());
                  TakeScreenshot.log(e,etest);
                  
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatWindow","ErrorWhileCheckingChatWindow",e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("Exception while checking chat module : "+e);
		}
		catch(Exception e)
		{
                  etest.log(Status.FATAL,"ErrorChatWindow"+e.toString());
                  TakeScreenshot.log(e,etest);

            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatWindow","ErrorWhileCheckingChatWindow",e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("Exception while checking chat module : "+e);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
        System.out.println(hashtable);
		return hashtable;
	}

    //Disable Business Hour
    private static boolean disableBusinessHour(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            System.out.println("Comes here");
            //WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("businesshourlink")));

            WebElement configbh = driver.findElement(By.id("businesshourlink"));

            if((configbh.getAttribute("style")).contains("inline-block"))
            {
                System.out.println("Comes here perfect");
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+configbh.getLocation().y+"-400)");
                configbh.click();
            }

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bhdisablelnk")));

            if((driver.findElement(By.id("bhdisablelnk")).getAttribute("style")).equals("display: none;"))
            {
                System.out.println("Comes here too");
                enableBusinessHour(driver);
            }
            //driver.findElement(By.xpath("//span[text()='"+ResourceManager.getRealValue("common_disable")+"']")).click();
            //driver.findElement(By.id("bhstatusdiv")).click();
            try
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.cssSelector("div.togglebtn.set_on"))).getLocation().y+"-400)");
                driver.findElement(By.cssSelector("div.togglebtn.set_on")).click();
            }
            catch(Exception e)
            {}
            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("bhcontainer"));
            List<WebElement> elmts = elmt.findElements(By.tagName("div"));
            if((elmts.get(0).getAttribute("style")).contains("none"))
            {
                return false;
            }
            //checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DisableBusinessHour","BusinessHourIsNotDisabled");

            return true;
        }
        catch(NoSuchElementException e)
        {
            //checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DisableBusinessHour","ErrorWhileDisablingBusinessHour",e);

            System.out.println("Expception while disabling business hours in Chat Module : "+e);
        }
        catch(Exception e)
        {
            //checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DisableBusinessHour","ErrorWhileDisablingBusinessHour",e);

            System.out.println("Expception while disabling business hours in Chat Module : "+e);
        }
        return false;
    }

    //Enable Business Hours
    private static boolean enableBusinessHour(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("businesshourlink")));

            if((driver.findElement(By.id("bhdisablelnk")).getAttribute("style")).equals("display: block;"))
            {
                disableBusinessHour(driver);
            }
            //driver.findElement(By.xpath("//span[text()='"+ResourceManager.getRealValue("common_enable")+"']")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhstatusdiv"))).getLocation().y+"-400)");
            driver.findElement(By.id("bhstatusdiv")).click();
            Thread.sleep(1000);
            driver.findElement(By.cssSelector("div.togglebtn.set_off")).click();
            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("bhcontainer"));
            List<WebElement> elmts = elmt.findElements(By.tagName("div"));

            if((elmts.get(0).getAttribute("style")).contains("none"))
            {
                return true;
            }
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EnableBusinessHour","BusinessHourIsNotEnabled");
        }
        catch(NoSuchElementException e)
        {
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EnableBusinessHour","ErrorWhileEnablingBusinessHour",e);

            System.out.println("Expception while enabling business hours in Chat Module : "+e);
        }
        catch(Exception e)
        {
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EnableBusinessHour","ErrorWhileEnablingBusinessHour",e);

            System.out.println("Expception while enabling business hours in Chat Module : "+e);
        }
        return false;
    }

    //get user name
	private static String getUserName(WebDriver driver)
	{
		String knownas = "";
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings")));

            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));

            Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_myprofile"))).click();
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("test")));

			WebElement elmt = driver.findElement(By.id("test"));
			WebElement userdetails = elmt.findElement(By.className("usr-mrgntp")).findElement(By.id("userdetails"));
			knownas = userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","GetOperatorNameFromMyProfilePage","Error",e);

            System.out.println("Expception while getting Operatorname in Chat Module : "+e);
        }
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","GetOperatorNameFromMyProfilePage","Error",e);

            System.out.println("Expception while getting Operatorname in Chat Module : "+e);
        }
		return knownas;
	}

    //Add a department
	private static void addDepartment(WebDriver driver, String deptname, String type)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			user = getUserName(driver);

            Thread.sleep(1000);
            
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

			driver.findElement(By.id("buttonadddept")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("moduleadd")));

			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_adddepartment")+"')]"));
			Thread.sleep(1000);
			driver.findElement(By.id("name")).click();
			driver.findElement(By.id("name")).clear();
			driver.findElement(By.id("name")).sendKeys(deptname);
			Thread.sleep(500);
			driver.findElement(By.id(type)).click();
			Thread.sleep(500);
			driver.findElement(By.id("desc")).click();
			driver.findElement(By.id("desc")).clear();
			driver.findElement(By.id("desc")).sendKeys("Description");
			Thread.sleep(1000);

			if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
			{
				WebElement elmt = driver.findElement(By.id("unassodeptlist"));

				List<WebElement> elmts = elmt.findElements(By.tagName("div"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-400)");

				for(WebElement element:elmts)
				{
					WebElement ptag;
					try
					{
						ptag = element.findElement(By.tagName("p"));
					}
					catch(Exception e)
					{
						continue;
					}
					if(user.equals(ptag.getText()))
					{
						List<WebElement> elmts1 = element.findElements(By.tagName("div"));

						elmts1.get(0).click();
						break;
					}
				}
			}
			Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+"-400)");
			driver.findElement(By.id("deptaddbtn")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);
    }
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddDepartment:"+deptname,"ErrorWhileAddingDepartment",e);

            System.out.println("Exception while adding department in chat module : "+e);
        }
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddDepartment:"+deptname,"ErrorWhileAddingDepartment",e);

            System.out.println("Exception while adding department in chat module : "+e);
        }
	}

    //check chat widget
	private static boolean isChatWidgetAvailable(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            visDriver = Functions.setUp();
            
            driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);
			String url = Util.siteNameout()+"/"+"chatops"+"/drawchat.ls?embedname="+"chatops";//ConfManager.getLoginURL()
			
            driver.get(url);
            
			Thread.sleep(5000);
            
            driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));
			Thread.sleep(2000);
			return true;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatWidgetAvailable","ErrorWhileCheckingChatWidgetAvailable",e);

            System.out.println("Exception while checking chat widget is available in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatWidgetAvailable","ErrorWhileCheckingChatWidgetAvailable",e);

            System.out.println("Exception while checking chat widget is available in chat module : "+e);
		}
		return false;
	}

    //check chat widget input fields
	private static void checkFields(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			try
			{
				driver.findElement(By.id("name")).clear();
				driver.findElement(By.id("name")).sendKeys(name);
				if(name.equals(driver.findElement(By.id("name")).getAttribute("value")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT2")+" is checked");

                    result.put("CHAT2", true);
				}
				else
				{
					checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT2"),"MismatchContent:"+name);

                    result.put("CHAT2", false);
				}
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT2"),"Error",e);

                result.put("CHAT2", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT2"),"Error",e);

                result.put("CHAT2", false);
            }
			try
			{
				driver.findElement(By.id("email")).clear();
				driver.findElement(By.id("email")).sendKeys(email);
				if(email.equals(driver.findElement(By.id("email")).getAttribute("value")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT3")+" is checked");

                    result.put("CHAT3", true);
				}
				else
				{
					checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT3"),"MismatchContent:"+email);

                    result.put("CHAT3", false);
				}
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT3"),"Error",e);

                result.put("CHAT3", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT3"),"Error",e);

                result.put("CHAT3", false);
            }
			try
			{
				driver.findElement(By.id("phone")).clear();
				driver.findElement(By.id("phone")).sendKeys(phno);
				if(phno.equals(driver.findElement(By.id("phone")).getAttribute("value")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT33")+" is checked");

                    result.put("CHAT33", true);
				}
				else
				{
					checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT33"),"MismatchContent:"+phno);

                    result.put("CHAT33", false);
				}
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT33"),"Error",e);

                result.put("CHAT33", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT33"),"Error",e);

                result.put("CHAT33", false);
            }

			try
			{
				driver.findElement(By.id("selecteddept")).click();
				driver.findElement(By.xpath(".//li[@uniname='"+dept+"']")).click();
				if(dept.equals(driver.findElement(By.id("selecteddept")).findElement(By.tagName("span")).getText()))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT4")+" is checked");

                    result.put("CHAT4", true);
				}
				else
				{
					checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT4"),"MismatchContent:"+dept);

                    result.put("CHAT4", false);
				}
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT4"),"Error",e);

                result.put("CHAT4", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT4"),"Error",e);

                result.put("CHAT4", false);
            }
			try
			{
				driver.findElement(By.id("question")).clear();
				driver.findElement(By.id("question")).sendKeys(ques);
				if(ques.equals(driver.findElement(By.id("question")).getAttribute("value")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT5")+" is checked");

                    result.put("CHAT5", true);
				}
				else
				{
					checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT5"),"MismatchContent:"+ques);

                    result.put("CHAT5", false);
				}
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT5"),"Error",e);

                result.put("CHAT5", false);
            }
            catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT5"),"Error",e);

                result.put("CHAT5", false);
            }
			result.put("CHAT6", false);
			result.put("CHAT7", false);
			if((ResourceManager.getRealValue("common_start").equals(driver.findElement(By.id("btnaddvisitor")).getAttribute("value"))) || (ResourceManager.getRealValue("common_chat").equals(driver.findElement(By.id("btnaddvisitor")).getAttribute("value"))))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT6")+" is checked");

                    result.put("CHAT6", true);
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT6"),"MismatchContentInButtons");
            }
			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(2000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("timersvg")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("timersvg")));
			etest.log(Status.PASS,KeyManager.getRealValue("CHAT7")+" is checked");
            result.put("CHAT7", true);

		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatWindowFields","Error",e);

            System.out.println("Exception while checking fields in the chat widget in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatWindowFields","Error",e);

            System.out.println("Exception while checking fields in the chat widget in chat module : "+e);
		}
	}


	//accept chat
	private static void acceptChat1(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT15", false);
			Thread.sleep(2000);

			driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(2000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));

            //Thread.sleep(1000);
            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wpckup")));

            Thread.sleep(3000);

                  CommonSikuli.findInWholePage(driver,"Chatattenddepartment.png","UI86",etest);
                  CommonSikuli.findInWholePage(driver,"Chatattendname.png","UI87",etest);

			driver.findElement(By.id("waitinglist")).findElement(By.id("wpckup")).click();

            Thread.sleep(4000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgtablediv")));

			if((driver.findElement(By.id("msgtablediv")).getAttribute("style")).equals("display: block;"))
			{
				result.put("CHAT15", true);
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AcceptChat","ChatIsNotAccepted");
            }
			visitorid = driver.findElement(By.id("msgtablediv")).findElements(By.className("lvst_idtxt")).get(0).getText();
			String timestr = driver.findElement(By.id("msgtablediv")).findElements(By.className("t-v-subtxt")).get(0).getText();
			time = (timestr.split(" by"))[0];
			time = "Today at "+time;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AcceptChat","ErrorWhileAcceptingChat",e);
            System.out.println("Exception while trying to accept chat in chat module : ");
            e.printStackTrace();
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AcceptChat","ErrorWhileAcceptingChat",e);
            System.out.println("Exception while trying to accept chat in chat module : ");
            e.printStackTrace();
		}
	}

    //check visitor data
	private static void checkVisitorData(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT10", false);
			result.put("CHAT11", false);
			result.put("CHAT12", false);
			result.put("CHAT13", false);
			result.put("CHAT14", false);

			try
			{
				if(name.equals(driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText()))
				{
					if((driver.findElement(By.className("t-v-subtxt")).getText()).contains(name))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT10")+" is checked");

                        result.put("CHAT10", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT10"),"MismatchContent:"+name);
                    }
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT10"),"MismatchContentInTitle:"+name);
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT10"),"Error",e);

                result.put("CHAT10", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT10"),"Error",e);

                result.put("CHAT10", false);
            }


			try
      			{     
                        
                   
                        commonIconsVerifyinMychatstab(driver);
                        WebElement editicon = CommonUtil.elfinder(driver,"id","cvemail");
                        CommonUtil.mouseHover(driver,editicon);   
                        CommonSikuli.findInWholePage(driver,"Visitoredit.png","UI88",etest);

				if((driver.findElement(By.className("t-v-subtxt")).getText()).contains(email))
				{
					if(email.equals(driver.findElement(By.id("cvemail")).findElement(By.tagName("a")).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT11")+" is checked");

                        result.put("CHAT11", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT11"),"MismatchContent:"+email);
                    }
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT11"),"MismatchContent:"+email);
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT11"),"Error",e);

                result.put("CHAT11", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT11"),"Error",e);

                result.put("CHAT11", false);
            }

			try
			{      
                        CommonSikuli.findInWholePage(driver,"Visitorphone.png","UI90",etest);
  
				if(phno.equals(driver.findElement(By.id("cvphone")).getText()))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT12")+" is checked");

                    result.put("CHAT12", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT12"),"MismatchContent:"+phno);
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT12"),"Error",e);

                result.put("CHAT12", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT12"),"Error",e);

                result.put("CHAT12", false);
            }

			try
			{
				List<WebElement> elmts1 = driver.findElement(By.id("visitordata")).findElements(By.className("rcvstinfotxt"));
				String txt = "";
				if(elmts1.size() > 2)
				{
					txt = elmts1.get(1).getText();
				}
				else if(elmts1.size() == 2)
				{
					txt = elmts1.get(0).getText();
				}

                        CommonSikuli.findInWholePage(driver,"Visitordept.png","UI89",etest);

				if((txt).contains(dept))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT13")+" is checked");

                    result.put("CHAT13", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT13"),"DepartmentsIsNotPresent");
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT13"),"Error",e);

                result.put("CHAT13", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT13"),"Error",e);

                result.put("CHAT13", false);
            }

			try
			{
				WebElement elmt2 = driver.findElement(By.id("msgtablediv"));
				List<WebElement> txt = elmt2.findElements(By.className("t-v-questionmn"));

				if((txt.get(0).getText()).contains(ques))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT14")+" is checked");

                    result.put("CHAT14", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT14"),"MismatchContent:"+ques);
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT14"),"Error",e);

                result.put("CHAT14", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT14"),"Error",e);

                result.put("CHAT14", false);
            }

		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorData","Error",e);

            System.out.println("Exception while checking visitor data in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorData","Error",e);

            System.out.println("Exception while checking visitor data in chat module : "+e);
		}
	}

    //check Visitor side after chat attend
	private static boolean checkVisitorSideAftrAttend(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);
            
			Thread.sleep(3000);

			WebElement elmt = driver.findElement(By.id("attender")).findElement(By.className("vistname")).findElement(By.className("vistinfo"));
			List<WebElement> elmts = elmt.findElements(By.tagName("span"));

            String value1 = elmts.get(0).getText();
            String value2 = elmts.get(1).getText();

			if((user.equals(value1)) && (ResourceManager.getRealValue("common_connected").equals(value2)))
			{
                etest.log(Status.PASS,KeyManager.getRealValue("CHAT21")+" is checked");

                return true;
			}
            else{
                etest.log(Status.FAIL,"Expected:"+user+"--"+ResourceManager.getRealValue("common_connected")+"--Actual:"+value1+"--"+value2+"--");
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorSideAfterAttend","MismatchContent");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorSideAfterAttend","Error",e);

            System.out.println("Exception while checking visitor side after attending chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorSideAfterAttend","Error",e);

            System.out.println("Exception while checking visitor side after attending chat in chat module : "+e);
		}
		return false;
	}

    //Chat reply
	private static boolean chatReply(WebDriver driver)
	{
		try
		{
            driver = driver1;

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			String agentmsg = "Agent Text";
			driver.findElement(By.cssSelector("[onmouseout*='WindowHandler.exist[0].disableClose()']")).click();
			By b = By.cssSelector("[onkeydown*='return WindowHandler.exist[0].handleKeyDwnEvent']");
			driver.findElement(By.cssSelector("[onkeydown*='return WindowHandler.exist[0].handleKeyDwnEvent']")).click();
			driver.findElement(By.cssSelector("[onkeydown*='return WindowHandler.exist[0].handleKeyDwnEvent']")).sendKeys(agentmsg);
			driver.findElement(By.cssSelector("[onkeydown*='return WindowHandler.exist[0].handleKeyDwnEvent']")).sendKeys(Keys.RETURN);
			Thread.sleep(4000);

			driver.navigate().refresh();

			Thread.sleep(10000);
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgtablediv")));

			WebElement elmt = driver.findElement(By.id("msgtablediv"));
			WebElement elmt1 = elmt.findElements(By.tagName("table")).get(1);
			WebElement elmt3 = elmt1.findElement(By.className("msgtxt"));

			Thread.sleep(1000);
			if(agentmsg.equals(elmt3.getText()))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT100")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatReplyFromAgentSide","MismatchContent:"+agentmsg);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatReplyFromAgentSide","Error",e);

            System.out.println("Exception while sending chat reply in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatReplyFromAgentSide","Error",e);

            System.out.println("Exception while sending chat reply in chat module : "+e);
		}
		return false;
	}

    //check reply message
	private static boolean checkReplyMessageOnVisitorSide(WebDriver driver)
	{
		try
		{
            driver = visDriver;
            
			Thread.sleep(3000);

			String agentmsg = "Agent Text";

			WebElement elmt = driver.findElement(By.id("msgdiv")).findElement(By.className("agntcont")).findElement(By.className("msg"));

			if((elmt.getText()).contains(agentmsg))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT22")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatReplyFromVisitorSide","MismatchContent:"+agentmsg);
            }
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatReplyFromVisitorSide","Error",e);

            System.out.println("Exception while checking reply message on visitor side in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatReplyFromVisitorSide","Error",e);

            System.out.println("Exception while checking reply message on visitor side in chat module : "+e);
		}
		return false;
	}

	//check data on agent side
	private static boolean checkReplyMessageOnAgentSide(WebDriver driver)
	{
		try
		{
            driver = visDriver;
			String visitortext = "Visitor replied text";
			Thread.sleep(1000);
			driver.findElement(By.id("lstxteditor")).click();
			driver.findElement(By.id("lstxteditor")).clear();
			driver.findElement(By.id("lstxteditor")).sendKeys(visitortext);
			driver.findElement(By.id("lstxteditor")).sendKeys(Keys.RETURN);

			if((driver.findElement(By.id("msgdiv")).findElement(By.className("vistcont")).findElement(By.className("msg")).getText()).contains(visitortext))
			{
                driver = driver1;

				Thread.sleep(1000);
                WebElement elmt = driver.findElement(By.className("t-v-fcont")).findElement(By.className("t-v-msg"));   //findElement(By.id("gtrans1"))
				Thread.sleep(1000);
				if(visitortext.equals(elmt.getText()))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT23")+" is checked");

                    return true;
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckReplyMessageOnAgentSide","MismatchContent:"+visitortext);
                }
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckReplyMessageOnAgentSide","MismatchContent:"+visitortext);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckReplyMessageOnAgentSide","Error",e);

            System.out.println("Exception while checking reply message on agent side in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckReplyMessageOnAgentSide","Error",e);

            System.out.println("Exception while checking reply message on agent side in chat module : "+e);
		}
		return false;
	}

    //check chats tab
	private static boolean checkChatsTab(WebDriver driver)
	{
		try
		{
			String tabtxt = driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_mycurrent")).getText();
			if(tabtxt.contains(ResourceManager.getRealValue("shortcut_chats")))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT29")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckChatsTab","MismatchContent:"+ResourceManager.getRealValue("shortcut_chats"));
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckChatsTab","Error",e);

            System.out.println("Exception while checking chats tab in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckChatsTab","Error",e);

            System.out.println("Exception while checking chats tab in chat module : "+e);
		}
		return false;
	}

	//check visitors tab
	private static boolean checkVisitorsTab(WebDriver driver)
	{
		try
		{
			String tabtxt = driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_current")).getText();
			if(tabtxt.contains(ResourceManager.getRealValue("common_visitors")))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT30")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorsTab","MismatchContent:"+ResourceManager.getRealValue("common_visitors"));
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorsTab","Error",e);

            System.out.println("Exception while checking visitors tab in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorsTab","Error",e);

            System.out.println("Exception while checking visitors tab in chat module : "+e);
		}
		return false;
	}


	//end chat
	private static boolean endChat(WebDriver driver)
	{
		try
		{
            driver = driver1;

            System.out.println("Exception ---??>>>??:??:>?>??>>??:>?>:>:>111");

                  CommonSikuli.findInWholePage(driver,"Endchat.png","UI96",etest);
			driver.findElement(By.id("endsession")).click();
                  Thread.sleep(1500);
			driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_endimd"))).click();

			Thread.sleep(5000);
			etest.log(Status.PASS,"End chat is checked");

            return true;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChat","Error",e);

            System.out.println("Exception while ending chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChat","Error",e);

            System.out.println("Exception while ending chat in chat module : "+e);
		}
		return false;
	}

    //agent chat end window
	private static boolean agentChatEndWindow(WebDriver driver)
	{
		try
		{
            System.out.println("Exception ---??>>>??:??:>?>??>>??:>?>:>:>222");

			WebElement elmt = driver.findElement(By.id("infodiv"));

            System.out.println("Exception ---??>>>??:??:>?>??>>??:>?>:>:>2222");

			if(ResourceManager.getRealValue("chatsessionendtext").equals(elmt.findElement(By.tagName("h1")).getText()))
			{
                System.out.println("Exception ---??>>>??:??:>?>??>>??:>?>:>:>22222");
				List<WebElement> elmts = elmt.findElement(By.className("grayish")).findElements(By.tagName("a"));

                String value1 = elmts.get(0).getText();
                String value2 = elmts.get(1).getText();
				if((ResourceManager.getRealValue("chatsessionendopt1").equals(value1)) && (ResourceManager.getRealValue("chatsessionendopt2").equals(value2)))
				{
                    System.out.println("Exception ---??>>>??:??:>?>??>>??:>?>:>:>2222222");
					driver.findElement(By.linkText(ResourceManager.getRealValue("closewindow"))).click();
                    System.out.println("Exception ---??>>>??:??:>?>??>>??:>?>:>:>22223231");
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT24")+" is checked");

                    return true;
				}
                else{
                    etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("chatsessionendopt1")+"--"+ResourceManager.getRealValue("chatsessionendopt2")+"--Actual"+value1+"--"+value2+"--");
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAgentChatWindowAfterEndSession","MismatchContent");
                }
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAgentChatWindowAfterEndSession","MismatchContent:"+ResourceManager.getRealValue("chatsessionendtext"));
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAgentChatWindowAfterEndSession","Error",e);

            System.out.println("Exception while checking agent chat end window in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAgentChatWindowAfterEndSession","Error",e);

            System.out.println("Exception while checking agent chat end window in chat module : "+e);
		}
		return false;
	}

	//visitor chat end window
	private static boolean visitorChatEndWindow(WebDriver driver)
	{
		try
		{
			Thread.sleep(1000);
			
            driver = visDriver;

			Thread.sleep(2000);
			//driver.findElement(By.id("fedbckinfotxtid")).click();
			//driver.findElement(By.id("fedbckinfotxtid")).getAttribute("class");
                  CommonSikuli.findInWholePage(driver,"Visitorfeedback.png","UI108",etest);
                  CommonSikuli.findInWholePage(driver,"Visitorstartchat.png","UI109",etest);
                  CommonSikuli.findInWholePage(driver,"Visitoremailtranscript.png","UI110",etest);
                  
            driver.findElement(By.id("submitfeedback")).click();
			driver.findElement(By.id("fedbckinfotxtid")).getAttribute("class");
			//driver.findElement(By.id("fdbckdiv")).click();
            driver.findElement(By.id("fdbckdiv")).findElement(By.id("ratingul")).findElement(By.className("three")).findElement(By.tagName("a")).click();

			Thread.sleep(1000);
			etest.log(Status.PASS,KeyManager.getRealValue("CHAT25")+" is checked");

            return true;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorChatWindowAfterEndSession","Error",e);

            System.out.println("Exception while checking visitor chat end window in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorChatWindowAfterEndSession","Error",e);

            System.out.println("Exception while checking visitor chat end window in chat module : "+e);
		}
		return false;
	}

	//Agent rating
	private static boolean feedbackAndRating(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("fdbckdiv")).findElement(By.id("ratingul")).findElement(By.className("three")).findElement(By.tagName("a")).click();
			Thread.sleep(1000);
			feedbackmsg = "Feedback message "+System.currentTimeMillis();
			WebElement elmt = driver.findElement(By.id("sprwinact")).findElement(By.id("txtmsg"));
            elmt.click();
            elmt.clear();
            elmt.sendKeys(feedbackmsg);
            Thread.sleep(1000);
            driver.findElement(By.id("btnsavefeedback")).click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sprwinact")));
			if(ResourceManager.getRealValue("feedback_message").equals(driver.findElement(By.id("sprwinact")).findElement(By.id("fdbksdiv")).getText()))
			{
                System.out.println("OMG here");
				driver = driver1;;wait = CommonUtil.waitreturner(driver,30,250);
				Thread.sleep(4000);
				driver.findElement(By.id("maincontainer")).findElement(By.id("menu_portal")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_feedback")).findElement(By.tagName("a")).click();
				Thread.sleep(1000);
				List<WebElement> elmts = driver.findElement(By.id("feedbacklist")).findElements(By.tagName("tr"));
				WebElement message = elmts.get(1).findElement(By.className("thrd-clm"));
				WebElement rating = elmts.get(1).findElement(By.className("four-clm"));
				if((feedbackmsg.equals(message.findElement(By.tagName("pre")).getText())) && (("fb_star star-3").equals(rating.findElements(By.tagName("div")).get(1).getAttribute("class"))))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT26")+" is checked");

                    return true;
				}
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","VisitorFeedbackAndRating","MismatchContent:"+feedbackmsg+","+"Rating-Class:fb_star star-3");
            }
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","VisitorFeedbackAndRating","MismatchContent:"+ResourceManager.getRealValue("feedback_message"));
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","VisitorFeedbackAndRating","Error",e);

            System.out.println("Exception while sending feedback and rating in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","VisitorFeedbackAndRating","Error",e);

            System.out.println("Exception while sending feedback and rating in chat module : "+e);
		}
		return false;
	}

    //clear visitors
	private static void checkAndClearVisitors(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver = driver1;;wait = CommonUtil.waitreturner(driver,30,250);

			driver.navigate().refresh();

            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("supportmenulist")));

            Thread.sleep(8000);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_current")).findElement(By.tagName("a")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_current")).findElement(By.tagName("a")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("historylist")).findElements(By.tagName("tr")).get(1).click();
			Thread.sleep(1000);
			driver.findElement(By.id("leftcontainer")).findElement(By.id("current_div")).findElement(By.id("innerheader")).findElements(By.tagName("span")).get(0).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgtablediv")));

			driver.findElement(By.id("endsession")).click();
            Thread.sleep(500);
			driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_endimd"))).click();
			Thread.sleep(4000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("closewindow"))).click();
			Thread.sleep(1000);
		}
        catch(NoSuchElementException e)
        {
            //System.out.println("Exception while checking and clearing visitors in chat module : "+e);
        }
		catch(Exception e)
        {
            //System.out.println("Exception while checking and clearing visitors in chat module : "+e);
        }
	}

	//initiate chat
	private static void initiateChat(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			Thread.sleep(2000);

			driver.findElement(By.id("name")).clear();
			driver.findElement(By.id("name")).sendKeys("Anand R");
			driver.findElement(By.id("email")).clear();
			driver.findElement(By.id("email")).sendKeys("rajkumar.natarajan+2@zohocorp.com");
			driver.findElement(By.id("selecteddept")).click();
			driver.findElement(By.xpath(".//li[@uniname='Automation']")).click();
			driver.findElement(By.id("question")).click();
			driver.findElement(By.id("question")).sendKeys("Hai there ?!");
            TakeScreenshot.screenshot(driver,etest,"ChatWindow","InitiateChat","Before",0);
			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(1000);
            TakeScreenshot.screenshot(driver,etest,"ChatWindow","InitiateChat","After",0);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("timersvg")));
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","InitiateChat","Error",e);

            System.out.println("Exception while initiating chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","InitiateChat","Error",e);

            System.out.println("Exception while initiating chat in chat module : "+e);
		}
	}

    //join chat
	private static boolean joinChat(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_current")).findElement(By.tagName("a")).click();
			Thread.sleep(1000);
                  CommonSikuli.findInWholePage(driver,"Connectedlogo.png","UI97",etest);
			driver.findElement(By.id("historylist")).findElements(By.tagName("tr")).get(1).click();
			Thread.sleep(1000);
                  //commonIconsVerify(driver);System.out.println("Connected tab Verified");
                  commonIconsVerifyinConnctedtab(driver);
            WebElement e = driver.findElement(By.id("leftcontainer")).findElement(By.id("current_div")).findElement(By.id("innerheader")).findElement(By.xpath("//span[contains(text(),'Join')]"));

            if(!e.getText().equals("Join"))
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","JoinChat","Join Is Not Present");
                return false;
            }
            e.click();
			Thread.sleep(1000);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgtablediv")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("msgtablediv")));
			etest.log(Status.PASS,KeyManager.getRealValue("CHAT34")+" is checked");

            return true;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","JoinChat","Error",e);

            System.out.println("Exception while joining chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","JoinChat","Error",e);

            System.out.println("Exception while joining chat in chat module : "+e);
		}
		return false;
	}

	//end chat visitor side
	private static boolean endChatVisSide(WebDriver driver)
	{
		try
		{
			driver = visDriver;

			Thread.sleep(1000);
			driver.findElement(By.id("optionbtn")).click();
            Thread.sleep(500);
			driver.findElement(By.id("options")).findElement(By.className("endcht")).click();
			Thread.sleep(1000);

			driver = driver1;
            etest.log(Status.PASS,KeyManager.getRealValue("CHAT102")+" is checked");

            return true;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChatVisitorSide","Error",e);

            System.out.println("Exception while ending chat in visitor side in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChatVisitorSide","Error",e);

            System.out.println("Exception while ending chat in visitor side in chat module : "+e);
		}
		return false;
	}

	//add note
	private static void addNote(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT46", false);
			result.put("CHAT47", false);
			result.put("CHAT48", false);
			try
			{
                driver.findElement(By.id("infodiv")).findElement(By.className("grayish")).findElement(By.id("notes")).click();
                etest.log(Status.PASS,KeyManager.getRealValue("CHAT46")+" is checked");

                result.put("CHAT46", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT46"),"Error",e);

                result.put("CHAT46", false);
            }
			//WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("notetxt")));

			driver.findElement(By.id("notetxt")).click();
			driver.findElement(By.id("notetxt")).clear();
			driver.findElement(By.id("notetxt")).sendKeys("Notes added for the chat");

			Thread.sleep(500);
			driver.findElement(By.id("addnotes")).findElement(By.className("rg-button")).click();
			Thread.sleep(1000);

			etest.log(Status.PASS,KeyManager.getRealValue("CHAT47")+" is checked");

            result.put("CHAT47", true);

			WebElement container = driver.findElement(By.id("nlcontainer"));
			String notes = container.findElement(By.className("nots-msg")).getText();
			String msg = container.findElement(By.className("nots-submsg")).getText();

			if((notes.equals(ResourceManager.getRealValue("common_notedagemtby")+" "+user)) && (msg.equals("Notes added for the chat")))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT48")+" is checked");

                result.put("CHAT48", true);
			}
            else{
                etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("common_notedagemtby")+" "+user+"--"+"Notes added for the chat--Actual:"+notes+"--"+msg+"--");
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT48"),"MismatchContent");
            }
			driver.findElement(By.id("chatcusactions")).findElement(By.id("selsubtab")).findElement(By.id("chat")).findElement(By.tagName("a")).click();
			Thread.sleep(1000);
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddNotes","Error",e);

            System.out.println("Exception while adding note in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddNotes","Error",e);

            System.out.println("Exception while adding note in chat module : "+e);
		}
	}

	//click close this window
	private static boolean closeThisWindow(WebDriver driver)
	{
		try
		{
            driver = driver1;

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("closewindow"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("closewindow"))).click();

            Thread.sleep(2000);

		etest.log(Status.PASS,"Chat Window is closed by Agent");

            return true;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ClickCloseWindowOnAgentSide","Error",e);

            System.out.println("Exception while clicking close this window in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ClickCloseWindowOnAgentSide","Error",e);

            System.out.println("Exception while clicking close this window in chat module : "+e);
		}
		return false;
	}

    //end chat with timer
	private static boolean endChatWithTimer(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			driver.findElement(By.id("endsession")).click();
            Thread.sleep(2000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_30secs"))).click();
			Thread.sleep(2000);
			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);
			//Thread.sleep(2000);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infomsg")));
            Thread.sleep(1000);

            System.out.println("Wait for Timer switch window");

			if((driver.findElement(By.id("infomsg")).getText()).contains(ResourceManager.getRealValue("endtimertext")))
			{
                System.out.println("Wait for Timer to end");
                Thread.sleep(40000);
                //driver.findElement(By.id("submitfeedback")).click();
                //driver.findElement(By.id("fedbckinfotxtid")).click();
                driver = driver1;;wait = CommonUtil.waitreturner(driver,30,250);

                etest.log(Status.PASS,KeyManager.getRealValue("CHAT103")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChatWithTimer","MismatchContent:"+ResourceManager.getRealValue("endtimertext"));
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChatWithTimer","Error",e);

            System.out.println("Exception while ending chat with timer in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","EndChatWithTimer","Error",e);

            System.out.println("Exception while ending chat with timer in chat module : "+e);
		}
		return false;
	}

    //check History tab
	private static boolean checkHistoryTab(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT49", false);
			result.put("CHAT50", false);
			result.put("CHAT51", false);
			result.put("CHAT52", false);
			result.put("CHAT53", false);
			result.put("CHAT54", false);
			result.put("CHAT55", false);
			result.put("CHAT56", false);
			result.put("CHAT57", false);
			result.put("CHAT58", false);
			result.put("CHAT59", false);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			if(ResourceManager.getRealValue("common_history").equals(driver.findElement(By.id("history_div")).findElement(By.id("innerheader")).findElement(By.tagName("h1")).getText()))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT49")+" is checked");

                result.put("CHAT49", true);
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT49"),"MismatchContent:"+ResourceManager.getRealValue("common_history"));
            }
			Thread.sleep(1000);

			WebElement actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions"));
			Thread.sleep(1000);

			try
			{
				WebElement assignedtome = driver.findElement(By.id("divhismysupport"));
				if(ResourceManager.getRealValue("history_assignedtome").equals(assignedtome.findElement(By.className("sptchkbx-txt")).getText()))
				{
					assignedtome.findElement(By.id("hismysupport")).click();
					Thread.sleep(1000);

					if(user.equals(driver.findElement(By.id("fdata")).findElement(By.className("fltrinfotxt")).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT50")+" is checked");

                        result.put("CHAT50", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT50"),"MismatchContent:"+user);
                    }
					assignedtome.findElement(By.id("hismysupport")).click();
					Thread.sleep(1000);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT50"),"MismatchContent+"+ResourceManager.getRealValue("history_assignedtome"));
                }
			}
			catch(Exception e){
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT50"),"Error",e);
            }
			try
			{

				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.className("combotitle")).click();
				Thread.sleep(500);
				List<WebElement> actns = driver.findElement(By.id("expdrpdowncntnt")).findElements(By.tagName("li"));
				if(actns.size() == 2)
				{
                    String value1 = actns.get(0).findElement(By.tagName("div")).getText();
                    String value2 = actns.get(1).findElement(By.tagName("div")).getText();
					if((ResourceManager.getRealValue("exportexcel").equals(value1)) && (ResourceManager.getRealValue("exportcsv").equals(value2)))
					{
					   	etest.log(Status.PASS,KeyManager.getRealValue("CHAT51")+" is checked");

                        result.put("CHAT51", true);
					}
                    else{
                        etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("exportexcel")+"--"+ResourceManager.getRealValue("exportcsv")+"--Actual:"+value1+"--"+value2+"--");
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT51"),"MismatchContent");
                    }
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT51"),"MismatchActionsCount");
                }
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.className("combotitle")).click();
			}
			catch(Exception e){
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT51"),"Error",e);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("cushistoryfilter")).findElement(By.tagName("span")).click();
				wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("ul")));
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT53")+" is checked");
                result.put("CHAT53", true);
				WebElement list = driver.findElement(By.tagName("ul"));
				try{
					WebElement elmt = driver.findElement(By.id("sagent"));
					if(ResourceManager.getRealValue("filter_user").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("sagent")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT54")+" is checked");

                        result.put("CHAT54", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT51"),"MismatchContent:"+ResourceManager.getRealValue("filter_user"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT51"),"Error",e);
                }

				try{
					WebElement elmt = driver.findElement(By.id("vstatus"));
					if(ResourceManager.getRealValue("filter_status").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("vstatus")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT55")+" is checked");

                        result.put("CHAT55", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT55"),"MismatchContent:"+ResourceManager.getRealValue("filter_status"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT55"),"Error",e);
                }
				try{
					WebElement elmt = driver.findElement(By.id("vdeptid"));
					if(ResourceManager.getRealValue("filter_department").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("vdeptid")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT56")+" is checked");

                        result.put("CHAT56", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT56"),"MismatchContent:"+ResourceManager.getRealValue("filter_department"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT56"),"Error",e);
                }
				try{
					WebElement elmt = driver.findElement(By.id("lsid"));
					if(ResourceManager.getRealValue("filter_embed").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("lsid")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT57")+" is checked");

                        result.put("CHAT57", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT57"),"MismatchContent:"+ResourceManager.getRealValue("filter_embed"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT57"),"Error",e);
                }
				try{
					WebElement elmt = driver.findElement(By.id("timekey"));
					if(ResourceManager.getRealValue("filter_date").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("timevalue")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT58")+" is checked");

                        result.put("CHAT58", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT58"),"MismatchContent:"+ResourceManager.getRealValue("filter_date"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT58"),"Error",e);
                }
				try{
					WebElement elmt = driver.findElement(By.id("vintegstatus"));
					if(ResourceManager.getRealValue("filter_integ").equals(elmt.findElements(By.className("txtaln")).get(0).getText()))
					{
						driver.findElement(By.id("vintegstatus")).click();
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT59")+" is checked");

                        result.put("CHAT59", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT59"),"MismatchContent:"+ResourceManager.getRealValue("filter_integ"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT59"),"Error",e);
                }
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("cushistoryfilter")).click();
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT53"),"Error",e);
            }

			WebElement history = history_content.findElement(By.id("historylist"));
			Thread.sleep(1000);
			try
			{
				WebElement header = history.findElement(By.className("un-sel"));
				String header1 = header.findElement(By.className("secnd-clm")).findElement(By.tagName("div")).getText();
				String header2 = header.findElement(By.className("thrd-clm")).findElement(By.tagName("div")).getText();
				String header3 = header.findElement(By.className("four-clm")).findElement(By.tagName("div")).getText();
				if((ResourceManager.getRealValue("history_nameemail").equals(header1)) && (ResourceManager.getRealValue("history_questime").equals(header2)) && (ResourceManager.getRealValue("history_owner").equals(header3)))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT52")+" is checked");

                    result.put("CHAT52", true);
				}
                else{
                    etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("history_nameemail")+","+ResourceManager.getRealValue("history_questime")+","+ResourceManager.getRealValue("history_owner")+"--Actual"+header1+"--"+header2+"--"+header3+"--");
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT52"),"MismatchContent");
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT52"),"Error",e);
            }
			List<WebElement> tr = history.findElements(By.className("cursr-point"));

			for(int i=0;i<tr.size();i++)
			{
				WebElement scolumn = tr.get(i).findElement(By.className("secnd-clm"));
				WebElement column = tr.get(i).findElement(By.className("thrd-clm"));
				Thread.sleep(1000);
				if(("Anand R".equals(scolumn.findElement(By.tagName("h2")).findElement(By.tagName("a")).getText())) && ("rajkumar.natarajan+2@zohocorp.com".equals(scolumn.findElement(By.tagName("div")).getText())))
				{
					if((visitorid.equals(column.findElement(By.className("grayee")).findElement(By.tagName("span")).getText())) && ((column.findElement(By.className("grayee")).getText()).contains("Hai there ?!")))
					{
						if(time.equals(column.findElement(By.className("grayish")).findElements(By.tagName("span")).get(0).getText()))
						{
							etest.log(Status.PASS,KeyManager.getRealValue("CHAT45")+" is checked");

                            return true;
						}
                        else{
                            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckHistoryTab","MismatchContent:"+time);
                        }
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckHistoryTab","MismatchContent:"+visitorid+","+column);
                    }
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckHistoryTab","MismatchContent:"+"Anand R"+","+"rajkumar.natarajan+2@zohocorp.com");
                }
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckHistoryTab","Error",e);

            System.out.println("Exception while checking history tab in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckHistoryTab","Error",e);

            System.out.println("Exception while checking history tab in chat module : "+e);
		}
		return false;
	}

    //end chat with timer immediate
	private static boolean endChatWithTimerImd(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            driver.findElement(By.id("endsession")).click();
            Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_30secs"))).click();
            Thread.sleep(2000);
            driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infomsg")));
            Thread.sleep(1000);
            System.out.println("Click timer switch window");

			if((driver.findElement(By.id("infomsg")).getText()).contains(ResourceManager.getRealValue("endtimertext")))
			{
                System.out.println("Click timer and end now");
				driver.findElement(By.id("infomsg")).findElements(By.tagName("a")).get(1).click();
				Thread.sleep(1000);
                driver.findElement(By.id("fdbckdiv")).findElement(By.id("ratingul")).findElement(By.className("three")).findElement(By.tagName("a")).click();
				driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

				etest.log(Status.PASS,KeyManager.getRealValue("CHAT104")+"is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT104"),"MismatchContent:"+ResourceManager.getRealValue("endtimertext"));
            }
        }
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT104"),"Error",e);

            System.out.println("Exception while checking end chat with timer immediate in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT104"),"Error",e);

            System.out.println("Exception while checking end chat with timer immediate in chat module : "+e);
		}
		return false;
	}

    //check chat action drop down
	private static void checkChatActions(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT60", false);
			result.put("CHAT61", false);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leftnav")));

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			history_content.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0).click();
			Thread.sleep(1000);
			try
			{
                        WebElement actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("selsubtab"));
				//CommonSikuli.findInWholePage(driver,"Notes.png","UI25",etest);
                        commonIconsVerifyinChatHistorytab(driver);
                        actions.findElement(By.id("notes")).findElement(By.tagName("a")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addnotes")));

				actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("selsubtab"));
                        //CommonSikuli.findInWholePage(driver,"Chatinfo.png","UI29",etest);

                        actions.findElement(By.id("info")).findElement(By.tagName("a")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdiv")));

				actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("selsubtab"));
				actions.findElement(By.id("chat")).findElement(By.tagName("a")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("displaydata")));

				etest.log(Status.PASS,KeyManager.getRealValue("CHAT60")+" is checked");

                result.put("CHAT60", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT60"),"Error",e);
            }
			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
				WebElement list = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("ulcontainer")).findElement(By.tagName("ul"));
				Thread.sleep(1000);

				if(((ResourceManager.getRealValue("actions_print")).equals(list.findElement(By.id("print")).getText())) && ((ResourceManager.getRealValue("actions_pdf")).equals(list.findElement(By.id("pdf")).getText())) && ((ResourceManager.getRealValue("actions_mail")).equals(list.findElement(By.id("sendmail")).getText())) && ((ResourceManager.getRealValue("actions_history")).equals(list.findElement(By.id("pastchat")).getText())))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT60")+" is checked");

                    result.put("CHAT61", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT61"),"MismatchContent:"+ResourceManager.getRealValue("actions_print")+","+ResourceManager.getRealValue("actions_pdf")+","+ResourceManager.getRealValue("actions_history"));
                }
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT61"),"Error",e);
            }

		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatActionsDropDown","Error",e);

            System.out.println("Exception while checking chat actions in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatActionsDropDown","Error",e);

            System.out.println("Exception while checking chat actions in chat module : "+e);
		}
	}

    //check add note tab
	private static void checkAddNoteTab(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT62", false);
			result.put("CHAT63", false);
			result.put("CHAT64", false);
			result.put("CHAT65", false);
			result.put("CHAT66", false);
			result.put("CHAT67", false);
			result.put("CHAT68", false);

            driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			Thread.sleep(1000);
			history_content.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0).click();
			Thread.sleep(1000);
			WebElement actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("selsubtab"));
			actions.findElement(By.id("notes")).findElement(By.tagName("a")).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addnotes")));

			try
			{
				WebElement hisdiv = driver.findElement(By.id("history_div"));
                WebElement header = hisdiv.findElement(By.id("innerheader")).findElement(By.className("bcrumbs"));
                String txt1 = header.findElement(By.tagName("a")).getText();
                String txt2 = header.findElement(By.tagName("span")).getText();
                if((txt1.equals(ResourceManager.getRealValue("common_history"))) && (txt2.equals("Anand R's "+ResourceManager.getRealValue("common_hnotes"))))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CHAT62")+" is checked");

                    result.put("CHAT62", true);
                }
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT62"),"MismatchContent:"+ResourceManager.getRealValue("common_history")+","+ResourceManager.getRealValue("common_hnotes"));
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT62"),"Error",e);
            }

			try
			{
				WebElement notesdiv = driver.findElement(By.id("history_div")).findElement(By.id("displaydata")).findElement(By.id("noteshead"));
				if((ResourceManager.getRealValue("common_hnotetxt")+" Anand R").equals(notesdiv.findElements(By.tagName("h4")).get(0).getText()))
				{
					if((ResourceManager.getRealValue("shortcut_notes")).equals(notesdiv.findElement(By.id("notesbase")).findElements(By.tagName("h4")).get(0).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT63")+" is checked");

                        result.put("CHAT63", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT63"),"MismatchContent:"+ResourceManager.getRealValue("shortcut_notes"));
                    }
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT63"),"MismatchContent:"+ResourceManager.getRealValue("common_hnotetxt")+" Anand R");
                }

				if((ResourceManager.getRealValue("nonotestext")).equals(notesdiv.findElement(By.id("notelist")).findElement(By.className("nts-blnktxt")).getText()))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT64")+" is checked");

                    result.put("CHAT64", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT64"),"MismatchContent:"+ResourceManager.getRealValue("nonotestext"));
                }

				String placeholder = notesdiv.findElement(By.id("addnotes")).findElement(By.id("notetxt")).getAttribute("placeholder");
				if(placeholder.equals(ResourceManager.getRealValue("notesclickhere")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT65")+" is checked");

                    result.put("CHAT65", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT65"),"MismatchContent:"+ResourceManager.getRealValue("notesclickhere"));
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAddNotesTab","Error",e);
            }

			try
			{
				WebElement notesdiv = driver.findElement(By.id("history_div")).findElement(By.id("displaydata")).findElement(By.id("noteshead"));
				WebElement form = notesdiv.findElement(By.id("addnotes"));

				form.findElement(By.id("notetxt")).click();
				form.findElement(By.id("notetxt")).clear();
				form.findElement(By.id("notetxt")).sendKeys("Notes added");

				Thread.sleep(500);
				form.findElement(By.className("rg-button")).click();
				Thread.sleep(1000);

				WebElement container = driver.findElement(By.id("nlcontainer"));
				String notes = container.findElement(By.className("nots-msg")).getText();
				String msg = container.findElement(By.className("nots-submsg")).getText();

				if((notes.equals(ResourceManager.getRealValue("common_notedagemtby")+" "+user)) && (msg.equals("Notes added")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT66")+" is checked");

                    result.put("CHAT66", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT66"),"MismatchContent:"+"Notes added"+","+ResourceManager.getRealValue("common_notedagemtby"));
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT66"),"Error",e);
            }

			try
			{
				WebElement notesdiv = driver.findElement(By.id("history_div")).findElement(By.id("displaydata")).findElement(By.id("noteshead"));
				notesdiv.findElement(By.id("addnotes")).findElement(By.className("actionbtn-base")).findElement(By.tagName("a")).click();
				Thread.sleep(1000);

				if("tarea".equals(driver.findElement(By.id("history_div")).findElement(By.id("displaydata")).findElement(By.id("noteshead")).findElement(By.id("addnotes")).findElement(By.id("notetxt")).getAttribute("class")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT67")+" is checked");

                    result.put("CHAT67", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT67"),"MismatchContent:"+"Id-notetxt -> classname-tarea");
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT67"),"Error",e);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("oprdiv")).findElement(By.className("sptrep-info")).findElement(By.id("userimage")).click();
				Thread.sleep(500);
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT68")+" is checked");

                result.put("CHAT68", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT68"),"Error",e);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAddNotesAndTab","Error",e);

            System.out.println("Exception while checking add note tab in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckAddNotesAndTab","Error",e);

            System.out.println("Exception while checking add note tab in chat module : "+e);
		}
	}

    //check visitor information
	private static void checkVisitorInfo(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT82", false);
			result.put("CHAT83", false);
			result.put("CHAT84", false);
			result.put("CHAT85", false);
			result.put("CHAT86", false);
			result.put("CHAT87", false);
			result.put("CHAT88", false);
			result.put("CHAT89", false);
			result.put("CHAT90", false);
			result.put("CHAT91", false);
			result.put("CHAT92", false);
			result.put("CHAT93", false);
			result.put("CHAT94", false);
			result.put("CHAT95", false);
			result.put("CHAT96", false);
			result.put("CHAT97", false);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			history_content.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0).click();
			Thread.sleep(1000);
			WebElement actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("selsubtab"));
			actions.findElement(By.id("info")).findElement(By.tagName("a")).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("displaydata")));

			try
			{
				WebElement hisdiv = driver.findElement(By.id("history_div"));
                WebElement header = hisdiv.findElement(By.id("innerheader")).findElement(By.className("bcrumbs"));
                String txt1 = header.findElement(By.tagName("a")).getText();
                String txt2 = header.findElement(By.tagName("span")).getText();
                if((txt1.equals(ResourceManager.getRealValue("common_history"))) && (txt2.equals("Anand R's "+ResourceManager.getRealValue("common_hinfo"))))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CHAT82")+" is checked");

                    result.put("CHAT82", true);
                }
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT82"),"MismatchContent:"+ResourceManager.getRealValue("common_history")+","+ResourceManager.getRealValue("common_hinfo"));
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT82"),"Error",e);
            }

			try
			{
				WebElement elmt = driver.findElement(By.id("history_div")).findElement(By.id("displaydata"));
				List<WebElement> infohead = elmt.findElements(By.className("section"));
				try
				{
					if((ResourceManager.getRealValue("his_visitorinfo")).equals(infohead.get(0).findElement(By.tagName("h4")).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT83")+" is checked");

                        result.put("CHAT83", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT83"),"MismatchContent:"+ResourceManager.getRealValue("his_visitorinfo"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT83"),"Error",e);
                }
				try{
					if((ResourceManager.getRealValue("his_time")).equals(infohead.get(1).findElement(By.tagName("h4")).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT84")+" is checked");

                        result.put("CHAT84", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT84"),"MismatchContent:"+ResourceManager.getRealValue("his_time"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT84"),"Error",e);
                }
				try{
					if((infohead.get(2).findElement(By.tagName("h4")).getText()).contains(ResourceManager.getRealValue("his_location")))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT85")+" is checked");

                        result.put("CHAT85", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT85"),"MismatchContent:"+ResourceManager.getRealValue("his_location"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT85"),"Error",e);
                }
				try{
					if((ResourceManager.getRealValue("his_browser")).equals(infohead.get(3).findElement(By.tagName("h4")).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT86")+" is checked");

                        result.put("CHAT86", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT86"),"MismatchContent:"+ResourceManager.getRealValue("his_browser"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT86"),"Error",e);
                }
				try{
					if((ResourceManager.getRealValue("his_system")).equals(infohead.get(4).findElement(By.tagName("h4")).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT87")+" is checked");

                        result.put("CHAT87", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT87"),"MismatchContent:"+ResourceManager.getRealValue("his_system"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT87"),"Error",e);
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckHistoryData","Error",e);
            }
			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("oprdiv")).findElement(By.className("sptrep-info")).findElement(By.id("userimage")).click();
				Thread.sleep(500);
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT88")+" is checked");

                result.put("CHAT88", true);
			}
            catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT88"),"Error",e);
            }

			try
			{
				WebElement elmt = driver.findElement(By.id("history_div")).findElement(By.id("displaydata"));
				List<WebElement> data = elmt.findElements(By.className("section")).get(0).findElement(By.tagName("table")).findElements(By.tagName("tr"));
				try
				{
					List<WebElement> td = data.get(0).findElements(By.tagName("td"));

                    String value1 = td.get(0).getText();
                    String value2 = td.get(1).getText();

					if((ResourceManager.getRealValue("info_visitorid").equals(value1)) && (visitorid.contains(value2)))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT89")+" is checked");

                        result.put("CHAT89", true);
					}
                    else{
                        etest.log(Status.FAIL,"Expected"+ResourceManager.getRealValue("info_visitorid")+"--"+visitorid+"--Actual"+value1+"--"+value2+"--");
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT89"),"MismatchContent");
                    }
					if((ResourceManager.getRealValue("common_name").equals(td.get(2).getText())) && ("Anand R".equals(td.get(3).getText())))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT90")+" is checked");

                        result.put("CHAT90", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT90"),"MismatchContent:"+ResourceManager.getRealValue("common_name")+","+"Anand R");
                    }

				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT89")+" and "+KeyManager.getRealValue("CHAT90"),"Error",e);
                }
				try
				{
					List<WebElement> td = data.get(1).findElements(By.tagName("td"));
					if((ResourceManager.getRealValue("info_email").equals(td.get(0).getText())) && ("rajkumar.natarajan+2@zohocorp.com".equals(td.get(1).getText())))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT91")+" is checked");

                        result.put("CHAT91", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT91"),"MismatchContent:"+ResourceManager.getRealValue("info_email")+","+"rajkumar.natarajan+2@zohocorp.com");
                    }
					if((ResourceManager.getRealValue("info_ques").equals(td.get(2).getText())) && ("Hai there ?!".equals(td.get(3).getText())))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT92")+" is checked");

                        result.put("CHAT92", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT92"),"MismatchContent:"+ResourceManager.getRealValue("info_ques")+","+"Hai there ?!");
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT91")+" and "+KeyManager.getRealValue("CHAT92"),"Error",e);
                }
				try
				{
					List<WebElement> td = data.get(2).findElements(By.tagName("td"));
					if((ResourceManager.getRealValue("setting_department").equals(td.get(0).getText())) && ("Automation".equals(td.get(1).getText())))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT93")+" is checked");

                        result.put("CHAT93", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT93"),"MismatchContent:"+ResourceManager.getRealValue("setting_department")+",Automation");
                    }
					if((EMBED.equals(td.get(2).getText())) && (("chatops").equals(td.get(3).getText())))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT94")+" is checked");

                        result.put("CHAT94", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT94"),"MismatchContent:"+EMBED+",chatops");
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT93")+" and "+KeyManager.getRealValue("CHAT94"),"Error",e);
                }

			}
            catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorInfo","Error",e);
            }
			try
			{
				WebElement elmt = driver.findElement(By.id("history_div")).findElement(By.id("displaydata"));
				List<WebElement> data = elmt.findElements(By.className("section")).get(1).findElement(By.tagName("table")).findElements(By.tagName("tr"));
				try
				{
					List<WebElement> td = data.get(0).findElements(By.tagName("td"));
					String timestr = "";
					if(time.contains("AM"))
					{
						timestr = time.split(" AM")[0].split(":")[0];
						timestr += ":"+time.split(" AM")[0].split(":")[1];
					}
					else
					{
						timestr = time.split(" PM")[0].split(":")[0];
						timestr += ":"+time.split(" PM")[0].split(":")[1];
					}

                    String value1 = td.get(0).getText();
                    String value2 = td.get(1).getText();

					if((ResourceManager.getRealValue("time_chatinitiate").equals(value1)) && ((value2).contains(timestr)))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT95")+" is checked");

                        result.put("CHAT95", true);
					}
                    else{
                        etest.log(Status.FAIL,"Expected"+ResourceManager.getRealValue("time_chatinitiate")+"--"+timestr+"--Actual:"+value1+"--"+value2+"--");
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT95"),"MismatchContent");
                    }
					if(ResourceManager.getRealValue("time_chatansaftr").equals(td.get(2).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT96")+" is checked");

                        result.put("CHAT96", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT96"),"MismatchContent:"+ResourceManager.getRealValue("time_chatansaftr"));
                    }

				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT95")+" and "+KeyManager.getRealValue("CHAT96"),"Error",e);
                }
				try
				{
					List<WebElement> td = data.get(1).findElements(By.tagName("td"));
					if(ResourceManager.getRealValue("time_chatduration").equals(td.get(0).getText()))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT97")+" is checked");

                        result.put("CHAT97", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT97"),"MismatchContent:"+ResourceManager.getRealValue("time_chatduration"));
                    }
				}
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT97"),"Error",e);
                }
			}
            catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorInfoChatContents","Error",e);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorInfo","Error",e);

            System.out.println("Exception while checking visitor info tab in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckVisitorInfo","Error",e);

            System.out.println("Exception while checking visitor info tab in chat module : "+e);
		}
	}

    //check chat tab
	private static void checkChatTab(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT69", false);
			result.put("CHAT70", false);
			//result.put("CHAT71", false);
			result.put("CHAT71", true);		//Change true to false to check proper condition or remove this line and uncomment the previous line for full functionality
			result.put("CHAT72", false);
			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			history_content.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0).click();
			Thread.sleep(1000);
			WebElement actions = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("selsubtab"));
			actions.findElement(By.id("chat")).findElement(By.tagName("a")).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("displaydata")));

			try
			{
				WebElement hisdiv = driver.findElement(By.id("history_div"));
                WebElement header = hisdiv.findElement(By.id("innerheader")).findElement(By.className("bcrumbs"));
                String txt1 = header.findElement(By.tagName("a")).getText();
                String txt2 = header.findElement(By.tagName("span")).getText();
                if((txt1.equals(ResourceManager.getRealValue("common_history"))) && (txt2.equals("Anand R's "+ResourceManager.getRealValue("common_hchat"))))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CHAT69")+" is checked");

                    result.put("CHAT69", true);
                }
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT69"),"MismatchContent:"+ResourceManager.getRealValue("common_history")+","+ResourceManager.getRealValue("common_hchat"));
                }

			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT69"),"Error",e);
            }

			try
			{
				WebElement hisdiv = driver.findElement(By.id("history_mcontent")).findElement(By.id("hdiv"));
				WebElement chat = driver.findElement(By.id("history_div")).findElement(By.id("displaydata")).findElement(By.id("chathead")).findElement(By.id("msgques"));
				WebElement data = chat.findElements(By.tagName("tr")).get(0).findElements(By.tagName("td")).get(1);

                String value1 = data.findElement(By.className("lvst_idtxt")).getText();
                String value2 = data.findElement(By.className("t-v-questionmn")).findElement(By.tagName("h1")).getText();

				if((visitorid.equals(value1)) && (value2.contains("Hai there ?!")))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT70")+" is checked");

                    result.put("CHAT70", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT70"),"MismatchContent:Hai there ?!--"+visitorid+"--Actual"+value2+"--"+value1+"--");
                }
				String timestr = time.split("at ")[1];
                System.out.println((data.findElement(By.className("t-v-questionmn")).findElement(By.className("t-v-subtxt")).getText()));
                System.out.println(timestr+" by Anand R - rajkumar.natarajan+2@zohocorp.com");
				if((data.findElement(By.className("t-v-questionmn")).findElement(By.className("t-v-subtxt")).getText()).equals(timestr+" by Anand R - rajkumar.natarajan+2@zohocorp.com"))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT71")+" is checked");

                    result.put("CHAT71", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT71"),"MismatchContent:"+timestr+" by Anand R - rajkumar.natarajan+2@zohocorp.com");
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT71"),"Error",e);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("oprdiv")).findElement(By.className("sptrep-info")).findElement(By.id("userimage")).click();
				Thread.sleep(500);
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT72")+" is checked");

                result.put("CHAT72", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT72"),"Error",e);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","HistoryChatTabCOntent","Error",e);

            System.out.println("Exception while checking chat tab in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","HistoryChatTabContent","Error",e);

            System.out.println("Exception while checking chat tab in chat module : "+e);
		}
	}

    //check send as mail option in actions
	private static void checkSendAsMail(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT73", false);
			result.put("CHAT74", false);
			result.put("CHAT75", false);
			result.put("CHAT76", false);
			result.put("CHAT77", false);
			result.put("CHAT78", false);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			history_content.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0).click();
			Thread.sleep(1000);

			driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
			WebElement list = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.tagName("ul"));
			list.findElement(By.id("sendmail")).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));

                  CommonSikuli.findInWholePage(driver,"Emailclose.png","UI118",etest);

			etest.log(Status.PASS,KeyManager.getRealValue("CHAT73")+" is checked");

            result.put("CHAT73", true);
			WebElement form = driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm"));

			try
			{
				if((ResourceManager.getRealValue("actions_enteremail")).equals(form.findElement(By.className("modal-header")).findElement(By.tagName("h4")).getText()))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT74")+" is checked");

                    result.put("CHAT74", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT74"),ResourceManager.getRealValue("actions_enteremail"));
                }
			}
			catch(Exception e){
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT74"),"Error",e);

                driver.navigate().refresh();Thread.sleep(4000);
            }

			try
			{
				form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a")).click();
				try
				{
					driver.findElement(By.id("dlgbox")).click();
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT75"),"WindowIsOpenedAfterClickingClose");
				}
				catch(Exception e){
                              driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT75")+" is checked");
                    result.put("CHAT75", true);
				}
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT75"),"Error",e);

                driver.navigate().refresh();Thread.sleep(4000);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
				list = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.tagName("ul"));
				list.findElement(By.id("sendmail")).click();

				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));

				form = driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm"));
				form.findElement(By.className("actionbtn-base")).findElements(By.className("cnfmbtm")).get(1).click();
				try
				{
					driver.findElement(By.id("dlgbox")).click();
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT76"),"WindowIsOpenedAfterClickingCancel");
				}
				catch(Exception e){
                              driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT76")+" is checked");
                    result.put("CHAT76", true);
				}
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT76"),"Error",e);

                driver.navigate().refresh();Thread.sleep(4000);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
				list = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.tagName("ul"));
				list.findElement(By.id("sendmail")).click();

				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));

				form = driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm"));
				driver.findElement(By.id("toemail")).click();
				driver.findElement(By.id("toemail")).clear();
				driver.findElement(By.id("toemail")).sendKeys("rajkumar.natarajan@zohocorp.com");
				form = driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm"));
				form.findElement(By.className("actionbtn-base")).findElements(By.className("cnfmbtm")).get(0).click();
				Tab.waitForLoading(driver,"visdatamail.do",etest);
                etest.log(Status.PASS,KeyManager.getRealValue("CHAT77")+" is checked");
                        driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
				result.put("CHAT77", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT77"),"Error",e);

                driver.navigate().refresh();Thread.sleep(4000);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
				list = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.tagName("ul"));
				list.findElement(By.id("sendmail")).click();

				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));

				form = driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm"));
				driver.findElement(By.id("toemail")).click();
				driver.findElement(By.id("toemail")).clear();
				driver.findElement(By.id("toemail")).sendKeys("rajkumar.natarajan@zohocorp.com");

				driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm")).findElement(By.className("sndmlmn")).findElement(By.tagName("a")).click();

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sendmailfrm")));

				form = driver.findElement(By.id("dlgbox")).findElement(By.id("sendmailfrm"));
				form.findElement(By.className("actionbtn-base")).findElements(By.className("cnfmbtm")).get(0).click();
				Tab.waitForLoading(driver,"visdatamail.do",etest);
                etest.log(Status.PASS,KeyManager.getRealValue("CHAT78")+" is checked");
				result.put("CHAT78", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT78"),"Error",e);

                driver.navigate().refresh();Thread.sleep(4000);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckSentMailDialogBox","Error",e);

            System.out.println("Exception while checking send as mail in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckSentMailDialogBox","Error",e);

            System.out.println("Exception while checking send as mail in chat module : "+e);
		}
	}

    //check past chats
	private static void checkPastHistory(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT79", false);
			result.put("CHAT80", false);
			result.put("CHAT81", false);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_history")).findElement(By.tagName("a")).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

			WebElement history_content = driver.findElement(By.id("history_mcontent"));
			history_content.findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0).click();
			Thread.sleep(1000);

			driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.id("combodiv")).findElement(By.className("combotitle")).click();
			WebElement list = driver.findElement(By.id("history_div")).findElement(By.id("cusactions")).findElement(By.tagName("ul"));
			list.findElement(By.id("pastchat")).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

                  CommonSikuli.findInWholePage(driver,"Historydept.png","UI123",etest);
                  CommonSikuli.findInWholePage(driver,"Historyportal.png","UI124",etest);


			try
			{
				WebElement hisdiv = driver.findElement(By.id("history_div"));
                WebElement header = hisdiv.findElement(By.id("innerheader")).findElement(By.className("bcrumbs"));
                String txt1 = header.findElement(By.tagName("a")).getText();
                String txt2 = header.findElements(By.tagName("a")).get(1).getText();
                String txt3 = header.findElement(By.tagName("span")).getText();
                if((txt1.equals(ResourceManager.getRealValue("common_history"))) && (txt2.equals("Anand R's")) && (txt3.equals(ResourceManager.getRealValue("actions_history"))))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CHAT79")+" is checked");

                    result.put("CHAT79", true);
                }
                else{
                    etest.log(Status.FAIL,"Expected"+ResourceManager.getRealValue("common_history")+"--"+ResourceManager.getRealValue("actions_history")+"--Anand R's--Actual:"+txt1+"--"+txt2+"--"+txt3+"--");
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT79"),"MismatchContent");
                }
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT79"),"Error",e);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("displaydata")).findElement(By.className("pasthst")).findElements(By.tagName("li")).get(1).click();
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("pcsubtab")));
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT80")+" is checked");
                result.put("CHAT80", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT80"),"Error",e);
            }

			try
			{
				driver.findElement(By.id("history_div")).findElement(By.id("oprdiv")).findElement(By.className("sptrep-info")).findElement(By.id("userimage")).click();
				Thread.sleep(500);
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT81")+" is checked");
                result.put("CHAT81", true);
			}
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT81"),"Error",e);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckchatHistory","Error",e);

            System.out.println("Exception while checking chat history in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","CheckchatHistory","Error",e);

            System.out.println("Exception while checking chat history in chat module : "+e);
		}
	}

    //chat initiate with no name and no email
	private static boolean initiateChatNoNameEmail(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			String question = "Hai der?";
			driver.findElement(By.id("selecteddept")).click();
			driver.findElement(By.xpath(".//li[@uniname='Automation']")).click();
			driver.findElement(By.id("question")).click();
			driver.findElement(By.id("question")).sendKeys(question);
			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("timersvg")));

			acceptChat1(driver);

			driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leftcontainer")));

            System.out.println("User Name : "+driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText());

			if((driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText()).contains("Anand R"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT35")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT35"),"MismatchContent:"+"Anand R");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT35"),"Error",e);

            System.out.println("Exception while initiating chat with no name and email in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT35"),"Error",e);

            System.out.println("Exception while initiating chat with no name and email in chat module : "+e);
		}
		return false;
	}

    //chat with no name and with email
	private static boolean initiateChatNoName(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			String question = "Hai der?";
			driver.findElement(By.id("email")).clear();
			driver.findElement(By.id("email")).sendKeys("rajkumar.natarajan@zohocorp.com");
			driver.findElement(By.id("selecteddept")).click();
			driver.findElement(By.xpath(".//li[@uniname='Automation']")).click();
			driver.findElement(By.id("question")).click();
			driver.findElement(By.id("question")).sendKeys(question);
			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("timersvg")));

			acceptChat1(driver);

			driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leftcontainer")));

            System.out.println("Operator Name (No name): "+driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText()+" >>>> ");

			if((driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText()).contains("Rajkumar.Natarajan"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT36")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT36"),"MismatchContent:"+"Rajkumar.Natarajan");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT36"),"Error",e);

            System.out.println("Exception while initiating chat with no name and with email in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT36"),"Error",e);

            System.out.println("Exception while initiating chat with no name and with email in chat module : "+e);
		}
		return false;
	}

    //Chat with no department
	private static boolean chatwithoutDept(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			driver.findElement(By.id("question")).click();
			driver.findElement(By.id("question")).sendKeys("Hai");

			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(1000);

			String classname = driver.findElement(By.id("selecteddept")).getAttribute("class");
			Thread.sleep(1000);

			if(classname.equals("drptxt errorbdr"))
			{
				driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT16")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT16"),"AlertNotFound");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT16"),"Error",e);

            System.out.println("Exception while chatting with no department in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT16"),"Error",e);

            System.out.println("Exception while chatting with no department in chat module : "+e);
		}
		return false;
	}

    //chat without question
	private static boolean chatwithoutQues(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			driver.findElement(By.id("selecteddept")).click();
			driver.findElement(By.xpath(".//li[@uniname='Automation']")).click();

			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(1000);

			String classname = driver.findElement(By.id("question")).getAttribute("class");
			Thread.sleep(1000);

			if(classname.equals("errorbdr"))
			{
				driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT17")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT17"),"AlertIsNotFound");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT17"),"Error",e);

            System.out.println("Exception while chatting without question in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT17"),"Error",e);

            System.out.println("Exception while chatting without question in chat module : "+e);
		}
		return false;
	}

    //chat with department and question alone
	private static boolean chatWithDeptQues(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			String question = "Hai der?";
			driver.findElement(By.id("selecteddept")).click();
			driver.findElement(By.xpath(".//li[@uniname='Automation']")).click();
			driver.findElement(By.id("question")).click();
			driver.findElement(By.id("question")).sendKeys(question);
			driver.findElement(By.id("btnaddvisitor")).click();
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("timersvg")));

			acceptChat1(driver);
            
            driver = driver1;

			if(!(driver.findElement(By.id("msgtablediv")).getAttribute("style")).equals("display: block;"))
			{
				checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT18"),"Error");

                return false;
			}

            try
			{
				if((driver.findElement(By.id("ptitle")).findElement(By.tagName("span")).getText()).contains("Rajkumar.Natarajan"))
				{
					if((driver.findElement(By.className("t-v-subtxt")).getText()).contains("Rajkumar.Natarajan"))
					{
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT18")+" is checked");

                        result.put("CHAT18", true);
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT18"),"MismatchContent:"+"Rajkumar.Natarajan");
                    }
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT18"),"MismatchContentInTitle:Rajkumar.Natarajan");
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT18"),"Error",e);
                result.put("CHAT18", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT18"),"Error",e);
                result.put("CHAT18", false);
            }

			try
			{
				WebElement elmts1 = driver.findElement(By.id("visitordata")).findElement(By.className("rcvstinfotxt"));
				if((elmts1.getText()).contains(dept))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT19")+" is checked");

                    result.put("CHAT19", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT19"),"MismatchContent:"+dept);
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT19"),"Error",e);
                result.put("CHAT19", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT19"),"Error",e);
                result.put("CHAT19", false);
            }

			try
			{
				WebElement elmt2 = driver.findElement(By.id("msgtablediv"));
				List<WebElement> txt = elmt2.findElements(By.className("t-v-questionmn"));

				if((txt.get(0).getText()).contains(question))
				{
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT20")+" is checked");

                    result.put("CHAT20", true);
				}
                else{
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT20"),"MismatchContent:"+ques);
                }
			}
			catch(NoSuchElementException e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT20"),"Error",e);
                result.put("CHAT20", false);
            }
			catch(Exception e)
            {
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT20"),"Error",e);
                result.put("CHAT20", false);
            }
        }
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChattingWithDeptAndQuestionOnly","Error",e);

            System.out.println("Exception while chatting with department and question only in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChattingWithDeptAndQuestionOnly","Error",e);

            System.out.println("Exception while chatting with department and question only in chat module : "+e);
		}
		return false;
	}

    //check ignore chat notification
	private static void checkIgnoreChatNotify(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			result.put("CHAT106", false);
			Thread.sleep(2000);
			driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

            Thread.sleep(2000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));

            //Thread.sleep(1000);
            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wpckup")));

            Thread.sleep(3000);

			driver.findElement(By.id("waitinglist")).findElement(By.id("wcancel")).click();
			Thread.sleep(3000);

			try
			{
				driver.findElement(By.id("waitinglist")).click();
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT106"),"IgnoredChatIsListed");
			}
			catch(Exception e)
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT106")+" is checked");

                result.put("CHAT106", true);
			}

			driver.findElement(By.id("leftnav")).findElement(By.id("suppm_current")).findElement(By.tagName("a")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("historylist")).findElement(By.tagName("table")).findElements(By.tagName("tr")).get(1).click();
			Thread.sleep(1000);
			driver.findElement(By.id("current_div")).findElement(By.id("innerheader")).findElement(By.className("gren-btn")).click();

			Thread.sleep(2000);
			if((driver.findElement(By.id("msgtablediv")).getAttribute("style")).equals("display: block;"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT15")+" is checked");

                result.put("CHAT15", true);
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT15"),"ChatIsNotAccepted");
            }
			visitorid = driver.findElement(By.id("msgtablediv")).findElements(By.className("lvst_idtxt")).get(0).getText();
			String timestr = driver.findElement(By.id("msgtablediv")).findElements(By.className("t-v-subtxt")).get(0).getText();
			time = (timestr.split(" by"))[0];
			time = "Today at "+time;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","IgnoreChatNotify","Error",e);

            System.out.println("Exception while ignoring chat notification in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","IgnoreChatNotify","Error",e);

            System.out.println("Exception while ignoring chat notification in chat module : "+e);
		}
	}

    //adding dynamic canned message to chat
	private static boolean addDynamicCannedMessage(WebDriver driver)
	{
		try
		{
			WebElement textarea = driver.findElement(By.id("txteditor"));
			driver.findElement(By.id("txteditor")).click();
			driver.findElement(By.id("txteditor")).clear();
			driver.findElement(By.id("txteditor")).sendKeys("#Hai");
			Thread.sleep(1000);
			driver.findElement(By.id("comptable")).findElement(By.className("candmsgcnt")).findElement(By.linkText("Hai Anand R, Welcome to SalesIQ")).click();
			textarea.click();
			textarea.sendKeys(Keys.RETURN);
			Thread.sleep(1000);

            if(ChatWindow.checkLastMessageInUserWindow(driver,"","Hai Anand R, Welcome to SalesIQ"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT112")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT112"),"MismatchContent:Hai Anand R, Welcome to SalesIQ");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT112"),"Error",e);

            System.out.println("Exception while adding dynamic canned message with # to chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT112"),"Error",e);

            System.out.println("Exception while adding dynamic canned message with # to chat in chat module : "+e);
		}
		return false;
	}

    //Dynamic canned message - add
	private static boolean addDynamicCannedMessage1(WebDriver driver, String message)
	{
		try
		{
			WebElement textarea = driver.findElement(By.id("txteditor"));
			driver.findElement(By.id("cwincannedmsg")).click();
			driver.findElement(By.linkText(message)).click();
			textarea.click();
			textarea.sendKeys(Keys.RETURN);
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("msgtablediv"));
			WebElement elmt1 = elmt.findElements(By.tagName("table")).get(1);
			WebElement elmt3;
			if(message.equals("Hello Anand R"))
			{
				elmt3 = elmt1.findElements(By.tagName("tr")).get(3);
			}
			else
			{
				elmt3 = elmt1.findElements(By.tagName("tr")).get(1);
			}

			if((elmt3.getText()).contains(message))
			{
				etest.log(Status.PASS,"Add Dynamic canned message is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddDynamicCannedMessage:"+message,"MismatchContent:"+message);
            }
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddDynamicCannedMessage:"+message,"Error",e);

            System.out.println("Exception while adding dynamic canned message through link to chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","AddDynamicCannedMessage:"+message,"Error",e);

            System.out.println("Exception while adding dynamic canned message through link to chat in chat module : "+e);
		}
		return false;
	}

	//add a dynamic canned message and add it to chat window
	private static boolean addDynamicCannedMessage2(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));

			try
			{
				driver.findElement(By.id("showempty")).click();
				Thread.sleep(1000);
				driver.findElement(By.linkText(ResourceManager.getRealValue("canned_message_addbtn"))).click();
				Thread.sleep(1000);
			}
			catch(NoSuchElementException e)
			{
				driver.findElement(By.id("cmsgbtn")).findElement(By.tagName("span")).click();
				Thread.sleep(1000);
			}
			driver.findElement(By.id("cmsg")).click();
			driver.findElement(By.id("cmsg")).clear();
			driver.findElement(By.id("cmsg")).sendKeys("Hello %visitor.name%");
			Thread.sleep(1000);

            String category;
            category = "CheckCategory";
            driver.findElement(By.id("toggle")).click();
            Thread.sleep(1000);
            driver.findElement(By.id("addtxtbox")).click();
            driver.findElement(By.id("addtxtbox")).clear();
            driver.findElement(By.id("addtxtbox")).sendKeys(category);
            Thread.sleep(1000);

			driver.findElement(By.id("btnsubmit")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Canned Message is added Successfully","addcannmsg.do",etest);

			driver.findElement(By.id("leftnav")).findElement(By.id("supportmenulist")).findElement(By.id("suppm_mycurrent")).findElement(By.tagName("a")).click();

			driver.navigate().refresh();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txteditor")));
			Thread.sleep(2000);

			WebElement textarea = driver.findElement(By.id("txteditor"));
			driver.findElement(By.id("txteditor")).click();
			driver.findElement(By.id("txteditor")).clear();
			driver.findElement(By.id("txteditor")).sendKeys("#Hel");
			Thread.sleep(1000);
			driver.findElement(By.id("comptable")).findElement(By.className("candmsgcnt")).findElement(By.linkText("Hello Anand R")).click();
			textarea.click();
			textarea.sendKeys(Keys.RETURN);
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("msgtablediv"));
			WebElement elmt1 = elmt.findElements(By.tagName("table")).get(1);
			WebElement elmt3 = elmt1.findElements(By.tagName("tr")).get(2);

			if((elmt3.getText()).contains("Hello Anand R"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT114")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT114"),"MismatchContent:Hello Anand R");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT114"),"Error",e);

            System.out.println("Exception while adding dynamic canned message during chat and adding it using # in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT114"),"Error",e);

            System.out.println("Exception while adding dynamic canned message during chat and adding it using # in chat module : "+e);
		}
		return false;
	}

    //chat end session - agent - end timer
	private static boolean endChatWithTimerATimer(WebDriver driver)
	{
		try
		{
			Thread.sleep(1000);
			driver.findElement(By.id("endsession")).click();
			driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_90secs"))).click();
			Thread.sleep(2000);

			driver = visDriver;
			Thread.sleep(2000);
			if(!((driver.findElement(By.id("infomsg")).getText()).contains(ResourceManager.getRealValue("endtimertext"))))
			{
				checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT32"),"MismatchContent:"+ResourceManager.getRealValue("endtimertext"));

                return false;
			}

			driver = driver1;
			Thread.sleep(2000);

			driver.findElement(By.id("endsession")).click();
			driver.findElement(By.id("divcontainer")).findElement(By.linkText(ResourceManager.getRealValue("endsession_endtimer"))).click();
			Thread.sleep(4000);



			if(((driver.findElement(By.xpath("//*[@id=\"actionlnkdiv\"]/em"))).getText()).contains("Chat Session Will End in"))
			{
				checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT32"),"MismatchContent:Chat Session Will End in");

                return false;
			}

			driver = visDriver;
			Thread.sleep(3000);

			WebElement elmt = driver.findElement(By.id("attender")).findElement(By.className("vistname")).findElement(By.className("vistinfo"));
			List<WebElement> elmts = elmt.findElements(By.tagName("span"));

			if((user.equals(elmts.get(0).getText())) && (ResourceManager.getRealValue("common_connected").equals(elmts.get(1).getText())))
			{
				driver = driver1;
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT32")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT32"),"MismatchContent:"+ResourceManager.getRealValue("common_connected")+","+user);
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT32"),"Error",e);

            System.out.println("Exception while ending chat with timer A in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT32"),"Error",e);

            System.out.println("Exception while ending chat with timer A in chat module : "+e);
		}
		return false;
	}

    //end chat with timer agent side - End immediate
	private static boolean endChatWithTimerAImd(WebDriver driver)
	{
		try
		{
            Thread.sleep(1000);
			driver.findElement(By.id("endsession")).click();
			driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_90secs"))).click();
			Thread.sleep(2000);

			driver = visDriver;
			Thread.sleep(2000);
			if(!((driver.findElement(By.id("infomsg")).getText()).contains(ResourceManager.getRealValue("endtimertext"))))
			{
				checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT31"),"MismatchContent:"+ResourceManager.getRealValue("endtimertext"));

                return false;
			}

			driver = driver1;
			Thread.sleep(2000);

			driver.findElement(By.id("endsession")).click();
			driver.findElement(By.id("divcontainer")).findElement(By.linkText(ResourceManager.getRealValue("endsession_endimd"))).click();
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("infodiv"));
			if(ResourceManager.getRealValue("chatsessionendtext").equals(elmt.findElement(By.tagName("h1")).getText()))
			{
				driver = visDriver;
				Thread.sleep(3000);

                driver.findElement(By.id("submitfeedback")).click();
				//driver.findElement(By.id("fedbckinfotxtid")).click();
				driver = driver1;
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT31")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT31"),"MismatchContent:"+ResourceManager.getRealValue("chatsessionendtext"));
            }
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT31"),"Error",e);

            System.out.println("Exception while ending chat with timer A immediate in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT31"),"Error",e);

            System.out.println("Exception while ending chat with timer A immediate in chat module : "+e);
		}
		return false;
	}

    //check actions on agent chat window
	private static boolean checkActionsBlockIP(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("moreaction")).click();
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
			//WebDriverWait wait = new WebDriverWait(driver, 10);

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if((ResourceManager.getRealValue("chatsessionendopt3").equals(el.findElement(By.tagName("a")).getText())))
					{
						el.findElement(By.tagName("a")).click();

                        Thread.sleep(1000);
						wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupmn")));
                                    CommonSikuli.findInWholePage(driver,"Blockipclose.png","UI119",etest);
                                    WebElement elmt2 = driver.findElement(By.className("lvd_popupmn")).findElement(By.className("lvd_popupsub")).findElement(By.className("lvd_popupcnt")).findElement(By.className("lvd_popuptitle"));
						if((ResourceManager.getRealValue("blockip_text")).equals(elmt2.getText()))
						{
							driver. findElement(By.className("lvd_popupmn")).findElement(By.className("lvd_popupsub")).findElement(By.id("popupftr")).findElement(By.id("cancelbtn")).click();
							Thread.sleep(1000);
							try
							{
								driver.findElement(By.className("lvd_popupmn")).click();
                                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT107"),"ChatWindowExistsAfterBlockingIP");
							}
							catch(Exception e)
							{
								etest.log(Status.PASS,KeyManager.getRealValue("CHAT107")+" is checked");

                                return true;
							}
						}
                        else{
                            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT107"),"MismatchContent:"+ResourceManager.getRealValue("blockip_text"));
                        }
						driver.findElement(By.className("lvd_popupmn")).findElement(By.className("lvd_popupsub")).findElement(By.id("popupftr")).findElement(By.id("cancelbtn")).click();
						break;
					}
				}
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT107"),"MismatchContent:"+ResourceManager.getRealValue("chatsessionendopt3"));
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT107"),"ThereIsNoActions");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT107"),"Error",e);

            System.out.println("Exception while checking actions BlockIP in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT107"),"Error",e);

            System.out.println("Exception while checking actions BlockIP in chat module : "+e);
		}
		return false;
	}

    //check share url
	private static boolean checkActionsShareURL(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("moreaction")).click();
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
			//WebDriverWait wait = new WebDriverWait(driver, 10);

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if((ResourceManager.getRealValue("action_shareurl").equals(el.findElement(By.tagName("a")).getText())))
					{
						el.findElement(By.tagName("a")).click();

                                    CommonSikuli.findInWholePage(driver,"Shareurlclose.png","UI120",etest);
                                    Thread.sleep(1000);
						wait.until(ExpectedConditions.presenceOfElementLocated(By.id("pushmsgdiv")));

						driver.findElement(By.id("pushmsg")).click();
						driver.findElement(By.id("pushmsg")).clear();
						driver.findElement(By.id("pushmsg")).sendKeys("www.zoho.com");
						Thread.sleep(500);

						//driver.findElement(By.className("push-msg")).findElement(By.tagName("form")).findElements(By.tagName("a")).get(0).click();
                        driver.findElement(By.id("dlgbox")).findElement(By.tagName("form")).findElement(By.className("actionbtn-base")).findElement(By.className("cnfmbtm")).click();
						Thread.sleep(1000);

						driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);
						Thread.sleep(1000);
                        
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("infomsg")));
                        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infomsg")));
                        
                        Thread.sleep(1000);

                        String info = driver.findElement(By.id("infomsg")).getText();
                        
                        System.out.println("<>ShareUrlText<>"+info+"<><>");

						if((info).contains(ResourceManager.getRealValue("shareurltext")))
						{
							driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
							Thread.sleep(1000);
							etest.log(Status.PASS,KeyManager.getRealValue("CHAT108")+" is checked");

                            return true;
						}
                        else{
                            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT108"),"MismatchContent:"+ResourceManager.getRealValue("shareurltext"));
                        }
						driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
						Thread.sleep(1000);
						break;
					}
                }
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT108"),"ShareURLisNotPresent");
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT108"),"ThereIsNoActions");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT108"),"Error",e);

            System.out.println("Exception while checking actions share URL in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT108"),"Error",e);

            System.out.println("Exception while checking actions share URL in chat module : "+e);
		}
		return false;
	}

    //Check transfer chat
    private static boolean checkActionsTransferChat(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver.findElement(By.id("moreaction")).click();
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
			//WebDriverWait wait = new WebDriverWait(driver, 10);

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if((ResourceManager.getRealValue("action_transferchat").equals(el.findElement(By.tagName("a")).getText())))
					{
						el.findElement(By.tagName("a")).click();

                        Thread.sleep(1000);
						wait.until(ExpectedConditions.presenceOfElementLocated(By.className("modal-window")));
                                    CommonSikuli.findInWholePage(driver,"Transferchatclose.png","UI121",etest);
						WebElement elmt2 = driver.findElement(By.className("modal-window"));

						if((ResourceManager.getRealValue("action_transferchat")).equals(elmt2.findElement(By.className("modal-header")).findElement(By.tagName("h4")).getText()))
						{
                            /*
							elmt2.findElement(By.className("floatrg")).findElement(By.tagName("a")).click();
							Thread.sleep(1000);
							try
							{
								driver.findElement(By.className("lvd_popupmn")).click();
							}
							catch(Exception e)
							{
								return true;
							}
                             */

                            driver.findElement(By.id("popupdiv")).findElement(By.className("modal-header")).findElement(By.tagName("em")).click();
                            Thread.sleep(500);

                            etest.log(Status.PASS,KeyManager.getRealValue("CHAT109")+" is checked");

                            return true;
						}
                        else{

                        }
						break;
					}
				}
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT109"),"TransferChatisNotPresent");
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT109"),"ThereIsNoActions");
            }
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT109"),"Error",e);

            System.out.println("Exception while checking actions transfer chat in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT109"),"Error",e);

            System.out.println("Exception while checking actions transfer chat in chat module : "+e);
		}
		return false;
	}

    //check actions visitor side
	private static boolean checkActionsSound(WebDriver driver)
	{
		try
		{
			driver = visDriver;
			Thread.sleep(1000);

			driver.findElement(By.id("optionbtn")).click();
			Thread.sleep(1000);

			WebElement elmt = driver.findElement(By.id("options"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if("sound".equals(el.getAttribute("class")))
					{
						el.click();
						if("soundoff".equals(el.getAttribute("class")))
						{
							el.click();
							driver.findElement(By.id("optionbtn")).click();
							etest.log(Status.PASS,KeyManager.getRealValue("CHAT110")+" is checked");

                            return true;
						}
                        else{
                            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT110"),"MismatchContent:SoundsClassName");
                        }
						break;
					}
				}
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT110"),"SoundsIsNotPresent");
			}
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT110"),"ThereIsNoActions");
			driver.findElement(By.id("optionbtn")).click();
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT110"),"Error",e);

            System.out.println("Exception while checking actions sound in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT110"),"Error",e);

            System.out.println("Exception while checking actions sound in chat module : "+e);
		}
		return false;
	}

    //Check Share Mail
    private static boolean checkActionsVShareMail(WebDriver driver)
	{
		try
		{
            driver = visDriver;
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			WebElement mailaddr = driver.findElement(By.id("optionbtn"));
			driver.findElement(By.id("optionbtn")).click();
			Thread.sleep(1000);
			WebElement elmt = driver.findElement(By.id("options"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(elmts.size() > 0)
			{
				for(WebElement el:elmts)
				{
					if("email".equals(el.getAttribute("class")))
					{
						Thread.sleep(1000);
						mailaddr.click();
						el.click();
						Thread.sleep(1000);
						driver.findElement(By.id("mailid")).sendKeys(Keys.RETURN);
						//WebDriverWait wait = new WebDriverWait(driver, 10);
						wait.until(ExpectedConditions.presenceOfElementLocated(By.id("mailstatus")));
						Thread.sleep(1000);
						driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
						Thread.sleep(1000);

						etest.log(Status.PASS,KeyManager.getRealValue("CHAT111")+" is checked");

                        return true;
					}
               }
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT111"),"EmailIsNotPresent");
			}
			driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
			Thread.sleep(1000);
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT111"),"Error",e);

            System.out.println("Exception while checking actions share mail in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT111"),"Error",e);

            System.out.println("Exception while checking actions share mail in chat module : "+e);
		}
		return false;
	}

    //check all end options
	private static boolean checkAllEndOptions(WebDriver driver)
	{
		try
		{
			ArrayList endsession = new ArrayList();
			endsession.add(ResourceManager.getRealValue("endsession_90secs"));
			endsession.add(ResourceManager.getRealValue("endsession_60secs"));
			endsession.add(ResourceManager.getRealValue("endsession_45secs"));
			endsession.add(ResourceManager.getRealValue("endsession_30secs"));
			endsession.add(ResourceManager.getRealValue("endsession_endimd"));

			driver.findElement(By.id("endsession")).click();

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if(endsession.size() == elmts.size())
			{
				for(WebElement el:elmts)
				{
					if(!(endsession.contains(el.findElement(By.tagName("a")).getText())))
					{
						checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT40"),"DefaultEndSessionDoesNotContains:"+el.findElement(By.tagName("a")).getText());

                        return false;
					}
				}
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT40")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT40"),"EndsessionDefaultCountMismatch");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT40"),"Error",e);

            System.out.println("Exception while checking all end options in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT40"),"Error",e);

            System.out.println("Exception while checking all end options in chat module : "+e);
		}
		return false;
	}

    //check more actions
	private static boolean checkMoreActions(WebDriver driver)
	{
		try
		{
			ArrayList moreactions = new ArrayList();
			moreactions.add(ResourceManager.getRealValue("chatsessionendopt3"));
			moreactions.add(ResourceManager.getRealValue("action_shareurl"));
			moreactions.add(ResourceManager.getRealValue("action_transferchat"));
            moreactions.add(ResourceManager.getRealValue("action_translatechat"));
            moreactions.add(ResourceManager.getRealValue("action_inviteusers"));
                  moreactions.add(ResourceManager.getRealValue("action_share_screen"));
                  moreactions.add(ResourceManager.getRealValue("action_visitor_share_screen"));

			driver.findElement(By.id("moreaction")).click();
			Thread.sleep(5000);

			WebElement elmt = driver.findElement(By.id("divcontainer"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

            int chsize = moreactions.size();

			if(elmts.size() != 0)                             //moreactions.size() == elmts.size())
			{
				for(WebElement el:elmts)
				{
                    chsize--;
                    if(chsize>=0)
                    {
                        if(!(moreactions.contains((el.findElement(By.tagName("a")).getText()))))
                        {
                            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT41"),"DefaultMoreSessionsDoesNotContains"+el.findElement(By.tagName("a")).getText());

                            return false;
                        }
                    }
				}
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT41")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT41"),"MoreActionsDefaultCountMismatch");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT41"),"Error",e);

            System.out.println("Exception while checking more actions in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT41"),"Error",e);

            System.out.println("Exception while checking more actions in chat module : "+e);
		}
		return false;
	}

    //check options on visitor side
	private static boolean checkOptionsVisSide(WebDriver driver)
	{
		try
		{
			driver = visDriver;
			Thread.sleep(1000);

			ArrayList options = new ArrayList();
			options.add("sound");
			options.add("upload");
			options.add("print");
			options.add("email");
			options.add("endcht");

                  CommonSikuli.findInWholePage(driver,"Visitoroptions.png","UI111",etest);
                  CommonSikuli.findInWholePage(driver,"Visitorsmiley.png","UI126",etest);

			driver.findElement(By.id("optionbtn")).click();
			Thread.sleep(5000);

                  CommonSikuli.findInWholePage(driver,"Visitormute.png","UI112",etest);
                  CommonSikuli.findInWholePage(driver,"Visitorsharefile.png","UI113",etest);
                  CommonSikuli.findInWholePage(driver,"Visitorprint.png","UI114",etest);
                  CommonSikuli.findInWholePage(driver,"Visitoremail.png","UI115",etest);
                  CommonSikuli.findInWholePage(driver,"Visitorendchat.png","UI117",etest);

			WebElement elmt = driver.findElement(By.id("options"));
			List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));

			if((options.size() == elmts.size()) || ((options.size()-1) == elmts.size()))
			{
				for(WebElement el:elmts)
				{
					if(!(options.contains(el.getAttribute("class"))))
					{
						checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT42"),"DefaultMoreSessionsDoesNotContains"+el.getAttribute("class"));

                        return false;
					}
				}
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT42")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT42"),"OptionsOnVisitorSideDefaultCountMismatch");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT42"),"Error",e);

            System.out.println("Exception while checking visitor side options in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT42"),"Error",e);

            System.out.println("Exception while checking visitor side options in chat module : "+e);
		}
		return false;
	}

    //change window
	private static void changeWindow(WebDriver driver)
	{
		try
		{
			driver = driver1;
		}
		catch(Exception e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChaneWindow","Error",e);

            System.out.println("Exception while changing window in chat module : "+e);
		}
	}

    //check canned message suggession
	private static boolean checkCannedMessageSugg1(WebDriver driver)
	{
		try
		{
            Long t1 = new Long(System.currentTimeMillis());
            
            ChatWindow.sentMessage(driver,""+t1);
            ChatWindow.checkLastMessageInUserWindow(driver,"",""+t1);
            
            WebElement textarea = driver.findElement(By.id("txteditor"));
			driver.findElement(By.id("txteditor")).click();
			driver.findElement(By.id("txteditor")).clear();
			driver.findElement(By.id("txteditor")).sendKeys("#Hai");
			Thread.sleep(1000);
			driver.findElement(By.id("comptable")).findElement(By.className("candmsgcnt")).findElement(By.linkText("Hai Anand R, Welcome to SalesIQ")).click();
			textarea.click();
			textarea.sendKeys(Keys.RETURN);
			Thread.sleep(1000);

            if(ChatWindow.checkLastMessageInUserWindow(driver,"","Hai Anand R, Welcome to SalesIQ"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT43")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT43"),"MismatchContent"+"Hai Anand R, Welcome to SalesIQ");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT43"),"Error",e);

            System.out.println("Exception while checking canned message suggestion in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT43"),"Error",e);

            System.out.println("Exception while checking canned message suggestion in chat module : "+e);
		}
		return false;
	}

	//check canned message suggession
	private static boolean checkCannedMessageSugg2(WebDriver driver)
	{
		try
		{
            Long t1 = new Long(System.currentTimeMillis());
            
            ChatWindow.sentMessage(driver,""+t1);
            ChatWindow.checkLastMessageInUserWindow(driver,"",""+t1);
            
			WebElement textarea = driver.findElement(By.id("txteditor"));
			driver.findElement(By.id("cwincannedmsg")).click();
			driver.findElement(By.linkText("Hai Anand R, Welcome to SalesIQ")).click();
			textarea.click();
			textarea.sendKeys(Keys.RETURN);
			Thread.sleep(1000);

            if(ChatWindow.checkLastMessageInUserWindow(driver,"","Hai Anand R, Welcome to SalesIQ"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("CHAT44")+" is checked");

                return true;
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT44"),"MismatchContent:"+"Hai Anand R, Welcome to SalesIQ");
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT44"),"Error",e);

            System.out.println("Exception while checking canned message suggestion through link in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT44"),"Error",e);

            System.out.println("Exception while checking canned message suggestion through link in chat module : "+e);
		}
		return false;
	}

    //single department
	private static boolean chatWithSingleDepartment(WebDriver driver,String useCase)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			try
			{
				driver.findElement(By.id("selecteddept")).click();
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue(useCase),"SelectDepartmentIspresent");
			}
			catch(NoSuchElementException e)
			{
				driver = driver1;
				etest.log(Status.PASS,KeyManager.getRealValue(useCase)+" is checked");

                return true;
			}
			driver = driver1;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue(useCase),"Error",e);

            System.out.println("Exception while chatting with single department in the portal in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue(useCase),"Error",e);

            System.out.println("Exception while chatting with single department in the portal in chat module : "+e);
		}
		return false;
	}

    //chat with no department
	private static boolean chatWithNoDept(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

			Thread.sleep(5000);
			driver.navigate().refresh();
            checkAlert(driver);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedmaindiv")));

			try
			{
				driver.findElement(By.id("selecteddept")).click();
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT39"),"SelectDepartmentIspresent");
			}
			catch(NoSuchElementException e)
			{
				driver.findElement(By.id("question")).click();
				driver.findElement(By.id("question")).sendKeys(ques);
				driver.findElement(By.id("btnaddvisitor")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("timersvg")));

				acceptChat1(driver);
                
                driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

				List<WebElement> elmts1 = driver.findElement(By.id("visitordata")).findElements(By.className("rcvstinfotxt"));
				String txt = "";
				if(elmts1.size() > 0)
				{
					txt = elmts1.get(0).getText();
				}
				if((txt).contains("Automation"))
				{
					driver = driver1;
					etest.log(Status.PASS,KeyManager.getRealValue("CHAT39")+" is checked");

                    return true;
				}
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT39"),"AutomationDepartmentIsNotPresent");
			}
			driver = driver1;
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT39"),"Error",e);

            System.out.println("Exception while chatting with no department in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT39"),"Error",e);

            System.out.println("Exception while chatting with no department in chat module : "+e);
		}
		return false;
	}

    //check offline chat widget on changing user status
	private static boolean checkWidgetOffline(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            try
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("hdrprt")));
            }
            catch(Exception e)
            {
                driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("hdrprt")));
            }

            changeStatus(driver,"busy");
			if((driver.findElement(By.id("switch-bg")).getAttribute("class")).contains("userstatus-3"))
			{
				driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);

				Thread.sleep(2000);
				driver.navigate().refresh();
                checkAlert(driver);

                        Thread.sleep(1000);
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedcontainer")));

                        try
                        {
                            if(((ResourceManager.getRealValue("offlinemsg")).equals(driver.findElement(By.id("embedcontainer")).findElement(By.id("offmsg")).getText())) && ((driver.findElement(By.id("embedcontainer")).findElement(By.id("offbtncontainer")).findElement(By.id("btnsavemisschat")).getAttribute("value")).equals("Submit")))
                            {
                                driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
                                Thread.sleep(3000);
                                etest.log(Status.PASS,KeyManager.getRealValue("CHAT98")+" is checked");

                        return true;
                    }
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT98"),"MismatchContent:"+ResourceManager.getRealValue("offlinemsg")+",Submit");
                    }
                }
                catch(Exception e)
                {
                    checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT98"),"Error",e);
                }
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT98"),"StatusIsNotChangedToBusy");
            }

            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT98"),"StatusIsNotPresntDropDown");
			driver = driver1;
			Thread.sleep(3000);
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT98"),"Error",e);

            System.out.println("Exception while checking chat widget when Operator offline in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT98"),"Error",e);

            System.out.println("Exception while checking chat widget when Operator offline in chat module : "+e);
		}
		return false;
	}

	//check offline chat widget on changing user status
	private static boolean checkWidgetOnline(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);

            changeStatus(driver,"available");
			if((driver.findElement(By.id("switch-bg")).getAttribute("class")).contains("userstatus-1"))
			{
				driver = visDriver;wait = CommonUtil.waitreturner(driver,30,250);
				Thread.sleep(2000);
				driver.navigate().refresh();
                checkAlert(driver);

				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedcontainer")));

				try
				{
					if((ResourceManager.getRealValue("offlinemsg")).equals(driver.findElement(By.id("embedcontainer")).findElement(By.id("offmsg")).getText()))
					{
                        driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
                        Thread.sleep(3000);
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"ChatWidgetShowsOffline");
                        return false;
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"MismatchContent:"+ResourceManager.getRealValue("offlinemsg"));
                    }
				}
				catch(Exception e)
				{
					if((driver.findElement(By.id("embedmaindiv")).findElement(By.id("btnaddvisitor")).getAttribute("value")).equals("Chat"))
					{
						driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);
						Thread.sleep(3000);
						etest.log(Status.PASS,KeyManager.getRealValue("CHAT99")+" is checked");

                        return true;
					}
                    else{
                        checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"ChatButtonIsNotPresent");
                    }
				}
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"StatusIsNotChangedToAvailable");
            }
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"StatusIsNotPresntDropDown");
			driver = driver1;
			Thread.sleep(3000);
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"Error",e);

            System.out.println("Exception while checking chat widget when Operator online in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT99"),"Error",e);

            System.out.println("Exception while checking chat widget when Operator online in chat module : "+e);
		}
		return false;
	}

    //delete department
	private static void deleteDepartment(WebDriver driver, String value)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver = driver1;wait = CommonUtil.waitreturner(driver,30,250);

            Thread.sleep(1000);
            
            Tab.navToDeptTab(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				Thread.sleep(1000);
				if(data.equals(value))
				{
					WebElement delelmt = elmt.findElements(By.className("list_cell")).get(0);
					mouseOver(driver, delelmt.findElement(By.className("list_lefticon")));
                    Thread.sleep(500);
					delelmt.findElement(By.className("list_lefticon")).click();
					Thread.sleep(1000);
					driver.findElement(By.id("deptselect_div")).click();
					Thread.sleep(2000);
					List<WebElement> elmt2 = driver.findElement(By.id("deptselect1")).findElements(By.tagName("li"));
					Thread.sleep(500);

					elmt2.get(0).click();
					Thread.sleep(2000);
                              CommonSikuli.findInWholePage(driver,"Departmentdelete.png","UI122",etest);
					driver.findElement(By.id("okbtn")).click();
					Thread.sleep(1000);
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DeleteDepartment:"+value,"Error",e);

            System.out.println("Exception while deleting department in chat module : "+e);
        }
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DeleteDepartment:"+value,"Error",e);

            System.out.println("Exception while deleting department in chat module : "+e);
        }
	}

    //chat end with timer - continue option
	private static boolean endChatWithTimerCont(WebDriver driver)
	{
		boolean isend = false;
		try
		{
			driver.findElement(By.id("endsession")).click();
			driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_90secs"))).click();
			Thread.sleep(2000);
			driver = visDriver;
            Thread.sleep(2000);
			if((driver.findElement(By.id("infomsg")).getText()).contains(ResourceManager.getRealValue("endtimertext")))
			{
				driver.findElement(By.id("infomsg")).findElements(By.tagName("a")).get(0).click();
				Thread.sleep(2000);

				driver.findElement(By.id("lstxteditor")).click();
				driver.findElement(By.id("lstxteditor")).clear();
				driver.findElement(By.id("lstxteditor")).sendKeys("Hai Welcome again");
				driver.findElement(By.id("lstxteditor")).sendKeys(Keys.RETURN);

				Thread.sleep(1000);

				driver = driver1;
				Thread.sleep(2000);

				if((driver.findElement(By.id("actionlnkdiv")).findElement(By.tagName("em")).getText()).contains("Chat Session Will End in"))
				{
					checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT105"),"ChatSessionEndsEvenAfterPressingContinue");

                    isend = false;
				}
                else
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CHAT105")+" is checked");

                    isend = true;
                }

				driver.findElement(By.id("endsession")).click();
				Thread.sleep(1000);
				driver.findElement(By.linkText(ResourceManager.getRealValue("endsession_endimd"))).click();
				Thread.sleep(5000);
			}
            else{
                checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT105"),"MismatchContent:"+ResourceManager.getRealValue("endtimertext"));
            }
		}
		catch(NoSuchElementException e)
		{
			checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT105"),"Error",e);

            System.out.println("Exception while ending chat timer continue in chat module : "+e);
		}
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow",KeyManager.getRealValue("CHAT105"),"Error",e);

            System.out.println("Exception while ending chat timer continue in chat module : "+e);
		}
		return isend;
	}

    //clear data
	public static boolean clearChat(WebDriver driver)
	{
		try
		{
			enableBusinessHour(driver);
			deleteDepartment(driver,"TestDepartment");
			deleteAddedCannedMessage(driver);
			return true;
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ClearChat","Error",e);
            System.out.println("Exception while clearing added data in chat module : "+e);
            return false;
        }
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ClearChat","Error",e);
            System.out.println("Exception while clearing added data in chat module : "+e);
            return false;
        }
	}
    //change status of the user
    private static void changeStatus(WebDriver driver,String status)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);

            try
            {
                Thread.sleep(2000);
                Functions.closeBannersAfterLogin(driver);
            }
            catch(Exception e)
            {
                System.out.println("Exception while closing the maintenance banner : "+e);
            }

            if(status.equals("available"))
            {
                if(!((driver.findElement(By.id("switch-bg")).getAttribute("class")).contains("userstatus-1")))
                {
                    driver.findElement(By.id("switch-bg")).click();

                    Thread.sleep(1000);

                    // driver.findElement(By.id("headerdropdiv")).findElement(By.id("ustatus")).findElement(By.tagName("a")).findElement(By.tagName("span")).click();

                    // Thread.sleep(1000);

                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if((driver.findElement(By.id("switch-bg")).getAttribute("class")).contains("userstatus-1"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                }
            }
            else if(status.equals("busy"))
            {
                if(!((driver.findElement(By.id("switch-bg")).getAttribute("class")).contains("userstatus-3")))
                {
                    driver.findElement(By.id("switch-bg")).click();

                    Thread.sleep(1000);

                    // driver.findElement(By.id("headerdropdiv")).findElement(By.id("ustatus")).findElement(By.tagName("a")).findElement(By.tagName("span")).click();

                    // Thread.sleep(1000);

                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if((driver.findElement(By.id("switch-bg")).getAttribute("class")).contains("userstatus-3"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                }
            }

            Thread.sleep(1000);
        }
        catch(NoSuchElementException e)
        {
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChangeStatus","Error",e);

            System.out.println("Exception while changing status in chat module : " + e);
        }
        catch(Exception e)
        {
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChangeStatus","Error",e);

            System.out.println("Exception while changing status in chat module : " + e);
        }
    }

    //Mouseover
	public static void mouseOver(WebDriver driver, WebElement element) throws Exception
	{
		Thread.sleep(500);
		new Actions(driver).moveToElement(element).perform();
	}

    //delete added canned message
	private static void deleteAddedCannedMessage(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			//WebDriverWait wait = new WebDriverWait(driver, 30);
            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

			WebElement elmt1 = driver.findElement(By.id("cmsglist"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			if(elmts.size() > 0)
			{
				try
				{
					for(WebElement elmt:elmts)
					{
						List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
						Thread.sleep(1000);
						if("Hello %visitor.name%".equals(elmts1.get(0).getText()))
						{
							String category = elmts1.get(1).getText();
							elmts1.get(3).findElement(By.tagName("em")).click();
							Thread.sleep(1000);

							driver.findElement(By.id("okbtn")).click();
							Thread.sleep(1000);
							break;
						}
					}
				}
				catch(Exception e){}
			}
		}
		catch(NoSuchElementException e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DeleteAddedCannedMessage","Error",e);

            System.out.println("Exception while deleting added canned message in chat module : "+e);
        }
		catch(Exception e)
		{
            checkAlert(driver);TakeScreenshot.screenshot(driver,etest,"ChatWindow","DeleteAddedCannedMessage","Error",e);

            System.out.println("Exception while deleting added canned message in chat module : "+e);
        }
	}

    public static void checkAlert(WebDriver driver)
    {
        try
        {
            Thread.sleep(1000);
            driver.switchTo().alert();
            driver.switchTo().alert().accept();
            Thread.sleep(2000);
        }
        catch(Exception e)
        {
        }
    }

    public static void commonIconsVerifyinMychatstab(WebDriver driver)
    {
        try
        {
          // checkVisitorData
          CommonSikuli.findInWholePage(driver,"Notes.png","UI91",etest);
          CommonSikuli.findInWholePage(driver,"Chat.png","UI93",etest);
          CommonSikuli.findInWholePage(driver,"Chatinfo.png","UI92",etest);
          WebElement browser = driver.findElement(By.xpath(".//*[contains(@class, '_browser')]"));
         WebElement os = driver.findElement(By.xpath(".//*[contains(@class, '_os')]"));

         if (browser.getAttribute("class").contains("browser"))
         {
           System.out.println(CommonSikuli.getBrowsername(browser));
           CommonSikuli.findInWholePage(driver,CommonSikuli.getBrowsername(browser),"UI94",etest);
         }
                  
         if (os.getAttribute("class").contains("os"))
         {     
            System.out.println(CommonSikuli.getOSname(os));
            CommonSikuli.findInWholePage(driver,CommonSikuli.getOSname(os),"UI95",etest);
         }
        CommonSikuli.findInWholePage(driver,"Mychatssmiley.png","UI125",etest);  //----

        }
        catch(Exception e)
        {
            System.out.println("Exception while Check commonIcons");
        }
    }
    public static void commonIconsVerifyinChatHistorytab(WebDriver driver)
    {
        try
        {
           //checkChatActions
          CommonSikuli.findInWholePage(driver,"Notes.png","UI103",etest);
          CommonSikuli.findInWholePage(driver,"Chat.png","UI105",etest);
          CommonSikuli.findInWholePage(driver,"Chatinfo.png","UI104",etest);
          WebElement browser = driver.findElement(By.xpath(".//*[contains(@class, '_browser')]"));
         WebElement os = driver.findElement(By.xpath(".//*[contains(@class, '_os')]"));
         //sendemail

        CommonSikuli.findInWholePage(driver,"Sendemail.png","UI127",etest);

         if (browser.getAttribute("class").contains("browser"))
         {
           System.out.println(CommonSikuli.getBrowsername(browser));
           CommonSikuli.findInWholePage(driver,CommonSikuli.getBrowsername(browser),"UI106",etest);
         }
                  
         if (os.getAttribute("class").contains("os"))
         {     
            System.out.println(CommonSikuli.getOSname(os));
            CommonSikuli.findInWholePage(driver,CommonSikuli.getOSname(os),"UI107",etest);
         }
        }
        catch(Exception e)
        {
            System.out.println("Exception while Check commonIcons");
        }
    }
    public static void commonIconsVerifyinConnctedtab(WebDriver driver)
    {
        try
        {
          // Joinchat
          CommonSikuli.findInWholePage(driver,"Notes.png","UI98",etest);
          CommonSikuli.findInWholePage(driver,"Chat.png","UI100",etest);
          CommonSikuli.findInWholePage(driver,"Chatinfo.png","UI99",etest);
          WebElement browser = driver.findElement(By.xpath(".//*[contains(@class, '_browser')]"));
         WebElement os = driver.findElement(By.xpath(".//*[contains(@class, '_os')]"));
         CommonSikuli.findInWholePage(driver,"Sendemail.png","UI128",etest);
         if (browser.getAttribute("class").contains("browser"))
         {
           System.out.println(CommonSikuli.getBrowsername(browser));
           CommonSikuli.findInWholePage(driver,CommonSikuli.getBrowsername(browser),"UI101",etest);
         }
                  
         if (os.getAttribute("class").contains("os"))
         {     
            System.out.println(CommonSikuli.getOSname(os));
            CommonSikuli.findInWholePage(driver,CommonSikuli.getOSname(os),"UI102",etest);
         }
        }
        catch(Exception e)
        {
            System.out.println("Exception while Check commonIcons");
        }
    }

    public static boolean checkAttachmentInTilesUI(WebDriver driver,ExtentTest etest) throws Exception
    {
      String website_name = ExecuteStatements.getDefaultEmbedName(driver);
      String widget_code = ExecuteStatements.getWidgetCodeFromEmbedName(driver,website_name);
      String portal_name = ExecuteStatements.getPortal(driver);
      String label = CommonUtil.getUniqueMessage();
      int failcount = 0;
      WebDriver visitor_driver=null;
      String visitor_id="";
      try
      {
            try
            {
                  visitor_driver=Functions.setUp(true);
                  VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
                  visitor_id=VisitorWindow.getVisitorId(visitor_driver,portal_name);
            }
            catch(Exception exp)
            {
                  TakeScreenshot.screenshot(visitor_driver,etest);
                  return false;
            }

            VisitorWindow.setupOngoingChat(driver,visitor_driver,etest,widget_code,label);

            VisitorWindow.sentMessageInTheme(visitor_driver,label+"1");
            ChatWindow.waitTillMessageInChat(driver,label+"1");
            
            FileType file_type=FileType.IMAGE;
            ChatWindow.uploadFile(driver,file_type);

            VisitorWindow.sentMessageInTheme(visitor_driver,label+"2");
            ChatWindow.waitTillMessageInChat(driver,label+"2");

            ChatWindow.endChat(driver);
            
            Tab.clickVisitorsOnline(driver);

            CannedMessagesCommonFunctions.clickVisitorOnline(driver,visitor_id);

            CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("ldsettings"),By.id("pathurl"),By.className("cp_chthref")));
            CommonWait.waitTillDisplayed(driver,By.id("pchat0"));
            TakeScreenshot.infoScreenshot(driver,etest);

            if(CommonWait.isDisplayed(driver,By.id("pchat0")))
            {
                  etest.log(Status.PASS,"Chat transcript was found in TilesUI");
                  if(!CommonUtil.checkStringContainsAndLog(file_type.getFileName(),CommonUtil.getElement(driver,By.id("ldsettings"),By.className("filedet")).getText(),"File name",etest))
                  {
                        failcount++;
                        TakeScreenshot.screenshot(driver,etest);
                  }
            }
            else
            {
                  etest.log(Status.FAIL,"Chat transcript was not found in TilesUI");
                  TakeScreenshot.screenshot(driver,etest);
                  failcount++;
            }
      }
      catch(Exception e)
      {
            TakeScreenshot.screenshot(driver,etest,"Chat","Exception","Exception",e);
      }
      return CommonUtil.returnResult(failcount);
    }
}
