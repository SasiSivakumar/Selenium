//$Id$
package com.zoho.livedesk.client;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.net.URL;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
//import com.sun.swing.internal.plaf.synth.resources.synth;

import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.Tab;
import java.io.IOException;
import com.zoho.livedesk.util.AutomationPauser;

public class ComplexReportFactory 
{

	public static ExtentReports reporter=null;
	public static Map<Long, String> threadToExtentTestMap = new HashMap<Long, String>();
	public static Map<String, ExtentTest> nameToTestMap = new HashMap<String, ExtentTest>();

	public static HashMap<ExtentTest, Long> testToStartTimeMap = new HashMap<ExtentTest, Long>();

    public static String buildlabel = "";
    public static String setup = "";
    public static String extentreportLoc = "";
    public static String extentreportLink = "";
    
	public synchronized static ExtentReports getExtentReport() 
	{
		if (reporter==null || !buildlabel.equals(Util.buildlabel()) || !setup.equals(Util.setUptracking())) 
		{
			// you can get the file name and other parameters here from a
			// config file or global variables
			reporterInit();
		}
		return reporter;
	}

	public static ExtentHtmlReporter getHtmlReporter() 
	{
	    ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(getExtentReportLocation());

	    htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("Automation for "+buildlabel);
        htmlReporter.config().setReportName("SalesIQ Automation Report");
	    htmlReporter.loadXMLConfig(getConfigLocation());
	    // htmlReporter.setAppendExisting(false);
	    // htmlReporter.start();

	    return htmlReporter;
	}

	public static String getConfigLocation()
	{
        URL location = ComplexReportFactory.class.getProtectionDomain().getCodeSource().getLocation();
        String fileloc = location.getFile();
        fileloc = fileloc.replaceAll("/lib/livedesk-webdriver.jar","/webapps/selenium/extent-config.xml");
        return fileloc;
	}

	public static void reporterInit()
	{
        nameToTestMap = new HashMap<String, ExtentTest>();
        testToStartTimeMap=new HashMap<ExtentTest, Long>();
        buildlabel = Util.buildlabel();
        setup = Util.setUptracking();            
        String bLabel=getReportFolderName();
        extentreportLink = "http://"+Util.serverHostName+":"+Util.serverPortNumber+"/reports/"+Util.setUptracking()+"/"+bLabel+"/ComplexReportB.html";

        String extentreportLoc=getExtentReportLocation();

        reporter = new ExtentReports();
		reporter.attachReporter(getHtmlReporter());
		reporter.setSystemInfo("Build Name",bLabel);
        reporter.setSystemInfo("Deployment",(Util.setUptracking()).toUpperCase());

        try
        {
	        com.zoho.livedesk.util.common.actions.FileUpload.createFileIfNotExists(extentreportLoc);
        }
        catch(IOException e)
        {
        	e.printStackTrace();
        }

		// closeReport1();

        System.out.println("Complex Report created at "+extentreportLoc);
	}

	public static void renameReportFileIfAlreadyExists()
	{
		String extentreportLoc=getExtentReportLocation();

        try
	    {
	        //in case file already exists, rename it
	        if(com.zoho.livedesk.util.common.actions.FileUpload.isFileExists(extentreportLoc))
	        {
	        	String time=""+new Long(System.currentTimeMillis());
	        	String renamedPath=extentreportLoc.replace( "ComplexReportB.html", time+".html" );
	        	com.zoho.livedesk.util.common.actions.FileUpload.renameFile(extentreportLoc,renamedPath);
	        }
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	}

	public static String getExtentReportLocation()
	{
        URL location = ComplexReportFactory.class.getProtectionDomain().getCodeSource().getLocation();
        String fileloc = location.getFile();
        fileloc = fileloc.replaceAll("/lib/livedesk-webdriver.jar","/webapps/selenium/reports/");

        String bLabel = getReportFolderName();
             
        fileloc = fileloc+Util.setUptracking()+"/"+bLabel;
        
        String extentreportLoc = fileloc+"/ComplexReportB.html";

        return extentreportLoc;
	}

	public static String getReportFolderName()
	{
        String bLabel = Util.buildlabel();
        
        if(bLabel==null||bLabel=="")
        {
            bLabel = "UnknownLabel";
        }
        
        if(bLabel.contains("/"))
        {
            bLabel = bLabel.replaceAll("/","_");
        }

        return bLabel;
	}
    
    public synchronized static ExtentTest getTest(String testName, String testDescription) {

		// if this test has already been created return
		if (!nameToTestMap.containsKey(testName))
		{
			Long threadID = Thread.currentThread().getId();

			ExtentTest test = getExtentReport().createTest(testName, testDescription);

			nameToTestMap.put(testName, test);
			threadToExtentTestMap.put(threadID, testName);
			testToStartTimeMap.put(test,new Long(System.currentTimeMillis()));
		}
        
        // Tab.etestName.put(nameToTestMap.get(testName),testName);
        
        return nameToTestMap.get(testName);
	}

	public synchronized static ExtentTest getTest(String testName) 
	{
		return getTest(testName, "");
	}

	public synchronized static ExtentTest getEtest(String testName,String moduleName) 
	{
		return getEtest(testName,"Automation",moduleName);
	}

	public synchronized static ExtentTest getEtest(String testName,String author,String moduleName) 
	{
		ExtentTest etest = getTest(testName);
		setValues(etest,author,moduleName);
		return etest;
	}

	public static Long getStartedTime(ExtentTest etest)
	{
		if(testToStartTimeMap.containsKey(etest))
		{
			return testToStartTimeMap.get(etest);
		}

		return null;
	}

	/*
	 * At any given instance there will be only one test running in a thread. We
	 * are already maintaining a thread to extentest map. This method should be
	 * used after some part of the code has already called getTest with proper
	 * testcase name and/or description.
	 * 
	 * Reason: This method is not for creating test but getting an existing test
	 * reporter. sometime you are in a utility function and want to log
	 * something from there. Utility function or similar code sections are not
	 * bound to a test hence we cannot get a reporter via test name, unless we
	 * pass test name in all method calls. Which will be an overhead and a rigid
	 * design. However, there is one common association which is the thread ID.
	 * When testng executes a test it puts it launches a new thread, assuming
	 * test level threading, all tests will have a unique thread id hence call
	 * to this function will return the right extent test to use
	 */
//	public synchronized static ExtentTest getTest() {
//		Long threadID = Thread.currentThread().getId();
//
//		if (threadToExtentTestMap.containsKey(threadID)) {
//			String testName = threadToExtentTestMap.get(threadID);
//			return nameToTestMap.get(testName);
//		}	
//		//system log, this shouldnt happen but in this crazy times if it did happen log it.
//		return null;
//	}

	public synchronized static void closeTest(String testName) 
	{
		closeReport1();
		// if (!testName.isEmpty()) 
		// {
		// 	ExtentTest test = getTest(testName);
		// 	getExtentReport().endTest(test);
		// }
	}

	public synchronized static void closeTest(ExtentTest test,boolean isCheckForPause) {
		// if (test != null) {
		// 	getExtentReport().endTest(test);
		// }

		if(isCheckForPause)
		{
			AutomationPauser.handle(test);
		}

		closeReport1();
	}

	public synchronized static void closeTest(ExtentTest test) 
	{
		closeTest(test,true);
	}

//	public synchronized static void closeTest()  {
//		ExtentTest test = getTest();
//		closeTest(test);
//	}

	public synchronized static void closeReport()
	{
		if (reporter != null) 
		{
			reporter.flush();
            nameToTestMap = new HashMap<String, ExtentTest>();
            reporter = null;
        }
	}
    
    public synchronized static void closeReport1() 
    {
        if(reporter != null) 
        {
            reporter.flush();
        }
    }
    
	public synchronized static void setValues(ExtentTest etest,String author,String category,String description) {
		etest.assignAuthor(author);
		etest.assignCategory(category);
        // Tab.etestCategory.put(test,category);
		//test.setDescription(description);
	}
    
    public synchronized static void setValues(ExtentTest etest,String author,String category) 
    {
    	setValues(etest,author,category,null);
    }

    public synchronized static void setValues(ExtentTest etest,String category) 
    {
    	setValues(etest,"Automation",category);
    }
}
