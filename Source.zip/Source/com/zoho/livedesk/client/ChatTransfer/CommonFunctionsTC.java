//$Id$
package com.zoho.livedesk.client.ChatTransfer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import org.openqa.selenium.StaleElementReferenceException;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.List;
import java.util.Set;

import com.google.common.base.Function;

import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class CommonFunctionsTC {
    
    public static void clickTransferChat(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","comptable"),"id","moreaction").click();

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","comptable"),"id","transfechat").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));
        
        etest.log(Status.INFO,"Transfer Chat is clicked");
    }

    public static void clickInviteUser(WebDriver driver, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","comptable"),"id","moreaction").click();

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","comptable"),"id","invitchat").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));
        
        etest.log(Status.INFO,"Invite Chat is clicked");
    }

    public static String[] transferChatContent(WebDriver driver,ExtentTest etest,String transferTo) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickTransferChat(driver,etest);

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        String[] content = new String[5];

        content[0] = CommonUtil.elementfinder(driver,popup,"classname","modal-header").getText();

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,popup,"id","usrcontainer"),"tagname","li");

        List<WebElement> list = CommonUtil.elementfinder(driver,popup,"id","usrcontainer").findElements(By.tagName("li"));

        for(WebElement ee : list)
        {
            if(CommonUtil.elementfinder(driver,ee,"classname","cht-tle").getText().contains(transferTo))
            {
                ee.click();
            }
        }

        CommonUtil.elementfinder(driver,popup,"id","seldiv");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(!CommonUtil.elementfinder(driver,popup,"id","seldiv").getAttribute("style").contains("none"))
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });

        List<WebElement> list1 = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,popup,"id","seldiv"),"id","transcontainer").findElements(By.tagName("li"));
    
        content[1] = CommonUtil.elementfinder(driver,list1.get(0),"classname","cht-tle").getText();
        content[2] = CommonUtil.elementfinder(driver,list1.get(2),"classname","cht-tle").getText();
        content[3] = CommonUtil.elementfinder(driver,popup,"id","btnsub").getText();
        content[4] = CommonUtil.elementfinder(driver,popup,"classname","btn_red").getText();

        return content;
    }

    public static void transferChat(WebDriver driver,ExtentTest etest,boolean needcomment,String comment,String dept,String transferTo) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickTransferChat(driver,etest);

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        String id = "transdeptlst";//"usrcontainer";

        if(dept != null)
        {
           CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,popup,"id",id),"tagname","li");

            List<WebElement> list1 = CommonUtil.elementfinder(driver,popup,"id",id).findElements(By.tagName("li"));
            
            for(WebElement ee : list1)
            {
                if(ee.getText().contains(dept))
                {
                    ee.click();
                }
            }
        }

        id = "usrcontainer";

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,popup,"id",id),"tagname","li");

        List<WebElement> list2 = CommonUtil.elementfinder(driver,popup,"id",id).findElements(By.tagName("li"));

        for(WebElement ee : list2)
        {
            if(CommonUtil.elementfinder(driver,ee,"classname","cht-tle").getText().contains(transferTo))
            {
                if(dept != null)
                {
                    TakeScreenshot.screenshot(driver,etest,"TransferChat","Values","CheckBefore",0);
                }
                
                ee.click();
            }
        }
        
        CommonUtil.elementfinder(driver,popup,"id","seldiv");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(!CommonUtil.elementfinder(driver,popup,"id","seldiv").getAttribute("style").contains("none"))
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });

        if(needcomment)
        {
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,popup,"id","seldiv"),"id","notes").sendKeys(comment);
            Thread.sleep(1000);
        }

        TakeScreenshot.screenshot(driver,etest,"TransferChat","Values","CheckBefore",0);
    
        CommonUtil.elementfinder(driver,popup,"id","btnsub").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(!driver.findElement(By.id("popupdiv")).isDisplayed())
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });
    }

    public static void inviteUser(WebDriver driver,ExtentTest etest,String user_name,String comment) throws Exception
    {
        clickInviteUser(driver,etest);
        WebElement user_container=com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("popupdiv"),By.id("usrcontainer"));
        com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementDisplayed(driver,user_container);

        List<WebElement> users = user_container.findElements(By.tagName("li"));

        WebElement user=com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(users,"innerText",user_name);
        user.click();

        WebElement submit_button=com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("btnsub"));
        com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementDisplayed(driver,submit_button);
        
        if(comment!=null)
        {
            CommonUtil.getElement(driver,By.id("popupdiv"),By.id("notes")).click();
            CommonUtil.getElement(driver,By.id("popupdiv"),By.id("notes")).sendKeys(comment);
        }

        submit_button.click();
        com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(By.id("popupdiv")),5,false);

        etest.log(Status.INFO,user_name+" was invited to chat with visitor.");
    }

    public static void acceptInvite(WebDriver driver,ExtentTest etest) throws Exception
    {
        acceptTransferedChat(driver,etest);     
        etest.log(Status.INFO,"Chat invite was accepted.");   
    }

    public static String[] acceptTransferedChatContent(WebDriver driver,boolean comment) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

        int i = 6;

        if(comment)
        {
            i++;
        }

        String[] content = new String[i];

        WebElement popup = CommonUtil.elfinder(driver,"classname","lvd_popupsub");

        int j = 0;

        content[j++] = CommonUtil.elementfinder(driver,popup,"classname","lvd_popuptitle").getText();
        content[j++] = CommonUtil.elementfinder(driver,popup,"id","okbtn").getText();
        content[j++] = CommonUtil.elementfinder(driver,popup,"id","cancelbtn").getText();
        content[j++] = CommonUtil.elementfinder(driver,popup.findElements(By.className("poptrncht_lst")).get(0),"tagname","div").getText();
        content[j++] = CommonUtil.elementfinder(driver,popup.findElements(By.className("poptrncht_lst")).get(1),"tagname","div").getText();
        content[j++] = CommonUtil.elementfinder(driver,popup.findElements(By.className("poptrncht_lst")).get(2),"tagname","div").getText();
        
        if(comment)
        {
           content[j++] = CommonUtil.elementfinder(driver,popup.findElements(By.className("poptrncht_lst")).get(3),"tagname","div").getText();
        }
        return content;
    }

    public static void acceptTransferedChat(WebDriver driver,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
        
        TakeScreenshot.screenshot(driver,etest,"TransferChat","AcceptTransferChat","CheckBefore",0);

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","lvd_popupsub"),"id","okbtn").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(!driver.findElement(By.id("popupdiv")).isDisplayed())
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });
    }

    public static void rejectTransferedChat(WebDriver driver,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
        
        TakeScreenshot.screenshot(driver,etest,"TransferChat","RejectTransferChat","CheckBefore",0);

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","lvd_popupsub"),"id","cancelbtn").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(!driver.findElement(By.id("popupdiv")).isDisplayed())
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });
    }

    public static String transferNoteInMessage(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","msgtablediv"),"classname","t-o-cont");

        List<WebElement> list = CommonUtil.elementfinder(driver,e,"id","msgtablediv").findElements(By.className("t-o-cont"));

        return list.get(0).getText();
    }

    public static String transferAcceptNoteInMessage(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        final WebElement div = CommonUtil.elementfinder(driver,e,"id","msgtablediv");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                String mainString = div.getAttribute("innerHTML");
                try
                {
                    if(CommonUtil.stringOccurence(mainString,"t-o-cont") == 2)
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });

        List<WebElement> list = CommonUtil.elementfinder(driver,e,"id","msgtablediv").findElements(By.className("t-o-cont"));

        return list.get(1).getText();
    }

    public static String transferRejectNoteInMessage(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        final WebElement div = CommonUtil.elementfinder(driver,e,"id","msgtablediv");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                String mainString = div.getAttribute("innerHTML");
                try
                {
                    if(CommonUtil.stringOccurence(mainString,"t-o-cont") == 2)
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });

        List<WebElement> list = div.findElements(By.className("t-o-cont"));

        return list.get(1).getText();
    }

    public static void clickViewNotesinSupportActions(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickChatInSupportActions(driver);

        Thread.sleep(2000);

        final WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,e,"id","notes").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(e.findElement(By.id("subtabholder")).getAttribute("style").contains("block"))
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });
    }

    public static void clickChatInSupportActions(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        final WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,e,"id","chat").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(e.findElement(By.id("msgtablediv")).getAttribute("style").contains("block"))
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });
    }

    public static String transferNoteInNotes(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","notelist"),"classname","spt-ntsmn");

        List<WebElement> list = CommonUtil.elementfinder(driver,e,"id","notelist").findElements(By.className("spt-ntsmn"));

        return CommonUtil.elementfinder(driver,list.get(list.size()-1),"classname","nots-msg").getText();
    }

    public static String transferAcceptNoteInNotes(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","notelist"),"classname","spt-ntsmn");

        List<WebElement> list = CommonUtil.elementfinder(driver,e,"id","notelist").findElements(By.className("spt-ntsmn"));

        return CommonUtil.elementfinder(driver,list.get(list.size()-2),"classname","nots-msg").getText();
    }

    public static String transferRejectNoteInNotes(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","notelist"),"classname","spt-ntsmn");

        List<WebElement> list = CommonUtil.elementfinder(driver,e,"id","notelist").findElements(By.className("spt-ntsmn"));

        return CommonUtil.elementfinder(driver,list.get(list.size()-2),"classname","nots-msg").getText();
    }

    public static String transferCommentInNotes(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement e = ChatWindow.chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","notelist"),"classname","spt-ntsmn");

        List<WebElement> list = CommonUtil.elementfinder(driver,e,"id","notelist").findElements(By.className("spt-ntsmn"));

        return CommonUtil.elementfinder(driver,list.get(list.size()-1),"classname","nots-submsg").getText();
    }

    public static void changeUserDept(WebDriver driver,String user,String dept) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        Tab.clickSettings(driver);

        String userid = null;

        List<WebElement> users = CommonUtil.elfinder(driver,"id","ulisttable").findElements(By.className("list-row"));

        for(WebElement e : users)
        {
            if(e.getText().contains(user))
            {
                userid = e.getAttribute("id");
                e.click();
                break;
            }
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Edit Profile")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Edit Profile")));

        String url = Util.siteNameout()+"/"+TransferChat.portal+"/index#setting/user/edit/"+userid;

        driver.get(url);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("useredit")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("useredit")));

        final WebElement depts = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","useredit"),"id","seldepartment");

        CommonUtil.inViewPort(depts);

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

        if(CommonUtil.elementfinder(driver,depts,"classname","seltext").getAttribute("style").contains("none"))
        {
            List<WebElement> list = CommonUtil.elementfinder(driver,depts,"classname","field_main").findElements(By.className("field_div"));

            for(WebElement e : list)
            {
                CommonUtil.elementfinder(driver,e,"classname","sqico-plus").click();
            }

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(!depts.findElement(By.className("seltext")).getAttribute("style").contains("none"))
                            return true;
                    }
                    catch(Exception e){}
                    return false;
                }
            });
        }

        Thread.sleep(1000);

        WebElement sel = CommonUtil.elementfinder(driver, depts, "css", ".field_main.unsel_main");
        
        List<WebElement> list = sel.findElements(By.className("field_div"));

        for(WebElement e : list)
        {
            if(e.getText().contains(dept))
            {
                CommonUtil.elementfinder(driver,e,"classname","sqico-plus").click();
                break;
            }
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(depts.findElement(By.className("seltext")).getAttribute("style").contains("none"))
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });

        WebElement update = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","useredit"),"id","useradd");

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

        update.click();

        try
        {
            Tab.waitForLoadingSuccessWithBanner(driver,"Operator details were updated successfully","updateusrdetails.do",TransferChat.etest);
        }
        catch(NullPointerException e)
        {
            TakeScreenshot.screenshot(driver,TransferChat.etest,"UpdateDetails","Error","Error",e);
        }
    }

    public static String transferMessageInVisitorWindow(WebDriver driver) throws Exception
    {
        return transferMessageInVisitorWindow(driver,1);
    }
    
    public static String transferMessageInVisitorWindow(WebDriver driver, final int count) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        try
        {
            VisitorWindow.switchToChatWidget(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgdiv")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("msgdiv")));
            
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            
            final WebElement div = CommonUtil.elfinder(driver,"id","msgdiv");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(div.findElements(By.className("siq-info-message")).size() == count)
                            return true;
                    }
                    catch(Exception e){}
                    return false;
                }
            });
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            
            List<WebElement> messages = div.findElements(By.className("siq-info-message"));
            
            return messages.get(messages.size()-1).getText();
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }
    }

    public static void changeStatus(WebDriver driver,String status) throws Exception
    {
        com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status);
    }

    public static void cleanUp(WebDriver driver1,WebDriver driver2,boolean d1,boolean d2)
    {
        try
        {
            if(d1)
            {
                clickChatInSupportActions(driver1);
                
                WebElement e = ChatWindow.chatInMyChats(driver1);
                
                if(CommonUtil.elementfinder(driver1,e,"id","infodiv").isDisplayed())
                {
                    ChatWindow.clickClosethisWindow(driver1);
                }
                else
                {
                    ChatWindow.endAndCloseChat(driver1);
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Transfer chat cleanup driver1 ");
            e.printStackTrace();
        }
        try
        {
            if(d2)
            {
                clickChatInSupportActions(driver2);
                
                WebElement e = ChatWindow.chatInMyChats(driver2);
                
                if(CommonUtil.elementfinder(driver2,e,"id","infodiv").isDisplayed())
                {
                    ChatWindow.clickClosethisWindow(driver2);
                }
                else
                {
                    ChatWindow.endAndCloseChat(driver2);
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Transfer chat cleanup driver2 ");
            e.printStackTrace();
        }
    }
    
    public static void waitTillTextAreaInVisible(WebDriver driver) throws Exception
    {
        WebElement e = ChatWindow.chatInMyChats(driver);
        
        WebElement textarea = CommonUtil.elementfinder(driver,e,"tagname","textarea");
        
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOf(textarea)));
    }
}
