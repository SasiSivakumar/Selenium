//$Id$
package com.zoho.livedesk.client.ChatTransfer;

import java.util.*;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.Triggers.CommonFunctions;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.VisitorWindow;
public class TransferChat
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static ExtentTest etest;
    public static String url = null;
    public static WebDriver driver2;
    public static boolean d1 = true,d2 = true;
    
    public static String widgetcode = "";
    public static String portal = "";
    
    public static String dept1 = "transferchat";
    public static String dept2 = "Automation";
    public static String embed2 = "transferchatembed2";
    
    public static Set<WebDriver> visDrivers = new HashSet<WebDriver>();
    
    public static Hashtable testtransferchat(WebDriver driver)
    {
        try
        {
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC1"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            
            portal=ExecuteStatements.getPortal(driver);
            widgetcode=ExecuteStatements.getWidgetCode(driver);
            
            d1 = false;d2 = false;

            CommonFunctionsTC.changeUserDept(driver,"Supervisor1",dept1);

            driver2 = Functions.setUp();
            Functions.login(driver2,"transferchat_supervisor");
            
            result.put("TC1",transferChatAcceptandCheckContent(driver,driver2,"Admin1","Supervisor1",false,false));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC10"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC10",transferChatAcceptandCheckContent(driver,driver2,"Admin1","Supervisor1",false,true));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);

            ComplexReportFactory.closeTest(etest);
        
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC2"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC2",transferChatAcceptandCheckContent(driver,driver2,"Admin1","Supervisor1",true,false));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC3"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC3",transferChatandReject(driver,driver2,"Admin1","Supervisor1",false));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC4"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC4",transferChatandReject(driver,driver2,"Admin1","Supervisor1",true));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC5"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC5",transferTransferedChat(driver,driver2,"Admin1","Supervisor1"));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC8"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC8",transferProActiveChat(driver,driver2,"Admin1","Supervisor1"));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC9"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC9",transferTriggeredChat(driver,driver2,"Admin1","Supervisor1"));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);

            com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC6"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC6",transferChatWithNoUser(driver,driver2,"Supervisor1",false));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            Thread.sleep(2000);

            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC7"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC7",transferChatToOtherDepartment(driver,driver2,"Supervisor1","Admin1",dept2));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);
            CommonFunctionsTC.changeUserDept(driver,"Supervisor1",dept1);
            Thread.sleep(2000);
    
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC11"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            d1 = false;d2 = false;
            
            result.put("TC11",transferChatWithNoUser(driver,driver2,"Supervisor1",true));
            CommonFunctionsTC.cleanUp(driver,driver2,d1,d2);

            ComplexReportFactory.closeTest(etest);

            driver2 = Functions.setUp();
            Functions.login(driver2,"transferchat_supervisor");

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC12"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            result.put("TC12",checkOperatorsShown(driver,driver2,true,etest,true));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC13"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            result.put("TC13",checkOperatorsShown(driver,driver2,false,etest,false));
            ComplexReportFactory.closeTest(etest);

            // changing the widget code for embed 2, in which department selection is available
            widgetcode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed2);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("TC14"));
            ComplexReportFactory.setValues(etest,"Automation","Transfer Chat");
            result.put("TC14",checkOperatorsShown(driver,driver2,false,etest,true));
            ComplexReportFactory.closeTest(etest);

            try
            {
                com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);
            }
            catch(Exception e1)
            {
                e1.printStackTrace();
                etest.log(Status.WARNING,"All triggers created in this module were not deleted, this could affect other modules running in this portal");
            }
        }
        catch(Exception e)
        {
            result.put("TC1", false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            etest.log(Status.FATAL,"Error occurred while checking network connection in transfer chat module : "+e);
            TakeScreenshot.screenshot(driver,etest,"TransferChat","TransferChat","Error",e);
        }
        
        closeDriver();
        
        ComplexReportFactory.closeTest(etest);
        
        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public static boolean transferChatAcceptandCheckContent(WebDriver driver1,WebDriver driver2,String transferTo,String transferFrom,boolean comment,boolean changeStatusToBusy) throws Exception
    {
        WebDriver visDriver = null;
        
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();
            String vdept = "transferchat";
            String commentcontent = "Comment"+t.toString();
            String agentMessage = "AM"+t.toString();
            String visitorMessage = "VM"+t.toString();

            if(changeStatusToBusy)
            {
                CommonFunctionsTC.changeStatus(driver1,"busy");
            }
            else
            {
                CommonFunctionsTC.changeStatus(driver1,"available");
            }
            
            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,null,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }

            try
            {
                FluentWait wait2 = CommonUtil.waitreturner(driver2,30,250);

                driver2.navigate().refresh();
            	CommonWait.waitTillDisplayed(driver2, By.id("waitinglist"));
                ChatWindow.acceptChat(driver2,etest);
                d2 = true;
                
                String[] content = CommonFunctionsTC.transferChatContent(driver2,etest,transferTo);

                String[] expected = {ResourceManager.getRealValue("transfer_popup_header"),transferFrom,transferTo,
                                        ResourceManager.getRealValue("transfer_popup_okbtn"),ResourceManager.getRealValue("transfer_popup_cancelbtn")};

                int i = 0;

                for(String s : content)
                {
                    if(!s.contains(expected[i]))
                    {
                        etest.log(Status.FAIL,"Actual:"+s+"--Expected:"+expected[i]+"--");
                        TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                        return false;
                    }
                    i++;
                }

                WebElement popup = CommonUtil.elfinder(driver2,"id","popupdiv");
                if(comment)
                {
                    CommonUtil.elementfinder(driver2,CommonUtil.elementfinder(driver2,popup,"id","seldiv"),"id","notes").sendKeys(commentcontent);
                    Thread.sleep(1000);
                }
                
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","Values","CheckBefore",0);

                CommonUtil.elementfinder(driver2,popup,"id","btnsub").click();

                wait2.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        try
                        {
                            if(!driver.findElement(By.id("popupdiv")).isDisplayed())
                                return true;
                        }
                        catch(Exception e){}
                        return false;
                    }
                });

            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }
            
            String acceptHeader = ResourceManager.getRealValue("transferaccept_popup_header").replace("transferFrom",transferFrom);

            int i = 6;

            if(comment)
                i++;

            String[] content = new String[i];
            String[] expected = new String[i];

            if(comment)
            {
                content = CommonFunctionsTC.acceptTransferedChatContent(driver1,true);

                expected = new String[]{acceptHeader,ResourceManager.getRealValue("transferaccept_popup_okbtn"),ResourceManager.getRealValue("transferaccept_popup_cancelbtn"),
                                    vname,vques,vdept,commentcontent};
            }
            else
            {
                content = CommonFunctionsTC.acceptTransferedChatContent(driver1,false);

                expected = new String[]{acceptHeader,ResourceManager.getRealValue("transferaccept_popup_okbtn"),ResourceManager.getRealValue("transferaccept_popup_cancelbtn"),
                                    vname,vques,vdept};
            }

            i = 0;

            for(String s : content)
            {
                if(!s.contains(expected[i]))
                {
                    etest.log(Status.FAIL,"Actual:"+s+"--Expected:"+expected[i]+"--");
                    TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                    return false;
                }
                i++;
            }
            
            CommonFunctionsTC.acceptTransferedChat(driver1,etest);
            d1 = true;
            
            CommonUtil.sleep(5000);

            Functions.refreshSiteAndWaitForRSID(driver1);
            
            try
            {
                CommonFunctionsTC.waitTillTextAreaInVisible(driver2);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }
            
            boolean note1 = true,note2 = true,note3 = true;

            CommonFunctionsTC.clickViewNotesinSupportActions(driver1);

            String transferNoteInNotes = CommonFunctionsTC.transferNoteInNotes(driver1);

            String transferNoteInNotesExpected = ResourceManager.getRealValue("transfer_info_notes").replace("transferFrom",transferFrom);
            transferNoteInNotesExpected = transferNoteInNotesExpected.replace("transferTo",transferTo);

            if(!transferNoteInNotes.contains(transferNoteInNotesExpected))
            {
                etest.log(Status.FAIL,"Actual:"+transferNoteInNotes+"--Expected:"+transferNoteInNotesExpected+"--");
                TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                note1 = false;
            }

            String transferAcceptNoteInNotes = CommonFunctionsTC.transferAcceptNoteInNotes(driver1);

            String transferAcceptNoteInNotesExpected = ResourceManager.getRealValue("transferaccept_info_notes").replace("transferFrom",transferFrom);
            transferAcceptNoteInNotesExpected = transferAcceptNoteInNotesExpected.replace("transferTo",transferTo);

            if(!transferAcceptNoteInNotes.contains(transferAcceptNoteInNotesExpected))
            {
                etest.log(Status.FAIL,"Actual:"+transferAcceptNoteInNotes+"--Expected:"+transferAcceptNoteInNotesExpected+"--");
                TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                note2 = false;
            }

            if(comment)
            {
                String transferCommentInNotes = CommonFunctionsTC.transferCommentInNotes(driver1);

                if(!transferCommentInNotes.contains(commentcontent))
                {
                    etest.log(Status.FAIL,"Actual:"+transferCommentInNotes+"--Expected:"+commentcontent+"--");
                    TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                    note2 = false;
                }
            }

            CommonFunctionsTC.clickChatInSupportActions(driver1);
                
            if(!note1 || !note2 || !note3)
            {
                return false;
            }

            String transferNoteInMessage = CommonFunctionsTC.transferNoteInMessage(driver1);

            String transferNoteInMessageExpected = ResourceManager.getRealValue("transfer_info_chat").replace("transferFrom",transferFrom);
            transferNoteInMessageExpected = transferNoteInMessageExpected.replace("transferTo",transferTo);

            if(!transferNoteInMessage.contains(transferNoteInMessageExpected))
            {
                etest.log(Status.FAIL,"Actual:"+transferNoteInMessage+"--Expected:"+transferNoteInMessageExpected+"--");
                TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                note1 = false;
            }

            String transferAcceptNoteInMessage = CommonFunctionsTC.transferAcceptNoteInMessage(driver1);

            String transferAcceptNoteInMessageExpected = ResourceManager.getRealValue("transferaccept_info_chat").replace("transferTo",transferTo);

            if(!transferAcceptNoteInMessage.contains(transferAcceptNoteInMessageExpected))
            {
                etest.log(Status.FAIL,"Actual:"+transferAcceptNoteInMessage+"--Expected:"+transferAcceptNoteInMessageExpected+"--");
                TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                note2 = false;
            }

            if(!note1 || !note2)
            {
                return false;
            }

            try
            {
                String transferMessageInVisitorWindow = CommonFunctionsTC.transferMessageInVisitorWindow(visDriver);
                
                String transferMessageInVisitorWindowExpected = ResourceManager.getRealValue("transfer_info_visitor").replace("transferTo",transferTo);

                if(!transferMessageInVisitorWindow.contains(transferMessageInVisitorWindowExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferMessageInVisitorWindow+"--Expected:"+transferMessageInVisitorWindowExpected+"--");
                    TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","MismatchContent");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }
            
            ChatWindow.sentMessage(driver1,agentMessage);
            
            try
            {
                if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,transferTo,agentMessage,1))
                {
                    etest.log(Status.FAIL,transferTo+":"+agentMessage+" is not found");
                    TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","AgentMessageNotFound");
                    return false;
                }
                
                VisitorWindow.sentMessageInTheme(visDriver,visitorMessage);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }

            ChatWindow.getLastMessageInUserWindow(driver1,visitorMessage);
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
            return false;
        }
    }

    public static boolean transferChatandReject(WebDriver driver1,WebDriver driver2,String transferTo,String transferFrom,boolean comment) throws Exception
    {
        WebDriver visDriver = null;
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();
            String commentcontent = "Comment"+t.toString();

            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,null,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatandReject","Error",e);
                return false;
            }

            try
            {
            	driver2.navigate().refresh();
        	    CommonWait.waitTillDisplayed(driver2, By.id("waitinglist"));      	
                ChatWindow.acceptChat(driver2,etest);
                
                d2 = true;

                if(comment)
                    CommonFunctionsTC.transferChat(driver2,etest,true,commentcontent,null,transferTo);
                else
                    CommonFunctionsTC.transferChat(driver2,etest,false,null,null,transferTo);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatandReject","Error",e);
                return false;
            }

            CommonFunctionsTC.rejectTransferedChat(driver1,etest);
         
            try
            {
                WebElement chats = ChatWindow.chatInMyChats(driver1);
                
                if(chats != null)
                {
                    if(chats.getAttribute("innerHTML").contains(vname))
                    {
                        etest.log(Status.FAIL,"Chat is found after rejecting");
                        TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatandReject","Error");
                        return false;
                    }
                }
                
            }
            catch(Exception e){}
            
            try
            {
                boolean note1 = true,note2 = true,note3 = true;

                String transferNoteInMessage = CommonFunctionsTC.transferNoteInMessage(driver2);
                
                String transferNoteInMessageExpected = ResourceManager.getRealValue("transfer_info_chat").replace("transferFrom",transferFrom);
                transferNoteInMessageExpected = transferNoteInMessageExpected.replace("transferTo",transferTo);

                if(!transferNoteInMessage.contains(transferNoteInMessageExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferNoteInMessage+"--Expected:"+transferNoteInMessageExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatandReject","MismatchContent");
                    note1 = false;
                }

                String transferRejectNoteInMessage = CommonFunctionsTC.transferRejectNoteInMessage(driver2);

                String transferRejectNoteInMessageExpected = ResourceManager.getRealValue("transferreject_info_chat").replace("transferTo",transferTo);

                if(!transferRejectNoteInMessage.contains(transferRejectNoteInMessageExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferRejectNoteInMessage+"--Expected:"+transferRejectNoteInMessageExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatandReject","MismatchContent");
                    note2 = false;
                }

                if(!note1 || !note2)
                {
                    return false;
                }

                CommonFunctionsTC.clickViewNotesinSupportActions(driver2);

                String transferNoteInNotes = CommonFunctionsTC.transferNoteInNotes(driver2);

                String transferNoteInNotesExpected = ResourceManager.getRealValue("transfer_info_notes").replace("transferFrom",transferFrom);
                transferNoteInNotesExpected = transferNoteInNotesExpected.replace("transferTo",transferTo);

                if(!transferNoteInNotes.contains(transferNoteInNotesExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferNoteInNotes+"--Expected:"+transferNoteInNotesExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatandReject","MismatchContent");
                    note1 = false;
                }

                String transferRejectNoteInNotes = CommonFunctionsTC.transferRejectNoteInNotes(driver2);

                String transferRejectNoteInNotesExpected = ResourceManager.getRealValue("transferreject_info_notes").replace("transferFrom",transferFrom);
                transferRejectNoteInNotesExpected = transferRejectNoteInNotesExpected.replace("transferTo",transferTo);

                if(!transferRejectNoteInNotes.contains(transferRejectNoteInNotesExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferRejectNoteInNotes+"--Expected:"+transferRejectNoteInNotesExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatandReject","MismatchContent");
                    note2 = false;
                }

                if(comment)
                {
                    String transferCommentInNotes = CommonFunctionsTC.transferCommentInNotes(driver2);

                    if(!transferCommentInNotes.contains(commentcontent))
                    {
                        etest.log(Status.FAIL,"Actual:"+transferCommentInNotes+"--Expected:"+commentcontent+"--");
                        TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatandReject","MismatchContent");
                        note2 = false;
                    }
                }

                CommonFunctionsTC.clickChatInSupportActions(driver2);
                    
                if(!note1 || !note2 || !note3)
                {
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatAndReject","Error",e);
                return false;
            }

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAndReject","Error",e);
            return false;
        }
    }

    public static boolean transferTransferedChat(WebDriver driver1,WebDriver driver2,String transferTo,String transferFrom) throws Exception
    {
        WebDriver visDriver = null;
        
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();
            
            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,null,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferTransferedChat","Error",e);
                return false;
            }
            
            try
            {
                FluentWait wait2 = CommonUtil.waitreturner(driver2,30,250);
                driver2.navigate().refresh();
            	CommonWait.waitTillDisplayed(driver2, By.id("waitinglist"));
                ChatWindow.acceptChat(driver2,etest);
                d2 = true;
                
                CommonFunctionsTC.transferChat(driver2,etest,false,null,null,transferTo);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferTransferedChat","Error",e);
                return false;
            }
            
            CommonFunctionsTC.acceptTransferedChat(driver1,etest);
            d1 = true;

            try
            {
                String transferMessageInVisitorWindow = CommonFunctionsTC.transferMessageInVisitorWindow(visDriver);
                
                String transferMessageInVisitorWindowExpected = ResourceManager.getRealValue("transfer_info_visitor").replace("transferTo",transferTo);

                if(!transferMessageInVisitorWindow.contains(transferMessageInVisitorWindowExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferMessageInVisitorWindow+"--Expected:"+transferMessageInVisitorWindowExpected+"--");
                    TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferTransferedChat","MismatchContent");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferTransferedChat","Error",e);
                return false;
            }

            CommonFunctionsTC.transferChat(driver1,etest,false,null,null,transferFrom);

            try
            {
                CommonFunctionsTC.acceptTransferedChat(driver2,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferTransferedChat","Error",e);
                return false;
            }

            try
            {
                Thread.sleep(1000);

                String transferMessageInVisitorWindow = CommonFunctionsTC.transferMessageInVisitorWindow(visDriver,2);
                
                String transferMessageInVisitorWindowExpected = ResourceManager.getRealValue("transfer_info_visitor").replace("transferTo",transferFrom);

                if(!transferMessageInVisitorWindow.contains(transferMessageInVisitorWindowExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferMessageInVisitorWindow+"--Expected:"+transferMessageInVisitorWindowExpected+"--");
                    TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferTransferedChat","MismatchContent");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferTransferedChat","Error",e);
                return false;
            }

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferTransferedChat","Error",e);
            return false;
        }
    }

    public static boolean transferChatWithNoUser(WebDriver driver1,WebDriver driver2,String transferTo,boolean logout) throws Exception
    {
        WebDriver visDriver = null;
        
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            if(logout)
            {
                try
                {
                    Functions.logout(driver2);
                    
                    Thread.sleep(15000);
                }
                catch(Exception e)
                {
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatWithNoOperators","Error",e);
                    return false;
                }
                

                com.zoho.livedesk.util.common.actions.Status.waitTillAgentStatusChange(driver1,transferTo,"offline");
            }
            else
            {
                CommonFunctionsTC.changeUserDept(driver1,transferTo,dept2);
            }

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();

            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,null,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatWithNoOperators","Error",e);
                return false;
            }
            
            driver1.navigate().refresh();
        	CommonWait.waitTillDisplayed(driver1, By.id("waitinglist"));
            ChatWindow.acceptChat(driver1,etest);
            d1 = true;

            Tab.clickMyChats(driver1);
            
            CommonFunctionsTC.clickTransferChat(driver1,etest);

            final WebElement container = CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"id","popupdiv"),"id","usrcontainer");

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(!container.getText().contains("Loading"))
                            return true;
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            String content = container.getText();

            if(!content.contains(ResourceManager.getRealValue("no_users_to_transfer")))
            {
                etest.log(Status.FAIL,"MismatchContent:Actual"+content+"--Expected:"+ResourceManager.getRealValue("no_users_to_transfer")+"--");
                TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatWithNoOperators","MismatchContent");
                CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"id","popupdiv"),"classname","lvd_popupclg").click();
                return false;
            }

            CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"id","popupdiv"),"classname","lvd_popupclg").click();
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatWithNoOperators","Error",e);
            return false;
        }
    }

    public static boolean transferChatToOtherDepartment(WebDriver driver1,WebDriver driver2,String transferTo,String transferFrom,String transferToDept) throws Exception
    {
        WebDriver visDriver = null;
        
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();

            CommonFunctionsTC.changeUserDept(driver1,transferTo,transferToDept);
            
            Thread.sleep(5000);
            
            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,null,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatToOtherDepartment","Error",e);
                return false;
            }
            
            driver1.navigate().refresh();
        	CommonWait.waitTillDisplayed(driver1, By.id("waitinglist"));
            ChatWindow.acceptChat(driver1,etest);
            d1 = true;
            
            CommonFunctionsTC.transferChat(driver1,etest,false,null,transferToDept,transferTo);

            try
            {
                CommonFunctionsTC.acceptTransferedChat(driver2,etest);
                d2 = true;

                CommonUtil.sleep(5000);
                Functions.refreshSiteAndWaitForRSID(driver2);
                
                boolean note1 = true,note2 = true;

                CommonFunctionsTC.clickViewNotesinSupportActions(driver2);

                String transferNoteInNotes = CommonFunctionsTC.transferNoteInNotes(driver2);

                String transferNoteInNotesExpected = ResourceManager.getRealValue("transfer_info_notes").replace("transferFrom",transferFrom);
                transferNoteInNotesExpected = transferNoteInNotesExpected.replace("transferTo",transferTo);

                if(!transferNoteInNotes.contains(transferNoteInNotesExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferNoteInNotes+"--Expected:"+transferNoteInNotesExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatToOtherDepartment","MismatchContent");
                    note1 = false;
                }

                String transferAcceptNoteInNotes = CommonFunctionsTC.transferAcceptNoteInNotes(driver2);

                String transferAcceptNoteInNotesExpected = ResourceManager.getRealValue("transferaccept_info_notes").replace("transferFrom",transferFrom);
                transferAcceptNoteInNotesExpected = transferAcceptNoteInNotesExpected.replace("transferTo",transferTo);

                if(!transferAcceptNoteInNotes.contains(transferAcceptNoteInNotesExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferAcceptNoteInNotes+"--Expected:"+transferAcceptNoteInNotesExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatToOtherDepartment","MismatchContent");
                    note2 = false;
                }

                CommonFunctionsTC.clickChatInSupportActions(driver2);
                    
                if(!note1 || !note2)
                {
                    return false;
                }

                String transferNoteInMessage = CommonFunctionsTC.transferNoteInMessage(driver2);

                String transferNoteInMessageExpected = ResourceManager.getRealValue("transfer_info_chat").replace("transferFrom",transferFrom);
                transferNoteInMessageExpected = transferNoteInMessageExpected.replace("transferTo",transferTo);

                if(!transferNoteInMessage.contains(transferNoteInMessageExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferNoteInMessage+"--Expected:"+transferNoteInMessageExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatToOtherDepartment","MismatchContent");
                    note1 = false;
                }

                String transferAcceptNoteInMessage = CommonFunctionsTC.transferAcceptNoteInMessage(driver2);

                String transferAcceptNoteInMessageExpected = ResourceManager.getRealValue("transferaccept_info_chat").replace("transferTo",transferTo);

                if(!transferAcceptNoteInMessage.contains(transferAcceptNoteInMessageExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferAcceptNoteInMessage+"--Expected:"+transferAcceptNoteInMessageExpected+"--");
                    TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatToOtherDepartment","MismatchContent");
                    note2 = false;
                }

                if(!note1 || !note2)
                {
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatToOtherDepartment","Error",e);
                return false;
            }


            try
            {
                String transferMessageInVisitorWindow = CommonFunctionsTC.transferMessageInVisitorWindow(visDriver);
                
                String transferMessageInVisitorWindowExpected = ResourceManager.getRealValue("transfer_info_visitor").replace("transferTo",transferTo);

                if(!transferMessageInVisitorWindow.contains(transferMessageInVisitorWindowExpected))
                {
                    etest.log(Status.FAIL,"Actual:"+transferMessageInVisitorWindow+"--Expected:"+transferMessageInVisitorWindowExpected+"--");
                    TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatToOtherDepartment","MismatchContent");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatToOtherDepartment","Error",e);
                return false;
            }
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatToOtherDepartment","Error",e);
            return false;
        }
    }

    public static boolean transferProActiveChat(WebDriver driver1,WebDriver driver2,String transferTo,String transferFrom) throws Exception
    {
        WebDriver visDriver = null;
        
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();

            visDriver = setUp();
            
            String id = null;
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                id = VisitorWindow.getVisitorId(visDriver,portal);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }
            
            try
            {
                FluentWait wait2 = CommonUtil.waitreturner(driver2,30,250);

                ChatWindow.initiateChat(driver2,id,"welcome");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }

            Thread.sleep(3000);
            
            try
            {
                VisitorWindow.sentMessageInTheme(visDriver,"hello",true);
                Thread.sleep(3000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }

            try
            {
            	driver2.navigate().refresh();
            	CommonWait.waitTillDisplayed(driver2, By.id("waitinglist"));
                ChatWindow.acceptChat(driver2,etest);
                d2 = true;

                CommonFunctionsTC.transferChat(driver2,etest,false,null,null,transferTo);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
                return false;
            }
            
            CommonFunctionsTC.acceptTransferedChat(driver1,etest);
            d1 = true;

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferChatAcceptandCheckContent","Error",e);
            return false;
        }
    }

    public static boolean transferTriggeredChat(WebDriver driver1,WebDriver driver2,String transferTo,String transferFrom) throws Exception
    {
        WebDriver visDriver = null;
        
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);

            Long t = new Long(System.currentTimeMillis());

            String vname = "Visitor"+t.toString();
            String vemail = "email@"+t.toString()+".com";
            String vques = "ques"+t.toString();

            Trigger.addTrigger(driver1,etest,"Lands on my website","Visitor Type","is equal to","All",null,"Send chat invite","3 Seconds","Automation","Hey!!!");
            
            Thread.sleep(2000);
            
            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
               CommonUtil.sleep(3000);
               if(!CommonFunctions.checkSendChat(visDriver,"Automation","Hey!!!",5)) {
            	 etest.log(Status.FAIL, "Trigger not applied");
            	 TakeScreenshot.screenshot(visDriver, etest);
            	  return false;
              }
              etest.log(Status.INFO, "Trigger applied");
        	  TakeScreenshot.infoScreenshot(visDriver, etest);              
                VisitorWindow.sentMessageInTheme(visDriver,"hello");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","TransferTriggeredChat","Error",e);
                return false;
            }
            
            try
            {
                FluentWait wait2 = CommonUtil.waitreturner(driver2,30,250);
                driver2.navigate().refresh();
            	CommonWait.waitTillDisplayed(driver2, By.id("waitinglist"));
                ChatWindow.acceptChat(driver2,etest);
                d2 = true;

                CommonFunctionsTC.transferChat(driver2,etest,false,null,null,transferTo);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"TransferChat","TransferTriggeredChat","Error",e);
                return false;
            }

            CommonFunctionsTC.acceptTransferedChat(driver1,etest);
            d1 = true;

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","TransferTriggeredChat","Error",e);
            return false;
        }
    }

    public static boolean checkOperatorsShown(WebDriver driver1,WebDriver driver2,boolean isAgentPartOfTheDepartment,ExtentTest etest,boolean department)
    {
        WebDriver visDriver = null;
        int failcount = 0;
        String deptname = (isAgentPartOfTheDepartment)?"AllOperators":"supervisor_alone";
        String type = "depttype_publi";
        String users = "";
        try
        {
            String label = CommonUtil.getUniqueMessage();
            String vname = "Visitor"+label;
            String vemail = "email@"+label+".com";
            String vques = "ques"+label;
            String commentcontent = "Comment"+label;

            if(department)
            {
            	
                Tab.clickSettings(driver1);
                List<WebElement> operatorsList = CommonUtil.getElement(driver1,By.id("ulisttable")).findElements(By.className("list-row"));
                for(WebElement operator : operatorsList)
                {
                    users += CommonUtil.getElement(operator,By.className("ulist_uname"),By.className("txtelips")).getText() + " ";
                }

                if(isAgentPartOfTheDepartment)
                {
                    Department.addDept(driver1,deptname,type,users,etest);
                }
                else
                {
                    String supervisor = ExecuteStatements.getUserName(driver2);
                    Department.addDept(driver1,deptname,type,supervisor,etest);
                }
            }
            
            visDriver = setUp();
            
            try
            {
                VisitorWindow.createPage(visDriver,widgetcode);
                VisitorWindow.initiateChatVisTheme(visDriver,vname,vemail,null,deptname,vques,etest);
            }
            catch(Exception e)
            {
            	
                TakeScreenshot.screenshot(visDriver,etest,"TransferChat","checkOperatorsShown","Error",e);
                Tab.clickSettings(driver1);
                Department.deleteDepartment(driver1,deptname,dept1,etest);
                return false;
            }
            driver2.navigate().refresh();
            ChatWindow.acceptChat(driver2,etest);
            CommonUtil.refreshPage(driver2);

            CommonFunctionsTC.clickTransferChat(driver2,etest);

            List<WebElement> deptList = CommonUtil.getElement(driver2,By.id("popupdiv"),By.id("transdeptlst")).findElements(By.tagName("li"));
            WebElement departmentToTransfer = null;

            if(isAgentPartOfTheDepartment)
            {
                // agent is common in present in both departments >> transferchat -> AllOperators
                departmentToTransfer = CommonUtil.getElementByAttributeValue(deptList,"innerText",deptname);
            }
            else
            {
                // transferring agent present in one department and accepting agent present in another department >> supervisor_alone -> Automation (or)
                // agent is present in chat initiated department but not in chat accepted department >> transferchat -> Automation
                departmentToTransfer = CommonUtil.getElementByAttributeValue(deptList,"innerText",dept2);
            }

            CommonUtil.clickWebElement(driver2,departmentToTransfer);

            WebElement userList = CommonUtil.getElement(driver2,By.id("popupdiv"),By.id("userlist"));

            CommonUtil.sleep(1000);

            if(isAgentPartOfTheDepartment)
            {
                if(userList.isDisplayed())
                {
                    etest.log(Status.PASS,"Operator details were displayed for the department where the agent is part of");
                    TakeScreenshot.infoScreenshot(driver2,etest);
                    CommonUtil.clickWebElement(driver2,CommonUtil.getElement(driver2,By.id("popupdiv"),By.id("usrcontainer"),By.tagName("li")));
                }
                else
                {
                    etest.log(Status.FAIL,"Operator details were not displayed for the department where the agent is part of");
                    TakeScreenshot.screenshot(driver2,etest);
                    failcount++;
                }
            }
            else
            {
                if(userList.isDisplayed())
                {
                    etest.log(Status.FAIL,"Operator details were shown for the department where the agent is not part of");
                    TakeScreenshot.screenshot(driver2,etest);
                    failcount++;
                }
                else
                {
                    etest.log(Status.PASS,"Operator details were not shown for the department where the agent is not part of");
                    TakeScreenshot.infoScreenshot(driver2,etest);
                }
            }

            CommonWait.waitTillDisplayed(driver2,By.id("popupdiv"),By.id("seldiv"));

            CommonUtil.clickWebElement(driver2,CommonUtil.getElement(driver2,By.id("popupdiv"),By.id("btnsub")));
            CommonWait.waitTillDisplayed(driver1, By.className("lvd_popupsub"));
            CommonFunctionsTC.acceptInvite(driver1,etest);

            try
            {

                CommonWait.waitTillDisplayed(driver1,By.id("suppm_mycurrent"));
                etest.log(Status.PASS,"Chat was accepted from admin");
                CommonWait.waitTillDisplayed(driver1,By.id("suppm_current"));
                boolean isConnectedTabShown = SettingsTab.checkConnectedTabShown(driver2);
                if((isAgentPartOfTheDepartment) != isConnectedTabShown)
                {
                    etest.log(Status.FAIL,"Connected tab was "+((isConnectedTabShown)?"":"not")+" shown in the transferring operator dashboard");
                    failcount++;
                    TakeScreenshot.screenshot(driver2,etest);
                }
                else
                {
                    etest.log(Status.PASS,"Connected tab was "+((isConnectedTabShown)?"":"not")+" shown in the transferring operator dashboard");
                    TakeScreenshot.infoScreenshot(driver2,etest);
                }
            }
            catch(Exception e)
            {
                etest.log(Status.FAIL,"Chat was not accepted by admin");
                TakeScreenshot.screenshot(driver1,etest);
                TakeScreenshot.screenshot(driver2,etest);
                failcount++;
            }

            ChatWindow.closeAllChats(driver1);
            ChatWindow.closeAllChats(driver2);

            etest.log(Status.INFO,"Chat was ended and closed from agent side");
            TakeScreenshot.infoScreenshot(driver1,etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"TransferChat","checkOperatorsShown","Error",e);
            TakeScreenshot.screenshot(driver2,etest,"TransferChat","checkOperatorsShown","Error",e);
            failcount++;
        }
        finally
        {
            try
            {
                if(!isAgentPartOfTheDepartment)
                {

                    Tab.clickSettings(driver1);
                    Department.deleteDepartment(driver1,deptname,dept1,etest);
                }
            }
            catch(Exception e)
            {
                etest.log(Status.WARNING,"Department 'All Operators' was not deleted");
            }

            return CommonUtil.returnResult(failcount);
        }
    }
    
    public static void closeDriver()
    {
        for(WebDriver visDriver : visDrivers)
        {
            try
            {
                visDriver.quit();
            }
            catch(Exception e){}
        }
        
        visDrivers = new HashSet<WebDriver>();
    }
    
    public static WebDriver setUp() throws Exception
    {
        closeDriver();
        
        WebDriver driver = Functions.setUp();
        
        visDrivers.add(driver);
        
        return driver;
    }
}
