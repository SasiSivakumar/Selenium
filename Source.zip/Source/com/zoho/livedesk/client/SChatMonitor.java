//$Id$
package com.zoho.livedesk.client;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions;
import com.zoho.livedesk.util.common.actions.Trigger;


import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.CommonUtil;

public class SChatMonitor
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	public static ExtentTest etest; 
	
	public static Hashtable chatMonitor(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM1"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

            url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			etest.log(Status.PASS,"Chat Monitor Tab is found");

			result.put("SSCM1", true);
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM2"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM2", isPageAvail(driver));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM3"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM3", addMonitor(driver, "VisitorEmail", "rajkumar.natarajan+123@zohocorp.com"));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM4"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM4", addMonitor(driver, "IpAddress", "123.1.1.1"));           
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM5"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM5", addInvalidValue(driver,"VisitorEmail","rajkumar.natarajan"));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM6"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM6", addInvalidValue(driver,"IpAddress","1234"));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM7"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM7", disableChatMonitor(driver,"rajkumar.natarajan+123@zohocorp.com"));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM8"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM8", enableChatMonitor(driver,"rajkumar.natarajan+123@zohocorp.com"));
			
			//result.put("SCM9", showOnlyMyMonitors(driver));
			
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSCM9"));
            ComplexReportFactory.setValues(etest,"Automation","ChatMonitor-Supervisor");

			result.put("SSCM9", deleteChatMonitor(driver,"rajkumar.natarajan+123@zohocorp.com"));
			
            ComplexReportFactory.closeTest(etest);
            
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorChatMonitorTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","ChatMonitortab","ErrorWhileCheckingChatMonitortab",e);

			result.put("SSCM1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorChatMonitorTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","ChatMonitortab","ErrorWhileCheckingChatMonitortab",e);

			result.put("SSCM1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	//Check Chat monitor Header
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
            
			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));
			Thread.sleep(1000);
            
			if(((text.get(0).getText()).contains(ResourceManager.getRealValue("settings_monitor_desc3"))) && ((text.get(1).getText()).contains(ResourceManager.getRealValue("settings_monitor_desc4"))))
			{
				etest.log(Status.PASS,"Chat Monitor Page is found");

				return true;
			}
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","ChatMonitorPage","MismatchDescription");
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","ChatMonitorPage","ErrorWhileCheckingChatMonitorPage",e);
            System.out.println("Exception while checking if chat monitor settings page is available in supervisor login : "+e);
            return false;
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","ChatMonitorPage","ErrorWhileCheckingChatMonitorPage",e);
            System.out.println("Exception while checking if chat monitor settings page is available in supervisor login : "+e);
            return false;
        }
		return false;
	}
	
	//Add Chat Monitor
	private static boolean addMonitor(WebDriver driver, String type, String value)
	{
        String typeid = null;
        String ipid = null;
        
        if(type.equals("VisitorEmail"))
        {
            typeid = "cmvisitoremail";
            ipid = "cmvisitoremailinput";
        }
        else if(type.equals("IpAddress"))
        {
            typeid = "cmipaddress";
            ipid = "cmipaddressinput";
        }
        else
        {
            typeid = "cmsupportrep";
            ipid = "cmsupportrepinput";
        }
        
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

            Trigger.clickAddButtonAutomationTab(driver,"chatmonitortab");
			
			//Check chat add monitor page
			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_addchatmonitor")+"')]"));
		 	
		 	//Add chat monitor
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(typeid)));
		 	
		 	driver.findElement(By.id(typeid)).click();
		 	driver.findElement(By.id(ipid)).sendKeys(value);
		 	Thread.sleep(300);
		 	driver.findElement(By.id("ipsavebtn")).click();
		 	
		 	try
		 	{
		 		if(driver.findElement(By.className("lvd_popuptitle")) != null)
		 		{
		 			if((driver.findElement(By.className("lvd_popuptitle")).getText()).equals(ResourceManager.getRealValue("setting_alert")))
		 			{
		 				TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","AddMonitor:"+type,"AlertIsFoundWhileAddingChatMonitor");
		 				driver.findElement(By.id("okbtn")).click();
		 				driver.findElement(By.id("btncancel")).click();
		 				return false;
		 			}
		 		}
		 	}
		 	catch(NoSuchElementException e)
		 	{
		 	}
		 	return checkAddedValue(driver, type, value);
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","AddMonitor:"+type,"ErrorWhileAddingChatMonitor"+type,e);
            System.out.println("Exception while adding chat monitor in chat monitor settings page in supervisor login : "+e);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","AddMonitor:"+type,"ErrorWhileAddingChatMonitor"+type,e);
            System.out.println("Exception while adding chat monitor in chat monitor settings page in supervisor login : "+e);
        }
		return false;
	}
	
	//Get User Name
	private static String getUserName(WebDriver driver)
	{
		String knownas = "";
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_myprofile"))).click();
            
			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("test")));
            
			WebElement elmt = driver.findElement(By.id("test"));
			List<WebElement> userdetails = elmt.findElements(By.tagName("div"));
			knownas = userdetails.get(1).findElement(By.tagName("h2")).getText();
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","GetOperatorName","Error",e);
            System.out.println("Exception while getting Operatorname in chat monitor settings page in supervisor login : "+e);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","GetOperatorName","Error",e);
            System.out.println("Exception while getting Operatorname in chat monitor settings page in supervisor login : "+e);
        }
		return knownas;
	}
	
	//Check Add Chat Monitor Value
	private static boolean checkAddedValue(WebDriver driver, String type, String value)
	{
		try
		{
			String user = getUserName(driver);
			if(user.isEmpty())
			{
				user = ConfManager.getUserName();
			}
			
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt1 = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            
			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				//String agent = elmt.findElement(By.tagName("a")).getText();
				if(data.equals(value))
				{
					//if(user.equals(agent))
					//{
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    String img_type = em.get(1).getAttribute("class");
                    if(type.equals("IpAddress"))
                    {
                        if(img_type.contains("ipadrs-img"))
                        {
                            etest.log(Status.PASS,"Addded Chat Monitor is found");

							return true;
                        }
                    }
                    else if(type.equals("VisitorEmail"))
                    {
                        if(img_type.contains("vistr-img"))
                        {
                            etest.log(Status.PASS,"Addded Chat Monitor is found");

							return true;
                        }
                    }
                    etest.log(Status.PASS,"Addded Chat Monitor is found");

					return true;
					//}
				}
			}
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","CHeckAddedChatMonitor:"+type,"AddedChatMonitorIsNotPresent");
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","CHeckAddedChatMonitor:"+type,"ErrorWhileCheckingAddedChatMonitor",e);
            System.out.println("Exception while checking added chat monitor in chat monitor settings page in supervisor login : "+e);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","CHeckAddedChatMonitor"+type,"ErrorWhileCheckingAddedChatMonitor",e);
            System.out.println("Exception while checking added chat monitor in chat monitor settings page in supervisor login : "+e);
        }
		return false;
	}
	
	//Add Chat Monitor Invalid Values
    private static boolean addInvalidValue(WebDriver driver, String type, String value)
    {
        String typeid = null;
        String ipid = null;
        int valnum = 0;
        int trycnt = 1;

        if(type.equals("VisitorEmail"))
        {
            typeid = "cmvisitoremail";
            ipid = "cmvisitoremailinput";
            valnum = 2;
        }
        else if(type.equals("IpAddress"))
        {
            typeid = "cmipaddress";
            ipid = "cmipaddressinput";
            valnum = 1;
        }
        else
        {
            typeid = "cmsupportrep";
            ipid = "cmsupportrepinput";
            valnum = 0;
        }
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            CommonUtil.click(driver,By.cssSelector("[documentclick='addChatMonitor' i]"));
            
            //Check chat add monitor page
            driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_addchatmonitor")+"')]"));
            
            //Add chat monitor
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(typeid)));
            driver.findElement(By.id(typeid)).click();
            driver.findElement(By.id(ipid)).sendKeys(value);
            Thread.sleep(300);
            driver.findElement(By.id("ipsavebtn")).click();
            
            Thread.sleep(500);
            
            while(trycnt<3)
            {
                trycnt++;
                
                WebElement erelmt = driver.findElement(By.id("keyvaluediv")).findElements(By.className("left_label")).get(valnum).findElement(By.tagName("em"));
                
                System.out.println("Visibility : >>>>"+erelmt.getAttribute("style"));
                
                if(erelmt.getAttribute("style").equals("visibility: visible;"))
                {
                	etest.log(Status.PASS,"Add InvalidValue for "+type+" is checked");
				    driver.findElement(By.id("btncancel")).click();
                    return true;
                }
            }
            
            try
            {
                if(driver.findElement(By.className("lvd_popuptitle")) != null)
                {
                    if((driver.findElement(By.className("lvd_popuptitle")).getText()).equals(ResourceManager.getRealValue("setting_alert")))
                    {
                        driver.findElement(By.id("okbtn")).click();
                        driver.findElement(By.id("btncancel")).click();
                        etest.log(Status.PASS,"Addded Chat Monitor is not found");

						return true;
                    }
                }
            }
            catch(NoSuchElementException e)
            {
            }
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","AddInvalidChatMonitor","MismatchAlertContent");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","AddInvalidChatMonitor","ErrorWhileAddingInvalidChatMonitor",e);
            System.out.println("Exception while adding invalid chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","AddInvalidChatMonitor","ErrorWhileAddingInvalidChatMonitor",e);
            System.out.println("Exception while adding invalid chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        return true;
    }
    
    //Disable Chat Monitor
    private static boolean disableChatMonitor(WebDriver driver, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            
            WebElement elmt1 = driver.findElement(By.id("listview"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                if(elmt.getText().contains(value))
                {
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    em.get(1).click();
                    break;
                    
                }
            }
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listviewdata")));
            
            if((driver.findElement(By.id("cmstatus")).getText()).equals(ResourceManager.getRealValue("common_disabled")))
            {
                enableChatMonitor(driver,value);
            }
            
            driver.findElement(By.id("btn")).click();
            
            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
                       {
                           public Boolean apply(WebDriver driver)
                           {
                               if((driver.findElement(By.id("btn")).getAttribute("class")).contains("cmn_gbutclor"))
                               {
                                   return true;
                               }
                               return false;
                           }
                       });
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            elmt1 = driver.findElement(By.id("listview"));
            elmts = elmt1.findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                if(elmt.getText().contains(value))
                {
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    em.get(1).click();
                    break;
                }
            }
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listviewdata")));
            
            if((driver.findElement(By.id("cmstatus")).getText()).equals((ResourceManager.getRealValue("common_disabled"))))
            {
                etest.log(Status.PASS,"Disable Chat Monitor is checked");

				return true;
            }
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DisableChatMonitor","ChatMonitorIsNotDisabled");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DisableChatMonitor","ErrorWhileDisblingChatMonitor",e);
            System.out.println("Exception while checking disable chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DisableChatMonitor","ErrorWhileDisblingChatMonitor",e);
            System.out.println("Exception while checking disable chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        return false;
    }
    
    //Enable Chat Monitor
    private static boolean enableChatMonitor(WebDriver driver, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            WebElement elmt1 = driver.findElement(By.id("listview"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                if(elmt.getText().contains(value))
                {
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    em.get(1).click();
                    break;
                }
            }
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listviewdata")));
            
            if((driver.findElement(By.id("cmstatus")).getText()).equals(ResourceManager.getRealValue("common_enabled")))
            {
                disableChatMonitor(driver,value);
            }
            driver.findElement(By.id("btn")).click();
            
            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
                       {
                           public Boolean apply(WebDriver driver)
                           {
                               if((driver.findElement(By.id("btn")).getAttribute("class")).contains("cmn_redbut"))
                               {
                                   return true;
                               }
                               return false;
                           }
                       });
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            elmt1 = driver.findElement(By.id("listview"));
            elmts = elmt1.findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                if(elmt.getText().contains(value))
                {
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    em.get(1).click();
                    break;
                }
            }
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listviewdata")));
            
            if((driver.findElement(By.id("cmstatus")).getText()).equals(ResourceManager.getRealValue("common_enabled")))
            {
                etest.log(Status.PASS,"Enable Chat Monitor is checked");

				return true;
            }
            else{
            	TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","EnableChatMonitor","ChatMonitorIsNotEnabled");
            
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","EnableChatMonitor","ErrorWhileEnablingChatMonitor",e);
            System.out.println("Exception while checking enable chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","EnableChatMonitor","ErrorWhileEnablingChatMonitor",e);
            System.out.println("Exception while checking enable chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        return false;
    }
    
    //Show only my monitors
    private static boolean showOnlyMyMonitors(WebDriver driver)
    {
        try
        {
            String user = getUserName(driver);
            if(user.isEmpty())
            {
                user = ConfManager.getUserName();
            }
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_chatmonitor"))).click();
            Thread.sleep(1000);
            
            if((driver.findElement(By.id("cmonitoractions"))).getAttribute("style").equals("display: none;"))
            {
                return true;
            }
            else
            {
                if(driver.findElement(By.id("chkmonitorme")) != null)
                {
                    driver.findElement(By.id("chkmonitorme")).click();
                }
            }
            
            WebElement elmt1 = driver.findElement(By.id("listview"));
            Thread.sleep(1000);
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
			
            for(WebElement elmt:elmts)
            {
                String agent = elmt.findElement(By.tagName("a")).getText();
                if(!(user.equals(agent)))
                {
                    return false;
                }
            }
            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking show only my monitors in chat monitor settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking show only my monitors in chat monitor settings page in supervisor login : "+e);
        }
        return false;
    }
    
    //Delete Chat Monitor
    public static boolean deleteChatMonitor(WebDriver driver, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Chat Monitor view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            WebElement elmt1 = driver.findElement(By.id("listview"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                if(elmt.getText().contains(value))
                {
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    mouseOver(driver,em.get(2));
                    em.get(2).click();
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                    driver.findElement(By.id("okbtn")).click();
                    
                    Thread.sleep(3000);
                    
                    WebElement elmt3 = driver.findElement(By.id("listview"));
                    List<WebElement> elmts1 = elmt3.findElements(By.className("list-row"));
                    
                    for(WebElement elmt2:elmts1)
                    {
                        List<WebElement> em1 = elmt2.findElements(By.tagName("em"));
                        if(em1.get(1).getText().equals(value))
                        {
                            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DeleteChatMonitor","ChatMonitorIsNotDeleted");
            				return false;
                        }
                    }
                    etest.log(Status.PASS,"Delete Chat Monitor is checked");

					return true;
                }
            }
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DeleteChatMonitor","ChatMonitorIsListed");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DeleteChatMonitor","ErrorWhileDeletingChatMonitor",e);
            System.out.println("Exception while deleting chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"ChatMonitor-Supervisor","DeleteChatMonitor","ErrorWhileDeletingChatMonitor",e);
            System.out.println("Exception while deleting chat monitor in chat monitor settings page in supervisor login : "+e);
        }
        return false;
    }
    
    //Clear chat monitor
    public static boolean clearChatMonitor(WebDriver driver)
    {
        try
        {
            deleteChatMonitor(driver,"rajkumar.natarajan+123@zohocorp.com");
            deleteChatMonitor(driver,"123.1.1.1");
            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clearing settings in chat monitor settings page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing settings in chat monitor settings page : "+e);
        }
        return false;
    }
    
    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
}
