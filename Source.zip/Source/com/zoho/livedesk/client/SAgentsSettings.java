//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class SAgentsSettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    
	private static String url = ConfManager.getLoginURL();
	private static String requrl = "";
	public static ExtentTest etest; 

    public static final String
    MODULE_NAME = "OperatorSettings-Supervisor"
    ;
    
	public static Hashtable agentsConfig(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU1"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");
            
            requrl = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            etest.log(Status.PASS,KeyManager.getRealValue("SSU1")+" is checked");

            result.put("SSU1", true);
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU2"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU2", isPageAvail(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU3"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU3", isaddPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU4"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU4", isHeadersPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU5"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU5", isActionPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU6"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU6", checkprofile(driver,"LDSupervisor",true));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU7"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU7", checkprofile(driver,"LDAssociate",true));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSU8"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Supervisor");

            result.put("SSU8", !(checkprofile(driver,"LDAutomation",false)));

            ComplexReportFactory.closeTest(etest);

            AgentsSettings.init();

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("SSU9"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("SSU9",AgentsSettings.checkOperatorStatusChangeOption(driver,AgentsSettings.admin_email,false,etest));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("SSU10"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("SSU10",AgentsSettings.checkOperatorStatusChangeOption(driver,AgentsSettings.supervisor_email,false,etest));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("SSU11"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("SSU11",AgentsSettings.checkOperatorStatusChangeOption(driver,AgentsSettings.associate_email,false,etest));
            ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
            etest.log(Status.FATAL,"ErrorAgentSettingsTab");

            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AgentsSettingTab","ErrorWhileCheckingAgentsSettingTab",e);

            result.put("SSU1", false);
		}
		catch(Exception e)
		{
            etest.log(Status.FATAL,"ErrorAgentSettingsTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AgentsSettingTab","ErrorWhileCheckingAgentsSettingTab",e);

			result.put("SSU1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	//Check Users Settings Page avail
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
			
            Thread.sleep(1000);
			List<WebElement> texts = driver.findElements(By.className("innersubinfotxt"));
            
			if(((texts.get(0).getText()).contains(ResourceManager.getRealValue("supervisor_settings_agents_desc1"))) && (((texts.get(1).getText()).contains(ResourceManager.getRealValue("supervisor_settings_agents_desc2")))))
			{
		 		etest.log(Status.PASS,KeyManager.getRealValue("SSU2")+" is checked");

                return true;
			}
            else{
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AgentsSettingPage","MismatchDescription");
            }
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AgentsSettingPage","ErrorWhileCheckingAgentsSettingPage",e);
            System.out.println("Exception while checking if Operators Settings page is available in supervisor login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AgentsSettingPage","ErrorWhileCheckingAgentsSettingPage",e);
            System.out.println("Exception while checking if Operators settings page is available in supervisor login : "+e);
			return false;
		}
		return false;
	}
	
	//Check for add button
    private static boolean isaddPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            try
            {
                driver.findElement(By.id("buttonuseradd")).click();
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AddButton","AddButtonIsPresent");
                return false;
            }
            catch(NoSuchElementException e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("SSU3")+" is checked");

                return true;
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("SSU3")+" is checked");

                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AddButton","ErrorWhileCheckingAddButton",e);
            System.out.println("Exception while checking if add button is present in Operator Settings in supervisor login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","AddButton","ErrorWhileCheckingAddButton",e);
            System.out.println("Exception while checking if add button is present in Operator Settings in supervisor login : "+e);
            return false;
        }
    }
    
    //Check if headers are present
    private static boolean isHeadersPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            List<WebElement> elmts = driver.findElement(By.id("ulisttable")).findElement(By.className("list_header")).findElements(By.className("list_cell"));
            
            if(((elmts.get(0).getText()).equals("Name"))&&((elmts.get(1).getText()).equals("Role"))&&((elmts.get(2).getText()).equals("Email")))
            {
                etest.log(Status.PASS,KeyManager.getRealValue("SSU4")+" is checked");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckHeaders","MismatchHeader");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckHeaders","ErrorWhileCheckingheaders",e);
            System.out.println("Exception while checking if add button is present in Operator Settings in supervisor login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckHeaders","ErrorWhileCheckingheaders",e);
            System.out.println("Exception while checking if add button is present in Operator Settings in supervisor login : "+e);
            return false;
        }
    }
	
    //Check for presence of action
    private static boolean isActionPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            if((driver.findElement(By.id("ulisttable")).findElement(By.className("list_header")).getText()).contains("Action"))
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckActions","ActionsIsPresent");
                return false;
            }
            etest.log(Status.PASS,KeyManager.getRealValue("SSU5")+" is checked");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckActions","ErrorWhileCheckingActions",e);
            System.out.println("Exception while checking if actions header is present in Operator Settings in supervisor login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckActions","ErrorWhileCheckingActions",e);
            System.out.println("Exception while checking if actions header is present in Operator Settings in supervisor login : "+e);
            return false;
        }
    }
    
    //Check agent profiles
    private static boolean checkprofile(WebDriver driver,String agent,boolean screenshot)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            List<WebElement> elmts = driver.findElement(By.id("ulisttable")).findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                WebElement elmts1 = elmt.findElement(By.className("list_cell")).findElement(By.className("txtelips"));
                
                if((elmts1.getText()).equals(agent))
                {
                    elmts1.click();
		            break;
                }
            }
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
            if((driver.findElement(By.id("userdetails")).findElement(By.className("myprfdtlmn")).findElement(By.className("myprfdtlmn_rht")).getText()).equals(agent))
            {
                if(!screenshot)
                {
                    TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckProfile:"+agent,"AgentWindowIsPresent");
                }
                else
                {
                    etest.log(Status.PASS,"Profile:"+agent+" is checked");
                }
                return true;
            }
            if(screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckProfile:"+agent,"MimatchAgentName");
            }
            else
            {
                    etest.log(Status.PASS,"Profile:"+agent+" is checked");
            }
            return false;
        }
        catch(NoSuchElementException e)
        {
            if(screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckProfile:"+agent,"ErrorWhileCheckingProfile",e);
            }
            else
            {
                    etest.log(Status.PASS,"Profile:"+agent+" is checked");
            }
            System.out.println("Exception while checking if supervisor profile in Operator Settings in supervisor login : "+e);
            return false;
        }
        catch(Exception e)
        {
            if(screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Supervisor","CheckProfile:"+agent,"ErrorWhileCheckingProfile",e);
            }
            else
            {
                    etest.log(Status.PASS,"Profile:"+agent+" is checked");
            }
            System.out.println("Exception while checking if supervisor profile in Operator Settings in supervisor login : "+e);
            return false;
        }
    }
	
	//Mouse Over for hidden element
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		Thread.sleep(500);
		new Actions(driver).moveToElement(element).perform(); 
	}
}
