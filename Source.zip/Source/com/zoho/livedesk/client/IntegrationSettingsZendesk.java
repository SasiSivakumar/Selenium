//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class IntegrationSettingsZendesk
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    private static String crmkey = null;
    private static String deskkey = null;
    private static String sportalname = null;
    private static String url = "";
    public static ExtentTest etest;

    public static Hashtable integ(WebDriver driver)
    {
        try
        {
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI1"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            url = ConfManager.requestURL();
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            etest.log(Status.PASS,"Checked");

            result.put("SI1", true);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI2"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI2", isCRMPageAvail(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI3"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI3", isSuppPageAvail(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI32"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            checkCRMIntegration(driver);

            ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI33"));
//            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");
//
//            regenerateCRMKey(driver);
//
//            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI4"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI4", chooseType(driver, "vistypecrmdiv", "Missed", 0, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI5"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI5", chooseType(driver, "vistypecrmdiv", "Attended", 1, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI6"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI6", chooseType(driver, "vistypecrmdiv", "Accessed", 2, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI7"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI7", addNewVisitorTo(driver,1,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI8"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI8", addNewVisitorTo(driver,0,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI9"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI9", chooseType(driver, "vistrackcrmdiv", "NOTIFYCRM", 0, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI10"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI10", chooseType(driver, "vistrackcrmdiv", "ADDVISITS", 1, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI11"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI11", pushToCRM(driver,"chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI13"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI13","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Tracked in CRM",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI12"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI12","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI14"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI14","assignowner_div_div","assignowner_div_ddown","Zoho SalesIQ Attender",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI15"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI15","newcusaddtask_div_div","newcusaddtask_div_ddown","14th Day",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI16"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI16","newcusaddtask_div_div","newcusaddtask_div_ddown","7th Day",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI17"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI17","newcusaddtask_div_div","newcusaddtask_div_ddown","None",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI18"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI18","newcusaddtask_div_div","newcusaddtask_div_ddown","Today",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI19"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            crmintegconfig(driver,"SI19","newcusaddtask_div_div","newcusaddtask_div_ddown","Tomorrow",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI20"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI20",disableCRMInteg(driver,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI21"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI21",enableCRMInteg(driver,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI34"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            checkSuppIntegration(driver);

            ComplexReportFactory.closeTest(etest);

//            ----Due to repeatative action the usecase fails-----
//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI35"));
//            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");
//
//            regenerateDeskKey(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI22"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI22", deskReqInLD(driver,0,"reqcriteria_all",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI23"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI23", deskReqInLD(driver,1,"reqcriteria_mdept",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI24"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI24",deskintegconfig(driver,"convertrequest_div_div","convertrequest_div_ddown","All Visitors",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI25"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI25",deskintegconfig(driver,"convertrequest_div_div","convertrequest_div_ddown","Attended",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI26"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI26",deskintegconfig(driver,"convertrequest_div_div","convertrequest_div_ddown","Missed",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI27"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI27",deskintegconfig(driver,"convertrequest_div_div","convertrequest_div_ddown","None",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI28"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI28",deskintegconfig(driver,"attendreqstatus_div_div","attendreqstatus_div_ddown","Closed",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI29"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI29",deskintegconfig(driver,"attendreqstatus_div_div","attendreqstatus_div_ddown","Open",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI30"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI30",disableDeskInteg(driver,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI31"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings");

            result.put("SI31",enableDeskInteg(driver,etest));

            ComplexReportFactory.closeTest(etest);
        }
        catch(NoSuchElementException e)
        {
            result.put("SI1", false);
            etest.log(Status.FATAL,"IntegrationTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","IntegHome","Error",e);
        }
        catch(Exception e)
        {
            result.put("SI1", false);
            etest.log(Status.FATAL,"IntegrationTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","IntegHome","Error",e);
        }

        ComplexReportFactory.closeTest(etest);

        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    //Check Integration page
    public static boolean isCRMPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            CommonUtil.inViewPort(driver.findElement(By.xpath("//div[text()='Zoho CRM']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            String desc = driver.findElement(By.className("innersubinfotxt")).getText();
            if((desc).equals(ResourceManager.getRealValue("settings_crminteg_desc")))
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"MismatchContent.Expected:"+ResourceManager.getRealValue("settings_crminteg_desc")+"--Actual:"+desc+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMPage","MismatchContent");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking if CRM Integration settings page is available : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMPage","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if CRM Integration settings page is available : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMPage","Error",e);
            return false;
        }
        return false;
    }

    //Check Integration page
    public static boolean isSuppPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking if Desk Integration settings page is available : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskPage","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if Desk Integration settings page is available : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskPage","Error",e);
            return false;
        }
        return false;
    }

    //Check CRM integration zsc key
    public static void checkCRMIntegration(WebDriver driver)
    {
        try
        {
            result.put("SI32", false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));



            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            crmkey = driver.findElement(By.id("zsckeydiv")).getText();

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_change"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdesc")));

            String key = driver.findElement(By.id("zsckey")).getAttribute("value");

            if(crmkey.equals(key))
            {
                etest.log(Status.PASS,"Checked");
                result.put("SI32", true);
            }
            else
            {
                etest.log(Status.FAIL,"Expected:"+crmkey+"--Actual:"+key+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMZSCKey","MismatchContent");
            }
            Thread.sleep(1000);
            driver.findElement(By.id("cancelbtn")).click();
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking CRM integration zsc key in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMZSCKey","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking CRM integration zsc key in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMZSCKey","Error",e);
        }
    }

    //Regenerate CRM key
    public static void regenerateCRMKey(WebDriver driver)
    {
        try
        {
            result.put("SI33", false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            String key = driver.findElement(By.id("zsckeydiv")).getText();

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_regenerate"))).click();

            Tab.waitForLoading(driver,"upzsckey.do",etest);

            crmkey = driver.findElement(By.id("zsckeydiv")).getText();

            if(!(key.equals(crmkey)))
            {
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_change"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdesc")));

                String keyafter = driver.findElement(By.id("zsckey")).getAttribute("value");

                if(crmkey.equals(keyafter))
                {
                    etest.log(Status.PASS,"Checked");
                    result.put("SI33", true);
                    driver.findElement(By.id("cancelbtn")).click();
                    return;
                }
                else
                {
                    etest.log(Status.FAIL,"MismatchContent.Expected:"+crmkey+"--Actual:"+keyafter+"--");
                }

                Thread.sleep(1000);
                driver.findElement(By.id("cancelbtn")).click();
            }
            else
            {
                etest.log(Status.FAIL,"ZSC key not regenerated.Old:"+key+"--New:"+crmkey+"--");
            }
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMRegenZSCKey","Error");
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking CRM integration zsc key regenerate in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMRegenZSCKey","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking CRM integration zsc key regenerate in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMRegenZSCKey","Error",e);
        }
    }

    //Choose visitors type to be added in CRM
    public static boolean chooseType(WebDriver driver, String id, String vid, int num,String chk,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            WebElement type = driver.findElement(By.id(id));
            List<WebElement> vistypes = type.findElements(By.tagName("span"));
            JavascriptExecutor je = (JavascriptExecutor)driver;

            if((vistypes.get(num).getAttribute("class")).contains("chckbxsel"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(vid))).getLocation().y+"-400)");

                Coordinates cc = ((Locatable)(driver.findElement(By.id(vid)))).getCoordinates();
                cc.inViewPort();

                driver.findElement(By.id(vid)).click();
                if(id.equals("vistrackcrmdiv"))
                {
                    Tab.waitForLoading(driver,"disabletracknfy.do",etest);
                }
                else
                {
                    Tab.waitForLoading(driver,"upintegconfig.do",etest);
                }
                Thread.sleep(1000);
                if(chk.equals("unchk"))
                {
                    etest.log(Status.PASS,id+" - "+vid+" checkbox - UnChecked is verified");
                    return true;
                }
            }

            if(chk.equals("unchk"))
            {
                etest.log(Status.PASS,id+" - "+vid+" checkbox - UnChecked is verified");
                return true;
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

            Coordinates cc1 = ((Locatable)(driver.findElement(By.id(vid)))).getCoordinates();
            cc1.inViewPort();

            type = driver.findElement(By.id(id));
            vistypes = type.findElements(By.tagName("span"));

            driver.findElement(By.id(vid)).click();

            if(id.equals("vistrackcrmdiv"))
            {
                Tab.waitForLoading(driver,"disabletracknfy.do",etest);
            }
            else
            {
                Tab.waitForLoading(driver,"upintegconfig.do",etest);
            }

            Thread.sleep(2000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));

            cc1 = ((Locatable)(driver.findElement(By.id(vid)))).getCoordinates();
            cc1.inViewPort();

            type = driver.findElement(By.id(id));
            vistypes = type.findElements(By.tagName("span"));

            if(chk.equals("chk"))
            {
                String s = vistypes.get(num).getAttribute("class");

                if(s.contains("chckbxsel"))
                {
                    etest.log(Status.PASS,id+" - "+vid+" checkbox - Checked is verified");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Mismatch Classname.Expected:chckbxsel-Actual"+s+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","ChooseType","Error");
                }
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while Choosing visitors type to be added in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","ChooseType","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while Choosing visitors type to be added in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","ChooseType","Error",e);
        }
        return false;
    }

    //Choose Add visitor to Lead/Contact
    public static boolean addNewVisitorTo(WebDriver driver, int num,ExtentTest etest)
    {
        String usecase = "Lead";

        try
        {
            if(num == 1)
            {
                usecase = "Contact";
            }
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElements(By.id("newcuscrmmodule")).get(num)).getLocation().y+"-400)");

            if(num==0)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("crmmodlead"))).getLocation().y+"-400)");

                Coordinates cc = ((Locatable)(driver.findElement(By.id("crmmodlead")))).getCoordinates();
                cc.inViewPort();

                driver.findElement(By.id("crmmodlead")).click();
            }
            else
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("crmmodcontact"))).getLocation().y+"-400)");

                Coordinates cc = ((Locatable)(driver.findElement(By.id("crmmodcontact")))).getCoordinates();
                cc.inViewPort();

                driver.findElement(By.id("crmmodcontact")).click();
            }

            //driver.findElements(By.id("newcuscrmmodule")).get(num).click();

            Tab.waitForLoading(driver,"upintegconfig.do",etest);

            Thread.sleep(2000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            String cl = driver.findElement(By.id("crmradio")).findElements(By.className("uprdowrap")).get(num).findElement(By.tagName("span")).getAttribute("class");

            if(cl.contains("rdselected"))//if("true".equals(driver.findElements(By.id("newcuscrmmodule")).get(num).getAttribute("checked")))
            {
                etest.log(Status.PASS,"Add new visitor to "+usecase+" is checked");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"MismatchContent Classname.Expected:rdselected--Actual:"+cl+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","AddNewVisitor"+usecase,"MismatchContent");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while Choosing Choose Add visitor to Lead/Contact in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","AddNewVisitor"+usecase,"Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while Choosing Choose Add visitor to Lead/Contact in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","AddNewVisitor"+usecase,"Error",e);
        }
        return false;
    }

    //Push Chat transcript to CRM
    public static boolean pushToCRM(WebDriver driver,String chk,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            String classname = driver.findElement(By.id("excuspushchattrans")).getAttribute("class");
            boolean val = (classname.contains("set_on")?true:false);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("excuspushchattrans"))).getLocation().y+"-400)");

            Coordinates cc = ((Locatable)(driver.findElement(By.id("excuspushchattrans")))).getCoordinates();
            cc.inViewPort();

            if(val && chk.equals("chk"))
            {
                etest.log(Status.PASS,"Push to CRM enabled is checked");
                return true;
            }
            else if(!val && chk.contains("unchk"))
            {
                etest.log(Status.PASS,"Push to CRM disabled is checked");
                return true;
            }
            else if(val && chk.contains("unchk"))
            {
                driver.findElement(By.id("excuspushchattrans")).click();
                Thread.sleep(2000);

                wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.id("excuspushchattrans")).getAttribute("class").contains("set_on"))
                            {
                                return false;
                            }
                            return true;
                        }
                    });

                classname = driver.findElement(By.id("excuspushchattrans")).getAttribute("class");

                val = (classname.contains("set_on")?true:false);

                if(!val)
                {
                    etest.log(Status.PASS,"Push to CRM disabled is checked");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Checkbox is not unchecked");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","PushToCRM","Error");
                    return false;
                }
            }

            else if(!val && chk.equals("chk"))
            {
                driver.findElement(By.id("excuspushchattrans")).click();

                Thread.sleep(3000);
                //WebDriverWait wait = new WebDriverWait(driver, 30);

                wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.id("excuspushchattrans")).getAttribute("class").contains("set_on"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });

                classname = driver.findElement(By.id("excuspushchattrans")).getAttribute("class");
                val = (classname.contains("set_on")?true:false);

                if(val)
                {
                    etest.log(Status.PASS,"Push to CRM enabled is checked");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Checkbox is unchecked");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","PushToCRM","Error");
                    return false;
                }
            }
            else
            {
                etest.log(Status.FAIL,"Cannot determine the status-"+chk);
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","PushToCRM","Error");
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Push Chat transcript to CRM in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","PushToCRM","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Push Chat transcript to CRM in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","PushToCRM","Error",e);
        }
        return false;
    }

    public static void crmintegconfig(WebDriver driver, String name, String id, String dname, String value,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            result.put(name, false);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

            Coordinates cc = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
            cc.inViewPort();

            Thread.sleep(500);

            driver.findElement(By.id(id)).click();

            Thread.sleep(500);

            WebElement elmt = driver.findElement(By.id(dname));

            List<WebElement> lis=elmt.findElements(By.tagName("li"));
            for(int i=0;i<lis.size();i++)
            {
                WebElement element = lis.get(i);
                WebElement element2 = element.findElement(By.tagName("div"));
                WebElement element3 = element2.findElement(By.tagName("span"));
                String title = element3.getAttribute("title");
                if(title.equals(value))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(element).getLocation().y+"-400)");

                    Coordinates cc1 = ((Locatable)element).getCoordinates();
                    cc1.inViewPort();

                    Thread.sleep(500);

                    element.click();

                    Tab.waitForLoading(driver,"upintegconfig.do",etest);

                    Thread.sleep(1000);
                    //WebDriverWait wait = new WebDriverWait(driver, 30);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

                    driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

                    Coordinates cc2 = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
                    cc2.inViewPort();

                    Thread.sleep(2000);

                    String actual = driver.findElement(By.id(id)).getText();

                    System.out.println(actual+"<><><<><><>"+value);

                    if(value.equals(actual))
                    {
                        result.put(name, true);
                        etest.log(Status.PASS,"CRM Integration Configuration for "+id+" - "+value+" is checked");
                        return;
                    }
                    else
                    {
                        etest.log(Status.FAIL,"Expected:"+value+"--Actual:"+actual+"--");
                        TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMIntegConfig","Error");
                    }
                    break;
                }
            }
            etest.log(Status.FAIL,value+" is not present");
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMIntegConfig","Error");
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking CRM Integration Configuration in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMIntegConfig","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking CRM Integration Configuration in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","CRMIntegConfig","Error",e);
        }
    }

    //Check Desk Integration
    public static void checkSuppIntegration(WebDriver driver)
    {
        try
        {
            result.put("SI34", false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            deskkey = driver.findElement(By.id("zsckeylabeldiv")).getText();
            sportalname = driver.findElement(By.id("zsuppintegdiv")).findElements(By.className("integ_dtl")).get(2).findElement(By.id("emailidlabeldiv")).getText();

            driver.findElement(By.className("cmn_dotlin")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdesc")));

            String actual1 = driver.findElement(By.id("zsckey")).getAttribute("value");
            String actual2 = driver.findElement(By.id("sportalname")).getAttribute("value");

            if((deskkey.equals(actual1)) && (sportalname.equals(actual2)))
            {
                etest.log(Status.PASS,"Checked");
                result.put("SI34", true);
            }
            else
            {
                etest.log(Status.FAIL,"Expected:"+deskkey+"--"+sportalname+"--Actual:"+actual1+"--"+actual2+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegration","Error");
            }
            Thread.sleep(1000);
            driver.findElement(By.id("cancelbtn")).click();
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Desk Integration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegration","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Desk Integration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegration","Error",e);
        }
    }

    //Regenerate Desk key
    public static void regenerateDeskKey(WebDriver driver)
    {
        try
        {
            result.put("SI35", false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            String key = driver.findElement(By.id("zsckeylabeldiv")).getText();
            sportalname = driver.findElement(By.id("emailidlabeldiv")).getText();

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_regenerate"))).click();

            Tab.waitForLoading(driver,null,etest);

            Thread.sleep(2000);

            deskkey = driver.findElement(By.id("zsckeylabeldiv")).getText();

            System.out.println("Regenerate Desk key:<<<"+key+">>><<<"+deskkey+">>>");

            if(!(key.equals(deskkey)))
            {
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_change"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdesc")));

                String zsckey = driver.findElement(By.id("zsckey")).getAttribute("value");
                String portalname = driver.findElement(By.id("sportalname")).getAttribute("value");

                System.out.println("Regenerate desk key:<<<"+zsckey+">>><<<"+deskkey+">>><<<"+portalname+">>><<<"+sportalname+">>>");

                if((deskkey.equals(zsckey)) && (sportalname.equals(portalname)))
                {
                    etest.log(Status.PASS,"Checked");
                    result.put("SI35", true);
                    driver.findElement(By.id("cancelbtn")).click();
                    return;
                }
                else
                {
                    etest.log(Status.FAIL,"Expected:"+deskkey+"--"+sportalname+"--Actual:"+zsckey+"--"+portalname);
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","RegenerateDeskKey","Error");
                }

                Thread.sleep(1000);
                driver.findElement(By.id("cancelbtn")).click();
            }
            else
            {
                etest.log(Status.FAIL,"Key is not changed.Old:"+key+"--New:"+deskkey);
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","RegenerateDeskKey","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Regenerate Desk key in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","RegenerateDeskKey","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Regenerate Desk key in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","RegenerateDeskKey","Error",e);
        }
    }

    //Add Desk request in livedesk
    public static boolean deskReqInLD(WebDriver driver, int num,String id,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            deskReqInLD1(driver,num,id,etest);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            Coordinates cc1 = ((Locatable)(driver.findElement(By.id("reqcriteriaradio")))).getCoordinates();
            cc1.inViewPort();

            String actual = driver.findElement(By.id("reqcriteriaradio")).findElements(By.className("uprdowrap")).get(num).findElement(By.tagName("span")).getAttribute("class");

            if((actual).contains("rdselected"))
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Expected:rdselected--Actual:"+actual+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskRequestInSalesIQ","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Add Desk request in livedesk in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskRequestInSalesIQ","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Add Desk request in livedesk in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskRequestInSalesIQ","Error",e);
        }
        return false;
    }

    public static boolean deskintegconfig(WebDriver driver,String id, String dname, String value,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            if(!deskintegconfig1(driver,id,dname,value,etest))
            {
                return false;
            }

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            Coordinates cc3 = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
            cc3.inViewPort();

            Thread.sleep(500);

            String actual = driver.findElement(By.id(id)).getText();

            if(value.equals(actual))
            {
                etest.log(Status.PASS,"Checked");
                //result.put(name, true);
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Expected:"+value+"--Actual:"+actual+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegrationConfig","Error");
            }

            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Desk integration configuration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegrationConfig","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Desk integration configuration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegrationConfig","Error",e);
        }

        return false;
    }

    //disable crm integration
    public static boolean disableCRMInteg(WebDriver driver,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            //List<WebElement> elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("crm_intgopt") || action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                try
                {
                    Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
                }
                catch(Exception exp)
                {
                    exp.printStackTrace();
                }
            }

            //elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            action = elmts.getText();

            if(classname.equals("") && action.contains(ResourceManager.getRealValue("common_disable")))
            {
                elmts.click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                driver.findElement(By.id("okbtn")).click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration disabled successfully","disableinteg.do",etest);
                String actual = driver.findElement(By.id("disablecontainer")).getAttribute("class");

                if((actual).contains("crm_intgopt"))
                {
                    etest.log(Status.PASS,"CRM Integration is successfully disabled");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Expected:crm_intgopt--Actual:"+actual+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableCRM","Error");
                }
            }
            else
            {
                etest.log(Status.FAIL,"Expected:empty--"+ResourceManager.getRealValue("common_disable")+"--Actual:"+classname+"--"+action+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableCRM","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while disabling CRM integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableCRM","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while disabling CRM integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableCRM","Error",e);
        }
        return false;
    }

    //enable CRM Integration
    public static boolean enableCRMInteg(WebDriver driver,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zendesk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            //List<WebElement> elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("") && action.contains(ResourceManager.getRealValue("common_disable")))
            {
                elmts.click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                driver.findElement(By.id("okbtn")).click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration disabled successfully","disableinteg.do",etest);
            }

            //elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            action = elmts.getText();

            if(classname.equals("crm_intgopt") && action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
                String actual = driver.findElement(By.id("disablecontainer")).getAttribute("class");
                if(!(actual).contains("crm_intgopt"))
                {
                    etest.log(Status.PASS,"CRM Integration is successfully enabled");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Expected:not crm_intgopt--Actual:"+actual+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableCRM","Error");
                }
            }
            else
            {
                etest.log(Status.FAIL,"Expected:crm_intgopt--"+ResourceManager.getRealValue("common_enable")+"--Actual:"+classname+"--"+action+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableCRM","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while enabling CRM integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableCRM","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while enabling CRM integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableCRM","Error",e);
        }
        return false;
    }

    //Disable Desk integration
    public static boolean disableDeskInteg(WebDriver driver,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            //List<WebElement> elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("a"));
            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("zsuppintegdiv")).getAttribute("class");

            String action = elmts.getText();

            if(action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
              Tab.waitForLoadingSuccessWithBanner(driver,"Zendesk Integration enabled successfully","enableinteg.do",etest);
            }

            elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            classname = driver.findElement(By.id("zsuppintegdiv")).getAttribute("class");

            action = elmts.getText();

            if(classname.contains("integcndrpdwn") && action.contains(ResourceManager.getRealValue("common_disable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zendesk Integration disabled successfully","disableinteg.do",etest);

                String actual = driver.findElement(By.id("zsuppintegdiv")).getAttribute("class");

                if((actual).contains("crm_intgopt"))
                {
                    etest.log(Status.INFO,"Successfully disabled");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Expected:crm_intgopt--Actual:"+actual+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableDeskInteg","Error");
                }
            }
            else
            {
                etest.log(Status.FAIL,"Expected:integcndrpdwn--"+ResourceManager.getRealValue("common_disable")+"--Actual:"+classname+"--"+action+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableDeskInteg","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while disabling Desk integration configuration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableDeskInteg","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while disabling Desk integration configuration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DisableDeskInteg","Error",e);
        }
        return false;
    }

    //Enable Desk Integration
    public static boolean enableDeskInteg(WebDriver driver,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            IntegrationSettings.navToIntegApp(driver,"Zendesk");

            //List<WebElement> elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
//            String classname = driver.findElement(By.id("zsuppintegdiv")).getAttribute("class");

            String action = elmts.getText();

            if(action.contains(ResourceManager.getRealValue("common_disable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zendesk Integration disabled successfully","disableinteg.do",etest);
            }

            elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
//            classname = driver.findElement(By.id("zsuppintegdiv")).getAttribute("class");

            action = elmts.getText();

            if(action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                
                Tab.waitForLoadingSuccessWithBanner(driver,"Zendesk Integration enabled successfully","enableinteg.do",etest);
                
                etest.log(Status.INFO,"Successfully enabled");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("common_enable")+"--Actual:"+action+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableDeskInteg","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while enabling Desk integration configuration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableDeskInteg","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while enabling Desk integration configuration in Desk integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","EnableDeskInteg","Error",e);
        }
        return false;
    }

    public static boolean deskintegconfig1(WebDriver driver,String id,String dname,String value,ExtentTest etest) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

        Coordinates cc2 = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
        cc2.inViewPort();

        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id(id)).findElement(By.tagName("span"))));

        driver.findElement(By.id(id)).findElement(By.tagName("span")).click();

        Thread.sleep(500);

        WebElement elmt = driver.findElement(By.id(dname));

        List<WebElement> lis=elmt.findElements(By.tagName("li"));
        for(int i=0;i<lis.size();i++)
        {
            WebElement element = lis.get(i);
            WebElement element2 = element.findElement(By.tagName("div"));
            WebElement element3 = element2.findElement(By.tagName("span"));
            String title = element3.getAttribute("title");
            if(title.equals(value))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(element).getLocation().y+"-400)");

                Coordinates cc1 = ((Locatable)(element)).getCoordinates();
                cc1.inViewPort();

                Thread.sleep(500);

                element.click();

                Tab.waitForLoading(driver,"updateinteg.do",etest);

                Thread.sleep(1000);

                return true;
            }
        }

        etest.log(Status.FAIL,value+" is not present");
        TakeScreenshot.screenshot(driver,etest,"IntegrationSettings","DeskIntegrationConfig","Error");
        return false;
    }

    public static boolean deskReqInLD1(WebDriver driver,int num,String id,ExtentTest etest) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

        Coordinates cc2 = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
        cc2.inViewPort();

        driver.findElement(By.id(id)).click();

        Tab.waitForLoading(driver,"updateinteg.do",etest);

        return true;
    }
}
