//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import com.zoho.qa.server.servlet.WebdriverApi;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class PortalSettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	private static String emailaddr = "rajkumar.natarajan+automation@zohocorp.com";
    public static ExtentTest etest;

	public static Hashtable portalSettings(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SP1"));
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);

            //WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			//Portal settings info view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

			//Thread.sleep(2000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));

			etest.log(Status.PASS,"PortalSettingsTab is present");

            result.put("SP1", true);

			//Thread.sleep(1000);
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SP2"));
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            result.put("SP2", isPageAvail(driver));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            //etest=ComplexReportFactory.getTest("Edit Configuration in Portal Settings Page");
            //ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfigurations(driver);
			//Thread.sleep(1000);
			//ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Edit Configuration for From Email Id - Name and Email ID");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editFromMailAddr(driver,"SP3","SP4","frommailid","rajkumar.natarajan+automation@zohocorp.com","Anand");

            ComplexReportFactory.closeTest(etest);
            //Thread.sleep(1000);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorPortalSettingsTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","PortalSettingsTab","ErrorWhileCheckingPortalSettingsTab",e);

            result.put("SP1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorPortalSettingsTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","PortalSettingsTab","ErrorWhileCheckingPortalSettingsTab",e);

            result.put("SP1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check Portal Settings Header
    private static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_portal")+"')]")));

            driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_portal")+"')]"));
            //Thread.sleep(3000);

            if((driver.findElement(By.className("innersubinfotxt")).getText()).equals(ResourceManager.getRealValue("settings_portal_desc")))
            {
                etest.log(Status.PASS,"PortalSettings Description Matched");

                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"PortalSettings","PortalSettingsPage","Mismatch Portal Settings Description");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","PortalSettingsPage","ErrorWhileCheckingPageAvailable",e);
            System.out.println("Exception while checking if portal settings page is available : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","PortalSettingsPage","ErrorWhileCheckingPageAvailable",e);
            System.out.println("Exception while checking if portal settings page is available : "+e);
            return false;
        }
        return false;
    }

    //Visitor Chat Window Configuration
    private static void editConfigurations(WebDriver driver)
    {
        try
        {
            etest=ComplexReportFactory.getTest("Enable and Disable ShowTyping in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig(driver,"ShowTyping","showtyping","portvisitorconfig");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable FileTransfer in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig(driver,"FileTransfer","filetransfer","portvisitorconfig");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable PushPage in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig(driver,"PushPage","pushpage","portvisitorconfig");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable EmailVisInfo in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig(driver,"EmailVisInfo","emailtranscripts","portvisitorconfig");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable GoogleTrans in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editDDConfig(driver,"EnableGoogleTrans","googletranslateconfig_div","googletranslateconfig_ddown","Auto");
            Thread.sleep(1000);
            editDDConfig(driver,"DisableGoogleTrans","googletranslateconfig_div","googletranslateconfig_ddown","Off");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable IdleAsOffline in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig(driver,"IdleAsOffline","idleasoffline","agentactivityconfig");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable SetAgentIdleTime in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editDDConfig(driver,"SetAgentIdleTime","inactiveperioddrpdwn_div","inactiveperioddrpdwn_ddown","1 Hour");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable VisitorChatTrans in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editDDConfig(driver,"VisitorChatTrans","vischattranscript_div","vischattranscript_ddown","Manual");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            /*
            Signature Chat removed from Portal Setting page

            etest=ComplexReportFactory.getTest("Enable and Disable SignatureChat in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editDDConfig(driver,"SignatureChat","signdrpdwncnt_div","signdrpdwncnt_ddown","Ecstasy");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);
            */

            etest=ComplexReportFactory.getTest("Enable and Disable EmailCopier in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig1(driver,"EmailCopier","sccemailaddr","rajkumar.natarajan+automation@zohocorp.com");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable DailyStatistics in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig1(driver,"DailyStatistics","sdailystatics","rajkumar.natarajan+automation@zohocorp.com");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable BlockIP in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig1(driver,"BlockIP","ssendemailforipblockto","rajkumar.natarajan+automation@zohocorp.com");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable VisitorFeedback in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig1(driver,"VisitorFeedback","svisitorfeedback","rajkumar.natarajan+automation@zohocorp.com");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable ChatTrans in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig1(driver,"ChatTrans","ssendtranasemail","rajkumar.natarajan+automation@zohocorp.com");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable MissedVisitor in Portal Settings Page");
            ComplexReportFactory.setValues(etest,"Automation","Portal Settings");

            editConfig1(driver,"MissedVisitor","soffbusymsg","rajkumar.natarajan+automation@zohocorp.com");
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while editing configuration in portal settings page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while editing configuration in portal settings page : "+e);
        }
    }

    private static void editConfig(WebDriver driver, String name, String id, String config)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            result.put("Disable"+name, false);
            result.put("Enable"+name, false);

            JavascriptExecutor je = (JavascriptExecutor)driver;

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(config)));

            WebElement elmt = driver.findElement(By.id(config));

            List<WebElement> elmts = elmt.findElements(By.className("configlist"));

            boolean presence = false;

            for(WebElement loop:elmts)
            {
                if(loop.getAttribute("innerHTML").contains(id))
                {
                    presence = true;

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

                    String desc = loop.findElement(By.className("floatlf")).getText();

                    if(!CommonUtil.checkStringEqualsAndLog(desc,ResourceManager.getRealValue("portal_"+name),name,etest))
                    {
                        // etest.log(Status.FAIL,name+" content mismatch.Expected:"+ResourceManager.getRealValue("portal_"+name)+"--Actual:"+desc+"--");

                        TakeScreenshot.screenshot(driver,etest,"PortalSettings","Desc"+name,"MismatchContent");

                        return;
                    }

                    break;
                }
            }

            if(!presence)
            {
                etest.log(Status.FAIL,name+" is not present");

                TakeScreenshot.screenshot(driver,etest,"PortalSettings",name,"Error");

                return;
            }

            etest.log(Status.INFO,"Content checked");

            for(WebElement loop:elmts)
            {
                String lid = loop.findElement(By.tagName("input")).getAttribute("id");
                if(lid.equals(id))
                {
                    if((loop.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_off"))
                    {
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                        loop.findElement(By.className("togglebtn")).click();

                        if(id.contains("translate"))
                        {
                            WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Google translator");
                            HandleCommonUI.clickPositivePopupButton(popup);
                        }
                        //Thread.sleep(1000);

						Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                        Thread.sleep(1000);
                    }

                    WebElement tgbtn = loop.findElement(By.className("togglebtn"));
                    //Thread.sleep(1000);

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                    tgbtn.click();
                    
                    Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                    Thread.sleep(1000);


                  	Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    Thread.sleep(1000);
                    //WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

                    //Thread.sleep(2000);
                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id(config)));

                    WebElement lelmt = driver.findElement(By.id(config));
                    //Thread.sleep(1000);

                    List<WebElement> lelmts = lelmt.findElements(By.className("configlist"));
                    //Thread.sleep(1000);

                    for(WebElement loop1:lelmts)
                    {
                        String lid1 = loop1.findElement(By.tagName("input")).getAttribute("id");
                        if(lid1.equals(id))
                        {
                            if((loop1.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_off"))
                            {
                                etest.log(Status.PASS,"Disable for "+name+" is checked");

                                result.put("Disable"+name, true);
                            }
                            else{
                                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Disable"+name,name+"IsNotDisabled");
                            }
                            break;
                        }
                    }
                    break;
                }
            }
            if(!(boolean)result.get("Disable"+name))
                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Disable"+name,name+"Error");
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(config)));

            WebElement elmt1 = driver.findElement(By.id(config));
            //Thread.sleep(1000);

            List<WebElement> elmts1 = elmt1.findElements(By.className("configlist"));
            //Thread.sleep(1000);

            for(WebElement loop1:elmts1)
            {
                String lid = loop1.findElement(By.tagName("input")).getAttribute("id");
                if(lid.equals(id))
                {
                    if((loop1.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_on"))
                    {
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                        loop1.findElement(By.className("togglebtn")).click();
                        //Thread.sleep(1000);

						Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                        Thread.sleep(1000);

                    }
                    WebElement tgbtn = loop1.findElement(By.className("togglebtn"));
                    //Thread.sleep(1000);

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
                    tgbtn.click();

                    if(id.contains("translate"))
                    {
                        WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Google translator");
                        HandleCommonUI.clickPositivePopupButton(popup);
                    }
					
                    Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                    Thread.sleep(1000);

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    Thread.sleep(1000);
                    //WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

                    //Thread.sleep(2000);
                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id(config)));

                    WebElement elmt2 = driver.findElement(By.id(config));
                    //Thread.sleep(1000);

                    List<WebElement> elmts2 = elmt2.findElements(By.className("configlist"));
                    //Thread.sleep(1000);

                    for(WebElement loop:elmts2)
                    {
                        String lid1 = loop.findElement(By.tagName("input")).getAttribute("id");
                        if(lid1.equals(id))
                        {
                            if((loop.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_on"))
                            {
                                etest.log(Status.PASS,"Enable for "+name+" is checked");

                                result.put("Enable"+name, true);
                            }
                            else{
                                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Enable"+name,name+"IsNotEnabled");
                            }
                            break;
                        }
                    }
                    break;
                }
            }
            if(!(boolean)result.get("Enable"+name))
                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Enable"+name,name+"Error");
            //Thread.sleep(300);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditConfiguration","ErrorWhileEditingConfiguration",e);

            System.out.println("Exception while checking toggle configuration in portal settings page : "+name+" ------ "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditConfiguration","ErrorWhileEditingConfiguration",e);

            System.out.println("Exception while checking toggle configuration in portal settings page : "+name+" ------ "+e);
        }
    }

    public static void editDDConfig(WebDriver driver, String name, String id, String dname, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            result.put(name, false);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));

            List<WebElement> elmts = driver.findElements(By.className("configlist"));

            boolean presence = false;

            for(WebElement loop:elmts)
            {
                if(loop.getAttribute("innerHTML").contains(id))
                {
                    presence = true;

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

                    String desc = loop.findElement(By.className("floatlf")).getText();

                    if(!name.contains("Clear"))
                    {
                        if(!CommonUtil.checkStringEqualsAndLog(desc,ResourceManager.getRealValue("portal_"+name),name,etest))
                        {
                            // etest.log(Status.FAIL,name+" content mismatch.Expected:"+ResourceManager.getRealValue("portal_"+name)+"--Actual:"+desc+"--");

                            TakeScreenshot.screenshot(driver,etest,"PortalSettings","Desc"+name,"MismatchContent");

                            return;
                        }
                    }
                    break;
                }
            }

            if(!presence)
            {
                etest.log(Status.FAIL,name+" is not present");

                TakeScreenshot.screenshot(driver,etest,"PortalSettings",name,"Error");

                return;
            }

            etest.log(Status.INFO,"Content checked");

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");
            driver.findElement(By.id(id)).click();

            WebElement elmt = driver.findElement(By.id(dname));

            List<WebElement> lis=elmt.findElements(By.tagName("li"));

            for(int i=0;i<lis.size();i++)
            {
                WebElement element = lis.get(i);
                WebElement element2 = element.findElement(By.tagName("div"));
                WebElement element3 = element2.findElement(By.tagName("span"));
                String title = element3.getAttribute("title");
                if(title.equals(value))
                {
                    element.click();
                    //Thread.sleep(2000);
					
                    Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    Thread.sleep(1000);
                    //WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

                    //Thread.sleep(2000);
                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));

                    if(value.equals(driver.findElement(By.id(id)).getText()))
                    {
                        etest.log(Status.PASS,"Editing Configurations for "+name+" is checked");

                        result.put(name, true);
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditingConfigurationsFor"+name,"MismatchEditedConfigFor"+name);
                    }
                    break;
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditingConfigurations","ErrorWhileEditingConfiguration",e);

            System.out.println("Exception while checking dropdown configuration in portal settings page : "+name+" ------ "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditingConfigurations","ErrorWhileEditingConfiguration",e);

            System.out.println("Exception while checking dropdown configuration in portal settings page : "+name+" ------ "+e);
        }
    }

		private static void editConfig1(WebDriver driver, String name, String eid, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            result.put("Disable"+name, false);
            result.put("Enable"+name, false);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portemailconfig")));

            WebElement elmt = driver.findElement(By.id("portemailconfig"));
            //Thread.sleep(1000);

            List<WebElement> elmts = elmt.findElements(By.className("configlist"));

            boolean presence = false;

            for(WebElement loop:elmts)
            {
                if(loop.getAttribute("innerHTML").contains(eid))
                {
                    presence = true;

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(eid))).getLocation().y+"-400)");

                    String desc = loop.findElement(By.className("floatlf")).getText();

                    if(!CommonUtil.checkStringEqualsAndLog(desc,ResourceManager.getRealValue("portal_"+name),name,etest))
                    {
                        // etest.log(Status.FAIL,name+" content mismatch.Expected:"+ResourceManager.getRealValue("portal_"+name)+"--Actual:"+desc+"--");

                        TakeScreenshot.screenshot(driver,etest,"PortalSettings","Desc"+name,"MismatchContent");

                        return;
                    }

                    break;
                }
            }

            if(!presence)
            {
                etest.log(Status.FAIL,name+" is not present");

                TakeScreenshot.screenshot(driver,etest,"PortalSettings",name,"Error");

                return;
            }

            etest.log(Status.INFO,"Content checked");

            for(WebElement loop:elmts)
            {
                String lid = "frommailid";

                if(!((loop.getAttribute("eid"))!=null))
                {
                    lid = loop.findElement(By.tagName("input")).getAttribute("id");
                }
                if(lid.equals(eid))
                {
                    if((loop.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_off"))
                    {
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(loop).getLocation().y+"-400)");
                        loop.findElement(By.className("togglebtn")).click();
                        //Thread.sleep(1000);

                        Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                        Thread.sleep(1000);

                    }

                    WebElement tgbtn = loop.findElement(By.className("togglebtn"));
                    //Thread.sleep(1000);

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(tgbtn).getLocation().y+"-400)");
                    tgbtn.click();
                    //Thread.sleep(1000);

					Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    Thread.sleep(1000);
                    //WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

                    //Thread.sleep(2000);
                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portemailconfig")));

                    WebElement lelmt = driver.findElement(By.id("portemailconfig"));
                    //Thread.sleep(1000);

                    List<WebElement> lelmts = lelmt.findElements(By.className("configlist"));
                    //Thread.sleep(1000);

                    for(WebElement loop1:lelmts)
                    {
                        String lid1 = "frommailid";

                        if(!((loop1.getAttribute("eid"))!=null))
                        {
                            lid1 = loop1.findElement(By.tagName("input")).getAttribute("id");
                        }
                        if(lid1.equals(eid))
                        {
                            if((loop1.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_off"))
                            {
                                etest.log(Status.PASS,"Disable for "+name+" is checked");

                                result.put("Disable"+name, true);
                                //Thread.sleep(1000);
                            }
                            else{
                                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Disable"+name,name+"IsNotDisabled");
                            }
                            break;
                        }
                    }
                    break;
                }
            }
            if(!(boolean)result.get("Disable"+name))
                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Disable"+name,name+"Error");

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portemailconfig")));

            WebElement elmt1 = driver.findElement(By.id("portemailconfig"));
            //Thread.sleep(1000);

            List<WebElement> elmts1 = elmt1.findElements(By.className("configlist"));
            //Thread.sleep(1000);

            for(WebElement loop1:elmts1)
            {
                String lid = "frommailid";

                if(!((loop1.getAttribute("eid"))!=null))
                {
                    lid = loop1.findElement(By.tagName("input")).getAttribute("id");
                }
                if(lid.equals(eid))
                {
                    if((loop1.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_on"))
                    {
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(loop1).getLocation().y+"-400)");
                        loop1.findElement(By.className("togglebtn")).click();
                        //Thread.sleep(1000);

						Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                        Thread.sleep(1000);
                    }

                    WebElement tgbtn = loop1.findElement(By.className("togglebtn"));
                    //Thread.sleep(1000);

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(tgbtn).getLocation().y+"-400)");
                    tgbtn.click();
                    //Thread.sleep(1000);

					Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);
                    Thread.sleep(1000);

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    Thread.sleep(1000);
                    //WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

                    //Thread.sleep(2000);
                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portemailconfig")));

                    WebElement elmt2 = driver.findElement(By.id("portemailconfig"));
                    //Thread.sleep(1000);

                    List<WebElement> elmts2 = elmt2.findElements(By.className("configlist"));
                    //Thread.sleep(1000);

                    for(WebElement loop:elmts2)
                    {
                        String lid1 = "frommailid";

                        if(!((loop.getAttribute("eid"))!=null))
                        {
                            lid1 = loop.findElement(By.tagName("input")).getAttribute("id");
                        }
                        if(lid1.equals(eid))
                        {
                            if((loop.findElement(By.className("togglebtn")).getAttribute("class")).equals("togglebtn set_on"))
                            {
                                //((JavascriptExecutor) driver).executeScript("$('#"+eid+"')[0].value='"+value+"';");
                                //Thread.sleep(1000);
                                String email = (String) ((JavascriptExecutor) driver).executeScript("return document.getElementById('"+eid+"').value");
                                //Thread.sleep(1000);
                                if(emailaddr.equals(email))
                                {
                                    etest.log(Status.PASS,"Enable for "+name+" is checked");

                                    result.put("Enable"+name, true);
                                    //Thread.sleep(1000);
                                }
                                else{
                                    TakeScreenshot.screenshot(driver,etest,"PortalSettings","Enable"+name,name+"IsNotEnabled");
                                }
                            }
                            break;
                        }
                    }
                    break;
                }
            }
            if(!(boolean)result.get("Enable"+name))
                TakeScreenshot.screenshot(driver,etest,"PortalSettings","Enable"+name,name+"Error");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditConfiguration","ErrorWhileEditingConfiguration",e);

            System.out.println("Exception while checking emailID configuration in portal settings page : "+name+" ------ "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","BlockedIPTab","ErrorWhileEditingConfiguration",e);

            System.out.println("Exception while checking emailID configuration in portal settings page : "+name+" ------ "+e);
        }
    }

    //Edit from mail address
    public static void editFromMailAddr(WebDriver driver, String name,String name1, String id, String value,String value1)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            result.put(name, false);
            result.put(name1, false);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("frommailid"))).getLocation().y+"-400)");
            //Thread.sleep(1000);
            /*List<WebElement> mlist = driver.findElements(By.className("prtcnfgmailid"));
            for(int i=0;i< mlist.size();i++)
            {
                mlist.get(i).click();
                break;
            }*/
            driver.findElement(By.id("frommailid")).click();
            Thread.sleep(500);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cntdiv")));
            driver.findElement(By.id("fnamediv")).findElement(By.tagName("input")).click();
            //Thread.sleep(1000);
            driver.findElement(By.id("fnamediv")).findElement(By.tagName("input")).clear();
            //Thread.sleep(1000);
            driver.findElement(By.id("fnamediv")).findElement(By.tagName("input")).sendKeys(value1);
            driver.findElement(By.id("pop-femail")).click();
            //Thread.sleep(1000);
            driver.findElement(By.id("pop-femail")).clear();
            //Thread.sleep(1000);
            driver.findElement(By.id("pop-femail")).sendKeys(value);
            //Thread.sleep(2000);
            driver.findElement(By.id("okbtn")).click();
            //Thread.sleep(2000);
            Tab.waitForLoadingSuccessWithBanner(driver,"Portal Configuration updated successfully","addpconfig.do",etest);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));

            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portemailconfig")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("frommailid"))).getLocation().y+"-400)");

            String chk = driver.findElement(By.id("fromidcontent")).getText();
            String chklcl = value1 + " <" + value + ">";

            System.out.println(chk+" ----- "+chklcl);

            if(chk.equals(chklcl))
            {
                driver.findElement(By.id("frommailid")).click();
                Thread.sleep(500);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cntdiv")));
                if((driver.findElement(By.id("fnamediv")).findElement(By.tagName("input")).getAttribute("value")).equals(value1))
                {
                    etest.log(Status.PASS,"EditingConfiguration for "+KeyManager.getRealValue(name1)+" is checked");

                    result.put(name1,true);
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditConfigurationFor"+name1,"MismatchEditedConfigFor"+name1);
                }
                if((driver.findElement(By.id("pop-femail")).getAttribute("value")).equals(value))
                {
                    etest.log(Status.PASS,"EditingConfiguration for "+KeyManager.getRealValue(name)+" is checked");

                    result.put(name,true);
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditConfigurationFor"+KeyManager.getRealValue(name),"MismatchEditedConfigFor"+name);
                }
                driver.findElement(By.id("cancelbtn")).click();
                Thread.sleep(500);
            }
            if(!(boolean)result.get(name)||!(boolean)result.get(name1))
                TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditConfigurationFor"+KeyManager.getRealValue(name)+","+KeyManager.getRealValue(name1),name+"Error");
            //Thread.sleep(300);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditingConfigurations","ErrorWhileEditingConfiguration",e);
            System.out.println("Exception while editing from emailID configuration in portal settings page : "+name+" ------ "+e);
            try
            {
                driver.findElement(By.id("cancelbtn")).click();
            }
            catch(Exception ee){}
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"PortalSettings","EditingConfigurations","ErrorWhileEditingConfiguration",e);
            System.out.println("Exception while editing from emailID configuration in portal settings page : "+name+" ------ "+e);
            try
            {
                driver.findElement(By.id("cancelbtn")).click();
            }
            catch(Exception ee){}
        }
    }

    //clear data
    public static boolean clearPortalSetings(WebDriver driver)
    {
        try
        {
            editDDConfig(driver,"SetAgentIdleTime","inactiveperioddrpdwn_div","inactiveperioddrpdwn_ddown","Never");
            //Thread.sleep(1000);
            editDDConfig(driver,"VisitorChatTrans","vischattranscript_div","vischattranscript_ddown","None");
            //Thread.sleep(1000);
            /*Signature chat removed from UI

            editDDConfig(driver,"SignatureChat","signdrpdwncnt_div","signdrpdwncnt_ddown","None");
            
            */
            //Thread.sleep(1000);
            /*editConfig1(driver,"EmailCopier","ccemailid","rajkumar.natarajan+automation@zohocorp.com");
            editConfig1(driver,"DailyStatistics","dailystatid","rajkumar.natarajan+automation@zohocorp.com");
            editConfig1(driver,"BlockIP","ipblockmailid","rajkumar.natarajan+automation@zohocorp.com");
            editConfig1(driver,"VisitorFeedback","vstfdbckmailid","rajkumar.natarajan+automation@zohocorp.com");
            editConfig1(driver,"ChatTrans","ssendtransmailid","rajkumar.natarajan+automation@zohocorp.com");
            editConfig1(driver,"MissedVisitor","soffbusymailid","rajkumar.natarajan+automation@zohocorp.com");*/
            editFromMailAddr(driver,"SP3","SP4","frommailid","rajkumar.natarajan+automation@zohocorp.com","Automation");
            //Thread.sleep(1000);

            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clearing configuration in portal settings page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing configuration in portal settings page : "+e);
        }
        return false;
    }
}
