//$Id$
package com.zoho.livedesk.client.OtherAppsIntegration;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

public class OtherAppsInteg {
    
    public static Hashtable result = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    private static String requrl = "";
	public static ExtentTest etest; 
	//public static WebDriver driver = null;
    public static String portalname = "ldautomation11";
    public static String website1 = "otherapp1";
    public static String website2 = "otherapp2";
    public static Hashtable appcontent = new Hashtable<>();
	//public static int usecase = 15;

    public static void init()
	{
		appcontent.put("aweber_identifier","?siq_name={!firstname} {!lastname}&siq_email={!email}");
		appcontent.put("aweber_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("aweber_smartidentifier2","/identify.ls?name={!name}&email={!email}\" />");
		appcontent.put("bronto_identifier","?siq_name=%%firstname%% %%lastname%%&siq_email=%%email%%");
		appcontent.put("bronto_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("bronto_smartidentifier2","/identify.ls?name=%%customerName%%&email=%%customerEmail%%\" />");
		appcontent.put("activecampaign_identifier","?siq_name=%FIRSTNAME% %LASTNAME%&siq_email=%EMAIL%");
		appcontent.put("activecampaign_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("activecampaign_smartidentifier2","/identify.ls?name=%FIRSTNAME% %LASTNAME%&email=%EMAIL%\" />");
		appcontent.put("campaignmonitor_identifier","?siq_name=[firstname] [lastname]&siq_email=[email]");
		appcontent.put("campaignmonitor_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("campaignmonitor_smartidentifier2","/identify.ls?name=[fullname]&email=[email]\" />");
		appcontent.put("campaignmaster_identifier","?siq_name=[!First Name!] [!Last Name!]&siq_email=[!EmailAddress!]");
		appcontent.put("campaignmaster_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("campaignmaster_smartidentifier2","/identify.ls?name=[!First Name!] [!Last Name!]&email=[!EmailAddress!]\" />");
		appcontent.put("dotmailer_identifier","?siq_name=@FIRSTNAME@ @LASTNAME@&siq_email=@EMAIL@");
		appcontent.put("dotmailer_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("dotmailer_smartidentifier2","/identify.ls?name=@FULLNAME@&email=@EMAIL@\" />");
		appcontent.put("getresponse_identifier","?siq_name=[[firstname]] [[lastname]]&siq_email=[[email]]");
		appcontent.put("getresponse_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("getresponse_smartidentifier2","/identify.ls?name=[[name]]&email=[[email]]\" />");
		appcontent.put("icontact_identifier","?siq_name=[fname] [lname]&siq_email=[email]");
		appcontent.put("icontact_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("icontact_smartidentifier2","/identify.ls?name=[fname] [lname]&email=[email]\" />");
		appcontent.put("aurea_identifier","?siq_name=%%firstname%%&siq_email=%%emailaddr%%");
		appcontent.put("aurea_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("aurea_smartidentifier2","/identify.ls?name=%%fullname%%&email=%%emailaddr%%\" />");
		appcontent.put("madmimi_identifier","?siq_name=(firstname) (lastname)&siq_email=(email)");
		appcontent.put("madmimi_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("madmimi_smartidentifier2","/identify.ls?name=(firstname) (lastname)&email=(email)\" />");
		appcontent.put("mailchimp_identifier","?siq_name=*|FNAME|* *|LNAME|*&siq_email=*|EMAIL|*");
		appcontent.put("mailchimp_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("mailchimp_smartidentifier2","/identify.ls?name=*|FNAME|* *|LNAME|*&email=*|EMAIL|*\" />");
		appcontent.put("verticalresponse_identifier","?siq_name={FIRST_NAME} {LAST_NAME}&siq_email={EMAIL_ADDRESS}");
		appcontent.put("verticalresponse_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("verticalresponse_smartidentifier2","/identify.ls?name={FIRST_NAME} {LAST_NAME}&email={EMAIL_ADDRESS}\" />");
		appcontent.put("whatcounts_identifier","?siq_name=%%$first%% %%$last%%&siq_email=%%$email%%");
		appcontent.put("whatcounts_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("whatcounts_smartidentifier2","/identify.ls?name=%%$first%% %%$last%%&email=%%$email%%\" />");
		appcontent.put("constantcontact_identifier","?siq_name=$Subscriber.FirstName $Subscriber.FamilyName &siq_email=$Subscriber.Email");
		appcontent.put("constantcontact_smartidentifier1","<img src=\"https://salesiq.zoho.com/");
		appcontent.put("constantcontact_smartidentifier2","/identify.ls?name=$Subscriber.FirstName $Subscriber.FamilyName&email=$Subscriber.Email\" />");
	}
	
	public static Hashtable otherAppsInteg(WebDriver driver){
    	try{

            result = new Hashtable();
            
            init();

    		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI1"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
            CommonFunctionsOtherApps.navToIntegTab(driver);
            Functions.closeBannersAfterLogin(driver);

			result.put("OAI1",checkcontentcampaigns(driver,"aweber","Aweber"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI2"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI2",checkcontentcampaigns(driver,"activecampaign","Active Campaign"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI3"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI3",checkcontentcampaigns(driver,"bronto","Bronto"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI4"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI4",checkcontentcampaigns(driver,"campaignmonitor","Campaign Monitor"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI5"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI5",checkcontentcampaigns(driver,"campaignmaster","Campaignmaster"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI6"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI6",checkcontentcampaigns(driver,"dotmailer","dotMailer"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI7"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI7",checkcontentcampaigns(driver,"getresponse","GetResponse"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI8"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI8",checkcontentcampaigns(driver,"icontact","Icontact"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI9"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI9",checkcontentcampaigns(driver,"aurea","Aurea"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI10"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI10",checkcontentcampaigns(driver,"madmimi","Mad Mimi"));
			
            ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI11"));
//			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
//            
//			result.put("OAI11",checkcontentcampaigns(driver,"mailchimp","MailChimp"));
//			
//            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI12"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI12",checkcontentcampaigns(driver,"verticalresponse","Vertical Response"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI13"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI13",checkcontentcampaigns(driver,"whatcounts","Whatcounts"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("OAI14"));
			ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");
            
			result.put("OAI14",checkcontentcampaigns(driver,"constantcontact","Constant contact"));

            ComplexReportFactory.closeTest(etest);

            checkAnalytics(driver,"googleanalytics","Google Analytics","Google Analytics",15);
			checkAnalytics(driver,"clicky","Clicky","Clicky",22);
			checkAnalytics(driver,"googletagmanager","Google Tag Manager","Google Tag Manager",29);
			checkAnalytics(driver,"kissmetrics","KissMetrics","Kiss Metrics",36);
			checkAnalytics(driver,"optimizely","Optimizely","Optimizely",43);
			checkAnalytics(driver,"woopra","Woopra","Woopra",50);
			checkAnalytics(driver,"matomo","Matomo","Matomo",57);
			checkAnalytics(driver,"mixpanel","MixPanel","Mixpanel",64);
			checkAnalytics(driver,"hubspot","HubSpot","Hubspot",71);

			//CommonFunctionsOtherApps.logout(driver);
			//driver.quit();
		}

    	catch(Exception e){
    		etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            etest.log(Status.FATAL,e.toString());
    		System.out.println("Error While checking Other Apps Integration - "+e.toString());
    		TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegrations","Integrations","Error",e);
    		result.put("OAI1",false);
    	}

    	ComplexReportFactory.closeTest(etest);

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    public static boolean checkcontentcampaigns(WebDriver driver,String app,String appname) throws Exception
    {
    	try
    	{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".cmn_txt.mrgntop30.campdesc")));

			WebElement desc = CommonUtilOtherApps.elfinder(driver, "css",".cmn_txt.mrgntop30.campdesc");

			if(!desc.getText().contains(ResourceManager.getRealValue(app+"_desc")))
			{
				etest.log(Status.FAIL,"Description Mismatch Actual:"+desc.getText()+"--"+"Expected"+ResourceManager.getRealValue(app+"_desc")+"--");
				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"Integration","DescMismatch");
				return false;
			}
			
			List<WebElement> list = driver.findElements(By.cssSelector(".cmn_txt.mrgntop30"));
			
			for(WebElement e:list)
			{
				CommonUtilOtherApps.inViewPort(e);
			}

			WebElement copydiv = null;
			//boolean copyexists = false;
			
			wait.until(new Function<WebDriver, Boolean>()
			{
					public Boolean apply(WebDriver driver)
					{
						List<WebElement> list2 = driver.findElements(By.cssSelector(".camlnkdiv.hidinptdiv.mrgntop30"));
			
						for(WebElement e:list2)
						{
							if(e.getText().contains("Copy"))
							{
								return true;
							}
						}
						return false;
					}
			});

			List<WebElement> list2 = driver.findElements(By.cssSelector(".camlnkdiv.hidinptdiv.mrgntop30"));
			
			for(WebElement e:list2)
			{
				if(e.getText().contains("Copy"))
				{
					copydiv = e;
					//copyexists=true;
					break;
				}
			}

			// if(!copyexists)
			// {
			// 	etest.log(Status.FAIL,"Copy Icon Is Not Present");
			// 	TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"Integration","Error");
			// 	return false;
			// }

			WebElement copy = CommonUtilOtherApps.elementfinder(driver,copydiv,"tagname","span");
			copy.click();

			Thread.sleep(1000);
			
//			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
//		    Transferable clipData = clipboard.getContents(clipboard);
//		    String s1 = (String)(clipData.getTransferData(DataFlavor.stringFlavor));
            
            String s1 = CommonUtilOtherApps.elfinder(driver,"id","identifi_input").getAttribute("value");
            
		    String copytext = copy.getText();
		    String contentExpected1 = appcontent.get(app+"_smartidentifier1")+"";
		    String contentExpected2 = appcontent.get(app+"_smartidentifier2")+"";
		    if(Util.siteNameout().contains("localzoho"))
		    {
		    	contentExpected1 = contentExpected1.replace("salesiq.zoho.com","salesiq.localzoho.com");
		    	contentExpected2 = contentExpected2.replace("salesiq.zoho.com","salesiq.localzoho.com");
		    }
            else if(Util.siteNameout().contains("presalesiq"))
            {
                contentExpected1 = contentExpected1.replace("salesiq.zoho.com","presalesiq.zoho.com");
                contentExpected2 = contentExpected2.replace("salesiq.zoho.com","presalesiq.zoho.com");
            }
		    String content = contentExpected1+portalname+contentExpected2;
		    String copied = ResourceManager.getRealValue("aftercopyingtext");

			if(!(copytext.contains(copied)&&s1.contains(content)))
		    {
		    	// s1 = s1.replace("img","Example");
		    	// content = content.replace("img","Example");
		    	
		    	etest.log(Status.FAIL,"Either content mismatch in smart identifier .1.Copy button text-Expected:\""+copied+"\".Actual:\""+copytext+"\"2.Content copied-Expected:"+content+"--.Actual:"+s1+"--");
				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"Integration","MismatchContent");
				return false;
		    }
		    
		    String url = "www.yourlink.com";
		   
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("camplinkinput")));

			WebElement link = CommonUtilOtherApps.elfinder(driver, "id", "camplinkinput");

			link.sendKeys(url);

			WebElement generate=CommonUtil.getElementByAttributeValue(driver.findElements(By.className("cmn_gbutclor")),"onclick","generateCampaignURL");

			CommonUtil.waitTillWebElementDisplayed(driver,generate);
			
			generate.click();

			Thread.sleep(1000);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("urlgeneratediv")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("urlgeneratediv")));

			WebElement identifier = CommonUtilOtherApps.elfinder(driver, "id","urlgeneratediv");
			WebElement copy1 = CommonUtilOtherApps.elementfinder(driver,identifier,"tagname","span");

			copy1.click();
			Thread.sleep(1000);

//			clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
//		    clipData = clipboard.getContents(clipboard);
//		    String s2 = (String)(clipData.getTransferData(DataFlavor.stringFlavor));
            
            String s2 = CommonUtilOtherApps.elementfinder(driver,identifier,"tagname","input").getAttribute("value");
            
		    String copytext1 = copy1.getText();
		    String content1 = url+appcontent.get(app+"_identifier");
		    
		    if(!(copytext1.contains(copied)&&s2.contains(content1)))
		    {
		    	etest.log(Status.FAIL,"Either content mismatch in identifier .1.Copy button text-Expected:\""+copied+"\".Actual:\""+copytext1+"\"2.Content copied-Expected:"+content1+"--.Actual:"+s2+"--");
				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"Integration","MismatchContent");
				return false;
			}

		    etest.log(Status.PASS,"Identifier Contents Checked");
			return true;
		}
		
		catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"Integration","Error",e);
    		e.printStackTrace();
    		return false;
    	}
	}

	public static boolean checkenableAnalytics(WebDriver driver,String app,String appname,String appname1)throws Exception
	{
		try
		{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("innersubinfotxt")));
			
			WebElement desc = CommonUtilOtherApps.elfinder(driver, "classname","innersubinfotxt");
			String desc1 = ResourceManager.getRealValue(app+"_desc1");
			String desc2 = ResourceManager.getRealValue(app+"_desc2");
			
			if(!(desc.getText().contains(desc1)&&desc.getText().contains(desc2)))
			{
				etest.log(Status.FAIL,"Description Mismatch Actual:"+desc+"--"+"Expected"+desc1+"-and-"+desc2+"--");
				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"Integration","DescMismatch");
				return false;
			}
			
			CommonFunctionsOtherApps.disableIntegration(driver,appname1,etest);
			
			CommonFunctionsOtherApps.enableIntegration(driver);

			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			if(CommonFunctionsOtherApps.checkEnabledStatusInIntegHome(driver,appname,"sqico-enable",etest))
			{
				etest.log(Status.PASS,"Enable "+appname+" is checked");
				return true;
			}

			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"EnableIntegration","IsNotEnabled");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",app+"EnableIntegration","Error",e);
			driver.navigate().refresh();
			Thread.sleep(5000);
			return false;
		}
	}

	public static boolean checkdisableAnalytics(WebDriver driver,String appname,String appname1)throws Exception
	{
		try
		{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			CommonFunctionsOtherApps.disableIntegration(driver,appname1,etest);

			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			if(CommonFunctionsOtherApps.checkEnabledStatusInIntegHome(driver,appname,"sqico-disable",etest))
			{
				etest.log(Status.PASS,"Disable "+appname+" is checked");
				return true;
			}

			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",appname+"DisableIntegration","IsNotDisabled");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg",appname+"DisableIntegration","Error",e);
			driver.navigate().refresh();
			Thread.sleep(5000);
			return false;
		}
	}

	public static boolean enableWebEmbedInAnalytics(WebDriver driver,String appname,boolean active,String embedname)throws Exception
	{
		try
		{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			CommonUtil.clickWebElement(driver,CommonFunctionsOtherApps.selectIntegApp(driver,appname));
			
			CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,active,embedname,true);

			CommonFunctionsOtherApps.navToIntegTab(driver);

			Thread.sleep(1500);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			String actual = CommonFunctionsOtherApps.toggleStatusOfEmbedInAnalytics(driver,active,embedname);

			if(actual.contains("togglebtn set_on"))
			{
				etest.log(Status.PASS,"Enable - "+embedname+" in "+appname+" is checked");
				return true;
			}

			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"IsNotEnabled");
			return false;			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"Error",e);
			return false;
		}
	}

	public static boolean disableWebEmbedInAnalytics(WebDriver driver,String appname,boolean active,String embedname,boolean screenshot)throws Exception
	{
		try
		{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			CommonFunctionsOtherApps.navToIntegTab(driver);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,active,embedname,false);

			CommonFunctionsOtherApps.navToIntegTab(driver);

			Thread.sleep(1500);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			String actual = CommonFunctionsOtherApps.toggleStatusOfEmbedInAnalytics(driver,active,embedname);

			if(actual.contains("togglebtn set_off"))
			{
				if(screenshot)
					etest.log(Status.PASS,"Disable - "+embedname+" in "+appname+" is checked");
				return true;
			}

			if(screenshot)
				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Disable"+embedname+"In"+appname,"IsNotDisabled");
			return false;			
		}
		catch(Exception e)
		{
			if(screenshot)
				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Disable"+embedname+"In"+appname,"Error",e);
			return false;
		}
	}

	public static boolean enableWebEmbedInAnalytics1(WebDriver driver,String appname,String embedname)throws Exception
	{
		try
		{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			CommonFunctionsOtherApps.navToEmbedTab(driver);

	        WebElement web = CommonFunctionsOtherApps.selectEmbedInWebEmbed(driver,embedname);

	        CommonFunctionsOtherApps.changeStatusOfWebEmbed(driver,true,embedname,web);

	        CommonFunctionsOtherApps.navToIntegTab(driver);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,true,embedname,true);

			CommonFunctionsOtherApps.navToEmbedTab(driver);

	        web = CommonFunctionsOtherApps.selectEmbedInWebEmbed(driver,embedname);

	        CommonFunctionsOtherApps.changeStatusOfWebEmbed(driver,false,embedname,web);

	        CommonFunctionsOtherApps.navToIntegTab(driver);

	        Thread.sleep(1500);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			String classname = CommonFunctionsOtherApps.toggleStatusOfEmbedInAnalytics(driver,false,embedname);

			if(classname.contains("togglebtn set_on"))
			{
				etest.log(Status.PASS,"Checked");
				
				return true;
			}

			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"MismatchInToggleBarStatusAfterDisablingWebEmbed");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"Error",e);
			return false;
		}
	}

	public static boolean enableWebEmbedInAnalytics2(WebDriver driver,String appname,String embedname,boolean toenable,String appname1)throws Exception
	{
		try
		{
	    	FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
			if(!enableWebEmbedInAnalytics1(driver,appname,embedname))
				return false;

			disableWebEmbedInAnalytics(driver,appname,false,embedname,true);

			CommonFunctionsOtherApps.navToIntegTab(driver);

			Thread.sleep(1500);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();
			
			CommonFunctionsOtherApps.enableInactiveWebEmbedInAnalytics(driver,appname1,embedname,toenable,etest);

            Thread.sleep(3000);
            
            CommonFunctionsOtherApps.navToIntegTab(driver);

			Thread.sleep(1500);
		
			CommonFunctionsOtherApps.selectIntegApp(driver,appname).click();

			String classname = CommonFunctionsOtherApps.toggleStatusOfEmbedInAnalytics(driver,toenable,embedname);

			if(classname.contains("togglebtn set_on"))
			{
				etest.log(Status.INFO,"WebEmbed is enabled");
			}

			CommonFunctionsOtherApps.navToEmbedTab(driver);

			WebElement embed = CommonFunctionsOtherApps.selectEmbedInWebEmbed(driver,embedname);

			if(toenable)
			{
				if(!embed.getAttribute("class").contains("list_disable"))
				{
					etest.log(Status.PASS,"Checked");
					return true;
				}

				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"WebEmbedIsNotEnabled");
				return false;
			}
			else
			{
				if(embed.getAttribute("class").contains("list_disable"))
				{
					etest.log(Status.PASS,"Checked");
					return true;
				}

				TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"WebEmbedIsEnabled");
				return false;
			}
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"OtherAppsInteg","Enable"+embedname+"In"+appname,"Error",e);
			driver.navigate().refresh();
			Thread.sleep(5000);
			return false;
		}
	}

	public static void checkAnalytics(WebDriver driver,String app,String appname,String appname1,int usecase) throws Exception
	{
		String e = "OAI"+usecase++;
		
		etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,checkenableAnalytics(driver,app,appname,appname1));
		
		ComplexReportFactory.closeTest(etest);

		e = "OAI"+usecase++;
        
        etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,enableWebEmbedInAnalytics(driver,appname,true,website1));
		
		ComplexReportFactory.closeTest(etest);

		e = "OAI"+usecase++;
        
        etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,disableWebEmbedInAnalytics(driver,appname,true,website1,true));
		
		ComplexReportFactory.closeTest(etest);

		e = "OAI"+usecase++;
        
        etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,enableWebEmbedInAnalytics1(driver,appname,website2));
		disableWebEmbedInAnalytics(driver,appname,false,website2,false);
		
		ComplexReportFactory.closeTest(etest);

		e = "OAI"+usecase++;
        
        etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,enableWebEmbedInAnalytics2(driver,appname,website2,false,appname1));
		disableWebEmbedInAnalytics(driver,appname,false,website2,false);
		
        ComplexReportFactory.closeTest(etest);

		e = "OAI"+usecase++;
        
        etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,enableWebEmbedInAnalytics2(driver,appname,website2,true,appname1));
		disableWebEmbedInAnalytics(driver,appname,true,website2,false);
		
        ComplexReportFactory.closeTest(etest);

		e = "OAI"+usecase++;
        
        etest=ComplexReportFactory.getTest(KeyManager.getRealValue(e));
		ComplexReportFactory.setValues(etest,"Automation","Other Apps Integration");

		result.put(e,checkdisableAnalytics(driver,appname,appname1));
        
        if(!appname.equals("HubSpot"))
        {
            ComplexReportFactory.closeTest(etest);
        }
	}
}
