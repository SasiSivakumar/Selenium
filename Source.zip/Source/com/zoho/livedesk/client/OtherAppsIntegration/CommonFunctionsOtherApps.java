//$Id$
package com.zoho.livedesk.client.OtherAppsIntegration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.List;

import com.google.common.base.Function;

public class CommonFunctionsOtherApps {
    
    public static void  login(WebDriver driver,String usrname,String pwd)throws Exception
    {
	    	int screenWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	    	int screenHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	    	Dimension targetSize = new Dimension(screenWidth,screenHeight);     //Imac - 2560*1440  Mac - 1440*900
	        driver.manage().window().setSize(targetSize);
	        
	    	driver.manage().window().maximize();
            if(Util.siteNameout().contains("local"))
                driver.get("https://accounts.localzoho.com");
            else
                driver.get("https://accounts.zoho.com");
	    	driver.switchTo().frame(0);
            CommonUtilOtherApps.elfinder(driver,"id","lid").clear();
            CommonUtilOtherApps.elfinder(driver,"id","lid").sendKeys(usrname);
            
            CommonUtilOtherApps.elfinder(driver,"id","pwd").clear();
            CommonUtilOtherApps.elfinder(driver,"id","pwd").sendKeys(pwd);
            CommonUtilOtherApps.elementfinder(driver,CommonUtilOtherApps.elfinder(driver,"id","login"),"classname","redBtn").click();
            
            //driver.findElement(By.id("login")).findElement(By.className("redBtn")).click();
            Thread.sleep(5000);
//            WebDriverWait wait = new WebDriverWait(driver, 40);
//            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portfolio-wrap")));
            if(Util.siteNameout().contains("lab"))
            {
                driver.get("https://labsalesiq.localzoho.com");
            }
            else if(Util.siteNameout().contains("local"))
                driver.get("https://salesiq.localzoho.com");
            else if(Util.siteNameout().contains("pre"))
                driver.get("https://presalesiq.zoho.com");
            else
                driver.get("https://salesiq.zoho.com");
            try{
            	WebElement banner = CommonUtilOtherApps.elfinder(driver,"id","dnenable");
            	WebElement close = CommonUtilOtherApps.elfinder(driver,"classname","sqico-close");
            	close.click();
            }
            catch(Exception e){}
            try
            {
                Thread.sleep(2000);
                Functions.closeBannersAfterLogin(driver);
            }
            catch(Exception e)
            {
                System.out.println("Exception while closing the maintenance banner : "+e);
            }
            System.out.println("Login success for Username:"+usrname);
    }
    
    public static void logout(WebDriver driver) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        
        driver.navigate().refresh();
        Thread.sleep(5000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdrpdwntop")));
        
        driver.findElement(By.id("hdrdrpdwntop")).click();
        
        Thread.sleep(1000);
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                           {
                               return true;
                           }
                           return false;
                       }
                   });
        
        driver.findElement(By.id("hdrdrpdwn")).findElement(By.cssSelector("[href='logout.sas']")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("header")));
        
        driver.findElement(By.className("header")).findElement(By.className("signin")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
    }
    
	public static void clickSettings(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
		WebElement settings = CommonUtilOtherApps.elfinder(driver,"id","menu_setting");
		settings.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
	}
	
	public static void navToIntegTab(WebDriver driver) throws Exception
	{
		clickSettings(driver);
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_integration")));
		WebElement integ = CommonUtilOtherApps.elfinder(driver,"id","setting_sm_integration");
		integ.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("integhome")));
	}

	public static void navToEmbedTab(WebDriver driver) throws Exception
	{
		clickSettings(driver);
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));
		WebElement embed = CommonUtilOtherApps.elfinder(driver,"id","setting_sm_embedchats");
		embed.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
	}

	public static WebElement selectEmbedInWebEmbed(WebDriver driver,String embedname) throws Exception
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("list-row")));

		List<WebElement> list = driver.findElements(By.className("list-row"));

		for(WebElement e : list)
		{
			if(e.getText().contains(embedname))
			{
				return e;
			}
		}

		return null;
	}
	
	public static WebElement selectIntegApp(WebDriver driver,String app)
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("integ_li")));

		List<WebElement> otherapps = driver.findElements(By.className("integ_li"));
		for(WebElement e: otherapps)
		{
			CommonUtilOtherApps.inViewPort(e);
			if(e.getText().contains(app))
			{
				return e;
			}
		}

		return null;
	}

	public static WebElement selectWebEmbedInAnalytics(WebDriver driver,boolean active,String embed) throws Exception
	{
		WebElement div = null;

		if(active)
		{
			div = CommonUtilOtherApps.elfinder(driver,"id","enabledembeds");
		}
		else
		{
			div = CommonUtilOtherApps.elfinder(driver,"id","disabledembeds");
		}

		CommonUtilOtherApps.inViewPort(div);
        
        CommonUtilOtherApps.elementfinder(driver,div,"classname","configlist");
		
		List<WebElement> list = div.findElements(By.className("configlist"));
		
		for(WebElement e : list)
		{
			CommonUtilOtherApps.inViewPort(e);
			CommonWait.waitTillDisplayed(e);
			if(e.getText().contains(embed))
			{
				return e;
			}
		}

		return null;
	}
	public static boolean checkEnabledStatusInIntegHome(WebDriver driver,String appname,String status,ExtentTest etest) throws Exception
	{
		String actual = CommonUtilOtherApps.elementfinder(driver,selectIntegApp(driver,appname),"tagname","em").getAttribute("class");

		if(actual.contains(status))
			return true;

		TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegration",appname,"MismatchEnabledStatusInIntegHome.Actual:"+actual+"--Expected:"+status);
		return false;
	}

	public static String toggleStatusOfEmbedInAnalytics(WebDriver driver,boolean active,String embedname) throws Exception
	{
		WebElement embed = selectWebEmbedInAnalytics(driver,active,embedname);
			
		String id = CommonUtilOtherApps.elementfinder(driver,embed,"tagname","input").getAttribute("id");

		String classname = CommonUtilOtherApps.elementfinder(driver,embed,"xpath","//div[@tbutid='"+id+"']").getAttribute("class");

		return classname;
	}
	public static void enableIntegration(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightintegbtn")));

		WebElement button = CommonUtilOtherApps.elfinder(driver,"id","rightintegbtn");

		if(CommonUtilOtherApps.elementfinder(driver,button,"tagname","span").getAttribute("purpose").contains("enableinteg"))
		{
			button.click();

			wait.until(new Function<WebDriver, Boolean>() {
	            public Boolean apply(WebDriver driver) {
	            	try
	            	{
						if(CommonUtilOtherApps.elfinder(driver, "id","disablecontainer").getAttribute("class").equals(""))
							return true;
					}
					catch (Exception e) {}
	            	return false;
	            }
	        });
		}
	}

	public static boolean disableIntegration(WebDriver driver,String appname,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightintegbtn")));

		WebElement button = CommonUtilOtherApps.elfinder(driver,"id","rightintegbtn");

		if(CommonUtilOtherApps.elementfinder(driver,button,"tagname","span").getAttribute("purpose").contains("disableinteg"))
		{
			button.click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

			String header = CommonUtilOtherApps.elementfinder(driver,CommonUtilOtherApps.elfinder(driver,"classname","lvd_popupsub"),"classname","lvd_popuptitle").getText();
			String desc = CommonUtilOtherApps.elementfinder(driver,CommonUtilOtherApps.elfinder(driver,"classname","lvd_popupsub"),"id","popupdesc").getText();

			String headerExpected = ResourceManager.getRealValue("disabling_analytics_integ_header").replace("AnalyticsApp",appname);
			String descExpected = ResourceManager.getRealValue("disabling_analytics_integ_desc").replace("AnalyticsApp",appname);
			String noteExpected = ResourceManager.getRealValue("disabling_analytics_integ_note").replace("AnalyticsApp",appname);;
			
			if(!(header.contains(headerExpected) && desc.contains(descExpected) && desc.contains(noteExpected)))
			{
				etest.log(Status.FAIL,"Actual--"+header+"--"+desc+"--Expected--"+headerExpected+"--"+descExpected+noteExpected+"--");
				TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegration",appname,"DisablingContentMismatch");
				return false;
			}

			CommonUtilOtherApps.elementfinder(driver,CommonUtilOtherApps.elfinder(driver,"classname","lvd_popupsub"),"id","okbtn").click();

			wait.until(new Function<WebDriver, Boolean>() {
	            public Boolean apply(WebDriver driver) {
	            	try
	            	{
						if(!CommonUtilOtherApps.elfinder(driver, "id","disablecontainer").getAttribute("class").equals(""))
							return true;
					}
					catch (Exception e) {}
	            	return false;
	            }
	        });

	        return true;
		}

		return true;
	}

	public static void changeStatusOfWebEmbed(WebDriver driver,final boolean toenable,String embedname, final WebElement web) throws Exception
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);
	
		Thread.sleep(1000);
        
        String status = "enabled";
        
        if(!toenable)
        {
            status = "disabled";
        }


		String classname = "";
        
        if(toenable == (!web.getAttribute("class").contains("list_disable")))
        {
            OtherAppsInteg.etest.log(Status.INFO,"Website "+embedname+" is "+status);
            return ;
        }
        
        if(toenable)
        {
            classname = "sqico-disable";
        }
        else
        {
            classname = "sqico-enable";
        }
        
        CommonUtilOtherApps.elementfinder(driver,web,"classname",classname).click();
        
        Tab.waitForLoadingLine(driver);
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if(toenable == (!web.getAttribute("class").contains("list_disable")))
                           {
                               return true;
                           }
                           
                           return false;
                       }
                   });
        
        Thread.sleep(1000);
        
        OtherAppsInteg.etest.log(Status.INFO,"Website "+embedname+" is "+status);
        
        Functions.createTabAndCloseCurrent2(driver);
	}

	public static void changeStatusOfWebEmbedInAnalytics(WebDriver driver,final boolean active,final String embedname,boolean enable) throws Exception
	{

		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);

		String initialClassname = null, finalClassname = null;
		if(enable)
		{
			initialClassname = "togglebtn set_off";
			finalClassname = "togglebtn set_on";
		}
		else
		{
			initialClassname = "togglebtn set_on";
			finalClassname = "togglebtn set_off";
		}
	
		String classname = toggleStatusOfEmbedInAnalytics(driver,active,embedname);

		if(classname.contains(initialClassname))
		{
			Thread.sleep(1000);
			CommonUtilOtherApps.elementfinder(driver,selectWebEmbedInAnalytics(driver,active,embedname),"classname","togglebtn").click();
		}
		
		if( !active && enable)
		{
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
	    }
	    else
	    {
	    	final String finalClassname1 = finalClassname;

			wait.until(new Function<WebDriver, Boolean>() {
	            public Boolean apply(WebDriver driver) {
	            	try
	            	{
						if(toggleStatusOfEmbedInAnalytics(driver,active,embedname).contains(finalClassname1))
							return true;
					}
					catch (Exception e) {}
	            	return false;
	            }
	        });
	    }
	}

	public static boolean enableInactiveWebEmbedInAnalytics(WebDriver driver,String appname,String embedname,boolean enableWebEmbed,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtilOtherApps.waitreturner(driver,30,250);

		changeStatusOfWebEmbedInAnalytics(driver,false,embedname,true);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

		WebElement popup = CommonUtilOtherApps.elfinder(driver,"classname","lvd_popupsub");

		String header = CommonUtilOtherApps.elementfinder(driver,popup,"classname","lvd_popuptitle").getText();

		String desc = CommonUtilOtherApps.elementfinder(driver,popup,"id","popupdesc").getText();

		WebElement okbtn = CommonUtilOtherApps.elementfinder(driver,popup,"id","okbtn");

		WebElement cancelbtn = CommonUtilOtherApps.elementfinder(driver,popup,"id","cancelbtn");
        
//        etest.log(Status.INFO,"<>"+header+"<>");
//        etest.log(Status.INFO,"<>"+desc+"<>");
//        etest.log(Status.INFO,"<>"+okbtn.getText()+"<>");
//        etest.log(Status.INFO,"<>"+cancelbtn.getText()+"<>");
//        
//        etest.log(Status.INFO,"<>"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_header")+"<>");
//        etest.log(Status.INFO,"<>"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_desc").replace("AnalyticsApp",appname)+"<>"+embedname+"<>");
//        etest.log(Status.INFO,"<>"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_okbtn")+"<>");
//        etest.log(Status.INFO,"<>"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_cancelbtn")+"<>");

		if(header.contains(ResourceManager.getRealValue("enabling_inactivewebembed_analytics_header")))
		{
			if(desc.contains(ResourceManager.getRealValue("enabling_inactivewebembed_analytics_desc").replace("AnalyticsApp",appname))&&desc.contains(embedname))
			{
				if(okbtn.getText().contains(ResourceManager.getRealValue("enabling_inactivewebembed_analytics_okbtn")))
				{
					if(cancelbtn.getText().contains(ResourceManager.getRealValue("enabling_inactivewebembed_analytics_cancelbtn")))
					{
						if(enableWebEmbed)
						{
							okbtn.click();
						}
						else
						{
							cancelbtn.click();
						}
					}
					else
					{
						etest.log(Status.FAIL,"MismatchCancelBtnContent.Actual:"+cancelbtn.getText()+"--Expected:"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_cancelbtn"));
						TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegration","EnablingInactiveWebEmbeds","MismatchCancelBtnContent");
						return false;
					}
				}
				else
				{
					etest.log(Status.FAIL,"MismatchOkBtnContent.Actual:"+okbtn.getText()+"--Expected:"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_okbtn"));
					TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegration","EnablingInactiveWebEmbeds","MismatchOkBtnContent");
					return false;
				}
			}
			else
			{
				etest.log(Status.FAIL,"MismatchDesc.Actual:"+desc+"--Expected:"+embedname+" "+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_desc").replace("AnalyticsApp",appname));
				TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegration","EnablingInactiveWebEmbeds","MismatchDescription");
				return false;
			}
		}
		else
		{
			etest.log(Status.FAIL,"MismatchHeader.Actual:"+header+"--Expected:"+ResourceManager.getRealValue("enabling_inactivewebembed_analytics_header"));
			TakeScreenshot.screenshot(driver,etest,"OtherAppsIntegration","EnablingInactiveWebEmbeds","MismatchHeader");
			return false;
		}

		return true;
	}
}
