//$Id$
package com.zoho.livedesk.client.ChatHistory;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.objects.ChatStatus;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.SettingsTab;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;
import com.zoho.livedesk.client.CRM.PotentialAdd;

public class ChatHistoryTests
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Chat History";
	public static String WIDGET_CODE="",WEBSITE_NAME="";

	public static VisitorDriverManager visitor_driver_manager;

	public static final String
	DUTCH_TEXT = "Nederlands",
	DUTCH_TRANSLATED_TEXT="dutch"
	;

	public static final String[]
	STATUS_LIST = {"Closed","Attended Online","Attended by Email","Tracked in CRM","Missed"},
	DATE_LIST = {"Today","Yesterday","This week","Last week","This month","Last month","Choose a Range"},
	INTEGRATION_STATUS_LIST = {"CRM Contacts","CRM Deals","CRM Leads","Not Available in CRM"}
	;

	public static final int NOTE_CHAR_LIMIT=2048;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			MODULE_NAME="Chat History";
			
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH1",checkShowOnlyMyChats(driver,etest));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH3",checkOldChatsLoadedWhenScrolledToBottom(driver,etest));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH6",checkDeleteChat(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH8"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH8",checkExportAs(driver,etest,ChatHistory.XLSX));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH9",checkExportAs(driver,etest,ChatHistory.CSV));
            ComplexReportFactory.closeTest(etest); 

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH10",checkChatIDIncreasesByOne(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH11",checkRetrieveChatInfoBasic(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Retrieve Translated Transcript");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRetrieveTranslatedChat(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH18"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH18",checkSaveTranscriptAsPDF(driver,etest));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH19"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH19",checkVisitorInfoRetrieved(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH20"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH20",checkReasonForMissed(driver,etest,WIDGET_CODE,AgentStatus.BUSY));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH21"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH21",checkReasonForMissed(driver,etest,WIDGET_CODE,AgentStatus.AVAILABLE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check add note");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkAddNote(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH26"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH26",checkChatHistoryChatTabsOpened(driver,etest,ChatWindow.CHAT_VIEW_ID,"CH27"));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH28"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH28",checkChatHistoryChatTabsOpened(driver,etest,ChatWindow.NOTES_VIEW_ID,"CH29"));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH30"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH30",checkChatHistoryChatTabsOpened(driver,etest,ChatWindow.INFO_VIEW_ID,"CH31"));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check edit visitor info");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEditVisitorInfo(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Toggle recent chats and visitor info in chat window RHS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRecentChatsToggle(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH40"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH40",verifyRecentChatsInfo(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH41"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH41",verifyHistoryChatInfo(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH43"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH43",checkHistoryChatTab(driver,etest,WIDGET_CODE,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH44"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH44",checkHistoryChatTab(driver,etest,WIDGET_CODE,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CH45"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CH45",checkHistoryChatTabEmptyState(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest); 

			checkFilterOptions(driver,etest,WIDGET_CODE);

			//running some chat module tests in this portal
			etest=ComplexReportFactory.getTest("Check live typing status");
			ComplexReportFactory.setValues(etest,"Automation",com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeTests.MODULE_NAME);
			checkTypingStatus(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getEtest("Check operator filter list",MODULE_NAME);
            checkFilterList(driver,etest,"CHT14");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getEtest("Check status filter list",MODULE_NAME);
            checkFilterList(driver,etest,"CHT15");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getEtest("Check department filter list",MODULE_NAME);
            checkFilterList(driver,etest,"CHT16");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getEtest("Check embed filter list",MODULE_NAME);
            checkFilterList(driver,etest,"CHT17");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getEtest("Check date filter list",MODULE_NAME);
            checkFilterList(driver,etest,"CHT18");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getEtest("Check integration status filter list",MODULE_NAME);
            checkFilterList(driver,etest,"CHT19");
            ComplexReportFactory.closeTest(etest);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}            
	}

	public static boolean checkShowOnlyMyChats(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount=0;

		try
		{
			Tab.clickChatHistory(driver);

			if(!ChatHistory.isShowOnlyMyChats(driver))
			{
				etest.log(Status.PASS,"'Show Only My Chats' was NOT checked when chat history was clicked for first time.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"'Show Only My Chats' was checked when chat history was clicked for first time.");
				TakeScreenshot.screenshot(driver,etest);
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkOldChatsLoadedWhenScrolledToBottom(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount=0;

		try
		{
			Tab.clickChatHistory(driver);

			if(ChatHistory.scrollToChatsLoadingDiv(driver,etest))
			{
				etest.log(Status.PASS,"Older chats were loaded after scrolling to bottom of chat history tab.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Older chats were NOT loaded after scrolling to bottom of chat history tab.");		
				TakeScreenshot.screenshot(driver,etest);		
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkDeleteChat(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);
			quickChat(driver,visitor_driver,etest,widgetcode,label);

			Tab.clickChatHistory(driver);

			boolean isDeleted=ChatHistory.deleteChat(driver,etest,label);

			if(isDeleted)
			{
				result.put("CH4",true);
				etest.log(Status.PASS,"Chat was NOT found in chat history tab after it was deleted");
			}
			else
			{
				result.put("CH4",false);
				etest.log(Status.FAIL,"Chat was found in chat history tab after it was deleted");	
				TakeScreenshot.screenshot(driver,etest);			
			}

			List<WebElement> search_result=GlobalSearch.search(driver,label);

			if(search_result==null || search_result.isEmpty())
			{
				etest.log(Status.PASS,"Deleted chat was NOT found in search results");
			}
			else
			{
				etest.log(Status.FAIL,"Deleted chat was found in search results");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			Tab.clickChatHistory(driver);

			ChatHistory.scrollToChatsLoadingDivForNTimes(driver,etest,5);

			if(ChatHistory.getNoOfChats(driver)<50)
			{
				throw new ZohoSalesIQRuntimeException("50 chats were not found. Could not test usecase");
			}

			ChatHistory.selectAllChats(driver,etest);

			TakeScreenshot.infoScreenshot(driver,etest);
			
	        CommonSikuli.findInWholePage(driver,"UI351.png","UI351",etest);

			ChatHistory.clickDeleteChatsButton(driver);

	        WebElement popup=HandleCommonUI.getPopupByInnerText(driver,ResourceManager.getRealValue("chat_history_delete_chat_limit_exceeded"));

	        CommonSikuli.findInWholePage(driver,"UI344.png","UI344",etest);

	        if(popup!=null)
	        {
	        	etest.log(Status.PASS,"Delete chats limit exceeded popup was found with text '"+ResourceManager.getRealValue("chat_history_delete_chat_limit_exceeded")+"' as expected");
	        	result.put("CH7",true);
	        }
	        else
	        {
	        	result.put("CH7",false);
	        	etest.log(Status.FAIL,"Delete chats limit exceeded popup was NOT found with text '"+ResourceManager.getRealValue("chat_history_delete_chat_limit_exceeded")+"' as expected");
	       		TakeScreenshot.screenshot(driver,etest);
	        }

		    HandleCommonUI.clickPositivePopupButton(popup);			
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkExportAs(WebDriver driver,ExtentTest etest,String export_as) throws Exception
	{
		int failcount=0;

		try
		{
			Tab.clickChatHistory(driver);

			String old_file_download_text=ChromeDownloadManager.getLatestDownloadText(driver,etest);

	        CommonSikuli.findInWholePage(driver,"UI340.png","UI340",etest);

			ChatHistory.exportAs(driver,export_as);

			CommonUtil.sleep(10000);//wait till file downloaded

			if(ChromeDownloadManager.isNewFileDownloaded(driver,etest,old_file_download_text)==false)
			{
				failcount++;
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static String quickChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code,String label) throws Exception
	{
		return quickChat(driver,visitor_driver,etest,widget_code,label,false);
	}

	public static String quickChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code,String label,boolean isMessage) throws Exception
	{
		return quickChat(driver,visitor_driver,etest,widget_code,label,isMessage,ChatType.COMPLETED);
	}

	public static String quickChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code,String label,boolean isMessage,ChatType chat_type) throws Exception
    {
    	Hashtable<String,List<String>> messages=null;

        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");

        etest.log(Status.INFO,"Chat will be initiated with following values.\n"+visitor_details.toString());

        if(isMessage)
        {
			messages=ConversationViewCommonFunctions.addMessageDetails(label,3);
        }

        return ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,chat_type,visitor_details,messages);
    }

	public static void quickMultipleChats(WebDriver driver,VisitorDriverManager visitor_driver_manager,ExtentTest etest,String widget_code,String label,int no_of_chats) throws Exception
    {
    	WebDriver visitor_driver=null;

    	for(int i=1;i<=no_of_chats;i++)
    	{
    		visitor_driver=visitor_driver_manager.getDriver(driver);

	    	etest.log(Status.INFO,"Initiating multiple chats. Current chat : "+i);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",label,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+i+"?","fb"+label+i,"3");
			Hashtable<String,List<String>> messages=ConversationViewCommonFunctions.addMessageDetails(label+i,3);
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,messages);
	    	etest.log(Status.INFO,"Current chat : "+(i)+" was completed");
    	}
    }

    public static Hashtable<String,String> getNThChatVisitorInfo(WebDriver driver,String label,int chat_index) throws Exception
    {
	    return ConversationViewCommonFunctions.addVisitorDetails("V"+label,"v"+label+"@email.com",label,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+chat_index+"?","fb"+label+chat_index,"3");    	
    }

    public static Hashtable<String,List<String>> getNThChatMessages(String label,int chat_index)
    {
	    return ConversationViewCommonFunctions.addMessageDetails(label+chat_index,3);   	
    }

	public static boolean checkChatIDIncreasesByOne(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);
			quickChat(driver,visitor_driver,etest,widgetcode,label);

			Tab.clickChatHistory(driver);

	        CommonSikuli.findInWholePage(driver,"UI347.png","UI347",etest);

			int old_chat_id=Integer.parseInt( ChatHistory.getChatData( ChatHistory.getLatestChat(driver) ).get(ChatHistory.CH_ID) );

			visitor_driver=visitor_driver_manager.getDriver(driver);
			quickChat(driver,visitor_driver,etest,widgetcode,label);

			Tab.clickChatHistory(driver);		

			int new_chat_id=Integer.parseInt( ChatHistory.getChatData( ChatHistory.getLatestChat(driver) ).get(ChatHistory.CH_ID) );

			if(new_chat_id==(old_chat_id+1))
			{
				etest.log(Status.PASS,"Chat id increased by 1 from "+old_chat_id+" to "+new_chat_id);
			}
			else
			{
				etest.log(Status.FAIL,"Chat id did NOT increase by one. ( previous chid : "+old_chat_id+" current_chid : "+new_chat_id+" )");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkRetrieveChatInfoBasic(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;

		final String
		visitor_name="V"+label,
		visitor_mail="v"+label+"@email.com",
		visitor_phone=label.substring(0,10),
		visitor_question="Q"+label+"?",
		visitor_feedback="FB"+label,
		rating="3"
		;

		String website=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);


			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,visitor_phone,null,visitor_question,visitor_feedback,rating);
			visitor_details.put(ConversationViewConstants.AGENT_NAME,ExecuteStatements.getUserName(driver));
			Hashtable<String,List<String>> messages=ConversationViewCommonFunctions.addMessageDetails(label);
	        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widgetcode,ChatType.COMPLETED,visitor_details,messages);

	        website=visitor_driver.getCurrentUrl();

			Tab.clickChatHistory(driver);

			ChatHistory.openChatByLabel(driver,visitor_name);

	        CommonSikuli.findInWholePage(driver,"UI345.png","UI345",etest);

			Hashtable<String,String> chat_data=ChatHistoryChat.getChatData(driver);
	        Hashtable<String,ArrayList<String>> categorised_messages=ChatHistoryChat.getMessages(driver);

	        // checking visitor question container
	        if(CommonUtil.checkStringContainsAndLog(visitor_name,chat_data.get(ChatHistory.VISITOR),"visitor name",etest)==false)
	        {
	        	failcount++;
	        }

	        if(CommonUtil.checkStringContainsAndLog(visitor_mail,chat_data.get(ChatHistory.MAIL),"visitor mail",etest)==false)
	        {
	        	failcount++;
	        }

	        if(CommonUtil.checkStringContainsAndLog(visitor_question,chat_data.get(ChatHistory.QUESTION),"visitor question",etest)==false)
	        {
	        	failcount++;
	        }

	        //checking transcript
	        List<String> actual_visitor_messages=categorised_messages.get(ChatHistoryChat.VISITOR_MESSAGE_LIST);
	        List<String> actual_agent_messages=categorised_messages.get(ChatHistoryChat.AGENT_MESSAGE_LIST);

	        List<String> expected_visitor_messages=messages.get(ConversationViewConstants.VISITOR_MESSAGES);
	        List<String> expected_agent_messages=messages.get(ConversationViewConstants.AGENT_MESSAGES);

	        int messages_failcount=0;

	        if(HandleCommonUI.checkMessages(expected_visitor_messages,actual_visitor_messages,"visitor message",etest)==false)
	        {
	        	messages_failcount++;
	        }

	        if(HandleCommonUI.checkMessages(expected_agent_messages,actual_agent_messages,"agent message",etest)==false)
	        {
	        	messages_failcount++;
	        }

	        result.put("CH13",CommonUtil.returnResult(messages_failcount));

	        //checking rhs
			Hashtable<String,String> chat_data_rhs=ChatHistoryChat.getChatDataRHS(driver);

			int chat_info_rhs_failcount=0;

	        if(CommonUtil.checkStringContainsAndLog(visitor_mail,chat_data_rhs.get(ChatHistory.MAIL),"visitor mail rhs",etest)==false)
	        {
	        	chat_info_rhs_failcount++;
	        }

	        if(CommonUtil.checkStringContainsAndLog(visitor_phone,chat_data_rhs.get(ChatHistory.VISITOR_PHONE),"visitor phone rhs",etest)==false)
	        {
	        	chat_info_rhs_failcount++;
	        }

	        if(CommonUtil.checkStringContainsAndLog(website.split("\\?")[0],chat_data_rhs.get(ChatHistory.WEBSITE).split("\\?")[0],"visitor website rhs",etest)==false)
	        {
	        	chat_info_rhs_failcount++;
	        }	

	        result.put("CH12",CommonUtil.returnResult(chat_info_rhs_failcount));
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkRetrieveTranslatedChat(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;

		final String
		visitor_name="V"+label,
		visitor_mail="v"+label+"@email.com",
		visitor_phone=label.substring(0,10),
		visitor_question=DUTCH_TEXT,
		visitor_feedback="FB"+label,
		rating="3",
		agent_message="bericht",
		agent_message_translated="message"
		;

		String website=null;

		try
		{
			PortalInput portal_input=new PortalInput(PortalSetting.GOOGLE_TRANSLATION,"Auto");
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);

 			visitor_driver=visitor_driver_manager.getDriver(driver);

			// Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,visitor_phone,null,visitor_question,visitor_feedback,rating);
	        // String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,WIDGET_CODE,ChatType.ONGOING,visitor_details,null);

	        VisitorWindow.createPage(visitor_driver,widgetcode);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
	        ChatWindow.acceptChat(driver,etest);
	        try
	        {
				ChatWindow.confirmAutoTranslate(driver,etest,true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			catch(Exception e)
			{
				etest.log(Status.INFO,"Confirmation text for translation was not present");
				TakeScreenshot.infoScreenshot(driver,etest);
			}

			CommonUtil.sleep(5000);//to wait till text translated

			ChatWindow.sentMessage(driver,agent_message_translated);
			VisitorWindow.waitTillMessageInChat(visitor_driver,agent_message);//translated message
			ChatWindow.waitTillMessageInChat(driver,agent_message_translated);
			CommonUtil.sleep(500);
			TakeScreenshot.infoScreenshot(driver,etest);

	        ChatWindow.closeAllChats(driver);
	        Driver.quitDriver(visitor_driver);

	        driver.navigate().refresh();

        	Tab.clickChatHistory(driver);

        	ChatHistory.openChatByLabel(driver,label);

        	ChatHistoryChat.setTranslationTo(driver,etest,true);

        	String translated_visitor_question=ChatHistoryChat.getChatData(driver).get(ChatHistory.QUESTION).toLowerCase();
        	String translated_agent_message=ChatHistoryChat.getMessages(driver).get(ChatHistoryChat.AGENT_MESSAGE_LIST).get(0).toLowerCase();

        	int translate_usecase_failcount=0;

        	if(CommonUtil.checkStringContainsAndLog(DUTCH_TRANSLATED_TEXT.trim(),translated_visitor_question.trim(),"translated visitor question",etest)==false)
        	{
        		translate_usecase_failcount++;
        		TakeScreenshot.screenshot(driver,etest);
        	}
        	if(CommonUtil.checkStringContainsAndLog(agent_message_translated,translated_agent_message,"translated agent message",etest)==false)
        	{
        		translate_usecase_failcount++;
        		TakeScreenshot.screenshot(driver,etest);
        	}

        	result.put("CH17",CommonUtil.returnResult(translate_usecase_failcount));

        	ChatHistoryChat.setTranslationTo(driver,etest,false);

        	String original_visitor_question=ChatHistoryChat.getChatData(driver).get(ChatHistory.QUESTION).toLowerCase();
        	String original_agent_message=ChatHistoryChat.getMessages(driver).get(ChatHistoryChat.AGENT_MESSAGE_LIST).get(0).toLowerCase();

        	int original_transcript_usecase=0;

        	if(CommonUtil.checkStringContainsAndLog(visitor_question.toLowerCase(),original_visitor_question,"original visitor question",etest)==false)
        	{
        		original_transcript_usecase++;
        		TakeScreenshot.screenshot(driver,etest);
        	}
        	if(CommonUtil.checkStringContainsAndLog(agent_message.toLowerCase(),original_agent_message,"original agent message",etest)==false)
        	{
        		original_transcript_usecase++;
        		TakeScreenshot.screenshot(driver,etest);
        	}

        	result.put("CH16",CommonUtil.returnResult(original_transcript_usecase));
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{

		}
	}

	public static boolean checkSaveTranscriptAsPDF(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount=0;

		String  current_url=null;

		try
		{
			current_url=driver.getCurrentUrl();

			String old_file_download_text=ChromeDownloadManager.getLatestDownloadText(driver,etest);

			Tab.clickChatHistory(driver);

			ChatHistory.clickLatestChatFromChatHistory(driver);

			ChatHistoryChat.selectActionFromDropdown(driver,ChatHistoryChat.ACTIONS_SAVE_PDF);
			// HandleCommonUI.authenticateFileDownloadPopup(driver);//uncomment if portal is gdpr enabled

			CommonUtil.sleep(10000);//wait till file downloaded

			if(ChromeDownloadManager.isNewFileDownloaded(driver,etest,old_file_download_text)==false)
			{
				failcount++;
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
		finally
		{
			try
			{
				driver.get(current_url);
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e1);
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkVisitorInfoRetrieved(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		final String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="V"+label,
		visitor_mail="v"+label+"@email.com",
		visitor_phone=label.substring(0,10),
		visitor_question="Q"+label+"?",
		visitor_feedback="FB"+label,
		rating="3"
		;

		try
		{
			Tab.clickChatHistory(driver);


 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
	        ChatWindow.acceptChat(driver,etest);
	        ChatWindow.openVisitorInfo(driver);

	        Hashtable<String,String> visitor_info_during_chat=ChatWindow.getAllVisitorInfo(driver);

	        //removing uncheckable keys
	        visitor_info_during_chat.remove(ResourceManager.getRealValue("time_chatduration"));

	        ChatWindow.openChatTranscript(driver);

	        ChatWindow.closeAllChats(driver);
	        Driver.quitDriver(visitor_driver);

	        driver.navigate().refresh();

        	Tab.clickChatHistory(driver);

        	ChatHistory.openChatByLabel(driver,label);	

        	ChatHistoryChat.openVisitorInfo(driver);

	        Hashtable<String,String> visitor_info_after_chat=ChatHistoryChat.getAllVisitorInfo(driver);

	        if(CommonUtil.compareHashtable(visitor_info_during_chat,visitor_info_after_chat,etest)==false)
	        {
	        	failcount++;
	        	TakeScreenshot.screenshot(driver,etest);
	        }
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkReasonForMissed(WebDriver driver,ExtentTest etest,String widgetcode,AgentStatus status) throws Exception
	{
		int failcount=0;

		final String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="V"+label,
		visitor_mail="v"+label+"@email.com",
		visitor_phone=label.substring(0,10),
		visitor_question="Q"+label+"?",
		visitor_feedback="FB"+label,
		rating="3"
		;

		String expected_reason_for_missed=null;

		WebDriver visitor_driver=null;

		try
		{
			Tab.clickChatHistory(driver);

			etest.log(Status.INFO,"Initiating chat which will be missed");

 			visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

			if(status==AgentStatus.BUSY)
			{
	            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");
			}

			if(status==AgentStatus.AVAILABLE)
			{
	            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			}
			etest.log(Status.INFO,"Agent status was set to "+status);

			if(status==AgentStatus.AVAILABLE)
			{
		        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
		        VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
			}
			else if(status==AgentStatus.BUSY)
			{
		        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,visitor_phone,null,visitor_question,false,etest,true);
		        VisitorWindow.infoInvisible(visitor_driver);
		        VisitorWindow.submitDataInOfflineChat(visitor_driver,visitor_name,visitor_mail,visitor_phone,visitor_question,etest);
		        etest.log(Status.INFO,"Offline response message was submitted.");
		        TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			TakeScreenshot.infoScreenshot(driver,etest);

	        Driver.quitDriver(visitor_driver);

	        driver.navigate().refresh();

        	Tab.clickChatHistory(driver);

        	ChatHistory.openChatByLabel(driver,label);	

        	ChatHistoryChat.openVisitorInfo(driver);

	        String actual_reason_for_missed=ChatHistoryChat.getAllVisitorInfo(driver).get(ResourceManager.getRealValue("reason_for_missed"));

	        if(status==AgentStatus.AVAILABLE)
	        {
	        	expected_reason_for_missed=ResourceManager.getRealValue("all_operators_busy");	
	        }
	        else if(status==AgentStatus.BUSY)
	        {
	        	expected_reason_for_missed=ResourceManager.getRealValue("operators_unavailable");	
	        }

	        if(CommonUtil.checkStringContainsAndLog(expected_reason_for_missed,actual_reason_for_missed,ResourceManager.getRealValue("reason_for_missed"),etest)==false)
	        {
	        	failcount++;
	        	TakeScreenshot.screenshot(driver,etest);
	        }
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
		finally
		{
	        com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkAddNote(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		final String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="V"+label,
		visitor_mail="v"+label+"@email.com",
		visitor_phone=label.substring(0,10),
		visitor_question="Q"+label+"?",
		visitor_feedback="FB"+label,
		rating="3",
		note="note"+label
		;

		try
		{
			Tab.clickChatHistory(driver);


 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
	        ChatWindow.acceptChat(driver,etest);

	        ChatWindow.openNotes(driver);
	        ChatWindow.addNote(driver,etest,note);

	        CommonSikuli.findInWholePage(driver,"UI346.png","UI346",etest);
	        CommonSikuli.findInWholePage(driver,"UI350.png","UI350",etest);

	        etest.log(Status.PASS,"Note  '"+note+"' was added during chat.");
	        ChatWindow.openChatTranscript(driver);
	        ChatWindow.closeAllChats(driver);
	        Driver.quitDriver(visitor_driver);

	        driver.navigate().refresh();

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,visitor_name);
	        ChatWindow.openNotes(driver);

	        if(ChatWindow.containsNote(driver,note))
	        {
	        	result.put("CH22",true);
	        	etest.log(Status.PASS,"Expected note '"+note+"' was found in notes tab when chat was opened from chat history tab");
	        }
	        else
	        {
	        	result.put("CH22",false);
	        	etest.log(Status.FAIL,"Expected note '"+note+"' was found in notes tab when chat was opened from chat history tab");
	        	TakeScreenshot.screenshot(driver,etest);
	        }

	        String note2="notes2"+label;
	        ChatWindow.addNote(driver,etest,note2);
	        etest.log(Status.PASS,"Note  '"+note2+"' was added from chat opened from chat history");

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,visitor_name);
	        ChatWindow.openNotes(driver);

	        if(ChatWindow.containsNote(driver,note))
	        {
	        	result.put("CH23",true);
	        	etest.log(Status.PASS,"Expected note '"+note+"' was found in notes tab when chat was opened from chat history tab");
	        }
	        else
	        {
	        	result.put("CH23",false);
	        	etest.log(Status.FAIL,"Expected note '"+note+"' was found in notes tab when chat was opened from chat history tab");
	        	TakeScreenshot.screenshot(driver,etest);
	        }

        	String note3=HandleCommonUI.getInputSample(NOTE_CHAR_LIMIT+1);
	        boolean isNoteAdded=ChatWindow.addNote(driver,etest,note3);

	        if(!isNoteAdded)
	        {
	        	result.put("CH25",true);
		        etest.log(Status.PASS,"Note was NOT added when char limit was more than "+NOTE_CHAR_LIMIT);
	        }
	        else
	        {
	        	result.put("CH25",false);
		        etest.log(Status.FAIL,"Note was added when char limit was more than "+NOTE_CHAR_LIMIT);
		        TakeScreenshot.screenshot(driver,etest);
	        }
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static boolean checkChatHistoryChatTabsOpened(WebDriver driver,ExtentTest etest,String tab_type,String chat_history_tab_usecase) throws Exception
	{
		int failcount=0;

		try
		{
			Tab.clickChatHistory(driver);
			ChatHistory.clickLatestChatFromChatHistory(driver);

			if(tab_type.equals(ChatWindow.CHAT_VIEW_ID))
			{
				//to open something else because chat view id will already be open by default
				ChatWindow.openVisitorInfo(driver);
			}

			if(ChatHistoryChat.openChatView(driver,tab_type))
			{
				etest.log(Status.PASS,tab_type+" tab was opened successfully from chat history tab.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,tab_type+" tab was opened successfully from chat history tab.");
				TakeScreenshot.screenshot(driver,etest);
			}

			ChatHistoryChat.clickChatHistoryInCustomerActionsContainer(driver);

			if(ChatHistory.isTabDisplayed(driver))
			{
				etest.log(Status.PASS,"Chat History tab was opened when 'Chat History' was clicked in cusactions container");
				result.put(chat_history_tab_usecase,true);
			}
			else
			{
				etest.log(Status.FAIL,"Chat History tab was NOT opened when 'Chat History' was clicked in cusactions container");
				TakeScreenshot.screenshot(driver,etest);
				result.put(chat_history_tab_usecase,false);
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkEditVisitorInfo(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		final String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="V"+label,
		visitor_mail="v"+label+"@email.com",
		visitor_phone=label.substring(0,10),
		visitor_question="Q"+label+"?",
		visitor_feedback="FB"+label,
		rating="3",
		note="note"+label
		;

		final String
		new_first_name="New_first_"+visitor_name,
		new_second_name="New_second_"+visitor_name,
		new_mail="new"+visitor_mail,
		new_phone="987"+visitor_phone
		;

		final String
		new_first_name2="New_first2_"+visitor_name,
		new_second_name2="New_second2_"+visitor_name,
		new_mail2="new2"+visitor_mail,
		new_phone2="9872"+visitor_phone
		;

		try
		{
			Tab.clickChatHistory(driver);


 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
	        ChatWindow.acceptChat(driver,etest);

	        ChatHistoryChat.setRHSData(driver,etest,new_first_name,new_second_name,new_mail,new_phone);

	        ChatWindow.closeAllChats(driver);
	        Driver.quitDriver(visitor_driver);

	        driver.navigate().refresh();

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,visitor_name);

	        if(ChatHistoryChat.verifyChatData(driver,etest,new_first_name,new_second_name,new_mail,new_phone))
	        {
	        	etest.log(Status.PASS,"Expected visitor data was found after changing during chat");
	        	result.put("CH32",true);
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Expected visitor data was NOT found after changing during chat");	      
	        	TakeScreenshot.screenshot(driver,etest);  	
	        	result.put("CH32",false);
	        }

	        ChatHistoryChat.setRHSData(driver,etest,new_first_name2,new_second_name2,new_mail2,new_phone2);

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,visitor_name);

	        if(ChatHistoryChat.verifyChatData(driver,etest,new_first_name2,new_second_name2,new_mail2,new_phone2))
	        {
	        	result.put("CH33",true);
	        	etest.log(Status.PASS,"Expected visitor data was found after changing from chat history");
	        }
	        else
	        {
	        	result.put("CH33",false);
	        	etest.log(Status.FAIL,"Expected visitor data was NOT found after changing from chat history");	      
	        	TakeScreenshot.screenshot(driver,etest);  	
	        }

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,visitor_name);

	        boolean isInvalidInputsSaved=true;

	        try
	        {
		        ChatHistoryChat.setRHSData(driver,etest,"3"+new_first_name,"3"+new_second_name,"invalid_mail","invalid_phone");
	        }
	        catch(Exception e)
	        {
	        	isInvalidInputsSaved=false;
	        }
	        
	        if(!isInvalidInputsSaved)
	        {
	        	result.put("CH34",true);
	        	etest.log(Status.PASS,"Invalid visitor info was NOT saved in RHS visitor info");
	        }
	        else
	        {
	        	result.put("CH34",false);
	        	etest.log(Status.FAIL,"Invalid visitor info was saved in RHS visitor info");
	        	TakeScreenshot.screenshot(driver,etest);
	        }

	        if(ChatHistoryChat.isRHSInputInvalid(driver))
	        {
	        	result.put("CH35",true);
	        	etest.log(Status.PASS,"RHS Input was found as invalid after invalid data was entered");
	        }
	        else
	        {
	        	result.put("CH35",false);
	        	etest.log(Status.FAIL,"RHS Input was NOT found as invalid after invalid data was entered");
	        	TakeScreenshot.screenshot(driver,etest);
	        }
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static boolean verifyRecentChatsInfo(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			quickMultipleChats(driver,visitor_driver_manager,etest,widgetcode,label,1);

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,getNThChatVisitorInfo(driver,label,1).get(ConversationViewConstants.VISITOR_QUESTION));
			String expected_chat_id=ChatHistoryChat.getChatData(driver).get(ChatHistory.CH_ID);

 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

	        Hashtable<String,String> visitor_details=getNThChatVisitorInfo(driver,label,2);

	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);

	        ChatWindow.acceptChat(driver,etest);

	        ChatWindow.openRecentChatByQuestion(driver,getNThChatVisitorInfo(driver,label,1).get(ConversationViewConstants.VISITOR_QUESTION));

	        Hashtable<String,String> recent_chat_info=ChatWindow.getRecentChatInfo(driver);

	        Hashtable<String,String> expected_recent_chat_info=getNThChatVisitorInfo(driver,label,1);

	        String expected_question=expected_recent_chat_info.get(ConversationViewConstants.VISITOR_QUESTION);
	        String actual_question=recent_chat_info.get(ChatHistory.QUESTION);

	        if(CommonUtil.checkStringEqualsAndLog(expected_question,actual_question,"question",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_chid=expected_chat_id;
	        String actual_chid=recent_chat_info.get(ChatHistory.CH_ID);

	        if(CommonUtil.checkStringEqualsAndLog(expected_chid,actual_chid,"chat id",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
	        String actual_dept=recent_chat_info.get(ChatHistory.DEPARTMENT);

	        if(CommonUtil.checkStringEqualsAndLog(expected_dept,actual_dept,"department",etest)==false)
	        {
	        	failcount++;
	        }

	        boolean isClosed=ChatWindow.closeRecentChat(driver);

	        if(isClosed)
	        {
	        	result.put("CH42",true);
	        	etest.log(Status.PASS,"Recent chat was closed when close icon was clicked");
	        }
	        else
	        {
	        	result.put("CH42",false);
	        	etest.log(Status.FAIL,"Recent chat was NOT closed when close icon was clicked");
	        	TakeScreenshot.screenshot(driver,etest);
	        }

	        ChatWindow.closeAllChats(driver);
	        Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkRecentChatsToggle(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			quickMultipleChats(driver,visitor_driver_manager,etest,widgetcode,label,1);

 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

	        Hashtable<String,String> visitor_details=getNThChatVisitorInfo(driver,label,2);

	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);

	        ChatWindow.acceptChat(driver,etest);

	        if(ChatWindow.toggleRecentChatsRHSView(driver))
	        {
	        	etest.log(Status.PASS,"Recent chats view was displayed after show recent chats button was clicked in chat window RHS");
	        	result.put("CH37",true);
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Recent chats view was NOT displayed after show recent chats button was clicked in chat window RHS");
	        	result.put("CH37",false);
	        	TakeScreenshot.screenshot(driver,etest);
	        }

	        if(ChatWindow.toggleVisitorInfoRHSView(driver))
	        {
	        	etest.log(Status.PASS,"Visitor info view was displayed after show visitor info button was clicked in chat window RHS");
	        	result.put("CH38",true);
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Visitor info view was NOT displayed after show recent chats button was clicked in chat window RHS");
	        	result.put("CH38",false);
	        	TakeScreenshot.screenshot(driver,etest);
	        }

	        driver.navigate().refresh();
	        ChatWindow.closeAllChats(driver);
	        Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean verifyHistoryChatInfo(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			quickMultipleChats(driver,visitor_driver_manager,etest,widgetcode,label,1);

			Tab.clickChatHistory(driver);
			ChatHistory.openChatByLabel(driver,getNThChatVisitorInfo(driver,label,1).get(ConversationViewConstants.VISITOR_QUESTION));
			String expected_chat_id=ChatHistoryChat.getChatData(driver).get(ChatHistory.CH_ID);

 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

	        Hashtable<String,String> visitor_details=getNThChatVisitorInfo(driver,label,2);

	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);

	        ChatWindow.acceptChat(driver,etest);

	        ChatWindow.clickHistoryInChatTranscriptDropdown(driver,etest);
	        boolean isHighlighted=ChatWindow.openChatFromChatTranscriptHistory(driver,0);

	        if(isHighlighted)
	        {
	        	etest.log(Status.PASS,"Chat selected from history tab was highlighted");
	        	result.put("CH39",true);
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Chat selected from history tab was NOT highlighted");
	        	result.put("CH39",false);
        	}

	        Hashtable<String,String> previous_chat_info=ChatWindow.getHistoryChatData(driver);

	        Hashtable<String,String> expected_previous_chat_info=getNThChatVisitorInfo(driver,label,1);

	        String expected_name=expected_previous_chat_info.get(ConversationViewConstants.VISITOR_NAME);
	        String actual_name=previous_chat_info.get(ChatHistory.VISITOR);

	        if(CommonUtil.checkStringEqualsAndLog(expected_name,actual_name,"name",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_question=expected_previous_chat_info.get(ConversationViewConstants.VISITOR_QUESTION);
	        String actual_question=previous_chat_info.get(ChatHistory.QUESTION);

	        if(CommonUtil.checkStringEqualsAndLog(expected_question,actual_question,"question",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_mail=expected_previous_chat_info.get(ConversationViewConstants.VISITOR_EMAIL);
	        String actual_mail=previous_chat_info.get(ChatHistory.MAIL);

	        if(CommonUtil.checkStringEqualsAndLog(expected_mail,actual_mail,"mail",etest)==false)
	        {
	        	failcount++;
	        }

	        String actual_chid=previous_chat_info.get(ChatHistory.CH_ID);

	        if(CommonUtil.checkStringEqualsAndLog(expected_chat_id,actual_chid,"chat id",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_ph=expected_previous_chat_info.get(ConversationViewConstants.VISITOR_PHONE);
	        String actual_ph=previous_chat_info.get(ChatHistory.VISITOR_PHONE);

	        if(CommonUtil.checkStringEqualsAndLog(expected_ph,actual_ph,"phone number",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_embed_name=ExecuteStatements.getDefaultEmbedName(driver);
	        String actual_embed_name=previous_chat_info.get(ChatHistory.WEBSITE);

	        if(CommonUtil.checkStringEqualsAndLog(expected_embed_name,actual_embed_name,"website name",etest)==false)
	        {
	        	failcount++;
	        }

	        String expected_dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
	        String actual_dept=previous_chat_info.get(ChatHistory.DEPARTMENT);

	        if(CommonUtil.checkStringEqualsAndLog(expected_embed_name,actual_embed_name,"department",etest)==false)
	        {
	        	failcount++;
	        }

	        driver.navigate().refresh();
	        ChatWindow.closeAllChats(driver);

	        Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkHistoryChatTab(WebDriver driver,ExtentTest etest,String widgetcode,boolean isMissChat) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			ChatWindow.closeAllChats(driver);
	        Hashtable<String,String> visitor_details=getNThChatVisitorInfo(driver,label,1);

			ChatType chat_type=isMissChat?ChatType.MISSED:ChatType.COMPLETED;

 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

			quickChat(driver,visitor_driver,etest,widgetcode,label,false,chat_type);

 			visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);
	        ChatWindow.acceptChat(driver,etest);

	        ChatWindow.clickHistoryInChatTranscriptDropdown(driver,etest);
			ChatWindow.openChatFromChatTranscriptHistory(driver,0);

			String expected_name=ChatWindow.getAgentNameChatTranscriptHistory(driver,0);
			String actual_name=isMissChat?ResourceManager.getRealValue("history_tab_transcript_missed"):ExecuteStatements.getUserName(driver);

			if(CommonUtil.checkStringEqualsAndLog(expected_name,actual_name,"agent name",etest)==false)
			{
				failcount++;
			}			
			
			boolean isImageExpected=isMissChat?false:true;

			if(ChatWindow.isAgentImagePresent(driver)==isImageExpected)
			{
				etest.log(Status.PASS,"Agent image was "+(isImageExpected?"found":"NOT found")+" for chat transcript opened from history dropdown");
			}
			else
			{
				etest.log(Status.FAIL,"Agent image was "+(isImageExpected?"NOT found":"found")+" for chat transcript opened from history dropdown");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

	        driver.navigate().refresh();
	        ChatWindow.closeAllChats(driver);

	        Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkHistoryChatTabEmptyState(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
	        Hashtable<String,String> visitor_details=getNThChatVisitorInfo(driver,label,1);

 			WebDriver visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);
	        ChatWindow.acceptChat(driver,etest);

	        ChatWindow.clickHistoryInChatTranscriptDropdown(driver,etest);

	        String expected=ResourceManager.getRealValue("past_chat_empty_state");

	        if(ChatWindow.getCurrentVisibleChat(driver).getText().contains(expected))
	        {
	        	etest.log(Status.PASS,"Text '"+expected+"' was found when no past chats are present");
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Text '"+expected+"' was NOT found when no past chats are present");	  
	        	failcount++;
	        	TakeScreenshot.screenshot(driver,etest);      	
	        }

	        driver.navigate().refresh();
	        ChatWindow.closeAllChats(driver);

	        Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	//middle checks

	public static void checkLoadMoreButtonPresent(WebElement load_more_div,ExtentTest etest)
	{
		if(!CommonUtil.isChecked("CH2",result))
		{
			if(load_more_div!=null)
			{
				etest.log(Status.PASS,"Load more button was found");
				result.put("CH2",true);
			}
			else
			{
				result.put("CH2",false);
				etest.log(Status.FAIL,"Load more button was NOT found");
			}
		}
	}

	public static void checkDeleteChatPopup(WebElement popup,ExtentTest etest)
	{
		if(!CommonUtil.isChecked("CH5",result))
		{
			if(popup!=null)
			{
				etest.log(Status.PASS,"Delete popup was found");
				result.put("CH5",true);
			}
			else
			{
				result.put("CH5",false);
				etest.log(Status.FAIL,"Delete popup was NOT found");
			}
		}
	}

	public static void checkTranslationBanner(WebDriver driver,ExtentTest etest,boolean isTranslated)
	{
		if(  !CommonUtil.isChecked("CH14",result) || !CommonUtil.isChecked("CH15",result) )
		{
			String usecase=isTranslated?"CH14":"CH15";
			String expected_text=isTranslated?ResourceManager.getRealValue("view_original"):ResourceManager.getRealValue("view_translated");
            String actual_text=CommonUtil.getElement(driver,ChatHistoryChat.TRANSLATION_CONTAINER).getText();

            if(CommonUtil.checkStringEqualsAndLog(expected_text,actual_text,"translation banner",etest))
            {
            	result.put(usecase,true);
            }
            else
            {
            	result.put(usecase,false);   
            	TakeScreenshot.screenshot(driver,etest);         	
            }

		}
	}

	public static void checkNoteLengthCharLimit(WebDriver driver,ExtentTest etest)
	{
		if(!CommonUtil.isChecked("CH24",result))
		{
			result.put("CH24",Tab.isBannerFound(driver,etest,ResourceManager.getRealValue("chat_note_char_limit_exceeded"),Tab.FAILURE_BANNER));
		}
	}

	public static void checkMailToLink(WebDriver driver,ExtentTest etest)
	{
		if(!CommonUtil.isChecked("CH36",result))
		{
	        WebElement visitor_info_container=CommonUtil.getElement(driver,ChatHistoryChat.RHS,ChatHistoryChat.RHS_VISITOR_DATA);
	        WebElement anchor_tag=CommonUtil.getElement(visitor_info_container,ChatHistoryChat.RHS_EMAIL,By.tagName("a"));

	        String expected_href="mailto:"+anchor_tag.getText();
	        String actual_href=anchor_tag.getAttribute("href");

	        boolean isMailToLinkFound=HandleCommonUI.verifyAnchorTag(anchor_tag,etest,null,expected_href);

	        result.put("CH36",isMailToLinkFound);

	        if(isMailToLinkFound)
	        {
	        	etest.log(Status.PASS,"Visitor mail was found with 'mailto:' link as expected. Expected :'"+expected_href+"' Actual : '"+actual_href+"'");
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Visitor mail was NOT found with 'mailto:' link as expected. Expected :'"+expected_href+"' Actual : '"+actual_href+"'");
	        	TakeScreenshot.screenshot(driver,etest);
	        }
		}		
	}
	
	public static void checkFilterOptions(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount = 0,cht1failcount = 0,cht3failcount = 0;
		String label=CommonUtil.getUniqueMessage();
		etest=ComplexReportFactory.getTest("initial filter conditions");
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		WebDriver agent_driver = Functions.setUp();
		WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
		
		try
		{
			Functions.login(agent_driver,"chathistory1");

			String url = Util.siteNameout()+"/"+ExecuteStatements.getPortal(driver);

			agent_driver.get(url);
		
			quickChat(driver,visitor_driver,etest,widgetcode,label);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

        ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT10"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		ChatHistory.navigateToChatHistoryTab(driver);
		int noOfChatsBeforeFilter = ChatHistory.getNoOfChats(driver);
		etest.log(Status.INFO,"No of chats brefore filter : "+noOfChatsBeforeFilter);
		

		//checking Associate user access with deleting a chat from chat history
		try
		{
			ChatHistory.navigateToChatHistoryTab(agent_driver);
			etest.log(Status.INFO,"Logged in with associate account");
			if(!isSelectOptionDisplayed(agent_driver))
			{
				etest.log(Status.PASS,"Associate user was restricted from deleting the chats from chat history");
				result.put("CHT10",true);
			}
			else
			{
				etest.log(Status.FAIL,"An Associate user was able to delete a chat from chat history");
				TakeScreenshot.screenshot(agent_driver,etest);
				result.put("CHT10",false);
				failcount++;
			}
		}
		catch(Exception e)
		{	
			TakeScreenshot.screenshot(agent_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

        ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT6"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		//checking hovertext for user image
		try
		{
			result.put("CHT6",ChatHistory.checkAllHoverText(driver,etest));
			ChatHistory.navigateToChatHistoryTab(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT1"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);


		//check filter by operator
		try
		{
			if(ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_OPERATOR,"Associate",ChatHistory.OWNER,etest))
			{
				result.put("CHT1",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT1",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		int noOfChatsAfterFilter = ChatHistory.getNoOfChats(driver);
		etest.log(Status.INFO,"No of chats after filter "+noOfChatsAfterFilter);

		//check filter text present in filter container
		try
		{
			if(CommonUtil.checkStringContainsAndLog(CommonUtil.getElement(driver,ChatHistory.FILTER_CONTAINER).getText(),"Associate","Filter container",etest))
			{
				etest.log(Status.PASS,"The filter selected was displayed in the filter container");
				result.put("CHT7",true);
			}
			else
			{
				etest.log(Status.FAIL,"The filter selected was not displayed in the filter container");
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT7",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest("Check chat count after adding and removing filters");
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		//check chat count by adding and removing filters
		try
		{
			etest.log(Status.INFO,noOfChatsAfterFilter+"~~"+noOfChatsBeforeFilter);
			TakeScreenshot.infoScreenshot(driver,etest);
			if(noOfChatsAfterFilter != noOfChatsBeforeFilter)
			{
				etest.log(Status.PASS,"After adding a filter only the respective chats were shown in the chat history");
			}
			else
			{
				etest.log(Status.FAIL,"After adding a filter all chats were shown in the chat history");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT8"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
		

		//check filter being replaced by other filter in filter container
		try
		{			
			ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_OPERATOR,ExecuteStatements.getUserName(driver),ChatHistory.OWNER,etest);

			if(CommonUtil.checkStringContainsAndLog(CommonUtil.getElement(driver,ChatHistory.FILTER_CONTAINER).getText(),ExecuteStatements.getUserName(driver),"Filter container",etest))
			{
				etest.log(Status.PASS,"The filter in the filter container was replaced by the selected filter from the drop down list");
				result.put("CHT8",true);
			}
			else
			{
				etest.log(Status.FAIL,"The filter in the filter container was not replaced by the selected filter from the drop down list");
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT8",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}


		//check filter icon and filter close icon
		try
		{
			ChatHistory.navigateToChatHistoryTab(driver);
			CommonUtil.clickWebElement(driver,ChatHistory.getFilterBoxElement(driver));
			CommonSikuli.findInWholePage(driver,"UI341.png","UI341",etest);
			CommonSikuli.findInWholePage(driver,"UI342.png","UI342",etest);

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ChatHistory.closeFilter(driver);

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest("Check chat count after adding and removing filters");
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		try
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			noOfChatsAfterFilter = ChatHistory.getNoOfChats(driver);
			etest.log(Status.INFO,noOfChatsAfterFilter+"~~"+noOfChatsBeforeFilter);

			if(noOfChatsAfterFilter == noOfChatsBeforeFilter)
			{
				etest.log(Status.PASS,"After removing the filter all chats were shown in the chat history");
			}
			else
			{
				etest.log(Status.FAIL,"After removing the filter all chats were not shown in the chat history");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}
			if(CommonUtil.returnResult(failcount))
			{
				result.put("CHT9",true);
			}
			else
			{
				result.put("CHT9",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT11"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);


		//filter by status, dept, embed, date
		try
		{
			if(ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_STATUS,"Attended Online",ChatHistory.STATUS,etest))
			{
				result.put("CHT11",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT11",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT12"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		try
		{
			ChatHistory.closeFilter(driver);
			if(ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_DEPT_ID,ExecuteStatements.getSystemGeneratedDepartment(driver),ChatHistory.DEPARTMENT,etest))
			{
				result.put("CHT12",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT12",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT13"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		try
		{
			ChatHistory.closeFilter(driver);
			if(ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_EMBED,ExecuteStatements.getDefaultEmbedName(driver),ChatHistory.EMBED,etest))
			{
				result.put("CHT13",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT13",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}


		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT2"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		try
		{
			ChatHistory.closeFilter(driver);
			if(ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_DATE,"Today",ChatHistory.CHAT_TIME,etest))
			{
				result.put("CHT2",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT2",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}	

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT3"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		//filter by integration status
		try
		{
			ChatHistory.closeFilter(driver);
			for(int option = 2; option <= 5; option++)
			{
				if(!ChatHistory.filterBy(driver,ChatHistory.FILTER_BY_INTEG_STATUS,ChatHistory.getOption(driver,ChatHistory.FILTER_BY_INTEG_STATUS,option),ChatHistory.CRM_TYPE,etest))
				{
					cht3failcount++;
					TakeScreenshot.screenshot(driver,etest);
				}
			}

			result.put("CHT3",CommonUtil.returnResult(cht3failcount));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
		}

		ComplexReportFactory.closeTest(etest);

		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CHT4"));
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		//filter by date range valid and invalid
		try
		{
			ChatHistory.closeFilter(driver);
			if(ChatHistory.filterByDateRange(driver,0,label,etest))
			{
				result.put("CHT4",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT4",false);
			}

			ChatHistory.closeFilter(driver);
			if(ChatHistory.filterByDateRange(driver,1,label,etest))
			{
				result.put("CHT5",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				result.put("CHT5",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			ChatHistory.closeFilter(driver);
		}
		
		ComplexReportFactory.closeTest(etest);

    	Functions.logout(agent_driver);
        
	}
	public static boolean isSelectOptionDisplayed(WebDriver driver)
	{
		try
		{
			if(CommonUtil.getElement(driver,ChatHistory.CHECKBOX_COLUMN).getAttribute("innerHTML").length() == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			return true;
		}
	}

	//Chat Module Live Typing Status Test Case
	public static boolean checkTypingStatus(WebDriver driver,ExtentTest etest,String widgetcode) throws Exception
	{
		int failcount=0;

		String message=null;
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		final int no_of_chars_to_delete=5;

		try
		{
 			visitor_driver=visitor_driver_manager.getDriver(driver);

	        VisitorWindow.createPage(visitor_driver,widgetcode);

	        Hashtable<String,String> visitor_details=getNThChatVisitorInfo(driver,label,1);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);
	        ChatWindow.acceptChat(driver,etest);


	        try
	        {
		        //type message
		        message=CommonUtil.getUniqueId();
		        VisitorWindow.typeMessage(visitor_driver,message);

		        //check
		        boolean isFound=ChatWindow.isLiveTypingStatus(driver,etest,message);
	        	result.put("TYP6",isFound);
	        	TakeScreenshot.infoScreenshot(driver,etest);
	        }
	        catch(Exception e1) 
	        {
	        	TakeScreenshot.screenshot(driver,etest,e1);
	        	TakeScreenshot.screenshot(visitor_driver,etest,e1);
	        }

	        try
	        {
	        	//send message from agent
				ChatWindow.sentMessage(driver,label);
				etest.log(Status.INFO,"Message was sent from agent to visitor after typing status was shown");
		        boolean isNotFound=(!ChatWindow.isLiveTypingStatus(driver,etest,label));
	        	result.put("TYP1",isNotFound);

	        	if(isNotFound)
	        	{
	        		etest.log(Status.PASS,"Typing status was not found after agent sent a message to visitor after typing status was shown");
	        	}
	        	else
	        	{
	        		etest.log(Status.FAIL,"Typing status was found after agent sent a message to visitor after typing status was shown");
	        		TakeScreenshot.screenshot(driver,etest);
	        		TakeScreenshot.screenshot(visitor_driver,etest);
	        	}
	        }
	        catch(Exception e2)
	        {
	        	TakeScreenshot.screenshot(driver,etest,e2);
	        	TakeScreenshot.screenshot(visitor_driver,etest,e2);
	        }

	        try
	        {
		        //type message
		        message=CommonUtil.getUniqueId();
		        VisitorWindow.typeMessage(visitor_driver,message);

		        //check
		        boolean isFound=ChatWindow.isLiveTypingStatus(driver,etest,message);
	        	TakeScreenshot.infoScreenshot(driver,etest);

	        	//send message from agent
				VisitorWindow.sentMessageInTheme(visitor_driver,label);
				etest.log(Status.INFO,"Message was sent from visitor to agent after typing status was shown");
		        boolean isNotFound=(!ChatWindow.isLiveTypingStatus(driver,etest,label));
	        	result.put("TYP2",isNotFound);

	        	if(isNotFound)
	        	{
	        		etest.log(Status.PASS,"Typing status was not found after visitor sent typed message to agent after typing status was shown");
	        	}
	        	else
	        	{
	        		etest.log(Status.FAIL,"Typing status was found after visitor sent typed message to agent after typing status was shown");
	        		TakeScreenshot.screenshot(driver,etest);
	        		TakeScreenshot.screenshot(visitor_driver,etest);
	        	}
	        }
	        catch(Exception e3)
	        {
	        	TakeScreenshot.screenshot(driver,etest,e3);
	        	TakeScreenshot.screenshot(visitor_driver,etest,e3);
	        }

	        try
	        {
		        //type message
		        message=CommonUtil.getUniqueId();
		        VisitorWindow.typeMessage(visitor_driver,message);

	        	//remove chars
	        	VisitorWindow.removeCharsFromTypedMessage(visitor_driver,no_of_chars_to_delete);
	        	etest.log(Status.INFO,no_of_chars_to_delete+" charecters were deleted from visitor message input");

		        String new_message=message.substring(0, message.length()- (no_of_chars_to_delete) );
		        etest.log(Status.INFO,"Now checking if extra chars message are removed");
		        boolean isOldMessageHidden=(!ChatWindow.isLiveTypingStatus(driver,etest,message));

		        etest.log(Status.INFO,"Now checking if expected typed message is found");
		        boolean isNewMessageFound=ChatWindow.isLiveTypingStatus(driver,etest,message);

		        if(isNewMessageFound && isOldMessageHidden)
		        {
		        	etest.log(Status.PASS,"Typed message was updated after visitor removed "+no_of_chars_to_delete+" characters.");
		        	result.put("TYP4",true);
		        }
		        else
		        {
		        	result.put("TYP4",false);
		        	etest.log(Status.FAIL,"Typed message was NOT updated after visitor removed "+no_of_chars_to_delete+" characters.");
		        	TakeScreenshot.screenshot(driver,etest);
		        	TakeScreenshot.screenshot(visitor_driver,etest);
		        }
				VisitorWindow.sentMessageInTheme(visitor_driver,label);
	        }
	        catch(Exception e4)
	        {
	        	TakeScreenshot.screenshot(driver,etest,e4);
	        	TakeScreenshot.screenshot(visitor_driver,etest,e4);
	        }


	        try
	        {
				//type message
		        VisitorWindow.typeMessage(visitor_driver,message);
		        ChatWindow.isLiveTypingStatus(driver,etest,message);
		        //type more chars
		        String new_message=message+label;
				VisitorWindow.sentMessageInTheme(visitor_driver,new_message,false,false);
				boolean isFound=ChatWindow.isLiveTypingStatus(driver,etest,message);

				if(isFound)
				{
					etest.log(Status.PASS,"Expected typing status was found after extra chars were typed by visitor");
		        	result.put("TYP3",true);
				}
				else
				{
		        	result.put("TYP3",false);
					etest.log(Status.FAIL,"Expected typing status was NOT found after extra chars were typed by visitor");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}

				//remove all typed message
		        VisitorWindow.typeMessage(visitor_driver,"");
		        etest.log(Status.INFO,"All typed message was removed. Now checking if typing status is not found in agent side");
				isFound=ChatWindow.isLiveTypingStatus(driver,etest,message);

				if(!isFound)
				{
					etest.log(Status.PASS,"Typing status was not found in agent side after visitor removed all typed text");
		        	result.put("TYP5",true);
				}
				else
				{
		        	result.put("TYP5",false);
					etest.log(Status.FAIL,"Typing status was found in agent side even after visitor removed all typed text");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
	        }
	        catch(Exception e5)
	        {
	        	TakeScreenshot.screenshot(driver,etest,e5);
	        	TakeScreenshot.screenshot(visitor_driver,etest,e5);
	        }

	        ChatWindow.closeAllChats(driver);

	        Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkFilterList(WebDriver driver,ExtentTest etest,String key)
	{
		List<String> toCheckList;
		By filterBy;
		int failcount = 0;
		try
		{
			switch(key)
			{
				case "CHT14" : 
				{
					toCheckList = SettingsTab.getOperatorList(driver);
					toCheckList.addAll(SettingsTab.getBotsList(driver));
					filterBy = ChatHistory.FILTER_BY_OPERATOR;
					break;
				}
				case "CHT15" : 
				{
					toCheckList = Arrays.asList(STATUS_LIST);
					filterBy = ChatHistory.FILTER_BY_STATUS;
					break;
				}
				case "CHT16" : 
				{
					toCheckList = SettingsTab.getDepartmentList(driver);
					filterBy = ChatHistory.FILTER_BY_DEPT_ID;
					break;
				}
				case "CHT17" : 
				{
					toCheckList = SettingsTab.getEmbedList(driver);
					filterBy = ChatHistory.FILTER_BY_EMBED;
					break;
				}
				case "CHT18" : 
				{
					CommonUtil.refreshPage(driver);
					toCheckList = Arrays.asList(DATE_LIST);
					filterBy = ChatHistory.FILTER_BY_DATE;
					break;
				}
				case "CHT19" : 
				{
					toCheckList = Arrays.asList(INTEGRATION_STATUS_LIST);
					filterBy = ChatHistory.FILTER_BY_INTEG_STATUS;
					break;
				}
				default :
				{
					result.put(key,false);
					return;
				}
			}

			ChatHistory.navigateToChatHistoryTab(driver);
			CommonUtil.clickWebElement(driver,ChatHistory.getFilterBoxElement(driver));
			CommonUtil.clickWebElement(driver,ChatHistory.getFilter(driver,filterBy));
			// String filterElement = ChatHistory.getFilter(driver,filterBy);
			String actualTextInFilter = "";
			List<WebElement> filterListElements = ChatHistory.getFilter(driver,filterBy).findElements(By.tagName("option"));

			for(WebElement filterElement : filterListElements)
			{
				actualTextInFilter += filterElement.getAttribute("innerText") + "\n";
			}
			String expectedTextInFilter = "All";
			etest.log(Status.INFO,"<pre><b>Actual Text In Filter</b> <br><br>"+actualTextInFilter+"</pre>");

			for(String toCheck : toCheckList)
			{
				if(!CommonUtil.checkStringContainsAndLog(toCheck,actualTextInFilter,"filter text",null))
				{
					etest.log(Status.FAIL,"Expected filter text  <b style=\"color:red;\">"+toCheck+"</b> is not found in the list");
					failcount++;
				}
				expectedTextInFilter +=  "\n" + toCheck;
			}

			etest.log(Status.INFO,"<pre><b>Expected Text In Filter</b> <br><br>"+expectedTextInFilter+"</pre>");
			etest.log(Status.INFO,"Expected List Size -- "+(toCheckList.size()+1)+"<br>Actual List Size -- "+filterListElements.size());
			if(filterListElements.size() != (toCheckList.size()+1))
			{
				etest.log(Status.FAIL,"Mismatch size in lists");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			if(failcount == 0)
			{
				etest.log(Status.PASS,"Expected data found in filter list");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			failcount++;
		}
		result.put(key,CommonUtil.returnResult(failcount));
	}
}
