//$Id$
package com.zoho.livedesk.client.VisitorTrackingInLangChange;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.VisitorsOnline;

public class VisitorTrackinginLangChange {

	public static Hashtable finalResult = new Hashtable();

	 public static Hashtable < String, Boolean > result = null;
	 public static ExtentTest etest;
	 static public ExtentReports extent;
     public static  WebDriver visitor_driver;
	 public static String moduleName = "VisTracking at Lang Change";
	 public static String widgetCode = "", websiteName = "";

	
	 public static VisitorDriverManager visitor_driver_manager;
	 
public static Hashtable test(WebDriver driver) 
{
	  try {	
		  
	   visitor_driver_manager = new VisitorDriverManager();
	   result = new Hashtable < String, Boolean > ();
	   websiteName = ExecuteStatements.getDefaultEmbedName(driver);
	   widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver, websiteName);

	   
	   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("LANGTRACKINGRINGS1"));
	   ComplexReportFactory.setValues(etest, "Automation", moduleName);
	   result.put("LANGTRACKINGRINGS1",checkLangInChatWin(driver, etest, widgetCode));
	   ComplexReportFactory.closeTest(etest);
	   
	   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("LANGTRACKINGRINGS2"));
	   ComplexReportFactory.setValues(etest, "Automation", moduleName);
	   result.put("LANGTRACKINGRINGS2",checkVisitorTrackingForLangChnage(driver, etest, widgetCode));
	   ComplexReportFactory.closeTest(etest);
	    	   
	   visitor_driver_manager.terminateAllDriverSessions();	   
	  }
	  catch (Exception e) 
	  {		  
	   etest.log(Status.FATAL, "Module breakage occurred " + e);
	   TakeScreenshot.log(e, etest);
	  }
	return finalResult; 
	   
}  
	


public static boolean checkLangInChatWin(WebDriver driver, ExtentTest etest,String widgetCode) throws Exception {
	try {
     visitor_driver = visitor_driver_manager.getDriver(driver);
	VisitorWindow.createPage(visitor_driver, widgetCode);	
	if(!checkwidgetLanguage(visitor_driver, etest)) {
		etest.log(Status.FAIL, "Float Widget Language not Changed ");
		TakeScreenshot.screenshot(visitor_driver, "Float Widget -Language Change", "Visitor Window", "not Changed");
		return false;
	}
	etest.log(Status.PASS, "Float Widget Language is Changed ");
	TakeScreenshot.infoScreenshot(visitor_driver, etest);
	return true;
	}
catch(Exception e) {
	TakeScreenshot.screenshot(visitor_driver, etest, "Float Widget - Language Change", "Visitor Window", "not Changed", e);
	TakeScreenshot.screenshot(driver, etest, "Float Widget - Language Change", "Visitor Window", "not Changed", e);
}
	return false;
}

public static boolean checkVisitorTrackingForLangChnage(WebDriver driver, ExtentTest etest,String widgetCode) throws Exception {
	try {		
		visitor_driver = visitor_driver_manager.getDriver(driver);
		VisitorWindow.createPage(visitor_driver, widgetCode);
		
		String portalName =ExecuteStatements.getPortal(driver);
		String visitor_id = VisitorWindow.getVisitorId(visitor_driver, portalName);	
		
		if(!checkVisTracking(driver, visitor_id, etest)) {
			etest.log(Status.FAIL, "Visitor not tracked in Rings");
			TakeScreenshot.screenshot(driver, "Visitor Tracking -Language Change", "Visitor Tracking", "not Tracked");
			return false;
		}
		etest.log(Status.PASS, "Visitor tracked in Rings");
		TakeScreenshot.infoScreenshot(driver, etest);	
		return true;
			
	}
catch(Exception e) {
	TakeScreenshot.screenshot(driver, etest, "Visitor Tracking - Language Chnage", "Visitor Tracking in Rings", "not Tracked", e);
}
	return false;
}


public static boolean checkVisTracking(WebDriver driver, String id,ExtentTest etest) throws Exception {

try {
    Tab.clickVisitorsOnline(driver);
    CommonUtil.refreshPage(driver);
    CommonWait.waitTillDisplayed(driver, By.id("ldsales"));
 
    if(!CommonWait.waitTillDisplayed(driver, By.id(id))) {
    	etest.log(Status.INFO, "Visitor Id Not Found");
    	TakeScreenshot.infoScreenshot(driver, etest);
    	return false;
    }
    etest.log(Status.INFO, "Visitor Id Found");
    TakeScreenshot.infoScreenshot(driver, etest);
    WebElement e = CommonUtil.elfinder(driver,"id",id);    
    VisitorsOnline.clickVisitor(e);  
    
    return true;
}
catch(Exception e) {
	
}
return false;
}


public static boolean checkwidgetLanguage(WebDriver driver ,ExtentTest etest) {
	
	if(CommonWait.waitTillDisplayed(driver, By.id("zsiq_float"))) {
			
	etest.log(Status.INFO, "Float Widget Found in Visitor Window");
	TakeScreenshot.infoScreenshot(driver, etest);
	
	WebElement titleActual =CommonUtil.getElement(driver, By.id("zsiq_maintitle"));
	String titleActualText = titleActual.getText();		
	String titleExpectedText = "We're Online!";
	
	if(CommonUtil.isEquals(titleExpectedText, titleActualText)){
		etest.log(Status.FAIL,"Title Text of Chat Wigdet is not changed");
		TakeScreenshot.screenshot(driver, "Float Widget-Title Text", "Language Change", "not Changed");
        return false;
	}
	etest.log(Status.INFO,"Title Text of Chat Wigdet is changed");
    TakeScreenshot.infoScreenshot(driver, etest);

	WebElement byLineActual =CommonUtil.getElement(driver, By.id("zsiq_byline"));
	String byLineActualText = byLineActual.getText();
	String byLineExpectedText = "How may I help you today?";
	
	if(CommonUtil.isEquals(byLineExpectedText, byLineActualText)) {
		 etest.log(Status.FAIL, "ByLine Text of Chat Wigdet is not changed");
			TakeScreenshot.screenshot(driver, "Float Widget-ByLIne Text", "Language Change", "not Changed");
	        return false;	
	}
	  etest.log(Status.INFO, "ByLine Text of Chat Wigdet is changed");
      TakeScreenshot.infoScreenshot(driver, etest);
			
	return true;
	}
    else
    {
		etest.log(Status.FAIL, "Float Widget not Found");
		TakeScreenshot.screenshot(driver, "Float Widget", "Widget", "not Found");
		return false;
	}        
}

	
}
