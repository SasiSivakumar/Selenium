//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;

public class BotsMisc
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots Misc";
	public static String widgetcode="",websitename="";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		//cleanup for this module is-->delete all bots,delete all depts

		try
		{
			visitor_driver_manager = new VisitorDriverManager(true);

            result = new Hashtable<String,Boolean>();

            websitename=ExecuteStatements.getDefaultEmbedName(driver);
            widgetcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,websitename);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Check bot impacted areas in product");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotImpactedInProduct(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Check modify and delete bot mapped department");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkModifyAndDeleteBotDepartment(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Check bot stats");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotStats(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void checkBotImpactedInProduct(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String website=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);
			String feedback="FB"+unique;
			String rating="3";
			
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable("Bot"+unique,"BOT1_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website,dept,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);

			String bot_name=bot_info.get(BotInfo.NAME);

			etest.log(Status.INFO,"Now checking usecase : "+KeyManager.getRealValue("BOTS105"));
			result.put("BOTS105",WMSBar.isOperatorFoundInWMSBar(driver,etest,bot_name,false));

			etest.log(Status.INFO,"Now checking usecase : "+KeyManager.getRealValue("BOTS106"));
			result.put("BOTS106",ChatMonitor.isOperatorFoundInChatMonitor(driver,etest,bot_name,false));

			etest.log(Status.INFO,"Now checking usecase : "+KeyManager.getRealValue("BOTS107"));
			result.put("BOTS107",Department.isOperatorFoundInAddDepartment(driver,etest,bot_name,false));

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot_name);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			String code=BotScripts.getBotMessageDuplicatorCode();
			DelugeScript.sendKeysToScript(driver,code);
			DelugeScript.clickPublish(driver);
			DelugeScript.close(driver);

			ArrayList<String> visitor_messages=new ArrayList<String>();
			ArrayList<String> bot_messages=new ArrayList<String>();

			for(int i=0;i<5;i++)
			{
				String message="M"+i+unique;
				visitor_messages.add(message);
				bot_messages.add("BOT"+message);
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			String visitor_name="V"+unique;
			VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,"V"+unique+"@emailed.com",null,dept,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			for(String visitor_message : visitor_messages)
			{
				BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
				VisitorWindow.sentMessageInTheme(visitor_driver,visitor_message,true);
				BotsVisitorSide.waitTillBotReplies(visitor_driver);
			}

			VisitorWindow.switchToChatWidget(visitor_driver);
			String conversation_id=ConversationViewCommonFunctions.getChatIdOfCurrentChat(visitor_driver,ChatType.ONGOING);

        	VisitorWindow.endChatVisitor(visitor_driver);
        	VisitorWindow.enterFeedbackInTheme(visitor_driver,feedback,rating);

        	VisitorWindow.clickCloseChatWidget(visitor_driver);

        	etest.log(Status.INFO,"Visitor messages->"+visitor_messages.toString());
        	etest.log(Status.INFO,"Agent messages->"+bot_messages.toString());

			Tab.clickChatHistory(driver);

			ChatHistory.openChatByLabel(driver,visitor_name);

			String agent_name=ChatHistoryChat.getAgentName(driver);

	        Hashtable<String,ArrayList<String>> categorised_messages=ChatHistoryChat.getMessages(driver);

	        categorised_messages.get(ChatHistoryChat.AGENT_MESSAGE_LIST).remove(0);//removing bot response to question.

			Hashtable<String,String> chat_data=ChatHistoryChat.getChatData(driver);

        	etest.log(Status.INFO,"Actual Visitor messages->"+categorised_messages.get(ChatHistoryChat.VISITOR_MESSAGE_LIST).toString());
        	etest.log(Status.INFO,"Actual Agent messages->"+categorised_messages.get(ChatHistoryChat.AGENT_MESSAGE_LIST).toString());
        	etest.log(Status.INFO,"Chat data->"+chat_data.toString());

        	int failcount=0;

        	if(HandleCommonUI.checkMessages(visitor_messages,categorised_messages.get(ChatHistoryChat.VISITOR_MESSAGE_LIST),"visitor messages",etest)==false)
        	{
        		TakeScreenshot.screenshot(driver,etest);
        		failcount++;
        	}

        	if(HandleCommonUI.checkMessages(bot_messages,categorised_messages.get(ChatHistoryChat.AGENT_MESSAGE_LIST),"agent messages",etest)==false)
        	{
        		TakeScreenshot.screenshot(driver,etest);
        		failcount++;
        	}

        	if(CommonUtil.checkStringContainsAndLog(bot_name,agent_name,"operator name for bot chat in chat history",etest)==false)
        	{
        		failcount++;
        	}
	        CommonSikuli.findInWholePage(driver,"UI429.png","UI429",etest);

	        result.put("BOTS109",CommonUtil.returnResult(failcount));

	        //feedback
			Tab.clickVisitorsOnline(driver);
			Tab.clickFeedback(driver);

			agent_name=Feedback.getOperatorNameFromFeedbackContainer( Feedback.getFeedbackByUniqueName(driver,visitor_name) );
	        CommonSikuli.findInWholePage(driver,"UI430.png","UI430",etest);
    		result.put("BOTS110",CommonUtil.checkStringContainsAndLog(bot_name,agent_name,"operator name for bot chat in feedback history",etest));

	        //conversation history
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.clickChatButton(visitor_driver);
			ConversationViewCommonFunctions.goToAllChats(visitor_driver);
			ConversationViewCommonFunctions.openChatByUniqueId(visitor_driver,ChatType.COMPLETED,conversation_id);
	        CommonSikuli.findInWholePage(visitor_driver,"UI431.png","UI431",etest);
			if(ConversationViewCommonFunctions.checkAgentName(visitor_driver,etest,bot_name))
			{
				result.put("BOTS108",true);
			}
			else
			{
				result.put("BOTS108",false);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkModifyAndDeleteBotDepartment(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String dept="D"+unique;
			String website=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);

			Department.addDept(driver,dept,"depttype_publi",ExecuteStatements.getUserName(driver),etest);

			CommonUtil.refreshPage(driver);

			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable("Bot"+unique,"BOT1_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website,dept,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);

			String bot_name=bot_info.get(BotInfo.NAME);

			String old_dept=dept;
			String new_dept="NEW_D_"+CommonUtil.getUniqueMessage();

			Department.renameDepartment(driver,etest,old_dept,new_dept);

			dept=new_dept;

			driver.navigate().refresh();//changes only on refresh
			etest.log(Status.INFO,"Browser was refreshed");

			String departments=BotInfo.getBotConfig(driver,etest,bot_name).get(BotInfo.DEPARTMENTS);

			result.put("BOTS111",CommonUtil.checkStringContainsAndLog(new_dept,departments,"department in list of bot departments",etest));

			Department.deleteDepartment(driver,dept,ExecuteStatements.getSystemGeneratedDepartment(driver),etest);
			etest.log(Status.INFO,"Department '"+dept+"' was deleted");
			Tab.navToDeptTab(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			CommonUtil.refreshPage(driver);

			Tab.navToBotsTab(driver);

			// String published_status=BotInfo.getBotPublishedStatus( BotsTab.getListedBotElement(driver,bot_name) );
			// result.put("BOTS112",CommonUtil.checkStringContainsAndLog(ResourceManager.getRealValue("bot_yet_to_publish"),published_status,"published status after bot was disabled",etest));

			String corrupt_bot_tooltip=ResourceManager.getRealValue("corrupt_bot_tooltip");

			Tab.navToBotsTab(driver);

			result.put("BOTS113",HandleCommonUI.verifyTooltip(driver,etest, BotsTab.getListedBotElement(driver,bot_name) , BotsTab.FAILED_TOOLTOP_TRIGGER , HandleCommonUI.TOOLTIP , corrupt_bot_tooltip));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkBotStats(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String website=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);
			String bot_name="Bot"+unique;

			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(bot_name,"BOT1_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website,dept,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);

			int transferred_count=1;
			int no_of_chats=2;
			String transfered_percentage="50%";


			//chat1->chat with bot and end chat
			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,dept,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"Hello",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			VisitorWindow.endChatVisitor(visitor_driver);
			ChatWindow.closeAllChats(driver);
			etest.log(Status.INFO,"Chat 1 was connected to human and then ended from visitor side");


			//chat2->chat with bot, connect to humn and end chat
			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,dept,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"Hello",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.setConnectToHuman(visitor_driver,etest,true);
			ChatWindow.handleBotTransfer(driver,true);
			ChatWindow.endAndCloseChat(driver);
			ChatWindow.closeAllChats(driver);


			etest.log(Status.INFO,"Chat 2 was connected to human and then ended and closed from agent side");
			TakeScreenshot.infoScreenshot(driver,etest);

			driver.navigate().refresh();

			Hashtable<String,String> actual_bot_info=BotInfo.getBotConfig(driver,etest,bot_name);

			etest.log(Status.INFO,"Actual Bot info --> "+actual_bot_info.toString());

			result.put("BOTS120",CommonUtil.checkStringContainsAndLog(actual_bot_info.get(BotInfo.CONVERSED),""+no_of_chats,"No of chats with bot",etest));

			result.put("BOTS122",CommonUtil.checkStringContainsAndLog(actual_bot_info.get(BotInfo.TRANSFERED_PERCENTAGE),""+transfered_percentage,"Percentage of chats transfered from bot to human",etest));

			result.put("BOTS123",CommonUtil.checkStringContainsAndLog(actual_bot_info.get(BotInfo.TRANSFERED_COUNT),""+transferred_count,"Number of chats transfered from bot to human",etest));

			if(actual_bot_info.get(BotInfo.HOURS_WORKED).contains("-")==false && actual_bot_info.get(BotInfo.HOURS_WORKED).length()>3)
			{
				etest.log(Status.PASS,"No of hours worked was found as -->"+actual_bot_info.get(BotInfo.HOURS_WORKED));
				result.put("BOTS124",true);
			}
			else
			{
				etest.log(Status.FAIL,"No of hours worked was found as -->"+actual_bot_info.get(BotInfo.HOURS_WORKED));
				TakeScreenshot.screenshot(driver,etest);				
				result.put("BOTS124",false);
			}

			if(actual_bot_info.get(BotInfo.LAST_USED).contains("-")==false && actual_bot_info.get(BotInfo.LAST_USED).length()>3)
			{
				etest.log(Status.PASS,"Last Used was found as -->"+actual_bot_info.get(BotInfo.LAST_USED));
				result.put("BOTS121",true);
			}
			else
			{
				etest.log(Status.FAIL,"Last Used was found as -->"+actual_bot_info.get(BotInfo.LAST_USED));
				TakeScreenshot.screenshot(driver,etest);				
				result.put("BOTS121",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

}
