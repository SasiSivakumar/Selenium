//$Id$
package com.zoho.livedesk.client.bots;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.DistributedTest;

public class BotTests implements DistributedTest
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

    public static VisitorDriverManager visitor_driver_manager;

    public void startThread(int thread_number) throws Exception
    {
        //to do seperate the test accordingly
        WebDriver driver = Driver.getLinuxDriver();

        if(thread_number==0)
        {         
	        Functions.login(driver,"bots1_admin");

            try
            {
                Hashtable module_hashtable=BotsBasic.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            closeBotUIIfOpen(driver);

            try
            {
                Hashtable module_hashtable=BotsCRUD.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            closeBotUIIfOpen(driver);

            try
            {
                Hashtable module_hashtable=BotsMisc.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            closeBotUIIfOpen(driver);

            try
            {                 
                Hashtable module_hashtable=BotPublish.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        if(thread_number==1)
        {           
            Functions.login(driver,"bots2");                    
            Hashtable module_hashtable=BotsConfig.test(driver);
            result.putAll((Hashtable) module_hashtable.get("result"));
            servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
        }

        if(thread_number==2)
        {
            Functions.login(driver,"bots3");

            try
            {
                Hashtable module_hashtable=BotsWidgets.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            closeBotUIIfOpen(driver);

            try
            {
                Hashtable module_hashtable=DelugeBasic.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        if(thread_number==3)
        {
            Functions.login(driver,"dialogflow1");
            Hashtable module_hashtable=DialogflowBotsWidgets.test(driver);
            result.putAll((Hashtable) module_hashtable.get("result"));
            servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
        }

        if(thread_number==4)
        {
            Functions.login(driver,"zia");
            Hashtable module_hashtable=ZiaTests.test(driver);
            result.putAll((Hashtable) module_hashtable.get("result"));
            servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
        }

        if(thread_number==5)
        {
            BotsWebhooks.startTunnel();

            Functions.login(driver,"webhook");

            Hashtable module_hashtable1=BotsWebhooks.test(driver);
            result.putAll((Hashtable) module_hashtable1.get("result"));
            servicedown.putAll((Hashtable) module_hashtable1.get("servicedown"));

            closeBotUIIfOpen(driver);

            Hashtable module_hashtable2=BotsVendorWebhook.test(driver);
            result.putAll((Hashtable) module_hashtable2.get("result"));
            servicedown.putAll((Hashtable) module_hashtable2.get("servicedown"));
        }

        if(thread_number==6)
        {
            Functions.login(driver,"watson");
            Hashtable module_hashtable=WatsonBot.test(driver);
            result.putAll((Hashtable) module_hashtable.get("result"));
            servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
        }

        Functions.logout(driver);   
    }

	public static Hashtable usecase() throws Exception
	{ 
        visitor_driver_manager=new VisitorDriverManager(true);

        BotTests usecases = new BotTests();
        Distributor distributor = new Distributor(usecases,7);
        distributor.initiate();

        visitor_driver_manager.terminateAllDriverSessions();

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

    public static void closeBotUIIfOpen(WebDriver driver)
    {
        try
        {
            try
            {
                com.zoho.livedesk.util.common.actions.bots.DelugeScript.close(driver);
            }
            catch(Exception e1)
            {
                CommonUtil.printStackTrace(e1);
                CommonUtil.goToSalesIQURL(driver);
            }
        }
        catch(Exception e)
        {
            
        }
    }
}
