//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;

public class BotsCRUD
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots CRUD";
	public static String widgetcode="",website="";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		//cleanup for this module is-->delete all bots,delete all depts

		try
		{
			visitor_driver_manager = new VisitorDriverManager(true);

            result = new Hashtable<String,Boolean>();

            website=ExecuteStatements.getDefaultEmbedName(driver);
            widgetcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

            
            
            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS13"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createBotAndPublish(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS17"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS17",toggleBot(driver,etest,widgetcode,true));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS16"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS16",toggleBot(driver,etest,widgetcode,false));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Delete bot,Check in bots tab and visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteBot(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Edit bot name and description");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			editNameAndDesc(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Edit bot website");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			editWebsite(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Edit bot department");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			editDepartment(driver,etest,widgetcode);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			DelugeScript.close(driver);
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void createBotAndPublish(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(driver,unique);
			result.put("BOTS12",BotConfiguration.createBot(driver,etest,bot_info));
			result.put("BOTS13",BotInfo.isBotValuesFound(driver,etest,bot_info));

			//check yet to be published
			checkPublishStatusForCreatedBot(driver,etest,bot_info.get(BotInfo.NAME));

			//pubilsh
			BotsTab.openBotConfiguration(driver,bot_info.get(BotInfo.NAME));
			BotConfiguration.clickOpenSalesIQScript(driver);
			DelugeScript.clickPublish(driver);
			DelugeScript.close(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,unique,ChatType.INITIATED);

			if(BotsVisitorSide.isBotChat(visitor_driver))
			{
				etest.log(Status.PASS,"Bot picked up the chat after it was published");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS15",true);
			}
			else
			{
				etest.log(Status.FAIL,"Bot did NOT pick up the chat after it was published");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS15",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			DelugeScript.close(driver);
		}
	}

	//toggle
	public static boolean toggleBot(WebDriver driver,ExtentTest etest,String widget_code,boolean isEnable)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(driver,unique);
			BotConfiguration.createBot(driver,etest,bot_info);

			//pubilsh
			BotsTab.openBotConfiguration(driver,bot_info.get(BotInfo.NAME));
			BotConfiguration.clickOpenSalesIQScript(driver);
			DelugeScript.clickPublish(driver);
			DelugeScript.close(driver);

			BotsTab.toggleBot(driver,etest,bot_info.get(BotInfo.NAME),isEnable);

			//configure website
			String embed=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);

			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,unique,ChatType.INITIATED);

			if(BotsVisitorSide.isBotChat(visitor_driver)==isEnable)
			{
				etest.log(Status.PASS,"Bot "+(isEnable?"":"did NOT")+" picked up the chat after it was "+(isEnable?"enabled":"disabled"));
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Bot "+(isEnable?"did NOT":"")+" picked up the chat after it was "+(isEnable?"enabled":"disabled"));
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			DelugeScript.close(driver);
		}

		return CommonUtil.returnResult(failcount);
	}

	//delete
	public static void deleteBot(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(unique,unique,BotInfo.CREATE_AND_PUBLISH,null,null,ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code),ExecuteStatements.getSystemGeneratedDepartment(driver),null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
			String bot_name=bot_info.get(BotInfo.NAME);

			//creating another bot and publishing it, so that Invoke Bot option will be shown in triggers to check BOT19 usecase
			Hashtable<String,String> dummy_bot_info=BotInfo.getBotInfoHashtable(CommonUtil.getUniqueMessage(),CommonUtil.getUniqueMessage(),BotInfo.CREATE_AND_PUBLISH,null,null,ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code),ExecuteStatements.getSystemGeneratedDepartment(driver),null,null);
			BotConfiguration.createBot(driver,etest,dummy_bot_info);
			
			//configure website
			String embed=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);

			//delete
			BotsTab.deleteBot(driver,etest,bot_name);

			result.put("BOTS18", (!BotsTab.isBotPresent(driver,bot_name)) );

			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,unique,ChatType.INITIATED);

			if(BotsVisitorSide.isBotChat(visitor_driver,bot_name)==false)
			{
				etest.log(Status.PASS,"Deleted bot '"+bot_name+"' did not pick up visitor chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS20",true);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted bot '"+bot_name+"' picked up visitor chat");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS20",false);
			}

			//Depracated usecase for new flow
			// if(Trigger.isBotPresentUnderInvokeBot(driver,etest,bot_name))
			// {
			// 	etest.log(Status.FAIL,"Deleted bot '"+bot_name+"' was found under invoke bot");
			// 	result.put("BOTS19",false);
			// 	TakeScreenshot.screenshot(driver,etest);
			// 	TakeScreenshot.screenshot(visitor_driver,etest);
			// }
			// else
			// {
			// 	etest.log(Status.PASS,"Deleted bot '"+bot_name+"' was NOT found under invoke bot");
			// 	result.put("BOTS19",true);
			// 	TakeScreenshot.infoScreenshot(driver,etest);
			// 	TakeScreenshot.infoScreenshot(visitor_driver,etest);
			// }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			DelugeScript.close(driver);
		}
	}

	//edit name
	public static void editNameAndDesc(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			//create bot
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(unique,unique,BotInfo.CREATE_AND_PUBLISH,null,null,ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code),ExecuteStatements.getSystemGeneratedDepartment(driver),null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
			String bot_name=bot_info.get(BotInfo.NAME);

			//edit name and desc
	        Tab.navToBotsTab(driver);

	        CommonSikuli.findInWholePage(driver,"UI432.png","UI432",etest);

	        BotsTab.openBotConfiguration(driver,bot_name);

		    CommonUtil.scrollIntoView(driver,true,BotConfiguration.SALESIQ_SCRIPT);
		    CommonUtil.scrollToBottomOfPage(driver);
	        CommonSikuli.findInWholePage(driver,"UI438.png","UI438",etest);
	        CommonUtil.scrollToTop(driver);

			String new_bot_name="BOT"+CommonUtil.getUniqueMessage();
			String new_bot_desc="DESC"+CommonUtil.getUniqueMessage();

	        BotConfiguration.editBotName(driver,new_bot_name);
	        BotConfiguration.editBotDescription(driver,new_bot_desc);
	        BotConfiguration.clickSave(driver);

	        etest.log(Status.INFO,"Bot name was changed from '"+bot_name+"' to '"+new_bot_name+"'.");
	        etest.log(Status.INFO,"Bot description was changed from '"+bot_info.get(BotInfo.DESCRIPTION)+"' to '"+new_bot_desc+"'.");
	        TakeScreenshot.infoScreenshot(driver,etest);

			//configure website
			String embed=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);

			Hashtable<String,String> actual_bot_config=BotInfo.getBotConfig(driver,etest,new_bot_name);

			result.put("BOTS21",CommonUtil.checkStringContainsAndLog(new_bot_name,actual_bot_config.get(BotInfo.NAME),"updated bot name",etest));
			result.put("BOTS23",CommonUtil.checkStringContainsAndLog(new_bot_desc,actual_bot_config.get(BotInfo.DESCRIPTION),"updated bot description",etest));

			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,unique,ChatType.INITIATED);

			if(BotsVisitorSide.isBotChat(visitor_driver,new_bot_name))
			{
				etest.log(Status.PASS,"bot '"+new_bot_name+"' did picked up visitor chat and name was updated");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS22",true);
			}
			else
			{
				etest.log(Status.FAIL,"bot with name '"+new_bot_name+"' did NOT pick up visitor chat,new name was NOT updated");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS22",false);
			}

			result.put("BOTS24",CommonUtil.checkStringContainsAndLog(new_bot_desc,BotsVisitorSide.getBotDesc(visitor_driver),"updated bot description in visitor side",etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			DelugeScript.close(driver);
		}
	}

	//edit website
	public static void editWebsite(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String old_website=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);
			String new_website=ExecuteStatements.getRandomWebsiteName(driver);
			String old_widget_code=widget_code;
			String new_widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,new_website);

			//create bot
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(unique,unique,BotInfo.CREATE_AND_PUBLISH,null,null,old_website,ExecuteStatements.getSystemGeneratedDepartment(driver),null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
			String bot_name=bot_info.get(BotInfo.NAME);

			//edit website
	        Tab.navToBotsTab(driver);
	        BotsTab.openBotConfiguration(driver,bot_name);
	        BotConfiguration.selectWebsite(driver,new_website);
	        BotConfiguration.clickSave(driver);

	        etest.log(Status.INFO,"Bot website was changed from '"+old_website+"' to '"+new_website+"'.");
	        TakeScreenshot.infoScreenshot(driver,etest);

			// //configure for both website website
			// Websites.setBotConfigForWebsite(driver,etest,old_website,BotsVisitorSide.BOT_ANSWERS_ALL);
			// Websites.setBotConfigForWebsite(driver,etest,new_website,BotsVisitorSide.BOT_ANSWERS_ALL);

			//check not pick for old site
			visitor_driver=visitor_driver_manager.getDriver(driver);	
			VisitorWindow.setupChat(driver,visitor_driver,etest,old_widget_code,unique,ChatType.INITIATED);
			if(BotsVisitorSide.isBotChat(visitor_driver,bot_name)==false)
			{
				etest.log(Status.PASS,"bot '"+bot_name+"' did NOT picked up visitor chat for website which was removed from the bot configuration (website:'"+old_website+"')");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS25",true);
			}
			else
			{
				etest.log(Status.FAIL,"bot '"+bot_name+"' did picked up visitor chat for website which was removed from the bot configuration (website:'"+old_website+"')");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS25",false);
			}

			//check pickup for new site
			visitor_driver=visitor_driver_manager.getDriver(driver);	
			VisitorWindow.setupChat(driver,visitor_driver,etest,new_widget_code,unique,ChatType.INITIATED);
			if(BotsVisitorSide.isBotChat(visitor_driver,bot_name))
			{
				etest.log(Status.PASS,"bot '"+bot_name+"' did picked up visitor chat for website which was modified in the bot configuration (website:'"+new_website+"')");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS26",true);
			}
			else
			{
				etest.log(Status.FAIL,"bot '"+bot_name+"' did NOT picked up visitor chat for website which was modified in the bot configuration (website:'"+new_website+"')");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS26",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			DelugeScript.close(driver);
		}
	}

	//edit dept
	public static void editDepartment(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{


			String old_dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String new_dept="D"+unique;

			//create new dept
			Department.addDept(driver,new_dept,"depttype_publi",ExecuteStatements.getUserName(driver),etest);
			etest.log(Status.PASS,"Department '"+new_dept+"' was added");

			CommonUtil.refreshPage(driver);

			//create bot
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(unique,unique,BotInfo.CREATE_AND_PUBLISH,null,null,ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code),old_dept,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
			String bot_name=bot_info.get(BotInfo.NAME);

			//edit dept
	        Tab.navToBotsTab(driver);
	        BotsTab.openBotConfiguration(driver,bot_name);
	        BotConfiguration.selectDepartment(driver,new_dept);
	        BotConfiguration.clickSave(driver);

	        etest.log(Status.INFO,"Bot department was changed from '"+old_dept+"' to '"+new_dept+"'.");
	        TakeScreenshot.infoScreenshot(driver,etest);

			//check not pick for old dept
			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.createPage(visitor_driver,widget_code);

			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,old_dept,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,bot_name)==false)
			{
				etest.log(Status.PASS,"bot '"+bot_name+"' did NOT picked up visitor chat for department which was removed from the bot configuration (department:'"+old_dept+"')");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS27",true);
			}
			else
			{
				etest.log(Status.FAIL,"bot '"+bot_name+"' did picked up visitor chat for department which was removed from the bot configuration (department:'"+old_dept+"')");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS27",false);
			}

			//check pickup for new dept
			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.createPage(visitor_driver,widget_code);

			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,new_dept,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,bot_name))
			{
				etest.log(Status.PASS,"bot '"+bot_name+"' did picked up visitor chat for department which was modified in the bot configuration (department:'"+old_dept+"')");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("BOTS28",true);
			}
			else
			{
				etest.log(Status.FAIL,"bot '"+bot_name+"' did NOT picked up visitor chat for department which was modified in the bot configuration (department:'"+old_dept+"')");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				result.put("BOTS28",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			DelugeScript.close(driver);
		}
	}

	//cases executed along with other flow
	public static void checkPublishStatusForCreatedBot(WebDriver driver,ExtentTest etest,String bot_name)
	{
		String actual_publish_status=BotInfo.getBotConfig(driver,etest,bot_name).get(BotInfo.PUBLISH_STATUS);
		String expected_publish_status=ResourceManager.getRealValue("bot_yet_to_publish");
		result.put("BOTS29",CommonUtil.checkStringContainsAndLog(expected_publish_status,actual_publish_status,"publish status for bot '"+bot_name+"'",etest));
	}


	public static void checkBotPreviewLoaded(WebDriver driver,ExtentTest etest)
	{
        if(CommonUtil.isChecked("BOTS14",result)==false)
        {
        	if(DelugeScript.isBotPreviewChatInputDisplayed(driver))
        	{
	        	result.put("BOTS14",true);
				etest.log(Status.PASS,"Bots preview input was shown after create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS14",false);
				etest.log(Status.PASS,"Bots preview input was NOT shown after create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}
        }
	}

	public static void createBotSikuli(WebDriver driver,ExtentTest etest)
	{
        CommonSikuli.findInWholePage(driver,"UI433.png","UI433",etest);
        CommonSikuli.findInWholePage(driver,"UI435.png","UI435",etest);
        CommonUtil.scrollIntoView(driver,true,CommonUtil.getElement(driver,By.id("emleftnav"),By.className("sqico-bot")));
        CommonSikuli.findInWholePage(driver,"UI436.png","UI436",etest);
        BotConfiguration.checkSalesIQScriptUI(driver,etest);
    }

}
