//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;

public class DelugeBasic
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots Deluge",BOT1=BotsWidgets.BOT1;

	public static VisitorDriverManager visitor_driver_manager;

	public static String website1=null,website1_code=null,department1=null;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager(true);

			setup(driver);

            result = new Hashtable<String,Boolean>();

			etest=ComplexReportFactory.getTest("In SalesIQ script page LHS deluge menu,Check if all values present under expected groups");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkLHSValues(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Check deluge script page - basic usecases");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDelugeScriptFlow(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS58")+" & "+KeyManager.getRealValue("BOTS59"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEdit(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Check widget templates");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkWidgetTemplates(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
            BotTests.closeBotUIIfOpen(driver);

			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void setup(WebDriver driver) throws Exception
	{

		//portal running this module must only have the following websites,depts and bots

		etest=ComplexReportFactory.getTest("Portal setup for bots deluge usecase");
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		for(int i=0;i<=3;i++)
		{
			try
			{
				website1=ExecuteStatements.getDefaultEmbedName(driver);	
				website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);

				department1=ExecuteStatements.getSystemGeneratedDepartment(driver);

				if(BotsTab.isBotPresent(driver,BOT1)==false)
				{
					Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(BOT1,"BOT1_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website1,department1,null,null);
					BotConfiguration.createBot(driver,etest,bot_info);
				}
				else if(BotsTab.isBotEnabled(driver,BOT1)==false)
				{
					BotsTab.toggleBot(driver,etest,BOT1,true);
				}

				etest.log(Status.PASS,"portal was setup for bots deluge basic module");

				break;
			}
			catch(Exception e)
			{
				CommonUtil.refreshPage(driver);
				if(i==3)
				{
					throw e;
				}
			}
		}

        ComplexReportFactory.closeTest(etest);
	}

	public static void checkLHSValues(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			result.put("BOTS43", DelugeScript.verifyDelugeTasksByCategory(driver,etest,DelugeScript.BASIC_GROUP,DelugeScript.DELUGE_TASKS_BASIC) );
			result.put("BOTS44", DelugeScript.verifyDelugeTasksByCategory(driver,etest,DelugeScript.CONDITION_GROUP,DelugeScript.DELUGE_TASKS_CONDITION) );
			result.put("BOTS45", DelugeScript.verifyDelugeTasksByCategory(driver,etest,DelugeScript.NOTIFICATION_GROUP,DelugeScript.DELUGE_TASKS_NOTIFICATION) );
			result.put("BOTS46", DelugeScript.verifyDelugeTasksByCategory(driver,etest,DelugeScript.INTEGRATION_GROUP,DelugeScript.DELUGE_TASKS_INTEGRATION) );
			result.put("BOTS47", DelugeScript.verifyDelugeTasksByCategory(driver,etest,DelugeScript.WIDGETS_GROUP,DelugeScript.DELUGE_TASKS_SALESIQ_WIDGETS) );
			result.put("BOTS48", DelugeScript.verifyDelugeTasksByCategory(driver,etest,DelugeScript.COLLECTION_GROUP,DelugeScript.DELUGE_TASKS_COLLECTION) );

			DelugeScript.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkDelugeScriptFlow(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

	        CommonSikuli.findInWholePage(driver,"UI439.png","UI439",etest);
	        CommonSikuli.findInWholePage(driver,"UI440.png","UI440",etest);
	        CommonSikuli.findInWholePage(driver,"UI442.png","UI442",etest);
	        CommonSikuli.findInWholePage(driver,"UI444.png","UI444",etest);

			if(DelugeScript.toggleChatPreview(driver,false))
			{
				etest.log(Status.PASS,"Chat preview was hidden after hide button was clicked in deluge script page");
				result.put("BOTS50",true);
			}
			else
			{
				result.put("BOTS50",false);
				etest.log(Status.FAIL,"Chat preview was NOT hidden after hide button was clicked in deluge script page");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(DelugeScript.toggleChatPreview(driver,true))
			{
				etest.log(Status.PASS,"Chat preview was shown after show button was clicked in deluge script page");
				result.put("BOTS49",true);
			}
			else
			{
				result.put("BOTS49",false);
				etest.log(Status.FAIL,"Chat preview was NOT shown after show button was clicked in deluge script page");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(DelugeScript.toggleDelugeLHS(driver,false))
			{
				etest.log(Status.PASS,"Deluge LHS was hidden after hide button was clicked in deluge script page");
				result.put("BOTS52",true);
			}
			else
			{
				result.put("BOTS52",false);
				etest.log(Status.FAIL,"Deluge LHS was NOT hidden after hide button was clicked in deluge script page");
				TakeScreenshot.screenshot(driver,etest);
			}

	        CommonSikuli.findInWholePage(driver,"UI441.png","UI441",etest);

			if(DelugeScript.toggleDelugeLHS(driver,true))
			{
				etest.log(Status.PASS,"Deluge LHS was shown after show button was clicked in deluge script page");
				result.put("BOTS51",true);
			}
			else
			{
				result.put("BOTS51",false);
				etest.log(Status.FAIL,"Deluge LHS was NOT shown after show button was clicked in deluge script page");
				TakeScreenshot.screenshot(driver,etest);
			}

			DelugeScript.checkHandlerDropdown(driver,etest);

			if(DelugeScript.resetPreviewChat(driver))
			{
				result.put("BOTS56",true);
				etest.log(Status.PASS,"Chat was reset after reset chat button was clicked in deluge script editor bot preview");
			}
			else
			{
				result.put("BOTS56",false);
				etest.log(Status.FAIL,"Chat was NOT reset after reset chat button was clicked in deluge script editor bot preview");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(DelugeScript.close(driver))
			{
				etest.log(Status.PASS,"Deluge script page was closed after clicking close icon");
				result.put("BOTS57",true);
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest);
				etest.log(Status.FAIL,"Deluge script page was NOT closed after clicking close icon");
				result.put("BOTS57",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkEdit(WebDriver driver,ExtentTest etest)
	{
		String unique=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;

		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			String bot_message=CommonUtil.getUniqueMessage();
			String code=BotScripts.getBotReplyCode(bot_message);
			DelugeScript.sendKeysToScript(driver,code);
			DelugeScript.clickSave(driver);
			DelugeScript.close(driver);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			String actual_code=DelugeScript.getCurrentCode(driver);

			if(actual_code.contains(bot_message))
			{
				etest.log(Status.PASS,"Saved changed were retained after navigating to other tabs and returning to bots menu");
				result.put("BOTS58",true);
			}
			else
			{
				result.put("BOTS58",false);
				etest.log(Status.FAIL,"Saved changed were NOT retained after navigating to other tabs and returning to bots menu. Expected to contain '"+unique+"' , but bot code was \n"+actual_code);
				TakeScreenshot.screenshot(driver,etest);
			}

			DelugeScript.clickPublish(driver);
			DelugeScript.close(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.createPage(visitor_driver,website1_code);

			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver)==false)
			{
				throw new ZohoSalesIQRuntimeException("Bot was expected to pick up the chat. But it did not!!");
			}

			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			String actual_bot_message=VisitorWindow.getLastMessage(visitor_driver);

			result.put("BOTS59", CommonUtil.checkStringContainsAndLog(bot_message,actual_bot_message,"new bot message after updating script",etest) );
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkWidgetTemplates(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			for(int i=0;i<DelugeScript.DELUGE_TASKS_WIDGET_IDS.length;i++)
			{
				String template_id=DelugeScript.DELUGE_TASKS_WIDGET_IDS[i];
				String usecase="BOTS_"+template_id+"_template";

				etest.log(Status.INFO,"Now checking use case-->"+usecase);

				try
				{
					result.put( usecase,DelugeScript.checkLHSWidgetTemplate(driver,etest,template_id) );
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(driver,etest,e);
				}
			}

            DelugeScript.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}


}
