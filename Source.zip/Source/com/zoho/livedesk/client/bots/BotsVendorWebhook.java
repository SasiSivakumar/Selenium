//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import java.util.Arrays;
import com.zoho.livedesk.util.common.DateTimeUtil;
import com.zoho.livedesk.util.ServerTunnel;
import com.zoho.livedesk.util.Webhook;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class BotsVendorWebhook
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Vendor-Webhook Integration";

	public static final String
	INVALID_URL="https://www.aklsdj09ds.com",
	REPLY="REPLY",
	BOT1=BotsWidgets.BOT1
	;

	public static final int
	GET_RULE=0,
	GET_RULES=1
	;

	public static String articleid1="Article not created 1",articleid2="Article not created 2",unpublished_article_id="Article not created 3",article_label1,article_label2,unpublished_article_label;

	public static String
	webhook_url=null,webhookauth_url=null,website=null,widget_code=null,department=null,bot_unique_message=null;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			website=ExecuteStatements.getDefaultEmbedName(driver);	
			widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			bot_unique_message=CommonUtil.getUniqueMessage();
			Webhook.setBotUniqueMessage(bot_unique_message);

			webhook_url=ServerTunnel.getTunnelURL()+"/webhook";
			webhookauth_url=ServerTunnel.getTunnelURL()+"/webhookauth";

            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"webhook_admin");

			etest=ComplexReportFactory.getTest("Create vendor webhook bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			createWebhookBot(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create vendor webhook bot with invalid webhook url");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			createWebhookBotWithInvalidWebhook(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create secured vendor webhook bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			checkSecuredBot(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);   

			etest=ComplexReportFactory.getTest("Create non-secured vendor webhook bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			checkNonSecuredBot(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);   

			etest=ComplexReportFactory.getTest("Update vendor webhook bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			updateWebhookBot(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create public key from API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			createPublicKey(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Handlers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			checkHandlersAPI(api_webdriver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			// etest=ComplexReportFactory.getTest("Publish and Unpublish bot via API");
			// ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
   //          BotsTab.deleteAllBots(driver,etest);
			// publishWebhookBot(api_webdriver,driver,etest);
   //          ComplexReportFactory.closeTest(etest);

        }
            
		catch(Exception e)
		{	
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			CommonUtil.printStackTrace(e);
			DelugeScript.close(driver);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void createWebhookBot(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			final String
			keys_check_usecase="BOTS290",
			resp_check_usecase="BOTS291",
			ui_check_usecase="BOTS292"
			;

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhook_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			boolean
			is_handoff=true,
			is_secured=false
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			//check expected keys
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_bot_api.expected_keys));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
						
			//check if values are found in response
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");
				result.put(resp_check_usecase,isValuesFoundInResponse(driver,etest,GET_RULE,response,null,name,description,app_id,operator_name,operator_id,is_secured,bot_webhook,Constants.ENABLED,connector,typing_delay,working_hours,true,department_ids,true,false,null,vendor_version,vendor_email,vendor_website,vendor_name,vendor_console_url));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			String bot_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			//check expected values are found in UI
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put(resp_check_usecase,isValuesFoundInUI(driver,etest,name,description,app_id,operator_name,operator_id,ResourceManager.getRealValue("immediate"),working_hours,true,department_names,true,false,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

		  	Tab.navToBotsTab(driver);
	        WebElement bot=BotsTab.getListedBotElement(driver,name);
	        String bot_published_status=BotInfo.getBotPublishedStatus(bot);

			if(bot_published_status.equals(ResourceManager.getRealValue("bot_yet_to_publish")))
			{
				etest.log(Status.PASS,"Vendor webhook bot was not published on creation");
				result.put("BOTS296",true);
			}
			else
			{
				result.put("BOTS296",false);
				etest.log(Status.PASS,"Vendor webhook bot was published on creation");
				TakeScreenshot.screenshot(driver,etest);
			}

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,name);
			BotConfiguration.openWebhookConfiguration(driver);
			VendorWebhookConfiguration.publish(driver,etest,name);
			VendorWebhookConfiguration.close(driver);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);

			if(BotsVisitorSide.waitTillBotPicksUp(visitor_driver))
			{
				etest.log(Status.PASS,"Bot picked up chat after publishing");
				result.put("BOTS297",true);
			}
			else
			{
				TakeScreenshot.screenshot(visitor_driver,etest);
				etest.log(Status.FAIL,"Bot did NOT pick up chat after publishing");				
				result.put("BOTS297",false);
			}			
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	public static void createWebhookBotWithInvalidWebhook(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			final String
			resp_check_usecase="BOTS293"
			;

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook="https://invalidwebhook:0747/invalid"
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			boolean
			is_handoff=true,
			is_secured=false
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			result.put(resp_check_usecase,SalesIQRestAPICommonFunctions.checkErrorJSON(response,"2008","Invalid Webhook",etest));
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	public static void checkSecuredBot(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhookauth_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			boolean
			is_handoff=true,
			is_secured=true
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String used_public_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PUBLIC_KEY1);
         	VerifySignature.setBotPublicKey(used_public_key);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,name);
			BotConfiguration.openWebhookConfiguration(driver);
			VendorWebhookConfiguration.publish(driver,etest,name);
			VendorWebhookConfiguration.close(driver);

         	etest.log(Status.INFO,"IS_SECURED-->TRUE AND CHECKING IF SIGNATURE VERIFICATION PASSES");

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS294",BotsWebhooks.checkSignatureMessage(visitor_driver,etest,used_public_key,true));

         	etest.log(Status.INFO,"IS_SECURED-->TRUE AND CHECKING IF SIGNATURE VERIFICATION FAILS WHEN CALLED FROM EXTERNAL SOURCE");

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			visitor_driver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(visitor_driver,"access","get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(visitor_driver,webhookauth_url);
			SalesIQRestAPICommonFunctions.sendAPIRequest(visitor_driver);
			response = SalesIQRestAPICommonFunctions.getAPIResponse(visitor_driver);
			result.put("BOTS298",BotsWebhooks.checkSignatureMessage(visitor_driver,etest,used_public_key,false,response));

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	public static void checkNonSecuredBot(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhookauth_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			boolean
			is_handoff=true,
			is_secured=false
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String used_public_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PUBLIC_KEY1);
         	VerifySignature.setBotPublicKey(used_public_key);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,name);
			BotConfiguration.openWebhookConfiguration(driver);
			VendorWebhookConfiguration.publish(driver,etest,name);
			VendorWebhookConfiguration.close(driver);

         	etest.log(Status.INFO,"IS_SECURED-->FALSE AND CHECKING IF SIGNATURE VERIFICATION FAILS");

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS295",BotsWebhooks.checkSignatureMessage(visitor_driver,etest,used_public_key,false));

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	//update bot
	public static void updateWebhookBot(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			final String
			keys_check_usecase="BOTS299",
			resp_check_usecase="BOTS300",
			ui_check_usecase="BOTS301"
			;

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhook_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			Boolean
			is_handoff=true,
			is_secured=false
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());


			Tab.navToBotsTab(driver);
        	CommonSikuli.findInWholePage(driver,"UI470.png","UI470",etest);
			BotsTab.openBotConfiguration(driver,name);
	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.WEBHOOK_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI471.png","UI471",etest);
			BotConfiguration.openWebhookConfiguration(driver);
        	CommonSikuli.findInWholePage(driver,"UI472.png","UI472",etest);
			VendorWebhookConfiguration.close(driver);

			String
			department2=ExecuteStatements.getRandomDepartment(driver),
			website2=ExecuteStatements.getRandomWebsiteName(driver),
			bot_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID),
			access_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.ACCESS_KEY)
			;

			label=CommonUtil.getUniqueMessage();

			name="Vendor"+label;
			description="desc"+label;
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website2);
			department_id=ExecuteStatements.getDepartmentId(driver,department2);
			working_hours=Constants.DURING_BUSINESS_HOURS;
			typing_delay="3";
			connector=null;
			vendor_name="Vendor"+label;
			vendor_email=label+"@vendoremail.com";
			vendor_console_url="https://www.vendor_console_url2.com";
			vendor_website="https://www.vendor_website2.com";
			vendor_version="7.37";
			vendor_logo=getBase64Image(2);
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
			operator_name=ExecuteStatements.getUserName(driver);
			operator_id=ExecuteStatements.getOperatorId(driver);
			bot_webhook=null
			;

			department_ids = new String[]{department_id};
			department_names = new String[]{department2};

			is_handoff=false;
			is_secured=null;

			Api update_bot_api = Api.WEBHOOK_BOT_UPDATE;
			api = update_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);

			payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			api=SalesIQRestAPICommonFunctions.addPayloadToAPIString(api,payload.toString());

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);		
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			Tab.navToBotsTab(driver);
        	CommonSikuli.findInWholePage(driver,"UI473.png","UI473",etest);
			BotsTab.openBotConfiguration(driver,name);
	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.WEBHOOK_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI474.png","UI474",etest);
			BotConfiguration.openWebhookConfiguration(driver);
        	CommonSikuli.findInWholePage(driver,"UI475.png","UI475",etest);
			VendorWebhookConfiguration.close(driver);

			//check expected keys
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,update_bot_api.expected_keys));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
						
			//check if values are found in response
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");
				result.put(resp_check_usecase,isValuesFoundInResponse(driver,etest,GET_RULE,response,null,name,description,app_id,operator_name,operator_id,is_secured,bot_webhook,Constants.ENABLED,connector,typing_delay,working_hours,true,department_ids,is_handoff,false,null,vendor_version,vendor_email,vendor_website,vendor_name,vendor_console_url));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//check expected values are found in UI
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put(resp_check_usecase,isValuesFoundInUI(driver,etest,name,description,app_id,operator_name,operator_id,ResourceManager.getRealValue("three_seconds"),working_hours,true,department_names,is_handoff,false,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	//public key
	public static void createPublicKey(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			final String
			keys_check_usecase="BOTS302",
			old_key_check_usecase="BOTS303",
			new_key_check_usecase="BOTS304"
			;

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhookauth_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			Boolean
			is_handoff=true,
			is_secured=true
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String
			bot_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID),
			access_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.ACCESS_KEY)
			;

			Api public_key_create = Api.WEBHOOK_BOT_PUBLIC_KEY_CREATE;
			api = public_key_create.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);

			// payload = GetPayload.getWebhookBotPayload(null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,access_key);
			// etest.log(Status.INFO,"Below json will be used as payload");
			// SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,public_key_create);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String
			new_public_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PUBLIC_KEY2),
			new_key_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PUBLIC_KEY2_ID),
			old_public_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PUBLIC_KEY1),
			old_key_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PUBLIC_KEY1_ID)
			;

			

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,public_key_create.expected_keys));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			etest.log(Status.INFO,"Newly created public key is "+new_public_key);
			etest.log(Status.INFO,"Old public key is "+old_public_key);


			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,name);
			BotConfiguration.openWebhookConfiguration(driver);
			VendorWebhookConfiguration.publish(driver,etest,name);
			VendorWebhookConfiguration.close(driver);

         	etest.log(Status.INFO,"USING OLD PUBLIC KEY - CHECKING IF SIGNATURE VERIFICATION PASSES");

         	VerifySignature.setBotPublicKey(old_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put(old_key_check_usecase,BotsWebhooks.checkSignatureMessage(visitor_driver,etest,old_public_key,true));

         	etest.log(Status.INFO,"USING NEW PUBLIC KEY - CHECKING IF SIGNATURE VERIFICATION FAILS");

         	VerifySignature.setBotPublicKey(new_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put(new_key_check_usecase,BotsWebhooks.checkSignatureMessage(visitor_driver,etest,new_public_key,false));

			

			public_key_create = Api.WEBHOOK_BOT_PUBLIC_KEY_CREATE;
			api = public_key_create.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);


			// payload = GetPayload.getWebhookBotPayload(null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,access_key);
			// etest.log(Status.INFO,"Below json will be used as payload");
			// SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,public_key_create);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			result.put("BOTS305",SalesIQRestAPICommonFunctions.checkErrorJSON(response,"1017","Resource limit reached for current plan",etest));

			

			Api public_key_delete = Api.WEBHOOK_BOT_PUBLIC_KEY_DELETE;
			api = public_key_delete.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api = api.replace("<keyid>",old_key_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);

			// payload = GetPayload.getWebhookBotPayload(null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,access_key);
			// etest.log(Status.INFO,"Below json will be used as payload");
			// SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,public_key_delete);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			

         	etest.log(Status.INFO,"USING DELETED PUBLIC KEY - CHECKING IF SIGNATURE VERIFICATION FAILS");

         	VerifySignature.setBotPublicKey(old_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS306",BotsWebhooks.checkSignatureMessage(visitor_driver,etest,old_public_key,false));

         	etest.log(Status.INFO,"USING REMAINING PUBLIC KEY - CHECKING IF SIGNATURE VERIFICATION PASSES");

         	VerifySignature.setBotPublicKey(new_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS307",BotsWebhooks.checkSignatureMessage(visitor_driver,etest,new_public_key,true));

         	etest.log(Status.INFO,"NOW TRYING TO DELETE LAST REMAINING KEY");

			public_key_delete = Api.WEBHOOK_BOT_PUBLIC_KEY_DELETE;
			api = public_key_delete.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api = api.replace("<keyid>",new_key_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);

			// payload = GetPayload.getWebhookBotPayload(null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,access_key);
			// etest.log(Status.INFO,"Below json will be used as payload");
			// SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,public_key_delete);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			result.put("BOTS308",SalesIQRestAPICommonFunctions.checkErrorJSON(response,"1026","Last available resource",etest));

			
			

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	//handler api
	public static void checkHandlersAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhook_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			Boolean
			is_handoff=true,
			is_secured=false
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String
			bot_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID),
			access_key=SalesIQRestAPICommonFunctions.jPath(response,JPaths.ACCESS_KEY)
			;

			label=CommonUtil.getUniqueMessage();

			bot_webhook=webhookauth_url;
			is_secured=true;
			Boolean is_published=true;

			Api update_bot_api = Api.WEBHOOK_BOT_HANDLERS;
			api = update_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);

			payload = GetPayload.getWebhookBotHandlerPayload(bot_webhook,is_secured,true);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			api=SalesIQRestAPICommonFunctions.addPayloadToAPIString(api,payload.toString());

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			//check expected keys
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("BOTS313",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,update_bot_api.expected_keys));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
						
			//check if values are found in response
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");
				result.put("BOTS309",isValuesFoundInResponse(driver,etest,GET_RULE,response,null,name,description,app_id,operator_name,operator_id,is_secured,bot_webhook,Constants.ENABLED,connector,typing_delay,working_hours,true,department_ids,is_handoff,is_published,null,vendor_version,vendor_email,vendor_website,vendor_name,vendor_console_url));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//check expected values are found in UI
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("BOTS310",isValuesFoundInUI(driver,etest,name,description,app_id,operator_name,operator_id,ResourceManager.getRealValue("immediate"),working_hours,true,department_names,is_handoff,is_published,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			is_published=false;

			update_bot_api = Api.WEBHOOK_BOT_HANDLERS;
			api = update_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);

			payload = GetPayload.getWebhookBotHandlerPayload(null,null,false);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			//check expected values are found in UI
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("BOTS312",isValuesFoundInUI(driver,etest,name,description,app_id,operator_name,operator_id,ResourceManager.getRealValue("immediate"),working_hours,true,department_names,is_handoff,is_published,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			bot_webhook=webhook_url+"invalid_url";

			update_bot_api = Api.WEBHOOK_BOT_HANDLERS;
			api = update_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);
			api=SalesIQRestAPICommonFunctions.addHeader(api,APIKeys.X_ACCESS_KEY,access_key);

			payload = GetPayload.getWebhookBotHandlerPayload(bot_webhook,is_secured,true);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			api=SalesIQRestAPICommonFunctions.addPayloadToAPIString(api,payload.toString());

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			// SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			result.put("BOTS311",SalesIQRestAPICommonFunctions.checkErrorJSON(response,"2008","Invalid Webhook",etest));

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	//pub and unpub
	public static void publishWebhookBot(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			//create webhook bot
			String
			name="Vendor"+label,
			description="desc"+label,
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			department_id=ExecuteStatements.getDepartmentId(driver,department),
			working_hours=Constants.ALL_THE_TIME,
			typing_delay="0",
			connector=Constants.WEBHOOK,
			vendor_name="Vendor"+label,
			vendor_email=label+"@vendoremail.com",
			vendor_console_url="https://www.vendor_console_url.com",
			vendor_website="https://www.vendor_website.com",
			vendor_version="7.47",
			vendor_logo=getBase64Image(1),
			// vendor_logo="iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
			operator_name=ExecuteStatements.getUserName(driver),
			operator_id=ExecuteStatements.getOperatorId(driver),
			bot_webhook=webhook_url
			;

			String[]
			department_ids = new String[]{department_id}
			;

			String[]
			department_names = new String[]{department}
			;

			Boolean
			is_handoff=true,
			is_secured=false
			;

			Api create_bot_api = Api.WEBHOOK_BOT_CREATE;
			String api = create_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getWebhookBotPayload(name,description,app_id,department_ids,is_handoff,working_hours,typing_delay,connector,bot_webhook,is_secured,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version,vendor_logo);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
         	CommonUtil.waitTillURLValid(bot_webhook);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			etest.log(Status.INFO,"NOW PUBLISHING BOT VIA API");

			String
			bot_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID)
			;

			Boolean is_published=true;

			Api update_bot_api = Api.WEBHOOK_BOT_UPDATE;
			api = update_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);

			payload = GetPayload.getWebhookBotHandlerPayload(null,null,is_published);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());
						
			//check expected values are found in UI
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("BOTS314",isValuesFoundInUI(driver,etest,name,description,app_id,operator_name,operator_id,ResourceManager.getRealValue("immediate"),working_hours,true,department_names,is_handoff,is_published,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			etest.log(Status.INFO,"NOW UNPUBLISHING BOT VIA API");

			is_published=false;

			update_bot_api = Api.WEBHOOK_BOT_UPDATE;
			api = update_bot_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api = api.replace("<id>",bot_id);

			payload = GetPayload.getWebhookBotHandlerPayload(null,null,is_published);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_bot_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"api-->"+api);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());
						
			//check expected values are found in UI
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("BOTS315",isValuesFoundInUI(driver,etest,name,description,app_id,operator_name,operator_id,ResourceManager.getRealValue("immediate"),working_hours,true,department_names,is_handoff,is_published,vendor_name,vendor_email,vendor_console_url,vendor_website,vendor_version));
			}
			catch(Exception e1)
			{
				CommonUtil.printStackTrace(e1);
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	public static String getBase64Image(int image_index) throws Exception
	{
		String fieldmaps_directory=FileUpload.getBuildRoot()+"/webapps/selenium/test_related_files/image"+image_index+"_base64.txt";
		return FileUpload.getFileAsString(fieldmaps_directory);
	}

	public static boolean isValuesFoundInResponse(WebDriver driver,ExtentTest etest,int api_type,String response,String id,String name,String description,String app_id,String operator_name,String operator_id,Boolean is_secured,String webhook,String connector_status,String connector_type,String typing_delay,String working_hours,Boolean is_enabled,String[] department_ids,Boolean is_handoff,Boolean is_published,String image_url,String vendor_version,String vendor_mail,String vendor_website,String vendor_name,String vendor_console) throws Exception
	{
		int failcount=0;

		if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,name,getJPath(response,id,JPaths.BOT_NAME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,description,getJPath(response,id,JPaths.BOT_DESCRIPTION,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,app_id,getJPath(response,id,JPaths.APPID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,operator_name,getJPath(response,id,JPaths.MODIFIER_NAME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,operator_id,getJPath(response,id,JPaths.MODIFIER_ID,api_type),etest))
		{
			failcount++;
		}

		if(is_secured!=null && !isValueFound(response,is_secured+"",getJPath(response,id,JPaths.IS_SECURED,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,connector_status,getJPath(response,id,JPaths.CONNECTOR_STATUS,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,connector_type,getJPath(response,id,JPaths.CONNECTOR_TYPE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,typing_delay,getJPath(response,id,JPaths.TYPING_DELAY,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,working_hours,getJPath(response,id,JPaths.WORKING_HOURS,api_type),etest))
		{
			failcount++;
		}

		if(is_enabled!=null && !isValueFound(response,is_enabled+"",getJPath(response,id,JPaths.ENABLED,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,operator_name,getJPath(response,id,JPaths.CREATOR_NAME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,operator_id,getJPath(response,id,JPaths.CREATOR_ID2,api_type),etest))
		{
			failcount++;
		}

		if(department_ids!=null)
		{
			for(int i=0;i<department_ids.length;i++)
			{
				String department_id=department_ids[i];

				if(!isValueFound(response,department_id,getJPath(response,id,JPaths.DEPARMENT_ID.replace("<index>",i+""),api_type),etest))
				{
					failcount++;
				}
			}
		}

		if(is_handoff!=null && !isValueFound(response,is_handoff+"",getJPath(response,id,JPaths.HANDOFF,api_type),etest))
		{
			failcount++;
		}

		if(is_published!=null && !isValueFound(response,is_published+"",getJPath(response,id,JPaths.IS_PUBLISHED,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,image_url,getJPath(response,id,JPaths.IMAGE_URL,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,vendor_version,getJPath(response,id,JPaths.VENDOR_VERSION,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,vendor_mail,getJPath(response,id,JPaths.VENDOR_MAIL,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,vendor_website,getJPath(response,id,JPaths.VENDOR_WEBSITE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,vendor_name,getJPath(response,id,JPaths.VENDOR_NAME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,vendor_console,getJPath(response,id,JPaths.VENDOR_CONSOLE,api_type),etest))
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isValuesFoundInUI(WebDriver driver,ExtentTest etest,String name,String description,String app_id,String operator_name,String operator_id,String typing_delay,String working_hours,Boolean is_enabled,String[] department_names,Boolean is_handoff,Boolean is_published,String vendor_name,String vendor_email,String vendor_console_url,String vendor_website,String vendor_version) throws Exception
	{
		int failcount=0;

		Tab.navToBotsTab(driver);
		BotsTab.openBotConfiguration(driver,name);

		Hashtable<String,String> bot_info=BotInfo.getBotConfig(driver,etest,name,false);

		BotConfiguration.openWebhookConfiguration(driver);

		final String
		actual_installed_by=VendorWebhookConfiguration.getInstalledBy(driver),
		actual_service=VendorWebhookConfiguration.getServiceName(driver),
		actual_version=VendorWebhookConfiguration.getVersion(driver),
		actual_email=VendorWebhookConfiguration.getEmail(driver),
		actual_website=VendorWebhookConfiguration.getWebsite(driver),
		actual_vendor_console_url=VendorWebhookConfiguration.getConsole(driver)
		;

		VendorWebhookConfiguration.close(driver);

		if(isContains(description,bot_info.get(BotInfo.DESCRIPTION),BotInfo.DESCRIPTION,etest)==false)
		{
			failcount++;
		}

		String actual_app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,bot_info.get(BotInfo.WEBSITE));

		if(isContains(app_id,actual_app_id,"app_id",etest)==false)
		{
			failcount++;
		}

		if(department_names!=null)
		{
			for(int i=0;i<department_names.length;i++)
			{
				String department_name=department_names[i];

				if(isContains(department_name,bot_info.get(BotInfo.DEPARTMENTS),"department",etest)==false)
				{
					failcount++;
				}
			}
		}

		if(isContains(app_id,actual_app_id,"app_id",etest)==false)
		{
			failcount++;
		}

		String actual_working_hours=BotInfo.WORKING_HOURS_VALUES[Integer.parseInt(bot_info.get(BotInfo.BUSINESS_HOUR))];

		if(isContains(working_hours,actual_working_hours,"working_hours",etest)==false)
		{
			failcount++;
		}

		if(isContains(typing_delay,bot_info.get(BotInfo.TYPING_DELAY),"typing delay",etest)==false)
		{
			failcount++;
		}

		if(isContains(operator_name,actual_installed_by,"installed_by",etest)==false)
		{
			failcount++;
		}

		if(isContains(vendor_name,actual_service,"vendor name",etest)==false)
		{
			failcount++;
		}

		if(isContains(vendor_email,actual_email,"vendor email",etest)==false)
		{
			failcount++;
		}

		if(isContains(vendor_console_url,actual_vendor_console_url,"vendor console",etest)==false)
		{
			failcount++;
		}

		if(isContains(vendor_website,actual_website,"vendor website",etest)==false)
		{
			failcount++;
		}

		if(isContains(vendor_version,actual_version,"vendor version",etest)==false)
		{
			failcount++;
		}

		if(isContains(is_handoff+"",bot_info.get(BotInfo.IS_CONNECT_HUMAN),"is handoff",etest)==false)
		{
			failcount++;
		}

		if(is_published!=null)
		{
			if(bot_info.get(BotInfo.PUBLISH_STATUS).equals(ResourceManager.getRealValue("bot_yet_to_publish"))!=is_published)
			{
				etest.log(Status.PASS,"Expected published value '"+is_published+"' was found");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Expected published value '"+is_published+"' was NOT found");
			}
		}


		return CommonUtil.returnResult(failcount);
	}

	//other methods
	public static String getJPath(String response,String rule_id,String jPath,int api_type) throws Exception
	{
		if(api_type==GET_RULE || response==null || rule_id==null)
		{
			return jPath;
		}
		else
		{
			int rule_index=getRuleIndexOfGetRulesResponse(response,rule_id);
			jPath=getJPathForIndex(jPath,rule_index);
			return jPath;
		}
	}

	public static String getJPathForIndex(String jPath,int rule_index) throws Exception
	{
		jPath=jPath.replace("data/", "data["+rule_index+"]/");
		return jPath;
	}

	public static int getRuleIndexOfGetRulesResponse(String response,String rule_id) throws Exception
	{
		JSONObject resp_json=new JSONObject(response);
		JSONArray rules_array=resp_json.getJSONArray("data");
		return SalesIQRestAPICommonFunctions.getJSONIndexWith(rules_array,"id",rule_id);
	}

	public static boolean isValueFound(String response,String expected,String jpath,ExtentTest etest) throws Exception
	{
		return SalesIQRESTAPIModule3.isValueFound(response,expected,jpath,etest);
	}

	public static boolean isContains(String expected,String actual,String description,ExtentTest etest) throws Exception
	{
		return SalesIQRESTAPIModule3.isContains(expected,actual,description,etest);
	}

	public static boolean isKeysFoundForGetRulesAPI(ExtentTest etest,String json_string,String[] jPaths) throws Exception
	{
		int failcount=0;

		for(String jPath : jPaths)
		{
			if(!SalesIQRestAPICommonFunctions.isKeyFound(etest,json_string,getJPathForIndex(jPath,0)))
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}


}