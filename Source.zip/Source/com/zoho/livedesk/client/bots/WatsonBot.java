//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import java.util.Arrays;
import com.zoho.livedesk.util.common.DateTimeUtil;

public class WatsonBot
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Watson Bot",BOT1=BotsWidgets.BOT1,WATSON_ASSISTANT_NAME="Automation",RANGLE_CALENDAR_LABEL=BotScripts.BOT_REPLY_MESSAGE;

	public static final String
	WATSON_ASSISTANT_ID="e649cb94-0e35-4ba9-9f4e-c2d57bd15d04",
	HOST_URL="https://gateway.watsonplatform.net/assistant/api/",
	API_KEY="OX0yif2rIO9Z9RX6c7FjEvkAnRfy0XJnSTup-RT_edzO",
	ANYTHING_ELSE_DIALOG="<bot_reply>"
	;

	public static Hashtable test(WebDriver driver)
	{
		//bot name must be same as bot widgets module-->BotsWidgets.BOT1

		try
		{
			// etest=ComplexReportFactory.getTest("Check Watson Bot - New Account");
			// ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			// checkWatsonNewAccount(driver,etest);
   //          ComplexReportFactory.closeTest(etest);

			String website1=ExecuteStatements.getDefaultEmbedName(driver);	
			String website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);
			String department1=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String bot_unique_message=CommonUtil.getUniqueMessage();

            result = new Hashtable<String,Boolean>();
            
			etest=ComplexReportFactory.getTest("Watson Portal Setup");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBots(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Watson Side UI - Create Watson Assistant CRUD");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkWatsonAssistantCRUD(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Create Watson Bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCreate(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Check replies");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkReply(driver,etest);
            ComplexReportFactory.closeTest(etest);

           //to make sure supervisor driver closes, we are using visitor driver manager
            WebDriver supervisor_driver=BotTests.visitor_driver_manager.getDriver(driver);

            Functions.login(supervisor_driver,"watson_supervisor");

			etest=ComplexReportFactory.getTest("Check supervisor permissions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSupervisor(supervisor_driver,etest);
            ComplexReportFactory.closeTest(etest);

            Functions.logout(supervisor_driver);
            
			etest=ComplexReportFactory.getTest("Widget Usecases Portal Setup");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBotsExcept(driver,etest,BOT1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS322"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBotsExcept(driver,etest,BOT1);
			result.put("BOTS322", BotsWidgets.checkSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS323"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS323", BotsWidgets.checkRangeSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS318"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS318", BotsWidgets.checkHappinessRatingWidget(driver,etest,3,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS319"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS319", BotsWidgets.checkHappinessRatingWidget(driver,etest,5,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check like rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkLikeWidget(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check star rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkStarRating(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check single select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSingleSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check multi select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkMultiSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check date-time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDateTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check range calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRangeCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);
        }
            
		catch(Exception e)
		{	
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			CommonUtil.printStackTrace(e);
			DelugeScript.close(driver);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void checkLikeWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkLikeWidget(driver,etest,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkStarRating(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkStarRating(driver,etest,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkSingleSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkSingleSelect(driver,etest,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkMultiSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkMultiSelect(driver,etest,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkTimeslots(driver,etest,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkDateTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkDateTimeslots(driver,etest,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkCalendar(driver,etest,BotScripts.BOT_REPLY_MESSAGE,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkRangeCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkRangeCalendar(driver,etest,RANGLE_CALENDAR_LABEL,website,department,BotsWidgets.WATSON_BOT);
        result.putAll(widget_result);
	}

	public static void checkCreate(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage(),siq_bot="Bot"+unique,trigger="Trigger"+unique;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			// BotConfiguration.createWatsonBot(driver,etest,siq_bot,"desc",website,department,WATSON_ASSISTANT_ID,trigger);

	        Tab.navToBotsTab(driver);
	        BotsTab.clickAddBot(driver);
	        BotConfiguration.editBotName(driver,siq_bot);
	        BotConfiguration.editBotDescription(driver,"desc");
	        BotConfiguration.selectWebsite(driver,website);
	        BotConfiguration.selectDepartment(driver,department);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.WATSON_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI476.png","UI476",etest);

	        BotConfiguration.openWatsonConfiguration(driver);

	        WatsonConfiguration.enterAssistantID(driver,WATSON_ASSISTANT_ID);

	        WatsonConfiguration.setTriggerMessages(driver,etest,trigger);

			//Check preview chat input not shown before clicking create
        	if(WatsonConfiguration.isBotPreviewChatInputDisplayed(driver)==false)
        	{
	        	result.put("BOTS345",true);
				etest.log(Status.PASS,"Bots preview input was NOT shown before create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS345",false);
				etest.log(Status.PASS,"Bots preview input was shown before create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}

	        WatsonConfiguration.clickCreateBot(driver);

			//Check preview chat input is shown after clicking create
        	if(WatsonConfiguration.isBotPreviewChatInputDisplayed(driver))
        	{
	        	result.put("BOTS346",true);
				etest.log(Status.PASS,"Bots preview input was shown after create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS346",false);
				etest.log(Status.PASS,"Bots preview input was NOT shown after create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}


	        etest.log(Status.INFO,"Watson bot '"+siq_bot+"' was created");
	        TakeScreenshot.infoScreenshot(driver,etest);

			//check in preview chat
			DelugeScript.resetPreviewChat(driver);
			BotsVisitorSide.waitTillBotReplies(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			VisitorWindow.sentMessageInTheme(driver,unique,true);
			BotsVisitorSide.waitTillBotReplies(driver);
			result.put("BOTS358", CommonUtil.checkStringContainsAndLog(ANYTHING_ELSE_DIALOG,VisitorWindow.getLastAgentMessage(driver),"portal side-preview chat-bot reply after invoking a watson dialog",etest) );


			//Check watson console page opens after clicking
			if(WatsonConfiguration.clickAccessConsole(driver,etest))
			{
				etest.log(Status.PASS,"Watson console was opened after clicking access watson button from salesiq");
				result.put("BOTS347",true);
			}
			else
			{
				etest.log(Status.FAIL,"Watson console was NOT opened after clicking access watson button from salesiq");
				result.put("BOTS347",false);
			}

			CommonUtil.closeAllTabs(driver);

			//Check if watson popup is opened after clicking change
			if(WatsonConfiguration.clickChangeButton(driver,etest))
			{
				etest.log(Status.PASS,"Popup was opened after clicking change button from salesiq");
				result.put("BOTS348",true);
			}
			else
			{
				etest.log(Status.FAIL,"Popup was NOT opened after clicking change button from salesiq");
				result.put("BOTS348",false);
			}

			String valid_host_url=WatsonConfiguration.getHostURLFromPopup(driver);
			String valid_api_key=WatsonConfiguration.getAPIKeyFromPopup(driver);

			//Enter invalid cred and check error
			result.put("BOTS349", WatsonConfiguration.editWatsonAssistantCredentials(driver,etest,"invalid","invalid",false) );

			//Enter valid cred and check success
			result.put("BOTS350", WatsonConfiguration.editWatsonAssistantCredentials(driver,etest,valid_host_url,valid_api_key,true) );

			BotConfiguration.close(driver);

			//Set trigger message and check if bot triggered in visitor side
			Tab.navToBotsTab(driver);
        	CommonSikuli.findInWholePage(driver,"UI477.png","UI477",etest);			

			BotsTab.openBotConfiguration(driver,siq_bot);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.WATSON_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI478.png","UI478",etest);

			BotConfiguration.triggerBotForAll(driver,etest);

        	//check in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			//bot will be triggered
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			VisitorWindow.waitTillMessageInChat(visitor_driver,trigger,5);

			String messages=VisitorWindow.getChatWindowInnerText(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(trigger,messages,"triggered message",etest))
			{
				etest.log(Status.PASS,"All expected trigger messages were received by the visitor");
				result.put("BOTS351",true);
			}
			else
			{
				etest.log(Status.FAIL,"All expected trigger messages were NOT received by the visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("BOTS351",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkSupervisor(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		try
		{
			//open watson console
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.openWatsonConfiguration(driver);

			//check managed by text
			String expected=ResourceManager.getRealValue("dialogflow_managed_by");
			String actual=WatsonConfiguration.getManagedByText(driver);

			if(CommonUtil.checkStringContainsAndLog(expected,actual,"watson managed by text for supervisor",etest)==false)
			{
				result.put("BOTS352",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			else
			{
				result.put("BOTS352",true);
			}

			//Check change button not shown
			if(CommonWait.isDisplayed(driver,WatsonConfiguration.CHANGE))
			{
				etest.log(Status.PASS,"Change button was shown for supervisor");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Change button was NOT shown for supervisor");
			}


			//check access watson console not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.ACCESS_DF_CONSOLE_BUTTON))
			{
				etest.log(Status.FAIL,"Access watson console button was shown for supervisor");
				failcount++;
			}
			else
			{
				etest.log(Status.PASS,"Access watson console  button was NOT shown for supervisor");
			}

			//check edit not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.EDIT))
			{
				etest.log(Status.PASS,"Edit button was shown for supervisor");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Edit button was NOT shown for supervisor");
			}

			if(CommonUtil.returnResult(failcount)==false)
			{
				TakeScreenshot.screenshot(driver,etest);
			}

			result.put("BOTS353", CommonUtil.returnResult(failcount) );
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	//new
	public static Hashtable<String,Boolean> checkWatsonNewAccount(WebDriver driver,ExtentTest etest)
	{
		Hashtable<String,Boolean> newaccount_result=new Hashtable<String,Boolean>();

		int failcount=0;

		String unique=CommonUtil.getUniqueMessage(),siq_bot="Watson"+unique;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

	        Tab.navToBotsTab(driver);
	        BotsTab.clickAddBot(driver);

	        BotConfiguration.editBotName(driver,siq_bot);
	        BotConfiguration.editBotDescription(driver,siq_bot);
	        BotConfiguration.selectWebsite(driver,website);
	        BotConfiguration.selectDepartment(driver,department);
	        BotConfiguration.clearCurrentTriggers(driver);
	        
	        BotConfiguration.openWatsonConfiguration(driver);

	        TakeScreenshot.infoScreenshot(driver,etest);

			//check connect with dialogflow UI is shown
			if(WatsonConfiguration.isConnectWithWatsonShown(driver))
			{
				newaccount_result.put("BOTS354",true);
				etest.log(Status.PASS,"Authenticate watson button was shown for new account");
			}
			else
			{
				newaccount_result.put("BOTS354",false);
				etest.log(Status.FAIL,"Authenticate watson button was NOT shown for new account");
				TakeScreenshot.screenshot(driver,etest);
			}

        	// CommonSikuli.findInWholePage(driver,"UI459.png","UI459",etest);

			//Check description text
			String expected=ResourceManager.getRealValue("watson_description");
			String actual=CommonUtil.getElement(driver,DialogflowConfiguration.DIALOGFLOW_DESC).getAttribute("innerText");

			if(CommonUtil.checkStringContainsAndLog(expected,actual,"watson description for new account",etest))
			{
				newaccount_result.put("BOTS355",true);
			}
			else
			{
				newaccount_result.put("BOTS355",false);				
			}

			if(WatsonConfiguration.authenticateWatsonNewAccount(driver,etest,HOST_URL,API_KEY))
			{
				etest.log(Status.PASS,"Bot was successfully authenticated for the portal.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Bot was NOT successfully authenticated for the portal.");
				TakeScreenshot.screenshot(driver,etest);				
			}

	        WatsonConfiguration.enterAssistantID(driver,WATSON_ASSISTANT_ID);

	        if(WatsonConfiguration.clickCreateBot(driver))
	        {
		        etest.log(Status.PASS,"Watson bot '"+siq_bot+"' was created in new account");
		        TakeScreenshot.infoScreenshot(driver,etest);
	        }
	        else
	        {
				failcount++;
		        etest.log(Status.FAIL,"Watson bot '"+siq_bot+"' was NOT created in new account");
				TakeScreenshot.screenshot(driver,etest);	        	
	        }

	        newaccount_result.put("BOTS356", CommonUtil.returnResult(failcount) );

	        WatsonConfiguration.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return newaccount_result;
	}

	//check replies
	public static void checkReply(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage(),siq_bot="Bot"+unique,trigger="Trigger"+unique;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			BotConfiguration.createWatsonBot(driver,etest,siq_bot,"desc",website,department,WATSON_ASSISTANT_ID,trigger);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			// VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"Message"+unique+"Visitor",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(CommonUtil.checkStringContainsAndLog(ANYTHING_ELSE_DIALOG,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after sending random message",etest))
			{
				result.put("BOTS357",true);
			}
			else
			{
				result.put("BOTS357",false);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkWatsonAssistantCRUD(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage(),siq_bot="Bot"+unique,trigger="Trigger"+unique;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String assistant_name="A"+unique;

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.openWatsonConfiguration(driver);

			WatsonConfiguration.clickAccessConsole(driver,etest);

			IBMWatsonUI.login(driver,etest);

			String new_assistant_id=IBMWatsonUI.createAssistant(driver,etest,assistant_name);

			CommonUtil.switchToTab(driver,0);
			
			WatsonConfiguration.close(driver);

			BotConfiguration.createWatsonBot(driver,etest,siq_bot,"desc",website,department,new_assistant_id,trigger);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"Message"+unique+"Visitor",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(CommonUtil.checkStringContainsAndLog(ANYTHING_ELSE_DIALOG,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after sending random message",etest))
			{
				result.put("BOTS357",true);
				etest.log(Status.PASS,"Bot created from newly created watson assistant picked up the chat in visitor side");
			}
			else
			{
				result.put("BOTS357",false);
				etest.log(Status.FAIL,"Bot created from newly created watson assistant did NOT pick up the chat in visitor side");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			//delete agent
			CommonUtil.switchToTab(driver,1);
			IBMWatsonUI.deleteAssistant(driver,etest,assistant_name);
			CommonUtil.switchToTab(driver,0);

			CommonUtil.refreshPage(driver);

			//check salesiq is corrupt
			Tab.navToBotsTab(driver);

			BotsTab.openBotConfiguration(driver,siq_bot);

			if(BotConfiguration.isBotCorrupt(driver))
			{
				etest.log(Status.PASS,"Connection error was shown after connected watson assistant was deleted.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Connection error was NOT shown after connected watson assistant was deleted.");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			Tab.navToBotsTab(driver);

			if(BotsTab.isBotEnabled(driver,siq_bot)==false)
			{
				etest.log(Status.PASS,"Corrupted bot '"+siq_bot+"' was disabled after connected watson assistant was deleted.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Corrupted bot '"+siq_bot+"' was not disabled after connected watson assistant was deleted.");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;		
			}

			result.put("BOTS362", CommonUtil.returnResult(failcount) );

			//reallocate assistant
			CommonUtil.switchToTab(driver,0);
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
	        BotConfiguration.openWatsonConfiguration(driver);
			WatsonConfiguration.clickEditBot(driver);
	        WatsonConfiguration.enterAssistantID(driver,WATSON_ASSISTANT_ID);
			etest.log(Status.INFO,"Watson assistant id '"+WATSON_ASSISTANT_ID+"' was allocated for SalesIQ bot : "+siq_bot);
			TakeScreenshot.infoScreenshot(driver,etest);
			WatsonConfiguration.clickSaveBot(driver);
			WatsonConfiguration.close(driver);

			//re-enable the bot
			Tab.navToBotsTab(driver);
			BotsTab.toggleBot(driver,etest,siq_bot,true);

			//check bot pickup in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,siq_bot))
			{
				result.put("BOTS363",true);
				etest.log(Status.PASS,"Watson bot '"+siq_bot+"' picked up chat after non-corrupt agent was reallocated");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS363",false);
				etest.log(Status.FAIL,"Watson bot '"+siq_bot+"' did NOT pick up chat even after non-corrupt agent was reallocated");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			Tab.navToBotsTab(driver);
			BotsTab.deleteBot(driver,etest,siq_bot);

			CommonUtil.closeAllTabs(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}
}
