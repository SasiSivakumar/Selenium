//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;

public class BotsConfig
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots Config";
	
	public static VisitorDriverManager visitor_driver_manager;

	public static String
	bot1,bot2,website1,website2,department1,department2,website1_code,website2_code;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			setup(driver);

			visitor_driver_manager = new VisitorDriverManager(true);

            result = new Hashtable<String,Boolean>();

			etest=ComplexReportFactory.getTest("Check bot website configurations");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotWebsite(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Check bot department configurations");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotDepartment(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS34"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS34",check2BotsFor2Departments(driver,etest));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS36_1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS36_1",checkBotBusinessHours(driver,etest,BotConfiguration.STANDARD_BUSINESS_HOUR_VALUE));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS36_2"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS36_2",checkBotBusinessHours(driver,etest,BotConfiguration.NON_BUSINESS_HOUR_VALUE));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS35"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS35",checkBotBusinessHours(driver,etest,BotConfiguration.ALL_TIME_BUSINESS_HOUR_VALUE));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,false);
			etest.log(Status.INFO,"Business hours was disabled successfully after checking the usecases");

            /*
			Depracated UI and flow

			etest=ComplexReportFactory.getTest("Checking bot pick up status when website configuration is "+BotsVisitorSide.NONE);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkWebsiteConfiguration(driver,etest,BotsVisitorSide.BOT_ANSWERS_NONE);
            ComplexReportFactory.closeTest(etest);
            
			etest=ComplexReportFactory.getTest("Checking bot pick up status when website configuration is "+BotsVisitorSide.ALL);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkWebsiteConfiguration(driver,etest,BotsVisitorSide.BOT_ANSWERS_ALL);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Checking bot pick up status when website configuration is "+BotsVisitorSide.WHEN_BUSY);
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkWebsiteConfiguration(driver,etest,BotsVisitorSide.BOT_ANSWERS_WHEN_BUSY);
            ComplexReportFactory.closeTest(etest);

            */

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS37")+" and "+KeyManager.getRealValue("BOTS39"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotConnectToHuman(driver,etest,true,true);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			/*
			Deprecated this option in visitor side

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS38")+" and "+KeyManager.getRealValue("BOTS40"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotConnectToHuman(driver,etest,true,false);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            */

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS42"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBotConnectToHuman(driver,etest,false,null);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void setup(WebDriver driver) throws Exception
	{

		//portal running this module must only have the following,depts and bots. All websites in portal must be enabled and portal must have atleast 2 websites

		etest=ComplexReportFactory.getTest("Portal setup for bot config usecase");
		ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

		website1=ExecuteStatements.getDefaultEmbedName(driver);	
		website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);

		website2=ExecuteStatements.getRandomWebsiteName(driver);
		website2_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website2);

		department1=ExecuteStatements.getSystemGeneratedDepartment(driver);
		department2="Department2";

		bot1="Bot_One";
		bot2="Bot_Two";

		ArrayList<String> departments=new ArrayList<String>();

		departments.add(department1);
		departments.add(department2);
		
		Cleanup.deleteAllDeparmentsExcept(driver,departments);
		// Cleanup.deleteAllBots(driver);

		if(Department.isDepartmentNamePresent(driver,department2)==false)
		{

			Department.addDept(driver,department2,"depttype_publi",ExecuteStatements.getUserName(driver),etest);
			etest.log(Status.PASS,"Department '"+department2+"' was added");
		}

		if(BotsTab.isBotPresent(driver,bot1)==false)
		{
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(bot1,"bot1_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website1,department1,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
		}
		else if(BotsTab.isBotEnabled(driver,bot1)==false)
		{
			BotsTab.toggleBot(driver,etest,bot1,true);
		}

		if(BotsTab.isBotPresent(driver,bot2)==false)
		{
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(bot2,"bot2_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website2,department2,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
		}
		else if(BotsTab.isBotEnabled(driver,bot2)==false)
		{
			BotsTab.toggleBot(driver,etest,bot2,true);
		}

		etest.log(Status.PASS,"portal was setup for bot configuration module");

        ComplexReportFactory.closeTest(etest);
	}


	public static void checkBotWebsite(WebDriver driver,ExtentTest etest)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			BotsTab.toggleBot(driver,etest,bot1,true);
			BotsTab.toggleBot(driver,etest,bot2,false);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot1);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department1,department2);
			BotConfiguration.clickSave(driver);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.setupChat(driver,visitor_driver,etest,website1_code,unique,ChatType.INITIATED);

			if(BotsVisitorSide.isBotChat(visitor_driver))
			{
				result.put("BOTS30",true);
				etest.log(Status.PASS,"Bot '"+bot1+"' picked up chat for configured website '"+website1+"' ");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS30",false);
				etest.log(Status.FAIL,"Bot '"+bot1+"' did NOT pick up chat for configured website '"+website1+"' ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.setupChat(driver,visitor_driver,etest,website2_code,unique,ChatType.INITIATED);

			if(BotsVisitorSide.isBotChat(visitor_driver)==false)
			{
				result.put("BOTS31",true);
				etest.log(Status.PASS,"Bot '"+bot1+"' did NOT picked up chat for unconfigured website '"+website2+"' ");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS31",false);
				etest.log(Status.FAIL,"Bot '"+bot1+"' picked up chat for unconfigured website '"+website2+"' ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkBotDepartment(WebDriver driver,ExtentTest etest)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			BotsTab.toggleBot(driver,etest,bot2,false);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot1);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department1);
			TakeScreenshot.infoScreenshot(driver,etest);
			BotConfiguration.clickSave(driver);
			etest.log(Status.INFO,"Bot department configuration was set for the following department ONLY : "+department1);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,bot1))
			{
				result.put("BOTS32",true);
				etest.log(Status.PASS,"Bot '"+bot1+"' picked up chat for configured department '"+department1+"' ");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS32",false);
				etest.log(Status.FAIL,"Bot '"+bot1+"' did NOT pick up chat for configured department '"+department1+"' ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department2,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver)==false)
			{
				result.put("BOTS33",true);
				etest.log(Status.PASS,"Bot '"+bot1+"' did NOT picked up chat for unconfigured department '"+department2+"' ");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS33",false);
				etest.log(Status.FAIL,"Bot '"+bot1+"' picked up chat for unconfigured department '"+department2+"' ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);

		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static boolean check2BotsFor2Departments(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			

			BotsTab.toggleBot(driver,etest,bot1,true);
			BotsTab.toggleBot(driver,etest,bot2,true);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot1);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department1);
			BotConfiguration.clickSave(driver);
			TakeScreenshot.infoScreenshot(driver,etest);


			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot2);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department2);
			BotConfiguration.clickSave(driver);
			TakeScreenshot.infoScreenshot(driver,etest);


			visitor_driver=visitor_driver_manager.getDriver(driver);

			VisitorWindow.createPage(visitor_driver,website1_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,bot1))
			{
				etest.log(Status.PASS,"Bot '"+bot1+"' picked up chat for configured department '"+department1+"' ");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Bot '"+bot1+"' did NOT pick up chat for configured department '"+department1+"' ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department2,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,bot2))
			{
				etest.log(Status.PASS,"Bot '"+bot2+"' picked up chat for configured department '"+department2+"' ");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Bot '"+bot2+"' did NOT pick up chat for configured department '"+department2+"' ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkBotBusinessHours(WebDriver driver,ExtentTest etest,int business_hour_value)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			boolean isBotPickupDuringBusinessHours=false,isBotPickupAfterBusinessHours=false,isChatWidgetExpectedOfflineAfterBusinessHours=false;

			if(business_hour_value==BotConfiguration.ALL_TIME_BUSINESS_HOUR_VALUE)
			{
				isBotPickupDuringBusinessHours=true;
				isBotPickupAfterBusinessHours=true;
				isChatWidgetExpectedOfflineAfterBusinessHours=false;
			}
			else if(business_hour_value==BotConfiguration.STANDARD_BUSINESS_HOUR_VALUE)
			{
				isBotPickupDuringBusinessHours=true;
				isBotPickupAfterBusinessHours=false;
				isChatWidgetExpectedOfflineAfterBusinessHours=true;
			}
			else if(business_hour_value==BotConfiguration.NON_BUSINESS_HOUR_VALUE)
			{
				isBotPickupDuringBusinessHours=false;
				isBotPickupAfterBusinessHours=true;
				isChatWidgetExpectedOfflineAfterBusinessHours=false;
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("This method does not support the business_hour_value : "+business_hour_value);
			}

			BotsTab.toggleBot(driver,etest,bot1,true);
			BotsTab.toggleBot(driver,etest,bot2,false);

			//need to change
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot1);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department1,department2);
			BotConfiguration.setBusinessHourConfig(driver,business_hour_value);
			BotConfiguration.clickSave(driver);
			etest.log(Status.INFO,"Business hours toggle for bot '"+bot1+"' is set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);

			//check after bh
			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,true);
			Company.toggleHideChatWidget(driver,false);
			BusinessHours.setPastTimeAsBusinessHour(driver,etest);
			BusinessHours.saveBusinessHourSettings(driver);
			etest.log(Status.INFO,"Business hours was set as current time in company settings");

			CommonUtil.sleep(5000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);

			if(isChatWidgetExpectedOfflineAfterBusinessHours)
			{
				boolean isChatOffline=VisitorWindow.checkChatWidgetOffline(visitor_driver);

				if(isChatOffline==isChatWidgetExpectedOfflineAfterBusinessHours)
				{
					etest.log(Status.PASS,"Chat widget was "+(isChatOffline?"shown as":"NOT shown as")+" offline state after 'allow bots after business hours' config was set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Chat widget was "+(isChatOffline?"NOT shown as":"shown as")+" offline state after 'allow bots after business hours' config was set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}
			else
			{
				VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

				if(BotsVisitorSide.isBotChat(visitor_driver)==isBotPickupAfterBusinessHours)
				{
					etest.log(Status.PASS,"Bot '"+bot1+"' "+(isBotPickupAfterBusinessHours?"picked up":"did NOT pick up")+" chat after business hours when business hour was set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);
					TakeScreenshot.infoScreenshot(driver,etest);
					TakeScreenshot.infoScreenshot(visitor_driver,etest);
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Bot '"+bot1+"' "+(isBotPickupAfterBusinessHours?"did NOT pick up":"picked up")+" chat after business hours when business hour was set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}

			if(isBotPickupAfterBusinessHours==false && isChatWidgetExpectedOfflineAfterBusinessHours==false)
			{
				try
				{
					ChatWindow.ignoreChat(driver);
				}
				catch(Exception e)
				{
					CommonUtil.doNothing();
				}
			}

			//check during bh
			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,true);
			Company.toggleHideChatWidget(driver,false);
			BusinessHours.setCurrentTimeAsBusinessHour(driver,etest);
			BusinessHours.saveBusinessHourSettings(driver);
			etest.log(Status.INFO,"Business hours was set as current time in company settings");

			CommonUtil.sleep(5000);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);

			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver)==isBotPickupDuringBusinessHours)
			{
				etest.log(Status.PASS,"Bot '"+bot1+"' "+(isBotPickupDuringBusinessHours?"picked up":"did NOT pick up")+" chat during business hours when business hour was set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Bot '"+bot1+"' "+(isBotPickupDuringBusinessHours?"did NOT pick up":"picked up")+" chat during business hours when business hour was set as "+BotConfiguration.BUSINESS_HOUR_VALUES[business_hour_value]);
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(isBotPickupDuringBusinessHours==false)
			{
				try
				{
					ChatWindow.ignoreChat(driver);
				}
				catch(Exception e)
				{
					CommonUtil.doNothing();
				}
			}

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	/*

	public static void checkWebsiteConfiguration(WebDriver driver,ExtentTest etest,int website_config)
	{
		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		boolean
		isBotAnswerWhenAvailable=false,
		isBotAnswerWhenBusy=false,
		isBotAnswerWhenOffline=false,
		isBotAnswerWhenEngaged=false
		;

		try
		{
			BotsTab.toggleBot(driver,etest,bot1,true);
			BotsTab.toggleBot(driver,etest,bot2,false);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot1);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department1,department2);
			BotConfiguration.clickSave(driver);

			//configure website
			Websites.setBotConfigForWebsite(driver,etest,website1,website_config);

			if(website_config==BotsVisitorSide.BOT_ANSWERS_NONE)
			{
				isBotAnswerWhenAvailable=false;
				isBotAnswerWhenBusy=false;
				isBotAnswerWhenOffline=false;
				isBotAnswerWhenEngaged=false;
			}
			if(website_config==BotsVisitorSide.BOT_ANSWERS_ALL)
			{
				isBotAnswerWhenAvailable=true;
				isBotAnswerWhenBusy=true;
				isBotAnswerWhenOffline=true;
				isBotAnswerWhenEngaged=true;
			}
			if(website_config==BotsVisitorSide.BOT_ANSWERS_WHEN_BUSY)
			{
				isBotAnswerWhenAvailable=false;
				isBotAnswerWhenBusy=true;
				isBotAnswerWhenOffline=true;
				isBotAnswerWhenEngaged=true;
			}

			boolean isBotPickup;
			AgentStatus status;

			// check when agent offline
			visitor_driver=visitor_driver_manager.getDriver(driver);

			status=AgentStatus.OFFLINE;
			Status.makeAgentAs(driver,etest,status);
			CommonUtil.sleep(5000);//wait till chat widget offline
			isBotPickup=isBotChat(driver,visitor_driver,etest,website1_code);

			if(isBotPickup==isBotAnswerWhenOffline)
			{
				etest.log(Status.PASS,"Bot behaved in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenOffline+") ");
				result.put("BOTS_WB_"+website_config+"_1",true);
			}
			else
			{
				result.put("BOTS_WB_"+website_config+"_1",false);
				etest.log(Status.FAIL,"Bot did NOT behave in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenOffline+") ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			ChatWindow.ignoreAllIncomingChats(driver);//just to make sure test is not affected due to chat notification UI

			Status.makeAgentAs(driver,etest,AgentStatus.AVAILABLE);

			//check when agent busy
			visitor_driver=visitor_driver_manager.getDriver(driver);

			status=AgentStatus.BUSY;
			Status.makeAgentAs(driver,etest,status);
			isBotPickup=isBotChat(driver,visitor_driver,etest,website1_code);

			if(isBotPickup==isBotAnswerWhenBusy)
			{
				etest.log(Status.PASS,"Bot behaved in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenBusy+") ");
				result.put("BOTS_WB_"+website_config+"_2",true);
			}
			else
			{
				result.put("BOTS_WB_"+website_config+"_2",false);
				etest.log(Status.FAIL,"Bot did NOT behave in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenBusy+") ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			ChatWindow.ignoreAllIncomingChats(driver);//just to make sure test is not affected due to chat notification UI

			//check when agent engaged
			visitor_driver=visitor_driver_manager.getDriver(driver);

			status=AgentStatus.ENGAGED;
			Status.makeAgentAs(driver,etest,status);
			isBotPickup=isBotChat(driver,visitor_driver,etest,website1_code);

			if(isBotPickup==isBotAnswerWhenEngaged)
			{
				etest.log(Status.PASS,"Bot behaved in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenEngaged+") ");
				result.put("BOTS_WB_"+website_config+"_3",true);			
			}
			else
			{
				result.put("BOTS_WB_"+website_config+"_3",false);
				etest.log(Status.FAIL,"Bot did NOT behave in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenEngaged+") ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			ChatWindow.ignoreAllIncomingChats(driver);//just to make sure test is not affected due to chat notification UI

			//check when agent available
			visitor_driver=visitor_driver_manager.getDriver(driver);

			status=AgentStatus.AVAILABLE;
			Status.makeAgentAs(driver,etest,status);
			isBotPickup=isBotChat(driver,visitor_driver,etest,website1_code);

			if(isBotPickup==isBotAnswerWhenAvailable)
			{
				etest.log(Status.PASS,"Bot behaved in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenAvailable+") ");
				result.put("BOTS_WB_"+website_config+"_4",true);
			}
			else
			{
				result.put("BOTS_WB_"+website_config+"_4",false);
				etest.log(Status.FAIL,"Bot did NOT behave in expected manner when agent was "+status+". (actual isBotPickup : "+isBotPickup+" ,expected isBotPickup : "+isBotAnswerWhenAvailable+") ");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	*/

	public static boolean isBotChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String widget_code) throws Exception
	{
		String unique=CommonUtil.getUniqueMessage();
		VisitorWindow.createPage(visitor_driver,widget_code);
		VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

		if(BotsVisitorSide.isBotChat(visitor_driver))
		{
			etest.log(Status.INFO,"Bot picked up chat");
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			return true;
		}
		else
		{
			etest.log(Status.INFO,"Bot did NOT pick up chat");
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			return false;
		}	
	}

	//connect to human
	public static boolean checkBotConnectToHuman(WebDriver driver,ExtentTest etest,Boolean isConnectToHumanConfig,Boolean isConnectToHumanInVisitorSide)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String visitor_side_usecase=null,agent_side_usecase=null,chat_notification_content_usecase="BOTS41",disable_connect_to_human_in_bot_config_usecase="BOTS42";

		try
		{
			try
			{
				CommonUtil.refreshPage(driver);
				ChatWindow.closeAllChats(driver);
				etest.log(Status.INFO,"All chats are closed");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			catch(Exception e)
			{
				etest.log(Status.WARNING,"Some chats may not be closed");
				TakeScreenshot.infoScreenshot(driver,etest);
				e.printStackTrace();
			}
			BotsTab.toggleBot(driver,etest,bot1,true);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot1);
			BotConfiguration.selectWebsite(driver,website1);
			BotConfiguration.selectDepartment(driver,department1,department2);
			BotConfiguration.setConnectToHumanConfig(driver,isConnectToHumanConfig);
			BotConfiguration.clickSave(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);

			String visitor_name="V"+unique;

			VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver)==false)
			{
				throw new ZohoSalesIQRuntimeException("Bot was expected to pick up the chat. But it did not!!");
			}

			if(isConnectToHumanInVisitorSide!=null)
			{
				if(isConnectToHumanInVisitorSide)
				{
					visitor_side_usecase="BOTS37";
					agent_side_usecase="BOTS39";
				}
				else
				{
					visitor_side_usecase="BOTS38";
					agent_side_usecase="BOTS40";
				}

				BotsVisitorSide.setConnectToHuman(visitor_driver,etest,isConnectToHumanInVisitorSide);

				if(BotsVisitorSide.isBotForwardedInfoMessageShown(visitor_driver)==isConnectToHumanInVisitorSide)
				{
					etest.log(Status.PASS,"Bot forwarded info message was "+(isConnectToHumanInVisitorSide?"shown":"NOT shown")+" in visitor side");
					result.put(visitor_side_usecase,true);
					TakeScreenshot.infoScreenshot(visitor_driver,etest);
				}
				else
				{
					etest.log(Status.FAIL,"Bot forwarded info message was "+(isConnectToHumanInVisitorSide?"NOT shown":"shown")+" in visitor side");
					result.put(visitor_side_usecase,false);
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}

				if(ChatWindow.isBotTransferRequestReceived(driver,etest,visitor_name)==isConnectToHumanInVisitorSide)
				{
					etest.log(Status.PASS,"Bot forwarded chat was "+(isConnectToHumanInVisitorSide?"forwarded":"NOT forwarded")+" to "+ExecuteStatements.getUserName(driver));
					result.put(agent_side_usecase,true);
					TakeScreenshot.infoScreenshot(driver,etest);
				}
				else
				{
					result.put(agent_side_usecase,false);
					etest.log(Status.FAIL,"Bot forwarded chat was "+(isConnectToHumanInVisitorSide?"NOT forwarded":"forwarded")+" to "+ExecuteStatements.getUserName(driver));
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
					failcount++;
				}

				if(isConnectToHumanInVisitorSide)
				{
					try
					{
						ChatWindow.handleBotTransfer(driver,true);
					}
					catch(Exception e)
					{
						CommonUtil.doNothing();
					}
					ChatWindow.closeAllChats(driver);
				}

				// if(isConnectToHumanInVisitorSide)
				// {
				// 	result.put(chat_notification_content_usecase,ChatWindow.isBotToHumanChatTransferNotification(driver,etest));
				// }
			}
			else
			{
				if(BotsVisitorSide.isConnectToHumanShown(visitor_driver)==false)
				{
					etest.log(Status.PASS,"Connect to human prompt was not shown in visitor side after it was disabled in bot config");
					result.put(disable_connect_to_human_in_bot_config_usecase,true);
				}
				else
				{
					etest.log(Status.FAIL,"Connect to human prompt was SHOWN in visitor side after it was disabled in bot config");
					result.put(disable_connect_to_human_in_bot_config_usecase,false);
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

}
