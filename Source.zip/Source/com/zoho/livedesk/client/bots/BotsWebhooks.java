//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import java.util.Arrays;
import com.zoho.livedesk.util.common.DateTimeUtil;
import com.zoho.livedesk.util.ServerTunnel;
import com.zoho.livedesk.util.Webhook;
import com.zoho.livedesk.client.SalesIQRestAPI.*;

public class BotsWebhooks
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Webhook";

	public static final String
	INVALID_URL="https://www.aklsdj09ds.com",
	REPLY="REPLY",
	BOT1=BotsWidgets.BOT1
	;

	public static String articleid1="Article not created 1",articleid2="Article not created 2",unpublished_article_id="Article not created 3",article_label1,article_label2,unpublished_article_label;

	public static String
	webhook_url=null,webhookauth_url=null,website=null,widget_code=null,department=null,bot_unique_message=null;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			website=ExecuteStatements.getDefaultEmbedName(driver);	
			widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			bot_unique_message=CommonUtil.getUniqueMessage();
			Webhook.setBotUniqueMessage(bot_unique_message);

			webhook_url=ServerTunnel.getTunnelURL()+"/webhook";
			webhookauth_url=ServerTunnel.getTunnelURL()+"/webhookauth";

            result = new Hashtable<String,Boolean>();

			etest=ComplexReportFactory.getTest("Create webhook bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			createWebhookBot(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Secure webhook usecases");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			secureWebhookBot(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Setup widgets bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBots(driver,etest);
			setupWidgetBot(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS257"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS257", BotsWidgets.checkSliderWidget(driver,etest,website,department));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS258"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS258", BotsWidgets.checkRangeSliderWidget(driver,etest,website,department));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS253"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS253", BotsWidgets.checkHappinessRatingWidget(driver,etest,3,website,department));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS254"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS254", BotsWidgets.checkHappinessRatingWidget(driver,etest,5,website,department));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check like rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkLikeWidget(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check star rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkStarRating(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check single select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSingleSelect(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check multi select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkMultiSelect(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTimeslots(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check date-time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDateTimeslots(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCalendar(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check range calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRangeCalendar(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS287"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS287", BotsWidgets.checkLinkWidget(driver,etest,website,department,bot_unique_message));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS288"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS288", BotsWidgets.checkImageWidget(driver,etest,website,department,bot_unique_message));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS289"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS289", BotsWidgets.checkArticlesWidget(driver,etest,website,department,articleid1,articleid2,unpublished_article_id,article_label1,article_label2,unpublished_article_label,bot_unique_message));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check visitor field name update from Bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkVisitorFieldNames(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check input validation");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkInputValidation(driver,etest,website,department);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);
        }
            
		catch(Exception e)
		{	
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			CommonUtil.printStackTrace(e);
			DelugeScript.close(driver);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void createWebhookBot(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			Tab.navToBotsTab(driver);
			BotsTab.clickAddBot(driver);

			String bot_name="WHBot"+label;
	        BotConfiguration.editBotName(driver,bot_name);
         	BotConfiguration.editBotDescription(driver,"desc"+label);
     		BotConfiguration.selectWebsite(driver,website);
     		BotConfiguration.clearCurrentTriggers(driver);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.WEBHOOK_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI466.png","UI466",etest);

         	BotConfiguration.openWebhookConfiguration(driver);

         	if(!WebhookConfiguration.setURL(driver,etest,INVALID_URL))
         	{
         		result.put("BOTS234",true);
         		etest.log(Status.PASS,"Webhook was not activated for invalid url : "+INVALID_URL);
         	}
         	else
         	{
         		result.put("BOTS234",false);
         		etest.log(Status.FAIL,"Webhook was activated for invalid url : "+INVALID_URL);
         		TakeScreenshot.screenshot(driver,etest);      		
         	}

         	CommonUtil.waitTillURLValid(webhookauth_url);
         	if(WebhookConfiguration.setURL(driver,etest,webhookauth_url))
         	{
         		result.put("BOTS235",true);
         		etest.log(Status.PASS,"Webhook was activated for valid url : "+webhookauth_url);
         	}
         	else
         	{
         		result.put("BOTS235",false);
         		etest.log(Status.FAIL,"Webhook was NOT activated for valid url : "+webhookauth_url);
         		TakeScreenshot.screenshot(driver,etest);      		
         	}

         	result.put("BOTS231",WebhookConfiguration.verifyIntroductionContent(driver,etest));
         	result.put("BOTS232",WebhookConfiguration.verifyInstructionContent(driver,etest));
         	result.put("BOTS233",WebhookConfiguration.verifySecureWebhookContent(driver,etest));

	        CommonUtil.scrollIntoView(driver,true,WebhookConfiguration.COPY_TO_CLIPBOARD);
        	CommonSikuli.findInWholePage(driver,"UI469.png","UI469",etest);

         	etest.log(Status.INFO,"Now checking modifying URL usecases");

         	if(!WebhookConfiguration.setURL(driver,etest,INVALID_URL))
         	{
         		result.put("BOTS238",true);
         		etest.log(Status.PASS,"Webhook was not activated for invalid url : "+INVALID_URL);
         	}
         	else
         	{
         		result.put("BOTS238",false);
         		etest.log(Status.FAIL,"Webhook was activated for invalid url : "+INVALID_URL);
         		TakeScreenshot.screenshot(driver,etest);      		
         	}

         	CommonUtil.waitTillURLValid(webhook_url);
         	if(WebhookConfiguration.setURL(driver,etest,webhook_url))
         	{
         		result.put("BOTS239",true);
         		etest.log(Status.PASS,"Webhook was activated for valid url : "+webhook_url);
         	}
         	else
         	{
         		result.put("BOTS239",false);
         		etest.log(Status.FAIL,"Webhook was NOT activated for valid url : "+webhook_url);
         		TakeScreenshot.screenshot(driver,etest);      		
         	}

         	DelugeScript.resetPreviewChat(driver);
			BotsVisitorSide.waitTillBotReplies(driver);

			etest.log(Status.INFO,"Now checking bot replies and trigger message in preview chat");

			int failcount=0;

			String expected_message="trigger"+bot_unique_message;
			String actual_message=VisitorWindow.getLastMessage(driver);

			if(CommonUtil.isContains(expected_message,actual_message))
			{
				etest.log(Status.PASS,"Bot was triggered in preview chat");
			}
			else
			{
				etest.log(Status.FAIL,"Bot was NOT triggered in preview chat");
				failcount++;
				TakeScreenshot.screenshot(driver,etest);				
			}

			VisitorWindow.sentMessageInTheme(driver,REPLY,true);
			BotsVisitorSide.waitTillBotReplies(driver);
			actual_message=VisitorWindow.getLastMessage(driver);
			expected_message=bot_unique_message;

			if(CommonUtil.isEquals(expected_message,actual_message))
			{
				etest.log(Status.PASS,"Expected reply was found for webhook bot");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Expected reply was NOT found for webhook bot");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			result.put("BOTS236",CommonUtil.returnResult(failcount));

         	WebhookConfiguration.publish(driver);
         	WebhookConfiguration.close(driver);

			Tab.navToBotsTab(driver);

        	CommonSikuli.findInWholePage(driver,"UI467.png","UI467",etest);

			BotsTab.openBotConfiguration(driver,bot_name);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.WEBHOOK_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI468.png","UI468",etest);

			BotConfiguration.triggerBotForAll(driver,etest);
			etest.log(Status.INFO,bot_name+" is set to trigger for all visitors.");	

			etest.log(Status.INFO,"Now checking bot replies and trigger message in visitor chat");

			failcount=0;

			//check in visitor
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);

			//trigger the bot
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			actual_message=VisitorWindow.getLastMessage(visitor_driver);

			if(CommonUtil.isContains(expected_message,actual_message))
			{
				etest.log(Status.PASS,"Bot was triggered in visitor side");
			}
			else
			{
				etest.log(Status.FAIL,"Bot was NOT triggered in visitor side");
				TakeScreenshot.screenshot(visitor_driver,etest);				
				failcount++;
			}

			VisitorWindow.sentMessageInTheme(visitor_driver,REPLY,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_message=VisitorWindow.getLastMessage(visitor_driver);
			expected_message=bot_unique_message;

			if(CommonUtil.isEquals(expected_message,actual_message))
			{
				etest.log(Status.PASS,"Expected reply was found for webhook bot");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Expected reply was NOT found for webhook bot");
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			result.put("BOTS237",CommonUtil.returnResult(failcount));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	public static void secureWebhookBot(WebDriver driver,ExtentTest etest)
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();

			Tab.navToBotsTab(driver);
			BotsTab.clickAddBot(driver);

			String bot_name="WHBot"+label;
	        BotConfiguration.editBotName(driver,bot_name);
         	BotConfiguration.editBotDescription(driver,"desc"+label);
     		BotConfiguration.selectWebsite(driver,website);
     		BotConfiguration.clearCurrentTriggers(driver);
         	BotConfiguration.openWebhookConfiguration(driver);

         	CommonUtil.waitTillURLValid(webhookauth_url);
         	if(!WebhookConfiguration.setURL(driver,etest,webhookauth_url))
         	{
         		etest.log(Status.FAIL,"Webhook was NOT activated for url : "+webhookauth_url);
         		TakeScreenshot.screenshot(driver,etest);      		
         	}

         	etest.log(Status.INFO,"SETTING SECURE TOGGLE ON AND CHECKING IF SIGNATURE VERIFICATION PASSES");

         	WebhookConfiguration.setSecureToggle(driver,etest,true);

         	String used_public_key=WebhookConfiguration.getUsedPublicKey(driver,etest);

         	VerifySignature.setBotPublicKey(used_public_key);

         	WebhookConfiguration.publish(driver);
         	WebhookConfiguration.close(driver);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS240",checkSignatureMessage(visitor_driver,used_public_key,true));

         	etest.log(Status.INFO,"SETTING SECURE TOGGLE ON AND CHECKING IF SIGNATURE VERIFICATION FAILS WHEN CALLED FROM EXTERNAL SOURCE");

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			visitor_driver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(visitor_driver,"access","get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(visitor_driver,webhookauth_url);
			SalesIQRestAPICommonFunctions.sendAPIRequest(visitor_driver);
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(visitor_driver);
			result.put("BOTS242",checkSignatureMessage(visitor_driver,used_public_key,false,response));

         	etest.log(Status.INFO,"SETTING SECURE TOGGLE OFF AND CHECKING IF SIGNATURE VERIFICATION FAILS");

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot_name);
			BotConfiguration.openWebhookConfiguration(driver);

         	VerifySignature.setBotPublicKey(used_public_key);
         	WebhookConfiguration.setSecureToggle(driver,etest,false);
         	WebhookConfiguration.close(driver);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS241",checkSignatureMessage(visitor_driver,used_public_key,false));

         	etest.log(Status.INFO,"CHECKING IF CURRENT PUBLIC KEY IS WORKING AFTER NEW KEY CREATION");

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,bot_name);
			BotConfiguration.openWebhookConfiguration(driver);
         	VerifySignature.setBotPublicKey(used_public_key);
         	WebhookConfiguration.setSecureToggle(driver,etest,true);
			WebhookConfiguration.createKey(driver,etest);
			CommonUtil.sleep(1000);
         	String unused_public_key=WebhookConfiguration.getUnusedPublicKey(driver,etest);
         	etest.log(Status.INFO,"Newly created key is :"+unused_public_key);

         	result.put("BOTS248",WebhookConfiguration.isInUseFlagFoundForCurrentKey(driver,etest));

         	VerifySignature.setBotPublicKey(used_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS243",checkSignatureMessage(visitor_driver,used_public_key,true));

         	etest.log(Status.INFO,"CHECKING IF NEW PUBLIC KEY IS NOT WORKING AFTER NEW KEY CREATION");

         	VerifySignature.setBotPublicKey(unused_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS244",checkSignatureMessage(visitor_driver,unused_public_key,false));

         	etest.log(Status.INFO,"CHECKING IF DELETED IN-USE PUBLIC KEY IS NOT WORKING");

			WebhookConfiguration.deleteKey(driver,etest,true);
         	VerifySignature.setBotPublicKey(used_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS246",checkSignatureMessage(visitor_driver,used_public_key,false));

         	etest.log(Status.INFO,"CHECKING IF CURRENT IN-USE PUBLIC KEY ASSIGNED AFTER DELETION OF PREVIOUS IN-USE KEY IS WORKING");

         	used_public_key=WebhookConfiguration.getUsedPublicKey(driver,etest);
         	VerifySignature.setBotPublicKey(used_public_key);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+label,"V"+label+"@emailed.com",null,department,"Q"+label,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			result.put("BOTS245",checkSignatureMessage(visitor_driver,used_public_key,true));

			// WebhookConfiguration.copyKeyToClipboard(driver,etest,true);
			// String clipboard_text=CommonUtil.getTextFromClipboard(driver,etest);
			// result.put("BOTS247",CommonUtil.checkStringContainsAndLog(used_public_key,clipboard_text,"text in clipboard",etest));

         	WebhookConfiguration.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}
	}

	public static void setupWidgetBot(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Tab.navToBotsTab(driver);
			BotsTab.clickAddBot(driver);

			String bot_name=BOT1;
	        BotConfiguration.editBotName(driver,bot_name);
         	BotConfiguration.editBotDescription(driver,"desc"+label);
     		BotConfiguration.selectWebsite(driver,website);
     		BotConfiguration.clearCurrentTriggers(driver);
         	BotConfiguration.openWebhookConfiguration(driver);

         	CommonUtil.waitTillURLValid(webhook_url);
         	if(!WebhookConfiguration.setURL(driver,etest,webhook_url))
         	{
         		etest.log(Status.FAIL,"Webhook was NOT activated for url : "+webhook_url);
         		TakeScreenshot.screenshot(driver,etest);      		
         	}

         	WebhookConfiguration.publish(driver);
         	WebhookConfiguration.close(driver);

 			//articles setup
			{
				Cleanup.deleteAllArticles(driver);
				article_label1="1_"+bot_unique_message;
				article_label2="2_"+bot_unique_message;
				unpublished_article_label="UNPUBLISHED_"+bot_unique_message;

				try
				{
					Tab.navToArticlesTab(driver);
					Articles.quickPublishArticle(driver,etest,article_label1);
					articleid1=Articles.getArticleIdByLabel(driver,article_label1);

					Tab.navToArticlesTab(driver);
					Articles.quickPublishArticle(driver,etest,article_label2);
					articleid2=Articles.getArticleIdByLabel(driver,article_label2);

			        Hashtable<String,String> article_data=Articles.getArticleDataByLabel(unpublished_article_label);
			        Articles.addNewArticle(driver,etest,article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),new String[]{website},article_data.get(Articles.CATEGORY),Articles.SAVE);
					unpublished_article_id=Articles.getArticleIdByLabel(driver,unpublished_article_label);

					Webhook.setArticleIds(articleid1,articleid2,unpublished_article_id);

					etest.log(Status.INFO,"Articles with article ids("+articleid1+","+articleid2+") are published and article with article id '"+unpublished_article_id+"' has been saved as draft");
				}
				catch(Exception e)
				{
					etest.log(Status.WARNING,"Articles could not be configured properly. So Articles widget usecase will fail");
					CommonUtil.printStackTrace(e);
					TakeScreenshot.screenshot(driver,etest,e);
				}
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

    public static boolean checkSignatureMessage(WebDriver visitor_driver,String public_key,boolean isSignatureVerified)
    {
    	return checkSignatureMessage(visitor_driver,etest,public_key,isSignatureVerified,null);
    }

    public static boolean checkSignatureMessage(WebDriver visitor_driver,ExtentTest etest,String public_key,boolean isSignatureVerified)
    {
    	return checkSignatureMessage(visitor_driver,etest,public_key,isSignatureVerified,null);
    }

    public static boolean checkSignatureMessage(WebDriver visitor_driver,String public_key,boolean isSignatureVerified,String actual)
    {
    	return checkSignatureMessage(visitor_driver,etest,public_key,isSignatureVerified,actual);	
    }

    public static boolean checkSignatureMessage(WebDriver visitor_driver,ExtentTest etest,String public_key,boolean isSignatureVerified,String actual)
    {
        String expected="Signature was"+(isSignatureVerified?" ":" NOT ")+"verified succesfully with public key --> "+public_key;
        	
        if(actual==null)
        {
	        actual=VisitorWindow.getLastMessage(visitor_driver);
        }	

        if(CommonUtil.isContains(expected,actual))
        {
            if(isSignatureVerified)
            {
                etest.log(Status.PASS,"Signature was verified for public key --> "+public_key);
            }
            else
            {
                etest.log(Status.PASS,"Signature was NOT verified for public key --> "+public_key);                
            }
            TakeScreenshot.infoScreenshot(visitor_driver,etest);

            return true;
        }
        else
        {
            if(isSignatureVerified)
            {
                etest.log(Status.FAIL,"Signature was NOT verified for public key --> "+public_key);
            }
            else
            {
                etest.log(Status.FAIL,"Signature was verified for public key --> "+public_key);                
            }
            TakeScreenshot.screenshot(visitor_driver,etest);

            return false;
        }
    }

	public static void checkLikeWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkLikeWidget(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkStarRating(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkStarRating(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkSingleSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkSingleSelect(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkMultiSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkMultiSelect(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkTimeslots(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkDateTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkDateTimeslots(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkCalendar(driver,etest,bot_unique_message,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkRangeCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkRangeCalendar(driver,etest,bot_unique_message,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkVisitorFieldNames(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkVisitorFieldNames(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void checkInputValidation(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkInputValidation(driver,etest,website,department,BotsWidgets.WEBHOOK_BOT);
        result.putAll(widget_result);
	}

	public static void startTunnel()
	{
        for(int i=0;i<=3;i++)
        {
            ServerTunnel.startTunnel();
            
            if(ServerTunnel.isTunnelOpen())
            {
                break;
            }
        }
	}
}
