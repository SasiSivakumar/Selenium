//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;

public class BotPublish
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots Publish";
	public static String widgetcode="",website="";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager(true);

            result = new Hashtable<String,Boolean>();

            String widget_code=ExecuteStatements.getWidgetCode(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS66"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS66", checkPublishInfoInBotsTab(driver,etest,widget_code,false,false,false) );
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS67"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS67", checkPublishInfoInBotsTab(driver,etest,widget_code,true,false,false) );
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS68"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS68", checkPublishInfoInBotsTab(driver,etest,widget_code,false,false,true) );
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS69"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS69", checkPublishInfoInBotsTab(driver,etest,widget_code,false,true,false) );
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS70"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS70", checkPublishInfoInBotsTab(driver,etest,widget_code,true,true,true) );
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			etest=ComplexReportFactory.getTest("Save all handlers and check if changes affected in preview window and not in visitor window, Publish all handlers and check if changes affected in visitor window");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSaveAndPublishInPreviewAndVisitor(driver,etest,widget_code);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Cleanup.deleteAllBots(driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static boolean checkPublishInfoInBotsTab(WebDriver driver,ExtentTest etest,String widget_code,boolean isPublishMessageHandler,boolean isPublishTriggerHandler,boolean isPublishContextHandler)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);
			String dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String bot_name="Bot_"+unique;
			String publish_action=null;
			String handler_name=null;
			String resource_key=null;

			if(isPublishMessageHandler && isPublishTriggerHandler && isPublishContextHandler)
			{
				publish_action=BotInfo.PUBLISH_ALL_HANDLERS;
				handler_name="Message handler,Trigger handler,Context handler";
			}
			else if(isPublishMessageHandler)
			{
				publish_action=BotInfo.PUBLISH_MESSAGE_HANDLER;
				handler_name="Message handler";
			}
			else if(isPublishTriggerHandler)
			{
				publish_action=BotInfo.PUBLISH_TRIGGER_HANDLER;
				handler_name="Trigger handler";
			}
			else if(isPublishContextHandler)
			{
				publish_action=BotInfo.PUBLISH_CONTEXT_HANDLER;
				handler_name="Context handler";
			}
			else
			{
				publish_action=BotInfo.CREATE_ONLY;	
				resource_key="bot_yet_to_publish";
			}

			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(bot_name,BotInfo.CREATE_ONLY,website,dept);

			BotConfiguration.createBot(driver,etest,bot_info);

			if(publish_action.equals(BotInfo.CREATE_ONLY)==false)
			{
				BotsTab.openBotConfiguration(driver,bot_info.get(BotInfo.NAME));
				BotConfiguration.clickOpenSalesIQScript(driver);

				DelugeScript.publishHandler(driver,publish_action);
				etest.log(Status.INFO,"Publish button was clicked from "+handler_name);
				DelugeScript.close(driver);
			}
			else
			{
				etest.log(Status.INFO,"Publish button was not clicked");
			}

			Hashtable<String,String> actual_bot_info=BotInfo.getBotConfig(driver,etest,bot_name);

			if(!isPublishMessageHandler && !isPublishTriggerHandler && !isPublishContextHandler)
			{
				String actual_publish_status=BotInfo.getBotConfig(driver,etest,bot_name).get(BotInfo.PUBLISH_STATUS);
				String expected_publish_status=ResourceManager.getRealValue(resource_key);

				if(CommonUtil.checkStringContainsAndLog(expected_publish_status,actual_publish_status,"publish status for bot '"+bot_name+"'",etest)==false)
				{
					failcount++;
				}
			}

			boolean isAnyOneHandlerPublished=(isPublishMessageHandler || isPublishContextHandler || isPublishTriggerHandler);

 			if(isAnyOneHandlerPublished==Boolean.parseBoolean(actual_bot_info.get(BotInfo.IS_MH_PUBLISHED)))
            {
                etest.log(Status.PASS,"Message handler "+(isAnyOneHandlerPublished?"was":"was NOT")+" published");
            }
            else
            {
                etest.log(Status.FAIL,"Message handler "+(isAnyOneHandlerPublished?"was NOT":"was")+" published");
                failcount++;
            }
 
            if(isAnyOneHandlerPublished==Boolean.parseBoolean(actual_bot_info.get(BotInfo.IS_TH_PUBLISHED)))
            {
                etest.log(Status.PASS,"Trigger handler "+(isAnyOneHandlerPublished?"was":"was NOT")+" published");
            }
            else
            {
                etest.log(Status.FAIL,"Trigger handler "+(isAnyOneHandlerPublished?"was NOT":"was")+" published");
                failcount++;
            }
 
            if(isAnyOneHandlerPublished==Boolean.parseBoolean(actual_bot_info.get(BotInfo.IS_CH_PUBLISHED)))
            {
                etest.log(Status.PASS,"Context handler "+(isAnyOneHandlerPublished?"was":"was NOT")+" published");
            }
            else
            {
                etest.log(Status.FAIL,"Context handler "+(isAnyOneHandlerPublished?"was NOT":"was")+" published");
                failcount++;
            }
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkSaveAndPublishInPreviewAndVisitor(WebDriver driver,ExtentTest etest,String widget_code)
	{
		final String unique=CommonUtil.getUniqueMessage();

		String message=unique;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widget_code);
			String dept=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String bot_name="Bot_"+unique;

			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(bot_name,BotInfo.CREATE_AND_PUBLISH,website,dept);

			BotConfiguration.createBot(driver,etest,bot_info);

			BotsTab.openBotConfiguration(driver,bot_info.get(BotInfo.NAME));

			BotConfiguration.triggerBotForAll(driver,etest);
			etest.log(Status.INFO,bot_name+" is set to trigger for all visitors.");

			BotConfiguration.clickOpenSalesIQScript(driver);

			final String
			mh_code=BotScripts.getBotCode(BotScripts.BASIC_ALL_HANDLERS_CODE,BotScripts.MESSAGE_HANDLER).replace(BotScripts.BOT_REPLY_MESSAGE,message),
			ch_code=BotScripts.getBotCode(BotScripts.BASIC_ALL_HANDLERS_CODE,BotScripts.CONTEXT_HANDLER),
			th_code=BotScripts.getBotCode(BotScripts.BASIC_ALL_HANDLERS_CODE,BotScripts.TRIGGER_HANDLER).replace(BotScripts.BOT_REPLY_MESSAGE,message)
			;

			DelugeScript.changeHandlerView(driver,DelugeScript.MESSAGE_HANDLER);
			DelugeScript.sendKeysToScript(driver,mh_code);
			DelugeScript.clickSave(driver);

			DelugeScript.changeHandlerView(driver,DelugeScript.CONTEXT_HANDLER);
			BotScripts.copyToClipboard(driver,etest,ch_code);
			DelugeScript.pasteCodeInScript(driver,etest);
			DelugeScript.clickSave(driver);

			DelugeScript.changeHandlerView(driver,DelugeScript.TRIGGER_HANDLER);
			DelugeScript.sendKeysToScript(driver,th_code);
			DelugeScript.clickSave(driver);

			etest.log(Status.INFO,"All handlers were saved.");

			//check in preview chat

			DelugeScript.resetPreviewChat(driver);
			BotsVisitorSide.waitTillBotReplies(driver);
			String actual_trigger_message_preview_window=VisitorWindow.getLastMessage(driver);
			String expected_trigger_message_preview_window="trigger"+message;
			result.put("BOTS64", CommonUtil.checkStringContainsAndLog(expected_trigger_message_preview_window,actual_trigger_message_preview_window,"triggered bot message in preview window",etest) );

			TakeScreenshot.infoScreenshot(driver,etest);

			VisitorWindow.sentMessageInTheme(driver,"Hello",true);
			BotsVisitorSide.waitTillBotReplies(driver);
			String actual_message_preview_window=VisitorWindow.getLastMessage(driver);
			String expected_message_preview_window="question"+message;
			result.put("BOTS60", CommonUtil.checkStringContainsAndLog(expected_message_preview_window,actual_message_preview_window,"message handler bot message in preview window",etest) );

			TakeScreenshot.infoScreenshot(driver,etest);

			VisitorWindow.sentMessageInTheme(driver,message,true);
			BotsVisitorSide.waitTillBotReplies(driver);
			String actual_context_message_preview_window=VisitorWindow.getLastMessage(driver);
			String expected_context_message_preview_window="context"+message;
			result.put("BOTS62", CommonUtil.checkStringContainsAndLog(expected_context_message_preview_window,actual_context_message_preview_window,"context handler bot message in preview window",etest) );

			TakeScreenshot.infoScreenshot(driver,etest);


			//check in visitor
			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);

			//trigger the bot
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_trigger_message_preview_window=VisitorWindow.getLastMessage(visitor_driver);
			expected_trigger_message_preview_window="trigger"+message;

			if(CommonUtil.isContains(expected_trigger_message_preview_window,actual_trigger_message_preview_window)==false)
			{
				etest.log(Status.PASS,"Saved changes were not affected in visitor side for trigger handler");
				result.put("BOTS65",true);
			}
			else
			{
				etest.log(Status.FAIL,"Saved changes were affected in visitor side for trigger handler");
				result.put("BOTS65",false);
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			VisitorWindow.sentMessageInTheme(visitor_driver,"Hello",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_message_preview_window=VisitorWindow.getLastMessage(visitor_driver);
			expected_message_preview_window="question"+message;
			result.put("BOTS61", CommonUtil.checkStringNotEquals(expected_message_preview_window,actual_message_preview_window) );

			if(result.get("BOTS61")==true)
			{
				etest.log(Status.PASS,"Saved changes were not affected in visitor side for message handler");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"visitor_driver changes were published in visitor side for message handler");
				TakeScreenshot.screenshot(driver,etest);
			}

			VisitorWindow.sentMessageInTheme(visitor_driver,message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_context_message_preview_window=VisitorWindow.getLastMessage(visitor_driver);
			expected_context_message_preview_window="context"+message;
			result.put("BOTS63", CommonUtil.checkStringNotEquals(expected_context_message_preview_window,actual_context_message_preview_window) );

			if(result.get("BOTS63")==true)
			{
				etest.log(Status.PASS,"Saved changes were not affected in visitor side for context handler");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Saved changes were published in visitor side for context handler");
				TakeScreenshot.screenshot(driver,etest);
			}

			//publish changes

			DelugeScript.changeHandlerView(driver,DelugeScript.MESSAGE_HANDLER);
			DelugeScript.clickPublish(driver);

			DelugeScript.changeHandlerView(driver,DelugeScript.CONTEXT_HANDLER);
			DelugeScript.clickPublish(driver);

			DelugeScript.changeHandlerView(driver,DelugeScript.TRIGGER_HANDLER);
			DelugeScript.clickPublish(driver);

			//check in visitor

			visitor_driver=visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);

			//trigger the bot
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_trigger_message_preview_window=VisitorWindow.getLastMessage(visitor_driver);
			expected_trigger_message_preview_window="trigger"+message;
			result.put("BOTS71", CommonUtil.checkStringContainsAndLog(expected_trigger_message_preview_window,actual_trigger_message_preview_window,"triggered bot message in visitor window",etest) );

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			VisitorWindow.sentMessageInTheme(visitor_driver,"Hello",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_message_preview_window=VisitorWindow.getLastMessage(visitor_driver);
			expected_message_preview_window="question"+message;
			result.put("BOTS73", CommonUtil.checkStringContainsAndLog(expected_message_preview_window,actual_message_preview_window,"message handler bot message in visitor window",etest) );

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			VisitorWindow.sentMessageInTheme(visitor_driver,message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			actual_context_message_preview_window=VisitorWindow.getLastMessage(driver);
			expected_context_message_preview_window="context"+message;
			result.put("BOTS72", CommonUtil.checkStringContainsAndLog(expected_context_message_preview_window,actual_context_message_preview_window,"context handler bot message in visitor window",etest) );

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			DelugeScript.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

}
