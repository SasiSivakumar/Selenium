//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import java.util.Arrays;
import com.zoho.livedesk.util.common.DateTimeUtil;

public class BotsWidgets
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots Widgets",BOT1="Widget Bot",DEPARTMENT2="DEPARTMENT2";

	public static final int
	SALESIQ_BOT=0,
	DIALOGFLOW_BOT=1,
	ZIA_BOT=2,
	WEBHOOK_BOT=3,
	WATSON_BOT=4
	;

	public static String bot_unique_message,articleid1="Article not created 1",articleid2="Article not created 2",unpublished_article_id="Article not created 3",article_label1,article_label2,unpublished_article_label;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			String website1=ExecuteStatements.getDefaultEmbedName(driver);	
			String website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);
			String department1=ExecuteStatements.getSystemGeneratedDepartment(driver);
			bot_unique_message=CommonUtil.getUniqueMessage();

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Portal setup for bot widgets usecase");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			for(int i=0;i<=3;i++)
			{
				try
				{
					setup(driver,etest,website1,department1);
					break;
				}
				catch(Exception e)
				{
					CommonUtil.printStackTrace(e);
					TakeScreenshot.screenshot(driver,etest,e);
					if(i==3)
					{
						throw e;
					}
				}
			}

	        ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS82"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS82", checkSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS83"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS83", checkRangeSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS78"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS78", checkHappinessRatingWidget(driver,etest,3,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS79"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS79", checkHappinessRatingWidget(driver,etest,5,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check like rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkLikeWidget(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check star rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkStarRating(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check single select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSingleSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check multi select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkMultiSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check date-time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDateTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check range calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRangeCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);
            

            WebDriver driver2=Driver.getLinuxDriver();
            Functions.login(driver2,"bots3_supervisor");

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS177"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS177", checkForwardAction(driver,driver2,etest,false,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS178"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS178", checkForwardAction(driver,driver2,etest,true,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            WebDriver driver3=Driver.getLinuxDriver();
            Functions.login(driver3,"bots3_associate");

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS179"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS179", checkForwardToDepartmentAction(driver,driver2,driver3,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            Functions.logout(driver2);
            Functions.logout(driver3);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS174"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS174", checkLinkWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS175"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS175", checkImageWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS176"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS176", checkArticlesWidget(driver,etest,website1,department1,articleid1,articleid2,unpublished_article_id,article_label1,article_label2,unpublished_article_label));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS181"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS181", checkChatEndAction(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS180"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS180", checkBlockAction(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS114"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS114", checkContextHandler(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS118"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkGoogleConnection(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS119"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS119",checkCRMConnection(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);
        }
            
		catch(Exception e)
		{	
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			e.printStackTrace();
			DelugeScript.close(driver);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void setup(WebDriver driver,ExtentTest etest,String website,String department) throws Exception
	{

		//portal running this module must only have the following websites,depts and bots

		//dept setup
		{
			try
			{
				//create dept if not exists
				if(Department.isDepartmentNamePresent(driver,DEPARTMENT2)==false)
				{
					String user1=ExecuteStatements.getAgentNameByEmailID(driver,ConfManager.getRealValue("bots3_supervisor_username"));
					String user2=ExecuteStatements.getAgentNameByEmailID(driver,ConfManager.getRealValue("bots3_associate_username"));
					Department.addDept(driver,DEPARTMENT2,"depttype_publi",user1+"|"+user2,etest);
				}				
			}
			catch(Exception e)
			{
				etest.log(Status.WARNING,"Department could not be configured properly. So FORWARD_TO_DEPT usecase will fail");
				CommonUtil.printStackTrace(e);
				TakeScreenshot.screenshot(driver,etest,e);
			}
		}

		//articles setup
		{
			Cleanup.deleteAllArticles(driver);
			article_label1="1_"+bot_unique_message;
			article_label2="2_"+bot_unique_message;
			unpublished_article_label="UNPUBLISHED_"+bot_unique_message;

			try
			{
				Tab.navToArticlesTab(driver);
				Articles.quickPublishArticle(driver,etest,article_label1);
				articleid1=Articles.getArticleIdByLabel(driver,article_label1);

				Tab.navToArticlesTab(driver);
				Articles.quickPublishArticle(driver,etest,article_label2);
				articleid2=Articles.getArticleIdByLabel(driver,article_label2);

		        Hashtable<String,String> article_data=Articles.getArticleDataByLabel(unpublished_article_label);
		        Articles.addNewArticle(driver,etest,article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),new String[]{website},article_data.get(Articles.CATEGORY),Articles.SAVE);
				unpublished_article_id=Articles.getArticleIdByLabel(driver,unpublished_article_label);

				etest.log(Status.INFO,"Articles with article ids("+articleid1+","+articleid2+") are published and article with article id '"+unpublished_article_id+"' has been saved as draft");
			}
			catch(Exception e)
			{
				etest.log(Status.WARNING,"Articles could not be configured properly. So Articles widget usecase will fail");
				e.printStackTrace();
				TakeScreenshot.screenshot(driver,etest,e);
			}
		}
			
		if(BotsTab.isBotPresent(driver,BOT1)==false)
		{
			Hashtable<String,String> bot_info=BotInfo.getBotInfoHashtable(BOT1,"BOT1_DESC",BotInfo.CREATE_AND_PUBLISH,null,null,website,department,null,null);
			BotConfiguration.createBot(driver,etest,bot_info);
		}

		else if(BotsTab.isBotEnabled(driver,BOT1)==false)
		{
			BotsTab.toggleBot(driver,etest,BOT1,true);
		}

		Tab.navToBotsTab(driver);
		BotsTab.openBotConfiguration(driver,BOT1);
		BotConfiguration.clickOpenSalesIQScript(driver);
		TakeScreenshot.infoScreenshot(driver,etest);

		String code=BotScripts.getBotWidgetsCode(bot_unique_message);

		code=code.replace(BotScripts.ARTICLEID1,articleid1);
		code=code.replace(BotScripts.ARTICLEID2,articleid2);
		code=code.replace(BotScripts.ARTICLEID3,unpublished_article_id);
		code=code.replace(BotScripts.FORWARD_TO_AGENT,ExecuteStatements.getUserMail(driver));
		code=code.replace(BotScripts.FORWARD_TO_DEPT,ExecuteStatements.getDepartmentID(driver,DEPARTMENT2));

		etest.log(Status.INFO,code);
		BotScripts.copyToClipboard(driver,etest,code);
		DelugeScript.pasteCodeInScript(driver,etest);
		DelugeScript.clickPublish(driver);

		DelugeScript.changeHandlerView(driver,DelugeScript.CONTEXT_HANDLER);
		
		code=BotScripts.getBotCode(BotScripts.WIDGETS_CODE,BotScripts.CONTEXT_HANDLER);
		BotScripts.copyToClipboard(driver,etest,code);
		DelugeScript.pasteCodeInScript(driver,etest);
		DelugeScript.clickPublish(driver);

		DelugeScript.close(driver);

		etest.log(Status.PASS,"portal was setup for bot widgets module");
	}


	public static boolean checkSliderWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		String website_code=null;

		WebDriver visitor_driver=null;

		try
		{
			website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_SLIDER,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//slider is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			CommonSikuli.findInWholePage(visitor_driver,"UI453.png","UI453",etest);

			if(Widgets.checkSliderWidgetSelectValues(visitor_driver,etest))
			{
				etest.log(Status.PASS,"All slider values were selectable when selecting from left to right and vice versa");
			}
			else
			{
				etest.log(Status.FAIL,"All slider values were selectable when selecting from left to right and vice versa");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			if(Widgets.submitSliderValue(visitor_driver,etest,Widgets.SLIDER_WIDGET_VALUES[3])==false)
			{
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkRangeSliderWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_RANGE_SLIDER,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//slider is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(Widgets.checkRangeSliderWidgetSelectValues(visitor_driver,etest))
			{
				etest.log(Status.PASS,"All slider values were selectable when selecting from left to right and vice versa");
			}
			else
			{
				etest.log(Status.FAIL,"All slider values were selectable when selecting from left to right and vice versa");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			if(Widgets.submitRangeSliderMaxValue(visitor_driver,etest)==false)
			{
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkHappinessRatingWidget(WebDriver driver,ExtentTest etest,int level,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=(level==3)?Widgets.INVOKE_HAPPINESS_RATING_LEVEL3:Widgets.INVOKE_HAPPINESS_RATING_LEVEL5;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//happiness rating is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(Widgets.checkHappinessRating(visitor_driver,etest,level))
			{
				etest.log(Status.PASS,"All expected smileys were found for happiness rating with level "+level);
			}
			else
			{
				etest.log(Status.FAIL,"All expected smileys were NOT found for happiness rating with level "+level);
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			boolean expected_skippable=(level==3)?true:false;

			if(Widgets.checkSkippable(visitor_driver,etest,expected_skippable)==false)
			{
				failcount++;
			}

			if(Widgets.selectHappinessRatingValue(visitor_driver,etest,level,2)==false)
			{
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkLikeWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> like_widget_result=checkLikeWidget(driver,etest,website,department,SALESIQ_BOT);
        result.putAll(like_widget_result);
	}

	public static Hashtable<String,Boolean> checkLikeWidget(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String usecase1=null,usecase2=null;
		usecase1=new String[] {"BOTS80","BOTS131","BOTS207","BOTS255","BOTS320"}[bot_type];
		usecase2=new String[] {"BOTS81","BOTS132","BOTS208","BOTS256","BOTS321"}[bot_type];

		Hashtable<String,Boolean> like_widget_result=new Hashtable<String,Boolean>();
		like_widget_result.put(usecase1,false);
		like_widget_result.put(usecase2,false);

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_LIKE_SKIPPABLE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//like rating is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			CommonSikuli.findInWholePage(visitor_driver,"UI451.png","UI451",etest);

			if(Widgets.selectLikeValue(visitor_driver,etest,true)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);				
			}

			like_widget_result.put(usecase1, CommonUtil.returnResult(failcount) );

			failcount=0;

			BotsVisitorSide.waitTillBotReplies(visitor_driver);



			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_LIKE_UNSKIPPABLE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//like rating is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkSkippable(visitor_driver,etest,false)==false)
			{
				failcount++;
			}

			CommonSikuli.findInWholePage(visitor_driver,"UI452.png","UI452",etest);

			if(Widgets.selectLikeValue(visitor_driver,etest,false)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);				
			}

			like_widget_result.put(usecase2, CommonUtil.returnResult(failcount) );

		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return like_widget_result;
	}

	public static void checkStarRating(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkStarRating(driver,etest,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkStarRating(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{

		String usecase1=null,usecase2=null;
		usecase1=new String[] {"BOTS84","BOTS135","BOTS209","BOTS259","BOTS324"}[bot_type];
		usecase2=new String[] {"BOTS85","BOTS136","BOTS210","BOTS260","BOTS325"}[bot_type];

		Hashtable<String,Boolean> star_widget_result=new Hashtable<String,Boolean>();
		star_widget_result.put(usecase1,false);
		star_widget_result.put(usecase2,false);

		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_5STAR_RATING,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//star rating is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			
			CommonSikuli.findInWholePage(visitor_driver,"UI454.png","UI454",etest);

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			if(Widgets.checkStars(visitor_driver,etest,5)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);
			}

			if(Widgets.selectStar(visitor_driver,etest,4)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);
			}

			star_widget_result.put(usecase1, CommonUtil.returnResult(failcount) );

			failcount=0;

			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_10STAR_RATING,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//star rating is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkSkippable(visitor_driver,etest,false)==false)
			{
				failcount++;
			}

			if(Widgets.checkStars(visitor_driver,etest,10)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);
			}

			if(Widgets.selectStar(visitor_driver,etest,7)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(driver,etest);
			}

			star_widget_result.put(usecase2, CommonUtil.returnResult(failcount) );
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return star_widget_result;
	}

	public static void checkSingleSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkSingleSelect(driver,etest,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkSingleSelect(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String usecase1=null,usecase2=null;
		usecase1=new String[] {"BOTS86","BOTS137","BOTS211","BOTS261","BOTS326"}[bot_type];
		usecase2=new String[] {"BOTS87","BOTS138","BOTS212","BOTS262","BOTS327"}[bot_type];

		Hashtable<String,Boolean> widget_result=new Hashtable<String,Boolean>();
		widget_result.put(usecase1,false);
		widget_result.put(usecase2,false);


		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);


			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_SINGLE_SELECT1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			if(Widgets.isSingleSelect(visitor_driver)==false)
			{
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			if(Widgets.checkAllSelectWidgetValues(visitor_driver,etest,Widgets.SINGLE_SELECT_VALUE_SET1)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(Widgets.selectValue(visitor_driver,etest,Widgets.SINGLE_SELECT_VALUE_SET1[0])==false)
			{
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			widget_result.put(usecase1, CommonUtil.returnResult(failcount) );

			failcount=0;

			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_SINGLE_SELECT2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkSkippable(visitor_driver,etest,false)==false)
			{
				failcount++;
			}

			if(Widgets.isSingleSelect(visitor_driver)==false)
			{
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			if(Widgets.checkAllSelectWidgetValues(visitor_driver,etest,Widgets.SINGLE_SELECT_VALUE_SET2)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(Widgets.selectValue(visitor_driver,etest,Widgets.SINGLE_SELECT_VALUE_SET2[0])==false)
			{
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			widget_result.put(usecase2, CommonUtil.returnResult(failcount) );
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return widget_result;
	}

	public static void checkMultiSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkMultiSelect(driver,etest,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkMultiSelect(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String
		usecase1=new String[] {"BOTS88","BOTS139","BOTS213","BOTS263","BOTS328"}[bot_type],
		usecase2=new String[] {"BOTS89","BOTS140","BOTS214","BOTS264","BOTS329"}[bot_type],
		usecase3=new String[] {"BOTS90","BOTS141","BOTS215","BOTS265","BOTS330"}[bot_type],
		usecase4=new String[] {"BOTS91","BOTS142","BOTS216","BOTS266","BOTS331"}[bot_type],
		usecase5=new String[] {"BOTS92","BOTS143","BOTS217","BOTS267","BOTS332"}[bot_type];//usecase 5 is handled in Widgets.java itself

		Hashtable<String,Boolean> widget_result=new Hashtable<String,Boolean>();
		widget_result.put(usecase1,false);
		widget_result.put(usecase2,false);
		widget_result.put(usecase3,false);
		widget_result.put(usecase4,false);

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_MULTISELECT1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.isMultiSelect(visitor_driver)==false)
			{
				etest.log(Status.FAIL,"Multiselect widget was not invoked. Someother widget is invoked");
				failcount++;
			}

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			if(Widgets.checkAllSelectWidgetValues(visitor_driver,etest,Widgets.MULTISELECT_VALUE_SET1)==false)
			{
				failcount++;
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			String[] select_values=Arrays.copyOfRange(Widgets.MULTISELECT_VALUE_SET1, 0, 5);//5 elements to select sa max-select is 5

			if(Widgets.selectMultipleValuesAndPost(visitor_driver,etest,select_values,bot_type)==false)
			{
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			widget_result.put(usecase1, CommonUtil.returnResult(failcount) );

			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_MULTISELECT2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			widget_result.put(usecase4,Widgets.checkSkippable(visitor_driver,etest,false));

			Hashtable<String,Boolean> select_result=Widgets.checkSelectAndUnselectMultiselectWidget(visitor_driver,etest);

			if(select_result.containsKey("IS_SELECTED"))
			{
				widget_result.put(usecase2,select_result.get("IS_SELECTED"));
			}
			if(select_result.containsKey("IS_UNSELECTED"))
			{
				widget_result.put(usecase3,select_result.get("IS_UNSELECTED"));
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return widget_result;
	}

	public static void checkTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkTimeslots(driver,etest,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkTimeslots(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String
		usecase1=new String[] {"BOTS93","BOTS144","BOTS218","BOTS268","BOTS333"}[bot_type],
		usecase2=new String[] {"BOTS94","BOTS145","BOTS219","BOTS269","BOTS334"}[bot_type],
		usecase3=new String[] {"BOTS95","BOTS146","BOTS220","BOTS270","BOTS335"}[bot_type],
		usecase4=new String[] {"BOTS96","BOTS147","BOTS221","BOTS271","BOTS336"}[bot_type],
		usecase5=new String[] {"BOTS97","BOTS148","BOTS222","BOTS272","BOTS337"}[bot_type],
		usecase6=new String[] {"BOTS98","BOTS149","BOTS223","BOTS273","BOTS338"}[bot_type]
		;

		Hashtable<String,Boolean> widget_result=new Hashtable<String,Boolean>();
		widget_result.put(usecase1,false);
		widget_result.put(usecase2,false);
		widget_result.put(usecase3,false);
		widget_result.put(usecase4,false);
		widget_result.put(usecase5,false);
		widget_result.put(usecase6,false);

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_TIMESLOTS1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			CommonSikuli.findInWholePage(visitor_driver,"UI455.png","UI455",etest);

			Widgets.clickScheduleButtonInSlotsWidget(visitor_driver);

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			if(Widgets.checkTimeSlotValues(visitor_driver,etest,Widgets.TIMESLOT_VALUES,Widgets.TIMESLOT_CONTENT)==false)
			{
				failcount++;
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			widget_result.put(usecase1,CommonUtil.returnResult(failcount));

			Hashtable<String,Boolean> check_timeslot_result1=Widgets.checkSelectTimeslot(visitor_driver,etest,true);

			if(check_timeslot_result1.containsKey("IS_TIMESLOTS_CHECKED"))
			{
				widget_result.put(usecase2, check_timeslot_result1.get("IS_TIMESLOTS_CHECKED") );
			}
			if(check_timeslot_result1.containsKey("IS_TIMEZONE_SELECTED"))
			{
				widget_result.put(usecase3, check_timeslot_result1.get("IS_TIMEZONE_SELECTED") );
			}
			if(check_timeslot_result1.containsKey("IS_TIMEZONE_SHOWN"))
			{
				widget_result.put(usecase6, check_timeslot_result1.get("IS_TIMEZONE_SHOWN") );
			}

			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_TIMESLOTS2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			widget_result.put(usecase5,Widgets.checkSkippable(visitor_driver,etest,false));

			Widgets.clickScheduleButtonInSlotsWidget(visitor_driver);

			Hashtable<String,Boolean> check_timeslot_result2=Widgets.checkSelectTimeslot(visitor_driver,etest,false);

			if(check_timeslot_result2.containsKey("IS_TIMEZONE_SHOWN"))
			{
				widget_result.put(usecase4, check_timeslot_result2.get("IS_TIMEZONE_SHOWN") );
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return widget_result;
	}

	public static void checkDateTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkDateTimeslots(driver,etest,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkDateTimeslots(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String
		usecase1=new String[] {"BOTS99","BOTS150","BOTS224","BOTS274","BOTS339"}[bot_type],
		usecase2=new String[] {"BOTS100","BOTS151","BOTS225","BOTS275","BOTS340"}[bot_type],
		usecase3=new String[] {"BOTS101","BOTS152","BOTS226","BOTS276","BOTS341"}[bot_type],
		usecase4=new String[] {"BOTS102","BOTS153","BOTS227","BOTS277","BOTS342"}[bot_type],
		usecase5=new String[] {"BOTS103","BOTS154","BOTS228","BOTS278","BOTS343"}[bot_type],
		usecase6=new String[] {"BOTS104","BOTS155","BOTS229","BOTS279","BOTS344"}[bot_type]
		;

		Hashtable<String,Boolean> widget_result=new Hashtable<String,Boolean>();
		widget_result.put(usecase1,false);
		widget_result.put(usecase2,false);
		widget_result.put(usecase3,false);
		widget_result.put(usecase4,false);
		widget_result.put(usecase5,false);
		widget_result.put(usecase6,false);

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_DATETIMESLOTS1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			Widgets.clickScheduleButtonInSlotsWidget(visitor_driver);

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			Widgets.selectDateFromDateTimeSlot(visitor_driver,etest,Widgets.DATE_TIME_DATES[0]);

			if(Widgets.checkTimeSlotValues(visitor_driver,etest,Widgets.DATE_TIMESLOT_DAY1_VALUES,Widgets.DATE_TIMESLOT_DAY1_CONTENT)==false)
			{
				failcount++;
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			Widgets.goToDateSelectFromTimeSelectForDateTimeSlot(visitor_driver);

			Widgets.selectDateFromDateTimeSlot(visitor_driver,etest,Widgets.DATE_TIME_DATES[1]);

			if(Widgets.checkTimeSlotValues(visitor_driver,etest,Widgets.DATE_TIMESLOT_DAY2_VALUES,Widgets.DATE_TIMESLOT_DAY2_CONTENT)==false)
			{
				failcount++;
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			Widgets.goToDateSelectFromTimeSelectForDateTimeSlot(visitor_driver);

			Widgets.selectDateFromDateTimeSlot(visitor_driver,etest,Widgets.DATE_TIME_DATES[2]);

			if(Widgets.checkTimeSlotValues(visitor_driver,etest,Widgets.DATE_TIMESLOT_DAY3_VALUES,Widgets.DATE_TIMESLOT_DAY3_CONTENT)==false)
			{
				failcount++;
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			Widgets.goToDateSelectFromTimeSelectForDateTimeSlot(visitor_driver);

			widget_result.put(usecase1,CommonUtil.returnResult(failcount));
			failcount=0;

			Hashtable<String,Boolean> check_datetimeslot_result1=Widgets.checkSelectDateTimeslot(visitor_driver,etest,true);
			widget_result.put(usecase2,check_datetimeslot_result1.get("IS_DATETIMESLOTS_CHECKED"));
			widget_result.put(usecase3,check_datetimeslot_result1.get("IS_TIMEZONE_SHOWN"));

			if(widget_result.get(usecase2)==false || widget_result.get(usecase3)==false)
			{
				TakeScreenshot.screenshot(driver,etest);
			}

			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_DATETIMESLOTS2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			widget_result.put(usecase5,Widgets.checkSkippable(visitor_driver,etest,false));

			Widgets.clickScheduleButtonInSlotsWidget(visitor_driver);

			Hashtable<String,Boolean> check_datetimeslot_result2=Widgets.checkSelectDateTimeslot(visitor_driver,etest,false);
			widget_result.put(usecase4,check_datetimeslot_result2.get("IS_DATETIMESLOTS_CHECKED"));
			widget_result.put(usecase6,check_datetimeslot_result1.get("IS_TIMEZONE_SHOWN"));

			if(widget_result.get(usecase4)==false || widget_result.get(usecase6)==false)
			{
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return widget_result;
	}

	public static void checkCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkCalendar(driver,etest,bot_unique_message,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkCalendar(WebDriver driver,ExtentTest etest,String calendar_label,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String usecase1=null,usecase2=null;
		usecase1=new String[] {"BOTS74","BOTS125","BOTS203","BOTS249","BOTS314"}[bot_type];
		usecase2=new String[] {"BOTS75","BOTS126","BOTS204","BOTS250","BOTS315"}[bot_type];

		Hashtable<String,Boolean> widget_result=new Hashtable<String,Boolean>();
		widget_result.put(usecase1,false);
		widget_result.put(usecase2,false);

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_CALENDAR1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

	        CommonSikuli.findInWholePage(visitor_driver,"UI445.png","UI445",etest);

			if(Widgets.checkCalendarLabelText(visitor_driver,etest,calendar_label)==false)
			{
				failcount++;
			}

			Widgets.openDatePicker(visitor_driver,etest);

			if(Widgets.checkCalendarDate(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.isDatesOutsideRangeDisabled(visitor_driver,etest)==false)
			{
				failcount++;
			}			

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			
			if(Widgets.setCalendarDateAs(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.setCalendarTimeAs(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.selectCalendarTimeZone(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.checkCalendarSchedule(visitor_driver,etest)==false)
			{
				failcount++;
			}

			widget_result.put(usecase1,CommonUtil.returnResult(failcount));
			failcount=0;

			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_CALENDAR2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			Widgets.openDatePicker(visitor_driver,etest);

			if(Widgets.checkCalendarDate(visitor_driver,etest,DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/dd"),null,null)==false)
			{
				failcount++;
			}

			if(Widgets.isDatesOutsideRangeDisabled(visitor_driver,etest,-1,-1) == false)
			{
				failcount++;
			}			

			if(Widgets.checkSkippable(visitor_driver,etest,false) == false)
			{
				failcount++;
			}

			
			if(Widgets.setCalendarDateAs(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.checkCalendarSchedule(visitor_driver,etest)==false)
			{
				failcount++;
			}

			widget_result.put(usecase2,CommonUtil.returnResult(failcount));
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return widget_result;
	}

	public static void checkRangeCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=checkRangeCalendar(driver,etest,bot_unique_message,website,department,SALESIQ_BOT);
        result.putAll(widget_result);
	}

	public static Hashtable<String,Boolean> checkRangeCalendar(WebDriver driver,ExtentTest etest,String calendar_label,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String usecase1=null,usecase2=null;
		usecase1=new String[] {"BOTS76","BOTS127","BOTS205","BOTS251","BOTS316"}[bot_type];
		usecase2=new String[] {"BOTS77","BOTS128","BOTS206","BOTS252","BOTS317"}[bot_type];

		Hashtable<String,Boolean> widget_result=new Hashtable<String,Boolean>();
		widget_result.put(usecase1,false);
		widget_result.put(usecase2,false);

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_RANGE_CALENDAR1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkCalendarLabelText(visitor_driver,etest,calendar_label)==false)
			{
				failcount++;
			}

			Widgets.openDatePicker(visitor_driver,etest);

			if(Widgets.checkCalendarDate(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.isDatesOutsideRangeDisabled(visitor_driver,etest)==false)
			{
				failcount++;
			}			

			if(Widgets.checkSkippable(visitor_driver,etest,true)==false)
			{
				failcount++;
			}

			String from_day,to_day;
			int from=-1,to=-1;
			int current_date=Integer.parseInt(DateTimeUtil.getCurrentTimeInFormat("dd"));

			if(current_date<5)
			{
				from=current_date;
				to=current_date+2;
			}
			else
			{
				from=current_date-2;
				to=current_date;
			}

			from_day=""+from;
			to_day=""+to;
			from_day=(from_day.length()==1?"0"+from_day:from_day);
			to_day=(to_day.length()==1?"0"+to_day:to_day);

			String from_date=DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/"+from_day);
			String to_date=DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/"+to_day);

			if(Widgets.setRangeCalendarDateAs(visitor_driver,etest,from_date,to_date )==false)
			{
				failcount++;
			}

			if(Widgets.setRangeCalendarTimeAs(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.selectCalendarTimeZone(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.checkRangeCalendarSchedule(visitor_driver,etest)==false)
			{
				failcount++;
			}

			widget_result.put(usecase1,CommonUtil.returnResult(failcount));
			failcount=0;

			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_RANGE_CALENDAR2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			Widgets.openDatePicker(visitor_driver,etest);

			if(Widgets.checkCalendarDate(visitor_driver,etest,DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/dd"),null,null)==false)
			{
				failcount++;
			}

			if(Widgets.isDatesOutsideRangeDisabled(visitor_driver,etest,-1,-1) == false)
			{
				failcount++;
			}			

			if(Widgets.checkSkippable(visitor_driver,etest,false) == false)
			{
				failcount++;
			}

			if(Widgets.setRangeCalendarDateAs(visitor_driver,etest)==false)
			{
				failcount++;
			}

			if(Widgets.checkRangeCalendarSchedule(visitor_driver,etest)==false)
			{
				failcount++;
			}

			widget_result.put(usecase2,CommonUtil.returnResult(failcount));
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return widget_result;
	}

	public static boolean checkArticlesWidget(WebDriver driver,ExtentTest etest,String website,String department,String articleid1,String articleid2,String unpublished_article_id,String article_label1,String article_label2,String unpublished_article_label)
	{
		return checkArticlesWidget(driver,etest,website,department,articleid1,articleid2,unpublished_article_id,article_label1,article_label2,unpublished_article_label,bot_unique_message);
	}


	public static boolean checkArticlesWidget(WebDriver driver,ExtentTest etest,String website,String department,String articleid1,String articleid2,String unpublished_article_id,String article_label1,String article_label2,String unpublished_article_label,String bot_unique_message)
	{

		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		final String
		HEADING=bot_unique_message,
		DESC=bot_unique_message+"_description"
		;

		try
		{
			Hashtable<String,String> expected_article=new Hashtable<String,String>();
			Hashtable<String,String> actual_article=new Hashtable<String,String>();
			Hashtable<String,String> article_data=new Hashtable<String,String>();
			WebElement article_container=null;

			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=Widgets.INVOKE_ARTICLES;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//image is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);


			//check article heading, description
			if(Widgets.checkArticlesWidgetContent(visitor_driver,etest,HEADING,DESC)==false)
			{
				failcount++;
			}

			//check article1,article2 is present and unpublished article is not present
			if(Widgets.isArticlePresent(visitor_driver,etest,articleid1,true) && Widgets.isArticlePresent(visitor_driver,etest,articleid2,true) && Widgets.isArticlePresent(visitor_driver,etest,unpublished_article_id,false))
			{
				etest.log(Status.PASS,"Published articles were displayed and unpublished articles were not displayed");
			}
			else
			{
				etest.log(Status.FAIL,"Articles count was wrong");
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			//open article1 check heading and content, like article and check if its liked then close article
			if(Widgets.openArticle(visitor_driver,etest,article_label1)==false)
			{
				failcount++;
			}

			article_container=ArticlesVisitorSide.getArticlePreviewContainer(visitor_driver);
	        article_data=Articles.getArticleDataByLabel(article_label1);
			expected_article=ArticlesVisitorSide.getExpectedArticleInfo(article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),"0","0","true");
			actual_article=ArticlesVisitorSide.getArticleInfo(article_container);

			if(ArticlesVisitorSide.verifyArticleData(etest,expected_article,actual_article))
			{
				etest.log(Status.PASS,"Article '"+article_label1+"' was found with expected values.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Article '"+article_label1+"' was NOT found with expected values.");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(ArticlesVisitorSide.likeArticle(visitor_driver))
			{
				etest.log(Status.PASS,"Like button was hidden after it was clicked in article preview container");
			}
			else
			{
				etest.log(Status.FAIL,"Like button was NOT hidden after it was clicked in article preview container");
				TakeScreenshot.screenshot(visitor_driver,etest);

			}

			ArticlesVisitorSide.closeArticle(visitor_driver);

			if(ArticlesVisitorSide.waitTillArticlePreviewHidden(visitor_driver))
			{
				etest.log(Status.PASS,"Article was closed after close button was clicked");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Article was NOT closed after close button was clicked");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}


			//open article2 check heading and content, dislike article and chekc if its disliked then click go to chat and check if chat is opened
			if(Widgets.openArticle(visitor_driver,etest,article_label2)==false)
			{
				failcount++;
			}

			article_container=ArticlesVisitorSide.getArticlePreviewContainer(visitor_driver);
	        article_data=Articles.getArticleDataByLabel(article_label2);
			expected_article=ArticlesVisitorSide.getExpectedArticleInfo(article_data.get(Articles.NAME),article_data.get(Articles.CONTENT),"0","0","true");
			actual_article=ArticlesVisitorSide.getArticleInfo(article_container);

			if(ArticlesVisitorSide.verifyArticleData(etest,expected_article,actual_article))
			{
				etest.log(Status.PASS,"Article '"+article_label2+"' was found with expected values.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Article '"+article_label2+"' was NOT found with expected values.");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(ArticlesVisitorSide.dislikeArticle(visitor_driver))
			{
				etest.log(Status.PASS,"Dislike button was hidden after it was clicked in article preview container");
			}
			else
			{
				etest.log(Status.FAIL,"Dislike button was NOT hidden after it was clicked in article preview container");
				TakeScreenshot.screenshot(visitor_driver,etest);

			}

			ArticlesVisitorSide.clickChatNowInArticlePreview(visitor_driver,etest);
			ArticlesVisitorSide.waitTillArticlePreviewHidden(visitor_driver);

			VisitorWindow.switchToChatWidget(visitor_driver);

			if(CommonWait.isDisplayed(visitor_driver,VisitorWindow.MESSAGE_AREA))
			{
				etest.log(Status.PASS,"Chat window was shown after 'Go to Chat' was clicked");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Chat window was NOT shown after 'Go to Chat' was clicked");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkImageWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		return checkImageWidget(driver,etest,website,department,bot_unique_message);
	}

	public static boolean checkImageWidget(WebDriver driver,ExtentTest etest,String website,String department,String bot_unique_message)
	{

		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=Widgets.INVOKE_IMAGE;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//image is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkImageWidget(visitor_driver,etest,bot_unique_message,Widgets.IMAGE_WIDGET_URL))
			{
				etest.log(Status.PASS,"Image widget works as expected");
			}
			else
			{
				etest.log(Status.FAIL,"Image widget does NOT work as expected");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkLinkWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		return checkLinkWidget(driver,etest,website,department,bot_unique_message);
	}

	public static boolean checkLinkWidget(WebDriver driver,ExtentTest etest,String website,String department,String bot_unique_message)
	{

		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=Widgets.INVOKE_LINK;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(Widgets.checkLinkWidgetContent(visitor_driver,etest,Widgets.LINKS_HEADER_TEXT))
			{
				etest.log(Status.PASS,"Link widget works as expected");
			}
			else
			{
				etest.log(Status.FAIL,"Link widget does NOT work as expected");
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			if(Widgets.checkExpectedLinkFound(visitor_driver,etest,0,Widgets.LINK1_TEXT.replace(BotScripts.BOT_REPLY_MESSAGE,bot_unique_message),Widgets.LINK1,Widgets.LINK1_ICON)==false)
			{
				failcount++;
			}

			if(Widgets.checkExpectedLinkFound(visitor_driver,etest,1,Widgets.LINK2_TEXT.replace(BotScripts.BOT_REPLY_MESSAGE,bot_unique_message),Widgets.LINK2,Widgets.LINK2_ICON)==false)
			{
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkContextHandler(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			String[] answers={Widgets.CONTEXT_HANDLER_SUGGESTIONS_FLOW1[1],"M"+unique+"2","M"+unique+"3",Widgets.CONTEXT_HANDLER_SUGGESTIONS_FLOW2[0],"M"+unique+"5","M"+unique+"6"};

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_CONTEXT_HANDLER_FLOW1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(CommonUtil.checkStringContainsAndLog(Widgets.QUESTION1,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply for context handler usecase",etest)==false)
			{
				failcount++;
			}

			if(BotsVisitorSide.isSuggestionsFound(visitor_driver,etest,Widgets.CONTEXT_HANDLER_SUGGESTIONS_FLOW1)==false)
			{
				failcount++;
			}

			BotsVisitorSide.selectSuggestion(visitor_driver,etest,answers[0]);

			if(CommonUtil.checkStringContainsAndLog(answers[0],VisitorWindow.getLastVisitorMessage(visitor_driver),"visitor message after clicking suggesstion",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(Widgets.QUESTION2,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply for context handler usecase",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,answers[1],true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(Widgets.QUESTION3,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply for context handler usecase",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,answers[2],true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String selected_values=VisitorWindow.getLastAgentMessage(visitor_driver).trim();

			etest.log(Status.INFO,"Visitor message was found as "+selected_values);

			if(CommonUtil.checkStringContainsAndLog(answers[0]+"$$"+answers[1]+"$$"+answers[2],selected_values,"selected values for context handler",etest)==false)
			{
				failcount++;
			}

			if(failcount>0)
			{
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			//flow2

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_CONTEXT_HANDLER_FLOW2,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(CommonUtil.checkStringContainsAndLog(Widgets.QUESTION4,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply for context handler usecase",etest)==false)
			{
				failcount++;
			}

			if(BotsVisitorSide.isSuggestionsFound(visitor_driver,etest,Widgets.CONTEXT_HANDLER_SUGGESTIONS_FLOW2)==false)
			{
				failcount++;
			}

			BotsVisitorSide.selectSuggestion(visitor_driver,etest,answers[3]);

			if(CommonUtil.checkStringContainsAndLog(answers[3],VisitorWindow.getLastVisitorMessage(visitor_driver),"visitor message after clicking suggesstion",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(Widgets.QUESTION5,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply for context handler usecase",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,answers[4],true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(Widgets.QUESTION6,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply for context handler usecase",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,answers[5],true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			selected_values=VisitorWindow.getLastAgentMessage(visitor_driver).trim();

			etest.log(Status.INFO,"Visitor message was found as "+selected_values);

			if(CommonUtil.checkStringContainsAndLog(answers[3]+"$$"+answers[4]+"$$"+answers[5],selected_values,"selected values for context handler",etest)==false)
			{
				failcount++;
			}

			if(failcount>0)
			{
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	//manage connections
	public static boolean checkCRMConnection(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;
		String connection_name=null,connection_name2=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			connection_name="crm"+unique;
			connection_name=connection_name.toLowerCase();

			//crm connection
			DelugeScript.clickManageConnections(driver,etest);
			ManageConnections.switchToManageConnectionsTab(driver);

			// ManageConnections.deleteAllConnections(driver,etest);

			if(ManageConnections.addCRMConnection(driver,etest,connection_name))
			{
				etest.log(Status.PASS,"CRM connection was successfully added and authenticated");
				result.put("BOTS115",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM connection was NOT successfully added and authenticated");
				result.put("BOTS115",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			connection_name2="crm2"+CommonUtil.getUniqueMessage();
			connection_name2=connection_name2.toLowerCase();

			CommonUtil.switchToTab(driver,0);

			DelugeScript.clickManageConnections(driver,etest);
			ManageConnections.switchToManageConnectionsTab(driver);

			if(ManageConnections.addCRMConnection2(driver,etest,connection_name2))
			{
				etest.log(Status.PASS,"CRM connection was successfully added and authenticated");
			}
			else
			{
				etest.log(Status.FAIL,"CRM connection was NOT successfully added and authenticated");
				TakeScreenshot.screenshot(driver,etest);
			}

			CommonUtil.switchToTab(driver,0);

			String crm_code=BotScripts.getCRMCode(connection_name,connection_name2);
			TakeScreenshot.infoScreenshot(driver,etest);
			// DelugeScript.sendKeysToScript(driver,crm_code);
			BotScripts.copyToClipboard(driver,etest,crm_code);
			DelugeScript.pasteCodeInScript(driver,etest);


			TakeScreenshot.infoScreenshot(driver,etest);

			DelugeScript.clickPublish(driver);
			
			// connection_name="crm1539259920734";
		
			final String
			vname="V"+unique,
			vemail="V"+unique+"@emailed.com",
			phone="9876543210"
			;

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,vname,vemail,null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_CREATE_LEAD,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(CommonUtil.checkStringContainsAndLog(Widgets.CRM_CREATE_API_KEY,VisitorWindow.getLastAgentMessage(visitor_driver),"zoho.crm.create lead function response",etest)==false)
			{
				failcount++;
			}

			CommonUtil.sleep(3*60*1000);//waiting for 3 minutes as it takes time for value to get updated and returned in response

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_GET_LEAD,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			String expected_crm_get_values=vname + "$$" + vemail + "$$" + phone;

			if(CommonUtil.checkStringContainsAndLog(expected_crm_get_values,VisitorWindow.getLastAgentMessage(visitor_driver),"CRM REST API called using connection "+connection_name,etest)==false)
			{
				failcount++;
			}

			//removing connection from code, so that it can be deleted
			String basic_code=BotScripts.getBotReplyCode(unique);
			TakeScreenshot.infoScreenshot(driver,etest);
			DelugeScript.sendKeysToScript(driver,basic_code);
			TakeScreenshot.infoScreenshot(driver,etest);
			DelugeScript.clickPublish(driver);

			DelugeScript.clickManageConnections(driver,etest);
			ManageConnections.switchToManageConnectionsTab(driver);

			result.put("BOTS117",ManageConnections.deleteConnection(driver,etest,connection_name));

			CommonUtil.closeCurrentTab(driver);
			CommonUtil.switchToTab(driver);

			DelugeScript.close(driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
			DelugeScript.close(driver);
		}
		finally
		{
			CommonUtil.switchToTab(driver,0);
		}

		return CommonUtil.returnResult(failcount);
	}

	//check Google connection
	public static boolean checkGoogleConnection(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;
		String connection_name=null;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.clickOpenSalesIQScript(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			connection_name="ggl"+unique;
			connection_name=connection_name.toLowerCase();


			//add google connection
			DelugeScript.clickManageConnections(driver,etest);
			ManageConnections.switchToManageConnectionsTab(driver);

			// ManageConnections.deleteAllConnections(driver,etest);

			if(ManageConnections.addGoogleConnection(driver,etest,connection_name))
			{
				etest.log(Status.PASS,"Google connection was successfully added and authenticated");
				result.put("BOTS116",true);
			}
			else
			{
				etest.log(Status.FAIL,"Google connection was NOT successfully added and authenticated");
				TakeScreenshot.screenshot(driver,etest);
				result.put("BOTS116",false);
			}

			CommonUtil.switchToTab(driver);

			String google_code=BotScripts.getGoogleCalendar(connection_name);
			TakeScreenshot.infoScreenshot(driver,etest);
			etest.log(Status.INFO,google_code);
			// DelugeScript.sendKeysToScript(driver,google_code);
			// TakeScreenshot.infoScreenshot(driver,etest);
			BotScripts.copyToClipboard(driver,etest,google_code);
			DelugeScript.pasteCodeInScript(driver,etest);

			DelugeScript.clickPublish(driver);
			
			final String
			vname="V"+unique,
			vemail="V"+unique+"@emailed.com",
			phone="9876543210"
			;

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,vname,vemail,null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);


			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_GOOGLE_CALENDAR_WIDGET,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//calendar widget is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			Widgets.openDatePicker(visitor_driver,etest);
			
			String date=DateTimeUtil.getCurrentTimeInFormat("yyyy/MM/28");
			String[] time=Widgets.CALENDAR_TIME1;

			Widgets.setCalendarDateAs(visitor_driver,etest,date);
			Widgets.setCalendarTimeAs(visitor_driver,etest,time);
	        Widgets.clickCalendarScheduleButton(visitor_driver,etest);

			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String add_event_api_response_reply=VisitorWindow.getLastAgentMessage(visitor_driver);

			String event_id=Widgets.getEventIdFromCalendarCodeBotMessage(add_event_api_response_reply);
			String invoke_get_event=Widgets.INVOKE_GOOGLE_CALENDAR_VERIFY.replace("<event_id>",event_id);

			etest.log(Status.INFO,"Event was added in google calendar on '"+date+"' at '"+Arrays.toString(time)+"', event_id:"+event_id+", Bot booking info is "+add_event_api_response_reply);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_get_event,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String get_event_api_response_reply=VisitorWindow.getLastAgentMessage(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(add_event_api_response_reply,get_event_api_response_reply,"expected event values, actual value is the value from response when event was added.",etest))
			{
				result.put("BOTS118",true);
			}
			else
			{
				result.put("BOTS118",false);
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			//removing connection from code, so that it can be deleted


			DelugeScript.close(driver);
			BotConfiguration.clickOpenSalesIQScript(driver);

			String basic_code=BotScripts.getBotReplyCode(unique);
			TakeScreenshot.infoScreenshot(driver,etest);
			DelugeScript.sendKeysToScript(driver,basic_code);
			TakeScreenshot.infoScreenshot(driver,etest);
			DelugeScript.clickPublish(driver);

			DelugeScript.clickManageConnections(driver,etest);
			ManageConnections.switchToManageConnectionsTab(driver);

			ManageConnections.deleteConnection(driver,etest,connection_name);

			CommonUtil.closeCurrentTab(driver);
			CommonUtil.switchToTab(driver);

			DelugeScript.close(driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.switchToTab(driver,0);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkForwardAction(WebDriver driver,WebDriver driver2,ExtentTest etest,boolean isForwardToSpecificAgent,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			/*
			Code flow is such that when isForwardToSpecificAgent is true, Chat will be forwarded to driver and will not be forwarded to driver2
			*/

			ChatWindow.closeAllChats(driver);
			ChatWindow.closeAllChats(driver2);

			String user1=ExecuteStatements.getUserName(driver);
			String user2=ExecuteStatements.getUserName(driver2);

			String visitor_name="V"+unique;

			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=(isForwardToSpecificAgent)?Widgets.INVOKE_FORWARD_TO_AGENT:Widgets.INVOKE_FORWARD_TO_ALL;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//join is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(ChatWindow.isBotTransferRequestReceived(driver,etest,visitor_name))
			{
				etest.log(Status.PASS,"Bot forwarded chat was forwarded to "+user1);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Bot forwarded chat was NOT forwarded to "+user1);
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			boolean willAgent2ReceiveRequest=!isForwardToSpecificAgent;
			boolean isChatForwardedForAgent2=ChatWindow.isBotTransferRequestReceived(driver2,etest,visitor_name);

			if(isChatForwardedForAgent2==willAgent2ReceiveRequest)
			{
				etest.log(Status.PASS,"Bot forwarded chat was "+(isChatForwardedForAgent2?"forwarded":"NOT forwarded")+" to "+user2);
			}
			else
			{
				etest.log(Status.FAIL,"Bot forwarded chat was "+(isChatForwardedForAgent2?"NOT forwarded":"forwarded")+" to "+user2);
				TakeScreenshot.screenshot(driver2,etest);
				failcount++;
			}

			if(ChatWindow.handleBotTransfer(driver,true)==false)
			{
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(driver2,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkForwardToDepartmentAction(WebDriver driver,WebDriver dept2_driver1,WebDriver dept2_driver2,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String user1=ExecuteStatements.getUserName(driver);

			String visitor_name="V"+unique;

			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=Widgets.INVOKE_FORWARD_TO_DEPARTMENT;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			//join is invoked
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			if(ChatWindow.isBotTransferRequestReceived(driver,etest,visitor_name)==false)
			{
				etest.log(Status.PASS,"Bot forwarded chat was NOT forwarded to NON department '"+DEPARTMENT2+"' member 1  : "+ExecuteStatements.getUserName(driver));
				TakeScreenshot.infoScreenshot(dept2_driver1,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Bot forwarded chat was forwarded to NON department '"+DEPARTMENT2+"' member 1 : "+ExecuteStatements.getUserName(driver));
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			if(ChatWindow.isBotTransferRequestReceived(dept2_driver1,etest,visitor_name))
			{
				etest.log(Status.PASS,"Bot forwarded chat was forwarded to department '"+DEPARTMENT2+"' member 1  : "+ExecuteStatements.getUserName(dept2_driver1));
				TakeScreenshot.infoScreenshot(dept2_driver1,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Bot forwarded chat was NOT forwarded to department '"+DEPARTMENT2+"' member 1 : "+ExecuteStatements.getUserName(dept2_driver1));
				TakeScreenshot.screenshot(dept2_driver1,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			if(ChatWindow.isBotTransferRequestReceived(dept2_driver2,etest,visitor_name))
			{
				etest.log(Status.PASS,"Bot forwarded chat was forwarded to department '"+DEPARTMENT2+"' member 2 : "+ExecuteStatements.getUserName(dept2_driver2));
				TakeScreenshot.infoScreenshot(dept2_driver2,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Bot forwarded chat was NOT forwarded to department '"+DEPARTMENT2+"' member 2  : "+ExecuteStatements.getUserName(dept2_driver2));
				TakeScreenshot.screenshot(dept2_driver2,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			if(ChatWindow.handleBotTransfer(dept2_driver1,true)==false)
			{
				failcount++;
			}

			if(ChatWindow.isBotTransferRequestReceived(dept2_driver2,etest,visitor_name)==false)
			{
				etest.log(Status.PASS,"Transfer UI was hidden for '"+ExecuteStatements.getUserName(dept2_driver2)+"' when other department member accepted the transfer request");
				TakeScreenshot.infoScreenshot(dept2_driver2,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Transfer UI was NOT hidden for '"+ExecuteStatements.getUserName(dept2_driver2)+"' when other department member accepted the transfer request");
				TakeScreenshot.screenshot(dept2_driver2,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkChatEndAction(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			String visitor_name="V"+unique;

			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=Widgets.INVOKE_END;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);

			//end is invoked
			if(VisitorWindow.isChatEnded(visitor_driver))
			{
				etest.log(Status.PASS,"Bot chat was ended after visitor invoked end action");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Bot chat was NOT ended after visitor invoked end action");
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkBlockAction(WebDriver driver,ExtentTest etest,String website,String department)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			Cleanup.deleteAllBlockedIP(driver);

			int before_block_count=BlockedIP.getBlockedIPCount(driver);

			String visitor_name="V"+unique;

			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			String invoke_message=Widgets.INVOKE_BLOCK;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invoke_message,true);

			CommonUtil.sleep(2000);

			//end is invoked
			if(VisitorWindow.isChatWindowHidden(visitor_driver))
			{
				etest.log(Status.PASS,"Chat window was hidden after visitor invoked block action");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Chat window was NOT hidden after visitor invoked block action");
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}

			int after_block_count=BlockedIP.getBlockedIPCount(driver);

			if(after_block_count==before_block_count+1)
			{
				etest.log(Status.PASS,"IP blocked was found in BlockedIP tab");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"IP blocked was NOT found in BlockedIP tab");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static Hashtable<String,Boolean> checkVisitorFieldNames(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String usecase1=null;
		usecase1=new String[] {null,null,null,"BOTS280"}[bot_type];

		Hashtable<String,Boolean> usecase_result=new Hashtable<String,Boolean>();
		usecase_result.put(usecase1,false);

		final String name="VisitorNewName";
		final String email="NewEmail@visitoremail.com";
		final String phone="9876543210";

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_STORE_NAME,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,name,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_STORE_EMAIL,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,email,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_STORE_PHONE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,phone,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			etest.log(Status.INFO,"Visitor field values were set from the bot.");
			TakeScreenshot.infoScreenshot(visitor_driver,etest);

			usecase_result.put(usecase1, VisitorWindow.checkVisitorInfo(visitor_driver,etest,name,email,phone) );
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return usecase_result;
	}

	public static Hashtable<String,Boolean> checkInputValidation(WebDriver driver,ExtentTest etest,String website,String department,int bot_type)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String usecase1=null,usecase2=null,usecase3=null,usecase4=null,usecase5=null,usecase6=null;

		usecase1=new String[] {null,null,null,"BOTS281"}[bot_type];
		usecase2=new String[] {null,null,null,"BOTS282"}[bot_type];
		usecase3=new String[] {null,null,null,"BOTS283"}[bot_type];
		usecase4=new String[] {null,null,null,"BOTS284"}[bot_type];
		usecase5=new String[] {null,null,null,"BOTS285"}[bot_type];
		usecase6=new String[] {null,null,null,"BOTS286"}[bot_type];

		Hashtable<String,Boolean> usecase_result=new Hashtable<String,Boolean>();
		usecase_result.put(usecase1,false);
		usecase_result.put(usecase2,false);
		usecase_result.put(usecase3,false);
		usecase_result.put(usecase4,false);
		usecase_result.put(usecase5,false);
		usecase_result.put(usecase6,false);

		final String
		invalid_email="NotAnEmail"+unique,
		valid_email="email@"+unique+".com",
		invalid_email_reply="invalid email",

		invalid_phone="NotAPhoneNumber"+unique,
		valid_phone="9876543210",
		invalid_phone_reply="invalid phoneno",

		invalid_url="NotAnURL"+unique,
		valid_url="https://www."+unique+".com",
		invalid_url_reply="invalid website",

		invalid_number="3.1428",
		valid_number="3",
		invalid_number_reply="invalid number",

		invalid_string_5_10="abcd2",
		valid_string_5_10="abcdefg",
		invalid_string_5_10_reply="invalid string(5-10)",

		invalid_number_5_10="1234",
		valid_number_5_10="9",
		invalid_number_5_10_reply="invalid number(5-10)"
		;

		try
		{
			String website_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);

			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			etest.log(Status.INFO,"NOW CHECKING EMAIL VALIDATION");

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_VALIDATE_EMAIL,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invalid_email,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(invalid_email_reply,VisitorWindow.getLastAgentMessage(visitor_driver),"invalid email reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,valid_email,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.isContains(invalid_email_reply,VisitorWindow.getLastAgentMessage(visitor_driver))==false)
			{
				etest.log(Status.PASS,"Email was validated after entering valid email");
			}
			else
			{
				etest.log(Status.FAIL,"Email was NOT validated after entering valid email");
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			usecase_result.put(usecase1,CommonUtil.returnResult(failcount));

			etest.log(Status.INFO,"NOW CHECKING PHONE NUMBER VALIDATION");

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_VALIDATE_PHONE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invalid_phone,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(invalid_phone_reply,VisitorWindow.getLastAgentMessage(visitor_driver),"invalid phone reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,valid_phone,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.isContains(invalid_phone_reply,VisitorWindow.getLastAgentMessage(visitor_driver))==false)
			{
				etest.log(Status.PASS,"Phone number was validated after entering valid phone number");
			}
			else
			{
				etest.log(Status.FAIL,"Phone number was NOT validated after entering valid phone number");
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			usecase_result.put(usecase2,CommonUtil.returnResult(failcount));

			etest.log(Status.INFO,"NOW CHECKING WEBSITE VALIDATION");

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_VALIDATE_WEBSITE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invalid_url,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(invalid_url_reply,VisitorWindow.getLastAgentMessage(visitor_driver),"invalid url reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,valid_url,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.isContains(invalid_url_reply,VisitorWindow.getLastAgentMessage(visitor_driver))==false)
			{
				etest.log(Status.PASS,"website was validated after entering valid url");
			}
			else
			{
				etest.log(Status.FAIL,"Website was NOT validated after entering valid url");
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			usecase_result.put(usecase3,CommonUtil.returnResult(failcount));

			etest.log(Status.INFO,"NOW CHECKING NUMBER VALIDATION");

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_VALIDATE_NUMBER,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invalid_number,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(invalid_number_reply,VisitorWindow.getLastAgentMessage(visitor_driver),"invalid number reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,valid_number,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.isContains(invalid_number_reply,VisitorWindow.getLastAgentMessage(visitor_driver))==false)
			{
				etest.log(Status.PASS,"Number was validated after entering valid number");
			}
			else
			{
				etest.log(Status.FAIL,"Number was NOT validated after entering valid number");
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			usecase_result.put(usecase4,CommonUtil.returnResult(failcount));

			etest.log(Status.INFO,"NOW CHECKING STRING(5-10) VALIDATION");

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_VALIDATE_STRING_N_M,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invalid_string_5_10,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(invalid_string_5_10_reply,VisitorWindow.getLastAgentMessage(visitor_driver),"invalid string(5-10) reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,valid_string_5_10,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.isContains(invalid_string_5_10_reply,VisitorWindow.getLastAgentMessage(visitor_driver))==false)
			{
				etest.log(Status.PASS,"String(5-10) was validated after entering valid input");
			}
			else
			{
				etest.log(Status.FAIL,"String(5-10) was NOT validated after entering valid input");
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			usecase_result.put(usecase5,CommonUtil.returnResult(failcount));

			etest.log(Status.INFO,"NOW CHECKING NUMBER(5-10) VALIDATION");

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,Widgets.INVOKE_VALIDATE_NUMBER_N_M,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,invalid_number_5_10,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(invalid_number_5_10_reply,VisitorWindow.getLastAgentMessage(visitor_driver),"invalid number(5-10) reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,valid_number_5_10,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			if(CommonUtil.isContains(invalid_number_5_10_reply,VisitorWindow.getLastAgentMessage(visitor_driver))==false)
			{
				etest.log(Status.PASS,"Number(5-10) was validated after entering valid input");
			}
			else
			{
				etest.log(Status.FAIL,"Number(5-10) was NOT validated after entering valid input");
				TakeScreenshot.screenshot(visitor_driver,etest);				
			}

			usecase_result.put(usecase6,CommonUtil.returnResult(failcount));
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return usecase_result;
	}
}
