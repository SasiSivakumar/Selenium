//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;

public class BotsBasic
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String modulename="Bots Basic";
	public static String widgetcode="",website_name="";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager(true);

            result = new Hashtable<String,Boolean>();

            website_name=ExecuteStatements.getDefaultEmbedName(driver);
            widgetcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website_name);

            Cleanup.deleteAllBots(driver);
            
			etest=ComplexReportFactory.getTest("Check bots tab and add bot button");
			ComplexReportFactory.setValues(etest,"Automation",modulename);
			checkBotsTab(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS2"));
			ComplexReportFactory.setValues(etest,"Automation",modulename);
			checkBotsEmptyState(driver,etest);
            ComplexReportFactory.closeTest(etest);

            WebDriver supervisor_driver=Driver.getLinuxDriver();
            WebDriver associate_driver=Driver.getLinuxDriver();

            Functions.login(supervisor_driver,"bots1_supervisor");
            Functions.login(associate_driver,"bots1_associate");

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS5"));
			ComplexReportFactory.setValues(etest,"Automation",modulename);
			result.put("BOTS5",checkAddBotButtonNotShown(supervisor_driver,etest));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS6"));
			ComplexReportFactory.setValues(etest,"Automation",modulename);
			result.put("BOTS6",checkAddBotButtonNotShown(associate_driver,etest));
            ComplexReportFactory.closeTest(etest);
            
            Functions.logout(supervisor_driver);
            Functions.logout(associate_driver);

			etest=ComplexReportFactory.getTest("Check create bot placeholder and check script not opened when name not given");
			ComplexReportFactory.setValues(etest,"Automation",modulename);
			checkCreateBotTab(driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check create bot department dropdown");
			ComplexReportFactory.setValues(etest,"Automation",modulename);
			checkCreateBotDepartmentDropdown(driver,etest);
            ComplexReportFactory.closeTest(etest);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void checkBotsTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			try
			{
				Tab.navToBotsTab(driver);
				result.put("BOTS1",true);
			}
			catch(Exception e1)
			{
				result.put("BOTS1",false);
				throw e1;
			}

			result.put("BOTS3",BotsTab.isBotsTabContentFound(driver,etest));
			result.put("BOTS4",BotsTab.isAddBotButtonShown(driver,etest));

			if(CommonUtil.isFail(result,"BOTS1","BOTS3","BOTS4"))
			{
				TakeScreenshot.screenshot(driver,etest);
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	//checked in new account module
	public static void checkBotsEmptyState(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToBotsTab(driver);
			result.put("BOTS2",BotsTab.isBotsEmptyStateContentFound(driver,etest));
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static boolean checkAddBotButtonNotShown(WebDriver non_admin_driver,ExtentTest etest)
	{
		try
		{
			try
			{
				Tab.navToBotsTab(non_admin_driver);
			}
			catch(Exception e1)
			{
				if(ExecuteStatements.isAssociate(non_admin_driver))
				{
					etest.log(Status.PASS,"Bots tab was not shown for associate");
					return true;
				}

				throw e1;
			}

			if(ExecuteStatements.isAssociate(non_admin_driver))
			{
				etest.log(Status.FAIL,"Bots tab was shown for associate");
				return false;
			}


			return !BotsTab.isAddBotButtonShown(non_admin_driver,etest);
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(non_admin_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(non_admin_driver,etest);
		}

		return false;
	}

	public static void checkCreateBotTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.clickAddBot(driver);

			result.put("BOTS7",BotConfiguration.checkPlaceHolders(driver,etest));

			BotConfiguration.clickOpenSalesIQScript(driver,false);

			if(Tab.isBannerFound(driver,etest,ResourceManager.getRealValue("bot_empty_name_banner"),Tab.FAILURE_BANNER) && !DelugeScript.isManageConnectionsButtonDisplayed(driver,false))
			{
				etest.log(Status.PASS,"Error message was shown and deluge page was not opened when salesiq script was opened without entering bot name");
				result.put("BOTS9",true);
			}
			else
			{
				result.put("BOTS9",false);
				etest.log(Status.FAIL,"Error message was NOT shown or deluge page was opened when salesiq script was opened without entering bot name");
				TakeScreenshot.screenshot(driver,etest);
			}			
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkCreateBotDepartmentDropdown(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.clickAddBot(driver);

			BotConfiguration.selectWebsite(driver,ExecuteStatements.getDefaultEmbedName(driver));

			if(BotConfiguration.toggleDepartments(driver,true))
			{
				etest.log(Status.PASS,"Department list was shown after clicking show departments button");
				result.put("BOTS10",true);
			}
			else
			{
				etest.log(Status.FAIL,"Department list was NOT shown after clicking show departments button");
				result.put("BOTS10",false);
				TakeScreenshot.screenshot(driver,etest);				
			}

			if(BotConfiguration.toggleDepartments(driver,false))
			{
				etest.log(Status.PASS,"Department list was hidden after clicking hide departments button");
				result.put("BOTS11",true);
			}
			else
			{
				etest.log(Status.FAIL,"Department list was NOT hidden after clicking hide departments button");
				result.put("BOTS11",false);
				TakeScreenshot.screenshot(driver,etest);				
			}

			try
			{
				//exception will be thrown when we try to deselect all departments
				BotConfiguration.selectDepartment(driver,null);
				result.put("BOTS8",false);
				etest.log(Status.FAIL,"All departments are deselected.");
				TakeScreenshot.screenshot(driver,etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.log(e,etest,Status.INFO);
				result.put("BOTS8",true);
				etest.log(Status.PASS,"All departments could not be deselected.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			driver.navigate().refresh();
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

}
