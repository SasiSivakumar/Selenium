//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import java.util.Arrays;
import com.zoho.livedesk.util.common.DateTimeUtil;

public class ZiaTests
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots - Zia",BOT1=BotsWidgets.BOT1,ZIA_AGENT_NAME="automation",RANGLE_CALENDAR_LABEL="RANGE CALENDAR1";

	public static Hashtable test(WebDriver driver)
	{
		//bot name must be same as bot widgets module-->BotsWidgets.BOT1

		try
		{
			String website1=ExecuteStatements.getDefaultEmbedName(driver);	
			String website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);
			String department1=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String bot_unique_message=CommonUtil.getUniqueMessage();

            result = new Hashtable<String,Boolean>();

            

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS199"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBotsExcept(driver,etest,BOT1);
			result.put("BOTS199", BotsWidgets.checkSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS200"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS200", BotsWidgets.checkRangeSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS201"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS201", BotsWidgets.checkHappinessRatingWidget(driver,etest,3,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS202"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS202", BotsWidgets.checkHappinessRatingWidget(driver,etest,5,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check like rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkLikeWidget(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check star rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkStarRating(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check single select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSingleSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check multi select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkMultiSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check date-time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDateTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check range calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRangeCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            

			etest=ComplexReportFactory.getTest("Check Zia concepts");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkZiaConcepts(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);
            
            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);

			etest=ComplexReportFactory.getTest("Zia agent create and delete");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkZiaSkillCRUD(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBotsExcept(driver,etest,BOT1);
			
			etest=ComplexReportFactory.getTest("Create zia bot,set triggers and check in visitor side, then edit trigger and check in visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkZiaBotCreate(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            WebDriver supervisor_driver=Driver.getDriver();

            Functions.login(supervisor_driver,"zia_supervisor");

			etest=ComplexReportFactory.getTest("Zia-Check supervisor permissions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSupervisor(supervisor_driver,etest);
            ComplexReportFactory.closeTest(etest);

            Functions.logout(supervisor_driver);
        }
            
		catch(Exception e)
		{	
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			e.printStackTrace();
			DelugeScript.close(driver);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void checkLikeWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkLikeWidget(driver,etest,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkStarRating(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkStarRating(driver,etest,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkSingleSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkSingleSelect(driver,etest,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkMultiSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkMultiSelect(driver,etest,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkTimeslots(driver,etest,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkDateTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkDateTimeslots(driver,etest,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkCalendar(driver,etest,Widgets.INVOKE_CALENDAR1,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkRangeCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkRangeCalendar(driver,etest,RANGLE_CALENDAR_LABEL,website,department,BotsWidgets.ZIA_BOT);
        result.putAll(widget_result);
	}

	public static void checkZiaSkillCRUD(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage(),siq_bot="ziaBot";

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			String agent_name="skill"+unique;

			//create siq bot
			BotConfiguration.createZiaBot(driver,etest,siq_bot,"desc",website,department,null,"TriggerMessage1");

			//open zia console
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openZiaConfiguration(driver);
			TakeScreenshot.infoScreenshot(driver,etest);
			ZiaConfiguration.clickAccessZiaConsole(driver,etest);

			//create agent
			CommonUtil.switchToTab(driver,1);
			Zia.createSkill(driver,etest,agent_name);
			CommonUtil.switchToTab(driver,0);

			ZiaConfiguration.close(driver);
			BotConfiguration.openZiaConfiguration(driver);

			//allocate new agent
			ZiaConfiguration.clickEditBot(driver);

			if(ZiaConfiguration.isZiaSkillPresent(driver,agent_name))
			{
				etest.log(Status.PASS,"Newly created zia skill was found in salesiq");
				result.put("BOTS195",true);
			}
			else
			{
				result.put("BOTS195",false);
				etest.log(Status.FAIL,"Newly created zia skill was NOT found in salesiq");
				TakeScreenshot.screenshot(driver,etest);
			}

			ZiaConfiguration.selectZiaAgent(driver,agent_name);
			etest.log(Status.INFO,"Zia agent '"+agent_name+"' was allocated for SalesIQ bot : "+siq_bot);
			TakeScreenshot.infoScreenshot(driver,etest);
			ZiaConfiguration.clickSaveBot(driver);
			ZiaConfiguration.close(driver);

			BotsTab.disableAllBotsExcept(driver,etest,siq_bot);

			//check bot pickup in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,siq_bot))
			{
				result.put("BOTS196",true);
				etest.log(Status.PASS,"Zia bot '"+siq_bot+"' picked up chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS196",false);
				etest.log(Status.FAIL,"Zia bot '"+siq_bot+"' did NOT pick up chat");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			//delete agent
			CommonUtil.switchToTab(driver,1);
			Zia.deleteSkillInCurrentPage(driver,etest);
			CommonUtil.switchToTab(driver,0);

			//Detects only when sending a message
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openZiaConfiguration(driver);
			BotsVisitorSide.waitTillBotReplies(driver);
			VisitorWindow.sentMessageInTheme(driver,"Hello",true);
			BotTests.closeBotUIIfOpen(driver);

			//check salesiq is corrupt
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);

			if(BotConfiguration.isBotCorrupt(driver))
			{
				etest.log(Status.PASS,"Connection error was shown after connected zia skill was deleted.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Connection error was NOT shown after connected zia skill was deleted.");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			Tab.navToBotsTab(driver);

			if(BotsTab.isBotEnabled(driver,siq_bot)==false)
			{
				etest.log(Status.PASS,"Corrupted bot '"+siq_bot+"' was disabled after connected zia skill was deleted.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Corrupted bot '"+siq_bot+"' was NOT disabled after connected zia skill was deleted.");		
				TakeScreenshot.screenshot(driver,etest);
				failcount++;		
			}

			result.put("BOTS197", CommonUtil.returnResult(failcount) );

			//reallocate agent
			CommonUtil.switchToTab(driver,0);
			allocateAutomationZiaAgent(driver,etest,siq_bot);

			//re-enable the bot
			Tab.navToBotsTab(driver);
			BotsTab.toggleBot(driver,etest,siq_bot,true);

			//check bot pickup in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,siq_bot))
			{
				result.put("BOTS198",true);
				etest.log(Status.PASS,"Zia bot '"+siq_bot+"' picked up chat after non-corrupt agent was reallocated");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS198",false);
				etest.log(Status.FAIL,"Zia bot '"+siq_bot+"' did NOT pick up chat even after non-corrupt agent was reallocated");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			Tab.navToBotsTab(driver);
			BotsTab.deleteBot(driver,etest,siq_bot);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void allocateAutomationZiaAgent(WebDriver driver,ExtentTest etest,String siq_bot)
	{
		try
		{
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openZiaConfiguration(driver);
			ZiaConfiguration.clickEditBot(driver);
			ZiaConfiguration.selectZiaAgent(driver,ZIA_AGENT_NAME);
			etest.log(Status.INFO,"Zia agent '"+ZIA_AGENT_NAME+"' was allocated for SalesIQ bot : "+siq_bot);
			TakeScreenshot.infoScreenshot(driver,etest);
			ZiaConfiguration.clickSaveBot(driver);
			ZiaConfiguration.close(driver);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			etest.log(Status.ERROR,"Error in rellocating the default automation zia skill for the portal, tests will fail.");
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}

	public static void checkZiaBotCreate(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String unique=CommonUtil.getUniqueMessage(),siq_bot="Zia"+unique;

		String
		trigger1="Trigger_"+unique
		;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			//create siq bot
	        Tab.navToBotsTab(driver);
	        BotsTab.clickAddBot(driver);

	        BotConfiguration.editBotName(driver,siq_bot);
	        BotConfiguration.editBotDescription(driver,siq_bot);
	        BotConfiguration.selectWebsite(driver,website);
	        BotConfiguration.selectDepartment(driver,department);
	        BotConfiguration.clearCurrentTriggers(driver);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.ZIA_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI462.png","UI462",etest);

        	etest.log(Status.INFO,"Sikuli checked...");

	        BotConfiguration.openZiaConfiguration(driver);

	        ZiaConfiguration.setTriggerMessage(driver,etest,trigger1);

        	if(ZiaConfiguration.isBotPreviewChatInputDisplayed(driver)==false)
        	{
	        	result.put("BOTS187",true);
				etest.log(Status.PASS,"Bots preview input was NOT shown before create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS187",false);
				etest.log(Status.PASS,"Bots preview input was shown before create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}

	        ZiaConfiguration.clickCreateBot(driver);
	        etest.log(Status.INFO,"Zia bot '"+siq_bot+"' was created");
	        TakeScreenshot.infoScreenshot(driver,etest);

        	if(ZiaConfiguration.isBotPreviewChatInputDisplayed(driver))
        	{
	        	result.put("BOTS188",true);
				etest.log(Status.PASS,"Bots preview input was shown after create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS188",false);
				etest.log(Status.PASS,"Bots preview input was NOT shown after create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}

        	//click zia console
			if(ZiaConfiguration.clickAccessZiaConsole(driver,etest))
			{
				etest.log(Status.PASS,"Zia console was opened after clicking access zia console button from salesiq");
				result.put("BOTS189",true);
			}
			else
			{
				etest.log(Status.FAIL,"Zia console was NOT opened after clicking access zia console button from salesiq");
				result.put("BOTS189",false);
			}

			CommonUtil.closeAllTabs(driver);

	        ZiaConfiguration.close(driver);

	        //set trigger
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.triggerBotForAll(driver,etest);

        	//check in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			//bot will be triggered
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			VisitorWindow.waitTillMessageInChat(visitor_driver,trigger1,15);

			String messages=VisitorWindow.getChatWindowInnerText(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(trigger1,messages,"triggered message",etest))
			{
				etest.log(Status.PASS,"Expected trigger message was received by the visitor");
				result.put("BOTS190",true);
			}
			else
			{
				etest.log(Status.FAIL,"Expected trigger message was NOT received by the visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("BOTS190",false);
			}

			unique=CommonUtil.getUniqueMessage();
			trigger1="Trigger_1_"+unique;

        	//edit trigger messages save bot
        	etest.log(Status.INFO,"Now editing the trigger messages");
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openZiaConfiguration(driver);
			ZiaConfiguration.clickEditBot(driver);
	        ZiaConfiguration.setTriggerMessage(driver,etest,trigger1);
			TakeScreenshot.infoScreenshot(driver,etest);
			ZiaConfiguration.clickSaveBot(driver);
			ZiaConfiguration.close(driver);
			etest.log(Status.INFO,"Trigger message was edited");


        	//check in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			//bot will be triggered
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			VisitorWindow.waitTillMessageInChat(visitor_driver,trigger1,15);

			messages=VisitorWindow.getChatWindowInnerText(visitor_driver);
			if(CommonUtil.checkStringContainsAndLog(trigger1,messages,"triggered message",etest))
			{
				etest.log(Status.PASS,"Expected trigger messages was received by the visitor");
				result.put("BOTS191",true);
			}
			else
			{
				etest.log(Status.FAIL,"Expected trigger messages was NOT received by the visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("BOTS191",false);
			}

			Tab.navToBotsTab(driver);
			BotsTab.deleteBot(driver,etest,siq_bot);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkSupervisor(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		try
		{
			//open zia console
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.openZiaConfiguration(driver);

			//check managed by text
			String expected=ResourceManager.getRealValue("dialogflow_managed_by");
			String actual=ZiaConfiguration.getManagedByText(driver);

			if(CommonUtil.checkStringContainsAndLog(expected,actual,"zia managed by text for supervisor",etest)==false)
			{
				result.put("BOTS193",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			else
			{
				result.put("BOTS193",true);
			}

			//Check change button not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.CHANGE))
			{
				etest.log(Status.FAIL,"Change button was shown for supervisor");
				failcount++;
			}
			else
			{
				etest.log(Status.PASS,"Change button was NOT shown for supervisor");
			}


			//check access df console not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.ACCESS_DF_CONSOLE_BUTTON))
			{
				etest.log(Status.PASS,"Access zia console button was shown for supervisor");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Access zia console  button was NOT shown for supervisor");
			}

			//check edit not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.EDIT))
			{
				etest.log(Status.PASS,"Edit button was shown for supervisor");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Edit button was NOT shown for supervisor");
			}

			if(CommonUtil.returnResult(failcount)==false)
			{
				TakeScreenshot.screenshot(driver,etest);
			}

			result.put("BOTS194", CommonUtil.returnResult(failcount) );
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static Hashtable<String,Boolean> checkZiaNewAccount(WebDriver driver,ExtentTest etest)
	{
		Hashtable<String,Boolean> newaccount_result=new Hashtable<String,Boolean>();

		int failcount=0;

		String unique=CommonUtil.getUniqueMessage(),siq_bot="Zia"+unique;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			//click create zia bot
			//create siq bot
	        Tab.navToBotsTab(driver);
	        BotsTab.clickAddBot(driver);

	        BotConfiguration.editBotName(driver,siq_bot);
	        BotConfiguration.editBotDescription(driver,siq_bot);
	        BotConfiguration.selectWebsite(driver,website);
	        BotConfiguration.selectDepartment(driver,department);
	        BotConfiguration.clearCurrentTriggers(driver);
	        
	        BotConfiguration.openZiaConfiguration(driver);

	        TakeScreenshot.infoScreenshot(driver,etest);

			//check connect with zia UI is shown
			if(ZiaConfiguration.isConnectWithZiaShown(driver))
			{
				etest.log(Status.PASS,"Connect with zia button was shown for new account");
			}
			else
			{
				etest.log(Status.FAIL,"Connect with zia button was NOT shown for new account");
				TakeScreenshot.screenshot(driver,etest);
			}

        	CommonSikuli.findInWholePage(driver,"UI465.png","UI465",etest);

			//Check zia description text
			String expected=ResourceManager.getRealValue("zia_newaccount_desc");
			String actual=CommonUtil.getElement(driver,DialogflowConfiguration.DIALOGFLOW_DESC).getAttribute("innerText");

			if(CommonUtil.checkStringContainsAndLog(expected,actual,"zia description for new account",etest)==false)
			{
				failcount++;
			}

			newaccount_result.put("BOTS230",CommonUtil.returnResult(failcount));

			//close all UI
			CommonUtil.closeAllTabs(driver);
	        ZiaConfiguration.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return newaccount_result;
	}

	public static void checkZiaConcepts(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		final String
		INVOKE_DIRECT_ANSWER="INVOKE DIRECT ANSWER",
		DIRECT_ANSWER_RESPONSE="DIRECT ANSWER IS INVOKED",
		FALLBACK_INTENT_RESPONSE="Sorry, I didn't understand that.",
		INVOKE_CONSTRUCT_ANSWER="INVOKE CONSTRUCT ANSWER",
		INVOKE_PERFORM_OPERATION="INVOKE PERFORM OPERATION",
		EXPECTED_INVOKE_PERFORM_OPERATION_RESPONSE="PARAMETER?",
		INVOKE_CONFIRM="INVOKE CONFIRM",
		EXPECTED_INVOKE_CONFIRM_RESPONSE="RUN EXECUTION FUNCTION?",
		EXPECTED_CONFIRM_TODO_VALID_RESPONSE="Function executed successfully",
		EXPECTED_CONFIRM_TODO_INVALID_RESPONSE="The given value seems to be invalid. RUN EXECUTION FUNCTION?",
		YES="Yes",
		ENTER_STRING="enter stringparam",
		ENTER_NUMBER="enter numberparam",
		ENTER_TIME="enter timeparam",
		ENTER_DATE="enter dateparam",
		ENTER_RADIO="enter radioparam",
		ENTER_CHECKBOX="enter checkboxparam",
		FORMATTED_TIME="01-Jan-2004 18:00:00",
		FORMATTED_DATE="01-Jan-2004",
		STRING_VALUE="String Value",
		NUMBER_VALUE="1",
		RADIO_PARAM_VALUE="One",
		CHECKBOX_PARAM_VALUE="Two,Three",
		TIME_VALUE="01/01/2004 6 PM",
		DATE_VALUE="01/01/2004",
		INVALID="The given value seems to be invalid.",
		EXPECTED_RESPONSE=STRING_VALUE+"|"+NUMBER_VALUE+"|"+FORMATTED_TIME+"|"+FORMATTED_DATE+"|"+RADIO_PARAM_VALUE+"|"+CHECKBOX_PARAM_VALUE;

		try
		{
			String website1=ExecuteStatements.getDefaultEmbedName(driver);	
			String website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);
			String department1=ExecuteStatements.getSystemGeneratedDepartment(driver);

			result.put("BOTS182",false);
			result.put("BOTS183",false);
			result.put("BOTS184",false);
			result.put("BOTS185",false);
			result.put("BOTS186",false);


			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_DIRECT_ANSWER,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(DIRECT_ANSWER_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after invoking a zia action",etest))
			{
				result.put("BOTS182",true);
			}


			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"Message"+unique+"Visitor",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(FALLBACK_INTENT_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after sending random message",etest))
			{
				result.put("BOTS185",true);
			}

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_CONSTRUCT_ANSWER,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTER_STRING,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,STRING_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTER_NUMBER,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,STRING_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(INVALID,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,NUMBER_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTER_TIME,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,STRING_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(INVALID,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,TIME_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTER_DATE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,STRING_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(INVALID,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,DATE_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTER_RADIO,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,STRING_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(INVALID,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,RADIO_PARAM_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTER_CHECKBOX,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,STRING_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(INVALID,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,CHECKBOX_PARAM_VALUE,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(EXPECTED_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply which contains all params entered by visitor",etest)==false)
			{
				failcount++;
			}

			result.put("BOTS183",CommonUtil.returnResult(failcount));

			if(failcount>0)
			{
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_PERFORM_OPERATION,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(EXPECTED_INVOKE_PERFORM_OPERATION_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply-params handler",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_CONFIRM,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(EXPECTED_INVOKE_CONFIRM_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply-context handler",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"test"+CommonUtil.getUniqueMessage(),true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(EXPECTED_CONFIRM_TODO_INVALID_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply-context handler",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,YES,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(EXPECTED_CONFIRM_TODO_VALID_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply-execution function",etest)==false)
			{
				failcount++;
			}

			result.put("BOTS184",CommonUtil.returnResult(failcount));

			if(failcount>0)
			{
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}			

			Tab.navToBotsTab(driver);
        	CommonSikuli.findInWholePage(driver,"UI463.png","UI463",etest);

			BotsTab.openBotConfiguration(driver,BOT1);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.ZIA_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI464.png","UI464",etest);

			BotConfiguration.openZiaConfiguration(driver);

			//check in preview chat
			DelugeScript.resetPreviewChat(driver);
			BotsVisitorSide.waitTillBotReplies(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			VisitorWindow.sentMessageInTheme(driver,INVOKE_DIRECT_ANSWER,true);
			BotsVisitorSide.waitTillBotReplies(driver);
			result.put("BOTS186", CommonUtil.checkStringContainsAndLog(DIRECT_ANSWER_RESPONSE,VisitorWindow.getLastAgentMessage(driver),"portal side-preview chat-bot reply after invoking a zia action",etest) );

			TakeScreenshot.infoScreenshot(driver,etest);
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		//close all UI
		CommonUtil.closeAllTabs(driver);
        ZiaConfiguration.close(driver);
	}	
}
