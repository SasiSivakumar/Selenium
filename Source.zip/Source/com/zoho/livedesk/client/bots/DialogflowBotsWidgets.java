//$Id$
package com.zoho.livedesk.client.bots;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import java.util.Arrays;
import com.zoho.livedesk.util.common.DateTimeUtil;

/*

Dialogflow Agent download link

http://integ-fileupload.csez.zohocorpin.com/zohotestautomation/kabilan.b/DIalogFlowSkippable.zip

*/

public class DialogflowBotsWidgets
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Bots - Dialogflow",BOT1=BotsWidgets.BOT1,DIALOGFLOW_AGENT_NAME="Automation",RANGLE_CALENDAR_LABEL="RC";

	public static Hashtable test(WebDriver driver)
	{
		//bot name must be same as bot widgets module-->BotsWidgets.BOT1

		try
		{
			String website1=ExecuteStatements.getDefaultEmbedName(driver);	
			String website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);
			String department1=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String bot_unique_message=CommonUtil.getUniqueMessage();

            result = new Hashtable<String,Boolean>();
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS133"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBotsExcept(driver,etest,BOT1);
			result.put("BOTS133", BotsWidgets.checkSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS134"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS134", BotsWidgets.checkRangeSliderWidget(driver,etest,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS129"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS129", BotsWidgets.checkHappinessRatingWidget(driver,etest,3,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS130"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BOTS130", BotsWidgets.checkHappinessRatingWidget(driver,etest,5,website1,department1));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check like rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkLikeWidget(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check star rating widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkStarRating(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check single select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSingleSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check multi select widget");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkMultiSelect(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check date-time slots");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDateTimeslots(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest(MODULE_NAME+" - Check range calendar widgets");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkRangeCalendar(driver,etest,website1,department1);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

			etest=ComplexReportFactory.getTest("Check dialogflow concepts");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDialogflowConcepts(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);

			etest=ComplexReportFactory.getTest("Dialogflow agent create and delete");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDialogFlowAgentCRUD(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            BotsTab.deleteAllBotsExcept(driver,etest,BOT1);
			BotsTab.disableAllBotsExcept(driver,etest,BOT1);

			etest=ComplexReportFactory.getTest("Create dialogflow bot,set triggers and check in visitor side, then edit trigger and check in visitor side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDialogFlowBotCreate(driver,etest);
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            //to make sure supervisor driver closes, we are using visitor driver manager
            WebDriver supervisor_driver=BotTests.visitor_driver_manager.getDriver(driver);

            Functions.login(supervisor_driver,"dialogflow_supervisor");

			etest=ComplexReportFactory.getTest("Check supervisor permissions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkSupervisor(supervisor_driver,etest);
            ComplexReportFactory.closeTest(etest);

            Functions.logout(supervisor_driver);
        }
            
		catch(Exception e)
		{	
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
			e.printStackTrace();
			DelugeScript.close(driver);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void checkLikeWidget(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkLikeWidget(driver,etest,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkStarRating(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkStarRating(driver,etest,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkSingleSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkSingleSelect(driver,etest,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkMultiSelect(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkMultiSelect(driver,etest,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkTimeslots(driver,etest,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkDateTimeslots(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkDateTimeslots(driver,etest,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkCalendar(driver,etest,Widgets.INVOKE_CALENDAR1,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkRangeCalendar(WebDriver driver,ExtentTest etest,String website,String department)
	{
		Hashtable<String,Boolean> widget_result=BotsWidgets.checkRangeCalendar(driver,etest,RANGLE_CALENDAR_LABEL,website,department,BotsWidgets.DIALOGFLOW_BOT);
        result.putAll(widget_result);
	}

	public static void checkDialogFlowAgentCRUD(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage(),siq_bot="DialogflowBot";

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			String dialogflow_agent_name="Agent"+unique;

			//create siq bot
			BotConfiguration.createDialogflowBot(driver,etest,siq_bot,"desc",website,department,null,"TriggerMessage1","TriggerMessage2");

			//open dialogflow console
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openDialogflowConfiguration(driver);
			TakeScreenshot.infoScreenshot(driver,etest);
			DialogflowConfiguration.clickAccessDialogflowConsole(driver,etest);
			Dialogflow.signIn(driver,etest);

			//create agent
			CommonUtil.switchToTab(driver,1);
			Dialogflow.createAgent(driver,etest,dialogflow_agent_name);
			CommonUtil.switchToTab(driver,0);

			//allocate new agent
			DialogflowConfiguration.clickEditBot(driver);
			if(DialogflowConfiguration.isDialogflowAgentPresent(driver,dialogflow_agent_name))
			{
				etest.log(Status.PASS,"Newly created dialogflow agent was found in salesiq");
				result.put("BOTS156",true);
			}
			else
			{
				result.put("BOTS156",false);
				etest.log(Status.FAIL,"Newly created dialogflow agent was NOT found in salesiq");
				TakeScreenshot.screenshot(driver,etest);
			}
			DialogflowConfiguration.selectDialogflowAgent(driver,dialogflow_agent_name);
			etest.log(Status.INFO,"Dialogflow agent '"+dialogflow_agent_name+"' was allocated for SalesIQ bot : "+siq_bot);
			TakeScreenshot.infoScreenshot(driver,etest);
			DialogflowConfiguration.clickSaveBot(driver);
			DialogflowConfiguration.close(driver);

			BotsTab.disableAllBotsExcept(driver,etest,siq_bot);

			//check bot pickup in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,siq_bot))
			{
				result.put("BOTS157",true);
				etest.log(Status.PASS,"Dialogflow bot '"+siq_bot+"' picked up chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS157",false);
				etest.log(Status.FAIL,"Dialogflow bot '"+siq_bot+"' did NOT pick up chat");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			//delete agent
			CommonUtil.switchToTab(driver,1);
			Dialogflow.deleteAgent(driver,etest,dialogflow_agent_name);
			CommonUtil.switchToTab(driver,0);
			//check salesiq is corrupt
			Tab.navToBotsTab(driver);

			try
			{
				BotsTab.openBotConfiguration(driver,siq_bot);
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,"Unable to open dialogflow bot in first attempt after it became corrupt (i.e. associated agent got deleted)  : ISSUE ID --> ZLS-6736");
				CommonUtil.printStackTrace(e);
				TakeScreenshot.infoScreenshot(driver,etest);
				BotsTab.openBotConfiguration(driver,siq_bot);
			}

			if(BotConfiguration.isDialogflowBotCorrupt(driver))
			{
				etest.log(Status.PASS,"Connection error was shown after connected dialogflow agent was deleted.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Connection error was NOT shown after connected dialogflow agent was deleted.");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			Tab.navToBotsTab(driver);

			if(BotsTab.isBotEnabled(driver,siq_bot)==false)
			{
				etest.log(Status.PASS,"Corrupted bot '"+siq_bot+"' was disabled after connected dialogflow agent was deleted.");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Corrupted bot '"+siq_bot+"' was disabled after connected dialogflow agent was deleted.");		
				TakeScreenshot.screenshot(driver,etest);
				failcount++;		
			}

			result.put("BOTS158", CommonUtil.returnResult(failcount) );

			//reallocate agent
			CommonUtil.switchToTab(driver,0);
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openDialogflowConfiguration(driver);
			DialogflowConfiguration.clickEditBot(driver);
			DialogflowConfiguration.selectDialogflowAgent(driver,DIALOGFLOW_AGENT_NAME);
			etest.log(Status.INFO,"Dialogflow agent '"+DIALOGFLOW_AGENT_NAME+"' was allocated for SalesIQ bot : "+siq_bot);
			TakeScreenshot.infoScreenshot(driver,etest);
			DialogflowConfiguration.clickSaveBot(driver);
			DialogflowConfiguration.close(driver);

			//re-enable the bot
			Tab.navToBotsTab(driver);
			BotsTab.toggleBot(driver,etest,siq_bot,true);

			//check bot pickup in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department,"Q"+unique,false,etest);

			if(BotsVisitorSide.isBotChat(visitor_driver,siq_bot))
			{
				result.put("BOTS159",true);
				etest.log(Status.PASS,"Dialogflow bot '"+siq_bot+"' picked up chat after non-corrupt agent was reallocated");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}
			else
			{
				result.put("BOTS159",false);
				etest.log(Status.FAIL,"Dialogflow bot '"+siq_bot+"' did NOT pick up chat even after non-corrupt agent was reallocated");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			Tab.navToBotsTab(driver);
			BotsTab.deleteBot(driver,etest,siq_bot);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkDialogFlowBotCreate(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String unique=CommonUtil.getUniqueMessage(),siq_bot="DF"+unique;

		String
		trigger1="Trigger_1_"+unique,
		trigger2="Trigger_2_"+unique,
		trigger3="Trigger_3_"+unique,
		trigger4="Trigger_4_"+unique,
		trigger5="Trigger_5_"+unique
		;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			//create siq bot
	        Tab.navToBotsTab(driver);
	        BotsTab.clickAddBot(driver);

        	if(DialogflowConfiguration.isBotPreviewChatInputDisplayed(driver)==false)
        	{
	        	result.put("BOTS160",true);
				etest.log(Status.PASS,"Bots preview input was NOT shown before create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS160",false);
				etest.log(Status.PASS,"Bots preview input was shown before create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}


	        BotConfiguration.editBotName(driver,siq_bot);
	        BotConfiguration.editBotDescription(driver,siq_bot);
	        BotConfiguration.selectWebsite(driver,website);
	        BotConfiguration.selectDepartment(driver,department);
	        BotConfiguration.clearCurrentTriggers(driver);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.DIALOGFLOW_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI456.png","UI456",etest);

	        BotConfiguration.openDialogflowConfiguration(driver);

	        DialogflowConfiguration.setTriggerMessages(driver,etest,trigger1,trigger2,trigger3,trigger4,trigger5);
	        DialogflowConfiguration.clickCreateBot(driver);
	        etest.log(Status.INFO,"Dialogflow bot '"+siq_bot+"' was created");
	        TakeScreenshot.infoScreenshot(driver,etest);

        	if(DialogflowConfiguration.isBotPreviewChatInputDisplayed(driver))
        	{
	        	result.put("BOTS161",true);
				etest.log(Status.PASS,"Bots preview input was shown after create button as clicked.");
				TakeScreenshot.infoScreenshot(driver,etest);		
        	}
        	else
        	{	
        		result.put("BOTS161",false);
				etest.log(Status.PASS,"Bots preview input was NOT shown after create button as clicked.");
				TakeScreenshot.screenshot(driver,etest);		
        	}

        	//click change button
			if(DialogflowConfiguration.clickChangeButton(driver,etest))
			{
				etest.log(Status.PASS,"Google change accounts page was opened after clicking change button from salesiq");
				result.put("BOTS163",true);
			}
			else
			{
				etest.log(Status.FAIL,"Google change accounts was NOT opened after clicking change button from salesiq");
				result.put("BOTS163",false);
			}

			CommonUtil.closeAllTabs(driver);

        	//click dialogflow console
			if(DialogflowConfiguration.clickAccessDialogflowConsole(driver,etest))
			{
				etest.log(Status.PASS,"Dialogflow console was opened after clicking access dialogflow button from salesiq");
				result.put("BOTS162",true);
			}
			else
			{
				etest.log(Status.FAIL,"Dialogflow console was NOT opened after clicking access dialogflow button from salesiq");
				result.put("BOTS162",false);
			}

			CommonUtil.closeAllTabs(driver);

	        DialogflowConfiguration.close(driver);

	        //set trigger
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.triggerBotForAll(driver,etest);

        	//check in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			//bot will be triggered
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			VisitorWindow.waitTillMessageInChat(visitor_driver,trigger5,15);

			String messages=VisitorWindow.getChatWindowInnerText(visitor_driver);

			if
				(
					CommonUtil.checkStringContainsAndLog(trigger1,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger2,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger3,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger4,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger5,messages,"triggered message",etest)
				)
			{
				etest.log(Status.PASS,"All expected trigger messages were received by the visitor");
				result.put("BOTS164",true);
			}
			else
			{
				etest.log(Status.FAIL,"All expected trigger messages were NOT received by the visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("BOTS164",false);
			}

			unique=CommonUtil.getUniqueMessage();
			trigger1="Trigger_1_"+unique;
			trigger2="Trigger_2_"+unique;
			trigger3="Trigger_3_"+unique;
			trigger4="Trigger_4_"+unique;
			trigger5="Trigger_5_"+unique;

        	//edit trigger messages save bot
        	etest.log(Status.INFO,"Now editing the trigger messages");
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,siq_bot);
			BotConfiguration.openDialogflowConfiguration(driver);
			DialogflowConfiguration.clickEditBot(driver);
	        DialogflowConfiguration.setTriggerMessages(driver,etest,trigger1,trigger2,trigger3,trigger4,trigger5);
			TakeScreenshot.infoScreenshot(driver,etest);
			DialogflowConfiguration.clickSaveBot(driver);
			DialogflowConfiguration.close(driver);
			etest.log(Status.INFO,"Trigger messages were edited");


        	//check in visitor side
			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widget_code);
			//bot will be triggered
			VisitorWindow.waitTillChatWindowShown(visitor_driver);//wait till triggered
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			VisitorWindow.waitTillMessageInChat(visitor_driver,trigger5,15);

			messages=VisitorWindow.getChatWindowInnerText(visitor_driver);

			if
				(
					CommonUtil.checkStringContainsAndLog(trigger1,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger2,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger3,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger4,messages,"triggered message",etest) &&
					CommonUtil.checkStringContainsAndLog(trigger5,messages,"triggered message",etest)
				)
			{
				etest.log(Status.PASS,"All expected trigger messages were received by the visitor");
				result.put("BOTS165",true);
			}
			else
			{
				etest.log(Status.FAIL,"All expected trigger messages were NOT received by the visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("BOTS165",false);
			}

			Tab.navToBotsTab(driver);
			BotsTab.deleteBot(driver,etest,siq_bot);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static void checkSupervisor(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		try
		{
			//open dialogflow console
			Tab.navToBotsTab(driver);
			BotsTab.openBotConfiguration(driver,BOT1);
			BotConfiguration.openDialogflowConfiguration(driver);

			//check managed by text
			String expected=ResourceManager.getRealValue("dialogflow_managed_by");
			String actual=DialogflowConfiguration.getManagedByText(driver);

			if(CommonUtil.checkStringContainsAndLog(expected,actual,"dialogflow managed by text for supervisor",etest)==false)
			{
				result.put("BOTS168",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			else
			{
				result.put("BOTS168",true);
			}

			//Check change button not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.CHANGE))
			{
				etest.log(Status.PASS,"Change button was shown for supervisor");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Change button was NOT shown for supervisor");
			}


			//check access df console not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.ACCESS_DF_CONSOLE_BUTTON))
			{
				etest.log(Status.FAIL,"Access dialogflow console button was shown for supervisor");
				failcount++;
			}
			else
			{
				etest.log(Status.PASS,"Access dialogflow console  button was NOT shown for supervisor");
			}

			//check edit not shown
			if(CommonWait.isDisplayed(driver,DialogflowConfiguration.EDIT))
			{
				etest.log(Status.PASS,"Edit button was shown for supervisor");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Edit button was NOT shown for supervisor");
			}

			if(CommonUtil.returnResult(failcount)==false)
			{
				TakeScreenshot.screenshot(driver,etest);
			}

			result.put("BOTS169", CommonUtil.returnResult(failcount) );
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}
	}

	public static Hashtable<String,Boolean> checkDialogflowNewAccount(WebDriver driver,ExtentTest etest)
	{
		Hashtable<String,Boolean> newaccount_result=new Hashtable<String,Boolean>();

		int failcount=0;

		String unique=CommonUtil.getUniqueMessage(),siq_bot="DF"+unique;

		WebDriver visitor_driver=null;

		try
		{
			String website=ExecuteStatements.getDefaultEmbedName(driver);
			String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);

			//click create dialogflow bot
			//create siq bot
	        Tab.navToBotsTab(driver);
	        BotsTab.clickAddBot(driver);

	        BotConfiguration.editBotName(driver,siq_bot);
	        BotConfiguration.editBotDescription(driver,siq_bot);
	        BotConfiguration.selectWebsite(driver,website);
	        BotConfiguration.selectDepartment(driver,department);
	        BotConfiguration.clearCurrentTriggers(driver);
	        
	        BotConfiguration.openDialogflowConfiguration(driver);

	        TakeScreenshot.infoScreenshot(driver,etest);

			//check connect with dialogflow UI is shown
			if(DialogflowConfiguration.isConnectWithDialogflowButtonShown(driver))
			{
				etest.log(Status.PASS,"Connect with dialogflow button was shown for new account");
			}
			else
			{
				etest.log(Status.FAIL,"Connect with dialogflow button was NOT shown for new account");
				TakeScreenshot.screenshot(driver,etest);
			}

        	CommonSikuli.findInWholePage(driver,"UI459.png","UI459",etest);

			//Check dialogflow description text
			String expected=ResourceManager.getRealValue("dialogflow_newaccount_desc");
			String actual=CommonUtil.getElement(driver,DialogflowConfiguration.DIALOGFLOW_DESC).getAttribute("innerText");

			if(CommonUtil.checkStringContainsAndLog(expected,actual,"dialogflow description for new account",etest)==false)
			{
				failcount++;
			}

			newaccount_result.put("BOTS166",CommonUtil.returnResult(failcount));

			failcount=0;

			//click connect with dialogflow and check google page is opened
			if(DialogflowConfiguration.clickConnectWithDialogflow(driver,etest))
			{
				etest.log(Status.PASS,"Google accounts page was opened after clicking connect with dialogflow button from salesiq");
			}
			else
			{
				etest.log(Status.FAIL,"Google accounts page was NOT opened after clicking connect with dialogflow button from salesiq");
				failcount++;
			}

			//enter gmail creds and check if dialogflow account is connected
			com.zoho.livedesk.util.common.GmailUtil.connectGoogleConnectionFromBots(driver,etest);
			CommonUtil.switchToTab(driver,0);

			if(CommonWait.waitTillDisplayed(driver,DialogflowConfiguration.CHANGE))
			{
				etest.log(Status.PASS,"Dialogflow was connected for new account.");
			}
			else
			{
				etest.log(Status.FAIL,"Dialogflow was NOT connected for new account.");
				failcount++;
			}

			newaccount_result.put("BOTS167", CommonUtil.returnResult(failcount) );

	        DialogflowConfiguration.setTriggerMessages(driver,etest,"Trigger1");
	        DialogflowConfiguration.clickCreateBot(driver);
	        etest.log(Status.INFO,"Dialogflow bot '"+siq_bot+"' was created for new account");
	        TakeScreenshot.infoScreenshot(driver,etest);

			//close all UI
			CommonUtil.closeAllTabs(driver);
	        DialogflowConfiguration.close(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			CommonUtil.closeAllTabs(driver);
			CommonUtil.switchToTab(driver,0);
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		return newaccount_result;
	}

	public static void checkDialogflowConcepts(WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		final String unique=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		final String
		INVOKE_INTENT1="AUTOMATION_INTENT",
		INTENT1_RESPONSE="AUTOMATION_INTENT",
		FALLBACK_INTENT_RESPONSE="FALLBACK_INTENT",
		INVOKE_ENTITY_INTENT="STORE_VALUE",
		ENTITY_INTENT_RESPONSE="ENTER_VALUE",
		INVOKE_ENTITY2_INTENT="SYNONYM1",
		ENTITY2_INTENT_RESPONSE="STORE_VALUE|VISITOR_INFO_VALUE"
		;

		try
		{
			String website1=ExecuteStatements.getDefaultEmbedName(driver);	
			String website1_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,website1);
			String department1=ExecuteStatements.getSystemGeneratedDepartment(driver);

			result.put("BOTS170",false);
			result.put("BOTS171",false);
			result.put("BOTS172",false);
			result.put("BOTS173",false);


			visitor_driver=BotTests.visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,website1_code);
			VisitorWindow.initiateChatVisTheme(visitor_driver,"V"+unique,"V"+unique+"@emailed.com",null,department1,"Q"+unique,false,etest);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_INTENT1,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(INTENT1_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after invoking a dialogflow intent",etest))
			{
				result.put("BOTS170",true);
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,"Message"+unique+"Visitor",true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(FALLBACK_INTENT_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after invoking dialogflow fallback intent",etest))
			{
				result.put("BOTS171",true);
			}

			failcount=0;

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_ENTITY_INTENT,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTITY_INTENT_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after invoking an intent with entity param",etest)==false)
			{
				failcount++;
			}

			BotsVisitorSide.waitTillInputIsEnabled(visitor_driver);
			VisitorWindow.sentMessageInTheme(visitor_driver,INVOKE_ENTITY2_INTENT,true);
			BotsVisitorSide.waitTillBotReplies(visitor_driver);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			if(CommonUtil.checkStringContainsAndLog(ENTITY2_INTENT_RESPONSE,VisitorWindow.getLastAgentMessage(visitor_driver),"bot reply after getting entity value in intent",etest)==false)
			{
				failcount++;
			}

			result.put("BOTS172",CommonUtil.returnResult(failcount));

			if(failcount>0)
			{
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
			}

			Tab.navToBotsTab(driver);
        	CommonSikuli.findInWholePage(driver,"UI457.png","UI457",etest);

			BotsTab.openBotConfiguration(driver,BOT1);

	        CommonUtil.scrollIntoView(driver,true,BotConfiguration.DIALOGFLOW_CONFIG);
        	CommonSikuli.findInWholePage(driver,"UI458.png","UI458",etest);

			BotConfiguration.openDialogflowConfiguration(driver);

			//check in preview chat
			DelugeScript.resetPreviewChat(driver);
			BotsVisitorSide.waitTillBotReplies(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			VisitorWindow.sentMessageInTheme(driver,INVOKE_INTENT1,true);
			BotsVisitorSide.waitTillBotReplies(driver);
			result.put("BOTS173", CommonUtil.checkStringContainsAndLog(INTENT1_RESPONSE,VisitorWindow.getLastAgentMessage(driver),"portal side-preview chat-bot reply after invoking a dialogflow intent",etest) );

			TakeScreenshot.infoScreenshot(driver,etest);
		}
		catch(Exception e)
		{
			DelugeScript.close(driver);
			failcount++;
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visitor_driver,etest,e);
		}
		finally
		{
			TakeScreenshot.infoScreenshot(driver,etest);
		}

		//close all UI
		CommonUtil.closeAllTabs(driver);
        DialogflowConfiguration.close(driver);
	}	
}
