//$Id$
package com.zoho.livedesk.client.crmplus.visitorhistory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class CommonFunctionsVH
{
	public static String
	inputCondition = "Last Visited Time",
	inputValue = "Today";

	public static By
	createList = By.id("createlist"),
	ldSettings = By.id("ldsettings"),
	input = By.tagName("input"),
	condition = By.id("prior1_col1_div"),
	conditionDropDown = By.id("prior1_col1_ddown"),
	conditionList = By.id("prior1_col10"),
	value = By.id("prior1_col3_div"),
	valueDropDown = By.id("prior1_col3_ddown"),
	valueList = By.id("prior1_col30"),
	fav = By.id("fav_bx"),
	applyCancelButtons = By.className("clboth"),
	favList = By.id("favdrpdown0"),
	popup = By.className("lvd_popupmn"),
	popupButtons = By.id("popupftr"),
	okButton = By.id("okbtn");

	public static void createLastVisitedTodayList(WebDriver driver)
	{
		createLastVisitedTodayList(driver,true);
	}
	public static void createLastVisitedTodayList(WebDriver driver,boolean isCRMP)
	{
		if(isCRMP)
		{
			CRMPlusCommonUtil.clickVisitorsHistory(driver);
		}
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,createList));
		CommonWait.waitTillDisplayed(driver,ldSettings);

		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,condition));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,conditionDropDown,conditionList).findElements(By.tagName("span")),"title",inputCondition));

		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,value));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,valueDropDown,valueList).findElements(By.tagName("span")),"title",inputValue));

		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,fav,applyCancelButtons).findElements(By.tagName("div")),"innerText","Apply"));

		try
		{
			CommonWait.waitTillDisplayed(driver,popup);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		if(CommonWait.isPresent(driver,popup))
		{
			HandleCommonUI.clickPositivePopupButton(HandleCommonUI.getPopupByInnerText(driver,"This criteria already exist"));
		}

		try
		{
			CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,favList,By.tagName("span")),"innerText",inputCondition);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static String getUuid(WebDriver driver,String visitorId)
	{
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
		return (((JavascriptExecutor) driver).executeScript("return UTSHandler.visitors[\""+visitorId+"\"].data[\"uuid\"];")).toString();
	}
}
