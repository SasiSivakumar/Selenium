//$Id$
package com.zoho.livedesk.client.crmplus.visitorhistory;

import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.crmplus.chats.CRMPChatWindow;
import com.zoho.livedesk.client.crmplus.rings.CommonFunctionsTR;

public class VisitorHistory
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();
	
	public static ExtentTest etest;

	public static VisitorDriverManager visitor_driver_manager;

	public static String 
	widgetCode,portalName,
	moduleName = "CRMP Visitor History",
	visitorsHistory = "Visitor History",
	actionsDiv = "actions_div",
	purpose[] = {"vst_interest","vst_crminfo"},
	behaviourCRMInfo[] = {"Behaviour","Zoho CRM Info"};

	public static By
	visitsDiv = By.id("visits_div"),
	innerHeader = By.id("innerheader"),
	listInfo = By.id("listinfo"),
	behaviourAndCRMInfo = By.id("lstintst"),
	listHeader = By.className("vlsthd"),
	ldSettings = By.id("ldsettings"),
	visitorInfoDiv = By.id("visitor_info_div"),
	visitsInfoDiv = By.id("vistinfodiv"),
	box4 = By.className("box4"),
	visitorInfo = By.id("visitorinfo"),
	visitType = By.id("visttype"),
	actionItem = By.className("actionitem"),
	actionData = By.className("action_data");

	public static Hashtable testVisitor(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_VISITOR_HISTORY",18);

			etest = ComplexReportFactory.getTest("Check Visitor History tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			CheckVisitorHistoryTab(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Visitor present in Visitor History after visitor left in rings");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkVisitorPresentInVisitorHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check visitor details in Visitor History");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkVisitorDetailsInVisitorHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM Info present for a visitor");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfoInVisitorHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check returning visitor");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkReturningVisitor(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check for tabs present for visitor in Visitor History");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkVisitorTabsInVisitorHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check chat Transcript of a visitor in Visitor History");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkChatTranscriptOfVisitorInVisitorHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred");
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void CheckVisitorHistoryTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsHistory(driver);
			if(CommonWait.isPresent(driver,visitsDiv))
			{
				etest.log(Status.INFO,"Visitor History tab is clicked");
				TakeScreenshot.infoScreenshot(driver,etest);

				if(CommonUtil.getElement(driver,visitsDiv,innerHeader).getText().contains(visitorsHistory))
				{
					etest.log(Status.PASS,"Visitors History tab is checked");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_VISITOR_HISTORY1",true);
				}
				else
				{
					etest.log(Status.FAIL,"Visitors History tab verification failed");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Visitor History tab is not opened");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"CheckVisitorHistoryTab","Exception",e);
		}
	}

	public static void checkVisitorPresentInVisitorHistory(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);

			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			String uuid = CommonFunctionsVH.getUuid(driver,visitorId);
			String visitorCol = "col0_"+uuid;
			visitor_driver.quit();

			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			CommonFunctionsVH.createLastVisitedTodayList(driver);

			if(CommonWait.isPresent(driver,By.id(visitorCol)))
			{
				etest.log(Status.PASS,"Visitor was present in Visitor History List after he has left the website");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY2",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor was not present in Visitor History List after he has left the website");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorPresentInVisitorHistory","Exception",e);
		}
	}

	public static void checkVisitorDetailsInVisitorHistory(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);

			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			String uuid = CommonFunctionsVH.getUuid(driver,visitorId);
			String visitorCol = "col0_"+uuid;
			String nameId = "name_"+visitorId;
			String vName = CommonUtil.getElement(driver,By.id(nameId)).getText();
			CommonFunctionsTR.waitTillVisitorPresentInRings(driver,visitorId);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorId)));
			try
			{
				CommonWait.waitTillDisplayed(driver,ldSettings);
			}
			catch(Exception e)
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorId)));
				CommonWait.waitTillDisplayed(driver,ldSettings);
			}
			String visitIp = CommonUtil.getElement(driver,ldSettings,visitsInfoDiv,box4).getText();
			visitor_driver.quit();

			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			CommonFunctionsVH.createLastVisitedTodayList(driver);

			CommonWait.waitTillDisplayed(driver,By.id(visitorCol));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorCol)));
			CommonWait.waitTillDisplayed(driver,listInfo);

			if(visitIp.contains(CommonUtil.getElement(driver,By.id(visitorCol),By.tagName("span")).getAttribute("title")))
			{
				etest.log(Status.PASS,"Visitors Country was found to be correct");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY3",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Country was found to be incorrect");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(visitIp.contains(CommonUtil.getElement(driver,By.id(visitorCol),By.id("name_"+uuid)).getText()))
			{
				etest.log(Status.PASS,"Visitor IP Adress was found to be correct");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY4",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor IP Adress was found to be incorrect");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(uuid.equals(CommonUtil.getElement(driver,listInfo).getAttribute("uuid")))
			{
				etest.log(Status.PASS,"Visitor Details opened on clicking Visitor from visitor history");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY5",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor Details opened on clicking Visitor from visitor history");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonUtil.getElement(driver,listInfo,visitorInfoDiv,visitorInfo,By.tagName("span")).getText().contains(vName))
			{
				etest.log(Status.PASS,"Visitors Name was found to be correct");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY6",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Name was found to be incorrect");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorDetailsInVisitorHistory","Exception",e);
		}
	}

	public static void checkCRMInfoInVisitorHistory(WebDriver driver,ExtentTest etest)
	{
		int i = 0;
		String keyCRMP = "CRMP_VISITOR_HISTORY";
		String key ;
		try
		{
			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			String uuid = CommonFunctionsVH.getUuid(driver,visitorId);
			String visitorCol = "col0_"+uuid;
			CRMPChatWindow.quickChat(driver,visitor_driver,etest);
			visitor_driver.quit();
			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);

			CommonFunctionsVH.createLastVisitedTodayList(driver);

			CommonWait.waitTillDisplayed(driver,By.id(visitorCol));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorCol)));

			try
			{
				CommonWait.waitTillDisplayed(driver,behaviourAndCRMInfo);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

			if(CommonWait.isDisplayed(driver,behaviourAndCRMInfo))
			{
				etest.log(Status.INFO,"Behaviour info was displayed");
				List<WebElement> visitInfo = CommonUtil.getElement(driver,behaviourAndCRMInfo,By.tagName("ul")).findElements(By.tagName("li"));
				for(WebElement info : visitInfo)
				{
					key = keyCRMP + (7+i);
					if(info.getAttribute("purpose").contains(purpose[i]) && info.getText().contains(behaviourCRMInfo[i]))
					{
						etest.log(Status.INFO,behaviourCRMInfo[i]+" was found in Visitor History ");
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put(key,true);
					}
					else
					{
						etest.log(Status.FAIL,behaviourCRMInfo[i]+" was not found in visitor history");
						TakeScreenshot.screenshot(driver,etest);
					}
					key = keyCRMP + (9+i);
					CommonUtil.clickWebElement(driver,info);
					try
					{
						CommonUtil.waitTillWebElementContainsAttributeValue(info,"class","bdr_sel");
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					if(info.getAttribute("class").contains("bdr_sel"))
					{
						etest.log(Status.INFO,"Info was clicked and selected");
						result.put(key,true);
					}
					else
					{
						etest.log(Status.FAIL,"Info clicked was not highlighted");
						TakeScreenshot.screenshot(driver,etest);
					}
					key = keyCRMP + (11+i);
					if(CommonWait.isDisplayed(driver,By.id(purpose[i])))
					{
						etest.log(Status.PASS,"Respective info was displayed on clicking "+behaviourCRMInfo[i]);
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put(key,true);
					}
					else
					{
						etest.log(Status.FAIL,"Respective info was not displayed on clicking "+behaviourCRMInfo[i]);
						TakeScreenshot.screenshot(driver,etest);
					}
					i++;
				}
				if(i==1)
				{
					etest.log(Status.FAIL,"CRM info was not displayed");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Behaviour info was not displayed");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMInfoInVisitorHistory","Exception",e);
		}
	}

	public static void checkReturningVisitor(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);

			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			String uuid = CommonFunctionsVH.getUuid(driver,visitorId);
			String visitorCol = "col0_"+uuid;
			visitor_driver.get("https://www.zoho.com");

			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitor_driver.quit();
			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			CommonFunctionsVH.createLastVisitedTodayList(driver);

			CommonWait.waitTillDisplayed(driver,By.id(visitorCol));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorCol)));
			CommonWait.waitTillDisplayed(driver,listInfo,visitorInfoDiv,visitType);
			CommonUtil.sleep(1000);

			if(CommonUtil.getElement(driver,listInfo,visitorInfoDiv,visitType).getText().contains("Returning"))
			{
				etest.log(Status.PASS,"Visitor Type Returning was found in Visitor Details");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY13",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor Type Returning was not found in visitor details");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkReturningVisitor","Exception",e);
		}
	}

	public static void checkVisitorTabsInVisitorHistory(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);

			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			String uuid = CommonFunctionsVH.getUuid(driver,visitorId);
			String visitorCol = "col0_"+uuid;
			visitor_driver.quit();

			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			CommonFunctionsVH.createLastVisitedTodayList(driver);

			CommonWait.waitTillDisplayed(driver,By.id(visitorCol));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorCol)));
			CommonWait.waitTillDisplayed(driver,listInfo);

			if((CommonUtil.getElement(driver,listInfo,listHeader).getText().contains("Visitor Info"))
				&& (CommonUtil.getElement(driver,listInfo,listHeader).getText().contains("Visits")) 
				 && (CommonUtil.getElement(driver,listInfo,listHeader).getText().contains("Actions")))
			{
				etest.log(Status.INFO,"Visitor tabs are present In Visitor History details view of a visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_VISITOR_HISTORY14",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor tabs are not present in Visitor History details view of a visitor");
				TakeScreenshot.screenshot(driver,etest);
			}

			int i = 0;
			List<WebElement> headerTabList = CommonUtil.getElement(driver,listInfo,listHeader,By.tagName("ul")).findElements(By.tagName("li"));
			for(WebElement headerTab : headerTabList)
			{
				String key = "CRMP_VISITOR_HISTORY"+(15+i++);
				String id = headerTab.getAttribute("purpose");
				CommonUtil.clickWebElement(driver,headerTab);
				CommonUtil.waitTillWebElementContainsAttributeValue(headerTab,"class","bdr_sel");
				if(CommonWait.isPresent(driver,By.id(id)))
				{
					etest.log(Status.PASS,headerTab.getText()+" tab was clicked and its respective was opened");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,headerTab.getText()+" tab was clicked but its respective tab was not opened");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorTabsInVisitorHistory","Exception",e);
		}
	}

	public static void checkChatTranscriptOfVisitorInVisitorHistory(WebDriver driver,ExtentTest etest)
	{
		try
		{
			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			String uuid = CommonFunctionsVH.getUuid(driver,visitorId);
			String visitorCol = "col0_"+uuid;
			CRMPChatWindow.quickChat(driver,visitor_driver,etest);
			visitor_driver.quit();
			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);

			CommonFunctionsVH.createLastVisitedTodayList(driver);

			CommonWait.waitTillDisplayed(driver,By.id(visitorCol));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorCol)));

			CommonWait.waitTillDisplayed(driver,listInfo);

			List<WebElement> infoHeaders = CommonUtil.getElement(driver,listInfo).findElements(listHeader);

			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(infoHeaders.get(0).findElements(By.tagName("li")),"purpose",actionsDiv));

			if(CommonWait.isDisplayed(driver,By.id(actionsDiv)))
			{
				etest.log(Status.INFO,"Actions Div was displayed on clicking Actions in header of Visitor History info");
				TakeScreenshot.infoScreenshot(driver,etest);
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(actionsDiv),actionItem));
				try
				{
					CommonWait.waitTillDisplayed(driver,actionData);
					if(CommonWait.isDisplayed(driver,actionData))
					{
						etest.log(Status.PASS,"Chat Transcript was displayed on clicking 'Chat Ended' in Actions Tab");
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put("CRMP_VISITOR_HISTORY18",true);
					}
					else
					{
						etest.log(Status.FAIL,"Chat Transcript was not displayed on clicking 'Chat Ended' in Actions Tab");
						TakeScreenshot.screenshot(driver,etest);
					}
				}
				catch(Exception e)
				{
					etest.log(Status.FAIL,"Chat Transcript was not displayed on clicking 'Chat Ended' in Actions Tab");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Actions Div was not displayed on clicking Actions in header of Visitor History Info");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkChatTranscriptOfVisitorInVisitorHistory","Exception",e);
		}
	}
}
