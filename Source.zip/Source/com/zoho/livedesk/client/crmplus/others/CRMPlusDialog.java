//$Id$
package com.zoho.livedesk.client.crmplus.others;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.zoho.livedesk.util.common.*;

public class CRMPlusDialog
{
	public static final By
	CRMPLUS_DIALOG = By.id("crmplus-dialog"),
	CRMPLUS_DIALOG_HEADER = By.id("crmplus-dialog-header"),
	CRMPLUS_DIALOG_BODY = By.id("crmplus-dialog-body"),
	CRMPLUS_APPS_ADDUSER = By.id("crmplus-apps-adduser"),
	CRMPLUS_DIALOG_ADDUSER = By.id("crmplus-dialog-button"),
	CRMPLUS_DIALOG_ERROR = By.id("crmplus-dialog-error"),
	CRMPLUS_APPS_ADDUSER_EMAIL = By.id("crmplus-apps-adduser-email"),
	SALESIQ_ROLES = By.id("salesiq-roles"),
	SALESIQ_ROLE = By.id("salesiq-role"),
	SALESIQ_ROLES_OPTIONS = By.id("salesiq-roles-options"),
	ADMINPANEL_FIXED_POP = By.id("adminpanel-fixed-pop"),
	SALESIQ_MONITOR_USER = By.id("salesiq-monitor-user"),
	SALESIQ_MONITOR_CONT = By.id("salesiq-monitor-cont"),
	CRMPLUS_APPS_ADDUSER_CONTAINER = By.id("crmplus-apps-adduser-container"),
	GREYTXT = By.className("greyTxt"),
	ZCRMP_USRCOMPREMV = By.className("zcrmp-usrCompRemv"),
	STATUS_MESSAGE = By.id("status-message")
	;

	public static final String
	SALESIQ_DEP = "salesiq-dep-dept_id",
	SALESIQ_DEPT_CHECKBOX = "#crmplus-dialog #salesiq-dep-dept_id-check",
	INVALID_EMAIL = "testinvalidemail",
	INVALID_EMAIL_ERROR = "Please enter a valid email address.",
	WITHOUT_EMAIL_ERROR = "Select at least one user",
	WITHOUT_BOTH_EMAIL_AND_DEPARTMENT_ERROR = "Please select at least one user and assign appropriate privileges",
	WITHOUT_DEPARTMENT_ERROR = "Please assign the department(s)",
	NEW_USER = "NEW USER",
	ROLE_ID = "role-id",
	ADMIN_ROLE_ID = "1",
	SUPERVISOR_ROLE_ID = "2",
	ASSOCIATE_ROLE_ID = "3",
	AUTOSUG_USERSTATUS_CLASSNAME = "autosug-userstatus",
	OPERATOR_ADDED_BANNER = "User assigned to the selected applications"
	;

	public static void clickAccept(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,CRMPLUS_DIALOG_ADDUSER);
	}

	public static String getErrorMessage(WebDriver driver)
	{
		CommonWait.waitTillDisplayed(driver,CRMPLUS_DIALOG_ERROR);
		CommonUtil.waitTillWebElementDoesNotContainAttributeValue(CommonUtil.getElement(driver,CRMPLUS_DIALOG_ERROR),"innerHTML","");
		return CommonUtil.getElement(driver,CRMPLUS_DIALOG_ERROR).getAttribute("innerText");
	}

	// to get the second line after the mail address -- this will give error message if any or return the same mail address if no error
	public static String getMailByLineText(WebDriver driver)
	{
		return CommonUtil.getElement(driver,CRMPLUS_APPS_ADDUSER_CONTAINER,GREYTXT).getAttribute("innerText");
	}

	public static String getAdminPanelFixedPopText(WebDriver driver)
	{
		return CommonUtil.getElement(driver,CRMPlusDialog.ADMINPANEL_FIXED_POP,CRMPlusDialog.GREYTXT).getAttribute("innerText");
	}

	public static void selectDeptWithId(WebDriver driver,String deptID)
	{
		String deptCheckId = SALESIQ_DEPT_CHECKBOX.replace("dept_id",deptID);
		CommonUtil.jsClick(driver,deptCheckId);
	}

	public static void enterMail(WebDriver driver,String email)
	{
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,CRMPLUS_DIALOG,CRMPLUS_APPS_ADDUSER_EMAIL),"");
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,CRMPLUS_DIALOG,CRMPLUS_APPS_ADDUSER_EMAIL),email);
		try
		{
			CommonWait.waitTillDisplayed(driver,ADMINPANEL_FIXED_POP);
			CommonUtil.clickWebElement(driver,ADMINPANEL_FIXED_POP,GREYTXT);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public static void clickRemoveIcon(WebDriver driver)
	{
		CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,CRMPLUS_DIALOG,CRMPLUS_APPS_ADDUSER_CONTAINER,GREYTXT));
		CommonUtil.clickWebElement(driver,CRMPLUS_DIALOG,CRMPLUS_APPS_ADDUSER_CONTAINER,ZCRMP_USRCOMPREMV);
	}

	public static void selectRole(WebDriver driver,String role_id)
	{
		CommonUtil.clickWebElement(driver,CRMPLUS_DIALOG,SALESIQ_ROLE);
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,ADMINPANEL_FIXED_POP).findElements(By.tagName("li")),ROLE_ID,role_id));
	}
}