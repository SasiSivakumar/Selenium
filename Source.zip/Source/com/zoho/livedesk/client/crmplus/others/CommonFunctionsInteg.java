//$Id$
package com.zoho.livedesk.client.crmplus.others;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;


public class CommonFunctionsInteg
{
	public static By
	cusHistoryFilter = By.id("cushistoryfilter"),
	integTab = By.id("setting_sm_integration"),
	excessHeader = By.id("excessheader");

	public static void clickIntegrationTab(WebDriver driver) throws Exception
	{
		CRMPlusCommonUtil.clickSettings(driver);
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
		try
		{
			CommonWait.waitTillDisplayed(driver,integTab);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		Tab.clickInteg(driver);
	}

	public static void clickInteg(WebDriver driver,String app) throws Exception
	{
		try
		{
			CommonWait.waitTillDisplayed(driver,excessHeader);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(CommonWait.isDisplayed(driver,excessHeader))
		{
			CommonUtil.clickWebElement(driver,excessHeader);
		}
		clickIntegrationTab(driver);
		Integration.selectIntegApp(driver,app);
	}

	public static void disableIntegration(WebDriver driver,ExtentTest etest,String app) throws Exception
	{
		String expectedBannerText = app+" Integration disabled successfully";
		clickInteg(driver,app);
		if(app.equals("Zoho CRM"))
		{
			Integration.clickDisableIntegration(driver,expectedBannerText,true,etest);
		}
		else
		{
			Integration.clickDisableIntegration(driver,expectedBannerText,app,etest);
		}
		CRMPlusCommonUtil.closeSettings(driver);
	}

	public static void enableIntegration(WebDriver driver,ExtentTest etest,String app) throws Exception
	{
		String expectedBannerText = app+" Integration enabled successfully";
		clickInteg(driver,app);
		Integration.clickEnableIntegration(driver,expectedBannerText,app,etest);
		CommonUtil.refreshPage(driver);
		CRMPlusCommonUtil.closeSettings(driver);
	}

	public static boolean checkEnable(WebDriver driver,String app) throws Exception
	{
		clickInteg(driver,app);
		return Integration.checkEnable(driver,app);
	}

	public static boolean checkDisable(WebDriver driver,String app) throws Exception
	{
		clickInteg(driver,app);
		return Integration.checkDisable(driver,app);
	}

	public static String getKey(String app,int count)
	{
		return "CRMP_INTEG_"+app.substring(app.indexOf(" ")+1, app.length()).toUpperCase()+count;
	}

	public static String getTabName(String tab)
	{
		return tab.substring(tab.indexOf("~")+2,tab.indexOf("-")-1);
	}

	public static String getTabId(String tab)
	{
		return tab.substring(tab.indexOf("-")+2,tab.length());
	}

	public static String getKeyCount(String tab)
	{
		return tab.substring(0,tab.indexOf("~")-1);
	}

	public static boolean isFilterFound(WebDriver driver,String filter)
	{
		List<WebElement> options = CommonUtil.getElement(driver,cusHistoryFilter).findElements(By.tagName("option"));
		for(WebElement option : options)
		{
			if(option.getText().contains(filter))
			{
				return true;
			}
		}
		return false;
	}
}