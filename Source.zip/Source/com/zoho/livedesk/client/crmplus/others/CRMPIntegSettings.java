//$Id$
package com.zoho.livedesk.client.crmplus.others;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.crmplus.chats.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

public class CRMPIntegSettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();
	public static ExtentTest etest;

	public static VisitorDriverManager visitor_driver_manager;
	public static WebDriver visitor_driver;

	public static By
	chatHistoryFilter = By.id("cushistoryfilter"),
	comboTitle = By.className("combotitle"),
	ulContainer = By.id("ulcontainer");

	public static String 
	deskFilterOptions[] = {"Converted as Ticket","Not Converted as Support Tickets","Added as Ticket"},
	crmFilterOptions[] = {"CRM Leads","CRM Contacts","CRM Deals","Not Available in CRM","Tracked in CRM"};

	public static String portalName,widgetCode;

	public static String
	moduleName = "CRMP Integ Settings",
	desk = "Zoho Desk",
	crm = "Zoho CRM",
	myChatsTab = "3 ~ My Chats - mycurrent",		//KEY ~ TAB_NAME - TAB_INDEX
	connectedTab = "4 ~ Connected - current",
	chatHistoryTab = "5 ~ Chat History - history",
	missedTab = "6 ~ Missed - missed";

	public static Hashtable testIntegSettings(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_INTEG_DESK",9);
			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_INTEG_CRM",11);

			// Disable Desk Integration and check the following
			etest = ComplexReportFactory.getTest("Disable Desk Integration");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkDisableIntegration(driver,etest,desk);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Initiate a chat and check ticket not generated");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketNotGenerated(driver,etest,myChatsTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Ticket not generated in Connected tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketNotGenerated(driver,etest,connectedTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check desk info not found in Chat history");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketNotGenerated(driver,etest,chatHistoryTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check ticket not generated for missed chats");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketNotGenerated(driver,etest,missedTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check filter options were not found related to desk");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkFilterOptionsNotFound(driver,etest,desk,deskFilterOptions);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Enable Desk Integration");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkEnableIntegration(driver,etest,desk);
			ComplexReportFactory.closeTest(etest);

			//Disable CRM integration and check the following
			etest = ComplexReportFactory.getTest("Disable CRM Integration");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkDisableIntegration(driver,etest,crm);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Initiate a chat and check if lead was not generated");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfoNotFound(driver,etest,myChatsTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM lead was not created in Connected tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfoNotFound(driver,etest,connectedTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM info not found in Chat history");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfoNotFound(driver,etest,chatHistoryTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM lead was not created for missed chats");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfoNotFound(driver,etest,missedTab);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check filter options were not found related to CRM");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkFilterOptionsNotFound(driver,etest,crm,crmFilterOptions);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Enable CRM Integration");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkEnableIntegration(driver,etest,crm);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkDisableIntegration(WebDriver driver,ExtentTest etest,String app)
	{
		try
		{
			String key = CommonFunctionsInteg.getKey(app,1);
			CommonFunctionsInteg.disableIntegration(driver,etest,app);
			CommonUtil.refreshPage(driver);
			if(CommonFunctionsInteg.checkDisable(driver,app))
			{
				etest.log(Status.PASS,app+" Integration was disabled");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,app+" Integration was not disabled");
				TakeScreenshot.screenshot(driver,etest);
			}
			CRMPlusCommonUtil.closeSettings(driver);
			CommonUtil.refreshPage(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkDisableIntegration","Exception",e);
		}
	}

	public static void checkEnableIntegration(WebDriver driver,ExtentTest etest,String app)
	{
		try
		{
			String key = CommonFunctionsInteg.getKey(app,2);
			CommonFunctionsInteg.enableIntegration(driver,etest,app);
			if(CommonFunctionsInteg.checkEnable(driver,app))
			{
				etest.log(Status.PASS,app+" Integration was enabled");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,app+" Integration was not enabled");
				TakeScreenshot.screenshot(driver,etest);
			}
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.closeSettings(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkEnableIntegration","Exception",e);
		}
	}

	public static void checkTicketNotGenerated(WebDriver driver,ExtentTest etest,String tab)
	{
		try
		{
			String tabName = CommonFunctionsInteg.getTabName(tab);
			String tabId = CommonFunctionsInteg.getTabId(tab);
			String keyCount = CommonFunctionsInteg.getKeyCount(tab);
			String key = "CRMP_INTEG_DESK"+keyCount;
			String tabDiv = tabId+"_div";
			if(tab.equals(myChatsTab))
			{
				CRMPlusCommonUtil.clickVisitorsOnline(driver);
				visitor_driver = visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CRMPChatWindow.quickOngoingChat(driver,visitor_driver,etest);
			}
			else if(tab.equals(chatHistoryTab))
			{
				CRMPChatWindow.closeAllChats(driver,etest);
			}
			else if(tab.equals(missedTab))
			{
				CRMPlusCommonUtil.clickVisitorsOnline(driver);
				visitor_driver = visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CRMPChatWindow.initiateChat(visitor_driver,etest);
				VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
			}

			CRMPlusCommonUtil.clickTabInSalesiq(driver,tabId);

			if(!tab.equals(myChatsTab))
			{
				CRMPChatWindow.clickLatestChat(driver,tabDiv);
			}

			if(!CommonFunctionsChatInteg.checkTicketGeneratedInSalesiq(driver))
			{
				etest.log(Status.PASS,"Desk info was not found in "+tabName+" tab when the desk integration was disabled");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk info was found in "+tabName+" tab even after the desk integration was disabled");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkTicketNotGenerated","Exception",e);
		}
	}

	public static void checkFilterOptionsNotFound(WebDriver driver,ExtentTest etest,String integ,String ...options)
	{
		try
		{
			int i = 7;
			CRMPlusCommonUtil.clickChatHistory(driver);
			CommonUtil.clickWebElement(driver,chatHistoryFilter,comboTitle);
			CommonWait.waitTillDisplayed(driver,chatHistoryFilter,ulContainer);
			for(String option : options)
			{
				String key = CommonFunctionsInteg.getKey(integ,i);
				i++;
				if(!CommonFunctionsInteg.isFilterFound(driver,option))
				{
					etest.log(Status.PASS,"<b>"+option+"</b> was not found in filter options after "+integ+" integration disabled");
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,"<b>"+option+"</b> was found in filter options even after "+integ+" integration was disabled");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			ChatHistory.closeFilter(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkFilterOptionsNotFound","Exception",e);
		}
	}

	public static void checkCRMInfoNotFound(WebDriver driver,ExtentTest etest,String tab)
	{
		try
		{
			String tabName = CommonFunctionsInteg.getTabName(tab);
			String tabId = CommonFunctionsInteg.getTabId(tab);
			String keyCount = CommonFunctionsInteg.getKeyCount(tab);
			String key = "CRMP_INTEG_CRM"+keyCount;
			String tabDiv = tabId+"_div";
			if(tab.contains(myChatsTab))
			{
				CRMPlusCommonUtil.clickVisitorsOnline(driver);
				visitor_driver = visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CRMPChatWindow.quickOngoingChat(driver,visitor_driver,etest);
			}

			CRMPlusCommonUtil.clickTabInSalesiq(driver,tabId);

			// if(!tab.equals(myChatsTab))
			// {
			// 	CRMPChatWindow.clickLatestChat(driver,tabDiv);
			// }
			// else 
			if (tab.equals(chatHistoryTab))
			{
				CRMPChatWindow.closeAllChats(driver,etest);
			}
			else if(tab.equals(missedTab))
			{
				CRMPlusCommonUtil.clickVisitorsOnline(driver);
				visitor_driver = visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CRMPChatWindow.initiateChat(visitor_driver,etest);
				VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
			}

			CRMPlusCommonUtil.clickTabInSalesiq(driver,tabId);

			if(!tab.equals(myChatsTab))
			{
				CRMPChatWindow.clickLatestChat(driver,tabDiv);
			}

			if(!CommonFunctionsChatInteg.isCRMInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"CRM info was not found in "+tabName+" tab when the CRM integration was disabled");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM info was found in "+tabName+" tab even after the CRM integration was disabled");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMInfoNotFound","Exception",e);
		}
	}
}
