//$Id$
package com.zoho.livedesk.client.crmplus.others;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.server.ResourceManager;

public class CommonFunctionsOthers
{
	public static final By
	PROFILE_PANEL = By.id("profilePanel"),
	PROFILE_ICON = By.id("prfileicon"),
	CLOSE_ICON = By.className("plus-close"),
	PROFILE_IMAGE = By.className("zcrmp-profileImg"),
	PROFILE_SCROLL_VIEW = By.id("crmpluscommonuiprofilescrollview"),
	CURRENT_STATUS = By.id("sidepanelagentchatsalesiqcurrentstatus"),
	STATUS_LIST = By.id("sidepanelagentchatsalesiqstatuslist"),
	ADMIN_PANEL = By.id("crmpluscommonuiadminpanel"),
	ADMIN_PANEL_TOP_BAR = By.id("commontopbaradminpanel"),
	SALESIQ_TOP_BAR = By.id("commontopbarsalesiq"),
	USER_VIEW = By.id("userview"),
	SALESIQ_APP = By.cssSelector("//*[@app='salesiq')]"),
	COMPANY_NAME = By.id("adminpanel-orgeditform-companyname"),
	PROCEED_BUTTON = By.id("onBoardProceedBtn"),
	STATUS_BANNER = By.id("status-message"),
	ACCESS_SALESIQ = By.id("crmplusoverviewloadingicon"),
	SALESIQ_MAIN_CONTAINER = By.id("maincontainer"),
	EMBED_CODE = By.id("wp_embedcode"),
	CRM_OVERVIEW = By.id("crmplusoverviewforservices")
	;

	public static final String 
	ACTIVE = "active",
	ACCESS_CRM_TEXT = "Access CRM"
	;

	public static void clickProfileIcon(WebDriver driver)
	{
		driver.switchTo().defaultContent();
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,PROFILE_ICON,PROFILE_IMAGE));
		CommonWait.waitTillDisplayed(driver,PROFILE_PANEL);
	}

	public static void closeProfilePanel(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,PROFILE_SCROLL_VIEW,CLOSE_ICON));
		CommonWait.waitTillHidden(driver,PROFILE_PANEL);
	}

	public static void changeStatus(WebDriver driver,String toStatus)
	{
		clickProfileIcon(driver);
		CommonWait.waitTillDisplayed(driver,PROFILE_PANEL);
		CommonUtil.sleep(500);
		CommonUtil.clickWebElement(driver,CURRENT_STATUS,By.tagName("span"));
		CommonWait.waitTillDisplayed(driver,STATUS_LIST);
		List<WebElement> statuses = CommonUtil.getElement(driver,STATUS_LIST).findElements(By.tagName("li"));
		for(WebElement status : statuses)
		{
			String statusInList = status.getText();
			if(statusInList.equals(toStatus))
			{
				CommonUtil.clickWebElement(driver,status);
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,CURRENT_STATUS),"innerText",statusInList);
				break;
			}
		}
		closeProfilePanel(driver);
	}

	public static void openAdminPanel(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,ADMIN_PANEL);
		CommonWait.waitTillDisplayed(driver,USER_VIEW);
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,USER_VIEW),"style","block");
	}

	public static void clickAdminPanelOnTopBar(WebDriver driver)
	{
		driver.switchTo().defaultContent();
		CommonUtil.clickWebElement(driver,ADMIN_PANEL_TOP_BAR,By.tagName("a"));
		CommonWait.waitTillDisplayed(driver,USER_VIEW);
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,USER_VIEW),"style","block");
		CommonUtil.sleep(5000);
	}

	public static void clickSalesiqOnTopBar(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,SALESIQ_TOP_BAR,By.tagName("a"));
		CommonWait.waitTillDisplayed(driver,By.id("salesiqLoadFrame"));
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
	}

	public static boolean checkOperatorListedInAdminPanel(WebDriver driver,String operator_email,ExtentTest etest)
	{
		int failcount = 0;
		try
		{
			clickAdminPanelOnTopBar(driver);
			String tableBodyText = CommonUtil.getElement(driver,By.id("userview-table-body")).getAttribute("innerText");
			if(tableBodyText.contains(operator_email))
			{
				etest.log(Status.INFO,"Operator was found in the list");
				TakeScreenshot.infoScreenshot(driver,etest);

				List<WebElement> listOfUsers = CommonUtil.getElement(driver,By.id("userview-table-body")).findElements(By.tagName("tr"));
				WebElement operator = CommonUtil.getElementByAttributeValue(listOfUsers,"innerText",operator_email);
				WebElement operatorSalesiqStatus = CommonUtil.getElementByAttributeValue(operator.findElements(By.tagName("td")),"app","salesiq");

				if(operatorSalesiqStatus.getAttribute("status").contains(ACTIVE))
				{
					etest.log(Status.INFO,"Salesiq status is active for the newly added user");
					TakeScreenshot.infoScreenshot(driver,etest);
				}
				else
				{
					etest.log(Status.INFO,"Salesiq status is disabled for the newly added user");
					TakeScreenshot.infoScreenshot(driver,etest);
					failcount++;
				}
			}
			else
			{
				etest.log(Status.INFO,"Operator was not found in the list");
				TakeScreenshot.infoScreenshot(driver,etest);
				failcount++;
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.infoScreenshot(driver,etest);
			failcount++;
		}
		clickSalesiqOnTopBar(driver);
		return CommonUtil.returnResult(failcount);
	}

	public static void gotoCrmplusUrl(WebDriver driver)
	{
		if(com.zoho.livedesk.util.Util.siteNameout().contains("local"))
		{
			driver.get("https://crmplus.localzoho.com/");
		}
		else
		{
			driver.get("https://crmplus.zoho.com/");
		}
	}

	public static void fillUpInitialForm(WebDriver driver)
	{
		String companyName = "company"+CommonUtil.getUniqueMessage();
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,COMPANY_NAME),companyName);
		CommonUtil.clickWebElement(driver,PROCEED_BUTTON,By.tagName("span"));
		CommonWait.waitTillDisplayed(driver,CRM_OVERVIEW);
		CommonUtil.sleep(20000); // wait till crm gets loaded
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,CRM_OVERVIEW),"innerText",ACCESS_CRM_TEXT);
	}

	public static void clickAccessSalesiq(WebDriver driver)
	{
		driver.switchTo().defaultContent();
		CommonUtil.clickWebElement(driver,ACCESS_SALESIQ);
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
		CommonWait.waitTillDisplayed(driver,SALESIQ_MAIN_CONTAINER);
	}

	public static boolean checkSalesiqPageOpened(WebDriver driver,ExtentTest etest)
	{
		String actualWelcomePageText = CommonUtil.getElement(driver,SALESIQ_MAIN_CONTAINER).getAttribute("innerText");
		String expectedWelcomePageText = ResourceManager.getRealValue("salesiq_welcomepage_text");

		return CommonUtil.checkStringContainsAndLog(expectedWelcomePageText,actualWelcomePageText,"Welcome page text",etest);
	}
}
