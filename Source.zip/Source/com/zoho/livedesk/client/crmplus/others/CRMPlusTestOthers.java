//$Id$
package com.zoho.livedesk.client.crmplus.others;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

public class CRMPlusTestOthers
{
	public static ExtentTest etest;
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();

	public static By
	profileScrollView = By.id("crmpluscommonuiprofilescrollview"),
	profilePanel = By.id("profilePanel"),
	closeIcon = By.className("plus-close"),
	salesiqOptions = By.id("crmpluscommonuispecificoption"),
	salesiqOptionsDiv = By.id("crmpluscommonuispecificoptiondiv"),
	salesiqOptionsHeader = By.id("crmpluscommonuispecificoptionheader"),
	personalizeOption = By.id("salesiq_specificoptions_personlaize"),
	keyboardShortuctOption = By.id("salesiq_specificoptions_keyboardshortcut"),
	salesiqPortalsOption = By.id("salesiq_specificoptions_myportals"),
	userPreferences = By.id("userPreference"),
	sounds = By.id("sounds"),
	tabHeader = By.className("tabnav"),
	close = By.className("sqico-close"),
	helpShortcut = By.id("shorcut_help"),
	helpShortcutHeader = By.className("hdr"),
	currentStatus = By.id("sidepanelagentchatsalesiqcurrentstatus"),
	statusList = By.id("sidepanelagentchatsalesiqstatuslist");

	public static String
	moduleName = "CRMP Test Others",
	salesiqHeader = "SALESIQ OPTIONS",
	personalizeText = "Personalize",
	keyboardShortcutText = "Keyboard Shortcuts",
	salesiqPortalsText = "Other Salesiq Portals",
	visitorEventText = "Visitor Events",
	operatorEventText = "Operator Events",
	busy = "Busy",
	available = "Available",
	availableCode = "1",
	busyCode = "3";

	public static Hashtable testOthers(WebDriver driver)
	{
		try
		{
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_OTHERS",13);

			etest = ComplexReportFactory.getTest("Check Profile Panel");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkProfilePanel(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Salesiq Options in Profile Panel");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkSalesiqOptions(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Personalize options in Salesiq options in Profile panel");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkPersonalizeOptions(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Keyboard Shortcuts options in Salesiq options in Profile panel");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkKeyboardShortcutOptions(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Salesiq portals options in profile panel");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkSalesiqPortalsOptions(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Operator Status");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkAgentStatus(driver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred"+e);
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkProfilePanel(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsOthers.clickProfileIcon(driver);

			if(CommonWait.isDisplayed(driver,profilePanel))
			{
				etest.log(Status.PASS,"Profile Panel was displayed on clicking profile icon");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_OTHERS1",true);
			}
			else
			{
				etest.log(Status.FAIL,"Profile Panel was not displayed on clicking profile icon");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonWait.isDisplayed(driver,profilePanel))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,profileScrollView,closeIcon));
				CommonWait.waitTillHidden(driver,profilePanel);
				if(!CommonWait.isDisplayed(driver,profilePanel))
				{
					etest.log(Status.PASS,"Profile Panel was hidden on clicking close icon in profile panel");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_OTHERS2",true);
				}
				else
				{
					etest.log(Status.FAIL,"Profile Panel was not hidden on clicking close icon in profile panel");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Profile Panel was not displayed on clicking profile icon");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkProfilePanel","Exception",e);
		}
	}

	public static void checkSalesiqOptions(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsOthers.clickProfileIcon(driver);

			if(CommonWait.isPresent(driver,salesiqOptions) && (CommonUtil.getElement(driver,salesiqOptionsHeader).getText().contains(salesiqHeader)))
			{
				etest.log(Status.PASS,"Salesiq options were found in profile panel");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_OTHERS3",true);
			}
			else
			{
				etest.log(Status.FAIL,"Salesiq options were not found in profile panel");
				TakeScreenshot.screenshot(driver,etest);
			}

			CommonFunctionsOthers.closeProfilePanel(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkSalesiqOptions","Exception",e);
		}
	}

	public static void checkPersonalizeOptions(WebDriver driver,ExtentTest etest)
	{
		try
		{

			CommonFunctionsOthers.clickProfileIcon(driver);

			if(CommonUtil.getElement(driver,salesiqOptionsDiv).getText().contains(personalizeText))
			{
				etest.log(Status.INFO,"<b>Personalize</b> option was found under Salesiq options in profile panel");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_OTHERS4",true);

				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,personalizeOption));
				CRMPlusCommonUtil.switchToSalesiqFrame(driver);
				if(CommonWait.isPresent(driver,userPreferences) 
					&& (CommonWait.isPresent(driver,userPreferences,sounds)) 
					&& (CommonUtil.getElement(driver,userPreferences,sounds,tabHeader).getText().contains(visitorEventText)) 
					&& (CommonUtil.getElement(driver,userPreferences,sounds,tabHeader).getText().contains(operatorEventText)))
				{
					etest.log(Status.PASS,"Personalize window was found and it contains the respective tabs");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_OTHERS5",true);
				}
				else
				{
					etest.log(Status.FAIL,"Personalize window was not found");
					TakeScreenshot.screenshot(driver,etest);
				}

				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,userPreferences,close));

				if(!CommonWait.isDisplayed(driver,userPreferences))
				{
					etest.log(Status.PASS,"Personalize options window was hidden on clicking close icon");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_OTHERS6",true);
				}
				else
				{
					etest.log(Status.FAIL,"Personalize options window was not hidden on clicking close icon");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"<b>Personalize</b> option was not found under Salesiq options in Profile Panel");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkPersonalizeOptions","Exception",e);
		}
	}

	public static void checkKeyboardShortcutOptions(WebDriver driver,ExtentTest etest)
	{
		try
		{

			CommonFunctionsOthers.clickProfileIcon(driver);

			if(CommonUtil.getElement(driver,salesiqOptionsDiv).getText().contains(keyboardShortcutText))
			{
				etest.log(Status.INFO,"<b>Keyboard Shortcuts</b> option was found under Salesiq options in profile panel");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_OTHERS7",true);

				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,keyboardShortuctOption));
				CRMPlusCommonUtil.switchToSalesiqFrame(driver);

				if(CommonWait.isPresent(driver,helpShortcut) && (CommonUtil.getElement(driver,helpShortcut,helpShortcutHeader).getText().contains(keyboardShortcutText)))
				{
					etest.log(Status.PASS,"Keyboard Shortcut Window was displayed");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_OTHERS8",true);
				}
				else
				{
					etest.log(Status.FAIL,"Keyboard Shortcut Window was not displayed");
					TakeScreenshot.screenshot(driver,etest);
				}

				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,helpShortcut,close));

				try
				{
					CommonWait.waitTillHidden(driver,helpShortcut);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

				if(!CommonWait.isDisplayed(driver,helpShortcut))
				{
					etest.log(Status.PASS,"Keyboard Shortcut options window was hidden on clicking close icon");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_OTHERS9",true);
				}
				else
				{
					etest.log(Status.FAIL,"Keyboard Shortcut options window was not hidden on clicking close icon");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"<b>Keyboard Shortcuts</b> option was not found under Salesiq options in Profile Panel");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkKeyboardShortcutOptions","Exception",e);
		}
	}

	public static void checkSalesiqPortalsOptions(WebDriver driver,ExtentTest etest)
	{
		try
		{

			CommonFunctionsOthers.clickProfileIcon(driver);

			if(CommonUtil.getElement(driver,salesiqOptionsDiv).getText().contains(salesiqPortalsText))
			{
				etest.log(Status.INFO,"<b>Other Salesiq Portals</b> option was found under Salesiq options in profile panel");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_OTHERS10",true);

				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,salesiqPortalsOption));
				if(CommonUtil.getTabsCount(driver) > 1)
				{
					CommonUtil.switchToTab(driver,1);
					if(driver.getCurrentUrl().contains("portal.do"))
					{
						etest.log(Status.PASS,"Other Salesiq portals window was opened on clicking <b>Other Salesiq Portals</b> under Salesiq options in Profile Panel");
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put("CRMP_OTHERS11",true);
					}
					else
					{
						etest.log(Status.FAIL,"Other Salesiq portals window was not opened on clicking <b>Other Salesiq Portals</b> under Salesiq options in Profile Panel");
						TakeScreenshot.screenshot(driver,etest);
					}
					driver.close();
					CommonUtil.switchToTab(driver);
				}
				else
				{
					etest.log(Status.FAIL,"Other Salesiq portals window was not opened on clicking <b>Other Salesiq Portals</b> under Salesiq options in Profile Panel");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"<b>Other Salesiq Portals</b> option was not found under Salesiq options in Profile Panel");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkSalesiqPortalsOptions","Exception",e);
		}
	}

	public static void checkAgentStatus(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsOthers.changeStatus(driver,busy);
			driver.switchTo().defaultContent();
			if(CommonUtil.getElement(driver,currentStatus).getAttribute("currstatus").contains(busyCode))
			{
				etest.log(Status.PASS,"Agent Status was changed to busy");
				CommonFunctionsOthers.clickProfileIcon(driver);
				TakeScreenshot.infoScreenshot(driver,etest);
				CommonFunctionsOthers.closeProfilePanel(driver);
				result.put("CRMP_OTHERS12",true);
			}
			else
			{
				etest.log(Status.FAIL,"Agent status was not changed to busy");
				CommonFunctionsOthers.clickProfileIcon(driver);
				TakeScreenshot.screenshot(driver,etest);
				CommonFunctionsOthers.closeProfilePanel(driver);
			}

			CommonUtil.sleep(1000);
			CommonFunctionsOthers.changeStatus(driver,available);
			driver.switchTo().defaultContent();
			if(CommonUtil.getElement(driver,currentStatus).getAttribute("currstatus").contains(availableCode))
			{
				etest.log(Status.PASS,"Agent Status was changed to available");
				CommonFunctionsOthers.clickProfileIcon(driver);
				TakeScreenshot.infoScreenshot(driver,etest);
				CommonFunctionsOthers.closeProfilePanel(driver);
				result.put("CRMP_OTHERS13",true);
			}
			else
			{
				etest.log(Status.FAIL,"Agent status was not changed to available");
				CommonFunctionsOthers.clickProfileIcon(driver);
				TakeScreenshot.screenshot(driver,etest);
				CommonFunctionsOthers.closeProfilePanel(driver);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkAgentStatus","Exception",e);
		}
	}
}
