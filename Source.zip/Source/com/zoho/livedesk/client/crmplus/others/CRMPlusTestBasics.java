//$Id$
package com.zoho.livedesk.client.crmplus.others;

import java.util.List;
import java.util.Hashtable;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class CRMPlusTestBasics
{
	public static ExtentTest etest;
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();

	public static final By
	TEXT = By.className("txtelips"),
	ADD_USER_INPUT = By.id("adduserinput"),
	ADD_USER = By.id("buttonuseradd"),
	ULISTTABLE = By.id("ulisttable"),
	LIST_ROW = By.className("list-row"),
	ULIST_EMAIL = By.className("ulist_email"),
	LIST_HILIGHT = By.className("list_hilight"),
	U_ROLWT = By.className("u_rolwt"),
	AJAXSTATUS = By.id("ajaxstatus"),
	ADDDEPT_USER = By.id("adddept_user"),
	ADDDEPT_USERAUTO = By.id("adddept_userauto"),
	ASSOCIATEDUSERS = By.id("associatedusers"),
	ASOCT_USERSPAN = By.className("asoct_userspan"),
	RMUSER_ICON = By.className("rmuser_icon")
	;

	public static final String
	MODULE_NAME = "CRMP Basics",
	TEST_DEPARTMENT = "test",
	ADD_OPERATOR_TEXT = "Add operator",
	DELETE_TEXT = "Delete",
	RE_INVITE_TEXT = "Re-Invite",
	EXPECTED_ROLE = "Associate",
	OPERATOR_DELETED_BANNER = "Operator deleted successfully",
	UPDATED_MESSAGE = "Updated successfully"
	;

	public static String
	newOperatorEmail = "testnew@qa.com",
	existingOperatorEmail = "test@test.com",
	defaultDepartmentId = ""
	;

	public static Hashtable testBasics(WebDriver driver)
	{
		WebDriver newDriver = null;
		try
		{
			newOperatorEmail = "user"+CommonUtil.getUniqueMessage()+"@qa.team";
			existingOperatorEmail = ExecuteStatements.getUserMail(driver);
			defaultDepartmentId = ExecuteStatements.getDepartmentID(driver,ExecuteStatements.getSystemGeneratedDepartment(driver));

			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			String default_user = ExecuteStatements.getUserName(driver);

			ArrayList<String> exceptions=new ArrayList<String>();
			exceptions.add(default_user);

			CRMPlusCommonUtil.deleteAllOperatorsExcept(driver,exceptions);

			// Add Operator 
			etest = ComplexReportFactory.getEtest("Check Invalid Inputs",MODULE_NAME);
			checkInvalidInputs(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Chat Monitor Option while adding an operator",MODULE_NAME);
			checkMonitorOption(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Add Operator",MODULE_NAME);
			checkAddOperator(driver,etest);
			ComplexReportFactory.closeTest(etest);

			// Associate Operator To A Department
			etest = ComplexReportFactory.getEtest("Check associate operator to department",MODULE_NAME);
			checkAssociateOperator(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check remove Associate",MODULE_NAME);
			checkRemoveAssociate(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Delete Operator",MODULE_NAME);
			checkDeleteOperator(driver,etest);
			ComplexReportFactory.closeTest(etest);

			newDriver = Functions.setUp();

			etest = ComplexReportFactory.getEtest("Check Signup new account",MODULE_NAME);
			checkSignup(newDriver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred"+e);
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(newDriver);
		}
		return finalResult;
	}

	public static void checkInvalidInputs(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickSettings(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			// Check Add Operator Text in Add Button
			String addOperatorText = CommonUtil.getElement(driver,ADD_USER).getAttribute("innerText");

			if(CommonUtil.checkStringContainsAndLog(ADD_OPERATOR_TEXT,addOperatorText,"ADD_OPERATOR_TEXT",etest))
			{
				result.put("CRMP_BASICS1",true);
			}
			else
			{
				result.put("CRMP_BASICS1",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			// Check Invalid Email Address Error
			// --> Without both
			CRMPlusCommonUtil.clickAddOperator(driver);
			CRMPlusDialog.clickAccept(driver);
			String actualMessage = CRMPlusDialog.getErrorMessage(driver);
			if(CommonUtil.checkStringContainsAndLog(CRMPlusDialog.WITHOUT_BOTH_EMAIL_AND_DEPARTMENT_ERROR,actualMessage,"WITHOUT_BOTH_EMAIL_AND_DEPARTMENT_ERROR",etest))
			{
				result.put("CRMP_BASICS2",true);
			}
			else
			{
				result.put("CRMP_BASICS2",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			// --> without email
			CRMPlusDialog.selectDeptWithId(driver,defaultDepartmentId);
			CRMPlusDialog.clickAccept(driver);
			actualMessage = CRMPlusDialog.getErrorMessage(driver);
			if(CommonUtil.checkStringContainsAndLog(CRMPlusDialog.WITHOUT_EMAIL_ERROR,actualMessage,"WITHOUT_EMAIL_ERROR",etest))
			{
				result.put("CRMP_BASICS3",true);
			}
			else
			{
				result.put("CRMP_BASICS3",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			CRMPlusDialog.selectDeptWithId(driver,defaultDepartmentId);

			// --> invalid email
			CRMPlusDialog.enterMail(driver,CRMPlusDialog.INVALID_EMAIL);
			actualMessage = CRMPlusDialog.getAdminPanelFixedPopText(driver);
			if(CommonUtil.checkStringContainsAndLog(CRMPlusDialog.INVALID_EMAIL_ERROR,actualMessage,"INVALID_EMAIL_ERROR",etest))
			{
				result.put("CRMP_BASICS4",true);
			}
			else
			{
				result.put("CRMP_BASICS4",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			// --> Check existing user text
			CRMPlusDialog.enterMail(driver,existingOperatorEmail);
			actualMessage = CRMPlusDialog.getAdminPanelFixedPopText(driver);
			if(actualMessage.contains(existingOperatorEmail))
			{
				etest.pass("Existing user case -- SUCCESS");
				result.put("CRMP_BASICS5",true);
			}
			else
			{
				etest.fail("Existing user case -- FAIL");
				result.put("CRMP_BASICS5",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			// --> without department error
			CRMPlusDialog.clickRemoveIcon(driver);
			CRMPlusDialog.clickAccept(driver);
			actualMessage = CRMPlusDialog.getErrorMessage(driver);
			if(CommonUtil.checkStringContainsAndLog(CRMPlusDialog.WITHOUT_DEPARTMENT_ERROR,actualMessage,"WITHOUT_DEPARTMENT_ERROR",etest))
			{
				result.put("CRMP_BASICS6",true);
			}
			else
			{
				result.put("CRMP_BASICS6",false);
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkInvalidInputs","Exception",e);
		}
	}

	public static void checkMonitorOption(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.clickSettings(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			CommonWait.waitTillDisplayed(driver,ADD_USER);
			CommonUtil.clickWebElement(driver,ADD_USER);

			driver.switchTo().defaultContent();
			CommonWait.waitTillDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG);

			// Check Monitor Option
			CRMPlusDialog.selectRole(driver,CRMPlusDialog.ADMIN_ROLE_ID);
			if(!(CommonWait.isDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG,CRMPlusDialog.SALESIQ_MONITOR_CONT)))
			{
				result.put("CRMP_BASICS7",true);
				etest.pass("Chat monitor option was not found for Admin role");
			}
			else
			{
				result.put("CRMP_BASICS7",false);
				etest.fail("Chat monitor option was found for Admin role");
				TakeScreenshot.screenshot(driver,etest);
			}

			CRMPlusDialog.selectRole(driver,CRMPlusDialog.SUPERVISOR_ROLE_ID);
			if(CommonWait.isDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG,CRMPlusDialog.SALESIQ_MONITOR_CONT))
			{
				result.put("CRMP_BASICS8",true);
				etest.pass("Chat monitor option was found for Supervisor role");
			}
			else
			{
				result.put("CRMP_BASICS8",false);
				etest.fail("Chat monitor option was not found for Supervisor role");
				TakeScreenshot.screenshot(driver,etest);
			}

			CRMPlusDialog.selectRole(driver,CRMPlusDialog.ASSOCIATE_ROLE_ID);
			if(CommonWait.isDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG,CRMPlusDialog.SALESIQ_MONITOR_CONT))
			{
				result.put("CRMP_BASICS9",true);
				etest.pass("Chat monitor option was found for Associate role");
			}
			else
			{
				result.put("CRMP_BASICS9",false);
				etest.fail("Chat monitor option was not found for Associate role");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkMonitorOption","Exception",e);
		}
	}

	public static void checkAddOperator(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.clickSettings(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			CommonWait.waitTillDisplayed(driver,ADD_USER);
			CommonUtil.clickWebElement(driver,ADD_USER);

			driver.switchTo().defaultContent();
			CommonWait.waitTillDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG);

			// --> Check new user text
			CRMPlusDialog.enterMail(driver,newOperatorEmail);
			String actualMessage = CommonUtil.getElement(driver,CRMPlusDialog.ADMINPANEL_FIXED_POP).getAttribute("innerText");
			result.put("CRMP_BASICS10",CommonUtil.checkStringContainsAndLog(CRMPlusDialog.NEW_USER,actualMessage,"NEW_USER",etest));

			// check remove icon
			CommonUtil.sendEnterKey(driver,CommonUtil.getElement(driver,CRMPlusDialog.CRMPLUS_DIALOG,CRMPlusDialog.CRMPLUS_APPS_ADDUSER_EMAIL));
			CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,CRMPlusDialog.CRMPLUS_DIALOG,CRMPlusDialog.CRMPLUS_APPS_ADDUSER_CONTAINER,CRMPlusDialog.GREYTXT));
			result.put("CRMP_BASICS11",CommonWait.waitTillDisplayed(driver,CRMPlusDialog.CRMPLUS_DIALOG,CRMPlusDialog.CRMPLUS_APPS_ADDUSER_CONTAINER,CRMPlusDialog.ZCRMP_USRCOMPREMV));

			// check operator added
			String deptCheckId = CRMPlusDialog.SALESIQ_DEPT_CHECKBOX.replace("dept_id",defaultDepartmentId);
			CommonUtil.jsClick(driver,deptCheckId);
			CRMPlusDialog.clickAccept(driver);

			// check operator added banner
			CommonWait.waitTillDisplayed(driver,CRMPlusDialog.STATUS_MESSAGE);
			actualMessage = CommonUtil.getElement(driver,CRMPlusDialog.STATUS_MESSAGE).getAttribute("innerText");
			result.put("CRMP_BASICS12",CommonUtil.checkStringContainsAndLog(CRMPlusDialog.OPERATOR_ADDED_BANNER,actualMessage,"OPERATOR_ADDED_BANNER",etest));

			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			List<WebElement> operatorsList = CommonUtil.getElement(driver,ULISTTABLE).findElements(LIST_ROW);
			WebElement newOperatorElement = CommonUtil.getElementByAttributeValue(operatorsList,"innerText",newOperatorEmail);

			// check operator email
			actualMessage = CommonUtil.getElement(newOperatorElement,ULIST_EMAIL).getAttribute("innerText");
			result.put("CRMP_BASICS13",CommonUtil.checkStringContainsAndLog(newOperatorEmail,actualMessage,"newOperatorEmail",etest));

			// check delete and re-invite option
			actualMessage = CommonUtil.getElement(newOperatorElement,LIST_HILIGHT).getAttribute("innerText");
			result.put("CRMP_BASICS14",CommonUtil.checkStringContainsAndLog(DELETE_TEXT,actualMessage,"DELETE_TEXT",etest));
			result.put("CRMP_BASICS15",CommonUtil.checkStringContainsAndLog(RE_INVITE_TEXT,actualMessage,"RE_INVITE_TEXT",etest));

			// check expected role
			actualMessage = CommonUtil.getElement(newOperatorElement,U_ROLWT).getAttribute("innerText");
			result.put("CRMP_BASICS16",CommonUtil.checkStringContainsAndLog(EXPECTED_ROLE,actualMessage,"EXPECTED_ROLE",etest));

			if(CommonFunctionsOthers.checkOperatorListedInAdminPanel(driver,newOperatorEmail,etest))
			{
				result.put("CRMP_BASICS23",true);
				etest.log(Status.PASS,"Added Operator was found in the list of users under admin panel");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				result.put("CRMP_BASICS23",false);
				etest.log(Status.FAIL,"Added Operator was not found in the list of users under admin panel");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkAddOperator","Exception",e);
		}
	}

	public static void checkDeleteOperator(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.closeSettings(driver);
			CRMPlusCommonUtil.clickSettings(driver);

			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			List<WebElement> operatorsList = CommonUtil.getElement(driver,ULISTTABLE).findElements(LIST_ROW);
			WebElement newOperatorElement = CommonUtil.getElementByAttributeValue(operatorsList,"innerText",newOperatorEmail);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(newOperatorElement,LIST_HILIGHT,By.tagName("em")));
			HandleCommonUI.clickPositivePopupButton(HandleCommonUI.getPopupByInnerText(driver,DELETE_TEXT));

			CommonWait.waitTillDisplayed(driver,AJAXSTATUS);
			String actualMessage = CommonUtil.getElement(driver,AJAXSTATUS).getAttribute("innerText");
			result.put("CRMP_BASICS17",CommonUtil.checkStringContainsAndLog(OPERATOR_DELETED_BANNER,actualMessage,"OPERATOR_DELETED_BANNER",etest));

			if(!CommonFunctionsOthers.checkOperatorListedInAdminPanel(driver,newOperatorEmail,etest))
			{
				result.put("CRMP_BASICS24",true);
				etest.log(Status.PASS,"Removed Operator was not found in the list of users under admin panel");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				result.put("CRMP_BASICS24",false);
				etest.log(Status.FAIL,"Removed Operator was found in the list of users under admin panel");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkDeleteOperator","Exception",e);
		}
	}

	public static void checkAssociateOperator(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickDept(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			WebElement dept = Department.getDept(driver,TEST_DEPARTMENT);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(dept,TEXT));
			CommonWait.waitTillDisplayed(driver,ADD_USER_INPUT);
			// CommonSikuli.findInWholePage(driver,"department_add_icon.png","UI479",etest);

			CommonUtil.clickWebElement(driver,ADD_USER_INPUT,By.tagName("em"));
			CommonWait.waitTillDisplayed(driver,ADDDEPT_USER);
			// CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,ADDDEPT_USER),(newOperatorEmail.substring(0,newOperatorEmail.length()-2)));

			CommonUtil.clickWebElement(driver,ADDDEPT_USERAUTO,By.tagName("li"),TEXT);

			CommonWait.waitTillDisplayed(driver,AJAXSTATUS);

			try
			{
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,AJAXSTATUS),"innerText",UPDATED_MESSAGE);
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}

			String actualMessage = CommonUtil.getElement(driver,AJAXSTATUS).getAttribute("innerText");
			result.put("CRMP_BASICS18",CommonUtil.checkStringContainsAndLog(UPDATED_MESSAGE,actualMessage,"UPDATED_MESSAGE",etest));
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			actualMessage = CommonUtil.getElement(driver,ASSOCIATEDUSERS).getAttribute("innerHTML");

			if(actualMessage.contains(newOperatorEmail))
			{
				etest.pass("Operator was associated with the department");
				result.put("CRMP_BASICS19",true);
			}
			else
			{
				etest.pass("Operator was not associated with the department");
				result.put("CRMP_BASICS19",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkAssociateOperator","Exception",e);
		}
	}

	public static void checkRemoveAssociate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String expectedRemoveTitle = "Remove "+newOperatorEmail+" from this department";

			CRMPlusCommonUtil.clickDept(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			WebElement dept = Department.getDept(driver,TEST_DEPARTMENT);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(dept,TEXT));
			CommonWait.waitTillDisplayed(driver,ADD_USER_INPUT);
			CommonWait.waitTillDisplayed(driver,ASSOCIATEDUSERS);

			List<WebElement> associatedOperators = CommonUtil.getElement(driver,ASSOCIATEDUSERS).findElements(ASOCT_USERSPAN);

			WebElement expectedOperator = CommonUtil.getElementByAttributeValue(associatedOperators,"innerHTML",newOperatorEmail);
			CommonUtil.mouseHover(driver,CommonUtil.getElement(expectedOperator,By.tagName("img")));

			WebElement removeIcon = CommonUtil.getElement(expectedOperator,RMUSER_ICON);
			String actualMessage = removeIcon.getAttribute("title");
			result.put("CRMP_BASICS20",CommonUtil.checkStringContainsAndLog(expectedRemoveTitle,actualMessage,"expectedRemoveTitle",etest));

			CommonUtil.clickWebElement(driver,removeIcon);
			CommonWait.waitTillDisplayed(driver,AJAXSTATUS);
			try
			{
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,AJAXSTATUS),"innerText",UPDATED_MESSAGE);
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
			actualMessage = CommonUtil.getElement(driver,AJAXSTATUS).getAttribute("innerText");
			result.put("CRMP_BASICS21",CommonUtil.checkStringContainsAndLog(UPDATED_MESSAGE,actualMessage,"UPDATED_MESSAGE",etest));
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			actualMessage = CommonUtil.getElement(driver,ASSOCIATEDUSERS).getAttribute("innerHTML");

			if(!actualMessage.contains(newOperatorEmail))
			{
				etest.pass("Operator was removed from the department");
				result.put("CRMP_BASICS22",true);
			}
			else
			{
				etest.pass("Operator was not removed from the department");
				result.put("CRMP_BASICS22",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRemoveAssociate","Exception",e);
		}
	}

	public static void checkSignup(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String
			label = CommonUtil.getUniqueMessage(),
			name = "name"+label,
			email = "email"+label+"@qa.team",
			pwd = "Muzamil@12"
			;
			com.zoho.livedesk.client.NewAccount.CommonFunctionsNA.signup(driver,name,email,pwd);

			etest.log(Status.INFO,"After Signing up new portal");
			TakeScreenshot.infoScreenshot(driver,etest);

			CommonFunctionsOthers.gotoCrmplusUrl(driver);

			etest.log(Status.INFO,"After Navigating to crmplus url");
			TakeScreenshot.infoScreenshot(driver,etest);

			CommonFunctionsOthers.fillUpInitialForm(driver);

			etest.log(Status.INFO,"After creating a crmplus account");
			TakeScreenshot.infoScreenshot(driver,etest);

			try
			{
				CRMPlusCommonUtil.navToSalesiq(driver);

				etest.log(Status.INFO,"After accessing salesiq in crmplus");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			catch(Exception e)
			{
				CommonUtil.printStackTrace(e);
			}

			CommonFunctionsOthers.clickAccessSalesiq(driver);

			etest.log(Status.INFO,"After clicking access salesiq");
			TakeScreenshot.infoScreenshot(driver,etest);

			result.put("CRMP_BASICS25",CommonFunctionsOthers.checkSalesiqPageOpened(driver,etest));

			etest.log(Status.INFO,"After salesiq accessed");
			TakeScreenshot.infoScreenshot(driver,etest);

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkSignup","Exception",e);
		}
	}

}
