//$Id$
package com.zoho.livedesk.client.crmplus.rings;

import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

public class TrackingRings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();

	public static ExtentTest etest;

	public static String 
	moduleName = "CRMP Tracking Rings",
	visitorsOnline = "Visitors Online",
	daysVisited = "Days Visited",
	lastVisited = "Last Visited",
	visitorSource = "Visitor Score",
	noVisitorsMessage = "No one's stopped by so far. Have you set up visitor tracking for your website?";

	public static String widgetCode,portalName;

	public static By
	visitorsCount = By.id("plusVisitorsCount"),
	rings = By.id("ldwrap"),
	floatWidget = By.id("zsiq_float"),
	wmsToolBar = By.id("wmstoolbar"),
	visitorsIcon = By.id("plusVisitorIcon"),
	crmplusVisitorsOnlineUI = By.id("crmpluscommonui_visitorsonline"),
	crmplusHeader = By.className("zcrmp-QLheader"),
	crmplusVisitorsOnlineContainer = By.id("crmpluscommonui_visitors_container"),
	visitorsOnlineCountcrmplusUI = By.id("plusvisitorscountonpaneltop"),
	crmplusVisitorHistoryDetails = By.className("zcrmp-visitedHis");

	public static VisitorDriverManager visitor_driver_manager;
	public static WebDriver visitor_driver;

	public static Hashtable testRings(WebDriver driver) throws Exception
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			visitor_driver = visitor_driver_manager.getDriver(driver);
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_RINGS",17);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CRMP_RINGS1"));
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			result.put("CRMP_RINGS1",checkTrackingRings(driver,etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CRMP_RINGS2"));
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			result.put("CRMP_RINGS2",checkVisitorPresent(driver,visitor_driver,etest,true,true));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CRMP_RINGS3"));
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			result.put("CRMP_RINGS3",checkVisitorPresent(driver,visitor_driver,etest,true,false));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CRMP_RINGS4"));
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			result.put("CRMP_RINGS4",checkVisitorPresent(driver,visitor_driver,etest,false,true));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CRMP_RINGS5"));
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			result.put("CRMP_RINGS5",checkVisitorPresent(driver,visitor_driver,etest,false,false));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CRMP_RINGS6"));
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			result.put("CRMP_RINGS6",checkVisitorsOnlineCount(driver,etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRMPlus UI for Visitors Online");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMPlusUI(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check visitor details in CRMPlus UI");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkVisitorsInCRMPlusUI(driver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred"+e);
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static boolean checkTrackingRings(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			CommonFunctionsTR.clickRingsView(driver);
			if(CommonWait.isDisplayed(driver,rings))
			{
				etest.log(Status.PASS,"Tracking Rings was found");
				TakeScreenshot.infoScreenshot(driver,etest);
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Tracking Rings was not found");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkTrackingRings","Exception",e);
			return false;
		}
	}

	public static boolean checkVisitorPresent(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,boolean isRings,boolean isPresent)
	{
		try
		{
			String visitorPresentStatus = isPresent?"present":"left";
			String view = isRings?"Rings":"List";
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			if(isRings)
			{
				CommonFunctionsTR.clickRingsView(driver);
			}
			else
			{
				CommonFunctionsTR.clickListView(driver);
			}
			
			if(isPresent)
			{
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CommonWait.waitTillDisplayed(visitor_driver,floatWidget);
			}

			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);

			if(isPresent)
			{
				CommonFunctionsTR.waitTillVisitorPresentInRings(driver,visitorId);
			}
			else
			{
				visitor_driver.get("https://www.zoho.com");
				CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			}

			boolean isVisitorPresent = CommonWait.isPresent(driver,By.id(visitorId));

			if(isPresent == isVisitorPresent)
			{
				etest.log(Status.PASS,"visitor was "+visitorPresentStatus+" in "+view+" view");
				TakeScreenshot.infoScreenshot(driver,etest);
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Visitor was not "+visitorPresentStatus+" in "+view+" view");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorPresent","Exception",e);
			return false;
		}
	}

	public static boolean checkVisitorsOnlineCount(WebDriver driver,ExtentTest etest)
	{
		try
		{
			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);

			CRMPlusCommonUtil.clickVisitorsOnline(driver);

			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			CommonFunctionsTR.waitTillVisitorPresentInRings(driver,visitorId);
			String count = CommonUtil.getElement(driver,rings).findElements(By.className("visit_div")).size()+"";
			driver.switchTo().defaultContent();

			if(CommonWait.isPresent(driver,visitorsCount))
			{
				if(CommonUtil.getElement(driver,visitorsCount).getText().contains(count))
				{
					etest.log(Status.PASS,"Visitors online count was updated in CRMPlus UI");
					TakeScreenshot.infoScreenshot(driver,etest);
					return true;
				}
				else
				{
					etest.log(Status.INFO,"Expected : "+count+"<br>Actual : "+CommonUtil.getElement(driver,visitorsCount).getText());
					etest.log(Status.FAIL,"Visitors online count was not updated in CRMPlus UI");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
					return false;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Online count UI was not found in CRMPlus UI");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorsOnlineCount","Exception",e);
			return false;
		}
	}

	public static void checkCRMPlusUI(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			visitor_driver.quit();
			CommonFunctionsTR.waitTillVisitorLeaves(driver,visitorId);
			driver.switchTo().defaultContent();

			if(CommonWait.isPresent(driver,wmsToolBar,visitorsIcon))
			{
				etest.log(Status.PASS,"Visitors Icon was present in CRMPlus UI in WMS bar");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS7",true);

				WebElement plusVisitorsIcon = CommonUtil.getElement(driver,visitorsIcon);
				CommonUtil.clickWebElement(driver,plusVisitorsIcon);
				if(CommonWait.isPresent(driver,crmplusVisitorsOnlineUI))
				{
					etest.log(Status.PASS,"CRMPlus Visitors Online UI was displayed on clicking CRMPlus visitors icon");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_RINGS8",true);

					if(CommonUtil.getElement(driver,crmplusVisitorsOnlineUI,crmplusHeader).getText().contains(visitorsOnline))
					{
						etest.log(Status.PASS,"<b>Visitors Online</b> Text was found in CRMPlus Visitors Online UI");
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put("CRMP_RINGS9",true);

						if(CommonUtil.getElement(driver,crmplusVisitorsOnlineUI,crmplusVisitorsOnlineContainer).getText().contains(noVisitorsMessage))
						{
							etest.log(Status.PASS,"<b>No Visitors Online</b> message was found in CRMPlus Visitors Online UI");
							TakeScreenshot.infoScreenshot(driver,etest);
							result.put("CRMP_RINGS10",true);
						}
						else
						{
							etest.log(Status.FAIL,"<b>No Visitors Online</b> message was not found in CRMPlus Visitors Online UI");
							TakeScreenshot.screenshot(driver,etest);
						}
					}
					else
					{
						etest.log(Status.FAIL,"<b>Visitors Online</b> Text was not found in CRMPlus Visitors Online UI");
						TakeScreenshot.screenshot(driver,etest);
					}
				}
				else
				{
					etest.log(Status.FAIL,"CRMPlus Visitors online UI was not displayed on clicking CRMPlus visitors icon");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Icon was not present in CRMPlus UI in WMS bar");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMPlusUI","Exception",e);
		}
	}

	public static void checkVisitorsInCRMPlusUI(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);

			String visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);

			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			CommonFunctionsTR.waitTillVisitorPresentInRings(driver,visitorId);

			String nameId = "name_"+visitorId;
			String visitorNameInRings = CommonUtil.getElement(driver,By.id(visitorId),By.id(nameId)).getText();
			String country = CommonUtil.getElement(driver,By.id(visitorId)).getAttribute("title");
			String visitorIdInUI = "visitoronline"+visitorId;
			String visitorNameInUI = "visitorname"+visitorId;
			String pageVisitsCountInUI = "pagevisitscount"+visitorId;
			String pageTitleInUI = "pagetitle"+visitorId;

			driver.switchTo().defaultContent();

			if(!CommonWait.isPresent(driver,crmplusVisitorsOnlineUI))
			{
				WebElement plusVisitorsIcon = CommonUtil.getElement(driver,visitorsIcon);
				CommonUtil.clickWebElement(driver,plusVisitorsIcon);
			}

			if(CommonUtil.getElement(driver,visitorsOnlineCountcrmplusUI).getText().contains("1"))
			{
				etest.log(Status.PASS,"Visitors Online count was updated in CRMPlus UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS11",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Online count was not updated in CRMPlus UI");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonWait.isPresent(driver,crmplusVisitorsOnlineContainer,By.id(visitorIdInUI)))
			{
				etest.log(Status.PASS,"Visitors details was found in CRMPlus Visitors Online container");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS12",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitors details was not found in CRMPlus Visitors Online container");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonWait.isPresent(driver,crmplusVisitorsOnlineContainer,By.id(visitorNameInUI)) && CommonUtil.getElement(driver,crmplusVisitorsOnlineContainer,By.id(visitorNameInUI)).getText().contains(visitorNameInRings))
			{
				etest.log(Status.PASS,"Visitors Name was found in CRMplus UI and was verified with the visitor in rings");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS13",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Name was not found in CRMplus UI");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonUtil.getElement(driver,crmplusVisitorsOnlineContainer,By.id(visitorIdInUI)).getText().contains(country))
			{
				etest.log(Status.PASS,"Visitors Country was found in CRMplus UI and was verified with the visitor in rings");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS14",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitors Country was not found in CRMplus UI");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonWait.isPresent(driver,crmplusVisitorsOnlineContainer,By.id(pageVisitsCountInUI)))
			{
				etest.log(Status.PASS,"Page Visited Count was found in CRMplus UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS15",true);
			}
			else
			{
				etest.log(Status.FAIL,"Page Visited Count was not found in CRMplus UI");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonWait.isPresent(driver,crmplusVisitorsOnlineContainer,By.id(pageTitleInUI)) && CommonUtil.getElement(driver,crmplusVisitorsOnlineContainer,By.id(pageTitleInUI)).getText().contains("SalesIQ Testing"))
			{
				etest.log(Status.PASS,"Page Title was found in CRMplus UI and was verified with the visitor in rings");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS16",true);
			}
			else
			{
				etest.log(Status.FAIL,"Page Title was not found in CRMplus UI");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonWait.isPresent(driver,crmplusVisitorsOnlineContainer,crmplusVisitorHistoryDetails) && CommonUtil.getElement(driver,crmplusVisitorsOnlineContainer,crmplusVisitorHistoryDetails).getText().contains(daysVisited) && CommonUtil.getElement(driver,crmplusVisitorsOnlineContainer,crmplusVisitorHistoryDetails).getText().contains(lastVisited) && CommonUtil.getElement(driver,crmplusVisitorsOnlineContainer,crmplusVisitorHistoryDetails).getText().contains(visitorSource))
			{
				etest.log(Status.PASS,"Visitor History Details was found in CRMplus UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_RINGS17",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor History Details was not found in CRMplus UI");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorsInCRMPlusUI","Exception",e);
		}
	}
}
