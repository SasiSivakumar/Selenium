//$Id$
package com.zoho.livedesk.client.crmplus.rings;

import com.zoho.livedesk.util.common.*;
import com.google.common.base.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.FluentWait;

public class CommonFunctionsTR
{
	public static By
	customizeHeader = By.id("customizeheader"),
	rings = By.className("sqico-vo_ring"),
	list = By.className("sqico-vo_list"),
	ringsStatus = By.className("tgl_ticon");


	public static String getVisitorId(WebDriver visitorDriver)
	{
		return (((JavascriptExecutor) visitorDriver).executeScript("return $zoho.salesiq.values.uvid;")).toString();
	}

	public static void clickRingsView(WebDriver driver)
	{
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
		if(!isRingsView(driver))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,customizeHeader,rings));
			WebElement view = CommonUtil.getElement(driver,customizeHeader,ringsStatus);
			try
			{
				CommonUtil.waitTillWebElementContainsAttributeValue(view,"class","vo_ring");
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
	}

	public static void clickListView(WebDriver driver)
	{
		if(isRingsView(driver))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,customizeHeader,list));
			WebElement view = CommonUtil.getElement(driver,customizeHeader,ringsStatus);
			try
			{
				CommonUtil.waitTillWebElementContainsAttributeValue(view,"class","vo_list");
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
	}

	public static boolean isRingsView(WebDriver driver)
	{
		String view = CommonUtil.getElement(driver,customizeHeader,ringsStatus).getAttribute("class");
		if(view.contains("vo_ring"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static void waitTillVisitorLeaves(WebDriver driver,String visitorId)
	{
		waitTillVisitorInRings(driver,visitorId,false);
	}

	public static void waitTillVisitorPresentInRings(WebDriver driver,String visitorId)
	{
		waitTillVisitorInRings(driver,visitorId,true);
	}

	public static void waitTillVisitorInRings(WebDriver driver,String visitorId,boolean isPresent)
	{
		CRMPlusCommonUtil.clickVisitorsOnline(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,80,200);
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(CommonWait.isPresent(driver,By.id(visitorId)) && isPresent)
					{
						return true;
					}
					return false;
				}
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
