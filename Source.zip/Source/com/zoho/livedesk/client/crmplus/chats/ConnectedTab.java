//$Id$
package com.zoho.livedesk.client.crmplus.chats;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

public class ConnectedTab
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();
	public static ExtentTest etest;

	public static WebDriver visitor_driver;
	public static VisitorDriverManager visitor_driver_manager;

	public static String widgetCode,portalName,visEmail;

	public static String
	moduleName = "CRMP Connected",
	join = "Join";

	public static By
	connectedDiv = By.id("current_div"),
	innerHeader = By.id("innerheader"),
	buttonPos = By.className("btnposn_div"),
	pickupButtonInConnected = By.className("gren-btn");

	public static Hashtable testConnectedTab(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_CONNECTED",12);

			etest = ComplexReportFactory.getTest("Check Connected Tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkConnectedTab(driver,etest,true);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("check pickup from connected tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkPickupFromConnected(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Join button after chat was attended");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkJoinButtonAfterChatAttended(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and Desk info was found in Connected Tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoInConnectedTab(driver,etest,true);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Connected tab disappeared after the chat was ended");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkConnectedTab(driver,etest,false);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and desk info not found in Connected tab if email was not given");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoInConnectedTab(driver,etest,false);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and desk info found in Connected Tab after the email address was updated");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoInConnectedTabAfterEmailUpdate(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check if previous related tickets were found in Connected tab for returning visitor");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkPreviousRelatedTicketsInConnectedTab(driver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module Breakage occurred"+e);
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkConnectedTab(WebDriver driver,ExtentTest etest,boolean isDisplayed)
	{
		try
		{
			String desc = isDisplayed ? " " : " not ";
			String descOpp = isDisplayed ? " not " : " ";
			String key = isDisplayed ? "CRMP_CONNECTED1" : "CRMP_CONNECTED2";
			if(isDisplayed)
			{
				String label = CommonUtil.getUniqueMessage();
				visEmail = "v"+label+"@email.com";
				CRMPlusCommonUtil.clickVisitorsOnline(driver);
				visitor_driver = visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CRMPChatWindow.initiateChat(visitor_driver,visEmail,etest);
			}
			else
			{
				CRMPChatWindow.closeAllChats(driver,etest);
			}

			if(CRMPChatWindow.checkConnectedTab(driver) == isDisplayed)
			{
				etest.log(Status.INFO,"Connected tab was"+desc+"displayed for incoming chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,"Connected tab was"+descOpp+"displayed for incoming chats");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkConnectedTab","Exception",e);
		}
	}

	public static void checkPickupFromConnected(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CRMPChatWindow.checkConnectedTab(driver))
			{
				CRMPlusCommonUtil.clickConnected(driver);
				etest.log(Status.INFO,"Connected tab was clicked");
				CRMPChatWindow.clickLatestChatInConnectedTab(driver);
				TakeScreenshot.infoScreenshot(driver,etest);
				CRMPChatWindow.clickPickupInConnectedTab(driver);
				TakeScreenshot.infoScreenshot(driver,etest);

				if(CRMPChatWindow.isMyChatsTabDisplayed(driver))
				{
					etest.log(Status.PASS,"Chat was picked from Connected tab");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CONNECTED3",true);
				}
				else
				{
					etest.log(Status.FAIL,"Chat was not picked from Connected tab");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Connected tab was not displayed");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkPickupFromConnected","Exception",e);
		}
	}

	public static void checkCRMDeskInfoInConnectedTab(WebDriver driver,ExtentTest etest,boolean isDisplayed)
	{
		try
		{
			String desc = isDisplayed ? " " : " not ";
			String descOpp = isDisplayed ? " not " : " ";
			String crmKey = isDisplayed ? "CRMP_CONNECTED4" : "CRMP_CONNECTED6";
			String deskKey = isDisplayed ? "CRMP_CONNECTED5" : "CRMP_CONNECTED7";

			if(!isDisplayed)
			{
				CRMPlusCommonUtil.clickVisitorsOnline(driver);
				visitor_driver = visitor_driver_manager.getDriver(driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				CRMPChatWindow.quickOngoingChat(driver,visitor_driver,"without",etest);
			}

			CRMPlusCommonUtil.clickConnected(driver);
			CRMPChatWindow.clickLatestChatInConnectedTab(driver);
			if(CommonFunctionsChatInteg.isCRMInfoDisplayed(driver) == isDisplayed)
			{
				etest.log(Status.INFO,"CRM data was"+desc+"found in Connected tab");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(crmKey,true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM data was"+descOpp+"found in Connected tab");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonFunctionsChatInteg.isDeskInfoDisplayed(driver) == isDisplayed)
			{
				etest.log(Status.INFO,"Desk info was"+desc+"found in Connected tab");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(deskKey,true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk info was"+descOpp+"found in Connected tab");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMDeskInfoInConnectedTab","Exception",e);
		}
	}

	public static void checkJoinButtonAfterChatAttended(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickConnected(driver);
			CRMPChatWindow.clickLatestChatInConnectedTab(driver);
			if(CommonUtil.getElement(driver,connectedDiv,innerHeader,buttonPos,pickupButtonInConnected).getText().contains(join))
			{
				etest.log(Status.INFO,"Join button was found in Connected tab");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CONNECTED8",true);

				CRMPChatWindow.clickJoinInConnected(driver);
				if(CRMPChatWindow.isMyChatsTabDisplayed(driver))
				{
					etest.log(Status.INFO,"On clicking Join in Connected tab it navigated to my chats tab");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CONNECTED9",true);
				}
				else
				{
					etest.log(Status.FAIL,"On clicking Join in Connected tab it didnot navigate to my chats tab");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Join button was not found in Connected tab");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkJoinButtonAfterChatAttended","Exception",e);
		}
	}

	public static void checkPreviousRelatedTicketsInConnectedTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CommonFunctionsChatInteg.isRecentTicketsInfoDisplayed(driver))
			{
				etest.log(Status.INFO,"Related Desk Info was found when the visitor was updated with existing email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CONNECTED10",true);
			}
			else
			{
				etest.log(Status.FAIL,"Related Desk info was not found when the visitor was updated with existing email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkPreviousRelatedTicketsInConnectedTab","Exception",e);
		}
	}

	public static void checkCRMDeskInfoInConnectedTabAfterEmailUpdate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.clickConnected(driver);
			CRMPChatWindow.clickLatestChatInConnectedTab(driver);
			ChatHistoryChat.setRHSData(driver,etest,null,null,visEmail,null);
			CRMPlusCommonUtil.clickConnected(driver);
			CRMPChatWindow.clickLatestChatInConnectedTab(driver);
			if(CommonFunctionsChatInteg.isCRMInfoDisplayed(driver) && (CommonFunctionsChatInteg.isCRMLead(driver) && (CommonFunctionsChatInteg.checkCRMOwner(driver))))
			{
				etest.log(Status.INFO,"CRM info was displayed in Connected tab after updating email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CONNECTED11",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM info was not displayed in Connected tab after updating email address");
				TakeScreenshot.screenshot(driver,etest);
			}
			if(CommonFunctionsChatInteg.isDeskInfoDisplayed(driver) && CommonFunctionsChatInteg.isRecentTicketsInfoDisplayed(driver))
			{
				etest.log(Status.INFO,"Desk info was displayed in Connected tab after updating email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CONNECTED12",true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk info was not displayed in Connected tab after updating email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMDeskInfoInConnectedTabAfterEmailUpdate","Exception",e);
		}
	}
}
