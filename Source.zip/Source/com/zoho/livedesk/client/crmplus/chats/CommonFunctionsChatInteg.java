//$Id$
package com.zoho.livedesk.client.crmplus.chats;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class CommonFunctionsChatInteg
{
	public static By
	deskDiv = By.id("associatedreq"),
	recentTicketsDiv = By.id("recentrequest"),
	contactInfoDiv = By.id("contactinfodiv"),
	headerDiv = By.id("headerdiv"),
	contactInfoHead = By.id("contactinfohead"),
	contactInfoDropdown = By.id("contactinfohead_ddown"),
	crmData = By.id("crm_data"),
	crmInfo = By.className("crmld_infomn"),
	crmInfoHeader = By.className("crmld_inflft"),
	crmInfoText = By.className("crmld_infrht"),
	deskReqTitle = By.id("reqtitle"),
	mainContainer = By.id("zsmaincontainer"),
	associatedData = By.id("associateddata"),
	supportTicketData = By.className("spt_tktdatamn"),
	ticketId = By.className("spt_tktdataid"),
	ticketTitle = By.className("spt_tktdatatxt"),
	windowOpen = By.id("wopen"),
	setReqStatus = By.id("setreqstatus"),
	supportStatus = By.className("sptsts"),
	supportStatusDropdown = By.className("sptsts_drp"),
	ticketStatus = By.id("tktStatus"),
	ticketStatusInDesk = By.className("stat_txt"),
	statusListInDesk = By.id("statusContainer"),
	listViewTable = By.id("listViewTable"),
	button = By.className("rg-button"),
	potentialDiv = By.id("associatedpotentialdiv"),
	newDeskTicket = By.id("newreqdiv"),
	dropdownLabel = By.id("ddownlbl"),
	recentPotential = By.id("recentpotentialdiv"),
	deskContent = By.id("showAllThreads"),
	supportNewRequest = By.className("spt_crtnewreqst"),
	newRequestDiv = By.id("zsaddreqdiv"),
	chatHistoryFilter = By.id("cushistoryfilter"),
	comboTitle = By.className("combotitle"),
	ulContainer = By.id("ulcontainer"),
	filterList = By.id("filterlist");

	public static String
	ticketsRelatedToThisChat = "Ticket related to this chat",
	recentTickets = "Recent Tickets from this visitor",
	convertChatAsTicket = "Convert chat as Ticket",
	zohoCRMInfo = "Zoho CRM Info",
	closed = "Closed",
	open = "Open",
	owner = "Owner",
	type = "Type",
	lead = "Lead",
	contact = "Contact",
	todaysLead = "Today's Leads",
	convertToContact = "Convert as Contact",
	notConvertedAsSupportTicket = "Not Converted as Support Tickets";

	public static String visitorEmail;

	public static boolean checkTicketGeneratedInSalesiq(WebDriver driver)
	{
		try
		{
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			CommonWait.waitTillDisplayed(driver,deskDiv);
			return (CommonWait.isDisplayed(driver,deskDiv) && (CommonUtil.getElement(driver,deskDiv,deskReqTitle).getText().contains(ticketsRelatedToThisChat)));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	public static void createTicket(WebDriver driver)
	{
		CRMPlusCommonUtil.clickMyChats(driver);
		CommonUtil.clickWebElement(driver,newDeskTicket,supportNewRequest,By.tagName("span"));
		CommonWait.waitTillDisplayed(driver,newRequestDiv);
		CommonUtil.clickWebElement(driver,newRequestDiv,button);
		CommonWait.waitTillHidden(driver,newDeskTicket);
		CommonWait.waitTillDisplayed(driver,deskDiv);
	}

	public static String getTicketIdFromMyChats(WebDriver driver)
	{
		return getTicketInfoFromMyChats(driver,ticketId);
	}

	public static String getTicketTitleFromMyChats(WebDriver driver)
	{
		return getTicketInfoFromMyChats(driver,ticketTitle);
	}

	public static String getTicketInfoFromMyChats(WebDriver driver,By info)
	{
		if(checkTicketGeneratedInSalesiq(driver))
		{
			return CommonUtil.getElement(driver,deskDiv,info).getText();
		}
		else
		{
			return "Ticket not generated";
		}
	}

	public static String getSupportId(WebDriver driver)
	{
		if(checkTicketGeneratedInSalesiq(driver))
		{
			return CommonUtil.getElement(driver,deskDiv,supportTicketData).getAttribute("id");
		}
		else
		{
			return "Ticket not generated";
		}
	}

	public static String getTicketStatus(WebDriver driver)
	{
		return getTicketInfoFromMyChats(driver,supportStatus);
	}

	public static void closeCurrentTicket(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,deskDiv,supportStatus));
		List<WebElement> statuses = CommonUtil.getElement(driver,deskDiv,supportStatusDropdown).findElements(By.tagName("li"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(statuses,"innerText",closed));

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,deskDiv,supportStatus),"innerText",closed);
	}

	public static void openCurrentTicket(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,deskDiv,supportStatus));
		List<WebElement> statuses = CommonUtil.getElement(driver,deskDiv,supportStatusDropdown).findElements(By.tagName("li"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(statuses,"innerText",open));

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,deskDiv,supportStatus),"innerText",open);
	}

	public static void closeTicketFromDesk(WebDriver driver,String ticketId)
	{
		String ticketTableId = "table_"+ticketId;
		CRMPlusCommonUtil.navToDesk(driver);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(ticketTableId),ticketStatus,ticketStatusInDesk));
		List<WebElement> statuses = CommonUtil.getElement(driver,By.id(ticketTableId),statusListInDesk).findElements(By.tagName("li"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(statuses,"innerText",closed));

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,By.id(ticketTableId),ticketStatusInDesk),"innerText",closed);
	}

	public static boolean checkCRMOwner(WebDriver driver)
	{
		String expectedOwner = ExecuteStatements.getUserName(driver);

		List<WebElement> crmInfoList = CommonUtil.getElement(driver,crmData).findElements(crmInfo);
		WebElement ownerInfo = CommonUtil.getElementByAttributeValue(crmInfoList,"innerText",owner);

		return ((ownerInfo.findElement(crmInfoHeader).getText().contains(owner)) && (ownerInfo.findElement(crmInfoText).getText().contains(expectedOwner)));
	}

	public static void arrangeNotes(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,By.id("downArrow"));
		CommonWait.waitTillDisplayed(driver,By.className("OptionlistNotesNew"));
		CommonUtil.clickWebElement(driver,By.className("recentNotesList"),By.id("allNotes"));
		CommonWait.waitTillHidden(driver,By.className("OptionlistNotesNew"));
	}

	public static String getCRMType(WebDriver driver)
	{
		if(!CommonWait.isDisplayed(driver,crmData))
		{
			toggleVisitorInfo(driver,"crm");
		}
		List<WebElement> crmInfoList = CommonUtil.getElement(driver,crmData).findElements(crmInfo);
		WebElement crmType = CommonUtil.getElementByAttributeValue(crmInfoList,"innerText",type);

		return (crmType.findElement(crmInfoText).getText());
	}

	public static void toggleVisitorInfo(WebDriver driver,String integ)
	{
		try
		{
			String id = integ+"_data";
			if(!CommonWait.isDisplayed(driver,By.id(id)))
			{
				CommonUtil.clickWebElement(driver,By.id("ddownlbl"));
				CommonWait.waitTillDisplayed(driver,By.id("contactinfohead_ddown"));
				CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(driver,By.id("contactinfohead_ddown"),By.tagName("li"),"id",integ));
			}
			CommonWait.waitTillDisplayed(driver,By.id(id));
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public static boolean isCRMInfoDisplayed(WebDriver driver)
	{
		try
		{
			toggleVisitorInfo(driver,"crm");
			CommonWait.waitTillDisplayed(driver,crmData);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return CommonWait.isDisplayed(driver,crmData);
	}

	public static boolean isDeskInfoDisplayed(WebDriver driver)
	{
		try
		{
			CommonWait.waitTillDisplayed(driver,deskDiv);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return (CommonWait.isDisplayed(driver,deskDiv) || (CommonWait.isDisplayed(driver,newDeskTicket)));
	}

	public static boolean isRecentTicketsInfoDisplayed(WebDriver driver)
	{
		return (CommonWait.isDisplayed(driver,recentTicketsDiv) && (CommonUtil.getElement(driver,recentTicketsDiv).getText().contains(recentTickets)));
	}

	public static boolean isRecentPotentialInfoDisplayed(WebDriver driver)
	{
		return CommonWait.isDisplayed(driver,recentPotential);
	}

	public static boolean isNewDeskInfoDisplayed(WebDriver driver)
	{
		return ((CommonWait.isDisplayed(driver,newDeskTicket)) && (CommonUtil.getElement(driver,newDeskTicket).getText().contains(convertChatAsTicket)));
	}

	public static boolean isCRMLead(WebDriver driver)
	{
		String crmType = getCRMType(driver);
		return (crmType.contains(lead));
	}

	public static boolean isCRMContact(WebDriver driver)
	{
		CRMPlusCommonUtil.clickMyChats(driver);
		String crmType = getCRMType(driver);
		return (crmType.contains(contact));
	}

	public static boolean containsPotential(WebDriver driver)
	{
		return CommonWait.isDisplayed(driver,potentialDiv);
	}

	public static boolean isLeadInCRM(WebDriver driver)
	{
		visitorEmail = CRMPChatWindow.getVisitorEmail(driver);

		CRMPlusCommonUtil.clickCRMLead(driver);

		return checkEmailIdInCRM(driver,visitorEmail);
	}

	public static boolean isContactInCRM(WebDriver driver)
	{
		visitorEmail = CRMPChatWindow.getVisitorEmail(driver);

		CRMPlusCommonUtil.clickCRMContact(driver);

		return checkEmailIdInCRM(driver,visitorEmail);
	}

	public static String getCRMId(WebDriver driver)
	{
		CRMPlusCommonUtil.clickMyChats(driver);
		String href = CommonUtil.getElement(driver,By.id("infolink"),By.tagName("a")).getAttribute("href");
		String crmId = href.substring(href.indexOf("id")+3,href.indexOf("&"));
		return crmId;
	}
	public static void clickContactInCRM(WebDriver driver,String id)
	{
		CRMPlusCommonUtil.switchToFrame(driver,"crm");
		String crmId = "listView_" + id;
		CommonUtil.clickWebElement(driver,By.id(crmId));
		CommonWait.waitTillDisplayed(driver,By.id("noteDetails"));
	}

	public static boolean checkEmailIdInCRM(WebDriver driver,String email)
	{
		return (CommonUtil.getElement(driver,listViewTable).getText().contains(email));
	}

	public static void convertLeadToContact(WebDriver driver)
	{
		int i = 0;
		CRMPlusCommonUtil.clickMyChats(driver);
		if(isCRMLead(driver))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,crmData).findElements(button),"innerText",convertToContact));
			do
			{
				CommonUtil.sleep(500);
			}while(isCRMLead(driver) && i++ <= 20);
		}
	}

	public static void addPotential(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("btnshowaddpoten")));
			com.zoho.livedesk.client.CRM.PotentialAdd.addCRMPotential(driver,etest);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void changeToDeskInfo(WebDriver driver)
	{
		changeInfoTo(driver,"support","integico_zohodesk");
	}

	public static void changeToCRMInfo(WebDriver driver)
	{
		changeInfoTo(driver,"crm","integico_zohocrm");
	}

	public static void changeInfoTo(WebDriver driver,String info,String infoClass)
	{
		CRMPlusCommonUtil.navToSalesiq(driver);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,contactInfoDiv,dropdownLabel));
		List<WebElement> dropdownElements = CommonUtil.getElement(driver,contactInfoDiv,contactInfoDropdown).findElements(By.tagName("li"));
		if(CommonWait.isDisplayed(CommonUtil.getElementByAttributeValue(dropdownElements,"id",info)))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(dropdownElements,"id",info));
		}
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,contactInfoDiv,dropdownLabel),"class",infoClass);
	}

	public static boolean checkTextInDesk(WebDriver driver,String searchText,String supportId)
	{
		String subjectId = "subject_"+supportId;
		try
		{
			CommonUtil.clickWebElement(driver,By.id(subjectId));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		CommonWait.waitTillDisplayed(driver,deskContent);
		return (CommonUtil.getElement(driver,deskContent).getText().contains(searchText));
	}
	public static boolean checNotesAdded(WebDriver driver,String supportId)
	{
		String ticket = "table_" + supportId;
		return (CommonUtil.getElement(driver,By.id(ticket),By.className("cmtDiv")).getText().length() > 0);
	}

	public static boolean checkFilterOptions(WebDriver driver,By filter,String filterName)
	{
		CommonUtil.clickWebElement(driver,chatHistoryFilter,comboTitle);
		CommonWait.waitTillDisplayed(driver,ulContainer);

		new Select(CommonUtil.getElement(driver,filterList,filter,By.tagName("select"))).selectByVisibleText(filterName);
		CommonUtil.clickWebElement(driver,chatHistoryFilter,comboTitle);

		CommonUtil.clickWebElement(driver,ChatHistory.getLatestChat(driver));

		if(checkTicketGeneratedInSalesiq(driver) != filterName.contains(notConvertedAsSupportTicket))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
