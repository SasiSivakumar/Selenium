//$Id$
package com.zoho.livedesk.client.crmplus.chats;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.VisitorWindow;
public class CRMPChatWindow
{
	public static By
	chatNotification = By.id("crmpluscommonuigeneralnotificationcontainer"),
	acceptChat = By.className("greenColor"),
	ignoreChat = By.className("redColor"),
	closeIcon = By.className("zcrmp-notifyClseIcn"),
	ldSettings = By.id("ldsettings"),
	startChat = By.id("startcht"),
	sendMessageButton = By.id("sendmsgbtn"),
	tilesUIChatDiv = By.id("chatdiv"),
	myChatsTab = By.id("crmpluscommonui_salesiq_mycurrent"),
	visitorSideInfoBanner = By.id("info_banr"),
	agentSideInfoBanner = By.className("zcrmp-notifyPanHead"),
	visitorName = By.id("chatvisname"),
	visitorEmail = By.id("chatvisemail"),
	notes = By.id("notes"),
	notesBase = By.id("notesbase"),
	notesText = By.id("notetxt"),
	saveButton = By.className("cmn_gbutclor"),
	notesList = By.id("notelist"),
	connectedTab = By.id("crmpluscommonui_salesiq_current"),
	chatsList = By.id("historylist"),
	connectedDiv = By.id("current_div"),
	innerHeader = By.id("innerheader"),
	buttonPos = By.className("btnposn_div"),
	pickupButtonInConnected = By.className("gren-btn");

	public static String 
	visName = "visName",
	pickUp = "Pickup",
	continueOption = "Continue",
	visitorSideWaitingMessage = "Please wait while we connect you to our support representative.",
	agentSideWaitingMessage = "wants to chat with you.",
	proactiveMessage = "Hello, This is Salesiq",
	noteToAdd = "Note Added";

	public static void initiateChat(WebDriver driver,ExtentTest etest) throws Exception
	{
		initiateChat(driver,null,etest);
	}

	// pass null to email for random email id,
	// pass email address if required
	// pass any string for chat with no email 
	public static void initiateChat(WebDriver driver,String email,ExtentTest etest) throws Exception
	{
		String vName = visName;
		String label = CommonUtil.getUniqueMessage();
		String visEmail;
		String visQues = "Testing crmplus "+label;
		String visPhone = "9123456789";
		if(email == null)
		{
			visEmail = "v"+label+"@email.com";
		}
		else if(email.contains("@"))
		{
			vName = email.substring(0,email.indexOf("@"));
			visEmail = email;
		}
		else
		{
			visEmail = null;
			visPhone = null;
		}

		VisitorWindow.initiateChatVisTheme(driver,vName,visEmail,visPhone,visQues,etest);
	}

	public static void quickChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
	{
		quickChat(driver,visitor_driver,null,etest);
	}

	public static void quickChat(WebDriver driver,WebDriver visitor_driver,String email,ExtentTest etest)
	{
		try
		{
			quickOngoingChat(driver,visitor_driver,email,etest);
			ChatWindow.endChat(driver);
			closeAllChats(driver,etest);
			TakeScreenshot.screenshot(driver,etest,"ChatWindow","End Chat","After",0);
			VisitorWindow.checkChatEndedInTheme(visitor_driver);
			TakeScreenshot.screenshot(visitor_driver,etest,"VisitorWindow","End Chat","After",0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void quickOngoingChat(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
	{
		quickOngoingChat(driver,visitor_driver,null,etest);
	}
	public static void quickOngoingChat(WebDriver driver,WebDriver visitor_driver,String email,ExtentTest etest)
	{
		try
		{
			initiateChat(visitor_driver,email,etest);
			checkChatNotificationFound(driver);
			TakeScreenshot.screenshot(driver,etest,"ChatWindow","Accept Chat","Before",0);
			acceptChat(driver);
			TakeScreenshot.screenshot(driver,etest,"ChatWindow","Accept Chat","After",0);
			CRMPlusCommonUtil.waitTillTabSelected(driver,By.id("crmpluscommonui_salesiq_mycurrent"));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static boolean checkChatNotificationFound(WebDriver driver)
	{
		try
		{
			driver.switchTo().defaultContent();
			CommonWait.waitTillDisplayed(driver,5,chatNotification);
			return (CommonWait.isDisplayed(driver,chatNotification));
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static void acceptChat(WebDriver driver)
	{
		clickInChatNotificationWindow(driver,acceptChat);
	}

	public static void ignoreChat(WebDriver driver)
	{
		clickInChatNotificationWindow(driver,ignoreChat);
	}

	public static void closeNotification(WebDriver driver)
	{
		CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,chatNotification,acceptChat));
		clickInChatNotificationWindow(driver,closeIcon);
	}

	public static void clickInChatNotificationWindow(WebDriver driver,By option)
	{
		if(checkChatNotificationFound(driver))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,chatNotification,option));
			CommonWait.waitTillHidden(driver,chatNotification);
		}
	}

	public static void addNote(WebDriver driver)
	{
		CRMPlusCommonUtil.navToSalesiq(driver);
		CRMPlusCommonUtil.clickMyChats(driver);

		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,notes));
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,notesBase,notesText));
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,notesBase,notesText),noteToAdd);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,notesBase,saveButton));

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,notesList),"innerText",noteToAdd);

		CommonUtil.clickWebElement(driver,By.id("chat"));
	}

	public static void closeAllChats(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(isMyChatsTabDisplayed(driver)==false)
	        {
	            return;
	        }

	        CRMPlusCommonUtil.clickMyChats(driver);

	        int max_chats_to_end=10;
	        int chats_ended=0;

	        while(isMyChatsTabDisplayed(driver) && chats_ended<max_chats_to_end)
	        {
	        	if(isMyChatsTabSelected(driver))
	        	{
	        		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
	            	ChatWindow.closeCurrentVisibleChat(driver);
	            	chats_ended++;   
	            }
	            CommonUtil.refreshPage(driver);
	        }
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	}

	public static boolean isMyChatsTabDisplayed(WebDriver driver)
	{
		driver.switchTo().defaultContent();
		try
		{
			CRMPlusCommonUtil.waitTillTabSelected(driver,myChatsTab);
			driver.switchTo().defaultContent();
			CommonWait.waitTillDisplayed(driver,30,myChatsTab);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return CommonWait.isDisplayed(driver,myChatsTab);
	}

	public static String getVisitorEmail(WebDriver driver)
	{
		CRMPlusCommonUtil.clickMyChats(driver);
		return CommonUtil.getElement(driver,visitorEmail).getText();
	}

	public static boolean isSearchTextPresentInCRMPChatNotification(WebDriver driver,String search_text)
	{
		if(checkChatNotificationFound(driver))
		{
			String textInCRMPChatNotification = CommonUtil.getElement(driver,chatNotification).getText();
			if(textInCRMPChatNotification.toLowerCase().contains(search_text.toLowerCase()))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}

	public static boolean checkContinueOptionInTilesUI(WebDriver driver,String visitorId)
	{
		return checkOptionInTilesUI(driver,visitorId,continueOption);
	}

	public static boolean checkPickupOptionInTilesUI(WebDriver driver,String visitorId)
	{
		return checkOptionInTilesUI(driver,visitorId,pickUp);
	}

	public static boolean checkOptionInTilesUI(WebDriver driver,String visitorId,String option)
	{
		CRMPlusCommonUtil.clickVisitorsOnline(driver);
		if(CommonWait.isDisplayed(driver,By.id(visitorId)))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorId)));
			CommonWait.waitTillDisplayed(driver,ldSettings);
			return (CommonUtil.getElement(driver,ldSettings,startChat).getText().contains(option));
		}
		else
		{
			return false;
		}
	}

	public static void endChatImmediate(WebDriver driver,WebDriver visitor_driver,String visitorId) throws Exception
	{
		clickPickUpInTilesUI(driver,visitorId);
		VisitorWindow.endChatVisitor(visitor_driver);
		CRMPlusCommonUtil.clickVisitorsOnline(driver);
	}

	public static void clickContinueInTilesUI(WebDriver driver,String visitorId)
	{
		if(checkContinueOptionInTilesUI(driver,visitorId))
		{
			clickStartChatOptionInTilesUI(driver);
		}
	}

	public static void clickPickUpInTilesUI(WebDriver driver,String visitorId)
	{
		if(checkPickupOptionInTilesUI(driver,visitorId))
		{
			clickStartChatOptionInTilesUI(driver);
		}
	}

	public static void clickStartChatOptionInTilesUI(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,ldSettings,startChat,By.tagName("a")));
		CommonWait.waitTillHidden(driver,ldSettings);
	}

	public static boolean isMyChatsTabSelected(WebDriver driver)
	{
		try
		{
			CRMPlusCommonUtil.waitTillTabSelected(driver,myChatsTab);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		driver.switchTo().defaultContent();
		return (CommonUtil.getElement(driver,myChatsTab).getAttribute("class").contains("selected"));
	}

	public static boolean checkWaitingMessageInVisitorSide(WebDriver driver)
	{
		VisitorWindow.switchToChatWidget(driver);
		CommonWait.waitTillDisplayed(driver,visitorSideInfoBanner);
		return (CommonUtil.getElement(driver,visitorSideInfoBanner).getText().contains(visitorSideWaitingMessage));
	}

	public static boolean checkWaitingMessageInAgentSide(WebDriver driver)
	{
		return isSearchTextPresentInCRMPChatNotification(driver,agentSideWaitingMessage);
	}

	public static boolean checkMessages(WebDriver driver,String agentMessage,String visMessage) throws Exception
	{
		String agentName = ExecuteStatements.getUserName(driver);
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
		return (ChatWindow.checkMessageInUserWindow(driver,agentName,agentMessage) && ChatWindow.checkMessageInUserWindow(driver,visName,visMessage));
	}

	public static boolean checkMessagesVisitorSide(WebDriver visitor_driver,String agentMessage,String visMessage) throws Exception
	{
		return (VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,null,visMessage,2) && VisitorWindow.checkAgentMessageInChatWindow(visitor_driver,null,agentMessage,1));
	}

	public static boolean checkVisitorInfo(WebDriver driver,ExtentTest etest)
	{
		CRMPlusCommonUtil.switchToSalesiqFrame(driver);
		String visQues = "Testing crmplus";
		String dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
		String country = (Util.siteNameout().contains("local"))?"United Kingdom":"India";
		String sourceUrl = "visitor/index1.html";

		return (isVisInfoFound(driver,dept,"Department",etest) && isVisInfoFound(driver,visQues,"Question",etest) && isVisInfoFound(driver,country,"Country",etest) && isVisInfoFound(driver,sourceUrl,"Source",etest));
	}

	public static boolean isVisInfoFound(WebDriver driver,String info,String infoToFind,ExtentTest etest)
	{
		if(isSearchTextPresentInCRMPChatNotification(driver,info))
		{
			etest.log(Status.INFO,"Expected Visitor "+infoToFind+" was found in chat notification");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Expected Visitor "+infoToFind+" was not found in chat notification");
			return false;
		}
	}

	public static void initiateProactiveChat(WebDriver driver,String visitorId,ExtentTest etest) throws Exception
	{
		String msgArea = "textarea_"+visitorId;
		CRMPlusCommonUtil.clickVisitorsOnline(driver);
		VisitorsOnline.waitTillVisitorStableInRings(CommonUtil.getElement(driver,By.id(visitorId)));
		CommonWait.waitTillDisplayed(driver,By.id(visitorId));
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(visitorId)));
		CommonWait.waitTillDisplayed(driver,ldSettings);
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,ldSettings,startChat,By.id(msgArea)),proactiveMessage);
		etest.log(Status.INFO,"Before Chat intiate via Tiles UI");
		TakeScreenshot.infoScreenshot(driver,etest);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,ldSettings,sendMessageButton));
		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,ldSettings,tilesUIChatDiv),"innerText",proactiveMessage);
		etest.log(Status.INFO,"After chat intiate via Tiles UI");
		TakeScreenshot.infoScreenshot(driver,etest);
	}

	public static boolean checkConnectedTab(WebDriver driver)
	{
		driver.switchTo().defaultContent();
		try
		{
			CommonWait.waitTillDisplayed(driver,connectedTab);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return CommonWait.isPresent(driver,connectedTab);
	}

	public static void clickLatestChatInConnectedTab(WebDriver driver)
	{
		clickLatestChat(driver,CommonUtil.getByValue(connectedDiv));
	}

	public static void clickLatestChat(WebDriver driver,String tabId)
	{
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(tabId),chatsList,By.tagName("table")).findElements(By.tagName("tr")).get(1));
	}

	public static void clickPickupInConnectedTab(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,connectedDiv,innerHeader,buttonPos,pickupButtonInConnected);
	}

	public static void clickJoinInConnected(WebDriver driver)
	{
		CommonUtil.clickWebElement(driver,connectedDiv,innerHeader,buttonPos,pickupButtonInConnected);
	}
}
