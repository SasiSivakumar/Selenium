//$Id$
package com.zoho.livedesk.client.crmplus.chats;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.crmplus.rings.CommonFunctionsTR;
import com.zoho.livedesk.client.crmplus.others.CommonFunctionsOthers;

public class ChatBasics
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();
	public static ExtentTest etest;

	public static VisitorDriverManager visitor_driver_manager;

	public static WebDriver visitor_driver;

	public static String widgetCode,portalName,visitorId;

	public static String
	moduleName = "CRMP Chat Basics",
	visMessage = "Visitor Sample Message",
	agentMesssage = "Agent Sample Message";

	public static By
	timerNotify = By.className("zcrmp-whichNotify");

	// The test cases and methods are written specifically to execute only for this class 
	// Dont use them elsewhere without analyzing the method completely (cc Muzamil)
	public static Hashtable testChatBasics(WebDriver driver)
	{
		try
		{
			CommonFunctionsOthers.changeStatus(driver,"Available");
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);
			visitor_driver_manager = new VisitorDriverManager();

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_CHATBASICS",18);

			etest = ComplexReportFactory.getTest("Check Chat notification");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkChatNotification(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Visitor Info");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkVisitorInfo(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Waiting Message");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkWaitingMessage(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Accept Chat");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkAcceptChat(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Messages");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkMessages(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check End chat");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkEndChat(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Ignore chat and pickup in Tiles UI");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkIgnoreChat(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Pickup button in Tiles UI");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkPickupInTilesUI(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check chat notification for proactive chat");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkNotificationForProactiveChat(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Close icon in chat notification");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkNotificationCloseIcon(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Continue chat from tiles UI");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkContinueChat(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check chat widget");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkChatWidget(driver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module Breakage occurred"+e);
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			try
			{
				CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}
	public static void checkChatWidget(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);

			CommonFunctionsOthers.changeStatus(driver,"Available");
			result.put("CRMP_CHATBASICS1",checkChatWidget(driver,etest,true));

			CommonUtil.sleep(1000);

			CommonFunctionsOthers.changeStatus(driver,"Busy");
			result.put("CRMP_CHATBASICS2",checkChatWidget(driver,etest,false));

			CommonUtil.sleep(1000);

			CommonFunctionsOthers.changeStatus(driver,"Available");

			CommonUtil.sleep(500);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkChatWidget","Exception",e);
			try
			{
				CommonFunctionsOthers.changeStatus(driver,"Available");
			}
			catch(Exception excep)
			{
				e.printStackTrace();
			}
		}
	}

	public static boolean checkChatWidget(WebDriver driver,ExtentTest etest,boolean isPresent)
	{
		try
		{
			if(isPresent)
			{
				if(!VisitorWindow.checkChatWidgetOffline(visitor_driver))
				{
					etest.log(Status.PASS,"Chat widget is available");
					TakeScreenshot.infoScreenshot(visitor_driver,etest);
					return true;
				}
				else
				{
					etest.log(Status.FAIL,"Chat widget is not available");
					TakeScreenshot.screenshot(visitor_driver,etest);
					return false;
				}
			}
			else
			{
				CommonUtil.refreshPage(visitor_driver);
				VisitorWindow.createPage(visitor_driver,widgetCode);
				if(VisitorWindow.checkChatWidgetOffline(visitor_driver))
				{
					etest.log(Status.PASS,"Chat widget is not available for offline");
					TakeScreenshot.infoScreenshot(visitor_driver,etest);
					return true;
				}
				else
				{
					etest.log(Status.FAIL,"Chat widget is available for offline");
					TakeScreenshot.screenshot(visitor_driver,etest);
					return false;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkChatWidget","Exception",e);
			return false;
		}
	}

	public static void checkChatNotification(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);

			CRMPChatWindow.initiateChat(visitor_driver,etest);

			if(CRMPChatWindow.checkChatNotificationFound(driver))
			{
				etest.log(Status.PASS,"Chat notification was found after chat was initiated from visitor");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS3",true);
			}
			else
			{
				etest.log(Status.FAIL,"Chat notification was not found even after chat was initiated from visitor");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkChatNotification","Exception",e);
		}
	}

	public static void checkPickupInTilesUI(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CRMPChatWindow.checkPickupOptionInTilesUI(driver,visitorId))
			{
				etest.log(Status.PASS,"Pickup option was found in Tiles UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS4",true);
				try
				{
					CRMPChatWindow.clickPickUpInTilesUI(driver,visitorId);
				}
				catch(Exception e)
				{
					etest.log(Status.FAIL,"Chat was not picked up from Tiles UI");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Pickup option was not found in Tiles UI after chat was initiated from visitor");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
			try
			{
				CRMPChatWindow.closeAllChats(driver,etest);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkPickupInTilesUI","Exception",e);
		}
	}

	public static void checkContinueChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CRMPChatWindow.checkContinueOptionInTilesUI(driver,visitorId))
			{
				etest.log(Status.PASS,"Continue option was found in Tiles UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS18",true);
				CRMPChatWindow.clickContinueInTilesUI(driver,visitorId);
			}
			else
			{
				etest.log(Status.FAIL,"Continue option was not found in Tiles UI after chat was initiated from visitor");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
			try
			{
				CRMPChatWindow.closeAllChats(driver,etest);
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkPickupInTilesUI","Exception",e);
		}
	}

	public static void checkWaitingMessage(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CRMPChatWindow.checkWaitingMessageInVisitorSide(visitor_driver))
			{
				etest.log(Status.PASS,"Waiting message was found in Visitor Side");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("CRMP_CHATBASICS5",true);
			}
			else
			{
				etest.log(Status.FAIL,"Waiting message was not found in Visitor side");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(CRMPChatWindow.checkWaitingMessageInAgentSide(driver))
			{
				etest.log(Status.PASS,"Waiting message was found in Agent Side");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS6",true);
			}
			else
			{
				etest.log(Status.FAIL,"Waiting message was not found in Agent side");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkWaitingMessage","Exception",e);
		}
	}

	public static void checkIgnoreChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			CRMPChatWindow.initiateChat(visitor_driver,etest);

			if(CRMPChatWindow.checkChatNotificationFound(driver))
			{
				CRMPChatWindow.ignoreChat(driver);
				if(!CRMPChatWindow.checkChatNotificationFound(driver))
				{
					etest.log(Status.PASS,"Chat was ignored");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATBASICS7",true);
				}
				else
				{
					etest.log(Status.FAIL,"Chat was not ignored even after clicking ignore from notification");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Chat notification was not found");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkIgnoreChat","Exception",e);
		}
	}

	public static void checkNotificationCloseIcon(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			if(CRMPChatWindow.checkChatNotificationFound(driver))
			{
				CRMPChatWindow.closeNotification(driver);
				if(!CRMPChatWindow.checkChatNotificationFound(driver))
				{
					etest.log(Status.PASS,"Chat notification was closed");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATBASICS8",true);
				}
				else
				{
					etest.log(Status.FAIL,"Chat notification was not closed even after clicking close icon from notification");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(visitor_driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Chat notification was not found");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkNotificationCloseIcon","Exception",e);
		}
	}

	public static void checkAcceptChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPChatWindow.acceptChat(driver);
			if(!CRMPChatWindow.checkChatNotificationFound(driver) && CRMPChatWindow.isMyChatsTabSelected(driver))
			{
				etest.log(Status.PASS,"Chat was accepted from notification");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS9",true);
			}
			else
			{
				etest.log(Status.FAIL,"Chat was not accepted even after clicking accept from notification");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkAcceptChat","Exception",e);
		}
	}

	public static void checkMessages(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);
			ChatWindow.sentMessage(driver,agentMesssage);
			VisitorWindow.sentMessageInTheme(visitor_driver,visMessage);
			if(CRMPChatWindow.checkMessages(driver,agentMesssage,visMessage))
			{
				etest.log(Status.PASS,"Sent Messages were checked in Agent Side");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS10",true);
			}
			else
			{
				etest.log(Status.FAIL,"Sent Messages were not checked in Agent Side");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CRMPChatWindow.checkMessagesVisitorSide(visitor_driver,agentMesssage,visMessage))
			{
				etest.log(Status.PASS,"Sent Messages were checked in Visitor Side");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("CRMP_CHATBASICS11",true);
			}
			else
			{
				etest.log(Status.FAIL,"Sent Messages were not checked in Visitor Side");
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkMessages","Exception",e);
		}
	}

	public static void checkVisitorInfo(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CRMPChatWindow.checkVisitorInfo(driver,etest))
			{
				etest.log(Status.PASS,"Visitor info was verified");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS12",true);
			}
			else
			{
				etest.log(Status.FAIL,"Visitor info was not verified");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorInfo","Exception",e);
		}
	}

	public static void checkEndChat(WebDriver driver,ExtentTest etest)
	{
		try
		{			
			ChatWindow.endChat(driver);
			try
			{
				VisitorWindow.checkChatEndedInTheme(visitor_driver);
				etest.log(Status.PASS,"Chat was ended from agent side");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS13",true);
				ChatWindow.clickClosethisWindow(driver);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,"Chat was not ended after clicking end chat icon from agent side");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkEndChat","Exception",e);
		}
	}

	public static void checkNotificationForProactiveChat(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
				
			CRMPChatWindow.initiateProactiveChat(driver,visitorId,etest);
			if(CommonUtil.getElement(driver,CRMPChatWindow.ldSettings,CRMPChatWindow.tilesUIChatDiv).getText().contains(CRMPChatWindow.proactiveMessage))
			{
				etest.log(Status.INFO,"Sent message was present in tiles UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS14",true);
			}
			else
			{
				etest.log(Status.FAIL,"Sent Message was not present in tiles UI");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(VisitorWindow.checkAgentMessageInChatWindow(visitor_driver,null,CRMPChatWindow.proactiveMessage,1))
			{
				etest.log(Status.INFO,"proactive Message was found in the visitor side");
				TakeScreenshot.infoScreenshot(visitor_driver,etest);
				result.put("CRMP_CHATBASICS15",true);
			}
			else
			{
				etest.log(Status.FAIL,"Proactive Message was not found in the visitor side");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
			VisitorWindow.sentMessageInTheme(visitor_driver,visMessage);

			if(CRMPChatWindow.checkChatNotificationFound(driver))
			{
				etest.log(Status.PASS,"Chat notification was found for proactive initiated chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATBASICS16",true);
				if(CommonUtil.getElement(driver,timerNotify).getText().length() < 2)
				{
					etest.log(Status.PASS,"Timer was not displayed for Proactive initiated chat");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATBASICS17",true);
					CRMPChatWindow.closeNotification(driver);				}
				else
				{
					etest.log(Status.FAIL,"Timer was displayed for Proactive Initiated Chat");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Chat notification was not found for proactive initiated chat");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkNotificationForProactiveChat","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest);
		}
	}
}
