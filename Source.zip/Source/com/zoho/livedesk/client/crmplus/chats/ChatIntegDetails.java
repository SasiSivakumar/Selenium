//$Id$
package com.zoho.livedesk.client.crmplus.chats;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.crmplus.rings.CommonFunctionsTR;
import com.zoho.livedesk.client.MissedChat.MissedChatCommonFunctions;

public class ChatIntegDetails
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();
	public static ExtentTest etest;

	public static WebDriver visitor_driver;
	public static VisitorDriverManager visitor_driver_manager;

	public static String widgetCode,portalName,visitorId,visName,visEmail,actualVisEmail,actualVisName,supportId;

	public static String
	moduleName = "CRMP Chat Integration Details",
	agentMesssage = "Agent Message",
	visMessage = "Visitor Message";

	public static By
	ticketStatusId = By.id("tktStatus"),
	ticketStatusInDesk = By.className("stat_txt"),
	newTag = By.className("tag-style");

	public static Hashtable testChatInteg(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_CHATINTEG",37);

			etest = ComplexReportFactory.getTest("Check if Ticket was generated for incoming chats");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketGenerated(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check if Ticket was generated in desk");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketGeneratedInDesk(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Ticket Status");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkTicketStatus(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Close Ticket from Chat");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCloseTicketFromChats(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check closing ticket from desk");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCloseTicketInDesk(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Lead created in CRM");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkLeadCreatedInCRM(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM Info in MyChats");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfo(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check change lead to contact");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkConvertLeadToContact(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Contact in CRM");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkConvertContact(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Add potential");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkAddPotential(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Add note");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkAddNote(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and desk info was not displayed if email address was not given");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoNotDisplayed(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Update with an Existing Email address and check if related details were found in CRM and Desk");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkRelatedInfoDeskCRM(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM Info");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfo(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Desk Info");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkDeskInfo(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check PreviousRelatedTicketsShown");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkPreviousRelatedTicketsShown(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Change email address from existing to new and check if recent tickets are disappeared");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkRecentTicketsDisappeared(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM info updated after visitor email address was updated");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMInfoAfterEmailUpdate(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Desk Info after visitor email updated");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkDeskInfoAfterEmailUpdate(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Chat transcript was found in CRM and Desk");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkChatTranscript(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check feedback info was not added to desk if rating alone was given");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkFeedbackInfo(driver,etest,false);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check feedback info was added to desk if feedback was given from visitor");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkFeedbackInfo(driver,etest,true);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Ticket auto generated for missed chats");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkAutoGeneratedTicketsForMissedChats(driver,etest,true);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and Desk info for Missed Chats after updating with new email address");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoInMissedChats(driver,etest,false);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Missed chats moved to Chat history after converting it as a ticket");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkMissedChatsMovedToChatHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Ticket not generated for missed chats if email was not given");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkAutoGeneratedTicketsForMissedChats(driver,etest,false);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and Desk info for Missed Chats after updating with existing email address");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoInMissedChats(driver,etest,true);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module Breakage occurred"+e);
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}
	public static void checkTicketGenerated(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			CRMPChatWindow.quickOngoingChat(driver,visitor_driver,etest);

			if(CommonFunctionsChatInteg.checkTicketGeneratedInSalesiq(driver))
			{
				etest.log(Status.PASS,"Ticket was generated and was displayed in My chats");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG1",true);
			}
			else
			{
				etest.log(Status.FAIL,"Ticket was not displayed in My chats");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkTicketGeneratedInDesk","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest);
		}
	}

	public static void checkTicketGeneratedInDesk(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String ticketId = CommonFunctionsChatInteg.getTicketIdFromMyChats(driver);
			String ticketTitle = CommonFunctionsChatInteg.getTicketTitleFromMyChats(driver);
			String supportId = CommonFunctionsChatInteg.getSupportId(driver);
			String supportTableId = "table_"+supportId;
			String subjectId = "subject_"+supportId;
			CRMPlusCommonUtil.navToDesk(driver);

			if(CommonWait.isDisplayed(driver,By.id(supportTableId)))
			{
				etest.log(Status.PASS,"Ticket generated was found in Desk");
				result.put("CRMP_CHATINTEG2",true);

				if(CommonUtil.getElement(driver,By.id(supportTableId),By.id(subjectId)).getText().contains(ticketId) &&
					CommonUtil.getElement(driver,By.id(supportTableId),By.id(subjectId)).getText().contains(ticketTitle))
				{
					etest.log(Status.PASS,"Ticket Id and Ticket title was verified in Desk");
					result.put("CRMP_CHATINTEG3",true);

					if(CommonWait.isDisplayed(driver,newTag))
					{
						etest.log(Status.PASS,"<b>New</b> tag was added to the ticket that was added just now");
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put("CRMP_CHATINTEG4",true);
					}
					else
					{
						etest.log(Status.FAIL,"<b>New</b> tag was not added to the ticket that was just generated");
						TakeScreenshot.screenshot(driver,etest);
					}
				}
				else
				{
					etest.log(Status.FAIL,"Ticket Id and Ticket title was incorrect in Desk<br>Expected Ticket Id : "+ticketId+"<br>Expected Ticket Title : "+ticketTitle);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Ticket generated was not found in Desk");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkTicketStatus","Exception",e);
		}
	}

	public static void checkTicketStatus(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.navToSalesiq(driver);
			CRMPlusCommonUtil.clickMyChats(driver);
			String ticketStatus = CommonFunctionsChatInteg.getTicketStatus(driver);
			String supportId = CommonFunctionsChatInteg.getSupportId(driver);
			String supportTableId = "table_"+supportId;

			if(ticketStatus.toLowerCase().contains("open"))
			{
				etest.log(Status.PASS,"Ticket status was found open");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG5",true);
			}
			else
			{
				etest.log(Status.FAIL,"Ticket status was not found open");
				TakeScreenshot.screenshot(driver,etest);
			}

			CRMPlusCommonUtil.navToDesk(driver);

			if(CommonWait.isDisplayed(driver,By.id(supportTableId)))
			{
				if(CommonUtil.getElement(driver,By.id(supportTableId),ticketStatusInDesk).getText().contains(ticketStatus))
				{
					etest.log(Status.PASS,"Ticket status was found in desk and was verified to be open");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATINTEG6",true);
				}
				else
				{
					etest.log(Status.FAIL,"Ticket status was either not found or found closed");
					TakeScreenshot.screenshot(driver,etest);
				}
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkTicketStatus","Exception",e);
		}
	}

	public static void checkCloseTicketFromChats(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickMyChats(driver);
			CommonFunctionsChatInteg.closeCurrentTicket(driver);

			String ticketStatus = CommonFunctionsChatInteg.getTicketStatus(driver);

			if(ticketStatus.toLowerCase().contains("closed"))
			{
				etest.log(Status.PASS,"Ticket status was closed in MyChats");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG7",true);
			}
			else
			{
				etest.log(Status.FAIL,"Ticket status was not found closed");
				TakeScreenshot.screenshot(driver,etest);
			}

			String supportId = CommonFunctionsChatInteg.getSupportId(driver);
			String supportTableId = "table_"+supportId;

			CRMPlusCommonUtil.navToDesk(driver);

			CommonUtil.refreshPage(driver);

			CRMPlusCommonUtil.navToDesk(driver);

			if(CommonWait.isDisplayed(driver,By.id(supportTableId)))
			{
				if(CommonUtil.getElement(driver,By.id(supportTableId),ticketStatusInDesk).getText().toLowerCase().contains("closed"))
				{
					etest.log(Status.PASS,"Ticket status was found in desk and was verified to be closed");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATINTEG8",true);
				}
				else
				{
					etest.log(Status.FAIL,"Ticket status was either not found or found open");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCloseTicketFromChats","Exception",e);
		}
	}

	public static void checkCloseTicketInDesk(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.navToSalesiq(driver);
			CRMPlusCommonUtil.clickMyChats(driver);
			String supportId = CommonFunctionsChatInteg.getSupportId(driver);
			String supportTableId = "table_"+supportId;
			CommonFunctionsChatInteg.openCurrentTicket(driver);

			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.navToDesk(driver);

			CommonFunctionsChatInteg.closeTicketFromDesk(driver,supportId);
			if(CommonWait.isDisplayed(driver,By.id(supportTableId)))
			{
				if(CommonUtil.getElement(driver,By.id(supportTableId),ticketStatusInDesk).getText().toLowerCase().contains("closed"))
				{
					etest.log(Status.PASS,"Ticket status was found in desk and was verified to be closed");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATINTEG9",true);
				}
				else
				{
					etest.log(Status.FAIL,"Ticket status was either not found or found open");
					TakeScreenshot.screenshot(driver,etest);
				}
			}

			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.navToSalesiq(driver);
			CRMPlusCommonUtil.clickMyChats(driver);

			String ticketStatus = CommonFunctionsChatInteg.getTicketStatus(driver);

			if(ticketStatus.toLowerCase().contains("closed"))
			{
				etest.log(Status.PASS,"Ticket status was closed in MyChats");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG10",true);
			}
			else
			{
				etest.log(Status.FAIL,"Ticket status was not found closed");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCloseTicketInDesk","Exception",e);
		}
	}

	public static void checkLeadCreatedInCRM(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickMyChats(driver);
			if(CommonFunctionsChatInteg.isCRMLead(driver))
			{
				etest.log(Status.PASS,"Lead was generated in My chats");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG11",true);
			}
			else
			{
				etest.log(Status.FAIL,"Lead was not generated in My chats tab");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonFunctionsChatInteg.isLeadInCRM(driver))
			{
				etest.log(Status.PASS,"Lead was generated in CRM");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG12",true);
			}
			else
			{
				etest.log(Status.FAIL,"Lead was not generated in CRM");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkLeadCreatedInCRM","Exception",e);
		}
	}

	public static void checkCRMInfo(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickMyChats(driver);
			if(CommonFunctionsChatInteg.checkCRMOwner(driver) && CommonFunctionsChatInteg.isCRMLead(driver))
			{
				etest.log(Status.PASS,"CRM info was found and was verified");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG13",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM info was not verified");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMInfo","Exception",e);
		}
	}

	public static void checkConvertLeadToContact(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsChatInteg.convertLeadToContact(driver);

			if(CommonFunctionsChatInteg.isCRMContact(driver))
			{
				etest.log(Status.PASS,"Lead was converted into Contact");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG14",true);
			}
			else
			{
				etest.log(Status.FAIL,"Lead was not converted into Contact");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkConvertLeadToContact","Exception",e);
		}
	}

	public static void checkConvertContact(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CommonFunctionsChatInteg.isContactInCRM(driver))
			{
				etest.log(Status.PASS,"Lead was converted into Contact and was verified in CRM");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG15",true);
			}
			else
			{
				etest.log(Status.FAIL,"Lead converted into contact was not found in CRM");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkConvertContact","Exception",e);
		}
	}

	public static void checkAddPotential(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickMyChats(driver);
			CommonFunctionsChatInteg.addPotential(driver,etest);

			if(CommonFunctionsChatInteg.containsPotential(driver))
			{
				etest.log(Status.PASS,"Potential was added to the CRM contact");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG16",true);
			}
			else
			{
				etest.log(Status.FAIL,"Potential was not added to the CRM contact");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkAddPotential","Exception",e);
		}
	}

	public static void checkCRMDeskInfoNotDisplayed(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			CRMPChatWindow.quickOngoingChat(driver,visitor_driver,"withoutemail",etest);

			if(!CommonFunctionsChatInteg.isCRMInfoDisplayed(driver) && !CommonFunctionsChatInteg.isDeskInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"CRM and Desk info was not displayed when chat was initiated without an email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG19",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM and Desk info was displayed even when the visitor was initiated without an email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMDeskInfoNotDisplayed","Exception",e);
		}
	}

	public static void checkCRMInfoAfterEmailUpdate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String email = CommonUtil.getUniqueMessage()+"@email.com";
			CRMPlusCommonUtil.navToSalesiq(driver);
			ChatHistoryChat.setRHSData(driver,etest,null,null,email,null);

			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			CRMPlusCommonUtil.clickMyChats(driver);
			if(CommonFunctionsChatInteg.isCRMInfoDisplayed(driver) && (CommonFunctionsChatInteg.isCRMContact(driver) && (CommonFunctionsChatInteg.checkCRMOwner(driver))))
			{
				etest.log(Status.PASS,"CRM info was displayed after updating with an email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG26",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM info was not displayed even after updating visitor with an email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMInfoAfterEmailUpdate","Exception",e);
		}
	}

	public static void checkDeskInfoAfterEmailUpdate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CommonFunctionsChatInteg.isDeskInfoDisplayed(driver) && (CommonUtil.getElement(driver,By.id("newreqdiv")).getText().contains("Convert chat as Ticket")))
			{
				etest.log(Status.PASS,"Desk info was displayed after updating with an email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG27",true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk info was not displayed even after updating visitor with an email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkDeskInfoAfterEmailUpdate","Exception",e);
		}
	}

	public static void checkRelatedInfoDeskCRM(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String email = CommonFunctionsChatInteg.visitorEmail;
			CRMPlusCommonUtil.navToSalesiq(driver);
			ChatHistoryChat.setRHSData(driver,etest,null,null,email,null);

			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			if(CommonFunctionsChatInteg.isCRMContact(driver))
			{
				etest.log(Status.PASS,"Related CRM data was found when the visitor was updated with existing (already visited) email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG20",true);
			}
			else
			{
				etest.log(Status.FAIL,"Related CRM data was not found when the visitor was updated with existing (already visited) email address");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonFunctionsChatInteg.isRecentTicketsInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"Related Desk Info was found when the visitor was updated with existing email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG21",true);
			}
			else
			{
				etest.log(Status.FAIL,"Related Desk info was not found when the visitor was updated with existing email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkRelatedInfoDeskCRM","Exception",e);
		}
	}

	public static void checkCRMDeskInfo(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsChatInteg.changeToCRMInfo(driver);

			CRMPlusCommonUtil.clickMyChats(driver);
			if(CommonFunctionsChatInteg.isCRMContact(driver) && CommonFunctionsChatInteg.checkCRMOwner(driver) && CommonFunctionsChatInteg.isRecentPotentialInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"CRM Info was found in RHS and related data was verified");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG22",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM Info was not found in RHS and related data was not verified");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMDeskInfo","Exception",e);
		}
	}

	public static void checkDeskInfo(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsChatInteg.changeToDeskInfo(driver);

			if(CommonFunctionsChatInteg.isNewDeskInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"Related Desk Info was found when the visitor was updated with existing email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG23",true);
			}
			else
			{
				etest.log(Status.FAIL,"Related Desk info was not found when the visitor was updated with existing email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkDeskInfo","Exception",e);
		}
	}

	public static void checkPreviousRelatedTicketsShown(WebDriver driver,ExtentTest etest)
	{
		try
		{
			if(CommonFunctionsChatInteg.isRecentTicketsInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"Previous ticket Info was found when the visitor was updated with existing email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG24",true);
			}
			else
			{
				etest.log(Status.FAIL,"Previous Ticket info was not found when the visitor was updated with existing email address");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkPreviousRelatedTicketsShown","Exception",e);
		}
	}

	public static void checkRecentTicketsDisappeared(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String email = CommonUtil.getUniqueMessage()+"@email.com";
			CRMPlusCommonUtil.navToSalesiq(driver);
			ChatHistoryChat.setRHSData(driver,etest,null,null,email,null);

			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToSalesiqFrame(driver);

			if(!CommonFunctionsChatInteg.isRecentTicketsInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"Previous ticket Info was disappeared when the visitor was updated with new email address");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG25",true);
			}
			else
			{
				etest.log(Status.FAIL,"Previous ticket info was not disappeared even when the visitor was updated with new email address");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkRecentTicketsDisappeared","Exception",e);
		}
	}

	public static void checkAddNote(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String crmId = CommonFunctionsChatInteg.getCRMId(driver);
			String supportId = CommonFunctionsChatInteg.getSupportId(driver);
			CRMPChatWindow.addNote(driver);
			CommonUtil.sleep(60000); //getting a min to update in CRM
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.clickCRMContact(driver);
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.clickCRMContact(driver);

			CommonFunctionsChatInteg.clickContactInCRM(driver,crmId);

			if(CommonUtil.getElement(driver,By.id("BodyContent")).getText().contains("Note Added"))
			{
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+CommonUtil.getElement(driver,By.id("noteDetails")).getLocation().y+"+500)");
				etest.log(Status.PASS,"Note added in Salesiq was found in CRM");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG17",true);
			}
			else
			{
				etest.log(Status.FAIL,"Note added in Salesiq was not found in CRM");
				TakeScreenshot.screenshot(driver,etest);
			}

			CRMPlusCommonUtil.navToDesk(driver);

			if((CommonFunctionsChatInteg.checNotesAdded(driver,supportId)) && (CommonFunctionsChatInteg.checkTextInDesk(driver,"Note Added",supportId)))
			{
				etest.log(Status.PASS,"Expected <b>note</b> was found in the respective ticket details");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG18",true);
			}
			else
			{
				etest.log(Status.FAIL,"Expected <b>note</b> was not found in the respective ticket details");
				TakeScreenshot.screenshot(driver,etest);
			}
			CRMPlusCommonUtil.clickMyChats(driver);
			ChatWindow.endChat(driver);
			CRMPChatWindow.closeAllChats(driver,etest);

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkAddNote","Exception",e);
		}
	}

	public static void checkChatTranscript(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CommonFunctionsChatInteg.createTicket(driver);
			CRMPlusCommonUtil.clickMyChats(driver);
			ChatWindow.sentMessage(driver,agentMesssage);
			VisitorWindow.sentMessageInTheme(visitor_driver,visMessage);
			String supportId = CommonFunctionsChatInteg.getSupportId(driver);
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.navToDesk(driver);
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToFrame(driver,"support");

			if((CommonFunctionsChatInteg.checkTextInDesk(driver,agentMesssage,supportId)) && (CommonFunctionsChatInteg.checkTextInDesk(driver,visMessage,supportId)))
			{
				etest.log(Status.PASS,"Expected <b>messages</b> were found in the respective ticket details");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG28",true);
			}
			else
			{
				etest.log(Status.FAIL,"Expected <b>messages</b> were not found in the respective ticket details");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkChatTranscript","Exception",e);
		}
	}

	public static void checkFeedbackInfo(WebDriver driver,ExtentTest etest,boolean isFeedbackGiven)
	{
		try
		{
			String desc = isFeedbackGiven?" ":" not ";
			String descOpp = isFeedbackGiven?" not ":" ";
			String key = isFeedbackGiven ? "CRMP_CHATINTEG29" : "CRMP_CHATINTEG30";

			if(isFeedbackGiven)
			{
				VisitorWindow.enterFeedbackInTheme(visitor_driver,"feedback given by automation test","3");
			}
			else
			{
				CRMPlusCommonUtil.clickMyChats(driver);
				supportId = CommonFunctionsChatInteg.getSupportId(driver);
				ChatWindow.endChat(driver);
				CRMPChatWindow.closeAllChats(driver,etest);
				VisitorWindow.enterFeedbackInTheme(visitor_driver,null,"3",true,etest);
			}

			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.navToDesk(driver);
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.switchToFrame(driver,"support");

			if(CommonFunctionsChatInteg.checkTextInDesk(driver,"feedback given by automation test",supportId) == isFeedbackGiven)
			{
				etest.log(Status.PASS,"Feedback info by the visitor was"+desc+"found in Desk");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,"Feedback info by the visitor was"+descOpp+"found in Desk");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkFeedbackInfo","Exception",e);
		}
	}

	public static void checkAutoGeneratedTicketsForMissedChats(WebDriver driver,ExtentTest etest,boolean isEmail)
	{
		try
		{
			String desc = isEmail?" ":" not ";
			String descOpp = isEmail?" not ":" ";
			String key = isEmail ? "CRMP_CHATINTEG31" : "CRMP_CHATINTEG32";

			String label = CommonUtil.getUniqueMessage();
			visName = isEmail?"v"+label:"visName";
			visEmail = isEmail?"v"+label+"@email.com":"not given";
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			visitorId = CommonFunctionsTR.getVisitorId(visitor_driver);
			CRMPChatWindow.initiateChat(visitor_driver,visEmail,etest);
			VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
			CRMPlusCommonUtil.clickMissedChats(driver);
			CommonUtil.sleep(5000);
			WebElement missedChat = MissedChatCommonFunctions.getHistoryListItemByName(driver,visName);
			CommonUtil.clickWebElement(driver,missedChat);
			CommonUtil.sleep(5000);
			CRMPlusCommonUtil.clickMissedChats(driver);
			missedChat = MissedChatCommonFunctions.getHistoryListItemByName(driver,visName);
			if(isEmail)
			{
				try
				{
					CommonWait.waitTillHidden(missedChat,120); // waiting till missed chat moved to chat history
				}
				catch(Exception e)
				{
					CommonUtil.refreshPage(driver);
					CommonWait.waitTillHidden(missedChat);
				}
			}
			CRMPlusCommonUtil.clickChatHistory(driver);
			WebElement missedChatInChatHistory = ChatHistory.getLatestChat(driver);

			if(CommonUtil.getElement(missedChatInChatHistory,ChatHistory.NAME_COLUMN,ChatHistory.VISITOR_NAME).getText().contains(visName))
			{
				CommonUtil.clickWebElement(driver,missedChatInChatHistory);
				if(CommonFunctionsChatInteg.checkTicketGeneratedInSalesiq(driver)  == isEmail)
				{
					etest.log(Status.PASS,"Ticket was"+desc+"auto generated for missed chat -- email("+visEmail+")");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,"Ticket was"+descOpp+"auto generated for missed chat -- email("+visEmail+")");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Missed chat was not found in chat history -- email("+visEmail+")");
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkAutoGeneratedTicketsForMissedChats","Exception",e);
		}
	}

	public static void checkCRMDeskInfoInMissedChats(WebDriver driver,ExtentTest etest,boolean isExistingEmail)
	{
		try
		{
			String crmKey = isExistingEmail?"CRMP_CHATINTEG33" : "CRMP_CHATINTEG34";
			String deskKey = isExistingEmail ? "CRMP_CHATINTEG35" : "CRMP_CHATINTEG36";
			CommonUtil.refreshPage(driver);
			CRMPlusCommonUtil.clickChatHistory(driver);
			CommonUtil.clickWebElement(driver,ChatHistory.getLatestChat(driver));
			if(isExistingEmail)
			{
				ChatHistoryChat.setRHSData(driver,etest,null,null,actualVisEmail,null);
			}
			if(CommonFunctionsChatInteg.isCRMInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"CRM info was displayed for a Missed chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(crmKey,true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM info was not displayed for a missed chat");
				TakeScreenshot.screenshot(driver,etest);
			}
			if(CommonFunctionsChatInteg.isDeskInfoDisplayed(driver) && (CommonFunctionsChatInteg.isRecentTicketsInfoDisplayed(driver) == isExistingEmail))
			{
				etest.log(Status.PASS,"Desk info was displayed for a Missed chat");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(deskKey,true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk info (including the previous ticket details) was not displayed for the missed chat");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMDeskInfoInMissedChats","Exception",e);
		}
	}

	public static void checkMissedChatsMovedToChatHistory(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickChatHistory(driver);

			actualVisName = ChatHistory.getChatData( ChatHistory.getLatestChat(driver) ).get(ChatHistory.VISITOR);
			actualVisEmail = ChatHistory.getChatData( ChatHistory.getLatestChat(driver) ).get(ChatHistory.MAIL);

			if((CommonUtil.checkStringContainsAndLog(visName,actualVisName,"Visitor Name",etest)) && 
				(CommonUtil.checkStringContainsAndLog(visEmail,actualVisEmail,"Visitor Email",etest)))
			{
				etest.log(Status.PASS,"Missed Chat was converted as ticket and was found in chat history");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATINTEG37",true);
			}
			else
			{
				etest.log(Status.FAIL,"Missed chat was not found in Chat history tab");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkMissedChatsMovedToChatHistory","Exception",e);
		}
	}
}
