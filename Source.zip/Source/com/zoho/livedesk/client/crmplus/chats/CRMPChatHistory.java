//$Id$
package com.zoho.livedesk.client.crmplus.chats;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

public class CRMPChatHistory
{
	public static Hashtable result = new Hashtable();
	public static Hashtable finalResult = new Hashtable();
	public static ExtentTest etest;

	public static WebDriver visitor_driver;
	public static VisitorDriverManager visitor_driver_manager;

	public static String widgetCode,portalName;

	public static By
	chatHistoryTab = By.id("crmpluscommonui_salesiq_history"),
	newDeskTicket = By.id("newreqdiv"),
	visitorStatus = By.id("vstatus"),
	integStatus = By.id("vintegstatus");

	public static String
	moduleName = "CRMP Chat history",
	convertChatAsTicket = "Convert chat as Ticket",
	convertedAsTicket = "Converted as Ticket",
	notConvertedAsSupportTicket = "Not Converted as Support Tickets",
	addedAsTicket = "Added as Ticket";

	public static Hashtable testChatHistory(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			widgetCode = ExecuteStatements.getWidgetCode(driver);
			portalName = ExecuteStatements.getPortal(driver);

			CRMPlusCommonUtil.initResultHashtable(result,"CRMP_CHATHISTORY",9);

			etest = ComplexReportFactory.getTest("Check Chat History Tab");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkChatHistoryTab(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Visitor Details");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkVisitorDetails(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check CRM and Desk Info of a visitor in Chat History");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkCRMDeskInfoInChatHistory(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check convert as Ticket for missed chat");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkConvertChatAsTicket(driver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check filter options");
			ComplexReportFactory.setValues(etest,"Automation",moduleName);
			checkFilterOptions(driver,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module Breakage Occurred"+e);
			TakeScreenshot.screenshot(driver,etest);
		}
		finally
		{
			visitor_driver_manager.closeAllDrivers(portalName);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkChatHistoryTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			driver.switchTo().defaultContent();
			if(CommonWait.isDisplayed(driver,chatHistoryTab))
			{
				etest.log(Status.INFO,"Chat history tab was displayed");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATHISTORY1",true);
			}
			else
			{
				etest.log(Status.FAIL,"Chat history tab was not displayed");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkChatHistoryTab","Exception",e);
		}
	}

	public static void checkVisitorDetails(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String visEmail = "v"+label+"@email.com";
			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			CRMPChatWindow.quickOngoingChat(driver,visitor_driver,visEmail,etest);

			if(CRMPChatWindow.isMyChatsTabDisplayed(driver))
			{
				CRMPlusCommonUtil.switchToSalesiqFrame(driver);
				ChatWindow.openVisitorInfo(driver);

		        Hashtable<String,String> visitor_info_during_chat=ChatWindow.getAllVisitorInfo(driver);

		        //removing uncheckable keys
		        visitor_info_during_chat.remove(ResourceManager.getRealValue("time_chatduration"));

		        ChatWindow.openChatTranscript(driver);

		        CRMPChatWindow.closeAllChats(driver,etest);
		        Driver.quitDriver(visitor_driver);

		        driver.navigate().refresh();

	        	CRMPlusCommonUtil.clickChatHistory(driver);

	        	CommonUtil.clickWebElement(driver,ChatHistory.getLatestChat(driver));

	        	ChatHistoryChat.openVisitorInfo(driver);

		        Hashtable<String,String> visitor_info_after_chat=ChatHistoryChat.getAllVisitorInfo(driver);

		        if(CommonUtil.compareHashtable(visitor_info_during_chat,visitor_info_after_chat,etest))
		        {
		        	etest.log(Status.PASS,"Visitor info were verified");
		        	TakeScreenshot.infoScreenshot(driver,etest);
		        	result.put("CRMP_CHATHISTORY2",true);
		        }
		        else
		        {
		        	etest.log(Status.FAIL,"Visitor info was not verified");
		        	TakeScreenshot.screenshot(driver,etest);
		        }
		    }
		    else
		    {
		    	etest.log(Status.FAIL,"My chats was not displayed after accepting chat");
		    	TakeScreenshot.screenshot(driver,etest);
		    	TakeScreenshot.screenshot(visitor_driver,etest);
		    }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkVisitorDetails","Exception",e);
		}
	}

	public static void checkCRMDeskInfoInChatHistory(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickChatHistory(driver);
			CommonUtil.clickWebElement(driver,ChatHistory.getLatestChat(driver));
			if(CommonFunctionsChatInteg.isCRMInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"CRM data was found in Chat History tab");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATHISTORY3",true);
			}
			else
			{
				etest.log(Status.FAIL,"CRM data was not found in Chat History tab");
				TakeScreenshot.screenshot(driver,etest);
			}

			if(CommonFunctionsChatInteg.isDeskInfoDisplayed(driver))
			{
				etest.log(Status.PASS,"Desk info was found in Chat History tab");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATHISTORY4",true);
			}
			else
			{
				etest.log(Status.FAIL,"Desk info was not found in Chat History tab");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkCRMDeskInfoInChatHistory","Exception",e);
		}
	}

	public static void checkConvertChatAsTicket(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String visEmail = "v"+label+"@email.com";

			CRMPlusCommonUtil.clickVisitorsOnline(driver);
			visitor_driver = visitor_driver_manager.getDriver(driver);
			VisitorWindow.createPage(visitor_driver,widgetCode);
			CRMPChatWindow.quickChat(driver,visitor_driver,"without email",etest);

			CRMPlusCommonUtil.clickChatHistory(driver);
			CommonUtil.clickWebElement(driver,ChatHistory.getLatestChat(driver));

			try
			{
				ChatHistoryChat.setRHSData(driver,etest,null,null,visEmail,null);
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,"Visitor details was not updated (waited for 1 minute). Hence the chat would not be converted to Ticket");
				TakeScreenshot.screenshot(driver,etest);
				return;
			}

			if(CommonFunctionsChatInteg.isDeskInfoDisplayed(driver))
			{
				etest.log(Status.INFO,"Desk info was found in Chat History tab");
				TakeScreenshot.infoScreenshot(driver,etest);
				if(CommonUtil.getElement(driver,newDeskTicket).getText().contains(convertChatAsTicket))
				{
					etest.log(Status.PASS,"Convert chat as Ticket option was found in Chat for visitor without email");
					TakeScreenshot.infoScreenshot(driver,etest);
					result.put("CRMP_CHATHISTORY5",true);
					CommonFunctionsChatInteg.createTicket(driver);
					if(CommonFunctionsChatInteg.checkTicketGeneratedInSalesiq(driver))
					{
						etest.log(Status.PASS,"Chat was converted into Ticket");
						TakeScreenshot.infoScreenshot(driver,etest);
						result.put("CRMP_CHATHISTORY6",true);
					}
					else
					{
						etest.log(Status.FAIL,"Chat was not converted into ticket");
						TakeScreenshot.screenshot(driver,etest);
					}
				}
				else
				{
					etest.log(Status.FAIL,"Convert chat as ticket option was not found in Chat for visitor without email");
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Desk info was not found in Chat History tab");
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkConvertChatAsTicket","Exception",e);
		}
	}

	public static void checkFilterOptions(WebDriver driver,ExtentTest etest)
	{
		try
		{
			CRMPlusCommonUtil.clickChatHistory(driver);
			if(CommonFunctionsChatInteg.checkFilterOptions(driver,visitorStatus,convertedAsTicket))
			{
				etest.log(Status.PASS,"<b>Convert Chat as a Ticket</b> filter was checked in chat history");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATHISTORY7",true);
			}
			else
			{
				etest.log(Status.FAIL,"<b>Convert Chat as a Ticket</b> filter check in chat history was failed");
				TakeScreenshot.screenshot(driver,etest);
			}

			CRMPlusCommonUtil.clickChatHistory(driver);
			ChatHistory.closeFilter(driver);
			if(CommonFunctionsChatInteg.checkFilterOptions(driver,integStatus,notConvertedAsSupportTicket))
			{
				etest.log(Status.PASS,"<b>Not Converted as a Support Ticket</b> filter was checked in chat history");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATHISTORY8",true);
			}
			else
			{
				etest.log(Status.FAIL,"<b>Not Converted as a Support Ticket</b> filter check in chat history was failed");
				TakeScreenshot.screenshot(driver,etest);
			}

			CRMPlusCommonUtil.clickChatHistory(driver);
			ChatHistory.closeFilter(driver);
			if(CommonFunctionsChatInteg.checkFilterOptions(driver,integStatus,addedAsTicket))
			{
				etest.log(Status.PASS,"<b>Added as Ticket</b> filter was checked in chat history");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put("CRMP_CHATHISTORY9",true);
			}
			else
			{
				etest.log(Status.FAIL,"<b>Added as Ticket</b> filter check in chat history was failed");
				TakeScreenshot.screenshot(driver,etest);
			}
			CRMPlusCommonUtil.clickChatHistory(driver);
			ChatHistory.closeFilter(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,moduleName,"checkFilterOptions","Exception",e);
		}
	}
}
