//$Id$
package com.zoho.livedesk.client;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class Department
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    private static String mailid = "";
    private static String url = "";
    public static ExtentTest etest;

	public static Hashtable department(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD1"));
            ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			url = ConfManager.requestURL();
			
            //WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			//Department view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
			//Thread.sleep(2000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));

            result.put("SD1", true);

            etest.log(Status.PASS,"Department Tab is present");
            ComplexReportFactory.closeTest(etest);
            //Thread.sleep(1000);
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD2"));
            ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD2", isPageAvail(driver));
            ComplexReportFactory.closeTest(etest);
			//Thread.sleep(1000);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD3"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD3", addDept(driver, "Department1", "depttype_privat",false));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD4"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD4", addDept(driver, "Renamed2", "depttype_publi",false));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD5")+" And Check Email Configuration");
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD5", addDept(driver, "Department3", "depttype_privat",true));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD6")+" And Check Email Configuration");
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD6", addDept(driver, "Department4", "depttype_publi",true));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD7"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD7", renameDepartment(driver,"Renamed2","Department2"));
            //Thread.sleep(1000);
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD8"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD8", changeDeptType(driver,"Department3","Public"));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD9"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD9", changeDeptType(driver,"Department4","Private"));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD10"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD10", disableDepartment(driver,"Department3"));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD11"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD11", enableDepartment(driver,"Department3"));
            //Thread.sleep(1000);
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD12"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD12", deleteDepartment(driver,"Department3"));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD13"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD13", addDeptNoAgent(driver,"Department5"));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD14"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD14", addDeptNoDeptName(driver));
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SD15"));
			ComplexReportFactory.setValues(etest,"Automation","DepartmentSettings-Admin");

            result.put("SD15", removeAgent(driver,"Department4","LDAutomation"));
            //Thread.sleep(1000);
			deleteDepartment(driver,"Department4");
            //Thread.sleep(1000);
			deleteDepartment(driver,"Department1");
            //Thread.sleep(1000);
			deleteDepartment(driver,"Department2");
            //Thread.sleep(1000);
			//deleteDepartment(driver,"Renamed2");
            //Thread.sleep(1000);
            ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorDepartmentTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentTab","ErrorDepartmentTab",e);

            result.put("SD1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorDepartmentTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentTab","ErrorDepartmentTab",e);

            result.put("SD1", false);
		}

		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check Department Header
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("setting_department")+"')]")));
			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("setting_department")+"')]"));
			//Thread.sleep(300);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));

			if((driver.findElement(By.className("innersubinfotxt")).getText()).equals(ResourceManager.getRealValue("settings_department_desc")))
		 	{
                etest.log(Status.PASS,"Description Matched");
				return true;
			}
            else{
                TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettingsDescription","MismatchDepartmentDescription");
            }
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettingsDescription","ErrorWhileCheckingDepartmentSettingsPageIsAvailable",e);

            System.out.println("Exception while checking if department settings page is available : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettingsDescription","ErrorWhileCheckingDepartmentSettingsPageIsAvailable",e);

            System.out.println("Exception while checking if department settings page is available : "+e);
        }
		return false;
	}

	//Get User Name
    private static String getUserName(WebDriver driver)
    {
        String knownas = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings")));

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));
            //Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_myprofile"))).click();
            //Thread.sleep(1000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

            WebElement elmt = driver.findElement(By.id("test"));
            WebElement userdetails = elmt.findElement(By.className("usr-mrgntp")).findElement(By.id("userdetails"));
            knownas = userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
            etest.log(Status.INFO,"Operatorname is got from MyProfile Page");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","GettingOperatorNameInProfilePage","ErrorWhileGettingOperatorNameFromProfilePage",e);

            System.out.println("Exception while getting operatorname in department settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","GettingOperatorNameInProfilePage","ErrorWhileGettingOperatorNameFromProfilePage",e);

            System.out.println("Exception while getting Operatorname in department settings page : "+e);
        }
        return knownas;
    }

    //Add Department with no agent
    private static boolean addDeptNoAgent(WebDriver driver, String deptname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

            driver.findElement(By.id("buttonadddept")).click();
            //Thread.sleep(500);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));

            driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_adddepartment")+"')]"));
            //Thread.sleep(300);
            driver.findElement(By.id("name")).click();
            //Thread.sleep(1000);
            driver.findElement(By.id("name")).clear();
            //Thread.sleep(1000);
            driver.findElement(By.id("name")).sendKeys(deptname);
            //Thread.sleep(500);
            driver.findElement(By.id("desc")).click();
            //Thread.sleep(1000);
            driver.findElement(By.id("desc")).clear();
            driver.findElement(By.id("desc")).sendKeys("Description");
            //Thread.sleep(1000);

            //JavascriptExecutor je = (JavascriptExecutor)driver;
            //je.executeScript("scroll(0,2000)");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+")");
            driver.findElement(By.id("deptaddbtn")).click();
            //Thread.sleep(1000);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("assodept")));

            if((driver.findElement(By.id("assodept")).getText()).contains(ResourceManager.getRealValue("settings_chooseuser")))
            {
                etest.log(Status.PASS,"Alert Matched");
                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettings-AlertContentForChooseOperatorInAddingDept","MismatchAlertContentForChooseOperatorInAddingDept");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettings-AlertContentForChooseOperatorInAddingDept","ErrorWhileAddingDepartmentWithoutOperator",e);

            System.out.println("Exception while Adding department without agent in department settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettings-AlertContentForChooseOperatorInAddingDept","ErrorWhileAddingDepartmentWithoutOperator",e);

            System.out.println("Exception while Adding department without agent in department settings page : "+e);
        }
        return false;
    }

    //Add Department with no department name
    private static boolean addDeptNoDeptName(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            String user = getUserName(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
            //Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

            driver.findElement(By.id("buttonadddept")).click();
            //Thread.sleep(500);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));

            driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_adddepartment")+"')]"));
            //Thread.sleep(300);
            driver.findElement(By.id("desc")).click();
            driver.findElement(By.id("desc")).clear();
            driver.findElement(By.id("desc")).sendKeys("Description");
            //Thread.sleep(1000);
            //JavascriptExecutor je = (JavascriptExecutor)driver;
            //je.executeScript("scroll(0,2000)");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+")");

            driver.findElement(By.id("deptaddbtn")).click();
            //Thread.sleep(1000);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("formadddept")));

            if((driver.findElement(By.id("formadddept")).getText()).contains(ResourceManager.getRealValue("settings_entervaliddept")))
            {
                etest.log(Status.PASS,driver.findElement(By.id("formadddept")).getText()+" is present");
                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettings-AlertContentForNoDeptNameInAddingDept","MismatchAlertContentForNoDeptNameInAddingDept");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettings-AlertContentForNoDeptNameInAddingDept","ErrorWhileAddingDepartmentWithoutDeptName",e);

            System.out.println("Exception while Adding department without department name in department settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DepartmentSettings-AlertContentForNoDeptNameInAddingDept","ErrorWhileAddingDepartmentWithoutDeptName",e);

            System.out.println("Exception while Adding department without department name in department settings page : "+e);
        }
        return false;
    }

	//Add Department
	private static boolean addDept(WebDriver driver, String deptname, String type, boolean emailconfig)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			String user = getUserName(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//Thread.sleep(1000);

			//WebDriverWait wait = new WebDriverWait(driver, 20);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

		 	//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

            driver.findElement(By.id("buttonadddept")).findElement(By.tagName("span")).click();
		 	//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));

		 	driver.findElement(By.id("name")).click();
		 	driver.findElement(By.id("name")).clear();
		 	driver.findElement(By.id("name")).sendKeys(deptname);
		 	//Thread.sleep(500);
		 	driver.findElement(By.id(type)).click();
		 	//Thread.sleep(500);
		 	driver.findElement(By.id("desc")).click();
            //Thread.sleep(1000);
		 	driver.findElement(By.id("desc")).clear();
            //Thread.sleep(1000);
		 	driver.findElement(By.id("desc")).sendKeys("Description");
		 	//Thread.sleep(1000);

			//JavascriptExecutor je = (JavascriptExecutor)driver;
			//je.executeScript("scroll(0,200)");
			//Thread.sleep(500);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("assodept"))).getLocation().y+"-300)");

			if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
			{
				WebElement elmt = driver.findElement(By.id("unassodeptlist"));

				List<WebElement> elmts = elmt.findElements(By.className("associatesel"));

				for(WebElement element:elmts)
				{
					WebElement ptag;
					//try
					//{
						ptag = element.findElement(By.tagName("p"));
					//}
					//catch(Exception e)
					//{
						//continue;
					//}
					if(user.equals(ptag.getText()))
					{
						//List<WebElement> elmts1 = element.findElements(By.tagName("div"));

                        element.findElement(By.tagName("div")).click();
						//elmts1.get(0).click();
						break;
					}
				}
			}
		 	//Thread.sleep(1000);
		 	if(emailconfig)
		 	{
		 		editEmailConfig(driver);
		 	}

			//je.executeScript("scroll(0,2000)");
			//Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+")");
		 	driver.findElement(By.id("deptaddbtn")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);

			if(emailconfig)
			{
				checkEmailConfig(driver, deptname);
			}
		 	return checkAddedDept(driver, deptname, type, user);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","AddingDepartment","ErrorWhileAddingDepartment",e);

            System.out.println("Exception while Adding department in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","AddingDepartment","ErrorWhileAddingDepartment",e);

            System.out.println("Exception while Adding department in department settings page : "+e);
        }
		return false;
	}

	//Edit email configurations
	private static void editEmailConfig(WebDriver driver)
	{
		try
		{
			//JavascriptExecutor je = (JavascriptExecutor)driver;
			//je.executeScript("scroll(0,600)");
			//Thread.sleep(1000);

			editData(driver,"SD16", null, "frommailid", "rajkumar.natarajan+11@zohocorp.com");
            //Thread.sleep(1000);
			addInvalidData(driver,"SD17","ccemailaddr", "sccemailaddr", "hi");
            //Thread.sleep(1000);

			editData(driver,"SD18", "ccemailaddr", "sccemailaddr", "rajkumar.natarajan+12@zohocorp.com");
            //Thread.sleep(1000);
            editData(driver,"SD19", "sendemailforipblockto",  "ssendemailforipblockto", "rajkumar.natarajan+13@zohocorp.com");
            //Thread.sleep(1000);
			//je.executeScript("scroll(0,1000)");
			//Thread.sleep(1000);

			editData(driver,"SD20", "visitorfeedback", "svisitorfeedback", "rajkumar.natarajan+14@zohocorp.com");
            //Thread.sleep(1000);
			editData(driver,"SD21", "sendtranasemail", "ssendtranasemail", "rajkumar.natarajan+15@zohocorp.com");
            //Thread.sleep(1000);
			editData(driver,"SD22", "offbusymsg", "soffbusymsg", "rajkumar.natarajan+16@zohocorp.com");
            //Thread.sleep(1000);

		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while editing email config in department settings page : "+e);
        }
		catch(Exception e)
		{
            System.out.println("Exception while editing email config in department settings page : "+e);
        }
	}

	//Add invalid value to email config
	private static void addInvalidData(WebDriver driver, String name, String id, String eid, String value)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(eid)));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(eid))).getLocation().y+"-400)");
			driver.findElement(By.id(eid)).click();
            //Thread.sleep(1000);
			driver.findElement(By.id(eid)).clear();
            //Thread.sleep(1000);
			driver.findElement(By.id(eid)).sendKeys(value);
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptconfig")));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptconfig"))).getLocation().y+")");
			driver.findElement(By.id("deptconfig")).click();

			if(driver.findElement(By.id("popupftr"))!=null)
			{
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("okbtn"))).getLocation().y+")");
				driver.findElement(By.id("okbtn")).click();
				//Thread.sleep(1000);
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(eid))).getLocation().y+")");
				driver.findElement(By.id(eid)).click();
                //Thread.sleep(1000);
				driver.findElement(By.id(eid)).clear();
                //Thread.sleep(1000);
				result.put(name, true);
			}
			else
			{
                TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","PopUpDivForInvalidEmailIdWhileAddingDept","PopUpDivNotPresentForInvalidEmailId");
				result.put(name, false);
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","PopUpDivForInvalidEmailIdWhileAddingDept","ErrorWhileEmailConfigWithInvalidEmailInDepartment",e);

            System.out.println("Exception while editing email config with invalid data in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","PopUpDivForInvalidEmailIdWhileAddingDept","ErrorWhileEmailConfigWithInvalidEmailInDepartment",e);

            System.out.println("Exception while editing email config with invalid data in department settings page : "+e);
        }
	}

	//Edit email configurations data
	private static void editData(WebDriver driver, String name, String id, String eid, String value)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			//Thread.sleep(3000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(eid)));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(eid))).getLocation().y+"-400)");
			driver.findElement(By.id(eid)).click();
            //Thread.sleep(1000);
			driver.findElement(By.id(eid)).clear();
            //Thread.sleep(1000);
			driver.findElement(By.id(eid)).sendKeys(value);
			//Thread.sleep(1000);

			//result.put(name, true);
		}
		catch(NoSuchElementException e)
		{
            result.put(name, false);
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","EditingEmailConfig","ErrorWhileEditingEmailConfigInDepartmentFor-"+eid,e);
            System.out.println("Exception while editing email config in department settings page : "+e);
        }
		catch(Exception e)
		{
            result.put(name, false);
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","EditingEmailConfig","ErrorWhileEditingEmailConfigInDepartmentFor-"+eid,e);
            System.out.println("Exception while editing email config in department settings page : "+e);
        }
	}

	//Check Email config
	private static void checkEmailConfig(WebDriver driver, String deptname)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			//Thread.sleep(2000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

			//Thread.sleep(1000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
			//Thread.sleep(1000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				//Thread.sleep(1000);
				if(data.equals(deptname))
				{
					List<WebElement> em = elmt.findElements(By.tagName("em"));
					//Thread.sleep(1000);
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
					em.get(1).click();
					//Thread.sleep(1000);
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptdetaildiv")));

			//JavascriptExecutor je = (JavascriptExecutor)driver;
			//je.executeScript("scroll(0,600)");
			//Thread.sleep(1000);

			checkData(driver,"SD16", null, "frommailid", "rajkumar.natarajan+11@zohocorp.com");
            //Thread.sleep(1000);

			checkData(driver,"SD18", "ccemailaddr", "sccemailaddr", "rajkumar.natarajan+12@zohocorp.com");
            //Thread.sleep(1000);
			checkData(driver,"SD19", "sendemailforipblockto", "ssendemailforipblockto", "rajkumar.natarajan+13@zohocorp.com");
            //Thread.sleep(1000);
			//je.executeScript("scroll(0,1000)");
			//Thread.sleep(1000);

			checkData(driver,"SD20", "visitorfeedback", "svisitorfeedback", "rajkumar.natarajan+14@zohocorp.com");
            //Thread.sleep(1000);
			checkData(driver,"SD21", "sendtranasemail", "ssendtranasemail", "rajkumar.natarajan+15@zohocorp.com");
            //Thread.sleep(1000);
			checkData(driver,"SD22", "offbusymsg", "soffbusymsg", "rajkumar.natarajan+16@zohocorp.com");
            //Thread.sleep(1000);

		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingEditedEmailConfig","ErrorWhileCheckingEmailConfigInDepartment",e);

            System.out.println("Exception while checking email config in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingEditedEmailConfig","ErrorWhileCheckingEmailConfigInDepartment",e);

            System.out.println("Exception while checking email config in department settings page : "+e);
        }
	}

	//Check email data
	private static void checkData(WebDriver driver, String name, String id, String eid, String value)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			//Thread.sleep(3000);
			result.put(name, false);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(eid)));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(eid))).getLocation().y+"-300)");

			String val = driver.findElement(By.id(eid)).getAttribute("value");

			if(val.equals(value))
			{
				etest.log(Status.PASS,eid+" is Verified");

                result.put(name, true);
			}
            else{
                TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingEditedEmailConfig","MismatchEditedEmailConfig-"+value);
            }
			//Thread.sleep(1000);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingEditedEmailConfig","ErrorWhileCheckingEditedEmailDataInDepartment",e);
            result.put(name, false);
            System.out.println("Exception while checking edited email data in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingEditedEmailConfig","ErrorWhileCheckingEditedEmailDataInDepartment",e);
            result.put(name, false);
            System.out.println("Exception while checking edited email data in department settings page : "+e);
        }
	}


	//Check added department details
	private static boolean checkAddedDept(WebDriver driver, String deptname, String type, String username)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			//Thread.sleep(2000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //Thread.sleep(1000);

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

			//Thread.sleep(1000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				//Thread.sleep(1000);
				if(data.equals(deptname))
				{
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
					List<WebElement> em = elmt.findElements(By.tagName("em"));
					//Thread.sleep(1000);
					em.get(1).click();
					//Thread.sleep(1000);
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptdetaildiv")));
		 	//Thread.sleep(500);
			WebElement departmentdetails = driver.findElement(By.id("deptdetaildiv"));
			String usr = departmentdetails.findElement(By.id("associatedusers")).findElement(By.tagName("img")).getAttribute("title");

			String desc = departmentdetails.findElement(By.tagName("textarea")).getText();

		 	if(desc.equals("Description") && usr.equals(username))
		 	{
				WebElement typeelmt = departmentdetails.findElement(By.id("departmenttype"));
		 		if(type.equals("depttype_privat"))
		 		{
					if((typeelmt.findElements(By.tagName("span")).get(1).getAttribute("class")).contains("rdselected"))
		 			{
		 				etest.log(Status.PASS,"Added Department - "+deptname+" is present");

                        return true;
		 			}
		 		}
		 		else if(type.equals("depttype_publi"))
		 		{
					if((typeelmt.findElements(By.tagName("span")).get(0).getAttribute("class")).contains("rdselected"))
		 			{
		 				etest.log(Status.PASS,"Added Department - "+deptname+" is present");

                        return true;
		 			}
		 		}
		 	}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingAddedDepartment","ErrorWhileCheckingAddedDepartment",e);

            System.out.println("Exception while checking added department in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","CheckingAddedDepartment","ErrorWhileCheckingAddedDepartment",e);

            System.out.println("Exception while checking added department in department settings page : "+e);
        }
		return false;
	}

	//Remove agent name in dept and save
	private static boolean removeAgent(WebDriver driver, String dept, String agent)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			String user = getUserName(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
			//Thread.sleep(1000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				//Thread.sleep(1000);
				if(data.equals(dept))
				{
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
					elmt.click();
					//Thread.sleep(1000);
					break;
				}
			}
			//Thread.sleep(500);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("main_rapr")));

			WebElement elmt = driver.findElement(By.className("main_rapr")).findElement(By.id("associatedusers"));
			elmts = elmt.findElements(By.tagName("span"));

			for(WebElement element:elmts)
			{
				if(user.equals(element.findElement(By.tagName("img")).getAttribute("title")))
				{
					List<WebElement> elmts1 = elmts.get(0).findElements(By.tagName("div"));
					mouseOver(driver, element.findElement(By.tagName("em")));
					element.findElement(By.tagName("em")).click();
					break;
				}
			}
			Tab.waitForLoading(driver,"updept.do",etest);

			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","RemovingAgentFromDept","ErrorWhileRemovingAgentFromDepartmentInDeptSettingsPage",e);

            System.out.println("Exception while removing agent from department in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","RemovingAgentFromDept","ErrorWhileRemovingAgentFromDepartmentInDeptSettingsPage",e);

            System.out.println("Exception while removing agent from department in department settings page : "+e);
        }
		return false;
	}

	//Rename department
	private static boolean renameDepartment(WebDriver driver, String oldname, String newname)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            System.out.println("djhvkagsjhfvjkvb 1");
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			System.out.println("djhvkagsjhfvjkvb 2");
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));
			//Thread.sleep(1000);
            System.out.println("djhvkagsjhfvjkvb 3");
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
		 	//Thread.sleep(1000);
            System.out.println("djhvkagsjhfvjkvb 5");
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));
            System.out.println("djhvkagsjhfvjkvb 6");
			WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            System.out.println("djhvkagsjhfvjkvb 7");
			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				//Thread.sleep(2000);
				if(data.equals(oldname))
				{
                    System.out.println("djhvkagsjhfvjkvb 8");
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
					elmt.click();
					//Thread.sleep(2000);
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptdetaildiv")));
					driver.findElement(By.id("deptname")).click();
                    System.out.println("CLICKED");
                    //Thread.sleep(2000);
                    driver.findElement(By.id("deptname")).clear();
                    System.out.println("CLEARED");
                    //Thread.sleep(2000);
					driver.findElement(By.id("deptname")).sendKeys(newname);
					System.out.println("Updated");
                    //Thread.sleep(2000);
                    ((JavascriptExecutor) driver).executeScript("document.getElementById('deptname').value='"+newname+"';");
                    System.out.println("Je updated");
                    //Thread.sleep(2000);
                    driver.findElement(By.className("innersubinfotxt")).click();
					//Thread.sleep(2000);
					break;
				}
			}
		 	//Thread.sleep(2000);
            Tab.waitForLoadingSuccessWithBanner(driver,"Updated successfully","updept.do",etest);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

		 	driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//Thread.sleep(2000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
		 	//Thread.sleep(2000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			elmt1 = driver.findElement(By.className("cmn_listviewer"));
			//Thread.sleep(2000);
			elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("txtelips")).getText();
				//Thread.sleep(2000);
				if(data.equals(newname))
				{
					etest.log(Status.PASS,"Department is renamed successfully");
                    return true;
				}
            }
		 	TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","RenameDepartment","DepartmentIsNotRenamed");
            return false;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","RenameDepartment","ErrorWhileRenamingDepartment",e);

            System.out.println("Exception while renaming department in department settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","RenameDepartment","ErrorWhileRenamingDepartment",e);

            System.out.println("Exception while renaming department in department settings page : "+e);
        }
		return false;
	}

	//change department type
    private static boolean changeDeptType(WebDriver driver, String deptname, String type)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            //Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            //Thread.sleep(1000);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(deptname))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
                    elmt.click();
                    //Thread.sleep(500);
                    break;
                }
            }
            //Thread.sleep(500);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("departmenttype")));

            driver.findElement(By.id("departmenttype")).findElement(By.id(type)).click();
            //Thread.sleep(1000);

            WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Department");

            if(popup != null)
            {
                try
                {
                    HandleCommonUI.clickPositivePopupButton(popup);
                }
                catch(Exception e)
                {
                    CommonUtil.doNothing();
                }
            }

            Tab.waitForLoadingSuccessWithBanner(driver,"Updated successfully","updept.do",etest);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(deptname))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    //Thread.sleep(1000);
                    em.get(1).click();
                    //Thread.sleep(1000);
                    break;
                }
            }

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptdetaildiv")));

            WebElement departmentdetails = driver.findElement(By.id("deptdetaildiv"));
            WebElement typeelmt = departmentdetails.findElement(By.id("departmenttype"));

            if(type.equals("Private"))
            {
                if((typeelmt.findElements(By.tagName("span")).get(1).getAttribute("class")).contains("rdselected"))
                {
                    etest.log(Status.PASS,"Department type is changed to private");

                    return true;
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","ChangeTo:Private","NotChanged");

                    return false;
                }
            }
            else if(type.equals("Public"))
            {
                if((typeelmt.findElements(By.tagName("span")).get(0).getAttribute("class")).contains("rdselected"))
                {
                    etest.log(Status.PASS,"Department type is changed to public");

                    return true;
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","ChangeTo:Public","NotChanged");

                    return false;
                }
            }
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","ChangeTo:"+type,"Error");

            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","ChangeDepartmentType","ErrorWhileChangingDeptType",e);

            System.out.println("Exception while changing the department type in department settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","ChangeDepartmentType","ErrorWhileChangingDeptType",e);

            System.out.println("Exception while changing the department type in department settings page : "+e);
        }
        return false;
    }

    //Disable department
    private static boolean disableDepartment(WebDriver driver, String deptname)throws Exception
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            //Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(deptname))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    //Thread.sleep(1000);
                    em.get(1).click();
                    //Thread.sleep(1000);
                    break;
                }
            }
            //Thread.sleep(2000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[onclick*='Department.changeStatus']")));
            driver.findElement(By.cssSelector("[onclick*='Department.changeStatus']")).click();

            Thread.sleep(1000);

            //Thread.sleep(5000);
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.className("innerbtnmn")).findElement(By.tagName("span")).getAttribute("class")).contains("cmn_gbutclor"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(deptname))
                {
                    if(elmt.getAttribute("class").contains("list_disable"))
                    {
                        etest.log(Status.PASS,"Department is Disabled");

                        return true;
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DisablingDepartment","DepartmentIsNotDisabled");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DisablingDepartment","ErrorWhileDisablingDepartment",e);

            System.out.println("Exception while disabling department in department settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DisablingDepartment","ErrorWhileDisablingDepartment",e);

            System.out.println("Exception while disabling department in department settings page : "+e);
        }
        return false;
    }

    //Enable department
    private static boolean enableDepartment(WebDriver driver, String deptname) throws Exception
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            //Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(deptname))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
                    List<WebElement> em = elmt.findElements(By.tagName("em"));
                    //Thread.sleep(1000);
                    em.get(1).click();
                    //Thread.sleep(1000);
                    break;
                }
            }

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[onclick*='Department.changeStatus']")));
            driver.findElement(By.cssSelector("[onclick*='Department.changeStatus']")).click();

            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.className("innerbtnmn")).findElement(By.tagName("span")).getAttribute("class")).contains("cmn_redbut"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                if(data.equals(deptname))
                {
                    if(elmt.getAttribute("class").contains("list_disable"))
                    {
                        TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","EnablingDepartment","DepartmentIsNotEnabled");
                        return false;
                    }
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","EnablingDepartment","ErrorWhileEnablingDepartment",e);
            System.out.println("Exception while enabling department in department settings page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","EnablingDepartment","ErrorWhileEnablngDepartment",e);
            System.out.println("Exception while enabling department in department settings page : "+e);
            return false;
        }
        etest.log(Status.PASS,"Department is enabled");
        return true;
    }

    //Delete department
    public static boolean deleteDepartment(WebDriver driver, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            WebElement elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(value))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-300)");
                    WebElement delelmt = elmt.findElements(By.className("list_cell")).get(0);
                    mouseOver(driver, delelmt.findElement(By.className("list_lefticon")));
                    CommonSikuli.findInWholePage(driver,"Departmentdelete1.png","UI306",etest);
                    mouseOver(driver, delelmt.findElement(By.className("list_lefticon")));
                    delelmt.findElement(By.className("list_lefticon")).click();
                    Thread.sleep(500);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptselect_div")));
                    //Thread.sleep(1000);
                    driver.findElement(By.id("deptselect_div")).click();
                    //Thread.sleep(2000);
                    List<WebElement> elmt2 = driver.findElement(By.id("deptselect1")).findElements(By.tagName("li"));
                    //Thread.sleep(500);

                    elmt2.get(0).click();
                    //Thread.sleep(2000);
                    driver.findElement(By.id("okbtn")).click();
                    //Thread.sleep(1000);
                    break;
                }
            }

            Tab.waitForLoading(driver,"deldept.do",etest);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_department"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_department"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            elmt1 = driver.findElement(By.className("cmn_listviewer"));
            //Thread.sleep(1000);
            elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("txtelips")).getText();
                //Thread.sleep(1000);
                if(data.equals(value))
                {
                    TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DeletingDepartment","DepartmentIsNotDeleted");
                    return false;
                }
            }
            etest.log(Status.PASS,"Department is Deleted");
            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DeletingDepartment","ErrorWhileDeletingDepartment",e);

            System.out.println("Exception while deleting department in department settings page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"DepartmentSettings-Admin","DeletingDepartment","ErrorWhileDeletingDepartment",e);

            System.out.println("Exception while deleting department in department settings page : "+e);
        }
        return false;
    }

    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        // new Actions(driver).moveToElement(element).perform();
        CommonUtil.mouseHover(driver,element);
    }

    //clear department details
    public static boolean clearDepts(WebDriver driver)
    {
        try
        {
            deleteDepartment(driver,"Department3");
            deleteDepartment(driver,"Department4");
            deleteDepartment(driver,"Department1");
            deleteDepartment(driver,"Department2");
            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clearing department data in department settings page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing department data in department settings page : "+e);
        }
        return false;
    }
}
