//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Keys;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;


public class GetPayload
{
    public static JSONObject getCreatePortalPayload(String name,String description) throws JSONException
    {
        return getCreatePortalPayload(name,null,null,null,null,description,null,null,null,null,null,null,null);
    }

    public static JSONObject getCreatePortalPayload(String name,String phone,String website,String fax,String time_zone,String description,String service,String autounique,String source,String ip,String language,String address,String email_id) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.PORTAL_NAME,name);
        payload=addIfNotNull(payload,APIKeys.PHONE,phone);
        payload=addIfNotNull(payload,APIKeys.WEBSITE,website);
        payload=addIfNotNull(payload,APIKeys.FAX,fax);
        payload=addIfNotNull(payload,APIKeys.TIME_ZONE,time_zone);
        payload=addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        payload=addIfNotNull(payload,APIKeys.SERVICE,service);
        payload=addIfNotNull(payload,APIKeys.AUTOUNIQUE,autounique);
        payload=addIfNotNull(payload,APIKeys.PORTAL_SOURCE,source);
        payload=addIfNotNull(payload,APIKeys.IP,ip);
        payload=addIfNotNull(payload,APIKeys.LANGUAGE,language);
        payload=addIfNotNull(payload,APIKeys.ADDRESS,address);
        payload=addIfNotNull(payload,APIKeys.EMAIL,email_id);
        return payload;
    }

    public static JSONObject getUpdatePortalPayload(String name,String phone,String website,String fax,String time_zone,String description,String language,String address,String email_id) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.PORTAL_NAME,name);
        payload=addIfNotNull(payload,APIKeys.PHONE,phone);
        payload=addIfNotNull(payload,APIKeys.WEBSITE,website);
        payload=addIfNotNull(payload,APIKeys.FAX,fax);
        payload=addIfNotNull(payload,APIKeys.TIME_ZONE,time_zone);
        payload=addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        payload=addIfNotNull(payload,APIKeys.LANGUAGE,language);
        payload=addIfNotNull(payload,APIKeys.ADDRESS,address);
        payload=addIfNotNull(payload,APIKeys.EMAIL,email_id);
        return payload;
    }

    public static JSONObject getCreateDepartmentPayload(String name,String is_public,String description,String[] operator_ids,String from_email,String is_transcript_mail_enabled,String transcript_recipients,String is_blockip_mail_enabled,String blockip_recipients,String is_feedback_mail_enabled,String feedback_recipients,String is_missedchat_mail_enabled,String missedchat_recipients,String is_cc_mail_enabled,String cc_recipients) throws JSONException
    {
        return getUpdateDepartmentPayload(name,is_public,description,operator_ids,from_email,is_transcript_mail_enabled,transcript_recipients,is_blockip_mail_enabled,blockip_recipients,is_feedback_mail_enabled,feedback_recipients,is_missedchat_mail_enabled,missedchat_recipients,is_cc_mail_enabled,cc_recipients);
    }

    public static JSONObject getUpdateDepartmentPayload(String name,String is_public,String description,String[] operator_ids,String from_email,String is_transcript_mail_enabled,String transcript_recipients,String is_blockip_mail_enabled,String blockip_recipients,String is_feedback_mail_enabled,String feedback_recipients,String is_missedchat_mail_enabled,String missedchat_recipients,String is_cc_mail_enabled,String cc_recipients) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.DEPARTMENT_NAME,name);
        payload=addIfNotNull(payload,APIKeys.DEPT_IS_PUBLIC,is_public);
        payload=addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        

        if(operator_ids!=null)
        {
            JSONArray operators=new JSONArray();

            for(String operator_id : operator_ids)
            {
                operators.put(operator_id);
            }

            payload.put(APIKeys.OPERATORS,operators);
        }

        JSONObject email_configurations=new JSONObject();
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_FROM_MAIL),from_email);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_IS_TRANSCRIPT),is_transcript_mail_enabled);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_TRANSCRIPT_MAIL),transcript_recipients);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_IS_BLOCKED),is_blockip_mail_enabled);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_BLOCKED_MAIL),blockip_recipients);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_IS_FEEDBACK),is_feedback_mail_enabled);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_FEEDBACK_MAIL),feedback_recipients);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_IS_MISSED),is_missedchat_mail_enabled);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_MISSED_MAIL),missedchat_recipients);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_IS_CC),is_cc_mail_enabled);
        email_configurations=addIfNotNull(email_configurations,APIKeys.getKeyFromJPath(JPaths.DEPT_CC_MAIL),cc_recipients);

        if(email_configurations.length()>0)
        {
            payload.put(APIKeys.EMAIL_CONFIGURATIONS,email_configurations);
        }

        return payload;
    }

    public static JSONObject getChangePortalOwnerPayload(String new_owner_id) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.NEW_OWNER_ID,new_owner_id);
        return payload;
    }

    public static JSONObject getAddOperatorToDepartmentPayload(String[] operator_ids) throws JSONException
    {
        JSONObject payload=new JSONObject();

        if(operator_ids!=null)
        {
            JSONArray operators=new JSONArray();

            for(String operator_id : operator_ids)
            {
                operators.put(operator_id);
            }

            payload.put("ids",operators);
        }

        return payload;
    }

    public static boolean isEmpty(JSONObject json_object)
    {
        try
        {
            return json_object.toString().equals("{}");
        }
        catch(Exception e)
        {

        }

        return false;
    }

    public static boolean isEmpty(JSONArray json_array)
    {
        try
        {
            return json_array.length()==0;
        }
        catch(Exception e)
        {

        }

        return false;
    }

    public static JSONObject addIfNotNull(JSONObject json,String key,String value) throws JSONException
    {
        if(key!=null && value!=null && !value.equals("null"))
        {
            json.put(key,value);
        }

        return json;
    }

    public static JSONObject addIfNotNull(JSONObject parent_json,String key,JSONObject child_json) throws JSONException
    {
        if(key!=null && child_json!=null && !isEmpty(child_json))
        {
            parent_json.put(key,child_json);
        }

        return parent_json;
    }

    public static JSONObject addIfNotNull(JSONObject parent_json,String key,JSONArray child_json_array) throws JSONException
    {
        if(key!=null && child_json_array!=null && !isEmpty(child_json_array))
        {
            parent_json.put(key,child_json_array);
        }

        return parent_json;
    }

    public static JSONObject getCreateOperatorPayload(String email_id,String role,String[] department_ids,String is_monitored,String is_chat_enabled,String nick_name,String first_name,String last_name,String description,String mobile,String phone,String time_zone,String language) throws Exception
    {
        JSONObject payload = new JSONObject();
        payload = addIfNotNull(payload,APIKeys.EMAIL,email_id);
        payload = addIfNotNull(payload,APIKeys.ROLE,role);

        if(department_ids!=null)
        {
            JSONArray departments=new JSONArray();

            for(String department_id : department_ids)
            {
                departments.put(department_id);
            }

            payload.put(APIKeys.DEPARTMENTS,departments);
        }

        payload = addIfNotNull(payload,APIKeys.IS_MONITORED,is_monitored);
        payload = addIfNotNull(payload,APIKeys.IS_CHAT_ENABLED,is_chat_enabled);
        payload = addIfNotNull(payload,APIKeys.NICK_NAME,nick_name);
        payload = addIfNotNull(payload,APIKeys.FIRST_NAME,first_name);
        payload = addIfNotNull(payload,APIKeys.LAST_NAME,last_name);
        payload = addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        payload = addIfNotNull(payload,APIKeys.MOBILE,mobile);
        payload = addIfNotNull(payload,APIKeys.PHONE,phone);
        payload = addIfNotNull(payload,APIKeys.TIME_ZONE,time_zone);
        payload = addIfNotNull(payload,APIKeys.LANGUAGE,language);

        return payload;
    }

    public static JSONObject getUpdateOperatorPayload(boolean isAdmin,String nick_name,String first_name,String last_name,String description,String mobile,String phone,String time_zone,String language,String maximum_concurrent_chat,String date_of_birth,String is_chat_enabled,String street,String city,String state,String country,String pin_code) throws Exception
    {
        JSONObject payload = new JSONObject();
        payload = addIfNotNull(payload,APIKeys.NICK_NAME,nick_name);
        payload = addIfNotNull(payload,APIKeys.FIRST_NAME,first_name);
        payload = addIfNotNull(payload,APIKeys.LAST_NAME,last_name);
        payload = addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        payload = addIfNotNull(payload,APIKeys.MOBILE,mobile);
        payload = addIfNotNull(payload,APIKeys.PHONE,phone);
        if(isAdmin)
        {
            payload = addIfNotNull(payload,APIKeys.MAXIMUM_CONCURRENT_CHAT,maximum_concurrent_chat);
        }
        payload = addIfNotNull(payload,APIKeys.TIME_ZONE,time_zone);
        payload = addIfNotNull(payload,APIKeys.LANGUAGE,language);
        payload = addIfNotNull(payload,APIKeys.DATE_OF_BIRTH,date_of_birth);
        payload = addIfNotNull(payload,APIKeys.IS_CHAT_ENABLED,is_chat_enabled);
        payload = addIfNotNull(payload,APIKeys.STREET,street);
        payload = addIfNotNull(payload,APIKeys.CITY,city);
        payload = addIfNotNull(payload,APIKeys.STATE,state);
        payload = addIfNotNull(payload,APIKeys.COUNTRY,country);
        payload = addIfNotNull(payload,APIKeys.PIN_CODE,pin_code);

        return payload;
    }

    public static JSONObject getSetStatusPayload(String status) throws Exception
    {
        JSONObject payload = new JSONObject();
        payload = addIfNotNull(payload,APIKeys.STATUS,status);
        return payload;
    }

    public static JSONObject getAssociateDepartmentsWithOperatorPayload(String[] department_ids) throws Exception
    {
        JSONObject payload = new JSONObject();
        if(department_ids!=null)
        {
            JSONArray departments=new JSONArray();

            for(String department_id : department_ids)
            {
                departments.put(department_id);
            }

            payload.put(APIKeys.DEPARTMENT_IDS,departments);
        }
        return payload;
    }

    public static JSONArray getUserSetForRouting(String[] operator_ids,String[] department_ids,String[] dynamic_users) throws JSONException
    {
        if(operator_ids==null && department_ids==null && dynamic_users==null)
        {
            return null;
        }

        JSONObject userset_json=new JSONObject();
        JSONArray userset_array=new JSONArray();

        if(operator_ids!=null)
        {
            JSONArray operator_ids_array=new JSONArray();

            for(String operator_id : operator_ids)
            {
                operator_ids_array.put(operator_id);
            }

            userset_json.put(APIKeys.OPERATOR_IDS,operator_ids_array);
        }

        if(department_ids!=null)
        {
            JSONArray department_ids_array=new JSONArray();

            for(String department_id : department_ids)
            {
                department_ids_array.put(department_id);
            }

            userset_json.put(APIKeys.DEPARTMENT_IDS_2,department_ids_array);
        }

        if(dynamic_users!=null)
        {
            JSONArray dynamic_users_array=new JSONArray();

            for(String dynamic_user : dynamic_users)
            {
                dynamic_users_array.put(dynamic_user);
            }

            userset_json.put(APIKeys.DYNAMIC_USERS,dynamic_users_array);
        }

        userset_array.put(userset_json);

        return userset_array;
    }

    public static JSONArray getANDCriteriaForRouting(String[]... or_criterias) throws JSONException
    {
        return getANDCriteria(or_criterias);
    }

    public static JSONArray getANDCriteria(String[]... or_criterias) throws JSONException
    {
        if(or_criterias==null || or_criterias[0]==null)
        {
            return null;
        }

        JSONArray or_criteria_array=new JSONArray();
        JSONObject or_criteria_json=new JSONObject();
        JSONArray and_criteria_json=new JSONArray();

        for(String[] or_criteria : or_criterias)
        {
            String field_name=or_criteria[0];
            String comparator=or_criteria[1];
            String values=or_criteria[2];

            JSONObject criteria=new JSONObject();

            JSONArray values_list=new JSONArray();

            values_list.put(values);

            criteria.put(APIKeys.FIELD_NAME,field_name);
            criteria.put(APIKeys.COMPARATOR,comparator);
            criteria.put(APIKeys.VALUES,values_list);

            or_criteria_array.put(criteria);
        }

        or_criteria_json.put(APIKeys.OR_CRITERIA,or_criteria_array);
        and_criteria_json.put(or_criteria_json);

        return and_criteria_json;
    }

    public static JSONObject getCreateRoutingRulePayload(String app_id,String title,String routing_type,String status,String[] operator_ids,String[] department_ids,String[] dynamic_users,String[]... or_criterias) throws JSONException
    {
        JSONObject payload=new JSONObject();

        payload=addIfNotNull(payload,APIKeys.APP_ID,app_id);
        payload=addIfNotNull(payload,APIKeys.TITLE,title);
        payload=addIfNotNull(payload,APIKeys.ROUTING_TYPE,routing_type);
        payload=addIfNotNull(payload,APIKeys.ENABLED,status);
        
        JSONArray userset=getUserSetForRouting(operator_ids,department_ids,dynamic_users);
        payload=addIfNotNull(payload,APIKeys.USERSET,userset);

        JSONArray and_criteria=getANDCriteriaForRouting(or_criterias);
        payload=addIfNotNull(payload,APIKeys.AND_CRITERIA,and_criteria);

        return payload;
    }

    public static JSONObject getCreateLeadscoringRulePayload(String status,String points,String[]... or_criterias) throws JSONException
    {
        JSONObject payload=new JSONObject();

        payload=addIfNotNull(payload,APIKeys.ENABLED,status);
        payload=addIfNotNull(payload,APIKeys.POINTS,points);
        
        JSONArray and_criteria=getANDCriteriaForRouting(or_criterias);
        payload=addIfNotNull(payload,APIKeys.AND_CRITERIA,and_criteria);

        return payload;
    }

    public static JSONObject getLeadscoringConfigPayload(String frequency) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.FREQUENCY,frequency);
        return payload;
    }

    public static JSONObject getRouteToAllConfigPayload(String route_to_all) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.ROUTE_TO_ALL,route_to_all);
        return payload;
    }

    public static JSONObject getUpdatePosistionPayload(String position) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.POSITION,position);
        return payload;
    }

    public static JSONObject getChatMonitorCreatePayload(String type,String operator,String visitor_ip,String visitor_email) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.TYPE,type);
        payload=addIfNotNull(payload,APIKeys.OPERATOR,operator);
        payload=addIfNotNull(payload,APIKeys.VISITOR_IP,visitor_ip);
        payload=addIfNotNull(payload,APIKeys.VISITOR_EMAIL,visitor_email);
        return payload;
    }

    public static JSONObject getMonitorByOperatorPayload(String operator) throws JSONException
    {
        return getChatMonitorCreatePayload(APIKeys.OPERATOR,operator,null,null);
    }

    public static JSONObject getMonitorByIPPayload(String visitor_ip) throws JSONException
    {
        return getChatMonitorCreatePayload(APIKeys.VISITOR_IP,null,visitor_ip,null);
    }

    public static JSONObject getMonitorByEmailPayload(String visitor_email) throws JSONException
    {
        return getChatMonitorCreatePayload(APIKeys.VISITOR_EMAIL,null,null,visitor_email);
    }

    public static JSONObject getUpdateMonitorPayload(Boolean status) throws JSONException
    {
        JSONObject payload=new JSONObject();

        payload=addIfNotNull(payload,APIKeys.ENABLED,""+status);
        
        return payload;
    }

    public static JSONObject getBlockedIPCreatePayload(String ip,String comment,String... app_ids) throws JSONException
    {
        JSONObject payload=new JSONObject();

        if(app_ids!=null)
        {
            JSONArray app_ids_json=new JSONArray();

            for(String app_id : app_ids)
            {
                app_ids_json.put(app_id);
            }

            payload.put(APIKeys.APP_IDS,app_ids_json);
        }


        payload=addIfNotNull(payload,APIKeys.IP,ip);
        payload=addIfNotNull(payload,APIKeys.COMMENT,comment);

        return payload;
    }

    public static JSONObject getBlockedIPCreateCommentPayload(String text) throws JSONException
    {
        JSONObject payload=new JSONObject();

        payload=addIfNotNull(payload,APIKeys.TEXT,text);

        return payload;
    }

    public static JSONObject getBlockedIPUpdatePayload(String status) throws JSONException
    {
        JSONObject payload=new JSONObject();
        payload=addIfNotNull(payload,APIKeys.STATUS,status);
        return payload;
    }

    public static JSONObject getCreateTriggerPayload(String app_id,String title,String event_type,String action_type,String params_sender_name,String params_value,String delay,String[]... or_criterias) throws JSONException
    {
        JSONObject payload=new JSONObject();

        payload=addIfNotNull(payload,APIKeys.APP_ID,app_id);
        payload=addIfNotNull(payload,APIKeys.TITLE,title);
        
        JSONObject event=new JSONObject();
        event.put(APIKeys.TYPE,event_type);
        payload.put(APIKeys.EVENT,event);

        JSONObject action=new JSONObject();
        JSONObject params=new JSONObject();

        params.put(APIKeys.SENDER_NAME,params_sender_name);
        params.put(APIKeys.VALUE,params_value);
        action.put(APIKeys.PARAMS,params);

        action.put(APIKeys.TYPE,action_type);
        action.put(APIKeys.DELAY,delay);

        payload.put(APIKeys.ACTION,action);

        JSONArray and_criteria=getANDCriteria(or_criterias);
        payload=addIfNotNull(payload,APIKeys.AND_CRITERIA,and_criteria);

        return payload;
    }

    public static JSONObject getUpdateTriggerPayload(String app_id,String title,String event_type,String action_type,String params_sender_name,String params_value,String delay,String[]... or_criterias) throws JSONException
    {
        return getCreateTriggerPayload(app_id,title,event_type,action_type,params_sender_name,params_value,delay,or_criterias);
    }

    public static JSONObject setTriggerStatusPayload(String status) throws JSONException
    {
        JSONObject payload = new JSONObject();
        payload = addIfNotNull(payload,APIKeys.ENABLED,status);
        return payload;
    }

    public static JSONObject getWebhookBotPayload(String name,String description,String app_id,String[] department_ids,Boolean is_handoff,String working_hours,String typing_delay,String connector,String webhook_url,Boolean is_secured,String vendor_name,String vendor_email,String vendor_console_url,String vendor_website,String vendor_version,String vendor_logo) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.NAME,name);
        payload = addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        payload = addIfNotNull(payload,APIKeys.APP_ID,app_id);
        // payload = addIfNotNull(payload,APIKeys.ACCESS_KEY,access_key);

        if(department_ids!=null)
        {
            JSONArray department_ids_json=new JSONArray();

            for(String department_id : department_ids)
            {
                department_ids_json.put(department_id);
            }

            payload=addIfNotNull(payload,APIKeys.DEPARTMENT_IDS_2,department_ids_json);
        }


        payload = addIfNotNull(payload,APIKeys.HANDOFF_ENABLED,is_handoff+"");
        payload = addIfNotNull(payload,APIKeys.WORKING_HOURS,working_hours);
        payload = addIfNotNull(payload,APIKeys.TYPING_DELAY,typing_delay);
        payload = addIfNotNull(payload,APIKeys.CONNECTOR,connector);


        JSONObject webhook=new JSONObject();
        webhook = addIfNotNull(webhook,APIKeys.SECURED,is_secured+"");
        webhook = addIfNotNull(webhook,APIKeys.URL,webhook_url);
        payload=addIfNotNull(payload,APIKeys.WEBHOOK,webhook);


        JSONObject vendor=new JSONObject();
        vendor = addIfNotNull(vendor,APIKeys.NAME,vendor_name);
        vendor = addIfNotNull(vendor,APIKeys.EMAIL,vendor_email);
        vendor = addIfNotNull(vendor,APIKeys.CONSOLE_URL,vendor_console_url);
        vendor = addIfNotNull(vendor,APIKeys.WEBSITE,vendor_website);
        vendor = addIfNotNull(vendor,APIKeys.VERSION,vendor_version);
        vendor = addIfNotNull(vendor,APIKeys.LOGO,vendor_logo);
        payload=addIfNotNull(payload,APIKeys.VENDOR,vendor);

        return payload;        
    }

    public static JSONObject getWebhookBotHandlerPayload(String webhook_url,Boolean is_secured,Boolean is_published) throws JSONException
    {
        JSONObject payload = new JSONObject();

        // payload = addIfNotNull(payload,APIKeys.ACCESS_KEY,access_key);
        payload = addIfNotNull(payload,APIKeys.IS_PUBLISHED,is_published+"");

        JSONObject webhook=new JSONObject();
        webhook = addIfNotNull(webhook,APIKeys.SECURED,is_secured+"");
        webhook = addIfNotNull(webhook,APIKeys.URL,webhook_url);
        payload=addIfNotNull(payload,APIKeys.WEBHOOK,webhook);

        return payload;        
    }

    public static JSONObject getVisitorHistoryViewPayload(String viewName,String sort_by,String favourited,String[]... or_criterias) throws JSONException
    {
        JSONObject payload = new JSONObject();

        JSONArray and_criteria=getANDCriteria(or_criterias);
        payload=addIfNotNull(payload,APIKeys.AND_CRITERIA,and_criteria);

        payload = addIfNotNull(payload,APIKeys.NAME,viewName);
        payload = addIfNotNull(payload,APIKeys.SORT_BY,sort_by);
        payload = addIfNotNull(payload,APIKeys.FAVOURITED,favourited);

        return payload;
    }

    public static JSONObject getUserPreferencesPayload(String list_name,String view_id) throws JSONException
    {
        JSONObject payload = new JSONObject();
        
        payload = addIfNotNull(payload,APIKeys.LIST_NAME,list_name);
        payload = addIfNotNull(payload,APIKeys.VIEW_ID,view_id);

        return payload;
    }

    public static JSONObject getUpdateCRMPayload(String lead_auto_approval,String attach_transcript,String assigned_owner,String minimum_leadscore,String followup_task_on,String departments_selected,String visitors_to_be_pushed,String add_new_visitor_as,String visitor_status_in_livedesk,String visitor_tracking,String visitor_tracking_visits) throws Exception
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.LEAD_AUTO_APPROVAL,lead_auto_approval);
        payload = addIfNotNull(payload,APIKeys.ATTACH_TRANSCRIPT,attach_transcript);
        payload = addIfNotNull(payload,APIKeys.ASSIGNED_OWNER,assigned_owner);
        payload = addIfNotNull(payload,APIKeys.MINIMUM_LEADSCORE,minimum_leadscore);
        payload = addIfNotNull(payload,APIKeys.FOLLOWUP_TASK_ON,followup_task_on);
        payload = addIfNotNull(payload,APIKeys.DEPARTMENTS_SELECTED,departments_selected);
        payload = addIfNotNull(payload,APIKeys.ADD_NEW_VISITOR_AS,add_new_visitor_as);
        payload = addIfNotNull(payload,APIKeys.VISITOR_STATUS_IN_LIVEDESK,visitor_status_in_livedesk);

        if(visitors_to_be_pushed != null)
        {
            JSONArray visitors_to_be_pushed_json = new JSONArray();
            visitors_to_be_pushed_json.put(visitors_to_be_pushed);
            payload = addIfNotNull(payload,APIKeys.VISITORS_TO_BE_PUSHED,visitors_to_be_pushed_json);
        }

        if(visitor_tracking != null)
        {
            JSONArray visitor_tracking_json = new JSONArray();
            visitor_tracking_json.put(visitor_tracking);
            visitor_tracking_json.put(visitor_tracking_visits);
            payload = addIfNotNull(payload,APIKeys.VISITOR_TRACKING,visitor_tracking_json);
        }

        return payload;
    }

    public static JSONObject getEnablePayload(String enabled) throws JSONException
    {
        JSONObject payload = new JSONObject();
        payload = addIfNotNull(payload,APIKeys.ENABLED,enabled);
        return payload;
    }

    public static JSONObject getZSCKeyPayload(String key,String email,String portal_name) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.KEY,key);
        payload = addIfNotNull(payload,APIKeys.EMAIL_KEY,email);
        payload = addIfNotNull(payload,APIKeys.PORTALNAME,portal_name);

        return payload;
    }

    public static JSONObject getUpdateDeskPayload(String convert_as_request,String push_visitor_feedback,String attended_request_status,String departments_selected) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.CONVERT_AS_REQUEST,convert_as_request);
        payload = addIfNotNull(payload,APIKeys.PUSH_VISITOR_FEEDBACK,push_visitor_feedback);
        payload = addIfNotNull(payload,APIKeys.ATTENDED_REQUEST_STATUS,attended_request_status);
        payload = addIfNotNull(payload,APIKeys.DEPARTMENTS_SELECTED,departments_selected);

        return payload;
    }

    public static JSONObject getDepartmentIntegrationPayload(String status,String integration_department_id) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.STATUS,status);
        payload = addIfNotNull(payload,APIKeys.INTEGRATION_DEPARTMENT_ID,integration_department_id);

        return payload;
    }

    public static JSONObject getUpdateCampaignPayload(String departments_selected,String field_id,String integration_field_id,String field_status,String previous_field_id) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.DEPARTMENTS_SELECTED,departments_selected);
        payload = addIfNotNull(payload,APIKeys.FIELD_ID,field_id);
        payload = addIfNotNull(payload,APIKeys.INTEGRATION_FIELD_ID,integration_field_id);
        payload = addIfNotNull(payload,APIKeys.FIELD_STATUS,field_status);
        payload = addIfNotNull(payload,APIKeys.PREVIOUS_FIELD_ID,previous_field_id);

        return payload;
    }

    public static JSONObject getUpdateClearBitPayload(String field_id,String integration_field_id,String field_status,String previous_field_id,String add_company_particulars_as,String refresh_frequency,String update_to_crm) throws JSONException
    {
        JSONObject payload = getUpdateCampaignPayload(null,field_id,integration_field_id,field_status,previous_field_id);

        payload = addIfNotNull(payload,APIKeys.ADD_COMPANY_PARTICULARS_AS,add_company_particulars_as);
        payload = addIfNotNull(payload,APIKeys.REFRESH_FREQUENCY,refresh_frequency);
        payload = addIfNotNull(payload,APIKeys.UPDATE_TO_CRM,update_to_crm);

        return payload;
    }

    public static JSONObject getCreateTrackingPresetsPayload(String name,String description,String applied,String enabled,String[]... or_criterias) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.NAME,name);
        payload = addIfNotNull(payload,APIKeys.ENABLED,enabled);
        payload = addIfNotNull(payload,APIKeys.DESCRIPTION,description);
        payload = addIfNotNull(payload,APIKeys.APPLIED,applied);

        JSONArray and_criteria=getANDCriteria(or_criterias[0]);
        payload=addIfNotNull(payload,APIKeys.RING1_CRITERIA,and_criteria);

        and_criteria=getANDCriteria(or_criterias[1]);
        payload=addIfNotNull(payload,APIKeys.RING2_CRITERIA,and_criteria);

        and_criteria=getANDCriteria(or_criterias[2]);
        payload=addIfNotNull(payload,APIKeys.RING3_CRITERIA,and_criteria);

        and_criteria=getANDCriteria(or_criterias[3]);
        payload=addIfNotNull(payload,APIKeys.RING4_CRITERIA,and_criteria);

        return payload;
    }

    public static JSONObject getUpdateTrackingUserPreferencesPayload(String view,String hide_other_agent_connected_visitors) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.VIEW,view);
        payload = addIfNotNull(payload,APIKeys.HIDE_OTHER_AGENT_CONNECTED_VISITORS,hide_other_agent_connected_visitors);

        return payload;
    }

    public static JSONObject getAppsCreatePayload(String name,String business_hours,String privacy) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.NAME,name);
        payload = addIfNotNull(payload,APIKeys.BUSINESS_HOURS,business_hours);
        payload = addIfNotNull(payload,APIKeys.PRIVACY,privacy);

        return payload;
    }

    public static JSONObject getAppsUpdatePayload(String name,String business_hours,String privacy) throws JSONException
    {
        JSONObject payload = new JSONObject();
        
        payload = addIfNotNull(payload,APIKeys.NAME,name);
        payload = addIfNotNull(payload,APIKeys.BUSINESS_HOURS,business_hours);
        payload = addIfNotNull(payload,APIKeys.PRIVACY,privacy);

        return payload;
    }

    public static JSONObject getChatWindowConfigUpdatePayload(String theme,String color) throws JSONException
    {
        JSONObject payload = new JSONObject();
        
        payload = addIfNotNull(payload,APIKeys.THEME,theme);
        payload = addIfNotNull(payload,APIKeys.COLOR,color);
        
        return payload;
    }

    public static JSONObject geFAQConfigUpdatePayload(String title,String like_response,String dislike_response) throws JSONException
    {
        JSONObject payload = new JSONObject();
        
        payload = addIfNotNull(payload,APIKeys.TITLE,title);
        payload = addIfNotNull(payload,APIKeys.LIKE_RESPONSE,like_response);
        payload = addIfNotNull(payload,APIKeys.DISLIKE_RESPONSE,dislike_response);
        
        return payload;
    }

    public static JSONObject getWidgetConfigUpdatePayload(String widget_type) throws JSONException
    {
        JSONObject payload = new JSONObject();
        
        payload = addIfNotNull(payload,APIKeys.WIDGET_TYPE,widget_type);
        
        return payload;
    }

    public static JSONObject getPreChatFormUpdatePayload(String form_type,String title_name,String title_message,Hashtable<String,String> field) throws JSONException
    {
        JSONObject payload = new JSONObject();
        JSONObject innerJson = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.FORM_TYPE,form_type);
        innerJson = addIfNotNull(innerJson,APIKeys.NAME,title_name);
        innerJson = addIfNotNull(innerJson,APIKeys.MESSAGE,title_message);
        payload = addIfNotNull(payload,APIKeys.TITLE,innerJson);

        JSONObject fieldJson = new JSONObject();
        fieldJson = addIfNotNull(fieldJson,APIKeys.NAME,field.get("name"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.VISIBILITY,field.get("visibility"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.MAXLENGTH,field.get("maxlength"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.QUESTION,field.get("question"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.MANDATORY,field.get("mandatory"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.ENABLED,field.get("enabled"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.TYPE,field.get("type"));
        fieldJson = addIfNotNull(fieldJson,APIKeys.PLACEHOLDER,field.get("placeholder"));

        JSONArray fieldJsonArray = new JSONArray();

        fieldJsonArray.put(fieldJson);

        payload = addIfNotNull(payload,APIKeys.FIELDS,fieldJsonArray);

        return payload;
    }

    public static JSONObject getPostChatFormUpdatePayload(String feedback_enabled,String rating_enabled) throws JSONException
    {
        JSONObject payload = new JSONObject();
        
        payload = addIfNotNull(payload,APIKeys.FEEDBACK_ENABLED,feedback_enabled);
        payload = addIfNotNull(payload,APIKeys.RATING_ENABLED,rating_enabled);
        
        return payload;
    }

    public static JSONObject getCreateChannelPayload(String bundleName) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.BUNDLE_NAME,bundleName);

        return payload;
    }

    public static JSONObject getIOSUpdatePayload(String enabled,String password) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.ENABLED,enabled);

        if(enabled == "true")
        {
            JSONObject notificationPayload = new JSONObject();
            notificationPayload = addIfNotNull(notificationPayload,APIKeys.ENABLED,enabled);
            notificationPayload = addIfNotNull(notificationPayload,APIKeys.PASSWORD,password);

            payload = addIfNotNull(payload,APIKeys.SANDBOX_NOTIFICATIONS,notificationPayload);
            payload = addIfNotNull(payload,APIKeys.PRODUCTION_NOTIFICATIONS,notificationPayload);
        }

        return payload;
    }

    public static JSONObject getComponentsPayload(String[] components) throws JSONException
    {
        JSONObject payload = new JSONObject();

        JSONArray componentsArray = new JSONArray();

        for(String component : components)
        {
            componentsArray.put(component);
        }

        payload = addIfNotNull(payload,APIKeys.COMPONENTS,componentsArray);

        return payload;
    }

    public static JSONObject getAndroidUpdatePayload(String enabled,String password) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.ENABLED,enabled);

        if(enabled == "true")
        {
            JSONObject notificationPayload = new JSONObject();
            notificationPayload = addIfNotNull(notificationPayload,APIKeys.ENABLED,enabled);
            notificationPayload = addIfNotNull(notificationPayload,APIKeys.PASSWORD,password);
            
            payload = addIfNotNull(payload,APIKeys.NOTIFICATIONS,notificationPayload);
        }


        return payload;
    }

    public static JSONObject getAppsUIUpdatePayload(String... values) throws JSONException
    {
        JSONObject payload = new JSONObject();

        String apiKeys[] = {APIKeys.NAME,APIKeys.BUSINESS_HOURS,APIKeys.PRIVACY};

        for(int i = 0; i < values.length; i++)
        {
            payload = addIfNotNull(payload,apiKeys[i],values[i]);
        }

        return payload;
    }

    public static JSONObject getCreateWebsite(String website_name) throws JSONException
    {
        JSONObject payload = new JSONObject();

        payload = addIfNotNull(payload,APIKeys.WEBSITE_NAME,website_name);

        return payload;
    }

    public static JSONObject getWebsiteConfigUpdatePayload(String website_name,String allow_in_multiple_websites,String enabled,String url) throws JSONException
    {
        JSONObject payload = new JSONObject();        
        payload = addIfNotNull(payload,APIKeys.WEBSITE_NAME,website_name);
        payload = addIfNotNull(payload,APIKeys.ALLOW_IN_MULTIPLE_WEBSITES,allow_in_multiple_websites);
        payload = addIfNotNull(payload,APIKeys.ENABLED,enabled);
        
        JSONObject websitesJSON = new JSONObject();
        websitesJSON = addIfNotNull(websitesJSON,APIKeys.URL,url);
        websitesJSON = addIfNotNull(websitesJSON,APIKeys.STATUS,"1");
        JSONArray websitesJSONArray = new JSONArray();
        websitesJSONArray.put(websitesJSON);

        payload = addIfNotNull(payload,APIKeys.ACCESS_MULTIPLE_WEBSITES,websitesJSONArray);
        return payload;
    }
    
    public static JSONObject getEmailSignatureConfigUpdatePayload(String enabled,String sticker,String show_company_logo,String show_company_info,String show_contact_info, String background) throws JSONException
    {
        JSONObject payload = new JSONObject();        
        payload = addIfNotNull(payload,APIKeys.ENABLED,enabled);
        payload = addIfNotNull(payload,APIKeys.STICKER,sticker);
        payload = addIfNotNull(payload,APIKeys.SHOW_COMPANY_LOGO,show_company_logo);
        payload = addIfNotNull(payload,APIKeys.SHOW_COMPANY_INFO,show_company_info);
        payload = addIfNotNull(payload,APIKeys.SHOW_CONTACT_INFO,show_contact_info);
        payload = addIfNotNull(payload,APIKeys.BACKGROUND,background);

        return payload;
    }

        
    public static JSONObject getCannedResponsesCreatePayload(String content,String associate_with_all_departments,String departmentId,String published) throws JSONException {
        
         JSONObject payload=new JSONObject();
        
         payload=addIfNotNull(payload, APIKeys.CONTENT, content);
         payload=addIfNotNull(payload, APIKeys.ASSOCIATE_WITH_ALL_DEPARTMENTS,associate_with_all_departments);
         payload=addIfNotNull(payload, APIKeys.DEPARTMENT_ID, departmentId);
         payload=addIfNotNull(payload, APIKeys.PUBLISHED, published);
                 
           return payload;
    }
}
