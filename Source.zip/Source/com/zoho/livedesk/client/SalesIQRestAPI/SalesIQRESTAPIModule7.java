//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class SalesIQRESTAPIModule7
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static VisitorDriverManager visitor_driver_manager;

	public static final String[] 
	SORT_BY_VALUES = {"frequency","leadscore","time_on_site","last_visit_time"},
	FAVOURITED_VALUES = {"true","false"},
	EDITED_OR_CRITERIA1 = {"browser","is_equal_to","apple_safari"}
	;

	public static final int
	GET_VIEW = 0,
	GET_VIEWS = 1
	;

	public static final By
	VISIT_MCONTENT = By.id("visit_mcontent"),
	VH_COLUMNS = By.className("vlstbx"),
	ACTIONDRPDOWN = By.className("actiondrpdown"),
	COMBOSUBDRPDWNMN = By.className("combosubdrpdwnmn"),
	ULLIST = By.className("ullist"),
	LDSETTINGS = By.id("ldsettings"),
	CMPNY_FLTR_DIV = By.id("cmpny_fltr_div"),
	TEXT = By.className("txtelips"),
	PRIOR1_COL1_DIV = By.id("prior1_col1_div"),
	PRIOR1_COL2_DIV = By.id("prior1_col2_div"),
	PRIOR1_COL3_DIV = By.id("prior1_col3"),
	SETFAV = By.id("setfav"),
	FAV_VAL = By.id("fav_val"),
	FAVDRPDOWN0 = By.id("favdrpdown0")
	;

	public static final String
	MODULE_NAME = "Rest API",
	ID = "<id>",
	VIEWID = "viewid",
	SORT_BY = "sort_by",
	FAVOURITED = "favourited",
	VIEW_NAME = "view_name",
	FIELD_NAME = "field_name",
	CONDITION = "condition",
	FIELD_VALUE = "field_value",
	SIZE = "size",
	EDITED_VIEW_NAME = "Edited Test View Name",
	EDITED_FAVOURITED = "false",
	EDITED_SORT_BY = "leadscore",
	ALL_VISITORS = "All Visitors",
	ALL_VISITORS_ID = "-1",
	RETURNING_VISITORS = "Returning Visitors",
	REPEATED_VISITORS = "Repeated Visitors",
	RETURNING_VISITORS_ID = "-2",
	LIST_ONE = "list_one"
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			Cleanup.deleteAllVisitorHistoryLists(driver);

			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"vh_view_admin");

			etest = ComplexReportFactory.getTest("Create Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			createVHViewAPI(driver,api_webdriver,true,560,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Checking Create Visitor History View API when only the mandatory fields are given");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			createVHViewAPI(driver,api_webdriver,true,589,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Checking Create Visitor History View API when the mandatory fields are not given");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			createVHViewAPI(driver,api_webdriver,false,592,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Checking Create Visitor History View API when the same view name is given");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			createVHViewAPI(driver,api_webdriver,true,593,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Get List of Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			getVHViewListAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Get Details of Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			getVHViewAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Update the details of Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			updateVHViewAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Delete a Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			deleteVHViewAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Get List of Selected Visitor History Views");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			getSelectedVHViewsAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Update Visitor History View details of particular column");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			updateVHVIewDetailsOfSpecificColumnAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Get CriteriaFields of Visitor History View");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkVHFieldMapsAPI(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getTest("Check invalid scope -- Create Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_CREATE,581,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Get List of Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_GET_LIST,582,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Get Details of Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_GET,583,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Update the details of Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_UPDATE,584,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Delete a Visitor History View API");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_DELETE,585,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Get List of Selected Visitor History Views");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_SELECTED,586,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Update Visitor History View details of particular column");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_UPDATE_SELECTED,587,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check invalid scope -- Get CriteriaFields of Visitor History View");
			ComplexReportFactory.setValues(etest,MODULE_NAME);
			checkInvalidScope(driver,api_webdriver,Api.VH_VIEW_CRITERIAFIELDS,588,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);

			visitor_driver_manager.terminateAllDriverSessions();
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void createVHViewAPI(WebDriver driver,WebDriver api_webdriver,boolean isMandatory,int startKey,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			String
			viewName = (isMandatory)?("testViewNewCreate"+startKey):null,
			sort_by = ((startKey == 560) || (startKey == 593))?SORT_BY_VALUES[key%4]:null,
			favourited = ((startKey == 560) || (startKey == 593))?FAVOURITED_VALUES[key%2]:null,
			responseCode = (isMandatory)?Constants.SUCCESS_CODE:Constants.INVALID_INPUTSTREAM
			;

			if(startKey == 560)
			{
				favourited = "true";
			}

			String sample_criteria = RestAPIConfManager.getRealValue("sample_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] or_criteria1 = (isMandatory)?(criteria[key%25].split(",")):null;

			if(startKey == 593)
			{
				viewName = "testViewNewCreate560";
				isMandatory = false;
				responseCode = Constants.VIEW_NAME_ALREADY_PRESENT;
			}

			JSONObject payload = GetPayload.getVisitorHistoryViewPayload(viewName,sort_by,favourited,or_criteria1);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_CREATE,isMandatory,isMandatory,responseCode,false,true,payload,GET_VIEW,startKey,key,etest);


			if(startKey == 589)
			{
				or_criteria1 = null;
				payload = GetPayload.getVisitorHistoryViewPayload(null,null,"true",or_criteria1);
				etest.log(Status.INFO,"Below json will be used as payload");
				SalesIQRestAPICommonFunctions.log(etest,payload);

				String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
				String id = getCurrentViewId(driver);
				SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,ID,id,Api.VH_VIEW_UPDATE,true,payload,etest);
				SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void getVHViewListAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_GET_LIST,true,true,Constants.SUCCESS_CODE,false,false,null,GET_VIEWS,563,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void getVHViewAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_GET,false,true,Constants.SUCCESS_CODE,true,false,null,GET_VIEW,566,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void updateVHViewAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			JSONObject payload = GetPayload.getVisitorHistoryViewPayload(EDITED_VIEW_NAME,EDITED_SORT_BY,EDITED_FAVOURITED,EDITED_OR_CRITERIA1);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_UPDATE,true,true,Constants.SUCCESS_CODE,true,true,payload,GET_VIEW,568,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void deleteVHViewAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_DELETE,true,false,Constants.SUCCESS_CODE,true,false,null,GET_VIEW,571,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void getSelectedVHViewsAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_SELECTED,true,true,Constants.SUCCESS_CODE,false,false,null,GET_VIEW,574,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void updateVHVIewDetailsOfSpecificColumnAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			int key = getRandomId();
			JSONObject payload = GetPayload.getUserPreferencesPayload(LIST_ONE,ALL_VISITORS_ID);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkVHViewAPI(driver,api_webdriver,Api.VH_VIEW_UPDATE_SELECTED,true,false,Constants.SUCCESS_CODE,false,true,payload,GET_VIEW,577,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkVHFieldMapsAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest) throws Exception
	{
		try
		{
			result.put("RESTAPI580",SalesIQRESTAPIModule3.fieldMapsAPI(api_webdriver,driver,etest,Api.VH_VIEW_CRITERIAFIELDS));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkInvalidScope(WebDriver driver,WebDriver api_webdriver,Api api_obj,int startKey,ExtentTest etest) throws Exception
	{
		try
		{
			int key = getRandomId();

			String
			label = CommonUtil.getUniqueMessage(),
			viewName = "testView"+label,
			favourited = FAVOURITED_VALUES[1],
			sort_by = SORT_BY_VALUES[2]
			;

			String sample_criteria = RestAPIConfManager.getRealValue("sample_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] or_criteria1 = criteria[key%25].split(",");

			boolean 
			isReplace = false,
			isPayload = false
			;

			JSONObject payload = null;
			switch(api_obj)
			{
				case VH_VIEW_CREATE:
				{
					isPayload = true;
					payload = GetPayload.getVisitorHistoryViewPayload(viewName,sort_by,favourited,or_criteria1);
					break;
				}
				case VH_VIEW_GET :
				{
					isReplace = true;
					break;
				}
				case VH_VIEW_UPDATE :
				{
					isPayload = true;
					payload = GetPayload.getVisitorHistoryViewPayload(viewName,sort_by,favourited,or_criteria1);
					isReplace = true;
					break;
				}
				case VH_VIEW_DELETE :
				{
					isReplace = true;
					break;
				}
				case VH_VIEW_UPDATE_SELECTED :
				{
					isPayload = true;
					payload = GetPayload.getUserPreferencesPayload(LIST_ONE,ALL_VISITORS_ID);
					break;
				}
				default :
				{
					isPayload = false;
					isReplace = false;
					payload = null;
				}
			}
			checkVHViewAPI(driver,api_webdriver,api_obj,false,false,Constants.INVALID_SCOPE_ERROR_CODE,isReplace,isPayload,payload,GET_VIEW,startKey,key,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);

		}
	}

	// COMMON FUNCTIONS

	public static String createVHView(WebDriver driver,WebDriver api_webdriver,String label,int startKey,int key,ExtentTest etest)
	{
		try
		{
			String
			viewName = "testView"+label,
			sort_by = SORT_BY_VALUES[key%4],
			favourited = FAVOURITED_VALUES[key%2]
			;

			if(startKey == 560)
			{
				favourited = "true";
			}

			String sample_criteria = RestAPIConfManager.getRealValue("sample_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] or_criteria1 = criteria[key%25].split(",");

			JSONObject payload = GetPayload.getVisitorHistoryViewPayload(viewName,sort_by,favourited,or_criteria1);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),false,"","",Api.VH_VIEW_CREATE,true,payload,etest);
			String view_id = new JSONObject(new JSONObject(response).get("data").toString()).get("id").toString();

			return view_id;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
			return "exception_occurred";
		}
	}

	public static void checkVHViewAPI(WebDriver driver,WebDriver api_webdriver,Api api_obj,boolean toCheckInUI,boolean isResponse,String responseCode,boolean isReplace,boolean isPayload,JSONObject payload,int view_type,int startKey,int key,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();

			if(api_obj == Api.VH_VIEW_CREATE)
			{
				label = "NewCreate"+startKey;
			}
			String
			sort_by = (startKey != 589)?SORT_BY_VALUES[key%4]:"last_visit_time",
			favourited = (startKey != 589)?FAVOURITED_VALUES[key%2]:"false",
			keys_check_usecase = "RESTAPI" + startKey,
			api_values_usecase = "RESTAPI" + (startKey+1),
			ui_values_usecase = "RESTAPI" + (startKey+2),
			viewName = "testView"+label,
			id = ""
			;

			etest.log(Status.INFO,"<pre>Check before<br>viewName : "+viewName+"<br>sort_by : "+sort_by+"<br>favourited : "+favourited+"<br>startKey : "+startKey+"<br>Key : "+key+"<br>id : "+id+"<br>"+keys_check_usecase+"<br>"+api_values_usecase+"<br>"+ui_values_usecase+"</pre>");

			String sample_criteria = RestAPIConfManager.getRealValue("sample_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] or_criteria1 = criteria[key%25].split(",");

			if(responseCode == Constants.INVALID_SCOPE_ERROR_CODE)
			{
				id = getRandomViewId(driver);
			}
			else if(api_obj != Api.VH_VIEW_CREATE)
			{
				id = createVHView(driver,api_webdriver,label,startKey,key,etest);
			}

			if(startKey == 560)
			{
				favourited = "true";
			}

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,ID,id,api_obj,isPayload,payload,etest);

			if((api_obj == Api.VH_VIEW_CREATE) && (responseCode != Constants.INVALID_SCOPE_ERROR_CODE) && (isResponse))
			{
				id = new JSONObject(new JSONObject(response).get("data").toString()).get("id").toString();
			}

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			etest.log(Status.INFO,"<pre>Check after response<br>viewName : "+viewName+"<br>sort_by : "+sort_by+"<br>favourited : "+favourited+"<br>startKey : "+startKey+"<br>Key : "+key+"<br>id : "+id+"</pre>");


			if(api_obj == Api.VH_VIEW_UPDATE)
			{
				viewName = EDITED_VIEW_NAME;
				sort_by = EDITED_SORT_BY;
				favourited = EDITED_FAVOURITED;
				or_criteria1 = EDITED_OR_CRITERIA1;
				etest.log(Status.INFO,"<pre>Check inside if update<br>viewName : "+viewName+"<br>sort_by : "+sort_by+"<br>favourited : "+favourited+"<br>startKey : "+startKey+"<br>Key : "+key+"<br>id : "+id+"</pre>");
			}
			else if(api_obj == Api.VH_VIEW_UPDATE_SELECTED)
			{
				id = ALL_VISITORS_ID;
				viewName = ALL_VISITORS;

				etest.log(Status.INFO,"<pre>Check inside update selected<br>viewName : "+viewName+"<br>sort_by : "+sort_by+"<br>favourited : "+favourited+"<br>startKey : "+startKey+"<br>Key : "+key+"<br>id : "+id+"</pre>");
			}

			if(isResponse)
			{
				try
				{
					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED KEYS ARE FOUND</b>");
					result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}

				try
				{
					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN API RESPONSE</b><pre><br>viewName : "+viewName+"<br>sort_by : "+sort_by+"<br>favourited : "+favourited+"<br>Key : "+key+"<br>id : "+id+"</pre>");
					result.put(api_values_usecase,isVHValuesFound(driver,etest,api_obj,response,view_type,id,viewName,sort_by,favourited,or_criteria1));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}

				if(toCheckInUI)
				{
					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI</b>");
					if(api_obj == Api.VH_VIEW_GET_LIST)
					{
						try
						{
							Hashtable<String,String> info = getVHViewInfo(driver,id,etest);
							int no_of_vh_views = Integer.parseInt(info.get(SIZE));
							
							JSONObject resp_json = new JSONObject(response);
							JSONArray vh_views_array = resp_json.getJSONArray("data");

							int actual_vh_views_size = vh_views_array.length();

							if(CommonUtil.checkStringEqualsAndLog(no_of_vh_views+"",actual_vh_views_size+"","No of visitor history views",etest))
							{
								etest.log(Status.PASS,"The total number of visitor history views shown in UI and API response are the same");
								result.put(ui_values_usecase,true);
							}
							else
							{
								etest.log(Status.FAIL,"The total number of visitor history views shown in UI and API response are not the same");
								result.put(ui_values_usecase,false);
								TakeScreenshot.screenshot(driver,etest);
								TakeScreenshot.screenshot(api_webdriver,etest);
								SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
							}
						}
						catch(Exception e1)
						{
							TakeScreenshot.screenshot(api_webdriver,etest,e1);
							TakeScreenshot.screenshot(driver,etest,e1);
							SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
						}
					}
					else if((api_obj == Api.VH_VIEW_SELECTED) || (api_obj == Api.VH_VIEW_UPDATE_SELECTED))
					{
						try
						{
							int failcount = 0;
							int i = 0;
							String[] list_view_id = {id,RETURNING_VISITORS_ID,ALL_VISITORS_ID};
							String[] list_view_name = {viewName,RETURNING_VISITORS,ALL_VISITORS};
							CommonUtil.refreshPage(driver);
							Tab.clickVisitorHistory(driver);
							List<WebElement> vhColumns = CommonUtil.getElement(driver,VISIT_MCONTENT).findElements(VH_COLUMNS);

							for(WebElement vhColumn : vhColumns)
							{
								if(!(CommonUtil.checkStringEqualsAndLog(vhColumn.getAttribute(VIEWID),list_view_id[i],"list ("+(i+1)+") view id",etest) &&
									CommonUtil.checkStringEqualsAndLog(vhColumn.findElement(TEXT).getAttribute("title"),list_view_name[i],"list ("+(i+1)+") view name",etest)))
								{
									TakeScreenshot.screenshot(driver,etest);
									failcount++;
								}
								i++;
							}
							result.put(ui_values_usecase,CommonUtil.returnResult(failcount));
						}
						catch(Exception e1)
						{
							TakeScreenshot.screenshot(api_webdriver,etest,e1);
							TakeScreenshot.screenshot(driver,etest,e1);
							SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
						}
					}
					else
					{
						try
						{
							result.put(ui_values_usecase,isVHViewValuesFoundInUI(driver,api_webdriver,etest,id,viewName,sort_by,favourited,or_criteria1));
						}
						catch(Exception e1)
						{
							TakeScreenshot.screenshot(api_webdriver,etest,e1);
							TakeScreenshot.screenshot(driver,etest,e1);
						}
					}

					if(!result.get(ui_values_usecase))
					{
						TakeScreenshot.screenshot(driver,etest);
					}
				}
			}
			else
			{
				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(responseCode,actualResponseCode,"response code",etest))
				{
					result.put(keys_check_usecase,true);
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					result.put(keys_check_usecase,false);
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
				}

				if(toCheckInUI)
				{
					boolean isDeletedPresent = false;
					if(api_obj == Api.VH_VIEW_DELETE)
					{
						result.put(api_values_usecase,true);
						CommonUtil.refreshPage(driver);
						Tab.clickVisitorHistory(driver);
						List<WebElement> vhColumns = CommonUtil.getElement(driver,VISIT_MCONTENT).findElements(VH_COLUMNS);

						CommonUtil.clickWebElement(driver,FAVDRPDOWN0,TEXT);
						CommonWait.waitTillDisplayed(driver,FAVDRPDOWN0,COMBOSUBDRPDWNMN);

						List<WebElement> vhViewsList = CommonUtil.getElement(driver,FAVDRPDOWN0,COMBOSUBDRPDWNMN,ULLIST).findElements(By.tagName("li"));

						for(WebElement vhView : vhViewsList)
						{
							if(vhView.getText().contains(viewName))
							{
								etest.log(Status.FAIL,"Deleted visitor history view ("+viewName+") was found in the list");
								TakeScreenshot.screenshot(driver,etest);
								result.put(ui_values_usecase,false);
								isDeletedPresent = true;
								break;
							}
						}
						if(!isDeletedPresent)
						{
							etest.log(Status.PASS,"Expected Visitor history view ("+viewName+") was found deleted");
							TakeScreenshot.infoScreenshot(driver,etest);
							result.put(ui_values_usecase,true);
						}
					}
					else if(api_obj == Api.VH_VIEW_UPDATE_SELECTED)
					{
						result.put(api_values_usecase,true);
						try
						{
							int failcount = 0;
							int i = 0;
							String[] list_view_id = {id,RETURNING_VISITORS_ID,ALL_VISITORS_ID};
							String[] list_view_name = {viewName,RETURNING_VISITORS,ALL_VISITORS};
							CommonUtil.refreshPage(driver);
							Tab.clickVisitorHistory(driver);
							List<WebElement> vhColumns = CommonUtil.getElement(driver,VISIT_MCONTENT).findElements(VH_COLUMNS);

							for(WebElement vhColumn : vhColumns)
							{
								if(!(CommonUtil.checkStringEqualsAndLog(vhColumn.getAttribute(VIEWID),list_view_id[i],"list ("+(i+1)+") view id",etest) &&
									CommonUtil.checkStringEqualsAndLog(vhColumn.findElement(TEXT).getAttribute("title"),list_view_name[i],"list ("+(i+1)+") view name",etest)))
								{
									TakeScreenshot.screenshot(driver,etest);
									failcount++;
								}
								i++;
							}
							result.put(ui_values_usecase,CommonUtil.returnResult(failcount));
						}
						catch(Exception e1)
						{
							TakeScreenshot.screenshot(api_webdriver,etest,e1);
							TakeScreenshot.screenshot(driver,etest,e1);
							SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static boolean isVHValuesFound(WebDriver driver,ExtentTest etest,Api api_obj,String response,int api_type,String id,String viewName,String sort_by,String favourited,String[] or_criteria1) throws Exception
	{
		int failcount=0;

		if((api_obj == Api.VH_VIEW_SELECTED) || (api_obj == Api.VH_VIEW_UPDATE_SELECTED))
		{
			if(!isValueFound(response,ALL_VISITORS_ID,getJPath(response,id,JPaths.LIST_THREE_ID,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,ALL_VISITORS,getJPath(response,id,JPaths.LIST_THREE_NAME,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,RETURNING_VISITORS_ID,getJPath(response,id,JPaths.LIST_TWO_ID,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,REPEATED_VISITORS,getJPath(response,id,JPaths.LIST_TWO_NAME,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,id,getJPath(response,id,JPaths.LIST_ONE_ID,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,viewName,getJPath(response,id,JPaths.LIST_ONE_NAME,api_type),etest))
			{
				failcount++;
			}
		}
		else
		{
			if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,viewName,getJPath(response,id,JPaths.NAME,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,sort_by,getJPath(response,id,JPaths.SORT_BY,api_type),etest))
			{
				failcount++;
			}

			if(!isValueFound(response,favourited,getJPath(response,id,JPaths.FAVOURITED,api_type),etest))
			{
				failcount++;
			}

			if(or_criteria1!=null)
			{
				JSONObject or_criteria1_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA1,api_type)));

				String actual_field_name=or_criteria1_json.get(APIKeys.FIELD_NAME).toString();
				String actual_comparator=or_criteria1_json.get(APIKeys.COMPARATOR).toString();
				String actual_values=or_criteria1_json.get(APIKeys.VALUES).toString();

				String expected_field_name=or_criteria1[0];
				String expected_comparator=or_criteria1[1];
				String expected_values=or_criteria1[2];

				if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 1",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 1",etest)==false)
				{
					failcount++;
				}
				if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 1",etest)==false)
				{
					failcount++;
				}
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isVHViewValuesFoundInUI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,String id,String viewName,String sortBy,String favourited,String[] or_criteria1)
	{
		int failcount = 0;
		Hashtable<String,String> info = getVHViewInfo(driver,id,etest);

		CommonUtil.print("\n\n\n\ngetVHViewInfo>>>>>>>"+id+"<<<<<<<<\n\n"+info+"\n\n\n");

		CommonUtil.print("\n\n\n\nisVHViewValuesFoundInUI>>>>>>>"+id+"<<<<<<<<\n\n>>>>>>>viewName<<<<<<<<"+viewName+"\n\n\n>>>>>>>sortBy<<<<<<<<"+sortBy+"\n\n\n>>>>>>>favourited<<<<<<<<"+favourited+"\n\n\n>>>>>>>or_criteria1<<<<<<<<"+or_criteria1+"\n\n\n");

		if(!CommonUtil.checkStringContainsAndLog(viewName,info.get(VIEW_NAME),"viewName",etest))
		{
			failcount++;
		}

		if(!CommonUtil.checkStringContainsAndLog(sortBy,info.get(SORT_BY),"sortBy",etest))
		{
			failcount++;
		}

		if(!CommonUtil.checkStringContainsAndLog(favourited,info.get(FAVOURITED),"favourited",etest))
		{
			failcount++;
		}

		if(!CommonUtil.checkStringContainsAndLog(or_criteria1[0],info.get(FIELD_NAME),"field_name",etest))
		{
			failcount++;
		}

		if(or_criteria1[1].equals("not_equals"))
		{
			or_criteria1[1] = "is_not_equal_to";
		}
		if(!CommonUtil.checkStringContainsAndLog(or_criteria1[1],info.get(CONDITION),"condition",etest))
		{
			failcount++;
		}

		if(!CommonUtil.checkStringContainsAndLog(or_criteria1[2].toLowerCase(),info.get(FIELD_VALUE),"field_value",etest))
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static String getJPath(String response,String view_id,String jPath,int api_type) throws Exception
	{
		if(api_type==GET_VIEW || response==null || view_id==null)
		{
			return jPath;
		}
		else
		{
			int view_index=getViewIndexOfGetViewsResponse(response,view_id);
			jPath=getJPathForIndex(jPath,view_index);
			return jPath;
		}
	}

	public static String getJPathForIndex(String jPath,int view_index) throws Exception
	{
		jPath=jPath.replace("data/", "data["+view_index+"]/");
		return jPath;
	}

	public static int getViewIndexOfGetViewsResponse(String response,String view_id) throws Exception
	{
		JSONObject resp_json = new JSONObject(response);
		JSONArray views_array = resp_json.getJSONArray("data");
		return SalesIQRestAPICommonFunctions.getJSONIndexWith(views_array,"id",view_id);
	}

	public static boolean isValueFound(String response,String expected,String jpath,ExtentTest etest) throws Exception
	{
		if(expected!=null && CommonUtil.checkStringContainsAndLog( expected , SalesIQRestAPICommonFunctions.jPath(response,jpath) , jpath , etest)==false)
		{
			return false;
		}

		return true;
	}

	public static String getRandomViewId(WebDriver driver)
	{
		return getViewIdByName(driver,null,false);
	}

	public static String getCurrentViewId(WebDriver driver)
	{
		return getViewIdByName(driver,null,true);
	}

	public static String getViewIdByName(WebDriver driver,String viewName,boolean isCurrentView)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			Tab.clickVisitorHistory(driver);
			List<WebElement> vhColumns = CommonUtil.getElement(driver,VISIT_MCONTENT).findElements(VH_COLUMNS);

			if(isCurrentView)
			{
				return CommonUtil.getElement(driver,FAVDRPDOWN0,TEXT).getAttribute("val");
			}
			else
			{
				CommonUtil.clickWebElement(driver,FAVDRPDOWN0,TEXT);
				CommonWait.waitTillDisplayed(driver,FAVDRPDOWN0,COMBOSUBDRPDWNMN);

				List<WebElement> vhViewsList = CommonUtil.getElement(driver,FAVDRPDOWN0,COMBOSUBDRPDWNMN,ULLIST).findElements(By.tagName("li"));

				for(WebElement vhView : vhViewsList)
				{
					if(viewName != null)
					{
						if(vhView.getText().contains(viewName))
						{
							return vhView.getAttribute("val");
						}
					}
					else
					{
						if(!vhView.getAttribute("val").contains("-"))
						{
							return vhView.getAttribute("val");
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
		return "-1";

	}

	public static Hashtable<String,String> getVHViewInfo(WebDriver driver,String id)
	{
		return getVHViewInfo(driver,id,null);
	}

	public static Hashtable<String,String> getVHViewInfo(WebDriver driver,String id,ExtentTest etest)
	{
		Hashtable<String,String> info=new Hashtable<String,String>();
		try
		{
			CommonUtil.refreshPage(driver);
			Tab.clickVisitorHistory(driver);

			List<WebElement> vhColumns = CommonUtil.getElement(driver,VISIT_MCONTENT).findElements(VH_COLUMNS);

			WebElement vhColumn = CommonUtil.getElementByAttributeValue(vhColumns,VIEWID,id);

			CommonUtil.clickWebElement(driver,CommonUtil.getElement(vhColumn,ACTIONDRPDOWN,By.tagName("div")));

			CommonWait.waitTillDisplayed(driver,COMBOSUBDRPDWNMN);

			List<WebElement> moreOptions = CommonUtil.getElement(driver,COMBOSUBDRPDWNMN,ULLIST).findElements(By.tagName("li"));

			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(moreOptions,"val","2"));

			CommonWait.waitTillDisplayed(driver,LDSETTINGS);

			WebElement ldSettings = CommonUtil.getElement(driver,LDSETTINGS);

			if(etest != null)
			{
				TakeScreenshot.infoScreenshot(driver,etest);
			}

			info.put(SORT_BY,getSortByValue(CommonUtil.getElement(ldSettings,CMPNY_FLTR_DIV,TEXT).getText().trim()));
			info.put(FAVOURITED,CommonUtil.getElement(ldSettings,SETFAV).getAttribute("checked").toString().trim());
			info.put(VIEW_NAME,CommonUtil.getElement(ldSettings,FAV_VAL).getAttribute("value").trim());
			info.put(FIELD_NAME,CommonUtil.getElement(ldSettings,PRIOR1_COL1_DIV).getAttribute("title").replace("(Last Visit)","").trim().toLowerCase().replaceAll(" ","_"));
			info.put(CONDITION,CommonUtil.getElement(ldSettings,PRIOR1_COL2_DIV).getAttribute("title").trim().replaceAll(" ","_").replaceAll("is_more_than","greater_than"));
			info.put(FIELD_VALUE,CommonUtil.getElement(ldSettings,PRIOR1_COL3_DIV,By.tagName("input")).getAttribute("value").toLowerCase().trim().replaceAll(" ","_"));

			CommonUtil.clickWebElement(driver,By.className("sqico-close"));

			try
			{
				CommonWait.waitTillHidden(ldSettings);
			}
			catch(Exception e)
			{
				ExecuteStatements.run(driver,"UTSHandler.hideAdvanceFilter()");
			}

			CommonUtil.clickWebElement(driver,FAVDRPDOWN0,TEXT);
			CommonWait.waitTillDisplayed(driver,FAVDRPDOWN0,COMBOSUBDRPDWNMN);

			List<WebElement> vhViewsList = CommonUtil.getElement(driver,FAVDRPDOWN0,COMBOSUBDRPDWNMN,ULLIST).findElements(By.tagName("li"));
			info.put(SIZE,vhViewsList.size()+"");

			CommonUtil.print("\n\n\n\ngetVHViewInfo>>>>>>>\n\n"+info+"\n\n\n");

			return info;
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			return info;
		}
	}

	public static String getSortByValue(String sortByFromUI)
	{
		String sortByValue = "";
		switch(sortByFromUI)
		{
			case "Recent Visitor" : 
			{
				sortByValue = "last_visit_time";
				break;
			}
			case "Frequent Visitor" : 
			{
				sortByValue = "frequency";
				break;
			}
			case "Top Lead Scoring Visitor" : 
			{
				sortByValue = "leadscore";
				break;
			}
			case "Visitor Spent More Time" : 
			{
				sortByValue = "time_on_site";
				break;
			}
			default :
			{
				sortByValue = "leadcore";
			}
		}
		return sortByValue;
	}

	public static int getRandomId()
	{
		String label = CommonUtil.getUniqueMessage();

		label = label.substring(label.length()-3,label.length());

		int randomId = Integer.parseInt(label);

		return randomId;
	}
}
