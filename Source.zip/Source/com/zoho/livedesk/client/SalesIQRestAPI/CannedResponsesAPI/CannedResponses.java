//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.CannedResponsesAPI;

import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesModule;
import com.zoho.livedesk.client.SalesIQRestAPI.APIKeys;
import com.zoho.livedesk.client.SalesIQRestAPI.Api;
import com.zoho.livedesk.client.SalesIQRestAPI.Constants;
import com.zoho.livedesk.client.SalesIQRestAPI.GetPayload;
import com.zoho.livedesk.client.SalesIQRestAPI.JPaths;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRESTAPIModule3;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPIModule;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class CannedResponses {

 public static Hashtable finalResult = new Hashtable();

 public static Hashtable < String, Boolean > result = null;
 public static ExtentTest etest;
 public static Hashtable < String, Boolean > testResults = new Hashtable < String, Boolean > ();
 public static final String MODULE_NAME = "CannedResponses API";

 public static final String
  COMMENT="comment",
  ENABLED="ENABLED";


 public static Hashtable test(WebDriver driver) {
  WebDriver api_webdriver = null, supervisorDriver = null;
  try {	 
      result = new Hashtable<String,Boolean>();     
      Cleanup.deleteAllCannedMessagesAndCategories(driver); 
      
   api_webdriver = Functions.setUp();
   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api1");

   etest = ComplexReportFactory.getEtest("Create Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   createCannedResponsesAPI(api_webdriver, driver, etest);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getEtest("Get Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   getCannedResponsesAPI(api_webdriver, driver, etest);
   ComplexReportFactory.closeTest(etest);
   
   etest = ComplexReportFactory.getEtest("Get Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   updateCannedResponsesAPI(api_webdriver, driver, etest);
   ComplexReportFactory.closeTest(etest);
   
   etest = ComplexReportFactory.getEtest("Get Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   deleteCannedResponsesAPI(api_webdriver, driver, etest);
   ComplexReportFactory.closeTest(etest);

   
   supervisorDriver=Driver.getDriver();
   Functions.login(supervisorDriver,"apps_api1");
   
   etest = ComplexReportFactory.getEtest("Create Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   createCannedResponsesAPI(supervisorDriver, driver, etest);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getEtest("Get Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   getCannedResponsesAPI(supervisorDriver, driver, etest);
   ComplexReportFactory.closeTest(etest);
   
   etest = ComplexReportFactory.getEtest("Get Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   updateCannedResponsesAPI(supervisorDriver, driver, etest);
   ComplexReportFactory.closeTest(etest);
   
   etest = ComplexReportFactory.getEtest("Get Canned Responses from API", MODULE_NAME);
   ComplexReportFactory.setValues(etest, "Automation", MODULE_NAME);
   deleteCannedResponsesAPI(supervisorDriver, driver, etest);
   ComplexReportFactory.closeTest(etest);
   
   
   

  } catch (Exception e) {
   CommonUtil.printStackTrace(e);
   etest.log(Status.FATAL, "Module Breakage occurred " + e);
   TakeScreenshot.screenshot(driver, etest);
   TakeScreenshot.log(e, etest);
  } finally {
   ComplexReportFactory.closeTest(etest);
   finalResult.put("result", result);
   finalResult.put("servicedown", new Hashtable());
   Driver.quitDriver(api_webdriver);
   Driver.quitDriver(supervisorDriver);
  }
  return finalResult;
 }




 public static void createCannedResponsesAPI(WebDriver api_webdriver, WebDriver driver, ExtentTest etest) throws Exception {
  try {
   int randomId = CommonUtil.getRandomId();
   String
   label = CommonUtil.getUniqueMessage(),
    website_name = ExecuteStatements.getDefaultEmbedName(driver),
    default_department = ExecuteStatements.getSystemGeneratedDepartment(driver),
    department_id = ExecuteStatements.getDepartmentID(driver, default_department),
    content = "Content_ " + label,
    departmentId = "DeptId_ " + randomId,
    associate_with_all_departments = "ture",
    published = "true",
    api = Api.CANNED_RESPONSES_CREATE.get();


   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));
   String keys_check_usecase = "RESTAPI1225", api_values_usecase = "RESTAPI1226", ui_values_usecase = "RESTAPI1227";
   JSONObject payload = null;

   payload = GetPayload.getCannedResponsesCreatePayload(content, associate_with_all_departments, departmentId, published);

   etest.log(Status.INFO, "Below json will be used as payload");
   SalesIQRestAPICommonFunctions.log(etest, payload);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, Api.CANNED_RESPONSES_CREATE);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.addPayload(api_webdriver, payload);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);
   etest.log(Status.PASS, "json_response-->" + json_response.toString());
   String rule_id = SalesIQRestAPICommonFunctions.jPath(response, JPaths.DATA_ID);

   if (CommonUtil.isChecked(keys_check_usecase, result) == false) {
    try {
     etest.log(Status.INFO, "NOW CHECKED IF EXPECTED KEYS ARE FOUND");
     result.put(keys_check_usecase, isKeysFoundForGetRulesAPI(etest, response, Api.CANNED_RESPONSES_CREATE.expected_keys));
    } catch (Exception e1) {
     TakeScreenshot.screenshot(api_webdriver, etest, e1);
     TakeScreenshot.screenshot(driver, etest, e1);
    }
   }

   try {
    etest.log(Status.INFO, "NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
    result.put(api_values_usecase, isCannedResponsesValuesFoundInResponse(driver, etest, response, rule_id, Constants.SUCCESS_CODE, department_id, content));
   } catch (Exception e1) {
    TakeScreenshot.screenshot(api_webdriver, etest, e1);
    TakeScreenshot.screenshot(driver, etest, e1);
   }
	try
	{
		etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
		result.put(ui_values_usecase,isCannedResponsesFoundInUI(driver, etest, rule_id,true));
	}
	catch(Exception e1)
	{
		TakeScreenshot.screenshot(api_webdriver,etest,e1);
		TakeScreenshot.screenshot(driver,etest,e1);
	}
	

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, e);
   TakeScreenshot.screenshot(api_webdriver, etest, e);
  }
 }



 //get
 public static void getCannedResponsesAPI(WebDriver api_webdriver, WebDriver driver, ExtentTest etest) throws Exception {
  try {
   String label = CommonUtil.getUniqueMessage();
   int randomId = CommonUtil.getRandomId();
   Api create_cannedresponses_api = null;

   String
   comment = "Comment" + label,
    default_department = ExecuteStatements.getSystemGeneratedDepartment(driver),
    department_id = ExecuteStatements.getDepartmentID(driver, default_department),
    content = "Content_ " + label,
    departmentId = "DeptId_ " + randomId,
    associate_with_all_departments = "ture",
    published = "true",

    keys_check_usecase = "RESTAPI1228",
    api_values_usecase = "RESTAPI1229",
    get_list_keys_check_usecase = "RESTAPI1230",
    get_list_api_values_usecase = "RESTAPI1231";

   create_cannedresponses_api = Api.CANNED_RESPONSES_CREATE;

   String api = create_cannedresponses_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));

   JSONObject payload = null;

   payload = GetPayload.getCannedResponsesCreatePayload(content, associate_with_all_departments, departmentId, published);

   etest.log(Status.INFO, "Below json will be used as payload");
   SalesIQRestAPICommonFunctions.log(etest, payload);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, create_cannedresponses_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.addPayload(api_webdriver, payload);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   if (SalesIQRestAPICommonFunctions.isKeyFound(etest, response, JPaths.DATA_ID)) {
    etest.log(Status.INFO, "CannedResponses was successfully created.");
   } else {
    throw new ZohoSalesIQRuntimeException("Cannedresponses was not created, Unable to check get API");
   }

   //Now calling get API
   String rule_id = SalesIQRestAPICommonFunctions.jPath(response, JPaths.DATA_ID);

   etest.log(Status.INFO, "Now calling get blocked IP API");

   Api get_api = Api.CANNED_RESPONSES_GET;

   api = get_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));
   api = api.replace("<" + "id" + ">", rule_id);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, get_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   try {
    etest.log(Status.INFO, "NOW CHECKED IF EXPECTED KEYS ARE FOUND");
    result.put(keys_check_usecase, SalesIQRestAPICommonFunctions.isKeysFound(etest, response, get_api.expected_keys));
   } catch (Exception e1) {
    TakeScreenshot.screenshot(api_webdriver, etest, e1);
    TakeScreenshot.screenshot(driver, etest, e1);
   }

   try {
    etest.log(Status.INFO, "NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
    result.put(api_values_usecase, isCannedResponsesValuesFoundInResponse(driver, etest, response, department_id, comment));
   } catch (Exception e1) {
    TakeScreenshot.screenshot(api_webdriver, etest, e1);
    TakeScreenshot.screenshot(driver, etest, e1);
   }

   //Now calling get  list API
   etest.log(Status.INFO, "Now calling get CannedResponses list API");

   Api get_list_api = Api.CANNED_RESPONSES_GET_LIST;

   api = get_list_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, get_list_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   if (CommonUtil.isChecked(get_list_keys_check_usecase, result) == false) {
    try {
     etest.log(Status.INFO, "NOW CHECKED IF EXPECTED KEYS ARE FOUND");
     result.put(get_list_keys_check_usecase, isKeysFoundForGetRulesAPI(etest, response, create_cannedresponses_api.expected_keys));
    } catch (Exception e1) {
     TakeScreenshot.screenshot(api_webdriver, etest, e1);
     TakeScreenshot.screenshot(driver, etest, e1);
    }
   }

   try {
    etest.log(Status.INFO, "NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
    result.put(get_list_api_values_usecase, isCannedResponsesValuesFoundInResponse(driver, etest, response, department_id, comment));
   } catch (Exception e1) {
    TakeScreenshot.screenshot(api_webdriver, etest, e1);
    TakeScreenshot.screenshot(driver, etest, e1);
   }
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, e);
   TakeScreenshot.screenshot(api_webdriver, etest, e);
  }
 }




 //update
 public static void updateCannedResponsesAPI(WebDriver api_webdriver, WebDriver driver, ExtentTest etest) throws Exception {
  try {
   String label = CommonUtil.getUniqueMessage();
   int randomId = CommonUtil.getRandomId();
   Api create_cannedresponses_api = null;

   String
   website = ExecuteStatements.getDefaultEmbedName(driver),
    comment = "Comment" + label,
    default_department = ExecuteStatements.getSystemGeneratedDepartment(driver),
    department_id = ExecuteStatements.getDepartmentID(driver, default_department),
    content = "Content_ " + label,
    departmentId = "DeptId_ " + randomId,
    associate_with_all_departments = "ture",
    published = "true",

    keys_check_usecase = "RESTAPI1232",
    api_values_usecase = "RESTAPI1233",
    ui_usecase="RESTAPI1234";

   create_cannedresponses_api = Api.CANNED_RESPONSES_CREATE;

   String api = create_cannedresponses_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));

   JSONObject payload = null;

   payload = GetPayload.getCannedResponsesCreatePayload(content, associate_with_all_departments, departmentId, published);

   etest.log(Status.INFO, "Below json will be used as payload");
   SalesIQRestAPICommonFunctions.log(etest, payload);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, create_cannedresponses_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.addPayload(api_webdriver, payload);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   if (SalesIQRestAPICommonFunctions.isKeyFound(etest, response, JPaths.DATA_ID)) {
    etest.log(Status.INFO, "CannedResponses was successfully created.");
   } else {
    throw new ZohoSalesIQRuntimeException("CannedResponses was not created, Unable to check get API");
   }

   //Now calling get  API
   String rule_id = SalesIQRestAPICommonFunctions.jPath(response, JPaths.DATA_ID);

   etest.log(Status.INFO, "Now calling get blocked IP API");

   Api get_api = Api.CANNED_RESPONSES_UPDATE;

   api = get_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));
   api = api.replace("<" + "id" + ">", rule_id);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, get_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   try {
    etest.log(Status.INFO, "NOW CHECKED IF EXPECTED KEYS ARE FOUND");
    result.put(keys_check_usecase, SalesIQRestAPICommonFunctions.isKeysFound(etest, response, get_api.expected_keys));
   } catch (Exception e1) {
    TakeScreenshot.screenshot(api_webdriver, etest, e1);
    TakeScreenshot.screenshot(driver, etest, e1);
   }

   try {
    etest.log(Status.INFO, "NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
    result.put(api_values_usecase, isCannedResponsesValuesFoundInResponse(driver, etest, response, department_id, comment));
   } catch (Exception e1) {
    TakeScreenshot.screenshot(api_webdriver, etest, e1);
    TakeScreenshot.screenshot(driver, etest, e1);
   }

	try
	{
		etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
		result.put(ui_usecase,isCannedResponsesFoundInUI(driver, etest, rule_id,true));
	}
	catch(Exception e1)
	{
		TakeScreenshot.screenshot(api_webdriver,etest,e1);
		TakeScreenshot.screenshot(driver,etest,e1);
	}

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, e);
   TakeScreenshot.screenshot(api_webdriver, etest, e);
  }
 }




 public static void deleteCannedResponsesAPI(WebDriver api_webdriver, WebDriver driver, ExtentTest etest) throws Exception {
  try {
   String label = CommonUtil.getUniqueMessage();
   int randomId = CommonUtil.getRandomId();
   Api create_cannedresponses_api = null;

   String
   website = ExecuteStatements.getDefaultEmbedName(driver),
    default_department = ExecuteStatements.getSystemGeneratedDepartment(driver),
    department_id = ExecuteStatements.getDepartmentID(driver, default_department),
    title = "title" + label,
    content = "Content_ " + label,
    departmentId = "DeptId_ " + randomId,
    associate_with_all_departments = "ture",
    published = "true";

   create_cannedresponses_api = Api.CANNED_RESPONSES_CREATE;

   String api = create_cannedresponses_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));

   JSONObject payload = null;

   payload = GetPayload.getCannedResponsesCreatePayload(content, associate_with_all_departments, departmentId, published);

   etest.log(Status.INFO, "Below json will be used as payload");
   SalesIQRestAPICommonFunctions.log(etest, payload);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, create_cannedresponses_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.addPayload(api_webdriver, payload);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   if (SalesIQRestAPICommonFunctions.isKeyFound(etest, response, JPaths.DATA_ID)) {
    etest.log(Status.INFO, "CannedResponses was successfully created.");
   } else {
    throw new ZohoSalesIQRuntimeException("CannedResponses was not created, Unable to check get API");
   }

   String rule_id = SalesIQRestAPICommonFunctions.jPath(response, JPaths.DATA_ID);

   //Now calling delete  API
   etest.log(Status.INFO, "Now calling delete CannedResponses API");

   Api delete_api = Api.CANNED_RESPONSES_DELETE;

   api = delete_api.get();
   api = api.replace("<" + APIKeys.SCREENNAME + ">", ExecuteStatements.getPortal(driver));
   api = api.replace("<" + "id" + ">", rule_id);

   api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
   SalesIQRestAPICommonFunctions.configureAPI(api_webdriver, delete_api);
   SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver, api);
   SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

   response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

   json_response = SalesIQRestAPICommonFunctions.convertToJSON(response, etest);

   etest.log(Status.PASS, "json_response-->" + json_response.toString());

   String resp_code = SalesIQRestAPICommonFunctions.jPath(response, "code");

   result.put("RESTAPI1235", CommonUtil.checkStringContainsAndLog("204", resp_code, "response code for delete CannedResponses API", etest));

   if (CannedMessagesModule.checkDeleteCannedMessage(driver) == false) {
    etest.log(Status.PASS, "CannedResponses was not found after it was deleted with REST API");
    result.put("RESTAPI1235", true);
   } else {
    etest.log(Status.FAIL, "CannedResponses was found after it was deleted with REST API");
    result.put("RESTAPI1235", false);
    TakeScreenshot.screenshot(driver, etest);
   }
   try
	{
		etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
		result.put("RESTAPI1237",isCannedResponsesFoundInUI(driver, etest, rule_id,true));
	}
	catch(Exception e1)
	{
		TakeScreenshot.screenshot(api_webdriver,etest,e1);
		TakeScreenshot.screenshot(driver,etest,e1);
	}

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, e);
   TakeScreenshot.screenshot(api_webdriver, etest, e);
  }

 }


 //other methods
 public static boolean isKeysFoundForGetRulesAPI(ExtentTest etest, String json_string, String[] jPaths) throws Exception {
  int failcount = 0;

  for (String jPath: jPaths) {
   if (!SalesIQRestAPICommonFunctions.isKeyFound(etest, json_string, getJPathForIndex(jPath, 0))) {
    failcount++;
   }
  }

  return CommonUtil.returnResult(failcount);
 }


 public static boolean isCannedResponsesValuesFoundInResponse(WebDriver driver, ExtentTest etest, String response, String id, String...comments) throws Exception {
  int failcount = 0;

  if (!isValueFound(response, id, getJPath(response, id, JPaths.RULEID), etest)) {
   failcount++;
  }

  if (comments != null) {
   for (int i = 0; i < comments.length; i++) {
    String comment = COMMENT;

    if (!isValueFound(response, comment, getJPath(response, id, JPaths.COMMENTS), etest)) {
     failcount++;
    }
   }
  }
  return CommonUtil.returnResult(failcount);
 }

 public static boolean isCannedResponsesFoundInUI(WebDriver driver,ExtentTest etest,String id,boolean is_enabled) throws Exception
	{
		int failcount=0;

		Hashtable<String,String> rule_info=getInfo(driver,id);
		
		if(isContains(""+is_enabled,rule_info.get(CannedResponses.ENABLED),"enabled/disabled status",etest)==false)
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}


 public static Hashtable<String,String> getInfo(WebDriver driver,String rule_id) throws Exception
 {
     Tab.clickCannedResponses(driver);

     WebElement canned_responses_container=CommonUtil.getElement(driver,By.cssSelector("[cannedid='"+rule_id+"']"));

     if(canned_responses_container==null)
     {
         throw new ZohoSalesIQRuntimeException("Chat monitor with id "+rule_id+" was not found");
     }

     CommonUtil.scrollIntoView(driver,canned_responses_container);

     Hashtable<String,String> rule_info=new Hashtable<String,String>();

     return rule_info;
 }


 public static boolean isContains(String expected, String actual, String description, ExtentTest etest) throws Exception {
  return SalesIQRESTAPIModule3.isContains(expected, actual, description, etest);
 }
	
 public static String getJPath(String response, String rule_id, String jPath) throws Exception {
  if (response == null || rule_id == null) {
   return jPath;
  } else {
   int rule_index = getRuleIndexOfGetRulesResponse(response, rule_id);
   jPath = getJPathForIndex(jPath, rule_index);
   return jPath;
  }
 }

 public static String getJPathForIndex(String jPath, int rule_index) throws Exception {
  jPath = jPath.replace("data/", "data[" + rule_index + "]/");
  return jPath;
 }

 public static int getRuleIndexOfGetRulesResponse(String response, String rule_id) throws Exception {
  JSONObject resp_json = new JSONObject(response);
  JSONArray rules_array = resp_json.getJSONArray("data");
  return SalesIQRestAPICommonFunctions.getJSONIndexWith(rules_array, "id", rule_id);
 }

 public static boolean isValueFound(String response, String expected, String jpath, ExtentTest etest) throws Exception {
  return SalesIQRESTAPIModule3.isValueFound(response, expected, jpath, etest);
 }
 
 
}