//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

public class JPaths
{
	public static final String
	PORTALS_ARRAY="data",
	PORTAL_WEBSITE="data/website",
	PORTAL_FAX="data/fax",
	PORTAL_EMAIL="data/email_id",
	PORTAL_LOGO="data/logo",
	PORTAL_LANGUAGE="data/language",
	PORTAL_PHONE="data/phone",
	PORTAL_ICON="data/icon",
	PORTAL_SCREENNAME="data/screenname",
	PORTAL_ADDRESS="data/address",
	PORTAL_DESCRIPTION="data/description",
	PORTAL_TIMEZONE="data/time_zone",
	PORTAL_COMPANY_NAME="data/company_name",
	DEPARTMENTS_ARRAY="data",

	DEPT_FEEDBACK_MAIL="data/email_configurations/feedback_recipients",
	DEPT_IS_FEEDBACK="data/email_configurations/is_feedback_mail_enabled",

	DEPT_CC_MAIL="data/email_configurations/cc_recipients",
	DEPT_IS_CC="data/email_configurations/is_cc_mail_enabled",

	DEPT_TRANSCRIPT_MAIL="data/email_configurations/transcript_recipients",
	DEPT_IS_TRANSCRIPT="data/email_configurations/is_transcript_mail_enabled",

	DEPT_MISSED_MAIL="data/email_configurations/missedchat_recipients",
	DEPT_IS_MISSED="data/email_configurations/is_missedchat_mail_enabled",

	DEPT_BLOCKED_MAIL="data/email_configurations/blockip_recipients",
	DEPT_IS_BLOCKED="data/email_configurations/is_blockip_mail_enabled",

	DEPT_FROM_MAIL="data/email_configurations/from_email",

	DEPT_NAME="data/name",
	DEPT_ID="data/id",
	DEPT_IS_ENABLED="data/is_enabled",
	DEPT_OPERATORS_ARRAY="data/operators",
	DEPT_CREATED_BY="data/is_public",
	DEPT_IMAGE_URL="data/image_url",
	DEPT_SYSTEM_GENERATED="data/is_system_generated",
	DEPT_IS_PUBLIC="data/is_public",
	DEPT_DESCRIPTION="data/description",
	DEPT_DISPLAY_NAME="data/display_name",

	BOT_NAME="data/name",
	BOT_DESCRIPTION="data/description",
	MODIFIER_NAME="data/modifier/name",
	MODIFIER_ID="data/modifier/id",
	IS_SECURED="data/webhook/secured",
	WEBHOOK_URL="data/webhook/url",
	CONNECTOR_STATUS="data/connector/status",
	CONNECTOR_TYPE="data/connector/type",
	TYPING_DELAY="data/typing_delay",
	WORKING_HOURS="data/working_hours",
	CREATOR_NAME="data/creator/name",
	DEPARMENT_ID="data/department_ids[<index>]",
	HANDOFF="data/handoff_enabled",
	IS_PUBLISHED="data/published",
	RESTRICT_SOURCE="data/restrict_source",
	IMAGE_URL="data/image_url",
	VENDOR_VERSION="data/vendor/version",
	VENDOR_MAIL="data/vendor/email_id",
	VENDOR_WEBSITE="data/vendor/website",
	VENDOR_NAME="data/vendor/name",
	VENDOR_CONSOLE="data/vendor/console_url",
	ACCESS_KEY="data/vendor/access_key",
	PUBLIC_KEY1="data/webhook/keys[0]/public_key",
	PUBLIC_KEY2="data/webhook/keys[1]/public_key",
	PUBLIC_KEY1_ID="data/webhook/keys[0]/id",
	PUBLIC_KEY2_ID="data/webhook/keys[1]/id",

	RULEID="data/id",
	TITLE="data/title",
	AND_CRITERIA="data/and_criteria",

	REPLIED_COUNT="data/stats/replied_count",
	TRIGGERED_COUNT="data/stats/triggered_count",
	ROUTED_COUNT="data/stats/routed_count",

	CONNECTED_COUNT="data/stats/connected_count",
	TRANSFERED_COUNT="data/stats/transfered_count",
	MISSED_COUNT="data/stats/missed_count",

	REQUESTED_COUNT="data/stats/requested_count",
	ATTENDED_COUNT="data/stats/attended_count",

	CONDITION_COUNT="data/condition",

	CREATOR_ID="data/creator_id",
	CREATOR_ID2="data/creator/id",
	STATUS="data/enabled",
	LAST_ROUTED_TIME="data/stats/last_routed_time",
	APPID="data/app/id",
	ROUTING_TYPE="data/routing_type",
	USERSET_ARRAY="data/userset",
	OR_CRITERIA1="data/and_criteria[0]/or_criteria[0]",
	OR_CRITERIA2="data/and_criteria[0]/or_criteria[1]",
	ROUTE_TO_ALL="data/route_to_all",
	OR_CRITERIA1_FIELDNAME="data/and_criteria[0]/or_criteria[0]/field_name",
	OR_CRITERIA2_FIELDNAME="data/and_criteria[0]/or_criteria[1]/field_name",
	OR_CRITERIA1_COMPARATOR="data/and_criteria[0]/or_criteria[0]/comparator",
	OR_CRITERIA2_COMPARATOR="data/and_criteria[0]/or_criteria[1]/comparator",
	OR_CRITERIA1_VALUES="data/and_criteria[0]/or_criteria[0]/values",
	OR_CRITERIA2_VALUES="data/and_criteria[0]/or_criteria[1]/values",

	POINTS="data/points",

	FREQUENCY="data/frequency",

	ERROR_MESSAGE="error/message",
	ERROR_CODE="error/code",
	MONITOR_TYPE="data/monitoring/type",
	OPERATOR_ID="data/monitoring/operator_id",
	VISITOR_IP="data/monitoring/visitor_ip",
	VISITOR_EMAIL="data/monitoring/visitor_email",
	STATUS2="data/status",
	BLOCKED_BY="data/blocked_by",
	APP_NAME="data/app/name",
	APPID2="data/app/id",
	IP="data/ip",
	NO_OF_COMMENTS="data/no_of_comments",
	COMMENTS="data/comments",
	COMMENT_OPERATOR_ID="data/comments[<index>]/operator_id",
	COMMENT_TEXT="data/comments[<index>]/text",
	RULEID_ARRAY="data[0]/id",

	POSITION="data/position",
	EVENT_TYPE="data/event/type",
	SEEN_COUNT="data/stats/seen_count",
	FAILED_COUNT="data/stats/failed_count",
	ACTION_TYPE="data/action/type",
	DELAY="data/action/delay",
	SENDER_NAME="data/action/params/sender_name",
	SENDER_VALUE="data/action/params/value",
	ENABLED="data/enabled",

	NAME="data/name",
	SORT_BY="data/sort_by",
	FAVOURITED="data/favourited",
	LIST_THREE_ID="data/visitorhistoryviews/list_three/view_id",
	LIST_THREE_NAME="data/visitorhistoryviews/list_three/view_name",
	LIST_TWO_ID="data/visitorhistoryviews/list_two/view_id",
	LIST_TWO_NAME="data/visitorhistoryviews/list_two/view_name",
	LIST_ONE_ID="data/visitorhistoryviews/list_one/view_id",
	LIST_ONE_NAME="data/visitorhistoryviews/list_one/view_name",

	DEPARTMENT_ENABLED = "data/departments[<id>]/enabled",
	DEPARTMENT_STATUS = "data/departments[<id>]/status",
	DEPARTMENT_NAME = "data/departments[<id>]/name",
	DEPARTMENT_ID = "data/departments[<id>]/mapped_integration_department/id",
	INTEGRATED_DEPARTMENT_NAME = "data/departments[<id>]/mapped_integration_department/name",
	PLACEHOLDER = "data[<id>]/placeholder",

	DATA_ID= "data/id",	
	CONTENT="data/content",
	DEPARTMENT_ID_CANNEDRESPONSES="data/department_id",
	PUBLISHED="data/published",
	ASSOCIATE_WITH_ALL_DEPARTMENTS="data/associate_withh_all_departments"
	;

	public static String getJPathByIndex(String jPath,int index)
	{
		return jPath.replace("<index>",""+index);
	}
}
