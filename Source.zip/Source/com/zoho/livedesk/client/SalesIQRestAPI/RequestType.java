//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

public enum RequestType
{
	GET,
	POST,
	PUT,
	DELETE
	;
}