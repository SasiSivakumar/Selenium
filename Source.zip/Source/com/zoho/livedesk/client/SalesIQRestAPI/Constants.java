//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

public class Constants
{
	public static final String
	ROUTE_TO_SELECTED_USERS="route_to_selected_users",
	ROUTE_TO_ONE_BY_ONE="route_one_by_one",
	LAST_ATTENDER="last_attender",
	ATLEAST_ONE_ONLINE="at_least_one_user_online",
	ENABLED="enabled",
	DISABLED="disabled",
	TRUE = "true",
	FALSE = "false",
	BLOCK="block",
	UNBLOCK="unblock",
	APPROVE="approve",
	REJECT="reject",
	BLOCKED="blocked",
	UNBLOCKED="unblocked",
	APPROVAL_REQUIRED="approval_required",
	LANDS_ON_WEBSITE="lands_on_website",
	ACCESS_ANY_PAGE_ON_WEBSITE = "access_any_page_on_website",
	SEND_CHAT_INVITE="send_chat_invite",
	ALL_THE_TIME="24x7",
	DURING_BUSINESS_HOURS="during_business_hours",
	WEBHOOK="webhook"
	;

	//Error messages
	public static final String
	SUCCESS_CODE = "204",

	INVALID_SCOPE_ERROR_CODE="1009",
	INVALID_SCOPE_ERROR_MESSAGE="Invalid OAuthScope",

	PERMISSION_ERROR_CODE="1016",
	PERMISSION_ERROR_MESSAGE="Operator doesn't have the permission to perform the operation",

	ACCESS_DENIED_MESSAGE = "Maintenance APIs can only be accessed by Admins",
	ACCESS_DENIED_CODE = "1013",

	PERMISSION_ERROR_CODE2=PERMISSION_ERROR_CODE,
	PERMISSION_ERROR_MESSAGE2=PERMISSION_ERROR_MESSAGE,

	INVALID_RESOURCE = "1019",
	INVALID_RESOURCE_ERROR_MESSAGE = "Invalid Resource",

	INVALID_INPUTSTREAM = "1015",
	INVALID_INPUTSTREAM_ERROR_MESSAGE = "Either the inputstream is invalid or absent",

	VIEW_NAME_ALREADY_PRESENT = "12000",
	VIEW_NAME_ALREADY_PRESENT_ERROR_MESSAGE = "View name is already present in another view",

	CHANNEL_ALREADY_EXISTS_CODE = "1408",
	CHANNEL_ALREADY_EXISTS_ERROR_MESSAGE = "Channel already exists"
	;

}
