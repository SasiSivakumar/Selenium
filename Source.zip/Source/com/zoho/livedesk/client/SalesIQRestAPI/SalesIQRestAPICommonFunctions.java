//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;


import com.zoho.livedesk.*;


import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.Augmenter;



import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;

import com.zoho.livedesk.util.common.CommonUtil;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.AAgentsSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Hashtable;

import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;


import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.SalesIQRestAPI.RestAPIConfManager;
import com.zoho.livedesk.client.AgentsSettings;
import org.openqa.selenium.JavascriptExecutor;

import java.net.URL;

import java.net.HttpURLConnection;



import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;



public class SalesIQRestAPICommonFunctions
{
	public static ExtentTest etest = null;
	public static String 
	screenname=RestAPIConfManager.getRealValue("screenname"),
	chatid=RestAPIConfManager.getRealValue("chat_id"),
	viewid=RestAPIConfManager.getRealValue("viewid"),
	attachmenturl=RestAPIConfManager.getRealValue("attachmenturl"),
	emailid=RestAPIConfManager.getRealValue("emailid"),
	widgetcode=RestAPIConfManager.getRealValue("widgetcode");

	public static String clientid=RestAPIConfManager.getRealValue("clientid"),clientsecret=RestAPIConfManager.getRealValue("clientsecret"),redirecturl=RestAPIConfManager.getRealValue("redirecturl"),refreshtoken=RestAPIConfManager.getRealValue("refreshtoken");


	public static void initiate()
	{
		if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
		{
			screenname=RestAPIConfManager.getRealValue("idc_screenname");
			chatid=RestAPIConfManager.getRealValue("idc_chat_id");
			viewid=RestAPIConfManager.getRealValue("idc_viewid");
			attachmenturl=RestAPIConfManager.getRealValue("idc_attachmenturl");
			emailid=RestAPIConfManager.getRealValue("idc_emailid");
			widgetcode=RestAPIConfManager.getRealValue("idc_widgetcode");
			clientid=RestAPIConfManager.getRealValue("idc_clientid");
			clientsecret=RestAPIConfManager.getRealValue("idc_clientsecret");
			redirecturl=RestAPIConfManager.getRealValue("idc_redirecturl");
			refreshtoken=RestAPIConfManager.getRealValue("idc_refreshtoken");
		}
		else
		{
			screenname=RestAPIConfManager.getRealValue("screenname");
			chatid=RestAPIConfManager.getRealValue("chat_id");
			viewid=RestAPIConfManager.getRealValue("viewid");
			attachmenturl=RestAPIConfManager.getRealValue("attachmenturl");
			emailid=RestAPIConfManager.getRealValue("emailid");
			widgetcode=RestAPIConfManager.getRealValue("widgetcode");
			clientid=RestAPIConfManager.getRealValue("clientid");
			clientsecret=RestAPIConfManager.getRealValue("clientsecret");
			redirecturl=RestAPIConfManager.getRealValue("redirecturl");
			refreshtoken=RestAPIConfManager.getRealValue("refreshtoken");
		}
	}

	public static void clickSettings(WebDriver driver)
	{
		driver.findElement(By.id("myBtn")).click();
	}

	public static void configureAPI(WebDriver driver,Api api) throws Exception
	{
		configureAPI(driver,api.request_type);
	}

	public static void configureAPI(WebDriver driver,RequestType requestType) throws Exception
	{
		configureAPI(driver,requestType.name().toLowerCase());
	}

	public static void configureAPI(WebDriver driver,String request_type) throws Exception
	{
		String token_type="access";

		if(AccessTokenManager.isRegenerate(driver))
		{
			token_type="refresh";

		}

		configureAPI(driver,token_type,request_type);
	}

	public static void configureAPI(WebDriver driver,String tokenType,String requestType) throws Exception
	{
		chooseTokenType(driver,tokenType);
		chooseRequestType(driver,requestType);
	}

	public static void sendKeysToAPIInput(WebDriver driver,String api)
	{
		CommonUtil.getElement(driver,By.id("apiurl")).sendKeys(api);
	}

	public static void chooseTokenType(WebDriver driver,String tokenType) throws Exception
	{
		if(tokenType.contains("refresh"))
		{
			CommonUtil.elfinder(driver,"id","rtkn").click();
		}
		else if(tokenType.contains("access"))
		{
			CommonUtil.elfinder(driver,"id","atkn").click();
		}
	}

	public static void chooseRequestType(WebDriver driver,String requestType) throws Exception
	{
		if(requestType.contains("get"))
		{
			CommonUtil.elfinder(driver,"id","getchkbx").click();
		}
		else if(requestType.contains("post"))
		{
			CommonUtil.elfinder(driver,"id","postchkbx").click();
		}
		else if(requestType.contains("put"))
		{
			CommonUtil.getElement(driver,By.id("putchkbx")).click();
		}
		else if(requestType.contains("delete"))
		{
			CommonUtil.getElement(driver,By.id("deletechkbx")).click();
		}
	}

	public static void sendAPIRequest(WebDriver driver) throws Exception
	{
		//for managing expiring access tokens
		boolean is_refresh_token=isRefreshTokenModeSelected(driver);

		String old_access_token=null;

		if(is_refresh_token)
		{
			old_access_token=getAccessToken(driver);
		}

		//click action
		FluentWait wait = CommonUtil.waitreturner(driver, 10, 50);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("btnsub")));
		CommonUtil.elfinder(driver,"id","btnsub").click();

		//for managing expiring access tokens
		if(old_access_token!=null && is_refresh_token)
		{
			CommonUtil.waitTillWebElementDoesNotContainAttributeValue( CommonUtil.getElement(driver,By.id("tkn")) , "value" , old_access_token );
			AccessTokenManager.add(driver);
		}
	}

	public static boolean isRefreshTokenModeSelected(WebDriver driver)
	{
		String tokentype=com.zoho.livedesk.util.common.actions.ExecuteStatements.getRadioValue(driver,"tokentype");
		return tokentype.equals("R");
	}

	public static String getRawAPIResponse(WebDriver driver) throws Exception
	{
		//use in case response contains HTML
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver, 30, 50);
	        
	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.id("resp")).getText().contains("{") && driver.findElement(By.id("resp")).getText().contains("}"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });			
		}

		catch(Exception e)
		{
			e.printStackTrace();
			return "No Response Received.Submit button may not be clicked";
		}

		finally
		{

		}

	    return CommonUtil.elfinder(driver,"id","resp").getAttribute("innerHTML");
	}

	public static String getAPIResponse(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver, 30, 50);
	        
	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.id("resp")).getText().contains("{") && driver.findElement(By.id("resp")).getText().contains("}"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });			
		}

		catch(Exception e)
		{
			e.printStackTrace();
			return "No Response Recieved.Submit button may not be clicked";
		}

		finally
		{

		}

	    return CommonUtil.elfinder(driver,"id","resp").getText();


	}
	
	public static String customiseAPI(String api,String myViewid,String attachmenturl) throws Exception
	{

		if(ConfManager.getSetup().contains("localzoho"))
		{
	        api = api.replace("salesiq.zoho.com","salesiq.localzoho.com");
		}

		if(api.contains("<screenname>"))
		{
			api=api.replace("<screenname>",screenname);
		}
		if(api.contains("<chat_id>"))
		{
			api=api.replace("<chat_id>",chatid);
		}
		if(api.contains("<viewid>"))
		{
			api=api.replace("<viewid>",myViewid);
		}
		if(api.contains("<attachmenturl>"))
		{
			api=api.replace("<attachmenturl>",attachmenturl);
		}
		if(api.contains("<emailid>"))
		{
			api=api.replace("<emailid>",emailid);
		}
		if(api.contains("<widgetcode>"))
		{
			api=api.replace("<widgetcode>",widgetcode);
		}	

		return api;
	}

	public static String customiseAPI(String api,String myViewid) throws Exception
	{
		return customiseAPI(api,myViewid,"");		
	}

	public static String customiseAPI(String api) throws Exception
	{
		return customiseAPI(api,"-1","");
	}

	public static String addHeader(String api,String key,String value)
	{
		return addParam(api,"request_header_"+key,value);
	}

	public static String addParam(String api,String key,String value)
	{
		if(api.contains("?"))
		{
			api=api+"&";
		}

		else if(!api.contains("?"))
		{
			api=api+"?";
		}

	 	return api+key+"="+value;
	}

	public static String addPayloadToAPIString(String api,String payload)
	{
		return addParam(api,"json_payload",payload);
	}

	public static void addPayload(WebDriver driver,JSONObject payload_json)
	{
		addPayload(driver,payload_json.toString());
	}

	public static void addPayload(WebDriver driver,String payload_json)
	{
		CommonUtil.clickWebElement(driver,By.id("addparam"));
		CommonUtil.getElement(driver,By.className("paramkey")).sendKeys("json_payload");
		CommonUtil.getElement(driver,By.className("paramvalue")).sendKeys(payload_json);
	}

	public static String getTimeFromMilliseconds(WebDriver driver,long millis,boolean trimSeconds) throws Exception
	{
		String hour = ((JavascriptExecutor) driver).executeScript("return new Date("+millis+").getHours();")+"";
        String mins = ((JavascriptExecutor) driver).executeScript("return new Date("+millis+").getMinutes();")+"";
        String seconds = ((JavascriptExecutor) driver).executeScript("return new Date("+millis+").getSeconds();")+"";
        
        if(Integer.parseInt(hour) < 10)
        {
            hour = "0"+hour;
        }
        if(Integer.parseInt(mins) < 10)
        {
            mins = "0"+mins;
        }
        if(Integer.parseInt(seconds) < 10)
        {
            seconds = "0"+seconds;
        }
        
        String time = hour+":"+mins+":"+seconds;
        
        System.out.println("Time<><>"+time);

		return time;
	}

	public static String getTimeFromMilliseconds(WebDriver driver,long millis) throws Exception
	{
		return getTimeFromMilliseconds(driver,millis,false);
	}

	public static String getDurationFromMilliseconds(long millis)
	{
		String duration = String.format("%d mins %d secs", 
	    TimeUnit.MILLISECONDS.toMinutes(millis),
	    TimeUnit.MILLISECONDS.toSeconds(millis) - 
	    TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis))
		);

		duration=duration.replace("0 mins ","");

		return duration;		 
	}

	public static JSONObject convertToJSON(String str,ExtentTest etest) throws Exception
	{
		if(str.contains("{") && str.contains("}"))
		{
			JSONObject json;

			try
			{
				json = new JSONObject(str);	
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,"Unable to parse response as JSON.Invalid JSON response recieved");
				return null;
			}

			if(json.has("JSPServerResponse") && json.has("Error"))
			{
				etest.log(Status.FAIL,"Error in jsp file(Error:"+json.get("Error").toString()+")");

				return null;
			}

			return json;
		}

		else
		{
			return null;
		}
	}

	public static JSONObject convertToJSON(String str) throws Exception
	{
		return convertToJSON(str,SalesIQRestAPIModule.etest);
	}

	// public static boolean checkTimeInResponse(JSONObject data,String key,ExtentTest etest) throws Exception
	// {
			
	// 		long expected_value_long=t2m(RestAPIConfManager.getRealValue(key));
	// 		long actual_value_long=Long.parseLong(data.get(key).toString());

	// 		System.out.println("ACTUAL EXPECTED LONG "+actual_value_long+" "+expected_value_long);

	// 		if((actual_value_long>(expected_value_long-60000)) && (actual_value_long<(expected_value_long+60000)))
	// 		{
	// 			return true;
	// 		}
	// 		else
	// 		{
	// 			etest.log(Status.FAIL,"Expected response for key '"+key+"' not found.(Expected :"+expected_value_long+" Actual :"+actual_value_long+")");
	// 			return false;
	// 		}			
	// }

	public static boolean checkTimeInResponse(JSONObject data,String key,ExtentTest etest,WebDriver driver) throws Exception
	{
			String expected_value=RestAPIConfManager.getRealValue(key);

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				expected_value=RestAPIConfManager.getRealValue("idc_"+key);
			}

			long actual_value_long;
			String actual_value;

		 	actual_value_long=Long.parseLong(data.get(key).toString());

			if(key.contains("duration"))
			{
				actual_value=getDurationFromMilliseconds(actual_value_long);
			}
			else
			{
	 			actual_value=getTimeFromMilliseconds(driver,actual_value_long);
			}



	 		System.out.println("$$$$$$$$actualval "+actual_value);

			if(expected_value.contains(actual_value))
			{
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Expected response for key '"+key+"' not found.(Expected :"+expected_value+" Actual :"+actual_value+")");
				return false;
			}			
	}


	public static boolean checkResponse(JSONObject data,String key,ExtentTest etest) throws Exception
	{
			String expected_value=RestAPIConfManager.getRealValue(key);

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				expected_value=RestAPIConfManager.getRealValue("idc_"+key);
			}

			String actual_value=data.get(key).toString();

			if(actual_value.contains(expected_value))
			{
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Expected response for key '"+key+"' not found.(Expected :"+expected_value+" Actual :"+actual_value+")");
				return false;
			}			
	}



	public static boolean checkAPIResponse(WebDriver driver,JSONObject data,ExtentTest etest) throws Exception
	{
		int failcount=0;

		if(data.has("attender_email"))
		{
			if(!checkResponse(data,"attender_email",etest))
			{
				failcount++;
			}
		}

		if(data.has("question"))
		{
			if(!checkResponse(data,"question",etest))
			{
				failcount++;
			}
		}


		if(data.has("department_id"))
		{
			if(!checkResponse(data,"department_id",etest))
			{
				failcount++;
			}
		}

		if(data.has("department_name"))
		{
			if(!checkResponse(data,"department_name",etest))
			{
				failcount++;
			}
		}

		if(data.has("waited_duration"))
		{
			if(!checkTimeInResponse(data,"waited_duration",etest,driver))
			{
				failcount++;
			}
		}


		if(data.has("end_time"))
		{
			if(!checkTimeInResponse(data,"end_time",etest,driver))
			{
				failcount++;
			}
		}


		if(data.has("embed_name"))
		{
			if(!checkResponse(data,"embed_name",etest))
			{
				failcount++;
			}
		}


		if(data.has("attender_name"))
		{
			if(!checkResponse(data,"attender_name",etest))
			{
				failcount++;
			}
		}


		if(data.has("visitor_email"))
		{
			if(!checkResponse(data,"visitor_email",etest))
			{
				failcount++;
			}
		}


		if(data.has("visitor_name"))
		{
			if(!checkResponse(data,"visitor_name",etest))
			{
				failcount++;
			}
		}


		if(data.has("attender_id"))
		{
			if(!checkResponse(data,"attender_id",etest))
			{
				failcount++;
			}
		}


		if(data.has("chat_id"))
		{
			if(!checkResponse(data,"chat_id",etest))
			{
				failcount++;
			}
		}


		if(data.has("country_code"))
		{
			if(!checkResponse(data,"country_code",etest))
			{
				failcount++;
			}
		}


		if(data.has("chat_duration"))
		{
			if(!checkTimeInResponse(data,"chat_duration",etest,driver))
			{
				failcount++;
			}
		}


		if(data.has("embed_id"))
		{
			if(!checkResponse(data,"embed_id",etest))
			{
				failcount++;
			}
		}


		if(data.has("chatinitiated_time"))
		{
			if(!checkTimeInResponse(data,"chatinitiated_time",etest,driver))
			{
				failcount++;
			}
		}


		if(data.has("pickup_time"))
		{
			if(!checkTimeInResponse(data,"pickup_time",etest,driver))
			{
				failcount++;
			}
		}


		if(data.has("visitor_ip"))
		{
			if(!checkResponse(data,"visitor_ip",etest))
			{
				failcount++;
			}
		}


		if(data.has("participants"))
		{
			if(!checkResponse(data,"participants",etest))
			{
				failcount++;
			}
		}


		if(failcount!=0)
		{
			return false;
		}

		return true;

	}

	public static boolean checkJSONTranscript(WebDriver driver,JSONArray data,ExtentTest etest) throws Exception
	{
		int failcount=0;

		JSONObject questionJSON=data.getJSONObject(0);

		checkAPIResponse(driver,questionJSON,etest);

		for(int i=1;i<=6;i++)
		{
			if(!checkMessage(driver,data.getJSONObject(i),i,etest))
			{
				failcount++;
			}
		}

		return SalesIQRestAPIModule.returnResult(failcount);
	}

	public static boolean checkMessage(WebDriver driver,JSONObject msg,int index,ExtentTest etest) throws Exception
	{
		int failcount=0;

		String expected_time="",expected_dname="",expected_message="",expected_sender="";

		if(msg.has("sender"))
		{
			//check sender
			expected_sender=RestAPIConfManager.getRealValue("attender_id");

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				expected_sender=RestAPIConfManager.getRealValue("idc_attender_id");
			}

			if(msg.get("sender").toString().contains(expected_sender))
			{

			}
			else
			{
				etest.log(Status.FAIL,"sender mismatch(expected:"+expected_sender+" actual:"+msg.get("sender").toString()+")");
				failcount++;
			}

			expected_dname=RestAPIConfManager.getRealValue("attender_name");

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				expected_dname=RestAPIConfManager.getRealValue("idc_attender_name");
			}
		}

		else
		{
			expected_dname=RestAPIConfManager.getRealValue("visitor_name");			

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				expected_dname=RestAPIConfManager.getRealValue("idc_visitor_name");
			}
		}

		//time,dname,sender message			
		expected_time=RestAPIConfManager.getRealValue("apicttime"+index);
		expected_message=RestAPIConfManager.getRealValue("apictmsg"+index);

		if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
		{
			expected_time=RestAPIConfManager.getRealValue("idc_apicttime"+index);
			expected_message=RestAPIConfManager.getRealValue("idc_apictmsg"+index);
		}

		System.out.println("MSG##$$$$<><>   "+msg);

		if(msg.get("dname").toString().contains(expected_dname))
		{

		}
		else
		{
			etest.log(Status.FAIL,"dname mismatch(expected:"+expected_dname+" actual:"+msg.get("dname").toString()+")");						
			failcount++;		
		}

		if(msg.get("msg").toString().contains(expected_message))
		{

		}
		else
		{
			etest.log(Status.FAIL,"msg mismatch(expected:"+expected_message+" actual:"+msg.get("msg").toString()+")");						
			failcount++;
		}

		String actual_time=getTimeFromMilliseconds(driver,(Long.parseLong(msg.get("time").toString())),true);

		if(actual_time.contains(expected_time))
		{

		}
		else
		{
			etest.log(Status.FAIL,"time mismatch(expected:"+expected_time+" actual:"+actual_time+")");
			failcount++;
		}			

		return SalesIQRestAPIModule.returnResult(failcount);
	}

	public static boolean checkVisitorDetails(WebDriver driver,JSONObject visitor,int index,ExtentTest etest) throws Exception
	{
		int failcount=0;

		System.out.println(visitor.toString());

		String[] keys = {"country","lastvisit_source"};

		for(int i=0;i<keys.length;i++)
		{
			System.out.println("KEYS "+visitor.get(keys[i]).toString());

			String expectedValue = RestAPIConfManager.getRealValue(keys[i]+index);

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				expectedValue = RestAPIConfManager.getRealValue("idc_"+keys[i]+index);
			}

			if(visitor.get(keys[i]).toString().contains(expectedValue))
			{

			}
			else
			{
				etest.log(Status.FAIL,keys[i]+" mismatch(expected:"+expectedValue+" actual:"+visitor.get(keys[i]).toString()+")");	
				failcount++;					
			}
		}

		if(visitor.get("total_timespent").toString()==null)
		{
			etest.log(Status.FAIL,"total_timespent key was found as null");
			failcount++;
		}

		return SalesIQRestAPIModule.returnResult(failcount);

	}

	public static String getStartKey(JSONObject response) throws Exception
	{
		if(response.getJSONObject("data").has("startkey"))
		{
			return response.getJSONObject("data").get("startkey").toString();
		}
		else
		{
			return null;
		}
	}

	public static JSONObject getJSONObjectByMailId(JSONArray visitorlist,int index) throws Exception
	{
		String mail="";

		for(int i=0;i<visitorlist.length();i++)
		{
			if(visitorlist.getJSONObject(i).has("email"))
			{
				System.out.println("SEARCH FOR VISITOR "+visitorlist.getJSONObject(i).toString());

				if(visitorlist.getJSONObject(i).get("lastvisit_source").toString().contains("Direct"))
				{
					return visitorlist.getJSONObject(i);
				}
			}
		}

		return null;
	}

	public static JSONObject getJSONObjectByMailId(JSONArray visitorlist,String mail) throws Exception
	{
		for(int i=0;i<visitorlist.length();i++)
		{
			if(visitorlist.getJSONObject(i).has("email"))
			{
				System.out.println("SEARCH FOR VISITOR "+visitorlist.getJSONObject(i).toString());

				if(visitorlist.getJSONObject(i).get("email").toString().contains(mail))
				{
					return visitorlist.getJSONObject(i);
				}
			}
		}

		return null;
	}


	public static boolean checkPostUpdate(JSONArray visitorlist,String mail,String key,String value)
	{
		try
		{
			System.out.println(key+" VALUE FOUND FOR CHECK POST "+getJSONObjectByMailId(visitorlist,mail).getJSONObject("customer_info").get(key).toString());

			return	getJSONObjectByMailId(visitorlist,mail).getJSONObject("customer_info").get(key).toString().contains(value);
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static boolean checkResponseCodeOfURL(String validate_url) throws Exception
	{		
		URL url = new URL(validate_url);

		HttpURLConnection connection = (HttpURLConnection)url.openConnection();

	    connection.addRequestProperty("User-Agent", "Safari");

		connection.setRequestMethod("GET");

		connection.connect();

		int code = connection.getResponseCode();

		System.out.println("URL "+validate_url+" code "+code);

		if(code==200)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public static boolean checkAuthorisationError(JSONObject errorJSON,String expected_message) throws Exception
	{
		if(getErrorMessage(errorJSON).equals(expected_message))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static String getErrorMessage(JSONObject json) throws Exception
	{
		return json.getJSONObject("error").get("message").toString();
	}

	public static boolean checkErrorJSON(String response,String expected_error_code,String expected_error_message,ExtentTest etest) throws Exception
	{
		int failcount=0;

		if(expected_error_code==null && expected_error_message==null)
		{
			if(isKeyFound(response,JPaths.ERROR_CODE)==false)
			{
				etest.log(Status.PASS,"Error code response was not found for API");
			}
			else
			{
				etest.log(Status.FAIL,"Error code response was found for API");	
				failcount++;			
			}

			if(isKeyFound(response,JPaths.ERROR_MESSAGE)==false)
			{
				etest.log(Status.PASS,"Error message was not found in response for API");
			}
			else
			{
				etest.log(Status.FAIL,"Error message was found in response for API");	
				failcount++;			
			}
		}

		if(expected_error_code!=null && CommonUtil.checkStringContainsAndLog(expected_error_code,SalesIQRestAPICommonFunctions.jPath(response,JPaths.ERROR_CODE),"error code",etest)==false)
		{
			failcount++;
		}
		if(expected_error_message!=null && CommonUtil.checkStringContainsAndLog(expected_error_message,SalesIQRestAPICommonFunctions.jPath(response,JPaths.ERROR_MESSAGE),"error message",etest)==false)
		{
			failcount++;
		}
		
		return CommonUtil.returnResult(failcount);
	}

	public static String corruptAPI(String api,String msg) throws Exception
	{
			String[] expected_message={"Unknown authentication error, Contact SalesIQ Team!","Invalid Request Type","Invalid OAuthToken","Invalid portal or wrong screenname","Invalid URL"};
		
			if(msg.contains("Invalid URL"))
			{
				api=api+"///";
			}

			else if(msg.contains("Invalid portal or wrong screenname"))
			{
				api=api.replace("<screenname>","afldsjfsdipfusdaop");
			}

			api=customiseAPI(api);	

			if(api.contains("visitorsbyemail"))
			{
				String customeInfoKey="KEY_"+SalesIQRestAPIModule.getUniqueMessage();
				String customeInfoValue="VALUE"+SalesIQRestAPIModule.getUniqueMessage();
				String postObject="{'"+customeInfoKey+"':'"+customeInfoValue+"'}";				
				api=SalesIQRestAPICommonFunctions.addParam(api,"customerinfo",postObject);				
			}


			return api;			
	}

	public static void configureCorruptAPI(WebDriver driver,String api,String msg,String accessToken) throws Exception
	{
		if(msg.contains("Invalid Request Type") && !api.contains("visitorsbyemail"))
		{
			chooseRequestType(driver,"post");			
		}

		else if(msg.contains("Invalid Request Type") && api.contains("visitorsbyemail"))
		{
			chooseRequestType(driver,"post");
		}

		else if(api.contains("visitorsbyemail"))
		{
			chooseRequestType(driver,"post");
		}

		else if(!api.contains("visitorsbyemail"))
		{
			chooseRequestType(driver,"get");
			System.out.println("API "+api);			
		}		

		if(msg.contains("Invalid OAuthToken") || msg.contains("Unknown authentication error"))
		{
			chooseTokenType(driver,"access");
			String token=msg.contains("Invalid OAuthToken")?"1000.5bdb518bf0dcadeaffdfb6f72ba5ddeb.c4196549d95024400ae0630dcbec43a0":"12(^#3276";
			driver.findElement(By.id("tkn")).clear();	
			driver.findElement(By.id("tkn")).sendKeys(token);
			System.out.println("MSG "+msg);
		}
		else
		{
			chooseTokenType(driver,"access");
			driver.findElement(By.id("tkn")).clear();	
			driver.findElement(By.id("tkn")).sendKeys(accessToken);
		}

	}

	//start new code
	public static boolean isAllStringInArrayPresentInJSONArray(JSONArray json_array,String[] expected_strings,String json_array_description,ExtentTest test) throws Exception
	{

		for(int i=0;i<expected_strings.length;i++)
		{
			if(!isStringPresentInJSONArray(json_array,expected_strings[i]))
			{
				test.log(Status.FAIL,"Expected  '"+expected_strings[i]+"' to be found in "+json_array_description+". But It could not be found.");
				return false;
			}
		}

		return true;
	}

	public static boolean isStringPresentInJSONArray(JSONArray json_array,String expected_string) throws Exception
	{
		
		String found_string="";

		for(int i=0;i<json_array.length();i++)
		{

			found_string=json_array.get(i).toString();

			if(expected_string.equals(found_string))
			{
				return true;
			}
		}

		return false;
	}

	//end new code

	public static void setAuth(WebDriver driver,String clientid,String clientsecret,String redirecturl,String refreshtoken) throws Exception
	{

		FluentWait wait = CommonUtil.waitreturner(driver, 10, 50);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("myModal")).isDisplayed())
                {
                    return true;
                }
                return false;
            }
        });

        try
        {
        	CommonWait.waitTillDisplayed(driver,By.id("myModal"));
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }

        CommonUtil.sendKeysToWebElement(driver, driver.findElement(By.id("cid")) ,clientid);
        CommonUtil.sendKeysToWebElement(driver, driver.findElement(By.id("csecret")) ,clientsecret);
        CommonUtil.sendKeysToWebElement(driver, driver.findElement(By.id("redirecturl")) ,redirecturl);
        CommonUtil.sendKeysToWebElement(driver, driver.findElement(By.id("refreshtoken")) ,refreshtoken);

        etest=ComplexReportFactory.getTest("RESTAPI settings screenshots");
        ComplexReportFactory.setValues(etest,"Automation","Issues");
        log(driver,etest);
        ComplexReportFactory.closeTest(etest);

		Thread.sleep(50);

		driver.findElement(By.id("ok")).click();

		Thread.sleep(50);
	}

	public static void setAuth(WebDriver driver) throws Exception
	{
		setAuth(driver,clientid,clientsecret,redirecturl,refreshtoken);
	}

	public static String getRequestTypeFromUI(WebDriver driver)
	{
		try
		{
	        return (((JavascriptExecutor) driver).executeScript("return document.querySelector('input[name='requesttype']:checked').value;")).toString();
		}
		catch(Exception e)
		{

		}

		return "";
	}

	public static boolean isKeysFound(ExtentTest etest,String json_string,String[] jPaths)
	{
		int failcount=0;

		for(String jPath : jPaths)
		{
			if(!isKeyFound(etest,json_string,jPath))
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isKeyFound(ExtentTest etest,String json_string,String jPath)
	{
		if(isKeyFound(json_string,jPath))
		{
			etest.log(Status.PASS,"Expected key '"+jPath+"' was found in response");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Expected key '"+jPath+"' was NOT found in response");
			log(etest,json_string);
			return false;
		}
	}

	public static boolean isKeyFound(String json_string,String jPath)
	{
		try
		{
			return (jPath(json_string,jPath)!=null);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	public static String jPath(String json_string,String jPath) throws Exception
	{
		return com.zoho.livedesk.util.common.ZohoMailAPIUtil.jPath(json_string,jPath);
	}

	public static JSONObject getJSONWith(JSONArray json_array,String key,String value) throws JSONException
	{
		for(int i=0;i<json_array.length();i++)
		{
			JSONObject json=json_array.getJSONObject(i);

			if(json.has(key) && json.get(key).equals(value))
			{
				return json;
			}
		}

		return null;
	}

	public static int getJSONIndexWith(JSONArray json_array,String key,String value) throws JSONException
	{
		for(int i=0;i<json_array.length();i++)
		{
			JSONObject json=json_array.getJSONObject(i);

			if(json.has(key) && json.get(key).equals(value))
			{
				return i;
			}
		}

		return -1;
	}

	public static JSONArray getArray(String json_string,String jPath) throws Exception
	{
		String last_json_key=jPath.split("/")[ jPath.split("/").length-1 ];
		String array_jpath = jPath.replace( "/"+last_json_key, "" );

		JSONObject json=null;

		if(array_jpath.equals(jPath))
		{
			json=new JSONObject(json_string);
		}
		else
		{
			json=new JSONObject(jPath(json_string,array_jpath));
		}

		return json.getJSONArray(last_json_key);
	}

	public static void log(ExtentTest etest,JSONObject json)
	{
		log(etest,json.toString());
	}

	public static void log(ExtentTest etest,String json)
	{
        etest.log(Status.INFO,"JSON:<pre>"+json+"</pre>");
	}

	public static void log(WebDriver driver,ExtentTest etest)
	{
		WebElement settingsElement = CommonUtil.getElement(driver,By.id("myModal"),By.className("modal-body"));
		String cid = settingsElement.findElement(By.id("cid")).getAttribute("value");
		String csec = settingsElement.findElement(By.id("csecret")).getAttribute("value");
		String rdurl = settingsElement.findElement(By.id("redirecturl")).getAttribute("value");
		String rftkn = settingsElement.findElement(By.id("refreshtoken")).getAttribute("value");
		String accessToken = CommonUtil.getElement(driver,By.id("tkn")).getAttribute("value");
		if(accessToken.length() < 1)
		{
			accessToken = "NO_ACCESS_TOKEN_WAS_GENERATED";
		}
		String script = "function isAccessTokenChecked(){ return document.getElementById(\"atkn\").checked;}return isAccessTokenChecked();";
		Boolean isAccessTokenChecked = Boolean.valueOf((((JavascriptExecutor) driver).executeScript(script)).toString());
		etest.log(Status.INFO,"<pre><b>Credentials at this time </b><br>"+
				"<b style=\"color:green;\">Client id 	: </b> "+cid+"<br>"+
				"<b style=\"color:green;\">Client secret	: </b> "+csec+"<br>"+
				"<b style=\"color:green;\">Redirect url	: </b> "+rdurl+"<br>"+
				"<b style=\"color:green;\">Refresh token	: </b> "+rftkn+"<br>"+
				"<b style=\"color:green;\">Access token 	: </b> "+accessToken+"<br>"+
				"<b style=\"color:green;\">Current Token	: </b><b> "+((isAccessTokenChecked)?"ACCESS_TOKEN":"REFRESH_TOKEN")+"</b></pre>");
		TakeScreenshot.infoScreenshot(driver,etest);
	}

	public static String getAPIURL(String api)
	{
		return Util.siteNameout()+api;
	}

	public static void setAuth(WebDriver driver,String module,String agent,ExtentTest etest) throws Exception
	{
		etest.log(Status.INFO,"<i><b style=\"color:red;\">Checking from "+agent+"</b></i>");
		setAuth(driver,module);
	}

	public static void setAuth(WebDriver driver,String module) throws Exception
	{
		SalesIQRestAPICommonFunctions.clickSettings(driver);
		SalesIQRestAPICommonFunctions.setAuth(driver,RestAPICredentialManager.getRealValue(module+"_cid"),RestAPICredentialManager.getRealValue(module+"_csec"),RestAPICredentialManager.getRealValue(module+"_url"),RestAPICredentialManager.getRealValue(module+"_rtoken"));
	}

	public static String getRefreshToken(WebDriver driver)
	{
		return com.zoho.livedesk.util.common.actions.ExecuteStatements.get(driver,"document.getElementById('refreshtoken').value");
	}

	public static String getAccessToken(WebDriver driver)
	{
		return com.zoho.livedesk.util.common.actions.ExecuteStatements.get(driver,"document.getElementById('tkn').value");
	}

	public static String getJSONResponse(WebDriver api_webdriver,String portal_name,boolean isReplace,String replaceString,String replaceWith,Api api_obj,boolean isPayload,JSONObject payload,ExtentTest etest) throws Exception
	{
		String api=api_obj.get();
		api=api.replace("<"+APIKeys.SCREENNAME+">",portal_name);
		if(isReplace)
		{
			api=api.replace(replaceString,replaceWith);
		}
		api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
		configureAPI(api_webdriver,api_obj);
		sendKeysToAPIInput(api_webdriver,api);
		if(isPayload)
		{
			addPayload(api_webdriver,payload);
		}
		sendAPIRequest(api_webdriver);

		String response;
		int i = 0;
		do
		{
			response = getAPIResponse(api_webdriver);
		}while(response.contains("No Response") && (i++ < 3));
		etest.log(Status.INFO,"<pre>API "+api+"</pre>");
		etest.log(Status.INFO,"Below json is the response");
		SalesIQRestAPICommonFunctions.log(etest,response);

		return response;
	}

	public static boolean checkDataInResponse(String keyToCheck,JSONObject response,boolean isArray,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		JSONObject data;
		String actual_value;

		String[] keysToCheck = RestAPIConfManager.getRealValue(keyToCheck).split(",");
		String[] valuesToCheck = RestAPIConfManager.getRealValue(keyToCheck+"_values").split(",");

		if(isArray)
		{
			data = response.getJSONArray("data").getJSONObject(0);
		}
		else
		{
			data = response.getJSONObject("data");
		}


		for(int i = 0; i < keysToCheck.length; i++)
		{
			if(data.has(keysToCheck[i]))
			{
				actual_value=data.get(keysToCheck[i]).toString();

				if(actual_value.contains(valuesToCheck[i]))
				{
					etest.log(Status.PASS,"Expected response for key '"+keysToCheck[i]+"' was found.(Expected :"+valuesToCheck[i]+" Actual :"+actual_value+")");
				}
				else
				{
					etest.log(Status.FAIL,"Expected response for key '"+keysToCheck[i]+"' was not found.(Expected :"+valuesToCheck[i]+" Actual :"+actual_value+")");
					failcount++;
				}
			}
		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkOperatorAddedInUI(WebDriver driver,String email,ExtentTest etest) throws Exception
	{
		CommonUtil.sleep(10000);
		CommonUtil.refreshPage(driver);
		Tab.clickSettings(driver);
		WebElement elmt1 = driver.findElement(By.id("ulisttable"));
		List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

		for(WebElement elmt:elmts)
		{
			List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
			if((userdetails.get(2).getText()).equals(email))
			{
				etest.log(Status.INFO,"Operator was added");
	 			return true;
			}
		}
		etest.log(Status.INFO,"Operator was not added");
		return false;
	}

	public static boolean postAndReturnResult(int failcount,String key,ExtentTest etest)
	{
		try
		{
			if(CommonUtil.returnResult(failcount))
			{
				etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(key)+" -- checked</b>");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(key)+" -- failed</b>");
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	public static String getOperatorId(WebDriver driver,String email) throws Exception
	{
		String userid = "id not found";
		CommonUtil.refreshPage(driver);
		Tab.clickSettings(driver);
		for(int i = 0; i < 3; i++)
		{
			WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
			CommonWait.waitTillDisplayed(driver,By.id("ulisttable"));
			CommonWait.waitTillDisplayed(driver,By.className("list_cell"));
			for(WebElement elmt:elmts)
			{
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).contains(email))
				{
					userid = elmt.getAttribute("id");
					break;
				}
			}
			if(!userid.contains("not found"))
			{
				break;
			}
		}
		return userid;
	}

	public static void editAgentInfo(WebDriver driver,String agent,ExtentTest etest)
	{
		String
		firstname = "AutomationFN",
		lastname = "AutomationLN",
		knownas = "Automation",
		mobileno = "123456789",
		phoneno = "9788153433",
		street = "DLF IT park,Ramapuram",
		city = "Chennai",
		state = "TN",
		pincode = "612345",
		aboutme = "Described",
		timezone = "( GMT 4:0 ) Armenia Summer Time(Asia/Yerevan)",
		lcountry = "United Kingdom",
		country = "United Kingdom";
		String url;

		try
		{
			if(Util.siteNameout().contains("pre"))
			{
				url = "https://presalesiq.zoho.com/";
			}
			else if(Util.siteNameout().contains("local"))
			{
				url = "https://salesiq.localzoho.com/";
			}
			else
			{
				url = "https://salesiq.zoho.com/";
			}
			url += ExecuteStatements.getPortal(driver);
			JavascriptExecutor je = (JavascriptExecutor)driver;
			AgentsSettings.editData(driver,url,agent,"firstname",firstname,etest);
			AgentsSettings.editData(driver,url,agent,"lastname",lastname,etest);
			AgentsSettings.editData(driver,url,agent,"mobile",mobileno,etest);
			AgentsSettings.editData(driver,url,agent,"phone",phoneno,etest);
			AgentsSettings.editData(driver,url,agent,"street",street,etest);
			AgentsSettings.editData(driver,url,agent,"city",city,etest);
			AgentsSettings.editData(driver,url,agent,"state",state,etest);
			AgentsSettings.editData(driver,url,agent,"pincode",pincode,etest);
			AgentsSettings.editData(driver,url,agent,"aboutme",aboutme,etest);
			AgentsSettings.editDDConfig(driver,url,agent,"tzonedropdown_div","tzonedropdown_ddown",timezone,etest);
			AgentsSettings.editDDConfig(driver,url,agent,"countrydropdown_div","countrydropdown_ddown",lcountry,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,SalesIQRESTAPIModule2.MODULE_NAME,"Exception","Exception",e);
        }
	}

	public static boolean checkEditedDataInUI(WebDriver driver,String email,ExtentTest etest) throws Exception
	{
		String url;
		if(Util.siteNameout().contains("pre"))
		{
			url = "https://presalesiq.zoho.com/";
		}
		else if(Util.siteNameout().contains("local"))
		{
			url = "https://salesiq.localzoho.com/";
		}
		else
		{
			url = "https://salesiq.zoho.com/";
		}
		url += ExecuteStatements.getPortal(driver);
		String operator_id = getOperatorId(driver,email);
		email = (email.indexOf("_")!=-1) ? email.substring(0,email.indexOf("_")) + email.substring(email.indexOf("@")) : email;
		email = email.replace("@","").replace(".","");
		int failcount = 0;
		String values[] = RestAPIConfManager.getRealValue(email+"_values").split(",");
		String keyid[] = RestAPIConfManager.getRealValue(email).split(",");

		//click edit operator icon
		Tab.clickSettings(driver);
		CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id(operator_id),By.className("txtelips")));
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(operator_id),By.className("txtelips")));
		CommonUtil.sleep(1000);
		// CommonWait.waitTillDisplayed(driver,By.linkText(ResourceManager.getRealValue("settings_edit")));
		// CommonUtil.clickWebElement(driver,By.linkText(ResourceManager.getRealValue("settings_edit")));

		driver.get(url+"/index#setting/user/edit/"+operator_id);

		for(int i = 0; i < values.length; i++)
		{
			if(!values[i].equals(CommonUtil.getElement(driver,By.id(keyid[i])).getAttribute("value")))
			{
				CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id(keyid[i])));
				etest.log(Status.FAIL,"Mismatch content for the key "+keyid[i]);
				etest.log(Status.INFO,"Expected -- "+values[i]+"<br>Actual -- "+CommonUtil.getElement(driver,By.id(keyid[i])).getAttribute("value"));
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}
		}
		if(!CommonUtil.getElement(driver,By.id("countrydropdown_div")).getAttribute("title").contains("United Kingdom"))
		{
			CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id("countrydropdown_div")));
			etest.log(Status.INFO,"<pre>Expected -- United Kingdom<br>Actual -- "+driver.findElement(By.id("countrydropdown_div")).getAttribute("title"));
			TakeScreenshot.screenshot(driver,etest);
			failcount++;
		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkOperatorsDeletedInUI(WebDriver driver,String email,ExtentTest etest) throws Exception
	{
		CommonUtil.refreshPage(driver);
		Tab.clickSettings(driver);
		if(Cleanup.isBodyContains(driver,email))
		{
			etest.log(Status.INFO,"Operator("+email+") found");
			return false;
		}
		else
		{
			etest.log(Status.INFO,"Operator("+email+") not found");
			return true;
		}
	}

	public static boolean checkOperatorDisabled(WebDriver driver,String email,ExtentTest etest) throws Exception
	{
		Tab.clickSettings(driver);
		String operator_id = getOperatorId(driver,email);

		if((CommonUtil.getElement(driver,By.id(operator_id)).getAttribute("class")).contains("list_disable"))
		{
			etest.log(Status.INFO,"Operator("+email+") was disabled");
			return true;
		}
		else
		{
			etest.log(Status.INFO,"Operator("+email+") was not disabled");
			return false;
		}
	}

	public static String checkStatusOfOperator(WebDriver driver,String operator_id,String email,ExtentTest etest) throws Exception 
	{
		Tab.clickSettings(driver);

		if((CommonUtil.getElement(driver,By.id(operator_id),By.tagName("img")).getAttribute("class")).contains("ustatus_1"))
		{
			etest.log(Status.INFO,"Operator("+email+") status was Available");
			return "Available";
		}
		else if((CommonUtil.getElement(driver,By.id(operator_id),By.tagName("img")).getAttribute("class")).contains("ustatus_3"))
		{
			etest.log(Status.INFO,"Operator("+email+") status was Busy");
			return "Busy";
		}
		else
		{
			TakeScreenshot.screenshot(driver,etest);
			etest.log(Status.INFO,"Operator("+email+") status was unknown");
			return "unknown";
		}
	}

	public static void uploadImage(WebDriver driver,String operator_id,String email,ExtentTest etest) throws Exception
	{
		try
		{
			Tab.clickSettings(driver);
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(operator_id),By.className("txtelips")));
			CommonUtil.sleep(1000);
			CommonWait.waitTillDisplayed(driver,By.linkText(ResourceManager.getRealValue("settings_edit")));

			FileUpload.uploadFile(CommonUtil.getElement(driver,By.id("aphotoupload")),FileType.SMALL_IMAGE);

			CommonUtil.sleep(2000);

			CommonWait.waitTillDisplayed(driver,By.id("delprofphoto"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,SalesIQRESTAPIModule2.MODULE_NAME,"Exception","Exception",e);
		}
	}

	public static boolean checkOperatorImageDeleted(WebDriver driver,String operator_id,String email,ExtentTest etest) throws Exception
	{
		Tab.clickSettings(driver);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(operator_id),By.className("txtelips")));
		CommonUtil.sleep(1000);
		CommonWait.waitTillDisplayed(driver,By.linkText(ResourceManager.getRealValue("settings_edit")));

		if(CommonUtil.getElement(driver,By.className("myprfsubmn"),By.tagName("img")).getAttribute("src").contains("0_"))
		{
			etest.log(Status.INFO,"Operator("+email+")'s image was deleted");
			return true;
		}
		else
		{
			etest.log(Status.INFO,"Operator("+email+")'s image was not deleted");
			return false;
		}
	}

	public static boolean checkdepartmentAssociated(WebDriver driver,String operator_id,String dept,String email,ExtentTest etest) throws Exception 
	{
		String url = Util.siteNameout() + "/" + ExecuteStatements.getPortal(driver);
		Tab.clickSettings(driver);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id(operator_id),By.className("txtelips")));
		CommonUtil.sleep(1000);
		CommonWait.waitTillDisplayed(driver,By.linkText(ResourceManager.getRealValue("settings_edit")));

		driver.get(url+"/index#setting/user/edit/"+operator_id);

		CommonWait.waitTillDisplayed(driver,By.id("firstname"));

		if(!CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("seldepartment")).findElements(By.className("field_main")),"innerText",dept).getAttribute("class").contains("unsel_main"))
		{
			etest.log(Status.INFO,"Operator("+email+") was associated with the department");
			return true;
		}
		else
		{
			etest.log(Status.INFO,"Operator("+email+") was not associated with the department");
			return false;
		}
	}

	public static boolean checkAppFieldsApi(WebDriver api_webdriver,WebDriver driver,String response_code,boolean isReplace,String replaceString,String replaceWith,Api api_obj,String file_name,int startKey,ExtentTest etest) throws Exception
	{
		int failcount=0;

		boolean isResponse = (response_code == Constants.SUCCESS_CODE)?true:false;

		String keys_check_usecase = "RESTAPI" + startKey;

		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,replaceString,replaceWith,api_obj,false,null,etest);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(isResponse)
			{
				String fieldmaps_directory=FileUpload.getBuildRoot()+"/webapps/selenium/test_related_files/fieldMapsJSON/";

				JSONObject expected_json=new JSONObject(FileUpload.getFileAsString(fieldmaps_directory+file_name));


				String expected_json_string=expected_json.toString().trim().replaceAll("\\n","");
				String actual_json_string=json_response.toString().trim().replaceAll("\\n","");

				try
				{

					etest.log(Status.INFO,"NOW CHECKING FIELDMAPS RESPONSE");

					if(expected_json_string.equals(actual_json_string))
					{
						etest.log(Status.PASS,"Expected fieldmaps response was found.");
					}
					else
					{
						etest.log(Status.FAIL,"Expected fieldmaps response was NOT found.");
						etest.log(Status.FAIL,"Expected:"+expected_json.toString());
						etest.log(Status.FAIL,"Actual:"+json_response.toString());
						TakeScreenshot.screenshot(api_webdriver,etest);
						failcount++;
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
				}
			}
			else
			{
				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
				{
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
					failcount++;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}
}
