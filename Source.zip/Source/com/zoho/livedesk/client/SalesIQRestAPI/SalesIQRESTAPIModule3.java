//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.AgentsSettings;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.BuildRejector;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class SalesIQRESTAPIModule3
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Rest API";
	public static String portal_name = "";

	public static VisitorDriverManager visitor_driver_manager;

	public static WebDriver admin_driver;

	public static final int
	ADMIN=0,
	INVALID_SCOPE=1,
	SUPERVISOR=2,
	ASSOCIATE=3
	;

	public static final int
	GET_RULE=0,
	GET_RULES=1
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{

			Cleanup.deleteAllVisitorRouting(driver);
			Cleanup.deleteAllChatRouting(driver);
			Cleanup.deleteAllCallRouting(driver);
			Cleanup.deleteAllLeadscoring(driver);

			admin_driver = Functions.setUp();

			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

			WebDriver api_driver=Functions.setUp();
			api_driver.get(SalesIQRestAPIModule.APITesterURL);


			SalesIQRestAPICommonFunctions.setAuth(api_driver,"routing_admin");
			
			etest=ComplexReportFactory.getTest("Create Visitor Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createRoutingRuleAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,ADMIN,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Chat Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createRoutingRuleAPI(api_driver,driver,RoutingRule.CHAT_ROUTING,ADMIN,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Call Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createRoutingRuleAPI(api_driver,driver,RoutingRule.CALL_ROUTING,ADMIN,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Get Visitor Routing Rule API & Get Visitor Routing Rules API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getRoutingRuleAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Get Chat Routing Rule API & Get Chat Routing Rules API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getRoutingRuleAPI(api_driver,driver,RoutingRule.CHAT_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Get Call Routing Rule API & Get Call Routing Rules API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getRoutingRuleAPI(api_driver,driver,RoutingRule.CALL_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Visitor Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateRoutingRuleAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Chat Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateRoutingRuleAPI(api_driver,driver,RoutingRule.CHAT_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Call Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateRoutingRuleAPI(api_driver,driver,RoutingRule.CALL_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Visitor Routing Rule Status API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateRoutingStatusRuleAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Chat Routing Rule Status API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateRoutingStatusRuleAPI(api_driver,driver,RoutingRule.CHAT_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);
            
			etest=ComplexReportFactory.getTest("Update Call Routing Rule Status API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateRoutingStatusRuleAPI(api_driver,driver,RoutingRule.CALL_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Delete Visitor Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteRoutingRuleAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Delete Chat Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteRoutingRuleAPI(api_driver,driver,RoutingRule.CHAT_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Delete Call Routing Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteRoutingRuleAPI(api_driver,driver,RoutingRule.CALL_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Visitor Routing - Route to all config API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			routingConfigCommonRuleAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Visitor Routing - Update position API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updatePositionAPI(api_driver,driver,RoutingRule.VISITOR_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Chat Routing - Update position API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updatePositionAPI(api_driver,driver,RoutingRule.CHAT_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Call Routing - Update position API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updatePositionAPI(api_driver,driver,RoutingRule.CALL_ROUTING,etest);
            ComplexReportFactory.closeTest(etest);
            
			etest=ComplexReportFactory.getTest("Leadscoring - Create rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createLeadscoringRuleAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Leadscoring - get rule and get rules API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getLeadscoringRuleAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Leadscoring - update rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateLeadscoringRuleAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Leadscoring - enable/disable rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateLeadscoringRuleStatusAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Leadscoring - delete rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteLeadscoringRuleStatusAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Leadscoring - config set and get APIs");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			leadscoringConfigAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI269"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			boolean test_outcome=fieldMapsAPI(api_driver,driver,etest,Api.VISITOR_ROUTING_FIELDMAPS);
			result.put("RESTAPI269",test_outcome);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI270"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			test_outcome=fieldMapsAPI(api_driver,driver,etest,Api.CHAT_ROUTING_FIELDMAPS);
			result.put("RESTAPI270",test_outcome);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI271"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			test_outcome=fieldMapsAPI(api_driver,driver,etest,Api.CALL_ROUTING_FIELDMAPS);
			result.put("RESTAPI271",test_outcome);
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI272"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			test_outcome=fieldMapsAPI(api_driver,driver,etest,Api.LEADSCORING_FIELDMAPS);
			result.put("RESTAPI272",test_outcome);
			ComplexReportFactory.closeTest(etest);

            Api[] apis=new Api[]
            {

        	Api.VISITOR_ROUTING_CREATE,Api.VISITOR_ROUTING_GET_LIST,Api.VISITOR_ROUTING_GET,Api.VISITOR_ROUTING_UPDATE,Api.VISITOR_ROUTING_UPDATE,Api.VISITOR_ROUTING_UPDATE,Api.VISITOR_ROUTING_DELETE,Api.VISITOR_ROUTING_COMMON_RULE_GET,Api.VISITOR_ROUTING_COMMON_RULE_SET,

        	Api.CHAT_ROUTING_CREATE,Api.CHAT_ROUTING_GET_LIST,Api.CHAT_ROUTING_GET,Api.CHAT_ROUTING_UPDATE,Api.CHAT_ROUTING_UPDATE,Api.CHAT_ROUTING_UPDATE,Api.CHAT_ROUTING_DELETE,

        	Api.CALL_ROUTING_CREATE,Api.CALL_ROUTING_GET_LIST,Api.CALL_ROUTING_GET,Api.CALL_ROUTING_UPDATE,Api.CALL_ROUTING_UPDATE,Api.CALL_ROUTING_UPDATE,Api.CALL_ROUTING_DELETE,

        	Api.LEADSCORING_CREATE,Api.LEADSCORING_GET_LIST,Api.LEADSCORING_GET,Api.LEADSCORING_UPDATE,Api.LEADSCORING_UPDATE,Api.LEADSCORING_DELETE,Api.LEADSCORING_CONFIG_SET,Api.LEADSCORING_CONFIG_GET
			
			};

            String[] api_types=
            {
        	
        	null,null,null,null,"status","position",null,null,null,
        	
        	null,null,null,null,"status","position",null,
        	
        	null,null,null,null,"status","position",null,
        	
        	null,null,null,null,"status",null,null,null
        	
        	};

            String[] invalid_scope_usecases=
            {
        	
        	"RESTAPI280","RESTAPI281","RESTAPI282","RESTAPI285","RESTAPI286","RESTAPI287","RESTAPI290","RESTAPI291","RESTAPI292",
        	
        	"RESTAPI295","RESTAPI296","RESTAPI297","RESTAPI300","RESTAPI301","RESTAPI302","RESTAPI305",
        	
        	"RESTAPI306","RESTAPI307","RESTAPI311","RESTAPI312","RESTAPI313","RESTAPI317","RESTAPI318",
        	
        	"RESTAPI319","RESTAPI323","RESTAPI324","RESTAPI325","RESTAPI361","RESTAPI362","RESTAPI363","RESTAPI366"
        	
        	};

            String[] supervisor_usecases=
            {
        	
        	"RESTAPI367","RESTAPI368","RESTAPI372","RESTAPI373","RESTAPI374","RESTAPI384","RESTAPI385","RESTAPI386","RESTAPI387",
        	
        	"RESTAPI388","RESTAPI389","RESTAPI390","RESTAPI391","RESTAPI392","RESTAPI393","RESTAPI394",
        	
        	"RESTAPI395","RESTAPI396","RESTAPI397","RESTAPI398","RESTAPI399","RESTAPI400","RESTAPI401",
        	
        	"RESTAPI402","RESTAPI403","RESTAPI404","RESTAPI405","RESTAPI406","RESTAPI407","RESTAPI408","RESTAPI409"
        	
        	};

            String[] associate_usecases=
            {
        	
        	"RESTAPI410","RESTAPI411","RESTAPI412","RESTAPI413","RESTAPI414","RESTAPI415","RESTAPI416","RESTAPI417","RESTAPI418",
        	
        	"RESTAPI419","RESTAPI420","RESTAPI421","RESTAPI422","RESTAPI423","RESTAPI424","RESTAPI425",
        	
        	"RESTAPI426","RESTAPI427","RESTAPI428","RESTAPI429","RESTAPI430","RESTAPI431","RESTAPI432",
        	
        	"RESTAPI433","RESTAPI434","RESTAPI435","RESTAPI273","RESTAPI274","RESTAPI275","RESTAPI276","RESTAPI277"
        	
        	};

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"inval");

        	for(int i=0;i<api_types.length;i++)
        	{
        		String api_type=api_types[i];
        		Api api=apis[i];
        		String usecase=invalid_scope_usecases[i];

				etest=ComplexReportFactory.getTest("Invalid Scope-Checking error code for API "+api.toString()+(api_type==null?"":" -- "+ api_type) );
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				test_outcome=errorCodeCheck(api_driver,driver,etest,api,api_type,Constants.INVALID_SCOPE_ERROR_CODE,Constants.INVALID_SCOPE_ERROR_MESSAGE);
				result.put(usecase,test_outcome);
				ComplexReportFactory.closeTest(etest);
        	}

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"routing_supervisor");

        	for(int i=0;i<api_types.length;i++)
        	{
        		String api_type=api_types[i];
        		Api api=apis[i];
        		String usecase=supervisor_usecases[i];

				etest=ComplexReportFactory.getTest("Invalid Role-Supervisor-Checking error code for API "+api.toString()+(api_type==null?"":" -- "+ api_type) );
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				test_outcome=errorCodeCheck(api_driver,driver,etest,api,api_type,Constants.PERMISSION_ERROR_CODE,Constants.PERMISSION_ERROR_MESSAGE);
				result.put(usecase,test_outcome);
				ComplexReportFactory.closeTest(etest);
        	}

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"routing_associate");

        	for(int i=0;i<api_types.length;i++)
        	{
        		String api_type=api_types[i];
        		Api api=apis[i];
        		String usecase=associate_usecases[i];

				etest=ComplexReportFactory.getTest("Invalid Role-Associate-Checking error code for API "+api.toString()+(api_type==null?"":" -- "+ api_type) );
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				test_outcome=errorCodeCheck(api_driver,driver,etest,api,api_type,Constants.PERMISSION_ERROR_CODE,Constants.PERMISSION_ERROR_MESSAGE);
				result.put(usecase,test_outcome);
				ComplexReportFactory.closeTest(etest);
        	}
        
            Driver.quitDriver(api_driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void createRoutingRuleAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,int usecase_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_rule_api=null;

			String keys_check_usecase=null,api_values_usecase=null,ui_values_usecase=null,invalid_scope_check_usecase=null,supervisor_check_usecase=null,associate_check_usecase=null;

			String
			replied_count=null,
			triggered_count=null,
			routed_count=null,
			connected_count=null,
			transfered_count=null,
			missed_count=null,
			requested_count=null,
			attended_count=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				create_rule_api=Api.VISITOR_ROUTING_CREATE;

				keys_check_usecase="RESTAPI260";
				api_values_usecase="RESTAPI261";
				ui_values_usecase="RESTAPI262";

				invalid_scope_check_usecase="RESTAPI269";
				supervisor_check_usecase="RESTAPI270";
				associate_check_usecase="RESTAPI271";

				replied_count="0";
				triggered_count="0";
				routed_count="0";
			}
			else if(rule_type==RoutingRule.CHAT_ROUTING)
			{
				create_rule_api=Api.CHAT_ROUTING_CREATE;

				keys_check_usecase="RESTAPI263";
				api_values_usecase="RESTAPI264";
				ui_values_usecase="RESTAPI265";

				invalid_scope_check_usecase="RESTAPI272";
				supervisor_check_usecase="RESTAPI273";
				associate_check_usecase="RESTAPI274";

				connected_count="0";
				transfered_count="0";
				missed_count="0";
				requested_count="0";
			}
			else if(rule_type==RoutingRule.CALL_ROUTING)
			{
				create_rule_api=Api.CALL_ROUTING_CREATE;

				keys_check_usecase="RESTAPI266";
				api_values_usecase="RESTAPI267";
				ui_values_usecase="RESTAPI268";

				invalid_scope_check_usecase="RESTAPI275";
				supervisor_check_usecase="RESTAPI276";
				associate_check_usecase="RESTAPI277";

				routed_count="0";
				missed_count="0";
				attended_count="0";
			}


			String api=create_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));


			String website_name=ExecuteStatements.getDefaultEmbedName(driver);
			String app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentID(driver,department);
			String operator_id=ExecuteStatements.getOperatorId(driver);
			String campaign_medium_value="campaign"+label;
			String title="title"+label;
			String routing_type=Constants.ROUTE_TO_SELECTED_USERS;
			String dynamic_users=Constants.LAST_ATTENDER;

			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(usecase_type==INVALID_SCOPE)
			{
				result.put(invalid_scope_check_usecase,SalesIQRestAPICommonFunctions.checkErrorJSON(response,Constants.INVALID_SCOPE_ERROR_CODE,Constants.INVALID_SCOPE_ERROR_MESSAGE,etest));
				return;
			}
			else if(usecase_type==SUPERVISOR)
			{
				result.put(supervisor_check_usecase,SalesIQRestAPICommonFunctions.checkErrorJSON(response,Constants.PERMISSION_ERROR_CODE,Constants.PERMISSION_ERROR_MESSAGE,etest));
				return;
			}
			else if(usecase_type==ASSOCIATE)
			{
				result.put(associate_check_usecase,SalesIQRestAPICommonFunctions.checkErrorJSON(response,Constants.PERMISSION_ERROR_CODE,Constants.PERMISSION_ERROR_MESSAGE,etest));
				return;
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(api_values_usecase,isRuleValuesFoundInResponse(driver,etest,GET_RULE,response,null,title,replied_count,triggered_count,routed_count,connected_count,transfered_count,missed_count,requested_count,attended_count,Constants.ATLEAST_ONE_ONLINE,null,Constants.TRUE,"-1",app_id,routing_type,operator_id,department_id,dynamic_users,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
				result.put(ui_values_usecase,isRuleValuesFoundInUI(driver,etest,rule_type,ruleid,title,replied_count,triggered_count,routed_count,connected_count,transfered_count,missed_count,requested_count,attended_count,Constants.ENABLED,website_name,routing_type,operator_id,department_id,dynamic_users,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void getRoutingRuleAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_rule_api=null;
			Api get_rule_api=null;
			Api get_rules_api=null;

			String get_rule_keys_check_usecase=null,get_rule_api_values_usecase=null;

			String get_rules_keys_check_usecase=null,get_rules_api_values_usecase=null;

			String
			replied_count=null,
			triggered_count=null,
			routed_count=null,
			connected_count=null,
			transfered_count=null,
			missed_count=null,
			requested_count=null,
			attended_count=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				create_rule_api=Api.VISITOR_ROUTING_CREATE;
				get_rule_api=Api.VISITOR_ROUTING_GET;
				get_rules_api=Api.VISITOR_ROUTING_GET_LIST;

				get_rule_keys_check_usecase="RESTAPI278";
				get_rule_api_values_usecase="RESTAPI279";

				get_rules_keys_check_usecase="RESTAPI293";
				get_rules_api_values_usecase="RESTAPI294";

				replied_count="0";
				triggered_count="0";
				routed_count="0";
			}
			else if(rule_type==RoutingRule.CHAT_ROUTING)
			{
				create_rule_api=Api.CHAT_ROUTING_CREATE;
				get_rule_api=Api.CHAT_ROUTING_GET;
				get_rules_api=Api.CHAT_ROUTING_GET_LIST;

				get_rule_keys_check_usecase="RESTAPI283";
				get_rule_api_values_usecase="RESTAPI284";

				get_rules_keys_check_usecase="RESTAPI298";
				get_rules_api_values_usecase="RESTAPI299";

				connected_count="0";
				transfered_count="0";
				missed_count="0";
				requested_count="0";
			}
			else if(rule_type==RoutingRule.CALL_ROUTING)
			{
				create_rule_api=Api.CALL_ROUTING_CREATE;
				get_rule_api=Api.CALL_ROUTING_GET;
				get_rules_api=Api.CALL_ROUTING_GET_LIST;

				get_rule_keys_check_usecase="RESTAPI288";
				get_rule_api_values_usecase="RESTAPI289";

				get_rules_keys_check_usecase="RESTAPI303";
				get_rules_api_values_usecase="RESTAPI304";

				routed_count="0";
				missed_count="0";
				attended_count="0";
			}

			//CREATE THE RULE API
			String api=create_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String website_name=ExecuteStatements.getDefaultEmbedName(driver);
			String app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentID(driver,department);
			String operator_id=ExecuteStatements.getOperatorId(driver);
			String campaign_medium_value="campaign"+label;
			String title="title"+label;
			String routing_type=Constants.ROUTE_TO_SELECTED_USERS;
			String dynamic_users=Constants.LAST_ATTENDER;

			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to get this rule using get rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
			//GET THE RULE API
			api=get_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(get_rule_keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(get_rule_api_values_usecase,isRuleValuesFoundInResponse(driver,etest,GET_RULE,response,null,title,replied_count,triggered_count,routed_count,connected_count,transfered_count,missed_count,requested_count,attended_count,Constants.ATLEAST_ONE_ONLINE,null,Constants.TRUE,"-1",app_id,routing_type,operator_id,department_id,dynamic_users,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//GET THE RULES API
			api=get_rules_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_rules_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(get_rules_keys_check_usecase,isKeysFoundForGetRulesAPI(etest,response,get_rules_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(get_rules_api_values_usecase,isRuleValuesFoundInResponse(driver,etest,GET_RULES,response,ruleid,title,replied_count,triggered_count,routed_count,connected_count,transfered_count,missed_count,requested_count,attended_count,Constants.ATLEAST_ONE_ONLINE,null,Constants.TRUE,"-1",app_id,routing_type,operator_id,department_id,dynamic_users,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//update rule
	public static void updateRoutingRuleAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_rule_api=null;
			Api update_rule_api=null;

			String update_rule_keys_check_usecase=null,update_rule_api_values_usecase=null,update_rule_ui_values_usecase=null;

			String
			replied_count=null,
			triggered_count=null,
			routed_count=null,
			connected_count=null,
			transfered_count=null,
			missed_count=null,
			requested_count=null,
			attended_count=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				create_rule_api=Api.VISITOR_ROUTING_CREATE;
				update_rule_api=Api.VISITOR_ROUTING_UPDATE;

				update_rule_keys_check_usecase="RESTAPI308";
				update_rule_api_values_usecase="RESTAPI309";
				update_rule_ui_values_usecase="RESTAPI310";

				replied_count="0";
				triggered_count="0";
				routed_count="0";
			}
			else if(rule_type==RoutingRule.CHAT_ROUTING)
			{
				create_rule_api=Api.CHAT_ROUTING_CREATE;
				update_rule_api=Api.CHAT_ROUTING_UPDATE;

				update_rule_keys_check_usecase="RESTAPI314";
				update_rule_api_values_usecase="RESTAPI315";
				update_rule_ui_values_usecase="RESTAPI316";

				connected_count="0";
				transfered_count="0";
				missed_count="0";
				requested_count="0";
			}
			else if(rule_type==RoutingRule.CALL_ROUTING)
			{
				create_rule_api=Api.CALL_ROUTING_CREATE;
				update_rule_api=Api.CALL_ROUTING_UPDATE;

				update_rule_keys_check_usecase="RESTAPI320";
				update_rule_api_values_usecase="RESTAPI321";
				update_rule_ui_values_usecase="RESTAPI322";

				routed_count="0";
				missed_count="0";
				attended_count="0";
			}

			//CREATE THE RULE API
			String api=create_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String website_name=ExecuteStatements.getDefaultEmbedName(driver);
			String app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentID(driver,department);
			String operator_id=ExecuteStatements.getOperatorId(driver);
			String campaign_medium_value="campaign"+label;
			String title="title"+label;
			String routing_type=Constants.ROUTE_TO_SELECTED_USERS;
			String dynamic_users=Constants.LAST_ATTENDER;

			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to update values for this rule using update rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
			//UPDATE THE RULE API
			etest.log(Status.INFO,"NOW CALLING UPDATE RULE API");

			api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			website_name=ExecuteStatements.getRandomWebsiteName(driver);
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);

			try
			{
				String users = "";
				String deptName = "testdept_"+CommonUtil.getUniqueMessage();
				Tab.clickSettings(driver);
	            List<WebElement> operatorsList = CommonUtil.getElement(driver,By.id("ulisttable")).findElements(By.className("list-row"));
	            for(WebElement operator : operatorsList)
	            {
	                users += CommonUtil.getElement(operator,By.className("ulist_uname"),By.className("txtelips")).getText() + " ";
	            }
				Department.addDept(driver,deptName,"depttype_publi",users,etest);
			}
			catch (Exception e) {
				CommonUtil.doNothing();				
			}

			department=ExecuteStatements.getRandomDepartment(driver);
			department_id=ExecuteStatements.getDepartmentID(driver,department);

			operator_id=ExecuteStatements.getOperatorId(driver);

			label=CommonUtil.getUniqueMessage();

			String utm_campaign_name="camp"+label;
			String api_email="email@"+label+".com";
			title="title"+label;
			routing_type=null;
			dynamic_users=Constants.LAST_ATTENDER;

			or_criteria1=new String[]{"utm_campaign_name","contains",utm_campaign_name};
			or_criteria2=new String[]{"email","contains",api_email};

			payload=GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(update_rule_keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,update_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(update_rule_api_values_usecase,isRuleValuesFoundInResponse(driver,etest,GET_RULE,response,null,title,replied_count,triggered_count,routed_count,connected_count,transfered_count,missed_count,requested_count,attended_count,Constants.ATLEAST_ONE_ONLINE,null,Constants.TRUE,"-1",app_id,routing_type,operator_id,department_id,dynamic_users,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put(update_rule_ui_values_usecase,isRuleValuesFoundInUI(driver,etest,rule_type,ruleid,title,replied_count,triggered_count,routed_count,connected_count,transfered_count,missed_count,requested_count,attended_count,Constants.ENABLED,website_name,routing_type,operator_id,department_id,dynamic_users,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//enable disable
	public static void updateRoutingStatusRuleAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_rule_api=null;
			Api update_rule_api=null;

			String enable_check_response_usecase=null,disable_check_response_usecase=null,enable_check_ui_usecase=null,disable_check_ui_usecase=null;

			String
			replied_count=null,
			triggered_count=null,
			routed_count=null,
			connected_count=null,
			transfered_count=null,
			missed_count=null,
			requested_count=null,
			attended_count=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				create_rule_api=Api.VISITOR_ROUTING_CREATE;
				update_rule_api=Api.VISITOR_ROUTING_UPDATE;

				disable_check_response_usecase="RESTAPI326";
				disable_check_ui_usecase="RESTAPI327";
				enable_check_response_usecase="RESTAPI328";
				enable_check_ui_usecase="RESTAPI329";

				replied_count="0";
				triggered_count="0";
				routed_count="0";
			}
			else if(rule_type==RoutingRule.CHAT_ROUTING)
			{
				create_rule_api=Api.CHAT_ROUTING_CREATE;
				update_rule_api=Api.CHAT_ROUTING_UPDATE;

				disable_check_response_usecase="RESTAPI330";
				disable_check_ui_usecase="RESTAPI331";
				enable_check_response_usecase="RESTAPI332";
				enable_check_ui_usecase="RESTAPI333";

				connected_count="0";
				transfered_count="0";
				missed_count="0";
				requested_count="0";
			}
			else if(rule_type==RoutingRule.CALL_ROUTING)
			{
				create_rule_api=Api.CALL_ROUTING_CREATE;
				update_rule_api=Api.CALL_ROUTING_UPDATE;

				disable_check_response_usecase="RESTAPI334";
				disable_check_ui_usecase="RESTAPI335";
				enable_check_response_usecase="RESTAPI336";
				enable_check_ui_usecase="RESTAPI337";

				routed_count="0";
				missed_count="0";
				attended_count="0";
			}

			//CREATE THE RULE API
			String api=create_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String website_name=ExecuteStatements.getDefaultEmbedName(driver);
			String app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentID(driver,department);
			String operator_id=ExecuteStatements.getOperatorId(driver);
			String campaign_medium_value="campaign"+label;
			String title="title"+label;
			String routing_type=Constants.ROUTE_TO_SELECTED_USERS;
			String dynamic_users=Constants.LAST_ATTENDER;

			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to update values for this rule using update rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
			
			//DISABLE THE RULE API
			etest.log(Status.INFO,"NOW CALLING DISABLE RULE API");

			api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			payload=GetPayload.getCreateRoutingRulePayload(null,null,null,Constants.FALSE,null,null,null,null,null);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("false",SalesIQRestAPICommonFunctions.jPath(response,"data/enabled"),"status",etest))
				{
					result.put(disable_check_response_usecase,true);
				}
				else
				{
					result.put(disable_check_response_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");

				if(CommonUtil.checkStringContainsAndLog("disable",RoutingRule.getRuleInfo(driver,ruleid,rule_type).get(RoutingRule.STATUS),"status",etest))
				{
					result.put(disable_check_ui_usecase,true);
				}
				else
				{
					result.put(disable_check_ui_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//ENABLE THE RULE API
			etest.log(Status.INFO,"NOW CALLING ENABLE RULE API");

			api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			payload=GetPayload.getCreateRoutingRulePayload(null,null,null,Constants.TRUE,null,null,null,null,null);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("true",SalesIQRestAPICommonFunctions.jPath(response,"data/enabled"),"status",etest))
				{
					result.put(enable_check_response_usecase,true);
				}
				else
				{
					result.put(enable_check_response_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");

				if(CommonUtil.checkStringContainsAndLog("enable",RoutingRule.getRuleInfo(driver,ruleid,rule_type).get(RoutingRule.STATUS),"status",etest))
				{
					result.put(enable_check_ui_usecase,true);
				}
				else
				{
					result.put(enable_check_ui_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//delete API
	public static void deleteRoutingRuleAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_rule_api=null;
			Api delete_rule_api=null;

			String delete_rule_ui_check_usecase=null,delete_rule_response_check_usecase=null;

			String
			replied_count=null,
			triggered_count=null,
			routed_count=null,
			connected_count=null,
			transfered_count=null,
			missed_count=null,
			requested_count=null,
			attended_count=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				create_rule_api=Api.VISITOR_ROUTING_CREATE;
				delete_rule_api=Api.VISITOR_ROUTING_DELETE;

				delete_rule_response_check_usecase="RESTAPI338";
				delete_rule_ui_check_usecase="RESTAPI339";

				replied_count="0";
				triggered_count="0";
				routed_count="0";
			}
			else if(rule_type==RoutingRule.CHAT_ROUTING)
			{
				create_rule_api=Api.CHAT_ROUTING_CREATE;
				delete_rule_api=Api.CHAT_ROUTING_DELETE;

				delete_rule_response_check_usecase="RESTAPI340";
				delete_rule_ui_check_usecase="RESTAPI341";

				connected_count="0";
				transfered_count="0";
				missed_count="0";
				requested_count="0";
			}
			else if(rule_type==RoutingRule.CALL_ROUTING)
			{
				create_rule_api=Api.CALL_ROUTING_CREATE;
				delete_rule_api=Api.CALL_ROUTING_DELETE;

				delete_rule_response_check_usecase="RESTAPI342";
				delete_rule_ui_check_usecase="RESTAPI343";

				routed_count="0";
				missed_count="0";
				attended_count="0";
			}

			//CREATE THE RULE API
			String api=create_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String website_name=ExecuteStatements.getDefaultEmbedName(driver);
			String app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentID(driver,department);
			String operator_id=ExecuteStatements.getOperatorId(driver);
			String campaign_medium_value="campaign"+label;
			String title="title"+label;
			String routing_type=Constants.ROUTE_TO_SELECTED_USERS;
			String dynamic_users=Constants.LAST_ATTENDER;

			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to update values for this rule using update rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
			
			//DELETE THE RULE API
			etest.log(Status.INFO,"NOW CALLING DELETE RULE API");

			api=delete_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,delete_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("204",SalesIQRestAPICommonFunctions.jPath(response,"code"),"success code",etest))
				{
					result.put(delete_rule_response_check_usecase,true);
				}
				else
				{
					result.put(delete_rule_response_check_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF DELETED RULE NOT FOUND IN UI");

				if(RoutingRule.isRulePresent(driver,ruleid,rule_type)==false)
				{
					etest.log(Status.PASS,"Rule with ruleid '"+ruleid+"' was deleted after delete API was called.");
					result.put(delete_rule_ui_check_usecase,true);
				}
				else
				{
					etest.log(Status.FAIL,"Rule with ruleid '"+ruleid+"' was NOT deleted after delete API was called.");
					result.put(delete_rule_ui_check_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//routing configuration API
	public static void routingConfigCommonRuleAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api common_rule_get_api=null;
			Api common_rule_set_api=null;

			String enabled_get_common_rule_resp_check=null,disabled_get_common_rule_resp_check=null,
				   enabled_set_common_rule_resp_check=null,disabled_set_common_rule_resp_check=null,
				   enabled_set_common_rule_ui_check=null, disabled_set_common_rule_ui_check=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				common_rule_set_api=Api.VISITOR_ROUTING_COMMON_RULE_SET;
				common_rule_get_api=Api.VISITOR_ROUTING_COMMON_RULE_GET;

				enabled_get_common_rule_resp_check="RESTAPI344";
				enabled_set_common_rule_resp_check="RESTAPI345";
				enabled_set_common_rule_ui_check="RESTAPI346";

				disabled_get_common_rule_resp_check="RESTAPI347";
				disabled_set_common_rule_resp_check="RESTAPI348";
				disabled_set_common_rule_ui_check="RESTAPI349";
			}
			

			//Set route all as disabled thorugh API
			etest.log(Status.INFO,"NOW CALLING DISABLE ROUTE ALL API");

			String api=common_rule_set_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=GetPayload.getRouteToAllConfigPayload("disabled");
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,common_rule_set_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("204",SalesIQRestAPICommonFunctions.jPath(response,"code"),"success code",etest))
				{
					result.put(disabled_set_common_rule_resp_check,true);
				}
				else
				{
					result.put(disabled_set_common_rule_resp_check,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//Check in UI if config is disabled
			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF ROUTING CONFIG DISABLED IN UI");

				if(RoutingRule.isRouteRemainingVisitorsToAllEnabled(driver)==false)
				{
					etest.log(Status.PASS,"Route to all checkbox was disabled after disable route all API was called.");
					result.put(disabled_set_common_rule_ui_check,true);
				}
				else
				{
					etest.log(Status.FAIL,"Route to all checkbox was NOT disabled after disable route all API was called.");
					result.put(disabled_set_common_rule_ui_check,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
			//Call get route all config API and check if disabled
			etest.log(Status.INFO,"NOW CALLING GET ROUTE ALL CONFIG API");

			api=common_rule_get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,common_rule_get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("disabled",SalesIQRestAPICommonFunctions.jPath(response,JPaths.ROUTE_TO_ALL),JPaths.ROUTE_TO_ALL,etest))
				{
					result.put(disabled_get_common_rule_resp_check,true);
				}
				else
				{
					result.put(disabled_get_common_rule_resp_check,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
			//Set route all as enabled through API
			etest.log(Status.INFO,"NOW CALLING ENABLE ROUTE ALL API");

			api=common_rule_set_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			payload=GetPayload.getRouteToAllConfigPayload("enabled");
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,common_rule_set_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("204",SalesIQRestAPICommonFunctions.jPath(response,"code"),"success code",etest))
				{
					result.put(enabled_set_common_rule_resp_check,true);
				}
				else
				{
					result.put(enabled_set_common_rule_resp_check,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//Check in UI if config is enabled
			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF ROUTING CONFIG ENABLED IN UI");

				if(RoutingRule.isRouteRemainingVisitorsToAllEnabled(driver))
				{
					etest.log(Status.PASS,"Route to all checkbox was enabled after enable route all API was called.");
					result.put(enabled_set_common_rule_ui_check,true);
				}
				else
				{
					etest.log(Status.FAIL,"Route to all checkbox was NOT enabled after enable route all API was called.");
					result.put(enabled_set_common_rule_ui_check,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//Call get route all config API and check if enabled
			etest.log(Status.INFO,"NOW CALLING GET ROUTE ALL CONFIG API");

			api=common_rule_get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,common_rule_get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("enabled",SalesIQRestAPICommonFunctions.jPath(response,JPaths.ROUTE_TO_ALL),JPaths.ROUTE_TO_ALL,etest))
				{
					result.put(enabled_get_common_rule_resp_check,true);
				}
				else
				{
					result.put(enabled_get_common_rule_resp_check,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}			

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//update position API
	public static void updatePositionAPI(WebDriver api_webdriver,WebDriver driver,int rule_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api update_rule_api=null;

			String update_position_resp_usecase=null,update_rule_ui_check_usecase=null;

			if(rule_type==RoutingRule.VISITOR_ROUTING)
			{
				update_rule_api=Api.VISITOR_ROUTING_UPDATE;
				update_position_resp_usecase="RESTAPI350";
				update_rule_ui_check_usecase="RESTAPI351";
			}
			else if(rule_type==RoutingRule.CHAT_ROUTING)
			{
				update_rule_api=Api.CHAT_ROUTING_UPDATE;
				update_position_resp_usecase="RESTAPI352";
				update_rule_ui_check_usecase="RESTAPI353";
			}
			else if(rule_type==RoutingRule.CALL_ROUTING)
			{
				update_rule_api=Api.CALL_ROUTING_UPDATE;
				update_position_resp_usecase="RESTAPI354";
				update_rule_ui_check_usecase="RESTAPI355";
			}


			String ruleid=RoutingRule.getBottomRoutingRuleId(driver,rule_type);
			//UPDATE THE RULE API
			etest.log(Status.INFO,"NOW CALLING UPDATE POSITION API");

			String api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			label=CommonUtil.getUniqueMessage();

			JSONObject payload=GetPayload.getUpdatePosistionPayload("1");

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKING IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("1",SalesIQRestAPICommonFunctions.jPath(response,"data/position"),"position",etest))
				{
					result.put(update_position_resp_usecase,true);
				}
				else
				{
					result.put(update_position_resp_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKING IF RULE IS PUSHED TO BOTTOM IN UI");

				RoutingRule.navToRuleTab(driver,rule_type);

				if(CommonUtil.checkStringContainsAndLog(ruleid,RoutingRule.getTopRoutingRuleId(driver,rule_type),"top most rule id",etest))
				{
					result.put(update_rule_ui_check_usecase,true);
				}
				else
				{
					result.put(update_rule_ui_check_usecase,false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//Leadscoring Code
	public static void createLeadscoringRuleAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_leadscoring_rule_api=Api.LEADSCORING_CREATE;

			String api=create_leadscoring_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String campaign_medium_value="campaign"+label;
			String points="22";
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_leadscoring_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("RESTAPI356",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_leadscoring_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//lead
			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put("RESTAPI357",isLeadscoreValuesFoundInResponse(driver,etest,GET_RULE,response,null,Constants.TRUE,points,null,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
				result.put("RESTAPI358",isLeadscoreValuesFoundInUI(driver,etest,ruleid,Constants.ENABLED,points,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void getLeadscoringRuleAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_leadscoring_rule_api=Api.LEADSCORING_CREATE;

			String api=create_leadscoring_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String campaign_medium_value="campaign"+label;
			String points="22";
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_leadscoring_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			//get
			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to get this rule using get rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
			//GET THE RULE API
			Api get_rule_api=Api.LEADSCORING_GET;
			api=get_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);			


			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("RESTAPI359",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_leadscoring_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put("RESTAPI360",isLeadscoreValuesFoundInResponse(driver,etest,GET_RULE,response,ruleid,Constants.TRUE,points,null,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//GET THE RULES API
			Api get_rules_api=Api.LEADSCORING_GET_LIST;
			api=get_rules_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_rules_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("RESTAPI364",isKeysFoundForGetRulesAPI(etest,response,get_rules_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN GET RULES API RESPONSE");
				result.put("RESTAPI365",isLeadscoreValuesFoundInResponse(driver,etest,GET_RULES,response,ruleid,Constants.TRUE,points,null,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void updateLeadscoringRuleAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_leadscoring_rule_api=Api.LEADSCORING_CREATE;

			String api=create_leadscoring_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String campaign_medium_value="campaign"+label;
			String points="22";
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_leadscoring_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			//get
			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to get this rule using get rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			//UPDATE THE RULE API
			etest.log(Status.INFO,"NOW CALLING UPDATE RULE API");

			Api update_rule_api=Api.LEADSCORING_UPDATE;
			api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			label=CommonUtil.getUniqueMessage();

			String utm_campaign_name="camp"+label;
			String api_email="email@"+label+".com";

			or_criteria1=new String[]{"utm_campaign_name","contains",utm_campaign_name};
			or_criteria2=new String[]{"email","contains",api_email};

			points="-112";

			payload=GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("RESTAPI369",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_leadscoring_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put("RESTAPI370",isLeadscoreValuesFoundInResponse(driver,etest,GET_RULE,response,null,Constants.TRUE,points,null,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("RESTAPI371",isLeadscoreValuesFoundInUI(driver,etest,ruleid,Constants.ENABLED,points,or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//enable disable
	public static void updateLeadscoringRuleStatusAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_leadscoring_rule_api=Api.LEADSCORING_CREATE;

			String api=create_leadscoring_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String campaign_medium_value="campaign"+label;
			String points="22";
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_leadscoring_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			//get
			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to get this rule using get rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			//DISABLE THE RULE API
			etest.log(Status.INFO,"NOW CALLING DISABLE RULE API");

			Api update_rule_api=Api.LEADSCORING_UPDATE;
			api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			payload=GetPayload.getCreateLeadscoringRulePayload(Constants.FALSE,null,null,null);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("false",SalesIQRestAPICommonFunctions.jPath(response,"data/enabled"),"status",etest))
				{
					result.put("RESTAPI375",true);
				}
				else
				{
					result.put("RESTAPI375",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");

				if(CommonUtil.checkStringContainsAndLog("disable",Leadscoring.getRuleInfo(driver,ruleid).get(Leadscoring.STATUS),"status",etest))
				{
					result.put("RESTAPI376",true);
				}
				else
				{
					result.put("RESTAPI376",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//ENABLE THE API

			etest.log(Status.INFO,"NOW CALLING ENABLE RULE API");

			update_rule_api=Api.LEADSCORING_UPDATE;
			api=update_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			payload=GetPayload.getCreateLeadscoringRulePayload(Constants.TRUE,null,null,null);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("true",SalesIQRestAPICommonFunctions.jPath(response,"data/enabled"),"status",etest))
				{
					result.put("RESTAPI377",true);
				}
				else
				{
					result.put("RESTAPI377",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");

				if(CommonUtil.checkStringContainsAndLog("enable",Leadscoring.getRuleInfo(driver,ruleid).get(Leadscoring.STATUS),"status",etest))
				{
					result.put("RESTAPI378",true);
				}
				else
				{
					result.put("RESTAPI378",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void deleteLeadscoringRuleStatusAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_leadscoring_rule_api=Api.LEADSCORING_CREATE;

			String api=create_leadscoring_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			String campaign_medium_value="campaign"+label;
			String points="22";
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			JSONObject payload=GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_leadscoring_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			//get
			if(json_response.has("data"))
			{
				etest.log(Status.PASS,"Rule was successfully created through API, Now let us try to get this rule using get rule API");
			}

			String ruleid=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			//delete
			etest.log(Status.INFO,"NOW CALLING DELETE RULE API");

			Api delete_rule_api=Api.LEADSCORING_DELETE;
			api=delete_rule_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",ruleid);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,delete_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("204",SalesIQRestAPICommonFunctions.jPath(response,"code"),"success code",etest))
				{
					result.put("RESTAPI379",true);
				}
				else
				{
					result.put("RESTAPI379",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF DELETED RULE NOT FOUND IN UI");

				if(Leadscoring.isRulePresent(driver,ruleid)==false)
				{
					etest.log(Status.PASS,"Rule with ruleid '"+ruleid+"' was deleted after delete API was called.");
					result.put("RESTAPI380",true);
				}
				else
				{
					etest.log(Status.FAIL,"Rule with ruleid '"+ruleid+"' was NOT deleted after delete API was called.");
					result.put("RESTAPI380",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void leadscoringConfigAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			Tab.navToLeadscoringTab(driver);
			Leadscoring.setAdvancedConfiguration(driver,etest,"Daily");

			String label=CommonUtil.getUniqueMessage();

			String frequency="yearly";
			String expected_ui_frequency="Yearly";

			Api set_leadscoring_config_api=Api.LEADSCORING_CONFIG_SET;

			String api=set_leadscoring_config_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));


			JSONObject payload=GetPayload.getLeadscoringConfigPayload(frequency);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,set_leadscoring_config_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{

				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog("204",SalesIQRestAPICommonFunctions.jPath(response,"code"),"success code",etest))
				{
					result.put("RESTAPI381",true);
				}
				else
				{
					result.put("RESTAPI381",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{

				etest.log(Status.INFO,"NOW CHECKING IN UI");

				if(CommonUtil.checkStringContainsAndLog(expected_ui_frequency,Leadscoring.getAdvancedConfiguration(driver),"leadscoring configuration",etest))
				{
					result.put("RESTAPI382",true);
				}
				else
				{
					result.put("RESTAPI382",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			etest.log(Status.INFO,"Now calling get leadscoring config API");

			//calling get config
			Api get_leadscoring_config_api=Api.LEADSCORING_CONFIG_GET;

			api=get_leadscoring_config_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_leadscoring_config_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{
				etest.log(Status.INFO,"NOW CHECKING IN RESPONSE");

				if(CommonUtil.checkStringContainsAndLog(frequency,SalesIQRestAPICommonFunctions.jPath(response,JPaths.FREQUENCY),"frequency value from get leadscoring config API",etest))
				{
					result.put("RESTAPI383",true);
				}
				else
				{
					result.put("RESTAPI383",false);
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest);
				}

			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static boolean fieldMapsAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,Api fieldmaps_api) throws Exception
	{
		int failcount=0;

		try
		{
			String api=fieldmaps_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,fieldmaps_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			
			etest.log(Status.INFO,"<pre>API "+api+"</pre>");
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			String file_name=null;

			String fieldmaps_directory=FileUpload.getBuildRoot()+"/webapps/selenium/test_related_files/fieldMapsJSON/";

			if(fieldmaps_api==Api.VISITOR_ROUTING_FIELDMAPS)
			{
				file_name="visitorrouting_fieldmaps.json";
			}
			else if(fieldmaps_api==Api.CHAT_ROUTING_FIELDMAPS)
			{
				file_name="chatrouting_fieldmaps.json";
			}
			else if(fieldmaps_api==Api.CALL_ROUTING_FIELDMAPS)
			{
				file_name="callrouting_fieldmaps.json";
			}
			else if(fieldmaps_api==Api.LEADSCORING_FIELDMAPS)
			{
				file_name="leadscoring_fieldmaps.json";
			}
			else if(fieldmaps_api==Api.TRIGGER_FIELDMAPS)
			{
				file_name="triggers_fieldmaps.json";
			}
			else if(fieldmaps_api==Api.VH_VIEW_CRITERIAFIELDS)
			{
				file_name="vh_fieldmaps.json";
			}

			JSONObject expected_json=new JSONObject(FileUpload.getFileAsString(fieldmaps_directory+file_name));


			String expected_json_string=expected_json.toString().trim().replaceAll("\\n","");
			String actual_json_string=json_response.toString().trim().replaceAll("\\n","");

			try
			{

				etest.log(Status.INFO,"NOW CHECKING FIELDMAPS RESPONSE");

				if(expected_json_string.equals(actual_json_string))
				{
					etest.log(Status.PASS,"Expected fieldmaps response was found.");
				}
				else
				{
					etest.log(Status.FAIL,"Expected fieldmaps response was NOT found.");
					etest.log(Status.FAIL,"Expected:"+expected_json.toString());
					etest.log(Status.FAIL,"Actual:"+json_response.toString());
					TakeScreenshot.screenshot(api_webdriver,etest);
					failcount++;
				}
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}

		return CommonUtil.returnResult(failcount);
	}

	//error code checks
	public static boolean errorCodeCheck(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,Api api_object,String api_type,String expected_error_code,String expected_error_message) throws Exception
	{
		try
		{
			String ruleid=getDummyRuleID(driver,api_object);

			String api=api_object.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			if(ruleid!=null)
			{
				api=api.replace("<"+APIKeys.RULEID+">",ruleid);
			}


			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,api_object);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);

			JSONObject payload=getDummyPayloadByAPI(driver,api_object,api_type);
			if(payload!=null)
			{
				etest.log(Status.INFO,"Below json will be used as payload for API-->"+api);
				SalesIQRestAPICommonFunctions.log(etest,payload);

				SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			}

			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			return SalesIQRestAPICommonFunctions.checkErrorJSON(response,expected_error_code,expected_error_message,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}

		return false;
	}

	public static boolean isRuleValuesFoundInUI(WebDriver driver,ExtentTest etest,int rule_type,String id,String title,String replied_count,String triggered_count,String routed_count,String connected_count,String transfered_count,String missed_count,String requested_count,String attended_count,String status,String website,String routing_type,String operator_id,String department_id,String dynamic_user,String[] or_criteria1,String[] or_criteria2) throws Exception
	{
		int failcount=0;

		Hashtable<String,String> rule_info=RoutingRule.getRuleInfo(driver,id,rule_type);

		if(isContains(title,rule_info.get(RoutingRule.NAME),RoutingRule.NAME,etest)==false)
		{
			failcount++;
		}

		if(rule_type==RoutingRule.VISITOR_ROUTING)
		{
			if(isContains(routed_count,rule_info.get(RoutingRule.ROUTED),RoutingRule.ROUTED,etest)==false)
			{
				failcount++;
			}

			if(isContains(replied_count,rule_info.get(RoutingRule.REPLIED),RoutingRule.REPLIED,etest)==false)
			{
				failcount++;
			}

			if(isContains(triggered_count,rule_info.get(RoutingRule.TRIGGERED),RoutingRule.TRIGGERED,etest)==false)
			{
				failcount++;
			}
		}

		else if(rule_type==RoutingRule.CHAT_ROUTING)
		{
			if(isContains(connected_count,rule_info.get(RoutingRule.CONNECTED),RoutingRule.CONNECTED,etest)==false)
			{
				failcount++;
			}

			if(isContains(transfered_count,rule_info.get(RoutingRule.TRANSFERED),RoutingRule.TRANSFERED,etest)==false)
			{
				failcount++;
			}

			if(isContains(requested_count,rule_info.get(RoutingRule.REQUESTED),RoutingRule.REQUESTED,etest)==false)
			{
				failcount++;
			}

			if(isContains(missed_count,rule_info.get(RoutingRule.MISSED),RoutingRule.MISSED,etest)==false)
			{
				failcount++;
			}
		}

		else if(rule_type==RoutingRule.CALL_ROUTING)
		{
			if(isContains(routed_count,rule_info.get(RoutingRule.ROUTED),RoutingRule.ROUTED,etest)==false)
			{
				failcount++;
			}

			if(isContains(attended_count,rule_info.get(RoutingRule.ATTENDED),RoutingRule.ATTENDED,etest)==false)
			{
				failcount++;
			}

			if(isContains(missed_count,rule_info.get(RoutingRule.MISSED),RoutingRule.MISSED,etest)==false)
			{
				failcount++;
			}
		}


		if(isContains(status,RoutingRule.toAPIValue(rule_info.get(RoutingRule.STATUS)),RoutingRule.STATUS,etest)==false)
		{
			failcount++;
		}

		if(isContains(website,rule_info.get(RoutingRule.WEBSITE),RoutingRule.WEBSITE,etest)==false)
		{
			failcount++;
		}

		if(isContains(routing_type,RoutingRule.getRoutingTypeAPIKey(rule_info.get(RoutingRule.ROUTING_TYPE)),RoutingRule.ROUTING_TYPE,etest)==false)
		{
			failcount++;
		}

		if(isContains(operator_id,rule_info.get(RoutingRule.ROUTING_ORDER),RoutingRule.ROUTING_ORDER,etest)==false)
		{
			failcount++;
		}

		if(isContains(department_id,rule_info.get(RoutingRule.ROUTING_ORDER),RoutingRule.ROUTING_ORDER,etest)==false)
		{
			failcount++;
		}

		if(isContains(RoutingRule.toUIValue(dynamic_user),rule_info.get(RoutingRule.ROUTING_ORDER),RoutingRule.ROUTING_ORDER,etest)==false)
		{
			failcount++;
		}

		if(isContains(RoutingRule.toUIValue(dynamic_user),rule_info.get(RoutingRule.ROUTING_ORDER),RoutingRule.ROUTING_ORDER,etest)==false)
		{
			failcount++;
		}

		if(or_criteria1!=null)
		{
			String criteria_value=rule_info.get(RoutingRule.ROUTING_CONDITION);

			String expected_field_name=or_criteria1[0];
			String expected_comparator=or_criteria1[1];
			String expected_values=or_criteria1[2];

			if(CommonUtil.checkStringContainsAndLog(RoutingRule.toUIValue(expected_field_name),criteria_value,"field_name 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(RoutingRule.toUIValue(expected_comparator),criteria_value,"expected_comparator 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(RoutingRule.toUIValue(expected_values),criteria_value,"expected_values 1",etest)==false)
			{
				failcount++;
			}
		}

		if(or_criteria2!=null)
		{
			String criteria_value=rule_info.get(RoutingRule.ROUTING_CONDITION);

			String expected_field_name=or_criteria2[0];
			String expected_comparator=or_criteria2[1];
			String expected_values=or_criteria2[2];

			if(CommonUtil.checkStringContainsAndLog(RoutingRule.toUIValue(expected_field_name),criteria_value,"field_name 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(RoutingRule.toUIValue(expected_comparator),criteria_value,"expected_comparator 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(RoutingRule.toUIValue(expected_values),criteria_value,"expected_values 2",etest)==false)
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isRuleValuesFoundInResponse(WebDriver driver,ExtentTest etest,int api_type,String response,String id,String title,String replied_count,String triggered_count,String routed_count,String connected_count,String transfered_count,String missed_count,String requested_count,String attended_count,String condition,String creator_id,String status,String last_routed_time,String appid,String routing_type,String operator_id,String department_id,String dynamic_user,String[] or_criteria1,String[] or_criteria2) throws Exception
	{
		int failcount=0;

		if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,title,getJPath(response,id,JPaths.TITLE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,replied_count,getJPath(response,id,JPaths.REPLIED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,triggered_count,getJPath(response,id,JPaths.TRIGGERED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,routed_count,getJPath(response,id,JPaths.ROUTED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,connected_count,getJPath(response,id,JPaths.CONNECTED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,transfered_count,getJPath(response,id,JPaths.TRANSFERED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,missed_count,getJPath(response,id,JPaths.MISSED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,requested_count,getJPath(response,id,JPaths.REQUESTED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,attended_count,getJPath(response,id,JPaths.ATTENDED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,creator_id,getJPath(response,id,JPaths.CREATOR_ID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,status,getJPath(response,id,JPaths.STATUS,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,last_routed_time,getJPath(response,id,JPaths.LAST_ROUTED_TIME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,appid,getJPath(response,id,JPaths.APPID2,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,routing_type,getJPath(response,id,JPaths.ROUTING_TYPE,api_type),etest))
		{
			failcount++;
		}

		if(operator_id!=null || dynamic_user!=null || department_id!=null)
		{
			JSONArray userset=SalesIQRestAPICommonFunctions.getArray(response,getJPath(response,id,JPaths.USERSET_ARRAY,api_type));

			if(operator_id!=null && CommonUtil.checkStringContainsAndLog( operator_id , userset.toString() , "operator id" , etest)==false)
			{
				failcount++;
			}

			if(department_id!=null && CommonUtil.checkStringContainsAndLog( department_id , userset.toString() , "department id" , etest)==false)
			{
				failcount++;
			}

			if(dynamic_user!=null && CommonUtil.checkStringContainsAndLog( dynamic_user , userset.toString() , "dynamic_users" , etest)==false)
			{
				failcount++;
			}
		}

		if(or_criteria1!=null)
		{
			JSONObject or_criteria1_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA1,api_type)));

			String actual_field_name=or_criteria1_json.get(APIKeys.FIELD_NAME).toString();
			String actual_comparator=or_criteria1_json.get(APIKeys.COMPARATOR).toString();
			String actual_values=or_criteria1_json.get(APIKeys.VALUES).toString();

			String expected_field_name=or_criteria1[0];
			String expected_comparator=or_criteria1[1];
			String expected_values=or_criteria1[2];

			if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 1",etest)==false)
			{
				failcount++;
			}
		}

		if(or_criteria2!=null)
		{
			JSONObject or_criteria2_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA2,api_type)));

			String actual_field_name=or_criteria2_json.get(APIKeys.FIELD_NAME).toString();
			String actual_comparator=or_criteria2_json.get(APIKeys.COMPARATOR).toString();
			String actual_values=or_criteria2_json.get(APIKeys.VALUES).toString();

			String expected_field_name=or_criteria2[0];
			String expected_comparator=or_criteria2[1];
			String expected_values=or_criteria2[2];

			if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 2",etest)==false)
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	//Leadscoring 
	public static boolean isLeadscoreValuesFoundInResponse(WebDriver driver,ExtentTest etest,int api_type,String response,String id,String status,String points,String creator_id,String[] or_criteria1,String[] or_criteria2) throws Exception
	{
		int failcount=0;

		if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,points,getJPath(response,id,JPaths.POINTS,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,creator_id,getJPath(response,id,JPaths.CREATOR_ID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,status,getJPath(response,id,JPaths.STATUS,api_type),etest))
		{
			failcount++;
		}

		if(or_criteria1!=null)
		{
			JSONObject or_criteria1_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA1,api_type)));

			String actual_field_name=or_criteria1_json.get(APIKeys.FIELD_NAME).toString();
			String actual_comparator=or_criteria1_json.get(APIKeys.COMPARATOR).toString();
			String actual_values=or_criteria1_json.get(APIKeys.VALUES).toString();

			String expected_field_name=or_criteria1[0];
			String expected_comparator=or_criteria1[1];
			String expected_values=or_criteria1[2];

			if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 1",etest)==false)
			{
				failcount++;
			}
		}

		if(or_criteria2!=null)
		{
			JSONObject or_criteria2_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA2,api_type)));

			String actual_field_name=or_criteria2_json.get(APIKeys.FIELD_NAME).toString();
			String actual_comparator=or_criteria2_json.get(APIKeys.COMPARATOR).toString();
			String actual_values=or_criteria2_json.get(APIKeys.VALUES).toString();

			String expected_field_name=or_criteria2[0];
			String expected_comparator=or_criteria2[1];
			String expected_values=or_criteria2[2];

			if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 2",etest)==false)
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isLeadscoreValuesFoundInUI(WebDriver driver,ExtentTest etest,String id,String status,String points,String[] or_criteria1,String[] or_criteria2) throws Exception
	{
		int failcount=0;

		Hashtable<String,String> rule_info=Leadscoring.getRuleInfo(driver,id);

		if(isContains(status,Leadscoring.toAPIValue(rule_info.get(Leadscoring.STATUS)),Leadscoring.STATUS,etest)==false)
		{
			failcount++;
		}

		if(isContains(points,Leadscoring.toAPIValue(rule_info.get(Leadscoring.POINTS)),Leadscoring.POINTS,etest)==false)
		{
			failcount++;
		}

		if(or_criteria1!=null)
		{
			String criteria_value=rule_info.get(Leadscoring.CONDITION);

			String expected_field_name=or_criteria1[0];
			String expected_comparator=or_criteria1[1];
			String expected_values=or_criteria1[2];

			if(CommonUtil.checkStringContainsAndLog(Leadscoring.toUIValue(expected_field_name),criteria_value,"field_name 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(Leadscoring.toUIValue(expected_comparator),criteria_value,"expected_comparator 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(Leadscoring.toUIValue(expected_values),criteria_value,"expected_values 1",etest)==false)
			{
				failcount++;
			}
		}

		if(or_criteria2!=null)
		{
			String criteria_value=rule_info.get(Leadscoring.CONDITION);

			String expected_field_name=or_criteria2[0];
			String expected_comparator=or_criteria2[1];
			String expected_values=or_criteria2[2];

			if(CommonUtil.checkStringContainsAndLog(Leadscoring.toUIValue(expected_field_name),criteria_value,"field_name 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(Leadscoring.toUIValue(expected_comparator),criteria_value,"expected_comparator 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(Leadscoring.toUIValue(expected_values),criteria_value,"expected_values 2",etest)==false)
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static String getJPath(String response,String rule_id,String jPath,int api_type) throws Exception
	{
		if(api_type==GET_RULE || response==null || rule_id==null)
		{
			return jPath;
		}
		else
		{
			int rule_index=getRuleIndexOfGetRulesResponse(response,rule_id);
			jPath=getJPathForIndex(jPath,rule_index);
			return jPath;
		}
	}

	public static String getJPathForIndex(String jPath,int rule_index) throws Exception
	{
		jPath=jPath.replace("data/", "data/rule_list["+rule_index+"]/");
		return jPath;
	}

	public static int getRuleIndexOfGetRulesResponse(String response,String rule_id) throws Exception
	{
		JSONObject resp_json=new JSONObject(response);
		JSONArray rules_array=resp_json.getJSONObject("data").getJSONArray("rule_list");
		return SalesIQRestAPICommonFunctions.getJSONIndexWith(rules_array,"id",rule_id);
	}

	public static boolean isContains(String expected,String actual,String description,ExtentTest etest) throws Exception
	{
		if(expected!=null && CommonUtil.checkStringContainsAndLog(expected,actual,description,etest)==false)
		{
			return false;
		}

		return true;
	}

	public static boolean isValueFound(String response,String expected,String jpath,ExtentTest etest) throws Exception
	{
		if(expected!=null && CommonUtil.checkStringContainsAndLog( expected , SalesIQRestAPICommonFunctions.jPath(response,jpath) , jpath , etest)==false)
		{
			return false;
		}

		return true;
	}

	public static boolean isKeysFoundForGetRulesAPI(ExtentTest etest,String json_string,String[] jPaths) throws Exception
	{
		int failcount=0;

		for(String jPath : jPaths)
		{
			if(!SalesIQRestAPICommonFunctions.isKeyFound(etest,json_string,getJPathForIndex(jPath,0)))
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static String getDummyRuleID(WebDriver driver,Api api) throws Exception
	{
		String api_name=api.toString();

		if(api.api_template.contains("<id>"))
		{
			if(api_name.contains("LEADSCORING"))
			{
				return Leadscoring.getTopRuleId(driver);
			}
			else
			{
				int rule_type=-1;

				if(api_name.contains("VISITOR_ROUTING"))
				{
					rule_type=RoutingRule.VISITOR_ROUTING;
				}

				if(api_name.contains("CHAT_ROUTING"))
				{
					rule_type=RoutingRule.CHAT_ROUTING;
				}

				if(api_name.contains("CALL_ROUTING"))
				{
					rule_type=RoutingRule.CALL_ROUTING;
				}

				return RoutingRule.getTopRoutingRuleId(driver,rule_type);
			}
		}

		return null;
	}

	public static JSONObject getDummyPayloadByAPI(WebDriver driver,Api api,String api_type) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();

		if( api_type!=null   &&  (api_type.equals("position"))   && (api==Api.VISITOR_ROUTING_UPDATE || api==Api.CHAT_ROUTING_UPDATE || api==Api.CALL_ROUTING_UPDATE) )
		{
			return GetPayload.getUpdatePosistionPayload("1");
		}
		else if(api_type!=null && api_type.equals("status") && (api==Api.VISITOR_ROUTING_UPDATE || api==Api.CHAT_ROUTING_UPDATE || api==Api.CALL_ROUTING_UPDATE) )
		{
			return GetPayload.getCreateRoutingRulePayload(null,null,null,Constants.FALSE,null,null,null,null,null);
		}
		else if(api==Api.VISITOR_ROUTING_CREATE || api==Api.CHAT_ROUTING_CREATE || api==Api.CALL_ROUTING_CREATE || api==Api.VISITOR_ROUTING_UPDATE || api==Api.CHAT_ROUTING_UPDATE || api==Api.CALL_ROUTING_UPDATE)
		{
			String
			replied_count=null,
			triggered_count=null,
			routed_count=null,
			connected_count=null,
			transfered_count=null,
			missed_count=null,
			requested_count=null,
			attended_count=null;

			if(api==Api.VISITOR_ROUTING_CREATE)
			{
				replied_count="0";
				triggered_count="0";
				routed_count="0";
			}
			else if(api==Api.CHAT_ROUTING_CREATE)
			{
				connected_count="0";
				transfered_count="0";
				missed_count="0";
				requested_count="0";
			}
			else if(api==Api.CALL_ROUTING_CREATE)
			{
				routed_count="0";
				missed_count="0";
				attended_count="0";
			}

			String website_name=ExecuteStatements.getDefaultEmbedName(driver);
			String app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website_name);
			String department=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentID(driver,department);
			String operator_id=ExecuteStatements.getOperatorId(driver);
			String campaign_medium_value="campaign"+label;
			String title="title"+label;
			String routing_type=Constants.ROUTE_TO_SELECTED_USERS;
			String dynamic_users=Constants.LAST_ATTENDER;

			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};


			return GetPayload.getCreateRoutingRulePayload(app_id,title,routing_type,null,new String[]{operator_id},new String[]{department_id},new String[]{dynamic_users},or_criteria1,or_criteria2);
		}
		else if(api==Api.VISITOR_ROUTING_COMMON_RULE_SET)
		{
			return GetPayload.getRouteToAllConfigPayload("disabled");
		}
		else if(api_type!=null && api_type.equals("status") && api==Api.LEADSCORING_UPDATE)
		{
			return GetPayload.getCreateLeadscoringRulePayload(Constants.FALSE,null,null,null);
		}
		else if(api==Api.LEADSCORING_CREATE || api==Api.LEADSCORING_UPDATE)
		{
			String campaign_medium_value="campaign"+label;
			String points="22";
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			return GetPayload.getCreateLeadscoringRulePayload(null,points,or_criteria1,or_criteria2);
		}	
		else if(api==Api.LEADSCORING_CONFIG_SET)
		{
			String frequency="yearly";
			return GetPayload.getLeadscoringConfigPayload(frequency);
		}

		return null;
	}
}
