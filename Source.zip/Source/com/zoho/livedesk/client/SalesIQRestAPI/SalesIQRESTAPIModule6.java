//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.AgentsSettings;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.BuildRejector;

public class SalesIQRESTAPIModule6
{
   public static Hashtable finalResult = new Hashtable();

   public static Hashtable<String,Boolean> result = null;
   public static ExtentTest etest;
   static public ExtentReports extent;

   public static final String MODULE_NAME="Rest API";
   public static String portal_name = "";

   public static WebDriver asso_driver = null;
   public static WebDriver sup_driver = null;
   public static WebDriver admin_driver = null;
   public static String[] department_ids = {"34068000000002013"};
   public static String new_department[] = new String[1];

   public static String
   admin_id = "34068000000002001",
   supervisor_id = "34068000001661161",
   associate_id = "34068000000218017";

   public static final String
   ROLE = "Associate",
   NICK_NAME = "MA",
   FIRST_NAME = "tester",
   LAST_NAME = "qa",
   DESCRIPTION = "Hi there just testing RESTAPI",
   MOBILE = "91234567890",
   PHONE = "81234567890",
   TIME_ZONE = "Asia/Calcutta",
   LANGUAGE = "en",
   MAXIMUM_CONCURRENT_CHAT = "5",
   DATE_OF_BIRTH = "12-03-1997",
   STREET = "P K P North West Street",
   CITY = "TVL",
   STATE = "TN",
   COUNTRY = "gb",
   PIN_CODE = "627005",
   OPERATORID = "<operatorid>",
   SUCCESS_CODE = "204",
   CLIENT_SIDE_ERROR = "400",
   operation_failed_error_code = "1000",
   operation_failed_error_message = "Operation Failed",
   invalid_scope_error_code = "1009",
   invalid_scope_error_message = "Invalid OAuthScope",
   invalid_request_parameters_error_code = "1011",
   invalid_request_parameters_error_message = "Either the request parameters are invalid or absent",
   resource_already_exists_error_code = "1014",
   resource_already_exists_error_message = "Resource already exists",
   access_denied_error_code = "1016",
   access_denied_error_message = "Operator doesn't have the permission to perform the operation",
   operator_not_associated_error_code = "1301",
   operator_not_associated_error_message = "Operator has to be associated in any other department to be removed from this department",
   ADMIN_TYPE = "agentyp_admin",
   SUPERVISOR_TYPE = "agentyp_super",
   ASSOCIATE_TYPE = "agentyp_agent",
   ADMIN_MAIN_EMAIL = "muzamilcsma+12@gmail.com",
   SUPERVISOR_MAIN_EMAIL = "muzamil.y+operator_restapi_supervisor_t0@zohotest.com",
   ASSOCIATE_MAIN_EMAIL = "muzamilcsma+1225@gmail.com",
   AVAILABLE = "Available",
   BUSY = "Busy"
   ;

   public static String 
   admin_email = "admin@test.com",
   supervisor_email = "supervisor@test.com",
   associate_email = "associate@test.com"
   ;

   public static VisitorDriverManager visitor_driver_manager;

   public static Hashtable test()
   {
      try
      {
         admin_driver = Functions.setUp();
         sup_driver = Functions.setUp();
         asso_driver = Functions.setUp();

         String label = CommonUtil.getUniqueMessage();
         admin_email = "admin_"+label+"@test.com";
         supervisor_email = "supervisor_"+label+"@test.com";
         associate_email = "associate_"+label+"@test.com";

         visitor_driver_manager = new VisitorDriverManager();

         result = new Hashtable<String,Boolean>();

         ArrayList<String> mainOperators = new ArrayList<String>();
         mainOperators.add(ADMIN_MAIN_EMAIL);
         mainOperators.add(SUPERVISOR_MAIN_EMAIL);
         mainOperators.add(ASSOCIATE_MAIN_EMAIL);


         WebDriver api_driver=Functions.setUp();
         api_driver.get(SalesIQRestAPIModule.APITesterURL);
         Functions.login(admin_driver,"restapi_admin");
         try
         {
            AgentsSettings.activateAgent(admin_driver,SUPERVISOR_MAIN_EMAIL);
            AgentsSettings.activateAgent(admin_driver,ASSOCIATE_MAIN_EMAIL);
         }
         catch(Exception e)
         {
            CommonUtil.doNothing();
         }

         Functions.login(sup_driver,"restapi_supervisor");
         Functions.login(asso_driver,"restapi_associate");
         portal_name = ExecuteStatements.getPortal(admin_driver);
         Cleanup.deleteAllDeparmentsExcept(admin_driver,null);
         Cleanup.deleteAllOperatorsExcept(admin_driver,mainOperators);

         etest=ComplexReportFactory.getTest("Check Get details of all Operators API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI81",checkGetListOfOperatorsAPI(api_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Create an Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI96",checkCreateOperatorAPI(api_driver,admin_driver,asso_driver,sup_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Get details of an Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI104",checkGetOperatorsDetailsAPI(admin_driver,api_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Update details of an Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI119",checkEditOperatorAPI(api_driver,admin_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Delete an Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI141",checkDeleteOperatorAPI(api_driver,admin_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Disable an Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI154",checkEnableDisableOperatorAPI(api_driver,admin_driver,true,154,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Enable an Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI168",checkEnableDisableOperatorAPI(api_driver,admin_driver,false,168,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Set Operator status API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI182",checkSetOperatorStatusAPI(api_driver,admin_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Delete Operator image API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI215",checkDeleteOperatorImageAPI(api_driver,admin_driver,sup_driver,asso_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Associate departments to Operator API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI228",checkAssociateDepartmentsWithOperatorAPI(api_driver,admin_driver,etest));
         ComplexReportFactory.closeTest(etest);

         etest=ComplexReportFactory.getTest("Check Remove associated departments from Operators API");
         ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
         result.put("RESTAPI244",checkRemoveAssociatedDepartmentFromOperatorsAPI(api_driver,admin_driver,etest));
         ComplexReportFactory.closeTest(etest);

         Driver.quitDriver(api_driver);

         visitor_driver_manager.terminateAllDriverSessions();
      }

      catch(Exception e)
      {
         etest.log(Status.FATAL,"Module breakage occurred "+e);
         TakeScreenshot.log(e,etest);
      }
      finally
      {
         ComplexReportFactory.closeTest(etest);
         //BuildRejector.analyse(result,"Failures in REST API module");
         finalResult.put("result",result);
         finalResult.put("servicedown",new Hashtable());
      }
      return finalResult;
   }

   //Add keys as such in operators module (refer keycount) so as to use the below method
   // (api_driver,api_obj,isReplace,replaceString,replaceWith,isArray,isResponse,response_code,isPayload,payload,startKey,etest)
   public static boolean checkAPI(WebDriver api_driver,Api api_obj,boolean isReplace,String replaceString,String replaceWith,boolean isArray,boolean isResponse,String response_code,boolean isPayload,JSONObject payload,int startKey,ExtentTest etest)
   {
      return checkAPI(api_driver,api_obj,isReplace,replaceString,replaceWith,isArray,isResponse,response_code,isPayload,payload,startKey,etest,true);
   }

   public static boolean checkAPI(WebDriver api_driver,Api api_obj,boolean isReplace,String replaceString,String replaceWith,boolean isArray,boolean isResponse,String response_code,boolean isPayload,JSONObject payload,int startKey,ExtentTest etest,boolean toCheckDeletedOperators)
   {
      int failcount = 0;
      String key,dataCheckKey;
      key = "RESTAPI"+startKey;
      dataCheckKey = "RESTAPI"+(++startKey);
      try
      {
         String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_driver,portal_name,isReplace,replaceString,replaceWith,api_obj,isPayload,payload,etest);

         JSONObject json_response = new JSONObject(response);
         if(isResponse)
         {
            if(!CommonUtil.isChecked(key,result))
            {
               if(SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys))
               {
                  etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(key)+" -- checked</b>");
                  result.put(key,true);
               }
               else
               {
                  failcount++;
                  etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(key)+" -- failed</b>");
                  result.put(key,false);
               }
            }
            if(SalesIQRestAPICommonFunctions.checkDataInResponse(dataCheckKey,json_response,isArray,etest))
            {
               if(!CommonUtil.isChecked(dataCheckKey,result))
               {
                  etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(dataCheckKey)+" -- checked</b>");
                  result.put(dataCheckKey,true);
               }
            }
            else
            {
               failcount++;
               etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(dataCheckKey)+" -- failed</b>");
               result.put(dataCheckKey,false);
            }
         }
         else
         {
            String actualResponseCode = "";
            if(new JSONObject(response).has("JSPServerResponse"))
            {
               actualResponseCode = new JSONObject(response).get("code").toString();
            }
            else
            {
               actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
            }

            if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
            {
               result.put(dataCheckKey,true);
               etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(dataCheckKey)+" -- Success</b>");
            }
            else
            {
               result.put(dataCheckKey,false);
               etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(dataCheckKey)+" -- failed</b>");
               failcount++;
            }
         }

         if(isArray && toCheckDeletedOperators)
         {
            if(json_response.getJSONArray("data").length() >= 4)
            {
               etest.log(Status.PASS,"Deleted operators were also present in the list");
               result.put("RESTAPI"+(startKey+1),true);
            }
            else
            {
               etest.log(Status.FAIL,"deleted operators were not present in the list");
               result.put("RESTAPI"+(startKey+1),false);
            }
         }
         return CommonUtil.returnResult(failcount);
      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         return false;
      }
   }

   public static boolean checkGetListOfOperatorsAPI(WebDriver api_driver,ExtentTest etest)
   {
      int failcount = 0;
      try
      {
         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!checkAPI(api_driver,Api.OPERATOR_GET_LIST,false,"","",true,true,SUCCESS_CODE,false,null,82,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!getListOfOperatorsAPI(api_driver,"RESTAPI86",87,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!getListOfOperatorsAPI(api_driver,"RESTAPI91",92,etest))
         {
            failcount++;
         }
         

         return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,"RESTAPI81",etest);
      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         return false;
      }
   }

   public static boolean getListOfOperatorsAPI(WebDriver api_driver,String key,int keyStart,ExtentTest etest)
   {
      if(!checkAPI(api_driver,Api.OPERATOR_GET_LIST,false,"","",true,true,SUCCESS_CODE,false,null,keyStart,etest))
      {
         result.put(key,false);
         return false;
      }
      else
      {
         result.put(key,true);
         return true;
      }
   }

   public static boolean checkCreateOperatorAPI(WebDriver api_driver,WebDriver driver,WebDriver assoc_driver,WebDriver sup_driver,ExtentTest etest)
   {
      int failcount = 0;
      JSONObject payload;
      String label = "";
      try
      {
         department_ids[0] = ExecuteStatements.getDepartmentId(driver,"comp12");
         label = CommonUtil.getUniqueMessage();
         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         payload = GetPayload.getCreateOperatorPayload(label+"admin@email.com",ROLE,department_ids,"true","true",NICK_NAME,FIRST_NAME,LAST_NAME,DESCRIPTION,MOBILE,PHONE,TIME_ZONE,LANGUAGE);
         etest.log(Status.INFO,"Below json will be used as payload");
         SalesIQRestAPICommonFunctions.log(etest,payload);
         if(!checkAPI(api_driver,Api.OPERATOR_CREATE,false,"","",false,true,SUCCESS_CODE,true,payload,97,etest))
         {
            failcount++;
         }
         if(!checkOperatorAddedInUI(driver,label+"admin@email.com","RESTAPI99",true,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);

         if(!createOPeratorAPI(api_driver,label+"supervisor@email.com","RESTAPI100",99,etest))
         {
            failcount++;
         }

         if(!checkOperatorAddedInUI(sup_driver,label+"supervisor@email.com","RESTAPI101",false,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);

         if(!createOPeratorAPI(api_driver,label+"associate@email.com","RESTAPI102",101,etest))
         {
            failcount++;
         }

         if(!checkOperatorAddedInUI(assoc_driver,label+"associate@email.com","RESTAPI103",false,etest))
         {
            failcount++;
         }
         AgentsSettings.deleteAgent(driver,label+"admin@email.com");
         return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,"RESTAPI96",etest);
      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         AgentsSettings.deleteAgent(driver,label+"admin@email.com");
         return false;
      }
   }

   public static boolean createOPeratorAPI(WebDriver api_driver,String email,String key,int startKey,ExtentTest etest) throws Exception
   {
      JSONObject payload = GetPayload.getCreateOperatorPayload(email,ROLE,department_ids,"true","true",NICK_NAME,FIRST_NAME,LAST_NAME,DESCRIPTION,MOBILE,PHONE,TIME_ZONE,LANGUAGE);
      etest.log(Status.INFO,"Below json will be used as payload");
      SalesIQRestAPICommonFunctions.log(etest,payload);
      if(checkAPI(api_driver,Api.OPERATOR_CREATE,false,"","",false,false,access_denied_error_code,true,payload,startKey,etest))
      {
         result.put(key,true);
         return true;
      }
      else
      {
         result.put(key,false);
         return false;
      }
   }

   public static boolean checkOperatorAddedInUI(WebDriver driver,String email,String key,boolean shouldBeAdded,ExtentTest etest) throws Exception
   {
      Status addedLog = shouldBeAdded?Status.PASS:Status.FAIL;
      Status notAddedLog = shouldBeAdded?Status.FAIL:Status.PASS;
      String addedMessage =shouldBeAdded?"Sucess":"Failed";
      String notAddedMessage = shouldBeAdded?"Failed":"Success";
      if(SalesIQRestAPICommonFunctions.checkOperatorAddedInUI(driver,email,etest))
      {
         result.put(key,shouldBeAdded);
         etest.log(addedLog,KeyManager.getRealValue(key)+" -- "+addedMessage);
         return shouldBeAdded;
      }
      else
      {
         result.put(key,!shouldBeAdded);
         etest.log(notAddedLog,KeyManager.getRealValue(key)+" -- "+notAddedMessage);
         return !shouldBeAdded;
      }
   }

   public static boolean checkGetOperatorsDetailsAPI(WebDriver driver,WebDriver api_driver,ExtentTest etest)
   {
      int failcount = 0;
      try
      {
         admin_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,ADMIN_MAIN_EMAIL);
         supervisor_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,SUPERVISOR_MAIN_EMAIL);
         associate_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,ASSOCIATE_MAIN_EMAIL);
         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,admin_id,false,true,SUCCESS_CODE,false,null,105,etest))
         {
            failcount++;
         }
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,supervisor_id,false,true,SUCCESS_CODE,false,null,107,etest))
         {
            failcount++;
         }
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,associate_id,false,true,SUCCESS_CODE,false,null,109,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,admin_id,false,false,access_denied_error_code,false,null,110,etest))
         {
            failcount++;
         }
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,supervisor_id,false,true,SUCCESS_CODE,false,null,112,etest))
         {
            failcount++;
         }
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,associate_id,false,true,SUCCESS_CODE,false,null,114,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,admin_id,false,false,access_denied_error_code,false,null,115,etest))
         {
            failcount++;
         }
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,supervisor_id,false,false,access_denied_error_code,false,null,116,etest))
         {
            failcount++;
         }
         if(!checkAPI(api_driver,Api.OPERATOR_GET,true,OPERATORID,associate_id,false,true,SUCCESS_CODE,false,null,117,etest))
         {
            failcount++;
         }

         return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,"RESTAPI104",etest);
      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         return false;
      }
   }

   public static boolean checkEditOperatorAPI(WebDriver api_driver,WebDriver driver,ExtentTest etest)
   {
      int failcount = 0;
      try
      {
         AgentsSettings.addAgent(driver,ADMIN_TYPE,admin_email);
         AgentsSettings.addAgent(driver,SUPERVISOR_TYPE,supervisor_email);
         AgentsSettings.addAgent(driver,ASSOCIATE_TYPE,associate_email);

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!editOperatorsAPI(api_driver,driver,true,admin_email,true,SUCCESS_CODE,120,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,true,supervisor_email,true,SUCCESS_CODE,123,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,true,associate_email,true,SUCCESS_CODE,126,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!editOperatorsAPI(api_driver,driver,false,SUPERVISOR_MAIN_EMAIL,true,SUCCESS_CODE,129,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,false,admin_email,false,access_denied_error_code,131,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,false,supervisor_email,false,access_denied_error_code,132,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,false,associate_email,false,access_denied_error_code,133,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!editOperatorsAPI(api_driver,driver,false,ASSOCIATE_MAIN_EMAIL,true,SUCCESS_CODE,135,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,false,admin_email,false,access_denied_error_code,137,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,false,supervisor_email,false,access_denied_error_code,138,etest))
         {
            failcount++;
         }
         if(!editOperatorsAPI(api_driver,driver,false,associate_email,false,access_denied_error_code,139,etest))
         {
            failcount++;
         }

      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         failcount++;
      }
      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,"RESTAPI119",etest);
   }

   public static boolean editOperatorsAPI(WebDriver api_driver,WebDriver driver,boolean isAdmin,String email,boolean isResponse,String response_code,int startKey,ExtentTest etest) throws Exception
   {
      int failcount = 0;
      String operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,email);
      JSONObject payload = GetPayload.getUpdateOperatorPayload(isAdmin,NICK_NAME,FIRST_NAME,LAST_NAME,DESCRIPTION,MOBILE,PHONE,TIME_ZONE,LANGUAGE,MAXIMUM_CONCURRENT_CHAT,DATE_OF_BIRTH,"true",STREET,CITY,STATE,COUNTRY,PIN_CODE);
      etest.log(Status.INFO,"Below json will be used as payload");
      SalesIQRestAPICommonFunctions.log(etest,payload);
      if(!checkAPI(api_driver,Api.OPERATOR_UPDATE,true,OPERATORID,operator_id,false,isResponse,response_code,true,payload,startKey,etest))
      {
         failcount++;
      }
      if(isResponse)
      {
         if(!SalesIQRestAPICommonFunctions.checkEditedDataInUI(driver,email,etest))
         {
            failcount++;
            result.put("RESTAPI"+(startKey+2),false);
            etest.log(Status.FAIL,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" failed");
         }
         else
         {
            etest.log(Status.PASS,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" checked");
            result.put("RESTAPI"+(startKey+2),true);
         }
         // SalesIQRestAPICommonFunctions.editAgentInfo(driver,email,etest);
      }

      return CommonUtil.returnResult(failcount);
   }

   public static boolean checkDeleteOperatorAPI(WebDriver api_driver,WebDriver driver,ExtentTest etest)
   {
      int failcount = 0;
      try
      {
         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!deleteOperatorAPI(api_driver,driver,access_denied_error_code,admin_email,147,etest))
         {
            failcount++;
         }
         if(!deleteOperatorAPI(api_driver,driver,access_denied_error_code,supervisor_email,148,etest))
         {
            failcount++;
         }
         if(!deleteOperatorAPI(api_driver,driver,access_denied_error_code,associate_email,149,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!deleteOperatorAPI(api_driver,driver,access_denied_error_code,admin_email,150,etest))
         {
            failcount++;
         }
         if(!deleteOperatorAPI(api_driver,driver,access_denied_error_code,supervisor_email,151,etest))
         {
            failcount++;
         }
         if(!deleteOperatorAPI(api_driver,driver,access_denied_error_code,associate_email,152,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!deleteOperatorAPI(api_driver,driver,SUCCESS_CODE,admin_email,141,etest))
         {
            failcount++;
         }
         if(!deleteOperatorAPI(api_driver,driver,SUCCESS_CODE,supervisor_email,143,etest))
         {
            failcount++;
         }
         if(!deleteOperatorAPI(api_driver,driver,SUCCESS_CODE,associate_email,145,etest))
         {
            failcount++;
         }
         
      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         failcount++;
      }
      AgentsSettings.deleteAgent(driver,admin_email);
      AgentsSettings.deleteAgent(driver,supervisor_email);
      AgentsSettings.deleteAgent(driver,associate_email);
      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,"RESTAPI141",etest);
   }

   public static boolean deleteOperatorAPI(WebDriver api_driver,WebDriver driver,String response_code,String email,int startKey,ExtentTest etest) throws Exception   
   {
      int failcount = 0;
      boolean deleted = true;
      boolean shouldBeDeleted = false;
      if(response_code.equals(SUCCESS_CODE))
      {
         shouldBeDeleted = true;
         deleted = false;
      }
      Status deletedLog = shouldBeDeleted?Status.PASS:Status.FAIL;
      Status notDeletedLog = shouldBeDeleted?Status.FAIL:Status.PASS;
      String deletedMessage =shouldBeDeleted?"Sucess":"Failed";
      String notDeletedMessage = shouldBeDeleted?"Failed":"Success";
      String operator_id = "";

      operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,email);
      if(!checkAPI(api_driver,Api.OPERATOR_DELETE,true,OPERATORID,operator_id,false,false,response_code,false,null,startKey,etest))
      {
         failcount++;
      }
      if(response_code.equals(SUCCESS_CODE))
      {
         if(SalesIQRestAPICommonFunctions.checkOperatorsDeletedInUI(driver,email,etest))
         {
            deleted = true;
            result.put("RESTAPI"+(startKey+2),shouldBeDeleted);
            etest.log(deletedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+deletedMessage);
         }
         else
         {
            result.put("RESTAPI"+(startKey+2),shouldBeDeleted);
            etest.log(notDeletedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+notDeletedMessage);
         }
         if(shouldBeDeleted != deleted)
         {
            failcount++;
         }
      }     

      return CommonUtil.returnResult(failcount);
   }

   public static boolean checkEnableDisableOperatorAPI(WebDriver api_driver,WebDriver driver,boolean isDisable,int startKey,ExtentTest etest)
   {
      int failcount = 0;
      try
      {
         if(isDisable)
         {
            AgentsSettings.addAgent(driver,ADMIN_TYPE,admin_email);
            AgentsSettings.addAgent(driver,SUPERVISOR_TYPE,supervisor_email);
            AgentsSettings.addAgent(driver,ASSOCIATE_TYPE,associate_email);
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,ADMIN_MAIN_EMAIL,access_denied_error_code,startKey,etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,admin_email,SUCCESS_CODE,(startKey+1),etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,supervisor_email,SUCCESS_CODE,(startKey+3),etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,associate_email,SUCCESS_CODE,(startKey+5),etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,admin_email,access_denied_error_code,(startKey+7),etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,supervisor_email,access_denied_error_code,(startKey+8),etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,associate_email,access_denied_error_code,(startKey+9),etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,admin_email,access_denied_error_code,(startKey+10),etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,supervisor_email,access_denied_error_code,(startKey+11),etest))
         {
            failcount++;
         }
         if(!enableDisableOperatorAPI(api_driver,driver,isDisable,associate_email,access_denied_error_code,(startKey+12),etest))
         {
            failcount++;
         }

      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         failcount++;
      }

      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,("RESTAPI"+startKey),etest);

   }

   public static boolean enableDisableOperatorAPI(WebDriver api_driver,WebDriver driver,boolean isDisable,String email,String response_code,int startKey,ExtentTest etest) throws Exception
   {
      int failcount = 0;
      Api api;
      if(isDisable)
      {
         api = Api.OPERATOR_DISABLE;
      }
      else
      {
         api = Api.OPERATOR_ENABLE;
      }
      boolean disabled = true;
      boolean shouldBeDisabled = false;
      if(response_code.equals(SUCCESS_CODE))
      {
         shouldBeDisabled = true;
         disabled = false;
      }

      Status disabledLog = shouldBeDisabled?Status.PASS:Status.FAIL;
      Status notDisabledLog = shouldBeDisabled?Status.FAIL:Status.PASS;
      String disabledMessage =shouldBeDisabled?"Sucess":"Failed";
      String notDisabledMessage = shouldBeDisabled?"Failed":"Success";
      String operator_id = "";

      operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,email);

      if(!checkAPI(api_driver,api,true,OPERATORID,operator_id,false,false,response_code,false,null,startKey,etest))
      {
         failcount++;
      }
      if(response_code.equals(SUCCESS_CODE))
      {
         if(SalesIQRestAPICommonFunctions.checkOperatorDisabled(driver,email,etest) == isDisable)
         {
            disabled = true;
            result.put("RESTAPI"+(startKey+2),shouldBeDisabled);
            etest.log(disabledLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+disabledMessage);
         }
         else
         {
            result.put("RESTAPI"+(startKey+2),shouldBeDisabled);
            etest.log(notDisabledLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+notDisabledMessage);
         }
         if(shouldBeDisabled != disabled)
         {
            failcount++;
         }
      }

      return CommonUtil.returnResult(failcount);
   }

   public static boolean checkSetOperatorStatusAPI(WebDriver api_driver,WebDriver driver,ExtentTest etest)
   {
      int failcount = 0,associate_status_failcount = 0,supervisor_status_failcount = 0;
      String admin_operator_id = "",supervisor_operator_id = "",associate_operator_id = "",admin_main_operator_id = "",supervisor_main_operator_id = "",associate_main_operator_id = "";
      try
      {
         admin_main_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,ADMIN_MAIN_EMAIL);
         supervisor_main_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,SUPERVISOR_MAIN_EMAIL);
         associate_main_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,ASSOCIATE_MAIN_EMAIL);

         admin_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,admin_email);
         supervisor_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,supervisor_email);
         associate_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,associate_email);

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,admin_main_operator_id,ADMIN_MAIN_EMAIL,SUCCESS_CODE,182,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,admin_main_operator_id,ADMIN_MAIN_EMAIL,SUCCESS_CODE,184,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,admin_operator_id,admin_email,SUCCESS_CODE,186,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,supervisor_operator_id,supervisor_email,SUCCESS_CODE,187,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,associate_operator_id,associate_email,SUCCESS_CODE,188,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,admin_operator_id,admin_email,SUCCESS_CODE,189,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,supervisor_operator_id,supervisor_email,SUCCESS_CODE,190,etest))
         {
            failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,associate_operator_id,associate_email,SUCCESS_CODE,191,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,supervisor_main_operator_id,SUPERVISOR_MAIN_EMAIL,SUCCESS_CODE,193,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,supervisor_main_operator_id,SUPERVISOR_MAIN_EMAIL,SUCCESS_CODE,195,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,admin_operator_id,admin_email,access_denied_error_code,197,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,supervisor_operator_id,supervisor_email,access_denied_error_code,198,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,associate_operator_id,associate_email,access_denied_error_code,199,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,admin_operator_id,admin_email,access_denied_error_code,200,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,supervisor_operator_id,supervisor_email,access_denied_error_code,201,etest))
         {
            supervisor_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,associate_operator_id,associate_email,access_denied_error_code,202,etest))
         {
            supervisor_status_failcount++;
         }
         result.put("RESTAPI193",SalesIQRestAPICommonFunctions.postAndReturnResult(supervisor_status_failcount,("RESTAPI193"),etest));

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,associate_main_operator_id,ASSOCIATE_MAIN_EMAIL,SUCCESS_CODE,204,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,associate_main_operator_id,ASSOCIATE_MAIN_EMAIL,SUCCESS_CODE,206,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,admin_operator_id,admin_email,access_denied_error_code,208,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,supervisor_operator_id,supervisor_email,access_denied_error_code,209,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,BUSY,associate_operator_id,associate_email,access_denied_error_code,210,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,admin_operator_id,admin_email,access_denied_error_code,211,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,supervisor_operator_id,supervisor_email,access_denied_error_code,212,etest))
         {
            associate_status_failcount++;
         }
         if(!setOperatorStatusAPI(api_driver,driver,AVAILABLE,associate_operator_id,associate_email,access_denied_error_code,213,etest))
         {
            associate_status_failcount++;
         }
         result.put("RESTAPI204",SalesIQRestAPICommonFunctions.postAndReturnResult(associate_status_failcount,("RESTAPI204"),etest));

      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         failcount++;
      }

      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,("RESTAPI182"),etest);
   }

   public static boolean setOperatorStatusAPI(WebDriver api_driver,WebDriver driver,String status,String operator_id,String email,String response_code,int startKey,ExtentTest etest) throws Exception
   {
      JSONObject payload = GetPayload.getSetStatusPayload(status);
      etest.log(Status.INFO,"Below json will be used as payload");
      SalesIQRestAPICommonFunctions.log(etest,payload);
      int failcount = 0;
      boolean isStatusSetInUI = true;
      boolean isStatusSet = false;
      if(response_code.equals(SUCCESS_CODE))
      {
         isStatusSet = true;
         isStatusSetInUI = false;
      }
      Status statusSetLog = isStatusSet?Status.PASS:Status.FAIL;
      Status statusNotSetLog = isStatusSet?Status.FAIL:Status.PASS;
      String statusSetMessage =isStatusSet?"Sucess":"Failed";
      String statusNotSetMessage = isStatusSet?"Failed":"Success";

      if(!checkAPI(api_driver,Api.OPERATOR_SET_STATUS,true,OPERATORID,operator_id,false,false,response_code,true,payload,startKey,etest))
      {
         failcount++;
      }
      if(email == ADMIN_MAIN_EMAIL || email == SUPERVISOR_MAIN_EMAIL || email == ASSOCIATE_MAIN_EMAIL)
      {
         if(SalesIQRestAPICommonFunctions.checkStatusOfOperator(driver,operator_id,email,etest).equals(status))
         {
            isStatusSetInUI = true;
            result.put("RESTAPI"+(startKey+2),isStatusSet);
            etest.log(statusSetLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+statusSetMessage);
         }
         else
         {
            result.put("RESTAPI"+(startKey+2),isStatusSet);
            etest.log(statusNotSetLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+statusNotSetMessage);
         }
         if(isStatusSet != isStatusSetInUI)
         {
            failcount++;
         }
      }

      return CommonUtil.returnResult(failcount);

   }

   public static boolean checkDeleteOperatorImageAPI(WebDriver api_driver,WebDriver driver,WebDriver supervisor_driver,WebDriver asso_driver,ExtentTest etest)
   {
      int failcount = 0;
      String admin_operator_id = "",supervisor_operator_id = "",associate_operator_id = "";
      try
      {
         admin_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,ADMIN_MAIN_EMAIL);
         supervisor_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,SUPERVISOR_MAIN_EMAIL);
         associate_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,ASSOCIATE_MAIN_EMAIL);

         SalesIQRestAPICommonFunctions.uploadImage(driver,admin_operator_id,ADMIN_MAIN_EMAIL,etest);
         SalesIQRestAPICommonFunctions.uploadImage(supervisor_driver,supervisor_operator_id,SUPERVISOR_MAIN_EMAIL,etest);
         SalesIQRestAPICommonFunctions.uploadImage(asso_driver,associate_operator_id,ASSOCIATE_MAIN_EMAIL,etest);

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!deleteOperatorImageAPI(api_driver,driver,admin_operator_id,ADMIN_MAIN_EMAIL,true,SUCCESS_CODE,215,etest))
         {
            failcount++;
         }
         if(!deleteOperatorImageAPI(api_driver,supervisor_driver,supervisor_operator_id,SUPERVISOR_MAIN_EMAIL,false,access_denied_error_code,217,etest))
         {
            failcount++;
         }
         if(!deleteOperatorImageAPI(api_driver,asso_driver,associate_operator_id,ASSOCIATE_MAIN_EMAIL,false,access_denied_error_code,218,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!deleteOperatorImageAPI(api_driver,driver,admin_operator_id,ADMIN_MAIN_EMAIL,false,access_denied_error_code,221,etest))
         {
            failcount++;
         }
         if(!deleteOperatorImageAPI(api_driver,supervisor_driver,supervisor_operator_id,SUPERVISOR_MAIN_EMAIL,true,SUCCESS_CODE,219,etest))
         {
            failcount++;
         }
         if(!deleteOperatorImageAPI(api_driver,asso_driver,associate_operator_id,ASSOCIATE_MAIN_EMAIL,false,access_denied_error_code,222,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!deleteOperatorImageAPI(api_driver,driver,admin_operator_id,ADMIN_MAIN_EMAIL,false,access_denied_error_code,225,etest))
         {
            failcount++;
         }
         if(!deleteOperatorImageAPI(api_driver,supervisor_driver,supervisor_operator_id,SUPERVISOR_MAIN_EMAIL,false,access_denied_error_code,226,etest))
         {
            failcount++;
         }
         if(!deleteOperatorImageAPI(api_driver,asso_driver,associate_operator_id,ASSOCIATE_MAIN_EMAIL,true,SUCCESS_CODE,223,etest))
         {
            failcount++;
         }
      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest);
         failcount++;
      }

      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,("RESTAPI215"),etest);
   }

   public static boolean deleteOperatorImageAPI(WebDriver api_driver,WebDriver driver,String operator_id,String email,boolean isImageDeleted,String response_code,int startKey,ExtentTest etest) throws Exception
   {
      int failcount = 0;
      boolean isOperatorImageDeletedInUI = true;
      boolean isOperatorImageDeleted = false;
      if(response_code.equals(SUCCESS_CODE))
      {
         isOperatorImageDeleted = true;
         isOperatorImageDeletedInUI = false;
      }
      Status operatorImageDeletedLog = isOperatorImageDeleted?Status.PASS:Status.FAIL;
      Status operatorImageNotDeletedLog = isOperatorImageDeleted?Status.FAIL:Status.PASS;
      String operatorImageDeletedMessage =isOperatorImageDeleted?"Sucess":"Failed";
      String operatorImageNotDeletedMessage = isOperatorImageDeleted?"Failed":"Success";

      if(!checkAPI(api_driver,Api.OPERATOR_DELETE_IMAGE,true,OPERATORID,operator_id,false,false,response_code,false,null,startKey,etest))
      {
         failcount++;
      }
      if(response_code.equals(SUCCESS_CODE))
      {
         if(SalesIQRestAPICommonFunctions.checkOperatorImageDeleted(driver,operator_id,email,etest) == isImageDeleted)
         {
            isOperatorImageDeletedInUI = true;
            result.put("RESTAPI"+(startKey+2),isOperatorImageDeleted);
            etest.log(operatorImageDeletedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+operatorImageDeletedMessage);
         }
         else
         {
            result.put("RESTAPI"+(startKey+2),isOperatorImageDeleted);
            etest.log(operatorImageNotDeletedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+operatorImageNotDeletedMessage);
         }
         if(isOperatorImageDeleted != isOperatorImageDeletedInUI)
         {
            failcount++;
         }
      }

      return CommonUtil.returnResult(failcount);
   }

   public static boolean checkAssociateDepartmentsWithOperatorAPI(WebDriver api_driver,WebDriver driver,ExtentTest etest)
   {
      int failcount = 0;
      String admin_operator_id = "",supervisor_operator_id = "",associate_operator_id = "";
      try
      {
         Cleanup.deleteAllDeparmentsExcept(driver,null);

         admin_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,admin_email);
         supervisor_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,supervisor_email);
         associate_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,associate_email);

         Tab.navToDeptTab(driver);
         Department.addDept(driver,"new","depttype_publi",ExecuteStatements.getUserName(driver),etest);
         CommonUtil.sleep(2000);
         etest.log(Status.INFO,"Department <b style=\"color:red;\">new</b> was added");
         TakeScreenshot.infoScreenshot(driver,etest);
         
         new_department[0] = ExecuteStatements.getDepartmentId(driver,"new");

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,admin_operator_id,admin_email,false,access_denied_error_code,237,etest))
         {
            failcount++;
         }
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,supervisor_operator_id,supervisor_email,false,access_denied_error_code,238,etest))
         {
            failcount++;
         }
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,associate_operator_id,associate_email,false,access_denied_error_code,239,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,admin_operator_id,admin_email,false,access_denied_error_code,240,etest))
         {
            failcount++;
         }
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,supervisor_operator_id,supervisor_email,false,access_denied_error_code,241,etest))
         {
            failcount++;
         }
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,associate_operator_id,associate_email,false,access_denied_error_code,242,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,admin_operator_id,admin_email,true,SUCCESS_CODE,229,etest))
         {
            failcount++;
         }
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,supervisor_operator_id,supervisor_email,true,SUCCESS_CODE,232,etest))
         {
            failcount++;
         }
         if(!associateDepartmentsWithOperatorAPI(api_driver,driver,associate_operator_id,associate_email,true,SUCCESS_CODE,235,etest))
         {
            failcount++;
         }

      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
         failcount++;
      }

      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,("RESTAPI228"),etest);
   }

   public static boolean associateDepartmentsWithOperatorAPI(WebDriver api_driver,WebDriver driver,String operator_id,String email,boolean isResponse,String response_code,int startKey,ExtentTest etest) throws Exception
   {
      int failcount = 0;
      boolean isDepartmentAssociatedInUI = true;
      boolean isDepartmentAssociated = false;
      if(response_code.equals(SUCCESS_CODE))
      {
         isDepartmentAssociated = true;
         isDepartmentAssociatedInUI = false;
      }
      JSONObject payload = GetPayload.getAssociateDepartmentsWithOperatorPayload(new_department);
      etest.log(Status.INFO,"Below json will be used as payload");
      SalesIQRestAPICommonFunctions.log(etest,payload);
      Status departmentAssociatedLog = isDepartmentAssociated?Status.PASS:Status.FAIL;
      Status departmentNotAssociatedLog = isDepartmentAssociated?Status.FAIL:Status.PASS;
      String departmentAssociatedMessage = isDepartmentAssociated?"Sucess":"Failed";
      String departmentNotAssociatedMessage = isDepartmentAssociated?"Failed":"Success";

      if(!checkAPI(api_driver,Api.OPERATOR_ASSOC_DEPARTMENT,true,OPERATORID,operator_id,false,isResponse,response_code,true,payload,startKey,etest))
      {
         failcount++;
      }
      if(response_code.equals(SUCCESS_CODE))
      {
         if(SalesIQRestAPICommonFunctions.checkdepartmentAssociated(driver,operator_id,"new",email,etest))
         {
            isDepartmentAssociatedInUI = true;
            result.put("RESTAPI"+(startKey+2),isDepartmentAssociated);
            etest.log(departmentAssociatedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+departmentAssociatedMessage);
         }
         else
         {
            result.put("RESTAPI"+(startKey+2),isDepartmentAssociated);
            etest.log(departmentNotAssociatedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+departmentNotAssociatedMessage);
         }
         if(isDepartmentAssociated != isDepartmentAssociatedInUI)
         {
            failcount++;
         }
      }

      return CommonUtil.returnResult(failcount);
   }

   public static boolean checkRemoveAssociatedDepartmentFromOperatorsAPI(WebDriver api_driver,WebDriver driver,ExtentTest etest)
   {
      int failcount = 0;
      String admin_operator_id = "",supervisor_operator_id = "",associate_operator_id = "";
      try
      {
         admin_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,admin_email);
         supervisor_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,supervisor_email);
         associate_operator_id = SalesIQRestAPICommonFunctions.getOperatorId(driver,associate_email);

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_admin","admin",etest);
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,admin_operator_id,admin_email,true,SUCCESS_CODE,245,etest))
         {
            failcount++;
         }
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,supervisor_operator_id,supervisor_email,true,SUCCESS_CODE,248,etest))
         {
            failcount++;
         }
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,associate_operator_id,associate_email,true,SUCCESS_CODE,251,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_supervisor","Supervisor",etest);
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,admin_operator_id,admin_email,false,access_denied_error_code,253,etest))
         {
            failcount++;
         }
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,supervisor_operator_id,supervisor_email,false,access_denied_error_code,254,etest))
         {
            failcount++;
         }
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,associate_operator_id,associate_email,false,access_denied_error_code,255,etest))
         {
            failcount++;
         }

         SalesIQRestAPICommonFunctions.setAuth(api_driver,"restapi_associate","Associate",etest);
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,admin_operator_id,admin_email,false,access_denied_error_code,256,etest))
         {
            failcount++;
         }
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,supervisor_operator_id,supervisor_email,false,access_denied_error_code,257,etest))
         {
            failcount++;
         }
         if(!removeDepartmentsWithOperatorAPI(api_driver,driver,associate_operator_id,associate_email,false,access_denied_error_code,258,etest))
         {
            failcount++;
         }

      }
      catch(Exception e)
      {
         TakeScreenshot.screenshot(api_driver,etest,MODULE_NAME,"Exception","Exception",e);
         TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
         failcount++;
      }

      AgentsSettings.deleteAgent(driver,admin_email);
      AgentsSettings.deleteAgent(driver,supervisor_email);
      AgentsSettings.deleteAgent(driver,associate_email);

      return SalesIQRestAPICommonFunctions.postAndReturnResult(failcount,("RESTAPI244"),etest);
   }

   public static boolean removeDepartmentsWithOperatorAPI(WebDriver api_driver,WebDriver driver,String operator_id,String email,boolean isResponse,String response_code,int startKey,ExtentTest etest) throws Exception
   {
      int failcount = 0;
      boolean isDepartmentRemovedInUI = true;
      boolean isDepartmentRemoved = false;
      if(response_code.equals(SUCCESS_CODE))
      {
         isDepartmentRemoved = true;
         isDepartmentRemovedInUI = false;
      }
      Api api = Api.OPERATOR_REMOVE_DEPARTMENT;
      api.api_template = api.api_template.replace("departmentid",department_ids[0]);

      Status departmentRemovedLog = isDepartmentRemoved?Status.PASS:Status.FAIL;
      Status departmentNotRemovedLog = isDepartmentRemoved?Status.FAIL:Status.PASS;
      String departmentRemovedMessage = isDepartmentRemoved?"Sucess":"Failed";
      String departmentNotRemovedMessage = isDepartmentRemoved?"Failed":"Success";

      if(!checkAPI(api_driver,api,true,OPERATORID,operator_id,false,isResponse,response_code,false,null,startKey,etest))
      {
         failcount++;
      }
      if(response_code.equals(SUCCESS_CODE))
      {
         if(!SalesIQRestAPICommonFunctions.checkdepartmentAssociated(driver,operator_id,"comp12",email,etest))
         {
            isDepartmentRemovedInUI = true;
            result.put("RESTAPI"+(startKey+2),isDepartmentRemoved);
            etest.log(departmentRemovedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+departmentRemovedMessage);
         }
         else
         {
            result.put("RESTAPI"+(startKey+2),isDepartmentRemoved);
            etest.log(departmentNotRemovedLog,KeyManager.getRealValue("RESTAPI"+(startKey+2))+" -- "+departmentNotRemovedMessage);
         }
         if(isDepartmentRemoved != isDepartmentRemovedInUI)
         {
            failcount++;
         }
      }

      return CommonUtil.returnResult(failcount);
   }
}
