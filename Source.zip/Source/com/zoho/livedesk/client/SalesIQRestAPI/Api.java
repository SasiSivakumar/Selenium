//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import com.zoho.livedesk.util.Util;

public enum Api
{
	PORTAL_CREATE("/api/v2/portals",RequestType.POST,null),
	PORTAL_GET_LIST("/api/v2/portals",RequestType.GET,ExpectedKeys.PORTAL_GET_LIST),
	PORTAL_GET("/api/v2/portals/<"+APIKeys.SCREENNAME+">",RequestType.GET,ExpectedKeys.PORTAL_GET),
	PORTAL_UPDATE("/api/v2/portals/<"+APIKeys.SCREENNAME+">",RequestType.PUT,ExpectedKeys.PORTAL_UPDATE),
	PORTAL_OWNER_UPDATE("/api/v2/portals/<"+APIKeys.SCREENNAME+">"+"/owner",RequestType.PUT,null),//incomplete
	DEPARTMENT_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments",RequestType.GET,ExpectedKeys.DEPARTMENT_GET_LIST),
	DEPARTMENT_GET("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>",RequestType.GET,ExpectedKeys.DEPARTMENT_GET),
	DEPARTMENT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>",RequestType.PUT,ExpectedKeys.DEPARTMENT_UPDATE),
	DEPARTMENT_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>",RequestType.DELETE,ExpectedKeys.DEPARTMENT_DELETE),
	DEPARTMENT_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments",RequestType.POST,ExpectedKeys.DEPARTMENT_CREATE),
	DEPARTMENT_ENABLE("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>/enable",RequestType.POST,null),
	DEPARTMENT_DISABLE("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>/disable",RequestType.POST,null),
	DEPARTMENT_ADD_OPERATOR("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>/operators",RequestType.POST,ExpectedKeys.DEPARTMENT_ADD_OPERATOR),
	DEPARTMENT_REMOVE_OPERATOR("/api/v2/<"+APIKeys.SCREENNAME+">"+"/departments/<departmentid>/operators",RequestType.DELETE,ExpectedKeys.DEPARTMENT_REMOVE_OPERATOR),
	OPERATOR_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/operators",RequestType.GET,ExpectedKeys.OPERATOR_GET_LIST),
	OPERATOR_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/operators",RequestType.POST,ExpectedKeys.OPERATOR_CREATE),
	OPERATOR_GET("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>",RequestType.GET,ExpectedKeys.OPERATOR_GET),
	OPERATOR_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>",RequestType.PUT,ExpectedKeys.OPERATOR_UPDATE),
	OPERATOR_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>",RequestType.DELETE,ExpectedKeys.OPERATOR_DELETE),
	OPERATOR_ENABLE("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>/enable",RequestType.POST,null),
	OPERATOR_DISABLE("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>/disable",RequestType.POST,null),
	OPERATOR_SET_STATUS("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>/status",RequestType.POST,null),
	OPERATOR_DELETE_IMAGE("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>/photo",RequestType.DELETE,null),
	OPERATOR_ASSOC_DEPARTMENT("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>/departments",RequestType.POST,ExpectedKeys.OPERATOR_ASSOC_DEPARTMENT),
	OPERATOR_REMOVE_DEPARTMENT("/api/v2/<"+APIKeys.SCREENNAME+">/operators/<operatorid>/departments?ids=departmentid",RequestType.DELETE,ExpectedKeys.OPERATOR_REMOVE_DEPARTMENT),
	
	VISITOR_ROUTING_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules",RequestType.POST,ExpectedKeys.VISITOR_ROUTING_RULE_CREATE),
	VISITOR_ROUTING_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules",RequestType.GET,ExpectedKeys.VISITOR_ROUTING_RULE_GET),//The expected keys for this object is the same as get rule API except it is contained into an array, So we use the same keys and convert it in SalesIQRESTAPIModule3.getJPath method
	VISITOR_ROUTING_GET("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules/<id>",RequestType.GET,ExpectedKeys.VISITOR_ROUTING_RULE_GET),
	VISITOR_ROUTING_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules/<id>",RequestType.PUT,ExpectedKeys.VISITOR_ROUTING_RULE_GET),
	VISITOR_ROUTING_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules/<id>",RequestType.DELETE,null),
	VISITOR_ROUTING_COMMON_RULE_SET("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules/commonrule",RequestType.PUT,null),
	VISITOR_ROUTING_COMMON_RULE_GET("/api/v2/<"+APIKeys.SCREENNAME+">/visitorroutingrules/commonrule",RequestType.GET,null),
	VISITOR_ROUTING_FIELDMAPS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/visitorrouting",RequestType.GET,null),

	CHAT_ROUTING_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/chatroutingrules",RequestType.POST,ExpectedKeys.CHAT_ROUTING_RULE_CREATE),
	CHAT_ROUTING_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/chatroutingrules",RequestType.GET,ExpectedKeys.CHAT_ROUTING_RULE_GET),//The expected keys for this object is the same as get rule API except it is contained into an array, So we use the same keys and convert it in SalesIQRESTAPIModule3.getJPath method
	CHAT_ROUTING_GET("/api/v2/<"+APIKeys.SCREENNAME+">/chatroutingrules/<id>",RequestType.GET,ExpectedKeys.CHAT_ROUTING_RULE_GET),
	CHAT_ROUTING_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/chatroutingrules/<id>",RequestType.PUT,ExpectedKeys.CHAT_ROUTING_RULE_GET),
	CHAT_ROUTING_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/chatroutingrules/<id>",RequestType.DELETE,null),
	CHAT_ROUTING_FIELDMAPS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/chatrouting",RequestType.GET,null),

	CALL_ROUTING_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/callroutingrules",RequestType.POST,ExpectedKeys.CALL_ROUTING_RULE_CREATE),
	CALL_ROUTING_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/callroutingrules",RequestType.GET,ExpectedKeys.CALL_ROUTING_RULE_GET),//The expected keys for this object is the same as get rule API except it is contained into an array, So we use the same keys and convert it in SalesIQRESTAPIModule3.getJPath method
	CALL_ROUTING_GET("/api/v2/<"+APIKeys.SCREENNAME+">/callroutingrules/<id>",RequestType.GET,ExpectedKeys.CALL_ROUTING_RULE_GET),
	CALL_ROUTING_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/callroutingrules/<id>",RequestType.PUT,ExpectedKeys.CALL_ROUTING_RULE_GET),
	CALL_ROUTING_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/callroutingrules/<id>",RequestType.DELETE,null),
	CALL_ROUTING_FIELDMAPS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/callrouting",RequestType.GET,null),

	LEADSCORING_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/leadscorerules",RequestType.POST,ExpectedKeys.LEADSCORING_CREATE),
	LEADSCORING_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/leadscorerules",RequestType.GET,ExpectedKeys.LEADSCORING_GET),//The expected keys for this object is the same as get rule API except it is contained into an array, So we use the same keys and convert it in SalesIQRESTAPIModule3.getJPath method
	LEADSCORING_GET("/api/v2/<"+APIKeys.SCREENNAME+">/leadscorerules/<id>",RequestType.GET,ExpectedKeys.LEADSCORING_GET),
	LEADSCORING_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/leadscorerules/<id>",RequestType.PUT,ExpectedKeys.LEADSCORING_UPDATE),
	LEADSCORING_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/leadscorerules/<id>",RequestType.DELETE,null),
	LEADSCORING_CONFIG_GET("/api/v2/<"+APIKeys.SCREENNAME+">/leadscoreconfigs",RequestType.GET,ExpectedKeys.LEADSCORING_CONFIG_GET),
	LEADSCORING_CONFIG_SET("/api/v2/<"+APIKeys.SCREENNAME+">/leadscoreconfigs/timerange",RequestType.PUT,null),
	LEADSCORING_FIELDMAPS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/leadscore",RequestType.GET,null),

	CHATMONITOR_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/chatmonitors",RequestType.POST,ExpectedKeys.CHATMONITOR_CREATE),
	CHATMONITOR_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/chatmonitors",RequestType.GET,ExpectedKeys.CHATMONITOR_CREATE),
	CHATMONITOR_GET("/api/v2/<"+APIKeys.SCREENNAME+">/chatmonitors/<id>",RequestType.GET,ExpectedKeys.CHATMONITOR_CREATE),
	CHATMONITOR_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/chatmonitors/<id>",RequestType.PUT,ExpectedKeys.CHATMONITOR_CREATE),
	CHATMONITOR_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/chatmonitors/<id>",RequestType.DELETE,null),

	BLOCKEDIP_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/blockedips",RequestType.POST,ExpectedKeys.BLOCKEDIP_CREATE),
	BLOCKEDIP_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/blockedips",RequestType.GET,ExpectedKeys.BLOCKEDIP_CREATE),
	BLOCKEDIP_GET("/api/v2/<"+APIKeys.SCREENNAME+">/blockedips/<id>",RequestType.GET,ExpectedKeys.BLOCKEDIP_CREATE),
	BLOCKEDIP_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/blockedips/<id>",RequestType.DELETE,null),
	BLOCKEDIP_COMMENT_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/blockedips/<id>/comments",RequestType.POST,ExpectedKeys.BLOCKEDIP_CREATE),
	BLOCKEDIP_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/blockedips/<id>",RequestType.PUT,ExpectedKeys.BLOCKEDIP_CREATE),

	TRIGGER_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules",RequestType.POST,ExpectedKeys.TRIGGER_CREATE),
	TRIGGER_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules",RequestType.GET,ExpectedKeys.TRIGGER_GET_LIST),
	TRIGGER_GET("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules/<id>",RequestType.GET,ExpectedKeys.TRIGGER_GET),
	TRIGGER_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules/<id>",RequestType.PUT,ExpectedKeys.TRIGGER_UPDATE),
	TRIGGER_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules/<id>",RequestType.DELETE,null),
	TRIGGER_ENABLE("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules/<id>",RequestType.PUT,ExpectedKeys.TRIGGER_GET),
	TRIGGER_DISABLE("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules/<id>",RequestType.PUT,ExpectedKeys.TRIGGER_GET),
	TRIGGER_UDPATE_POSITION("/api/v2/<"+APIKeys.SCREENNAME+">/triggerrules/<id>",RequestType.PUT,ExpectedKeys.TRIGGER_GET),
	TRIGGER_FIELDMAPS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/trigger",RequestType.GET,null),

	WEBHOOK_BOT_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/bots",RequestType.POST,ExpectedKeys.WEBHOOK_BOT_CREATE),
	WEBHOOK_BOT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/bots/<id>",RequestType.PUT,ExpectedKeys.WEBHOOK_BOT_CREATE),
	WEBHOOK_BOT_PUBLIC_KEY_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/bots/<id>/keys",RequestType.POST,ExpectedKeys.WEBHOOK_BOT_PUBLIC_KEY_CREATE),
	WEBHOOK_BOT_PUBLIC_KEY_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/bots/<id>/keys/<keyid>",RequestType.DELETE,null),
	WEBHOOK_BOT_HANDLERS("/api/v2/<"+APIKeys.SCREENNAME+">/bots/<id>/handlers",RequestType.PUT,ExpectedKeys.WEBHOOK_BOT_CREATE),

	VH_VIEW_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/visitorhistoryviews",RequestType.POST,ExpectedKeys.VH_VIEW_CREATE),
	VH_VIEW_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/visitorhistoryviews",RequestType.GET,ExpectedKeys.VH_VIEW_GET_LIST),
	VH_VIEW_GET("/api/v2/<"+APIKeys.SCREENNAME+">/visitorhistoryviews/<id>",RequestType.GET,ExpectedKeys.VH_VIEW_GET),
	VH_VIEW_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/visitorhistoryviews/<id>",RequestType.PUT,ExpectedKeys.VH_VIEW_UPDATE),
	VH_VIEW_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/visitorhistoryviews/<id>",RequestType.DELETE,null),
	VH_VIEW_SELECTED("/api/v2/<"+APIKeys.SCREENNAME+">/userpreferences",RequestType.GET,ExpectedKeys.VH_VIEW_SELECTED),
	VH_VIEW_UPDATE_SELECTED("/api/v2/<"+APIKeys.SCREENNAME+">/userpreferences/visitorhistoryviews",RequestType.PUT,null),
	VH_VIEW_CRITERIAFIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/visitorhistory",RequestType.GET,null),

	INTEG_CRM_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocrm",RequestType.GET,ExpectedKeys.INTEG_CRM_GET),
	INTEG_CRM_GET_USER("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocrm/appusers",RequestType.GET,ExpectedKeys.INTEG_CRM_GET_USER),
	INTEG_CRM_APP_FIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocrm/appfields/<resource_name>",RequestType.GET,null),
	INTEG_CRM_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocrm",RequestType.PUT,ExpectedKeys.INTEG_CRM_GET),
	INTEG_CRM_DEPT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocrm/departments/<id>",RequestType.PUT,ExpectedKeys.INTEG_CRM_GET),
	INTEG_CRM_KEY_AUTHENTICATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocrm/authenticate",RequestType.PUT,ExpectedKeys.INTEG_CRM_GET),

	INTEG_DESK_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohodesk",RequestType.GET,ExpectedKeys.INTEG_DESK_GET),
	INTEG_DESK_APP_FIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohodesk/appfields/department",RequestType.GET,ExpectedKeys.INTEG_DESK_APP_FIELDS),
	INTEG_DESK_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohodesk",RequestType.PUT,ExpectedKeys.INTEG_DESK_GET),
	INTEG_DESK_DEPT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohodesk/departments/<id>",RequestType.PUT,ExpectedKeys.INTEG_DESK_GET),
	INTEG_DESK_KEY_AUTHENTICATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohodesk/authenticate",RequestType.PUT,ExpectedKeys.INTEG_DESK_GET),

	INTEG_CAMPAIGN_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocampaign",RequestType.GET,ExpectedKeys.INTEG_CAMPAIGN_GET),
	INTEG_CAMPAIGN_APP_FIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocampaign/appfields/contact",RequestType.GET,null),
	INTEG_CAMPAIGN_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocampaign",RequestType.PUT,ExpectedKeys.INTEG_CAMPAIGN_GET),
	INTEG_CAMPAIGN_DEPT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocampaign/departments/<id>",RequestType.PUT,ExpectedKeys.INTEG_CAMPAIGN_GET),
	INTEG_CAMPAIGN_KEY_AUTHENTICATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zohocampaign/authenticate",RequestType.PUT,ExpectedKeys.INTEG_CAMPAIGN_GET),

	INTEG_SALESFORCE_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/salesforce",RequestType.GET,ExpectedKeys.INTEG_SALESFORCE_GET),
	INTEG_SALESFORCE_GET_USER("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/salesforce/appusers",RequestType.GET,ExpectedKeys.INTEG_SALESFORCE_GET_USER),
	INTEG_SALESFORCE_APP_FIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/salesforce/appfields/<resource_name>",RequestType.GET,null),
	INTEG_SALESFORCE_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/salesforce",RequestType.PUT,ExpectedKeys.INTEG_SALESFORCE_GET),
	INTEG_SALESFORCE_DEPT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/salesforce/departments/<id>",RequestType.PUT,ExpectedKeys.INTEG_SALESFORCE_GET),

	INTEG_ZENDESK_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zendesk",RequestType.GET,ExpectedKeys.INTEG_ZENDESK_GET),
	INTEG_ZENDESK_APP_FIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zendesk/appfields/department",RequestType.GET,ExpectedKeys.INTEG_ZENDESK_APP_FIELDS),
	INTEG_ZENDESK_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zendesk",RequestType.PUT,ExpectedKeys.INTEG_ZENDESK_GET),
	INTEG_ZENDESK_DEPT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/zendesk/departments/<id>",RequestType.PUT,ExpectedKeys.INTEG_ZENDESK_GET),

	INTEG_MAILCHIMP_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/mailchimp",RequestType.GET,ExpectedKeys.INTEG_MAILCHIMP_GET),
	INTEG_MAILCHIMP_APP_FIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/mailchimp/<appfields_resource>",RequestType.GET,null),
	INTEG_MAILCHIMP_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/mailchimp",RequestType.PUT,ExpectedKeys.INTEG_MAILCHIMP_GET),
	INTEG_MAILCHIMP_DEPT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/mailchimp/departments/<id>",RequestType.PUT,ExpectedKeys.INTEG_MAILCHIMP_GET),

	INTEG_ANALYTICS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/googleanalytics",RequestType.GET,ExpectedKeys.INTEG_ANALYTICS_GET),
	INTEG_ANALYTICS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/googleanalytics",RequestType.PUT,ExpectedKeys.INTEG_ANALYTICS_GET),
	INTEG_ANALYTICS_APPS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/googleanalytics/apps/<id>",RequestType.PUT,ExpectedKeys.INTEG_ANALYTICS_GET),

	INTEG_CB_REVEAL_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/clearbitreveal",RequestType.GET,ExpectedKeys.INTEG_CB_REVEAL_GET),
	INTEG_CB_REVEAL_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/clearbitreveal",RequestType.PUT,ExpectedKeys.INTEG_CB_REVEAL_GET),

	INTEG_CB_ENRICHMENT_GET("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/clearbitenrichment",RequestType.GET,ExpectedKeys.INTEG_CB_ENRICHMENT_GET),
	INTEG_CB_ENRICHMENT_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/integrations/clearbitenrichment",RequestType.PUT,ExpectedKeys.INTEG_CB_ENRICHMENT_GET),

	TRACKING_PRESETS_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets",RequestType.POST,ExpectedKeys.TRACKING_PRESETS_GET),
	TRACKING_PRESETS_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets",RequestType.GET,ExpectedKeys.TRACKING_PRESETS_GET_LIST),
	TRACKING_PRESETS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets/<id>",RequestType.GET,ExpectedKeys.TRACKING_PRESETS_GET),
	TRACKING_PRESETS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets/<id>",RequestType.PUT,ExpectedKeys.TRACKING_PRESETS_GET),
	TRACKING_PRESETS_ENABLE("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets/<id>",RequestType.PUT,ExpectedKeys.TRACKING_PRESETS_GET),
	TRACKING_PRESETS_DISABLE("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets/<id>",RequestType.PUT,ExpectedKeys.TRACKING_PRESETS_GET),
	TRACKING_PRESETS_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/trackingpresets/<id>",RequestType.DELETE,null),
	TRACKING_PRESETS_SELECTED("/api/v2/<"+APIKeys.SCREENNAME+">/userpreferences",RequestType.GET,ExpectedKeys.TRACKING_PRESETS_SELECTED),
	TRACKING_PRESETS_UPDATE_SELECT_RING("/api/v2/<"+APIKeys.SCREENNAME+">/userpreferences/tracking",RequestType.PUT,ExpectedKeys.TRACKING_PRESETS_SELECTED),
	TRACKING_PRESETS_UPDATE_SELECT_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/userpreferences/tracking",RequestType.PUT,ExpectedKeys.TRACKING_PRESETS_SELECTED),
	TRACKING_PRESETS_CRITERIAFIELDS("/api/v2/<"+APIKeys.SCREENNAME+">/criteriafields/trackingpresets",RequestType.GET,null),

	FEEDBACK_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/feedbacks",RequestType.GET,ExpectedKeys.FEEDBACK_GET_LIST),
	FEEDBACK_GET("/api/v2/<"+APIKeys.SCREENNAME+">/conversations/<id>/feedback",RequestType.GET,ExpectedKeys.FEEDBACK_GET),

	APPS_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps",RequestType.POST,ExpectedKeys.APPS_GET),
	APPS_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/apps",RequestType.GET,ExpectedKeys.APPS_GET_LIST),
	APPS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>",RequestType.GET,ExpectedKeys.APPS_GET),
	APPS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>",RequestType.PUT,ExpectedKeys.APPS_GET),
	APPS_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>",RequestType.DELETE,null),

	APPS_CHAT_WINDOW_CONFIGURATION_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/components/chat",RequestType.GET,ExpectedKeys.APPS_CHAT_WINDOW_CONFIGURATION_GET),
	APPS_CHAT_WINDOW_CONFIGURATION_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/components/chat",RequestType.PUT,ExpectedKeys.APPS_CHAT_WINDOW_CONFIGURATION_GET),

	APPS_FAQ_COMPONENTS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/components/faq",RequestType.GET,ExpectedKeys.APPS_FAQ_COMPONENTS_GET),
	APPS_FAQ_COMPONENTS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/components/faq",RequestType.PUT,ExpectedKeys.APPS_FAQ_COMPONENTS_GET),

	APPS_WIDGET_CONFIGURATION_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/widgets",RequestType.GET,ExpectedKeys.APPS_WIDGET_CONFIGURATION_GET),
	APPS_WIDGET_CONFIGURATION_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/widgets",RequestType.PUT,ExpectedKeys.APPS_WIDGET_CONFIGURATION_GET),

	APPS_PRE_CHAT_FORM_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/forms/prechat",RequestType.GET,ExpectedKeys.APPS_PRE_CHAT_FORM_GET),
	APPS_PRE_CHAT_FORM_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/forms/prechat",RequestType.PUT,ExpectedKeys.APPS_PRE_CHAT_FORM_GET),

	APPS_POST_CHAT_FORM_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/forms/postchat",RequestType.GET,ExpectedKeys.APPS_POST_CHAT_FORM_GET),
	APPS_POST_CHAT_FORM_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/forms/postchat",RequestType.PUT,ExpectedKeys.APPS_POST_CHAT_FORM_GET),

	APPS_FIELD_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/forms/fields/<field_id>",RequestType.DELETE,null),

	APPS_CUSTOM_CSS_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/stylesheet",RequestType.DELETE,null),

	APPS_IOS_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios",RequestType.POST,ExpectedKeys.APPS_IOS_GET),
	APPS_IOS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios",RequestType.GET,ExpectedKeys.APPS_IOS_GET),
	APPS_IOS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios",RequestType.PUT,ExpectedKeys.APPS_IOS_GET),
	APPS_IOS_ACCESS_KEYS_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios/accesskeys",RequestType.POST,ExpectedKeys.APPS_IOS_GET),
	APPS_IOS_ACCESS_KEYS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios/accesskeys",RequestType.GET,ExpectedKeys.APPS_IOS_ACCESS_KEYS_GET),
	APPS_IOS_ACCESS_KEYS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios/accesskeys/1",RequestType.PUT,null),
	APPS_IOS_ACCESS_KEYS_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios/accesskeys/1",RequestType.DELETE,null),
	APPS_IOS_COMPONENTS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/ios/components",RequestType.PUT,ExpectedKeys.APPS_IOS_GET),

	APPS_ANDROID_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android",RequestType.POST,ExpectedKeys.APPS_ANDROID_GET),
	APPS_ANDROID_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android",RequestType.GET,ExpectedKeys.APPS_ANDROID_GET),
	APPS_ANDROID_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android",RequestType.PUT,ExpectedKeys.APPS_ANDROID_GET),
	APPS_ANDROID_ACCESS_KEYS_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android/accesskeys",RequestType.POST,ExpectedKeys.APPS_ANDROID_GET),
	APPS_ANDROID_ACCESS_KEYS_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android/accesskeys",RequestType.GET,ExpectedKeys.APPS_ANDROID_ACCESS_KEYS_GET),
	APPS_ANDROID_ACCESS_KEYS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android/accesskeys/1",RequestType.PUT,null),
	APPS_ANDROID_ACCESS_KEYS_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android/accesskeys/1",RequestType.DELETE,null),
	APPS_ANDROID_COMPONENTS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/android/components",RequestType.PUT,ExpectedKeys.APPS_ANDROID_GET),

	APPS_WEBSITE_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/website",RequestType.POST,ExpectedKeys.APPS_WEBSITE_GET),
	APPS_WEBSITE_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/website",RequestType.GET,ExpectedKeys.APPS_WEBSITE_GET),
	APPS_WEBSITE_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/website",RequestType.PUT,ExpectedKeys.APPS_WEBSITE_GET),
	APPS_WEBSITE_COMPONENTS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/website/components",RequestType.PUT,ExpectedKeys.APPS_WEBSITE_GET),

	APPS_EMAIL_SIGNATURE_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/emailsignature",RequestType.POST,ExpectedKeys.APPS_EMAIL_SIGNATURE_GET),
	APPS_EMAIL_SIGNATURE_GET("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/emailsignature",RequestType.GET,ExpectedKeys.APPS_EMAIL_SIGNATURE_GET),
	APPS_EMAIL_SIGNATURE_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/emailsignature",RequestType.PUT,ExpectedKeys.APPS_EMAIL_SIGNATURE_GET),
	APPS_EMAIL_SIGNATURE_COMPONENTS_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>/channels/emailsignature/components",RequestType.PUT,ExpectedKeys.APPS_EMAIL_SIGNATURE_GET),

	APPS_UI_CASES_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>",RequestType.PUT,ExpectedKeys.APPS_UI_CASES_GET),
	APPS_UI_CASES_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/apps/<id>",RequestType.DELETE,null),

	APPS_WEBSITE_VISITOR_API_GET("/visitor/v2/channels/website?widgetcode=<widgetcode>",RequestType.GET,ExpectedKeys.APPS_WEBSITE_VISITOR_API_GET),
	APPS_ANDROID_VISITOR_API_GET("/visitor/v2/channels/android",RequestType.GET,ExpectedKeys.APPS_ANDROID_VISITOR_API_GET),
	APPS_IOS_VISITOR_API_GET("/visitor/v2/channels/ios",RequestType.GET,ExpectedKeys.APPS_IOS_VISITOR_API_GET),

	COUNT_GET("/api/v2/<"+APIKeys.SCREENNAME+">/counts",RequestType.GET,null),

	CANNED_RESPONSES_CREATE("/api/v2/<"+APIKeys.SCREENNAME+">/cannedresponses",RequestType.POST,ExpectedKeys.CANNED_RESPONSES_GET),
	CANNED_RESPONSES_GET_LIST("/api/v2/<"+APIKeys.SCREENNAME+">/cannedresponses",RequestType.GET,ExpectedKeys.CANNED_RESPONSES_GET),
    CANNED_RESPONSES_GET("/api/v2/<"+APIKeys.SCREENNAME+">/cannedresponses/<id>",RequestType.GET,ExpectedKeys.CANNED_RESPONSES_GET),
    CANNED_RESPONSES_UPDATE("/api/v2/<"+APIKeys.SCREENNAME+">/cannedresponses/<id>",RequestType.PUT,ExpectedKeys.CANNED_RESPONSES_GET) ,
    CANNED_RESPONSES_DELETE("/api/v2/<"+APIKeys.SCREENNAME+">/cannedresponses/<id>",RequestType.DELETE,ExpectedKeys.CANNED_RESPONSES_GET)    
	;

	public String api_template;
	public RequestType request_type;
	public String[] expected_keys;

	Api(String api_template,RequestType request_type,String[] expected_keys)
	{
		this.api_template=api_template;
		this.request_type=request_type;
		this.expected_keys=expected_keys;
	}

	public String get()
	{
		return Util.siteNameout()+api_template;
	}
}
