//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class AppsAndroid
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String
	MODULE_NAME = "Apps Restapi",
	BUNDLE_NAME_KEY = "data_bundle_name",
	IS_ANDROID = "isAndroid",
	ENABLED = "data_enabled",
	NOTIFICATIONS = "data_notifications_enabled",
	NOTIFICATIONS_PASSWORD = "data_notifications_password",
	COMPONENTS_KEY = "data_components",
	IS_RESPONSE = "isResponse"
	;

	public static final String[]
	COMPONENTS = {"chat","proactive","faq"},
	UPDATE_ANDROID_KEYS = {ENABLED,NOTIFICATIONS,NOTIFICATIONS_PASSWORD},
	BOOLEAN_VALUES = {"true","false"}
	;

	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api2");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check create Android channel",MODULE_NAME);
			checkCreateAndroidChannel(driver,api_webdriver,Constants.SUCCESS_CODE,1160,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get Android channel Configuration",MODULE_NAME);
			checkGetAndroidChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1163,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Android channel Configuration",MODULE_NAME);
			checkUpdateAndroidChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1165,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check create Android accesskeys",MODULE_NAME);
			checkCreateAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1168,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get Android accesskeys",MODULE_NAME);
			checkGetAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1171,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Android accesskeys",MODULE_NAME);
			checkUpdateAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1173,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Delete Android accesskeys",MODULE_NAME);
			checkDeleteAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1176,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update components for Android",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1178,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");

			etest = ComplexReportFactory.getEtest("Supervisor -- Check create Android channel",MODULE_NAME);
			checkCreateAndroidChannel(driver,api_webdriver,Constants.SUCCESS_CODE,1181,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Get Android channel Configuration",MODULE_NAME);
			checkGetAndroidChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1184,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update Android channel Configuration",MODULE_NAME);
			checkUpdateAndroidChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1186,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check create Android accesskeys",MODULE_NAME);
			checkCreateAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1189,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Get Android accesskeys",MODULE_NAME);
			checkGetAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1192,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update Android accesskeys",MODULE_NAME);
			checkUpdateAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1194,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Delete Android accesskeys",MODULE_NAME);
			checkDeleteAndroidAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1197,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update components for Android",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1199,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest = ComplexReportFactory.getEtest("Associate -- Check create Android channel",MODULE_NAME);
			checkCreateAndroidChannel(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1202,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Get Android channel Configuration",MODULE_NAME);
			checkGetAndroidChannelConfig(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1203,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update Android channel Configuration",MODULE_NAME);
			checkUpdateAndroidChannelConfig(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1204,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check create Android accesskeys",MODULE_NAME);
			checkCreateAndroidAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1205,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Get Android accesskeys",MODULE_NAME);
			checkGetAndroidAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1206,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update Android accesskeys",MODULE_NAME);
			checkUpdateAndroidAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1207,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Delete Android accesskeys",MODULE_NAME);
			checkDeleteAndroidAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1208,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update components for Android",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1209,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check create Android channel",MODULE_NAME);
			checkCreateAndroidChannel(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1210,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Get Android channel Configuration",MODULE_NAME);
			checkGetAndroidChannelConfig(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1211,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update Android channel Configuration",MODULE_NAME);
			checkUpdateAndroidChannelConfig(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1212,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check create Android accesskeys",MODULE_NAME);
			checkCreateAndroidAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1213,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Get Android accesskeys",MODULE_NAME);
			checkGetAndroidAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1214,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update Android accesskeys",MODULE_NAME);
			checkUpdateAndroidAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1215,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Delete Android accesskeys",MODULE_NAME);
			checkDeleteAndroidAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1216,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update components for Android",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1217,etest);
			ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkCreateAndroidChannel(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String
			bundle_name = "bundle_name_"+randomId
			;

			JSONObject payload = GetPayload.getCreateChannelPayload(bundle_name);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(BUNDLE_NAME_KEY,bundle_name);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_ANDROID_CREATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetAndroidChannelConfig(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_ANDROID,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_ANDROID_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateAndroidChannelConfig(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String
			enabled = BOOLEAN_VALUES[startKey%2],
			password = (enabled == "true")?"password"+startKey:null,
			notification_enabled = (enabled == "true")?enabled:null
			;

			JSONObject payload = GetPayload.getAndroidUpdatePayload(enabled,password);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedInfo(UPDATE_ANDROID_KEYS,enabled,notification_enabled,password);
			expectedInfo.put(IS_ANDROID,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_ANDROID_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkCreateAndroidAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_ANDROID,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_ANDROID_ACCESS_KEYS_CREATE,null,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetAndroidAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_ANDROID,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_ANDROID_ACCESS_KEYS_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateAndroidAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String
			enabled = BOOLEAN_VALUES[randomId%2]
			;

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_ANDROID,"true");
			expectedInfo.put(ENABLED,enabled);
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_ANDROID_ACCESS_KEYS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkDeleteAndroidAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_ANDROID,"true");
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_ANDROID_ACCESS_KEYS_DELETE,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateComponentsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String[]
			components = {COMPONENTS[randomId%2],COMPONENTS[(randomId+1)%2]}
			;

			JSONObject payload = GetPayload.getComponentsPayload(components);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_ANDROID,"true");
			expectedInfo.put(COMPONENTS_KEY,components[0]+","+components[1]);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_ANDROID_COMPONENTS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getExpectedInfo(String[] keys,String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(keys[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}
}
