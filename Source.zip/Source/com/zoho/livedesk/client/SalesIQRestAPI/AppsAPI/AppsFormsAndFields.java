//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class AppsFormsAndFields
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String
	MODULE_NAME = "Apps Restapi",
	FORM_TYPE_KEY = "data_form_type",
	TITLE_NAME_KEY = "data_title_name",
	TITLE_MESSAGE_KEY = "data_title_message",
	NAME_KEY = "data_fields_name",
	VISIBILITY_KEY = "data_fields_visibility",
	MAXLENGTH_KEY = "data_fields_maxlength",
	QUESTION_KEY = "data_fields_question",
	MANDATORY_KEY = "data_fields_mandatory",
	ENABLED_KEY = "data_fields_enabled",
	TYPE_KEY = "data_fields_type",
	PLACEHOLDER_KEY = "data_fields_placeholder",
	FEEDBACK_ENABLED_KEY = "data_is_feedback_enabled",
	RATING_ENABLED_KEY = "data_is_rating_enabled",
	IS_RESPONSE = "isResponse"
	;

	public static final String[]
	FORM_TYPE = {"general","classic","conversation"},
	VISIBILITY = {"online","offline"},
	BOOLEAN_VALUES = {"true","false"},
	FIELD_TYPE = {"visitor_name","visitor_email"},
	PRE_CHAT_FORM_KEYS = {FORM_TYPE_KEY,TITLE_NAME_KEY,TITLE_MESSAGE_KEY,NAME_KEY,VISIBILITY_KEY,MAXLENGTH_KEY,QUESTION_KEY,MANDATORY_KEY,ENABLED_KEY,TYPE_KEY,PLACEHOLDER_KEY},
	POST_CHAT_FORM_KEYS = {FEEDBACK_ENABLED_KEY,RATING_ENABLED_KEY}
	;

	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api1");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get pre chat Configurations",MODULE_NAME);
			checkGetPreChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1060,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update pre chat Configurations",MODULE_NAME);
			checkUpdatePreChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1062,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get post chat Configurations",MODULE_NAME);
			checkGetPostChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1065,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update post chat Configurations",MODULE_NAME);
			checkUpdatePostChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1067,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check delete fields",MODULE_NAME);
			checkDeleteFieldsConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1070,etest);
			ComplexReportFactory.closeTest(etest);

			// etest = ComplexReportFactory.getEtest("Check delete custom css",MODULE_NAME);
			// checkDeleteCustomCSSAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1073,etest);
			// ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Get pre chat Configurations",MODULE_NAME);
			checkGetPreChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1075,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update pre chat Configurations",MODULE_NAME);
			checkUpdatePreChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1077,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Get post chat Configurations",MODULE_NAME);
			checkGetPostChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1080,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update post chat Configurations",MODULE_NAME);
			checkUpdatePostChatConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1082,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check delete fields",MODULE_NAME);
			checkDeleteFieldsConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1085,etest);
			ComplexReportFactory.closeTest(etest);

			// etest = ComplexReportFactory.getEtest("Supervisor -- Check delete custom css",MODULE_NAME);
			// checkDeleteCustomCSSAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1088,etest);
			// ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest = ComplexReportFactory.getEtest("Associate -- Check Get pre chat Configurations",MODULE_NAME);
			checkGetPreChatConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1090,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update pre chat Configurations",MODULE_NAME);
			checkUpdatePreChatConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1091,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Get post chat Configurations",MODULE_NAME);
			checkGetPostChatConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1092,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update post chat Configurations",MODULE_NAME);
			checkUpdatePostChatConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1093,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check delete fields",MODULE_NAME);
			checkDeleteFieldsConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1094,etest);
			ComplexReportFactory.closeTest(etest);

			// etest = ComplexReportFactory.getEtest("Associate -- Check delete custom css",MODULE_NAME);
			// checkDeleteCustomCSSAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1095,etest);
			// ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check Get pre chat Configurations",MODULE_NAME);
			checkGetPreChatConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1096,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check Update pre chat Configurations",MODULE_NAME);
			checkUpdatePreChatConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1097,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check Get post chat Configurations",MODULE_NAME);
			checkGetPostChatConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1098,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check Update post chat Configurations",MODULE_NAME);
			checkUpdatePostChatConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1099,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check delete fields",MODULE_NAME);
			checkDeleteFieldsConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1100,etest);
			ComplexReportFactory.closeTest(etest);

			// etest = ComplexReportFactory.getEtest("Invalid Scope -- Check delete custom css",MODULE_NAME);
			// checkDeleteCustomCSSAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1101,etest);
			// ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkGetPreChatConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_PRE_CHAT_FORM_GET,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdatePreChatConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();
			String
			form_type = FORM_TYPE[randomId%3],
			title_name = "title_name_"+randomId,
			title_message = "title_message_"+randomId
			;

			Hashtable<String,String> field = getPreChatFields(randomId);

			Hashtable<String,String> expectedInfo = getExpectedInfo(PRE_CHAT_FORM_KEYS,form_type,title_name,title_message,field.get("name"),field.get("visibility"),field.get("maxlength"),field.get("question"),field.get("mandatory"),field.get("enabled"),field.get("type"),field.get("placeholder"));

			JSONObject payload = GetPayload.getPreChatFormUpdatePayload(form_type,title_name,title_message,field);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_PRE_CHAT_FORM_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetPostChatConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_POST_CHAT_FORM_GET,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdatePostChatConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();
			String
			feedback_enabled = BOOLEAN_VALUES[randomId%2],
			rating_enabled = BOOLEAN_VALUES[randomId%2]
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(POST_CHAT_FORM_KEYS,feedback_enabled,rating_enabled);

			JSONObject payload = GetPayload.getPostChatFormUpdatePayload(feedback_enabled,rating_enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_POST_CHAT_FORM_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkDeleteFieldsConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_FIELD_DELETE,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkDeleteCustomCSSAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_CUSTOM_CSS_DELETE,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getExpectedInfo(String[] keys,String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(keys[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}

	public static Hashtable<String,String> getPreChatFields(int randomId)
	{
		Hashtable<String,String> field = new Hashtable<String,String>();

		String
		field_name = "field_name_"+randomId,
		visibility = VISIBILITY[randomId%2],
		maxlength = (randomId % 100) + "",
		question = "question_" + randomId,
		mandatory = BOOLEAN_VALUES[randomId%2],
		enabled = BOOLEAN_VALUES[0],
		field_type = FIELD_TYPE[randomId%2],
		placeholder = "placeholder_text_"+randomId
		;

		field.put("name",field_name);
		field.put("visibility",visibility);
		field.put("maxlength",maxlength);
		field.put("question",question);
		field.put("mandatory",mandatory);
		field.put("enabled",enabled);
		field.put("type",field_type);
		field.put("placeholder",placeholder);

		
		return field;
	}

}
