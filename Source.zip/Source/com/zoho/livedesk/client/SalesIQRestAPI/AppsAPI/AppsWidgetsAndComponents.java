//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class AppsWidgetsAndComponents
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String
	MODULE_NAME = "Apps Restapi",
	THEME_KEY = "data_theme",
	COLOR_KEY = "data_color",
	WIDGET_TYPE_KEY = "data_widget_type",
	TITLE_KEY = "data_title",
	LIKE_RESPONSE_KEY = "data_like_response",
	DISLIKE_RESPONSE_KEY = "data_dislike_response"
	;

	public static final String[]
	CHAT_WINDOW_KEYS = {THEME_KEY,COLOR_KEY},
	FAQ_KEYS = {TITLE_KEY,LIKE_RESPONSE_KEY,DISLIKE_RESPONSE_KEY},
	WIDGET_CONFIG_KEYS = {WIDGET_TYPE_KEY}
	;

	public static final String[]
	THEME_VALUES = {"pattern","pattern_straight","pattern_curve","lloyd"},
	THEME_KEY_VALUES = {"8","9","10","4"},
	COLOR_VALUES = {"#7D89EA","#00A5FF","#30C6EC","#70DAFE","#52DF7E","#52DF7E","#9D73E2","#D066E5","#E85CCE","#E35468","#F84C62","#FF6D42","#FFB300","#FFEE38","#AFB0B3"},
	WIDGET_TYPE_VALUES = {"float","button","personalized"}
	;

	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api1");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get Chat Window Configurations",MODULE_NAME);
			checkChatWindowConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1018,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Chat Window Configurations",MODULE_NAME);
			checkUpdateChatWindowConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1020,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get FAQ Configurations",MODULE_NAME);
			checkFAQConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1023,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update FAQ Configurations",MODULE_NAME);
			checkUpdateFAQConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1025,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get Widget Configurations",MODULE_NAME);
			checkWidgetConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1028,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Widget Configurations",MODULE_NAME);
			checkUpdateWidgetConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1030,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Get Chat Window Configurations",MODULE_NAME);
			checkChatWindowConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1033,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Update Chat Window Configurations",MODULE_NAME);
			checkUpdateChatWindowConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1035,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Get FAQ Configurations",MODULE_NAME);
			checkFAQConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1038,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Update FAQ Configurations",MODULE_NAME);
			checkUpdateFAQConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1040,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Get Widget Configurations",MODULE_NAME);
			checkWidgetConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1043,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Update Widget Configurations",MODULE_NAME);
			checkUpdateWidgetConfigurationsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1045,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Get Chat Window Configurations",MODULE_NAME);
			checkChatWindowConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1048,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Update Chat Window Configurations",MODULE_NAME);
			checkUpdateChatWindowConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1049,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Get FAQ Configurations",MODULE_NAME);
			checkFAQConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1050,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Update FAQ Configurations",MODULE_NAME);
			checkUpdateFAQConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1051,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Get Widget Configurations",MODULE_NAME);
			checkWidgetConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1052,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Update Widget Configurations",MODULE_NAME);
			checkUpdateWidgetConfigurationsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1053,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Check Get Chat Window Configurations",MODULE_NAME);
			checkChatWindowConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1054,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Check Update Chat Window Configurations",MODULE_NAME);
			checkUpdateChatWindowConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1055,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Check Get FAQ Configurations",MODULE_NAME);
			checkFAQConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1056,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Check Update FAQ Configurations",MODULE_NAME);
			checkUpdateFAQConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1057,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Check Get Widget Configurations",MODULE_NAME);
			checkWidgetConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1058,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Check Update Widget Configurations",MODULE_NAME);
			checkUpdateWidgetConfigurationsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1059,etest);
			ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkChatWindowConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_CHAT_WINDOW_CONFIGURATION_GET,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateChatWindowConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int key = CommonUtil.getRandomId();
			String
			theme = THEME_VALUES[key%THEME_VALUES.length],
			color = COLOR_VALUES[key%COLOR_VALUES.length]
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(CHAT_WINDOW_KEYS,theme,color);

			JSONObject payload = GetPayload.getChatWindowConfigUpdatePayload(theme,color);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_CHAT_WINDOW_CONFIGURATION_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkFAQConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_FAQ_COMPONENTS_GET,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateFAQConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String
			title = "test_title",
			like_response = "test_like_response",
			dislike_response = "test_dislike_response"
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(FAQ_KEYS,title,like_response,dislike_response);

			JSONObject payload = GetPayload.geFAQConfigUpdatePayload(title,like_response,dislike_response);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_FAQ_COMPONENTS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkWidgetConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_WIDGET_CONFIGURATION_GET,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateWidgetConfigurationsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int key = CommonUtil.getRandomId();
			String
			widget_type = WIDGET_TYPE_VALUES[key%WIDGET_TYPE_VALUES.length]
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(WIDGET_CONFIG_KEYS,widget_type);

			JSONObject payload = GetPayload.getWidgetConfigUpdatePayload(widget_type);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_WIDGET_CONFIGURATION_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getExpectedInfo(String[] keys,String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(keys[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}

}
