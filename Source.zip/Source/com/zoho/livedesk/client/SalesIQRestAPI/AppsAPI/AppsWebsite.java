//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.Api;
import com.zoho.livedesk.client.SalesIQRestAPI.Constants;
import com.zoho.livedesk.client.SalesIQRestAPI.GetPayload;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPIModule;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;

public class AppsWebsite {

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	public static final String MODULE_NAME = "Apps Restapi";
	
	public static final String
	ALLOW_IN_MULTIPLE_WEBSITES_KEY = "data_allow_in_multiple_websites",
	ACCESS_MULTIPLE_WEBSITES_KEY = "data_access_multiple_websites_url",
	ENABLED_KEY = "data_enabled",
	APP_WEBSITE_KEY="data_website",
	COMPONENTS_KEY="data_components"
	;

	public static final String[]
	BUSINESS_HOURS = {"true","false"},
	PRIVACY = {"false","true"},
	ACCESS_MULTIPLE_WEBSITES= {"www.zoho","www.localzoho","www.salesiq.zoho"},
	COMPONENTS= {"proactive","faq","call","chat"},
	BOOLEAN_VALUES = {"true","false"},
	APP_WEBSITE= {APP_WEBSITE_KEY},
	KEYS = {APP_WEBSITE_KEY,ALLOW_IN_MULTIPLE_WEBSITES_KEY,ENABLED_KEY,ACCESS_MULTIPLE_WEBSITES_KEY}
	;


	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api3");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Get a website Configuration from App",MODULE_NAME);
			checkGetWebsiteConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1218,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Create a website to apps",MODULE_NAME);
			checkCreateWebsiteAPI(driver,api_webdriver,Constants.CHANNEL_ALREADY_EXISTS_CODE,1220,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Update website configuration from App",MODULE_NAME);
			checkUpdateWebsiteConfigAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1223,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Update a Website Components to Enable in App",MODULE_NAME);
			checkUpdateWebsiteComponentsToBeEnabledAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1226,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");
			
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Get a website Configuration from App",MODULE_NAME);
			checkGetWebsiteConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1229,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Create a website/App",MODULE_NAME);
			checkCreateWebsiteAPI(driver,api_webdriver,Constants.CHANNEL_ALREADY_EXISTS_CODE,1231,etest);
			ComplexReportFactory.closeTest(etest);
		
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Update website configuration from App",MODULE_NAME);
			checkUpdateWebsiteConfigAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1234,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Update a Website Components to Enable in App",MODULE_NAME);
			checkUpdateWebsiteComponentsToBeEnabledAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1237,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest= ComplexReportFactory.getEtest("Associate -- Check Create a website/App",MODULE_NAME);
			checkCreateWebsiteAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1240,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Associate -- Check Get a website Configuration from App",MODULE_NAME);
			checkGetWebsiteConfig(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1241,etest);
			ComplexReportFactory.closeTest(etest);
		
			etest= ComplexReportFactory.getEtest("Associate -- Check Update website configuration from App",MODULE_NAME);
			checkUpdateWebsiteConfigAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1242,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Associate -- Check Update a Website Components to Enable in App",MODULE_NAME);
			checkUpdateWebsiteComponentsToBeEnabledAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1243,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest= ComplexReportFactory.getEtest("Invalid Scope -- Check Create a website/App",MODULE_NAME);
			checkCreateWebsiteAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1244,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Invalid Scope -- Check Get a website Configuration from App",MODULE_NAME);
			checkGetWebsiteConfig(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1245,etest);
			ComplexReportFactory.closeTest(etest);
		
			etest= ComplexReportFactory.getEtest("Invalid Scope -- Check Update website configuration from App",MODULE_NAME);
			checkUpdateWebsiteConfigAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1246,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Invalid Scope -- Check Update a Website Components to Enable in App",MODULE_NAME);
			checkUpdateWebsiteComponentsToBeEnabledAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1247,etest);
			ComplexReportFactory.closeTest(etest);
			
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}
	
		
	public static void checkCreateWebsiteAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
		
			String
			websitename="www."+CommonUtil.getUniqueMessage()+".com"
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(APP_WEBSITE,websitename);
			
			JSONObject payload = GetPayload.getCreateWebsite(websitename);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_WEBSITE_CREATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetWebsiteConfig(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{		
		try
		{			
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_WEBSITE_GET,null,null,null,startKey));	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	
	public static void checkUpdateWebsiteConfigAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();
			String
			website_name = "testapp"+CommonUtil.getUniqueMessage(),
			allow_in_multiple_websites = BOOLEAN_VALUES[randomId%2],
			enabled = BOOLEAN_VALUES[randomId%2],
			url = "www."+website_name+".com"
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(KEYS,website_name,allow_in_multiple_websites,enabled,url);
			
			JSONObject payload = GetPayload.getWebsiteConfigUpdatePayload(website_name,allow_in_multiple_websites,enabled,url);
					
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_WEBSITE_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	
	public static void checkUpdateWebsiteComponentsToBeEnabledAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String[]
			components = {COMPONENTS[randomId%2],COMPONENTS[(randomId+1)%2]}
			;

			JSONObject payload = GetPayload.getComponentsPayload(components);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(COMPONENTS_KEY,components[0]+","+components[1]);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_WEBSITE_COMPONENTS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	

	public static Hashtable<String,String> getExpectedInfo(String[] keys,String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(keys[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}
	
	
}
