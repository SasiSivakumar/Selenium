//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class AppsMain
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String
	MODULE_NAME = "Apps Restapi",
	APP_NAME_KEY = "data_name",
	APP_UNIQUE_NAME_KEY = "data_unique_name",
	BUSINESS_HOURS_KEY = "data_business_hours",
	PRIVACY_KEY = "data_privacy",
	IS_RESPONSE = "isResponse"
	;

	public static final String[]
	BUSINESS_HOURS = {"true","false"},
	PRIVACY = {"false","true"},
	KEYS = {APP_NAME_KEY,APP_UNIQUE_NAME_KEY,BUSINESS_HOURS_KEY,PRIVACY_KEY}
	;

	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api1");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check create an app API",MODULE_NAME);
			checkCreateAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,984,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check get list of apps API",MODULE_NAME);
			checkGetListOfAppsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,987,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check get details of an app API",MODULE_NAME);
			checkGetDetailsOfAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,989,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check update details of an app API",MODULE_NAME);
			checkUpdateAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,991,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check delete an app API",MODULE_NAME);
			checkDeleteAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,994,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");

			etest = ComplexReportFactory.getEtest("Supervisor -- Check create an app API",MODULE_NAME);
			checkCreateAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,996,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check get list of apps API",MODULE_NAME);
			checkGetListOfAppsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,999,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check get details of an app API",MODULE_NAME);
			checkGetDetailsOfAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1001,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check update details of an app API",MODULE_NAME);
			checkUpdateAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1003,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check delete an app API",MODULE_NAME);
			checkDeleteAppAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1006,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest = ComplexReportFactory.getEtest("Associate -- Check create an app API",MODULE_NAME);
			checkCreateAppAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1008,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check get list of apps API",MODULE_NAME);
			checkGetListOfAppsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1009,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check get details of an app API",MODULE_NAME);
			checkGetDetailsOfAppAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1010,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check update details of an app API",MODULE_NAME);
			checkUpdateAppAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1011,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check delete an app API",MODULE_NAME);
			checkDeleteAppAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1012,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check create an app API",MODULE_NAME);
			checkCreateAppAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1013,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check get list of apps API",MODULE_NAME);
			checkGetListOfAppsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1014,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check get details of an app API",MODULE_NAME);
			checkGetDetailsOfAppAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1015,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check update details of an app API",MODULE_NAME);
			checkUpdateAppAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1016,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Invalid Scope -- Check delete an app API",MODULE_NAME);
			checkDeleteAppAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1017,etest);
			ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkCreateAppAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int key = CommonUtil.getRandomId();
			String
			appName = "testapp"+CommonUtil.getUniqueMessage(),
			businessHours = BUSINESS_HOURS[key%2],
			privacy = PRIVACY[key%2]
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(appName,appName,businessHours,privacy);

			JSONObject payload = GetPayload.getAppsCreatePayload(appName,businessHours,privacy);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,Api.APPS_CREATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetListOfAppsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,Api.APPS_GET_LIST,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetDetailsOfAppAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_GET,null,null,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateAppAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int key = CommonUtil.getRandomId();
			String
			appName = "testapp"+CommonUtil.getUniqueMessage(),
			businessHours = BUSINESS_HOURS[key%2],
			privacy = PRIVACY[key%2]
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(appName,null,businessHours,privacy);

			JSONObject payload = GetPayload.getAppsUpdatePayload(appName,businessHours,privacy);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkDeleteAppAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_DELETE,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getExpectedInfo(String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(KEYS[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}
}
