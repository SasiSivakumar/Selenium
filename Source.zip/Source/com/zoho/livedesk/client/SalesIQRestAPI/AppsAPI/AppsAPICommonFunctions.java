//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.List;
import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;
import org.json.JSONArray;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class AppsAPICommonFunctions
{
	public static final String 
	DATA_ID = "data/id",
	FIELD_ID = "data/fields[0]/id",
	REPLACE_STRING = "<id>",
	FIELD_REPLACE_STRING = "<field_id>",
	WIDGET_CODE_REPLACE_STRING = "<widgetcode>",
	APP_NAME = "app_name",
	WIDGET_CODE = "data_code",
	DATA_WIDGET_CODE = "data_widget_code",
	DATA_CHAT_CODE = "data_chat_code",
	APP_ID = "app_id",
	NAME = "<name>",
	ACCESS_KEY_ENABLED = "data[1]/enabled",
	APP_KEY = "data/app_key",
	ACCESS_KEY = "data/access_keys[0]/key",
	BUNDLE_ID = "data/bundle_id"
	;

	public static final By
	EMBED_LIST = By.id("embedlist"),
	LIST_ROW = By.className("list-row")
	;

	public static Hashtable<String,Boolean> checkAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,boolean toCheckInUI,String response_code,boolean isReplace,Api api_obj,JSONObject payload,Hashtable<String,String> expectedIntegInfo,Hashtable<String,String> integInfoFromUI,int startKey) throws Exception
	{
		boolean isPayload = (payload != null);	
		boolean isResponse = (response_code == Constants.SUCCESS_CODE)?true:false;
		String fieldId = "1234567890";

		if(expectedIntegInfo != null && expectedIntegInfo.containsKey("isResponse") && expectedIntegInfo.get("isResponse").contains("false"))
		{
			isResponse = false;
		}

		Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
		Hashtable<String,String> channelDetails = new Hashtable<String,String>();

		try
		{
			String
			appName = "testapp"+CommonUtil.getUniqueMessage(),
			keys_check_usecase = "RESTAPI" + startKey,
			api_values_usecase = "RESTAPI" + (++startKey),
			ui_values_usecase = "RESTAPI" + (++startKey),
			appId = "app not created",
			widgetCode = appId
			;

			if(expectedIntegInfo == null)
			{
				expectedIntegInfo = new Hashtable<String,String>();
			}

			if(expectedIntegInfo != null && expectedIntegInfo.containsKey("app"))
			{
				appName = expectedIntegInfo.get("app");
			}

			if(((api_obj != Api.APPS_CREATE) && (isResponse)) || (response_code == Constants.SUCCESS_CODE && (expectedIntegInfo != null && expectedIntegInfo.containsKey("isResponse") && expectedIntegInfo.get("isResponse").contains("false"))))
			{
				try
				{
					appId = createApp(driver,appName,api_webdriver,etest);
					CommonUtil.refreshPage(driver);
					widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,appName);

					CommonUtil.print("expectedIntegInfo1<><>"+expectedIntegInfo);

					if(expectedIntegInfo != null && expectedIntegInfo.containsKey("isIos") && expectedIntegInfo.get("isIos").contains("true"))
					{
						createChannel(driver,api_webdriver,appId,Api.APPS_IOS_CREATE,etest);
					}

					if(expectedIntegInfo != null && expectedIntegInfo.containsKey("isAndroid") && expectedIntegInfo.get("isAndroid").contains("true"))
					{
						createChannel(driver,api_webdriver,appId,Api.APPS_ANDROID_CREATE,etest);
					}

					if((api_obj == Api.APPS_IOS_ACCESS_KEYS_DELETE) || (api_obj == Api.APPS_IOS_ACCESS_KEYS_UPDATE))
					{
						createAccesskeys(driver,api_webdriver,appId,Api.APPS_IOS_ACCESS_KEYS_CREATE,etest);
					}
					else if((api_obj == Api.APPS_ANDROID_ACCESS_KEYS_DELETE) || (api_obj == Api.APPS_ANDROID_ACCESS_KEYS_UPDATE))
					{
						createAccesskeys(driver,api_webdriver,appId,Api.APPS_ANDROID_ACCESS_KEYS_CREATE,etest);
					}
				}
				catch(Exception e)
				{
					CommonUtil.printStackTrace(e);
				}
			}

			if(expectedIntegInfo != null && expectedIntegInfo.containsKey("app"))
			{
				try
				{
					appName = expectedIntegInfo.get("app");
					CommonUtil.refreshPage(driver);
					appId = ExecuteStatements.getWebsiteIDFromEmbedName(driver,appName);
					widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,appName);
					etest.info("appName<><>"+appName+"<br>appId<><>"+appId+"<br>widgetcode<><>"+widgetCode);
				}
				catch(Exception e)
				{
					CommonUtil.printStackTrace(e);
				}
			}
			else if((api_obj != Api.APPS_CREATE) && (appId == "app not created"))
			{
				try
				{
					CommonUtil.refreshPage(driver);
					appName = ExecuteStatements.getRandomWebsiteName(driver);
					appId = ExecuteStatements.getWebsiteIDFromEmbedName(driver,appName);
					CommonUtil.refreshPage(driver);
					widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,appName);
				}
				catch(Exception e)
				{
					CommonUtil.printStackTrace(e);
				}
			}

			if(expectedIntegInfo != null && expectedIntegInfo.containsKey("isIos") && expectedIntegInfo.get("isIos").contains("true"))
			{
				channelDetails = getChannelDetails(driver,api_webdriver,appId,Api.APPS_IOS_GET,etest);
			}

			if(expectedIntegInfo != null && expectedIntegInfo.containsKey("isAndroid") && expectedIntegInfo.get("isAndroid").contains("true"))
			{
				channelDetails = getChannelDetails(driver,api_webdriver,appId,Api.APPS_ANDROID_GET,etest);
			}

			if(api_obj == Api.APPS_WEBSITE_VISITOR_API_GET)
			{
				api_obj.api_template=api_obj.api_template.replace(WIDGET_CODE_REPLACE_STRING,widgetCode);
			}
			else if(api_obj == Api.APPS_ANDROID_VISITOR_API_GET || api_obj == Api.APPS_IOS_VISITOR_API_GET)
			{
				api_obj.api_template = SalesIQRestAPICommonFunctions.addHeader(api_obj.api_template,APIKeys.X_ACCESS_KEY,channelDetails.get("accessKey"));
				api_obj.api_template = SalesIQRestAPICommonFunctions.addHeader(api_obj.api_template,APIKeys.X_APP_KEY,channelDetails.get("appKey"));
				api_obj.api_template = SalesIQRestAPICommonFunctions.addHeader(api_obj.api_template,APIKeys.X_BUNDLE_ID,"test");
				api_obj.api_template = SalesIQRestAPICommonFunctions.addHeader(api_obj.api_template,APIKeys.X_MOBILISTEN_VERSION,"1");
			}


			expectedIntegInfo.put(APP_ID,appId);
			expectedIntegInfo.put(APP_NAME,appName);
			expectedIntegInfo.put(WIDGET_CODE,widgetCode);
			expectedIntegInfo.put(DATA_WIDGET_CODE,widgetCode);
			expectedIntegInfo.put(DATA_CHAT_CODE,widgetCode);

			etest.info("expectedIntegInfo<><>"+expectedIntegInfo);

			if(api_obj.api_template.contains(FIELD_REPLACE_STRING))
			{
				fieldId = getFieldIdFromPreChat(api_webdriver,driver,appId,etest);
				api_obj.api_template = api_obj.api_template.replace(FIELD_REPLACE_STRING,fieldId);
			}

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,REPLACE_STRING,appId,api_obj,isPayload,payload,etest);

			api_obj.api_template = api_obj.api_template.replace(fieldId,FIELD_REPLACE_STRING);

			if(isResponse)
			{
				try
				{
					result.put(keys_check_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED KEYS ARE FOUND</b>");

					if(new JSONObject(response).has("error"))
					{
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys));
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}

				try
				{
					result.put(api_values_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN API RESPONSE</b>");

					if(new JSONObject(response).has("error"))
					{
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(api_values_usecase,checkData(expectedIntegInfo,null,keys_check_usecase,response,false,etest));
					}

					if(!result.get(api_values_usecase))
					{
						TakeScreenshot.screenshot(api_webdriver,etest);
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}
			}
			else
			{
				result.put(keys_check_usecase,false);

				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else if(new JSONObject(response).has("error"))
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if((actualResponseCode != "") && (CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest)))
				{
					result.put(keys_check_usecase,true);
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					result.put(keys_check_usecase,false);
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
				}

				if((api_obj == Api.APPS_FIELD_DELETE) && (response_code == Constants.SUCCESS_CODE))
				{
					String currentFieldId = getFieldIdFromPreChat(api_webdriver,driver,appId,etest);

					if(currentFieldId == fieldId)
					{
						result.put(api_values_usecase,false);
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(api_values_usecase,true);
						etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(api_values_usecase)+" -- Success</b>");
					}
				}
				else if((api_obj == Api.APPS_IOS_ACCESS_KEYS_UPDATE) && (response_code == Constants.SUCCESS_CODE))
				{
					String enabledStatus = getEnabledStatusForIosAccessKeys(api_webdriver,driver,appId,etest);

					if(enabledStatus != expectedIntegInfo.get("data_enabled"))
					{
						result.put(api_values_usecase,false);
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(api_values_usecase,true);
						etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(api_values_usecase)+" -- Success</b>");
					}
				}
				else if((api_obj == Api.APPS_IOS_ACCESS_KEYS_DELETE) && (response_code == Constants.SUCCESS_CODE))
				{
					boolean isAccessKeyDeleted = checkIosAccessKeyDeleted(api_webdriver,driver,appId,etest);

					if(isAccessKeyDeleted)
					{
						result.put(api_values_usecase,true);
						etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(api_values_usecase)+" -- Success</b>");
					}
					else
					{
						result.put(api_values_usecase,false);
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
				}
				else if((api_obj == Api.APPS_ANDROID_ACCESS_KEYS_UPDATE) && (response_code == Constants.SUCCESS_CODE))
				{
					String enabledStatus = getEnabledStatusForAndroidAccessKeys(api_webdriver,driver,appId,etest);

					if(enabledStatus != expectedIntegInfo.get("data_enabled"))
					{
						result.put(api_values_usecase,false);
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(api_values_usecase,true);
						etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(api_values_usecase)+" -- Success</b>");
					}
				}
				else if((api_obj == Api.APPS_ANDROID_ACCESS_KEYS_DELETE) && (response_code == Constants.SUCCESS_CODE))
				{
					boolean isAccessKeyDeleted = checkAndroidAccessKeyDeleted(api_webdriver,driver,appId,etest);

					if(isAccessKeyDeleted)
					{
						result.put(api_values_usecase,true);
						etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(api_values_usecase)+" -- Success</b>");
					}
					else
					{
						result.put(api_values_usecase,false);
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
				}
				else
				{
					ui_values_usecase = api_values_usecase;
				}
			}

			if((toCheckInUI) && (response_code == Constants.SUCCESS_CODE))
			{
				try
				{
					// not to check for now since apps module not completely moved
					result.put(ui_values_usecase,true);

					// result.put(ui_values_usecase,false);

					// etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN UI</b>");

					// result.put(ui_values_usecase,checkData(expectedIntegInfo,integInfoFromUI,keys_check_usecase,response,true,etest));
					// if(!result.get(ui_values_usecase))
					// {
					// 	TakeScreenshot.screenshot(driver,etest);
					// }
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
		return result;
	}

	public static boolean checkData(Hashtable<String,String> expected,Hashtable<String,String> valuesFromUI,String keyToCheck,String response,boolean isUI,ExtentTest etest) throws Exception
	{
		String expected_value,actual_value;

		String[] keysToCheck = RestAPIConfManager.getRealValue(keyToCheck+"_keys").split(",");

		int failcount = 0;
		int index = 0;

		if(keysToCheck[0].contains(REPLACE_STRING))
        {
			index = getIndex( response,expected.get(APP_ID),etest );
		}

		expected = getExpectedInfo(expected,keyToCheck,index,expected.get(APP_NAME));

        for(int i = 0; i < keysToCheck.length; i++)
        {
        	try
        	{
	        	if(keysToCheck[i].contains(REPLACE_STRING))
	        	{
	        		keysToCheck[i] = keysToCheck[i].replace( REPLACE_STRING,index+"" );
	        	}
	        	etest.log(Status.INFO,"Checking "+keysToCheck[i]);

	        	if(isUI)
	        	{
		    		expected_value = expected.get(keysToCheck[i].replaceAll("/","_").replace("[0]",""));
		    		actual_value = valuesFromUI.get(keysToCheck[i].replaceAll("/","_").replace("[0]",""));
		    	}
		    	else
		    	{
		    		actual_value = expected.get(keysToCheck[i].replaceAll("/","_").replace("[0]",""));
		    		expected_value = SalesIQRestAPICommonFunctions.jPath(response,keysToCheck[i]);
		    	}

		    	// uncomment below for checking values if exception thrown before the below string check
		    	// etest.info("<pre>expected_value - "+expected_value+"<br>actual_value - "+actual_value+"</pre>");

	    		if((expected_value.contains(",")) && isUI )
	    		{
	    			String[] values = expected_value.replace("]","").replace("[","").split(",");
	    			for(String value : values)
	    			{
		    			if(!CommonUtil.checkStringContainsAndLog(value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
			    		{
			    			failcount++;
			    		}
	    			}
	    		}
	    		else if((actual_value.contains(",")) && !isUI)
	    		{
	    			String[] values = actual_value.replace("]","").replace("[","").split(",");
	    			for(String value : values)
	    			{
		    			if(!CommonUtil.checkStringContainsAndLog(value,expected_value,"value for key '"+keysToCheck[i]+"' ",etest))
			    		{
			    			failcount++;
			    		}
	    			}
	    		}
	    		else 
	    		{
	    			if(!CommonUtil.checkStringContainsAndLog(expected_value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
		    		{
		    			failcount++;
		    		}
		    	}
		    }
		    catch(Exception e)
		    {
		    	failcount++;
		    	etest.log(Status.FAIL,"Expected key not present in the response");
		    	CommonUtil.printStackTrace(e);
		    }
        }

        return CommonUtil.returnResult(failcount);
	}

	public static String createApp(WebDriver driver,String appName,WebDriver api_webdriver,ExtentTest etest)
	{
		String appId = "app not created";
		try
		{
			JSONObject payload = GetPayload.getAppsCreatePayload(appName,null,null);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),false,"","",Api.APPS_CREATE,true,payload,etest);

			appId = SalesIQRestAPICommonFunctions.jPath(response,DATA_ID);
		}
		catch(Exception e)
		{
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(api_webdriver,etest);
		}
		return appId;
	}

	public static Hashtable<String,String> getExpectedInfo(Hashtable<String,String> expected,String keyToCheck,int index,String appName)
	{
		String[] expectedKey = RestAPIConfManager.getRealValue(keyToCheck+"_keys").split(",");
		String[] expectedValues = RestAPIConfManager.getRealValue(keyToCheck+"_values").split(",");

		for(int i = 0; i < expectedKey.length;i++)
		{
			CommonUtil.print("\nexpectedkey"+keyToCheck+"<><>"+expectedKey[i]+"\nexpectedValues"+keyToCheck+"<><>"+expectedValues[i]);

			if(expectedKey[i].contains(REPLACE_STRING))
			{
				expectedKey[i] = expectedKey[i].replace( REPLACE_STRING,index+"" );
			}
			if(expectedValues[i].contains(NAME))
			{
				expectedValues[i] = appName;
			}

			CommonUtil.print("\nexpectedkey"+keyToCheck+"<><>"+expectedKey[i]+"--\nexpectedValues"+keyToCheck+"<><>"+expectedValues[i]+"--");

			expectedValues[i] = expectedValues[i].replaceAll("_",",");

			if(!expected.containsKey(expectedKey[i].replaceAll("/","_").replace("[0]","")))
			{
				expected.put(expectedKey[i].replaceAll("/","_").replace("[0]",""),expectedValues[i]);
			}

			CommonUtil.print("\nexpected"+keyToCheck+"<><>"+expected);

		}

		CommonUtil.print("expected"+keyToCheck+"<><>"+expected);

		return expected;
	}

	public static void deleteAllApps(WebDriver driver,WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			// ArrayList<String> ignore_list = new ArrayList<String>();
			// Cleanup.deleteAllWebsitesExcept(driver,ignore_list);

			Tab.navToEmbedTab(driver);
			String defaultEmbed = ExecuteStatements.getDefaultEmbedName(driver);
			List<WebElement> embedList = CommonUtil.getElement(driver,EMBED_LIST).findElements(LIST_ROW);
			List<String> list_ids=CommonUtil.getAttributesFromList(embedList,"id");

        	for(String id : list_ids)
			{
				WebElement element=CommonUtil.getElement(driver,By.id(id),Cleanup.WEBSITES_AND_DEPARMENTS);

	            if(!element.getText().toLowerCase().contains(defaultEmbed.toLowerCase()))
				{
					String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,id,Api.APPS_DELETE,false,null,etest);
					etest.log(Status.INFO,"Below json is the response");
					SalesIQRestAPICommonFunctions.log(etest,response);
				}
			}

			etest.info("All apps except default were deleted");
			TakeScreenshot.infoScreenshot(driver,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
		}
	}

	public static Hashtable<String,String> createChannel(WebDriver driver,WebDriver api_webdriver,String appId,Api api_obj,ExtentTest etest)
	{
		Hashtable<String,String> channelDetails = new Hashtable<String,String>();
		try
		{
			JSONObject payload = GetPayload.getCreateChannelPayload("test");
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,appId,api_obj,true,payload,etest);

			String appKey = SalesIQRestAPICommonFunctions.jPath(response,APP_KEY);
			String accessKey = SalesIQRestAPICommonFunctions.jPath(response,ACCESS_KEY);
			String bundleId = SalesIQRestAPICommonFunctions.jPath(response,BUNDLE_ID);

			channelDetails.put("appKey",appKey);
			channelDetails.put("accessKey",accessKey);
			channelDetails.put("bundleId",bundleId);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return channelDetails;
	}

	public static int getIndex(String response,String id,ExtentTest etest)
	{
		int index = 0;
		try
		{
			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			JSONArray appsArray = json_response.getJSONArray("data");
			index = SalesIQRestAPICommonFunctions.getJSONIndexWith(appsArray,"id",id);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
		return index;
	}

	public static String getFieldIdFromPreChat(WebDriver api_webdriver,WebDriver driver,String app_id,ExtentTest etest)
	{
		String fieldId = "1234567890";
		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,app_id,Api.APPS_PRE_CHAT_FORM_GET,false,null,etest);

			fieldId = SalesIQRestAPICommonFunctions.jPath(response,FIELD_ID);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return fieldId;
	}

	public static void createAccesskeys(WebDriver driver,WebDriver api_webdriver,String appId,Api api_obj,ExtentTest etest)
	{
		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,appId,api_obj,false,null,etest);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public static String getEnabledStatusForAccessKeys(WebDriver api_webdriver,WebDriver driver,String app_id,Api api_obj,ExtentTest etest)
	{
		String enabledStatus = "";
		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,app_id,api_obj,false,null,etest);

			enabledStatus = SalesIQRestAPICommonFunctions.jPath(response,ACCESS_KEY_ENABLED);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return enabledStatus;
	}

	public static boolean checkAccessKeyDeleted(WebDriver api_webdriver,WebDriver driver,String app_id,Api api_obj,ExtentTest etest)
	{
		String enabledStatus = "";
		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,app_id,api_obj,false,null,etest);

			try
			{
				enabledStatus = SalesIQRestAPICommonFunctions.jPath(response,ACCESS_KEY_ENABLED);
			}
			catch(Exception e)
			{
				return true;
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return false;
	}

	public static String getEnabledStatusForIosAccessKeys(WebDriver api_webdriver,WebDriver driver,String app_id,ExtentTest etest)
	{
		return getEnabledStatusForAccessKeys(api_webdriver,driver,app_id,Api.APPS_IOS_ACCESS_KEYS_GET,etest);
	}

	public static boolean checkIosAccessKeyDeleted(WebDriver api_webdriver,WebDriver driver,String app_id,ExtentTest etest)
	{
		return checkAccessKeyDeleted(api_webdriver,driver,app_id,Api.APPS_IOS_ACCESS_KEYS_GET,etest);
	}

	public static String getEnabledStatusForAndroidAccessKeys(WebDriver api_webdriver,WebDriver driver,String app_id,ExtentTest etest)
	{
		return getEnabledStatusForAccessKeys(api_webdriver,driver,app_id,Api.APPS_ANDROID_ACCESS_KEYS_GET,etest);
	}

	public static boolean checkAndroidAccessKeyDeleted(WebDriver api_webdriver,WebDriver driver,String app_id,ExtentTest etest)
	{
		return checkAccessKeyDeleted(api_webdriver,driver,app_id,Api.APPS_ANDROID_ACCESS_KEYS_GET,etest);
	}

	public static Hashtable<String,String> getChannelDetails(WebDriver driver,WebDriver api_webdriver,String appId,Api api_obj,ExtentTest etest)
	{
		Hashtable<String,String> channelDetails = new Hashtable<String,String>();
		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,REPLACE_STRING,appId,api_obj,false,null,etest);

			String appKey = SalesIQRestAPICommonFunctions.jPath(response,APP_KEY);
			String accessKey = SalesIQRestAPICommonFunctions.jPath(response,ACCESS_KEY);
			String bundleId = SalesIQRestAPICommonFunctions.jPath(response,BUNDLE_ID);

			channelDetails.put("appKey",appKey);
			channelDetails.put("accessKey",accessKey);
			channelDetails.put("bundleId",bundleId);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return channelDetails;
	}

}
