//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.Api;
import com.zoho.livedesk.client.SalesIQRestAPI.Constants;
import com.zoho.livedesk.client.SalesIQRestAPI.GetPayload;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPIModule;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;

public class AppsEmailSignature {

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	public static final String MODULE_NAME = "Apps Restapi";
	
	public static final String
	ENABLED_KEY = "data_enabled",
	STICKER_KEY="data_sticker",
	BACKGROUND_KEY="data_background",
	SHOW_CONTACT_INFO_KEY="data_show_contact_info",
	SHOW_COMPANY_INFO_KEY="data_show_company_info",
	SHOW_COMPANY_LOGO_KEY="data_show_company_logo",
	COMPONENTS_KEY="data_components"
	;

	public static final String[]
	COMPONENTS = {"chat","call","faq"},		
	KEYS = {ENABLED_KEY,STICKER_KEY,SHOW_COMPANY_LOGO_KEY,SHOW_COMPANY_INFO_KEY,SHOW_CONTACT_INFO_KEY,BACKGROUND_KEY},
	COMPONENTS_KEYS = {COMPONENTS_KEY},
	BOOLEAN_VALUES = {"true","false"},
	STICKER = {"ebony","abyss","blast","wilderness","ecstasy","eclipse","luna"}
	;


	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{		
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api3");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Get Email Signature Configurations",MODULE_NAME);
			checkGetEmailSignatureConfigToApp(driver,api_webdriver,Constants.SUCCESS_CODE,1248,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Add Email Signature to App",MODULE_NAME);
			checkAddEmailSignatureToApp(driver,api_webdriver,Constants.CHANNEL_ALREADY_EXISTS_CODE,1250,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Update Email Signature Configurations",MODULE_NAME);
			checkUpdateEmailSignatureConfigToApp(driver,api_webdriver,Constants.SUCCESS_CODE,1253,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Update Email signature Components",MODULE_NAME);
			checkUpdateEmailSignatureComponentsToApp(driver,api_webdriver,Constants.SUCCESS_CODE,1256,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");
			
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Get Email Signature Configurations",MODULE_NAME);
			checkGetEmailSignatureConfigToApp(driver,api_webdriver,Constants.SUCCESS_CODE,1259,etest);
			ComplexReportFactory.closeTest(etest);

			etest= ComplexReportFactory.getEtest("Supervisor -- Check Add Email Signature to App",MODULE_NAME);
			checkAddEmailSignatureToApp(driver,api_webdriver,Constants.CHANNEL_ALREADY_EXISTS_CODE,1261,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Update Email Signature Configurations",MODULE_NAME);
			checkUpdateEmailSignatureConfigToApp(driver,api_webdriver,Constants.SUCCESS_CODE,1264,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Supervisor -- Check Update Email signature Components",MODULE_NAME);
			checkUpdateEmailSignatureComponentsToApp(driver,api_webdriver,Constants.SUCCESS_CODE,1267,etest);
			ComplexReportFactory.closeTest(etest);
	
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest= ComplexReportFactory.getEtest("Associate -- Check Add Email Signature to Apps",MODULE_NAME);
			checkAddEmailSignatureToApp(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1270,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Associate -- Check Get Email Signature Configurations",MODULE_NAME);
			checkGetEmailSignatureConfigToApp(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1271,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Associate -- Check Update Email Signature Configurations",MODULE_NAME);
			checkUpdateEmailSignatureConfigToApp(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1272,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Associate -- Check Update Email signature Components",MODULE_NAME);
			checkUpdateEmailSignatureComponentsToApp(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1273,etest);
			ComplexReportFactory.closeTest(etest);			
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");
						
			etest= ComplexReportFactory.getEtest("Check Invalid Scope -- Check Add Email Signature to Apps",MODULE_NAME);
			checkAddEmailSignatureToApp(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1274,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Invalid Scope -- Check Get Email Signature Configurations",MODULE_NAME);
			checkGetEmailSignatureConfigToApp(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1275,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update Email Signature Configurationss",MODULE_NAME);
			checkUpdateEmailSignatureConfigToApp(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1276,etest);
			ComplexReportFactory.closeTest(etest);
			
			etest= ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update Email signature Components",MODULE_NAME);
			checkUpdateEmailSignatureComponentsToApp(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1277,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkAddEmailSignatureToApp(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{	

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_EMAIL_SIGNATURE_CREATE,null,null,null,startKey));	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetEmailSignatureConfigToApp(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{	
			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_EMAIL_SIGNATURE_GET,null,null,null,startKey));	
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateEmailSignatureConfigToApp(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();
			String
			enabled = BOOLEAN_VALUES[randomId%2],
			sticker = STICKER[randomId%7],
			show_company_logo = BOOLEAN_VALUES[randomId%2],
			show_company_info = BOOLEAN_VALUES[randomId%2],
			show_contact_info = BOOLEAN_VALUES[randomId%2],
			background = (randomId % 4) + ""
			;

			Hashtable<String,String> expectedInfo = getExpectedInfo(KEYS,enabled,sticker,show_company_logo,show_company_info,show_contact_info,background);
			JSONObject payload = GetPayload.getEmailSignatureConfigUpdatePayload(enabled,sticker,show_company_logo,show_company_info,show_contact_info,background);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_EMAIL_SIGNATURE_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	public static void checkUpdateEmailSignatureComponentsToApp(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String[]
			components = {COMPONENTS[randomId%2],COMPONENTS[(randomId+1)%2]}
			;

			JSONObject payload = GetPayload.getComponentsPayload(components);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(COMPONENTS_KEY,components[0]+","+components[1]);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_EMAIL_SIGNATURE_COMPONENTS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	public static Hashtable<String,String> getExpectedInfo(String[] keys,String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(keys[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}
	
	
	
}
