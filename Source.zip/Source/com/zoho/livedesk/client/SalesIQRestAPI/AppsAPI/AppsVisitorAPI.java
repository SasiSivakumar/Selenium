//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class AppsVisitorAPI
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String
	MODULE_NAME = "Apps Restapi",
	IS_ANDROID = "isAndroid",
	APP_NAME = "app",
	IS_IOS = "isIos"
	;

	public static String
	websiteAppName = "website_app",
	androidAppName = "android_app",
	iosAppName = "ios_app"
	;

	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

            websiteAppName = websiteAppName + CommonUtil.getUniqueMessage();
			androidAppName = androidAppName + CommonUtil.getUniqueMessage();
			iosAppName = iosAppName + CommonUtil.getUniqueMessage(); 

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api3");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check website visitor API",MODULE_NAME);
			checkWebsiteVisitorAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1278,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Android visitor API",MODULE_NAME);
			checkAndroidVisitorAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1280,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Ios visitor API",MODULE_NAME);
			checkIosVisitorAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1282,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkWebsiteVisitorAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(APP_NAME,websiteAppName);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,Api.APPS_WEBSITE_VISITOR_API_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkAndroidVisitorAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(APP_NAME,androidAppName);
			expectedInfo.put(IS_ANDROID,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,Api.APPS_ANDROID_VISITOR_API_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkIosVisitorAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(APP_NAME,iosAppName);
			expectedInfo.put(IS_IOS,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,Api.APPS_IOS_VISITOR_API_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


}
