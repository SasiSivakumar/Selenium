//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI;

import java.util.Hashtable;
import java.util.ArrayList;

import org.json.JSONObject;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class AppsIOS
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String
	MODULE_NAME = "Apps Restapi",
	BUNDLE_NAME_KEY = "data_bundle_name",
	IS_IOS = "isIos",
	ENABLED = "data_enabled",
	SANDBOX_NOTIFICATIONS = "data_sandbox_notifications_enabled",
	PRODUCTION_NOTIFICATIONS = "data_production_notifications_enabled",
	SANDBOX_NOTIFICATIONS_PASSWORD = "data_sandbox_notifications_password",
	PRODUCTION_NOTIFICATIONS_PASSWORD = "data_production_notifications_password",
	COMPONENTS_KEY = "data_components",
	IS_RESPONSE = "isResponse"
	;

	public static final String[]
	COMPONENTS = {"chat","proactive","faq"},
	UPDATE_IOS_KEYS = {ENABLED,SANDBOX_NOTIFICATIONS,SANDBOX_NOTIFICATIONS_PASSWORD,PRODUCTION_NOTIFICATIONS,PRODUCTION_NOTIFICATIONS_PASSWORD},
	BOOLEAN_VALUES = {"true","false"}
	;

	public static Hashtable test(WebDriver driver)
	{
		WebDriver api_webdriver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

			api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api2");

			etest = ComplexReportFactory.getEtest("Initial Setup deleting all apps except default",MODULE_NAME);
			AppsAPICommonFunctions.deleteAllApps(driver,api_webdriver,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check create ios channel",MODULE_NAME);
			checkCreateIosChannel(driver,api_webdriver,Constants.SUCCESS_CODE,1102,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get ios channel Configuration",MODULE_NAME);
			checkGetIosChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1105,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update ios channel Configuration",MODULE_NAME);
			checkUpdateIosChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1107,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check create ios accesskeys",MODULE_NAME);
			checkCreateIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1110,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Get ios accesskeys",MODULE_NAME);
			checkGetIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1113,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update ios accesskeys",MODULE_NAME);
			checkUpdateIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1115,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Delete ios accesskeys",MODULE_NAME);
			checkDeleteIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1118,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update components for ios",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1120,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_supervisor");

			etest = ComplexReportFactory.getEtest("Supervisor -- Check create ios channel",MODULE_NAME);
			checkCreateIosChannel(driver,api_webdriver,Constants.SUCCESS_CODE,1123,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Get ios channel Configuration",MODULE_NAME);
			checkGetIosChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1126,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update ios channel Configuration",MODULE_NAME);
			checkUpdateIosChannelConfig(driver,api_webdriver,Constants.SUCCESS_CODE,1128,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check create ios accesskeys",MODULE_NAME);
			checkCreateIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1131,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Get ios accesskeys",MODULE_NAME);
			checkGetIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1134,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update ios accesskeys",MODULE_NAME);
			checkUpdateIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1136,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Delete ios accesskeys",MODULE_NAME);
			checkDeleteIosAccessKeys(driver,api_webdriver,Constants.SUCCESS_CODE,1139,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Supervisor -- Check Update components for ios",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,1141,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"apps_api_associate");

			etest = ComplexReportFactory.getEtest("Associate -- Check create ios channel",MODULE_NAME);
			checkCreateIosChannel(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1144,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Get ios channel Configuration",MODULE_NAME);
			checkGetIosChannelConfig(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1145,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update ios channel Configuration",MODULE_NAME);
			checkUpdateIosChannelConfig(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1146,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check create ios accesskeys",MODULE_NAME);
			checkCreateIosAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1147,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Get ios accesskeys",MODULE_NAME);
			checkGetIosAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1148,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update ios accesskeys",MODULE_NAME);
			checkUpdateIosAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1149,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Delete ios accesskeys",MODULE_NAME);
			checkDeleteIosAccessKeys(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1150,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Associate -- Check Update components for ios",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.ACCESS_DENIED_CODE,1151,etest);
			ComplexReportFactory.closeTest(etest);
			
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check create ios channel",MODULE_NAME);
			checkCreateIosChannel(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1152,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Get ios channel Configuration",MODULE_NAME);
			checkGetIosChannelConfig(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1153,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update ios channel Configuration",MODULE_NAME);
			checkUpdateIosChannelConfig(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1154,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check create ios accesskeys",MODULE_NAME);
			checkCreateIosAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1155,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Get ios accesskeys",MODULE_NAME);
			checkGetIosAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1156,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update ios accesskeys",MODULE_NAME);
			checkUpdateIosAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1157,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Delete ios accesskeys",MODULE_NAME);
			checkDeleteIosAccessKeys(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1158,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Update components for ios",MODULE_NAME);
			checkUpdateComponentsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,1159,etest);
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			Driver.quitDriver(api_webdriver);
		}
		return finalResult;
	}

	public static void checkCreateIosChannel(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String
			bundle_name = "bundle_name_"+randomId
			;

			JSONObject payload = GetPayload.getCreateChannelPayload(bundle_name);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(BUNDLE_NAME_KEY,bundle_name);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_IOS_CREATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetIosChannelConfig(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_IOS,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_IOS_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateIosChannelConfig(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String
			enabled = BOOLEAN_VALUES[startKey%2],
			password = (enabled == "true")?"password"+startKey:null,
			notification_enabled = (enabled == "true")?enabled:null
			;

			CommonUtil.print("channel update ios");

			JSONObject payload = GetPayload.getIOSUpdatePayload(enabled,password);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			CommonUtil.print("channel update ios 4");

			Hashtable<String,String> expectedInfo = getExpectedInfo(UPDATE_IOS_KEYS,enabled,notification_enabled,password,notification_enabled,password);
			expectedInfo.put(IS_IOS,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_IOS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkCreateIosAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_IOS,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_IOS_ACCESS_KEYS_CREATE,null,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetIosAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_IOS,"true");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_IOS_ACCESS_KEYS_GET,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateIosAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String
			enabled = BOOLEAN_VALUES[randomId%2]
			;

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_IOS,"true");
			expectedInfo.put(ENABLED,enabled);
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_IOS_ACCESS_KEYS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkDeleteIosAccessKeys(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_IOS,"true");
			expectedInfo.put(IS_RESPONSE,"false");

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,true,Api.APPS_IOS_ACCESS_KEYS_DELETE,null,expectedInfo,null,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateComponentsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = CommonUtil.getRandomId();

			String[]
			components = {COMPONENTS[randomId%2],COMPONENTS[(randomId+1)%2]}
			;

			JSONObject payload = GetPayload.getComponentsPayload(components);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(IS_IOS,"true");
			expectedInfo.put(COMPONENTS_KEY,components[0]+","+components[1]);

			result.putAll(AppsAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,Api.APPS_IOS_COMPONENTS_UPDATE,payload,expectedInfo,getIntegInfoFromUI(driver),startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getExpectedInfo(String[] keys,String... values)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		for(int i = 0; i < values.length; i++)
		{
			if(values[i] != null)
			{
				info.put(keys[i],values[i]);
			}
		}
		return info;
	}

	public static Hashtable<String,String> getIntegInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		// logic to get all info from ui

		return info;
	}
}
