//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.DistributedTest;

import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPICRMInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPIDeskInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPIZendeskInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPICampaignInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPIMailChimpInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPISalesforceInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPIGAnalyticsInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPIClearbitRevealInteg;
import com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI.RESTAPIClearbitEnrichmentInteg;

public class SalesIQRESTAPIModule8 implements DistributedTest
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

	public void startThread(int thread_number) throws Exception
	{
		WebDriver driver = Functions.setUp();

		if(thread_number == 0)
        {
            Functions.login(driver,"integration_restapi1");
            try
            {
                Hashtable module_hashtable = RESTAPICRMInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = RESTAPISalesforceInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = RESTAPIClearbitRevealInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = RESTAPIClearbitEnrichmentInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }
        }
        else if(thread_number == 1)
        {
            Functions.login(driver,"integration_restapi2");
            try
            {
                Hashtable module_hashtable = RESTAPIDeskInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = RESTAPIZendeskInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = RESTAPIGAnalyticsInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }


            Driver.quitDriver(driver);
            driver = Functions.setUp();

            Functions.login(driver,"integration_restapi3");
            try
            {
                Hashtable module_hashtable = RESTAPICampaignInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = RESTAPIMailChimpInteg.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }
        }

        // else if(thread_number == 2)
        // {
        //     Functions.login(driver,"integration_restapi3");
        //     try
        //     {
        //         Hashtable module_hashtable = RESTAPICampaignInteg.test(driver);
        //         result.putAll((Hashtable) module_hashtable.get("result"));
        //         servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
        //     }
        //     catch(Exception e)
        //     {
        //         CommonUtil.printStackTrace(e);
        //     }

        //     try
        //     {
        //         Hashtable module_hashtable = RESTAPIMailChimpInteg.test(driver);
        //         result.putAll((Hashtable) module_hashtable.get("result"));
        //         servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
        //     }
        //     catch(Exception e)
        //     {
        //         CommonUtil.printStackTrace(e);
        //     }
        // }

        Functions.logout(driver);
	}

	public static Hashtable usecase() throws Exception
	{ 
        SalesIQRESTAPIModule8 usecases = new SalesIQRESTAPIModule8();
        Distributor distributor = new Distributor(usecases,2);
        distributor.initiate();

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
}
