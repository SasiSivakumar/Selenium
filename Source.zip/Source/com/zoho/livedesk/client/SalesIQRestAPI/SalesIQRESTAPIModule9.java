//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.DistributedTest;

import com.zoho.livedesk.client.SalesIQRestAPI.AppsAPI.*;

public class SalesIQRESTAPIModule9 implements DistributedTest
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

	public void startThread(int thread_number) throws Exception
	{
		WebDriver driver = Functions.setUp();

		if(thread_number == 0)
        {
            Functions.login(driver,"apps_api1");
            try
            {
                Hashtable module_hashtable = AppsMain.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = AppsWidgetsAndComponents.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = AppsFormsAndFields.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            Driver.quitDriver(driver);
            driver = Functions.setUp();

            Functions.login(driver,"apps_api2");
            try
            {
                Hashtable module_hashtable = AppsIOS.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = AppsAndroid.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }
            
            Driver.quitDriver(driver);
            driver = Functions.setUp();

            Functions.login(driver,"apps_api3");
            try
            {
                Hashtable module_hashtable = AppsWebsite.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }
            
            try
            {
                Hashtable module_hashtable = AppsEmailSignature.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }

            try
            {
                Hashtable module_hashtable = AppsVisitorAPI.test(driver);
                result.putAll((Hashtable) module_hashtable.get("result"));
                servicedown.putAll((Hashtable) module_hashtable.get("servicedown"));
            }
            catch(Exception e)
            {
                CommonUtil.printStackTrace(e);
            }
        }

        Functions.logout(driver);
	}

	public static Hashtable usecase() throws Exception
	{ 
        SalesIQRESTAPIModule9 usecases = new SalesIQRESTAPIModule9();
        Distributor distributor = new Distributor(usecases,1);
        distributor.initiate();

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
}
