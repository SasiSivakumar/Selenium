//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.AgentsSettings;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.BuildRejector;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class SalesIQRESTAPIModule5
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Rest API";
	public static String portal_name = "";

	public static VisitorDriverManager visitor_driver_manager;

	public static final String
	TITLE = "Updated title",
	EVENT = Constants.ACCESS_ANY_PAGE_ON_WEBSITE,
	ACTION_TYPE = "send_chat_invite",
	SENDER_NAME = "Updated Tester name",
	SENDER_VALUE = "UPdated message",
	DELAY = "20";

	public static String
	appId = "";
	public static final String[] OR_CRITERIA1 = new String[]{"browser","is_equal_to","apple_safari"};
	public static final String[] OR_CRITERIA2 = new String[]{"operating_system","is_equal_to","blackberry"};

	public static final String
	ID = "<id>"
	;

	public static final int
	ADMIN=0,
	INVALID_SCOPE=1,
	SUPERVISOR=2,
	ASSOCIATE=3
	;

	public static final String
	SUCCESS_CODE = "204"
	;

	public static final int
	GET_RULE=0,
	GET_RULES=1
	;

	// public static int key = 0;

	public static Hashtable test(WebDriver driver)
	{
		try
		{

			Cleanup.deleteAllTriggers(driver);

			appId = ExecuteStatements.getWebsiteIDFromEmbedName(driver,"website2");

			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

			WebDriver api_driver = Functions.setUp();
			api_driver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"trigger_admin");
			
			etest = ComplexReportFactory.getTest("Create Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createTriggerAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Get All Triggers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getAllTriggersAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Get a specific Triggers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getSpecificTriggersAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Update Triggers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateTriggersAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Delete a  Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteTriggerAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Enable a Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			enableTriggerAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Disable a Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			disableTriggerAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Update Trigger position API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateTriggerPositionAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Triggers Fieldmaps API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkFieldMapsTriggersAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);
        	
        	SalesIQRestAPICommonFunctions.setAuth(api_driver,"trigger_supervisor");

        	etest = ComplexReportFactory.getTest("Checking Create Trigger API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_CREATE,"RESTAPI535");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Get All Triggers API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_GET_LIST,"RESTAPI536");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Get a specific Triggers API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_GET,"RESTAPI537");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Update Triggers API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_UPDATE,"RESTAPI538");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Delete a  Trigger API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_DELETE,"RESTAPI539");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Enable a Trigger API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_ENABLE,"RESTAPI540");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Disable a Trigger API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_DISABLE,"RESTAPI541");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Update Trigger position API from supervisor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_UDPATE_POSITION,"RESTAPI542");
            ComplexReportFactory.closeTest(etest);

        	SalesIQRestAPICommonFunctions.setAuth(api_driver,"trigger_associate");

        	etest = ComplexReportFactory.getTest("Checking Create Trigger API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_CREATE,"RESTAPI543");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Get All Triggers API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_GET_LIST,"RESTAPI544");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Get a specific Triggers API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_GET,"RESTAPI545");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Update Triggers API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_UPDATE,"RESTAPI546");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Delete a  Trigger API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_DELETE,"RESTAPI547");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Enable a Trigger API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_ENABLE,"RESTAPI548");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Disable a Trigger API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_DISABLE,"RESTAPI549");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking Update Trigger position API from associate");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.PERMISSION_ERROR_CODE,Api.TRIGGER_UDPATE_POSITION,"RESTAPI550");
            ComplexReportFactory.closeTest(etest);

            SalesIQRestAPICommonFunctions.setAuth(api_driver,"inval");

        	etest = ComplexReportFactory.getTest("Checking invalid scope for Create Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_CREATE,"RESTAPI551");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Get All Triggers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_GET_LIST,"RESTAPI552");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Get a specific Triggers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_GET,"RESTAPI553");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Update Triggers API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_UPDATE,"RESTAPI554");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Delete a  Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_DELETE,"RESTAPI555");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Enable a Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_ENABLE,"RESTAPI556");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Disable a Trigger API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_DISABLE,"RESTAPI557");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Update Trigger position API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_UDPATE_POSITION,"RESTAPI558");
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Checking invalid scope for Trigger Criteriafields API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkErrorResponse(api_driver,driver,etest,Constants.INVALID_SCOPE_ERROR_CODE,Api.TRIGGER_UDPATE_POSITION,"RESTAPI559");
            ComplexReportFactory.closeTest(etest);

            Driver.quitDriver(api_driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	public static void createTriggerAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();

			Api create_rule_api = Api.TRIGGER_CREATE;

			String keys_check_usecase = "RESTAPI514",api_values_usecase = "RESTAPI515",ui_values_usecase = "RESTAPI516";

			String
			operator_id = ExecuteStatements.getOperatorId(driver),
			website = ExecuteStatements.getDefaultEmbedName(driver),
			app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			title = "Automation"+label,
			campaign_medium_value = "camp"+label,
			event = Constants.LANDS_ON_WEBSITE,
			action_type = Constants.SEND_CHAT_INVITE,
			sender_name = "Sender"+label,
			sender_value = "Hello"+label,
			delay = "10"
			;

			String[] or_criteria1 = new String[]{"country","is_equal_to","India"};
			String[] or_criteria2 = new String[]{"campaign_medium","contains",campaign_medium_value};

			String api = create_rule_api.get();
			api = api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload = GetPayload.getCreateTriggerPayload(app_id,title,event,action_type,sender_name,sender_value,delay,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_rule_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.INFO,"<pre>API "+api+"</pre>");
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_rule_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(api_values_usecase,isTriggerValuesFoundInResponse(driver,etest,GET_RULE,response,null,title,event,"0","0","0","0",operator_id,action_type,sender_name,sender_value,"1",app_id,"true",or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				String rule_id = new JSONObject(new JSONObject(response).get("data").toString()).get("id").toString();
				result.put(ui_values_usecase,isTriggerValuesFoundInUI(driver,api_webdriver,etest,rule_id,title,event,"0","0","0","0",operator_id,action_type,sender_name,sender_value,"1",app_id,"true",or_criteria1,or_criteria2));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}	
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void getAllTriggersAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			checkTriggerAPI(driver,api_webdriver,etest,false,true,SUCCESS_CODE,false,Api.TRIGGER_GET_LIST,false,null,GET_RULES,517);

			Tab.navToITTab(driver);
			List<WebElement> rule_list = CommonUtil.getElement(driver,By.id("rulelist")).findElements(By.className("data_row"));

			int no_of_rules = rule_list.size();

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			JSONObject resp_json = new JSONObject(response);
			JSONArray rules_array = resp_json.getJSONObject("data").getJSONArray("rule_list");

			int actual_rules_size = rules_array.length();

			if(CommonUtil.checkStringEqualsAndLog(no_of_rules+"",actual_rules_size+"","No of rules",etest))
			{
				etest.log(Status.PASS,"The total number of triggers shown in UI and API response are the same");
				result.put("RESTAPI519",true);
			}
			else
			{
				etest.log(Status.FAIL,"The total number of triggers shown in UI and API response are not the same");
				result.put("RESTAPI519",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void getSpecificTriggersAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			checkTriggerAPI(driver,api_webdriver,etest,false,true,SUCCESS_CODE,true,Api.TRIGGER_GET,false,null,GET_RULE,520);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}


	public static void updateTriggersAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			JSONObject payload=GetPayload.getUpdateTriggerPayload(appId,TITLE,EVENT,ACTION_TYPE,SENDER_NAME,SENDER_VALUE,DELAY,OR_CRITERIA1,OR_CRITERIA2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkTriggerAPI(driver,api_webdriver,etest,true,true,SUCCESS_CODE,true,Api.TRIGGER_UPDATE,true,payload,GET_RULE,522);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void deleteTriggerAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			checkTriggerAPI(driver,api_webdriver,etest,true,false,SUCCESS_CODE,true,Api.TRIGGER_DELETE,false,null,GET_RULE,525);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void enableTriggerAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			JSONObject payload = GetPayload.setTriggerStatusPayload("true");

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkTriggerAPI(driver,api_webdriver,etest,true,true,SUCCESS_CODE,true,Api.TRIGGER_ENABLE,true,payload,GET_RULE,528);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void disableTriggerAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			JSONObject payload=GetPayload.setTriggerStatusPayload("false");

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkTriggerAPI(driver,api_webdriver,etest,true,true,SUCCESS_CODE,true,Api.TRIGGER_DISABLE,true,payload,GET_RULE,530);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void updateTriggerPositionAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			JSONObject payload = GetPayload.getUpdatePosistionPayload("1");

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			checkTriggerAPI(driver,api_webdriver,etest,true,true,SUCCESS_CODE,true,Api.TRIGGER_UDPATE_POSITION,true,payload,GET_RULE,532);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void checkFieldMapsTriggersAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			result.put("RESTAPI534",SalesIQRESTAPIModule3.fieldMapsAPI(api_webdriver,driver,etest,Api.TRIGGER_FIELDMAPS));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void checkErrorResponse(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,String response_code,Api api_obj,String keys_check_usecase) throws Exception
	{
		try
		{
			boolean isPayload = false;
			boolean isReplace = true;
			JSONObject payload = null;
			String
			label = CommonUtil.getUniqueMessage(),
			title="Automation"+label,
			campaign_medium_value="camp"+label,
			event=Constants.LANDS_ON_WEBSITE,
			action_type=Constants.SEND_CHAT_INVITE,
			sender_name="Sender"+label,
			sender_value="Hello"+label,
			delay="10"
			;
			String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			switch(api_obj)
			{
				case TRIGGER_CREATE : 
				{
					payload = GetPayload.getCreateTriggerPayload(appId,title,event,action_type,sender_name,sender_value,delay,or_criteria1,or_criteria2);
					isPayload = true;
					isReplace = false;
					break;
				}
				case TRIGGER_UPDATE : 
				{
					payload = GetPayload.getUpdateTriggerPayload(appId,TITLE,EVENT,ACTION_TYPE,SENDER_NAME,SENDER_VALUE,DELAY,OR_CRITERIA1,OR_CRITERIA2);
					isPayload = true;
					break;
				}
				case TRIGGER_ENABLE : 
				{
					payload = GetPayload.setTriggerStatusPayload("true");
					isPayload = true;
					break;
				}
				case TRIGGER_DISABLE : 
				{
					payload = GetPayload.setTriggerStatusPayload("false");
					isPayload = true;
					break;
				}
				case TRIGGER_UDPATE_POSITION : 
				{
					payload = GetPayload.getUpdatePosistionPayload("1");
					isPayload = true;
					break;
				}
				case TRIGGER_GET_LIST :
				{
					isReplace = false;
				}
				default : 
				{
					payload =null;
					isPayload = false;
					break;
				}
			}


			if(payload != null)
			{
				etest.log(Status.INFO,"Below json will be used as payload");
				SalesIQRestAPICommonFunctions.log(etest,payload);
			}

			String rule_id = Trigger.getRuleId(driver,0);

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,ID,rule_id,api_obj,isPayload,payload,etest);

			String actualResponseCode = "";
			if(new JSONObject(response).has("JSPServerResponse"))
			{
				actualResponseCode = new JSONObject(response).get("code").toString();
			}
			else
			{
				actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
			}

			if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
			{
				result.put(keys_check_usecase,true);
				etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
			}
			else
			{
				result.put(keys_check_usecase,false);
				etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static void checkTriggerAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,boolean toCheckInUI,boolean isResponse,String response_code,boolean isReplace,Api api_obj,boolean isPayload,JSONObject payload,int rule_type,int startKey) throws Exception
	{
		try
		{
			int key = getRandomId();

			String
			label = CommonUtil.getUniqueMessage(),
			keys_check_usecase = "RESTAPI" + startKey,
			api_values_usecase = "RESTAPI" + (++startKey),
			ui_values_usecase = "RESTAPI" + (++startKey),
			operator_id=ExecuteStatements.getOperatorId(driver),
			website=ExecuteStatements.getDefaultEmbedName(driver),
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			title="Automation"+label,
			campaign_medium_value="test"+label,
			event=Constants.LANDS_ON_WEBSITE,
			action_type=Constants.SEND_CHAT_INVITE,
			sender_name="Sender"+label,
			sender_value="Hello"+label,
			delay="10",
			is_enabled = "true"
			;
			// String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			// String[] or_criteria2=new String[]{"campaign_medium","contains",campaign_medium_value};

			String sample_criteria = RestAPIConfManager.getRealValue("sample_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] or_criteria1 = criteria[key%25].split(",");
			String[] or_criteria2 = criteria[(key%25)+1].split(",");

			String rule_id = createTriggerRule(driver,api_webdriver,label,key,etest);

			if(api_obj==Api.TRIGGER_UPDATE)
			{
				app_id = appId;
				title = TITLE;
				event = EVENT;
				action_type = ACTION_TYPE;
				sender_name = SENDER_NAME;
				sender_value = SENDER_VALUE;
				delay = DELAY;
				or_criteria1 = OR_CRITERIA1;
				or_criteria2 = OR_CRITERIA2;
			}
			else if(api_obj == Api.TRIGGER_UDPATE_POSITION)
			{
				rule_id = Trigger.getRuleId(driver,Trigger.getList(driver).size()-1);
				etest.log(Status.INFO,"Changing the trigger rule with ID <b>"+rule_id+"</b> from position <b>"+(Trigger.getList(driver).size()-1)+"</b> to top");
			}
			else if(api_obj == Api.TRIGGER_DISABLE)
			{
				is_enabled = "false";
			}

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,ID,rule_id,api_obj,isPayload,payload,etest);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			// etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(api_obj == Api.TRIGGER_UDPATE_POSITION)
			{
				or_criteria1 = new String[]{SalesIQRestAPICommonFunctions.jPath(response,JPaths.OR_CRITERIA1_FIELDNAME),SalesIQRestAPICommonFunctions.jPath(response,JPaths.OR_CRITERIA1_COMPARATOR),SalesIQRestAPICommonFunctions.jPath(response,JPaths.OR_CRITERIA1_VALUES).replace("\"", "").replace("[", "").replace("]", "")};
				or_criteria2 = new String[]{SalesIQRestAPICommonFunctions.jPath(response,JPaths.OR_CRITERIA2_FIELDNAME),SalesIQRestAPICommonFunctions.jPath(response,JPaths.OR_CRITERIA2_COMPARATOR),SalesIQRestAPICommonFunctions.jPath(response,JPaths.OR_CRITERIA2_VALUES).replace("\"", "").replace("[", "").replace("]", "")};
				title = SalesIQRestAPICommonFunctions.jPath(response,JPaths.TITLE);
				event = SalesIQRestAPICommonFunctions.jPath(response,JPaths.EVENT_TYPE);
				operator_id = SalesIQRestAPICommonFunctions.jPath(response,JPaths.CREATOR_ID2);
				action_type = SalesIQRestAPICommonFunctions.jPath(response,JPaths.ACTION_TYPE);
				sender_name = SalesIQRestAPICommonFunctions.jPath(response,JPaths.SENDER_NAME);
				sender_value = SalesIQRestAPICommonFunctions.jPath(response,JPaths.SENDER_VALUE);
				app_id = SalesIQRestAPICommonFunctions.jPath(response,JPaths.APPID);
				is_enabled = SalesIQRestAPICommonFunctions.jPath(response,JPaths.ENABLED);
			}

			if(isResponse)
			{
				try
				{
					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED KEYS ARE FOUND</b>");
					result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}

				try
				{
					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN API RESPONSE</b>");
					if(api_obj == Api.TRIGGER_UDPATE_POSITION)
					{
						if(CommonUtil.checkStringContainsAndLog("1",SalesIQRestAPICommonFunctions.jPath(response,JPaths.POSITION),"position",etest))
						{
							result.put(api_values_usecase,true);
						}
						else
						{
							result.put(api_values_usecase,false);
							TakeScreenshot.screenshot(api_webdriver,etest);
							TakeScreenshot.screenshot(driver,etest);
						}
					}
					else
					{
						result.put(api_values_usecase,isTriggerValuesFoundInResponse(driver,etest,rule_type,response,rule_id,title,event,"0","0","0","0",operator_id,action_type,sender_name,sender_value,"1",app_id,is_enabled,or_criteria1,or_criteria2));
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}

				if(toCheckInUI)
				{
					try
					{
						etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN UI</b>");
						result.put(ui_values_usecase,isTriggerValuesFoundInUI(driver,api_webdriver,etest,rule_id,title,event,"0","0","0","0",operator_id,action_type,sender_name,sender_value,"1",app_id,is_enabled,or_criteria1,or_criteria2));
					}
					catch(Exception e1)
					{
						TakeScreenshot.screenshot(api_webdriver,etest,e1);
						TakeScreenshot.screenshot(driver,etest,e1);
					}
				}
			}
			else
			{
				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
				{
					result.put(keys_check_usecase,true);
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					result.put(keys_check_usecase,false);
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
				}

				if(toCheckInUI)
				{
					if(api_obj == Api.TRIGGER_DELETE)
					{
						Tab.navToITTab(driver);
						if(!CommonUtil.getElement(driver,By.id("rightcontainer")).getAttribute("innerHTML").contains(rule_id))
						{
							etest.log(Status.PASS,"The respective trigger rule was deleted in UI");
							result.put(ui_values_usecase,true);
						}
						else
						{
							etest.log(Status.FAIL,"The respective trigger rule was not deleted in UI");
							result.put(ui_values_usecase,false);
						}

						response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),true,ID,rule_id,Api.TRIGGER_GET,false,null,etest);
						String actualResponseMessage = "";
						if(new JSONObject(response).has("JSPServerResponse"))
						{
							actualResponseCode = new JSONObject(response).get("code").toString();
							actualResponseMessage = "Response not Found";
						}
						else
						{
							actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
							actualResponseMessage = new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString();
						}
						if(CommonUtil.checkStringEqualsAndLog(Constants.INVALID_RESOURCE,actualResponseCode,"response code",etest) && 
							CommonUtil.checkStringEqualsAndLog(Constants.INVALID_RESOURCE_ERROR_MESSAGE,actualResponseMessage,"response code",etest))
						{
							result.put(api_values_usecase,true);
							etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(api_values_usecase)+" -- Success</b>");
						}
						else
						{
							result.put(api_values_usecase,false);
							etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
						}
					}
					else if((api_obj == Api.TRIGGER_ENABLE) || (api_obj == Api.TRIGGER_DISABLE))
					{
						String enabled = (api_obj == Api.TRIGGER_ENABLE)?"true":"false";

						Hashtable<String,String> info = Trigger.getInfo(driver,rule_id);

						etest.log(Status.INFO,"<b style=\"color:green;\">Now checking the trigger status in UI</b>");

						result.put(api_values_usecase,CommonUtil.checkStringContainsAndLog(enabled,info.get(Trigger.ENABLED),"Trigger Status",etest));
					}

					else if(api_obj == Api.TRIGGER_UDPATE_POSITION)
					{
						Hashtable<String,String> info = Trigger.getInfo(driver,rule_id);

						etest.log(Status.INFO,"<b style=\"color:green;\">Now checking the trigger position in UI</b>");

						result.put(api_values_usecase,CommonUtil.checkStringContainsAndLog("1",info.get(Trigger.POSITION),"POSITION",etest));
					}
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static String createTriggerRule(WebDriver driver,WebDriver api_webdriver,String label,int key,ExtentTest etest)
	{
		try
		{
			String
			operator_id=ExecuteStatements.getOperatorId(driver),
			website=ExecuteStatements.getDefaultEmbedName(driver),
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			title="Automation"+label,
			sample_text="test",
			event=Constants.LANDS_ON_WEBSITE,
			action_type=Constants.SEND_CHAT_INVITE,
			sender_name="Sender"+label,
			sender_value="Hello"+label,
			delay="10"
			;
			// String[] or_criteria1=new String[]{"country","is_equal_to","India"};
			// String[] or_criteria2=new String[]{"campaign_medium","contains",sample_text};

			String sample_criteria = RestAPIConfManager.getRealValue("sample_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] or_criteria1 = criteria[key%25].split(",");
			String[] or_criteria2 = criteria[(key%25)+1].split(",");

			JSONObject payload=GetPayload.getCreateTriggerPayload(app_id,title,event,action_type,sender_name,sender_value,delay,or_criteria1,or_criteria2);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),false,"","",Api.TRIGGER_CREATE,true,payload,etest);
			String rule_id = new JSONObject(new JSONObject(response).get("data").toString()).get("id").toString();

			// key = key+2;

			return rule_id;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
			return "exception_occurred";
		}
	}

	public static boolean isTriggerValuesFoundInUI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,String rule_id,String title,String event_type,String triggered_count,String replied_count,String seen_count,String failed_count,String creator_id,String action_type,String sender_name,String sender_value,String position,String app_id,String is_enabled,String[] or_criteria1,String[] or_criteria2) throws Exception
	{
		int failcount = 0;
		String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
		CommonUtil.refreshPage(driver);
		Hashtable<String,String> info = Trigger.getInfo(driver,rule_id);

		if(!CommonUtil.checkStringContainsAndLog(title,info.get(Trigger.TITLE),"TITLE",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(event_type,info.get(Trigger.EVENT_TYPE),"EVENT_TYPE",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(triggered_count,info.get(Trigger.TRIGGERED_COUNT),"TRIGGERED_COUNT",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(seen_count,info.get(Trigger.SEEN_COUNT),"SEEN_COUNT",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(replied_count,info.get(Trigger.REPLIED_COUNT),"REPLIED_COUNT",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(failed_count,info.get(Trigger.FAILED_COUNT),"FAILED_COUNT",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(creator_id,info.get(Trigger.CREATOR_ID),"CREATOR_ID",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(action_type,info.get(Trigger.ACTION_TYPE),"ACTION_TYPE",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(sender_name,info.get(Trigger.SENDER_NAME),"SENDER_NAME",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(sender_value,info.get(Trigger.SENDER_VALUE),"SENDER_VALUE",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(position,info.get(Trigger.POSITION),"POSITION",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(app_id,info.get(Trigger.APPID),"APPID",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(is_enabled,info.get(Trigger.ENABLED),"ENABLED",etest))
		{
			failcount++;
		}

		String condition1 = (or_criteria1[0]+" "+or_criteria1[1]+" "+or_criteria1[2]).replaceAll("_"," ").replaceAll("greater than","is more than").replaceAll("not equals","is not equal to").replaceAll("email","email address").replaceAll("less than","is less than").toLowerCase();
		String condition2 = (or_criteria2[0]+" "+or_criteria2[1]+" "+or_criteria2[2]).replaceAll("_"," ").replaceAll("greater than","is more than").replaceAll("not equals","is not equal to").replaceAll("email","email address").replaceAll("less than","is less than").toLowerCase();
		if(!CommonUtil.checkStringContainsAndLog(condition1,info.get(Trigger.CONDITION),"CONDITION",etest))
		{
			failcount++;
		}
		if(!CommonUtil.checkStringContainsAndLog(condition2,info.get(Trigger.CONDITION),"CONDITION",etest))
		{
			failcount++;
		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean isTriggerValuesFoundInResponse(WebDriver driver,ExtentTest etest,int api_type,String response,String id,String title,String event_type,String triggered_count,String replied_count,String seen_count,String failed_count,String creator_id,String action_type,String sender_name,String sender_value,String position,String app_id,String is_enabled,String[] or_criteria1,String[] or_criteria2) throws Exception
	{
		int failcount=0;

		if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,title,getJPath(response,id,JPaths.TITLE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,event_type,getJPath(response,id,JPaths.EVENT_TYPE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,triggered_count,getJPath(response,id,JPaths.TRIGGERED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,replied_count,getJPath(response,id,JPaths.REPLIED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,seen_count,getJPath(response,id,JPaths.SEEN_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,failed_count,getJPath(response,id,JPaths.FAILED_COUNT,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,creator_id,getJPath(response,id,JPaths.CREATOR_ID2,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,action_type,getJPath(response,id,JPaths.ACTION_TYPE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,sender_name,getJPath(response,id,JPaths.SENDER_NAME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,sender_value,getJPath(response,id,JPaths.SENDER_VALUE,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,position,getJPath(response,id,JPaths.POSITION,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,app_id,getJPath(response,id,JPaths.APPID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,is_enabled,getJPath(response,id,JPaths.ENABLED,api_type),etest))
		{
			failcount++;
		}

		if(or_criteria1!=null)
		{
			JSONObject or_criteria1_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA1,api_type)));

			String actual_field_name=or_criteria1_json.get(APIKeys.FIELD_NAME).toString();
			String actual_comparator=or_criteria1_json.get(APIKeys.COMPARATOR).toString();
			String actual_values=or_criteria1_json.get(APIKeys.VALUES).toString();

			String expected_field_name=or_criteria1[0];
			String expected_comparator=or_criteria1[1];
			String expected_values=or_criteria1[2];

			if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 1",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 1",etest)==false)
			{
				failcount++;
			}
		}

		if(or_criteria2!=null)
		{
			JSONObject or_criteria2_json=new JSONObject(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.OR_CRITERIA2,api_type)));

			String actual_field_name=or_criteria2_json.get(APIKeys.FIELD_NAME).toString();
			String actual_comparator=or_criteria2_json.get(APIKeys.COMPARATOR).toString();
			String actual_values=or_criteria2_json.get(APIKeys.VALUES).toString();

			String expected_field_name=or_criteria2[0];
			String expected_comparator=or_criteria2[1];
			String expected_values=or_criteria2[2];

			if(CommonUtil.checkStringContainsAndLog(expected_field_name,actual_field_name,"field_name 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_comparator,actual_comparator,"expected_comparator 2",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringContainsAndLog(expected_values,actual_values,"expected_values 2",etest)==false)
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	//COMMON FUNCTIONS

	public static String getJPath(String response,String rule_id,String jPath,int api_type) throws Exception
	{
		if(api_type==GET_RULE || response==null || rule_id==null)
		{
			return jPath;
		}
		else
		{
			int rule_index=getRuleIndexOfGetRulesResponse(response,rule_id);
			jPath=getJPathForIndex(jPath,rule_index);
			return jPath;
		}
	}

	public static String getJPathForIndex(String jPath,int rule_index) throws Exception
	{
		jPath=jPath.replace("data/", "data/rule_list["+rule_index+"]/");
		return jPath;
	}

	public static int getRuleIndexOfGetRulesResponse(String response,String rule_id) throws Exception
	{
		JSONObject resp_json=new JSONObject(response);
		JSONArray rules_array=resp_json.getJSONObject("data").getJSONArray("rule_list");
		return SalesIQRestAPICommonFunctions.getJSONIndexWith(rules_array,"id",rule_id);
	}

	public static boolean isContains(String expected,String actual,String description,ExtentTest etest) throws Exception
	{
		if(expected!=null && CommonUtil.checkStringContainsAndLog(expected,actual,description,etest)==false)
		{
			return false;
		}

		return true;
	}

	public static boolean isValueFound(String response,String expected,String jpath,ExtentTest etest) throws Exception
	{
		if(expected!=null && CommonUtil.checkStringContainsAndLog( expected , SalesIQRestAPICommonFunctions.jPath(response,jpath) , jpath , etest)==false)
		{
			return false;
		}

		return true;
	}

	public static boolean isKeysFoundForGetRulesAPI(ExtentTest etest,String json_string,String[] jPaths) throws Exception
	{
		int failcount=0;

		for(String jPath : jPaths)
		{
			if(!SalesIQRestAPICommonFunctions.isKeyFound(etest,json_string,getJPathForIndex(jPath,0)))
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static String getDummyRuleID(WebDriver driver,Api api) throws Exception
	{
		return null;
	}

	public static JSONObject getDummyPayloadByAPI(WebDriver driver,Api api,String api_type) throws Exception
	{
		return null;
	}

	public static int getRandomId()
	{
		String label = CommonUtil.getUniqueMessage();

		label = label.substring(label.length()-3,label.length());

		int randomId = Integer.parseInt(label);

		return randomId;
	}
}
