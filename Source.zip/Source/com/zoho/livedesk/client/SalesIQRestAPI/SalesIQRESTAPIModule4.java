//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.AgentsSettings;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.BuildRejector;
import com.zoho.livedesk.util.common.actions.BlockedIP;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;

public class SalesIQRESTAPIModule4
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static final String MODULE_NAME="Rest API";
	public static String portal_name = "";

	public static VisitorDriverManager visitor_driver_manager;

	public static WebDriver admin_driver;

	public static final int
	ADMIN=0,
	INVALID_SCOPE=1,
	SUPERVISOR=2,
	ASSOCIATE=3
	;

	public static final int
	GET_RULE=0,
	GET_RULES=1
	;

	public static final int
	MONITOR_BY_OPERATOR=0,
	MONITOR_BY_VISITOR_EMAIL=1,
	MONITOR_BY_VISITOR_IP=2;

	public static int ip_count=0;

	public static final String DELIMITER="<><><><>";

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			ip_count=100;
			deleteAllChatMonitor(driver);
			deleteAllBlockedIP(driver);
			Trigger.deleteAllRule(driver,null);
			Cleanup.deleteAllDeparmentsExcept(driver,null);

			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

			WebDriver api_driver=Functions.setUp();
			api_driver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.setAuth(api_driver,"chatmonitor_admin");
			
			etest=ComplexReportFactory.getTest("Create Chat Monitor API-Monitor by Operator");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createChatMonitorAPI(api_driver,driver,MONITOR_BY_OPERATOR,etest);
            ComplexReportFactory.closeTest(etest);

			deleteAllChatMonitor(driver);

			etest=ComplexReportFactory.getTest("Get Chat Monitor API and Get Chat Monitor List API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getChatMonitorAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			deleteAllChatMonitor(driver);

			etest=ComplexReportFactory.getTest("Enable/Disable Chat Monitor Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			setChatMonitorStatusAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			deleteAllChatMonitor(driver);

			etest=ComplexReportFactory.getTest("Delete Chat Monitor Rule API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteChatMonitorAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			deleteAllChatMonitor(driver);

			etest=ComplexReportFactory.getTest("Create Chat Monitor API-Monitor by Email");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createChatMonitorAPI(api_driver,driver,MONITOR_BY_VISITOR_EMAIL,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Chat Monitor API-Monitor by IP");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createChatMonitorAPI(api_driver,driver,MONITOR_BY_VISITOR_IP,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Count API-Get chat monitor count");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getChatMonitorCountAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            WebDriver associate_driver=Driver.getDriver();
            Functions.login(associate_driver,"restapi4");
			etest=ComplexReportFactory.getTest("Check BlockedIP API Status");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkBlockedIPStatusAPI(api_driver,driver,associate_driver,etest);
            ComplexReportFactory.closeTest(etest);   
            Functions.logout(associate_driver);

			etest=ComplexReportFactory.getTest("Create BlockedIP API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createBlockedIPAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Get BlockedIP API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			getBlockedIPAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Delete BlockedIP API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteBlockedIPAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Comment for BlockedIP API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createCommentBlockedIPAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

            Api[] apis=new Api[]
            {
        		Api.CHATMONITOR_CREATE,Api.CHATMONITOR_GET_LIST,Api.CHATMONITOR_GET,Api.CHATMONITOR_UPDATE,Api.CHATMONITOR_DELETE,
        		Api.BLOCKEDIP_CREATE,Api.BLOCKEDIP_GET_LIST,Api.BLOCKEDIP_GET,Api.BLOCKEDIP_COMMENT_CREATE,Api.BLOCKEDIP_UPDATE,Api.BLOCKEDIP_DELETE,
        		Api.COUNT_GET
			};

            String[] invalid_scope_usecases=
            {
        	
        	"RESTAPI478","RESTAPI479","RESTAPI480","RESTAPI481","RESTAPI482",
        	"RESTAPI483","RESTAPI484","RESTAPI485","RESTAPI487","RESTAPI488","RESTAPI486",
        	"RESTAPI489"
        	};

            String[] supervisor_usecases=
            {
        	
        	"RESTAPI490","RESTAPI491","RESTAPI492","RESTAPI493","RESTAPI494",
        	"RESTAPI495","RESTAPI496","RESTAPI497","RESTAPI499","RESTAPI500","RESTAPI498",
        	"RESTAPI501"
        	};

            String[] associate_usecases=
            {
        	
        	"RESTAPI502","RESTAPI503","RESTAPI504","RESTAPI505","RESTAPI506",
        	"RESTAPI507","RESTAPI508","RESTAPI509","RESTAPI511","RESTAPI512","RESTAPI510",
        	"RESTAPI513"
        	};

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"inval");

        	for(int i=0;i<apis.length;i++)
        	{
        		Api api=apis[i];
        		String usecase=invalid_scope_usecases[i];

				etest=ComplexReportFactory.getTest("Invalid Scope-Checking error code for API-"+api.toString());
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				boolean test_outcome=errorCodeCheck(api_driver,driver,etest,api,Constants.INVALID_SCOPE_ERROR_CODE,Constants.INVALID_SCOPE_ERROR_MESSAGE);
				result.put(usecase,test_outcome);
				ComplexReportFactory.closeTest(etest);
        	}

            WebDriver supervisor_driver=Driver.getDriver();
            Functions.login(supervisor_driver,"restapi3");

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"chatmonitor_supervisor");

        	for(int i=0;i<apis.length;i++)
        	{
        		Api api=apis[i];
        		String usecase=supervisor_usecases[i];

				etest=ComplexReportFactory.getTest("Supervisor Permission Check for API-"+api.toString());
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				boolean test_outcome=errorCodeCheck(api_driver,supervisor_driver,etest,api,null,null);
				result.put(usecase,test_outcome);
				ComplexReportFactory.closeTest(etest);
        	}

        	Functions.logout(supervisor_driver);

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"chatmonitor_associate");

        	for(int i=0;i<apis.length;i++)
        	{
        		Api api=apis[i];
        		String usecase=associate_usecases[i];

        		String expected_error_code=Constants.PERMISSION_ERROR_CODE2;
        		String expected_error_message=Constants.PERMISSION_ERROR_MESSAGE2;

        		if(api==Api.BLOCKEDIP_GET_LIST || api==Api.BLOCKEDIP_GET || api==Api.BLOCKEDIP_COMMENT_CREATE)
        		{
        			expected_error_code=null;
        			expected_error_message=null;
        		}

				etest=ComplexReportFactory.getTest("Associate Permission Check for API-"+api.toString());
				ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
				boolean test_outcome=errorCodeCheck(api_driver,driver,etest,api,expected_error_code,expected_error_message);
				result.put(usecase,test_outcome);
				ComplexReportFactory.closeTest(etest);
        	}

            Driver.quitDriver(api_driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}            

		return finalResult;
	}

	//Chat Monitor Methods

	public static void createChatMonitorAPI(WebDriver api_webdriver,WebDriver driver,int monitor_type,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_monitor_api=null;
			String keys_check_usecase=null,api_values_usecase=null,ui_values_usecase=null;

			String
			type=null,
			monitor_operator=null,
			monitor_ip=null,
			monitor_email=null;

			create_monitor_api=Api.CHATMONITOR_CREATE;
			keys_check_usecase="RESTAPI436";

			String api=create_monitor_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			if(monitor_type==MONITOR_BY_OPERATOR)
			{
				api_values_usecase="RESTAPI440";
				ui_values_usecase="RESTAPI437";
				type=APIKeys.OPERATOR;
				monitor_operator=ExecuteStatements.getRandomAssociateOperatorID(driver);
				payload=GetPayload.getMonitorByOperatorPayload(monitor_operator);
			}
			else if(monitor_type==MONITOR_BY_VISITOR_EMAIL)
			{
				api_values_usecase="RESTAPI441";
				ui_values_usecase="RESTAPI438";
				type=APIKeys.VISITOR_EMAIL;
				monitor_email="vis@"+label+".com";
				payload=GetPayload.getMonitorByEmailPayload(monitor_email);
			}
			else if(monitor_type==MONITOR_BY_VISITOR_IP)
			{
				api_values_usecase="RESTAPI442";
				ui_values_usecase="RESTAPI439";
				type=APIKeys.VISITOR_IP;
				monitor_ip="192"+".192"+".1.3";
				payload=GetPayload.getMonitorByIPPayload(monitor_ip);
			}

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_monitor_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(CommonUtil.isChecked(keys_check_usecase,result)==false)
			{
				try
				{
					etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
					result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_monitor_api.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(api_values_usecase,isMonitorValuesFoundInResponse(driver,etest,GET_RULE,response,null,true,type,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);
				result.put(ui_values_usecase,isMonitorValuesFoundInUI(driver,etest,rule_id,type,true,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//get
	public static void getChatMonitorAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_monitor_api=null;

			String
			type=null,
			monitor_operator=null,
			monitor_ip=null,
			monitor_email=null,

			keys_check_usecase="RESTAPI443",
			api_values_usecase="RESTAPI444",
			get_list_keys_check_usecase="RESTAPI445",
			get_list_api_values_usecase="RESTAPI446"
			;

			create_monitor_api=Api.CHATMONITOR_CREATE;

			String api=create_monitor_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			type=APIKeys.OPERATOR;
			monitor_operator=ExecuteStatements.getRandomAssociateOperatorID(driver);
			payload=GetPayload.getMonitorByOperatorPayload(monitor_operator);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_monitor_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.MONITOR_TYPE))
			{
				etest.log(Status.INFO,"Chat monitor was successfully created.");
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Chat monitor was not created, Unable to check get API");
			}

			//Now calling get monitor API

			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			etest.log(Status.INFO,"Now calling get monitor API");

			Api get_api=Api.CHATMONITOR_GET;

			api=get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(api_values_usecase,isMonitorValuesFoundInResponse(driver,etest,GET_RULE,response,null,true,type,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//Now calling get monitor list API

			etest.log(Status.INFO,"Now calling get monitor list API");

			Api get_list_api=Api.CHATMONITOR_GET_LIST;

			api=get_list_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_list_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(get_list_keys_check_usecase,isKeysFoundForGetRulesAPI(etest,response,get_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(get_list_api_values_usecase,isMonitorValuesFoundInResponse(driver,etest,GET_RULES,response,rule_id,true,type,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//enable/disable
	public static void setChatMonitorStatusAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_monitor_api=null;

			String
			type=null,
			monitor_operator=null,
			monitor_ip=null,
			monitor_email=null
			;

			create_monitor_api=Api.CHATMONITOR_CREATE;

			String api=create_monitor_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			type=APIKeys.OPERATOR;
			monitor_operator=ExecuteStatements.getRandomAssociateOperatorID(driver);
			payload=GetPayload.getMonitorByOperatorPayload(monitor_operator);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_monitor_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.MONITOR_TYPE))
			{
				etest.log(Status.INFO,"Chat monitor was successfully created.");
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Chat monitor was not created, Unable to check get API");
			}

			//Now calling disable monitor API

			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			etest.log(Status.INFO,"Now calling disable monitor API");

			Api update_api=Api.CHATMONITOR_UPDATE;

			api=update_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			payload=GetPayload.getUpdateMonitorPayload(false);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("RESTAPI447",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,update_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put("RESTAPI448",isMonitorValuesFoundInResponse(driver,etest,GET_RULE,response,null,false,type,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("RESTAPI449",isMonitorValuesFoundInUI(driver,etest,rule_id,type,false,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//Now calling enable monitor api

			etest.log(Status.INFO,"Now calling enable monitor API");

			update_api=Api.CHATMONITOR_UPDATE;

			api=update_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			payload=GetPayload.getUpdateMonitorPayload(true);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put("RESTAPI450",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,update_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put("RESTAPI451",isMonitorValuesFoundInResponse(driver,etest,GET_RULE,response,null,true,type,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("RESTAPI452",isMonitorValuesFoundInUI(driver,etest,rule_id,type,true,monitor_operator,monitor_email,monitor_ip));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//delete monitor
	public static void deleteChatMonitorAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_monitor_api=null;

			String
			type=null,
			monitor_operator=null,
			monitor_ip=null,
			monitor_email=null
			;

			create_monitor_api=Api.CHATMONITOR_CREATE;

			String api=create_monitor_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			type=APIKeys.OPERATOR;
			monitor_operator=ExecuteStatements.getRandomAssociateOperatorID(driver);
			payload=GetPayload.getMonitorByOperatorPayload(monitor_operator);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_monitor_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.MONITOR_TYPE))
			{
				etest.log(Status.INFO,"Chat monitor was successfully created.");
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Chat monitor was not created, Unable to check get API");
			}

			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID);

			//Now calling delete monitor rule API
			etest.log(Status.INFO,"Now calling delete monitor API");

			Api delete_api=Api.CHATMONITOR_DELETE;

			api=delete_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,delete_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String resp_code=SalesIQRestAPICommonFunctions.jPath(response,"code");

			result.put("RESTAPI453",CommonUtil.checkStringContainsAndLog("204",resp_code,"response code for delete monitor API",etest));

			if(ChatMonitor.isChatMonitorFound(driver,rule_id)==false)
			{
				etest.log(Status.PASS,"Chat monitor was not found after it was deleted with REST API");
				result.put("RESTAPI454",true);
			}
			else
			{
				etest.log(Status.FAIL,"Chat monitor was found after it was deleted with REST API");
				result.put("RESTAPI454",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			etest.log(Status.INFO,"Now calling get monitor API to check if error is shown for deleted monitor");

			Api get_api=Api.CHATMONITOR_GET;

			api=get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			result.put("RESTAPI455",SalesIQRestAPICommonFunctions.checkErrorJSON(response,"1212","No chatmonitor found",etest));

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//get count API
	public static void getChatMonitorCountAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount=0;

		try
		{
			Api get_count_api=null;

			get_count_api=Api.COUNT_GET;

			String api=get_count_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=SalesIQRestAPICommonFunctions.addParam(api,APIKeys.RESOURCE,APIKeys.CHATMONITORS);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_count_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);

			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			Hashtable<String,Integer> count_in_ui=ChatMonitor.getCount(driver);

			String
			api_visitor_email_count=SalesIQRestAPICommonFunctions.jPath(response,"data/visitor_email"),
			api_operator_count=SalesIQRestAPICommonFunctions.jPath(response,"data/operator"),
			api_visitor_ip_count=SalesIQRestAPICommonFunctions.jPath(response,"data/visitor_ip");

			if(CommonUtil.checkStringEqualsAndLog(""+count_in_ui.get(ChatMonitor.VISITOR_EMAIL_KEY),api_visitor_email_count,"visitor emails chat monitor count",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringEqualsAndLog(""+count_in_ui.get(ChatMonitor.OPERATOR_KEY),api_operator_count,"operator chat monitor count",etest)==false)
			{
				failcount++;
			}
			if(CommonUtil.checkStringEqualsAndLog(""+count_in_ui.get(ChatMonitor.VISITOR_IP_KEY),api_visitor_ip_count,"visitor ip chat monitor count",etest)==false)
			{
				failcount++;
			}

			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.infoScreenshot(api_webdriver,etest);

			result.put("RESTAPI456", CommonUtil.returnResult(failcount) );
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static boolean isMonitorValuesFoundInResponse(WebDriver driver,ExtentTest etest,int api_type,String response,String id,Boolean enabled,String type,String operator_id,String visitor_email,String visitor_ip) throws Exception
	{
		int failcount=0;

		if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,""+enabled,getJPath(response,id,JPaths.STATUS,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,type,getJPath(response,id,JPaths.MONITOR_TYPE,api_type),etest))
		{
			failcount++;
		}

		if(operator_id!=null && !isValueFound(response,operator_id,getJPath(response,id,JPaths.OPERATOR_ID,api_type),etest))
		{
			failcount++;
		}

		if(visitor_email!=null && !isValueFound(response,visitor_email,getJPath(response,id,JPaths.VISITOR_EMAIL,api_type),etest))
		{
			failcount++;
		}

		if(visitor_ip!=null && !isValueFound(response,visitor_ip,getJPath(response,id,JPaths.VISITOR_IP,api_type),etest))
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isMonitorValuesFoundInUI(WebDriver driver,ExtentTest etest,String id,String type,boolean is_enabled,String operator_id,String visitor_email,String visitor_ip) throws Exception
	{
		int failcount=0;

		Hashtable<String,String> rule_info=ChatMonitor.getInfo(driver,id);

		if(isContains(type,rule_info.get(ChatMonitor.TYPE),ChatMonitor.TYPE,etest)==false)
		{
			failcount++;
		}

		String expected_value=null;

		if(type.equals(APIKeys.OPERATOR))
		{
			expected_value=operator_id;
		}
		else if(type.equals(APIKeys.VISITOR_EMAIL))
		{
			expected_value=visitor_email;
		}
		else if(type.equals(APIKeys.VISITOR_IP))
		{
			expected_value=visitor_ip;
		}

		if(isContains(expected_value,rule_info.get(ChatMonitor.VALUE),type+" value",etest)==false)
		{
			failcount++;
		}

		if(isContains(""+is_enabled,rule_info.get(ChatMonitor.ENABLED),"enabled/disabled status",etest)==false)
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	//BlockedIP methods
	public static void createBlockedIPAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_blockedip_api=null;
			String keys_check_usecase="RESTAPI457",api_values_usecase="RESTAPI458",ui_values_usecase="RESTAPI459";

			String
			ip=getRandomIP(),
			website=ExecuteStatements.getDefaultEmbedName(driver),
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			comment="Comment"+label,
			operator_id=ExecuteStatements.getOperatorId(driver)
			;

			create_blockedip_api=Api.BLOCKEDIP_CREATE;

			String api=create_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			payload=GetPayload.getBlockedIPCreatePayload(ip,comment,app_id);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID_ARRAY);

			if(CommonUtil.isChecked(keys_check_usecase,result)==false)
			{
				try
				{
					etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
					result.put(keys_check_usecase,isKeysFoundForGetRulesAPI(etest,response,create_blockedip_api.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(api_values_usecase,isBlockedIPValuesFoundInResponse(driver,etest,GET_RULES,response,rule_id,Constants.BLOCKED,operator_id,website,app_id,ip,1,operator_id+DELIMITER+comment));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put(ui_values_usecase,isBlockedIPValuesFoundInUI(driver,etest,GET_RULES,response,rule_id,Constants.BLOCKED,operator_id,website,app_id,ip,1,comment));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//get
	public static void getBlockedIPAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_blockedip_api=null;

			String
			ip=getRandomIP(),
			website=ExecuteStatements.getDefaultEmbedName(driver),
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			comment="Comment"+label,
			operator_id=ExecuteStatements.getOperatorId(driver),

			keys_check_usecase="RESTAPI460",
			api_values_usecase="RESTAPI461",
			get_list_keys_check_usecase="RESTAPI462",
			get_list_api_values_usecase="RESTAPI463"
			;

			create_blockedip_api=Api.BLOCKEDIP_CREATE;

			String api=create_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			payload=GetPayload.getBlockedIPCreatePayload(ip,comment,app_id);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.RULEID_ARRAY))
			{
				etest.log(Status.INFO,"BlockedIP was successfully created.");
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("BlockedIP was not created, Unable to check get API");
			}

			//Now calling get blockedIP API
			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID_ARRAY);

			etest.log(Status.INFO,"Now calling get blocked IP API");

			Api get_api=Api.BLOCKEDIP_GET;

			api=get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
				result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_api.expected_keys));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(api_values_usecase,isBlockedIPValuesFoundInResponse(driver,etest,GET_RULE,response,rule_id,Constants.BLOCKED,operator_id,website,app_id,ip,1,operator_id+DELIMITER+comment));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//Now calling get blocked IP list API
			etest.log(Status.INFO,"Now calling get blockedIP list API");

			Api get_list_api=Api.BLOCKEDIP_GET_LIST;

			api=get_list_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_list_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(CommonUtil.isChecked(get_list_keys_check_usecase,result)==false)
			{
				try
				{
					etest.log(Status.INFO,"NOW CHECKED IF EXPECTED KEYS ARE FOUND");
					result.put(get_list_keys_check_usecase,isKeysFoundForGetRulesAPI(etest,response,create_blockedip_api.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest,e1);
					TakeScreenshot.screenshot(driver,etest,e1);
				}
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put(get_list_api_values_usecase,isBlockedIPValuesFoundInResponse(driver,etest,GET_RULES,response,rule_id,Constants.BLOCKED,operator_id,website,app_id,ip,1,operator_id+DELIMITER+comment));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//DELETE BLOCKEDIP
	public static void deleteBlockedIPAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_blockedip_api=null;

			String
			ip=getRandomIP(),
			website=ExecuteStatements.getDefaultEmbedName(driver),
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			comment="Comment"+label,
			operator_id=ExecuteStatements.getOperatorId(driver)
			;

			create_blockedip_api=Api.BLOCKEDIP_CREATE;

			String api=create_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			payload=GetPayload.getBlockedIPCreatePayload(ip,comment,app_id);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.RULEID_ARRAY))
			{
				etest.log(Status.INFO,"BlockedIP was successfully created.");
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("BlockedIP was not created, Unable to check get API");
			}

			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID_ARRAY);

			//Now calling delete blockedIP API
			etest.log(Status.INFO,"Now calling delete blockedIP API");

			Api delete_api=Api.BLOCKEDIP_DELETE;

			api=delete_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,delete_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			String resp_code=SalesIQRestAPICommonFunctions.jPath(response,"code");

			result.put("RESTAPI464",CommonUtil.checkStringContainsAndLog("204",resp_code,"response code for delete blockedIP API",etest));

			if(BlockedIP.isBlockedIPFound(driver,rule_id)==false)
			{
				etest.log(Status.PASS,"BlockedIP was not found after it was deleted with REST API");
				result.put("RESTAPI465",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was found after it was deleted with REST API");
				result.put("RESTAPI465",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			//Now calling get blockedIP API
			etest.log(Status.INFO,"Now calling get monitor API to check if error is shown for deleted monitor");

			Api get_api=Api.BLOCKEDIP_GET;

			api=get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			result.put("RESTAPI466",SalesIQRestAPICommonFunctions.checkErrorJSON(response,"1250","Unable to retrieve blockedips",etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//ADD COMMENT FOR BLOCKED IP
	public static void createCommentBlockedIPAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();

			Api create_blockedip_api=null;

			String
			ip=getRandomIP(),
			website=ExecuteStatements.getDefaultEmbedName(driver),
			app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
			comment="Comment"+label,
			operator_id=ExecuteStatements.getOperatorId(driver),
			new_comment="NewKomment"+label
			;

			create_blockedip_api=Api.BLOCKEDIP_CREATE;

			String api=create_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			JSONObject payload=null;

			payload=GetPayload.getBlockedIPCreatePayload(ip,comment,app_id);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.RULEID_ARRAY))
			{
				etest.log(Status.INFO,"BlockedIP was successfully created.");
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("BlockedIP was not created, Unable to check API");
			}

			String rule_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.RULEID_ARRAY);

			Api create_blockedip_comment_api=Api.BLOCKEDIP_COMMENT_CREATE;

			api=create_blockedip_comment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+APIKeys.RULEID+">",rule_id);

			payload=GetPayload.getBlockedIPCreateCommentPayload(new_comment);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_blockedip_comment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN API RESPONSE");
				result.put("RESTAPI467",isBlockedIPValuesFoundInResponse(driver,etest,GET_RULE,response,rule_id,Constants.BLOCKED,null,null,null,ip,1,new_comment));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			try
			{
				etest.log(Status.INFO,"NOW CHECKED IF EXPECTED VALUES ARE FOUND IN UI");
				result.put("RESTAPI468",isBlockedIPValuesFoundInUI(driver,etest,GET_RULES,response,rule_id,Constants.BLOCKED,null,null,null,ip,1,new_comment));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	//CHECK BLOCKEDIP STATUS
	public static void checkBlockedIPStatusAPI(WebDriver api_webdriver,WebDriver driver,WebDriver associate_driver,ExtentTest etest) throws Exception
	{
		try
		{
			String label=CommonUtil.getUniqueMessage();
			String rule_id=null;

			//check approval status

			Cleanup.deleteAllBlockedIP(driver);
			blockVisitorIP(associate_driver,etest,ExecuteStatements.getWidgetCode(driver));
			rule_id=BlockedIP.getRuleIDOfFirstBlockedIP(driver);

			Api get_api=Api.BLOCKEDIP_GET;

			String api=get_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			try
			{
				etest.log(Status.INFO,"NOW CHECK IF STATUS IS APPROVAL_REQUIRED IN API RESPONSE");
				result.put("RESTAPI469",isBlockedIPValuesFoundInResponse(driver,etest,GET_RULE,response,rule_id,Constants.APPROVAL_REQUIRED,null,null,null,null,null));
			}
			catch(Exception e1)
			{
				TakeScreenshot.screenshot(api_webdriver,etest,e1);
				TakeScreenshot.screenshot(driver,etest,e1);
			}

			//reject
			Cleanup.deleteAllBlockedIP(driver);
			blockVisitorIP(associate_driver,etest,ExecuteStatements.getWidgetCode(driver));
			rule_id=BlockedIP.getRuleIDOfFirstBlockedIP(driver);

			Api update_blockedip_api=null;
			JSONObject payload=null;
			String resp_code=null;

			update_blockedip_api=Api.BLOCKEDIP_UPDATE;

			api=update_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			payload=GetPayload.getBlockedIPUpdatePayload(Constants.REJECT);

			etest.log(Status.INFO,"Below API will be called");
			etest.log(Status.INFO,api);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			resp_code=SalesIQRestAPICommonFunctions.jPath(response,"code");

			resp_code=SalesIQRestAPICommonFunctions.jPath(response,"code");
			result.put("RESTAPI470",CommonUtil.checkStringContainsAndLog("204",resp_code,"response code for reject",etest));

			if(BlockedIP.isBlockedIPFound(driver,rule_id)==false)
			{
				etest.log(Status.PASS,"BlockedIP was not found after it was rejected with REST API");
				result.put("RESTAPI471",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was found after it was rejected with REST API");
				result.put("RESTAPI471",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			//approve
			Cleanup.deleteAllBlockedIP(driver);
			blockVisitorIP(associate_driver,etest,ExecuteStatements.getWidgetCode(driver));
			rule_id=BlockedIP.getRuleIDOfFirstBlockedIP(driver);

			update_blockedip_api=Api.BLOCKEDIP_UPDATE;

			api=update_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			payload=GetPayload.getBlockedIPUpdatePayload(Constants.APPROVE);

			etest.log(Status.INFO,"Below API will be called");
			etest.log(Status.INFO,api);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.RULEID))
			{
				etest.log(Status.PASS,"BlockedIP was approved from REST API");
				result.put("RESTAPI472",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was NOT approved from REST API");
				result.put("RESTAPI472",false);				
			}

			if(BlockedIP.getInfo(driver,rule_id).get(BlockedIP.STATUS).equals(Constants.BLOCKED))
			{
				etest.log(Status.PASS,"BlockedIP was not found as blocked after it was approved with REST API");
				result.put("RESTAPI473",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was found as blocked after it was approved with REST API");
				result.put("RESTAPI473",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			//unblock
			update_blockedip_api=Api.BLOCKEDIP_UPDATE;

			api=update_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			payload=GetPayload.getBlockedIPUpdatePayload(Constants.UNBLOCK);

			etest.log(Status.INFO,"Below API will be called");
			etest.log(Status.INFO,api);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.RULEID))
			{
				etest.log(Status.PASS,"BlockedIP was approved from REST API");
				result.put("RESTAPI474",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was NOT approved from REST API");
				result.put("RESTAPI474",false);				
			}

			if(BlockedIP.getInfo(driver,rule_id).get(BlockedIP.STATUS).equals(Constants.UNBLOCKED))
			{
				etest.log(Status.PASS,"BlockedIP was not found as blocked after it was blocked with REST API");
				result.put("RESTAPI475",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was found as blocked after it was blocked with REST API");
				result.put("RESTAPI475",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			//block
			update_blockedip_api=Api.BLOCKEDIP_UPDATE;

			api=update_blockedip_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<"+"id"+">",rule_id);

			payload=GetPayload.getBlockedIPUpdatePayload(Constants.BLOCK);

			etest.log(Status.INFO,"Below API will be called");
			etest.log(Status.INFO,api);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_blockedip_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(SalesIQRestAPICommonFunctions.isKeyFound(etest,response,JPaths.RULEID))
			{
				etest.log(Status.PASS,"BlockedIP was blocked from REST API");
				result.put("RESTAPI476",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was NOT blocked from REST API");
				result.put("RESTAPI476",false);				
			}

			if(BlockedIP.getInfo(driver,rule_id).get(BlockedIP.STATUS).equals(Constants.BLOCKED))
			{
				etest.log(Status.PASS,"BlockedIP was not found as blocked after it was blocked with REST API");
				result.put("RESTAPI477",true);
			}
			else
			{
				etest.log(Status.FAIL,"BlockedIP was found as blocked after it was blocked with REST API");
				result.put("RESTAPI477",false);
				TakeScreenshot.screenshot(driver,etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}
	}

	public static boolean isBlockedIPValuesFoundInResponse(WebDriver driver,ExtentTest etest,int api_type,String response,String id,String status,String blocked_by_operator_id,String app_name,String app_id,String ip,Integer no_of_comments,String... comments) throws Exception
	{
		int failcount=0;

		if(!isValueFound(response,id,getJPath(response,id,JPaths.RULEID,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,""+status,getJPath(response,id,JPaths.STATUS2,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,blocked_by_operator_id,getJPath(response,id,JPaths.BLOCKED_BY,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,app_name,getJPath(response,id,JPaths.APP_NAME,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,app_id,getJPath(response,id,JPaths.APPID2,api_type),etest))
		{
			failcount++;
		}

		if(!isValueFound(response,ip,getJPath(response,id,JPaths.IP,api_type),etest))
		{
			failcount++;
		}

		if(no_of_comments!=null)
		{
			int actual_no_of_comments=Integer.parseInt(SalesIQRestAPICommonFunctions.jPath(response,getJPath(response,id,JPaths.NO_OF_COMMENTS,api_type)));

			if(actual_no_of_comments>=no_of_comments)
			{
				etest.log(Status.PASS,"Actual no of comments >= Expected no of comments");
			}
			else
			{
				etest.log(Status.FAIL,"Actual no of comments < Expected no of comments");
				failcount++;
			}
		}

		if(comments!=null)
		{
			for(int i=0;i<comments.length;i++)
			{
				String comment_info=comments[i];
				String comment=comment_info.contains(DELIMITER)?comment_info.split(DELIMITER)[1]:comment_info;

				if(!isValueFound(response,comment,getJPath(response,id,JPaths.COMMENTS,api_type),etest))
				{
					failcount++;
				}
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isBlockedIPValuesFoundInUI(WebDriver driver,ExtentTest etest,int api_type,String response,String id,String status,String blocked_by_operator_id,String app_name,String app_id,String ip,int no_of_comments,String... comments) throws Exception
	{
		int failcount=0;

		Hashtable<String,String> rule_info=BlockedIP.getInfo(driver,id);

		if(isContains(ip,rule_info.get(BlockedIP.IP),BlockedIP.IP,etest)==false)
		{
			failcount++;
		}

		if(isContains(status,rule_info.get(BlockedIP.STATUS),BlockedIP.STATUS,etest)==false)
		{
			failcount++;
		}

		if(isContains(blocked_by_operator_id,rule_info.get(BlockedIP.BLOCKED_BY_OPERATOR_ID),BlockedIP.BLOCKED_BY_OPERATOR_ID,etest)==false)
		{
			failcount++;
		}

		if(isContains(app_name,rule_info.get(BlockedIP.APP_NAME),BlockedIP.APP_NAME,etest)==false)
		{
			failcount++;
		}

		if(isContains(app_id,rule_info.get(BlockedIP.APP_ID),BlockedIP.APP_ID,etest)==false)
		{
			failcount++;
		}

		if(Integer.parseInt(rule_info.get(BlockedIP.NO_OF_COMMENTS))>=no_of_comments)
		{
			etest.log(Status.PASS,"Actual no of comments >= Expected no of comments");
		}
		else
		{
			etest.log(Status.FAIL,"Actual no of comments < Expected no of comments");
			failcount++;
		}

		for(String comment : comments)
		{
			if(isContains(comment,rule_info.get(BlockedIP.COMMENTS),BlockedIP.COMMENTS,etest)==false)
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static String getRandomIP()
	{
		ip_count++;
		return ip_count+".100.1.1";
	}
	
	public static void blockVisitorIP(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		WebDriver visitor_driver=null;

		try
		{
			String label=CommonUtil.getUniqueMessage();
			visitor_driver=visitor_driver_manager.getDriver();
			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V@"+label+".com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label,null,null);
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);
	        ChatWindow.blockIPFromChat(driver,etest);
	        Driver.quitDriver(visitor_driver);
	        ChatWindow.closeAllChats(driver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(visitor_driver,etest);
			throw e;
		}
	}

	//Common Methods

	//error code checks
	public static boolean errorCodeCheck(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,Api api_object,String expected_error_code,String expected_error_message) throws Exception
	{
		try
		{
			String ruleid=getDummyRuleID(driver,api_object);

			String api=api_object.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			if(ruleid!=null)
			{
				api=api.replace("<"+APIKeys.RULEID+">",ruleid);
			}
			if(api_object==Api.COUNT_GET)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,APIKeys.RESOURCE,APIKeys.CHATMONITORS);
			}


			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,api_object);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);

			JSONObject payload=getDummyPayloadByAPI(driver,api_object);
			if(payload!=null)
			{
				etest.log(Status.INFO,"Below json will be used as payload for API-->"+api);
				SalesIQRestAPICommonFunctions.log(etest,payload);

				SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			}

			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			return SalesIQRestAPICommonFunctions.checkErrorJSON(response,expected_error_code,expected_error_message,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest,e);
		}

		return false;
	}

	public static String getDummyRuleID(WebDriver driver,Api api) throws Exception
	{
		String api_name=api.toString();

		if(api.api_template.contains("<id>"))
		{
			if(api_name.contains("CHATMONITOR"))
			{
				return ChatMonitor.getRuleIDOfFirstChatMonitor(driver);
			}
			else if(api_name.contains("BLOCKEDIP"))
			{
				return BlockedIP.getRuleIDOfFirstBlockedIP(driver);
			}
		}

		return null;
	}

	public static JSONObject getDummyPayloadByAPI(WebDriver driver,Api api) throws Exception
	{
		String api_name=api.toString();

		String label=CommonUtil.getUniqueMessage();

		if(api_name.contains("CHATMONITOR"))
		{
			if(api==Api.CHATMONITOR_CREATE)
			{
				return GetPayload.getMonitorByEmailPayload("V@"+label+".com");
			}
			if(api==Api.CHATMONITOR_UPDATE)
			{
				return GetPayload.getUpdateMonitorPayload(false);
			}
		}

		if(api_name.contains("BLOCKEDIP"))
		{
			if(api==Api.BLOCKEDIP_CREATE)
			{
				String
				ip=getRandomIP(),
				website=ExecuteStatements.getDefaultEmbedName(driver),
				app_id=ExecuteStatements.getWebsiteIDFromEmbedName(driver,website),
				comment="Comment"+label
				;

				return GetPayload.getBlockedIPCreatePayload(ip,comment,app_id);
			}
			if(api==Api.BLOCKEDIP_COMMENT_CREATE)
			{
				return GetPayload.getBlockedIPCreateCommentPayload("NewKomment"+label);
			}
			if(api==Api.BLOCKEDIP_UPDATE)
			{
				return GetPayload.getBlockedIPUpdatePayload(Constants.UNBLOCK);
			}
		}

		return null;
	}

	//other methods	
	public static String getJPath(String response,String rule_id,String jPath,int api_type) throws Exception
	{
		if(api_type==GET_RULE || response==null || rule_id==null)
		{
			return jPath;
		}
		else
		{
			int rule_index=getRuleIndexOfGetRulesResponse(response,rule_id);
			jPath=getJPathForIndex(jPath,rule_index);
			return jPath;
		}
	}

	public static String getJPathForIndex(String jPath,int rule_index) throws Exception
	{
		jPath=jPath.replace("data/", "data["+rule_index+"]/");
		return jPath;
	}

	public static int getRuleIndexOfGetRulesResponse(String response,String rule_id) throws Exception
	{
		JSONObject resp_json=new JSONObject(response);
		JSONArray rules_array=resp_json.getJSONArray("data");
		return SalesIQRestAPICommonFunctions.getJSONIndexWith(rules_array,"id",rule_id);
	}

	public static boolean isValueFound(String response,String expected,String jpath,ExtentTest etest) throws Exception
	{
		return SalesIQRESTAPIModule3.isValueFound(response,expected,jpath,etest);
	}

	public static boolean isContains(String expected,String actual,String description,ExtentTest etest) throws Exception
	{
		return SalesIQRESTAPIModule3.isContains(expected,actual,description,etest);
	}

	public static boolean isKeysFoundForGetRulesAPI(ExtentTest etest,String json_string,String[] jPaths) throws Exception
	{
		int failcount=0;

		for(String jPath : jPaths)
		{
			if(!SalesIQRestAPICommonFunctions.isKeyFound(etest,json_string,getJPathForIndex(jPath,0)))
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void deleteAllChatMonitor(WebDriver driver)
	{
		try
		{
			Cleanup.deleteAllChatMonitor(driver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public static void deleteAllBlockedIP(WebDriver driver)
	{
		try
		{
			Cleanup.deleteAllBlockedIP(driver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}


}
