//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.Tracking;

import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeTests;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class TrackingPresetsAPI
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String 
	MODULE_NAME = "Rest API",
	APP_FIELDS_JSON = "trackingpresets_fieldmaps.json"
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

            WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

            SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"tracking");

            etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check add tracking preset API",MODULE_NAME);
			checkAddTrackingPresetAPI(driver,api_webdriver,Constants.SUCCESS_CODE,925,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Get List of tracking presets API",MODULE_NAME);
			checkGetListOfTrackingPresetsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,928,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check the details of a particular tracking preset API",MODULE_NAME);
			checkGetTrackingPresetAPI(driver,api_webdriver,Constants.SUCCESS_CODE,930,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check update details of a particular tracking presets API",MODULE_NAME);
			checkUpdateTrackingPresetAPI(driver,api_webdriver,Constants.SUCCESS_CODE,933,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Disable a particular tracking preset API",MODULE_NAME);
			checkEnableTrackingPresetAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,936,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Enable a particular tracking preset API",MODULE_NAME);
			checkEnableTrackingPresetAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,939,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Delete a particular tracking preset API",MODULE_NAME);
			checkDeleteTrackingPresetAPI(driver,api_webdriver,Constants.SUCCESS_CODE,942,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check update details of tracking user preference API for list view type",MODULE_NAME);
			checkUpdateDetailsOfUserPreferenceAPI(driver,api_webdriver,"list",Constants.SUCCESS_CODE,948,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check update details of tracking user preference API for ring view type",MODULE_NAME);
			checkUpdateDetailsOfUserPreferenceAPI(driver,api_webdriver,"ring",Constants.SUCCESS_CODE,945,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check get details of user preference",MODULE_NAME);
			checkGetDetailsOfUserPreferenceAPI(driver,api_webdriver,Constants.SUCCESS_CODE,951,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check get list of criterias",MODULE_NAME);
			checkGetListOfCriteriasAPI(driver,api_webdriver,Constants.SUCCESS_CODE,954,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Add tracking preset API",MODULE_NAME);
			checkAddTrackingPresetAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,955,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Get List of tracking presets API",MODULE_NAME);
			checkGetListOfTrackingPresetsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,956,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Get details of a particular tracking preset API",MODULE_NAME);
			checkGetTrackingPresetAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,957,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Update details of a particular tracking presets API",MODULE_NAME);
			checkUpdateTrackingPresetAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,958,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Disable a particular tracking preset API",MODULE_NAME);
			checkEnableTrackingPresetAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,959,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Enable a particular tracking preset API",MODULE_NAME);
			checkEnableTrackingPresetAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,960,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Delete a particular tracking preset API",MODULE_NAME);
			checkDeleteTrackingPresetAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,961,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Update details of tracking user preference API for list view type",MODULE_NAME);
			checkUpdateDetailsOfUserPreferenceAPI(driver,api_webdriver,"list",Constants.INVALID_SCOPE_ERROR_CODE,962,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Update details of tracking user preference API for ring view type",MODULE_NAME);
			checkUpdateDetailsOfUserPreferenceAPI(driver,api_webdriver,"ring",Constants.INVALID_SCOPE_ERROR_CODE,963,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Get details of user preference",MODULE_NAME);
			checkGetDetailsOfUserPreferenceAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,964,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Tracking Presets API -- Check Invalid Scope for Get list of criterias",MODULE_NAME);
			checkGetListOfCriteriasAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,965,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}


	public static void checkAddTrackingPresetAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			TrackingRingsCustomizeTests.deleteAllPresets(driver,etest);

			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,false,true,Api.TRACKING_PRESETS_CREATE,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkGetListOfTrackingPresetsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,false,response_code,false,false,Api.TRACKING_PRESETS_GET_LIST,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkGetTrackingPresetAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			TrackingRingsCustomizeTests.deleteAllPresets(driver,etest);
			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,false,Api.TRACKING_PRESETS_GET,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkUpdateTrackingPresetAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,true,Api.TRACKING_PRESETS_UPDATE,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkEnableTrackingPresetAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnable,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			TrackingRingsCustomizeTests.deleteAllPresets(driver,etest);

			Api api_obj = (isEnable) ? Api.TRACKING_PRESETS_ENABLE : Api.TRACKING_PRESETS_DISABLE;

			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,true,api_obj,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkDeleteTrackingPresetAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,false,Api.TRACKING_PRESETS_DELETE,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkGetDetailsOfUserPreferenceAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			TrackingRingsCustomizeTests.deleteAllPresets(driver,etest);

			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,false,Api.TRACKING_PRESETS_SELECTED,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkUpdateDetailsOfUserPreferenceAPI(WebDriver driver,WebDriver api_webdriver,String view_type,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Api api_obj = (view_type == "ring") ? Api.TRACKING_PRESETS_UPDATE_SELECT_RING : Api.TRACKING_PRESETS_UPDATE_SELECT_LIST;

			result.putAll(TrackingPresetsAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,true,api_obj,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}


	public static void checkGetListOfCriteriasAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{	
			String use_case_key = "RESTAPI"+startKey;
			TrackingRingsCustomizeTests.deleteAllPresets(driver,etest);

			result.put(use_case_key,SalesIQRestAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,false,"","",Api.TRACKING_PRESETS_CRITERIAFIELDS,APP_FIELDS_JSON,startKey,etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
}