//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.Tracking;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.RuleType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.TrackingRing;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.RuleCriteria;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.RuleCondition;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class TrackingPresetsAPICommonFunctions
{
	public static final String[]
	APPLIED = {"true","false"},
	ENABLED = {"true","false"}
	;

	public static final String 
	PRESET_NAME = "data_name",
	PRESET_DESCRIPTION = "data_description",
	PRESET_ENABLED = "data_enabled",
	PRESET_APPLIED = "data_applied",
	RING1_CONTENT = "data_rule_ring_one",
	RING2_CONTENT = "data_rule_ring_two",
	RING3_CONTENT = "data_rule_ring_three",
	RING4_CONTENT = "data_rule_ring_four",
	PAST_CHATS_DEFAULT_PRESET_VALUE = "4",
	PRESET_DELETED = "data_deleted",
	RING_TYPE = "data_tracking_view",
	HIDE_OTHER_AGENT_CONNECTED_VISITORS = "data_tracking_hide_other_agent_connected_visitors",
	ID = "<id>"
	;

	public static final By
	CUSTOMIZE_HEADER = By.id("customizeheader"),
	TRACKING_LIST_TYPE = By.className("tgl_ticon"),
	PRESET_DEFAULT_RULE = By.id("defaultrule"),
	TRACKING_CUSTOMIZE = By.className("cursr-point"),
	CUSTOMIZE_MENU = By.id("lddrawer"),
	CUSTOMIZE_MENU_RULES = By.id("rulescrollmain"),
	CUSTOMIZE_MENU_SETTINGS = By.className("zsiq_setting"),
	CUSTOMIZE_MENU_HEADER = By.className("cumtz_padn"),
	CUSTOMIZE_MENU_FLOATING_HEADER = By.id("floatingheader"),
	PRESET_EDIT = By.id("presetedt"),
	PRESET_LABEL = By.id("presetlbl"),
	SELECTED_PRESET_NAME = By.id("presetname"),
	SELECTED_PRESET_NAME_DIV = By.id("presetname_div"),
	SELECT_PRESET_DROPDOWN = By.id("presetname_ddown"),
	DEFAULT_PRESET_DROPDOWN = By.id("presetname0"),
	PRESET_DROPDOWN_LIST = By.className("ullistwrap"),
	PRESET_SETTINGS = By.className("sqico-settings"),
	CUSTOMIZE_MENU_RINGS = By.id("cumtz_main"),
	CUSTOMIZE_RING1 = By.id("cumtz_drdn_1"),
	CUSTOMIZE_RING2 = By.id("cumtz_drdn_2"),
	CUSTOMIZE_RING3 = By.id("cumtz_drdn_3"),
	CUSTOMIZE_RING4 = By.id("cumtz_drdn_4"),
	PRESET_SETTING = By.id("presetsettings"),
	USER_DEFINED_PRESET = By.className("show_drop"),
	PRESET_STATUS = By.xpath("//em[@purpose='statuscheckbox']"),
	PRESET_TEXT = By.className("txtelips"),
	CUSTOMIZE_MENU_CLOSE = By.className("sqico-close")
	;

	public static Hashtable<String,Boolean> checkApi(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,boolean toCheckInUI,String response_code,boolean isReplace,boolean isPayload,Api api_obj,int startKey) throws Exception
	{
		boolean isResponse = (response_code == Constants.SUCCESS_CODE)?true:false;
		String trackingPresetsId = "",view = "",hide_other_agent_connected_visitors = "";

		JSONObject payload = null;

		Hashtable<String,String> trackingPresetsInfo = new Hashtable<String,String>();
		Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();

		try
		{
			String
			keys_check_usecase = "RESTAPI" + startKey,
			api_values_usecase = "RESTAPI" + (++startKey),
			ui_values_usecase = "RESTAPI" + (++startKey)
			;

			int randomId = CommonUtil.getRandomId();

			if(api_obj == Api.TRACKING_PRESETS_ENABLE)
			{
				randomId = 1225;
			}
			else if(api_obj == Api.TRACKING_PRESETS_DISABLE)
			{
				randomId = 1252;
			}
			String
			name = "trackingpreset"+randomId,
			description = "trackingpresetdesc"+randomId,
			applied = APPLIED[randomId%2],
			enabled = ENABLED[randomId%2],
			deleted = "false"
			;

			String sample_criteria = RestAPIConfManager.getRealValue("tracking_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] ring_criteria1 = criteria[randomId%22].split(",");
			String[] ring_criteria2 = criteria[(randomId+1)%22].split(",");
			String[] ring_criteria3 = criteria[(randomId+2)%22].split(",");
			String[] ring_criteria4 = criteria[(randomId+3)%22].split(",");

			if(api_obj == Api.TRACKING_PRESETS_ENABLE)
			{
				enabled = "true";
			}
			else if(api_obj == Api.TRACKING_PRESETS_DISABLE)
			{
				enabled = "false";
			}
			else if(api_obj == Api.TRACKING_PRESETS_DELETE)
			{
				deleted = "true";
				isResponse = false;
			}
			else if((api_obj == Api.TRACKING_PRESETS_UPDATE_SELECT_RING) || (api_obj == Api.TRACKING_PRESETS_SELECTED))
			{
				view = "ring";
				hide_other_agent_connected_visitors = "enabled";
			}
			else if(api_obj == Api.TRACKING_PRESETS_UPDATE_SELECT_LIST)
			{
				view = "list";
				hide_other_agent_connected_visitors = "disabled";
			}


			Hashtable<String,String> expectedIntegInfo = getExpectedInfo(name,description,enabled,applied,ring_criteria1,ring_criteria2,ring_criteria3,ring_criteria4,deleted,view,hide_other_agent_connected_visitors);

			if(isPayload)
			{
				if((api_obj == Api.TRACKING_PRESETS_ENABLE) || (api_obj == Api.TRACKING_PRESETS_DISABLE))
				{
					payload = GetPayload.getEnablePayload(enabled);
				}
				else if((api_obj == Api.TRACKING_PRESETS_UPDATE_SELECT_RING) || (api_obj == Api.TRACKING_PRESETS_UPDATE_SELECT_LIST))
				{
					payload = GetPayload.getUpdateTrackingUserPreferencesPayload(view,hide_other_agent_connected_visitors);
				}
				else
				{
					payload = GetPayload.getCreateTrackingPresetsPayload(name,description,applied,enabled,ring_criteria1,ring_criteria2,ring_criteria3,ring_criteria4);
				}

				etest.log(Status.INFO,"Below json will be used as payload");
				SalesIQRestAPICommonFunctions.log(etest,payload);
			}


			if(response_code == Constants.INVALID_SCOPE_ERROR_CODE)
			{
				trackingPresetsId = "123256789"; //just random value
			}
			else if(api_obj != Api.TRACKING_PRESETS_CREATE)
			{
				if(api_obj == Api.TRACKING_PRESETS_UPDATE)
				{
					randomId = randomId+2;
				}
				trackingPresetsId = createNewTrackingPreset(driver,api_webdriver,randomId,etest);
			}

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,ID,trackingPresetsId,api_obj,isPayload,payload,etest);


			if((api_obj == Api.TRACKING_PRESETS_CREATE) && (response_code != Constants.INVALID_SCOPE_ERROR_CODE))
			{
				trackingPresetsId = new JSONObject(new JSONObject(response).get("data").toString()).get("id").toString();
			}

			expectedIntegInfo.put("id",trackingPresetsId);

			if(isResponse)
			{
				try
				{
					result.put(keys_check_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED KEYS ARE FOUND</b>");
					result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}

				try
				{
					result.put(api_values_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN API RESPONSE</b>");

					result.put(api_values_usecase,checkData(expectedIntegInfo,null,keys_check_usecase,response,false,etest));

				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}
			}
			else
			{
				result.put(keys_check_usecase,false);

				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
				{
					result.put(keys_check_usecase,true);
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					result.put(keys_check_usecase,false);
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
				}

				ui_values_usecase = api_values_usecase;
			}

			if((toCheckInUI) && (response_code == Constants.SUCCESS_CODE))
			{
				try
				{
					trackingPresetsInfo = getTrackingPresetsInfo(driver,trackingPresetsId,etest);

					result.put(ui_values_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN UI</b>");

					result.put(ui_values_usecase,checkData(expectedIntegInfo,trackingPresetsInfo,keys_check_usecase,response,true,etest));
					if(!result.get(ui_values_usecase))
					{
						TakeScreenshot.screenshot(driver,etest);
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}

		return result;
	}

	public static String createNewTrackingPreset(WebDriver driver,WebDriver api_webdriver,int randomId,ExtentTest etest)
	{
		try
		{
			String
			name = "trackingpreset"+randomId,
			description = "trackingpresetdesc"+randomId,
			applied = APPLIED[randomId%2],
			enabled = ENABLED[randomId%2]
			;

			String sample_criteria = RestAPIConfManager.getRealValue("tracking_criteria");
			String[] criteria = sample_criteria.split("#");
			String[] ring_criteria1 = criteria[randomId%22].split(",");
			String[] ring_criteria2 = criteria[(randomId+1)%22].split(",");
			String[] ring_criteria3 = criteria[(randomId+2)%22].split(",");
			String[] ring_criteria4 = criteria[(randomId+3)%22].split(",");

			JSONObject payload = GetPayload.getCreateTrackingPresetsPayload(name,description,applied,enabled,ring_criteria1,ring_criteria2,ring_criteria3,ring_criteria4);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),false,"","",Api.TRACKING_PRESETS_CREATE,true,payload,etest);
			String id = new JSONObject(new JSONObject(response).get("data").toString()).get("id").toString();

			return id;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
			return "exception_occurred";
		}
	}

	public static Hashtable<String,String> getTrackingPresetsInfo(WebDriver driver,String id,ExtentTest etest)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		boolean isDeleted,isApplied,isPresent,isEnabled = false;

		WebElement presetElement = null,preset = null;

		String presetName = "";

		try
		{
			CommonUtil.refreshPage(driver);
			Tab.clickVisitorsOnline(driver);
			String ring_type = (CommonUtil.getElement(driver,CUSTOMIZE_HEADER,TRACKING_LIST_TYPE).getAttribute("class").contains("vo_ring")) ? "ring" : "list";
			CommonUtil.clickWebElement(driver,CUSTOMIZE_HEADER,TRACKING_CUSTOMIZE);
			CommonWait.waitTillDisplayed(driver,CUSTOMIZE_MENU);
			etest.info("Before getting info from UI");
			TakeScreenshot.infoScreenshot(driver,etest);

			WebElement customizeMenuSettings = CommonUtil.getElement(driver,CUSTOMIZE_MENU,CUSTOMIZE_MENU_RULES,CUSTOMIZE_MENU_SETTINGS);
			WebElement customizeMenuHeader = CommonUtil.getElement(customizeMenuSettings,CUSTOMIZE_MENU_HEADER);
			WebElement customizeMenuRings = CommonUtil.getElement(customizeMenuSettings,CUSTOMIZE_MENU_RINGS);

			WebElement presetNameDiv = CommonUtil.getElement(customizeMenuHeader,CUSTOMIZE_MENU_FLOATING_HEADER,PRESET_LABEL,SELECTED_PRESET_NAME,SELECTED_PRESET_NAME_DIV);
			presetName = presetNameDiv.getText().trim();
			String presetDescription = CommonUtil.getElement(customizeMenuHeader,CUSTOMIZE_MENU_FLOATING_HEADER,By.tagName("p")).getText().trim();

			String selectedPresetId = CommonUtil.getElement(presetNameDiv,By.className("txtelips")).getAttribute("val");

			CommonUtil.clickWebElement(driver,presetNameDiv.findElement(By.tagName("span")));
			CommonWait.waitTillDisplayed(driver,SELECT_PRESET_DROPDOWN);
			etest.pass("Preset dropdown");
			TakeScreenshot.infoScreenshot(driver,etest);

			WebElement presetDropdown = CommonUtil.getElement(driver,SELECT_PRESET_DROPDOWN,PRESET_DROPDOWN_LIST);

			if(presetDropdown != null)
			{
				List<WebElement> presetDropdownList = presetDropdown.findElements(By.tagName("li"));

				presetElement = CommonUtil.getElementByAttributeValue(presetDropdownList,"val",id);
			}

			if(presetElement == null)
			{
				isApplied = false;
				isEnabled = false;
			}
			else
			{
				isApplied = (selectedPresetId.contains(id));
			}

			WebElement presetSettings = CommonUtil.getElement(driver,PRESET_SETTINGS);
			if(CommonWait.isDisplayed(presetSettings))
			{
				CommonUtil.clickWebElement(driver,PRESET_SETTINGS);
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,PRESET_SETTING),"content","false");
				preset = CommonUtil.getElementByAttributeValue(driver,PRESET_SETTING,USER_DEFINED_PRESET,"innerHTML",id);
			}

			if(preset == null)
			{
				isPresent = false;
				info.put(PRESET_DELETED,(!isPresent)+"");
			}
			else
			{
				isPresent = true;

				isEnabled = CommonUtil.getElement(preset,PRESET_STATUS).getAttribute("class").contains("sqico-checkbox");
				presetName = CommonUtil.getElement(preset,PRESET_TEXT).getAttribute("innerText");
				presetDescription = CommonUtil.getElement(preset,By.tagName("p")).getAttribute("innerText");

				if(!isEnabled)
				{
					CommonUtil.mouseHover(driver,preset);
					WebElement option=preset.findElement(By.className("sqico-uncheckbox"));
					CommonUtil.inViewPort(option);
					CommonUtil.waitTillWebElementDisplayed(driver,option);
					CommonUtil.mouseHoverAndClick(driver,option);
					CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(preset,PRESET_STATUS),"class","sqico-checkbox");
				}

				try
				{
					TrackingRingsCustomizeCommonFunctions.clickBackButtonInPresetSettings(driver,etest);
				}
				catch(Exception e)
				{
					CommonUtil.doNothing();
				}

			}

			customizeMenuSettings = CommonUtil.getElement(driver,CUSTOMIZE_MENU,CUSTOMIZE_MENU_RULES,CUSTOMIZE_MENU_SETTINGS);
			customizeMenuHeader = CommonUtil.getElement(customizeMenuSettings,CUSTOMIZE_MENU_HEADER);
			customizeMenuRings = CommonUtil.getElement(customizeMenuSettings,CUSTOMIZE_MENU_RINGS);

			try
			{
				TrackingRingsCustomizeCommonFunctions.setVisitorPrioririzedBy(driver,presetName,etest);
			}
			catch(Exception e)
			{
				CommonUtil.printStackTrace(e);
			}

			String ring1 = formatRingText(CommonUtil.getElement(customizeMenuRings,CUSTOMIZE_RING1).getText());
			String ring2 = formatRingText(CommonUtil.getElement(customizeMenuRings,CUSTOMIZE_RING2).getText());
			String ring3 = formatRingText(CommonUtil.getElement(customizeMenuRings,CUSTOMIZE_RING3).getText());
			String ring4 = formatRingText(CommonUtil.getElement(customizeMenuRings,CUSTOMIZE_RING4).getText());

			TrackingRingsCustomizeCommonFunctions.addNewTrackingCustomizeRule(driver,etest,TrackingRing.RING1,RuleType.NEW,RuleCondition.BROWSER,RuleCriteria.EQUAL,"Apple Safari",null);

			String isHideVisitorFromOtherAgentsEnabled = (CommonUtil.getElement(driver,PRESET_DEFAULT_RULE).getAttribute("class").contains("sqico-checkbox")) ? "enabled":"disabled";

			info.put(PRESET_NAME,presetName);
			info.put(PRESET_DESCRIPTION,presetDescription);
			info.put(RING1_CONTENT,ring1);
			info.put(RING2_CONTENT,ring2);
			info.put(RING3_CONTENT,ring3);
			info.put(RING4_CONTENT,ring4);
			info.put(PRESET_ENABLED,isEnabled+"");
			info.put(RING_TYPE,ring_type);
			info.put(PRESET_APPLIED,isApplied+"");
			info.put(HIDE_OTHER_AGENT_CONNECTED_VISITORS,isHideVisitorFromOtherAgentsEnabled);

			try
			{
				TrackingRingsCustomizeCommonFunctions.closeCustomizeMenu(driver,etest);
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			CommonUtil.printStackTrace(e);
		}

		CommonUtil.print("\n\nTrackingpresets -- getInfo >>>>>"+info);

		return info;
	}

	public static String formatRingText(String ringText)
	{
		return ringText.trim().replaceAll(" ","_").toLowerCase().replaceAll("is_less_than","less_than").replaceAll("is_more_than","greater_than").replaceAll("is_not_equal_to","not_equals");
	}

	public static boolean checkData(Hashtable<String,String> expected,Hashtable<String,String> valuesFromUI,String keyToCheck,String response,boolean isUI,ExtentTest etest) throws Exception
	{
		String expected_value,actual_value;

		String[] keysToCheck = RestAPIConfManager.getRealValue(keyToCheck+"_keys").split(",");

		int failcount = 0;

		int index = 0;

		String apiTestKey = "";

        for(int i = 0; i < keysToCheck.length; i++)
        {
        	apiTestKey = keysToCheck[i];
        	if(keysToCheck[i].contains("<id>"))
        	{
        		JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
				JSONArray trackingPresets = json_response.getJSONArray("data");
				index = SalesIQRestAPICommonFunctions.getJSONIndexWith(trackingPresets,"id",expected.get("id"));
				apiTestKey = keysToCheck[i].replaceAll("<id>",index+"");
        	}
        	etest.log(Status.INFO,"Checking "+keysToCheck[i]);
        	CommonUtil.print("keysToCheck[i]<><><>"+keysToCheck[i]+"\n\napiTestKey<><><><>"+apiTestKey);
        	if(isUI)
        	{
	    		expected_value = expected.get(keysToCheck[i].replaceAll("/","_").replace("[<id>]",""));
	    		actual_value = valuesFromUI.get(keysToCheck[i].replaceAll("/","_").replace("[<id>]",""));
	    	}
	    	else
	    	{
	    		actual_value = expected.get(keysToCheck[i].replaceAll("/","_").replace("[<id>]",""));

	    		expected_value = SalesIQRestAPICommonFunctions.jPath(response,apiTestKey);
	    		if(!keysToCheck[i].contains("rule"))
	    		{
	    			expected_value = expected_value.replaceAll("_","");
	    		}
	    		else
	    		{
	    			String comparator = apiTestKey + "[0]/or_criteria[0]/comparator";
	    			String field_name = apiTestKey + "[0]/or_criteria[0]/field_name";
	    			String values = apiTestKey + "[0]/or_criteria[0]/values[0]";
	    			expected_value = (SalesIQRestAPICommonFunctions.jPath(response,field_name)+"_"+
	    								SalesIQRestAPICommonFunctions.jPath(response,comparator)+"_"+
	    									SalesIQRestAPICommonFunctions.jPath(response,values)).toLowerCase();
	    		}
	    	}

	    	etest.log(Status.INFO,"expected_value "+expected_value+"\n\n actual_value "+actual_value);

    		if(expected_value.contains(","))
    		{
    			String[] values = expected_value.replace("]","").replace("[","").split(",");
    			for(String value : values)
    			{
	    			if(!CommonUtil.checkStringContainsAndLog(value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
		    		{
		    			failcount++;
		    		}
    			}
    		}
    		else 
    		{
    			if(!CommonUtil.checkStringContainsAndLog(expected_value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
	    		{
	    			failcount++;
	    		}
	    	}
        }

        return CommonUtil.returnResult(failcount);
	}

	public static Hashtable<String,String> getExpectedInfo(String preset_name,String preset_description,String preset_enabled,String preset_applied,String[] ring1_content,String[] ring2_content,String[] ring3_content,String[] ring4_content,String preset_deleted,String ring_type,String hide_other_agent_connected_visitors)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		info.put(PRESET_DELETED,preset_deleted+"");
		info.put(PRESET_NAME,preset_name);
		info.put(PRESET_DESCRIPTION,preset_description);
		info.put(PRESET_ENABLED,preset_enabled);
		info.put(RING1_CONTENT,(ring1_content[0]+"_"+ring1_content[1]+"_"+ring1_content[2]).toLowerCase());
		info.put(RING2_CONTENT,(ring2_content[0]+"_"+ring2_content[1]+"_"+ring2_content[2]).toLowerCase());
		info.put(RING3_CONTENT,(ring3_content[0]+"_"+ring3_content[1]+"_"+ring3_content[2]).toLowerCase());
		info.put(RING4_CONTENT,(ring4_content[0]+"_"+ring4_content[1]+"_"+ring4_content[2]).toLowerCase());
		info.put(PRESET_APPLIED,preset_applied);
		info.put(RING_TYPE,ring_type);
		info.put(HIDE_OTHER_AGENT_CONNECTED_VISITORS,hide_other_agent_connected_visitors);

		CommonUtil.print("\n\nTrackingpresets -- getExpectedInfo >>>>>"+info);
		return info;
	}
}
