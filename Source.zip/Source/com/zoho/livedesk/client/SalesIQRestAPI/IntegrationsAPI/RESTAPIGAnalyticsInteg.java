//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPIGAnalyticsInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[]
	ENABLED_VALUES = {"true","false"}
	;

	public static final By
	ANALYTICSCONFIG = By.id("analyticsconfig"),
	CONFIGLIST = By.className("configlist"),
	TOGGLE_BUTTON = By.className("togglebtn")
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	APP_NAME = "data_apps[0]_name",
	APP_ID = "data_apps[0]_id",
	APP_ENABLED = "data_apps[0]_enabled",
	ENABLED = "data_enabled",
	ANALYTICS = "Google Analytics",
	ID = "<id>",
	TBUT_ID = "tbutid",
	LAST = "Last",
	SET_ON = "set_on"
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api2");

			etest = ComplexReportFactory.getEtest("Check get individual Google Analytics integration",MODULE_NAME);
			checkGetGAnalyticsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,850,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,true,Constants.SUCCESS_CODE,852,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,true,Constants.SUCCESS_CODE,855,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,false,Constants.SUCCESS_CODE,858,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,false,Constants.SUCCESS_CODE,861,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check get individual Google Analytics integration",MODULE_NAME);
			checkGetGAnalyticsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,864,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Disable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,true,Constants.PERMISSION_ERROR_CODE,865,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Enable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,true,Constants.PERMISSION_ERROR_CODE,866,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Disable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,false,Constants.PERMISSION_ERROR_CODE,867,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Enable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,false,Constants.PERMISSION_ERROR_CODE,868,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Check Associate -- Check get individual Google Analytics integration",MODULE_NAME);
			checkGetGAnalyticsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,869,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Disable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,true,Constants.PERMISSION_ERROR_CODE,870,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Enable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,true,Constants.PERMISSION_ERROR_CODE,871,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Disable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,false,Constants.PERMISSION_ERROR_CODE,872,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Enable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,false,Constants.PERMISSION_ERROR_CODE,873,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Google Analytics integration",MODULE_NAME);
			checkGetGAnalyticsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,874,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,true,Constants.INVALID_SCOPE_ERROR_CODE,875,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable apps in Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,true,Constants.INVALID_SCOPE_ERROR_CODE,876,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,false,false,Constants.INVALID_SCOPE_ERROR_CODE,877,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Google Analytics integration",MODULE_NAME);
			checkUpdateGAnalyticsAPI(driver,api_webdriver,true,false,Constants.INVALID_SCOPE_ERROR_CODE,878,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetGAnalyticsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> info = getInfoFromUI(driver);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_ANALYTICS_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateGAnalyticsAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,boolean isAppsUpdate,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled_key = ENABLED;
			String app_id = "";
			boolean isReplace = false;
			String replaceString = "";
			Api api_obj = Api.INTEG_ANALYTICS_UPDATE;
			if(isAppsUpdate)
			{
				replaceString = ID;
				isReplace = true;
				api_obj = Api.INTEG_ANALYTICS_APPS_UPDATE;
				enabled_key = APP_ENABLED;
				app_id = ExecuteStatements.getWebsiteIDFromEmbedName(driver,ExecuteStatements.getDefaultEmbedName(driver));
			}
			
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(enabled_key,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,isReplace,replaceString,app_id,api_obj,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,ANALYTICS);

			WebElement app = CommonUtil.getElement(driver,ANALYTICSCONFIG,CONFIGLIST);
			String appDetails = app.getText().trim();
			String appName = appDetails.substring(0,appDetails.indexOf(LAST)).trim();

			WebElement toggle = CommonUtil.getElement(app,TOGGLE_BUTTON);
			String app_enabled = (toggle.getAttribute("class").contains(SET_ON)) + "";

			String tbut_id = toggle.getAttribute(TBUT_ID);
			String app_id = tbut_id.substring(tbut_id.indexOf("_")+1);

			info.put(APP_NAME,appName);
			info.put(APP_ID,app_id);
			info.put(APP_ENABLED,app_enabled);
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));


		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
		}

		return info;
	}
}