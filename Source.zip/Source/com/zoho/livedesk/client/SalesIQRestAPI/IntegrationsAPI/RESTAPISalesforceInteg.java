//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPISalesforceInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[]
	ATTACH_TRANSCRIPT_VALUES = {"true","false"},
	FOLLOWUP_TASK_ON_VALUES = {"next_week","this_week","none","today","tomorrow"},
	DEPARTMENTS_SELECTED_VALUES = {"all","custom"},
	VISITORS_TO_BE_PUSHED_VALUES = {"missed","attended","accessed"},
	ADD_NEW_VISITOR_AS_VALUES = {"lead","contact"},
	VISITOR_STATUS_IN_LIVEDESK_VALUES = {"push_to_crm","missed"},
	ENABLE_VALUES = {"true","false"}
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	RESOURCE_NAME = "<resource_name>",
	ID = "<id>",
	SALESFORCE = "Salesforce",
	CRM = "Zoho CRM",
	ATTACH_TRANSCRIPT_KEY = "data_general_config_attach_transcript",
	ASSIGNED_OWNER_KEY = "data_general_config_assigned_owner",
	FOLLOWUP_TASK_ON_KEY = "data_general_config_followup_task_on",
	DEPARTMENTS_SELECTED_KEY = "data_general_config_departments_selected",
	VISITORS_TO_BE_PUSHED_KEY = "data_general_config_visitors_to_be_pushed",
	ADD_NEW_VISITOR_AS_KEY = "data_general_config_add_new_visitor_as",
	VISITOR_STATUS_IN_LIVEDESK_KEY = "data_general_config_visitor_status_in_livedesk",
	OWNER_EMAIL_KEY = "data_owner_email",
	ENABLED_KEY = "data_enabled",
	LEAD_APP_FIELDS_JSON = "integ_salesforce_lead_appfields.json",
	CONTACT_APP_FIELDS_JSON = "integ_salesforce_contact_appfields.json",
	OPPORTUNITY_APP_FIELDS_JSON = "integ_salesforce_opportunity_appfields.json",
	SET_ON = "set_on",
	ALL_DEPARTMENTS = "alldept",
	ALL = "all",
	CUSTOM = "custom",
	LEAD = "lead",
	CONTACT = "contact",
	OPPORTUNITY = "opportunity",
	LEAD_ID = "crmmodlead"
	;

	public static final By
	OWNER_EMAIL = By.xpath("//*[@id='iscdetailsdiv']//div[@class='myprfdtlmn_rht']/div"),
	VISITORS_TO_BE_PUSHED = By.id("vistypecrmdiv"),
	ADD_NEW_VISITOR_AS = By.id("crmradio"),
	FOLLOWUP_TASK_ON = By.id("newcusaddtask_div"),
	ASSIGNED_OWNER = By.id("assignowner_div"),
	ATTACH_TRANSCRIPT = By.id("excuspushchattrans"),
	VISITOR_STATUS_IN_LIVEDESK = By.id("vstatusinlivedesk_div"),
	DEPARTMENTS_SELECTED = By.id("crmdeptsel")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api1");

			etest = ComplexReportFactory.getEtest("Check get individual Salesforce integration",MODULE_NAME);
			checkGetSalesforceAPI(driver,api_webdriver,Constants.SUCCESS_CODE,725,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check get Salesforce user details",MODULE_NAME);
			checkGetSalesforceAppUserDetailsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,727,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check get Salesforce App field details",MODULE_NAME);
			checkGetSalesforceAppFieldsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,729,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Salesforce details",MODULE_NAME);
			checkUpdateSalesforceAPI(driver,api_webdriver,Constants.SUCCESS_CODE,732,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Salesforce Department",MODULE_NAME);
			checkUpdateSalesforceDepartmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,735,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,738,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,741,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check Supervisor -- get individual Salesforce integration",MODULE_NAME);
			checkGetSalesforceAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,744,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- get Salesforce user details",MODULE_NAME);
			checkGetSalesforceAppUserDetailsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,745,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- get Salesforce App field details",MODULE_NAME);
			checkGetSalesforceAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,746,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Update Salesforce details",MODULE_NAME);
			checkUpdateSalesforceAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,749,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Update Salesforce Department",MODULE_NAME);
			checkUpdateSalesforceDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,750,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Disable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,751,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Enable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,752,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Check Associate -- get individual Salesforce integration",MODULE_NAME);
			checkGetSalesforceAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,753,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- get Salesforce user details",MODULE_NAME);
			checkGetSalesforceAppUserDetailsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,754,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- get Salesforce App field details",MODULE_NAME);
			checkGetSalesforceAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,755,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Update Salesforce details",MODULE_NAME);
			checkUpdateSalesforceAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,758,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Update Salesforce Department",MODULE_NAME);
			checkUpdateSalesforceDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,759,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Disable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,760,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Enable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,761,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check invalid scope -- get individual Salesforce integration",MODULE_NAME);
			checkGetSalesforceAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,762,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- get Salesforce user details",MODULE_NAME);
			checkGetSalesforceAppUserDetailsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,763,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- get Salesforce App field details",MODULE_NAME);
			checkGetSalesforceAppFieldsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,764,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Update Salesforce details",MODULE_NAME);
			checkUpdateSalesforceAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,767,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Update Salesforce Department",MODULE_NAME);
			checkUpdateSalesforceDepartmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,768,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Disable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,769,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check invalid scope -- Enable Salesforce Integration",MODULE_NAME);
			checkEnableSalesforceAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,770,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetSalesforceAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,SALESFORCE,CRM,etest);

			Hashtable<String,String> info = getInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_SALESFORCE_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetSalesforceAppUserDetailsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> info = IntegrationRESTAPICommonFunctions.getValuesFromConf("RESTAPI727");
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_SALESFORCE_GET_USER,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetSalesforceAppFieldsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String leadKey = "RESTAPI" + startKey;
			String contactKey = "RESTAPI" + (startKey+1);
			String opportunityKey = "RESTAPI" + (startKey+2);

			result.put(leadKey,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,RESOURCE_NAME,LEAD,Api.INTEG_SALESFORCE_APP_FIELDS,LEAD_APP_FIELDS_JSON,startKey,etest));
			result.put(contactKey,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,RESOURCE_NAME,CONTACT,Api.INTEG_SALESFORCE_APP_FIELDS,CONTACT_APP_FIELDS_JSON,(startKey+1),etest));
			result.put(opportunityKey,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,RESOURCE_NAME,OPPORTUNITY,Api.INTEG_SALESFORCE_APP_FIELDS,OPPORTUNITY_APP_FIELDS_JSON,(startKey+2),etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateSalesforceAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String
			attach_transcript = ATTACH_TRANSCRIPT_VALUES[randomId%2],
			followup_task_on = FOLLOWUP_TASK_ON_VALUES[randomId%5],
			departments_selected = DEPARTMENTS_SELECTED_VALUES[1],
			visitors_to_be_pushed = VISITORS_TO_BE_PUSHED_VALUES[randomId%3],
			add_new_visitor_as = ADD_NEW_VISITOR_AS_VALUES[randomId%2],
			visitor_status_in_livedesk = VISITOR_STATUS_IN_LIVEDESK_VALUES[randomId%2]
			;

			JSONObject payload = GetPayload.getUpdateCRMPayload(null,attach_transcript,null,null,followup_task_on,departments_selected,visitors_to_be_pushed,add_new_visitor_as,visitor_status_in_livedesk,null,null);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedCRMInfo(attach_transcript,followup_task_on,departments_selected,visitors_to_be_pushed,add_new_visitor_as,visitor_status_in_livedesk);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_SALESFORCE_UPDATE,payload,expectedInfo,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateSalesforceDepartmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);
			String enabled = ENABLE_VALUES[randomId%2];

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put("enabled",enabled);
			info.put("id",department_id);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,ID,department_id,Api.INTEG_SALESFORCE_DEPT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkEnableSalesforceAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED_KEY,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_SALESFORCE_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		try
		{
			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,SALESFORCE);

			info.put(ATTACH_TRANSCRIPT_KEY,IntegrationRESTAPICommonFunctions.getSelectedFromToggle(driver,ATTACH_TRANSCRIPT,SET_ON));
			info.put(ASSIGNED_OWNER_KEY,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,ASSIGNED_OWNER));
			info.put(FOLLOWUP_TASK_ON_KEY,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,FOLLOWUP_TASK_ON));
			info.put(DEPARTMENTS_SELECTED_KEY,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,DEPARTMENTS_SELECTED,ALL_DEPARTMENTS,ALL,CUSTOM));
			info.put(VISITORS_TO_BE_PUSHED_KEY,"["+IntegrationRESTAPICommonFunctions.getSelectedFromCheckBox(driver,VISITORS_TO_BE_PUSHED)+"]");
			info.put(ADD_NEW_VISITOR_AS_KEY,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,ADD_NEW_VISITOR_AS,LEAD_ID,LEAD,CONTACT));
			info.put(VISITOR_STATUS_IN_LIVEDESK_KEY,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,VISITOR_STATUS_IN_LIVEDESK).replace("pushed","push"));
			info.put(OWNER_EMAIL_KEY,IntegrationRESTAPICommonFunctions.getTextFromDiv(driver,OWNER_EMAIL));
			info.put(ENABLED_KEY,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
		}
		return info;
	}

	public static Hashtable<String,String> getExpectedCRMInfo(String attach_transcript,String followup_task_on,String departments_selected,String visitors_to_be_pushed,String add_new_visitor_as,String visitor_status_in_livedesk)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		
		info.put(ATTACH_TRANSCRIPT_KEY,attach_transcript);
		info.put(FOLLOWUP_TASK_ON_KEY,followup_task_on.replaceAll("_",""));
		info.put(DEPARTMENTS_SELECTED_KEY,departments_selected);
		info.put(VISITORS_TO_BE_PUSHED_KEY,"[\""+visitors_to_be_pushed+"\"]");
		info.put(ADD_NEW_VISITOR_AS_KEY,add_new_visitor_as);
		info.put(VISITOR_STATUS_IN_LIVEDESK_KEY,visitor_status_in_livedesk.replaceAll("_",""));
		
		return info;
	}
}