//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPICampaignInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[]
	FIELD_ID = {"city","state","phone","country","zip"},
	INTEGRATION_FIELD_ID = {"city","state","phone","country","zipcode"},
	INTEGRATION_FIELD_NAME = {"City","State","Phone","Country","Zip Code"},
	FIELD_STATUS = {"enabled","disabled"},
	ENABLE_VALUES = {"true","false"}
	;

	public static final String 
	MODULE_NAME = "Integration RESTAPI",
	CAMPAIGN = "Zoho Campaigns",
	MAILCHIMP = "MailChimp",
	ID = "<id>",
	ZSC_KEY = "data_connected_account_key",
	ENABLED = "data_enabled",
	DEPARTMENTS_SELECTED = "data_general_config_departments_selected",
	FIELDS = "data_fields",
	CONFIGTABLE = "configtable",
	ALL = "all",
	CUSTOM = "custom",
	ALL_DEPARTMENTS = "alldept",
	APP_FIELDS_JSON = "integ_campaign_contact_appfields.json"
	;

	public static final By
	DEPT_SELECTED = By.id("crmdeptsel"),
	ZSC_KEY_DIV = By.id("zsckeylabeldiv"),
	ZSC_REGENERATE = By.id("zsckeyeditlink"),
	LIST_ROW = By.className("list-row"),
	CAMP_FIELDS = By.className("camp_fields")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

            WebDriver campaignDriver = Functions.setUp();
            Functions.loginZohoCampaign(campaignDriver,"integration_restapi3");

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api3");

			etest = ComplexReportFactory.getEtest("Check get individual Zoho Campaign integration",MODULE_NAME);
			checkGetCampaignAPI(driver,api_webdriver,campaignDriver,Constants.SUCCESS_CODE,686,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Campaign get App fields",MODULE_NAME);
			checkGetCampaignAppFieldsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,688,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Campaign update configurations",MODULE_NAME);
			checkCampaignUpdateConfigAPI(driver,api_webdriver,Constants.SUCCESS_CODE,689,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Campaign update department configuration",MODULE_NAME);
			checkCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,692,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,698,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,695,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check authenticate ZSC Key in Zoho Campaign integration",MODULE_NAME);
			checkCampaignZSCKeyAuthenticateAPI(driver,api_webdriver,campaignDriver,Constants.SUCCESS_CODE,701,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check get individual Zoho Campaign integration",MODULE_NAME);
			checkGetCampaignAPI(driver,api_webdriver,campaignDriver,Constants.PERMISSION_ERROR_CODE,704,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check Zoho Campaign get App fields",MODULE_NAME);
			checkGetCampaignAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,705,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check Zoho Campaign update configurations",MODULE_NAME);
			checkCampaignUpdateConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,706,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check Zoho Campaign update department configuration",MODULE_NAME);
			checkCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,707,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check Disable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,708,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check Enable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,709,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Supervisor -- Check authenticate ZSC Key in Zoho Campaign integration",MODULE_NAME);
			checkCampaignZSCKeyAuthenticateAPI(driver,api_webdriver,campaignDriver,Constants.PERMISSION_ERROR_CODE,710,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check get individual Zoho Campaign integration",MODULE_NAME);
			checkGetCampaignAPI(driver,api_webdriver,campaignDriver,Constants.PERMISSION_ERROR_CODE,711,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check Zoho Campaign get App fields",MODULE_NAME);
			checkGetCampaignAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,712,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check Zoho Campaign update configurations",MODULE_NAME);
			checkCampaignUpdateConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,713,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check Zoho Campaign update department configuration",MODULE_NAME);
			checkCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,714,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check Disable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,715,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check Enable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,716,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Campaign Associate -- Check authenticate ZSC Key in Zoho Campaign integration",MODULE_NAME);
			checkCampaignZSCKeyAuthenticateAPI(driver,api_webdriver,campaignDriver,Constants.PERMISSION_ERROR_CODE,717,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Zoho Campaign integration",MODULE_NAME);
			checkGetCampaignAPI(driver,api_webdriver,campaignDriver,Constants.INVALID_SCOPE_ERROR_CODE,718,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Campaign get App fields",MODULE_NAME);
			checkGetCampaignAppFieldsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,719,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Campaign update configurations",MODULE_NAME);
			checkCampaignUpdateConfigAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,720,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Campaign update department configuration",MODULE_NAME);
			checkCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,721,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,722,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Zoho Campaign integration",MODULE_NAME);
			checkCampaignEnableAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,723,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check authenticate ZSC Key in Zoho Campaign integration",MODULE_NAME);
			checkCampaignZSCKeyAuthenticateAPI(driver,api_webdriver,campaignDriver,Constants.INVALID_SCOPE_ERROR_CODE,724,etest);
			ComplexReportFactory.closeTest(etest);

			Functions.logout(campaignDriver);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetCampaignAPI(WebDriver driver,WebDriver api_webdriver,WebDriver campaignDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,CAMPAIGN,MAILCHIMP,etest);
			
			String zscKey = IntegrationRESTAPICommonFunctions.getCampaignZSCKey(campaignDriver);
			IntegrationRESTAPICommonFunctions.changeZSCKey(driver,zscKey);

			Hashtable<String,String> info = getCampaignInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_CAMPAIGN_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetCampaignAppFieldsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String use_case_key = "RESTAPI"+startKey;
			result.put(use_case_key,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,false,"","",Api.INTEG_CAMPAIGN_APP_FIELDS,APP_FIELDS_JSON,startKey,etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	public static void checkCampaignUpdateConfigAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,CAMPAIGN);
			List<WebElement> fieldList = CommonUtil.getElement(driver,By.id(CONFIGTABLE)).findElements(LIST_ROW);

			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String previous_field_id = CommonUtil.getElement(fieldList.get(3),By.id("col1_3")).getAttribute("innerText").toLowerCase().trim().replaceAll(" ","").replaceAll("zipcode","zip");
			String field_id = FIELD_ID[randomId%5];

			if(previous_field_id.contains(field_id))
			{
				randomId++;
			}

			field_id = FIELD_ID[randomId%5];

			String
			departments_selected = "custom",
			integration_field_id = INTEGRATION_FIELD_ID[randomId%5],
			integration_field_name = INTEGRATION_FIELD_NAME[randomId%5],
			field_status = FIELD_STATUS[randomId%2]
			;

			JSONObject payload = GetPayload.getUpdateCampaignPayload(departments_selected,field_id,integration_field_id,field_status,previous_field_id);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedCampaignInfo(driver,departments_selected,field_id,integration_field_name,previous_field_id,field_status);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CAMPAIGN_UPDATE,payload,expectedInfo,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkCampaignUpdateDepartmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);
			String enabled = ENABLE_VALUES[randomId%2];

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put("enabled",enabled);
			info.put("id",department_id);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,ID,department_id,Api.INTEG_CAMPAIGN_DEPT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	public static void checkCampaignEnableAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CAMPAIGN_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkCampaignZSCKeyAuthenticateAPI(WebDriver driver,WebDriver api_webdriver,WebDriver campaignDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String key = IntegrationRESTAPICommonFunctions.getCampaignZSCKey(campaignDriver);
			String email = ExecuteStatements.getUserMail(driver);

			JSONObject payload = GetPayload.getZSCKeyPayload(key,email,null);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ZSC_KEY,key);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CAMPAIGN_KEY_AUTHENTICATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getCampaignInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);

			CommonUtil.refreshPage(driver);
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,CAMPAIGN);

			info.put(ZSC_KEY,IntegrationRESTAPICommonFunctions.getTextFromDiv(driver,ZSC_KEY_DIV));
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));
			info.put(DEPARTMENTS_SELECTED,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,DEPT_SELECTED,ALL_DEPARTMENTS,ALL,CUSTOM));
			info.put(FIELDS,getFieldDetails(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
		}

		return info;
	}

	public static Hashtable<String,String> getExpectedCampaignInfo(WebDriver driver,String departments_selected,String field_id,String integration_field_name,String previous_field_id,String field_status) throws Exception
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		JSONObject fieldDetails = new JSONObject(getFieldDetails(driver));
		fieldDetails.put(field_id,integration_field_name+"_"+field_status);
		fieldDetails.put(previous_field_id,integration_field_name+"_deleted");

		info.put(DEPARTMENTS_SELECTED,departments_selected);
		info.put(FIELDS,fieldDetails.toString());

		return info;
	}

	public static String getFieldDetails(WebDriver driver) throws Exception
	{
		return getFieldDetails(driver,"");
	}

	public static String getFieldDetails(WebDriver driver,String addOn) throws Exception
	{
		JSONObject fieldDetails = new JSONObject();

		String configTable = addOn.replace("_","") + CONFIGTABLE;

		List<WebElement> fieldList = CommonUtil.getElement(driver,By.id(configTable)).findElements(LIST_ROW);

		for(int i = 1; i < fieldList.size(); i++)
		{
			String fieldName = CommonUtil.getElement(fieldList.get(i),By.id(addOn+"col1_"+i)).getAttribute("innerText").toLowerCase().trim().replaceAll(" ","").replaceAll("zipcode","zip").replaceAll("emailaddress","emailAddresses").replace("companyname","name");
			String integratedFieldName = CommonUtil.getElement(fieldList.get(i),By.id(addOn+"col2_"+i)).getAttribute("innerText").trim();
			String field_status;
			if(fieldList.get(i).getAttribute("class").contains("nopoint"))
			{
				field_status = "default";
			}
			else if(fieldList.get(i).getAttribute("class").contains("greyout"))
			{
				field_status = "disabled";
			}
			else
			{
				field_status = "enabled";
			}

			fieldDetails.put(fieldName,integratedFieldName+"_"+field_status);
		}

		return fieldDetails.toString();
	}
}
