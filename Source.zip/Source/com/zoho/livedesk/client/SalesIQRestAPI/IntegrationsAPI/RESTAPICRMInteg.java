//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPICRMInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[]
	LEAD_AUTO_APPROVAL_VALUES = {"true","false"},
	ATTACH_TRANSCRIPT_VALUES = {"false","true"},
	ASSIGNED_OWNER_VALUES = {"-1","616141000000257009"},
	MINIMUM_LEADSCORE_VALUES = {"12","25","123","125","1225"},
	FOLLOWUP_TASK_ON_VALUES = {"next_week","this_week","none","today","tomorrow"},
	DEPARTMENTS_SELECTED_VALUES = {"all","custom"},
	VISITORS_TO_BE_PUSHED_VALUES = {"attended","accessed","missed"},
	ADD_NEW_VISITOR_AS_VALUES = {"lead","contact"},
	VISITOR_STATUS_IN_LIVEDESK_VALUES = {"push_to_crm","missed"},
	VISITOR_TRACKING_VALUES = {"add_visits","notify_crm"},
	ENABLE_VALUES = {"true","false"}
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	RESOURCE_NAME = "<resource_name>",
	SET_OFF = "set_off",
	SET_ON = "set_on",
	LEAD_AUTO_APPROVAL = "data_general_config_lead_auto_approval",
	ATTACH_TRANSCRIPT = "data_general_config_attach_transcript",
	ASSIGNED_OWNER = "data_general_config_assigned_owner",
	MINIMUM_LEADSCORE = "data_general_config_minimum_leadscore",
	FOLLOWUP_TASK_ON = "data_general_config_followup_task_on",
	DEPARTMENTS_SELECTED = "data_general_config_departments_selected",
	VISITORS_TO_BE_PUSHED = "data_general_config_visitors_to_be_pushed",
	ADD_NEW_VISITOR_AS = "data_general_config_add_new_visitor_as",
	VISITOR_STATUS_IN_LIVEDESK = "data_general_config_visitor_status_in_livedesk",
	VISITOR_TRACKING = "data_general_config_visitor_tracking",
	ENABLED = "data_enabled",
	ZSC_KEY = "data_connected_account_key",
	RADIO_SELECTED = "rdselected",
	ALL_DEPARTMENTS = "alldept",
	LEAD_ID = "crmmodlead",
	ALL = "all",
	CUSTOM = "custom",
	LEAD = "lead",
	CONTACT = "contact",
	DEAL = "deal",
	CRM = "Zoho CRM",
	SALESFORCE = "Salesforce",
	LEAD_APP_FIELDS_JSON = "integ_crm_lead_appfields.json",
	CONTACT_APP_FIELDS_JSON = "integ_crm_contact_appfields.json",
	DEAL_APP_FIELDS_JSON = "integ_crm_deal_appfields.json",
	ID = "<id>"
	;

	public static final By
	REQAPPROVAL = By.id("reqapproval"),
	EXCUSPUSHCHATTRANS = By.id("excuspushchattrans"),
	ASSIGNOWNER_DIV = By.id("assignowner_div"),
	VISLSCORETXT = By.id("vislscoretxt"),
	NEWCUSADDTASK_DIV = By.id("newcusaddtask_div"),
	CRMDEPTSEL = By.id("crmdeptsel"),
	UPRDOWRAP = By.className("uprdowrap"),
	VISTYPECRMDIV = By.id("vistypecrmdiv"),
	CRMRADIO = By.id("crmradio"),
	VSTATUSINLIVEDESK_DIV = By.id("vstatusinlivedesk_div"),
	VISTRACKCRMDIV = By.id("vistrackcrmdiv"),
	ZSC_KEY_DIV = By.id("zsckeydiv")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			WebDriver crmWebDriver = Functions.setUp();
			Functions.loginCRM(crmWebDriver,"integration_restapi1",5);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api1");

			etest = ComplexReportFactory.getEtest("Check get individual Zoho CRM integration",MODULE_NAME);
			checkGetCRMAPI(driver,api_webdriver,crmWebDriver,Constants.SUCCESS_CODE,594,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check get Zoho CRM user details",MODULE_NAME);
			checkGetAppUserDetailsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,596,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check get Zoho CRM App field details",MODULE_NAME);
			checkGetAppFieldsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,598,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Zoho CRM details",MODULE_NAME);
			checkUpdateCRMAPI(driver,api_webdriver,Constants.SUCCESS_CODE,601,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Zoho CRM Department",MODULE_NAME);
			checkUpdateCRMDepartmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,604,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,607,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,610,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Update Zoho CRM ZSC Key Authenticate",MODULE_NAME);
			checkZSCKeyAuthenticate(driver,api_webdriver,crmWebDriver,Constants.SUCCESS_CODE,613,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check get individual Zoho CRM integration",MODULE_NAME);
			checkGetCRMAPI(driver,api_webdriver,crmWebDriver,Constants.PERMISSION_ERROR_CODE,616,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check get Zoho CRM user details",MODULE_NAME);
			checkGetAppUserDetailsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,617,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check get Zoho CRM App field details",MODULE_NAME);
			checkGetAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,618,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check Update Zoho CRM details",MODULE_NAME);
			checkUpdateCRMAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,621,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check Update Zoho CRM Department",MODULE_NAME);
			checkUpdateCRMDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,622,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check Disable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,623,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check Enable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,624,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Supervisor -- Check Update Zoho CRM ZSC Key Authenticate",MODULE_NAME);
			checkZSCKeyAuthenticate(driver,api_webdriver,crmWebDriver,Constants.PERMISSION_ERROR_CODE,625,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check get individual Zoho CRM integration",MODULE_NAME);
			checkGetCRMAPI(driver,api_webdriver,crmWebDriver,Constants.PERMISSION_ERROR_CODE,626,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check get Zoho CRM user details",MODULE_NAME);
			checkGetAppUserDetailsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,627,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check get Zoho CRM App field details",MODULE_NAME);
			checkGetAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,628,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check Update Zoho CRM details",MODULE_NAME);
			checkUpdateCRMAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,631,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check Update Zoho CRM Department",MODULE_NAME);
			checkUpdateCRMDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,632,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check Disable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,633,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check Enable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,634,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM Associate -- Check Update Zoho CRM ZSC Key Authenticate",MODULE_NAME);
			checkZSCKeyAuthenticate(driver,api_webdriver,crmWebDriver,Constants.PERMISSION_ERROR_CODE,635,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check get individual Zoho CRM integration",MODULE_NAME);
			checkGetCRMAPI(driver,api_webdriver,crmWebDriver,Constants.INVALID_SCOPE_ERROR_CODE,636,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check get Zoho CRM user details",MODULE_NAME);
			checkGetAppUserDetailsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,637,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check get Zoho CRM App field details",MODULE_NAME);
			checkGetAppFieldsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,638,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check Update Zoho CRM details",MODULE_NAME);
			checkUpdateCRMAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,641,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check Update Zoho CRM Department",MODULE_NAME);
			checkUpdateCRMDepartmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,642,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check Disable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,643,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check Enable Zoho CRM",MODULE_NAME);
			checkEnableCRMAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,644,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("CRM invalid Scope -- Check Update Zoho CRM ZSC Key Authenticate",MODULE_NAME);
			checkZSCKeyAuthenticate(driver,api_webdriver,crmWebDriver,Constants.INVALID_SCOPE_ERROR_CODE,645,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);

			Functions.logout(crmWebDriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetCRMAPI(WebDriver driver,WebDriver api_webdriver,WebDriver crmWebDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,CRM,SALESFORCE,etest);
			if(response_code.equals(Constants.SUCCESS_CODE))
			{
				com.zoho.livedesk.client.CRM.ZSCKey.ZSCregenerate(driver,crmWebDriver,etest);
			}
			else
			{
				String zscKey = IntegrationRESTAPICommonFunctions.getCRMZSCKey(crmWebDriver);
				IntegrationRESTAPICommonFunctions.changeZSCKey(driver,zscKey);
			}

			Hashtable<String,String> info = getCRMInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_CRM_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetAppUserDetailsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> info = IntegrationRESTAPICommonFunctions.getValuesFromConf("RESTAPI596");
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_CRM_GET_USER,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetAppFieldsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String leadKey = "RESTAPI" + startKey;
			String contactKey = "RESTAPI" + (startKey+1);
			String dealKey = "RESTAPI" + (startKey+2);

			result.put(leadKey,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,RESOURCE_NAME,LEAD,Api.INTEG_CRM_APP_FIELDS,LEAD_APP_FIELDS_JSON,startKey,etest));
			result.put(contactKey,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,RESOURCE_NAME,CONTACT,Api.INTEG_CRM_APP_FIELDS,CONTACT_APP_FIELDS_JSON,(startKey+1),etest));
			result.put(dealKey,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,RESOURCE_NAME,DEAL,Api.INTEG_CRM_APP_FIELDS,DEAL_APP_FIELDS_JSON,(startKey+2),etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateCRMAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String
			lead_auto_approval = LEAD_AUTO_APPROVAL_VALUES[randomId%2],
			attach_transcript = ATTACH_TRANSCRIPT_VALUES[randomId%2],
			assigned_owner = ASSIGNED_OWNER_VALUES[0],
			minimum_leadscore = MINIMUM_LEADSCORE_VALUES[randomId%5],
			followup_task_on = FOLLOWUP_TASK_ON_VALUES[randomId%5],
			departments_selected = DEPARTMENTS_SELECTED_VALUES[1],
			visitors_to_be_pushed = VISITORS_TO_BE_PUSHED_VALUES[randomId%3],
			add_new_visitor_as = ADD_NEW_VISITOR_AS_VALUES[randomId%2],
			visitor_status_in_livedesk = VISITOR_STATUS_IN_LIVEDESK_VALUES[randomId%2],
			visitor_tracking = VISITOR_TRACKING_VALUES[0],
			visitor_tracking_visits = VISITOR_TRACKING_VALUES[1]
			;

			JSONObject payload = GetPayload.getUpdateCRMPayload(lead_auto_approval,attach_transcript,assigned_owner,minimum_leadscore,followup_task_on,departments_selected,visitors_to_be_pushed,add_new_visitor_as,visitor_status_in_livedesk,visitor_tracking,visitor_tracking_visits);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedCRMInfo(lead_auto_approval,attach_transcript,assigned_owner,minimum_leadscore,followup_task_on,departments_selected,visitors_to_be_pushed,add_new_visitor_as,visitor_status_in_livedesk,visitor_tracking);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CRM_UPDATE,payload,expectedInfo,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateCRMDepartmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);
			String enabled = ENABLE_VALUES[randomId%2];

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put("enabled",enabled);
			info.put("id",department_id);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,ID,department_id,Api.INTEG_CRM_DEPT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkEnableCRMAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CRM_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkZSCKeyAuthenticate(WebDriver driver,WebDriver api_webdriver,WebDriver crmWebDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String key = IntegrationRESTAPICommonFunctions.getCRMZSCKey(crmWebDriver);
			String email = ExecuteStatements.getUserMail(driver);

			JSONObject payload = GetPayload.getZSCKeyPayload(key,email,null);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ZSC_KEY,key);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CRM_KEY_AUTHENTICATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getCRMInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		try
		{
			CommonUtil.refreshPage(driver);
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,CRM);

			info.put(LEAD_AUTO_APPROVAL,IntegrationRESTAPICommonFunctions.getSelectedFromToggle(driver,REQAPPROVAL,SET_OFF));
			info.put(ATTACH_TRANSCRIPT,IntegrationRESTAPICommonFunctions.getSelectedFromToggle(driver,EXCUSPUSHCHATTRANS,SET_ON));
			info.put(ASSIGNED_OWNER,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,ASSIGNOWNER_DIV));
			info.put(MINIMUM_LEADSCORE,IntegrationRESTAPICommonFunctions.getValueFromInput(driver,VISLSCORETXT));
			info.put(FOLLOWUP_TASK_ON,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,NEWCUSADDTASK_DIV));
			info.put(DEPARTMENTS_SELECTED,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,CRMDEPTSEL,ALL_DEPARTMENTS,ALL,CUSTOM));
			info.put(VISITORS_TO_BE_PUSHED,"["+IntegrationRESTAPICommonFunctions.getSelectedFromCheckBox(driver,VISTYPECRMDIV)+"]");
			info.put(ADD_NEW_VISITOR_AS,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,CRMRADIO,LEAD_ID,LEAD,CONTACT));
			info.put(VISITOR_STATUS_IN_LIVEDESK,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,VSTATUSINLIVEDESK_DIV).replace("pushed","push"));
			info.put(VISITOR_TRACKING,"["+IntegrationRESTAPICommonFunctions.getSelectedFromCheckBox(driver,VISTRACKCRMDIV)+"]");
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));
			info.put(ZSC_KEY,IntegrationRESTAPICommonFunctions.getTextFromDiv(driver,ZSC_KEY_DIV));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
		}
		return info;
	}

	public static Hashtable<String,String> getExpectedCRMInfo(String lead_auto_approval,String attach_transcript,String assigned_owner,String minimum_leadscore,String followup_task_on,String departments_selected,String visitors_to_be_pushed,String add_new_visitor_as,String visitor_status_in_livedesk,String visitor_tracking)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		
		info.put(LEAD_AUTO_APPROVAL,lead_auto_approval);
		info.put(ATTACH_TRANSCRIPT,attach_transcript);
		info.put(ASSIGNED_OWNER,assigned_owner);
		info.put(MINIMUM_LEADSCORE,minimum_leadscore);
		info.put(FOLLOWUP_TASK_ON,followup_task_on.replaceAll("_",""));
		info.put(DEPARTMENTS_SELECTED,departments_selected);
		info.put(VISITORS_TO_BE_PUSHED,"[\""+visitors_to_be_pushed+"\"]");
		info.put(ADD_NEW_VISITOR_AS,add_new_visitor_as);
		info.put(VISITOR_STATUS_IN_LIVEDESK,visitor_status_in_livedesk.replaceAll("_",""));
		info.put(VISITOR_TRACKING,"[\""+visitor_tracking.replaceAll("_","")+"\"]");
		
		return info;
	}

}