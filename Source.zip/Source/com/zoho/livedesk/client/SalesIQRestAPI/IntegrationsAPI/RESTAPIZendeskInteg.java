//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPIZendeskInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static Hashtable<String,String> departmentInfo = null;
	public static ExtentTest etest;

	public static final String[]
	CONVERT_AS_REQUEST_VALUES = {"all","attended","missed","none"},
	ATTENDED_REQUEST_STATUS_VALUES = {"open","pending"},
	DEPARTMENTS_SELECTED_VALUES = {"all","custom"},
	STATUS_VALUES = {"choose_on_demand","no_integration","read_only","active"}
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	ZENDESK = "Zendesk",
	DESK = "Zoho Desk",
	PORTAL_NAME = "data_connected_account_portal_name",
	ATTENDED_REQUEST_STATUS = "data_general_config_attended_request_status",
	CONVERT_AS_REQUEST = "data_general_config_convert_as_request",
	DEPARTMENTS_SELECTED = "data_general_config_departments_selected",
	DEPARTMENT_STATUS = "data/departments",
	ENABLED = "data_enabled",
	ID = "<id>",
	ALL_DEPARTMENTS = "reqcriteria_all",
	ALL = "all",
	CUSTOM = "custom",
	STATUS = "status",
	PORTAL_NAME_TEXT = "Portal Name",
	DEPARTMENT_JSON = "integ_zendesk_department_appfields.json"
	;

	public static final By
	ATTEND_REQ_STATUS_DIV = By.id("attendreqstatus_div"),
	CONVERT_REQUEST_DIV = By.id("convertrequest_div"),
	DEPT_SELECTED = By.id("reqcriteriaradio"),
	PORTAL_NAME_DIV = By.id("emailidlabeldiv"),
	ZSUPPINTEGDIV = By.id("zsuppintegdiv"),
	INTEG_DETAILS = By.className("integ_dtl"),
	ZSC_REGENERATE = By.id("zsckeyeditlink"),
	DEPT_LIST = By.id("mapsupportdept")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();
            departmentInfo = new Hashtable<String,String>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api2");

			etest = ComplexReportFactory.getEtest("Check get individual Zendesk integration",MODULE_NAME);
			checkGetZendeskAPI(driver,api_webdriver,Constants.SUCCESS_CODE,771,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zendesk App fields",MODULE_NAME);
			checkGetZendeskFieldDetailsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,773,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zendesk Update config",MODULE_NAME);
			checkUpdateZendeskConfigAPI(driver,api_webdriver,Constants.SUCCESS_CODE,775,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zendesk Department Update",MODULE_NAME);
			checkUpdateZendeskDepartmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,778,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,781,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,784,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check get individual Zendesk integration",MODULE_NAME);
			checkGetZendeskAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,787,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Zendesk App fields",MODULE_NAME);
			checkGetZendeskFieldDetailsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,788,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Zendesk Update config",MODULE_NAME);
			checkUpdateZendeskConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,789,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Zendesk Department Update",MODULE_NAME);
			checkUpdateZendeskDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,790,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Disable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,791,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Enable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,792,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Check Associate -- Check get individual Zendesk integration",MODULE_NAME);
			checkGetZendeskAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,793,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Zendesk App fields",MODULE_NAME);
			checkGetZendeskFieldDetailsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,794,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Zendesk Update config",MODULE_NAME);
			checkUpdateZendeskConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,795,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Zendesk Department Update",MODULE_NAME);
			checkUpdateZendeskDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,796,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Disable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,797,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Enable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,798,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Zendesk integration",MODULE_NAME);
			checkGetZendeskAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,799,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zendesk App fields",MODULE_NAME);
			checkGetZendeskFieldDetailsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,800,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zendesk Update config",MODULE_NAME);
			checkUpdateZendeskConfigAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,801,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zendesk Department Update",MODULE_NAME);
			checkUpdateZendeskDepartmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,802,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,803,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Zendesk Integration",MODULE_NAME);
			checkEnableZendeskAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,804,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetZendeskAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,ZENDESK,DESK,etest);

			Hashtable<String,String> info = getInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_ZENDESK_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetZendeskFieldDetailsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String keys_use_case = "RESTAPI"+startKey;
			result.put(keys_use_case,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,false,"","",Api.INTEG_ZENDESK_APP_FIELDS,DEPARTMENT_JSON,startKey,etest));
			if(response_code == Constants.SUCCESS_CODE)
			{
				setDeskDepartmentInfo(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateZendeskConfigAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String
			portal_name = ExecuteStatements.getPortal(driver),
			convert_as_request = CONVERT_AS_REQUEST_VALUES[randomId%4],
			attended_request_status = ATTENDED_REQUEST_STATUS_VALUES[randomId%2],
			departments_selected = DEPARTMENTS_SELECTED_VALUES[1]
			;

			JSONObject payload = GetPayload.getUpdateDeskPayload(convert_as_request,null,attended_request_status,departments_selected);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = RESTAPIDeskInteg.getExpectedDeskInfo(convert_as_request,null,attended_request_status,departments_selected);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_ZENDESK_UPDATE,payload,expectedInfo,startKey));

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateZendeskDepartmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String integration_department_id = null;
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);
			String status = STATUS_VALUES[randomId%4];

			if(status.equals("active"))
			{
				integration_department_id = departmentInfo.get("id"+(randomId%2));
			}

			JSONObject payload = GetPayload.getDepartmentIntegrationPayload(status,integration_department_id);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			if(status.equals("active"))
			{
				status = departmentInfo.get("name"+(randomId%2));
			}

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put("status",status);
			info.put("id",department_id);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,ID,department_id,Api.INTEG_ZENDESK_DEPT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkEnableZendeskAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_ZENDESK_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);

			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,ZENDESK);

			String portal_name_in_ui = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,ZSUPPINTEGDIV).findElements(INTEG_DETAILS),"innerText",PORTAL_NAME_TEXT),PORTAL_NAME_DIV).getText();

			info.put(PORTAL_NAME,portal_name_in_ui);
			info.put(CONVERT_AS_REQUEST,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,CONVERT_REQUEST_DIV));
			info.put(ATTENDED_REQUEST_STATUS,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,ATTEND_REQ_STATUS_DIV));
			info.put(DEPARTMENTS_SELECTED,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,DEPT_SELECTED,ALL_DEPARTMENTS,ALL,CUSTOM));
			info.put(DEPARTMENT_STATUS,IntegrationRESTAPICommonFunctions.getDepartmentStatus(driver,DEPT_LIST,department_id).get(STATUS));
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
		}

		return info;
	}

	public static void setDeskDepartmentInfo(WebDriver api_webdriver,ExtentTest etest)
	{
		try
		{
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
	    	
	    	JSONArray json_array = json_response.getJSONArray("data");
	    	
	    	for(int i = 0; i < json_array.length(); i++)
	    	{
	    		String name = json_array.getJSONObject(i).getString("placeholder");
	    		String id = json_array.getJSONObject(i).getString("id");
	    		departmentInfo.put("name"+i, name);
	    		departmentInfo.put("id"+i, id);
	    	}
	    }
	    catch(Exception e)
	    {
	    	TakeScreenshot.screenshot(api_webdriver,etest,e);
	    }
	}
}