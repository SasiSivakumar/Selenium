//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

public class RESTAPIClearbitEnrichmentInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[][]
	FIELD_ID = {{"phone","description","state","city","country"},{"phone","description","state","city","country"}},
	INTEGRATION_FIELD_ID = {{"Phone","Description","State","City","Country"},{"Phone","Description","Mailing State","Other City","Mailing Country"}},
	INTEGRATION_FIELD_NAME = {{"Phone","Description","State","City","Country"},{"Phone","Description","Mailing State","Other City","Mailing Country"}}
	;

	public static final String[]
	UPDATE_TO_CRM_VALUES = {"true","false"},
	ADD_COMPANY_PARTICULARS_AS_VALUES = {"Lead","Contact"},
	REFRESH_FREQUENCY_VALUES = {"weekly","every_30_days","every_90_days"},
	FIELD_STATUS = {"enabled","disabled"},
	ENABLE_VALUES = {"true","false"}
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	CLEARBITENRICHMENT = "Clearbit (Enrichment)",
	CRM = "Zoho CRM",
	SALESFORCE = "Salesforce",
	ENABLED = "data_enabled",
	KEY = "data_connected_account_key",
	REFRESH_FREQUENCY = "data_general_config_refresh_frequency",
	ADD_COMPANY_PARTICULARS_AS = "data_general_config_add_company_particulars_as",
	UPDATE_TO_CRM = "data_general_config_update_to_crm",
	FIELDS = "data_fields",
	NAME = "data_name",
	CLEARBITENRICHMENT_NAME = "clearbitenrichment",
	SET_ON = "set_on",
	CLEARBITENRICHMENT_ID = "clearbitenrichment_"
	;

	public static final By
	CB_API_TOKEN = By.id("cbapitoken"),
	UPDATE_TO_CRM_DIV = By.id("pushclearbitenrichmentinfo"),
	CRMCLEARBITDROPDOWN = By.id("crmtypelist"),
	CRMTYPELIST_DIV = By.id("crmtypelist_div"),
	CRMTYPELIST_DDOWN = By.id("crmtypelist_ddown"),
	UL_LIST = By.className("ullist"),
	TEXT = By.className("txtelips"),
	CBIT_DROPDOWN = By.id("cbitdropdown_div"),
	CONFIGTABLE = By.id("clearbitenrichmentconfigtable"),
	LIST_ROW = By.className("list-row")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api1");

			etest = ComplexReportFactory.getEtest("Check get individual Clearbit Enrichment integration",MODULE_NAME);
			checkGetCBEnrichmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,902,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check update Clearbit Enrichment integration",MODULE_NAME);
			checkUpdateCBEnrichmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,904,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,907,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,910,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check get individual Clearbit Enrichment integration",MODULE_NAME);
			checkGetCBEnrichmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,913,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check update Clearbit Enrichment integration",MODULE_NAME);
			checkUpdateCBEnrichmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,914,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check Disable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,915,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check Enable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,916,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Check Associate -- Check get individual Clearbit Enrichment integration",MODULE_NAME);
			checkGetCBEnrichmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,917,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check update Clearbit Enrichment integration",MODULE_NAME);
			checkUpdateCBEnrichmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,918,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Disable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,919,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Enable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,920,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Clearbit Enrichment integration",MODULE_NAME);
			checkGetCBEnrichmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,921,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check update Clearbit Enrichment integration",MODULE_NAME);
			checkUpdateCBEnrichmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,922,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,923,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Clearbit Enrichment Integration",MODULE_NAME);
			checkEnableCBEnrichmentAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,924,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetCBEnrichmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,CRM,SALESFORCE,etest);

			Hashtable<String,String> info = getInfoFromUI(driver,startKey);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_CB_ENRICHMENT_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateCBEnrichmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,CLEARBITENRICHMENT,etest);

			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String add_company_particulars_as = ADD_COMPANY_PARTICULARS_AS_VALUES[randomId%2];
			selectCRMType(driver,add_company_particulars_as);
			String previous_field_id = getPreviousFieldId(driver);
			String field_id = FIELD_ID[randomId%2][randomId%5];

			CommonUtil.print("\n\n\n>>>>previous_field_id"+previous_field_id+"\n\n\n");

			if(previous_field_id.contains(field_id))
			{
				randomId++;
			}

			add_company_particulars_as = ADD_COMPANY_PARTICULARS_AS_VALUES[randomId%2];
			selectCRMType(driver,add_company_particulars_as);
			previous_field_id = getPreviousFieldId(driver);
			field_id = FIELD_ID[randomId%2][randomId%5];

			String
			integration_field_id = INTEGRATION_FIELD_ID[randomId%2][randomId%5],
			integration_field_name = INTEGRATION_FIELD_NAME[randomId%2][randomId%5],
			field_status = FIELD_STATUS[randomId%2],
			update_to_crm = UPDATE_TO_CRM_VALUES[0],
			refresh_frequency = REFRESH_FREQUENCY_VALUES[randomId%2]
			;

			add_company_particulars_as = add_company_particulars_as.toLowerCase();

			JSONObject payload = GetPayload.getUpdateClearBitPayload(field_id,integration_field_id,field_status,previous_field_id,add_company_particulars_as,refresh_frequency,update_to_crm);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedInfo(field_id,integration_field_name,previous_field_id,field_status,update_to_crm,add_company_particulars_as,refresh_frequency);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CB_ENRICHMENT_UPDATE,payload,expectedInfo,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkEnableCBEnrichmentAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CB_ENRICHMENT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getInfoFromUI(WebDriver driver,int startKey)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			CommonUtil.refreshPage(driver);
			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,CLEARBITENRICHMENT);
			info.put(NAME,CLEARBITENRICHMENT_NAME);
			info.put(KEY,IntegrationRESTAPICommonFunctions.getValueFromInput(driver,CB_API_TOKEN));
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));
			info.put(UPDATE_TO_CRM,IntegrationRESTAPICommonFunctions.getSelectedFromToggle(driver,UPDATE_TO_CRM_DIV,SET_ON));
			info.put(ADD_COMPANY_PARTICULARS_AS,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,CRMCLEARBITDROPDOWN));
			info.put(REFRESH_FREQUENCY,IntegrationRESTAPICommonFunctions.getTextFromDiv(driver,CBIT_DROPDOWN).toLowerCase().replaceAll(" ",""));

			if(startKey == 909)
			{
				return info;
			}

			selectCRMType(driver,"Lead");
			String leadFieldDetails = RESTAPICampaignInteg.getFieldDetails(driver,CLEARBITENRICHMENT_ID);

			selectCRMType(driver,"Contact");
			String contactFieldDetails = RESTAPICampaignInteg.getFieldDetails(driver,CLEARBITENRICHMENT_ID);

			JSONObject fieldDetails = new JSONObject();

			fieldDetails.put("lead",leadFieldDetails);
			fieldDetails.put("contact",contactFieldDetails);
			
			info.put(FIELDS,fieldDetails.toString());

			CommonUtil.print("\n\n\n\n\nInfo>>>>>>>>>>>"+info+"\n\n\n");
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}

		return info;
	}

	public static Hashtable<String,String> getExpectedInfo(String field_id,String integration_field_name,String previous_field_id,String field_status,String update_to_crm,String add_company_particulars_as,String refresh_frequency) throws Exception
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		JSONObject fieldDetails = new JSONObject();
		fieldDetails.put(field_id,integration_field_name+"_"+field_status);
		fieldDetails.put(previous_field_id,integration_field_name+"_deleted");

		JSONObject expectedFieldDetails = new JSONObject();

		expectedFieldDetails.put(add_company_particulars_as,fieldDetails.toString());

		info.put(NAME,CLEARBITENRICHMENT_NAME);
		info.put(UPDATE_TO_CRM,update_to_crm);
		info.put(ADD_COMPANY_PARTICULARS_AS,add_company_particulars_as);
		info.put(REFRESH_FREQUENCY,refresh_frequency.replace("_",""));
		info.put(FIELDS,expectedFieldDetails.toString());

		CommonUtil.print("\n\n\n\n\nExpectedInfo>>>>>>>>>>>"+info+"\n\n\n");

		return info;
	}

	public static void selectCRMType(WebDriver driver,String crmType) throws Exception
	{
		CommonUtil.clickWebElement(driver,CRMCLEARBITDROPDOWN,CRMTYPELIST_DIV,TEXT);
		CommonWait.waitTillDisplayed(driver,CRMCLEARBITDROPDOWN,CRMTYPELIST_DDOWN);
		List<WebElement> crmTypeList = CommonUtil.getElement(driver,CRMCLEARBITDROPDOWN,CRMTYPELIST_DDOWN,UL_LIST).findElements(By.tagName("li"));
		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(crmTypeList,"innerText",crmType));
		CommonWait.waitTillHidden(driver,CRMCLEARBITDROPDOWN,CRMTYPELIST_DDOWN);
	}

	public static String getPreviousFieldId(WebDriver driver) throws Exception
	{
		List<WebElement> fieldList = CommonUtil.getElement(driver,CONFIGTABLE).findElements(LIST_ROW);
		String previous_field_id = CommonUtil.getElement(fieldList.get(2),By.id(CLEARBITENRICHMENT_ID+"col1_2")).getAttribute("innerText").toLowerCase().trim().replaceAll(" ","").replaceAll("companyname","legalName");

		return previous_field_id;
	}
}