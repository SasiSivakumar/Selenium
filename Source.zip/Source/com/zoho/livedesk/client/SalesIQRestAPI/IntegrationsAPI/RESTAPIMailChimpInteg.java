//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPIMailChimpInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[]
	ENABLE_VALUES = {"true","false"},
	DEPARTMENTS_SELECTED_VALUES = {"all","custom"}
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	CAMPAIGN = "Zoho Campaigns",
	MAILCHIMP = "MailChimp",
	APP_FIELDS_REPLACE = "<appfields_resource>",
	ID = "<id>",
	CAMPAIGNSCONTENT = "campaignscontent/",
	APPFIELDS = "appfields/",
	APPVALUES = "appvalues/",
	CONTACT = "contact/",
	LISTFIELDS = "listfields/",
	LIST = "list",
	LIST_APP_FIELDS_JSON = "integ_mailchimp_list_appfields.json",
	CAMPAIGNSCONTENT_APP_FIELDS_JSON = "integ_mailchimp_campaignscontent_appfields.json",
	CONTACT_APP_FIELDS_JSON = "integ_mailchimp_contact_appfields.json",
	LISTFIELDS_APP_FIELDS_JSON = "integ_mailchimp_listfields_appfields.json",
	EMAIL_LABEL = "MailChimp Email Address",
	ALL = "all",
	CUSTOM = "custom",
	ALL_DEPARTMENTS = "alldept",
	OWNER_EMAIL = "data_owner_email",
	DEPARTMENTS_SELECTED = "data_general_config_departments_selected",
	ENABLED = "data_enabled"
	;

	public static final By
	DEPT_SELECTED = By.id("crmdeptsel"),
	DISABLECONTAINER = By.id("disablecontainer"),
	INTEG_DETAILS = By.className("integ_dtl"),
	PORTAL_NAME_DIV = By.id("emailidlabeldiv")
	;


	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api3");

			etest = ComplexReportFactory.getEtest("Check get individual Mailchimp Campaign integration",MODULE_NAME);
			checkGetMailChimpCampaignAPI(driver,api_webdriver,Constants.SUCCESS_CODE,805,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Mailchimp Campaign get App fields",MODULE_NAME);
			checkGetMailChimpCampaignAppFieldsAPI(driver,api_webdriver,Constants.SUCCESS_CODE,807,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Mailchimp Campaign update configurations",MODULE_NAME);
			checkMailChimpCampaignUpdateConfigAPI(driver,api_webdriver,Constants.SUCCESS_CODE,811,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Mailchimp Campaign update department configuration",MODULE_NAME);
			checkMailChimpCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.SUCCESS_CODE,814,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,817,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,820,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check get individual Mailchimp Campaign integration",MODULE_NAME);
			checkGetMailChimpCampaignAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,823,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Mailchimp Campaign get App fields",MODULE_NAME);
			checkGetMailChimpCampaignAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,824,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Mailchimp Campaign update configurations",MODULE_NAME);
			checkMailChimpCampaignUpdateConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,828,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Mailchimp Campaign update department configuration",MODULE_NAME);
			checkMailChimpCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,829,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Disable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,830,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Supervisor -- Check Enable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,831,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Check associate -- Check get individual Mailchimp Campaign integration",MODULE_NAME);
			checkGetMailChimpCampaignAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,832,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check associate -- Check Mailchimp Campaign get App fields",MODULE_NAME);
			checkGetMailChimpCampaignAppFieldsAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,833,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check associate -- Check Mailchimp Campaign update configurations",MODULE_NAME);
			checkMailChimpCampaignUpdateConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,837,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check associate -- Check Mailchimp Campaign update department configuration",MODULE_NAME);
			checkMailChimpCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,838,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check associate -- Check Disable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,839,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check associate -- Check Enable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,840,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Mailchimp Campaign integration",MODULE_NAME);
			checkGetMailChimpCampaignAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,841,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Mailchimp Campaign get App fields",MODULE_NAME);
			checkGetMailChimpCampaignAppFieldsAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,842,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Mailchimp Campaign update configurations",MODULE_NAME);
			checkMailChimpCampaignUpdateConfigAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,846,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Mailchimp Campaign update department configuration",MODULE_NAME);
			checkMailChimpCampaignUpdateDepartmentAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,847,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,848,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Mailchimp Campaign integration",MODULE_NAME);
			checkMailChimpCampaignEnableAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,849,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetMailChimpCampaignAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,MAILCHIMP,CAMPAIGN,etest);

			Hashtable<String,String> info = getInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_MAILCHIMP_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetMailChimpCampaignAppFieldsAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String id = "e5cde1e3b6";

			String use_case_key = "RESTAPI"+startKey;

			String replaceWith = APPFIELDS + LIST;			
			result.put(use_case_key,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,APP_FIELDS_REPLACE,replaceWith,Api.INTEG_MAILCHIMP_APP_FIELDS,LIST_APP_FIELDS_JSON,startKey,etest));

			if(response_code == Constants.SUCCESS_CODE)
			{
				id = getListId(api_webdriver,etest);
			}
			use_case_key = "RESTAPI"+(startKey+1);
			replaceWith = APPVALUES + CAMPAIGNSCONTENT + id;
			result.put(use_case_key,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,APP_FIELDS_REPLACE,replaceWith,Api.INTEG_MAILCHIMP_APP_FIELDS,CAMPAIGNSCONTENT_APP_FIELDS_JSON,startKey,etest));

			use_case_key = "RESTAPI"+(startKey+2);
			replaceWith = APPFIELDS + CONTACT + id;
			result.put(use_case_key,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,APP_FIELDS_REPLACE,replaceWith,Api.INTEG_MAILCHIMP_APP_FIELDS,CONTACT_APP_FIELDS_JSON,startKey,etest));

			use_case_key = "RESTAPI"+(startKey+3);
			replaceWith = APPFIELDS + LISTFIELDS + id;
			result.put(use_case_key,IntegrationRESTAPICommonFunctions.checkAppFieldsApi(api_webdriver,driver,response_code,true,APP_FIELDS_REPLACE,replaceWith,Api.INTEG_MAILCHIMP_APP_FIELDS,LISTFIELDS_APP_FIELDS_JSON,startKey,etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	public static void checkMailChimpCampaignUpdateConfigAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String departments_selected = DEPARTMENTS_SELECTED_VALUES[1];

			JSONObject payload = GetPayload.getUpdateCampaignPayload(departments_selected,null,null,null,null);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = new Hashtable<String,String>();
			expectedInfo.put(DEPARTMENTS_SELECTED,departments_selected);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_MAILCHIMP_UPDATE,payload,expectedInfo,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkMailChimpCampaignUpdateDepartmentAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);
			String enabled = ENABLE_VALUES[randomId%2];

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put("enabled",enabled);
			info.put("id",department_id);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,ID,department_id,Api.INTEG_MAILCHIMP_DEPT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	
	public static void checkMailChimpCampaignEnableAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_MAILCHIMP_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		try
		{
			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,MAILCHIMP);

			String owner_email = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,DISABLECONTAINER).findElements(INTEG_DETAILS),"innerText",EMAIL_LABEL),PORTAL_NAME_DIV).getText().replaceAll("_","");

			info.put(OWNER_EMAIL,owner_email);
			info.put(DEPARTMENTS_SELECTED,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,DEPT_SELECTED,ALL_DEPARTMENTS,ALL,CUSTOM));
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			TakeScreenshot.screenshot(driver,etest,e);
		}
		return info;
	}

	public static String getListId(WebDriver api_webdriver,ExtentTest etest)
	{
		String id = "e5cde1e3b6";
		try
		{
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
	    	
	    	JSONArray json_array = json_response.getJSONArray("data");
	    	
	    	for(int i = 0; i < json_array.length(); i++)
	    	{
	    		String name = json_array.getJSONObject(i).getString("placeholder");
	    		if(name.contains("others"))
	    		{
	    			id = json_array.getJSONObject(i).getString("id");
	    		}
	    	}
	    }
	    catch(Exception e)
	    {
	    	TakeScreenshot.screenshot(api_webdriver,etest,e);
	    }
	    return id;
	}
}
