//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class RESTAPIDeskInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[]
	CONVERT_AS_REQUEST_VALUES = {"all","attended","missed","none"},
	PUSH_VISITOR_FEEDBACK_VALUES = {"true","false"},
	ATTENDED_REQUEST_STATUS_VALUES = {"open","closed"},
	DEPARTMENTS_SELECTED_VALUES = {"all","custom"},
	STATUS_VALUES = {"choose_on_demand","no_integration","read_only","active"}
	;

	public static final String 
	MODULE_NAME = "Integration RESTAPI",
	DESK = "Zoho Desk",
	ZENDESK = "Zendesk",
	ZSC_KEY = "data_connected_account_key",
	PORTAL_NAME = "data_connected_account_portal_name",
	PUSH_VISITOR_FEEDBACK = "data_general_config_push_visitor_feedback",
	ATTENDED_REQUEST_STATUS = "data_general_config_attended_request_status",
	CONVERT_AS_REQUEST = "data_general_config_convert_as_request",
	DEPARTMENTS_SELECTED = "data_general_config_departments_selected",
	PUSH_CALLLOG = "data_general_config_push_calllog",
	ENABLED = "data_enabled",
	DEPARTMENT_STATUS = "data/departments",
	ID = "<id>",
	SET_ON = "set_on",
	ALL_DEPARTMENTS = "reqcriteria_all",
	ALL = "all",
	CUSTOM = "custom",
	STATUS = "status",
	PORTAL_NAME_TEXT = "Portal Name"
	;

	public static final By
	ZSC_KEY_DIV = By.id("zsckeylabeldiv"),
	PUSH_FEEDBACK = By.id("pushfeedback"),
	ATTEND_REQ_STATUS_DIV = By.id("attendreqstatus_div"),
	CONVERT_REQUEST_DIV = By.id("convertrequest_div"),
	DEPT_SELECTED = By.id("reqcriteriaradio"),
	PORTAL_NAME_DIV = By.id("emailidlabeldiv"),
	DEPT_LIST = By.id("mapsupportdept"),
	ACTIVE_DEPARTMENTS_LIST = By.id("activeDepartmentsList"),
	DEPT_DIV = By.className("zs-deptrow "),
	ZSUPPINTEGDIV = By.id("zsuppintegdiv"),
	INTEG_DETAILS = By.className("integ_dtl"),
	ZSC_REGENERATE = By.id("zsckeyeditlink")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

            WebDriver zohoDeskDriver = Functions.setUp();
            Functions.loginZohoDesk(zohoDeskDriver,"integration_restapi2");

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api2");

			etest = ComplexReportFactory.getEtest("Check get individual Zoho Desk integration",MODULE_NAME);
			checkGetDeskAPI(driver,api_webdriver,zohoDeskDriver,Constants.SUCCESS_CODE,646,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Desk App fields",MODULE_NAME);
			checkGetDeskFieldDetailsAPI(driver,api_webdriver,zohoDeskDriver,Constants.SUCCESS_CODE,648,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Desk Update config",MODULE_NAME);
			checkUpdateZohoDeskConfigAPI(driver,api_webdriver,Constants.SUCCESS_CODE,650,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Desk Department Update",MODULE_NAME);
			checkUpdateZohoDeskDepartmentAPI(driver,api_webdriver,zohoDeskDriver,Constants.SUCCESS_CODE,653,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,656,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,659,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Zoho Desk ZSC Key Authenticate",MODULE_NAME);
			checkDeskZSCKeyAuthenticateAPI(driver,api_webdriver,zohoDeskDriver,Constants.SUCCESS_CODE,662,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check get individual Zoho Desk integration",MODULE_NAME);
			checkGetDeskAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,665,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check Zoho Desk App fields",MODULE_NAME);
			checkGetDeskFieldDetailsAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,666,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check Zoho Desk Update config",MODULE_NAME);
			checkUpdateZohoDeskConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,667,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check Zoho Desk Department Update",MODULE_NAME);
			checkUpdateZohoDeskDepartmentAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,668,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check Disable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,669,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check Enable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,670,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Supervisor -- Check Zoho Desk ZSC Key Authenticate",MODULE_NAME);
			checkDeskZSCKeyAuthenticateAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,671,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check get individual Zoho Desk integration",MODULE_NAME);
			checkGetDeskAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,672,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check Zoho Desk App fields",MODULE_NAME);
			checkGetDeskFieldDetailsAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,673,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check Zoho Desk Update config",MODULE_NAME);
			checkUpdateZohoDeskConfigAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,674,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check Zoho Desk Department Update",MODULE_NAME);
			checkUpdateZohoDeskDepartmentAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,675,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check Disable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,676,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check Enable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,677,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("ZohoDesk Associate -- Check Zoho Desk ZSC Key Authenticate",MODULE_NAME);
			checkDeskZSCKeyAuthenticateAPI(driver,api_webdriver,zohoDeskDriver,Constants.PERMISSION_ERROR_CODE,678,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Zoho Desk integration",MODULE_NAME);
			checkGetDeskAPI(driver,api_webdriver,zohoDeskDriver,Constants.INVALID_SCOPE_ERROR_CODE,679,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Desk App fields",MODULE_NAME);
			checkGetDeskFieldDetailsAPI(driver,api_webdriver,zohoDeskDriver,Constants.INVALID_SCOPE_ERROR_CODE,680,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Desk Update config",MODULE_NAME);
			checkUpdateZohoDeskConfigAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,681,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Desk Department Update",MODULE_NAME);
			checkUpdateZohoDeskDepartmentAPI(driver,api_webdriver,zohoDeskDriver,Constants.INVALID_SCOPE_ERROR_CODE,682,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,683,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Zoho Desk",MODULE_NAME);
			checkEnableDeskAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,684,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Zoho Desk ZSC Key Authenticate",MODULE_NAME);
			checkDeskZSCKeyAuthenticateAPI(driver,api_webdriver,zohoDeskDriver,Constants.INVALID_SCOPE_ERROR_CODE,685,etest);
			ComplexReportFactory.closeTest(etest);

			Functions.logout(zohoDeskDriver);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetDeskAPI(WebDriver driver,WebDriver api_webdriver,WebDriver zohoDeskDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,DESK,ZENDESK,etest);

			String zscKey = IntegrationRESTAPICommonFunctions.getDeskZSCKey(zohoDeskDriver);
			IntegrationRESTAPICommonFunctions.changeZSCKey(driver,zscKey);


			Hashtable<String,String> info = getDeskInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_DESK_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkGetDeskFieldDetailsAPI(WebDriver driver,WebDriver api_webdriver,WebDriver zohoDeskDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> info = getDeskDepartmentInfo(zohoDeskDriver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_DESK_APP_FIELDS,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateZohoDeskConfigAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String
			portal_name = ExecuteStatements.getPortal(driver),
			convert_as_request = CONVERT_AS_REQUEST_VALUES[randomId%4],
			push_visitor_feedback = PUSH_VISITOR_FEEDBACK_VALUES[randomId%2],
			attended_request_status = ATTENDED_REQUEST_STATUS_VALUES[randomId%2],
			departments_selected = DEPARTMENTS_SELECTED_VALUES[1]
			;

			JSONObject payload = GetPayload.getUpdateDeskPayload(convert_as_request,push_visitor_feedback,attended_request_status,departments_selected);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedDeskInfo(convert_as_request,push_visitor_feedback,attended_request_status,departments_selected);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_DESK_UPDATE,payload,expectedInfo,startKey));

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateZohoDeskDepartmentAPI(WebDriver driver,WebDriver api_webdriver,WebDriver zohoDeskDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			Hashtable<String,String> departmentInfo = new Hashtable<String,String>();
			String integration_department_id = null;
			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);
			String status = STATUS_VALUES[randomId%4];

			if(response_code != Constants.SUCCESS_CODE)
			{
				status = "no_integration";
			}
			else if(status.equals("active"))
			{
				departmentInfo = getDeskDepartmentInfo(zohoDeskDriver);
				integration_department_id = departmentInfo.get("id"+(randomId%2));
			}

			JSONObject payload = GetPayload.getDepartmentIntegrationPayload(status,integration_department_id);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			if(status.equals("active"))
			{
				status = departmentInfo.get("name"+(randomId%2));
			}

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put("status",status);
			info.put("id",department_id);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,true,ID,department_id,Api.INTEG_DESK_DEPT_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkDeskZSCKeyAuthenticateAPI(WebDriver driver,WebDriver api_webdriver,WebDriver zohoDeskDriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String
			key = IntegrationRESTAPICommonFunctions.getDeskZSCKey(zohoDeskDriver),
			email = ExecuteStatements.getUserMail(driver),
			portal_name = ExecuteStatements.getPortal(driver)
			;

			JSONObject payload = GetPayload.getZSCKeyPayload(key,email,portal_name);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ZSC_KEY,key);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_DESK_KEY_AUTHENTICATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			TakeScreenshot.screenshot(zohoDeskDriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkEnableDeskAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_DESK_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getDeskInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			String department = ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id = ExecuteStatements.getDepartmentID(driver,department);

			CommonUtil.refreshPage(driver);
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,DESK);

			String portal_name_in_ui = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,ZSUPPINTEGDIV).findElements(INTEG_DETAILS),"innerText",PORTAL_NAME_TEXT),PORTAL_NAME_DIV).getText();

			info.put(ZSC_KEY,IntegrationRESTAPICommonFunctions.getTextFromDiv(driver,ZSC_KEY_DIV));
			info.put(PORTAL_NAME,portal_name_in_ui);
			info.put(CONVERT_AS_REQUEST,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,CONVERT_REQUEST_DIV));
			info.put(PUSH_VISITOR_FEEDBACK,IntegrationRESTAPICommonFunctions.getSelectedFromToggle(driver,PUSH_FEEDBACK,SET_ON));
			info.put(ATTENDED_REQUEST_STATUS,IntegrationRESTAPICommonFunctions.getSelectedFromDropdown(driver,ATTEND_REQ_STATUS_DIV));
			info.put(DEPARTMENTS_SELECTED,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,DEPT_SELECTED,ALL_DEPARTMENTS,ALL,CUSTOM));
			info.put(DEPARTMENT_STATUS,IntegrationRESTAPICommonFunctions.getDepartmentStatus(driver,DEPT_LIST,department_id).get(STATUS));
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
		}

		return info;
	}

	public static Hashtable<String,String> getDeskDepartmentInfo(WebDriver zohoDeskDriver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			String current_url = zohoDeskDriver.getCurrentUrl();
			String deptUrl = current_url.substring(0,current_url.indexOf("#"))+"#setup/general/departments";
			// String deptUrl = "https://desk.localzoho.com/support/integrationsapi2/ShowHomePage.do#setup/general/departments";
			zohoDeskDriver.get(deptUrl);

			CommonWait.waitTillDisplayed(zohoDeskDriver,ACTIVE_DEPARTMENTS_LIST);
			List<WebElement> deptList = CommonUtil.getElement(zohoDeskDriver,ACTIVE_DEPARTMENTS_LIST).findElements(DEPT_DIV);

			for(int i = 0; i < deptList.size();i++)
			{
				zohoDeskDriver.get(deptUrl);
				CommonUtil.refreshPage(zohoDeskDriver);
				CommonWait.waitTillDisplayed(zohoDeskDriver,ACTIVE_DEPARTMENTS_LIST);
				deptList = CommonUtil.getElement(zohoDeskDriver,ACTIVE_DEPARTMENTS_LIST).findElements(DEPT_DIV);

				String deptName = CommonUtil.getElement(deptList.get(i),By.tagName("a")).getText();
				CommonUtil.clickWebElement(zohoDeskDriver,CommonUtil.getElement(deptList.get(i),By.tagName("a")));

				String currentUrl = zohoDeskDriver.getCurrentUrl();
				String deptId = currentUrl.substring(deptUrl.length()+1);

				info.put("name"+i,deptName);
				info.put("id"+i,deptId);
				zohoDeskDriver.get(deptUrl);
				CommonUtil.refreshPage(zohoDeskDriver);
			}

		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}

		return info;
	}

	public static Hashtable<String,String> getExpectedDeskInfo(String convert_as_request,String push_visitor_feedback,String attended_request_status,String departments_selected)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		info.put(CONVERT_AS_REQUEST,convert_as_request);
		if(push_visitor_feedback != null)
		{
			info.put(PUSH_VISITOR_FEEDBACK,push_visitor_feedback);
		}
		info.put(ATTENDED_REQUEST_STATUS,attended_request_status);
		info.put(DEPARTMENTS_SELECTED,departments_selected);

		return info;
	}
}