//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.Set;
import java.util.List;
import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class IntegrationRESTAPICommonFunctions
{
	public static final By
	UPRDOWRAP = By.className("uprdowrap"),
	CHCKBXMN = By.className("chckbxmn"),
	RIGHTINTEGBTN = By.id("rightintegbtn"),
	SETUPINNERLINKS = By.id("setupInnerLinks"),
	ZSC_CSS_SELECTOR = By.cssSelector("a[href*='zsc']"),
	SHOW_API_KEY = By.id("showAPIKey"),
	REGENERATE_BUTTON = By.id("regenBtn"),
	GENERATE_API_KEY = By.cssSelector("input[onclick*='genAPIKey']"),
	ACTIONMN = By.className("actionmn"),
	ACTIONMN_LEFT = By.className("actionmn-lft"),
	ACTIONMN_RIGHT = By.className("myprfdtlmn_rht"),
	DESK_ZSC_KEY_CONTAINER = By.id("ZSC_Key_container"),
	DESK_ZSC_KEY_REGENERATE_BUTTON = By.className("SLAlink"),
	DESK_ZSC_KEY = By.xpath("//*[@id='ZSC_Key_container']//span[contains(@class,'emailclr')]"),
	DESKPOPUP = By.id("deskpopup"),
	DESK_POPUP_OK = By.id("back-url"),
	CAMPAIGNS_INNER_CONTAINER = By.id("campaignInnerContents"),
	CAMPAIGNS_ZSC_KEY = By.id("zsc"),
	CAMPAIGNS_ZSC_KEY_REGENERATE_BUTTON = By.id("showbox"),
	CAMPAIGNS_ZSC_KEY_ALERT = By.id("zsckeyAlert"),
	CAMPAIGNS_ZSC_KEY_ALERT_CONFIRM = By.id("regenerateKey"),
	CHANGE_ZSC_KEY = By.xpath("//*[@purpose='changeowner']"),
	CHANGE_CRM_ZSC_KEY = By.xpath("//*[@id='emailideditlink']/a"),
	ZSC_KEY_CHANGE_DIV = By.id("zsckey"),
	ASSIGNED_OWNER = By.id("assignowner_div")
	;

	public static final String
	CRM = "Zoho CRM",
	SALESFORCE = "Salesforce",
	CAMPAIGN = "Zoho Campaigns",
	MAILCHIMP = "MailChimp",
	GOOGLE_ANALYTICS = "Google Analytics",
	CHCKBXSEL = "chckbxsel",
	RADIO_SELECTED = "rdselected",
	DISABLE = "Disable"
	;

	public static Hashtable<String,Boolean> checkAPI(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,boolean toCheckInUI,String response_code,boolean isReplace,String replaceString,String replaceWith,Api api_obj,JSONObject payload,Hashtable<String,String> expectedIntegInfo,int startKey) throws Exception
	{
		boolean isPayload = (payload != null);
		boolean isResponse = (response_code == Constants.SUCCESS_CODE)?true:false;
		boolean isEnableType = true;

		if(api_obj.get().contains("desk"))
		{
			isEnableType = false;
		}

		Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
		Hashtable<String,String> integInfoFromUI = new Hashtable<String,String>();
		try
		{
			String
			keys_check_usecase = "RESTAPI" + startKey,
			api_values_usecase = "RESTAPI" + (++startKey),
			ui_values_usecase = "RESTAPI" + (++startKey)
			;

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,replaceString,replaceWith,api_obj,isPayload,payload,etest);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(isResponse)
			{
				try
				{
					result.put(keys_check_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED KEYS ARE FOUND</b>");
					result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys));
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}

				try
				{
					result.put(api_values_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN API RESPONSE</b>");
					if(api_obj == Api.INTEG_DESK_APP_FIELDS)
					{
						result.put(api_values_usecase,checkExpectedDataPresentInResponse(expectedIntegInfo,response,etest));
					}
					else if(api_obj.get().contains("departments"))
					{
						result.put(api_values_usecase,checkDepartmentDetails(expectedIntegInfo,response,isEnableType,etest));
					}
					else
					{
						result.put(api_values_usecase,checkData(expectedIntegInfo,null,keys_check_usecase,response,false,etest));
					}
					if(!result.get(api_values_usecase))
					{
						TakeScreenshot.screenshot(api_webdriver,etest);
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}

				if(toCheckInUI)
				{
					String app = "";
					try
					{
						if(api_obj == Api.INTEG_CRM_DEPT_UPDATE)
						{
							app = CRM;
						}
						else if(api_obj == Api.INTEG_CAMPAIGN_DEPT_UPDATE)
						{
							app = CAMPAIGN;
						}
						else if(api_obj == Api.INTEG_SALESFORCE_DEPT_UPDATE)
						{
							app = SALESFORCE;
						}
						else if(api_obj == Api.INTEG_MAILCHIMP_DEPT_UPDATE)
						{
							app = MAILCHIMP;
						}

						if(api_obj.get().contains("zohocrm"))
						{
							integInfoFromUI = RESTAPICRMInteg.getCRMInfoFromUI(driver);
						}
						else if(api_obj.get().contains("zohodesk"))
						{
							integInfoFromUI = RESTAPIDeskInteg.getDeskInfoFromUI(driver);
						}
						else if(api_obj.get().contains("zohocampaign"))
						{
							integInfoFromUI = RESTAPICampaignInteg.getCampaignInfoFromUI(driver);
						}
						else if(api_obj.get().contains("salesforce"))
						{
							integInfoFromUI = RESTAPISalesforceInteg.getInfoFromUI(driver);
						}
						else if(api_obj.get().contains("zendesk"))
						{
							integInfoFromUI = RESTAPIZendeskInteg.getInfoFromUI(driver);
						}
						else if(api_obj.get().contains("mailchimp"))
						{
							integInfoFromUI = RESTAPIMailChimpInteg.getInfoFromUI(driver);
						}
						else if(api_obj.get().contains("googleanalytics"))
						{
							integInfoFromUI = RESTAPIGAnalyticsInteg.getInfoFromUI(driver);
						}
						else if(api_obj.get().contains("clearbitreveal"))
						{
							integInfoFromUI = RESTAPIClearbitRevealInteg.getInfoFromUI(driver);
						}
						else if(api_obj.get().contains("clearbitenrichment"))
						{
							integInfoFromUI = RESTAPIClearbitEnrichmentInteg.getInfoFromUI(driver,startKey);
						}

						result.put(ui_values_usecase,false);

						etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN UI</b>");

						if((api_obj == Api.INTEG_CRM_DEPT_UPDATE) || (api_obj == Api.INTEG_CAMPAIGN_DEPT_UPDATE) || (api_obj == Api.INTEG_SALESFORCE_DEPT_UPDATE) || (api_obj == Api.INTEG_MAILCHIMP_DEPT_UPDATE))
						{
							result.put(ui_values_usecase,checkDeptUpdate(driver,expectedIntegInfo,app,etest));
						}
						else if((api_obj == Api.INTEG_DESK_DEPT_UPDATE) || (api_obj == Api.INTEG_ZENDESK_DEPT_UPDATE))
						{
							result.put(ui_values_usecase,checkDeskDeptUpdate(driver,integInfoFromUI,expectedIntegInfo,etest));
						}
						else
						{
							result.put(ui_values_usecase,checkData(expectedIntegInfo,integInfoFromUI,keys_check_usecase,response,true,etest));
							if(!result.get(ui_values_usecase))
							{
								TakeScreenshot.screenshot(driver,etest);
							}
						}
					}
					catch(Exception e1)
					{
						TakeScreenshot.screenshot(api_webdriver,etest);
						TakeScreenshot.screenshot(driver,etest,e1);
						SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
					}
				}
			}
			else
			{
				result.put(keys_check_usecase,false);

				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
				{
					result.put(keys_check_usecase,true);
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					result.put(keys_check_usecase,false);
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
		return result;
	}

	public static boolean checkAppFieldsApi(WebDriver api_webdriver,WebDriver driver,String response_code,boolean isReplace,String replaceString,String replaceWith,Api api_obj,String file_name,int startKey,ExtentTest etest) throws Exception
	{
		int failcount=0;

		boolean isResponse = (response_code == Constants.SUCCESS_CODE)?true:false;

		String keys_check_usecase = "RESTAPI" + startKey;

		try
		{
			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,replaceString,replaceWith,api_obj,false,null,etest);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			etest.log(Status.PASS,"json_response-->"+json_response.toString());

			if(isResponse)
			{
				String fieldmaps_directory=FileUpload.getBuildRoot()+"/webapps/selenium/test_related_files/fieldMapsJSON/";

				JSONObject expected_json=new JSONObject(FileUpload.getFileAsString(fieldmaps_directory+file_name));


				String expected_json_string=expected_json.toString().trim().replaceAll("\\n","");
				String actual_json_string=json_response.toString().trim().replaceAll("\\n","");

				try
				{

					etest.log(Status.INFO,"NOW CHECKING FIELDMAPS RESPONSE");

					if(expected_json_string.equals(actual_json_string))
					{
						etest.log(Status.PASS,"Expected fieldmaps response was found.");
					}
					else
					{
						etest.log(Status.FAIL,"Expected fieldmaps response was NOT found.");
						etest.log(Status.FAIL,"Expected:"+expected_json.toString());
						etest.log(Status.FAIL,"Actual:"+json_response.toString());
						TakeScreenshot.screenshot(api_webdriver,etest);
						failcount++;
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
				}
			}
			else
			{
				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
				{
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
					failcount++;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkData(Hashtable<String,String> expected,Hashtable<String,String> valuesFromUI,String keyToCheck,String response,boolean isUI,ExtentTest etest) throws Exception
	{
		String expected_value,actual_value;

		String[] keysToCheck = RestAPIConfManager.getRealValue(keyToCheck+"_keys").split(",");

		int failcount = 0;

        for(int i = 0; i < keysToCheck.length; i++)
        {
        	etest.log(Status.INFO,"Checking "+keysToCheck[i]);
        	if(isUI)
        	{
	    		expected_value = expected.get(keysToCheck[i].replaceAll("/","_"));
	    		actual_value = valuesFromUI.get(keysToCheck[i].replaceAll("/","_"));
	    		// actual_value = SalesIQRestAPICommonFunctions.jPath(response,keysToCheck[i]).replaceAll("_","");
	    	}
	    	else
	    	{
	    		actual_value = expected.get(keysToCheck[i].replaceAll("/","_"));
	    		expected_value = SalesIQRestAPICommonFunctions.jPath(response,keysToCheck[i]);
	    		if(!keysToCheck[i].equals("data/connected_account/key"))
	    		{
	    			expected_value = expected_value.replaceAll("_","");
	    		}
	    	}

    		if(expected_value.contains(","))
    		{
    			String[] values = expected_value.replace("]","").replace("[","").split(",");
    			for(String value : values)
    			{
	    			if(!CommonUtil.checkStringContainsAndLog(value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
		    		{
		    			failcount++;
		    		}
    			}
    		}
    		else 
    		{
    			if(!CommonUtil.checkStringContainsAndLog(expected_value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
	    		{
	    			failcount++;
	    		}
	    	}
        }

        if(expected.containsKey("data_fields"))
        {
        	String expectedFields = expected.get("data_fields");
        	String fieldHeader = (expected.containsKey("data_general_config_add_company_particulars_as"))?(expected.get("data_general_config_add_company_particulars_as")):null;
        	if(expected.containsKey("data_name") && expected.get("data_name").equals(RESTAPIClearbitEnrichmentInteg.CLEARBITENRICHMENT_NAME))
        	{
        		expectedFields = new JSONObject(expected.get("data_fields")).getString(fieldHeader);
        	}
        	CommonUtil.print("\n\n\n\n\n>>>>>>expected\n\n"+expected+"\n\n\n\n\n\n");
        	CommonUtil.print("\n\n\n\n\n>>>>>>ExpectedFields\n\n"+expectedFields+"\n\n\n\n\n\n");
        	if(!checkFieldDetails(response,expectedFields,fieldHeader,etest))
        	{
        		failcount++;
        	}
        }

        return CommonUtil.returnResult(failcount);
	}

	public static boolean checkDepartmentDetails(Hashtable<String,String> expectedIntegInfo,String response,boolean isEnableType,ExtentTest etest) throws Exception
	{
		String
		actual = "",
		expected = ""
		;

		JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

		JSONArray department_array = new JSONObject(json_response.get("data").toString()).getJSONArray("departments");
		int index = SalesIQRestAPICommonFunctions.getJSONIndexWith(department_array,"id",expectedIntegInfo.get("id"));

		if(isEnableType)
		{
			actual = SalesIQRestAPICommonFunctions.jPath(response,getJPathForIndex(JPaths.DEPARTMENT_ENABLED,index));
			expected = expectedIntegInfo.get("enabled");
		}
		else
		{
			actual = SalesIQRestAPICommonFunctions.jPath(response,getJPathForIndex(JPaths.DEPARTMENT_STATUS,index));
			if(actual.equals("active"))
			{
				actual = SalesIQRestAPICommonFunctions.jPath(response,getJPathForIndex(JPaths.INTEGRATED_DEPARTMENT_NAME,index));
			}
			expected = expectedIntegInfo.get("status");
		}

		return CommonUtil.checkStringContainsAndLog(expected,actual,"department status",etest);
	}

	public static boolean checkDeskDeptUpdate(WebDriver driver,Hashtable<String,String> infoFromUI,Hashtable<String,String> expectedIntegInfo,ExtentTest etest)
	{
		String expected = expectedIntegInfo.get("status").toLowerCase().replace(" ","_");
		String actual = infoFromUI.get(RESTAPIDeskInteg.DEPARTMENT_STATUS).toLowerCase();

		return CommonUtil.checkStringContainsAndLog(expected,actual,"department status in UI",etest);
	}

	public static boolean checkDeptUpdate(WebDriver driver,Hashtable<String,String> expectedIntegInfo,String app,ExtentTest etest)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,app);

			List<WebElement> departmentList = CommonUtil.getElement(driver,By.id("deptlistbx")).findElements(By.tagName("li"));
			for(WebElement department : departmentList)
			{
				if(department.getAttribute("val").contains(expectedIntegInfo.get("id")))
				{
					if(expectedIntegInfo.get("enabled").equals("true"))
					{
						etest.log(Status.PASS,"Expected status for department was found in UI");
						return true;
					}
					else
					{
						etest.log(Status.FAIL,"Expected status for department was not found in UI");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
				}
			}

			if(expectedIntegInfo.get("enabled").equals("false"))
			{
				etest.log(Status.PASS,"Expected status for department was found in UI");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Expected status for department was not found in UI");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FAIL,"Expected status for department was not found in UI");
			TakeScreenshot.screenshot(driver,etest);
			return false;
		}
	}

	public static boolean checkExpectedDataPresentInResponse(Hashtable<String,String> expected,String response,ExtentTest etest)
	{
		int failcount = 0;

		Set<String> expected_keys = expected.keySet();

		for(String expected_key : expected_keys)
		{
			if(!CommonUtil.checkStringContainsAndLog(expected.get(expected_key),response,"department value in appfield",etest))
			{
				failcount++;
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkFieldDetails(String response,String expected_string,String fieldHeader,ExtentTest etest)
	{
		int failcount = 0;
		try
		{

			JSONObject expected = new JSONObject(expected_string);

			JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			JSONArray json_array;

			if(fieldHeader == null)
			{
				json_array = json_response.getJSONObject("data").getJSONArray("fields");
			}
			else
			{
				json_array = json_response.getJSONObject("data").getJSONObject("fields").getJSONArray(fieldHeader);
			}

			CommonUtil.print("\n\n\n\n\n>>>>>>json_array\n\n"+json_array+"\n\n\n\n\n\n");

			for(int i = 0; i < json_array.length(); i++)
			{
				try
				{
					String actualFieldId = json_array.getJSONObject(i).getString("field_id");
					String actualIntegratedFieldName = json_array.getJSONObject(i).getString("integration_field_name");
					String actualFieldStatus = json_array.getJSONObject(i).getString("field_status");

					if(!(fieldHeader != null && expected.has(actualFieldId)))
					{
						continue;
					}

					String expectedIntegratedFieldName = expected.getString(actualFieldId).split("_")[0];
					String expectedFieldStatus = expected.getString(actualFieldId).split("_")[1];

					if(!(CommonUtil.checkStringContainsAndLog(expectedFieldStatus,actualFieldStatus,"field status for "+actualFieldId,etest) &&
						CommonUtil.checkStringContainsAndLog(expectedIntegratedFieldName,actualIntegratedFieldName,"integration field for "+actualFieldId,etest)))
					{
						failcount++;
					}
				}
				catch(Exception e)
				{
					String actualFieldId = json_array.getJSONObject(i).getString("field_id");
					if(!CommonUtil.checkStringContainsAndLog(expected.getString(actualFieldId).split("_")[1],"deleted","field status for "+actualFieldId,etest))
					{
						etest.log(Status.FAIL,"Expected field name ("+actualFieldId+") with integration id ("+expected.getString(actualFieldId)+") not present");
						CommonUtil.printStackTrace(e);
						failcount++;
					}
				}
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static String getSelectedFromCheckBox(WebDriver driver,By by) throws Exception
	{
		String selected = "";
		List<WebElement> optionElements = CommonUtil.getElement(driver,by).findElements(CHCKBXMN);

		for(WebElement element : optionElements)
		{
			if(element.getAttribute("innerHTML").contains(CHCKBXSEL))
			{
				String id = element.findElement(By.tagName("input")).getAttribute("id").toLowerCase();
				id = "\""+id+"\",";
				selected += id;
			}
		}
		selected = selected.substring(0,selected.length()-1);
		return selected;
	}

	public static String getSelectedFromRadio(WebDriver driver,By by,String checkAttr,String valueIfYes,String valueIfNo) throws Exception
	{
		WebElement selectedElement = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,by).findElements(UPRDOWRAP),"innerHTML",RADIO_SELECTED);
		String selected = selectedElement.findElement(By.tagName("input")).getAttribute("id").contains(checkAttr)?valueIfYes:valueIfNo;
		return selected;
	}

	public static String getSelectedFromRadio(WebDriver driver,By by) throws Exception
	{
		WebElement selectedElement = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,by).findElements(UPRDOWRAP),"innerHTML",RADIO_SELECTED);
		String selected = selectedElement.findElement(By.tagName("input")).getAttribute("crmtype").toLowerCase();
		return selected;
	}

	public static String getSelectedFromDropdown(WebDriver driver,By by) throws Exception
	{
		if(CommonUtil.getByValue(by).equals(CommonUtil.getByValue(ASSIGNED_OWNER)))
		{
			return CommonUtil.getElement(driver,by).getAttribute("selval").replaceAll(" ","");
		}
		else
		{
			return CommonUtil.getElement(driver,by).getAttribute("selval").toLowerCase().replaceAll(" ","");
		}
	}

	public static String getValueFromInput(WebDriver driver,By by) throws Exception
	{
		return CommonUtil.getElement(driver,by).getAttribute("value");
	}

	public static String getSelectedFromToggle(WebDriver driver,By by,String expectedClass) throws Exception
	{
		return CommonUtil.getElement(driver,by).getAttribute("class").contains(expectedClass) + "";
	}

	public static String getEnableStatus(WebDriver driver) throws Exception
	{
		return CommonUtil.getElement(driver,RIGHTINTEGBTN).getText().contains(DISABLE) + "";
	}

	public static String getTextFromDiv(WebDriver driver,By by) throws Exception
	{
		return CommonUtil.getElement(driver,by).getAttribute("innerText").trim();
	}

	public static Hashtable<String,String> getValuesFromConf(String keyToCheck)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		String[] keys = RestAPIConfManager.getRealValue(keyToCheck+"_keys").split(",");
		String[] values = RestAPIConfManager.getRealValue(keyToCheck+"_values").split(",");

		for(int i = 0; i < keys.length;i++)
		{
			info.put(keys[i].replaceAll("/","_"),values[i]);
		}

		return info;
	}

	public static Hashtable<String,String> getDepartmentStatus(WebDriver driver,By by,String id) throws Exception
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		List<WebElement> deptList = CommonUtil.getElement(driver,by).findElements(ACTIONMN);

		WebElement dept = CommonUtil.getElementByAttributeValue(deptList,"id",id);

		info.put("id",dept.getAttribute("id"));
		info.put("status",dept.findElement(ACTIONMN_RIGHT).getAttribute("innerText").trim().replaceAll(" ","_").replaceAll("-","_").toLowerCase());

		return info;
	}

	public static String getJPathForIndex(String jPath,int index) throws Exception
	{
		jPath = jPath.replace("<id>", index+"");
		return jPath;
	}

	public static String getCRMZSCKey(WebDriver crmwindow)
	{
		String newkey;
		String current_url = crmwindow.getCurrentUrl();
        String expected_url = current_url.replaceAll(current_url.substring(current_url.indexOf("/",current_url.indexOf("org"))), "/settings/api");
        crmwindow.get(expected_url);

        CommonWait.waitTillDisplayed(crmwindow,SETUPINNERLINKS,ZSC_CSS_SELECTOR);
        CommonUtil.getElement(crmwindow,SETUPINNERLINKS,ZSC_CSS_SELECTOR).click();

        CommonWait.waitTillDisplayed(crmwindow,SHOW_API_KEY);

        String oldkey = CommonUtil.getElement(crmwindow,SHOW_API_KEY).getText().trim();

        // CommonUtil.getElement(crmwindow,REGENERATE_BUTTON).click();

        // CommonWait.waitTillDisplayed(crmwindow,GENERATE_API_KEY);
        // CommonUtil.getElement(crmwindow,GENERATE_API_KEY).click();

        // for(int i = 1; i <= 10;i++)
        // {
        //     newkey = CommonUtil.getElement(crmwindow,SHOW_API_KEY).getText();

        //     if(!newkey.equals("") && !newkey.equals(oldkey))
        //     {
        //         break;
        //     }

        //     CommonUtil.sleep(1000);
        // }

        newkey = CommonUtil.getElement(crmwindow,SHOW_API_KEY).getText();

        return newkey;
	}

	public static String getDeskZSCKey(WebDriver deskDriver)
	{
		String newKey;
		String currentUrl = deskDriver.getCurrentUrl();
		String expectedUrl = currentUrl.substring(0,currentUrl.indexOf("#"))+"#setup/developer-space/api";
		deskDriver.get(expectedUrl);

		CommonWait.waitTillDisplayed(deskDriver,DESK_ZSC_KEY_CONTAINER);
		CommonUtil.inViewPortSafe(deskDriver,CommonUtil.getElement(deskDriver,DESK_ZSC_KEY),50);

		String oldKey = CommonUtil.getElement(deskDriver,DESK_ZSC_KEY).getText().trim();

		// CommonUtil.clickWebElement(deskDriver,DESK_ZSC_KEY_CONTAINER,DESK_ZSC_KEY_REGENERATE_BUTTON);

		// CommonWait.waitTillDisplayed(deskDriver,DESKPOPUP);
		// CommonUtil.clickWebElement(deskDriver,DESKPOPUP,DESK_POPUP_OK,By.tagName("input"));

		// for(int i = 1; i <= 10;i++)
  //       {
  //           newKey = CommonUtil.getElement(deskDriver,DESK_ZSC_KEY).getText();

  //           if(!newKey.equals("") && !newKey.equals(oldKey))
  //           {
  //               break;
  //           }

  //           CommonUtil.sleep(1000);
  //       }

        newKey = CommonUtil.getElement(deskDriver,DESK_ZSC_KEY).getText();

        return newKey;
	}

	public static String getCampaignZSCKey(WebDriver campaignDriver)
	{
		String newKey;
		String currentUrl = campaignDriver.getCurrentUrl();
		String expectedUrl = currentUrl.substring(0,currentUrl.indexOf("#"))+"#settings/api";
		campaignDriver.get(expectedUrl);

		CommonWait.waitTillDisplayed(campaignDriver,CAMPAIGNS_INNER_CONTAINER);
		CommonUtil.inViewPortSafe(campaignDriver,CommonUtil.getElement(campaignDriver,CAMPAIGNS_ZSC_KEY_REGENERATE_BUTTON),50);

		String oldKey = CommonUtil.getElement(campaignDriver,CAMPAIGNS_ZSC_KEY).getAttribute("value").trim();

		// CommonUtil.clickWebElement(campaignDriver,CAMPAIGNS_ZSC_KEY_REGENERATE_BUTTON);

		// CommonWait.waitTillDisplayed(campaignDriver,CAMPAIGNS_ZSC_KEY_ALERT);
		// CommonUtil.clickWebElement(campaignDriver,CAMPAIGNS_ZSC_KEY_ALERT,CAMPAIGNS_ZSC_KEY_ALERT_CONFIRM);

		// for(int i = 1; i <= 10;i++)
  //       {
  //           newKey = CommonUtil.getElement(campaignDriver,CAMPAIGNS_ZSC_KEY).getAttribute("value");

  //           if(!newKey.equals("") && !newKey.equals(oldKey))
  //           {
  //               break;
  //           }

  //           CommonUtil.refreshPage(campaignDriver);
  //           CommonUtil.sleep(1000);
  //       }

  //       newKey = CommonUtil.getElement(campaignDriver,CAMPAIGNS_ZSC_KEY).getAttribute("value");

        return oldKey;
	}

	public static int getRandomId()
	{
		String label = CommonUtil.getUniqueMessage();

		label = label.substring(label.length()-3,label.length());

		int randomId = Integer.parseInt(label);

		return randomId;
	}

	public static void changeZSCKey(WebDriver driver,String zscKey)
	{
		if(driver.getCurrentUrl().contains("integration/crm"))
		{
			CommonUtil.clickWebElement(driver,CHANGE_CRM_ZSC_KEY);
		}
		else
		{
			CommonUtil.clickWebElement(driver,CHANGE_ZSC_KEY);
		}
		WebElement changeZSCPopup = HandleCommonUI.getPopupByInnerText(driver,"ZSC");
		CommonUtil.sendKeysToWebElement(driver,changeZSCPopup.findElement(ZSC_KEY_CHANGE_DIV),zscKey);
		HandleCommonUI.clickPositivePopupButton(changeZSCPopup);
	}

	public static void enableIntegration(WebDriver driver,String app,ExtentTest etest)
	{
		enableIntegration(driver,app,null,etest);
	}

	public static void enableIntegration(WebDriver driver,String app,String disableApp,ExtentTest etest)
	{
		try
		{
			
			if(disableApp != null)
			{
				boolean popup = ( (disableApp.equals(CRM)) || (app.equals(GOOGLE_ANALYTICS)) )?true:false;
				selectIntegApp(driver,disableApp);
				Integration.clickDisableIntegration(driver,"Integration disabled successfully",popup,disableApp,etest);
			}
			selectIntegApp(driver,app);
			Integration.clickEnableIntegration(driver,"Integration enabled successfully",app,etest);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}

	public static void selectIntegApp(WebDriver driver,String app)
	{
		try
		{
			CommonUtil.refreshPage(driver);
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,app);			
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
	}
}