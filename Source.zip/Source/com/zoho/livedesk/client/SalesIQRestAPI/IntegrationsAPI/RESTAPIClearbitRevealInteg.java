//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.IntegrationsAPI;

import java.util.List;
import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;

public class RESTAPIClearbitRevealInteg
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String[][]
	FIELD_ID = {{"phone","description","state","city","country"},{"phone","description","state","city","country"},{"phone","description","state","city","country"}},
	INTEGRATION_FIELD_ID = {{"Phone","Description","State","City","Country"},{"Phone","Description","Mailing State","Other City","Mailing Country"},{"Phone","Description","Billing State","Shipping City","Shipping Country"}},
	INTEGRATION_FIELD_NAME = {{"Phone","Description","State","City","Country"},{"Phone","Description","Mailing State","Other City","Mailing Country"},{"Phone","Description","Billing State","Shipping City","Shipping Country"}}
	;

	public static final String[]
	UPDATE_TO_CRM_VALUES = {"true","false"},
	ADD_COMPANY_PARTICULARS_AS_VALUES = {"lead","contact","account"},
	REFRESH_FREQUENCY_VALUES = {"weekly","every_30_days","every_90_days"},
	FIELD_STATUS = {"enabled","disabled"},
	ENABLE_VALUES = {"true","false"}
	;

	public static final String
	MODULE_NAME = "Integration RESTAPI",
	CLEARBITREVEAL = "Clearbit (Reveal)",
	CRM = "Zoho CRM",
	SALESFORCE = "Salesforce",
	ENABLED = "data_enabled",
	KEY = "data_connected_account_key",
	REFRESH_FREQUENCY = "data_general_config_refresh_frequency",
	ADD_COMPANY_PARTICULARS_AS = "data_general_config_add_company_particulars_as",
	UPDATE_TO_CRM = "data_general_config_update_to_crm",
	FIELDS = "data_fields",
	NAME = "data_name",
	CLEARBITREVEAL_NAME = "clearbitreveal",
	SET_ON = "set_on",
	CLEARBITREVEAL_ID = "clearbitreveal_"
	;

	public static final By
	CB_API_TOKEN = By.id("cbapitoken"),
	UPDATE_TO_CRM_DIV = By.id("pushclearbitrevealinfo"),
	CRMCLEARBITRADIO = By.id("crmclearbitradio"),
	CBIT_DROPDOWN = By.id("cbitdropdown_div"),
	CONFIGTABLE = By.id("clearbitrevealconfigtable"),
	LIST_ROW = By.className("list-row")
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

			WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api1");

			etest = ComplexReportFactory.getEtest("Check get individual Clearbit Reveal integration",MODULE_NAME);
			checkGetCBRevealAPI(driver,api_webdriver,Constants.SUCCESS_CODE,879,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check update Clearbit Reveal integration",MODULE_NAME);
			checkUpdateCBRevealAPI(driver,api_webdriver,Constants.SUCCESS_CODE,881,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Disable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,false,Constants.SUCCESS_CODE,884,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Enable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,true,Constants.SUCCESS_CODE,887,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_supervisor");

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check get individual Clearbit Reveal integration",MODULE_NAME);
			checkGetCBRevealAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,890,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check update Clearbit Reveal integration",MODULE_NAME);
			checkUpdateCBRevealAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,891,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check Disable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,892,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check supervisor -- Check Enable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,893,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"integ_api_associate");

			etest = ComplexReportFactory.getEtest("Check Associate -- Check get individual Clearbit Reveal integration",MODULE_NAME);
			checkGetCBRevealAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,894,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check update Clearbit Reveal integration",MODULE_NAME);
			checkUpdateCBRevealAPI(driver,api_webdriver,Constants.PERMISSION_ERROR_CODE,895,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Disable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,false,Constants.PERMISSION_ERROR_CODE,896,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Associate -- Check Enable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,true,Constants.PERMISSION_ERROR_CODE,897,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check get individual Clearbit Reveal integration",MODULE_NAME);
			checkGetCBRevealAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,898,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check update Clearbit Reveal integration",MODULE_NAME);
			checkUpdateCBRevealAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,899,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Disable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,false,Constants.INVALID_SCOPE_ERROR_CODE,900,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Check Invalid Scope -- Check Enable Clearbit Reveal Integration",MODULE_NAME);
			checkEnableCBRevealAPI(driver,api_webdriver,true,Constants.INVALID_SCOPE_ERROR_CODE,901,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetCBRevealAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,CRM,SALESFORCE,etest);

			Hashtable<String,String> info = getInfoFromUI(driver);
			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,false,response_code,false,"","",Api.INTEG_CB_REVEAL_GET,null,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkUpdateCBRevealAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,CLEARBITREVEAL);
			IntegrationRESTAPICommonFunctions.enableIntegration(driver,CLEARBITREVEAL,etest);
			List<WebElement> fieldList = CommonUtil.getElement(driver,CONFIGTABLE).findElements(LIST_ROW);

			int randomId = IntegrationRESTAPICommonFunctions.getRandomId();

			String previous_field_id = CommonUtil.getElement(fieldList.get(2),By.id(CLEARBITREVEAL_ID+"col1_2")).getAttribute("innerText").toLowerCase().trim().replaceAll(" ","").replaceAll("legalname","legalName");
			String field_id = FIELD_ID[randomId%3][randomId%5];

			if(previous_field_id.contains(field_id))
			{
				randomId++;
			}

			field_id = FIELD_ID[randomId%3][randomId%5];

			String
			integration_field_id = INTEGRATION_FIELD_ID[randomId%3][randomId%5],
			integration_field_name = INTEGRATION_FIELD_NAME[randomId%3][randomId%5],
			field_status = FIELD_STATUS[randomId%2],
			update_to_crm = UPDATE_TO_CRM_VALUES[0],
			add_company_particulars_as = ADD_COMPANY_PARTICULARS_AS_VALUES[randomId%3],
			refresh_frequency = REFRESH_FREQUENCY_VALUES[randomId%3]
			;

			JSONObject payload = GetPayload.getUpdateClearBitPayload(field_id,integration_field_id,field_status,previous_field_id,add_company_particulars_as,refresh_frequency,update_to_crm);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			Hashtable<String,String> expectedInfo = getExpectedInfo(field_id,integration_field_name,previous_field_id,field_status,update_to_crm,add_company_particulars_as,refresh_frequency);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CB_REVEAL_UPDATE,payload,expectedInfo,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static void checkEnableCBRevealAPI(WebDriver driver,WebDriver api_webdriver,boolean isEnabled,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			String enabled = isEnabled + "";

			Hashtable<String,String> info = new Hashtable<String,String>();
			info.put(ENABLED,enabled);

			JSONObject payload = GetPayload.getEnablePayload(enabled);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			result.putAll(IntegrationRESTAPICommonFunctions.checkAPI(driver,api_webdriver,etest,true,response_code,false,"","",Api.INTEG_CB_REVEAL_UPDATE,payload,info,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

	public static Hashtable<String,String> getInfoFromUI(WebDriver driver)
	{
		Hashtable<String,String> info = new Hashtable<String,String>();

		try
		{
			CommonUtil.refreshPage(driver);
			IntegrationRESTAPICommonFunctions.selectIntegApp(driver,CLEARBITREVEAL);
			info.put(NAME,CLEARBITREVEAL_NAME);
			info.put(KEY,IntegrationRESTAPICommonFunctions.getValueFromInput(driver,CB_API_TOKEN));
			info.put(ENABLED,IntegrationRESTAPICommonFunctions.getEnableStatus(driver));
			info.put(UPDATE_TO_CRM,IntegrationRESTAPICommonFunctions.getSelectedFromToggle(driver,UPDATE_TO_CRM_DIV,SET_ON));
			info.put(ADD_COMPANY_PARTICULARS_AS,IntegrationRESTAPICommonFunctions.getSelectedFromRadio(driver,CRMCLEARBITRADIO));
			info.put(REFRESH_FREQUENCY,IntegrationRESTAPICommonFunctions.getTextFromDiv(driver,CBIT_DROPDOWN).toLowerCase().replaceAll(" ",""));
			info.put(FIELDS,RESTAPICampaignInteg.getFieldDetails(driver,CLEARBITREVEAL_ID));

			CommonUtil.print("\n\n\n\n\nInfo>>>>>>>>>>>"+info+"\n\n\n");
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}

		return info;
	}

	public static Hashtable<String,String> getExpectedInfo(String field_id,String integration_field_name,String previous_field_id,String field_status,String update_to_crm,String add_company_particulars_as,String refresh_frequency) throws Exception
	{
		Hashtable<String,String> info = new Hashtable<String,String>();
		JSONObject fieldDetails = new JSONObject();
		fieldDetails.put(field_id,integration_field_name+"_"+field_status);
		fieldDetails.put(previous_field_id,integration_field_name+"_deleted");

		info.put(NAME,CLEARBITREVEAL_NAME);
		info.put(UPDATE_TO_CRM,update_to_crm);
		info.put(ADD_COMPANY_PARTICULARS_AS,add_company_particulars_as);
		info.put(REFRESH_FREQUENCY,refresh_frequency.replace("_",""));
		info.put(FIELDS,fieldDetails.toString());

		CommonUtil.print("\n\n\n\n\nExpectedInfo>>>>>>>>>>>"+info+"\n\n\n");

		return info;
	}
}