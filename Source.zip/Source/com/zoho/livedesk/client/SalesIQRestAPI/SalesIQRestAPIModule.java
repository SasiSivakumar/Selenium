//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;


import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;




import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;



import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.SalesIQRestAPI.RestAPIConfManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.BuildRejector;

public class SalesIQRestAPIModule{

	public static WebDriver driver1;	

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
	public static ExtentTest etest; 
	static public ExtentReports extent;

	public static String APITesterURL="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/REST_API/API.html";


	public static String
	getAllChatAPI="https://salesiq.zoho.com/api/v1/<screenname>/chats",
	getChatDetailsAPI="https://salesiq.zoho.com/api/v1/<screenname>/chats/<chat_id>",
	getChatTranscriptAPI="https://salesiq.zoho.com/api/v1/<screenname>/chats/<chat_id>/transcript",
	getAttachmentURLAPI="https://salesiq.zoho.com/api/v1/<screenname>/chats/<chat_id><attachmenturl>",
	getVisitorDetailsAPI="https://salesiq.zoho.com/api/v1/<screenname>/visitorsview/<viewid>/visitors",
	postVisitorDetailsAPI="https://salesiq.zoho.com/api/v1/<screenname>/visitorsbyemail/<emailid>",
	getDepartmentListWithWidgetCodeAPI="https://salesiq.zoho.com/api/v1/<screenname>/websites/<widgetcode>/departments";

	public static String fromtime=RestAPIConfManager.getRealValue("fromtimechat"),totime=RestAPIConfManager.getRealValue("totimechat");
	public static String fromtimect=RestAPIConfManager.getRealValue("fromtimect"),totimect=RestAPIConfManager.getRealValue("totimect");

	public static boolean isNoOfVisitorsMoreThan100=Boolean.parseBoolean(RestAPIConfManager.getRealValue("isNoOfVisitorsMoreThan100"));

	public static int expected_noofchats=Integer.parseInt(RestAPIConfManager.getRealValue("expected_noofchats"));

	public static int expected_noofmsgs=Integer.parseInt(RestAPIConfManager.getRealValue("expected_noofmsgs"));

	public static void initiateValues()
	{
		if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
		{
			fromtime=RestAPIConfManager.getRealValue("idc_fromtimechat");
			totime=RestAPIConfManager.getRealValue("idc_totimechat");
			fromtimect=RestAPIConfManager.getRealValue("idc_fromtimect");
			totimect=RestAPIConfManager.getRealValue("idc_totimect");
			isNoOfVisitorsMoreThan100=Boolean.parseBoolean(RestAPIConfManager.getRealValue("idc_isNoOfVisitorsMoreThan100"));
			expected_noofchats=Integer.parseInt(RestAPIConfManager.getRealValue("idc_expected_noofchats"));
			expected_noofmsgs=Integer.parseInt(RestAPIConfManager.getRealValue("idc_expected_noofmsgs"));
		}
		else
		{
			fromtime=RestAPIConfManager.getRealValue("fromtimechat");
			totime=RestAPIConfManager.getRealValue("totimechat");
			fromtimect=RestAPIConfManager.getRealValue("fromtimect");
			totimect=RestAPIConfManager.getRealValue("totimect");
			isNoOfVisitorsMoreThan100=Boolean.parseBoolean(RestAPIConfManager.getRealValue("isNoOfVisitorsMoreThan100"));
			expected_noofchats=Integer.parseInt(RestAPIConfManager.getRealValue("expected_noofchats"));
			expected_noofmsgs=Integer.parseInt(RestAPIConfManager.getRealValue("expected_noofmsgs"));
		}
	}

	public static Hashtable test() throws Exception
	{
		try
		{
			initiateValues();
			SalesIQRestAPICommonFunctions.initiate();

			driver1=Functions.setUp();


			driver1.get(APITesterURL);	

			SalesIQRestAPICommonFunctions.clickSettings(driver1);			
			SalesIQRestAPICommonFunctions.setAuth(driver1);





			// get from chat id
			etest=ComplexReportFactory.getTest(getTest("RESTAPI1"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI1", checkChatAPI(driver1,-1,null,null,true));        
            ComplexReportFactory.closeTest(etest);
            
            //get all chats
			etest=ComplexReportFactory.getTest(getTest("RESTAPI2"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI2", checkChatAPI(driver1,-1,null,null,false));        
            ComplexReportFactory.closeTest(etest);

            //get less than default limit limit chats
			etest=ComplexReportFactory.getTest(getTest("RESTAPI3"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI3", checkChatAPI(driver1,2,null,null,false));        
            ComplexReportFactory.closeTest(etest);

            //get  max limit chats
			etest=ComplexReportFactory.getTest(getTest("RESTAPI4"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI4", checkChatAPI(driver1,99,null,null,false));        
            ComplexReportFactory.closeTest(etest);

            //get more than max limit chats
			etest=ComplexReportFactory.getTest(getTest("RESTAPI14"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI14", checkChatAPI(driver1,100,null,null,false));        
            ComplexReportFactory.closeTest(etest);

            //get more from to time chats
			etest=ComplexReportFactory.getTest(getTest("RESTAPI5"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI5", checkChatAPI(driver1,-1,fromtime,totime,false));        
            ComplexReportFactory.closeTest(etest);

            //to check chat transcript
            etest=ComplexReportFactory.getTest(getTest("RESTAPI6"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI6", checkChatTranscriptAPI(driver1,-1,null,null));        
            ComplexReportFactory.closeTest(etest);

            //to check chat transcript limit less
            etest=ComplexReportFactory.getTest(getTest("RESTAPI7"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI7", checkChatTranscriptAPI(driver1,3,null,null));        
            ComplexReportFactory.closeTest(etest);

            //to check chat transcript limit more
            etest=ComplexReportFactory.getTest(getTest("RESTAPI8"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI8", checkChatTranscriptAPI(driver1,84,null,null));        
            ComplexReportFactory.closeTest(etest);

            //to check chat transcript from time to time
            etest=ComplexReportFactory.getTest(getTest("RESTAPI9"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI9", checkChatTranscriptAPI(driver1,-1,fromtimect,totimect));        
            ComplexReportFactory.closeTest(etest);

            //to check visitor details
            etest=ComplexReportFactory.getTest(getTest("RESTAPI10"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI10", checkVisitorDetailAPI(driver1));        
            ComplexReportFactory.closeTest(etest);

            //tocheckattchmentrurl checkAttachmentURLAPI

            etest=ComplexReportFactory.getTest(getTest("RESTAPI11"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI11", checkAttachmentURLAPI(driver1));        
            ComplexReportFactory.closeTest(etest);

 
            //checkAuthorisationErrors

            etest=ComplexReportFactory.getTest(getTest("RESTAPI12"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI12", checkAuthorisationErrors(driver1));        
            ComplexReportFactory.closeTest(etest);

			//get departments with widget code

            etest=ComplexReportFactory.getTest(getTest("RESTAPI13"));
			ComplexReportFactory.setValues(etest,"Automation","Rest API");
            TestResults.put("RESTAPI13", checkGetDepartmentListWithWidgetCodeAPI(driver1));        
            ComplexReportFactory.closeTest(etest);

		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
			return finalResult;
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);

            driver1.quit();
			// BuildRejector.analyse(TestResults,"Failures in REST API module");
			finalResult.put("result",TestResults);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}
	
	}

	public static boolean checkChatAPI(WebDriver driver,int limit,String fromtime,String totime,boolean getFromChatId) throws Exception
	{
		int failcount=0;

		try
		{

			driver.navigate().refresh();

			String api="";

			if(getFromChatId)
			{
				api=SalesIQRestAPICommonFunctions.customiseAPI(getChatDetailsAPI);
			}

			else
			{
				api=SalesIQRestAPICommonFunctions.customiseAPI(getAllChatAPI);
			}

			if(limit>0 && !getFromChatId)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,"limit",limit+"");
			}

			if(fromtime!=null)
			{

				api=SalesIQRestAPICommonFunctions.addParam(api,"fromtime",fromtime);
			}

			if(totime!=null)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,"totime",totime);
			}

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);
            
            etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");

			JSONObject JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

			if(limit==-1 && !getFromChatId && fromtime==null && totime==null)
			{
				int defaultlimit=50;

				boolean isTotalChatsLessThanDefault=Boolean.parseBoolean(RestAPIConfManager.getRealValue("isTotalChatsLessThanDefault"));

				if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
				{
					isTotalChatsLessThanDefault=Boolean.parseBoolean(RestAPIConfManager.getRealValue("idc_isTotalChatsLessThanDefault"));
				}

				

				if(JSONResponse.getJSONArray("data").length()==defaultlimit && !isTotalChatsLessThanDefault)
				{
					etest.log(Status.PASS,"API works as expected");
				}

				else if(JSONResponse.getJSONArray("data").length()<defaultlimit && isTotalChatsLessThanDefault)
				{
					etest.log(Status.PASS,"API works as expected");
				}

				else
				{
					failcount++;
					etest.log(Status.FAIL,"API limit param does not work as expected(Expected chats "+limit+": Actual Chats : "+JSONResponse.getJSONArray("data").length()+")");
				}

				TestResults.put("RESTAPI981",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,ExpectedKeys.GET_CHATS_V1));
			}

			if(limit>0 && !getFromChatId && fromtime==null && totime==null)
			{

				if(limit<=99)//max limit
				{
					if(JSONResponse.getJSONArray("data").length()==limit)
					{
						etest.log(Status.PASS,"API limit param works as expected");
					}
					else
					{
						failcount++;
						etest.log(Status.FAIL,"API limit param does not work as expected.(Expected chats "+limit+": Actual Chats : "+JSONResponse.getJSONArray("data").length()+")");
					}
				}
				else
				{
                    if(SalesIQRestAPICommonFunctions.checkAuthorisationError(JSONResponse,"Unknown authentication error, Contact SalesIQ Team!"))
                    {
                    	etest.log(Status.PASS,"Expected error message was found after limit greater than max limit was passed as param in get all chats API");
                    }
                    else
                    {
                    	etest.log(Status.FAIL,"Expected error message was NOT found after limit greater than max limit was passed as param in get all chats API");
                    	TakeScreenshot.screenshot(driver,etest);
                    }
				}
			}

			if(fromtime!=null && totime!=null && !getFromChatId)
			{
				if(JSONResponse.getJSONArray("data").length()==expected_noofchats)
				{
					etest.log(Status.PASS,"API fromtime and totime param works as expected");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"API fromtime and totime param does not work as expected.(Expected chats "+expected_noofchats+": Actual Chats : "+JSONResponse.getJSONArray("data").length()+")");
				}			
			}


			if(getFromChatId) 
			{
				// JSONObject data = JSONResponse.getJSONArray("data").getJSONObject(0);

				JSONObject data = JSONResponse.getJSONObject("data");

				if(SalesIQRestAPICommonFunctions.checkAPIResponse(driver,data,etest))
				{
					etest.log(Status.PASS,"API works as expected");
				}

				else
				{
					failcount++;
					etest.log(Status.FAIL,"API does not work as expected");	
				}

				TestResults.put("RESTAPI982",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,ExpectedKeys.GET_CHAT_V1));
			}		



		}
		catch(Exception e)
		{
			failcount++;
			e.printStackTrace();
			TakeScreenshot.log(e,etest);
			etest.log(Status.FAIL,"API could not be verified due to unexpected response structure");
			etest.log(Status.FAIL,"Error:"+e.getMessage());
		}
		finally
		{
			return returnResult(failcount);
		}

	}


	//transcript


	public static boolean checkChatTranscriptAPI(WebDriver driver,int limit,String fromtime,String totime) throws Exception
	{

		int failcount=0;

		try
		{

			driver.navigate().refresh();

			String api="";

			api=SalesIQRestAPICommonFunctions.customiseAPI(getChatTranscriptAPI);


			if(limit>0)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,"limit",limit+"");
			}

			if(fromtime!=null)
			{

				api=SalesIQRestAPICommonFunctions.addParam(api,"fromtime",fromtime);
			}

			if(totime!=null)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,"totime",totime);
			}

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);
            
            etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");

			JSONObject JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

			boolean isTotalMessagesLessThanDefault=Boolean.parseBoolean(RestAPIConfManager.getRealValue("isTotalMessagesLessThanDefault"));

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				isTotalMessagesLessThanDefault=Boolean.parseBoolean(RestAPIConfManager.getRealValue("idc_isTotalMessagesLessThanDefault"));
			}

			int maxlimit=50;

			if(limit==-1 && fromtime==null && totime==null)
			{

				if(JSONResponse.getJSONArray("data").length()==maxlimit && !isTotalMessagesLessThanDefault)
				{
					etest.log(Status.PASS,"API limit param works as expected");
				}

				else if(JSONResponse.getJSONArray("data").length()<maxlimit && isTotalMessagesLessThanDefault)
				{
					etest.log(Status.PASS,"API limit param works as expected");
				}

				else
				{
					failcount++;
					etest.log(Status.FAIL,"API limit param does not work as expected(Actual Chats : "+JSONResponse.getJSONArray("data").length()+")");
				}

				TestResults.put("RESTAPI980",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,ExpectedKeys.GET_CHAT_TRANSCRIPT_V1));
			}

			if(limit>0 && fromtime==null && totime==null)
			{
				limit=limit>=49?49:limit;

				if(JSONResponse.getJSONArray("data").length()==limit+1)
				{
					etest.log(Status.PASS,"API limit param works as expected");
				}

				else if(isTotalMessagesLessThanDefault && JSONResponse.getJSONArray("data").length()<maxlimit)
				{
					etest.log(Status.PASS,"API limit param works as expected");
				}

				else
				{
					failcount++;
					etest.log(Status.FAIL,"API limit param does not work as expected.(Expected chats "+(limit+1)+": Actual Chats : "+JSONResponse.getJSONArray("data").length()+")");
				}
			}

			if(fromtime!=null && totime!=null)
			{
				if(JSONResponse.getJSONArray("data").length()==expected_noofmsgs)
				{
					etest.log(Status.PASS,"API fromtime and totime param works as expected");
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"API fromtime and totime param does not work as expected.(Expected chats "+expected_noofmsgs+": Actual Chats : "+JSONResponse.getJSONArray("data").length()+")");
				}			
			}


			if(limit==-1 && fromtime==null && totime==null) 
			{
				JSONArray data = JSONResponse.getJSONArray("data");

				if(SalesIQRestAPICommonFunctions.checkJSONTranscript(driver,data,etest))
				{
					etest.log(Status.PASS,"API works as expected");
				}

				else
				{
					failcount++;
					etest.log(Status.FAIL,"API does not work as expected");	
				}

			}		

		}

		catch(Exception e)
		{
			failcount++;
			e.printStackTrace();
			etest.log(Status.FAIL,"API could not be verified due to unexpected response structure");
			etest.log(Status.FAIL,"Error:"+e.getMessage());

		}
		finally
		{
			return returnResult(failcount);
		}

	}

	public static String getEmailId(JSONArray visitorlist)
	{
		String email = "";
		try
		{
			for(int i=0;i<visitorlist.length();i++)
			{
				if(visitorlist.getJSONObject(i).has("email"))
				{
					email = visitorlist.getJSONObject(i).get("email").toString();
					break;
				}
			}
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
		}
		return email;
	}

	//visitor history

	public static boolean checkVisitorDetailAPI(WebDriver driver) throws Exception
	{

		int failcount=0;

		try
		{

			driver.navigate().refresh();

			String test_api="";

			test_api=SalesIQRestAPICommonFunctions.customiseAPI(getVisitorDetailsAPI,"-1");

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,test_api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			String test_response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

            etest.log(Status.INFO,"Url:<pre>"+test_api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+test_response+"</pre>");
            
            JSONObject json_response = SalesIQRestAPICommonFunctions.convertToJSON(test_response);

			JSONArray visitorDetails = json_response.getJSONObject("data").getJSONArray("visitorlist");

			SalesIQRestAPICommonFunctions.emailid = getEmailId(visitorDetails);

			etest.info("Email Id : "+SalesIQRestAPICommonFunctions.emailid);

			driver.navigate().refresh();

			String postapi="";

			postapi=SalesIQRestAPICommonFunctions.customiseAPI(postVisitorDetailsAPI);

			String customeInfoKey="KEY_"+getUniqueMessage();
			String customeInfoValue="VALUE"+getUniqueMessage();
			String postObject="{'"+customeInfoKey+"':'"+customeInfoValue+"'}";

			postapi=SalesIQRestAPICommonFunctions.addParam(postapi,"customerinfo",postObject);

			SalesIQRestAPICommonFunctions.configureAPI(driver,"post");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,postapi);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			String postresponse = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

            etest.log(Status.INFO,"Url:<pre>"+postapi+"</pre>");
			etest.log(Status.INFO,"Response:<pre>"+postresponse+"</pre>");

			TakeScreenshot.infoScreenshot(driver,etest);
            
            JSONObject PostJSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(postresponse);

			if(PostJSONResponse.get("data").toString().contains(SalesIQRestAPICommonFunctions.emailid))
			{
				etest.log(Status.PASS,"Success response was recieved for POST request");	
			}
			else
			{
				etest.log(Status.FAIL,"Success response was NOT recieved for POST request");
				failcount++;	
			}

			driver.navigate().refresh();			

			String api="";

			api=SalesIQRestAPICommonFunctions.customiseAPI(getVisitorDetailsAPI,"-1");

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

            etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");
            
            JSONObject JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

			JSONArray visitor_details = JSONResponse.getJSONObject("data").getJSONArray("visitorlist");

			if(SalesIQRestAPICommonFunctions.checkVisitorDetails(driver,SalesIQRestAPICommonFunctions.getJSONObjectByMailId(visitor_details,1),1,etest) && SalesIQRestAPICommonFunctions.checkVisitorDetails(driver,SalesIQRestAPICommonFunctions.getJSONObjectByMailId(visitor_details,2),2,etest))
			{
				etest.log(Status.PASS,"Get visitor details by viewid API was successful for 'All Visitors' view");	
			}

			else
			{
				etest.log(Status.FAIL,"Get visitor details by viewid API was NOT successful for 'All Visitors' view");	
				failcount++;
			}

			if(SalesIQRestAPICommonFunctions.checkPostUpdate(visitor_details,SalesIQRestAPICommonFunctions.emailid,customeInfoKey,customeInfoValue))
			{
				etest.log(Status.PASS,"Data sent by POST Visitor details API was successfully updated");					
			}	

			else
			{
				etest.log(Status.FAIL,"Data sent by POST Visitor details API was NOT successfully updated");	
				failcount++;								
			}

			String startkey="";

			if(isNoOfVisitorsMoreThan100)
			{
				startkey=SalesIQRestAPICommonFunctions.getStartKey(JSONResponse);

				String JSONStringBeforeStartKey=visitor_details.toString();

				driver.navigate().refresh();			

				api=SalesIQRestAPICommonFunctions.customiseAPI(getVisitorDetailsAPI,"-1");

				api=SalesIQRestAPICommonFunctions.addParam(api,"startkey",startkey);

				SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
				SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
				SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

				response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);
                
                etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
                etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");

				JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

				visitor_details = JSONResponse.getJSONObject("data").getJSONArray("visitorlist");

				String JSONStringAfterStartKey=visitor_details.toString();

				if(!JSONStringBeforeStartKey.equals(JSONStringAfterStartKey))
				{
					etest.log(Status.PASS,"JSON Response displayed a different set of visitors after using startkey param");						
				}	

				else
				{
					etest.log(Status.PASS,"Startkey param works as expected");
					failcount++;					
				}			
			}

			driver.navigate().refresh();

			api=SalesIQRestAPICommonFunctions.customiseAPI(getVisitorDetailsAPI,"-2");

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

            etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");
            
            JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

			visitor_details = JSONResponse.getJSONObject("data").getJSONArray("visitorlist");


			if(SalesIQRestAPICommonFunctions.checkVisitorDetails(driver,SalesIQRestAPICommonFunctions.getJSONObjectByMailId(visitor_details,3),3,etest) && SalesIQRestAPICommonFunctions.checkVisitorDetails(driver,SalesIQRestAPICommonFunctions.getJSONObjectByMailId(visitor_details,4),4,etest))
			{
				etest.log(Status.PASS,"Response of Get visitor details by viewid api was successfully verified for 'Returning Visitors' view");	
			}

			else
			{
				etest.log(Status.FAIL,"Get visitor details by viewid was NOT successful for 'Returning Visitors' view");	
				failcount++;
			}	


			driver.navigate().refresh();

			api="";					

			api=SalesIQRestAPICommonFunctions.customiseAPI(getVisitorDetailsAPI,SalesIQRestAPICommonFunctions.viewid);

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

            etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");
            
            JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

			visitor_details = JSONResponse.getJSONObject("data").getJSONArray("visitorlist");

			if(SalesIQRestAPICommonFunctions.checkVisitorDetails(driver,SalesIQRestAPICommonFunctions.getJSONObjectByMailId(visitor_details,1),1,etest) && SalesIQRestAPICommonFunctions.checkVisitorDetails(driver,SalesIQRestAPICommonFunctions.getJSONObjectByMailId(visitor_details,2),2,etest))
			{
				etest.log(Status.PASS,"Get visitor details by viewid API was successful for Custom view");	
			}

			else
			{
				etest.log(Status.FAIL,"Get visitor details by viewid API was NOT successful for Custom view");	
				failcount++;
			}

		}

		catch(Exception e)
		{
			failcount++;
			e.printStackTrace();
			etest.log(Status.FAIL,"API could not be verified due to unexpected response structure");
			etest.log(Status.FAIL,"Error:"+e.getMessage());
		}
		finally
		{
			return returnResult(failcount);
		}

	}

	//attachment

	public static boolean checkAttachmentURLAPI(WebDriver driver) throws Exception
	{

		int failcount=0;

		try
		{
			String
			gifurl = RestAPIConfManager.getRealValue("gifurl"),
			jpgurl = RestAPIConfManager.getRealValue("jpgurl"),
			txturl = RestAPIConfManager.getRealValue("txturl"),
			htmlurl = RestAPIConfManager.getRealValue("htmlurl"),
			pdfurl = RestAPIConfManager.getRealValue("pdfurl")
			;

			if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
			{
				gifurl = RestAPIConfManager.getRealValue("idc_gifurl");
				jpgurl = RestAPIConfManager.getRealValue("idc_jpgurl");
				txturl = RestAPIConfManager.getRealValue("idc_txturl");
				htmlurl = RestAPIConfManager.getRealValue("idc_htmlurl");
				pdfurl = RestAPIConfManager.getRealValue("idc_pdfurl");
			}

			String api="";
			String[] urls={gifurl,jpgurl,txturl,htmlurl,pdfurl};
			String response="";
			JSONObject JSONResponse;
			String download_url="";


			for(int i=0;i<urls.length;i++)
			{

				driver.navigate().refresh();

				api=SalesIQRestAPICommonFunctions.customiseAPI(getAttachmentURLAPI,"",urls[i]);

				SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
				SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
				SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

				response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);
                
                etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
            etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");

				JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

				download_url =  JSONResponse.getJSONObject("data").get("download_url").toString();

				if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(download_url))
				{
					etest.log(Status.PASS,"Download url's response code was 200 for file "+(i+1));
				}

				else
				{
					failcount++;
					etest.log(Status.FAIL,"Download url's(url:"+download_url+") response code was 200 for file "+i);				
				}

			}

			TestResults.put("RESTAPI983",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,ExpectedKeys.GET_ATTACHMENT_URL_V1));

			return returnResult(failcount);
		}

		catch(Exception e)
		{
			failcount++;
			e.printStackTrace();
			etest.log(Status.FAIL,"API could not be verified due to unexpected response structure");
			etest.log(Status.FAIL,"Error:"+e.getMessage());

		}
		finally
		{
			return returnResult(failcount);
		}

	}

	//auth errors

	public static boolean checkAuthorisationErrors(WebDriver driver) throws Exception
	{

		int failcount=0;

		try
		{


			String api="";
			//add "Unknown authentication error, Contact SalesIQ Team!" to the below array if it reproduces for an exact case
			String[] expected_message={"Invalid Request Type","Invalid portal or wrong screenname","Invalid URL","Invalid OAuthToken"};
			String[] apis={getAllChatAPI,getChatDetailsAPI,getChatTranscriptAPI,getAttachmentURLAPI,getVisitorDetailsAPI,postVisitorDetailsAPI};

			String response="";
			JSONObject JSONResponse;
			String errormsg="";

			// String accessToken = "first";
			String accessToken = CommonUtil.getElement(driver,By.id("tkn")).getAttribute("value");

			for(int j=0;j<apis.length;j++)
			{
				for(int i=0;i<expected_message.length;i++)
				{
					if(!(expected_message[i].contains("Invalid Request Type") && apis[j].contains("visitorsbyemail")))
					{
						driver.navigate().refresh();

						api=SalesIQRestAPICommonFunctions.corruptAPI(apis[j],expected_message[i]);
						SalesIQRestAPICommonFunctions.configureCorruptAPI(driver,apis[j],expected_message[i],accessToken);
						SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
						SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

						response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);

						String request_type=SalesIQRestAPICommonFunctions.getRequestTypeFromUI(driver);

						etest.log(Status.INFO,request_type+" Url ("+expected_message[i]+") :<pre>"+api+"</pre>");
                        etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");
                        
                        JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

                        if(SalesIQRestAPICommonFunctions.checkAuthorisationError(JSONResponse,expected_message[i]))
						{
							etest.log(Status.PASS,"Expected error response("+expected_message[i]+") was recieved for api : "+api);
							TakeScreenshot.infoScreenshot(driver,etest);
						}

						else
						{
							failcount++;
							etest.log(Status.FAIL,"Unexpected error response <br>{<br><b style=\"color:red;\">actual:</b>"+SalesIQRestAPICommonFunctions.getErrorMessage(JSONResponse)+" <br><b style=\"color:red;\">expected:</b>"+expected_message[i]+"<br>}<br> was recieved for api : "+api);
							SalesIQRestAPICommonFunctions.log(driver,etest);
						}					
					}

					// if(j == 0 && i == 0)
					// {
					// 	accessToken = CommonUtil.getElement(driver,By.id("tkn")).getAttribute("value");
					// }
				}
			}


			return returnResult(failcount);
		}

		catch(Exception e)
		{
			failcount++;
			e.printStackTrace();
			etest.log(Status.FAIL,"API could not be verified due to unexpected response structure");
			etest.log(Status.FAIL,"Error:"+e.getMessage());
		}
		finally
		{
			return returnResult(failcount);
		}

	}

	//checkGetDepartmentListWithWidgetCodeAPI

	public static boolean checkGetDepartmentListWithWidgetCodeAPI(WebDriver driver) throws Exception
	{
		//new functions

		int failcount=0;

		String[] expected_list_of_departments=RestAPIConfManager.getRealValue("list_of_departments").split(",");

		if((Util.setUptracking().equals("idc")) || (Util.setUptracking().equals("pre")))
		{
			expected_list_of_departments=RestAPIConfManager.getRealValue("idc_list_of_departments").split(",");
		}

		try
		{


			String api="";
			String response="";
			JSONObject JSONResponse;

			driver.navigate().refresh();

			api=SalesIQRestAPICommonFunctions.customiseAPI(getDepartmentListWithWidgetCodeAPI);

			SalesIQRestAPICommonFunctions.configureAPI(driver,"get");
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(driver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(driver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(driver);
	        
	        etest.log(Status.INFO,"Url:<pre>"+api+"</pre>");
	    etest.log(Status.INFO,"Response:<pre>"+response+"</pre>");

			JSONResponse = SalesIQRestAPICommonFunctions.convertToJSON(response);

			JSONArray list_of_departments =  JSONResponse.getJSONArray("data");

			if(SalesIQRestAPICommonFunctions.isAllStringInArrayPresentInJSONArray(list_of_departments,expected_list_of_departments,"list of departments",etest))
			{
				etest.log(Status.PASS,"Get list of departments API works as expected.");
			}

			else
			{
				etest.log(Status.FAIL,"Get list of departments API does NOT work as expected.");				
				failcount++;
			}			

			return returnResult(failcount);
		}

		catch(Exception e)
		{
			failcount++;
			e.printStackTrace();
			etest.log(Status.FAIL,"API could not be verified due to unexpected response structure");
			etest.log(Status.FAIL,"Error:"+e.getMessage());

		}
		finally
		{
			return returnResult(failcount);
		}

	}



	public static String getTest(String key)
	{
		 return KeyManager.getRealValue(key).replace("<","&#60;").replace(">","&#62;");
	}




	//end of test case functions

	public static String getUniqueMessage()
	{
		return ""+new Long(System.currentTimeMillis());
	}

	public static boolean returnResult(int failcount)
	{
		if(failcount>0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
