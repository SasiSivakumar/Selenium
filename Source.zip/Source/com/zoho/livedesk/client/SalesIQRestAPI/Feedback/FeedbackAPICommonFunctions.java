//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.Feedback;

import java.util.Hashtable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.Feedback;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class FeedbackAPICommonFunctions
{
	public static final String[]
	RATING_VALUES = {"happy","neutral","sad"},
	STAR_VALUES = {"1","3","5"}
	;

	public static final String
	ID = "<id>",
	FEEDBACK = "data_feedback",
	RATING = "data_rating",
	VISITOR_NAME = "data_visitor_name",
	VISITOR_EMAIL = "data_visitor_email",
	CONVERSATION_ID = "data_conversation_id"
	;

	public static Hashtable<String,Boolean> checkApi(WebDriver driver,WebDriver api_webdriver,ExtentTest etest,boolean toCheckInUI,String response_code,boolean isReplace,boolean isPayload,Api api_obj,int startKey) throws Exception
	{
		boolean isResponse = (response_code == Constants.SUCCESS_CODE)?true:false;
		JSONObject payload = null;
		String visitorId = "1234567890";

		Hashtable<String,String> infoFromUI = new Hashtable<String,String>();
		Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
		Hashtable<String,String> expectedInfo = new Hashtable<String,String>();

		try
		{
			String
			keys_check_usecase = "RESTAPI" + startKey,
			api_values_usecase = "RESTAPI" + (++startKey),
			ui_values_usecase = "RESTAPI" + (++startKey)
			;

			int randomId = CommonUtil.getRandomId();
			String
			visitorName = "visitorName"+randomId,
			visitorEmail = "visitoremail"+randomId+"@test.com",
			feedback = "testFeedback"+randomId,
			rating = RATING_VALUES[randomId%3],
			starRating = STAR_VALUES[randomId%3]
			;

			if(response_code != Constants.INVALID_SCOPE_ERROR_CODE)
			{
				initiateChat(driver,visitorName,visitorEmail,feedback,starRating,etest);

				infoFromUI = getFeedbackInfo(driver,feedback,etest);

				expectedInfo = getExpectedInfo(feedback,rating,visitorName,visitorEmail);

				visitorId = infoFromUI.get(CONVERSATION_ID);
			}

			String response = SalesIQRestAPICommonFunctions.getJSONResponse(api_webdriver,ExecuteStatements.getPortal(driver),isReplace,ID,visitorId,api_obj,isPayload,payload,etest);

			if(isResponse)
			{
				try
				{
					result.put(keys_check_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED KEYS ARE FOUND</b>");
					if(new JSONObject(response).has("error"))
					{
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(keys_check_usecase,SalesIQRestAPICommonFunctions.isKeysFound(etest,response,api_obj.expected_keys));
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}

				try
				{
					result.put(api_values_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN API RESPONSE</b>");
					if(new JSONObject(response).has("error"))
					{
						etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(api_values_usecase)+" -- failed</b>");
					}
					else
					{
						result.put(api_values_usecase,checkData(expectedInfo,null,keys_check_usecase,response,false,etest));
					}

				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}
			}
			else
			{
				result.put(keys_check_usecase,false);

				String actualResponseCode = "";
				if(new JSONObject(response).has("JSPServerResponse"))
				{
					actualResponseCode = new JSONObject(response).get("code").toString();
				}
				else
				{
					actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				}

				if(CommonUtil.checkStringEqualsAndLog(response_code,actualResponseCode,"response code",etest))
				{
					result.put(keys_check_usecase,true);
					etest.log(Status.PASS,"<b style=\"color:green;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- Success</b>");
				}
				else
				{
					result.put(keys_check_usecase,false);
					etest.log(Status.FAIL,"<b style=\"color:red;\">"+KeyManager.getRealValue(keys_check_usecase)+" -- failed</b>");
				}

				ui_values_usecase = api_values_usecase;
			}

			if((toCheckInUI) && (response_code == Constants.SUCCESS_CODE))
			{
				try
				{

					result.put(ui_values_usecase,false);

					etest.log(Status.INFO,"<b style=\"color:green;\">NOW CHECKING IF EXPECTED VALUES ARE FOUND IN UI</b>");

					result.put(ui_values_usecase,checkData(expectedInfo,infoFromUI,keys_check_usecase,response,true,etest));
					if(!result.get(ui_values_usecase))
					{
						TakeScreenshot.screenshot(driver,etest);
					}
				}
				catch(Exception e1)
				{
					TakeScreenshot.screenshot(api_webdriver,etest);
					TakeScreenshot.screenshot(driver,etest,e1);
					SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}

		return result;
	}

	public static boolean checkData(Hashtable<String,String> expected,Hashtable<String,String> valuesFromUI,String keyToCheck,String response,boolean isUI,ExtentTest etest) throws Exception
	{
		String expected_value,actual_value;

		String[] keysToCheck = RestAPIConfManager.getRealValue(keyToCheck+"_keys").split(",");

		int failcount = 0;
		int index = 0;

        for(int i = 0; i < keysToCheck.length; i++)
        {
        	String apiTestKey = keysToCheck[i];

        	keysToCheck[i] = keysToCheck[i].replace("/feedback_list[0]","").replaceAll("/","_").replace("[0]","");
        	etest.log(Status.INFO,"Checking "+keysToCheck[i]);

        	if(isUI)
        	{
	    		expected_value = expected.get(keysToCheck[i]);
	    		actual_value = valuesFromUI.get(keysToCheck[i]);
	    	}
	    	else
	    	{
	    		actual_value = expected.get(keysToCheck[i]);
	    		expected_value = SalesIQRestAPICommonFunctions.jPath(response,apiTestKey).replaceAll("_","");
	    	}

    		if(expected_value.contains(","))
    		{
    			String[] values = expected_value.replace("]","").replace("[","").split(",");
    			for(String value : values)
    			{
	    			if(!CommonUtil.checkStringContainsAndLog(value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
		    		{
		    			failcount++;
		    		}
    			}
    		}
    		else 
    		{
    			if(!CommonUtil.checkStringContainsAndLog(expected_value,actual_value,"value for key '"+keysToCheck[i]+"' ",etest))
	    		{
	    			failcount++;
	    		}
	    	}
        }

        return CommonUtil.returnResult(failcount);
	}

	public static Hashtable<String,String> getFeedbackInfo(WebDriver driver,String expectedFeedback,ExtentTest etest)
	{
		Hashtable info = new Hashtable<String,String>();

		info.put(CONVERSATION_ID,"40526000001475039"); //random id to avoid exception in checkApi method

		try
		{
			Tab.clickFeedback(driver);
			WebElement latestChat;
			try
			{
				latestChat = Feedback.getFeedbackDiv(driver,expectedFeedback);
			}
			catch(Exception e)
			{
				latestChat = Feedback.getFeedbackDiv(driver,0);
			}

			String id = latestChat.getAttribute("id");

			String
			visitorName = Feedback.getDetails(driver,latestChat,"secnd-clm","h2"),
			visitorEmail = Feedback.getDetails(driver,latestChat,"secnd-clm","a"),
			feedback = Feedback.getDetails(driver,latestChat,"thrd-clm","pre"),
			starRating = Feedback.getStar(driver,latestChat),
			rating = ""
			;

			if((starRating.contains("star-3")) || (starRating.contains("star-4")))
			{
				rating = "neutral";
			}
			else if(starRating.contains("star-5"))
			{
				rating = "happy";
			}
			else if((starRating.contains("star-1")) || (starRating.contains("star-2")))
			{
				rating = "sad";
			}

			info.put(CONVERSATION_ID,id);
			info.put(FEEDBACK,feedback);
			info.put(VISITOR_NAME,visitorName);
			info.put(VISITOR_EMAIL,visitorEmail);
			info.put(RATING,rating);

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
			CommonUtil.printStackTrace(e);
		}

		return info;
	}

	public static Hashtable<String,String> getExpectedInfo(String feedback,String rating,String visitorName,String visitorEmail)
	{
		Hashtable info = new Hashtable<String,String>();

		info.put(FEEDBACK,feedback);
		info.put(VISITOR_NAME,visitorName);
		info.put(VISITOR_EMAIL,visitorEmail);
		info.put(RATING,rating);

		return info;
	}

	public static void initiateChat(WebDriver driver,String visitorName,String visitorEmail,String feedback,String rating,ExtentTest etest)
	{
		WebDriver visitor_driver = null;
		try
		{
			visitor_driver = Functions.setUp();
			String widget_code = ExecuteStatements.getWidgetCode(driver);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitorName,visitorEmail,null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Question from "+visitorName,feedback,rating);

	        etest.log(Status.INFO,"Chat will be initiated with following values.\n"+visitor_details.toString());
			
			ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest);
			TakeScreenshot.screenshot(visitor_driver,etest);
			CommonUtil.printStackTrace(e);
		}
		visitor_driver.quit();
	}

	public static int getJSONIndexWith(JSONArray json_array,String jpath,String value) throws JSONException
	{
		for(int i=0;i<json_array.length();i++)
		{
			JSONObject json=json_array.getJSONObject(i).getJSONObject("conversation");

			if(json.has(jpath) && json.get(jpath).equals(value))
			{
				return i;
			}
		}

		return -1;
	}
}
