//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI.Feedback;

import java.util.Hashtable;

import org.json.JSONObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.SalesIQRestAPI.*;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Trigger;

public class FeedbackAPI
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final String 
	MODULE_NAME = "Rest API"
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

            Cleanup.deleteAllBlockedIP(driver);
            Trigger.deleteAllRule(driver,null);

            WebDriver api_webdriver = Functions.setUp();
			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

            SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"feedback");

            etest = ComplexReportFactory.getEtest("Feedback API -- Check Get List of feedbacks API",MODULE_NAME);
			checkGetListOfFeedbacksAPI(driver,api_webdriver,Constants.SUCCESS_CODE,966,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Feedback API -- Check Get Visitor Feedback of single visitor API",MODULE_NAME);
			checkGetVisitorFeedbackOfSingleVisitorAPI(driver,api_webdriver,Constants.SUCCESS_CODE,968,etest);
			ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"inval");

			etest = ComplexReportFactory.getEtest("Feedback API -- Check Invalid Scope -- Get List of feedbacks API",MODULE_NAME);
			checkGetListOfFeedbacksAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,976,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getEtest("Feedback API -- Check Invalid Scope -- Get Visitor Feedback of single visitor API",MODULE_NAME);
			checkGetVisitorFeedbackOfSingleVisitorAPI(driver,api_webdriver,Constants.INVALID_SCOPE_ERROR_CODE,977,etest);
			ComplexReportFactory.closeTest(etest);

			Driver.quitDriver(api_webdriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module Breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkGetListOfFeedbacksAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(FeedbackAPICommonFunctions.checkApi(driver,api_webdriver,etest,false,response_code,false,false,Api.FEEDBACK_GET_LIST,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}
	public static void checkGetVisitorFeedbackOfSingleVisitorAPI(WebDriver driver,WebDriver api_webdriver,String response_code,int startKey,ExtentTest etest)
	{
		try
		{
			result.putAll(FeedbackAPICommonFunctions.checkApi(driver,api_webdriver,etest,true,response_code,true,false,Api.FEEDBACK_GET,startKey));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(api_webdriver,etest);
			SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
		}
	}

}
