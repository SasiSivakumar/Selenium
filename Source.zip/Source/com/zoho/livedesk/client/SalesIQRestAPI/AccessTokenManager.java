//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;


import com.zoho.livedesk.*;


import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.Augmenter;



import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;

import com.zoho.livedesk.util.common.CommonUtil;

import com.zoho.livedesk.client.AAgentsSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Hashtable;

import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;

import com.zoho.livedesk.util.common.CommonUtil;

import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.SalesIQRestAPI.RestAPIConfManager;

import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

public class AccessTokenManager
{
	public static Hashtable<String,Long> created_times;
	public static Hashtable<String,String> refresh_tokens;

	public static final int TOKEN_EXPIRE_LIMIT_IN_MINS=55;

	public static void init()
	{
		created_times=new Hashtable<String,Long>();
		refresh_tokens=new Hashtable<String,String>();
	}

	public static void add(WebDriver driver)
	{
		String access_token=SalesIQRestAPICommonFunctions.getAccessToken(driver);
		Long created_time=new Long(System.currentTimeMillis());
		String refresh_token=SalesIQRestAPICommonFunctions.getRefreshToken(driver);

		if(access_token.length()<40)
		{
			//Don't add as its an invalid token
			return;
		}

		created_times.put(access_token,created_time);
		refresh_tokens.put(access_token,refresh_token);

		// System.out.println("~~#ATM New access tokens added!!-->\nrefresh_tokens ht-->"+refresh_tokens.toString()+"\n-->created_times ht-->"+created_times);
	}

	public static boolean isRegenerate(WebDriver driver)
	{
		String access_token=SalesIQRestAPICommonFunctions.getAccessToken(driver);
		String refresh_token=SalesIQRestAPICommonFunctions.getRefreshToken(driver);

		if(created_times.containsKey(access_token) && refresh_tokens.containsKey(access_token) && refresh_tokens.get(access_token).equals(refresh_token))
		{
			Long created_time=created_times.get(access_token);

			if(CommonUtil.isTimeout(created_time,TOKEN_EXPIRE_LIMIT_IN_MINS))
			{
				// System.out.println("~~#ATM "+access_token+" access_token was regenerated due to expiry");
				return true;
			}
			else
			{
				// System.out.println("~~#ATM "+access_token+" access_token was NOT regenerated");
				return false;
			}
		}

		// System.out.println("~~#ATM "+access_token+" access_token was regenerated due to untracked");

		return true;
	}
}