//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import java.io.FileInputStream;
import java.util.Properties;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.server.PropertyFileParser;
import com.zoho.livedesk.util.Util;


public class RestAPICredentialManager 
{
    public static PropertyFileParser config_manager=new PropertyFileParser("restapicredentials.properties");

    public static String getRealValue(String key)
    {
        String prefix="";

        if(Util.setUptracking().contains("local") || Util.setUptracking().contains("lab"))
        {
            prefix="local_";
        }
        else
        {
            prefix="idc_";
        }

        return config_manager.getRealValue(prefix+key);
    }

    public static String getRealValueByKey(String key)
    {
        return config_manager.getRealValue(key);
    }

}
