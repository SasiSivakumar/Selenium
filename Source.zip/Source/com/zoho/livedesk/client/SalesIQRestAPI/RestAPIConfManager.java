//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import java.io.FileInputStream;
import java.util.Properties;
import com.zoho.qa.server.WebdriverQAUtil;

public class RestAPIConfManager {

	public static void init()
	{
		try
		{
            System.out.println(WebdriverQAUtil.getAttachmentPath("restapiconf.properties"));
			String serverconf = WebdriverQAUtil.getAttachmentPath("restapiconf.properties");
			Properties prop = getProperties(serverconf);		
        }
		catch(Exception e)
		{}
	}

    public static Properties getProperties(String propsFile)
    {
            try
            {
                    Properties props = new Properties();
                    props.load(new FileInputStream(propsFile));
                    return props;
            }
            catch (Exception exp)
            {
                    return null;
            }
    }
	
    public static String getRealValue(String key)
    {
        String resourcepath =  WebdriverQAUtil.getAttachmentPath("restapiconf.properties");
        Properties prop = getProperties(resourcepath);
    
        try
        {
            if(resourcepath.contains("null"))
            {
                resourcepath = resourcepath.replace("null","salesiq");
                prop = getProperties(resourcepath);
            }
            String val = null;
            val = prop.getProperty(key,val);
            if(val != null)
            {
                return val;
            }
        }
        catch(Exception e){}
        return key;
    }
}
