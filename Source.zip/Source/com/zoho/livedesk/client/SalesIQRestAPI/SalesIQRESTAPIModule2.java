//$Id$
package com.zoho.livedesk.client.SalesIQRestAPI;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.AgentsSettings;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.Department;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.zoho.livedesk.util.BuildRejector;

public class SalesIQRESTAPIModule2
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Rest API";
	public static String portal_name = "";

	public static final String
	SUCCESS_CODE = "204",
	operation_failed_error_code = "1000",
	operation_failed_error_message = "Operation Failed",
	invalid_scope_error_code = "1009",
	invalid_scope_error_message = "Invalid OAuthScope",
	invalid_request_parameters_error_code = "1011",
	invalid_request_parameters_error_message = "Either the request parameters are invalid or absent",
	resource_already_exists_error_code = "1014",
	resource_already_exists_error_message = "Resource already exists",
	access_denied_error_code = "1016",
	access_denied_error_message = "Operator doesn't have the permission to perform the operation",
	operator_not_associated_error_code = "1034",
	operator_not_associated_error_message = "Operation failed  to meet criteria"
	;

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			Cleanup.deleteAllDeparmentsExcept(driver,null);

			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();


			WebDriver api_driver=Functions.setUp();
			api_driver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"main");

			etest=ComplexReportFactory.getTest("Get All Portals API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkPortalListAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);
                        

			etest=ComplexReportFactory.getTest("Get Portal API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkPortalInfoAPI(api_driver,driver,etest,Api.PORTAL_GET);
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest("Update Portal API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkPortalInfoAPI(api_driver,driver,etest,Api.PORTAL_UPDATE);
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest("Update Portal Owner API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			changePortalOwner(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Portal Owner API from Non Owner Credentials");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			changePortalOwnerFromNonOwner(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Portal API from Associate Credentials");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updatePortalInfoFromAssociate(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"main");

			etest=ComplexReportFactory.getTest("Get All Departments API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDepartmentListAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Get Departments Info API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDepartmentAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Department Info API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateDepartmentAPI(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Update Department Info API from Associate Credentials");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			updateDepartmentAPIFromAssociate(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);

			SalesIQRestAPICommonFunctions.setAuth(api_driver,"main");


			etest=ComplexReportFactory.getTest("Create Department API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createDepartmentAPI(api_driver,driver,etest,NORMAL);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Private Department API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createDepartmentAPI(api_driver,driver,etest,PRIVATE_DEPARTMENT);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Department Without Email Configuration API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createDepartmentAPI(api_driver,driver,etest,WITHOUT_EMAIL_CONFIGURATION);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Create Department With Name of Existing Department");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			createDepartmentAPI(api_driver,driver,etest,EXISTING_DEPARTMENT);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Delete department from API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteDepartmentAPI(api_driver,driver,etest,false,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Delete department from API by passing the department id of department to be deleted in the configure_to param");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			deleteDepartmentAPI(api_driver,driver,etest,true,false);
            ComplexReportFactory.closeTest(etest);

   //          IF THIS TEST FAILS, PORTAL WILL BE CORRUPTED
			// etest=ComplexReportFactory.getTest("Delete System Generated Department From API");
			// ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			// deleteDepartmentAPI(api_driver,driver,etest,false,true);
   //          ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Enable Department API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			toggleDepartment(api_driver,driver,etest,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Disable Department API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			toggleDepartment(api_driver,driver,etest,false);
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest("Add/Remove Operators From Department using API");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			addRemoveOperators(api_driver,driver,etest);
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest("Setting an invalid scope for invalid API scope usecases");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			setInvalidAuth(api_driver,etest);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI64"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI64",checkInvalidScope(api_driver,driver,etest,Api.PORTAL_GET_LIST));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI65"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI65",checkInvalidScope(api_driver,driver,etest,Api.PORTAL_GET));
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI66"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI66",checkInvalidScope(api_driver,driver,etest,Api.PORTAL_UPDATE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI67"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI67",checkInvalidScope(api_driver,driver,etest,Api.PORTAL_OWNER_UPDATE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI68"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI68",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_GET_LIST));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI69"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI69",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_GET));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI70"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI70",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_UPDATE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI71"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI71",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_DELETE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI72"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI72",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_CREATE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI73"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI73",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_ENABLE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI74"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI74",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_DISABLE));
            ComplexReportFactory.closeTest(etest);
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI75"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI75",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_ADD_OPERATOR));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RESTAPI76"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("RESTAPI76",checkInvalidScope(api_driver,driver,etest,Api.DEPARTMENT_REMOVE_OPERATOR));
            ComplexReportFactory.closeTest(etest);

            Driver.quitDriver(api_driver);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			//BuildRejector.analyse(result,"Failures in REST API module");
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}            
	}

	public static void setInvalidAuth(WebDriver api_driver,ExtentTest etest)
	{
		try
		{
			etest.log(Status.INFO,"Auth credentials before");
			SalesIQRestAPICommonFunctions.log(api_driver,etest);
			SalesIQRestAPICommonFunctions.setAuth(api_driver,"inval");
			etest.log(Status.PASS,"Invalid scope auth was configured");
			SalesIQRestAPICommonFunctions.log(api_driver,etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FAIL,"Invalid scope auth NOT was configured");
			TakeScreenshot.screenshot(api_driver,etest,e);
			e.printStackTrace();
		}
	}

	public static void createPortalAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();

		Api create_portal_api=Api.PORTAL_CREATE;

		String api=create_portal_api.get();

		JSONObject payload=GetPayload.getCreatePortalPayload(label,label+" Portal Description");
		etest.log(Status.INFO,"Below json will be used as payload");
		SalesIQRestAPICommonFunctions.log(etest,payload);


		api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
		SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_portal_api);
		SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
		SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
		SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

		String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

		JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

		etest.log(Status.PASS,"json_response-->"+json_response.toString());
	}

	public static void checkPortalListAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			Api get_portal_list_api=Api.PORTAL_GET_LIST;
			String api=get_portal_list_api.get();

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_portal_list_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			result.put("RESTAPI18",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_portal_list_api.expected_keys));
			
			JSONArray portals=SalesIQRestAPICommonFunctions.getArray(response,JPaths.PORTALS_ARRAY);


			ArrayList<String> associated_portals=PortalConfig.getAssociatedPortals(driver);

			int associated_portals_failcount=0;

			for(String associated_portal : associated_portals)
			{
				if(SalesIQRestAPICommonFunctions.getJSONWith(portals,APIKeys.PORTAL_NAME_GET_PORTALS_LIST,associated_portal)!=null)
				{
					etest.log(Status.PASS,"Portal '"+associated_portal+"' was found in APIs response.");
				}
				else
				{
					etest.log(Status.FAIL,"Portal '"+associated_portal+"' was NOT found in APIs response.");
					SalesIQRestAPICommonFunctions.log(etest,portals.toString());
					associated_portals_failcount++;
				}
			}

			result.put("RESTAPI15",CommonUtil.returnResult(associated_portals_failcount));

			String expected_portal=ExecuteStatements.getPortal(driver);

			JSONObject current_portal_info=SalesIQRestAPICommonFunctions.getJSONWith(portals,APIKeys.PORTAL_NAME_GET_PORTALS_LIST,expected_portal);
		
			if(current_portal_info==null)
			{
				etest.log(Status.FAIL,"Portal "+expected_portal+" was not found in the response.");
				SalesIQRestAPICommonFunctions.log(etest,response);
			}

			if( CommonUtil.checkStringEqualsAndLog( ExecuteStatements.getPortalOwnerId(driver) , current_portal_info.getString(APIKeys.OPERATOR_ID) , APIKeys.OPERATOR_ID , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( ExecuteStatements.getPortal(driver) , current_portal_info.getString(APIKeys.PORTAL_NAME_GET_PORTALS_LIST) , APIKeys.PORTAL_NAME_GET_PORTALS_LIST , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( ExecuteStatements.getPortalCreatedTime(driver) , current_portal_info.getString(APIKeys.CREATED_TIME) , APIKeys.CREATED_TIME , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( ExecuteStatements.getPortalOwnerZUID(driver) , current_portal_info.getString(APIKeys.OWNER_ZUID) , APIKeys.OWNER_ZUID , etest ) == false)
			{
				failcount++;
			}

			result.put("RESTAPI16",CommonUtil.returnResult(failcount));

			String logo_download_url=current_portal_info.getString(APIKeys.LOGO);
			logo_download_url=SalesIQRestAPICommonFunctions.getAPIURL(logo_download_url);

			if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(logo_download_url))
			{
				etest.log(Status.PASS,APIKeys.LOGO+" was found with success response code.");
				result.put("RESTAPI17",true);
			}
			else
			{
				result.put("RESTAPI17",false);
				etest.log(Status.FAIL,APIKeys.LOGO+" was NOT found with success response code.");
				SalesIQRestAPICommonFunctions.log(etest,current_portal_info.toString());
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void checkPortalInfoAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,Api api_under_test)
	{
		String label=CommonUtil.getUniqueMessage();

		final String
		name="name"+label,
		website="www."+label+".com",
		address="address"+label,
		email=label+"@email.com",
		phone=label,
		fax="123-"+label,
		language="English",
		expected_language_in_response="en",
		timezone="Asia/Calcutta",
		description="we are company "+label
		;

		try
		{
			if(api_under_test.equals(Api.PORTAL_GET))
			{
				// // to make sure description is set properly
				// Tab.navToCompTab(driver);
				// for(int i=0;i<=3;i++)
				// {
				// 	CommonUtil.sleep(5000);
				// 	// Company.setCompanyInfoBy(description,driver,etest,Company.COMPANY_DESCRIPTION_INPUT);
				// 	Company.setCompanyInfo(driver,etest,name,website,address,email,phone,fax,null,null,description);
				// 	Company.setCompanyInfoBy(description,driver,etest,Company.COMPANY_DESCRIPTION_INPUT);
				// }

				Company.setCompanyInfo(driver,etest,name,website,address,email,null,null,null,null,null);

				// this is to wait for a minute to get rid of the ip lock in upcompanyinfo call
				CommonUtil.sleep(90000);
				Company.setCompanyInfo(driver,etest,null,null,null,null,phone,fax,language,timezone,description);
			}
			else if(api_under_test.equals(Api.PORTAL_UPDATE))
			{
				String api=api_under_test.get();
				api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

				JSONObject payload=GetPayload.getUpdatePortalPayload(name,phone,website,fax,timezone,description,expected_language_in_response,address,email);
				etest.log(Status.INFO,"Below json will be used as payload");
				SalesIQRestAPICommonFunctions.log(etest,payload);

				api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

				SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,api_under_test);
				SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
				SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
				SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

				String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
				SalesIQRestAPICommonFunctions.log(etest,response);

				result.put("RESTAPI23",isCompanySettingsFound(driver,etest,api_under_test,response,website,fax,email,expected_language_in_response,phone,address,description,timezone,name));
				result.put("RESTAPI24",isCompanySettingsFoundInUI(driver,etest,response));
			}


			Api get_portal_api=Api.PORTAL_GET;
			String api=get_portal_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_portal_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);
			TakeScreenshot.infoScreenshot(api_webdriver,etest);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			result.put("RESTAPI19",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_portal_api.expected_keys));

			result.put("RESTAPI22",isCompanySettingsFound(driver,etest,api_under_test,response,website,fax,email,expected_language_in_response,phone,address,description,timezone,name));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void updatePortalInfoFromAssociate(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		String label=CommonUtil.getUniqueMessage();

		final String
		name="name"+label,
		website="www."+label+".com",
		address="address"+label,
		email=label+"@email.com",
		phone=label,
		fax="123-"+label,
		language="English",
		expected_language_in_response="en",
		timezone="Asia/Calcutta",
		description="description"+label
		;

		try
		{
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"asso");

			String api=Api.PORTAL_UPDATE.get();

			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver)); 

			JSONObject payload=GetPayload.getUpdatePortalPayload(name,phone,website,fax,timezone,description,expected_language_in_response,address,email);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,Api.PORTAL_UPDATE);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(CommonUtil.checkStringEqualsAndLog(access_denied_error_code,new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString(),"response code",etest) && 
				CommonUtil.checkStringEqualsAndLog(access_denied_error_message,new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString(),"response message",etest))
			{
				etest.log(Status.PASS,"Access denied response was received for update portal API when associate credentials were provided");
				result.put("RESTAPI25",true);
			}
			else
			{
				result.put("RESTAPI25",false);
				etest.log(Status.FAIL,"Access denied response was not received for update portal API when associate credentials were provided");
				TakeScreenshot.screenshot(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{	
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void changePortalOwner(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		String label=CommonUtil.getUniqueMessage();

		WebDriver driver2=null;

		try
		{
			driver2=Functions.setUp();
			Functions.login(driver2,"restapi2");

			WebDriver owner_driver=null,admin_driver=null;

			String owner_credentials_key=null,new_owner_id=null,new_owner_username=null;

			if(ExecuteStatements.isOwner(driver))
			{
				owner_driver=driver;
				admin_driver=driver2;
				owner_credentials_key="main";
				new_owner_id=ExecuteStatements.getOperatorId(driver2);
				new_owner_username=ExecuteStatements.getUserName(driver2);
			}
			else if(ExecuteStatements.isOwner(driver2))
			{
				owner_driver=driver2;
				admin_driver=driver;
				owner_credentials_key="admin";
				new_owner_id=ExecuteStatements.getOperatorId(driver);
				new_owner_username=ExecuteStatements.getUserName(driver);
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Both the drivers are not owners. One must be owner and one must be admin");
			}

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,owner_credentials_key);

			String api=Api.PORTAL_OWNER_UPDATE.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(owner_driver)); 

			JSONObject payload=GetPayload.getChangePortalOwnerPayload(new_owner_id);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,Api.PORTAL_OWNER_UPDATE);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			SalesIQRestAPICommonFunctions.log(etest,response);

			String actualResponseCode = "";
			if(new JSONObject(response).has("error"))
			{
				actualResponseCode = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
			}
			else
			{
				actualResponseCode = new JSONObject(response).get("code").toString();
			}

			result.put("RESTAPI77",CommonUtil.checkStringEqualsAndLog(SUCCESS_CODE,actualResponseCode,"response code",etest));

			String current_owner=PortalConfig.getCurrentPortalOwner(owner_driver);

			result.put("RESTAPI78",CommonUtil.checkStringEqualsAndLog(new_owner_username,current_owner,"new owner",etest));

			Api get_portal_list_api=Api.PORTAL_GET_LIST;
			api=get_portal_list_api.get();

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_portal_list_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			String current_portal=ExecuteStatements.getPortal(owner_driver);
			JSONArray portals=SalesIQRestAPICommonFunctions.getArray(response,JPaths.PORTALS_ARRAY);

			JSONObject current_portal_info=SalesIQRestAPICommonFunctions.getJSONWith(portals,APIKeys.PORTAL_NAME_GET_PORTALS_LIST,current_portal);		
			result.put("RESTAPI79",CommonUtil.checkStringEqualsAndLog( new_owner_id , current_portal_info.getString(APIKeys.OPERATOR_ID) , APIKeys.OPERATOR_ID , etest ));
		}
		catch(Exception e)
		{	
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			Driver.quitDriver(driver2);
		}	
	}

	public static void changePortalOwnerFromNonOwner(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		String label=CommonUtil.getUniqueMessage();

		WebDriver driver2=null;

		try
		{
			driver2=Functions.setUp();
			Functions.login(driver2,"restapi2");

			CommonUtil.refreshPage(driver);

			WebDriver owner_driver=null,admin_driver=null;

			String admin_credentials_key=null,new_owner_id=null,new_owner_username=null;

			if(ExecuteStatements.isOwner(driver))
			{
				owner_driver=driver;
				admin_driver=driver2;
				admin_credentials_key="admin";
				new_owner_id=ExecuteStatements.getOperatorId(admin_driver);
				new_owner_username=ExecuteStatements.getUserName(admin_driver);
			}
			else if(ExecuteStatements.isOwner(driver2))
			{
				owner_driver=driver2;
				admin_driver=driver;
				admin_credentials_key="main";
				new_owner_id=ExecuteStatements.getOperatorId(admin_driver);
				new_owner_username=ExecuteStatements.getUserName(admin_driver);
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Both the drivers are not owners. One must be owner and one must be admin");
			}

			etest.log(Status.INFO,"Owner-->"+ExecuteStatements.getUserName(owner_driver)+"----"+ExecuteStatements.getOperatorId(owner_driver));
			etest.log(Status.INFO,"Admin-->"+ExecuteStatements.getUserName(admin_driver)+"----"+ExecuteStatements.getOperatorId(admin_driver));

			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,admin_credentials_key);

			String api=Api.PORTAL_OWNER_UPDATE.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(owner_driver)); 

			JSONObject payload=GetPayload.getChangePortalOwnerPayload(new_owner_id);

			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);

			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,Api.PORTAL_OWNER_UPDATE);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(CommonUtil.checkStringEqualsAndLog(access_denied_error_code,new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString(),"response code",etest) && 
				CommonUtil.checkStringEqualsAndLog(access_denied_error_message,new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString(),"response message",etest))
			{
				etest.log(Status.PASS,"Expected messsage and code was found in the response");
				result.put("RESTAPI80",true);
			}
			else
			{
				etest.log(Status.FAIL,"Expected messsage and code was not found in the response");
				result.put("RESTAPI80",false);
			}
		}
		catch(Exception e)
		{	
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			Driver.quitDriver(driver2);
		}	
	}

	public static boolean isCompanySettingsFound(WebDriver driver,ExtentTest etest,Api api_under_test,String response,String website,String fax,String email,String expected_language_in_response,String phone,String address,String description,String timezone,String name) throws Exception
	{
		int failcount=0;

		if( CommonUtil.checkStringEqualsAndLog( website , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_WEBSITE) , JPaths.PORTAL_WEBSITE , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( fax , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_FAX) , JPaths.PORTAL_FAX , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( email , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_EMAIL) , JPaths.PORTAL_EMAIL , etest ) == false)
		{
			failcount++;
		}

		String logo_download_url=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_LOGO);
		logo_download_url=SalesIQRestAPICommonFunctions.getAPIURL(logo_download_url);

		if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(logo_download_url))
		{
			etest.log(Status.PASS,APIKeys.LOGO+" was found with success response code.");

			if(api_under_test.equals(Api.PORTAL_GET))
			{
				result.put("RESTAPI20",true);
			}
		}
		else
		{
			if(api_under_test.equals(Api.PORTAL_GET))
			{
				result.put("RESTAPI20",false);
			}

			etest.log(Status.FAIL,APIKeys.LOGO+" was NOT found with success response code.");
			SalesIQRestAPICommonFunctions.log(etest,response);
		}

		if( CommonUtil.checkStringEqualsAndLog( expected_language_in_response , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_LANGUAGE) , JPaths.PORTAL_LANGUAGE , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( phone , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_PHONE) , JPaths.PORTAL_PHONE , etest ) == false)
		{
			failcount++;
		}

		String icon_download_url=SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_ICON);
		icon_download_url=SalesIQRestAPICommonFunctions.getAPIURL(icon_download_url);

		if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(icon_download_url))
		{
			etest.log(Status.PASS,APIKeys.ICON+" was found with success response code.");
			result.put("RESTAPI21",true);
		}
		else
		{
			result.put("RESTAPI21",false);
			etest.log(Status.FAIL,APIKeys.ICON+" was NOT found with success response code.");
			SalesIQRestAPICommonFunctions.log(etest,response);
		}

		if( CommonUtil.checkStringEqualsAndLog( ExecuteStatements.getPortal(driver) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_SCREENNAME) , JPaths.PORTAL_SCREENNAME , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( address , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_ADDRESS) , JPaths.PORTAL_ADDRESS , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( description , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_DESCRIPTION) , JPaths.PORTAL_DESCRIPTION , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringContainsAndLog( SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_TIMEZONE), timezone , JPaths.PORTAL_TIMEZONE , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( name , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_COMPANY_NAME) , JPaths.PORTAL_COMPANY_NAME , etest ) == false)
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean isCompanySettingsFoundInUI(WebDriver driver,ExtentTest etest,String response) throws Exception
	{
		int failcount=0;

		Hashtable<String,String> company_settings=Company.getCompanyInfo(driver);


		if( CommonUtil.checkStringEqualsAndLog( company_settings.get(Company.WEBSITE) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_WEBSITE) , JPaths.PORTAL_WEBSITE , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( company_settings.get(Company.FAX) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_FAX) , JPaths.PORTAL_FAX , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( company_settings.get(Company.EMAIL) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_EMAIL) , JPaths.PORTAL_EMAIL , etest ) == false)
		{
			failcount++;
		}


		String expected_langauge=null;

		if(company_settings.get(Company.LANGUAGE).contains("English"))
		{
			expected_langauge="en";
		}

		if( CommonUtil.checkStringEqualsAndLog( expected_langauge , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_LANGUAGE) , JPaths.PORTAL_LANGUAGE , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( company_settings.get(Company.PHONE) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_PHONE) , JPaths.PORTAL_PHONE , etest ) == false)
		{
			failcount++;
		}


		if( CommonUtil.checkStringEqualsAndLog( company_settings.get(Company.ADDRESS) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_ADDRESS) , JPaths.PORTAL_ADDRESS , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringEqualsAndLog( company_settings.get(Company.DESCRIPTION) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_DESCRIPTION) , JPaths.PORTAL_DESCRIPTION , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringContainsAndLog( SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_TIMEZONE), company_settings.get(Company.TIMEZONE) , JPaths.PORTAL_TIMEZONE , etest ) == false)
		{
			failcount++;
		}

		if( CommonUtil.checkStringContainsAndLog( company_settings.get(Company.NAME) , SalesIQRestAPICommonFunctions.jPath(response,JPaths.PORTAL_COMPANY_NAME) , JPaths.PORTAL_COMPANY_NAME , etest ) == false)
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	//Department
	public static void checkDepartmentListAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		final String
		name="dept"+label,
		description="desc"+label,
		from_mail="from"+label+"@email.com",
		missedmail="missedmail"+label+"@email.com",
		fbmail="fbmail"+label+"@email.com",
		ccmail="ccmail"+label+"@email.com",
		transmail="transmail"+label+"@email.com",
		blockmail="blockmail"+label+"@email.com"
		;

		final boolean
		isEnabled=true,
		isPublic=true,
		isMissed=true,
		isFeedback=true,
		isCC=true,
		isTranscript=true,
		isBlock=true
		;

		try
		{

			String expected_deparment=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String dept_id=ExecuteStatements.getDepartmentId(driver,expected_deparment);


			Department.setDepartmentInfo(driver,etest,dept_id,isEnabled,name,isPublic,description,from_mail,isMissed,missedmail,isFeedback,fbmail,isCC,ccmail,isTranscript,transmail,isBlock,blockmail);

			//as we have changed the name
			expected_deparment=name;

			CommonUtil.sleep(10000);

			Api get_deparment_list_api=Api.DEPARTMENT_GET_LIST;
			String api=get_deparment_list_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_deparment_list_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			result.put("RESTAPI26",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_deparment_list_api.expected_keys));
			
			JSONArray deparments=SalesIQRestAPICommonFunctions.getArray(response,JPaths.DEPARTMENTS_ARRAY);

			ArrayList<String> deparment_names=Department.getDepartments(driver);

			int deparments_failcount=0;

			for(String deparment : deparment_names)
			{
				if(SalesIQRestAPICommonFunctions.getJSONWith(deparments,APIKeys.DEPARTMENT_NAME,deparment)!=null)
				{
					etest.log(Status.PASS,"deparment '"+deparment+"' was found in APIs response.");
				}
				else
				{
					etest.log(Status.FAIL,"deparment '"+deparment+"' was NOT found in APIs response.");
					SalesIQRestAPICommonFunctions.log(etest,deparments.toString());
					deparments_failcount++;
				}
			}

			result.put("RESTAPI27",CommonUtil.returnResult(deparments_failcount));


			JSONObject current_deparment_info=SalesIQRestAPICommonFunctions.getJSONWith(deparments,APIKeys.DEPARTMENT_NAME,expected_deparment);
		
			if(current_deparment_info==null)
			{
				etest.log(Status.FAIL,"deparment "+expected_deparment+" was not found in the response.");
				SalesIQRestAPICommonFunctions.log(etest,response);
			}

			if( CommonUtil.checkStringEqualsAndLog( dept_id , current_deparment_info.getString(APIKeys.DEPT_ID) , APIKeys.DEPT_ID , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( ""+isEnabled , current_deparment_info.getString(APIKeys.DEPT_IS_ENABLED) , APIKeys.DEPT_IS_ENABLED , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( ""+isPublic , current_deparment_info.getString(APIKeys.DEPT_IS_PUBLIC) , APIKeys.DEPT_IS_PUBLIC , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( ""+true , current_deparment_info.getString(APIKeys.IS_SYSTEM_DEPT) , APIKeys.IS_SYSTEM_DEPT , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( description , current_deparment_info.getString(APIKeys.DESCRIPTION) , APIKeys.DESCRIPTION , etest ) == false)
			{
				failcount++;
			}

			if( CommonUtil.checkStringEqualsAndLog( expected_deparment , current_deparment_info.getString(APIKeys.DISPLAY_NAME) , APIKeys.DISPLAY_NAME , etest ) == false)
			{
				failcount++;
			}

			result.put("RESTAPI28",CommonUtil.returnResult(failcount));

			String image_url=current_deparment_info.getString(APIKeys.IMAGE_URL);
			image_url=SalesIQRestAPICommonFunctions.getAPIURL(image_url);

			if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(image_url))
			{
				etest.log(Status.PASS,APIKeys.IMAGE_URL+" was found with success response code.");
				result.put("RESTAPI29",true);
			}
			else
			{
				result.put("RESTAPI29",false);
				etest.log(Status.FAIL,APIKeys.IMAGE_URL+" was NOT found with success response code.");
				SalesIQRestAPICommonFunctions.log(etest,current_deparment_info.toString());
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void checkDepartmentAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		final String
		name="dept"+label,
		description="desc"+label,
		from_mail="from"+label+"@email.com",
		missedmail="missedmail"+label+"@email.com",
		fbmail="fbmail"+label+"@email.com",
		ccmail="ccmail"+label+"@email.com",
		transmail="transmail"+label+"@email.com",
		blockmail="blockmail"+label+"@email.com"
		;

		final boolean
		isEnabled=true,
		isPublic=true,
		isMissed=true,
		isFeedback=true,
		isCC=true,
		isTranscript=true,
		isBlock=true
		;

		try
		{

			String expected_deparment=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String dept_id=ExecuteStatements.getDepartmentId(driver,expected_deparment);


			Department.setDepartmentInfo(driver,etest,dept_id,isEnabled,name,isPublic,description,from_mail,isMissed,missedmail,isFeedback,fbmail,isCC,ccmail,isTranscript,transmail,isBlock,blockmail);

			//as we have changed the name
			expected_deparment=name;

			CommonUtil.sleep(10000);

			Api get_deparment_api=Api.DEPARTMENT_GET;
			String api=get_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",dept_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			result.put("RESTAPI32",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,get_deparment_api.expected_keys));

			result.put("RESTAPI30",isDepartmentSettingsFound(driver,etest,response));

			String image_url=jPath(response,JPaths.DEPT_IMAGE_URL);
			image_url=SalesIQRestAPICommonFunctions.getAPIURL(image_url);

			if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(image_url))
			{
				etest.log(Status.PASS,APIKeys.IMAGE_URL+" was found with success response code.");
				result.put("RESTAPI31",true);
			}
			else
			{
				result.put("RESTAPI31",false);
				etest.log(Status.FAIL,APIKeys.IMAGE_URL+" was NOT found with success response code.");
				SalesIQRestAPICommonFunctions.log(etest,response.toString());
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void updateDepartmentAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		final String
		name="dept"+label,
		description="desc"+label,
		from_mail="from"+label+"@email.com",
		missedmail="missedmail"+label+"@email.com",
		fbmail="fbmail"+label+"@email.com",
		ccmail="ccmail"+label+"@email.com",
		transmail="transmail"+label+"@email.com",
		blockmail="blockmail"+label+"@email.com"
		;

		final boolean
		isEnabled=true,
		isPublic=true,
		isMissed=true,
		isFeedback=true,
		isCC=true,
		isTranscript=true,
		isBlock=true
		;

		try
		{
			String expected_deparment=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String dept_id=ExecuteStatements.getDepartmentId(driver,expected_deparment);
			String operator_id=ExecuteStatements.getOperatorId(driver);

			JSONObject payload=GetPayload.getUpdateDepartmentPayload(name,""+isPublic,description,null,from_mail,""+isTranscript,transmail,""+isBlock,blockmail,""+isFeedback,fbmail,""+isMissed,missedmail,""+isCC,ccmail);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			//update from API and check from response,
			Api update_deparment_api=Api.DEPARTMENT_UPDATE;
			String api=update_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",dept_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			etest.log(Status.INFO,"Now checking if all keys are found");
			result.put("RESTAPI33",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,update_deparment_api.expected_keys));
			etest.log(Status.INFO,"Now verifying all values in response");
			result.put("RESTAPI34",isDepartmentSettingsFoundInResponse(driver,etest,response,name,""+isPublic,""+isEnabled,description,""+true,from_mail,""+isMissed,missedmail,""+isCC,ccmail,""+isTranscript,transmail,""+isFeedback,fbmail,""+isBlock,blockmail));
			etest.log(Status.INFO,"Now check if updated values are found in UI");
			result.put("RESTAPI35",isDepartmentSettingsFound(driver,etest,response));

			String image_url=jPath(response,JPaths.DEPT_IMAGE_URL);
			image_url=SalesIQRestAPICommonFunctions.getAPIURL(image_url);

			if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(image_url))
			{
				etest.log(Status.PASS,APIKeys.IMAGE_URL+" was found with success response code.");
				result.put("RESTAPI37",true);
			}
			else
			{
				result.put("RESTAPI37",false);
				etest.log(Status.FAIL,APIKeys.IMAGE_URL+" was NOT found with success response code.");
				SalesIQRestAPICommonFunctions.log(etest,response.toString());
			}

			etest.log(Status.INFO,"Now checking if updated values are found in get department info API");

			//as we have changed the name
			expected_deparment=name;

			//checking if updated values found in get dept info API
			Api get_deparment_api=Api.DEPARTMENT_GET;
			api=get_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",dept_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			etest.log(Status.INFO,"Below json is the respons");
			SalesIQRestAPICommonFunctions.log(etest,response);

			result.put("RESTAPI36",isDepartmentSettingsFoundInResponse(driver,etest,response,name,""+isPublic,""+isEnabled,description,""+true,from_mail,""+isMissed,missedmail,""+isCC,ccmail,""+isTranscript,transmail,""+isFeedback,fbmail,""+isBlock,blockmail));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void updateDepartmentAPIFromAssociate(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		final String
		name="dept"+label,
		description="desc"+label,
		from_mail="from"+label+"@email.com",
		missedmail="missedmail"+label+"@email.com",
		fbmail="fbmail"+label+"@email.com",
		ccmail="ccmail"+label+"@email.com",
		transmail="transmail"+label+"@email.com",
		blockmail="blockmail"+label+"@email.com"
		;

		final boolean
		isEnabled=true,
		isPublic=true,
		isMissed=true,
		isFeedback=true,
		isCC=true,
		isTranscript=true,
		isBlock=true
		;

		try
		{
			SalesIQRestAPICommonFunctions.setAuth(api_webdriver,"asso");

			String expected_deparment=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String dept_id=ExecuteStatements.getDepartmentId(driver,expected_deparment);
			String operator_id=ExecuteStatements.getOperatorId(driver);

			JSONObject payload=GetPayload.getUpdateDepartmentPayload(name,""+isPublic,description,null,from_mail,""+isTranscript,transmail,""+isBlock,blockmail,""+isFeedback,fbmail,""+isMissed,missedmail,""+isCC,ccmail);
			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			//update from API and check from response,
			Api update_deparment_api=Api.DEPARTMENT_UPDATE;
			String api=update_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",dept_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,update_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(CommonUtil.checkStringEqualsAndLog(access_denied_error_code,new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString(),"response code",etest) && 
				CommonUtil.checkStringEqualsAndLog(access_denied_error_message,new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString(),"response message",etest))
			{
				etest.log(Status.PASS,"Response was not received for update department API when associate credentials were provided");
				result.put("RESTAPI38",true);
			}
			else
			{
				result.put("RESTAPI38",false);
				etest.log(Status.FAIL,"Response was received for update department API when associate credentials were provided");
				TakeScreenshot.screenshot(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static boolean isDepartmentSettingsFoundInResponse(WebDriver driver,ExtentTest etest,String response,String name,String is_public,String is_enabled,String description,String is_system_generated,String from_mail,String is_missed,String missed,String is_cc,String cc,String is_transcript,String transcript,String is_feedback,String feedback,String is_blocked,String blocked) throws Exception
	{
		String department_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.DEPT_ID);

		Hashtable<String,String> dept_info=Department.getDepartmentInfo(driver,department_id);

		int failcount=0;

		if(CommonUtil.checkStringEqualsAndLog( name , jPath(response,JPaths.DEPT_NAME) , JPaths.DEPT_NAME , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog(is_public  , jPath(response,JPaths.DEPT_IS_PUBLIC) , JPaths.DEPT_IS_PUBLIC , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( is_enabled , jPath(response,JPaths.DEPT_IS_ENABLED) , JPaths.DEPT_IS_ENABLED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog(description, jPath(response,JPaths.DEPT_DESCRIPTION) , JPaths.DEPT_DESCRIPTION , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( is_system_generated , jPath(response,JPaths.DEPT_SYSTEM_GENERATED) , JPaths.DEPT_SYSTEM_GENERATED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( from_mail , jPath(response,JPaths.DEPT_FROM_MAIL) , JPaths.DEPT_FROM_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( is_missed, jPath(response,JPaths.DEPT_IS_MISSED) , JPaths.DEPT_IS_MISSED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( missed , jPath(response,JPaths.DEPT_MISSED_MAIL) , JPaths.DEPT_MISSED_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog(is_cc , jPath(response,JPaths.DEPT_IS_CC) , JPaths.DEPT_IS_CC , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog(cc , jPath(response,JPaths.DEPT_CC_MAIL) , JPaths.DEPT_CC_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( is_transcript, jPath(response,JPaths.DEPT_IS_TRANSCRIPT) , JPaths.DEPT_IS_TRANSCRIPT , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( transcript, jPath(response,JPaths.DEPT_TRANSCRIPT_MAIL) , JPaths.DEPT_TRANSCRIPT_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog(is_feedback , jPath(response,JPaths.DEPT_IS_FEEDBACK) , JPaths.DEPT_IS_FEEDBACK , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( feedback, jPath(response,JPaths.DEPT_FEEDBACK_MAIL) , JPaths.DEPT_FEEDBACK_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( is_blocked, jPath(response,JPaths.DEPT_IS_BLOCKED) , JPaths.DEPT_IS_BLOCKED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( blocked, jPath(response,JPaths.DEPT_BLOCKED_MAIL) , JPaths.DEPT_BLOCKED_MAIL , etest)==false)
		{
			failcount++;
		}

		JSONArray operators=SalesIQRestAPICommonFunctions.getArray(response,JPaths.DEPT_OPERATORS_ARRAY);

		if(CommonUtil.checkStringContainsAndLog( ExecuteStatements.getOperatorId(driver) , operators.toString() , JPaths.DEPT_OPERATORS_ARRAY , etest)==false)
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}
	//e

	public static boolean isDepartmentSettingsFound(WebDriver driver,ExtentTest etest,String response) throws Exception
	{
		String department_id=SalesIQRestAPICommonFunctions.jPath(response,JPaths.DEPT_ID);

		Hashtable<String,String> dept_info=Department.getDepartmentInfo(driver,department_id);

		SalesIQRestAPICommonFunctions.log(etest,"Actual Department Values Found In UI \n"+dept_info.toString());

		int failcount=0;

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.NAME) , jPath(response,JPaths.DEPT_NAME) , JPaths.DEPT_NAME , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_PUBLIC) , jPath(response,JPaths.DEPT_IS_PUBLIC) , JPaths.DEPT_IS_PUBLIC , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_ENABLED) , jPath(response,JPaths.DEPT_IS_ENABLED) , JPaths.DEPT_IS_ENABLED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.DESCRIPTION) , jPath(response,JPaths.DEPT_DESCRIPTION) , JPaths.DEPT_DESCRIPTION , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_SYSTEM_GENERATED) , jPath(response,JPaths.DEPT_SYSTEM_GENERATED) , JPaths.DEPT_SYSTEM_GENERATED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.FROM_EMAIL) , jPath(response,JPaths.DEPT_FROM_MAIL) , JPaths.DEPT_FROM_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_MISSED_MAIL) , jPath(response,JPaths.DEPT_IS_MISSED) , JPaths.DEPT_IS_MISSED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.MISSED_MAIL) , jPath(response,JPaths.DEPT_MISSED_MAIL) , JPaths.DEPT_MISSED_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_CC_MAIL) , jPath(response,JPaths.DEPT_IS_CC) , JPaths.DEPT_IS_CC , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.CC_MAIL) , jPath(response,JPaths.DEPT_CC_MAIL) , JPaths.DEPT_CC_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_TRANSCRIPT_MAIL) , jPath(response,JPaths.DEPT_IS_TRANSCRIPT) , JPaths.DEPT_IS_TRANSCRIPT , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.TRANSCRIPT_MAIL) , jPath(response,JPaths.DEPT_TRANSCRIPT_MAIL) , JPaths.DEPT_TRANSCRIPT_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_FEEDBACK_MAIL) , jPath(response,JPaths.DEPT_IS_FEEDBACK) , JPaths.DEPT_IS_FEEDBACK , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.FEEDBACK_MAIL) , jPath(response,JPaths.DEPT_FEEDBACK_MAIL) , JPaths.DEPT_FEEDBACK_MAIL , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.IS_BLOCKEDIP_MAIL) , jPath(response,JPaths.DEPT_IS_BLOCKED) , JPaths.DEPT_IS_BLOCKED , etest)==false)
		{
			failcount++;
		}

		if(CommonUtil.checkStringEqualsAndLog( dept_info.get(Department.BLOCKEDIP_MAIL) , jPath(response,JPaths.DEPT_BLOCKED_MAIL) , JPaths.DEPT_BLOCKED_MAIL , etest)==false)
		{
			failcount++;
		}

		JSONArray operators=SalesIQRestAPICommonFunctions.getArray(response,JPaths.DEPT_OPERATORS_ARRAY);

		if(CommonUtil.checkStringContainsAndLog( ExecuteStatements.getOperatorId(driver) , operators.toString() , JPaths.DEPT_OPERATORS_ARRAY , etest)==false)
		{
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static final String
	NORMAL="NORMAL",
	WITHOUT_EMAIL_CONFIGURATION="WITHOUT_EMAIL_CONFIGURATION",
	PRIVATE_DEPARTMENT="PRIVATE_DEPARTMENT",
	EXISTING_DEPARTMENT="EXISTING_DEPARTMENT"
	;

	public static void createDepartmentAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,String usecase)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		String
		name="dept"+label,
		description="desc"+label,
		from_mail="from"+label+"@email.com",
		missedmail="missedmail"+label+"@email.com",
		fbmail="fbmail"+label+"@email.com",
		ccmail="ccmail"+label+"@email.com",
		transmail="transmail"+label+"@email.com",
		blockmail="blockmail"+label+"@email.com"
		;

		boolean
		isEnabled=true,
		isPublic=true,
		isMissed=true,
		isFeedback=true,
		isCC=true,
		isTranscript=true,
		isBlock=true
		;

		String verify_in_UI_usecase=null;

		if(usecase.equals(PRIVATE_DEPARTMENT))
		{
			verify_in_UI_usecase="RESTAPI50";
		}
		if(usecase.equals(WITHOUT_EMAIL_CONFIGURATION))
		{
			verify_in_UI_usecase="RESTAPI51";
		}
		if(usecase.equals(NORMAL))
		{
			verify_in_UI_usecase="RESTAPI47";
		}

		try
		{
			if(usecase.equals(PRIVATE_DEPARTMENT))
			{
				isPublic=false;
			}
			if(usecase.equals(EXISTING_DEPARTMENT))
			{
				name=ExecuteStatements.getSystemGeneratedDepartment(driver);
			}

			String operator_id=ExecuteStatements.getOperatorId(driver);

			JSONObject payload=null;

			if(usecase.equals(WITHOUT_EMAIL_CONFIGURATION))
			{
				payload=GetPayload.getCreateDepartmentPayload(name,""+isPublic,description,new String[]{operator_id},null,null,null,null,null,null,null,null,null,null,null);
			}
			else
			{
				payload=GetPayload.getCreateDepartmentPayload(name,""+isPublic,description,new String[]{operator_id},from_mail,""+isTranscript,transmail,""+isBlock,blockmail,""+isFeedback,fbmail,""+isMissed,missedmail,""+isCC,ccmail);
			}


			etest.log(Status.INFO,"Below json will be used as payload");
			SalesIQRestAPICommonFunctions.log(etest,payload);

			//update from API and check from response,
			Api create_deparment_api=Api.DEPARTMENT_CREATE;
			String api=create_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			if(usecase.equals(EXISTING_DEPARTMENT))
			{
				etest.log(Status.INFO,"Response when existing department name is called");
				SalesIQRestAPICommonFunctions.log(etest,response);

				if(CommonUtil.checkStringEqualsAndLog(resource_already_exists_error_code,new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString(),"response code",etest) &&
					CommonUtil.checkStringEqualsAndLog(resource_already_exists_error_message,new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString(),"response message",etest))
				{
					result.put("RESTAPI52",true);
					etest.log(Status.PASS,"Resource already exists response was received for create department API when existing department name was given.");
				}
				else
				{
					result.put("RESTAPI52",false);
					etest.log(Status.FAIL,"Resource already exists response was not received for create department API when existing department name was given.");
					TakeScreenshot.screenshot(api_webdriver,etest);
				}

				return;
			}

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);

			if(CommonUtil.isChecked("RESTAPI45",result)==false)
			{
				etest.log(Status.INFO,"Now checking if all keys are found");
				result.put("RESTAPI45",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,create_deparment_api.expected_keys));
			}
			else if(CommonUtil.isChecked("RESTAPI46",result)==false)
			{
				etest.log(Status.INFO,"Now verifying all values in response");
				result.put("RESTAPI46",isDepartmentSettingsFoundInResponse(driver,etest,response,name,""+isPublic,""+isEnabled,description,""+false,from_mail,""+isMissed,missedmail,""+isCC,ccmail,""+isTranscript,transmail,""+isFeedback,fbmail,""+isBlock,blockmail));
			}

			etest.log(Status.INFO,"Now check if updated values are found in UI");
			result.put(verify_in_UI_usecase,isDepartmentSettingsFound(driver,etest,response));

			if(!usecase.equals(NORMAL))
			{
				return;
			}

			String image_url=jPath(response,JPaths.DEPT_IMAGE_URL);
			image_url=SalesIQRestAPICommonFunctions.getAPIURL(image_url);

			if(SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(image_url))
			{
				etest.log(Status.PASS,APIKeys.IMAGE_URL+" was found with success response code.");
				result.put("RESTAPI49",true);
			}
			else
			{
				result.put("RESTAPI49",false);
				etest.log(Status.FAIL,APIKeys.IMAGE_URL+" was NOT found with success response code.");
				SalesIQRestAPICommonFunctions.log(etest,response.toString());
			}

			etest.log(Status.INFO,"Now checking if updated values are found in get department info API");

			String dept_id=ExecuteStatements.getDepartmentId(driver,name);

			//checking if updated values found in get dept info API
			Api get_deparment_api=Api.DEPARTMENT_GET;
			api=get_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",dept_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			result.put("RESTAPI48",isDepartmentSettingsFoundInResponse(driver,etest,response,name,""+isPublic,""+isEnabled,description,""+false,from_mail,""+isMissed,missedmail,""+isCC,ccmail,""+isTranscript,transmail,""+isFeedback,fbmail,""+isBlock,blockmail));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void deleteDepartmentAPI(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,boolean isSameConfigureTo,boolean isSystemGeneratedDeptDeleted)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		String usecase=null;
		if(isSameConfigureTo)
		{
			usecase="RESTAPI41";
		}
		else if(isSystemGeneratedDeptDeleted)
		{
			usecase="RESTAPI42";
		}
		else
		{
			usecase="RESTAPI39";
		}

		try
		{
			String department_to_delete_id=createDepartment(api_webdriver,driver,etest);
			etest.log(Status.PASS,"Department with department id "+department_to_delete_id+" was created");

			String configure_department_id=null;

			if(isSameConfigureTo)
			{
				configure_department_id=department_to_delete_id;
			}
			else
			{
				configure_department_id=ExecuteStatements.getDepartmentId(driver,ExecuteStatements.getSystemGeneratedDepartment(driver));
			}

			if(isSystemGeneratedDeptDeleted && !isSameConfigureTo)
			{
				//swap
				String temp=department_to_delete_id;
				department_to_delete_id=configure_department_id;
				configure_department_id=temp;
			}

			if(isSameConfigureTo)
			{
				etest.log(Status.INFO,"Attempting to delete a department by settings configure_to value same as department to be deleted");
			}
			if(isSystemGeneratedDeptDeleted)
			{
				etest.log(Status.INFO,"Attempting to delete system generated department");
			}

			Api delete_deparment_api=Api.DEPARTMENT_DELETE;
			String api=delete_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_to_delete_id);
			api=SalesIQRestAPICommonFunctions.addParam(api,APIKeys.CONFIGURE_TO,configure_department_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,delete_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			String response_value = "";
			String response_message = "";
			if(new JSONObject(response).has("error"))
			{
				response_value = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				response_message = new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString();
			}
			else
			{
				response_value = new JSONObject(response).get("code").toString();
				response_message = SUCCESS_CODE;
			}

			boolean expectedIsDeleted= !(isSameConfigureTo||isSystemGeneratedDeptDeleted);

			String expected=null;
			String expected_message = "";
			if(expectedIsDeleted)
			{
				expected = SUCCESS_CODE;
				expected_message = SUCCESS_CODE;
			}
			else
			{
				expected = invalid_request_parameters_error_code;
				expected_message = invalid_request_parameters_error_message;
			}

			if(CommonUtil.checkStringContainsAndLog(expected,response_value,"response code",etest) && (CommonUtil.checkStringContainsAndLog(expected_message,response_message,"response message",etest)))
			{
				etest.log(Status.PASS,"Department with dept id "+department_to_delete_id+" was "+(expectedIsDeleted?"deleted":"NOT deleted"));
				result.put(usecase,true);
			}
			else
			{
				result.put(usecase,false);
				etest.log(Status.FAIL,"Department with dept id "+department_to_delete_id+" was "+(expectedIsDeleted?"NOT deleted":"deleted"));
				TakeScreenshot.screenshot(api_webdriver,etest);
			}

			if(!expectedIsDeleted)
			{
				return;
			}

			if(Department.isDepartmentFound(driver,department_to_delete_id)==false)
			{
				etest.log(Status.PASS,"Deleted department was not found in UI after it was deleted");
				result.put("RESTAPI40",true);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted department was found in UI after it was deleted");
				result.put("RESTAPI40",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			//list check
			Api get_deparment_list_api=Api.DEPARTMENT_GET_LIST;
			api=get_deparment_list_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_deparment_list_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			JSONObject json_response=SalesIQRestAPICommonFunctions.convertToJSON(response,etest);
			
			JSONArray deparments=SalesIQRestAPICommonFunctions.getArray(response,JPaths.DEPARTMENTS_ARRAY);

			if(SalesIQRestAPICommonFunctions.getJSONWith(deparments,APIKeys.DEPT_ID,department_to_delete_id)==null)
			{
				etest.log(Status.PASS,"Deleted deparment with id '"+department_to_delete_id+"' was NOT found in APIs response.");
				result.put("RESTAPI43",true);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted deparment with id '"+department_to_delete_id+"' was found in APIs response.");
				SalesIQRestAPICommonFunctions.log(etest,deparments.toString());
				result.put("RESTAPI43",false);
			}

			//get check
			Api get_deparment_api=Api.DEPARTMENT_GET;
			api=get_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_to_delete_id);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,get_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);

			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			if(CommonUtil.checkStringEqualsAndLog(Constants.INVALID_RESOURCE,new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString(),"response code",etest) &&
				CommonUtil.checkStringEqualsAndLog(Constants.INVALID_RESOURCE_ERROR_MESSAGE,new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString(),"response message",etest))
			{
				result.put("RESTAPI44",true);
				etest.log(Status.PASS,"Department info was not received for deleted department in get department info API.");
			}
			else
			{
				result.put("RESTAPI44",false);
				etest.log(Status.FAIL,"Department info was not received for deleted department (deptid:"+department_to_delete_id+") in get department info API.");
				TakeScreenshot.screenshot(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	//create department and return dept id
	public static String createDepartment(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		String label=CommonUtil.getUniqueMessage();

		String
		name="dept"+label,
		description="desc"+label,
		from_mail="from"+label+"@email.com",
		missedmail="missedmail"+label+"@email.com",
		fbmail="fbmail"+label+"@email.com",
		ccmail="ccmail"+label+"@email.com",
		transmail="transmail"+label+"@email.com",
		blockmail="blockmail"+label+"@email.com"
		;

		boolean
		isEnabled=true,
		isPublic=true,
		isMissed=true,
		isFeedback=true,
		isCC=true,
		isTranscript=true,
		isBlock=true
		;

		try
		{
			String operator_id=ExecuteStatements.getOperatorId(driver);

			JSONObject payload=GetPayload.getCreateDepartmentPayload(name,""+isPublic,description,new String[]{operator_id},from_mail,""+isTranscript,transmail,""+isBlock,blockmail,""+isFeedback,fbmail,""+isMissed,missedmail,""+isCC,ccmail);

			Api create_deparment_api=Api.DEPARTMENT_CREATE;
			String api=create_deparment_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,create_deparment_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);

			return jPath(response,JPaths.DEPT_ID);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			return null;
		}
	}

	public static void toggleDepartment(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,boolean isEnable)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		String resp_usecase=null,ui_usecase=null,already_usecase=null;

		try
		{
			String department_id=createDepartment(api_webdriver,driver,etest);
			etest.log(Status.PASS,"Department with department id "+department_id+" was created");

			Tab.navToDeptTab(driver);
			Department.openDepartment(driver,department_id);

			Department.toggleDepartment(driver,!isEnable);//so that we set it to isEnable from API

			Api toggle_department_api=null;

			if(isEnable)
			{
				toggle_department_api=Api.DEPARTMENT_ENABLE;
				resp_usecase="RESTAPI53";
				ui_usecase="RESTAPI54";
				already_usecase="RESTAPI55";

			}
			else
			{
				toggle_department_api=Api.DEPARTMENT_DISABLE;
				resp_usecase="RESTAPI56";
				ui_usecase="RESTAPI57";
				already_usecase="RESTAPI58";
			}

			String api=toggle_department_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,toggle_department_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			String response_code=new JSONObject(response).get("code").toString();
			result.put(resp_usecase, CommonUtil.checkStringEqualsAndLog(SUCCESS_CODE,response_code,"response code",etest) );

			Tab.navToDeptTab(driver);
			Department.openDepartment(driver,department_id);

			result.put(ui_usecase, CommonUtil.checkStringEqualsAndLog(""+isEnable,""+Department.isDepartmentEnabled(driver),"expected department 'is enabled'",etest));

			api=toggle_department_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,toggle_department_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			response_code=new JSONObject(response).get("code").toString();
			result.put(already_usecase, CommonUtil.checkStringEqualsAndLog("204",response_code,"response code",etest) );
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	public static void addRemoveOperators(WebDriver api_webdriver,WebDriver driver,ExtentTest etest)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			String department_id=createDepartment(api_webdriver,driver,etest);
			etest.log(Status.PASS,"Department with department id "+department_id+" was created");

			String operator_id=UsersTab.getRandomOperatorId(driver);

			String operator_name = CommonUtil.getElement(driver,By.id(operator_id),By.className("txtelips")).getText();

			Tab.navToDeptTab(driver);
			Department.addDept(driver,"newdept"+label,"depttype_publi",operator_name,etest);

			Tab.navToDeptTab(driver);

			Api add_operator_api=Api.DEPARTMENT_ADD_OPERATOR;
			String api=add_operator_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,add_operator_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.addPayload(api_webdriver, GetPayload.getAddOperatorToDepartmentPayload(new String[]{operator_id}) );
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			result.put("RESTAPI59",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,add_operator_api.expected_keys));

			Tab.navToDeptTab(driver);
			Department.openDepartment(driver,department_id);

			//check in UI if added
			String actual_operators=Department.getDepartmentInfo(driver,department_id).get(Department.OPERATORS);
			result.put("RESTAPI60",CommonUtil.checkStringContainsAndLog("|"+operator_id+"|",actual_operators,"operator id in UI",etest));

			//remove
			Api remove_operator_api=Api.DEPARTMENT_REMOVE_OPERATOR;
			api=remove_operator_api.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_id);
			api=SalesIQRestAPICommonFunctions.addParam(api,"ids",operator_id);

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,remove_operator_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			result.put("RESTAPI61",SalesIQRestAPICommonFunctions.isKeysFound(etest,response,remove_operator_api.expected_keys));

			//check in UI if removed
			actual_operators=Department.getDepartmentInfo(driver,department_id).get(Department.OPERATORS);

			if(CommonUtil.isContains("|"+operator_id+"|",actual_operators)==false)
			{
				etest.log(Status.PASS,"Operator id "+operator_id+" was NOT found in UI after it was removed using the API");
				result.put("RESTAPI62",true);			
			}
			else
			{
				etest.log(Status.FAIL,"Operator id "+operator_id+" was found in UI even after it was removed using the API");
				result.put("RESTAPI62",false);							
			}

			//trying to delete already deleted operator
			etest.log(Status.INFO,"Trying to delete operator not from department and check for error response");
			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,remove_operator_api);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);
			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			String response_code = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
			String response_message = new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString();
			//to check this
			if(CommonUtil.checkStringEqualsAndLog(operator_not_associated_error_code,response_code,"response code",etest) &&
				CommonUtil.checkStringEqualsAndLog(operator_not_associated_error_message,response_message,"response message",etest))
			{
				etest.log(Status.PASS,"Error response was received for delete department API, when operator was not part of the department");
				result.put("RESTAPI63",true);
			}
			else
			{
				result.put("RESTAPI63",false);
				etest.log(Status.FAIL,"Error response was NOT received for delete department API, when operator was not part of the department");
				TakeScreenshot.screenshot(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}	
	}

	//invalid scope
	public static boolean checkInvalidScope(WebDriver api_webdriver,WebDriver driver,ExtentTest etest,Api api_under_test)
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		try
		{
			String expected_deparment=ExecuteStatements.getSystemGeneratedDepartment(driver);
			String department_id=ExecuteStatements.getDepartmentId(driver,expected_deparment);
			String operator_id=UsersTab.getRandomOperatorId(driver);

			String api=api_under_test.get();
			api=api.replace("<"+APIKeys.SCREENNAME+">",ExecuteStatements.getPortal(driver));
			api=api.replace("<departmentid>",department_id);

			if(api_under_test==Api.DEPARTMENT_DELETE)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,APIKeys.CONFIGURE_TO,department_id);
			}
			else if(api_under_test==Api.DEPARTMENT_REMOVE_OPERATOR)
			{
				api=SalesIQRestAPICommonFunctions.addParam(api,"ids",operator_id);
			}

			etest.log(Status.INFO,"Below API will be called");
			SalesIQRestAPICommonFunctions.log(etest,api);

			api_webdriver.get(SalesIQRestAPIModule.APITesterURL);
			SalesIQRestAPICommonFunctions.configureAPI(api_webdriver,api_under_test);
			SalesIQRestAPICommonFunctions.sendKeysToAPIInput(api_webdriver,api);

			JSONObject payload=null;


			String dummy_email=label+"@email.com";

			if(api_under_test==Api.PORTAL_UPDATE)
			{
				payload=GetPayload.getUpdatePortalPayload(label,label,"www."+label+".com",label,"IST",label,"en",label,dummy_email);
			}
			else if(api_under_test==Api.DEPARTMENT_UPDATE)
			{
				payload=GetPayload.getUpdateDepartmentPayload(label,""+true,label,null,dummy_email,""+true,dummy_email,""+true,dummy_email,""+true,dummy_email,""+true,dummy_email,""+true,dummy_email);
			}
			else if(api_under_test==Api.DEPARTMENT_CREATE)
			{
				payload=GetPayload.getCreateDepartmentPayload(label,""+true,label,new String[]{operator_id},null,null,null,null,null,null,null,null,null,null,null);
			}
			else if(api_under_test==Api.DEPARTMENT_ADD_OPERATOR)
			{
				payload=GetPayload.getAddOperatorToDepartmentPayload(new String[]{operator_id});
			}
			else if(api_under_test==Api.PORTAL_OWNER_UPDATE)
			{
				String new_owner_id=ExecuteStatements.getOperatorId(driver);
				payload=GetPayload.getChangePortalOwnerPayload(new_owner_id);
			}

			if(payload!=null)
			{
				etest.log(Status.INFO,"Below JSON will be added as payload");
				SalesIQRestAPICommonFunctions.log(etest,payload.toString());

				SalesIQRestAPICommonFunctions.addPayload(api_webdriver,payload);
			}

			SalesIQRestAPICommonFunctions.sendAPIRequest(api_webdriver);
			String response = SalesIQRestAPICommonFunctions.getAPIResponse(api_webdriver);
			TakeScreenshot.infoScreenshot(driver,etest);

			etest.log(Status.INFO,"Below json is the response");
			SalesIQRestAPICommonFunctions.log(etest,response);

			String code,response_message;
			if(new JSONObject(response).has("error"))
			{
				code = new JSONObject(new JSONObject(response).get("error").toString()).get("code").toString();
				response_message = new JSONObject(new JSONObject(response).get("error").toString()).get("message").toString();
			}
			else
			{
				code = new JSONObject(response).get("code").toString();
				response_message = new JSONObject(response).getString("JSPServerResponse");
			}

			if(CommonUtil.checkStringEqualsAndLog(invalid_scope_error_code,code,"response code",etest) && 
				CommonUtil.checkStringEqualsAndLog(invalid_scope_error_message,response_message,"response message",etest))
			{
				etest.log(Status.PASS,"Error response was received for API : "+api_under_test+" , When it was called with invalid scope");
			}
			else
			{
				etest.log(Status.FAIL,"Error response was NOT received for API : "+api_under_test+" , When it was called with invalid scope");
				SalesIQRestAPICommonFunctions.log(api_webdriver,etest);
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(api_webdriver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			return CommonUtil.returnResult(failcount);
		}	
	}

	public static String jPath(String response,String jPath) throws Exception
	{
		return SalesIQRestAPICommonFunctions.jPath(response,jPath);
	}
}
