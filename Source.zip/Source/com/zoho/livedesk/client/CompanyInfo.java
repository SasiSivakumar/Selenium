//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class CompanyInfo
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

	public static String companyname = null;
	public static String website = null;
	public static String address = null;
	public static String emailid = null;
	public static String telephone = null;
	public static String fax = null;
	public static String desc = null;
	public static String language = null;
	public static String timezone = null;
	private static String url = "";
    public static ExtentTest etest;

	private static void init()
	{
		companyname = "Zoho corp";
		website = "http://people.zoho.com";
		address = "DLF IT park, Ramapuram";
		emailid = "anand.ramachandran@zohocorp.com";
		telephone = "9788160492";
		fax = "9123456789";
		desc = "AdventNet";
		language = "English";
		timezone = "( GMT 5:45 ) Nepal Time(Asia/Katmandu)";
	}

	public static Hashtable companydetails(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC1"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			//WebDriverWait wait = new WebDriverWait(driver, 30);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			//Company info view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

			//Thread.sleep(1000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            etest.log(Status.PASS,"Company - Settings Tab is Present");

			result.put("SC1", true);

			//Thread.sleep(1000);
			init();
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC2"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC2", isPageAvail(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC3"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC3", configBusinessHour(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC5"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC5", enableBusinessHour(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC6"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC6", hideChatWidgetwithBusinessHour(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC7"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC7", hideChatWidgetwithBusinessHourDisable(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC4"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC4", disableBusinessHour(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            // etest=ComplexReportFactory.getTest("Edit Data In Company Settings Page");
            // ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            editCompanyInfo(driver);
            //Thread.sleep(1000);

            //ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorCompayTab");

            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CompanyTab","ErrorCompanyTab",e);

            result.put("SC1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorCompayTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CompanyTab","ErrorCompanyTab",e);

            result.put("SC1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check Company Header
    private static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_comp_info")+"')]")));

            driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_comp_info")+"')]"));
            //Thread.sleep(300);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));

            if((driver.findElement(By.className("innersubinfotxt")).getText()).equals(ResourceManager.getRealValue("settings_company_desc")))
            {
                etest.log(Status.PASS,"Company - Settings Description is matched");

                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CompanySettingsPage","MismatchDescription");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CompanySettingsPage","ErrorWhileCheckingCompanySettingsPage",e);

            System.out.println("Exception while checking if company settings page is available : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CompanySettingsPage","ErrorWhileCheckingCompanySettingsPage",e);

            System.out.println("Exception while checking if company settings page is available : "+e);
        }
        return false;
    }

    //Check Configure Business Hours
    private static boolean configBusinessHour(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("businesshourlink")));
            final WebElement elmt = driver.findElement(By.id("businesshourlink"));
            //Thread.sleep(1000);

            if((elmt.getAttribute("style")).contains("inline-block"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");
                elmt.click();
                //Thread.sleep(1000);
            }

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(elmt.getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            etest.log(Status.PASS,"Company - Settings Configure Bussiness Hour is checked");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","ConfigureBusinessHour","ErrorWhileConfiguringBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while configuring business hour through link in company settings : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","ConfigureBusinessHour","ErrorWhileConfiguringBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while configuring business hour through link in company settings : "+e);
        }
        return false;
    }

    //Check Disable Business Hours
    public static boolean disableBusinessHour(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("businesshourlink")));
            WebElement configbh = driver.findElement(By.id("businesshourlink"));
            //Thread.sleep(1000);
            if((configbh.getAttribute("style")).contains("inline-block"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+configbh.getLocation().y+")");
                configbh.click();
                //Thread.sleep(2000);
            }

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bhdisablelnk")));

            if(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked") == null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv"))).getLocation().y+"-300)");
                driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv")).click();
                //Thread.sleep(4000);
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("bhstatusdiv")).getAttribute("class")).contains("set_on"))                //("true".equals(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked")))
                        {
                            return true;
                        }
                        return false;
                    }
                });

                if(!("true".equals(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked"))))
                {
                    TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableBusinessHour","BusinessHourIsNotEnabled");

                    return false;
                }
            }
            //Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv"))).getLocation().y+"-300)");
            driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv")).click();
            //Thread.sleep(5000);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("bhstatusdiv")).getAttribute("class")).contains("set_off"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bhcontainer")));
            WebElement elmt = driver.findElement(By.id("bhcontainer"));
            //Thread.sleep(1000);
            WebElement elmts = elmt.findElement(By.className("lvdsblesb"));
            //Thread.sleep(1000);

            if((elmts.getAttribute("style")).contains("none"))
            {
                TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableBusinessHour","BusinessHourIsNotDisabled");

                return false;
            }
            etest.log(Status.PASS,"Company - Settings DisableBusinessHour is Checked");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableBusinessHour","ErrorWhileDisablingBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while disabling business hours in company settings : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableBusinessHour","ErrorWhileDisablingBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while disabling business hours in company settings : "+e);
        }
        return false;
    }

    //Check Enable Business Hours
    public static boolean enableBusinessHour(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("businesshourlink")));
            WebElement configbh = driver.findElement(By.id("businesshourlink"));
            //Thread.sleep(1000);

            if((configbh.getAttribute("style")).contains("inline-block"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+configbh.getLocation().y+")");
                configbh.click();
                //Thread.sleep(2000);
            }
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bhdisablelnk")));

            if("true".equals(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked")))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv"))).getLocation().y+"-300)");
                driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv")).click();
                //Thread.sleep(4000);

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("bhstatusdiv")).getAttribute("class")).contains("set_off"))
                        {
                            return true;
                        }
                        return false;
                    }
                });

                if("true".equals(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked")))
                {
                    TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableBusinessHour","BusinessHourIsNotDisabled");

                    return false;
                }
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv"))).getLocation().y+"-300)");
            driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv")).click();
            //Thread.sleep(2000);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("bhstatusdiv")).getAttribute("class")).contains("set_on"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bhcontainer")));
            WebElement elmt = driver.findElement(By.id("bhcontainer"));
            //Thread.sleep(1000);
            WebElement elmts = elmt.findElement(By.className("lvdsblesb"));
            //Thread.sleep(1000);
            if((elmts.getAttribute("style")).contains("none"))
            {
                etest.log(Status.PASS,"Company - Settings EnableBusinessHour is Checked");

                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableBusinessHour","BusinessHourIsNotEnabled");
            }
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableBusinessHour","ErrorWhileEnablingBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while enabling business hours in company settings : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableBusinessHour","ErrorWhileEnablingBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while enabling business hours in company settings : "+e);
        }
        return false;
    }

    //Check slider in business Enable
    private static boolean hideChatWidgetwithBusinessHour(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("businesshourlink")));
            final WebElement configbh = driver.findElement(By.id("businesshourlink"));
            //Thread.sleep(1000);

            if((configbh.getAttribute("style")).contains("inline-block"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+configbh.getLocation().y+")");
                configbh.click();
                //Thread.sleep(2000);
            }

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((configbh.getAttribute("style")).contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            if(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked") == null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv"))).getLocation().y+"-300)");
                driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv")).click();
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("bhstatusdiv")).getAttribute("class")).contains("set_on"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                //Thread.sleep(1000);
            }

            if("true".equals(driver.findElement(By.id("bhbtncontainer")).findElement(By.id("bhbtninput")).getAttribute("checked")))
            {
                //Thread.sleep(1000);
                hideChatWidgetwithBusinessHourDisable(driver);
            }
            //JavascriptExecutor je = (JavascriptExecutor)driver;
            //je.executeScript("scroll(0,1000)");

            System.out.println("Comes here ;---------------------------------------------------1----------");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhbtn"))).getLocation().y+")");
            driver.findElement(By.id("bhbtn")).click();
            //Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("svebtn")));
            driver.findElement(By.id("svebtn")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            System.out.println("Comes here ;----------------------------------------------------2---------");
            //Thread.sleep(1000);
            driver.findElement(By.id("okbtn")).click();
            //Thread.sleep(2000);
            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("bhactionui")).getAttribute("style")).contains("none"))
                    {
                        System.out.println("Comes here ;-----------------------------------------3--------------------");
                        return true;
                    }
                    return false;
                }
            });
            //wait.until(ExpectedConditions.not(ExpectedConditions.presenceOfElementLocated(By.id("okbtn"))));

            System.out.println("Comes here ;------------------------------------------------------4-------");
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("bhbtn")).getAttribute("class")).contains("set_on"))
                    {
                        System.out.println("Comes here ;-------------------------------------------5------------------");
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            System.out.println("Comes here");

            if("true".equals(driver.findElement(By.id("bhbtncontainer")).findElement(By.id("bhbtninput")).getAttribute("checked")))
            {
                System.out.println("Comes here not here");
                etest.log(Status.PASS,"Company - Settings HideWidget is Enabled");

                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableHideWidgetWithBusinessHours","HideWidgetIsNotEnabled");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableHideWidgetWithBusinessHours","ErrorWhileEnablingHideWidgetWithBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while enabling hide widget with business hours in company settings : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EnableHideWidgetWithBusinessHours","ErrorWhileEnablingHideWidgetWithBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while enabling hide widget with business hours in company settings : "+e);
        }
        return false;
    }

    //Check slider in business Disable
    public static boolean hideChatWidgetwithBusinessHourDisable(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            //Thread.sleep(1000);
            final WebElement configbh = driver.findElement(By.id("businesshourlink"));
            //Thread.sleep(1000);

            if((configbh.getAttribute("style")).contains("inline-block"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+configbh.getLocation().y+")");
                configbh.click();
                //Thread.sleep(2000);
            }

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((configbh.getAttribute("style")).contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            if(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusradio")).getAttribute("checked") == null)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv"))).getLocation().y+"-300)");
                driver.findElement(By.id("bhdisablelnk")).findElement(By.id("bhstatusdiv")).click();

                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("bhstatusdiv")).getAttribute("class")).contains("set_on"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                //Thread.sleep(1000);
            }

            if(driver.findElement(By.id("bhbtncontainer")).findElement(By.id("bhbtninput")).getAttribute("checked") == null)
            {
                //Thread.sleep(1000);
                hideChatWidgetwithBusinessHour(driver);
            }
            //JavascriptExecutor je = (JavascriptExecutor)driver;
            //je.executeScript("scroll(0,1000)");

            System.out.println("Comes here ;----------------------------------------------6---------------");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("bhbtn"))).getLocation().y+")");
            driver.findElement(By.id("bhbtn")).click();
            //Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("svebtn")));
            driver.findElement(By.id("svebtn")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            //Thread.sleep(1000);
            driver.findElement(By.id("okbtn")).click();
            //Thread.sleep(2000);
            Thread.sleep(1000);

            System.out.println("Comes here ;-----------------------------------------------7--------------");
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("bhactionui")).getAttribute("style")).contains("none"))
                    {
                        System.out.println("Comes here ;--------------------8-----------------------------------------");
                        return true;
                    }
                    return false;
                }
            });
            //wait.until(ExpectedConditions.not(ExpectedConditions.presenceOfElementLocated(By.id("okbtn"))));

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("bhbtn")).getAttribute("class")).contains("set_off"))
                    {
                        System.out.println("Comes here ;---------------------9----------------------------------------");
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);
            System.out.println("Comes here ;----------------------------------10---------------------------");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            System.out.println("Comes here dis");

            if(driver.findElement(By.id("bhbtncontainer")).findElement(By.id("bhbtninput")).getAttribute("checked") == null)
            {
                System.out.println("Comes here not here dis");
                etest.log(Status.PASS,"Company - Settings HideWidget is Disabled");

                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableHideWidgetWithBusinessHours","HideWidgetIsNotDisabled");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableHideWidgetWithBusinessHours","ErrorWhileDisablingHideWidgetWithBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while disabling hide widget with business hours in company settings : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","DisableHideWidgetWithBusinessHours","ErrorWhileDisablingHideWidgetWithBusinessHourInCompanySettingsPage",e);

            System.out.println("Exception while disabling hide widget with business hours in company settings : "+e);
        }
        return false;
    }

    //Edit Company Info
    private static void editCompanyInfo(WebDriver driver)
    {
        try
        {
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC8"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC8", editData(driver, "companyname", companyname));
            //Thread.sleep(6000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC9"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC9", editData(driver, "companywebsite", website));
            //Thread.sleep(6000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC10"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC10", editData(driver, "companyaddress", address));
            //Thread.sleep(6000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC11"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC11", editData(driver, "companyemail", emailid));
            //Thread.sleep(6000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC12"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC12", editData(driver, "companytelephone", telephone));
            //Thread.sleep(6000);
            telephone = "+444 123456555";
            result.put("SC12", editData(driver, "companytelephone", telephone));
            //Thread.sleep(6000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC13"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC13", editData(driver, "companyfax", fax));
            //Thread.sleep(6000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC14"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            result.put("SC14", editData(driver, "companydesc", desc));
            //Thread.sleep(6000);

            result.put("SC15", false);
            result.put("SC16", false);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC15"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            editDDData(driver, "SC15", "companylanguage_div", "companylanguage_ddown", language);
            //Thread.sleep(6000);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SC16"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Admin");

            editDDData(driver, "SC16", "companytimezone_div", "companytimezone_ddown", timezone);
            //Thread.sleep(6000);
			ComplexReportFactory.closeTest(etest);
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while editing company info in company settings : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while editing company info in company settings : "+e);
        }
    }

    //Edit Company Data
    public static boolean editData(WebDriver driver, String field, String value)
    {
        boolean isupdated = false;
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            System.out.println("comaoishdjhkavsv m m1");

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            System.out.println("comaoishdjhkavsv m m3");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(field)));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(field))).getLocation().y+"-500)");
            Thread.sleep(500);

            System.out.println("comaoishdjhkavsv m m4");

            driver.findElement(By.id(field)).click();
            System.out.println("comaoishdjhkavsv m m5");
            //Thread.sleep(1000);
            driver.findElement(By.id(field)).clear();
            System.out.println("comaoishdjhkavsv m m6");
            //Thread.sleep(1000);
            driver.findElement(By.id(field)).sendKeys(value);
            System.out.println("comaoishdjhkavsv m m7");
            //Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("document.getElementById('"+field+"').value='"+value+"';");
            System.out.println("comaoishdjhkavsv m m8");
            Thread.sleep(1000);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.className("cmntitle"))).getLocation().y+"-500)");
            Thread.sleep(500);
            driver.findElement(By.className("cmntitle")).click();
            System.out.println("comaoishdjhkavsv m m9");

            Tab.waitForLoadingSuccessWithBanner(driver,"Updated successfully","upcompanyinfo.do",etest);
            System.out.println("comaoishdjhkavsv m m13");
            //Check in company info page
            isupdated = checkCompanyInfo(driver, field, value);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EditData","ErrorWhileEdittingDataInCompanySettingsPage",e);

            System.out.println("Exception while editing company info in company settings : "+field+" --Exception-- "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EditData","ErrorWhileEdittingDataInCompanySettingsPage",e);

            System.out.println("Exception while editing company info in company settings : "+field+" --Exception-- "+e);
        }
        if(isupdated)
        {
            etest.log(Status.PASS,"Edited value for "+field+" is checked");

            return true;
        }
        else
            return false;
    }

    //Check edited data in Settings->Company page
    private static boolean checkCompanyInfo(WebDriver driver, String field, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            if((driver.findElement(By.id(field)).getAttribute("value")).equals(value))
            {
                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CheckEditedData-"+value,"MismatchEditedContent-"+value);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CheckEditedData-"+value,"ErrorWhileCheckingEditedDataFor-"+value,e);

            System.out.println("Exception while checking edited company info in company settings : "+field+" --Exception-- "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","CheckEditedData-"+value,"ErrorWhileCheckingEditedDataFor-"+value,e);

            System.out.println("Exception while checking edited company info in company settings : "+field+" --Exception-- "+e);
        }
        return false;
    }

    public static void editDDData(WebDriver driver, String name, String id, String dname, String value)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            String langvalue=null;

            if(id.equals("companytimezone_div"))
            {
                System.out.println("comaoishdjhkavsv m mmmmmmm1");
                int m,n;
                m = value.indexOf(')');
                n = value.indexOf('(',3);
                langvalue = value.substring(m+1,n);
            }
            //System.out.println(langvalue);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //Thread.sleep(1000);

            System.out.println("comaoishdjhkavsv m mmmmmmm2");
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);
            System.out.println("comaoishdjhkavsv m mmmmmmm3");

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            System.out.println("comaoishdjhkavsv m mmmmmmm4");
            //JavascriptExecutor je = (JavascriptExecutor)driver;
            //je.executeScript("scroll(0,1000)");
            //Thread.sleep(1000);

            System.out.println("comaoishdjhkavsv m mmmmmmm5");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-500)");
            System.out.println("comaoishdjhkavsv m mmmmmmm6");

            driver.findElement(By.id(id)).click();
            //Thread.sleep(500);
            System.out.println("comaoishdjhkavsv m mmmmmmm7");

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(dname)));
            WebElement elmt = driver.findElement(By.id(dname));

            System.out.println("comaoishdjhkavsv m mmmmmmm8");
            if(id.equals("companytimezone_div"))
            {
                System.out.println("comaoishdjhkavsv m mmmmmmm88");
                elmt.findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(langvalue);
            }
            else
            {
                System.out.println("comaoishdjhkavsv m mmmmmmm89");
                elmt.findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(value);
            }

            List<WebElement> lis=elmt.findElements(By.tagName("li"));

            System.out.println("comaoishdjhkavsv m mmmmmmm9");
            for(int i=0;i<lis.size();i++)
            {
                WebElement element = lis.get(i);
                WebElement element2 = element.findElement(By.tagName("div"));
                WebElement element3 = element2.findElement(By.tagName("span"));
                String title = element3.getAttribute("title");
                if(title.equals(value))
                {
                    element.click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Updated successfully","upcompanyinfo.do",etest);
                    System.out.println("comaoishdjhkavsv m mmmmmmm11");
                    //Thread.sleep(2000);
                    //wait.until(ExpectedConditions.textToBePresentInElementLocated(By.id(id),value));
                    Thread.sleep(1000);
                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
                    //WebDriverWait wait = new WebDriverWait(driver, 10);
                    System.out.println("comaoishdjhkavsv m mmmmmmm12");
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
                    //Thread.sleep(1000);
                    System.out.println("comaoishdjhkavsv m mmmmmmm13");

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

                    System.out.println("comaoishdjhkavsv m mmmmmmm14");
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));

                    System.out.println("comaoishdjhkavsv m mmmmmmm15");
                    if(value.equals(driver.findElement(By.id(id)).getText()))
                    {
                        etest.log(Status.PASS,KeyManager.getRealValue(name)+" is checked");

                        result.put(name, true);
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EditData-"+value,"MismatchEditedContent-"+value);
                    }
                    break;
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EditData-"+value,"ErrorWhileCheckingEditedDataFor-"+value,e);

            System.out.println("Exception while editing dropdown in company info in company settings : "+dname+" --Exception-- "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CompanySettings-Admin","EditData-"+value,"ErrorWhileCheckingEditedDataFor-"+value,e);

            System.out.println("Exception while editing dropdown in company info in company settings : "+dname+" --Exception-- "+e);
        }
    }

    //clear company info
    public static boolean clearCompanyInfo(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            //COMPANY INFO VIEW
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));

            editData(driver, "companyname", "Comp");
            //Thread.sleep(6000);

            editData(driver, "companywebsite", "http://z.z.z");
            //Thread.sleep(6000);

            editData(driver, "companyaddress", "");
            //Thread.sleep(6000);
            editData(driver, "companyemail", "");
            //Thread.sleep(6000);

            editData(driver, "companytelephone", "");
            //Thread.sleep(6000);

            editData(driver, "companyfax", "");
            //Thread.sleep(6000);
            editData(driver, "companydesc", "");
            //Thread.sleep(6000);
            editDDData(driver, "SC15", "companylanguage_div", "companylanguage_ddown", "English");
            //Thread.sleep(6000);
            editDDData(driver, "SC16", "companytimezone_div", "companytimezone_ddown", "( GMT 5:30 ) India Standard Time(IST)");
            //Thread.sleep(6000);

            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clearing data in company settings : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in company settings : "+e);
        }
        return false;
    }
}
