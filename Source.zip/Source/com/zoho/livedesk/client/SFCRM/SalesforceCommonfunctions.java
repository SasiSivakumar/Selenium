//$Id$
package com.zoho.livedesk.client.SFCRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.SFCRM.IntegrationSettingssalesforce;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.JSAPIW.JSApiutilWC;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;


import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class SalesforceCommonfunctions
{
    public static boolean Salesforceenable(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            IntegrationSettingssalesforce.enableSalesforceInteg(driver,SalesforceIntegration.etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            System.out.println("Initiating chat - Enable Salesforce");

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","EnableSalesforce","SalesforceEnableError",e);
                return false;
            }

            ChatWindow.acceptChat(driver,SalesforceIntegration.etest);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(2000);

            try
            {
                driver.findElement(By.id("crminfocontainer")).findElement(By.className("spt_tkadtbtnmn")).findElement(By.tagName("span"));
                SalesforceIntegration.etest.log(Status.PASS,"Push to Salesforce CRM is present");
                CommonFunctions.endChat(driver);
                return true;
            }
            catch(Exception e)
            {

              SalesforceIntegration.etest.log(Status.FAIL,"SalesforceCRM Not Enabled");
              TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","EnableSalesforce","SalesforceEnableError");
              CommonFunctions.endChat(driver);
              return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Salesforce enable in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","EnableSalesforce","SalesforceEnableError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Salesforce enable in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","EnableSalesforce","SalesforceEnableError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean Salesforcedisable(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            IntegrationSettingssalesforce.disablesalesforceInteg(driver,SalesforceIntegration.etest);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";


            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            System.out.println("Initiating chat - Disable Salesforce");

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","DisableSalesforce","Error",e);
                return false;
            }

            ChatWindow.acceptChat(driver,SalesforceIntegration.etest);

            Thread.sleep(2000);
            try
            {
                driver.findElement(By.id("crminfocontainer")).findElement(By.className("spt_tkadtbtnmn")).findElement(By.tagName("span"));
                SalesforceIntegration.etest.log(Status.FAIL,"Push to Salesforce CRM is present");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","DisableSalesforce","SalesforceDisableError");
                CommonFunctions.endChat(driver);
                //chatwindow.quit();
                return false;
            }
            catch(Exception e)
            {
                SalesforceIntegration.etest.log(Status.PASS,"SalesforceCRM disabled");
                CommonFunctions.endChat(driver);
                //chatwindow.quit();
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Salesforce disable in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","DisableSalesforce","SalesforceDisableError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Salesforce disable in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","DisableSalesforce","SalesforceDisableError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    //Manual push visitor as contact in CRM
    public static boolean manualContact(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","Manualcontact","ManualcontactError",e);
                return false;
            }

            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred");
            }
            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
          //  WebElement ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span");
            //driver.findElement(By.id("crminfocontainer")).findElement(By.className("spt_tkadtbtnmn")).findElement(By.tagName("span"));
            //new Actions(driver).moveToElement(ptc).perform();
            //ptc.click();
            // //CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfocontainer"),"classname","spt_tkadtbtnmn"),"tagname","span");
            //ptc.click();
            // //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("crminfocontainer")));
            // Thread.sleep(3000);
            CommonUtil.elfinder(driver,"xpath",".//*[@class='sal_intico']").click();
            //CommonFunctions.clickContact(driver);

            // String ptc1 = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span");
            // ptc1.getText();
            //System.out.println("Disble PTC : >>"+ptc1);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contact_div")));
            CommonUtil.elfinder(driver,"id","contact_head").click();

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","contact_div");

            CommonUtil.elementfinder(driver,crmelmt,"id","accountname").sendKeys(vacname);

            Thread.sleep(500);
            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();
            Thread.sleep(2000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            System.out.println(contactname+"<><>"+contactemail+"<><>"+contactphone+"<><>"+contacttype);

            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))//&&contactacname.equals(vacname)
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--AutomationComp--"+vphone+"--Lead--Actual:"+contactname+"--"+contactemail+"----"+contactphone+"--"+contacttype+"--");//"+contactacname+"
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","Manualcontact","ManualcontactError");
                CommonFunctions.endChat(driver);
                return false;
            }
            else
            {
              CommonFunctions.endChat(driver);
              SalesforceIntegration.etest.log(Status.PASS,"manualContact Added");
              return true;
            }
        }

        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm manually push as contact in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","Manualcontact","ManualcontactError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm manually push as contact in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","Manualcontact","ManualcontactError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean addPotential(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();

            CommonFunctions.chatHistoryClick(driver);
            CommonFunctions.clickAddPotenChatHis(driver);

            WebElement potelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","addpotentialdiv"),"id","savepotentialfrm");

            CommonUtil.elementfinder(driver,potelmt,"id","potentialname").sendKeys(pname);
            new Select(CommonUtil.elementfinder(driver,potelmt,"xpath",".//select[@id='potentialstage'][@class='crmseld']")).selectByVisibleText("Closed Won");
            CommonUtil.elementfinder(driver,potelmt,"id","potentialamount").sendKeys(pamt);
            CommonUtil.elementfinder(driver,potelmt,"id","potentialclosedate").click();

            Thread.sleep(500);
            if(!((CommonUtil.elementfinder(driver,potelmt,"id","crmdatepickerdiv").getAttribute("style")).contains("display: block;")))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Potential div is not displayed");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddPotential","AddPotentialError");
                return false;
            }

            WebElement caelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","potentialclosedatediv"),"tagname","table");
            WebElement calelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,caelmt,"tagname","table"),"classname","datepickerDays");

            String pdatedd = calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String pdatemmyy = caelmt.findElement(By.tagName("table")).findElement(By.className("datepickerMonth")).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String mmddyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"mmddyy");
            String ddmmyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"ddmmyy");

            calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).click();

            Thread.sleep(500);
            CommonUtil.elementfinder(driver,potelmt,"classname","rg-button").click();

            Thread.sleep(2000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!(driver.findElement(By.id("associatedpotentialdiv")).getAttribute("style").contains("none")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement chatlead = CommonUtil.elfinder(driver,"id","associatedpotentialdiv");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String potname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String potstage = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String potamt = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String potdate = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            if(!(potname.equals(pname)&&potstage.equals("Closed Won")&&potamt.equals(pamt)&&potdate.equals(ddmmyy)))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+pname+"--Closed Won--"+pamt+"--"+ddmmyy+"--Actual:"+potname+"--"+potstage+"--"+potamt+"--"+potdate+"--");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddPotential","AddPotentialError");
                return false;
            }
            else
            {
              SalesforceIntegration.etest.log(Status.PASS,"Potential added");
              return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm add potential to added contact in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddPotential","AddPotentialError",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm add potential to added contact in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddPotential","AddPotentialError",e);
            return false;
        }
    }

    public static boolean pushToCRMButton(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);
            String widgetcode = SalesforceIntegration.widgetcode;
            System.out.println(widgetcode+"widgetcodepushToCRMButton");
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","PushToCRM","PushTocrmError",e);
                chatwindow.quit();
                return false;
            }

            acceptChat(driver,SalesforceIntegration.etest);
            //Thread.sleep(3000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(1500);
            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            System.out.println("Disble PTC : >>"+ptc);
            if(ptc.contains("Push To Salesforce CRM"))
            {
                CommonFunctions.endChat(driver);

                chatwindow.quit();
                Thread.sleep(1000);

                chatwindow = VisitorSite.chatdriver(widgetcode);

                IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "chk",SalesforceIntegration.etest);
                IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,SalesforceIntegration.etest);
                Functions.refreshSiteAndWaitForRSID(driver);
                Thread.sleep(1000);

                vemail = "email1@"+System.currentTimeMillis()+".com";
                try
                {
                    VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
                }
                catch(Exception e)
                {
                    TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","PushToCRM","PushTocrmError",e);
                    chatwindow.quit();
                    return false;
                }
                ChatWindow.acceptChat(driver,SalesforceIntegration.etest);
                Thread.sleep(3000);

                try
                {
                    driver.findElement(By.id("crminfocontainer")).findElement(By.className("spt_tkadtbtnmn")).findElement(By.tagName("span"));
                    SalesforceIntegration.etest.log(Status.FAIL,"Push to CRM is present");
                    TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","PushToCRM","PushTocrmError");
                    CommonFunctions.endChat(driver);
                    chatwindow.quit();
                    return false;
                }
                catch(Exception e)
                {
                    SalesforceIntegration.etest.log(Status.PASS,"Push to CRM is Not present");
                    CommonFunctions.endChat(driver);
                    chatwindow.quit();
                    return true;
                }
            }
            SalesforceIntegration.etest.log(Status.FAIL,"Expected:Push To Salesforce CRM--Actual"+ptc+"--");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","PushToCRM","PushTocrmError");
            CommonFunctions.endChat(driver);
            chatwindow.quit();
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking push to crm button in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","PushToCRM","PushTocrmError",e);
            CommonFunctions.endChat(driver);
            chatwindow.quit();
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking push to crm button in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","PushToCRM","PushTocrmError",e);
            CommonFunctions.endChat(driver);
            chatwindow.quit();
            return false;
        }
    }

    //Add task to added contact
    public static boolean addTaskContact(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMSI1","newcusaddtask_div_div","newcusaddtask_div_ddown","Tomorrow",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","AddTaskContact","AddTaskContactError",e);
                return false;
            }

            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            //TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Click Mychats");
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred");
            }
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(2000);
            WebElement ptc = CommonUtil.elfinder(driver,"xpath",".//*[@class='sal_intico']");
            //driver.findElement(By.id("crminfocontainer")).findElement(By.className("spt_tkadtbtnmn")).findElement(By.tagName("span"));
            //CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfocontainer"),"classname","spt_tkadtbtnmn"),"tagname","span");
            ptc.click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contact_div")));
            CommonUtil.elfinder(driver,"id","contact_head").click();

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","contact_div");

            CommonUtil.elementfinder(driver,crmelmt,"id","accountname").sendKeys(vacname);
            CommonUtil.elementfinder(driver,crmelmt,"id","addtask").click();

            Thread.sleep(500);
            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contactinfodiv")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
          //  String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            //&&contactacname.equals(vacname)
            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"----"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"----"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddTaskContact","AddTaskContactError");
                CommonFunctions.endChat(driver);
                return false;
            }

            else
            {
                SalesforceIntegration.etest.log(Status.PASS,"addTaskContact Passed");
                CommonFunctions.endChat(driver);
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while adding task to added contact in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddTaskContact","AddTaskContactError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while adding task to added contact in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","AddTaskContact","AddTaskContactError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean statusInSalesiqMissed(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "chk",SalesforceIntegration.etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,SalesforceIntegration.etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMIS1","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
                CommonFunctions.missChat(chatwindow);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","StatusMissed","StatusMissedError",e);
                chatwindow.quit();
                return false;
            }

            chatwindow.quit();
            Thread.sleep(5000);

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(2000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("common_missed"))));

            CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_missed")).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("missed_div")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("missed_div")));

            Thread.sleep(1000);

            WebElement celmt = driver.findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));

            Thread.sleep(1000);
          //  wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_history")).click();

            Thread.sleep(2000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("history_div")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));

            for(int i = 1;i<=3;i++)
            {
                WebElement hiselmt = driver.findElement(By.id("history_mcontent")).findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0);
                String chname = hiselmt.findElement(By.className("secnd-clm")).findElement(By.tagName("h2")).getText();

                if(chname.equals(vname))
                {
                    String visstatusclass = hiselmt.findElement(By.className("thrd-clm")).findElement(By.className("grayish")).findElement(By.tagName("em")).getAttribute("class");
                    String visstatustitle = hiselmt.findElement(By.className("thrd-clm")).findElement(By.className("grayish")).findElement(By.tagName("em")).getAttribute("title");

                    System.out.println("here 322");
                    if(visstatustitle.equals("Missed")&&visstatusclass.equals("visitstatus-1"))
                    {
                        SalesforceIntegration.etest.log(Status.PASS,"Checked");
                        return true;
                    }
                    SalesforceIntegration.etest.log(Status.FAIL,vname+"Expected:Missed--visitstatus-1--Actual"+visstatustitle+"--"+visstatusclass+"--");
                    TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusMissed","StatusMissedError");
                    return false;
                }

                Thread.sleep(3000);
                Functions.refreshSiteAndWaitForRSID(driver);
                Thread.sleep(1000);
            }
            SalesforceIntegration.etest.log(Status.FAIL,vname+" is not present");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusMissed","StatusMissedError");
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking status showed in salesiq missed in Salesforce integration :");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusMissed","StatusMissedError",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking status showed in salesiq missed in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusMissed","StatusMissedError",e);
            return false;
        }
    }

    public static boolean statusInSalesiqTracked(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "chk",SalesforceIntegration.etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,SalesforceIntegration.etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMIS1","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Tracked in CRM",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
                CommonFunctions.missChat(chatwindow);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","StatusTrackedinCRM","StatusTrackedinCRMError",e);
                chatwindow.quit();
                return false;
            }

            chatwindow.quit();
            Thread.sleep(120000);

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(2000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_history")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_mcontent")));
            for(int i = 1;i<=3;i++)
            {
                WebElement hiselmt = driver.findElement(By.id("history_mcontent")).findElement(By.id("historylist")).findElements(By.className("cursr-point")).get(0);
                String chname = hiselmt.findElement(By.className("secnd-clm")).findElement(By.tagName("h2")).getText();
                System.out.println(chname);
                if(chname.equals(vname))
                {
                    String visstatusclass = hiselmt.findElement(By.className("thrd-clm")).findElement(By.className("grayish")).findElement(By.tagName("em")).getAttribute("class");
                    String visstatustitle = hiselmt.findElement(By.className("thrd-clm")).findElement(By.className("grayish")).findElement(By.tagName("em")).getAttribute("title");
                    System.out.println(visstatusclass);
                    System.out.println(visstatustitle);
                    System.out.println("here 311");

                    if(visstatustitle.equals("Tracked in SalesforceCRM")&&visstatusclass.equals("visitstatus10"))
                    {
                        SalesforceIntegration.etest.log(Status.PASS,"Checked");
                        return true;
                    }
                    SalesforceIntegration.etest.log(Status.FAIL,"Expected:Tracked in SalesforceCRM--visitstatus10--Actual:"+visstatustitle+"--"+visstatusclass+"--");
                    TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusTrackedinCRM","StatusTrackedinCRMError");
                    return false;
                }

                Thread.sleep(1000);
                Functions.refreshSiteAndWaitForRSID(driver);
            }
            SalesforceIntegration.etest.log(Status.FAIL,vname+" is not present");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusTrackedinCRM","StatusTrackedinCRMError");
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking status showed in salesiq tracked in crm in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusTrackedinCRM","StatusTrackedinCRMError",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking status showed in salesiq tracked in crm in Salesforce integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","StatusTrackedinCRM","StatusTrackedinCRMError",e);
            return false;
        }
    }

    public static boolean autoMissedContact(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "chk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMIS1","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
                CommonFunctions.missChat(chatwindow);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushMissedContactEnabled","Error",e);
                return false;
            }

            Thread.sleep(80000);
            Functions.refreshSiteAndWaitForRSID(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("common_missed"))));
            Thread.sleep(1000);

            //driver.findElement(By.partialLinkText(ResourceManager.getRealValue("common_missed"))).click();
            CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_missed")).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("missed_div")));
            Thread.sleep(1000);

            WebElement celmt = driver.findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            //celmt.findElement(By.linkText(vname)).click();
            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));



            try
            {
                wait.until(new Function<WebDriver, Boolean>() {
                   public Boolean apply(WebDriver driver) {
                       try
                       {
                           if((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true"))
                               return true;
                       }
                       catch (Exception e) {}
                       return false;
                   }
                });
            }
            catch(Exception e){}

            // if(!((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            // {
            //     etest.log(Status.FAIL,"CRM div is not present");
            //     TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactEnabled","Error");
            //     return false;
            // }

            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");
            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            //String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            System.out.println(contactemail+"dd");
            System.out.println(contactphone);
            System.out.println(contacttype);
            System.out.println(contactemail+"<><>"+contactphone+"<><>"+contacttype);
            if(!(contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))//&&contactacname.equals(vacname)&&contactname.equals(vname)
            {
                // "+vname+"-- "+contactname+"--
                etest.log(Status.FAIL,"Expected:"+vemail+"--"+vphone+"--Contact--Actual:"+contactemail+"--"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactEnabled","Error");
                return false;
            }
            else
            {
              etest.log(Status.PASS,"AutoPushMissedContactEnabled");
              return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push missed contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactEnabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push missed contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactEnabled","Error",e);
            return false;
        }
    }

    public static boolean autoAttendedContact(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAttendedContactEnabled","Error",e);
                return false;
            }

            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            //TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Click Mychats");
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred :" + e);
            }
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            //String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            System.out.println(contactemail+"dd");
            System.out.println(contactphone);
            System.out.println(contacttype);
            System.out.println(contactemail+"<><>"+contactphone+"<><>"+contacttype);
            
            if(!(contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))    //&&contactacname.equals(vacname)contactname.equals(vname)&&
            {
                etest.log(Status.FAIL,"Expected:"+vemail+"--"+vphone+"--Contact--Actual:"+contactemail+"--"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Error");
                CommonFunctions.endChat(driver);
                return false;
            }
            else
            {
              etest.log(Status.PASS,"PushAttendedContactEnabled");
              CommonFunctions.endChat(driver);
              return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended Contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended Contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean autoAccessedContact(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Accessed", 2, "chk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedContactEnabled","Error",e);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            CommonFunctions.endChat(driver);
            Thread.sleep(2000);
            try
            {
                chatwindow.get("https://www.zoho.com");
                Thread.sleep(70000);

                String widgetcode = SalesforceIntegration.widgetcode;
                System.out.println(widgetcode+"widgetcodeautoAccessedContact");
                VisitorWindow.clickpreviouschathistoryicon(chatwindow,widgetcode);
                Thread.sleep(1000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedContactEnabled","Error",e);
                return false;
            }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_history")).click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("historylist")));

            WebElement celmt = driver.findElement(By.id("history_div")).findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            //celmt.findElement(By.linkText(vname)).click();
            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");
            Thread.sleep(4000);
            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            //String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            System.out.println(contactname);
            System.out.println(contactemail);
            //System.out.println(contactphone);
            System.out.println(contacttype);
            System.out.println(contactname+"<><>"+contactemail+"<><>"+contacttype);

            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contacttype.equals("Contact")))//&&contactphone.equals(vphone)&&contactacname.equals(vacname)contactname.equals(vname)
            {
                // "+contactname+"--"+vname+"--"+vphone+""+contactphone+"
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--Contact--Actual:"+contactname+"--"+contactemail+"----"+contacttype+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedContactEnabled","Error");
                //CommonFunctions.endChat(driver);
                return false;
            }
            else
            {
              etest.log(Status.PASS,"AutoAccessedContact Enabled");
              //CommonFunctions.endChat(driver);
              return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push Accessed Contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedContactEnabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push Accessed Contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedContactEnabled","Error",e);
            return false;
        }
    }

  public static boolean autoAttendedContactDisabled(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAttendedContactDisabled","Error",e);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(2000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("Waited");

            // String ptc1 = driver.findElement(By.xpath(".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span")).getText();
            // System.out.println("PTC : >>"+ptc1);
            //String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span").getText();
            //String ptc = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfocontainer"),"classname","spt_tkadtbtnmn"),"tagname","span").getText();
            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            System.out.println("PTC : >>"+ptc);

            if(!ptc.contains("Push To Salesforce CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push to Salesforce CRM--Actual"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactDisabled","Error");
                CommonFunctions.endChat(driver);
                return false;
            }
            else
            {
              etest.log(Status.PASS,"autoAttendedContactDisabled");
              CommonFunctions.endChat(driver);
              return true;
            }
          }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended Contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactDisabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended Contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactDisabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean autoMissedContactDisabled(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMIS1","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
                CommonFunctions.missChat(chatwindow);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushMissedContactDisabled","Error",e);
                return false;
            }

            Thread.sleep(60000);
            Functions.refreshSiteAndWaitForRSID(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("common_missed"))));
            Thread.sleep(1000);

            //driver.findElement(By.partialLinkText(ResourceManager.getRealValue("common_missed"))).click();
            CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_missed")).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("missed_div")));
            Thread.sleep(1000);

            WebElement celmt = driver.findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            //celmt.findElement(By.linkText(vname)).click();
            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));

            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("Waited");

            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            //driver.findElement(By.xpath(".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span")).getText();
            System.out.println("PTC : >>"+ptc);

            // String ptc = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfocontainer"),"classname","spt_tkadtbtnmn"),"tagname","span").getText();
            // System.out.println("PTC : >>"+ptc);


            if(!ptc.contains("Push To Salesforce CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push to Salesforce CRM--Actual"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactDisabled","Error");
                return false;
            }
            else
            {
              etest.log(Status.PASS,"autoMissedContactDisabled");
              return true;
            }
          }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push missed contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactDisabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push missed contact in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedContactDisabled","Error",e);
            return false;
        }
    }

    public static boolean autoAccessedContactDisabled(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Accessed", 2, "unchk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedContactDisabled","Error",e);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            CommonFunctions.endChat(driver);
            Thread.sleep(2000);
            try
            {
                chatwindow.get("https://www.zoho.com");
                Thread.sleep(70000);

                String widgetcode = SalesforceIntegration.widgetcode;
                System.out.println(widgetcode+"widgetcodeautoAccessedContactDisabled");
                VisitorWindow.clickpreviouschathistoryicon(chatwindow,widgetcode);
                Thread.sleep(1000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedContactDisabled","Error",e);
                return false;
            }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_history")).click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("historylist")));

            WebElement celmt = driver.findElement(By.id("history_div")).findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            //celmt.findElement(By.linkText(vname)).click();
            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(3000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");

            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            System.out.println("PTC : >>"+ptc);

            if(!ptc.contains("Push To Salesforce CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push to Salesforce CRM--Actual:"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedContactDisabled","Error");
                return false;
            }
            else
            {
                etest.log(Status.PASS,"autoAccessedContactDisabled");
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedContactDisabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in Salesforce integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedContactDisabled","Error",e);
            return false;
        }
    }

    public static boolean contUser(WebDriver driver,WebDriver chatwindow,String uname,String type)
    {
        try
        {
            System.out.println("Came to Attend");
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "chk",SalesforceIntegration.etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "chk",SalesforceIntegration.etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Accessed", 2, "chk",SalesforceIntegration.etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,1,SalesforceIntegration.etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMIS1","assignowner_div_div","assignowner_div_ddown",uname,SalesforceIntegration.etest);
            //uname = ddvalue smart xerago //

            try
            {
            JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.id("crmtypelist")));
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("crmtypelist_div")));
            Thread.sleep(1500);
            driver.findElement(By.id("crmtypelist_div")).click();
            driver.switchTo().activeElement();
            driver.findElement(By.xpath(".//*[@id='crmtypelist_ddown']//*[contains(@title, '" + type + "')]")).click();
            System.out.println(".//*[@id='crmtypelist_ddown']//*[contains(@title, '" + type + "')]");
            WebElement Searchfield = driver.findElement(By.id("ldfields"));
            wait.until(ExpectedConditions.visibilityOf(Searchfield));
            Searchfield.clear();
            Searchfield.sendKeys("Owner");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@title='" + type + " Owner']")));
            Actions Cowner = new Actions(driver);
            WebElement Cowner1 = driver.findElement(By.xpath(".//*[@title='"+ type + " Owner']"));
            System.out.println(".//*[@title='"+ type + " Owner']");
            WebElement Cownerd = driver.findElement(By.id("dropblearea"));
            Cowner.dragAndDrop(Cowner1, Cownerd).perform();
          }
          catch(Exception e)
          {
              TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","RespUser","Info",e);
              SalesforceIntegration.etest.log(Status.INFO,"Already element Present");
              return false;
          }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","RespUser","Error",e);
                return false;
            }

            ChatWindow.acceptChat(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            try
            {
                wait.until(new Function<WebDriver, Boolean>() {
                   public Boolean apply(WebDriver driver) {
                       try
                       {
                           if((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true"))
                               return true;
                       }
                       catch (Exception e) {}
                       return false;
                   }
                });
            }
            catch(Exception e){}

            if(!((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"CRM div is not present");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","RespUser","Error");
                CommonFunctions.endChat(driver);
                return false;
            }

            Thread.sleep(1000);

            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            String Contactowner = chatlead.findElement(By.xpath(".//*[@title=''" + type + " Owner']/following-sibling::div")).getText();

            if(!(Contactowner.equals(uname)))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+uname+"--Actual:"+Contactowner+"--");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","RespUser","Error");
                CommonFunctions.endChat(driver);
                return false;
            }

            Thread.sleep(2000);
            try
            {
                 CommonFunctions.endChat(driver);
                return false;
            }
            catch(Exception e)
            {
                CommonFunctions.endChat(driver);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","RespUser","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","RespUser","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean manualLead(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","ManualLead","ManualLeadError",e);
                return false;
            }

            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            //TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Click Mychats");
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred");
            }
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(2000);

            //CommonFunctions.clickLead(driver);


            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']")));
            CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span").click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lead_div")));

            Thread.sleep(500);

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","lead_div");
            wait.until(ExpectedConditions.visibilityOf(crmelmt));
            CommonUtil.elementfinder(driver,crmelmt,"id","companyname").sendKeys("AutomationComp");

            new Select(CommonUtil.elementfinder(driver,crmelmt,"xpath",".//select[@id='lstatus'][@class='crmseld']")).selectByVisibleText("Working - Contacted");
            Thread.sleep(1000);

            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");
            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            String leadname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leademail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String leadcomp = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String leadphone = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
          //  String leadphonea = driver.findElement(By.xpath(".//*[@id='crm_data']/div[4]/div[2]")).getText();
            //String leadtype = chatelmts.get(4).findElement(By.className("crmld_infrht")).getText();

            //System.out.println(leadphonea);
            System.out.println("<<<<"+leadname+">><<"+leademail+">><<"+leadcomp+">><<"+leadphone+">>>>");//+leadtype+

            if(!(leadname.equals(vname)&&leademail.equals(vemail)&&leadcomp.equals("AutomationComp")&&leadphone.equals(vphone)))//&&leadtype.equals("Lead")
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--AutomationComp--"+vphone+"--Lead--Actual:"+leadname+"--"+leademail+"--"+leadcomp+"--"+leadphone+"----");//+leadtype+
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ManualLead","ManualLeadError");
                CommonFunctions.endChat(driver);
                return false;
            }
            else
            {
              SalesforceIntegration.etest.log(Status.PASS,"manualLead is added");
              CommonFunctions.endChat(driver);
            return true;
          }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm manually push as lead in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ManualLead","ManualLeadError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm manually push as lead in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ManualLead","ManualLeadError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }
    public static boolean leadToContactNoPotential(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            final FluentWait failwait = CommonUtil.waitreturner(driver,5,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
                return false;
            }

            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            //TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Click Mychats");
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred");
            }
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(1000);

            //CommonFunctions.clickLead(driver);

            CommonUtil.elfinder(driver,"xpath",".//*[@class='sal_intico']").click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lead_div")));

            Thread.sleep(500);

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","lead_div");

            CommonUtil.elementfinder(driver,crmelmt,"id","companyname").sendKeys("AutomationComp");

            new Select(CommonUtil.elementfinder(driver,crmelmt,"xpath",".//select[@id='lstatus'][@class='crmseld']")).selectByVisibleText("Working - Contacted");
            Thread.sleep(1000);

            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();

            Thread.sleep(4000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));

            Thread.sleep(1000);
            WebElement leaddata = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","convertlead_div"),"id","convertlead");

            leaddata.findElements(By.className("rg-button")).get(1).click();

            Thread.sleep(1000);
            Tab.waitForLoadingSuccessWithBanner(driver,"Lead converted successfully","invokeaction.do",SalesforceIntegration.etest);

            Thread.sleep(1000);

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        failwait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));
                        return false;
                    }
                    catch(Exception e)
                    {
                        return true;
                    }
                }
            });

            if(!(CommonUtil.elfinder(driver,"id","addpotentialdiv").getAttribute("style").contains("none")))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Potential div is displayed");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                System.out.println("Convert Error Contact without potential add potential missing");
                CommonFunctions.endChat(driver);
                return false;
            }

            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");

            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            System.out.println("<<<<"+contactname+">><<"+contactemail+">><<"+contactphone+">><<"+contacttype+">>>>");

            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))//&&contactacname.equals("AutomationComp")
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"----"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                System.out.println("Convert Error Contact without potential Error");
                CommonFunctions.endChat(driver);
                return false;
            }
            else
            {
              SalesforceIntegration.etest.log(Status.PASS,"leadToContactNoPotential is added");
              CommonFunctions.endChat(driver);
              return true;
          }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while converting lead to contact without potential in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while converting lead to contact without potential in crm integration : ");
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
            CommonFunctions.endChat(driver);
            return false;
        }

    }

    //convert lead to contact with potential
    public static boolean leadToContactWithPotential(WebDriver driver,WebDriver chatwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            final FluentWait failwait = CommonUtil.waitreturner(driver,5,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",SalesforceIntegration.etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,SalesforceIntegration.etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError",e);
                return false;
            }

            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            //TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedContactEnabled","Click Mychats");
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred");
            }
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(3000);

            //CommonFunctions.clickLead(driver);

            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span")));
            CommonUtil.elfinder(driver,"xpath",".//*[@class='sal_intico']").click();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lead_div")));

            Thread.sleep(500);

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","lead_div");

            CommonUtil.elementfinder(driver,crmelmt,"id","companyname").sendKeys("AutomationComp");

            new Select(CommonUtil.elementfinder(driver,crmelmt,"xpath",".//select[@id='lstatus'][@class='crmseld']")).selectByVisibleText("Working - Contacted");
            Thread.sleep(1000);

            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();

            Thread.sleep(4000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));

            Thread.sleep(2000);
            WebElement leaddata = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","convertlead_div"),"id","convertlead");

            CommonUtil.elementfinder(driver,leaddata,"id","potential").click();
            Thread.sleep(1000);

            WebElement potdata = CommonUtil.elementfinder(driver,leaddata,"id","portentialdiv");

            CommonUtil.elementfinder(driver,potdata,"id","potentialname").sendKeys(pname);
            new Select(CommonUtil.elementfinder(driver,potdata,"xpath",".//select[@id='potentialstage'][@class='crmseld']")).selectByVisibleText("Qualification");
            CommonUtil.elementfinder(driver,potdata,"id","potentialamount").sendKeys(pamt);
            CommonUtil.elementfinder(driver,potdata,"id","potentialclosedate").click();

            Thread.sleep(1000);
            if(!((potdata.findElement(By.id("crmdatepickerdiv")).getAttribute("style")).contains("display: block;")))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Date picker is not visible");
                TakeScreenshot.screenshot(chatwindow,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError");
                CommonFunctions.endChat(driver);
                return false;
            }

            WebElement caelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","potentialclosedatediv"),"tagname","table");
            WebElement calelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,caelmt,"tagname","table"),"classname","datepickerDays");

            String pdatedd = calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String pdatemmyy = caelmt.findElement(By.tagName("table")).findElement(By.className("datepickerMonth")).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String mmddyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"mmddyy");
            String ddmmyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"ddmmyy");

            calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).click();

            Thread.sleep(500);
            leaddata.findElements(By.className("rg-button")).get(1).click();

            Thread.sleep(1000);
            Tab.waitForLoadingSuccessWithBanner(driver,"Lead converted successfully","invokeaction.do",SalesforceIntegration.etest);

            Thread.sleep(1000);

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        failwait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));
                        return false;
                    }
                    catch(Exception e)
                    {
                        return true;
                    }
                }
            });

            if(!(CommonUtil.elfinder(driver,"id","addpotentialdiv").getAttribute("style").contains("none")))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Potential div is displayed");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError");
                System.out.println("Convert Error Contact add potential missing");
                CommonFunctions.endChat(driver);
                return false;
            }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");

            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            System.out.println(contactname);
            System.out.println("<<<<"+contactname+">><<"+contactemail+">><<"+contactphone+">><<"+contacttype+">>>>");//+contactacname+

            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))//&&contactacname.equals("AutomationComp")
            {
                // "--AutomationComp--
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"----"+contactphone+"--"+contacttype+"--");//"+contactacname+"
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError");
                CommonFunctions.endChat(driver);
                return false;
            }

            Thread.sleep(3000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");
            WebElement chatpot = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='associatedpotentialdiv']");
            List<WebElement> potelmts = chatpot.findElements(By.className("crmld_infomn"));

            String potname = potelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String potstage = potelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String potamt = potelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String potdate = potelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            if(!(potname.equals(pname)&&potstage.equals("Qualification")&&potamt.equals(pamt)&&potdate.equals(ddmmyy)))
            {
                SalesforceIntegration.etest.log(Status.FAIL,"Expected:"+pname+"--Qualification--"+pamt+"--"+ddmmyy+"--Actual:"+potname+"--"+potstage+"--"+potamt+"--"+potdate+"--");
                TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError");
                CommonFunctions.endChat(driver);
                return false;
            }

            else
            {
              SalesforceIntegration.etest.log(Status.PASS,"leadToContactWithPotential is added");
              CommonFunctions.endChat(driver);
              return true;
          }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while converting crm lead to contact with potential in crm integration : "+e);
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while converting crm lead to contact with potential in crm integration : "+e);
            TakeScreenshot.screenshot(driver,SalesforceIntegration.etest,"SalesforceIntegration","ConvLeadPot","ConvLeadPotError",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean autoAttendedLead(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,0,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                JSApiutilWC.changeConfigInfo(chatwindow,"{\"Company\": \"Zoho\"}");
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAttendedLeadEnabled","Error",e);
                return false;
            }


            String id = Chataccept(driver,SalesforceIntegration.etest);
            Thread.sleep(2000);
            try
            {
            driver.findElement(By.xpath(".//*[@id='ptitle']/span[contains(text(), '" + vname + "')]")).click();
            }
            catch(Exception e)
            {
            System.out.println("While Click My chats window Exception occurred");
            }

            //Thread.sleep(5000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(2000);
            WebElement chatlead = CommonUtil.elfinder(driver,"xpath",".//*[@id='" + id +"']//*[@id='crm_data']");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            //String leadname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leademail = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leadcomp = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String leadphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String leadtype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            //leadname.equals(vname)&&
            System.out.println(leademail);
            System.out.println(leadphone);
            System.out.println(leadcomp);

            if(!(leademail.equals(vemail)&&leadphone.equals(vphone)&&leadcomp.equals("Zoho")))//&&leadcomp.equals("AutomationComp")
            {
                // "+vname+"--  "+leadname+"--
                etest.log(Status.FAIL,"Expected:"+vemail+"--zoho--"+vphone+"--Actual:"+leademail+"--"+leadcomp+"--"+leadphone+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedLeadEnabled","Error");
                CommonFunctions.endChat(driver);
                return false;
            }

            //return true
            else
            {
            Thread.sleep(2000);
            etest.log(Status.PASS,"autoAttendedLead Enabled");
            CommonFunctions.endChat(driver);
            return true;
          }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedLeadEnabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedLeadEnabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean autoAttendedLeadDisabled(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,0,etest);

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAttendedLeadDisabled","Error",e);
                return false;
            }

          //ChatWindow.acceptChat(driver,etest);
            acceptChat(driver,SalesforceIntegration.etest);
            Thread.sleep(3000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            // String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[@class='spt_crtnewreqst']/a/span").getText();
            // System.out.println("PTC : >>"+ptc);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("crminfocontainer")));
            Thread.sleep(1500);
            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            System.out.println("PTC : >>"+ptc);

            if(!ptc.contains("Push To Salesforce CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push to Salesforce CRM--Actual:"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedLeadDisabled","Error");
                CommonFunctions.endChat(driver);
                return false;
            }

            else
            {
              Thread.sleep(2000);
              etest.log(Status.PASS,"autoAttendedLeadDisabled");
              CommonFunctions.endChat(driver);
              return true;
          }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedLeadDisabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAttendedLeadDisabled","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean autoMissedLead(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "chk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,0,etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMSI1","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                JSApiutilWC.changeConfigInfo(chatwindow,"{\"Company\": \"Zoho\"}");
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushMissedLeadEnabled","Error",e);
                return false;
            }

            Thread.sleep(80000);
            Functions.refreshSiteAndWaitForRSID(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("common_missed"))));
            Thread.sleep(1000);

            //driver.findElement(By.partialLinkText(ResourceManager.getRealValue("common_missed"))).click();
            CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_missed")).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("missed_div")));
            Thread.sleep(1000);

            WebElement celmt = driver.findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            //celmt.findElement(By.linkText(vname)).click();
            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            try
            {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("schedule_tip")));
            Actions a = new Actions(driver);
            WebElement tooltip1 = driver.findElement(By.className("schedule_tip"));
            a.moveToElement(tooltip1).build().perform();
            driver.findElement(By.xpath(".//*[@id='bannerclose']")).click();
            }
            catch(Exception e)
            {
              System.out.println("Tooltip not showing");
            }

            Thread.sleep(2000);
            Functions.refreshSiteAndWaitForRSID(driver);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");

            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            //String leadname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leademail = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leadcomp = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String leadphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String leadtype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            System.out.println(leademail);
            System.out.println(leadcomp);
            System.out.println(leadphone);

            // leadname.equals(vname)&&
            if(!(leademail.equals(vemail)&&leadphone.equals(vphone)&&leadcomp.equals("Zoho")))//&&leadcomp.equals("AutomationComp")
            {
                // "+vname+"--  "+leadname+"--
                etest.log(Status.FAIL,"Expected:"+vemail+"--"+vphone+"--Zoho--Actual"+leademail+"--"+leadphone+"--"+leadcomp+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadEnabled","Error");
                return false;
            }

            else
            {
              Thread.sleep(2000);
              etest.log(Status.PASS,"autoMissedLead");
              return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push missed lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadEnabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push missed lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadEnabled","Error",e);
            return false;
        }
    }

    public static boolean autoMissedLeadDisabled(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,0,etest);
            IntegrationSettingssalesforce.sfcrmintegconfig(driver,"CRMSI1","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
                CommonFunctions.missChat(chatwindow);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushMissedLeadDisabled","Error",e);
                return false;
            }

            Thread.sleep(60000);
            Functions.refreshSiteAndWaitForRSID(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("common_missed"))));
            Thread.sleep(1000);

            //driver.findElement(By.partialLinkText(ResourceManager.getRealValue("common_missed"))).click();
            CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_missed")).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("missed_div")));
            Thread.sleep(1000);

            WebElement celmt = driver.findElement(By.id("historylist"));

            List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

            WebElement visitor_name = CommonUtil.getElement(CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

            CommonUtil.clickWebElement(driver,visitor_name);

            //celmt.findElement(By.linkText(vname)).click();
            // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            if(((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                etest.log(Status.FAIL,"CRM div is present");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadDisabled","Error");
                return false;
            }

            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            System.out.println("PTC : >>"+ptc);

            if(!ptc.contains("Push To Salesforce CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push to Salesforce CRM--Actual:"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadDisabled","Error");
                return false;
            }
            else
            {

            Thread.sleep(2000);
            etest.log(Status.PASS,"autoMissedLeadDisabled Passed");
            return true;
          }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push missed lead disabled in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadDisabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push missed lead disabled in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushMissedLeadDisabled","Error",e);
            return false;
        }
    }

    public static boolean autoAccessedLead(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Accessed", 2, "chk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,0,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                JSApiutilWC.changeConfigInfo(chatwindow,"{\"Company\": \"Zoho\"}");
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedLeadEnabled","Error",e);
                return false;
            }

            ChatWindow.acceptChat(driver,etest);
            CommonFunctions.endChat(driver);


            Thread.sleep(2000);
            try
            {
                chatwindow.get("https://www.zoho.com");
                Thread.sleep(80000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedLeadEnabled","Error",e);
                return false;
            }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            CommonFunctions.clickChatHistory(driver,vname);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            Thread.sleep(2000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            System.out.println("waited");

            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String leadname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leademail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String leadcomp = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String leadphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String leadtype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            if(!(leadname.equals(vname)&&leademail.equals(vemail)&&leadcomp.equals("Zoho")))//&&leadcomp.equals("AutomationComp")&&leadphone.equals(vphone)&&leadtype.equals("Lead")
            {
                //"+vphone+""+leadtype+"
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--Zoho--Actual:"+leadname+"--"+leademail+"--"+leadcomp+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadEnabled","Error");
                return false;
            }
            else
            {
            Thread.sleep(2000);
            etest.log(Status.PASS,"autoAccessedLead  Passed");
            return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadEnabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadEnabled","Error",e);
            return false;
        }
    }

    public static boolean autoAccessedLeadDisabled(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettingssalesforce.chooseTypeSF(driver, "vistypecrmdiv", "Accessed", 2, "unchk",etest);
            IntegrationSettingssalesforce.addNewVisitorToSF(driver,0,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedLeadDisabled","Error",e);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            CommonFunctions.endChat(driver);
            Thread.sleep(2000);

            try
            {
                chatwindow.get("https://www.zoho.com");
                Thread.sleep(80000);

                String widgetcode = SalesforceIntegration.widgetcode;
                System.out.println(widgetcode+"widgetcodeautoAccessedLeadDisabled");
                VisitorWindow.clickpreviouschathistoryicon(chatwindow,widgetcode);
                Thread.sleep(1000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"SalesforceIntegration","PushAccessedLeadDisabled","Error",e);
                return false;
            }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            CommonFunctions.clickChatHistory(driver,vname);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            if(((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                etest.log(Status.FAIL,"CRM div is present");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadDisabled","Error");
                return false;
            }

            String ptc = CommonUtil.elfinder(driver,"xpath",".//*[@id='crminfocontainer']//*[starts-with(@class, 'rg-button')]").getText();
            System.out.println("PTC : >>"+ptc);

            if(!ptc.contains("Push To Salesforce CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push To Salesforce CRM--Actual:"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadDisabled","Error");
                return false;
            }
            else
            {
              etest.log(Status.PASS,"autoAccessedLeadDisabled");
              return true;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadDisabled","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"SalesforceIntegration","PushAccessedLeadDisabled","Error",e);
            return false;
        }
    }

      public static String Chataccept(WebDriver driver,ExtentTest etest) throws Exception
      {
      		WebDriverWait wait = new WebDriverWait(driver, 60);
      		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(), 'Accept')]")));
          wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));
          String Visitorid = driver.findElement(By.xpath(".//*[@id='waitinglist']//*[@class='longwait-hovrinrmn']")).getAttribute("id");
      		String[] vid = Visitorid.split("_");
      		String vid1 = vid[0];
      		String vid2 = vid[1];
          WebElement notification = CommonUtil.elfinder(driver,"id","waitinglist");
          //String vid = CommonUtil.elementfinder(driver,notification,"tagname","div").getAttribute("id").replace("waitinfo_","");
          WebElement e = CommonUtil.elementfinder(driver,notification,"id","wpckup");
          TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatNotification","Before",0);
          e.click();
      	//	driver.findElement(By.xpath("//span[contains(text(), 'Accept')]")).click();
      		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@visitorid='"+vid2+"']/ancestor::*[@class='prelative']")));
      		String Visd = driver.findElement(By.xpath(".//*[@visitorid='"+vid2+"']/ancestor::*[@class='prelative']")).getAttribute("id");
      		return Visd;
      }

      public static void acceptChat(WebDriver driver,ExtentTest etest) throws Exception
      {
          FluentWait wait = CommonUtil.waitreturner(driver,30,200);
          wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));
          Thread.sleep(1500);
          WebElement notification = CommonUtil.elfinder(driver,"id","waitinglist");
          String vid = CommonUtil.elementfinder(driver,notification,"tagname","div").getAttribute("id").replace("waitinfo_","");
          WebElement e = CommonUtil.elementfinder(driver,notification,"id","wpckup");
          TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatNotification","Before",0);
          e.click();
          Thread.sleep(500);
          TakeScreenshot.screenshot(driver,etest,"ChatWindow","ChatNotification","After",0);
      }
}
