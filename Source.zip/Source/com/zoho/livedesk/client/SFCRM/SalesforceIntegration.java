//$Id$
package com.zoho.livedesk.client.SFCRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.common.base.Function;

import com.zoho.livedesk.util.ApiAutomation;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.SFCRM.IntegrationSettingssalesforce;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class SalesforceIntegration
{
    public static Hashtable finalResult = new Hashtable();
    public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
    public static ExtentTest etest;
    private static String url = "";
    public static WebDriver driver;
    public static WebDriver chatwindow;

    public static String embedname = "";
    public static String widgetcode = "";

    public static Hashtable crminteg(WebDriver driver)
     {

    try
        {
              TestResults = new Hashtable<String,Boolean>();

              embedname = ExecuteStatements.getDefaultEmbedName(driver);
              widgetcode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,embedname);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM1"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              FluentWait wait = CommonUtil.waitreturner(driver,30,250);
              System.out.println("~~crminteg");
              CommonFunctions.clickCRMInteg(driver);
              etest.log(Status.PASS,"Checked");
              TestResults.put("SFCRM1",true);
              System.out.println(TestResults.get("SFCRM1"));
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM2"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              Thread.sleep(1000);
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM2",SalesforceCommonfunctions.Salesforcedisable(driver,chatwindow));
              chatwindow.quit();
              System.out.println(TestResults.get("SFCRM2"));
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM3"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM3",SalesforceCommonfunctions.Salesforceenable(driver,chatwindow));
              chatwindow.quit();
              System.out.println(TestResults.get("SFCRM3"));
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM4"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM4",SalesforceCommonfunctions.manualContact(driver,chatwindow));
              chatwindow.quit();
              System.out.println(TestResults.get("SFCRM4"));
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM5"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              TestResults.put("SFCRM5",SalesforceCommonfunctions.addPotential(driver));
              System.out.println(TestResults.get("SFCRM5"));
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM6"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM6",SalesforceCommonfunctions.pushToCRMButton(driver,chatwindow));
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM7"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM7",SalesforceCommonfunctions.addTaskContact(driver,chatwindow));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM8"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM8",SalesforceCommonfunctions.statusInSalesiqMissed(driver,chatwindow));
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM9"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM9",SalesforceCommonfunctions.statusInSalesiqTracked(driver,chatwindow));
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM10"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM10",SalesforceCommonfunctions.autoMissedContact(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM11"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM11",SalesforceCommonfunctions.autoAttendedContact(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM12"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM12",SalesforceCommonfunctions.autoAccessedContact(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM13"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM13",SalesforceCommonfunctions.autoMissedContactDisabled(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM14"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM14",SalesforceCommonfunctions.autoAttendedContactDisabled(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM15"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM15",SalesforceCommonfunctions.autoAccessedContactDisabled(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM16"));
            // ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
            //
            // chatwindow = VisitorSite.chatdriver();
            // TestResults.put("SFCRM16",SalesforceCommonfunctions.contUser(driver,chatwindow,"supervisor familyplus","Contact"));
            // chatwindow.quit();
            //
            // ComplexReportFactory.closeTest(etest);

              // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM17"));
              // ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              // chatwindow = VisitorSite.chatdriver(widgetcode);
              // TestResults.put("SFCRM17",SalesforceCommonfunctions.manualLead(driver,chatwindow));
              // chatwindow.quit();
              // 
              // ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM18"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM18",SalesforceCommonfunctions.leadToContactNoPotential(driver,chatwindow));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM19"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM19",SalesforceCommonfunctions.leadToContactWithPotential(driver,chatwindow));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM20"));
              // ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              // chatwindow = com.zoho.livedesk.client.JSAPIW.CommonFunctions.setup(driver,widgetcode);
              // TestResults.put("SFCRM20",SalesforceCommonfunctions.autoAttendedLead(driver,chatwindow,etest));
              // chatwindow.quit();
              // 
              // ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM21"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow.quit();
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM21",SalesforceCommonfunctions.autoAttendedLeadDisabled(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

              // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM22"));
              // ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              // chatwindow = com.zoho.livedesk.client.JSAPIW.CommonFunctions.setup(driver,widgetcode);
              // TestResults.put("SFCRM22",SalesforceCommonfunctions.autoMissedLead(driver,chatwindow,etest));
              // 
              // ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM23"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM23",SalesforceCommonfunctions.autoMissedLeadDisabled(driver,chatwindow,etest));
              
              ComplexReportFactory.closeTest(etest);

              // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM24"));
              // ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              // chatwindow = com.zoho.livedesk.client.JSAPIW.CommonFunctions.setup(driver,widgetcode);
              // TestResults.put("SFCRM24",SalesforceCommonfunctions.autoAccessedLead(driver,chatwindow,etest));
              // chatwindow.quit();
              // 
              // ComplexReportFactory.closeTest(etest);

              etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SFCRM25"));
              ComplexReportFactory.setValues(etest,"Automation","Salesforce Integration");
              chatwindow = VisitorSite.chatdriver(widgetcode);
              TestResults.put("SFCRM25",SalesforceCommonfunctions.autoAccessedLeadDisabled(driver,chatwindow,etest));
              chatwindow.quit();
              
              ComplexReportFactory.closeTest(etest);

          }

          catch(Exception e)
      		{
              etest.log(Status.FATAL,"Module breakage occurred "+e);
              System.out.println("~~Module breakage occurred");
              e.printStackTrace();
              System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
          }
      		finally
      		{
        			ComplexReportFactory.closeTest(etest);
        			finalResult.put("result",TestResults);
        			finalResult.put("servicedown",new Hashtable());
        			return finalResult;
      		}
    }
}
