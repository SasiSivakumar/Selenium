//$Id$
package com.zoho.livedesk.client.SFCRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class IntegrationSettingssalesforce
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    private static String crmkey = null;
    private static String deskkey = null;
    private static String sportalname = null;
    private static String url = "";
    public static ExtentTest etest;

    public static Hashtable integ(WebDriver driver)
    {
        try
        {
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI1"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            url = ConfManager.requestURL();

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            etest.log(Status.PASS,"Checked");

            result.put("SI1", true);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI38"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI38", isSFCRMPageAvail(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI37"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI37",disablesalesforceInteg(driver,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI36"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI36",enableSalesforceInteg(driver,etest));

            ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI39"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI39", chooseTypeSF(driver, "vistypecrmdiv", "Missed", 0, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI40"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI40", chooseTypeSF(driver, "vistypecrmdiv", "Attended", 1, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI41"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI41", chooseTypeSF(driver, "vistypecrmdiv", "Accessed", 2, "chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI42"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI42", addNewVisitorToSF(driver,1,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI43"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI43", addNewVisitorToSF(driver,0,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI44"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            result.put("SI44", pushToSFCRM(driver,"chk",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI45"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI45","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Tracked in CRM",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI46"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI46","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI47"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI47","assignowner_div_div","assignowner_div_ddown","Zoho SalesIQ Attender",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI48"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI48","newcusaddtask_div_div","newcusaddtask_div_ddown","14th Day",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI49"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI49","newcusaddtask_div_div","newcusaddtask_div_ddown","7th Day",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI50"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI50","newcusaddtask_div_div","newcusaddtask_div_ddown","None",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI51"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI51","newcusaddtask_div_div","newcusaddtask_div_ddown","Today",etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SI52"));
            ComplexReportFactory.setValues(etest,"Automation","Integration Settings Salesforce");

            sfcrmintegconfig(driver,"SI52","newcusaddtask_div_div","newcusaddtask_div_ddown","Tomorrow",etest);

            ComplexReportFactory.closeTest(etest);

        }

        catch(NoSuchElementException e)
        {
            result.put("SI1", false);
            etest.log(Status.FATAL,"IntegrationTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Integration Settings Salesforce","IntegHome","Error",e);
        }
        catch(Exception e)
        {
            result.put("SI1", false);
            etest.log(Status.FATAL,"IntegrationTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Integration Settings Salesforce","IntegHome","Error",e);
        }

        ComplexReportFactory.closeTest(etest);

        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    // Salesforce Integration ---

    //Check Integration page
    public static boolean isSFCRMPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            String desc = driver.findElement(By.className("innersubinfotxt")).getText();
            if((desc).equals(ResourceManager.getRealValue("settings_SFCRMinteg_desc")))
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"MismatchContent.Expected:"+ResourceManager.getRealValue("settings_SFCRMinteg_desc")+"--Actual:"+desc+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","Salesforce CRMPage","MismatchContent");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking if Salesforce CRM Integration settings page is available : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","CRMPage","Error",e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if Salesforce CRM Integration settings page is available : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","CRMPage","Error",e);
            return false;
        }
        return false;
    }


    //Choose visitors type to be added in CRM
    public static boolean chooseTypeSF(WebDriver driver, String id, String vid, int num,String chk,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            WebElement type = driver.findElement(By.id(id));
            List<WebElement> vistypes = type.findElements(By.tagName("span"));
            JavascriptExecutor je = (JavascriptExecutor)driver;

            if((vistypes.get(num).getAttribute("class")).contains("chckbxsel"))
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(vid))).getLocation().y+"-400)");

                Coordinates cc = ((Locatable)(driver.findElement(By.id(vid)))).getCoordinates();
                cc.inViewPort();

                driver.findElement(By.id(vid)).click();
                if(id.equals("vistrackcrmdiv"))
                {
                    Tab.waitForLoading(driver,"disabletracknfy.do",etest);
                }
                else
                {
                    Tab.waitForLoading(driver,"upintegconfig.do",etest);
                }
                Thread.sleep(1000);
                if(chk.equals("unchk"))
                {
                    etest.log(Status.PASS,id+" - "+vid+" checkbox - UnChecked is verified");
                    return true;
                }
            }

            if(chk.equals("unchk"))
            {
                etest.log(Status.PASS,id+" - "+vid+" checkbox - UnChecked is verified");
                return true;
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

            Coordinates cc1 = ((Locatable)(driver.findElement(By.id(vid)))).getCoordinates();
            cc1.inViewPort();

            type = driver.findElement(By.id(id));
            vistypes = type.findElements(By.tagName("span"));

            driver.findElement(By.id(vid)).click();

            if(id.equals("vistrackcrmdiv"))
            {
                Tab.waitForLoading(driver,"disabletracknfy.do",etest);
            }
            else
            {
                Tab.waitForLoading(driver,"upintegconfig.do",etest);
            }

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));

            cc1 = ((Locatable)(driver.findElement(By.id(vid)))).getCoordinates();
            cc1.inViewPort();

            type = driver.findElement(By.id(id));
            vistypes = type.findElements(By.tagName("span"));

            if(chk.equals("chk"))
            {
                String s = vistypes.get(num).getAttribute("class");

                if(s.contains("chckbxsel"))
                {
                    etest.log(Status.PASS,id+" - "+vid+" checkbox - Checked is verified");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Mismatch Classname.Expected:chckbxsel-Actual"+s+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","chooseTypeSF","Error");
                }
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while Choosing visitors type to be added in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","chooseTypeSF","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while Choosing visitors type to be added in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","chooseTypeSF","Error",e);
        }
        return false;
    }

    //Choose Add visitor to Lead/Contact
    public static boolean addNewVisitorToSF(WebDriver driver, int num,ExtentTest etest)
    {
        String usecase = "Lead";

        try
        {
            if(num == 1)
            {
                usecase = "Contact";
            }
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElements(By.id("newcuscrmmodule")).get(num)).getLocation().y+"-400)");

            if(num==0)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("crmmodlead"))).getLocation().y+"-400)");

                Coordinates cc = ((Locatable)(driver.findElement(By.id("crmmodlead")))).getCoordinates();
                cc.inViewPort();

                driver.findElement(By.id("crmmodlead")).click();
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("mandatetext")));
                String leadtext = driver.findElement(By.className("mandatetext")).getText();
                if(leadtext.equals("Note: Company Field is mandatory for Lead Creation Process. To add Company Field via JSAPI, please click here."))
                {
                    etest.log(Status.PASS,"Lead Button Text Verified");
                }
                else
                {
                    etest.log(Status.FAIL,"Lead Button Text Not Verified");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","AddNewVisitorSF"+usecase,"Error");
                }
            }
            else
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("crmmodcontact"))).getLocation().y+"-400)");

                Coordinates cc = ((Locatable)(driver.findElement(By.id("crmmodcontact")))).getCoordinates();
                cc.inViewPort();

                driver.findElement(By.id("crmmodcontact")).click();
            }

            //driver.findElements(By.id("newcuscrmmodule")).get(num).click();

            Tab.waitForLoading(driver,"upintegconfig.do",etest);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            String cl = driver.findElement(By.id("crmradio")).findElements(By.className("uprdowrap")).get(num).findElement(By.tagName("span")).getAttribute("class");

            if(cl.contains("rdselected"))//if("true".equals(driver.findElements(By.id("newcuscrmmodule")).get(num).getAttribute("checked")))
            {
                etest.log(Status.PASS,"Add new visitor to "+usecase+" is checked");
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"MismatchContent Classname.Expected:rdselected--Actual:"+cl+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","AddNewVisitorSF"+usecase,"MismatchContent");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while Choosing Choose Add visitor to Lead/Contact in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","AddNewVisitorSF"+usecase,"Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while Choosing Choose Add visitor to Lead/Contact in CRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","AddNewVisitor"+usecase,"Error",e);
        }
        return false;
    }

    //Push Chat transcript to CRM
    public static boolean pushToSFCRM(WebDriver driver,String chk,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            String classname = driver.findElement(By.id("excuspushchattrans")).getAttribute("class");
            boolean val = (classname.contains("set_on")?true:false);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("excuspushchattrans"))).getLocation().y+"-400)");

            Coordinates cc = ((Locatable)(driver.findElement(By.id("excuspushchattrans")))).getCoordinates();
            cc.inViewPort();

            if(val && chk.equals("chk"))
            {
                etest.log(Status.PASS,"Push to SFCRM enabled is checked");
                return true;
            }
            else if(!val && chk.contains("unchk"))
            {
                etest.log(Status.PASS,"Push to SFCRM disabled is checked");
                return true;
            }
            else if(val && chk.contains("unchk"))
            {
                driver.findElement(By.id("excuspushchattrans")).click();
                Thread.sleep(2000);

                wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.id("excuspushchattrans")).getAttribute("class").contains("set_on"))
                            {
                                return false;
                            }
                            return true;
                        }
                    });

                classname = driver.findElement(By.id("excuspushchattrans")).getAttribute("class");

                val = (classname.contains("set_on")?true:false);

                if(!val)
                {
                    etest.log(Status.PASS,"Push to SFCRM disabled is checked");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Checkbox is not unchecked");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","PushToSFCRM","Error");
                    return false;
                }
            }

            else if(!val && chk.equals("chk"))
            {
                driver.findElement(By.id("excuspushchattrans")).click();

                Thread.sleep(3000);
                //WebDriverWait wait = new WebDriverWait(driver, 30);

                wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.id("excuspushchattrans")).getAttribute("class").contains("set_on"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });

                classname = driver.findElement(By.id("excuspushchattrans")).getAttribute("class");
                val = (classname.contains("set_on")?true:false);

                if(val)
                {
                    etest.log(Status.PASS,"Push to SFCRM enabled is checked");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Checkbox is unchecked");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","PushToSFCRM","Error");
                    return false;
                }
            }
            else
            {
                etest.log(Status.FAIL,"Cannot determine the status-"+chk);
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","PushToSFCRM","Error");
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking Push Chat transcript to SFCRM in SFCRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","PushToSFCRM","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Push Chat transcript to SFCRM in SFCRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","PushToSFCRM","Error",e);
        }
        return false;
    }

    //crmintegconfig(driver,"SI12","vstatusinlivedesk_div_div","vstatusinlivedesk_div_ddown","Keep as Missed",etest);

    public static void sfcrmintegconfig(WebDriver driver, String name, String id, String dname, String value,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            result.put(name, false);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(id))).getLocation().y+"-400)");

            Coordinates cc = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
            cc.inViewPort();

            Thread.sleep(500);

            driver.findElement(By.id(id)).click();

            Thread.sleep(500);

            WebElement elmt = driver.findElement(By.id(dname));

            List<WebElement> lis=elmt.findElements(By.tagName("li"));
            for(int i=0;i<lis.size();i++)
            {
                WebElement element = lis.get(i);
                WebElement element2 = element.findElement(By.tagName("div"));
                WebElement element3 = element2.findElement(By.tagName("span"));
                String title = element3.getAttribute("title");
                if(title.equals(value))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(element).getLocation().y+"-400)");

                    Coordinates cc1 = ((Locatable)element).getCoordinates();
                    cc1.inViewPort();

                    Thread.sleep(500);

                    element.click();

                    Tab.waitForLoading(driver,"upintegconfig.do",etest);

                    navToIntegApp(driver,"Salesforce");

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

                    Coordinates cc2 = ((Locatable)(driver.findElement(By.id(id)))).getCoordinates();
                    cc2.inViewPort();

                    Thread.sleep(2000);

                    String actual = driver.findElement(By.id(id)).getText();

                    System.out.println(actual+"<><><<><><>"+value);

                    if(value.equals(actual))
                    {
                        result.put(name, true);
                        etest.log(Status.PASS,"SFCRM Integration Configuration for "+id+" - "+value+" is checked");
                        return;
                    }
                    else
                    {
                        etest.log(Status.FAIL,"Expected:"+value+"--Actual:"+actual+"--");
                        TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","SFCRMIntegConfig","Error");
                    }
                    break;
                }
            }
            etest.log(Status.FAIL,value+" is not present");
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","SFCRMIntegConfig","Error");
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking SFCRM Integration Configuration in SFCRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","SFCRMIntegConfig","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking SFCRM Integration Configuration in SFCRM Integration settings page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","SFCRMIntegConfig","Error",e);
        }
    }

    //enable SalesforceCRM Integration
    public static boolean enableSalesforceInteg(WebDriver driver,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            //List<WebElement> elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("") && action.contains(ResourceManager.getRealValue("common_disable")))
            {
                elmts.click();
                //wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                //driver.findElement(By.id("okbtn")).click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Salesforce CRM Integration disabled successfully","disableinteg.do",etest);
            }

            //elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            action = elmts.getText();

            if(classname.equals("crm_intgopt") && action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Salesforce CRM Integration enabled successfully","enableinteg.do",etest);
                String actual = driver.findElement(By.id("disablecontainer")).getAttribute("class");
                if(!(actual).contains("crm_intgopt"))
                {
                    etest.log(Status.PASS,"Salesforce CRM Integration is successfully enabled");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Expected:not crm_intgopt--Actual:"+actual+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","EnableSalesforceCRM","Error");
                }
            }
            else
            {
                etest.log(Status.FAIL,"Expected:crm_intgopt--"+ResourceManager.getRealValue("common_enable")+"--Actual:"+classname+"--"+action+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","EnableSalesforceCRM","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while enabling SalesforceCRM integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","EnableSalesforceCRM","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while enabling SalesforceCRM integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","EnableSalesforceCRM","Error",e);
        }
        return false;
    }

    // disablesalesforceInteg
    public static boolean disablesalesforceInteg(WebDriver driver,ExtentTest etest)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            navToIntegApp(driver,"Salesforce");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_SFCRMheader")+"')]")));

            //List<WebElement> elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("crm_intgopt") || action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Salesforce CRM Integration enabled successfully","enableinteg.do",etest);
            }

            //elmts = driver.findElement(By.id("rightintegbtn")).findElements(By.tagName("a"));
            elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            action = elmts.getText();

            if(classname.equals("") && action.contains(ResourceManager.getRealValue("common_disable")))
            {
                elmts.click();
                // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                // driver.findElement(By.id("okbtn")).click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Salesforce CRM Integration disabled successfully","disableinteg.do",etest);
                String actual = driver.findElement(By.id("disablecontainer")).getAttribute("class");

                if((actual).contains("crm_intgopt"))
                {
                    etest.log(Status.PASS,"salesforce Integration is successfully disabled");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,"Expected:crm_intgopt--Actual:"+actual+"--");
                    TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","Disablesalesforce","Error");
                }
            }
            else
            {
                etest.log(Status.FAIL,"Expected:empty--"+ResourceManager.getRealValue("common_disable")+"--Actual:"+classname+"--"+action+"--");
                TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","Disablesalesforce","Error");
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while disabling salesforce integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","Disablesalesforce","Error",e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while disabling salesforce integration configuration in CRM integration page : "+e);
            TakeScreenshot.screenshot(driver,etest,"IntegrationSettingsSalesforce","Disablesalesforce","Error",e);
        }
        return false;
    }

    public static void navToIntegApp(WebDriver driver, String app) throws Exception
    {
        Tab.navToIntegrationTab(driver);

        Integration.selectIntegApp(driver,app);
    }
}
