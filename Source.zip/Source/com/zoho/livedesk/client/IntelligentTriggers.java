//$Id$
package com.zoho.livedesk.client;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import java.util.Stack;

public class IntelligentTriggers
{
    public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

    private static String url = "";

    private static int wcnum = 0;

    public static ExtentTest etest;

    public static Hashtable values = new Hashtable();
    public static Hashtable etests = new Hashtable();
    
    public static Hashtable secondAttemptResult = new Hashtable();
    public static Stack<String> usecases = new Stack();
    public static int secondAttempt = 0;
    public static String secondAttemptIds = "";
    
    public static Hashtable itriggers(WebDriver driver)
    {
        try
        {
            secondAttempt = 0;
            secondAttemptIds = "";
            
            result = new Hashtable();
            
            values = new Hashtable();
            etests = new Hashtable();
            secondAttemptResult = new Hashtable();
            usecases = new Stack();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT1"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            url = ConfManager.requestURL();
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("filterhd")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));

            etest.log(Status.PASS,"IntelligentTriggers Tab is present");

            result.put("SIT1",true);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT2"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT2",isPageAvail(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT73"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT73",checkDefaultIcons(driver));
           
            ComplexReportFactory.closeTest(etest);

            accresDel(driver);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT3"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT3",checkDValues(driver));
            
            ComplexReportFactory.closeTest(etest);

            addFull(driver);

            accresDel(driver);
            
            checkCRM(driver);
            
            accresDel(driver);

            addruleadvanced(driver);
            
            accresDel(driver);

            checkCRMFull(driver);
            
            if(secondAttempt != 0)
            {
                etest=ComplexReportFactory.getTest("Intelligent Triggers - Successfull addition only after second attempt");
                ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");
                
                etest.log(Status.FAIL,"Number of second attempts:"+secondAttempt);
                etest.log(Status.FAIL,"Ids - "+secondAttemptIds);
                
                ComplexReportFactory.closeTest(etest);
            }
            
            accresDel(driver);
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.FATAL,"IntelligentTriggersTabError");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggerTab","ErrorWhileCheckingIntelligentTriggerTab",e);

            result.put("SIT1", false);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"IntelligentTriggersTabError");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggerTab","ErrorWhileCheckingIntelligentTriggerTab",e);

            result.put("SIT1", false);
        }
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    //Check if page is available
    private static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("filterhd")));

            List<WebElement> text = driver.findElement(By.className("automationcontent")).findElements(By.className("innersubinfotxt"));

            if(((text.get(0).getText()).contains(ResourceManager.getRealValue("intelligenttriggers_desc1")))&&((text.get(1).getText()).contains(ResourceManager.getRealValue("intelligenttriggers_desc2"))))
            {
                etest.log(Status.PASS,"IntelligentTriggers Description matched");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","Description Mismatched");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingIntelligentTriggersPage",e);
            System.out.println("Exception while checking if the intelligent triggers page is available : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingIntelligentTriggersPage",e);
            System.out.println("Exception while checking if the intelligent triggers page is available : "+e);
            return false;
        }
        return false;
    }

    //Intelligent triggers default rule check
    private static boolean checkDValues(WebDriver driver)
    {
        String elid = "0";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Tab.navToITTab(driver);

            Trigger.clickAdd(driver,etest);
            elid=Trigger.getRuleId(driver,0);
            // Trigger.saveRule(driver,etest,elid);
            elid=Trigger.getRuleId(driver,0);

            Tab.navToITTab(driver);

            Trigger.openRuleEditView(driver,elid);

            List<WebElement> elmts = Trigger.getRuleEditContainer(driver,elid).findElements(By.className("trulesinfo"));

            WebElement elmt = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            String present = elmts.get(0).getText();

            if((present).equals("When would you like to trigger the visitor?"))
            {
                present = elmt.findElement(By.id("triggerevent_"+elid+"_div")).getText();
                if((present).equals("Lands on my website"))
                {
                    present = elmts.get(1).getText();
                    if((present).equals("Choose a condition and criteria for the trigger"))
                    {
                        String present1 = elmt.findElement(By.id("prior"+elid+"_col1_div")).getText();
                        String present2 = elmt.findElement(By.id("prior"+elid+"_col2_div")).getText();
                        String present3 = elmt.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).getAttribute("title");
                        if(((present1).equals("Visitor Type"))&&((present2).equals("is equal to"))&&((present3).equals("All")))
                        {
                            present = elmts.get(2).getText();
                            if((present).equals("What type of trigger you would like to use?"))
                            {
                                present = elmt.findElement(By.id("action_"+elid)).findElement(By.id("action_"+elid+"_div")).getText();
                                if((present).equals("Select an action"))
                                {
                                    etest.log(Status.PASS,"Default IntelligentTriggers is checked");
                                    Trigger.cancelRule(driver,etest,elid);
                                    return true;
                                }
                                else{
                                    etest.log(Status.FAIL,"Expected:Select an action--Actual"+present+"--");
                                    TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","MismatchContent");
                                }
                            }
                            else{
                                etest.log(Status.FAIL,"Expected:What type of trigger you would like to use?--Actual"+present+"--");
                                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","MismatchContent");
                            }
                        }
                        else{
                            etest.log(Status.FAIL,"Expected:Visitor type,is equal to,All--Actual"+present1+","+present2+","+present3+"--");
                            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","MismatchContent");
                        }
                    }
                    else{
                        etest.log(Status.FAIL,"Expected:When would you like to trigger the visitor?--Actual"+present+"--");
                        TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","MismatchContent");
                    }
                }
                else{
                    etest.log(Status.FAIL,"Expected:Lands on my website--Actual:"+present+"--");
                    TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","MismatchContent");
                }
            }
            else{
                etest.log(Status.FAIL,"Expected:When would you like to trigger the visitor?--Actual"+present+"--");
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","MismatchContent");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","ErrorWhileCheckingDefaultIntelligentTrigger",e);

            System.out.println("Exception while checking the default values in the added rule : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIntelligentTrigger","ErrorWhileCheckingDefaultIntelligentTrigger",e);

            System.out.println("Exception while checking the default values in the added rule : "+e);
        }
        Trigger.cancelRule(driver,etest,elid);
        return false;
    }

    //Add Full set of rules
    private static void addFull(WebDriver driver)
    {
        try
        {
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("STT4")+" and "+KeyManager.getRealValue("SIT5"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Browser","is equal to","Google Chrome",null,"Send chat invite","20 Seconds","STT4","SIT5");

            // ComplexReportFactory.closeTest(etest);


           

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT6"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Campaign Content","contains","Checking",null,"Invoke JS API","30 Seconds","SIT6",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT7"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Campaign Medium","is equal to","Checking",null,"Invoke JS API","31 Seconds","SIT7",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT8"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Campaign Name","contains","Checking",null,"Send chat invite","32 Seconds","SIT8",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT9"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Campaign Source","is equal to","Checking",null,"Invoke JS API","33 Seconds","SIT9",null);

            // ComplexReportFactory.closeTest(etest);



            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT10"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Campaign Term","contains","Checking",null,"Send chat invite","34 Seconds","SIT10",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT11"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"City","is not equal to","Checking",null,"Invoke JS API","36 Seconds","SIT11",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT12")+" and "+KeyManager.getRealValue("SIT13"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Country","is equal to","United States",null,"Send chat invite","28 Seconds","SIT12","SIT13");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT14"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Current Page Title","begins with","salesiq",null,"Invoke JS API","40 Seconds","SIT14",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT15"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Current Page URL","ends with","zoho.com",null,"Send chat invite","43 Seconds","SIT15",null);

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT16"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Email Address","ends with","@gmail.com",null,"Invoke JS API","47 Seconds","SIT16",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT17"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"IP Address","is equal to","192.168."+"43.100",null,"Send chat invite","50 Seconds","SIT17",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT18"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Landing Page Title","contains","Checking",null,"Invoke JS API","1 Minute","SIT18",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT19"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Landing Page URL","doesn't contain","Checking",null,"Send chat invite","36 Seconds","SIT19",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT20"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Number of Past Chats","is more than","7",null,"Invoke JS API","25 Seconds","SIT20",null);

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT21"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Number of Visits","is less than","7",null,"Send chat invite","3 Minutes","SIT21",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT22")+" and "+KeyManager.getRealValue("SIT23"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Operating System","is not equal to","Kindle",null,"Invoke JS API","5 Minutes","SIT22","SIT23");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT24"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Previous Page URL","ends with",".co.in",null,"Send chat invite","7 Minutes","SIT24",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT25"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Referrer","is not equal to","Yahoo",null,"Invoke JS API","9 Minutes","SIT25",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT26")+" and "+KeyManager.getRealValue("SIT27"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Region","is equal to","Asia Pacific",null,"Send chat invite","12 Minutes","SIT26","SIT27");

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT28")+" and "+KeyManager.getRealValue("SIT29"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Search Engine","is not equal to","Bing",null,"Invoke JS API","14 Minutes","SIT28","SIT29");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT30"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"State","is equal to","Checking",null,"Send chat invite","16 Minutes","SIT30",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT31")+" and "+KeyManager.getRealValue("SIT32"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Triggered Status","is equal to","Invoked",null,"Invoke JS API","18 Minutes","SIT31","SIT32");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT33"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRule(driver,"Visitor Info","is equal to","Checking",null,"Send chat invite","20 Minutes","SIT33",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT34")+" and "+KeyManager.getRealValue("SIT35"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Visitor Type","is equal to","Returning",null,"Invoke JS API","30 Minutes","SIT34","SIT35");

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT36")+" and "+KeyManager.getRealValue("SIT37"));
            // ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            // addRuleddown(driver,"Websites","is not equal to",ExecuteStatements.getDefaultEmbedName(driver),null,"Open chat window","45 Minutes","SIT36","SIT37");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT46")+" and "+KeyManager.getRealValue("SIT47"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addRuleddown(driver,"Visitor Stage in CRM","is not equal to","Not available",null,"Invoke JS API","45 Seconds","SIT46","SIT47");
            
            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingFullSetOfIntelligentTriggerRules",e);
            System.out.println("Exception while adding full set of rules in intelligent triggers : "+e);
        }
    }

    //Add Rule
    private static void addRuleddown(WebDriver driver,String cond,String qual,String val1,String val2,String act,String acttimer,String drnum,String rnum1)
    {
        String id = "";
        try
        {
            etests.put(rnum1,etest);
            usecases.add(rnum1);

            if(values.size() == 0)
            {
                Tab.navToITTab(driver);
            }
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            
            Trigger.clickAdd(driver,etest);

            id = Trigger.getRuleId(driver,0);

            String wcchk;

            if(wcnum == 0)
            {
                wcchk="Lands on my website";
                wcnum++;
            }
            else
            {
                wcchk="Accesses any page on my website";
                wcnum--;
            }

            String v1 = id+"/"+wcchk+"/"+cond+"/"+qual+"/"+val1+"/"+act+"/"+acttimer;

            values.put(rnum1,v1);
            
            Boolean allTrue[] = {true,true,true,true,true,true};

            fillFields(driver,etest,rnum1,allTrue);
            
            id = Trigger.getRuleId(driver,0);//id will be finalised only after saving

            v1 = id+"/"+wcchk+"/"+cond+"/"+qual+"/"+val1+"/"+act+"/"+acttimer;
            values.put(rnum1,v1);

            Trigger.openRuleEditView(driver,id);

            Boolean dropDownPresence = Trigger.selectValues(driver,id,val1,true,etest);
            
            if(dropDownPresence)
            {
                System.out.println("DropDown True");
                etest.log(Status.PASS,KeyManager.getRealValue(drnum)+" is checked");
                result.put(drnum,true);
            }
            else
            {
                System.out.println("DropDown False");
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(drnum),"DropDownIsNotVisible");
                result.put(drnum,false);
            }
            
            clickHeader(driver,id);
        }
        catch(NoSuchElementException e)
        {
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
        catch(Exception e)
        {
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
        Trigger.cancelRule(driver,etest,id);
    }

    //Add Rule only (no dropdown check)
    private static void addRule(WebDriver driver,String cond,String qual,String val1,String val2,String act,String acttimer,String rnum1,String drnum)
    {

        try
        {
            etests.put(rnum1,etest);
            usecases.add(rnum1);

            if(values.size() == 0)
            {
                Tab.navToITTab(driver);
            }
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            
            Trigger.clickAdd(driver,etest);

            String id = "";

            id = Trigger.getRuleId(driver,0);

            String wcchk;

            if(wcnum == 0)
            {
                wcchk="Lands on my website";
                wcnum++;
            }
            else
            {
                wcchk="Accesses any page on my website";
                wcnum--;
            }

            String v1 = id+"/"+wcchk+"/"+cond+"/"+qual+"/"+val1+"/"+act+"/"+acttimer;

            values.put(rnum1,v1);
            
            Boolean allTrue[] = {true,true,true,true,true,true};
            fillFields(driver,etest,rnum1,allTrue);

            id = Trigger.getRuleId(driver,0);

            v1 = id+"/"+wcchk+"/"+cond+"/"+qual+"/"+val1+"/"+act+"/"+acttimer;
            values.put(rnum1,v1);
       }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
            values.put(rnum1,"Error");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
            values.put(rnum1,"Error");
        }
    }

    //Delete rules when access restricted Issue
    public static void accresDel(WebDriver driver)
    {
        try
        {
            Tab.navToITTab(driver);
            if(Cleanup.getDeleteButton(driver)!=null)
            {
                WebElement delete=Cleanup.getDeleteButton(driver);
                CommonUtil.mouseHover(driver,delete);
                CommonSikuli.findInWholePage(driver,"Intelligenttriggerdelete.png","UI171",etest);
            }
        }
        catch(Exception e)
        {
            etest.log(Status.WARNING,"Intelligent Trigger Delete icon not Verified");
        }
        com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);
        etest.log(Status.PASS,"All triggers were deleted successfully.");
        // try
        // {
        //     FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        //     Tab.navToITTab(driver);

        //     for(int i=0;i<=10;i++)
        //     {
        //         if(Trigger.ruleExist(driver))
        //         {
        //             List<WebElement> list = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("trules"));
                    
        //             final int count = list.size();

        //             WebElement elmtch = list.get(0);

        //             mouseOver(driver,elmtch);

        //             CommonSikuli.findInWholePage(driver,"Intelligenttriggerdelete.png","UI171",etest);

        //             CommonUtil.elementfinder(driver,elmtch,"classname","sqico-delico").click();

        //             wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
        //             wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                    
        //             CommonUtil.elfinder(driver,"id","okbtn").click();

        //             final WebElement e = CommonUtil.elfinder(driver,"id","popupdiv");

        //             wait.until(new Function<WebDriver,Boolean>()
        //             {
        //                 public Boolean apply(WebDriver driver)
        //                 {
        //                     if(e.getAttribute("innerHTML").equals(""))
        //                     {
        //                         return true;
        //                     }
        //                     return false;
        //                 }
        //             });

        //             Tab.waitForLoadingSuccessWithBanner(driver,"Rule deleted Successfully","deleterule.do",etest);

        //             if(count == 1)
        //             {
        //                 if(!Trigger.ruleExist(driver))
        //                 {
        //                     return;
        //                 }
        //             }

        //             wait.until(new Function<WebDriver,Boolean>()
        //             {
        //                 public Boolean apply(WebDriver driver)
        //                 {
        //                     try
        //                     {
        //                         int finalCount = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("trules")).size();
                            
        //                         if(finalCount == (count - 1))
        //                         {
        //                             return true;
        //                         }
        //                     }
        //                     catch(Exception e)
        //                     {}
        //                     return false;
        //                 }
        //             });

        //             Thread.sleep(500);
        //         }
        //         else
        //         {
        //             break;
        //         }
        //     }
        // }
        // catch(NoSuchElementException e)
        // {
        //     System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        // }
        // catch(Exception e)
        // {
        //     System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        // }
    }

    //Check CRM integration
    private static void checkCRM(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT38"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT38",disableCRM(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT39"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT39",enableCRM(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT40")+" and "+KeyManager.getRealValue("SIT41"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Last Name","is equal to","Paul","Send chat invite","50 Seconds","SIT40","SIT41");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT42")+" and "+KeyManager.getRealValue("SIT43"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Industry","contains","Checking","Invoke JS API","90 Seconds","SIT42","SIT43");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT44")+" and "+KeyManager.getRealValue("SIT45"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Deal","No of Open Deals","is equal to","8","Send chat invite","30 Seconds","SIT44","SIT45");
            
            // ComplexReportFactory.closeTest(etest);
            checkValuesCRM(driver);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingCRMRulesInIntelligentTriggers",e);
            System.out.println("Exception while checking CRM rules in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingCRMRulesInIntelligentTriggers",e);
            System.out.println("Exception while checking CRM rules in intelligent triggers : "+e);
        }
    }

    //Add full list of crm rules
    private static void checkCRMFull(WebDriver driver)
    {
        try
        {
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT48"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Lead Source","is equal to","Checking","Send chat invite","50 Seconds",null,"SIT48");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT49"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Mailing City","is not equal to","Chennai","Invoke JS API","65 Seconds",null,"SIT49");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT50"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Mailing Country","is not equal to","India","Send chat invite","70 Seconds",null,"SIT50");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT51"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Mailing State","begins with","Checking","Invoke JS API","75 Seconds",null,"SIT51");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT52"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Mailing Street","ends with","Checking","Send chat invite","55 Seconds",null,"SIT52");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT53"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Mailing Zip","contains","Checking","Invoke JS API","80 Seconds",null,"SIT53");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT54"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Mobile","is not equal to","+917358613178","Send chat invite","77 Seconds",null,"SIT54");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT55"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Number Of Chats","is more than","7","Invoke JS API","39 Seconds",null,"SIT55");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT56"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Visitor Score","is more than","500","Send chat invite","67 Seconds",null,"SIT56");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT57"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Contact","Skype ID","ends with","Check","Invoke JS API","80 Seconds",null,"SIT57");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT58"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Last Name","is equal to","Testerln","Send chat invite","87 Seconds",null,"SIT58");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT59"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Lead Source","contains","hello","Invoke JS API","69 Seconds",null,"SIT59");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT60"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Lead Status","is not equal to","Checking","Send chat invite","55 Seconds",null,"SIT60");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT61"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Mobile","is not equal to","+917358613178","Invoke JS API","80 Seconds",null,"SIT61");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT62"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","No of Employees","is more than","7","Send chat invite","77 Seconds",null,"SIT62");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT63"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Number Of Chats","is more than","7","Invoke JS API","39 Seconds",null,"SIT63");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT64"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Phone","is equal to","9600665433","Send chat invite","67 Seconds",null,"SIT64");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT66"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Secondary Email","begins with","salesiq","Invoke JS API","87 Seconds",null,"SIT66");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT67"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Lead","Skype ID","contains","hello","Send chat invite","69 Seconds",null,"SIT67");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT70"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Deal","Closed Won","is more than","800","Invoke JS API","30 Seconds",null,"SIT70");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT71"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Deal","Revenue in pipeline","is less than","50000","Send chat invite","36 Seconds",null,"SIT71");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT72"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            addcrmrule(driver,"CRM Deal","Closing Date","is after","Today","Invoke JS API","38 Seconds",null,"SIT72");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingAllCRMRulesInIntelligentTriggersPage",e);
            System.out.println("Exception while checking all CRM rules in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileCheckingAllCRMRulesInIntelligentTriggersPage",e);
            System.out.println("Exception while checking all CRM rules in intelligent triggers : "+e);
        }
    }

    //CRM integration - disable and check
    public static boolean disableCRM(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            Thread.sleep(1000);

            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("crm_intgopt") || action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
            }

            Thread.sleep(1000);

            WebElement elmtss = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));

            elmtss.click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            driver.findElement(By.id("okbtn")).click();
            Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration disabled successfully","disableinteg.do",etest);
            
            Tab.navToITTab(driver);

            Trigger.clickAdd(driver,etest);

            elid = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmt = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
            Thread.sleep(500);

            try
            {
                elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("prior"+elid+"_col11"));
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();

                Thread.sleep(1000);

                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","DisableCRM","CRMisNotDisabled");
                Trigger.cancelRule(driver,etest,elid);
                return false;
            }
            catch(NoSuchElementException e)
            {
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                etest.log(Status.PASS,"DisableCRM is checked");
                Trigger.cancelRule(driver,etest,elid);
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","DisableCRM","ErrorWhileCheckingDisablingCRM",e);

            System.out.println("Exception while checking CRM dropdown when CRM integration is disabled in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","DisableCRM","ErrorWhileCheckingDisablingCRM",e);

            System.out.println("Exception while checking CRM dropdown when CRM integration is disabled in intelligent triggers : "+e);
        }
        Trigger.cancelRule(driver,etest,elid);
        return false;
    }

    //CRM integration - Enable and check
    public static boolean enableCRM(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            Thread.sleep(1000);

            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            Thread.sleep(3000);

            WebElement elmtss = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));

            elmtss.click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);

            Tab.navToITTab(driver);

            Trigger.clickAdd(driver,etest);

            elid = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmt = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();

            try
            {
                elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("prior"+elid+"_col11"));
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                Thread.sleep(1000);

                etest.log(Status.PASS,"Enable CRM is checked");
                Trigger.cancelRule(driver,etest,elid);
                return true;
            }
            catch(NoSuchElementException e)
            {
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","EnableCRM","CRMisNotEnabled");
                Trigger.cancelRule(driver,etest,elid);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","EnableCRM","ErrorWhileCheckingEnablingCRM",e);

            System.out.println("Exception while checking CRM dropdown when CRM integration is enabled in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","EnableCRM","ErrorWhileCheckingEnablingCRM",e);

            System.out.println("Exception while checking CRM dropdown when CRM integration is enabled in intelligent triggers : "+e);
        }
        Trigger.cancelRule(driver,etest,elid);
        return false;
    }

    //CRM rule add
    private static void addcrmrule(WebDriver driver,String cond1,String cond2,String qual,String val,String act,String acttimer,String drnum,String rnum1)
    {
        try
        {
            if(drnum!=null)
            {
                result.put(drnum,false);
            }

            etests.put(rnum1,etest);
            usecases.add(rnum1);

            if(values.size() == 0)
            {
                Tab.navToITTab(driver);
            }
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            
            Trigger.clickAdd(driver,etest);

            String id = "";

            id = Trigger.getRuleId(driver,0);

            String wcchk;

            if(wcnum == 0)
            {
                wcchk="Lands on my website";
                wcnum++;
            }
            else
            {
                wcchk="Accesses any page on my website";
                wcnum--;
            }
            
            String v1 = id+"/"+wcchk+"/"+cond1+"/"+cond2+"/"+qual+"/"+val+"/"+act+"/"+acttimer;
            
            values.put(rnum1,v1);
            
            Boolean allTrue[] = {true,true,true,true,true,true,true};
            fillFieldsCRM(driver,etest,rnum1,allTrue);

            id=Trigger.getRuleId(driver,0);
            v1 = id+"/"+wcchk+"/"+cond1+"/"+cond2+"/"+qual+"/"+val+"/"+act+"/"+acttimer;            
            values.put(rnum1,v1);

            if(drnum!=null)
            {
                result.put(drnum,true);
            }
        }
        catch(NoSuchElementException e)
        {
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
        catch(Exception e)
        {
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
    }

    //Add rule advanced
    private static void addruleadvanced(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT68"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT68",addRulesingleand(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SIT69"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers");

            result.put("SIT69",addRulesingleor(driver));
            
            ComplexReportFactory.closeTest(etest);

            Thread.sleep(20000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileAddingAdvancedRuleInIntelligentTriggersPage",e);
            System.out.println("Exception while adding advanced rule in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileAddingAdvancedRuleInIntelligentTriggersPage",e);
            System.out.println("Exception while adding advanced rule in intelligent triggers : "+e);
        }
    }

    //Add Rule advanced - Single OR condition
    private static boolean addRulesingleand(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //String cond,String qual,String val1,String val2,String act,String acttimer

            String cond = "Advanced";

            Tab.navToITTab(driver);

            Trigger.clickAdd(driver,etest);

            elid = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmt = Trigger.getRuleEditContainer(driver,elid);// CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            elmt.findElement(By.id("triggerevent_"+elid+"_div")).click();

            String wcchk;

            if(wcnum == 0)
            {
                elmt.findElement(By.id("triggerevent_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(0).click();
                wcchk="Lands on my website";
                wcnum++;
            }
            else
            {
                elmt.findElement(By.id("triggerevent_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(1).click();
                wcchk="Accesses any page on my website";
                wcnum--;
            }
            Thread.sleep(500);

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
            elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            Thread.sleep(500);
            elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();

            elmt.findElement(By.id("prior"+elid+"_col3")).findElement(By.className("col3input")).findElement(By.tagName("em")).click();

            Thread.sleep(1000);

            WebElement elmtpp = driver.findElement(By.id("ldsettings"));

            addCriteria(driver,"1","Country","is equal to","United States",null);
            elmtpp.findElement(By.className("andwrp")).findElement(By.cssSelector("div.and.opr")).click();
            addCriteria(driver,"2","Browser","is not equal to","Google Chrome",null);

            elmtpp.findElement(By.className("cnfmbtm")).click();

            Thread.sleep(1000);

            Trigger.saveRule(driver,etest,elid);

            elid = Trigger.getRuleId(driver,0);

            /*if((act.equals("Open chat window"))||(act.equals("Glow button"))||(act.equals("Show bubble"))||(act.equals("Show button")))
            {
                elmt.findElement(By.className("routeto")).findElement(By.id("action_"+elid+"_div")).click();

                List<WebElement> actlist = elmt.findElement(By.className("routeto")).findElement(By.id("action_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li"));

                for(WebElement act1:actlist)
                {
                    if((act1.getText()).equals(act))
                    {
                        act1.click();
                    }
                }

                elmt.findElement(By.id("actionarea_"+elid)).findElement(By.className("attrigger")).findElement(By.tagName("input")).sendKeys(acttimer);
            }
            */
            String elid12 = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmts2 = Trigger.getRuleEditContainer(driver,elid); // CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            String checkstr = elmts2.findElement(By.id("prior"+elid12+"_col3")).findElement(By.className("col3input")).findElement(By.tagName("div")).getText();

            System.out.println(checkstr+"---------------------------------------->>>>>>>>>");

            if(checkstr.equals("( Country is equal to United States ) AND ( Browser is not equal to Google Chrome )"))
            {
                etest.log(Status.PASS,KeyManager.getRealValue("SIT68")+" is checked");
                Trigger.cancelRule(driver,etest,elid);
                return true;
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue("SIT68"),"MismatchContent:( Country is equal to United States ) AND ( Browser is not equal to Google Chrome )");

                Trigger.cancelRule(driver,etest,elid);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue("SIT68"),"ErrorWhileChecking"+KeyManager.getRealValue("SIT68"),e);
            System.out.println("Exception while adding advanced rule with single AND in the rule in intelligent triggers : "+e);
            Trigger.cancelRule(driver,etest,elid);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue("SIT68"),"ErrorWhileChecking"+KeyManager.getRealValue("SIT68"),e);
            System.out.println("Exception while adding advanced rule with single AND in the rule in intelligent triggers : "+e);
            Trigger.cancelRule(driver,etest,elid);
            return false;
        }
    }

    //Add Rule advanced - Single AND condition
    private static boolean addRulesingleor(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            String cond = "Advanced";

            String act = "Send chat invite";

            String acttimer = "50 Seconds";

            Tab.navToITTab(driver);

            Trigger.clickAdd(driver,etest);

            elid = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmt = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            elmt.findElement(By.id("triggerevent_"+elid+"_div")).click();

            String wcchk;

            if(wcnum == 0)
            {
                elmt.findElement(By.id("triggerevent_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(0).click();
                wcchk="Lands on my website";
                wcnum++;
            }
            else
            {
                elmt.findElement(By.id("triggerevent_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(1).click();
                wcchk="Accesses any page on my website";
                wcnum--;
            }
            Thread.sleep(500);

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
            elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            Thread.sleep(500);
            elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
            Thread.sleep(500);

            elmt.findElement(By.id("prior"+elid+"_col3")).findElement(By.className("col3input")).findElement(By.tagName("em")).click();

            Thread.sleep(1000);

            WebElement elmtpp = driver.findElement(By.id("ldsettings"));

            addCriteria(driver,"1","Number of Visits","is more than","5",null);
            elmtpp.findElement(By.id("prior1")).findElement(By.cssSelector("div.or.floatlf.opr")).click();
            addCriteria(driver,"2","Number of Past Chats","is less than","10",null);

            elmtpp.findElement(By.className("cnfmbtm")).click();

            Thread.sleep(4000);

            elmt = Trigger.getRuleEditContainer(driver,elid);

            if((act.equals("Open chat window"))||(act.equals("Glow button"))||(act.equals("Show bubble"))||(act.equals("Show button")))
            {
                elmt.findElement(By.className("routeto")).findElement(By.id("action_"+elid+"_div")).click();

                List<WebElement> actlist = elmt.findElement(By.className("routeto")).findElement(By.id("action_"+elid+"_ddown")).findElement(By.id("action_"+elid+"1")).findElements(By.tagName("li"));

                for(WebElement act1:actlist)
                {
                    if((act1.getText()).equals(act))
                    {
                        act1.click();
                    }
                }

                elmt.findElement(By.id("actionarea_"+elid)).findElement(By.className("attrigger")).findElement(By.tagName("input")).sendKeys(acttimer);
            }
            else
            {
                String actionValue1 = "Welcome";
                String actionValue2 = "How can I help you?";
                Trigger.selectAction(driver,elid,act,acttimer,actionValue1,actionValue2,etest);
            }


            Trigger.saveRule(driver,etest,elid);

            String elid12 = Trigger.getRuleId(driver,0);
            Trigger.openRuleEditView(driver,elid);
            WebElement elmts2 = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            String checkstr = elmts2.findElement(By.id("prior"+elid12+"_col3")).findElement(By.className("col3input")).findElement(By.tagName("div")).getAttribute("title");

            System.out.println(checkstr+"---------------------------------------->>>>>>>>>");

            if(CommonUtil.checkStringContainsAndLog("Number of Visits is more than 5 OR Number of Past Chats is less than 10",checkstr,"Advanced trigger",etest))
            {
                etest.log(Status.PASS,KeyManager.getRealValue("SIT69")+" is checked");
                Trigger.cancelRule(driver,etest,elid);
                return true;
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue("SIT69"),"MismatchContent:( Number of Visits is more than 5 OR Number of Past Chats is less than 10 ) WITH ~~"+checkstr);

                Trigger.cancelRule(driver,etest,elid);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue("SIT69"),"ErrorWhileChecking"+KeyManager.getRealValue("SIT69"),e);
            System.out.println("Exception while adding advanced rule with single OR in the rule in intelligent triggers : "+e);
            Trigger.cancelRule(driver,etest,elid);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue("SIT69"),"ErrorWhileCheckingBlockedTab"+KeyManager.getRealValue("SIT69"),e);
            System.out.println("Exception while adding advanced rule with single OR in the rule in intelligent triggers : "+e);
            Trigger.cancelRule(driver,etest,elid);
            return false;
        }
    }

    //Add Rule advanced - multiple condition
    private static boolean addRulemultiple(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //String cond,String qual,String val1,String val2,String act,String acttimer

            String cond = "Advanced";

            /*result.put("SIT"+rnum,false);
            System.out.println("-------------------------------->>>>>>"+cond+rnum);*/

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));

            List<WebElement> intcnt = CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER).findElements(Trigger.TRIGGER_RULE_CONTAINER);

            int rcount1 = 0;

            for(WebElement elmt:intcnt)
            {
                rcount1++;
            }
            final int rcount = rcount1;

            driver.findElement(By.id("autobtnadd")).findElement(By.tagName("span")).click();

            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    List<WebElement> intcnt1 = CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER).findElements(Trigger.TRIGGER_RULE_CONTAINER);
                    int rcountchk = 0;

                    for(WebElement elmt:intcnt1)
                    {
                        rcountchk++;
                    }
                    if(rcountchk == (rcount+1))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);

            elid = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmt = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            elmt.findElement(By.id("triggerevent_"+elid+"_div")).click();

            String wcchk;

            if(wcnum == 0)
            {
                elmt.findElement(By.id("triggerevent_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(0).click();
                wcchk="Lands on my website";
                wcnum++;
            }
            else
            {
                elmt.findElement(By.id("triggerevent_"+elid+"_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(1).click();
                wcchk="Accesses any page on my website";
                wcnum--;
            }
            Thread.sleep(500);

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
            elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            Thread.sleep(500);
            elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
            Thread.sleep(500);

            elmt.findElement(By.id("prior"+elid+"_col3")).findElement(By.className("col3input")).findElement(By.tagName("em")).click();

            Thread.sleep(1000);

            WebElement elmtpp = driver.findElement(By.id("ldsettings"));

            addCriteria(driver,"1","Number of Visits","is more than","5",null);
            elmtpp.findElement(By.id("prior1")).findElement(By.cssSelector("div.or.floatlf.opr")).click();
            addCriteria(driver,"2","Number of Past Chats","is less than","10",null);
            elmtpp.findElement(By.className("andwrp")).findElement(By.cssSelector("div.and.opr")).click();
            addCriteria(driver,"3","Country","is equal to","United States",null);
            elmtpp.findElement(By.id("prior3")).findElement(By.cssSelector("div.or.floatlf.opr")).click();
            addCriteria(driver,"4","Browser","is not equal to","Google Chrome",null);

            elmtpp.findElement(By.className("cnfmbtm")).click();

            Thread.sleep(4000);

            String elid12 = Trigger.getRuleId(driver,0);

            Trigger.openRuleEditView(driver,elid);

            WebElement elmts2 = Trigger.getRuleEditContainer(driver,elid); //CommonUtil.getElement(driver,Trigger.TRIGGER_RULES_CONTAINER,Trigger.TRIGGER_RULES_LIST_CONTAINER,Trigger.TRIGGER_RULE_CONTAINER);

            String checkstr = elmts2.findElement(By.id("prior"+elid12+"_col3")).findElement(By.className("col3input")).findElement(By.tagName("div")).getText();

            System.out.println(checkstr+"---------------------------------------->>>>>>>>>");

            if(checkstr.equals("( Number of Visits is more than 5 OR Number of Past Chats is less than 10 ) AND ( Country is equal to United States OR Browser is not equal to Google Chrome )"))
            {
                Trigger.cancelRule(driver,etest,elid);
                return true;
            }
            else
            {
                Trigger.cancelRule(driver,etest,elid);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileAddingAdvancedRuleWithMultipleCriteriaIntelligentTriggersPage",e);
            System.out.println("Exception while adding advanced rule with multiple criteria in the rule in intelligent triggers : "+e);
            Trigger.cancelRule(driver,etest,elid);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileAddingAdvancedRuleWithMultipleCriteriaIntelligentTriggersPage",e);
            System.out.println("Exception while adding advanced rule with multiple criteria in the rule in intelligent triggers : "+e);
            Trigger.cancelRule(driver,etest,elid);
            return false;
        }
    }

    //Adding Criteria
    private static void addCriteria(WebDriver driver,String pnum,String cond,String qual,String val1,String val2)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            /*
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });*/
            Thread.sleep(1000);

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            String qid = "prior"+pnum+"_col2_div";
            String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();
            /*
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });*/

            Thread.sleep(1000);

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","AddCriteria","ErrorWhileAddingCriteria",e);

            System.out.println("Exception while adding criteria in advanced rules in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","AddCriteria","ErrorWhileAddingCriteria",e);

            System.out.println("Exception while adding criteria in advanced rules in intelligent triggers : "+e);
        }
    }

    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    public static Boolean[] checkValues(WebDriver driver, String usecase, boolean navTo, Status log) throws Exception
    {
        String id = "";
        Boolean failed[] = {false,false,false,false,false,false};
        etest = (ExtentTest)etests.get(usecase);

        try
        {
            String allValues = ((String)values.get(usecase));
            
            System.out.println(usecase+"<>"+allValues+"<>");
            
            if(navTo)
            {
                Tab.clickVisitorRouting(driver);
                Tab.clickIntelligentTrigger(driver);
            }
            
            if(allValues.equals("Error"))
            {
                result.put(usecase,false);
                etest.log(Status.FAIL,"Use case failed");
                return failed;
            }
            
            id = ((String)values.get(usecase)).split("/")[0];

            allValues = allValues.replace(id+"/","");

            Trigger.openRuleEditView(driver,id);

            WebElement e = Trigger.getRuleEditContainer(driver,id).findElement(By.id("newrule"));

            Dimension s = driver.manage().window().getSize();
            int x = s.height;

            int f = e.getLocation().y;
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            jse.executeScript("scroll(0,"+(f-(x/2))+")");
            
            String expected[] = allValues.split("/");

            String actualVisitorEvent = Trigger.getVisitorEvent(driver,id);
            String actualCriteria = Trigger.getCriteria(driver,id);
            String actualConditon = Trigger.getCondition(driver,id);
            String actualValue = Trigger.getValue1(driver,id);
            String actualAction = Trigger.getAction(driver,id);
            String actualTime = Trigger.getActionTime(driver,id);

            //important actionvalue1 and value2

            String actual[] = {actualVisitorEvent,actualCriteria,actualConditon,actualValue,actualAction,actualTime};
            
            for(int i = 0 ; i < actual.length; i++)
            {
                if(!actual[i].equals(expected[i]))
                {
                    etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                    failed[i] = true;
                }
                else
                {
                    etest.log(Status.INFO,expected[i]+" is present");
                }
            }
            
            Boolean res = true;
            
            for(Boolean fail : failed)
            {
                if(fail)
                {
                    res = false;
                    break;
                }
            }

            if(!res)
            {
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(usecase),"MismatchContent",0);
                result.put(usecase,false);
            }
            else
            {
                result.put(usecase,true);
            }
        }
        catch(Exception e)
        {
            result.put(usecase,false);
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckAddedValues","Error",e);
        }
        Trigger.cancelRule(driver,etest,id);
        return failed;
    }

    public static void checkValues(WebDriver driver) throws Exception
    {
        Thread.sleep(15000);

        boolean navTo = true;
        for(String s : usecases)
        {
            Boolean failed[];
            if(navTo)
            {
                failed = checkValues(driver,s,true,Status.INFO);
                navTo = false;
            }
            else
            {
                failed = checkValues(driver,s,false,Status.INFO);
            }
            
            Boolean res = true;
            
            for(Boolean f : failed)
            {
                if(f)
                {
                    res = false;
                }
            }
            
            try
            {
                ExtentTest etest = (ExtentTest)etests.get(s);
                
                if(res)
                {
                    ComplexReportFactory.closeTest(etest);
                }
                else
                {
                    secondAttemptResult.put(s,failed);
                    
                    etest.log(Status.INFO,"<pre>Second attempt ...</pre>");
                    
                    fillFields(driver,etest,s,failed);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(s),"ErrorWhileChecking"+KeyManager.getRealValue(s),e);
                values.put(s,"Error");
            }
        }

        Set<String> secondAttemptUsecases = secondAttemptResult.keySet();
        
        if(secondAttemptUsecases.size() != 0)
        {
            Thread.sleep(10000);
        }
        
        navTo = true;
        
        for(String s : secondAttemptUsecases)
        {
            try
            {
                String value = values.get(s).toString();
                
                if(!value.equals("Error"))
                {
                    secondAttempt++;
                    
                    String id = value.split("/")[0];
                    
                    secondAttemptIds += id+";";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            if(navTo)
            {
                checkValues(driver,s,true,Status.FAIL);
                navTo = false;
            }
            else
            {
                checkValues(driver,s,false,Status.FAIL);
            }
            
            ExtentTest etest = (ExtentTest)etests.get(s);
            
            ComplexReportFactory.closeTest(etest);
        }
        
        accresDel(driver);

        values = new Hashtable();
        etests = new Hashtable();
        secondAttemptResult = new Hashtable();
        usecases = new Stack();
    }

    public static Boolean[] checkValuesCRM(WebDriver driver, String usecase, boolean navTo, Status log) throws Exception
    {
        String id = "";
        etest = (ExtentTest)etests.get(usecase);
        Boolean failed[] = {false,false,false,false,false,false,false};

        try
        {
            String allValues = ((String)values.get(usecase));
            
            System.out.println(usecase+"<>"+allValues+"<>");
            
            if(navTo)
            {
                Tab.clickVisitorRouting(driver);
                Tab.clickIntelligentTrigger(driver);
            }
            
            if(allValues.equals("Error"))
            {
                result.put(usecase,false);
                etest.log(Status.FAIL,"Use case failed");
            }
            
            id = ((String)values.get(usecase)).split("/")[0];

            Trigger.openRuleEditView(driver,id);

            allValues = allValues.replace(id+"/","");

            WebElement e = Trigger.getRuleEditContainer(driver,id).findElement(By.id("newrule"));

            Dimension s = driver.manage().window().getSize();
            int x = s.height;

            int f = e.getLocation().y;
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            jse.executeScript("scroll(0,"+(f-(x/2))+")");
            
            String expected[] = allValues.split("/");

            String actualVisitorEvent = Trigger.getVisitorEvent(driver,id);
            String actualCriteria = Trigger.getCriteria(driver,id);
            String actualSubCriteria = Trigger.getSubCriteria(driver,id);
            String actualConditon = Trigger.getCondition(driver,id);
            String actualValue = "";

            if(allValues.contains("Closing Date"))
            {
                actualValue = Trigger.getValueFromDropDown(driver,id);
            }
            else
            {
                actualValue = Trigger.getValue1(driver,id);
            }

            String actualAction = Trigger.getAction(driver,id);
            String actualTime = Trigger.getActionTime(driver,id);

            //important actionvalue1 and value2

            String actual[] = {actualVisitorEvent,actualCriteria,actualSubCriteria,actualConditon,actualValue,actualAction,actualTime};

            for(int i = 0 ; i < actual.length; i++)
            {
                if(!actual[i].equals(expected[i]))
                {
                    etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                    failed[i] = true;
                }
                else
                {
                    etest.log(Status.INFO,expected[i]+" is present");
                }
            }
            
            boolean res = true;
            
            for(Boolean fail : failed)
            {
                if(fail)
                {
                    res = false;
                    break;
                }
            }

            if(!res)
            {
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(usecase),"MismatchContent",0);
                result.put(usecase,false);
            }
            else
            {
                result.put(usecase,true);
            }
        }
        catch(Exception e)
        {
            result.put(usecase,false);
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckAddedValues","Error",e);
        }
        Trigger.cancelRule(driver,etest,id);
        return failed;
    }

    public static void checkValuesCRM(WebDriver driver) throws Exception
    {
        Thread.sleep(15000);

        boolean navTo = true;
        for(String s : usecases)
        {
            Boolean failed[];
            if(navTo)
            {
                failed = checkValuesCRM(driver,s,true,Status.INFO);
                navTo = false;
            }
            else
            {
                failed = checkValuesCRM(driver,s,false,Status.INFO);
            }
            
            Boolean res = true;
            
            for(Boolean f : failed)
            {
                if(f)
                {
                    res = false;
                }
            }
            
            try
            {
                ExtentTest etest = (ExtentTest)etests.get(s);
                
                if(res)
                {
                    ComplexReportFactory.closeTest(etest);
                }
                else
                {
                    secondAttemptResult.put(s,failed);
                    
                    etest.log(Status.INFO,"<pre>Second attempt ...</pre>");
                    
                    fillFieldsCRM(driver,etest,s,failed);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers",KeyManager.getRealValue(s),"ErrorWhileChecking"+KeyManager.getRealValue(s),e);
                values.put(s,"Error");
            }
        }

        Set<String> secondAttemptUsecases = secondAttemptResult.keySet();
        
        if(secondAttemptUsecases.size() != 0)
        {
            Thread.sleep(10000);
        }
        
        navTo = true;
        
        for(String s : secondAttemptUsecases)
        {
            try
            {
                String value = values.get(s).toString();
                
                if(!value.equals("Error"))
                {
                    secondAttempt++;
                    
                    String id = value.split("/")[0];
                    
                    secondAttemptIds += id+";";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            if(navTo)
            {
                checkValuesCRM(driver,s,true,Status.FAIL);
                navTo = false;
            }
            else
            {
                checkValuesCRM(driver,s,false,Status.FAIL);
            }
            
            ExtentTest etest = (ExtentTest)etests.get(s);
            
            ComplexReportFactory.closeTest(etest);
        }

        accresDel(driver);

        values = new Hashtable();
        etests = new Hashtable();
        secondAttemptResult = new Hashtable();
        usecases = new Stack();
    }
    
    public static void fillFields(WebDriver driver, ExtentTest etest, String usecase, Boolean failed[]) throws Exception
    {
        String actionValue1 = "Welcome";
        String actionValue2 = "How can I help you?";
        
        String value[] = values.get(usecase).toString().split("/");
        
        String id = value[0];

        Trigger.openRuleEditView(driver,id);

        WebElement e = Trigger.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        Dimension s = driver.manage().window().getSize();
        int x = s.height;
        
        int f = e.getLocation().y;
        
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,0)");
        jse.executeScript("scroll(0,"+(f-(x/2))+")");
        
        etest.log(Status.INFO,"Filling fields for trigger id - "+id);

        Trigger.setRuleName(driver,id,CommonUtil.getUniqueMessage());
        
        if(failed[0])
        {
            Trigger.selectVisitorEvent(driver,id,value[1],etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[1])
        {
            Trigger.selectCriteria(driver,id,value[2],etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[2])
        {
            Trigger.selectCondition(driver,id,value[3],etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[3])
        {
            Trigger.selectValues(driver,id,value[4],etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        String act = value[5];
        String acttimer = value[6];
        
        if(failed[4] || failed[5])
        {
            if((act.equals("Open chat window"))||(act.equals("Glow button"))||(act.equals("Show bubble"))||(act.equals("Show button")))
            {
                Trigger.selectAction(driver,id,act,acttimer,etest);
            }
            else if(act.equals("Send chat invite"))
            {
                Trigger.selectAction(driver,id,act,acttimer,actionValue1,actionValue2,etest);
            }
            else if(act.equals("Animate button"))
            {
                //important
                Trigger.selectAction(driver,id,act,acttimer,etest);
            }
            else if(act.equals("Invoke JS API"))
            {
                actionValue1 = "Checking";
                Trigger.selectAction(driver,id,act,acttimer,actionValue1,null,etest);
            }
            
            // clickHeader(driver,id);//click save
            Trigger.saveRule(driver,etest,id);
            Thread.sleep(1000);
        }
        
        Thread.sleep(2000);
        TakeScreenshot.screenshot(driver,etest,"IntelligentTrigger","Check","Before",0);
    }
    
    public static void fillFieldsCRM(WebDriver driver, ExtentTest etest, String usecase, Boolean failed[]) throws Exception
    {
        String actionValue1 = "Welcome";
        String actionValue2 = "How can I help you?";
        
        String value[] = values.get(usecase).toString().split("/");
        
        String id = value[0];

        Trigger.openRuleEditView(driver,id);
        
        WebElement e = Trigger.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        Dimension s = driver.manage().window().getSize();
        int x = s.height;
        
        int f = e.getLocation().y;
        
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,0)");
        jse.executeScript("scroll(0,"+(f-(x/2))+")");
        
        etest.log(Status.INFO,"Filling fields for trigger id - "+id);
        
        String wcchk = value[1];
        String cond1 = value[2];
        String cond2 = value[3];
        String qual = value[4];
        String val = value[5];
        String act = value[6];
        String acttimer = value[7];
        
        if(failed[0])
        {
            Trigger.selectVisitorEvent(driver,id,wcchk,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[1] || failed[2])
        {
            Trigger.selectCriteria(driver,id,cond1,cond2,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[3])
        {
            Trigger.selectCondition(driver,id,qual,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[4])
        {
            if(cond2.equals("Closing Date"))
            {
                Trigger.selectValuesInDropDown(driver,id,val,etest);
            }
            else
            {
                Trigger.selectValues(driver,id,val,etest);
            }
            clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[5] || failed[6])
        {
            if((act.equals("Open chat window"))||(act.equals("Glow button"))||(act.equals("Show bubble"))||(act.equals("Show button")))
            {
                Trigger.selectAction(driver,id,act,acttimer,etest);
            }
            else if(act.equals("Send chat invite"))
            {
                Trigger.selectAction(driver,id,act,acttimer,actionValue1,actionValue2,etest);
            }
            else if(act.equals("Animate button"))
            {
                //important
                Trigger.selectAction(driver,id,act,acttimer,etest);
            }
            else if(act.equals("Invoke JS API"))
            {
                actionValue1 = "Checking";
                Trigger.selectAction(driver,id,act,acttimer,actionValue1,null,etest);
            }

            Trigger.saveRule(driver,etest,id);
            // clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        Thread.sleep(1000);
        TakeScreenshot.screenshot(driver,etest,"IntelligentTrigger","Check","Before",0);
    }
    
    public static void clickHeader(WebDriver driver, String id) throws Exception
    {
        WebElement e = Trigger.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        WebElement f = CommonUtil.elementfinder(driver,e,"classname","trulesinfo");
        
        mouseHoverAndClick(driver, f);
    }
    
    public static void mouseHoverAndClick(WebDriver driver,WebElement element)
    {
        int x = element.getLocation().x;
        int y = element.getLocation().y;
        
        Actions actions = new Actions(driver);
        actions.moveByOffset(x, y).build().perform();
        actions.click().build().perform();
    }

    //Intelligent triggers default Icons check
    private static boolean checkDefaultIcons(WebDriver driver) throws Exception
    {
        try
        {

            if (checkingIcons(driver,etest)==false)
            {   
               try
               {
                    driver.findElement(By.id("ldsettings")).findElement(By.className("canceldrag")).click();
               }
               catch(Exception e)
               {
                    System.out.println("Exception while close Advanced popup in intelligent triggers : "+e);
               }                
               System.out.println("failed");
               etest.log(Status.FAIL,"IntelligentTriggers Icons not Verified");
               Trigger.cancelRule(driver,etest,"0");
               return false;
            }
            else
            {
               try
               {
                    driver.findElement(By.id("ldsettings")).findElement(By.className("canceldrag")).click();
               }
               catch(Exception e)
                {
                     System.out.println("Exception while close Advanced popup in intelligent triggers : "+e);
                }
                
                etest.log(Status.PASS,"IntelligentTriggers Icons is Verified");
                Trigger.cancelRule(driver,etest,"0");
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIconsIntelligentTrigger","ErrorWhileCheckingDefaulticonsIntelligentTrigger",e);
            Trigger.cancelRule(driver,etest,"0");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIconsIntelligentTrigger","ErrorWhileCheckingDefaulticonsIntelligentTrigger",e);
            Trigger.cancelRule(driver,etest,"0");
            return false;
        }
    }
    

    public static boolean checkingIcons(WebDriver driver,ExtentTest etest) throws Exception
    {   
        int failcount = 0;
        try
        {
        

        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);

        Trigger.clickAdd(driver,etest);
        String elid=Trigger.getRuleId(driver,0);
        elid=Trigger.getRuleId(driver,0);
        Trigger.openRuleEditView(driver,elid);
        Trigger.setRuleName(driver,elid,CommonUtil.getUniqueMessage());

        String type = "Intelligent triggers";
        
        Trigger.selectCriteria(driver,elid,"Browser",etest);clickHeader(driver,elid);
        Thread.sleep(1000);        
        WebElement e = CommonUtil.elfinder(driver,"id","prior"+elid+"_col3");
        e.click();
    

        if(CommonSikuli.browsericons(driver,type,"Default",etest)>0)
        {
            failcount++;
        }

        Trigger.selectCriteria(driver,elid,"Operating System",etest);clickHeader(driver,elid);
        Thread.sleep(1000); 
        e.click();
        
        if (CommonSikuli.operatingsystemicons(driver,type,"Default",etest)>0)
        {
            failcount++;
        }

        Trigger.selectCriteria(driver,elid,"Region",etest);clickHeader(driver,elid);
        Thread.sleep(1000); 
        e.click();
        
        if (CommonSikuli.regionIcons(driver,type,"Default",etest)>0)
         {
            failcount++;
         }
        Trigger.selectCriteria(driver,elid,"Advanced",etest);clickHeader(driver,elid);
        CommonSikuli.findInWholePage(driver,"Intelligenttriggersettings.png","UI239",etest);
        Thread.sleep(1000);
        e.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
        
        filldata(driver,"Browser");
        if (CommonSikuli.browsericons(driver,type,"Advanced",etest)>0)
        {
            failcount++;
        }

        filldata(driver,"Operating System");
        if (CommonSikuli.operatingsystemicons(driver,type,"Advanced",etest)>0)
        {
            failcount++;
        }

        filldata(driver,"Region");
        if (CommonSikuli.regionIcons(driver,type,"Advanced",etest)>0)
        {
            failcount++;
        }

        } 
         catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIconsIntelligentTrigger","ErrorWhileCheckingDefaulticonsIntelligentTrigger",e);
            failcount++;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","CheckDefaultIconsIntelligentTrigger","ErrorWhileCheckingDefaulticonsIntelligentTrigger",e);
            failcount++;
        }
       
        return CommonUtil.returnResult(failcount);
    }

    public static void filldata(WebDriver driver, String type)
    {
        try
        {   
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver.findElement(By.id("prior1_col1")).click();
            CommonSikuli.findInWholePage(driver,"Intelligenttriggersearch.png","UI170",etest);
            driver.findElement(By.id("prior1_col1_ddown")).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(type);
            driver.findElement(By.xpath(".//*[@id='prior1_col1_ddown']//*[contains(@title,'"+type+"')]")).click(); 
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='col3_input1']"))); 
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Intelligent Triggers","IntelligentTriggersPage","ErrorWhileFillingDataIntelligentTriggersPage",e);
            System.out.println("Exception while Fill data in intelligent triggers : "+e);
        }
    }
}
