//$Id$
package com.zoho.livedesk.client;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.Util;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;

import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;

import java.lang.reflect.Method;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.io.StringWriter;
import java.io.PrintWriter;
import java.util.UUID;

import com.zoho.livedesk.util.exceptions.SalesIQAutomationExceptionHandler;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.exceptions.Debugger;
import com.zoho.livedesk.util.ImageProcessor.*;
import com.zoho.livedesk.util.exceptions.ExceptionTracker;


public class TakeScreenshot
{
    public static int scount = 0;
    public static String sync_variable = "";
    
    public static void screenshot(WebDriver driver,String buildName,String folderName,String failureName)
    {
        try
        {
            //Test
            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            
            failureName = failureName+scount;
            buildName = getBuildLabel();
            
            failureName=getFileName();
            String filelocation = filePath()+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);

            if(status)
            {
                System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
            }
            else
            {
                System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot not taken @"+driverGetTime);
            }
            scount++;
        }
        catch(Exception e)
        {
            System.out.println("Exception while trying to take screenshot :");
            e.printStackTrace();
        }
    }

    public static String getFileName()
    {
        return UUID.randomUUID().toString();
    }

    public static void screenshot(WebDriver driver,ExtentTest etest)
    {
        screenshot(driver,etest,"failure","screenshot","view");
    }

    public static void debug(WebDriver driver)
    {
        ExtentTest etest=ComplexReportFactory.getTest("Breakpoints");
        ComplexReportFactory.setValues(etest,"Automation","Breakpoint Screenshots");
        debug(driver,etest);
        ComplexReportFactory.closeTest(etest);
    }

    public static void debug(WebDriver driver,ExtentTest etest)
    {
        debug(driver,etest,"Breakpoint");
    }

    public static void debug(ExtentTest etest,String text)
    {
        debug(null,etest,text);
    }

    public static void debug(WebDriver driver,ExtentTest etest,String text)
    {
        //to be used only in dev mode.
        try
        {
            throw new ZohoSalesIQRuntimeException("breakpoint");
        }
        catch(ZohoSalesIQRuntimeException e)
        {
            String stack_trace=getStacktrace(e);
            String log_info_string=getCustomHTMLForReport(text,stack_trace);
            etest.log(Status.INFO,log_info_string);
        }

        if(driver!=null)
        {
            screenshot(driver,etest,"info","screenshot","view",1);
        }
    }

    public static void infoScreenshot(WebDriver driver,ExtentTest etest)
    {
        screenshot(driver,etest,"info","screenshot","view",1);
    }

    public static void log(Exception e,ExtentTest etest,Status status)
    {
        etest.log(status,getCustomHTMLForReport("Exception occured",getStacktrace(e)));
    }

    public static void log(Exception e,ExtentTest etest)
    {
        log(e,etest,Status.FAIL);
    }

    public static void screenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName,int i)
    {
        try
        {
            System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
            
            test.log(Status.INFO,buildName+"--"+folderName+"--"+failureName);
            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            
            failureName = failureName+scount;
            
            failureName=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);

            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.INFO, "Screenshot: "+driver.getCurrentUrl(), MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
            scount++;
        }
        catch(Exception ee)
        {
            System.out.println("Exception while trying to take screenshot :");
            ee.printStackTrace();
        }
    }

    public static void screenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName,NoSuchElementException e)
    {
        try
        {
            System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
            
            e.printStackTrace();
        
            String reason = e.toString().split("\"}")[0]+"\"}";

            String exception_log=buildName+"--"+folderName+"--"+failureName+"--"+reason;

            addStacktraceToReport(driver,test,exception_log,e);

            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            
            failureName = failureName+scount;
            
            failureName=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);

            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.FAIL, "Error Screenshot: "+driver.getCurrentUrl(), MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
                printInReport(driver,test);
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
            
            scount++;
            
        }
        catch(Exception ee)
        {
            System.out.println("Exception while trying to take screenshot :");
            ee.printStackTrace();
        }
    }

    public static void screenshot(WebDriver driver,ExtentTest test,Exception e)
    {
        screenshot(driver,test,"Exception","Occured","Click here to expand",e);
    }


    public static void screenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName,Exception e)
    {
        try{

        System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
        e.printStackTrace();
            String reason = e.toString();
        if(reason.contains("TimeoutException"))
           {
                reason = reason.split("Build info")[0];
                String exception_log=buildName+"--"+folderName+"--"+failureName+"--"+reason;
                addStacktraceToReport(driver,test,exception_log,e);
            }
            else if(reason.contains("NoSuchElementException"))
            {
                reason = reason.split("\"}")[0]+"\"}";
                String exception_log=buildName+"--"+folderName+"--"+failureName+"--"+reason;
                addStacktraceToReport(driver,test,exception_log,e);
            }
           else
           {
               String exception_log=buildName+"--"+folderName+"--"+failureName+"--"+e.getClass().getName();
               addStacktraceToReport(driver,test,exception_log,e);
           }


            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
        
            failureName = failureName+scount;
            
            failureName=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);

            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.FAIL, "Error Screenshot: "+driver.getCurrentUrl(), MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
                printInReport(driver,test);
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
        
            scount++;

            SalesIQAutomationExceptionHandler.handleAllExceptions(driver,test);
            
        }
        catch(Exception ee)
        {
            System.out.println("Exception while trying to take screenshot :");
            ee.printStackTrace();
        }
    }


    public static void addStacktraceToReport(WebDriver driver,ExtentTest test,String header_text)
    {
        addStacktraceToReport(driver,test,header_text,null);
    }

    public static void addStacktraceToReport(ExtentTest test,String header_text,Exception e)
    {
        addStacktraceToReport(null,test,header_text,e);
    }

    public static void addSiteStateToReport(WebDriver driver,ExtentTest etest)
    {
        addStacktraceToReport(driver,etest,"Click here to view the portal state.",null);
    }

    public static void addStacktraceToReport(WebDriver driver,ExtentTest test,String header_text,Exception e)
    {
        String site_state="";

        String stack_trace="";

        if(driver!=null && Debugger.isSiteStateLoggable(driver))
        {
            site_state="Site state at the time of exception : \n\n"+Debugger.getSiteStateAsHTML(driver)+"\n\n\n";
        }

        if(e!=null)
        {
            stack_trace=getStacktrace(e);
            //Track
            ExceptionTracker.track(e);
        }

        String inner_content=site_state+stack_trace;

        String log_info_string="";

        if(inner_content.equals("")==false)
        {
            log_info_string=getCustomHTMLForReport(header_text,inner_content);
        }
        else
        {
            log_info_string=header_text;
        }


        test.log(Status.FAIL,log_info_string);
    }

    public static void addStacktraceToReport(ExtentTest test,Exception e)
    {
        addStacktraceToReport(test,"Click to expand stacktrace",e);
    }

    public static String getStacktrace(Exception e)
    {
        return SalesIQAutomationExceptionHandler.getStacktrace(e);
    }
    public static String getCustomHTMLForReport(String header,String content)
    {
        String uniqueID = UUID.randomUUID().toString();
        uniqueID="'"+uniqueID+"'";
        String html="<div onclick=\"if(document.getElementById("+uniqueID+").style.display.includes('none')){document.getElementById("+uniqueID+").style.display='block'}else{document.getElementById("+uniqueID+").style.display='none' }document.querySelectorAll('.test.active')[0].click()\">"+header+"</div><div id="+uniqueID+" style='display: none;'><pre>"+content+"</pre></div>";
        return html;
    }

    public static void addExpandableLog(ExtentTest etest,Status log_status,String header,String content)
    {
        etest.log(log_status,getCustomHTMLForReport(header,content));   
    }

    public static void screenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName)
    {
        try
        {
            System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
            
            String failure_log=buildName+"--"+folderName+"--"+failureName;

            addStacktraceToReport(driver,test,failure_log);

            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            
            failureName = failureName+scount;
            
            failureName=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);

            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.FAIL, "Error Screenshot: "+driver.getCurrentUrl(), MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
                printInReport(driver,test);
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
            
            
            scount++;
            
        }
        catch(Exception e)
        {
            System.out.println("Exception while trying to take screenshot :");
            e.printStackTrace();
        }
    }
    public static void screenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName,String failureName1)
    {
        try
        {
            System.out.println(buildName+"--"+folderName+"--"+failureName+"--"+failureName1+"--Screenshot taken");
            
            test.log(Status.FAIL,buildName+"--"+folderName+"--"+failureName+"--"+failureName1);
            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            failureName1 = removeSpecialCharacters(failureName1);
            
            failureName1 = failureName1+scount;
            
            failureName1=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+"/"+failureName1;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);

            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.FAIL, "Error Screenshot: "+driver.getCurrentUrl(), MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
                printInReport(driver,test);
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
            
            scount++;
         
            
        }
        catch(Exception e)
        {
            System.out.println("Exception while trying to take screenshot :");
            e.printStackTrace();
        }
    }  

    public static String filePath()
    {
        URL location = TakeScreenshot.class.getProtectionDomain().getCodeSource().getLocation();
        String fileloc = location.getFile();
        fileloc = fileloc.replaceAll("/lib/livedesk-webdriver.jar","/webapps/selenium/screenshots/");
        return fileloc;
    }
    private static String removeSpecialCharacters(String s)
    {
        synchronized(sync_variable)
        {
            if(s != null)
            {
                s = s.replaceAll(" ","_");
                s = s.replaceAll("#","_");
                s = s.replaceAll("/","_");
                s = s.replaceAll("'","_");
                s = s.replaceAll("\\?","_");
                s = s.replaceAll("!","_");
            }
            return s;
        }
    }
    
    public static void printInReport(WebDriver driver, ExtentTest test)
    {
        List console_errors=new ArrayList<String>();

        LogEntries logEntries = driver.manage().logs().get("browser");
        
        Long t1 = ComplexReportFactory.getStartedTime(test);
        
        boolean timeDuration = false;
        
        Long t2 = new Long(System.currentTimeMillis());
        
        if(t2 - t1 <= 120000)
        {
            timeDuration = true;
        }
        
        boolean first = true;
        
        for (LogEntry entry : logEntries)
        {
            if(entry.getLevel().toString().toLowerCase().contains("severe"))
            {
                if(entry.toString().contains("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/favicon.ico") || entry.toString().contains("http://"+Util.serverHostName+"/favicon.ico"))
                {
                    continue;
                }
                if(entry.toString().contains("http://"+Util.serverHostName+"/foundation.css") || entry.toString().contains("http://"+Util.serverHostName+"/style.css"))
                {
                    continue;
                }
                
                if(timeDuration)
                {
                    if(entry.getTimestamp() >= t1)
                    {
                        if(first)
                        {
                            first = false;
                        }

                        console_errors.add(entry.toString());

                    }
                    else
                    {
                       com.zoho.livedesk.util.Util.print(t1+"<><><><>"+entry.toString());
                    }
                }
                else
                {
                    if(entry.getTimestamp()+120000 >= System.currentTimeMillis())
                    {
                        if(first)
                        {
                            first = false;
                        }
                        
                        console_errors.add(entry.toString());            
                    }
                    else
                    {
                        com.zoho.livedesk.util.Util.print(t1+"<><><><>"+entry.toString());
                    }
                }
            }
        }

        addConsoleErrorsToReport(test,console_errors);

    }

    public static void addConsoleErrorsToReport(ExtentTest etest,List<String> console_errors)
    {
        if(console_errors.size()==0)
        {
            return;
        }

        String console_errors_string="";

        for(String console_error : console_errors)
        {
            console_errors_string=console_errors_string+"<pre>"+console_error+"</pre><br><br>";
        }
        
        String console_errors_html=getCustomHTMLForReport("<b style='color:red'>Console Errors (click here to expand)</b>",console_errors_string);

        etest.log(Status.FAIL,console_errors_html);
    }
    
    public static String getBuildLabel()
    {
        return Util.buildlabel().replace("/","_");
    }

    public static void takingScreenshot(WebDriver driver, String filelocation) throws Exception
    {
        if(filelocation.contains(".jpg")==false)
        {
            filelocation=filelocation+".jpg";
        }

        // driver = new Augmenter().augment(driver);
        // File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        // FileUtils.copyFile(scrFile, new File(filelocation));    
        // ImageCompressor.compressAndWrite(scrFile,filelocation);

        driver = new Augmenter().augment(driver);            
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(scrFile, new File(filelocation));
    }

    public static boolean takeScreenshot(WebDriver driver, String filelocation) throws Exception
    {
        boolean status = testIt(driver,filelocation,true);

        return status;
    }

    public static class Thread_Class extends Thread
    {
        private boolean status = false;
        private WebDriver d = null;
        private String loc = null;
        private Exception excep = null;

        Thread_Class(WebDriver d1, String l1)
        {
            d = d1;
            loc = l1;
        }

        public void run()
        {
            try
            {
                takingScreenshot(d, loc);

                status = true;
            }
            catch (Exception e)
            {
                excep = e;
            }
        }

        public Boolean getValue()
        {
            return status;
        }

        public Exception getException()
        {
            return excep;
        }
    }

    public static boolean testIt(WebDriver driver, String filelocation, boolean another) throws Exception
    {
        Thread_Class obj = new Thread_Class(driver, filelocation);

        int count = 0;

        obj.start();
        
        for(;;)
        {
            if(obj.getValue())
            {
                return true;
            }
            if(obj.getException() != null)
            {
                throw obj.getException();
            }
            if(count++ > 30)
            {
                stopThread(obj);
                if(another)
                {
                    return testIt(driver,filelocation,false);
                }
                else
                {
                    return false;
                }
            }
            Thread.sleep(1000);
        }
    }

    public static void stopThread(Thread_Class e) throws Exception
    {
        Method m = Thread.class.getDeclaredMethod( "stop0" , new Class[]{Object.class} );
        m.setAccessible( true );
        m.invoke( e , new ThreadDeath() );
    }
    
    public static void mobileScreenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName,Exception e)
    {
        try{
            
            System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
            e.printStackTrace();
            String reason = e.toString();
            if(reason.contains("TimeoutException"))
            {
                reason = reason.split("Build info")[0];
                test.log(Status.FAIL,buildName+"--"+folderName+"--"+failureName+"--"+reason);
            }
            else if(reason.contains("NoSuchElementException"))
            {
                reason = reason.split("\"}")[0]+"\"}";
                test.log(Status.FAIL,buildName+"--"+folderName+"--"+failureName+"--"+reason);
            }
            else
            {
                test.log(Status.FAIL,buildName+"--"+folderName+"--"+failureName+"--"+e.getClass().getName());
            }
            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            
            failureName = failureName+scount;
            
            failureName=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);
            
            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.FAIL, "Error Screenshot: "+driver.getCurrentUrl(), MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
            
            scount++;
        }
        catch(Exception ee)
        {
            System.out.println("Exception while trying to take screenshot :");
            ee.printStackTrace();
        }
    }
    
    public static void mobileScreenshot(WebDriver driver,ExtentTest test,String buildName,String folderName,String failureName) throws IOException
    {
        try
        {
            System.out.println(buildName+"--"+folderName+"--"+failureName+"--Screenshot taken");
            
            test.log(Status.FAIL,buildName+"--"+folderName+"--"+failureName);
            failureName = removeSpecialCharacters(failureName);
            folderName = removeSpecialCharacters(folderName);
            
            failureName = failureName+scount;
            
            failureName=getFileName();
            String filelocation = filePath()+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName;
            
            DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date dateobj = new Date();
            String driverGetTime = df.format(dateobj);
            
            boolean status = takeScreenshot(driver, filelocation);
            
            if(status)
            {
                String screenshot_url="http://"+Util.serverHostName+":"+Util.serverPortNumber+"/screenshots/"+getBuildLabel()+"/"+buildName+"/"+folderName+"/"+failureName+".jpg";
                test.log(Status.FAIL, "Error Screenshot: ", MediaEntityBuilder.createScreenCaptureFromPath(screenshot_url).build());
            }
            else
            {
                test.log(Status.FAIL,"Screenshot not taken @"+driverGetTime);
            }
            
            scount++;
        }
        catch(Exception e)
        {
            System.out.println("Exception while trying to take screenshot :");
            e.printStackTrace();
        }
    }
}
