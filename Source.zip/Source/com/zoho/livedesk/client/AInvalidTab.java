//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class AInvalidTab
{
    public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    
    private static String url = "";
    public static ExtentTest etest; 
    
    public static Hashtable invalidtab(WebDriver driver)
    {
        try
        {
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASIT1"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Associate");
            
            url = ConfManager.requestURL();
            
            result.put("ASIT1",false);
            result.put("ASIT2",false);
            result.put("ASIT3",false);
            result.put("ASIT4",false);
            result.put("ASIT5",false);
            
            result.put("ASIT1", checkTab(driver,"settings_portal"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASIT2"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Associate");

            result.put("ASIT2", checkTab(driver,"settings_leadscoring"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASIT3"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Associate");

            result.put("ASIT3", checkTab(driver,"settings_integration"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASIT4"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Associate");

            result.put("ASIT4", checkTab(driver,"settings_automationtab"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASIT5"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Associate");

            result.put("ASIT5", checkTab(driver,"settings_webembed"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASIT6"));
            ComplexReportFactory.setValues(etest,"Automation","InvalidTabs - Associate");

            result.put("ASIT6", checkTab(driver,"Reports"));
            
            ComplexReportFactory.closeTest(etest);
        }
        catch(NoSuchElementException e)
        {
            result.put("ASIT1",false);
            result.put("ASIT2",false);
            result.put("ASIT3",false);
            result.put("ASIT4",false);
            result.put("ASIT5",false);
            result.put("ASIT6",false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
        }
        catch(Exception e)
        {
            result.put("ASIT1",false);
            result.put("ASIT2",false);
            result.put("ASIT3",false);
            result.put("ASIT4",false);
            result.put("ASIT5",false);
            result.put("ASIT6",false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
        }
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }
    
    //check main tabs
    private static boolean checkTab(WebDriver driver,String tname)
    {
        try
        {
            Thread.sleep(1000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue(tname))).click();
            
            Thread.sleep(1000);
            
            TakeScreenshot.screenshot(driver,etest,"InvalidTabs-Associate","InvalidTab:"+ResourceManager.getRealValue(tname),"TabIsPresent");

            return false;
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.PASS,ResourceManager.getRealValue(tname)+" is not present");

            return true;
        }
        catch(Exception e)
        {
            etest.log(Status.PASS,ResourceManager.getRealValue(tname)+" is not present");

            return true;
        }
    }
}
