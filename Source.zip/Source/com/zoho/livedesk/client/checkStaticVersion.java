//$Id$
package com.zoho.livedesk.client;



import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;



import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;



import com.zoho.livedesk.util.common.CommonUtil;

public class checkStaticVersion{


	static WebDriver driver1,driver2;	

	public static String test() throws Exception
	{
        String staticVersion = "";
		try
		{
            String setup = "";
            
            if(Util.siteNameout().contains("lab"))
            {
                setup = "Lab SalesIQ";
            }
            else if(Util.siteNameout().contains("local"))
            {
                setup = "Local";
            }
            else if(Util.siteNameout().contains("pre"))
            {
                setup = "Pre";
            }
            else
            {
                return staticVersion;
            }
            
            staticVersion = "\\n*Static version*:  ";
            
			driver1=Functions.setUp();
			driver2=Functions.setUp();
					
			Functions.login(driver2,"static_agent");
			Functions.login(driver1,"static_idc_agent");

			String content = checkJsAndCssUpdate(driver1,driver2,setup);
            
            System.out.println(content);
 
            Functions.logout(driver1);
            Functions.logout(driver2);
        
            return staticVersion+content;
      	}
		catch(Exception e)
		{
            System.out.println("FATAL_ERROR_OCCURRED");
            e.printStackTrace();
            return staticVersion+"Could not be found";
		}
    }

	public static String checkJsAndCssUpdate(WebDriver driver1,WebDriver driver2,String setup) throws Exception
	{
        String chat_message_content="*"+setup+"* - "+getJsAndCssVersion(driver2);
        
        chat_message_content += " | *IDC* - "+getJsAndCssVersion(driver1);
		
        return chat_message_content;
	}

   	public static String getJsAndCssVersion(WebDriver driver)
   	{
   		String js_ver=getJsVersion(driver);
   		String css_ver=getCssVersion(driver);
   		if(js_ver.equals(css_ver))
   		{
   			return js_ver;
   		}
   		else
   		{
   			System.out.println("STRING_MISMATCH_FAILURE_DIFFRENT_JS_AND_CSS_EXISTS"+js_ver+"<><>"+css_ver+"<><>");
   		}

   		return null;
   	}

   	public static String getJsVersion(WebDriver driver)
   	{
   		List<WebElement> staticScriptTags = driver.findElements(By.xpath("//script[contains(@src,'zohostatic.com/salesiq/')]"));
   		String jsVersion= "Not found";
        String previous = null;
        int i = 0;
        
   		for(WebElement ele : staticScriptTags)
   		{
   			jsVersion=ele.getAttribute("src").toString().split("zohostatic.com/salesiq/")[1].split("/")[0];
   			System.out.println(i+"<><>"+jsVersion);
   			if(jsVersion.contains("https"))
            {
                if(previous != null)
                {
                    if(!jsVersion.equals(previous))
                    {
                        System.out.println(previous+"<>Mismatch<>"+jsVersion);
                        return null;
                    }
                }
                
                previous = jsVersion;
            }
   			i++;
   		}

   		return jsVersion;
   	}

   	public static String getCssVersion(WebDriver driver)
   	{
   		List<WebElement> staticCssTags = driver.findElements(By.xpath("//link[contains(@href,'zohostatic.com/salesiq/')]"));
   		String cssVersion="Not found";
   		int i=0;
   		for(WebElement ele : staticCssTags)
   		{
   			cssVersion=ele.getAttribute("href").toString().split("zohostatic.com/salesiq/")[1].split("/")[0];
   			System.out.println(i+"<><>"+cssVersion);
   			if(i>0)
   			{
   				if(!staticCssTags.get(i-1).equals(ele.getAttribute("href").toString().split("zohostatic.com/salesiq/")[1].split("/")[0]))
	   			{
	   				return null;
	   			}	
   			}
   			i++;

   		}

   		return cssVersion;
   	}
}