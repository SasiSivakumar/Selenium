//$Id$
package com.zoho.livedesk.client.ChatMonitorRT;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Cookie;
import java.net.URL;

import com.google.common.base.Function;
import com.zoho.qa.server.servlet.WebdriverApi;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.zoho.livedesk.client.TakeScreenshot;
import com.aventstack.extentreports.Status;

public class CommonFunctions
{
    public static void clickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setting_sm_user")));
    }

    public static void clickMyChats(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("suppm_mycurrent")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("suppm_mycurrent")));

        CommonUtil.elfinder(driver,"id","suppm_mycurrent").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("mycurrent_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("mycurrent_div")));
    }

    public static void clickConnected(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("suppm_current")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("suppm_current")));

        CommonUtil.elfinder(driver,"id","suppm_current").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("current_mcontent")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current_mcontent")));
    }

    public static void clickChatMonitor(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        navigateToAutomation(driver);

        Thread.sleep(1000);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_chatmonitor"))));

        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("automationtab_chatmonitor")).click();

        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
    }

    public static void clickVisitorsOnline(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_monitor")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visitor_monitor")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
    }

    public static void navigateToAutomation(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickSettings(driver);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));

        CommonUtil.elfinder(driver,"id","setting_sm_automation").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("automationcontent")));
    }

    public static void navToEmbedTab(WebDriver driver) throws Exception
    {
        clickSettings(driver);

        FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));

        WebElement embed = CommonUtil.elfinder(driver,"id","setting_sm_embedchats");

        embed.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
    }

    public static void clickIntelligentTriggers(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        navigateToAutomation(driver);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotriggerstab")));

        CommonUtil.elfinder(driver,"classname","autotriggerstab").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotabcontainer")));
    }

    public static WebElement selectChatInConnected(WebDriver driver,String visitor,String question) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        String content = "";

        CommonWait.waitTillDisplayed(driver,By.id("current_div"));

        List<WebElement> chats = com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("current_div"),By.id("historylist")).findElements(By.tagName("tr"));

        for(WebElement e : chats)
        {
            content += "<><>"+e.getText();
            
            if(e.getText().contains(visitor) && e.getText().contains(question))
            {
                return e;
            }
        }
        
        content += "<><>";
        
        System.out.println("Content for Select chat in connected. Expected"+visitor+"--"+question+"--Actual:"+content);

        return null;
    }

    public static String getQuestionFromChat(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        for(int i = 1;i<=10;i++)
        {
            if(CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn").isDisplayed())
                break;
            Thread.sleep(1000);
        }
        return CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn").getText();
    }

    public static String getVisitorNameFromChat(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        for(int i = 1;i<=10;i++)
        {
            if(CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn").isDisplayed())
                break;
            Thread.sleep(1000);
        }
        return CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn"),"id","chatvisname").getText();
    }

    public static void clickJoinInMyChats(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"id","infodiv");

        wait.until(ExpectedConditions.visibilityOf(e));

        WebElement join = CommonUtil.elementfinder(driver,e,"linktext","Join this chat");

        wait.until(ExpectedConditions.visibilityOf(join));

        join.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","lvd_popupsub"),"id","okbtn").click();

        Thread.sleep(500);

        checkPresenceOfTextArea(driver);
    }

    public static void clickJoinInConnected(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("current_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current_div")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".gren-btn.sel")));

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","current_div"),"css",".gren-btn.sel").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","lvd_popupsub"),"id","okbtn").click();

        Thread.sleep(500);

        checkPresenceOfTextArea(driver);
    }

    public static void clickEndInConnected(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("current_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("current_div")));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".sptmisd-btn.marginfour")));

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","current_div"),"css",".sptmisd-btn.marginfour").click();

    }

    public static void checkPresenceOfTextArea(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        final WebElement e = CommonUtil.elementfinder(driver,chat,"id","comptable");

        wait.until(ExpectedConditions.visibilityOf(e));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!e.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static boolean checkMessageInUserWindow(WebDriver driver,String user,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"id","chatdivcontainer");

        wait.until(ExpectedConditions.visibilityOf(e));

        List<WebElement> messages = e.findElements(By.tagName("tr"));

        for(WebElement f : messages)
        {
            if(f.getText().contains(user) && f.getText().contains(msg))
                return true;
        }
        return false;
    }

    public static boolean checkMessageInVisitorWindow(WebDriver driver,String user,String msg) throws Exception
    {
        return VisitorWindow.checkAgentMessageInChatWindow(driver,user,msg,2);
    }

    public static String getRadioButtonId(String type)
    {
        String typeid = null;
        String ipid = null;

        if(type.equals("VisitorEmail"))
        {
            typeid = "cmvisitoremail";
            ipid = "cmvisitoremailinput";
        }
        else if(type.equals("IpAddress"))
        {
            typeid = "cmipaddress";
            ipid = "cmipaddressinput";
        }
        else
        {
            typeid = "cmsupportrep";
            ipid = "cmsupportrepinput";
        }

        return typeid;
    }

    public static String getInputId(String type)
    {
        String typeid = null;
        String ipid = null;

        if(type.equals("VisitorEmail"))
        {
            typeid = "cmvisitoremail";
            ipid = "cmvisitoremailinput";
        }
        else if(type.equals("IpAddress"))
        {
            typeid = "cmipaddress";
            ipid = "cmipaddressinput";
        }
        else
        {
            typeid = "cmsupportrep";
            ipid = "cmsupportrepinput";
        }

        return ipid;
    }

    public static void clickAddInChatMonitor(WebDriver driver) throws Exception
    {
        
        Trigger.clickAddButtonAutomationTab(driver,"chatmonitortab");
    
    }
    public static void addChatMonitor(WebDriver driver,String type,String value) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        //CommonFunctions.navigateToAutomation(driver);

        Tab.navToCMTab(driver);

        final String typeid = getRadioButtonId(type);
        final String ipid = getInputId(type);

        clickAddInChatMonitor(driver);

        //Check chat add monitor page
        CommonUtil.elfinder(driver,"xpath","//*[contains(.,'"+ResourceManager.getRealValue("settings_addchatmonitor")+"')]");

        //Add chat monitor
        //WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(typeid)));

        CommonUtil.elfinder(driver,"id",typeid).click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id(ipid)).getAttribute("class").contains("disable_cntnr"))
                {
                    return true;
                }
                return false;
            }
        });

        if(type.equals("Operator"))
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(ipid)));

            CommonUtil.elfinder(driver,"id",ipid).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cmsupportrepinput_ddown")));

            List<WebElement> users = CommonUtil.elfinder(driver,"id","cmsupportrepinput_ddown").findElements(By.tagName("li"));

            for(WebElement e : users)
            {
                if(e.getText().equals(value))
                    e.click();
            }

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("cmsupportrepinput_ddown")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        else
        {
            CommonUtil.elfinder(driver,"id",ipid).sendKeys(value);
        }
        Thread.sleep(300);
        CommonUtil.elfinder(driver,"id","ipsavebtn").click();

    }

    public static void deleteChatMonitor(WebDriver driver,String value) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        //CommonFunctions.navigateToAutomation(driver);

        Tab.navToCMTab(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

        WebElement elmt1 = CommonUtil.elfinder(driver,"id","listview");
        List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

        for(WebElement elmt:elmts)
        {
            if(elmt.getText().contains(value))
            {
                List<WebElement> em = elmt.findElements(By.tagName("em"));

                new Actions(driver).moveToElement(em.get(2)).build().perform();

                em.get(2).click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                CommonUtil.elfinder(driver,"id","okbtn").click();

                Thread.sleep(1000);
            }
        }
    }

    public static String returnVisitorId(WebDriver driver) throws Exception
    {
        String portalname = ConfManager.getChatmonitorPortalName();

        return VisitorWindow.getVisitorId(driver,portalname);
    }

    // public static String returnVisitorId(WebDriver driver) throws Exception
    // {
    //     FluentWait wait = CommonUtil.waitreturner(driver,30,250);

    //     wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div .visit_div")));

    //     WebElement listElmt = CommonUtil.elfinder(driver,"id","ldwrap");

    //     List<WebElement> vlists = listElmt.findElements(By.cssSelector("div .visit_div"));

    //     System.out.println("Visitor List Size - "+vlists.size()+"&& Latest Visitor ID : "+vlists.get(vlists.size()-1).getAttribute("id"));

    //     String uvid = vlists.get(vlists.size()-1).getAttribute("id");

    //     //String uuid = (((JavascriptExecutor) driver).executeScript("return UTSHandler.visitors[\""+uvid+"\"].data[\"uuid\"];")).toString();

    //     return uvid;
    // }

    public static void initiateChatVis(WebDriver driver,String vname,String vemail,String vphone,String vques) throws Exception
    {
        VisitorWindow.initiateChatVisTheme(driver,vname,vemail,vphone,vques,ChatMonitorRealTime.etest);
    }

    public static void initiateChatUser(WebDriver driver,String id,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        clickVisitorsOnline(driver);

        VisitorsOnline.waitTillVisitorPresent(driver,id);

        CommonUtil.elfinder(driver,"id",id).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        try
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.detbox.box4")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.detbox.box4")));

            ChatMonitorRealTime.ipaddress = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"css","div.detbox.box4"),"tagname","p").getText();

            ChatMonitorRealTime.etest.log(Status.INFO,"IP Address : "+ChatMonitorRealTime.ipaddress);

            TakeScreenshot.screenshot(driver,ChatMonitorRealTime.etest,"ChatMonitor","IPAddress","TilesUI",0);
        }
        catch(Exception e)
        {
            ChatMonitorRealTime.etest.log(Status.FAIL,"IP Address cannot be found");
            TakeScreenshot.screenshot(driver,ChatMonitorRealTime.etest,"ChatMonitor","FindIP","Error");
        }

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht"),"tagname","textarea").sendKeys(msg);

        WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");
        CommonUtil.elementfinder(driver,pelmt,"linktext",ResourceManager.getRealValue("rings_proactive")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".chatarea.ps-container")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".chatarea.ps-container")));

        Thread.sleep(1000);
    }

    public static void acceptChat(WebDriver driver) throws Exception
    {
        driver.navigate().refresh();
        ChatWindow.acceptChat(driver,ChatMonitorRealTime.etest);
    }

    public static void sentMessageVisitor(WebDriver driver,String msg) throws Exception
    {
        VisitorWindow.sentMessageInTheme(driver,msg);
    }

    public static void switchToChatWidget(WebDriver driver) throws Exception
    {
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","zlsiframe"));
    }
    public static void sentMessageUser(WebDriver driver,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"id","txteditor");

        wait.until(ExpectedConditions.visibilityOf(e));

        e.sendKeys(msg);
        e.sendKeys(Keys.RETURN);
    }

    public static void clickClosethisWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"id","infodiv");

        wait.until(ExpectedConditions.visibilityOf(e));

        CommonUtil.elementfinder(driver,e,"linktext",ResourceManager.getRealValue("closewindow")).click();

        Thread.sleep(1000);

    }
    public static void endChatUser(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);

        CommonUtil.elementfinder(driver,chat,"id","endsession").click();

        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();

    }

    public static void endChatUser(WebDriver driver,String action) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        sentMessageUser(driver,"Bye ...");
        
        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);
        
        CommonUtil.elementfinder(driver,chat,"id","endsession").click();
        
        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue(action)).click();
            
    }

    public static WebElement chatInMyChats(WebDriver driver) throws Exception
    {
        List<WebElement> list = CommonUtil.elfinder(driver,"id","mycurrent_div").findElements(By.className("prelative"));

        WebElement chat = null;

        for(WebElement e : list)
        {
            if(e.getAttribute("style").contains("display: block;"))
                chat = e;
        }

        return chat;
    }

    public static void endChatVisitor(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            switchToChatWidget(driver);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lstxteditor")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("optionbtn")));

            CommonUtil.elfinder(driver,"id","optionbtn").click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("endcht")));

            CommonUtil.elfinder(driver,"classname","endcht").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fedbckinfotxtid")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fedbckinfotxtid")));

            driver.switchTo().defaultContent();
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            throw e;
        }

    }

    public static void clickCloseVisitor(WebDriver driver) throws Exception
    {
        driver.switchTo().defaultContent();

        CommonUtil.elfinder(driver,"id","zlscloseimg").click();

        Thread.sleep(1000);
    }

    public static void waitTillVisitorLeaves(WebDriver driver,WebDriver visdriver) throws Exception
    {
        clickVisitorsOnline(driver);

        visdriver.get("data:,");

        FluentWait drwait = CommonUtil.waitreturner(driver,80,500);

        drwait.until(new Function<WebDriver,Boolean>()
                     {
                         public Boolean apply(WebDriver driver)
                         {
                             try
                             {
                                 if(driver.findElement(By.xpath("//div[contains(@class,'visit_div')]")).getAttribute("id")!=null)
                                 {
                                     return false;
                                 }
                                 return true;
                             }
                             catch(Exception e)
                             {
                                 return true;
                             }
                         }
                     });

    }

    public static WebDriver openVis(WebDriver driver) throws Exception
    {
        VisitorWindow.createPage(driver,ChatMonitorRealTime.widgetcode);

        return driver;
    }
    public static void closeMyChats(WebDriver driver)
    {
        try
        {
            driver.navigate().refresh();
            CommonFunctions.clickMyChats(driver);
        }
        catch(Exception e)
        {
            return;
        }
        try
        {
            CommonFunctions.endChatUser(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while endchatuser : "+e);
        }
        try
        {
            CommonFunctions.clickClosethisWindow(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clickClosethisWindow : "+e);
        }
    }

    public static WebDriver cleanUp(WebDriver driver1,WebDriver driver2,WebDriver visdriver,String name)
    {
        try
        {
            if(driver2 != null)
            {
                closeMyChats(driver2);
            }

            if(driver1 != null)
            {
                //closeMyChats(driver1);
                driver1.navigate().refresh();
                Thread.sleep(2000);
                deleteChatMonitor(driver1,name);
            }

            if(visdriver != null)
            {
                visdriver.quit();
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while cleaning in chat monitor rt module : "+e);
        }
        try
        {
            return Functions.setUp(true);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static WebDriver cleanUp(WebDriver driver,WebDriver visdriver,String name)
    {
        try
        {
            if(driver != null)
            {
                //closeMyChats(driver1);
                driver.navigate().refresh();
                Thread.sleep(2000);
                deleteChatMonitor(driver,name);
            }

            if(visdriver != null)
            {
                visdriver.quit();
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while cleaning in chat monitor rt module : "+e);
        }
        try
        {
            return Functions.setUp(true);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static void changeUserDept(WebDriver driver,String user,String dept) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickSettings(driver);

        String userid = "";

        List<WebElement> users = CommonUtil.elfinder(driver,"id","ulisttable").findElements(By.className("list-row"));

        for(WebElement e : users)
        {
            if(e.getText().contains(user))
            {
                userid = e.getAttribute("id");
                e.click();
            }
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Edit Profile")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Edit Profile")));

        String url = Util.siteNameout()+"/"+ConfManager.getChatmonitorPortalName()+"/index#setting/user/edit/"+userid;

        driver.get(url);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("useredit")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("useredit")));

        final WebElement depts = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","useredit"),"id","seldepartment");

        CommonUtil.inViewPort(depts);

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

        if(CommonUtil.elementfinder(driver,depts,"classname","seltext").getAttribute("style").contains("none"))
        {
            List<WebElement> list = CommonUtil.elementfinder(driver,depts,"classname","field_main").findElements(By.className("field_div"));

            for(WebElement e : list)
            {
                CommonUtil.elementfinder(driver,e,"classname","sqico-plus").click();
            }

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(!depts.findElement(By.className("seltext")).getAttribute("style").contains("none"))
                            return true;
                    }
                    catch(Exception e){}
                    return false;
                }
            });
        }

        Thread.sleep(1000);

        WebElement sel = CommonUtil.elementfinder(driver, depts, "css", ".field_main.unsel_main");

        List<WebElement> list = sel.findElements(By.className("field_div"));

        for(WebElement e : list)
        {
            if(e.getText().contains(dept))
            {
                CommonUtil.elementfinder(driver,e,"classname","sqico-plus").click();
                break;
            }
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(depts.findElement(By.className("seltext")).getAttribute("style").contains("none"))
                        return true;
                }
                catch(Exception e){}
                return false;
            }
        });

        WebElement update = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","useredit"),"id","useradd");

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");

        update.click();

        Tab.waitForLoadingSuccessWithBanner(driver,"User details updated successfully","updateusrdetails.do",ChatMonitorRealTime.etest);
    }
}
