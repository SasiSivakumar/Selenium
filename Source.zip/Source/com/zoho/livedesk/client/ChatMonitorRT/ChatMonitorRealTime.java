//$Id$
package com.zoho.livedesk.client.ChatMonitorRT;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class ChatMonitorRealTime
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static ExtentTest etest;
    public static WebDriver visDriver = null;
    public static WebDriver supDriver = null;
    public static WebDriver assoDriver = null;
    public static String url = null;
    public static Long t = null;
    public static String ipaddress = null;
    public static String ipaddress1 = "";
    public static String ipaddress2 = "";
    public static String ipaddress3 = "";
    public static String ipaddress4 = "";
    public static String ipaddress5 = "";
    public static String ipaddress6 = "";
    public static String widgetcode = "";

    public static Hashtable cmrt(WebDriver driver)
    {
        try
        {
            result = new Hashtable();
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT17"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            widgetcode = ExecuteStatements.getWidgetCode(driver);
            
            if(Util.setUptracking().contains("local"))
            {
                // widgetcode = "e91dabf0c282530044e4d41792feb8632d7f17d1808b5d9f8be6bcc3e0ff5a443667780ea08a1e9d23e2db9c722864e1";
                ipaddress1 = "192.168"+"."+"144.105"; //qa4, split ip due to codecheck
                ipaddress2 = "192.168.144.116"; //zsalesiq-imac
                // ipaddress3 = "192.168.144.239"; //zsalesiq2
                ipaddress4 = "192.168.144.123"; //linux 1
                ipaddress5 = "192.168.144.218"; //linux 2
                ipaddress6 = "192.168.144.40";  //linux 3
            }
            else
            {
                // widgetcode = "940e920c0d4217a22fd3e08e09c3cb62b7d40f0914fa7f82547206c14f666736b820be693dc85220cfa2ff02a70a9ac1";
                ipaddress1 = "121.244"+"."+"91.20";   //qa4, split ip due to codecheck
                ipaddress2 = "121.244.91.21";   //zsalesiq-imac
                // ipaddress3 = "121.244.91.24";   //zsalesiq2
                ipaddress4 = "121.244.91.22";   //linux 1
                ipaddress5 = "121.244.91.21";   //linux 2
                ipaddress6 = "121.244.91.23";   //linux 3
            }
            
            supDriver = Functions.setUp();
            assoDriver = Functions.setUp();
            
            if(!Functions.login(supDriver,"cm_rt_supervisor") | !Functions.login(assoDriver,"cm_rt_associate"))
            {
                etest.log(Status.FAIL,"Login Failed");
                ComplexReportFactory.closeTest(etest);
                result.put("CMRT1",false);
                hashtable.put("result", result);
                hashtable.put("servicedown", servicedown);
                return hashtable;
            }
            visDriver = Functions.setUp(true);
            
            ipaddress = "1.1.1.1";
            
            result.put("CMRT17",manualTrigger(driver,supDriver,visDriver,"Operator","Supervisor1"));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"Supervisor1");
            
            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT1"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");
            
            result.put("CMRT1",chatMonitor(driver,supDriver,visDriver,"Admin1","Operator","Supervisor1",true,true));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"Supervisor1");
            
            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT2"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT2",chatMonitor(driver,supDriver,visDriver,"Admin1","Operator","Supervisor1",false,true));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"Supervisor1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT3"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT3",chatMonitor(driver,assoDriver,visDriver,"Admin1","Operator","Associate1",true,true));
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,"Associate1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT4"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT4",chatMonitor(driver,assoDriver,visDriver,"Admin1","Operator","Associate1",false,true));
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,"Associate1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT5"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT5",chatMonitor(driver,assoDriver,visDriver,"Admin1","IpAddress",ipaddress,true,true));
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,ipaddress1);
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,ipaddress2);
            // visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,ipaddress3);
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,ipaddress4);
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,ipaddress5);
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,ipaddress6);
            
            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT6"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT6",chatMonitor(driver,supDriver,visDriver,"Admin1","IpAddress",ipaddress,true,true));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,ipaddress1);
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,ipaddress2);
            // visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,ipaddress3);
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,ipaddress4);
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,ipaddress5);
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,ipaddress6);

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT7"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            t = new Long(System.currentTimeMillis());
            result.put("CMRT7",chatMonitor(driver,assoDriver,visDriver,"Admin1","VisitorEmail","vis@"+t.toString()+".com",true,true));
            visDriver = CommonFunctions.cleanUp(driver,assoDriver,visDriver,"vis@"+t.toString()+".com");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT8"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            t = new Long(System.currentTimeMillis());
            result.put("CMRT8",chatMonitor(driver,supDriver,visDriver,"Admin1","VisitorEmail","vis@"+t.toString()+".com",true,true));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"vis@"+t.toString()+".com");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT9"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT9",cantMonitor(supDriver,"Admin1"));

            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT10"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT10",chatMonitor(supDriver,assoDriver,visDriver,"Supervisor1","Operator","Associate1",true,true));
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,"Associate1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT11"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT11",chatMonitor(supDriver,assoDriver,visDriver,"Supervisor1","Operator","Associate1",false,true));
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,"Associate1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT12"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT12",chatMonitor(supDriver,assoDriver,visDriver,"Supervisor1","IpAddress",ipaddress,true,true));
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,ipaddress1);
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,ipaddress2);
            // visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,ipaddress3);
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,ipaddress4);
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,ipaddress5);
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,ipaddress6);

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT13"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT13",chatMonitor(supDriver,driver,visDriver,"Supervisor1","IpAddress",ipaddress,true,true));
            visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,ipaddress1);
            visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,ipaddress2);
            // visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,ipaddress3);
            visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,ipaddress4);
            visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,ipaddress5);
            visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,ipaddress6);

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT14"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            t = new Long(System.currentTimeMillis());
            result.put("CMRT14",chatMonitor(supDriver,assoDriver,visDriver,"Supervisor1","VisitorEmail","vis@"+t.toString()+".com",true,true));
            visDriver = CommonFunctions.cleanUp(supDriver,assoDriver,visDriver,"vis@"+t.toString()+".com");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT15"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            t = new Long(System.currentTimeMillis());
            result.put("CMRT15",chatMonitor(supDriver,driver,visDriver,"Supervisor1","VisitorEmail","vis@"+t.toString()+".com",true,true));
            visDriver = CommonFunctions.cleanUp(supDriver,driver,visDriver,"vis@"+t.toString()+".com");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT16"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT16",chatMonitor(driver,supDriver,visDriver,"Admin1","Operator","Supervisor1",true,false));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"Supervisor1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT18"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT18",transferMonitorChat(driver,supDriver,visDriver,"Operator","Supervisor1"));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"Supervisor1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT20"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT20",checkEndInConnected(supDriver,assoDriver,visDriver,"Operator","Associate1"));
            visDriver = CommonFunctions.cleanUp(supDriver,visDriver,"Associate1");

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT21"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT21",checkEndInConnected(driver,supDriver,visDriver,"Operator","Supervisor1"));
            visDriver = CommonFunctions.cleanUp(driver,visDriver,"Supervisor1");

            ComplexReportFactory.closeTest(etest);
            Thread.sleep(10000);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("CMRT19"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Monitor Real Time");

            result.put("CMRT19",monitorTriggeredChat(driver,supDriver,visDriver,"Admin1","Operator","Supervisor1"));
            visDriver = CommonFunctions.cleanUp(driver,supDriver,visDriver,"Supervisor1");
            accresDel(driver);

            ComplexReportFactory.closeTest(etest);
            
        }
        catch(Exception e)
        {
            result.put("CMRT1", false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            etest.log(Status.FATAL,"Error occurred while checking network connection in chat monitor rt module : "+e);
            TakeScreenshot.screenshot(driver,etest,"ChatMonitorRT","ChatMonitorShowStopper","CMRTError",e);
        }
        
        supDriver.quit();
        assoDriver.quit();
        visDriver.quit();
        
        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public static boolean chatMonitor(WebDriver driver1,WebDriver driver2,WebDriver visDriver,String user,String type,String value, boolean connected,boolean beforeVisit)
    {
        Long time = new Long(System.currentTimeMillis());
        time = time + 123;
        String vname = "Visitor"+time.toString();
        String vemail = "vis@"+time.toString()+".com";
        if(value.contains("@"))
            vemail = value;
        String vphone = "54321";
        String vques = "Ques"+time.toString();
        String usermessage = "User"+time.toString();
        String monitormessage = "Monitor"+time.toString();

        try
        {
            try
            {
                if(!beforeVisit)
                    CommonFunctions.openVis(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","OpenVisitorWindow","Error",e);
                return false;
            }
            
            if(type.equals("IpAddress"))
            {
                CommonFunctions.addChatMonitor(driver1,type,ipaddress1);
                CommonFunctions.addChatMonitor(driver1,type,ipaddress2);
                // CommonFunctions.addChatMonitor(driver1,type,ipaddress3);
                CommonFunctions.addChatMonitor(driver1,type,ipaddress4);
                CommonFunctions.addChatMonitor(driver1,type,ipaddress5);
                CommonFunctions.addChatMonitor(driver1,type,ipaddress6);
            }
            else
            {
                CommonFunctions.addChatMonitor(driver1,type,value);
            }
            etest.log(Status.INFO,"Value added in ChatMonitor:"+value);
            try
            {
                if(beforeVisit)
                    CommonFunctions.openVis(visDriver);
                CommonFunctions.initiateChatVis(visDriver,vname,vemail,vphone,vques);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","OpenVisitorWindow","Error",e);
                return false;
            }
            
            try
            {
                CommonFunctions.acceptChat(driver2);
                CommonFunctions.sentMessageUser(driver2,usermessage);
                ChatWindow.waitTillMessageInChat(driver2,usermessage);
                VisitorWindow.waitTillMessageInChat(visDriver,usermessage);
                TakeScreenshot.infoScreenshot(driver2,etest);
                TakeScreenshot.infoScreenshot(visDriver,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","AcceptChat","Error",e);
                return false;
            }

            if(connected)
            {
                driver1.navigate().refresh();
                Tab.clickVisitorsOnline(driver1);
                CommonWait.waitTillDisplayed(driver1,By.id("suppm_mycurrent"));
                CommonFunctions.clickConnected(driver1);
                CommonFunctions.selectChatInConnected(driver1,vname,vques).click();
                CommonFunctions.clickJoinInConnected(driver1);
            }
            else
            {
                CommonFunctions.clickMyChats(driver1);
                CommonFunctions.clickJoinInMyChats(driver1);
            }
            String checkName = CommonFunctions.getVisitorNameFromChat(driver1);
            String checkQues = CommonFunctions.getQuestionFromChat(driver1);
            
            if(!(checkName.contains(vname) && checkQues.contains(vques)))
            {
                etest.log(Status.FAIL,"MismatchContent--Actual:"+checkName+"--"+checkQues+"--Expected:"+vname+"--"+vques);
                TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckContent","Error");
                return false;
            }
        
            CommonFunctions.sentMessageUser(driver1,monitormessage);    
            
            Thread.sleep(1000);
            try
            {
                for(int i = 1;i<=10;i++)
                {
                    if(CommonFunctions.checkMessageInUserWindow(driver2,user,monitormessage))
                    {
                        break;
                    } 
                    Thread.sleep(1000);
                }
                if(!CommonFunctions.checkMessageInUserWindow(driver2,user,monitormessage))
                {
                    etest.log(Status.FAIL,"Message Not Seen In Agent Window - "+monitormessage);
                    TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","CheckContent","Error");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","CheckMessage","Error",e);
                return false;
            }

            try
            {
                if(!CommonFunctions.checkMessageInVisitorWindow(visDriver,user,monitormessage))
                {
                    etest.log(Status.FAIL,"Message Not Seen In Visitor Window - "+monitormessage);
                    TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","CheckContent","Error");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","CheckContent","Error",e);
                return false;
            }

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckRealTime","Error",e);
            return false;
        }
    }

    public static boolean manualTrigger(WebDriver driver1,WebDriver driver2,WebDriver visDriver,String type,String value)
    {
        Long time = new Long(System.currentTimeMillis());
        time = time + 123;
        String vname = "Visitor"+time.toString();
        String vemail = "vis@"+time.toString()+".com";
        if(value.contains("@"))
            vemail = value;
        String vphone = "54321";
        String vques = "Ques"+time.toString();
        String usermessage = "User"+time.toString();

        String visitorId = "";
        try
        {
            CommonFunctions.addChatMonitor(driver1,type,value);
            etest.log(Status.INFO,"Value:"+value);
            
            try
            {
                CommonFunctions.openVis(visDriver);

                visitorId = CommonFunctions.returnVisitorId(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","OpenVisitor","Error",e);
                return false;
            }
            
            try
            {
                CommonFunctions.initiateChatUser(driver2,visitorId,usermessage);
                VisitorWindow.waitTillMessageInChat(visDriver,usermessage);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","InitiateChatAgent","Error",e);
                return false;
            }

            try
            {
                Thread.sleep(2000);

                CommonFunctions.sentMessageVisitor(visDriver,vques);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","SentMessage","Error",e);
                return false;
            }

            CommonFunctions.clickMyChats(driver1);
            
            CommonFunctions.clickConnected(driver1);
            CommonFunctions.selectChatInConnected(driver1,"Visitor",vques).click();
            CommonFunctions.clickJoinInConnected(driver1);
        
            String checkName = CommonFunctions.getVisitorNameFromChat(driver1);
            String checkQues = CommonFunctions.getQuestionFromChat(driver1);
            
            if(checkName.contains("Visitor") && checkQues.contains(vques))
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            
            etest.log(Status.FAIL,"MismatchContent--Actual:"+checkName+"--"+checkQues+"--Expected:"+vname+"--"+vques);
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckContent","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","ManualTrigger","Error",e);
            return false;
        }
    }

    public static boolean transferMonitorChat(WebDriver driver1,WebDriver driver2,WebDriver visDriver,String type,String value)
    {
        Long time = new Long(System.currentTimeMillis());
        time = time + 123;
        String vname = "Visitor"+time.toString();
        String vemail = "vis@"+time.toString()+".com";
        if(value.contains("@"))
            vemail = value;
        String vphone = "54321";
        String vques = "Ques"+time.toString();
        String usermessage = "User"+time.toString();
        try
        {
            CommonFunctions.addChatMonitor(driver1,type,value);
            etest.log(Status.INFO,"Value:"+value);
            try
            {
                CommonFunctions.openVis(visDriver);
                CommonFunctions.initiateChatVis(visDriver,vname,vemail,vphone,vques);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","OpenVisitor","Error",e);
                return false;
            }
            
            try
            {
                CommonFunctions.acceptChat(driver2);
                CommonFunctions.sentMessageUser(driver2,usermessage);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","AcceptChat","Error",e);
                return false;
            }

            CommonFunctions.clickMyChats(driver1);

            CommonFunctions.clickConnected(driver1);
            CommonFunctions.selectChatInConnected(driver1,vname,vques).click();
            CommonFunctions.clickJoinInConnected(driver1);
            
            WebElement chatWin = ChatWindow.chatInMyChats(driver1);
        
            CommonUtil.elementfinder(driver1,CommonUtil.elementfinder(driver1,chatWin,"id","comptable"),"id","moreaction").click();

            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);
            
            WebElement trans = CommonUtil.elementfinder(driver1,CommonUtil.elementfinder(driver1,chatWin,"id","comptable"),"id","transfechat");

            wait.until(ExpectedConditions.visibilityOf(trans));

            trans.click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

            String header = CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"classname","lvd_popupsub"),"classname","lvd_popuptitle").getText();
            String content = CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"classname","lvd_popupsub"),"id","popupdesc").getText();
            

            if(header.contains("Sorry! Unable to transfer this chat") && content.contains("You only have the privilege to invite other operators to this chat session."))
            {
                etest.log(Status.PASS,"Checked");
                CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"classname","lvd_popupsub"),"id","dlgclose").click();
                return true;
            }
            
            etest.log(Status.FAIL,"MismatchContent--Actual:"+header+"--"+content+"--Expected:"+vname+"--"+vques);
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckContent","Error");
            CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"classname","lvd_popupsub"),"id","dlgclose").click();
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","TransferMonitoredChat","Error",e);
            return false;
        }
    }

    public static boolean checkEndInConnected(WebDriver driver1,WebDriver driver2,WebDriver visDriver,String type,String value)
    {
        Long time = new Long(System.currentTimeMillis());
        time = time + 123;
        String vname = "Visitor"+time.toString();
        String vemail = "vis@"+time.toString()+".com";
        if(value.contains("@"))
            vemail = value;
        String vphone = "54321";
        String vques = "Ques"+time.toString();
        String usermessage = "User"+time.toString();
        try
        {
            CommonFunctions.addChatMonitor(driver1,type,value);
            etest.log(Status.INFO,"Value:"+value);
            try
            {
                CommonFunctions.openVis(visDriver);
                CommonFunctions.initiateChatVis(visDriver,vname,vemail,vphone,vques);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","OpenVisitor","Error",e);
                return false;
            }
            
            try
            {
                CommonFunctions.acceptChat(driver2);
                CommonFunctions.sentMessageUser(driver2,usermessage);
                Functions.logout(driver2);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","AcceptChat","Error",e);
                return false;
            }

            com.zoho.livedesk.util.common.actions.Status.waitTillAgentStatusChange(driver1,value,"offline");
            
            Thread.sleep(2000);

            CommonFunctions.clickConnected(driver1);
            CommonFunctions.selectChatInConnected(driver1,vname,vques).click();
            CommonFunctions.clickEndInConnected(driver1);
        
            try
            {
                FluentWait wait = CommonUtil.waitreturner(visDriver,30,250);

                VisitorWindow.checkChatEndedInTheme(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","CheckChatEnded","Error",e);
                return false;
            }
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckEndButton","Error",e);
            return false;
        }
    }

    public static boolean cantMonitor(WebDriver driver,String value)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            //CommonFunctions.navigateToAutomation(driver);
            Tab.navToCMTab(driver);
            CommonFunctions.clickAddInChatMonitor(driver);

            final String typeid = "cmsupportrep";
            final String ipid = "cmsupportrepinput";
            
            CommonUtil.elfinder(driver,"xpath","//*[contains(.,'"+ResourceManager.getRealValue("settings_addchatmonitor")+"')]");
        
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(typeid)));
            
            CommonUtil.elfinder(driver,"id",typeid).click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id(ipid)).getAttribute("class").contains("disable_cntnr"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(ipid)));

            CommonUtil.elfinder(driver,"id",ipid).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cmsupportrepinput_ddown")));

            List<WebElement> users = CommonUtil.elfinder(driver,"id","cmsupportrepinput_ddown").findElements(By.tagName("li"));

            for(WebElement e : users)
            {
                if(e.getText().equals(value))
                {
                    etest.log(Status.FAIL,"Can Monitor "+value);
                    TakeScreenshot.screenshot(driver,etest,"ChatMonitorRT","AddChatMonitor","Error");
                    return false;
                }
            }
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"ChatMonitorRT","AddChatMonitor","Error",e);
            return false;
        }
    }

    public static boolean monitorTriggeredChat(WebDriver driver1,WebDriver driver2,WebDriver visDriver,String user,String type,String value)
    {
        Long time = new Long(System.currentTimeMillis());
        time = time + 123;
        String vname = "Visitor";
        String vques = "Ques"+time.toString();
        String usermessage = "User"+time.toString();
        String monitormessage = "Monitor"+time.toString();

        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver1,30,250);
            
            CommonFunctions.waitTillVisitorLeaves(driver1,visDriver);

            com.zoho.livedesk.client.Triggers.CommonFunctions.applyRule(driver1,etest,"Lands on my website","Visitor Type","is equal to","All",null,"Send chat invite","10 Seconds",null,null);

            // final WebElement page = CommonUtil.elfinder(driver1,"id","trouting");
            // List<WebElement> list = page.findElements(By.className("data_row"));
            // final int i = list.size();

            // if(list.size()==0)
            // {
            //     // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addsuggtitle")));
            //     // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addsuggtitle")));
            //     WebElement action=com.zoho.livedesk.util.common.CommonUtil.getElement(driver1,By.className("triggerstab")).findElement(By.className("add_btn"));
            //     action.click();
            //     //CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"id","addsuggtitle"),"id","addrule").click();
            // }
            // else
            // {
            //     wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));
            //     CommonUtil.elfinder(driver1,"id","autobtnadd").click();   
            // }

            // WebElement trigger = page.findElements(By.className("data_row")).get(0);
            // String id = trigger.getAttribute("ruleid");
            // CommonUtil.elementfinder(driver1,trigger,"id","triggerevent_"+id+"_div").click();
            // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("triggerevent_"+id)));
            // WebElement ulist = CommonUtil.elementfinder(driver1,trigger,"id","triggerevent_"+id);
            // for(WebElement e : ulist.findElements(By.tagName("li")))
            // {
            //     if(e.getText().contains("Lands on my website"))
            //     {
            //         e.click();
            //     }
            // }

            // Thread.sleep(500);

            // CommonUtil.elementfinder(driver1,trigger,"id","action_"+id).click();
            // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("action_"+id+"_ddown")));

            // WebElement ulist2 = CommonUtil.elementfinder(driver1,trigger,"id","action_"+id+"_ddown");
            // for(WebElement e : ulist2.findElements(By.tagName("li")))
            // {
            //     CommonUtil.JSScroll(driver1,e);
            //     if(e.getText().contains("Send chat invite"))
            //     {
            //         Thread.sleep(500);
            //         e.click();
            //     }
            // }

            // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("actionarea_"+id)));
            // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("actionarea_"+id)));
            
            // WebElement actionarea = CommonUtil.elementfinder(driver1,trigger,"id","actionarea_"+id);

            // for(WebElement e : actionarea.findElements(By.tagName("input")))
            // {
            //     if(e.getAttribute("key").contains("sendername"))
            //         e.sendKeys("Automation");
            // }

            // CommonUtil.elementfinder(driver1,actionarea,"id","message_"+id).sendKeys("Hello there ...");

            // for(WebElement e : actionarea.findElements(By.tagName("input")))
            // {
            //     if(e.getAttribute("key").contains("time"))
            //         e.sendKeys("10 Seconds");
            // }

            // Trigger.saveRule(driver1,etest,id);

            CommonFunctions.addChatMonitor(driver1,type,value);
            etest.log(Status.INFO,"Value:"+value);
            
            try
            {
                CommonFunctions.openVis(visDriver);
                Thread.sleep(15000);
                CommonFunctions.sentMessageVisitor(visDriver,vques);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","SentMessage","Error",e);
                return false;
            }

            try
            {
                CommonFunctions.acceptChat(driver2);
                CommonFunctions.sentMessageUser(driver2,usermessage);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","AcceptChat","Error",e);
                return false;
            }

            CommonFunctions.clickMyChats(driver1);
            
            CommonFunctions.clickConnected(driver1);
            CommonFunctions.selectChatInConnected(driver1,vname,vques).click();
            CommonFunctions.clickJoinInConnected(driver1);
            
            String checkName = CommonFunctions.getVisitorNameFromChat(driver1);
            String checkQues = CommonFunctions.getQuestionFromChat(driver1);
            
            if(!(checkName.contains(vname) && checkQues.contains(vques)))
            {
                etest.log(Status.FAIL,"MismatchContent--Actual:"+checkName+"--"+checkQues+"--Expected:"+vname+"--"+vques);
                TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckContent","Error");
                return false;
            }
        
            CommonFunctions.sentMessageUser(driver1,monitormessage);    
            
            Thread.sleep(1000);
            try
            {
                for(int ii = 1;ii <= 10;ii++)
                {
                    if(CommonFunctions.checkMessageInUserWindow(driver2,user,monitormessage))
                    {
                        break;
                    } 
                    Thread.sleep(1000);
                }

                if(!CommonFunctions.checkMessageInUserWindow(driver2,user,monitormessage))
                {
                    etest.log(Status.FAIL,"Message Not Seen In Agent Window - "+monitormessage);
                    TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","CheckContent","Error");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"ChatMonitorRT","SentMessage","Error",e);
                return false;
            }

            try
            {
                if(!VisitorWindow.checkAgentMessageInChatWindow(visDriver,user,monitormessage,3))
                {
                    etest.log(Status.FAIL,"Message Not Seen In Visitor Window - "+monitormessage);
                    TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","CheckContent","Error");
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"ChatMonitorRT","CheckMessage","Error",e);
                return false;
            }

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"ChatMonitorRT","TriggeredChat","Error",e);
            return false;
        }
    }

    public static void accresDel(WebDriver driver)
    {
        try
        {
            com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);
            // FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            // List<WebElement> list = driver.findElements(By.className("trules"));

            // for(int i=0;i<list.size();i++)
            // {
            //     CommonFunctions.clickIntelligentTriggers(driver);
                
            //     try
            //     {
            //         WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("trules"));
                    
            //         new Actions(driver).moveToElement(elmtch).perform();
                    
            //         elmtch.findElement(By.className("routeto")).findElement(By.className("sqico-delico")).click();
                    
            //         wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

            //         driver.findElement(By.id("okbtn")).click();
                    
            //     }
            //     catch(IndexOutOfBoundsException e)
            //     {
            //         System.out.println("Exception while deleting rules in intelligent triggers : "+e);
            //     }
            //     catch(Exception e)
            //     {
            //         System.out.println("Exception while deleting rules in intelligent triggers : "+e);
            //     }
            // }
        }
        catch(Exception e)
        {
            System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        }
    }
}
