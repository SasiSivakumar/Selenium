//$Id$
package com.zoho.livedesk.client;
import com.zoho.livedesk.util.Util;
import java.io.File;
import java.util.List;
import java.util.Arrays;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.net.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import java.util.Date;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.CommonWait;

public class CRMWebform {
	
    public static WebDriver visitordriver;
	
    public static ExtentTest etest;
	public static Hashtable result;
    public static Hashtable servicedown;
    static Hashtable hashtable=new Hashtable();

    public static int resultcount=0;
	public static String portalname="googleanalytics1";
    static Long time = new Long(System.currentTimeMillis());
    static String namewf, lnamewf, emailwf, companywf, visitorURL;
	public static boolean checkVisitorOnline(WebDriver driver,WebDriver visitordriver) throws Exception
	{
		try
		{
            String vid = null;
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            Tab.clickVisitorsOnline(driver);
			
            try
            {
                visitordriver.get(visitorURL);
                vid=VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Error checking visitor online",e);
                return false;
            }
			
            VisitorsOnline.waitTillVisitorPresent(driver,vid);
			
            if(driver.findElement(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]")).isDisplayed())
			{
				etest.log(Status.PASS,"Visitor online------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Visitor offline------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor not in online");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Error checking visitor online",e);
		}
		return checkResult(1);
	}
	public static boolean checkNameOnFormSubmit(WebDriver driver,WebDriver visitordriver) throws Exception
	{
		try
		{
            String vid = null;
            
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			Tab.clickVisitorsOnline(driver);
            
            vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            
			VisitorsOnline.waitTillVisitorPresent(driver,vid);
			getVisitor(driver,vid).click();
			wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle')]")));
			
            try
            {
                submitForm(visitordriver,namewf,lnamewf,emailwf,companywf,0);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Update visitor name, mail id and checking in tracking window",e);
                return false;
            }
			
            etest.log(Status.INFO,"Verifying visitor name");
			
            String name = getVisitorName(driver,vid);
            if(name.equals(namewf+" "+lnamewf))
			{
				etest.log(Status.PASS,"Visitor name updated in tracking window------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Visitor name not updated in tracking window------Test failed. Expected:"+namewf+"--Actual:"+name+"--");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","VVisitor name not updated in tracking window");
			}
			
            etest.log(Status.INFO,"Verifying mail id");
			
            String email = getVisitormail(driver,vid);
            if(email.equals(emailwf))
			{
				etest.log(Status.PASS,"Visitor email id updated in tracking window------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Visitor email id not updated in tracking window------Test failed. Expected:"+emailwf+"--Actual:"+email+"--");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor email id not updated in tracking window");
			}
			
            CommonUtil.elfinder(driver,"xpath","//div[@id='ldsettings']//div[@class='visitdetails']//textarea").click();
			CommonUtil.elfinder(driver,"xpath","//div[@id='ldsettings']//div[@class='visitdetails']//textarea").sendKeys(Keys.ESCAPE);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Update visitor name, mail id and checking in tracking window",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}
		return checkResult(2);
	}
	public static boolean checkCompanyName(WebDriver driver,WebDriver visitordriver) throws Exception
	{
		try
		{
			String vid=VisitorWindow.getVisitorId(visitordriver,portalname);
			
            Tab.clickVisitorsOnline(driver);
			
            visitordriver.get("https://www.google.com/");
            VisitorsOnline.waitTillVisitorLeaves(driver,vid);
            visitordriver.get(visitorURL);
            
            VisitorsOnline.waitTillVisitorPresent(driver,vid);
			getVisitor(driver,vid).click();
			checkPresenceOfLeadInfoAndOpen(driver);
            
            etest.log(Status.INFO,"Verifying company name");
			
            String comp = getCompanyName(driver);
            if(comp.equals(companywf))
			{
                TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Check Visitor company name in tracking window",0);
				etest.log(Status.PASS,"Visitor company name updated in tracking window------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Visitor company name not updated in tracking window------Test failed. Expected:"+companywf+"--Actual:"+comp+"--");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor company name not updated in tracking window");
			}
            
            etest.log(Status.INFO,"Verifying visitor name");
            
            String name = getVisitorName(driver,vid);
            if(name.equals(namewf+" "+lnamewf))
            {
                etest.log(Status.PASS,"Visitor name updated in tracking window------Test passed");
                resultcount++;
            }
            else
            {
                etest.log(Status.FAIL,"Visitor name not updated in tracking window------Test failed. Expected:"+namewf+"--Actual:"+name+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","VVisitor name not updated in tracking window");
            }
            
            etest.log(Status.INFO,"Verifying mail id");
            
            String email = getVisitormail(driver,vid);
            if(email.equals(emailwf))
            {
                etest.log(Status.PASS,"Visitor email id updated in tracking window------Test passed");
                resultcount++;
            }
            else
            {
                etest.log(Status.FAIL,"Visitor email id not updated in tracking window------Test failed. Expected:"+emailwf+"--Actual:"+email+"--");
                TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor email id not updated in tracking window");
            }
            
            CommonUtil.elfinder(driver,"xpath","//div[@id='ldsettings']//div[@class='visitdetails']//textarea").click();
            CommonUtil.elfinder(driver,"xpath","//div[@id='ldsettings']//div[@class='visitdetails']//textarea").sendKeys(Keys.ESCAPE);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor company name not updated in tracking window",e);	
		}
		return checkResult(3);
	}
	public static void submitForm(WebDriver visitordriver,String firstname,String lastname,String email,String comname) throws Exception
	{
        FluentWait wait = CommonUtil.waitreturner(visitordriver,30,200);
        
        WebElement company=CommonUtil.elfinder(visitordriver,"xpath","//div[@id='crmWebToEntityForm']//input[@name='Company']");
        wait.until(ExpectedConditions.visibilityOf(company));
        
        CommonUtil.getElement(visitordriver,By.cssSelector("[name='First Name']")).sendKeys(firstname);
        CommonUtil.getElement(visitordriver,By.cssSelector("[name='Last Name']")).sendKeys(lastname);
        CommonUtil.getElement(visitordriver,By.cssSelector("[name='Email']")).sendKeys(email);
        CommonUtil.getElement(visitordriver,By.cssSelector("[name='Company']")).sendKeys(comname);
        
        TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","SubmitForm",0);

        Thread.sleep(5000);
        
        CommonUtil.getElement(visitordriver,By.cssSelector("[value='Submit']")).click();
        
        Thread.sleep(5000);
    }
	public static void submitForm(WebDriver visitordriver,String firstname,String lastname,String email,String comname,int i) throws Exception
	{
        visitordriver.switchTo().defaultContent();
        
        if(CommonUtil.elfinder(visitordriver,"tagname","body").getAttribute("innerHTML").contains("crmWebToEntityForm"))
		{
			submitForm(visitordriver,firstname,lastname,email,comname);
		}
		else
		{
            visitordriver.switchTo().frame(0);
            submitForm(visitordriver,firstname,lastname,email,comname);
		}
	}


	public static String getVisitorName(WebDriver driver,String id) throws Exception
	{
		int size=driver.findElements(By.xpath("//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle') and contains(@id,'infoname_"+id+"')]")).size();
		WebElement visitorinfo=driver.findElements(By.xpath("//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle') and contains(@id,'infoname_"+id+"')]")).get(size-1);
		return visitorinfo.getAttribute("innerText");
	}
	public static String getVisitormail(WebDriver driver,String id) throws Exception
	{
		WebElement visitorinfo=CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle') and contains(@id,'infoemail_"+id+"')]//a");
		return visitorinfo.getAttribute("innerText");
	}
	public static void checkPresenceOfLeadInfoAndOpen(WebDriver driver) throws Exception
	{
		if(driver.findElements(By.id("crminfo")).size()!=0)
		{
			openLeadInfo(driver);
		}
	}
	public static void openLeadInfo(WebDriver driver) throws Exception
	{
		if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfo"),"id","crmldinfo").getCssValue("display").contains("none"))
		{
			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfo"),"className","cursr-point").click();
		}
	}
	public static String getCompanyName(WebDriver driver) throws Exception
	{
		return CommonUtil.getElement(driver,By.id("ldsettings"),By.id("ccinfodiv")).findElements(By.tagName("td")).get(1).getAttribute("innerText");
	}
	public static WebElement getVisitor(WebDriver driver, String vid) throws Exception
	{
		return driver.findElement(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]"));
	}
	public static boolean checkResult(int i) throws Exception
	{
		if(resultcount==i)
		{
			resultcount=0;
			return true;
		}
		else
		{
			resultcount=0;
			return false;
		}
	}
	public static Hashtable test(WebDriver driver) throws Exception
	{	
		try
		{
			//sleep is adde due to product slowness
			CommonUtil.sleep(10000);

			result=new Hashtable();
            servicedown=new Hashtable();
            
            time = new Long(System.currentTimeMillis());

			/*Not working for below data*/            
            // namewf = "FN"+time;
            // lnamewf = "LN"+time;
            // emailwf = "email@"+time+".com";
            // companywf = "Comp"+time;

			//since above data not working, as workaround we are using this data
            namewf = "John";
            lnamewf = "Williams";
            emailwf = "john123williams@"+"randommail"+".com";
            companywf = "Zoho";


            visitorURL = "https://crmwebformidc.blogspot.in/2017/11/crm-webform-idc.html";
            
            if(Util.setUptracking().equals("local") || Util.setUptracking().equals("lab"))
            {
                visitorURL = "https://crmwebformlocal.blogspot.in/2017/11/crm-webform-local.html";
            }
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRMWF1"));
            ComplexReportFactory.setValues(etest,"Automation","CRM Webform");
        	
            visitordriver=Functions.setUp();
        	result.put("CRMWF1",checkVisitorOnline(driver,visitordriver));
			
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRMWF2"));
            ComplexReportFactory.setValues(etest,"Automation","CRM Webform");

        	result.put("CRMWF2",checkNameOnFormSubmit(driver,visitordriver));
      
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRMWF3"));
            ComplexReportFactory.setValues(etest,"Automation","CRM Webform");

        	result.put("CRMWF3",checkCompanyName(driver,visitordriver));

        	visitordriver.quit();
			ComplexReportFactory.closeTest(etest);
        }
		catch(Exception e)
		{
            result.put("CRMWF1",false);
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Error- submitting form",e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            ComplexReportFactory.closeTest(etest);
		}
		
        hashtable.put("result", result);
        hashtable.put("servicedown",servicedown);
		return hashtable;
	}

}
