//$Id$
package com.zoho.livedesk.client.CannedResponse;

import java.util.List;
import java.util.Hashtable;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.CannedResponse.CannedResponseCommonFunctions;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;

import com.zoho.livedesk.server.KeyManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;



public class CannedResponseModule{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String portal_name=null;
	public static String embed_name=null;
	public static String canned_message = "";

    public static String widget_code="";

    public static String
    DEPT_DEFAULT = "All Departments",
    NO_CANNED_RESPONSE = "No shortcuts available",
	EMPTY_STATE_DESCRIPTION = "Looks like you haven't added any response template(s) to your repository yet! Create one right away.";
		
    public static By
    EM_TAG = By.tagName("em"),

    EMPTY_STATE = By.id("emptyslate"),
    FAQLISTVIEW = By.id("faqlistview"),
    
    LIST_CELL = By.className("list_cell"),
    LIST_HEADER = By.className("list_header"),
    SORT_ARROW = By.className("sqico-toparrow");

    public static String 
	canned1 = "canned_message1",
	canned2 = "canned_message2";

	public static Hashtable test(WebDriver driver1) throws Exception
	{
		try
		{
			if(embed_name==null)
			{
				embed_name=ExecuteStatements.getDefaultEmbedName(driver1);
			}

			widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver1,embed_name);
			portal_name=ExecuteStatements.getPortal(driver1);
			canned_message = CommonUtil.getUniqueMessage();

            TestResults = new Hashtable<String,Boolean>();
            
			etest=ComplexReportFactory.getTest("Check canned response");
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			initialCondition(driver1);

			checkCannedResponseTab(driver1);

            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Add canned response");
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			checkAddCannedResponse(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check canned response list");
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			checkCannedResponse(driver1);

            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCR10"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			checkEditCannedResponse(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCR15"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			checkCannedResponseInChat(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCR20"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			TestResults.put("DCR20", checkCannedResponseInTilesUI(driver1));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCR21"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			TestResults.put("DCR21", checkAllDynamicCannedResponse(driver1));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check sort icon");
            ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

            TestResults.put("DCR9", checkSortIcon(driver1));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Delete canned Response");
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Response");

			TestResults.put("DCR22", checkEmptyState(driver1));

            ComplexReportFactory.closeTest(etest);

        }
		catch(Exception e)
		{
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);

			finalResult.put("result",TestResults);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static void initialCondition(WebDriver driver)
	{
		try
		{
			sendCannedMessageToChat(driver,canned1,false);
			sendCannedMessageToChat(driver,canned2,true);

			Tab.clickCannedResponses(driver);
			// CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,CommonUtil.getUniqueMessage());
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","initialCondition","Exception",e);
		}
	}

	public static void sendCannedMessageToChat(WebDriver driver,String message,boolean toUseOtherCanned) throws Exception
	{
		String vstr=CommonUtil.getUniqueMessage();
		String visitor_name="V_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		String visitor_mail="v_"+vstr.substring(3,6)+vstr.substring(9)+"@salesiqautomation.com";

		try
		{
			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,message);
			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);
			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				CannedResponseCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Response","Visitor Failure","Error at Visitor Window",exp);
				return;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,"chat initiated from visitor(visitor name : '"+visitor_name+"' )");


			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);
			CannedMessagesCommonFunctions.clickCannedMessageFromListInChat(driver,message);
			Thread.sleep(1000);
			CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);

			if(toUseOtherCanned)
			{
				CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);
				CannedMessagesCommonFunctions.clickCannedMessageFromListInChat(driver,canned2);
				Thread.sleep(1000);
				CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);
			}
            ChatWindow.endAndCloseChat(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","sendCannedMessageToChat","Exception",e);
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}
	}

	public static void checkCannedResponseTab(WebDriver driver)
	{
		TestResults.put("DCR1",false);
		TestResults.put("DCR2",false);
		try
		{
			Tab.clickCannedResponses(driver);
			if(CannedResponseCommonFunctions.checkCannedResponseTab(driver,etest))
			{
				etest.log(Status.PASS,"Canned Response subtab was present under the Templates tab in Settings menu");
				TestResults.put("DCR1",true);
			}
			else
			{
				etest.log(Status.FAIL,"Canned Response subtab was not present under the Templates tab in settings menu");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseTab","Exception",e);
		}
		try
		{
			if(CannedResponseCommonFunctions.clickAddButtonInCannedResponse(driver))
			{
				etest.log(Status.PASS,"Add button was found in canned response tab");
				TestResults.put("DCR2",true);
			}
			else
			{
				etest.log(Status.FAIL,"Add button was not found in canned response tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseTab","Exception",e);
		}
	}

	public static void checkAddCannedResponse(WebDriver driver)
	{
		TestResults.put("DCR3",false);
		TestResults.put("DCR4",false);
		TestResults.put("DCR5",false);
		TestResults.put("DCR6",false);

		try
		{
			Tab.clickCannedResponses(driver);
			if(CannedResponseCommonFunctions.clickAddButtonInCannedResponse(driver))
			{
				etest.log(Status.PASS,"Add button in canned message tab was clicked");
				if(CannedResponseCommonFunctions.checkComposeMessage(driver))
				{
					etest.log(Status.PASS,"Compose message header was found in add new Canned Response tab");
					TestResults.put("DCR3",true);
				}
				else
				{
					etest.log(Status.FAIL,"Compose message was not found in add new Canned Response tab");
					TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				}
			}
			else
			{
				etest.log(Status.FAIL,"Add button was not found in canned response tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkAddCannedResponse","Exception",e);
		}
		try
		{
			Tab.clickCannedResponses(driver);
			if(CannedResponseCommonFunctions.clickAddButtonInCannedResponse(driver))
			{
				etest.log(Status.PASS,"Add button in canned response tab was clicked");
				TestResults.put("DCR4",CannedResponseCommonFunctions.checkDepartmentOption(driver,etest));
			}
			else
			{
				etest.log(Status.FAIL,"Add button was not found in canned response tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkAddCannedResponse","Exception",e);
		}
		try
		{
			Tab.clickCannedResponses(driver);
			if(CannedResponseCommonFunctions.clickAddButtonInCannedResponse(driver))
			{
				etest.log(Status.PASS,"Add button in canned response tab was clicked");
				CannedMessagesCommonFunctions.sendTextToComposeMessageTextArea(driver,"%");

				if(CannedMessagesCommonFunctions.checkDynamicTextSuggestionsDisplayed(driver))
				{
					etest.log(Status.PASS,"Dynamic text suggestions were displayed in canned response edit tab on clicking '%'");
					TestResults.put("DCR5",true);
				}
				else
				{
					etest.log(Status.FAIL,"Dynamic text suggestions were not displayed in canned response edit tab on clicking '%'");
					TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
					TestResults.put("DCR5",false);
				}
			}
			else
			{
				etest.log(Status.FAIL,"Add button was not found in canned response tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkAddCannedResponse","Exception",e);
		}
		try
		{
			Tab.clickCannedResponses(driver);
			if(CannedResponseCommonFunctions.clickAddButtonInCannedResponse(driver))
			{
				etest.log(Status.PASS,"Add button in canned response tab was clicked");
				TestResults.put("DCR6",CannedResponseCommonFunctions.checkAddButtonAndCancelButtonInAddCanned(driver,etest));
			}
			else
			{
				etest.log(Status.FAIL,"Add button was not found in canned response tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkAddCannedResponse","Exception",e);
		}
	}

	public static void checkCannedResponse(WebDriver driver)
	{
		int failcount = 0;
		TestResults.put("DCR7",false);
		TestResults.put("DCR8",false);
		try
		{
			Tab.clickCannedResponses(driver);
			if(!CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message))
			{
				failcount++;
			}
			if(CannedMessagesCommonFunctions.checkCannedMessagePresentInList(driver,canned_message))
			{
				etest.log(Status.PASS,"Added canned message ("+canned_message+") was present in the canned message list");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Added canned message ("+canned_message+") was not present in the canned message list");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponse","Exception",e);
		}
		TestResults.put("DCR7",returnResult(failcount));
		try
		{
			Tab.clickCannedResponses(driver);
			TestResults.put("DCR8",CannedResponseCommonFunctions.checkCannedResponseHeader(driver,etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponse","Exception",e);
		}
	}

	public static boolean checkSortIcon(WebDriver driver)
	{
		canned_message = CommonUtil.getUniqueMessage();
		int failcount = 0;
		try
		{
			Tab.clickCannedResponses(driver);

			CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message);
			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);

			CannedResponseCommonFunctions.checkInnerElements(driver,etest);

			List<WebElement> cannedResponseHeader = CommonUtil.getElement(driver,FAQLISTVIEW,LIST_HEADER).findElements(LIST_CELL);

			if(CannedResponseCommonFunctions.checkSortIcon(driver,etest))
			{
				etest.log(Status.PASS,"Sort icon present in the header in canned response list was verified");
			}
			else
			{
				failcount++;
			}

			CannedResponseCommonFunctions.deleteAllCannedMessages(driver);

			CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message);
			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);


			//check sort icon for single canned response

			cannedResponseHeader = CommonUtil.getElement(driver,FAQLISTVIEW,LIST_HEADER).findElements(LIST_CELL);
			WebElement header = cannedResponseHeader.get(1);
			WebElement sortIcon = CommonUtil.getElement(header,SORT_ARROW);
			if(!CannedResponseCommonFunctions.isDisplayed(sortIcon))
			{
				etest.log(Status.PASS,"Sort icon was not displayed in the '"+header.findElements(EM_TAG).get(0).getText()+"' header in canned response tab for single canned reponse");
			}
			else
			{
				etest.log(Status.FAIL,"Sort icon was displayed in the '"+header.findElements(EM_TAG).get(0).getText()+"' header in canned reponse tab for single canned reponse");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}

			header = cannedResponseHeader.get(2);
		
			sortIcon = CommonUtil.getElement(header,SORT_ARROW);
			if(!CannedResponseCommonFunctions.isDisplayed(sortIcon))
			{
				etest.log(Status.PASS,"Sort icon was not displayed in the '"+header.findElements(EM_TAG).get(0).getText()+"' header in canned response tab for single canned reponse");
			}
			else
			{
				etest.log(Status.FAIL,"Sort icon was displayed in the '"+header.findElements(EM_TAG).get(0).getText()+"' header in canned reponse tab for single canned reponse");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}

			//check sort icon for single canned response ends

			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponse","Exception",e);
			failcount++;
		}

		return returnResult(failcount);
	}
	public static void checkEditCannedResponse(WebDriver driver)
	{
		TestResults.put("DCR10",false);
		TestResults.put("DCR11",false);
		TestResults.put("DCR12",false);
		TestResults.put("DCR13",false);
		TestResults.put("DCR14",false);
		try
		{
			String new_canned_message = CommonUtil.getUniqueMessage();
			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.editCannedMessage(driver,canned_message,new_canned_message,etest);
			canned_message = new_canned_message;

			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);

			if(CannedMessagesCommonFunctions.checkCannedMessagePresentInList(driver,canned_message) && CannedResponseCommonFunctions.checkModified(driver,canned_message))
			{
				etest.log(Status.PASS,"Canned message ("+canned_message+") was edited and was found in the canned message list");
				TestResults.put("DCR10",true);
			}
			else
			{
				etest.log(Status.FAIL,"Edited canned message ("+canned_message+") was not present in the canned message list");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkEditCannedResponse","Exception",e);
		}
		try
		{
			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.deleteCannedMessage(driver,canned_message);

			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);

			if(!CannedMessagesCommonFunctions.checkCannedMessagePresentInList(driver,canned_message))
			{
				etest.log(Status.PASS,"Canned message ("+canned_message+") was deleted successfully in the canned message list");
				TestResults.put("DCR11",true);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted canned message ("+canned_message+") was found in the canned message list");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkEditCannedResponse","Exception",e);
		}
		try
		{
			int ownerdept_failcount = 0;
			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message);
			
			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);
			CommonWait.waitTillDisplayed(driver,FAQLISTVIEW);
			if(CannedResponseCommonFunctions.checkOwner(driver,"you"))
			{
				etest.log(Status.PASS,"The expected owner of newly created chat message was found in canned message details");
			}
			else
			{
				etest.log(Status.FAIL,"The expected owner of newly created chat message was not found in canned message details");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				ownerdept_failcount++;
			}
			CannedMessagesCommonFunctions.clickCannedMessagePresentInList(driver,canned_message);
			if(CannedResponseCommonFunctions.checkDepartment(driver,DEPT_DEFAULT))
			{
				etest.log(Status.PASS,"The expected department of newly created chat message was found in canned message details");
			}
			else
			{
				etest.log(Status.FAIL,"The expected department(expected department:'All Departments') of newly created chat message was not found in canned message details");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				ownerdept_failcount++;
			}
			TestResults.put("DCR12", CommonUtil.returnResult(ownerdept_failcount));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkEditCannedResponse","Exception",e);
		}
		try
		{
			Tab.clickCannedResponses(driver);
			TestResults.put("DCR13",CannedResponseCommonFunctions.checkNumberOfChatsCannedMessageUsed(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkEditCannedResponse","Exception",e);
		}
		try
		{
			Tab.clickCannedResponses(driver);
			TestResults.put("DCR14",CannedResponseCommonFunctions.checkLastUsedTimeOfCannedMessage(driver));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkEditCannedResponse","Exception",e);
		}
	}

	public static void checkCannedResponseInChat(WebDriver driver) throws Exception
	{
		int dcr15_failcount = 0,dcr16_failcount = 0,dcr17_failcount = 0,dcr19_failcount = 0;
		String vstr=CommonUtil.getUniqueMessage();
		String visitor_name="V_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		String visitor_mail="v_"+vstr.substring(3,6)+vstr.substring(9)+"@salesiqautomation.com";

		canned_message = CommonUtil.getUniqueMessage();
		TestResults.put("DCR15",false);
		TestResults.put("DCR16",false);
		TestResults.put("DCR17",false);
		TestResults.put("DCR18",false);
		TestResults.put("DCR19",false);
		try
		{
			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message);

			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				CannedResponseCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Response","Visitor Failure","Error at Visitor Window",exp);
				return;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,"chat initiated from visitor(visitor name : '"+visitor_name+"' )");

			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);

			if(CannedMessagesCommonFunctions.checkCannedMessageListInChat(driver))
			{
				etest.log(Status.PASS,"Canned messages were displayed after clicking canned messages button in chat");
			}
			else
			{
				etest.log(Status.FAIL,"Canned messages were NOT displayed after clicking canned messages button in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr15_failcount++;
			}

			if(CannedMessagesCommonFunctions.checkCannedMessageSearchDisplayed(driver))
			{
				etest.log(Status.PASS,"Canned messages search was displayed after clicking canned messages button in chat");
			}
			else
			{
				etest.log(Status.FAIL,"Canned messages search was NOT displayed after clicking canned messages button in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr15_failcount++;
			}
	        TestResults.put("DCR15",CommonUtil.returnResult(dcr15_failcount));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseInChat","Exception",e);
		}
		try
		{
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was displayed after pressing '#' key in chat");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was NOT displayed after pressing '#' key in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr16_failcount++;
			}

			CannedMessagesCommonFunctions.clickCannedMessageFromInput(driver,canned_message);
			etest.log(Status.INFO,"Canned message was clicked from the canned message suggestion list in chat");
			if(CannedMessagesCommonFunctions.checkMessagePresentInChatTextArea(driver,canned_message))
			{
				etest.log(Status.PASS,"Selected canned message was added to chat input");
			}
			else
			{
				etest.log(Status.FAIL,"Selected canned message was NOT added to chat input");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr16_failcount++;
			}

			CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);

			if(CannedMessagesCommonFunctions.isMessageAppendedInUserSide(driver,canned_message))
			{
				etest.log(Status.PASS,"Selected canned message was sent to visitor after pressing 'Enter' key.");
			}
			else
			{
				etest.log(Status.FAIL,"Selected canned message was NOT sent to visitor after pressing 'Enter' key.");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr16_failcount++;
			}

       		TestResults.put("DCR16",CommonUtil.returnResult(dcr16_failcount));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseInChat","Exception",e);
		}
		try
		{
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);
			CannedMessagesCommonFunctions.searchCannedMessage(driver,canned_message);

			if(CannedMessagesCommonFunctions.checkSearchIsHighlighted(driver,canned_message))
			{
				etest.log(Status.PASS,"Canned message("+canned_message+") was found in canned message search after it was searched");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message("+canned_message+") was NOT found in canned message search after it was searched");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr17_failcount++;
			}

			String sub_canned_message=canned_message.substring(0,canned_message.length()-3);
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);
			CannedMessagesCommonFunctions.searchCannedMessage(driver,sub_canned_message);

			if(CannedMessagesCommonFunctions.checkSearchIsHighlighted(driver,sub_canned_message))
			{
				etest.log(Status.PASS,"Canned message search result(search:"+sub_canned_message+") was highlighted in canned message search result after it was searched");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message search result(search:"+sub_canned_message+") was highlighted in canned message search result after it was searched");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr17_failcount++;
			}

       		TestResults.put("DCR17",CommonUtil.returnResult(dcr17_failcount));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseInChat","Exception",e);
		}
		try
		{
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,CommonUtil.getUniqueMessage()+"#");
			if(!CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was NOT displayed after pressing '#' key when chat input contained other text.");
				TestResults.put("DCR18",true);
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was displayed after pressing '#' key when chat input contained other text.");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseInChat","Exception",e);
		}
		try
		{
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was displayed after pressing '#' key in chat");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was NOT displayed after pressing '#' key in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr19_failcount++;
			}

			CannedMessagesCommonFunctions.sendEscapeKeyInChatTextArea(driver);

			if(!CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was NOT displayed after pressing 'Escape' key");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was displayed after pressing 'Escape' key");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				dcr19_failcount++;
			}
       		TestResults.put("DCR19",CommonUtil.returnResult(dcr19_failcount));

            ChatWindow.endAndCloseChat(driver);

            CannedResponseCommonFunctions.deleteCannedMessage(driver,canned_message);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseInChat","Exception",e);
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}
	}

	public static boolean checkCannedResponseInTilesUI(WebDriver driver)
	{
		int failcount = 0;
		WebDriver visitor_driver=null;
		String visitor_id="";
		canned_message=CommonUtil.getUniqueMessage();

		try
		{
			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message);

			CommonUtil.refreshPage(driver);

			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				visitor_id=VisitorWindow.getVisitorId(visitor_driver,portal_name);
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Response","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			Tab.clickVisitorsOnline(driver);

			CannedMessagesCommonFunctions.clickVisitorOnline(driver,visitor_id);
            
			CannedMessagesCommonFunctions.sendTextToTilesUIChat(driver,visitor_id,"#");
			if(CannedMessagesCommonFunctions.checkCannedMessageSuggestionDisplayedTilesUI(driver,visitor_id))
			{
				etest.log(Status.PASS,"Canned message suggestions were displayed after pressing '#' key in Tiles UI");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions were NOT displayed after pressing '#' key in Tiles UI");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}
			CannedMessagesCommonFunctions.clickCannedMessageFromSuggestionTilesUI(driver,visitor_id,canned_message);

			if(CannedMessagesCommonFunctions.checkTextInTilesUIChat(driver,visitor_id,canned_message))
			{
				etest.log(Status.PASS,"Canned message was added to message input after clicking it from canned message suggestion in Tiles UI");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message was NOT added to message input after clicking it from canned message suggestion in Tiles UI");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}

			CannedMessagesCommonFunctions.sendEnterKeyToTilesUIChat(driver,visitor_id);

			if(CannedMessagesCommonFunctions.checkMessageAppendInTilesUIChat(driver,visitor_id,canned_message))
			{
				etest.log(Status.PASS,"Canned message was sent to visitor after pressing enter key in chat of Tiles UI");
			}
			else
			{
				etest.log(Status.FAIL,"Canned message was NOT sent to visitor after pressing enter key in chat of Tiles UI");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}

			CannedMessagesCommonFunctions.sendEscapeKeyToTilesUIChat(driver,visitor_id);

			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.deleteCannedMessage(driver,canned_message);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkCannedResponseInTilesUI","Exception",e);
			failcount++;
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}

		return returnResult(failcount);
	}

	public static boolean checkAllDynamicCannedResponse(WebDriver driver) throws Exception
	{
		int failcount=0;
		Thread.sleep(147);
		String vstr=CommonUtil.getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello,What are the available discounts?";
		String pagetitle="";
		String url="";
		String browser="";
		String os="";
		String browser_version="";
		String UserName=ExecuteStatements.getUserName(driver);
		String UserMail=ExecuteStatements.getUserMail(driver);

		try
		{
			String canned_message_id=CommonUtil.getUniqueMessage();
			String canned_message=canned_message_id+"visitor.name:%visitor.name%attender.name:%attender.name%smart.timenow:%smart.timenow%visitor.department:%visitor.department%visitor.email:%visitor.email%attender.email:%attender.email%visitor.question:%visitor.question%visitor.id:%visitor.id%visitor.phone:%visitor.phone%visitor.country:%visitor.country%visitor.city:%visitor.city%web.embed.name:%web.embed.name%visitor.pagetitle:%visitor.pagetitle%visitor.ip:%visitor.ip%visitor.pageurl:%visitor.pageurl%visitor.referrer:%visitor.referrer%visitor.state:%visitor.state%visitor.timezone:%visitor.timezone%visitor.latitude:%visitor.latitude%visitor.longitude:%visitor.longitude%visitor.operating.system:%visitor.operating.system%visitor.browser:%visitor.browser%visitor.browser.version:%visitor.browser.version%visitor.platform:%visitor.platform%screen.resolution:%screen.resolution%search.engine:%search.engine%search.query:%search.query%";
			Tab.clickCannedResponses(driver);
			if(!CannedResponseCommonFunctions.addNewCannedResponse(driver,etest,canned_message))
			{
				failcount++;
			}

			CommonUtil.refreshPage(driver);

			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				CannedResponseCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				pagetitle=visitor_driver.getTitle().toString();
				url=visitor_driver.getCurrentUrl();

				Capabilities cap = ((RemoteWebDriver) visitor_driver).getCapabilities();
				browser = cap.getBrowserName().toLowerCase();
				os = cap.getPlatform().toString();
				browser_version = cap.getVersion().toString();
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Response","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,"A chat was initiated from visitor(visitor name : '"+visitor_name+"' )");

			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");
			CannedMessagesCommonFunctions.clickCannedMessageFromInput(driver,canned_message_id);
			etest.log(Status.INFO,"Canned message was clicked from the canned message suggestion list in chat");
			CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);
			CannedMessagesCommonFunctions.isMessageAppendedInUserSide(driver,canned_message_id);
		
			//Hashtable insertion begins
			String keys_array[]={"visitor.name","attender.name","visitor.email","visitor.question","attender.email","visitor.pagetitle","visitor.pageurl","visitor.browser.version"};
			Hashtable<Integer,String> keys=new Hashtable<Integer,String>();
			for(int i=0;i<keys_array.length;i++)
			{
				keys.put(i,keys_array[i]);
			}

			Hashtable<String,String> expected=new Hashtable<String,String>();
			// expected.put("",);

			expected.put("visitor.name",visitor_name);
			expected.put("visitor.email",visitor_mail);
			expected.put("visitor.question",visitor_question);
			expected.put("attender.name",UserName);
			expected.put("attender.email",UserMail);
			expected.put("visitor.pagetitle",pagetitle);
			expected.put("visitor.pageurl",url);
			expected.put("visitor.timezone","GMT+0530");
			expected.put("visitor.browser.version",browser_version);
			//seperate checks
			expected.put("visitor.browser",browser);
			expected.put("visitor.operating.system",os);
			//Hashtable insertion ends

			if(!CannedMessagesCommonFunctions.checkAllCannedMessages(driver,keys,expected,etest))
			{
				failcount++;
			}

			Tab.clickCannedResponses(driver);
			CannedResponseCommonFunctions.deleteCannedMessage(driver,canned_message);

            Tab.clickMyChats(driver);
            ChatWindow.endAndCloseChat(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkAllDynamicCannedResponse","Exception",e);
			failcount++;
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}

		return returnResult(failcount);
	}

	public static boolean checkEmptyState(WebDriver driver)
	{
		try
		{
			CannedResponseCommonFunctions.deleteAllCannedMessages(driver);
			etest.log(Status.INFO,"All canned responses were deleted");

			CommonUtil.refreshPage(driver);

			return isEmptyState(driver,etest);

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Response","checkEmptyState","Exception",e);
		}

		return false;
	}

	public static boolean isEmptyState(WebDriver driver,ExtentTest etest) throws Exception
	{
		Tab.clickCannedResponses(driver);
		WebElement emptyState = CommonUtil.getElement(driver,EMPTY_STATE);
		if(emptyState.isDisplayed())
		{
			etest.log(Status.PASS,"Empty State div element was found when no canned responses were present in canned response tab");
			if(CommonUtil.checkStringContainsAndLog(NO_CANNED_RESPONSE.toLowerCase(),emptyState.getText().toLowerCase(),"empty state text",etest))
			{
				if(CommonUtil.checkStringContainsAndLog(EMPTY_STATE_DESCRIPTION.toLowerCase(),emptyState.getText().toLowerCase(),"empty state description",etest))
				{
					return true;
				}
				else
				{
					TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				}
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		else
		{
			etest.log(Status.FAIL,"Empty state div element was not found when no canned responses were present in canned response tab");
			TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
		}

		return false;
	}

	public static boolean returnResult(int failcount)
	{
		if(failcount > 0)
		{
			return false;
		}
		return true;
	}
	
}
