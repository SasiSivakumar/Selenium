//$Id$
package com.zoho.livedesk.client.CannedResponse;

import java.util.List;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.common.base.Function;

import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;



public class CannedResponseCommonFunctions
{
	public static final int
	CHARACTER_COUNT = 2048;

	public static String 
	CANNED_RESPONSE_DESC = "Create response templates for the queries that are frequently asked by your website visitors. Operators of your firm can choose and utilize the apt template based on the context of an ongoing conversation right away from their chat windows.",
	NO_SHORTCUT = "No shortcuts available",
	CREATED_TEXT = "Created",
	MODIFIED_TEXT = "Modified",
	SUBMIT_BUTTON_TEXT = "Add",
	CANCEL_BUTTON_TEXT = "Cancel",
	COMPOSE_MESSAGE_TEXT = "Compose message",
	CHOOSE_DEPT_TEXT = "Choose a department",
	CANNED_RESPONSE_TAB = "Canned responses",
	CANNED_RESPONSE_HEADERS[] = {"Canned responses","Chat","Last used"};

	public static By
	EM_TAG = By.tagName("em"),
	LI_TAG = By.tagName("li"),
	SPAN_TAG = By.tagName("span"),

	SUBMIT_BUTTON = By.id("btnsubmit"),
	CANCEL_BUTTON = By.id("btncancel"),
	CANNED_DEPT = By.id("candeptslct_div"),
	RIGHT_CONTAINER = By.id("rightcontainer"),
	CANNED_DEPT_SELECT = By.id("candeptslct"),
	CANNED_RESPONSE_LIST = By.id("faqlistview"),
	CANNED_RESPONSE_COMPOSE_AREA = By.id("cmsg"),
	CANNED_RESPONSE_ADD_BUTTON = By.id("cmsgbtn"),
	CANNED_MESSAGE_COUNT = By.id("cmessagecount"),
	EMPTY_STATE_IN_CANNED_RESPONSE = By.id("emptyslate"),
	
	LIST_ROW = By.className("list-row"),
	LIST_CELL = By.className("list_cell"),
	LIST_HEADER = By.className("list_header"),
	DELETE_ICON = By.className("sqico-delico"),
	SORT_ICON = By.className("sqico-toparrow"),
	LIST_CELL_FCHILD = By.className("list_fchild"),
	CANNED_RESPONSE_WORD = By.className("cmn_wordbr"),
	AUTO_TAB_CONTAINER = By.className("autotabcontainer"),
	NO_CHATS_CANNED_USED = By.className("sqico-chatbubble");

	public static void initiateChatInClientSide(WebDriver driver,String name,String email_id,String message) throws Exception
	{
		VisitorWindow.clickChatButton(driver);
		VisitorWindow.initiateChatVisTheme(driver,name,email_id,null,message,CannedResponseModule.etest);
	}

	public static boolean checkCannedResponseTab(WebDriver driver,ExtentTest etest) throws Exception
	{
		WebElement autoTabContainer = CommonUtil.getElement(driver,RIGHT_CONTAINER,AUTO_TAB_CONTAINER);
		List<WebElement> autoTabContainerElements = autoTabContainer.findElements(LI_TAG);
		for(WebElement element : autoTabContainerElements)
		{
			if(element.getAttribute("data-tab").contains("shortcut") &&
			 	CommonUtil.checkStringContainsAndLog(CANNED_RESPONSE_TAB,element.getText(),"canned response tab",etest) &&
			 		CommonUtil.checkStringContainsAndLog(CANNED_RESPONSE_DESC,CommonUtil.getElement(driver,By.id("innersub")).getText(),"canned response description",etest))
			{
				return true;
			}
		}
		return false;
	}

	public static boolean clickAddButtonInCannedResponse(WebDriver driver) throws Exception
	{
		if(CommonUtil.getElement(driver,RIGHT_CONTAINER).getText().contains(NO_SHORTCUT))
		{
			WebElement emptyState = CommonUtil.getElement(driver,EMPTY_STATE_IN_CANNED_RESPONSE);
			WebElement addBtn = CommonUtil.getElementByAttributeValue(emptyState.findElements(SPAN_TAG),"documentclick","addCannedMessage");
			if(addBtn.isDisplayed())
			{
				CommonUtil.clickWebElement(driver,addBtn);
				CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,RIGHT_CONTAINER),COMPOSE_MESSAGE_TEXT);
				return true;
			}
		}
		else
		{
			if(CommonUtil.getElement(driver,CANNED_RESPONSE_ADD_BUTTON).isDisplayed())
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,CANNED_RESPONSE_ADD_BUTTON));
				CommonUtil.waitTillTextFound(driver,CommonUtil.getElement(driver,RIGHT_CONTAINER),COMPOSE_MESSAGE_TEXT);
				return true;
			}
		}
		return false;
	}

	public static boolean checkComposeMessage(WebDriver driver) throws Exception
	{
		if(CommonUtil.isTextFound(driver,CommonUtil.getElement(driver,RIGHT_CONTAINER),COMPOSE_MESSAGE_TEXT))
		{
			CommonWait.waitTillDisplayed(driver,CANNED_RESPONSE_COMPOSE_AREA);
			if(CommonUtil.getElement(driver,CANNED_RESPONSE_COMPOSE_AREA).isDisplayed())
			{
				return true;
			}
		}
		return false;
	}

	public static boolean checkDepartmentOption(WebDriver driver,ExtentTest etest) throws Exception
	{
		if(CommonUtil.isTextFound(driver,CommonUtil.getElement(driver,RIGHT_CONTAINER),CHOOSE_DEPT_TEXT))
		{
			etest.log(Status.PASS,"Choose a department header was found in add new canned response tab");
			CommonWait.waitTillDisplayed(driver,CANNED_DEPT_SELECT);
			if(CommonUtil.getElement(driver,CANNED_DEPT_SELECT).isDisplayed())
			{
				etest.log(Status.PASS,"Choose a department drop down box was found in add new canned response tab");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Choose a department drop down box was not found in add new canned response tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");	
			}
		}
		else
		{
			etest.log(Status.FAIL,"Choose a department header was not found in add new canned response tab");
			TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");	
		}
		return false;
	}

	public static boolean isDisplayed(WebElement ele)
	{
		try
		{
			return ele.isDisplayed();
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static boolean checkAddButtonAndCancelButtonInAddCanned(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount=0;
		if(CommonUtil.isTextFound(driver,CommonUtil.getElement(driver,SUBMIT_BUTTON),SUBMIT_BUTTON_TEXT))
		{
			etest.log(Status.PASS,"Add button was found in add new canned response tab");
		}
		else
		{
			etest.log(Status.FAIL,"Add button was NOT found in add new canned response tab");		
			TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");	
			failcount++;
		}

		if(CommonUtil.isTextFound(driver,CommonUtil.getElement(driver,CANCEL_BUTTON),CANCEL_BUTTON_TEXT))
		{
			etest.log(Status.PASS,"Cancel button was found in add new canned response tab");
		}
		else
		{
			etest.log(Status.FAIL,"Cancel button was NOT found in add new canned response tab");		
			TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");	
			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean addCannedMessage(WebDriver driver,String message,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		int len = CHARACTER_COUNT - message.length();
		CannedMessagesCommonFunctions.sendTextToComposeMessageTextArea(driver,message);
		CommonWait.waitTillDisplayed(driver,CANNED_MESSAGE_COUNT);
		if(isDisplayed(CommonUtil.getElement(driver,CANNED_MESSAGE_COUNT)) && CommonUtil.getElement(driver,CANNED_MESSAGE_COUNT).getText().contains(len+" characters left"))
		{
			etest.log(Status.PASS,"Character count was verified in edit canned response tab");
		}
		else
		{
			etest.log(Status.FAIL,"Character count was incorrect in edit canned response tab... Expected : '"+len+" characters left' ~~~~ Found: '"+CommonUtil.getElement(driver,CANNED_MESSAGE_COUNT).getText()+"' ");
			TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			failcount++;
		}
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,SUBMIT_BUTTON));
		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkCannedResponseHeader(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		int i = 0;
		List<WebElement> cannedResponseHeader = CommonUtil.getElement(driver,CANNED_RESPONSE_LIST,LIST_HEADER).findElements(LIST_CELL);
		for(WebElement header : cannedResponseHeader)
		{
			if(!CommonUtil.checkStringContainsAndLog(CANNED_RESPONSE_HEADERS[i],header.getText(),"header text",etest))
			{
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}
			i++;
		}
		return CommonUtil.returnResult(failcount);
	}


	public static boolean addNewCannedResponse(WebDriver driver,ExtentTest etest,String canned_message) throws Exception
	{
		int failcount = 0;
		if(clickAddButtonInCannedResponse(driver))
		{
			etest.log(Status.PASS,"Add button in canned response was clicked");
			if(!addCannedMessage(driver,canned_message,etest))
			{
				failcount++;
			}
			etest.log(Status.INFO,"New canned message ("+canned_message+") was created");
			CommonUtil.refreshPage(driver);
			Tab.clickCannedResponses(driver);
		}
		else
		{
			etest.log(Status.FAIL,"Add button was not found in canned response tab");
			TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean editCannedMessage(WebDriver driver,String canned_message,String new_canned_message,ExtentTest etest) throws Exception
	{
		CannedMessagesCommonFunctions.clickCannedMessagePresentInList(driver,canned_message);
		if(addCannedMessage(driver,new_canned_message,etest))
		{
			return true;
		}
		return false;
	}

	public static void deleteCannedMessage(WebDriver driver,String canned_message) throws Exception
	{
		Tab.clickCannedResponses(driver);
		List<WebElement> CannedResponseList = getCannedResponseList(driver);
		for(WebElement canned_response : CannedResponseList)
		{
			if(canned_response.getText().contains(canned_message))
			{
				// CommonUtil.scrollToBottomOfPage(driver);
				CommonUtil.mouseHover(driver,canned_response);
				CommonWait.waitTillDisplayed(CommonUtil.getElement(canned_response,DELETE_ICON));
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(canned_response,DELETE_ICON));
				break;
			}
		}
	}

	public static boolean checkModified(WebDriver driver,String canned_response) throws Exception
	{
		List<WebElement> cannedResponseList = getCannedResponseList(driver);
		for(WebElement canned_message : cannedResponseList)
		{
			if(canned_message.findElement(CANNED_RESPONSE_WORD).getText().contains(canned_response) && canned_message.findElement(LIST_CELL_FCHILD).getText().contains(MODIFIED_TEXT))
			{
				return true;
			}
		}
		return false;
	}

	public static boolean checkOwner(WebDriver driver,String expected_owner) throws Exception
	{
		List<WebElement> list_items = driver.findElements(LIST_CELL);

		for(WebElement ele : list_items)
		{
			if(ele.getText().contains(CREATED_TEXT) && ele.getText().contains(expected_owner))
			{
				return true;
			}
		}

		return false;
	}

	public static boolean checkDepartment(WebDriver driver,String expected_department) throws Exception
	{
		return CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(CANNED_DEPT)).getText().contains(expected_department);
	}

	public static void checkInnerElements(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		List<WebElement> cannedResponseList = getCannedResponseList(driver);
		for(WebElement canned_response : cannedResponseList)
		{
			if(CommonUtil.getElement(canned_response,NO_CHATS_CANNED_USED).getText().contains("0"))
			{
				if(canned_response.findElements(LIST_CELL).get(2).getText().contains("-"))
				{
					etest.log(Status.PASS,"The data present in the no of chats and last used for the canned response ("+CommonUtil.getElement(canned_response,CANNED_RESPONSE_WORD).getText()+") was verified to be correct");
				}
				else
				{
					etest.log(Status.FAIL,"The data present in the no of chats and last used for the canned response ("+CommonUtil.getElement(canned_response,CANNED_RESPONSE_WORD).getText()+") was incorrect.. Expected : '-' ~~~~ Found : '"+canned_response.findElements(LIST_CELL).get(2).getText()+"'");
					TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
					failcount++;
				}
			}
			else if(CommonUtil.getElement(canned_response,NO_CHATS_CANNED_USED).getText().contains("1") || CommonUtil.getElement(canned_response,NO_CHATS_CANNED_USED).getText().contains("2"))
			{
				if(canned_response.findElements(LIST_CELL).get(2).getText().contains("Today"))
				{
					etest.log(Status.PASS,"The data present in the no of chats and last used for the canned response ("+CommonUtil.getElement(canned_response,CANNED_RESPONSE_WORD).getText()+") was verified to be correct");
				}
				else
				{
					etest.log(Status.FAIL,"The data present in the no of chats and last used for the canned response ("+CommonUtil.getElement(canned_response,CANNED_RESPONSE_WORD).getText()+") was incorrect.. Expected: 'Today' ~~~~ Found : '"+canned_response.findElements(LIST_CELL).get(2).getText()+"'");
					TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"The data present in the no of chats for the canned response ("+CommonUtil.getElement(canned_response,CANNED_RESPONSE_WORD).getText()+") was incorrect.. Expected : '0' or '1' or '2' Found : '"+canned_response.findElements(LIST_CELL).get(1).getText()+"'");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
				failcount++;
			}
		}
	}

	public static List<WebElement> getCannedResponseList(WebDriver driver) throws Exception
	{
		return CommonUtil.getElement(driver,CANNED_RESPONSE_LIST).findElements(LIST_ROW);
	}

	public static boolean checkSortIcon(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0;
		for(int i = 1; i <= 2 ; i++)
		{
			List<WebElement> CannedResponseList = getCannedResponseList(driver);
			List<WebElement> cannedResponseHeader = CommonUtil.getElement(driver,CANNED_RESPONSE_LIST,LIST_HEADER).findElements(LIST_CELL);
			WebElement header = cannedResponseHeader.get(i);
			WebElement sortIcon = CommonUtil.getElement(header,SORT_ICON);
			if(sortIcon.isDisplayed())
			{
				etest.log(Status.PASS,"Sort icon was displayed in the '"+header.findElements(EM_TAG).get(0).getText()+"' header in canned response tab");
				CommonUtil.clickWebElement(driver,sortIcon);
				CannedResponseList = CommonUtil.getElement(driver,CANNED_RESPONSE_LIST).findElements(LIST_ROW);
				String firstCannedMessage = CommonUtil.getElement(CannedResponseList.get(0),CANNED_RESPONSE_WORD).getText();
				String firstCannedMessageUsedCount = CommonUtil.getElement(CannedResponseList.get(0),NO_CHATS_CANNED_USED).getText();
				String lastCannedMessageUsedCount = CommonUtil.getElement(CannedResponseList.get(CannedResponseList.size()-1),NO_CHATS_CANNED_USED).getText();
				String lastCannedMessageLastUsed = CommonUtil.getElement(CannedResponseList.get(CannedResponseList.size()-1)).findElements(LIST_CELL).get(2).getText();
				if((lastCannedMessageUsedCount.contains("0") && firstCannedMessage.contains(CannedResponseModule.canned1)) ||
					(firstCannedMessageUsedCount.contains("0") && lastCannedMessageLastUsed.contains("Today")))
				{
					etest.log(Status.PASS,"After clicking sort icon in the '"+header.findElements(EM_TAG).get(0).getText()+"' header the canned response list was sorted based on the number of chats the canned response was used");
				}
				else
				{
					etest.log(Status.FAIL,"After clicking sort icon in the '"+header.findElements(EM_TAG).get(0).getText()+"' header the canned response list was not sorted based on the number of chats the canned response was used");
					TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Sort icon was not displayed in the '"+header.findElements(EM_TAG).get(0).getText()+"' header in canned reponse tab");
				TakeScreenshot.screenshot(driver,etest,"Canned Response","Failure","Operator window screenshot");
			}
		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkNumberOfChatsCannedMessageUsed(WebDriver driver) throws Exception
	{
		List<WebElement> CannedResponseList = getCannedResponseList(driver);
		WebElement noOfChatsElement = CommonUtil.getElementByAttributeValue(CannedResponseList.get(0).findElements(LIST_CELL),"class","sqico-chatbubble");
		return noOfChatsElement.isDisplayed();
	}

	public static boolean checkLastUsedTimeOfCannedMessage(WebDriver driver) throws Exception
	{
		List<WebElement> CannedResponseList = getCannedResponseList(driver);
		WebElement lastUsedElement = CannedResponseList.get(0).findElements(LIST_CELL).get(2);
		return lastUsedElement.isDisplayed();
	}

	public static void deleteAllCannedMessages(WebDriver driver) throws Exception
	{
		Tab.clickCannedResponses(driver);
		List<WebElement> CannedResponseList = getCannedResponseList(driver);
		for(WebElement canned_response : CannedResponseList)
		{
			CommonUtil.mouseHover(driver,canned_response);
			CommonWait.waitTillDisplayed(CommonUtil.getElement(canned_response,DELETE_ICON));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(canned_response,DELETE_ICON));
			CommonUtil.sleep(1000);
		}
	}
	
}
