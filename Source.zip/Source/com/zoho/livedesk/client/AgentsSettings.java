//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.bots.BotsVisitorSide;

import com.zoho.livedesk.client.ChatTransfer.CommonFunctionsTC;
import com.zoho.livedesk.client.WMSBar.SalesIQWmsBarFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;

import com.google.common.base.Function;

public class AgentsSettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String firstname=null;
	private static String lastname=null;
	private static String knownas=null;
	private static String mobileno=null;
	private static String phoneno=null;
	private static String street=null;
	private static String city=null;
	private static String state=null;
	private static String pincode=null;
	private static String aboutme=null;
	private static String role=null;
	private static String timezone=null;
	private static String lcountry=null;
	private static String country=null;
	private static String date=null;
	private static String month=null;
	private static String year=null;

	private static String url = Util.siteNameout()+"/"+ConfManager.getScreenname();//ConfManager.getLoginURL();
	private static String requrl = "";
	public static ExtentTest etest;

	public static WebDriver
	supervisorDriver = null,
	associateDriver = null
	;

	public static final String
	MODULE_NAME = "OperatorSettings-Admin",
	OFFLINE_OPERATOR_EMAIL = "muzamil.y+offline_operator_t0@zohotest.com",
	AVAILABLE = "Available",
	BUSY = "Busy",
	AVAILABLE_CLASS = "ustatus_1",
	BUSY_CLASS = "ustatus_3",
	AVAILABLE_CLASS_IN_WMS = "sts-1",
	BUSY_CLASS_IN_WMS = "sts-3"
	;

	public static String
	admin_email = "renganathan.k+automation@zohocorp.com",
	supervisor_email = "renganathan.k+supervisor@zohocorp.com",
	associate_email = "renganathan.k+associate@zohocorp.com",
	supervisor_login = "supervisor",
	assocaite_login = "associate"
	;

	public static final By
	OPERATOR_LIST = By.id("ulisttable"),
	LIST_ROW = By.className("list-row"),
	TEXT_CLASS = By.className("txtelips"),
	LIST_CELL = By.className("list_cell"),
	USER_STATUS_DRP_DWN = By.id("user_status_drp_dwn"),
	USER_STATUS_DRP_DWN_DDOWN = By.id("user_status_drp_dwn_ddown"),
	UL_LIST = By.className("ullist"),
	LI_ELEMENTS = By.tagName("li"),
	USER_IMAGE = By.className("list_uimg"),
	MY_COLLEAGUES = By.id("mycolleagues"),
	MSG_DISP = By.id("msgdisp"),
	SUPREPMN = By.className("suprepmn")
	;

	public static void init()
	{
		firstname = "AutomationFN";
		lastname = "AutomationLN";
		knownas = "Automation";
		mobileno = "123456789";
		phoneno = "9788153433";
		street = "DLF IT park,Ramapuram";
		city = "Chennai";
		state = "TN";
		pincode = "612345";
		aboutme = "Described";
		role = "Associate";
		timezone = "( GMT 4:0 ) Armenia Summer Time(Asia/Yerevan)";
		lcountry = "United Kingdom";
		country = "United Kingdom";
		date = "6";
		month = "Dec";
		year = "1989";

		if(Util.isQuickAutomationSet())
		{
			admin_email = "muzamil.y+siqmain_admin_t0@zohotest.com";
			supervisor_email = "muzamil.y+siqmain_supervisor_t0@zohotest.com";
			associate_email = "muzamil.y+siqmain_associate_t0@zohotest.com";
			supervisor_login = "supervisor_quick";
			assocaite_login = "associate_quick";
		}
		else
		{
			admin_email = "renganathan.k+automation@zohocorp.com";
			supervisor_email = "renganathan.k+supervisor@zohocorp.com";
			associate_email = "renganathan.k+associate@zohocorp.com";
			supervisor_login = "supervisor";
			assocaite_login = "associate";
		}
	}

	public static Hashtable agentsConfig(WebDriver driver)
	{
		try
		{
            url = Util.siteNameout()+"/"+ExecuteStatements.getPortal(driver);

            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU1"));
			ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			requrl = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			//WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

			etest.log(Status.PASS,"Operators Settings Tab is present");

			result.put("SU1", true);

			ComplexReportFactory.closeTest(etest);
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU2"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU2", isPageAvail(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU3"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU3", addAgent(driver,"agentyp_admin","rajkumar.natarajan+105@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU4"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU4", addAgent(driver,"agentyp_super","rajkumar.natarajan+106@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU5"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU5", addAgent(driver,"agentyp_agent","rajkumar.natarajan+107@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU6"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU6", addAgentInvalidEmail(driver,"agentyp_admin", "12anand"));
            //result.put("SU7", addAgentWithNoDept(driver,"agentyp_admin", "rajkumar.natarajan+104@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU8"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU8", deactivateAgent(driver,"rajkumar.natarajan+106@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU9"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU9", activateAgent(driver,"rajkumar.natarajan+106@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU10"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU10", reinviteAgent(driver,"rajkumar.natarajan+106@zohocorp.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU11"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			init();
			result.put("SU11", false);

            editAgentProfile(driver,"rajkumar.natarajan+105@zohocorp.com");
			checkUserData(driver,"rajkumar.natarajan+105@zohocorp.com");
			editData(driver,"rajkumar.natarajan+105@zohocorp.com","nickname",knownas);
			checkUserName(driver,"rajkumar.natarajan+105@zohocorp.com");
			editData(driver,"rajkumar.natarajan+105@zohocorp.com","nickname","rajkumar.natarajan+105@zohocorp.com");

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SU12"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Admin");

			result.put("SU12",deleteAgent(driver,"rajkumar.natarajan+107@zohocorp.com"));

			ComplexReportFactory.closeTest(etest);


			init();
			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("SU27"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("SU27",checkOperatorStatusChangeOption(driver,admin_email,true,etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("SU28"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("SU28",checkOperatorStatusChangeOption(driver,supervisor_email,true,etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest(KeyManager.getRealValue("SU29"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("SU29",checkOperatorStatusChangeOption(driver,associate_email,true,etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Admin's Status Changed to Busy when changed from Admin");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,driver,admin_email,false,30,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Admin's Status Changed to Available when changed from Admin");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,driver,admin_email,true,34,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Operator status not changed to Busy when changed from Admin while operator was offline");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,driver,OFFLINE_OPERATOR_EMAIL,false,58,true,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Operator status not changed to Available when changed from Admin while operator was offline");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,driver,OFFLINE_OPERATOR_EMAIL,true,59,true,etest);
			ComplexReportFactory.closeTest(etest);

			supervisorDriver = Functions.setUp();
			Functions.login(supervisorDriver,supervisor_login);

			etest = ComplexReportFactory.getTest("Check Supervisor's Status Changed to Busy when changed from Admin");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,supervisorDriver,supervisor_email,false,38,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Supervisor's Status Changed to Available when changed from Admin");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,supervisorDriver,supervisor_email,true,43,etest);
			ComplexReportFactory.closeTest(etest);

			associateDriver = Functions.setUp();
			Functions.login(associateDriver,assocaite_login);

			etest = ComplexReportFactory.getTest("Check Associate's Status Changed to Busy when changed from Admin");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,associateDriver,associate_email,false,48,etest);
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Check Associate's Status Changed to Available when changed from Admin");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOperatorStatusChanged(driver,associateDriver,associate_email,true,53,etest);
			ComplexReportFactory.closeTest(etest);

			Functions.logout(supervisorDriver);
			Functions.logout(associateDriver);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorOperator(s)Tab");

            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckOperatorTab","ErrorOperator(s)Tab",e);

			result.put("SU1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorOperatorSettings(s)Tab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckOperatorSettingsTab","ErrorOperatorSettings(s)Tab",e);

			result.put("SU1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check Users Settings Page avail
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();


            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonuseradd")));


            Thread.sleep(1000);
			List<WebElement> texts = driver.findElements(By.className("innersubinfotxt"));

			if(((texts.get(0).getText()).equals(ResourceManager.getRealValue("settings_agents_desc1"))) && (((texts.get(1).getText()).contains(ResourceManager.getRealValue("settings_agents_desc2")))))
			{
		 		etest.log(Status.PASS,"OperatorSettings Desription Matched");

		 		return true;
			}
			TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","OperatorsSettingsDescription","MismatchOperatorSettingsDescription");
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","OperatorSettingsDescription","ErrorWhileCheckingOperatorSettingsPageAvailable",e);
            System.out.println("Exception while checking if Operators Settings page is available : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","OperatorsSettingsDescription","ErrorWhileCheckingOperatorSettingsPageAvailable",e);
            System.out.println("Exception while checking if Operators settings page is available : "+e);
			return false;
		}
		return false;
	}

	//Add user
	public static boolean addAgent(WebDriver driver, String type, String email)
	{
		try
		{
			boolean depts = false;//true;

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
			
            Tab.navToDeptTab(driver);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			WebElement deptelmt = driver.findElement(By.className("cmn_listviewer"));
			List<WebElement> deptelmts = deptelmt.findElements(By.className("list-row"));

			System.out.println("checkdepartmentcount:"+deptelmts.size());

			// if(deptelmts.size() == 1)
			// {
			// 	depts = false;
			// }

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonuseradd")));

			driver.findElement(By.id("buttonuseradd")).click();

            Thread.sleep(1000);
		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtuname")));

		 	driver.findElement(By.id("txtuname")).click();
		 	driver.findElement(By.id("txtuname")).sendKeys(email);
		 	Thread.sleep(1000);

		 	if(!("checked".equals(driver.findElement(By.id(type)).getAttribute("checked"))))
			{
			 	driver.findElement(By.id(type)).click();
			 	Thread.sleep(1000);
			}

			JavascriptExecutor je = (JavascriptExecutor)driver;
			je.executeScript("scroll(0,400)");
		 	Thread.sleep(500);

		 	if(!(type.equals("agentyp_admin")))
		 	{
		 		driver.findElement(By.id("chatmonitor")).click();
		 		Thread.sleep(1000);
		 	}

		 	if(depts)
			{
		 		WebElement dept = driver.findElement(By.id("unassodeptlist"));
			 	List<WebElement> divs = dept.findElements(By.tagName("div"));
			 	divs.get(1).click();
			 	Thread.sleep(1000);
			}

			je.executeScript("scroll(0,1000)");
		 	Thread.sleep(500);

		 	driver.findElement(By.id("useradd")).click();
		 	Tab.waitForLoading(driver,"addportaluser.do",etest);


            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

			WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(email))
				{
					etest.log(Status.PASS,"Operator-"+type+" is added");

		 			return true;
				}
			}
			TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddOperator"+type,"OperatorisNotAdded-"+type);
			return false;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddOperator"+type,"ErrorWhileAddingOperators-"+type,e);
			System.out.println("Exception while adding Operator in Operator settings page : "+e);
            return false;
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddOperator"+type,"ErrorWhileAddingOperators-"+type,e);
			System.out.println("Exception while adding Operator in Operator settings page : "+e);
            return false;
        }
	}

	//Add user with invalid email address
	private static boolean addAgentInvalidEmail(WebDriver driver, String type, String email)
	{
		try
		{
			boolean depts = true;

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
			
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

			WebElement deptelmt = driver.findElement(By.className("cmn_listviewer"));
			List<WebElement> deptelmts = deptelmt.findElements(By.className("list-row"));

			if(deptelmts.size() == 1)
			{
				depts = false;
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonuseradd")));

			driver.findElement(By.id("buttonuseradd")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtuname")));

		 	driver.findElement(By.id("txtuname")).click();
		 	driver.findElement(By.id("txtuname")).sendKeys(email);
		 	Thread.sleep(1000);

		 	driver.findElement(By.id(type)).click();
		 	Thread.sleep(1000);

			JavascriptExecutor je = (JavascriptExecutor)driver;
			je.executeScript("scroll(0,400)");
			Thread.sleep(500);

		 	if(!(type.equals("agentyp_admin")))
		 	{
		 		driver.findElement(By.id("chatmonitor")).click();
		 		Thread.sleep(1000);
		 	}

		 	if(depts)
			{
		 		WebElement dept = driver.findElement(By.id("unassodeptlist"));
			 	List<WebElement> divs = dept.findElements(By.tagName("div"));
			 	divs.get(1).click();
			 	Thread.sleep(1000);
			}

			je.executeScript("scroll(0,1000)");
			Thread.sleep(500);

		 	driver.findElement(By.id("useradd")).click();

            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("frmadduser")));
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.className("err_em")).getAttribute("style")).contains("none")))
                    {
                        return true;
                    }
                    return false;
                }
            });

		 	if((driver.findElement(By.className("err_em")).getText()).contains(ResourceManager.getRealValue("settings_entervalidemail")))
		 	{
		 		etest.log(Status.PASS,"Add Agent with Invalid EmailId is verified");

		 		return true;
		 	}
		 	TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddAgentInvalidEmail","MismatchInvalidEmailAlertContent");
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddAgentInvalidEmail","ErrorWhileAddingOperator-InvalidEmail",e);
            System.out.println("Exception while adding Operator using invalid EmailID in OperatorSettings page : "+e);
            return false;
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddAgentInvalidEmail","ErrorWhileAddingOperator-InvalidEmail",e);
            System.out.println("Exception while adding Operator using invalid EmailID in Operators settings page : "+e);
            return false;
        }
		return false;
	}

	//Add user with no department
    private static boolean addAgentWithNoDept(WebDriver driver, String type, String email)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonuseradd")));

            driver.findElement(By.id("buttonuseradd")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtuname")));

            driver.findElement(By.id("txtuname")).click();
            driver.findElement(By.id("txtuname")).sendKeys(email);
            Thread.sleep(1000);

            driver.findElement(By.id(type)).click();
            Thread.sleep(1000);

            JavascriptExecutor je = (JavascriptExecutor)driver;
            je.executeScript("scroll(0,400)");
            Thread.sleep(500);

            if(!(type.equals("agentyp_admin")))
            {
                driver.findElement(By.id("chatmonitor")).click();
                Thread.sleep(1000);
            }

            je.executeScript("scroll(0,1000)");
            Thread.sleep(500);

            driver.findElement(By.id("useradd")).click();
            if((driver.findElement(By.id("unassodept")).getText()).contains(ResourceManager.getRealValue("settings_choosedepartment")))
            {
                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddAgentWithNoDept","MismatchAlert");
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddAgentWithNoDept","ErrorWhileAddingAgentWithNoDept",e);
            System.out.println("Exception while adding Agent without choosing department in Operator settings page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AddAgentWithNoDept","ErrorWhileAddingAgentWithNoDept",e);
            System.out.println("Exception while adding Agent without choosing department in Operator settings page : "+e);
            return false;
        }
        return false;
    }

	//Delete user
	public static boolean deleteAgent(WebDriver driver, String agent)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

			WebElement table = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = table.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
					WebElement elmt2 = elmts1.get(3);

                    try
					{
						elmt2.findElement(By.tagName("em")).click();
					}
					catch(Exception e)
					{
						JavascriptExecutor je = (JavascriptExecutor)driver;
						je.executeScript("scroll(0,1000)");
						Thread.sleep(1000);
						elmt2.findElement(By.tagName("em")).click();
					}

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

					driver.findElement(By.id("okbtn")).click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Operator deleted successfully","delportaluser.do",etest);

					Thread.sleep(1000);
                    etest.log(Status.PASS,"Operator Deleted successfully");
					return true;
				}
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","DeleteAgent","ErrorWhileDeletingAgent",e);
            System.out.println("Exception while deleting agent in Operators settings settings page: "+e);
            return false;
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","DeleteAgent","ErrorWhileDeletingAgent",e);
            System.out.println("Exception while deleting agent in Operators settings page: "+e);
            return false;
        }
		return false;
	}

	//Re-invite user
	private static boolean reinviteAgent(WebDriver driver, String agent)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

			WebElement table = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = table.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
					WebElement elmt2 = elmts1.get(3);

					elmt2.findElement(By.tagName("span")).click();

					Tab.waitForLoadingSuccessWithBanner(driver,"Re-invitation sent successfully","reinviteusr.do",etest);
                    etest.log(Status.PASS,"Reinvite Agent is verified");
					Thread.sleep(1000);
					return true;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","ReinviteAgent","ErrorWhileCheckingReInviteInOperatorSettingsPage",e);
            System.out.println("Exception while checking agent re-invite in Operator settings page : "+e);
            return false;
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","ReinviteAgent","ErrorWhileCheckingReInviteInOperatorSettingPsage",e);
            System.out.println("Exception while checking agent re-invite in Operator settings page : "+e);
            return false;
        }
		return false;
	}
	//Deactivate user
    private static boolean deactivateAgent(WebDriver driver, String agent)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

            WebElement elmt1 = driver.findElement(By.id("ulisttable"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
            	CommonUtil.inViewPortSafe(driver,elmt);
                List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
                if((userdetails.get(2).getText()).equals(agent))
                {
                    elmt.findElement(By.className("txtelips")).click();
                    break;
                }
            }

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setactive")));
            WebElement deactivate = driver.findElement(By.id("setactive"));

            if((deactivate.findElement(By.tagName("span")).getText()).contains(ResourceManager.getRealValue("settings_useractivate")))
            {
                driver.findElement(By.id("setactive")).click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Operator status updated","upuserstatus.do",etest);
            }

            if((driver.findElement(By.id("setactive")).findElement(By.tagName("span")).getText()).contains(ResourceManager.getRealValue("settings_userdeactivate")))
            {
                driver.findElement(By.id("setactive")).click();
                
                Tab.waitForLoadingSuccessWithBanner(driver,"Operator status updated","upuserstatus.do",etest);

                if((driver.findElement(By.id("setactive")).findElement(By.tagName("span")).getText()).contains(ResourceManager.getRealValue("settings_useractivate")))
                {
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

                    elmt1 = driver.findElement(By.id("ulisttable"));
                    elmts = elmt1.findElements(By.className("list-row"));

                    for(WebElement elmt:elmts)
                    {
                    	CommonUtil.inViewPortSafe(driver,elmt);
                        List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
                        if((userdetails.get(2).getText()).equals(agent))
                        {
                            if((elmt.getAttribute("class")).contains("list_disable"))
                            {
                                etest.log(Status.PASS,"Operator is Disabled");

                                return true;
                            }
                            else{
                            	TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","DisableOperator","OperatorIsNotDisabled");
                            }
                        }
                    }
                }
                else{
                	TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","DisableOperator","MismatchActivateButtonContent");
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","DisableOperator","ErrorWhileCheckingOperatorDeactivate",e);
            System.out.println("Exception while checking Operator deactivate in Operators settings page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","DisableOperator","ErrorWhileCheckingOperatorDeactivate",e);
            System.out.println("Exception while checking Operator deactivate in Operators settings page : "+e);
            return false;
        }
        return false;
    }

    //Activate user
    public static boolean activateAgent(WebDriver driver, String agent)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

            WebElement elmt1 = driver.findElement(By.id("ulisttable"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
            	CommonUtil.inViewPortSafe(driver,elmt);
                List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
                if((userdetails.get(2).getText()).equals(agent))
                {
                    elmt.findElement(By.className("txtelips")).click();
                    break;
                }
            }

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setactive")));

            WebElement deactivate = driver.findElement(By.id("setactive"));
            if((deactivate.findElement(By.tagName("span")).getText()).contains(ResourceManager.getRealValue("settings_userdeactivate")))
            {
                driver.findElement(By.id("setactive")).click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Operator status updated","upuserstatus.do",etest);
            }

            if((driver.findElement(By.id("setactive")).findElement(By.tagName("span")).getText()).contains(ResourceManager.getRealValue("settings_useractivate")))
            {
                driver.findElement(By.id("setactive")).click();
                
                Tab.waitForLoadingSuccessWithBanner(driver,"Operator status updated","upuserstatus.do",etest);

                if((driver.findElement(By.id("setactive")).findElement(By.tagName("span")).getText()).contains(ResourceManager.getRealValue("settings_userdeactivate")))
                {
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));

                    driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

                    elmt1 = driver.findElement(By.id("ulisttable"));
                    elmts = elmt1.findElements(By.className("list-row"));

                    for(WebElement elmt:elmts)
                    {
                    	CommonUtil.inViewPortSafe(driver,elmt);
                        List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
                        if((userdetails.get(2).getText()).equals(agent))
                        {
                            if((elmt.getAttribute("class")).contains("list_disable"))
                            {
                                return false;
                            }
                        }
                    }
                }
                else{
                	TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EnableOperator","MismatchDectivateButtonContent");
                }
            }
            etest.log(Status.PASS,"Enable Operator is verified");
            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EnableOperator","ErrorWhileCheckingOperatorActivate",e);
            System.out.println("Exception while checking Operator deactivate in Operators settings page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EnableOperator","ErrorWhileCheckingOperatorActivate",e);
            System.out.println("Exception while checking Operator deactivate in Operators settings page : "+e);
            return false;
        }
    }

	//Edit user data
	public static void editAgentProfile(WebDriver driver,String agent)
	{
		try
		{
			JavascriptExecutor je = (JavascriptExecutor)driver;
			etest.log(Status.PASS,"Edit Operator Profile Page is present");
			result.put("SU11", true);
			editData(driver,agent,"firstname",firstname);
			editData(driver,agent,"lastname",lastname);
			editData(driver,agent,"mobile",mobileno);
			editData(driver,agent,"phone",phoneno);
			editData(driver,agent,"street",street);
			editData(driver,agent,"city",city);
			editData(driver,agent,"state",state);
			editData(driver,agent,"pincode",pincode);
			editData(driver,agent,"aboutme",aboutme);
			editDateConfig(driver,agent,"datedropdown_div","datedropdown_ddown",date,"monthdropdown_div","monthdropdown_ddown",month,"yeardropdown_div","yeardropdown_ddown",year);
			editDDConfig(driver,agent,"roledropdown_div","roledropdown_ddown",role);
			editDDConfig(driver,agent,"tzonedropdown_div","tzonedropdown_ddown",timezone);
			editDDConfig(driver,agent,"countrydropdown_div","countrydropdown_ddown",lcountry);
			editDDConfig(driver,agent,"abtcountrydropdown_div","abtcountrydropdown_ddown",country);
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while editing Operator profile in Operators settings page : "+e);
        }
		catch(Exception e)
		{
            System.out.println("Exception while editing Operator profile in Operators settings page : "+e);
        }
	}
	//Edit Data
	public static void editData(WebDriver driver, String agent, String id, String value)
	{
		editData(driver,url,agent,id,value,etest);
	}
	public static void editData(WebDriver driver,String url, String agent, String id, String value,ExtentTest etest)
	{
		try
		{
            System.out.println("CHECKING --------"+id);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

			String userid="";

			WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					userid = elmt.getAttribute("id");
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");
                    mouseOver(driver,elmt);
                    CommonSikuli.findInWholePage(driver,"Operatoredit.png","UI305",etest);
					elmt.findElement(By.className("txtelips")).click();
					break;
				}
			}

            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

			driver.get(url+"/index#setting/user/edit/"+userid);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("firstname")));

			JavascriptExecutor je = (JavascriptExecutor)driver;
			try
			{
		 		driver.findElement(By.id(id)).click();
			}
			catch(Exception e)
			{
				je.executeScript("scroll(0,550)");
				Thread.sleep(1000);
		 		driver.findElement(By.id(id)).click();
			}
		 	driver.findElement(By.id(id)).clear();
		 	driver.findElement(By.id(id)).sendKeys(value);
			je.executeScript("scroll(0,2000)");
			Thread.sleep(500);
		 	driver.findElement(By.id("useradd")).click();
            
            Tab.waitForLoading(driver,"updateusrdetails.do",etest);

            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
    }
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EditingDataInOperatorProfile-"+value,"ErrorWhileEditingDataInOperatorProfile-"+value,e);

            System.out.println("Exception while editing data in profile in Operators settings : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EditingDataInOperatorProfile-"+value,"ErrorWhileEditingDataInOperatorProfile-"+value,e);

            System.out.println("Exception while editing data in profile in Operators settings : "+e);
        }
	}

	public static void editDDConfig(WebDriver driver, String agent, String id, String dname, String value)
	{
		editDDConfig(driver,url,agent,id,dname,value,etest);
	}
	public static void editDDConfig(WebDriver driver, String url, String agent, String id, String dname, String value,ExtentTest etest)
	{
		try
		{
            System.out.println("CHECKING --------"+id);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

            String userid = "";
			WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					userid = elmt.getAttribute("id");
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");
					elmt.findElement(By.className("txtelips")).click();
					break;
				}
			}

            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

			driver.get(url+"/index#setting/user/edit/"+userid);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("firstname")));

		 	try
			{
				driver.findElement(By.id(id)).click();
			}
			catch(Exception e)
			{
				JavascriptExecutor je = (JavascriptExecutor)driver;
				je.executeScript("scroll(0,500)");
			 	Thread.sleep(1000);
				driver.findElement(By.id(id)).click();
			}
			Thread.sleep(500);

			WebElement elmt = driver.findElement(By.id(dname));

			List<WebElement> lis=elmt.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			   {
				WebElement element = lis.get(i);
				WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(value))
				{
					element.click();
					break;
				}
			   }
			JavascriptExecutor je = (JavascriptExecutor)driver;
			je.executeScript("scroll(0,2000)");
			Thread.sleep(500);

			driver.findElement(By.id("useradd")).click();
		 	Tab.waitForLoading(driver,"updateusrdetails.do",etest);

            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
    }
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EditingDataInOperatorProfile-"+value,"ErrorWhileEditingDataInOperatorProfile-"+value,e);

            System.out.println("Exception while editing dropdown data in profile in Operato settings : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","EditingDataInOperatorProfile-"+value,"ErrorWhileEditingDataInOperatorProfile-"+value,e);

            System.out.println("Exception while editing dropdown data in profile in Operators settings : "+e);
        }
	}

	private static void editDateConfig(WebDriver driver, String agent, String did, String ddown, String dvalue, String mid, String mdown, String mvalue, String yid, String ydown, String yvalue)
	{
		try
		{
            System.out.println("CHECKING --------date");

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

            String userid="";
			WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					userid = elmt.getAttribute("id");
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");
					elmt.findElement(By.className("txtelips")).click();
					break;
				}
			}

            Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

			driver.get(url+"/index#setting/user/edit/"+userid);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("firstname")));

			driver.findElement(By.id(did)).click();
			Thread.sleep(500);

			WebElement elmt = driver.findElement(By.id(ddown));

			List<WebElement> lis=elmt.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
            {
                WebElement element = lis.get(i);
                WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(dvalue))
				{
					element.click();
					break;
				}
            }

			driver.findElement(By.id(mid)).click();
			Thread.sleep(500);

			elmt = driver.findElement(By.id(mdown));
			lis=elmt.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
            {
				WebElement element = lis.get(i);
				WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(mvalue))
				{
					element.click();
					break;
				}
            }

			driver.findElement(By.id(yid)).click();
			Thread.sleep(500);

			elmt = driver.findElement(By.id(ydown));

			lis=elmt.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
            {
				WebElement element = lis.get(i);
				WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(yvalue))
				{
					element.click();
					break;
				}
            }
            JavascriptExecutor je = (JavascriptExecutor)driver;
			je.executeScript("scroll(0,2000)");
			Thread.sleep(500);

			driver.findElement(By.id("useradd")).click();
		 	Tab.waitForLoading(driver,"updateusrdetails.do",etest);

            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
    }
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AgentsSettings-Admin","ErrorWhileEditingDataInOperatorProfile-Date",e);

            System.out.println("Exception while editing date data in profile in Operators settings : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","AgentsSettings-Admin","ErrorWhileEditingDataInOperatorProfile-Date",e);

            System.out.println("Exception while editing date data in profile in Operators settings : "+e);
        }
	}
	//Check edited data
	private static void checkUserData(WebDriver driver, String agent)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

            String href = driver.findElement(By.linkText(agent)).getAttribute("href");
			String userid = "";

            WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					userid = elmt.getAttribute("id");
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");
					elmt.findElement(By.className("txtelips")).click();
					break;
				}
			}

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

			WebElement userdetails = driver.findElement(By.id("userdetails"));

			String details = userdetails.getText();
			result.put("SU13", checkEditData(driver, firstname, userid, "firstname"));
			result.put("SU14", checkEditData(driver, lastname, userid, "lastname"));
            result.put("SU15", false);
			result.put("SU16", false);
			result.put("SU17", false);
			result.put("SU18", false);
			result.put("SU19", false);
			result.put("SU20", false);
			result.put("SU21", false);
			result.put("SU22", false);
			result.put("SU23", false);
			result.put("SU24", false);
			result.put("SU25", false);

			if(details.contains(mobileno))
			{
				result.put("SU15", checkEditData(driver, mobileno, userid, "mobile"));
			}
			if(details.contains(phoneno))
			{
				result.put("SU16", checkEditData(driver, phoneno, userid, "phone"));
			}
			if(details.contains(street))
			{
				result.put("SU17", checkEditData(driver, street, userid, "street"));
			}
			if(details.contains(city))
			{
				result.put("SU18", checkEditData(driver, city, userid, "city"));
			}
			if(details.contains(state))
			{
				result.put("SU19", checkEditData(driver, state, userid, "state"));
			}
			if(details.contains(country))
			{
				result.put("SU20", checkDDEditData(driver, country, userid, "countrydropdown"));
			}
			if(details.contains(pincode))
			{
				result.put("SU21", checkEditData(driver, pincode, userid, "pincode"));
			}
			if(details.contains(aboutme))
			{
				result.put("SU22", checkEditData(driver, aboutme, userid, "aboutme"));
			}
			if(details.contains(role))
			{
				result.put("SU23", checkDDEditData(driver, role, userid, "roledropdown"));
			}
			if(details.contains(timezone))
			{
				result.put("SU24", checkDDEditData(driver, timezone, userid, "tzonedropdown"));
			}
			if(details.contains(getAgentDOB()))
			{
				try
				{
					driver.get(url+"/index#setting/user/edit/"+userid);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("firstname")));

					if((date.equals(driver.findElement(By.id("datedropdown")).findElement(By.tagName("span")).getText())) && (month.equals(driver.findElement(By.id("monthdropdown")).findElement(By.tagName("span")).getText())) && (year.equals(driver.findElement(By.id("yeardropdown")).findElement(By.tagName("span")).getText())))
					{
						etest.log(Status.PASS,"Checked Edited Data for Date");

						result.put("SU25", true);
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-Date","MismatchEditedValue-Date");
					}

				}
				catch(NoSuchElementException e)
				{
                    TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-Date","ErrorWhileCheckingEditedDataInOperatorProfile",e);

            		System.out.println("Exception while checking edited data in Operators settings page : "+e);
                }
				catch(Exception e)
				{
                    TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-Date","ErrorWhileCheckingEditedDataInOperatorProfile",e);

            		System.out.println("Exception while checking edited data in Operators settings page : "+e);
                }

				JavascriptExecutor je = (JavascriptExecutor)driver;
				je.executeScript("scroll(0,2000)");
				driver.findElement(By.id("btncancel")).click();
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedDataInOperatorProfile","ErrorWhileCheckingEditedDataInOperatorProfile",e);

            System.out.println("Exception while checking edited data in Operators settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedDataInOperatorProfile","ErrorWhileCheckingEditedDataInOperatorsProfile",e);

            System.out.println("Exception while checking edited data in Operators settings page : "+e);
        }
	}

	public static boolean checkEditData(WebDriver driver, String value, String userid, String id)
	{
		return checkEditData(driver,url, value, userid, id,etest);
	}
	public static boolean checkEditData(WebDriver driver,String url, String value, String userid, String id,ExtentTest etest)
	{
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);

		try
		{
			driver.get(url+"/index#setting/user/edit/"+userid);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("firstname")));

			if(value.equals(driver.findElement(By.id(id)).getAttribute("value")))
			{
				JavascriptExecutor je = (JavascriptExecutor)driver;
				je.executeScript("scroll(0,2000)");
				driver.findElement(By.id("btncancel")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

				etest.log(Status.PASS,"Checked Edited Data for "+value);

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-"+value,"MismatchEditedValue-"+value);
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-"+value,"ErrorWhileCheckingEditedDataInOperatorProfile-"+value,e);

            System.out.println("Exception while checking edited data in Operators settings page : "+value+" -- "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-"+value,"ErrorWhileCheckingEditedDataInOperatorProfile-"+value,e);

            System.out.println("Exception while checking edited data in Operators settings page : "+value+" -- "+e);
        }

        JavascriptExecutor je = (JavascriptExecutor)driver;
		je.executeScript("scroll(0,2000)");

		driver.findElement(By.id("btncancel")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

		return false;
	}

	public static boolean checkDDEditData(WebDriver driver, String value, String userid, String id)
	{
		return checkDDEditData(driver,url,value,userid,id,etest);
	}
	public static boolean checkDDEditData(WebDriver driver,String url, String value, String userid, String id,ExtentTest etest)
	{
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);

		try
		{
			driver.get(url+"/index#setting/user/edit/"+userid);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("firstname")));

			if(value.equals(driver.findElement(By.id(id)).findElement(By.tagName("span")).getText()))
			{
				JavascriptExecutor je = (JavascriptExecutor)driver;
				je.executeScript("scroll(0,2000)");

				driver.findElement(By.id("btncancel")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

				etest.log(Status.PASS,"Checked Edited Data for "+value);

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-"+value,"MismatchEditedValue-"+value);
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-"+value,"ErrorWhileCheckingEditedDataInOperatorProfile-"+value,e);

            System.out.println("Exception while checking edited dropdown data in Operators settings page : "+value+" -- "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-"+value,"ErrorWhileCheckingEditedDataInOperatorProfile-"+value,e);

            System.out.println("Exception while checking edited dropdown data in Operators settings page : "+value+" -- "+e);
        }
		JavascriptExecutor je = (JavascriptExecutor)driver;
		je.executeScript("scroll(0,2000)");
		driver.findElement(By.id("btncancel")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_edit"))));

		return false;
	}

	public static void checkUserName(WebDriver driver, String agent)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            //WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));

			String userid = "";
			WebElement elmt1 = driver.findElement(By.id("ulisttable"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				CommonUtil.inViewPortSafe(driver,elmt);
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(agent))
				{
					userid = elmt.getAttribute("id");
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");
					elmt.findElement(By.className("txtelips")).click();
					break;
				}
			}

            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));

			WebElement userdetails = driver.findElement(By.id("userdetails"));

			String details = userdetails.getText();
			result.put("SU26", false);
			if(details.contains(knownas))
			{
				result.put("SU26", checkEditData(driver, knownas, userid, "nickname"));
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-OperatorName","ErrorWhileCheckingEditedDataInOperatorProfile-OperatorName",e);

            System.out.println("Exception while checking Operatorname in Operators settings page : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"AgentsSettings-Admin","CheckEditedData-OperatorsName","ErrorWhileCheckingEditedDataInOperatorsProfile-OperatorName",e);

            System.out.println("Exception while checking Operatorname in Operator settings page : "+e);
        }
	}

	private static String getAgentDOB()
	{
		String dob = "";
		dob = dob+date+"-";
		if(month.equals("Jan"))
		{
			dob = dob + "01-";
		}
		else if(month.equals("Feb"))
		{
			dob = dob + "02-";
		}
		else if(month.equals("Mar"))
		{
			dob = dob + "03-";
		}
		else if(month.equals("Apr"))
		{
			dob = dob + "04-";
		}
		else if(month.equals("May"))
		{
			dob = dob + "05-";
		}
		else if(month.equals("Jun"))
		{
			dob = dob + "06-";
		}
		else if(month.equals("Jul"))
		{
			dob = dob + "07-";
		}
		else if(month.equals("Aug"))
		{
			dob = dob + "08-";
		}
		else if(month.equals("Sep"))
		{
			dob = dob + "09-";
		}
		else if(month.equals("Oct"))
		{
			dob = dob + "10-";
		}
		else if(month.equals("Nov"))
		{
			dob = dob + "11-";
		}
		else if(month.equals("Dec"))
		{
			dob = dob + "12-";
		}
		dob = dob + year;
		return dob;
	}

	//Clear updated settings
	public static boolean clearAgentSettings(WebDriver driver)
	{
		try
		{
			deleteAgent(driver,"rajkumar.natarajan+106@zohocorp.com");
			deleteAgent(driver,"rajkumar.natarajan+105@zohocorp.com");
			deleteAgent(driver,"rajkumar.natarajan+107@zohocorp.com");
			return true;
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while clearing data in Operators settings page : "+e);
        }
		catch(Exception e)
		{
            System.out.println("Exception while clearing data in Operators settings page : "+e);
        }
		return false;
	}

	//Mouse Over for hidden element
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		Thread.sleep(500);
		new Actions(driver).moveToElement(element).perform();
	}


	public static boolean checkOperatorStatusChangeOption(WebDriver driver,String email,boolean isToBeFound,ExtentTest etest)
	{
		try
		{
			selectAgentByEmail(driver,email);

			if(CommonWait.isDisplayed(driver,USER_STATUS_DRP_DWN) == isToBeFound)
			{
				etest.log(Status.PASS,"Operator status change option "+((isToBeFound)?"was":"was not")+" found");
				TakeScreenshot.infoScreenshot(driver,etest);
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Operator status change option "+((isToBeFound)?"was not":"was")+" found");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			return false;
		}
	}

	public static void checkOperatorStatusChanged(WebDriver driver,WebDriver toCheckDriver,String agent_email,boolean isAvailable,int startKey,ExtentTest etest)
	{
		checkOperatorStatusChanged(driver,toCheckDriver,agent_email,isAvailable,startKey,false,etest);
	}

	public static void checkOperatorStatusChanged(WebDriver driver,WebDriver toCheckDriver,String agent_email,boolean isAvailable,int startKey,boolean isOperatorOffline,ExtentTest etest)
	{
		String status = (isAvailable)?"Available":"Busy";
		String revertStatus = (isAvailable)?"Busy":"Available";
		AgentStatus agentStatus = (isAvailable)?AgentStatus.AVAILABLE:AgentStatus.BUSY;

		WebDriver visDriver = null;
		String 
		visName = "test",
		visEmail = "test@qa.team",
		visQues = "testing"
		;
		String script = "function getAgentNamesByEmail(email) {var agentName='';var reps = AgentDB.reps;for (var property in reps){if (reps.hasOwnProperty(property)){if(reps[property].EMAIL == email){agentName = reps[property].DNAME;break;}}}return agentName;}return getAgentNamesByEmail('"+agent_email+"');";
		String agentMail = (((JavascriptExecutor) driver).executeScript(script)).toString();

		String key = "SU"+startKey;
		try
		{
			visDriver = Functions.setUp();
			changeOperatorStatusFromAdmin(driver,agent_email,status);

			if(isOperatorOffline)
			{
				agentStatus = AgentStatus.OFFLINE;
				status = "Offline";
			}

			etest.log(Status.INFO,"Operator status was changed to "+status+" from admin");
			TakeScreenshot.infoScreenshot(driver,etest);

			if(getStatusFromOperatorsList(driver,agent_email) == agentStatus)
			{
				etest.log(Status.PASS,"Agent status was found "+status+" in the UI");
				TakeScreenshot.infoScreenshot(driver,etest);
				result.put(key,true);
			}
			else
			{
				etest.log(Status.FAIL,"Agent status was not found "+status+" in the UI");
				TakeScreenshot.screenshot(driver,etest);
				result.put(key,false);
			}

			key = "SU"+(startKey+4);
			if(agent_email != admin_email)
			{
				if(getAgentStatusFromWMSBar(driver,agentMail) == agentStatus)
				{
					etest.log(Status.PASS,"Agent status was found "+status+" in WMS bar");
					TakeScreenshot.infoScreenshot(toCheckDriver,etest);
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,"Agent status was not found "+status+" in WMS bar");
					TakeScreenshot.screenshot(driver,etest);
					result.put(key,false);
				}
			}

			if(!isOperatorOffline)
			{
				key = "SU"+(startKey+1);

				if(com.zoho.livedesk.util.common.actions.Status.getAgentStatus(toCheckDriver) == agentStatus)
				{
					etest.log(Status.PASS,"Agent status was found "+status+" in the UI of the agent side");
					TakeScreenshot.infoScreenshot(toCheckDriver,etest);
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,"Agent status was not found "+status+" in the UI of the agent side");
					TakeScreenshot.screenshot(toCheckDriver,etest);
					result.put(key,false);
				}

				key = "SU"+(startKey+2);

				String widgetCode = ExecuteStatements.getWidgetCode(driver);

				VisitorWindow.createPage(visDriver,widgetCode);
				VisitorWindow.initiateChatVisTheme(visDriver,visName,visEmail,null,visQues,etest);
				BotsVisitorSide.waitTillBotReplies(visDriver);
				VisitorWindow.sentMessageInTheme(visDriver,"forward");

				try
				{
					CommonFunctionsTC.acceptTransferedChat(toCheckDriver,etest);
				}
				catch(Exception e)
				{
					CommonUtil.doNothing();
				}

				CommonUtil.sleep(5000);

				if(Tab.isMyChatsShown(toCheckDriver) == isAvailable)
				{
					etest.log(Status.PASS,"My chats "+((isAvailable)?"was":"was not")+" found in agent side after the status was changed by admin");
					TakeScreenshot.infoScreenshot(toCheckDriver,etest);
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,"My chats "+((isAvailable)?"was not":"was")+" found in agent side after the status was changed by admin");
					TakeScreenshot.screenshot(toCheckDriver,etest);
					result.put(key,false);
				}

				try
				{
					VisitorWindow.endChatVisitor(visDriver);
					Tab.clickMyChats(driver);
					ChatWindow.closeAllChats(driver);
					// VisitorWindow.waitTillChatisMissedInTheme(visDriver);
				}
				catch(Exception e)
				{
					CommonUtil.printStackTrace(e);
				}

				key = "SU"+(startKey+3);
				com.zoho.livedesk.util.common.actions.Status.changeStatus(toCheckDriver,revertStatus.toLowerCase(),etest);
				TakeScreenshot.infoScreenshot(toCheckDriver,etest);
				if(getOperatorStatusFromOperatorInfo(driver,agent_email).contains(revertStatus))
				{
					etest.log(Status.PASS,"Expected status ("+revertStatus+") was found in Operator info after changing the status from operator end");
					result.put(key,true);
				}
				else
				{
					etest.log(Status.FAIL,"Expected status ("+revertStatus+") was not found in Operator info after changing the status from operator end");
					TakeScreenshot.screenshot(driver,etest);
					TakeScreenshot.screenshot(toCheckDriver,etest);
					result.put(key,false);
				}

				com.zoho.livedesk.util.common.actions.Status.changeStatus(toCheckDriver,status.toLowerCase(),etest);
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			TakeScreenshot.screenshot(visDriver,etest,e);
			TakeScreenshot.screenshot(toCheckDriver,etest,e);
		}
		finally
		{
			try
			{
				SalesIQWmsBarFunctions.closeMycolleague(driver);
			}
			catch(Exception excep)
			{
				CommonUtil.doNothing();
			}
			visDriver.quit();
		}
	}

	public static void selectAgentByEmail(WebDriver driver,String agent_email) throws Exception
	{
		WebElement operator = getOperatorElement(driver,agent_email);
		
		ExecuteStatements.run(driver,"window.scrollTo(0,"+operator.getLocation().y+")");
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(operator,TEXT_CLASS));
		CommonWait.waitTillDisplayed(driver,By.linkText(ResourceManager.getRealValue("settings_edit")));
	}

	public static AgentStatus getAgentStatusFromWMSBar(WebDriver driver,String userName) throws Exception
	{
		SalesIQWmsBarFunctions.openMycolleague(driver);

		List<WebElement> operatorsInWMS = CommonUtil.getElement(driver,MY_COLLEAGUES,MSG_DISP).findElements(SUPREPMN);

		String statusClass = CommonUtil.getElementByAttributeValue(operatorsInWMS,"title",userName).getAttribute("innerHTML");

		if(statusClass.contains(AVAILABLE_CLASS_IN_WMS))
		{
			return AgentStatus.AVAILABLE;
		}
		else if(statusClass.contains(BUSY_CLASS_IN_WMS))
		{
			return AgentStatus.BUSY;
		}
		else
		{
			return AgentStatus.OFFLINE;
		}
	}

	public static AgentStatus getStatusFromOperatorsList(WebDriver driver,String agent_email) throws Exception 
	{
		WebElement operator = getOperatorElement(driver,agent_email);
		String statusClass = CommonUtil.getElement(operator,USER_IMAGE).getAttribute("class");
		if(statusClass.contains(AVAILABLE_CLASS))
		{
			return AgentStatus.AVAILABLE;
		}
		else if(statusClass.contains(BUSY_CLASS))
		{
			return AgentStatus.BUSY;
		}
		else
		{
			return AgentStatus.OFFLINE;
		}
	}

	public static WebElement getOperatorElement(WebDriver driver,String agent_email) throws Exception
	{
		Tab.clickSettings(driver);
		CommonWait.waitTillDisplayed(driver,OPERATOR_LIST);
		List<WebElement> operatorList = CommonUtil.getElement(driver,OPERATOR_LIST).findElements(LIST_ROW);

		for(WebElement operator : operatorList)
		{
			String current_email=CommonUtil.getElement(operator,By.className("ulist_email")).getAttribute("innerText").trim();

			if(current_email.equals(agent_email))
			{
				ExecuteStatements.run(driver,"window.scrollTo(0,"+operator.getLocation().y+")");
				return operator;
			}
		}

		throw new com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException("Agent not found. -->"+agent_email);
	}

	public static void changeOperatorStatusFromAdmin(WebDriver driver,String agent_email,String status) throws Exception
	{
		selectAgentByEmail(driver,agent_email);

		CommonWait.waitTillDisplayed(driver,USER_STATUS_DRP_DWN);
		CommonUtil.clickWebElement(driver,USER_STATUS_DRP_DWN,TEXT_CLASS);
		CommonWait.waitTillDisplayed(driver,USER_STATUS_DRP_DWN_DDOWN);

		List<WebElement> statuses = CommonUtil.getElement(driver,USER_STATUS_DRP_DWN_DDOWN,UL_LIST).findElements(LI_ELEMENTS);

		CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(statuses,"val",status));

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,USER_STATUS_DRP_DWN,TEXT_CLASS),"val",status);
	}

	public static String getOperatorStatusFromOperatorInfo(WebDriver driver,String agent_email) throws Exception
	{
		selectAgentByEmail(driver,agent_email);

		CommonWait.waitTillDisplayed(driver,USER_STATUS_DRP_DWN);

		String statusFromOperatorInfo = CommonUtil.getElement(driver,USER_STATUS_DRP_DWN,TEXT_CLASS).getAttribute("val");

		return statusFromOperatorInfo;

	}
}
