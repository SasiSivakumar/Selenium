//$Id$
package com.zoho.livedesk.client.DailyReportUnsubscribe;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.Tab;

public class UnSubscription {

 public static Hashtable < String, Boolean > result = new Hashtable();
 public static Hashtable < String, Hashtable < String, Boolean >> hashtable = new Hashtable();
 public static Hashtable < String, Boolean > servicedown = new Hashtable();
 public static ExtentTest etest;
 public static String module_name = "DailyReportUnSubscription";
 public static String portal_name = "", dummy_portal_name = "";

 public static Hashtable test(WebDriver driver) {
  try {
   portal_name = ExecuteStatements.getPortal(driver);
   dummy_portal_name = "_" + CommonUtil.getUniqueId() + "_";
   ExecuteStatements.openNewTab(driver, "https://salesiq.localzoho.com/" + portal_name + "/unsubscribe.sas?id=8622a22ccd4f5df0b23fbf15861066bb9911089cd66f8a62afd2162d2b62b0117893c7ad5a4559d84b3811efe93d229791f7b255ffdb6cd8ead8d2e83aaca35ddf053ed0f41398dceb44de670281668288ca7fa81adc7687a9e56f0c227f66bc3bde29c19788912e9768d2b4e6424358754351114abbb4976b55789e46f8f2e18f47548eefa8a07c0d9e2d0fc11214ea5e15a29e4a4abc981030306902056a5841fa5d2ab93af82097d19fd1c682913d85a19ac51528b597afd2162d2b62b011ca7a9e470efe9f1040b97a97d55a8f2dbc639ef933681d2045ddc72920b1e1c209f6762c2560f6b030065b53f4faa9877dcd4d893c278fbe8533102fa710136b3f55b4154bb276d1c49656c1e54fa562299efa3a6cd5f15c");

   Hashtable < String, Boolean > expected_result = null;

   result = new Hashtable < String, Boolean > ();

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS1"));
   checkUnsubscrptionPageContentBeforeUnsubscription(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS2"));
   checkUnsubscription(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS3"));
   checkUnsubscrptionPageContentAfterUnsubscription(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS4"));
   checkUnsubscrptionPageContentRepeatUnsubscription(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS5"));
   checkUnSubscriptionPageWithDifferentPortal(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);


   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS8"));
   checkModificationLinkInUnsubscribePage(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("DRUS6"));
   checkUnRegistredPortal(driver, etest);
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   Functions.logout(driver);
  } catch (Exception e) {
   etest.log(Status.FATAL, "Apps Visitor Module error");
   etest.log(Status.FATAL, "Module breakage occurred " + e);
   TakeScreenshot.screenshot(driver, etest, "Apps Visitor", "Exception", "Module breakage", e);
  }
  hashtable.put("result", result);
  hashtable.put("servicedown", servicedown);
  return hashtable;
 }


 private static boolean checkUnsubscrptionPageContentRepeatUnsubscription(WebDriver driver1, ExtentTest etest) {
  try {

   CommonUtil.switchToTab(driver1, 1);

   driver1.navigate().to("https://salesiq.localzoho.com/" + portal_name + "/unsubscribe.sas?id=8622a22ccd4f5df0b23fbf15861066bb9911089cd66f8a62afd2162d2b62b0117893c7ad5a4559d84b3811efe93d229791f7b255ffdb6cd8ead8d2e83aaca35ddf053ed0f41398dceb44de670281668288ca7fa81adc7687a9e56f0c227f66bc3bde29c19788912e9768d2b4e6424358754351114abbb4976b55789e46f8f2e18f47548eefa8a07c0d9e2d0fc11214ea5e15a29e4a4abc981030306902056a5841fa5d2ab93af82097d19fd1c682913d85a19ac51528b597afd2162d2b62b011ca7a9e470efe9f1040b97a97d55a8f2dbc639ef933681d2045ddc72920b1e1c209f6762c2560f6b030065b53f4faa9877dcd4d893c278fbe8533102fa710136b3f55b4154bb276d1c49656c1e54fa562299efa3a6cd5f15c");

   clickUnsubscriptionButton(driver1, etest);

   if (!checkRepeatedSubscriptionPageHeading(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageHeadingContent") + "' not found");
    TakeScreenshot.screenshot(driver1, "Daily Report -Repeated Unsubscrption", "Heading", " Not Present");
    return false;
   }
   etest.log(Status.PASS, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageHeadingContent") + "' Found");
   TakeScreenshot.infoScreenshot(driver1, etest);

   if (!checkRepeatedSubscriptionPageSubHeading(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageSubHeadingContent") + "' not found");
    TakeScreenshot.screenshot(driver1, "Daily Report -Repeated Unsubscrption", "Heading", " Not Present");
    return false;
   }
   etest.log(Status.PASS, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageSubHeadingContent") + "' Found");
   TakeScreenshot.infoScreenshot(driver1, etest);
   CommonUtil.switchToTab(driver1, 0);
   return true;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver1, etest, "Daily Report- Repeated Subscription", "Unsubscription button", "Not clicked", e);

  }
  return false;
 }

 public static boolean checkRepeatedSubscriptionPageHeading(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("main"));
  WebElement heading = CommonUtil.getElement(driver, By.id("heading"));
  String headingContent = heading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("repeatedUnSubscriptionPageHeadingContent"), headingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageHeadingContent") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageHeadingContent") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
 }

 public static boolean checkRepeatedSubscriptionPageSubHeading(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("main"));
  WebElement subheading = CommonUtil.getElement(driver, By.id("content"));
  String subheadingContent = subheading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("repeatedUnSubscriptionPageSubHeadingContent"), subheadingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageSubHeadingContent") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("repeatedUnSubscriptionPageHeadingContent") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }

 }

 public static boolean checkUnsubscrptionPageContentBeforeUnsubscription(WebDriver driver1, ExtentTest etest) {
  try {
   CommonUtil.switchToTab(driver1, 1);

   if (!checkSubscriptionPageHeading(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContent") + "' not found");
    TakeScreenshot.screenshot(driver1, "UnSubscription Page", "Heading Text", "Heading not Found");
    return false;
   }
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContent") + "' found");
   TakeScreenshot.infoScreenshot(driver1, etest);

   if (!checkSubscriptionPageSubHeading(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContent") + "' not found");
    TakeScreenshot.screenshot(driver1, "UnSubscription Page", "Heading Text", "Sub Heading not Found");
    return false;
   }
   etest.log(Status.PASS, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContent") + "'  found");
   TakeScreenshot.infoScreenshot(driver1, etest);

   if (!checkSubscriptionPageLinkContent(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPagelinkContent") + "' not found");
    TakeScreenshot.screenshot(driver1, "UnSubscription Page", "Heading Text", "Link content not Found");
    return false;
   }
   etest.log(Status.PASS, "Heading '" + ResourceManager.getRealValue("unSubscriptionPagelinkContent") + "'  found");
   TakeScreenshot.infoScreenshot(driver1, etest);

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver1, etest, "Daily Report Subscription", "Unsubscription Page", "Page not Found", e);
  }
  CommonUtil.switchToTab(driver1, 0);
  return false;
 }

 public static boolean checkUnsubscription(WebDriver driver, ExtentTest etest) {
  try {

   CommonUtil.switchToTab(driver, 0);

   if (!addMailIdInDailyReportPortalSettings(driver, etest)) {
    etest.log(Status.FAIL, "Mail Id Not Added to Daily Report Section in Portal Settings");
    TakeScreenshot.screenshot(driver, "Daily Report Subscrption", "Add Mail Id in Daily report - Portal Setting", "Mai Id not added");
    return false;
   }
   etest.log(Status.PASS, "Mail Id Added to Daily Report Section in Portal Setting");
   TakeScreenshot.infoScreenshot(driver, etest);

   CommonUtil.switchToTab(driver, 1);

   if (!clickUnsubscriptionButton(driver, etest)) {
    etest.log(Status.FAIL, "Unsubscription button is not Clicked");
    TakeScreenshot.screenshot(driver, "Daily Report Unsubscription", "Unsubscribe Button", "Button Not Clicked");
    return false;
   }
   etest.log(Status.PASS, "Unsubscription button is Clicked in unsubscribe page");
   TakeScreenshot.infoScreenshot(driver, etest);

   CommonUtil.switchToTab(driver, 0);

   if (!checkMailIdRemovedInPortalSettings(driver, etest)) {
    etest.log(Status.FAIL, "EmailID found in Daily statistics section");
    TakeScreenshot.screenshot(driver, "Portal Settings", "Daily statistics", "EmailID Found");
    return false;
   }
   etest.log(Status.PASS, "No EmailID is found in Daily statistics section");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Daily Report Subscription", "Portal Settings Page", "EmailID Found after Unsubscription", e);
   TakeScreenshot.screenshot(driver, etest, "Daily Report Subscription", "Unsubscription button", "Not clicked", e);

  }
  return false;

 }


 public static boolean checkUnsubscrptionPageContentAfterUnsubscription(WebDriver driver1, ExtentTest etest) {

  try {

   CommonUtil.switchToTab(driver1, 1);

   if (!checkUnSubscriptionPageHeading(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContentAfterUnsubscribe") + "' not found");
    TakeScreenshot.screenshot(driver1, "UnSubscription Page", "Heading Text", "Heading not Found");
    return false;
   }
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContentAfterUnsubscribe") + "' found");
   TakeScreenshot.infoScreenshot(driver1, etest);

   if (!checkUnSubscriptionPageSubHeading(driver1, etest)) {
    etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentAfterUnsubscribe") + "' not found");
    TakeScreenshot.screenshot(driver1, "UnSubscription Page", "Heading Text", "Sub Heading not Found");
    return false;
   }
   etest.log(Status.PASS, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentAfterUnsubscribe") + "'  found");
   TakeScreenshot.infoScreenshot(driver1, etest);
   return true;

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver1, etest, "Daily Report Subscription", "Unsubscription Page", "Page not Found", e);
  }
  CommonUtil.switchToTab(driver1, 0);
  return false;
 }

 public static boolean checkUnSubscriptionPageWithDifferentPortal(WebDriver driver1, ExtentTest etest) {

  try {

   CommonUtil.switchToTab(driver1, 1);

   driver1.navigate().to("https://salesiq.localzoho.com/sasisksiq/unsubscribe.sas?id=8622a22ccd4f5df0b23fbf15861066bb9911089cd66f8a62afd2162d2b62b0117893c7ad5a4559d84b3811efe93d229791f7b255ffdb6cd8ead8d2e83aaca35ddf053ed0f41398dceb44de670281668288ca7fa81adc7687a9e56f0c227f66bc3bde29c19788912e9768d2b4e6424358754351114abbb4976b55789e46f8f2e18f47548eefa8a07c0d9e2d0fc11214ea5e15a29e4a4abc981030306902056a5841fa5d2ab93af82097d19fd1c682913d85a19ac51528b597afd2162d2b62b011ca7a9e470efe9f1040b97a97d55a8f2dbc639ef933681d2045ddc72920b1e1c209f6762c2560f6b030065b53f4faa9877dcd4d893c278fbe8533102fa710136b3f55b4154bb276d1c49656c1e54fa562299efa3a6cd5f15c");

   if (!clickUnsubscriptionButton(driver1, etest)) {
    etest.log(Status.FAIL, "Unsubscription button is not Clicked");
    TakeScreenshot.screenshot(driver1, "Daily Report Unsubscription", "Unsubscribe Button", "Button Not Clicked");
    return false;
   }

   etest.log(Status.PASS, "Unsubscription button is Clicked in unsubscribe page");
   TakeScreenshot.infoScreenshot(driver1, etest);

   checkDifferentPortalPageContent(driver1, etest);

   etest.log(Status.PASS, "Page content Matched after tried with Different Portal");
   TakeScreenshot.infoScreenshot(driver1, etest);

   CommonUtil.switchToTab(driver1, 0);
   return true;


  } catch (Exception e) {
   TakeScreenshot.screenshot(driver1, etest, "Daily Report Subscription", "Unsubscription Page-Different Portal", "Page not Found", e);
  }

  return false;
 }

 public static boolean checkUnRegistredPortal(WebDriver driver1, ExtentTest etest) {
  try {

   CommonUtil.switchToTab(driver1, 1);

   driver1.navigate().to("https://salesiq.localzoho.com/" + dummy_portal_name + "/unsubscribe.sas?id=8622a22ccd4f5df0b23fbf15861066bb9911089cd66f8a62afd2162d2b62b0117893c7ad5a4559d84b3811efe93d229791f7b255ffdb6cd8ead8d2e83aaca35ddf053ed0f41398dceb44de670281668288ca7fa81adc7687a9e56f0c227f66bc3bde29c19788912e9768d2b4e6424358754351114abbb4976b55789e46f8f2e18f47548eefa8a07c0d9e2d0fc11214ea5e15a29e4a4abc981030306902056a5841fa5d2ab93af82097d19fd1c682913d85a19ac51528b597afd2162d2b62b011ca7a9e470efe9f1040b97a97d55a8f2dbc639ef933681d2045ddc72920b1e1c209f6762c2560f6b030065b53f4faa9877dcd4d893c278fbe8533102fa710136b3f55b4154bb276d1c49656c1e54fa562299efa3a6cd5f15c");

   if (CommonWait.waitTillDisplayed(driver1, By.className("sadSmiley"))) {

    etest.log(Status.PASS, "Not process your request page displayed");
    TakeScreenshot.infoScreenshot(driver1, etest);
    return true;
   }
   etest.log(Status.FAIL, "Not process your request page is not displayed");
   TakeScreenshot.screenshot(driver1, "Daily Report Subscription", "Unsubscription Page-UnRegistered Portal", "Page not Found");
   CommonUtil.switchToTab(driver1, 0);
   return false;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver1, etest, "Daily Report Subscription", "Unsubscription Page-UnRegistered Portal", "Page not Found", e);
  }

  return false;
 }

 public static boolean checkModificationLinkInUnsubscribePage(WebDriver driver, ExtentTest etest) {

  try {
   CommonUtil.switchToTab(driver, 1);

   driver.navigate().to("https://salesiq.localzoho.com/" + portal_name + "/unsubscribe.sas?id=8622a22ccd4f5df0b23fbf15861066bb9911089cd66f8a62afd2162d2b62b0117893c7ad5a4559d84b3811efe93d229791f7b255ffdb6cd8ead8d2e83aaca35ddf053ed0f41398dceb44de670281668288ca7fa81adc7687a9e56f0c227f66bc3bde29c19788912e9768d2b4e6424358754351114abbb4976b55789e46f8f2e18f47548eefa8a07c0d9e2d0fc11214ea5e15a29e4a4abc981030306902056a5841fa5d2ab93af82097d19fd1c682913d85a19ac51528b597afd2162d2b62b011ca7a9e470efe9f1040b97a97d55a8f2dbc639ef933681d2045ddc72920b1e1c209f6762c2560f6b030065b53f4faa9877dcd4d893c278fbe8533102fa710136b3f55b4154bb276d1c49656c1e54fa562299efa3a6cd5f15c");

   if (checkSubscriptionPageLinkContent(driver, etest)) {
    CommonUtil.clickWebElement(driver, By.id("btn1"));
    etest.log(Status.PASS, "Modification Link in Subscription page is clicked");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   String actual = driver.getCurrentUrl().toString();
   String expected = "https://salesiq.localzoho.com/" + portal_name + "/index#setting/configration";

   if (!CommonUtil.checkStringEqualsAndLog(expected, actual, "Current URL of Portal Settings Page", etest)) {

    etest.log(Status.FAIL, "URL '#setting/configration' not found ");
    TakeScreenshot.screenshot(driver, "Portal Setting", "URL", "Not Found");
    return false;
   }
   etest.log(Status.PASS, "URL 'setting/configration' found and Displayed ");
   TakeScreenshot.infoScreenshot(driver, etest);
   CommonUtil.switchToTab(driver, 0);
   return true;

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Daily Report Subscription", "Unsubscription Page", "Link not Found", e);
   TakeScreenshot.screenshot(driver, etest, "Portal Settings", "URL-'#setting/configration'", "Not Found", e);
  }
  return false;
 }



 public static boolean checkDifferentPortalPageContent(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("heading"));
  WebElement heading = CommonUtil.getElement(driver, By.id("heading"));
  String headingContent = heading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPageHeadingContentDifferentPortal"), headingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContentDifferentPortal") + "' not found");
   TakeScreenshot.screenshot(driver, "Daily Report Unsubscription ", "Different Portal-Heading", "Not Found");
   return false;
  }
  etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContentDifferentPortal") + "' found");
  TakeScreenshot.infoScreenshot(driver, etest);

  CommonWait.waitTillDisplayed(driver, By.id("content"));
  WebElement subheading = CommonUtil.getElement(driver, By.id("content"));
  String subheadingContent = subheading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentDifferentPortal"), subheadingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.FAIL, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentDifferentPortal") + "' not found");
   TakeScreenshot.screenshot(driver, "Daily Report Unsubscription ", "Different Portal-Sub Heading", "Not Found");
   return false;
  }
  etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentDifferentPortal") + "' found");
  TakeScreenshot.infoScreenshot(driver, etest);
  return true;
 }


 public static boolean checkUnSubscriptionPageHeading(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("heading"));
  WebElement heading = CommonUtil.getElement(driver, By.id("heading"));
  String headingContent = heading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPageHeadingContentAfterUnsubscribe"), headingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContentAfterUnsubscribe") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContentAfterUnsubscribe") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }

 }

 public static boolean checkUnSubscriptionPageSubHeading(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("content"));
  WebElement subheading = CommonUtil.getElement(driver, By.id("content"));
  String subheadingContent = subheading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentAfterUnsubscribe"), subheadingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentAfterUnsubscribe") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContentAfterUnsubscribe") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }

 }


 public static boolean clickUnsubscriptionButton(WebDriver driver, ExtentTest etest) {
  if (CommonWait.waitTillDisplayed(driver, By.id("btn"))) {
   CommonUtil.clickWebElement(driver, By.id("btn"));
   etest.log(Status.INFO, "Unsubscription button is Clicked in unsubscribe page");
   return true;
  } else {
   etest.log(Status.FAIL, "Unsubscription button not found");
   TakeScreenshot.screenshot(driver, "Daily Report Unsubscription", "unsubscribe page", "Not Found");
   return false;
  }
 }

 public static boolean checkMailIdRemovedInPortalSettings(WebDriver driver, ExtentTest etest) throws Exception {

  Tab.navToPortalTab(driver);
  CommonUtil.refreshPage(driver);

  if (CommonWait.waitTillDisplayed(driver, By.id("sdailystatics"))) {
   CommonUtil.clickWebElement(driver, By.id("sdailystatics"));
   etest.log(Status.INFO, "Daily statistics section is clicked");
  }

  CommonUtil.clickWebElement(driver, By.id("count_sdailystatics"));
  String actual = CommonUtil.getElement(driver, By.id("sdailystatics")).getAttribute("value");
  String expected = "";

  if (!CommonUtil.checkStringEqualsAndLog(expected, actual, "EmailId Check ", etest)) {
   etest.log(Status.INFO, "EmailID " + actual + " found in Daily statistics section");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "No EmailID " + actual + "  is found in Daily statistics section");
   return true;
  }

 }

 public static boolean addMailIdInDailyReportPortalSettings(WebDriver driver, ExtentTest etest) throws Exception {

  Tab.navToPortalTab(driver);
  CommonUtil.sleep(2000);
  ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,300)");
  if (!CommonWait.waitTillDisplayed(driver, By.id("sdailystatics"))) {
   etest.log(Status.FAIL, "Daily statistics section not Found");
   TakeScreenshot.screenshot(driver, "Daily Report Subscrption", "Daily report Section - Portal Setting", "Not Found");
   return false;
  }

  WebElement sendMailIDToDailyReport = driver.findElement(By.id("sdailystatics"));
  sendMailIDToDailyReport.clear();
  sendMailIDToDailyReport.sendKeys("sasi.sk+siq1+t0@zohotest.com");
  CommonUtil.clickWebElement(driver, By.id("sweeklystats"));
  CommonUtil.sleep(2000);
  etest.log(Status.INFO, "Administrator Mail Id " + ExecuteStatements.getUserMail(driver) + " is added successfully");
  TakeScreenshot.infoScreenshot(driver, etest);
  return true;
 }

 public static boolean checkSubscriptionPageHeading(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("heading"));
  WebElement heading = CommonUtil.getElement(driver, By.id("heading"));
  String headingContent = heading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPageHeadingContent"), headingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContent") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContent") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }

 }


 public static boolean checkSubscriptionPageSubHeading(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("content"));
  WebElement subheading = CommonUtil.getElement(driver, By.id("content"));
  String subheadingContent = subheading.getText();

  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPageSubHeadingContent"), subheadingContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageSubHeadingContent") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPageHeadingContent") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
 }

 public static boolean checkSubscriptionPageLinkContent(WebDriver driver, ExtentTest etest) {
  CommonWait.waitTillDisplayed(driver, By.id("link"));
  WebElement link = CommonUtil.getElement(driver, By.id("link"));
  String linkContent = link.getText();
  if (!CommonUtil.checkStringEqualsAndLog(ResourceManager.getRealValue("unSubscriptionPagelinkContent"), linkContent, "Heading Content of Unsubscription Page", etest)) {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPagelinkContent") + "' not found");
   TakeScreenshot.infoScreenshot(driver, etest);

   return false;
  } else {
   etest.log(Status.INFO, "Heading '" + ResourceManager.getRealValue("unSubscriptionPagelinkContent") + "' found");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }

 }

}