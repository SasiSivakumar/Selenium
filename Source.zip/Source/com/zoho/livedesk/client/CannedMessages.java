//$Id$
package com.zoho.livedesk.client;

import java.io.PrintStream;
import java.util.*;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class CannedMessages
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	public static ExtentTest etest;

	public static Hashtable cannedMsgConfig(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM1"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			url = ConfManager.requestURL();
			
            try
			{
				Functions.closeBannersAfterLogin(driver);
			}
            catch(NoSuchElementException e){}
			catch(Exception e){}

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);

            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));

			etest.log(Status.PASS,"Canned Message Tab is present");

			result.put("CM1", true);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM2"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM2", isMessageTabPresent(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM3"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM3", isCategoryTabPresent(driver));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM4"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM4", addCannedCategory(driver, "Category @ 1"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM5"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM5", addCannedMessage(driver, "Message1", "All Departments", null));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM6"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM6", addCannedMessage(driver, "Message2", "All Departments", "Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM7"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM7", addCannedMessage(driver, "Message3", "Automation", "Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM9"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM9", editCannedMessage(driver,"Message2","Edited message 2", "Automation", "Test one"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM8"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM8", editCannedCategory(driver, "Test one", "Test two"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM10"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM10", checkCannedMessages(driver,"Category @ 2"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM11"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM11", deleteCannedMessage(driver, "Message3"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM12"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM12", deleteCannedCategory(driver, "Category @ 1"));

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CM13"));
            ComplexReportFactory.setValues(etest,"Automation","CannedMessages-Admin");

			result.put("CM13", addCannedWithoutCategory(driver));

			ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"TabCannedMessagesTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMessagesTab","ErrorCannedMessageTab",e);

			result.put("CM1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"TabCannedMessagesTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMessagesTab","ErrorCannedMessageTab",e);

			result.put("CM1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown",servicedown);
		return hashtable;
	}

	private static boolean isMessageTabPresent(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
			
            List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));

			if( text.get(0).getText().equals( ResourceManager.getRealValue("cannedmessages_desc1") ) )
			{
				etest.log(Status.PASS,"Canned Messages Description is matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMesage-MessageTabAndDescription","MismatchCannedMessagesDescrption");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMesage-MessageTabAndDescription","ErrorWhileCheckingCannedMessageDescription",e);

			System.out.println("Exception while checking if message tab is present in canned messages : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMesage-MessageTabAndDescription","ErrorWhileCheckingCannedMessageDescription",e);

			System.out.println("Exception while checking if message tab is present in canned messages : "+e);
		}
		return false;
	}

	private static boolean isCategoryTabPresent(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));

			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));
			Thread.sleep(1000);

			if(((text.get(0).getText()).equals(ResourceManager.getRealValue("cannedcategory_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("cannedcategory_desc2"))))
			{
				etest.log(Status.PASS,"Canned Messages Catagory Description is matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMesage-CatagoryTabAndDescription","MismatchCannedMessageDescription");
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMesage-CatagoryTabAndDescription","ErrorWhileCheckingCannedMessageDescription",e);

			System.out.println("Exception while checking if categories tab is available in canned messages : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CannedMesage-CatagoryTabAndDescription","ErrorWhileCheckingCannedMessageDescription",e);

			System.out.println("Exception while checking if categories tab is available in canned messages : "+e);
		}
		return false;
	}

	private static boolean addCannedCategory(WebDriver driver, String category)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));

			if(driver.findElement(By.id("emptycannedcategory")).getAttribute("style").equals("display: none;"))
			{
				driver.findElement(By.id("ccaddbtn")).findElement(By.tagName("span")).click();
				Thread.sleep(1000);
			}
			else
			{
				driver.findElement(By.id("emptycannedcategory")).findElement(By.tagName("a")).click();
				Thread.sleep(1000);
			}

			driver.findElement(By.id("category")).click();
			driver.findElement(By.id("category")).sendKeys(category);

			List<WebElement> btns = driver.findElement(By.id("categorydlgbox")).findElements(By.className("cnfmbtm"));

			btns.get(0).click();

            Tab.waitForLoadingLine(driver);

            Thread.sleep(3000);

			String username = getUserName(driver);

			Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

			List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

			for(WebElement webelmt:list)
			{
				String data = webelmt.findElement(By.className("cmn_wordbr")).getText();
				List<WebElement> elmts1 = webelmt.findElements(By.className("list_cell"));
				if((category.equals(elmts1.get(0).getText())) && (username.equals(elmts1.get(2).getText())))
				{
					etest.log(Status.PASS,"Added Catagory is present");

					return true;
				}
			}
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddCatagory","AddedCatagoryIsNotPresent");
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddCatagory","ErrorWhileAddingCatagory",e);

			System.out.println("Exception while adding canned category in canned messages : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddCatagory","ErrorWhileAddingCatagory",e);

			System.out.println("Exception while adding canned category in canned messages : "+e);
		}
		return false;
	}

	private static boolean addCannedMessage(WebDriver driver, String message, String department, String category)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

			try
			{
				driver.findElement(By.id("showempty")).click();
				Thread.sleep(1000);
				driver.findElement(By.linkText(ResourceManager.getRealValue("canned_message_addbtn"))).click();
				Thread.sleep(1000);
			}
			catch(NoSuchElementException e)
			{
				driver.findElement(By.id("cmsgbtn")).findElement(By.tagName("span")).click();
				Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));
			}
			driver.findElement(By.id("cmsg")).click();
			driver.findElement(By.id("cmsg")).clear();
			driver.findElement(By.id("cmsg")).sendKeys(message);

			driver.findElement(By.id("candeptslct_div")).click();
			WebElement webelement = driver.findElement(By.id("candeptslct_ddown"));
			List<WebElement> list = webelement.findElements(By.tagName("li"));

			for(int i=0;i<list.size();i++)
			{
				WebElement webelement2 = (WebElement)list.get(i);
				WebElement webelement4 = webelement2.findElement(By.tagName("div"));
				WebElement webelement6 = webelement4.findElement(By.tagName("span"));
				if((webelement6.getAttribute("title")).equals(department))
				{
					webelement2.click();
					break;
				}
			}
			if(category == null)
			{
				category = "Basic";
				driver.findElement(By.id("toggle")).click();
				Thread.sleep(1000);
				driver.findElement(By.id("addtxtbox")).click();
				driver.findElement(By.id("addtxtbox")).clear();
				driver.findElement(By.id("addtxtbox")).sendKeys(category);
			}
			else
			{
                int ch=0;
				driver.findElement(By.id("cannedcat_div")).click();
				WebElement webelement1 = driver.findElement(By.id("cannedcat_ddown"));
				List<WebElement> list1 = webelement1.findElements(By.tagName("li"));
				for(int i=0;i<list1.size();i++)
				{
					WebElement webelement7 = list1.get(i);
					WebElement webelement8 = webelement7.findElement(By.tagName("div"));
					WebElement webelement9 = webelement8.findElement(By.tagName("span"));
                    if((webelement9.getAttribute("title")).equals(category))
					{
						webelement7.click();
						break;
					}
                    ch++;
                    if(ch==list1.size())
                    {
                        driver.findElement(By.id("toggle")).click();
                        Thread.sleep(1000);
                        driver.findElement(By.id("addtxtbox")).click();
                        driver.findElement(By.id("addtxtbox")).clear();
                        driver.findElement(By.id("addtxtbox")).sendKeys(category);
                    }
				}
			}

			driver.findElement(By.id("btnsubmit")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Canned Message is added Successfully","addcannmsg.do",etest);
            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

			WebElement elmt1 = driver.findElement(By.id("cmsglist"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = elmt.findElement(By.className("cmn_wordbr")).getText();
				List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
				if((data.equals(message)) && (category.equals(elmts1.get(1).getText())) && (department.equals(elmts1.get(2).getText())))
				{
					Thread.sleep(1000);
                    
                    Tab.clickCannedMessagesCategory(driver);
                    
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

					List<WebElement> clist = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

					for(WebElement cwebelement:clist)
					{
						List<WebElement> celmts = cwebelement.findElements(By.className("list_cell"));
						String cdata = celmts.get(0).getText();
						if(cdata.equals(category))
						{
							cwebelement.click();
							break;
						}
					}

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

					WebElement elmt2 = driver.findElement(By.id("cmsglist"));
					List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

					for(WebElement elmt3:elmts2)
					{
						data = elmt3.findElement(By.className("cmn_wordbr")).getText();
						List<WebElement> elmts3 = elmt3.findElements(By.className("list_cell"));
						if((data.equals(message)) && (category.equals(elmts3.get(1).getText())) && (department.equals(elmts3.get(2).getText())))
						{
							etest.log(Status.PASS,"Added Canned Message is present");

							return true;
						}
					}

					TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddedCannedMessage","AddedCannedMessageIsNotListed");

					Thread.sleep(1000);
                    
                    Tab.clickCannedMessages(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));
				}
			}
			return false;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddedCannedMessage","ErrorWhileAddingCannedMessage",e);

			System.out.println("Exception while adding canned message in canned message tab : "+e);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddedCannedMessage","ErrorWhileAddingCannedMessage",e);

			System.out.println("Exception while adding canned message in canned message tab : "+e);
		}
		return false;
	}

    private static boolean addCannedWithoutCategory(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            try
            {
                driver.findElement(By.id("showempty")).click();
                Thread.sleep(1000);
                driver.findElement(By.linkText(ResourceManager.getRealValue("canned_message_addbtn"))).click();
                Thread.sleep(1000);
            }
            catch(NoSuchElementException e)
            {
                driver.findElement(By.id("cmsgbtn")).findElement(By.tagName("span")).click();
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));
            }

            driver.findElement(By.id("cmsg")).click();
            driver.findElement(By.id("cmsg")).clear();
            driver.findElement(By.id("cmsg")).sendKeys("Message 4");

            driver.findElement(By.id("toggle")).click();
            Thread.sleep(1000);

            driver.findElement(By.id("btnsubmit")).click();
            Thread.sleep(1000);

            if(ResourceManager.getRealValue("cannedmessages_validcat").equals(driver.findElement(By.id("emnewcancategory")).getText()))
            {
                etest.log(Status.PASS,"Add CannedMessages without Catagory is checked");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddedCannedMessageWithoutCatagory","MismatchAlertContent");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddedCannedMessageWithoutCatagory","ErrorWhileAddingCannedMessageWithoutCatagory",e);

            System.out.println("Exception while adding canned message without category in canned message tab : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","AddedCannedMessageWithoutCatagory","ErrorWhileAddingCannedMessageWithoutCatagory",e);

            System.out.println("Exception while adding canned message without category in canned message tab : "+e);
        }
        return false;
    }

    private static boolean deleteCannedMessage(WebDriver driver, String message)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt1 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            if(elmts.size() > 0)
            {
                try
                {
                    for(WebElement elmt:elmts)
                    {
						List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
						if(message.equals(elmts1.get(0).getText()))
						{
							String category = elmts1.get(1).getText();
							elmts1.get(0).click();

                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btncancel")));
							driver.findElement(By.id("btncancel")).click();

                            Thread.sleep(1000);
							wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

							driver.findElement(By.id("okbtn")).click();
                            Thread.sleep(1000);
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

							WebElement elmt2 = driver.findElement(By.id("cmsglist"));
							List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

							for(WebElement elmt3:elmts2)
							{
								String data = elmt3.findElement(By.className("cmn_wordbr")).getText();
								List<WebElement> elmts3 = elmt3.findElements(By.className("list_cell"));
								if((data.equals(message)) && (category.equals(elmts3.get(1).getText())))
								{
									TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedMessage","DeletedCannedMessageisListed");
									return false;
								}
							}

							Thread.sleep(1000);
                            
                            Tab.clickCannedMessagesCategory(driver);

                            Thread.sleep(1000);
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

							try
							{
								driver.findElement(By.linkText(category)).click();
								Thread.sleep(1000);
							}
							catch(NoSuchElementException exp)
							{
								etest.log(Status.PASS,"Deleted CannedMessages is not listed");

                    			return true;
							}

                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));
							WebElement elmt3 = driver.findElement(By.id("cmsglist"));
							List<WebElement> elmts3 = elmt3.findElements(By.className("list-row"));

							if(elmts3.size()>0)
							{

								for(WebElement elmt4:elmts3)
								{
									String data = elmt4.findElement(By.className("cmn_wordbr")).getText();
									List<WebElement> elmts4 = elmt4.findElements(By.className("list_cell"));
									if((data.equals(message)) && (category.equals(elmts4.get(1).getText())))
									{
										TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedMessage","DeletedCannedMessageisListedInCatagory");

            							return false;
									}
								}
							}
						}
						Thread.sleep(1000);
                        
                        Tab.clickCannedMessages(driver);

                        Thread.sleep(1000);
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
					}
                }
                catch(StaleElementReferenceException exp)
                {
                    etest.log(Status.PASS,"Deleted CannedMessages is not listed");

                    return true;
                }
            }
            etest.log(Status.PASS,"Deleted CannedMessages is not listed");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedMessage","ErrorWhileDeletingCannedMessage",e);

            System.out.println("Exception while deleting canned message in canned message tab : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedMessage","ErrorWhileDeletingCannedMessage",e);

            System.out.println("Exception while deleting canned message in canned message tab : "+e);
        }
        return false;
    }

    public static boolean deleteCannedCategory(WebDriver driver, String category)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

            for(WebElement webelement:list)
            {
                String data = webelement.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(category))
                {
                    List<WebElement> elmts1 = webelement.findElements(By.className("list_cell"));
                    elmts1.get(1).findElement(By.tagName("em")).click();

                    driver.findElement(By.id("okbtn")).click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Category deleted successfully","delcanncategory.do",etest);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

                    List<WebElement> list1 = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));
                    for(WebElement webelement2:list1)
                    {
                        if(webelement2.getText().equals(category))
                        {
                        	TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedCatagory","DeleteCannedCatagoryisListed");

                            return false;
                        }
                    }

                    driver.findElement(By.id("canned_sm_message")).click();

                    try
                    {
                        driver.findElement(By.id("showempty")).click();
                    }
                    catch(NoSuchElementException e)
                    {
                        etest.log(Status.PASS,"Deleted CannedCatagory is not listed");

                        return true;
                    }

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                    WebElement elmt1 = driver.findElement(By.id("cmsglist"));
                    List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

                    for(WebElement elmt:elmts)
                    {
                        List<WebElement> elmts2 = elmt.findElements(By.className("list_cell"));
                        String data2 = elmts2.get(1).getText();
                        if(data2.equals(category))
                        {
                        	TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedCatagory","DeleteCannedCatagoryisListed");

                            return false;
                        }
                    }
                }
            }
            etest.log(Status.PASS,"Deleted CannedCatagory is not listed");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedCatagory","ErrorWhileDeletingCannedCatagory",e);

            System.out.println("Exception while deleting canned category in canned message tab : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","DeleteCannedCatagory","ErrorWhileDeletingCannedCatagory",e);

            System.out.println("Exception while deleting canned category in canned message tab : "+e);
        }
        return false;
    }

    private static String getUserName(WebDriver driver)
    {
        String name = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings")));

            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_myprofile"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("test")));

            WebElement elmt = driver.findElement(By.id("test"));
            WebElement userdetails = elmt.findElement(By.className("usr-mrgntp")).findElement(By.id("userdetails"));
            name = userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","GetOperatorName","ErrorWhileGettingOperatorNameFromMyProfilePage",e);

            System.out.println("Exception getting operatorname in canned message tab : "+e);
        }
        catch(Exception e)
        {
           TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","GetOperatorName","ErrorWhileGettingOperatorNameFromMyProfilePage",e);

           System.out.println("Exception getting operatorname in canned message tab : "+e);
        }
        return name;
    }

    private static boolean editCannedCategory(WebDriver driver, String category, String newcategory)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            WebElement elmt1 = driver.findElement(By.id("ccategorylist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                List<WebElement> celmts = elmt.findElements(By.className("list_cell"));
                if(data.equals(category))
                {
                    CommonUtil.mouseHover(driver,CommonUtil.getElement(elmt,By.className("cmn_wordbr")));
                    CommonSikuli.findInWholePage(driver,"cannedmessgecategoryedit.png");

                    CommonUtil.mouseHover(driver,CommonUtil.getElement(elmt,By.className("cmn_wordbr")));
                    CommonSikuli.findInWholePage(driver,"cannedmessgecategoryedit.png","UI307",etest);
                    CommonUtil.jsClick(driver,celmts.get(0).findElement(By.tagName("em")));

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("category")));

                    driver.findElement(By.id("category")).click();
                    driver.findElement(By.id("category")).clear();
                    driver.findElement(By.id("category")).sendKeys(newcategory);

                    List<WebElement> btns = driver.findElement(By.id("categorydlgbox")).findElements(By.className("cnfmbtm"));
                    btns.get(0).click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Category updated successfully","upcanncategory.do",etest);
                    break;
                }
            }

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            List<WebElement> list1 = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

            for(WebElement webelement:list1)
            {
                String data = webelement.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(newcategory))
                {
                    Thread.sleep(1000);
                    
                    Tab.clickCannedMessages(driver);
                    
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                    WebElement elmt2 = driver.findElement(By.id("cmsglist"));
                    List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

                    for(WebElement elmt:elmts2)
                    {
                        String data1 = elmt.findElement(By.className("cmn_wordbr")).getText();
                        List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
                        if((data1.equals("Edited message 2")) && (newcategory.equals(elmts1.get(1).getText())))
                        {
                            etest.log(Status.PASS,"EditCannedCatagory is checked");

                            return true;
                        }
                    }
                    TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","EditCannedCatagory","MismatctEditedCannedCatagoryContent:"+"Edited message 2"+","+newcategory);
                }
            }
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","EditCannedCatagory","ErrorWhileEditingCannedCatagory",e);

            System.out.println("Exception while editing canned category in canned message tab : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","EditCannedCatagory","ErrorWhileEditingCannedCatagory",e);

            System.out.println("Exception while editing canned category in canned message tab : "+e);
        }
        return false;
    }

    private static boolean checkCannedMessages(WebDriver driver, String category)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt1 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            Hashtable canmsgs = new Hashtable();
            int i = 0;

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));
                if(category.equals(elmts1.get(1).getText()))
                {
                    canmsgs.put(data,elmts1.get(2).getText());
                }
            }

            Thread.sleep(1000);
			
            Tab.clickCannedMessagesCategory(driver);

			Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

            List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

            for(WebElement webelement:list)
            {
                String data = webelement.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(category))
                {
                    webelement.click();

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                    WebElement elmt2 = driver.findElement(By.id("cmsglist"));
                    List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

                    if((elmts2.size())==(canmsgs.size()))
                    {
                        for(WebElement elmt3:elmts2)
                        {
                            String msg = elmt3.findElement(By.className("cmn_wordbr")).getText();
                            List<WebElement> elmts3 = elmt3.findElements(By.className("list_cell"));
                            if((canmsgs.containsKey(msg)) && ((elmts3.get(2).getText()).equals(canmsgs.get(msg))))
                            {
                                i++;
                            }
                        }
                    }
                    break;
                }
            }
            if(i == canmsgs.size())
            {
                etest.log(Status.PASS,"Canned Messages count(In messages tab and catagory tab) is matched");

				return true;
            }
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CheckCannedMessages","MismatchCannedMessageCount");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CheckCannedMessages","ErrorWhileCheckingCannedMessages",e);

            System.out.println("Exception while checking canned messages in canned messages tab : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","CheckCannedMessages","ErrorWhileCheckingCannedMessages",e);

            System.out.println("Exception while checking canned messages in canned messages tab : "+e);
        }
        return false;
    }

    private static boolean editCannedMessage(WebDriver driver, String oldmessage, String message, String department, String category)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            
            Tab.clickCannedMessages(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt1 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

            for(WebElement elmt:elmts)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                if(data.equals(oldmessage))
                {
                   	CommonUtil.mouseHover(driver,CommonUtil.getElement(elmt,By.className("cmn_wordbr")));
                   	CommonSikuli.findInWholePage(driver,"cannedmessgeedit.png","UI308",etest);
                    try
                    {
                    	elmt.findElements(By.tagName("em")).get(0).click();
                    }
                    catch(Exception e)
                    {
                    	((JavascriptExecutor)driver).executeScript("arguments[0].click()",elmt.findElement(By.className("list_editicon")));
                    }

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsg")));

                    driver.findElement(By.id("cmsg")).click();
                    driver.findElement(By.id("cmsg")).clear();
                    driver.findElement(By.id("cmsg")).sendKeys(message);

                    driver.findElement(By.id("candeptslct_div")).click();
                    WebElement webelement = driver.findElement(By.id("candeptslct_ddown"));
                    List<WebElement> list = webelement.findElements(By.tagName("li"));

                    for(int i=0;i<list.size();i++)
                    {
                        WebElement webelement2 = (WebElement)list.get(i);
                        WebElement webelement4 = webelement2.findElement(By.tagName("div"));
                        WebElement webelement6 = webelement4.findElement(By.tagName("span"));
                        if((webelement6.getAttribute("title")).equals(department))
                        {
                            webelement2.click();
                            break;
                        }
                    }

                    driver.findElement(By.id("cannedcat_div")).click();
                    WebElement webelement1 = driver.findElement(By.id("cannedcat_ddown"));
                    List<WebElement> list1 = webelement1.findElements(By.tagName("li"));
                    int ch1=0;
                    for(int i=0;i<list1.size();i++)
                    {
                        WebElement webelement7 = list1.get(i);
                        WebElement webelement8 = webelement7.findElement(By.tagName("div"));
                        WebElement webelement9 = webelement8.findElement(By.tagName("span"));
                        if((webelement9.getAttribute("title")).equals(category))
                        {
                            webelement7.click();
                            break;
                        }
                        ch1++;
                        if(ch1==list1.size()-1)
                        {
                            driver.findElement(By.id("toggle")).click();
                            Thread.sleep(1000);
                            driver.findElement(By.id("addtxtbox")).click();
                            driver.findElement(By.id("addtxtbox")).clear();
                            driver.findElement(By.id("addtxtbox")).sendKeys(category);
                        }
                    }
                    driver.findElement(By.id("btnsubmit")).click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Canned Message is updated Successfully","upcannmsg.do",etest);
                    break;
                }
            }

            Thread.sleep(1000);
            
            Tab.clickCannedMessages(driver);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

            WebElement elmt3 = driver.findElement(By.id("cmsglist"));
            List<WebElement> elmts3 = elmt3.findElements(By.className("list-row"));

            for(WebElement elmt:elmts3)
            {
                String data = elmt.findElement(By.className("cmn_wordbr")).getText();
                List<WebElement> elmts1 = elmt.findElements(By.className("list_cell"));

                if((data.equals(message)) && (category.equals(elmts1.get(1).getText())) && (department.equals(elmts1.get(2).getText())))
                {
                    Thread.sleep(1000);
                    
                    Tab.clickCannedMessagesCategory(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccaddbtn")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccategorylist")));

                    List<WebElement> list = driver.findElement(By.id("ccategorylist")).findElements(By.className("list-row"));

                    for(WebElement webelmt:list)
                    {
                        String cdata = webelmt.findElement(By.className("cmn_wordbr")).getText();
                        if(category.equals(cdata))
                        {
                            webelmt.click();

                            Thread.sleep(1000);
                            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));

                            WebElement elmt2 = driver.findElement(By.id("cmsglist"));
                            List<WebElement> elmts2 = elmt2.findElements(By.className("list-row"));

                            for(WebElement elmt4:elmts2)
                            {
                                data = elmt4.findElement(By.className("cmn_wordbr")).getText();
                                List<WebElement> elmts4 = elmt4.findElements(By.className("list_cell"));
                                if((data.equals(message)) && (category.equals(elmts4.get(1).getText())) && (department.equals(elmts4.get(2).getText())))
                                {
                                    etest.log(Status.PASS,"Edit Canned Message is checked");

									return true;
                                }
                            }
                            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","EditCannedMessage","MismatchEditedCannedMessageContent");

                            break;
                        }
                    }
                    Thread.sleep(1000);
                    
                    Tab.clickCannedMessages(driver);

                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmsglist")));
                }
            }
            return false;
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","EditCannedMessage","ErrorWhileEditingCannedMessage",e);

            System.out.println("Exception while editing canned message in canned message tab : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"CannedMessages-Admin","EditCannedMessage","ErrorWhileEditingCannedMessage",e);

            System.out.println("Exception while editing canned message in canned message tab : "+e);
        }
        return false;
    }

    public static void mouseOver(WebDriver driver, WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    public static boolean clearCannedMessages(WebDriver driver)
    {
        try
        {
            editCannedCategory(driver, "Test two", "Test one");
            deleteCannedMessage(driver, "Message2");
            deleteCannedCategory(driver, "Basic");
            deleteCannedMessage(driver, "Edited message 2");
            deleteCannedMessage(driver, "Message1");
            deleteCannedCategory(driver, "Basic");
            deleteCannedMessage(driver, "Message3");
            deleteCannedCategory(driver, "Category @ 1");
            deleteCannedCategory(driver, "Category @ 2");
            deleteCannedCategory(driver, "Test one");
            return true;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clearing data in canned message tab : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in canned message tab : "+e);
        }
        return false;
    }
}
