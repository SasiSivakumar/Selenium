//$Id$
package com.zoho.livedesk.client.ZohoCampaign;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import java.util.List;

import com.google.common.base.Function;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.util.common.actions.*;
import java.net.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class CommonFunctions {

	public static WebDriver setUp() throws Exception
	{
        return Functions.setUp();
	}
    
    public static void  login(WebDriver driver,String usrname,String pwd)throws Exception
    {
	    	int screenWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	    	int screenHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	    	Dimension targetSize = new Dimension(screenWidth,screenHeight);     //Imac - 2560*1440  Mac - 1440*900
	        driver.manage().window().setSize(targetSize);
	        
	    	driver.manage().window().maximize();
            if(Util.siteNameout().contains("local"))
                driver.get("https://accounts.localzoho.com");
            else
                driver.get("https://accounts.zoho.com");
	    	driver.switchTo().frame(0);
            CommonUtil.elfinder(driver,"id","lid").clear();
            CommonUtil.elfinder(driver,"id","lid").sendKeys(usrname);
            
            CommonUtil.elfinder(driver,"id","pwd").clear();
            CommonUtil.elfinder(driver,"id","pwd").sendKeys(pwd);
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","login"),"classname","redBtn").click();
            
            //driver.findElement(By.id("login")).findElement(By.className("redBtn")).click();
        Thread.sleep(5000);
        //            WebDriverWait wait = new WebDriverWait(driver, 40);
        //            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portfolio-wrap")));
            if(Util.siteNameout().contains("lab"))
            {
                driver.get("https://labsalesiq.localzoho.com");
            }
            else if(Util.siteNameout().contains("local"))
                driver.get("https://salesiq.localzoho.com");
            else if(Util.siteNameout().contains("pre"))
                driver.get("https://presalesiq.zoho.com");
            else
                driver.get("https://salesiq.zoho.com");
            try{
            	WebElement banner = CommonUtil.elfinder(driver,"id","dnenable");
            	WebElement close = CommonUtil.elfinder(driver,"classname","sqico-close");
            	close.click();
            }
            catch(Exception e){}
        try
        {
            Thread.sleep(2000);
            Functions.closeBannersAfterLogin(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while closing the maintenance banner : "+e);
        }
        
            System.out.println("Login success for Username:"+usrname);
     }
    
    public static void logout(WebDriver driver) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        
        driver.navigate().refresh();
        Thread.sleep(5000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdrpdwntop")));
        
        driver.findElement(By.id("hdrdrpdwntop")).click();
        
        Thread.sleep(1000);
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                           {
                               return true;
                           }
                           return false;
                       }
                   });
        
        driver.findElement(By.id("hdrdrpdwn")).findElement(By.cssSelector("[href='logout.sas']")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("header")));
        
        driver.findElement(By.className("header")).findElement(By.className("signin")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
    }
    
	public static boolean clickSettings(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
			WebElement settings = CommonUtil.elfinder(driver,"id","menu_setting");
			settings.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ClickSettings","Error",e);
			return false;
		}
	}
	public static boolean navToDeptTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_department")));
			WebElement dept = CommonUtil.elfinder(driver,"id","setting_sm_department");
			dept.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ClickDepartmentTab","Error",e);
			return false;
		}
	}

	public static boolean navToIntegTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_integration")));
			WebElement integ = CommonUtil.elfinder(driver,"id","setting_sm_integration");
			integ.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("integhome")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ClickIntegrationsTab","Error",e);
			return false;
		}
	}
	public static boolean navToEmbedTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));
			WebElement embed = CommonUtil.elfinder(driver,"id","setting_sm_embedchats");
			embed.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ClickWebEmbedTab","Error",e);
			return false;
		}
	}
	public static boolean navToAutoTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
			WebElement automation = CommonUtil.elfinder(driver,"id","setting_sm_automation");
			automation.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("autotabcontainer")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ClickAutomationTab","Error",e);
			return false;
		}
	}
	public static boolean navToTriggersTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!navToAutoTab(driver,etest))
				return false;
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotriggerstab")));
			WebElement triggers = CommonUtil.elfinder(driver,"classname","autotriggerstab");
			triggers.click();
			Thread.sleep(1500);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ClickTriggersTab","Error",e);
			return false;
		}
	}
	public static boolean addDept(WebDriver driver,String dept,ExtentTest etest) throws Exception{
		try{
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
	        
	        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings"));
	        
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_myprofile"))));
	        
	        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("settings_myprofile")).click();
	        
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("userdetails")));
	            
	        WebElement userdetails = CommonUtil.elfinder(driver,"id","userdetails");
	        
	        String user = userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();

	        Thread.sleep(1500);

			if(!navToDeptTab(driver,etest))
				return false;

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("buttonadddept")));
			CommonUtil.elfinder(driver,"id","buttonadddept").click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("moduleadd")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("moduleadd")));
			WebElement page = CommonUtil.elfinder(driver,"id","moduleadd");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("name")));
			WebElement name = CommonUtil.elementfinder(driver,page,"id","name");
			name.click();
			name.clear();
			name.sendKeys(dept);

			if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
			{
				WebElement elmt = driver.findElement(By.id("unassodeptlist"));

				CommonUtil.inViewPort(elmt);
				
				List<WebElement> elmts = elmt.findElements(By.className("associatesel"));

				for(WebElement element:elmts)
				{
					WebElement ptag;
					ptag = element.findElement(By.tagName("p"));
				
					if(user.equals(ptag.getText()))
					{
				        element.findElement(By.tagName("div")).click();
						break;
					}
				}
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".top_savebtn.deptaddbtn")));
			CommonUtil.elfinder(driver,"css",".top_savebtn.deptaddbtn").click();
			loading(driver,wait,"adddept.do",etest);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-list")));
			page = CommonUtil.elfinder(driver,"id","module-list");
			List<WebElement> depts = page.findElements(By.className("list-row"));
			for(WebElement e : depts)
				if(CommonUtil.elementfinder(driver,e,"classname","txtelips").getText().equals(dept))
					return true;
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","AddDepartment-"+dept,"AddedDepartmentIsNotPresent");
			return false;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","AddDepartment-"+dept,"Error",e);
			driver.navigate().refresh();
			Thread.sleep(4000);
			return false;
		}
	}
	public static boolean deleteDept(WebDriver driver,String dept,ExtentTest etest) throws Exception{
		try{
			if(!navToDeptTab(driver,etest))
				return false;
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-list")));
			final WebElement page = CommonUtil.elfinder(driver,"id","module-list");
			List<WebElement> depts = page.findElements(By.className("list-row"));
			for(WebElement e : depts)
			{
				if(CommonUtil.elementfinder(driver,e,"classname","txtelips").getText().equals(dept))
				{
					final int initialcount = depts.size();
					CommonUtil.mouseHover(driver,e);
					WebElement delete = CommonUtil.elementfinder(driver,e,"classname","list_lefticon");
					wait.until(ExpectedConditions.visibilityOf(delete));
					delete.click();
					wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
					WebElement popup = CommonUtil.elfinder(driver,"classname","lvd_popupsub");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("deptselect_div")));
					CommonUtil.elementfinder(driver,popup,"id","deptselect_div").click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("deptselect1")));
					CommonUtil.elementfinder(driver,popup,"id","deptselect1").click();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
					CommonUtil.elementfinder(driver,popup,"id","okbtn").click();
					wait.until(new Function<WebDriver,Boolean>(){
						public Boolean apply(WebDriver driver){
							if((initialcount-1)==page.findElements(By.className("list-row")).size())
								return true;
							return false;
						}
					});
					List<WebElement> depts1 = page.findElements(By.className("list-row"));
					for(WebElement ee : depts1)
						if(CommonUtil.elementfinder(driver,ee,"classname","txtelips").getText().equals(dept))
						{
							TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DeleteDepartment-"+dept,"DeletedDepartmentIsPresent");
							return false;	
						}
					etest.log(Status.PASS,"Department - "+dept+" is Deleted");
					return true;
				}
			}
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DeleteDepartment-"+dept,"DepartmentToBeDeletedIsNotPresent");
			return false;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","AddDepartment-"+dept,"Error",e);
			return false;
		}
	}
	public static boolean openApp(WebDriver driver,ExtentTest etest,String app){
		try{
			boolean appexists=false;
			List<WebElement> otherapps = driver.findElements(By.className("integ_linm"));
			for(WebElement e: otherapps){
				Coordinates ord = ((Locatable)e).getCoordinates();
				ord.inViewPort();
				System.out.println(e.getText());
				if(e.getText().contains(app)){
					e.click();
					appexists=true;
					break;
				}
			}
			if(!appexists){
				TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckApp-"+app,"AppNotPresent");
				return false;
			}
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckApp-"+app,"Error",e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public static void loading(WebDriver driver,FluentWait wait,String uri,ExtentTest etest) throws Exception
	{
        Tab.waitForLoading(driver,uri,etest);
	}
	public static void openVisitorWin(WebDriver driver,String widget_code) throws Exception
	{
		VisitorWindow.createPage(driver,widget_code);
    }
	
	public static void switchToChatWidget(WebDriver driver) throws Exception
    {
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","zlsiframe"));
    }
}
