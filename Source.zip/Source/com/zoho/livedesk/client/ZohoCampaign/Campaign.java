//$Id$
package com.zoho.livedesk.client.ZohoCampaign;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.Calendar;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.Websites;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;

public class Campaign {
    
    public static Hashtable result = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable LISTNAME = new Hashtable();
    private static String requrl = "";
	public static ExtentTest etest; 
	//public static WebDriver driver = null;
    public static Long time = new Long(System.currentTimeMillis());
    public static String WIDGET_CODE;
    
	public static Hashtable campaign(WebDriver driver)
	{
    	try{
    		WebDriver visDriver = null;
            result = new Hashtable();

            WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM1"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            CommonFunctions.navToIntegTab(driver,etest);

			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Campaigns']")));

			CommonUtil.elfinder(driver,"xpath","//div[text()='Zoho Campaigns']").click();      

            etest.log(Status.PASS,"Zoho Campaigns is present");

            result.put("CAM1",true);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM2"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM2",isPageAvailable(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM3"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM3",campaigndisable(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM4"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM4",campaignenable(driver));

            ComplexReportFactory.closeTest(etest);
			
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM5"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM5",checkFields(driver,"Visitor Name","Last Name",false,true));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM6"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM6",checkFields(driver,"Email","Contact Email",false,true));
			
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM10"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM10",addField(driver,"Phone","Phone"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM11"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM11",addField(driver,"State","State"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM12"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM12",addField(driver,"Country","Country"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM13"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM13",addField(driver,"City","City"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM14"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM14",deleteAllFields(driver,true));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM15"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM15",checkdropdown1(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM16"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM16",checkdropdown2(driver));
            deleteAllFields(driver,false);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM17"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM17",disableAndEnable(driver,"City"));
            deleteField(driver,"City",true);

            ComplexReportFactory.closeTest(etest);

		    etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM18"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM18",disableAndDelete(driver,"Country"));

            ComplexReportFactory.closeTest(etest);

		 //    etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM19"));
			// ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
   //          result.put("CAM19",checkDepartmentView(driver,false));

   //          ComplexReportFactory.closeTest(etest);

		    etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM20"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM20",checkConfigurationDetailsWithTwoDept(driver));
            CommonFunctions.deleteDept(driver,"Department1",etest);
            
            ComplexReportFactory.closeTest(etest);

		    etest=ComplexReportFactory.getTest("Zoho Campaign - Check identifier and Smart identifier");
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            checkIdentifierandShow(driver);
        
            ComplexReportFactory.closeTest(etest);
		    
		    etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM26"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM26",checkWithValidLink(driver));
            
            ComplexReportFactory.closeTest(etest);

		    etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM29"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM29",enableNewsletter(driver,"notallowed"));
            
            ComplexReportFactory.closeTest(etest);

		    etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM31"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            visDriver = CommonFunctions.setUp();
            result.put("CAM31",checkChatWidget(visDriver,true));
            visDriver.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM32"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
	        
	        visDriver = CommonFunctions.setUp();
	        result.put("CAM32",pushDataToCampaignsList(driver,visDriver,true,"notallowed",false));
	        driver.get(Util.siteNameout());
            Thread.sleep(3000);
	    	visDriver.quit();

	        ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM33"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            visDriver = CommonFunctions.setUp();
            result.put("CAM33",disableNewsletterAndCheck(driver,visDriver));
            visDriver.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM38"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
	        
	        visDriver = CommonFunctions.setUp();
	        result.put("CAM38",pushDataToCampaignsList(driver,visDriver,false,"notallowed",false));
	        driver.get(Util.siteNameout());
            Thread.sleep(3000);
	    	visDriver.quit();

	        ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM35"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM35",addListInTriggers(driver,"List"+time.toString(),"custdept_no",""));
            driver.get(Util.siteNameout());
            Thread.sleep(3000);

            ComplexReportFactory.closeTest(etest);

            if((boolean)result.get("CAM35"))
            {
	            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM39"));
				ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
	            
	            visDriver = CommonFunctions.setUp();
	            result.put("CAM39",pushDataToCampaignsList(driver,visDriver,true,(String)LISTNAME.get("None"),true));
	            visDriver.quit();
	            deleteCampaignList(driver);
	        	driver.get(Util.siteNameout());
	            accresDel(driver);
	            
	            ComplexReportFactory.closeTest(etest);
	        }

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM36"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM36",addListInTriggers(driver,"List"+time.toString(),"custdept_yes","custdept_1"));
            driver.get(Util.siteNameout());
            Thread.sleep(3000);

            ComplexReportFactory.closeTest(etest);

            if((boolean)result.get("CAM36"))
            {
	            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM40"));
				ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
	            
	            visDriver = CommonFunctions.setUp();
	            result.put("CAM40",pushDataToCampaignsList(driver,visDriver,true,(String)LISTNAME.get("Weekly"),true));
	            visDriver.quit();
	            deleteCampaignList(driver);
	        	driver.get(Util.siteNameout());
	            accresDel(driver);
	            
	            ComplexReportFactory.closeTest(etest);
	        }

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM37"));
			ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
            
            result.put("CAM37",addListInTriggers(driver,"List"+time.toString(),"custdept_yes","custdept_2"));
            driver.get(Util.siteNameout());
            Thread.sleep(3000);

            ComplexReportFactory.closeTest(etest);

            if((boolean)result.get("CAM37"))
            {
	            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CAM41"));
				ComplexReportFactory.setValues(etest,"Automation","ZohoCampaign Integration");
	            
	            visDriver = CommonFunctions.setUp();
	            result.put("CAM41",pushDataToCampaignsList(driver,visDriver,true,(String)LISTNAME.get("Monthly"),true));
	            visDriver.quit();
	            deleteCampaignList(driver);
	        	driver.get(Util.siteNameout());
	            accresDel(driver);
	            
	            ComplexReportFactory.closeTest(etest);
	        }

	        deleteCampaignList(driver);
	        accresDel(driver);
            //CommonFunctions.logout(driver);
            //driver.quit();
        }
    	catch(Exception e){
    		System.out.println("Error While checking Zoho Campaign Integration - "+e.toString());
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","IntegrationSettingsPage","Error",e);
    		result.put("CAM1",false);
    	}
        ComplexReportFactory.closeTest(etest);
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }
    public static boolean isPageAvailable(WebDriver driver)
    {
    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("integrationmain")));
			WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
			String desc = CommonUtil.elementfinder(driver,el,"classname","innersubinfotxt").getText();
			String desc1 = CommonUtil.elementfinder(driver,el,"classname","zc_cnfig_desc").getText();
			
			if(!(CommonUtil.checkStringcontains(desc,ResourceManager.getRealValue("zohocampaign_desc"),etest))
					&&!(CommonUtil.checkStringequals(desc1,ResourceManager.getRealValue("zohocampaign_configuration_desc"),etest)))
				return false;
			etest.log(Status.PASS,"ZohoCampaign Descriptions is checked");
			return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","IsPageAvailable","Error",e);
    		return false;
    	}
    }
    public static boolean campaigndisable(WebDriver driver)
    {
    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
            
            Integration.clickEnableIntegration(driver,"Zoho Campaigns Integration enabled successfully",etest);
            Integration.clickDisableIntegration(driver,"Zoho Campaigns Integration disabled successfully",etest);
            
			etest.log(Status.PASS,"ZohoCampaign is successfully disabled");
			return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","Disable","Error",e);
    		return false;
    	}
    }
    public static boolean campaignenable(WebDriver driver)
    {
    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
            
            Integration.clickDisableIntegration(driver,"Zoho Campaigns Integration disabled successfully",etest);
            Integration.clickEnableIntegration(driver,"Zoho Campaigns Integration enabled successfully",etest);
            
			etest.log(Status.PASS,"ZohoCampaign is successfully enabled");
			return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","Enable","Error",e);
    		return false;
    	}
    }
    public static boolean checkFieldsList(WebDriver driver,List<WebElement> list,String field[])
    {
    	try
    	{
    		boolean exists = false;
    		
    		for(String s : field)
    		{
				exists = false;
				for(WebElement e : list)
    			{
    				if(e.getText().contains(s))
						exists = true;
				}
				if(!exists)
				{
					TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckFieldsList",s+"IsNotPresent");
    				return false;	
				}
			}
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckFieldsList","Error",e);
    		return false;
    	}
    }public static boolean checkFields(WebDriver driver,String col1,String col2,boolean access,boolean screenshot)
    {
    	try
    	{
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
			WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configtable")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("configtable")));
			List<WebElement> list = CommonUtil.elementfinder(driver,el,"id","configtable").findElements(By.className("list-row"));
			for(WebElement e : list){
				int count = list.indexOf(e);
				CommonUtil.inViewPort(e);
				if(e.getText().contains(col1))
				{
					if(!screenshot)
					{
						TakeScreenshot.screenshot(driver,etest,"ZohoCampaign",col1+"Field","IsPresent");
		    			return false;
		    		}
					WebElement salesiq = CommonUtil.elementfinder(driver,e,"id","col1_"+count);
					WebElement campaign = CommonUtil.elementfinder(driver,e,"id","col2_"+count);
					if(CommonUtil.checkStringequals(salesiq.getText(),col1,etest)&&CommonUtil.checkStringequals(campaign.getText(),col2,etest))
					{
						etest.log(Status.INFO,col1+" and "+col2+" are present");
						return checkFieldsAccess(driver,e,access);
					}
					return false;
				}
			}
			if(screenshot)
			{
				TakeScreenshot.screenshot(driver,etest,"ZohoCampaign",col1+"Field","IsNotPresent");
    			return false;
    		}
    		else
    		{
    			etest.log(Status.PASS,col1+" is not present");
    			return true;
    		}
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign",col1+"Fields","Error",e);
    		return false;
    	}
    }
    public static boolean checkFieldsAccess(WebDriver driver,WebElement element,boolean exists)
    {
    	boolean presence = false;
    	try
    	{
    		CommonUtil.mouseHover(driver,element);
    		Thread.sleep(1000);
    		try
    		{
    			WebElement disable = CommonUtil.elementfinder(driver,element,"classname","sqico-enable");
    			WebElement delete = CommonUtil.elementfinder(driver,element,"classname","sqico-delico");
    			if(disable.isDisplayed()&&delete.isDisplayed())
    				presence = true;
    		}
    		catch(Exception e){}
    		if(exists == presence)
    			return true;

    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckDisableAndDeleteInFields","MismatchInPresence");
    		return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckDisableAndDeleteInFields","Error",e);
    		return false;
    	}
    }
    public static boolean addField(WebDriver driver,String col1,String col2)
    {
    	try
    	{
    		String dropdownlist[] = {"Phone","City","State","Country"}; 
    		if(col1.equals("Phone"))
    		{
    			result.put("CAM7",false);
	    		result.put("CAM8",false);
	    		result.put("CAM9",false);
	    	}
	    	if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		final WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		final int initialcount = el.findElements(By.className("list-row")).size();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".floatrg.paddingtop15")));
			WebElement add = CommonUtil.elementfinder(driver,el,"css",".floatrg.paddingtop15");
			CommonUtil.inViewPort(add);
            HandleCommonUI.hideSeasonalFloat(driver);
			add.click();
			result.put("CAM7",true);
    		
			wait.until(new Function<WebDriver, Boolean>()
			{
					public Boolean apply(WebDriver driver)
					{
						int finalcount = el.findElements(By.className("list-row")).size();
						if(finalcount>initialcount)
							return true;
						return false;
					}
			});
			List<WebElement> list = el.findElements(By.className("list-row"));
			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				if(list.indexOf(e)==initialcount)
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id("col1_"+(list.size()-1))));
					final WebElement column = CommonUtil.elementfinder(driver,el,"id","col1_"+(list.size()-1));
					wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								try
								{
									CommonUtil.elementfinder(driver,column,"css",".combotitle.bxsizing.drphead");
									return true;
								}
								catch(Exception e)
								{
									return false;
								}
							}
					});
					WebElement drpdwn = CommonUtil.elementfinder(driver,column,"css",".combotitle.bxsizing.drphead");
					drpdwn.click();
					wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								try
								{
									CommonUtil.elementfinder(driver,column,"classname","ullist");
									return true;
								}
								catch(Exception e)
								{
									return false;
								}
							}
					});
					WebElement drpdwnlist = CommonUtil.elementfinder(driver,column,"classname","ullist");
					wait.until(ExpectedConditions.visibilityOf(drpdwnlist));
					List<WebElement> list1 = drpdwnlist.findElements(By.tagName("li"));
					if(col1.equals("Phone")&&!checkFieldsList(driver,list1,dropdownlist))
						return false;
					result.put("CAM8",true);
					for(WebElement e1 : list1)
					{
						if(e1.getText().equals(col1))
                        {
                            e1.click();
                            break;
                        }
					}
				}
			}

			Thread.sleep(1000);
			List<WebElement> list2 = el.findElements(By.className("list-row"));
			for(WebElement e : list2)
			{
				CommonUtil.inViewPort(e);
				if(list2.indexOf(e)==initialcount)
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id("col2_"+(list2.size()-1))));
					final WebElement column = CommonUtil.elementfinder(driver,el,"id","col2_"+(list.size()-1));
					wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								try
								{
									CommonUtil.elementfinder(driver,column,"css",".combotitle.bxsizing.drphead");
									return true;
								}
								catch(Exception e)
								{
									return false;
								}
							}
					});
					WebElement drpdwn = CommonUtil.elementfinder(driver,column,"css",".combotitle.bxsizing.drphead");
					drpdwn.click();
					wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								try
								{
									CommonUtil.elementfinder(driver,column,"classname","ullist");
									return true;
								}
								catch(Exception e)
								{
									return false;
								}
							}
					});
					WebElement drpdwnlist = CommonUtil.elementfinder(driver,column,"classname","ullist");
					wait.until(ExpectedConditions.visibilityOf(drpdwnlist));
					List<WebElement> list1 = drpdwnlist.findElements(By.tagName("li"));
					if(col1.equals("Phone")&&!checkFieldsList(driver,list1,dropdownlist))
						return false;
					result.put("CAM9",true);
					for(WebElement e1 : list1)
					{
						if(e1.getText().equals(col2))
                        {
                            e1.click();
                            break;
                        }
					}
				}
			}

			Thread.sleep(1000);
			return checkFields(driver,col1,col2,true,true);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","AddField-"+col1,"Error",e);
    		return false;
    	}
    }
    public static boolean deleteAllFields(WebDriver driver,boolean check)
    {
    	try
    	{
	    	if(deleteField(driver,"Phone",check)&deleteField(driver,"City",check)&deleteField(driver,"State",check)&deleteField(driver,"Country",check))
	    		return true;
	    }
	    catch(Exception e){}
    	return false;
    }
    public static boolean deleteField(WebDriver driver,String field,boolean check)
    {
    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		final WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configtable")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("configtable")));
			List<WebElement> list = CommonUtil.elementfinder(driver,el,"id","configtable").findElements(By.className("list-row"));
    		final int initialcount = list.size();
			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				if(e.getText().contains(field))
				{
					CommonUtil.mouseHover(driver,e);
	    			WebElement delete = CommonUtil.elementfinder(driver,e,"classname","sqico-delico");
	    			delete.click();
	    			wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								int finalcount = el.findElements(By.className("list-row")).size();
								if(finalcount==(initialcount - 1))
									return true;
								return false;
							}
					});
					etest.log(Status.PASS,field+" is deleted");
					return checkFields(driver,field,field,false,false);
    			}
    		}
    		if(check)
    			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DeleteField-"+field,"ToBeDeletedIsNotPresent");
    		return false;
    	}
    	catch(Exception e)
    	{
    		if(check)
    			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DeleteField-"+field,"Error",e);
    		return false;
    	}
    }
    public static boolean checkdropdown1(WebDriver driver)
    {
    	try
    	{
    		String dropdownlist[] = {"State","Phone","City"};
    		if(!addField(driver,"Country","Country"))
    			return false;
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		final WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		final int initialcount = el.findElements(By.className("list-row")).size();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".floatrg.paddingtop15")));
			WebElement add = CommonUtil.elementfinder(driver,el,"css",".floatrg.paddingtop15");
			CommonUtil.inViewPort(add);
			add.click();
			
			wait.until(new Function<WebDriver, Boolean>()
			{
					public Boolean apply(WebDriver driver)
					{
						int finalcount = el.findElements(By.className("list-row")).size();
						if(finalcount>initialcount)
							return true;
						return false;
					}
			});
    			
    		List<WebElement> list = el.findElements(By.className("list-row"));
			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				if(list.indexOf(e)==initialcount)
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id("col1_"+(list.size()-1))));
					WebElement drpdwn = CommonUtil.elementfinder(driver,e,"css",".combotitle.bxsizing.drphead");
					drpdwn.click();
					WebElement drpdwnlist = CommonUtil.elementfinder(driver,e,"classname","ullist");
					wait.until(ExpectedConditions.visibilityOf(drpdwnlist));
					List<WebElement> list1 = drpdwnlist.findElements(By.tagName("li"));
					return checkFieldsList(driver,list1,dropdownlist);
				}
			}
			return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ModifyFieldAndCheckDropDown","Error",e);
    		return false;
    	}
    }
    public static boolean changeField(WebDriver driver,String col1,String col2)
    {
    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		CommonUtil.inViewPort(CommonUtil.elementfinder(driver,el,"id","col1_3"));
    		CommonUtil.elementfinder(driver,el,"id","col1_3").click();
    		WebElement drpdwnlist = CommonUtil.elementfinder(driver,el,"classname","ullist");
			wait.until(ExpectedConditions.visibilityOf(drpdwnlist));
			List<WebElement> list1 = drpdwnlist.findElements(By.tagName("li"));
			for(WebElement e1 : list1)
			{
				if(e1.getText().equals(col1))
                {
                    e1.click();
                    break;
                }
			}
    		Thread.sleep(1000);
			List<WebElement> list2 = el.findElements(By.className("list-row"));
			for(WebElement e : list2)
			{
				CommonUtil.inViewPort(e);
				if(list2.indexOf(e)==list2.size()-1)
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id("col2_"+(list2.size()-1))));
					final WebElement column = CommonUtil.elementfinder(driver,el,"id","col2_"+(list2.size()-1));
					wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								try
								{
									CommonUtil.elementfinder(driver,column,"css",".combotitle.bxsizing.drphead");
									return true;
								}
								catch(Exception e)
								{
									return false;
								}
							}
					});
					WebElement drpdwn = CommonUtil.elementfinder(driver,column,"css",".combotitle.bxsizing.drphead");
					drpdwn.click();
					wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								try
								{
									CommonUtil.elementfinder(driver,column,"classname","ullist");
									return true;
								}
								catch(Exception e)
								{
									return false;
								}
							}
					});
					WebElement drpdwnlist1 = CommonUtil.elementfinder(driver,column,"classname","ullist");
					wait.until(ExpectedConditions.visibilityOf(drpdwnlist1));
					List<WebElement> list3 = drpdwnlist1.findElements(By.tagName("li"));
					for(WebElement e1 : list3)
					{
						if(e1.getText().equals(col2))
                        {
                            e1.click();
                            break;
                        }
					}
				}
			}

			Thread.sleep(1000);
			return true;
		}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ModifyFieldValue","Error",e);
    		return false;
    	}
    }
    public static boolean checkdropdown2(WebDriver driver)
    {
    	try
    	{
    		String dropdownlist[] = {"Phone","Country","City"};
    		if(!changeField(driver,"State","State"))
    			return false;
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		final WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		final int initialcount = el.findElements(By.className("list-row")).size();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".floatrg.paddingtop15")));
			WebElement add = CommonUtil.elementfinder(driver,el,"css",".floatrg.paddingtop15");
			CommonUtil.inViewPort(add);
			add.click();
			
			wait.until(new Function<WebDriver, Boolean>()
			{
					public Boolean apply(WebDriver driver)
					{
						int finalcount = el.findElements(By.className("list-row")).size();
						if(finalcount>initialcount)
							return true;
						return false;
					}
			});
    			
    		List<WebElement> list = el.findElements(By.className("list-row"));
			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				if(list.indexOf(e)==initialcount)
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id("col1_"+(list.size()-1))));
					WebElement drpdwn = CommonUtil.elementfinder(driver,e,"css",".combotitle.bxsizing.drphead");
					drpdwn.click();
					WebElement drpdwnlist = CommonUtil.elementfinder(driver,e,"classname","ullist");
					wait.until(ExpectedConditions.visibilityOf(drpdwnlist));
					List<WebElement> list1 = drpdwnlist.findElements(By.tagName("li"));
					return checkFieldsList(driver,list1,dropdownlist);
				}
			}
			return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","ModifyFieldAndCheckDropDown","Error",e);
    		return false;
    	}
    }
    public static boolean disableField(WebDriver driver,String field)
    {
    	    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		final WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configtable")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("configtable")));
			List<WebElement> list = CommonUtil.elementfinder(driver,el,"id","configtable").findElements(By.className("list-row"));
    		final int initialcount = list.size();
			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				if(e.getText().contains(field))
				{
					CommonUtil.mouseHover(driver,e);
	    			WebElement disable = CommonUtil.elementfinder(driver,e,"classname","sqico-enable");
	    			disable.click();
	    			final WebElement ee = e;
	    			wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								String check = ee.getAttribute("className");
								if(check.contains("greyout"))
									return true;
								return false;
							}
					});
					etest.log(Status.PASS,field+" is Disabled");
					return true;
    			}
    		}
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DisableField-"+field,"ToBeDisabledIsNotPresent");
    		return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DisableField-"+field,"Error",e);
    		return false;
    	}
    }
    public static boolean enableField(WebDriver driver,String field)
    {
    	    	try
    	{
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		final WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configtable")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("configtable")));
			List<WebElement> list = CommonUtil.elementfinder(driver,el,"id","configtable").findElements(By.className("list-row"));
    		final int initialcount = list.size();
			for(WebElement e : list)
			{
				CommonUtil.inViewPort(e);
				if(e.getText().contains(field))
				{
					CommonUtil.mouseHover(driver,e);
	    			WebElement enable = CommonUtil.elementfinder(driver,e,"classname","sqico-enable");
	    			enable.click();
	    			final WebElement ee = e; 
	    			wait.until(new Function<WebDriver, Boolean>()
					{
							public Boolean apply(WebDriver driver)
							{
								String check = ee.getAttribute("className");
								if(check.contains("greyout"))
									return false;
								return true;
							}
					});
					etest.log(Status.PASS,field+" is Enabled");
					return true;
    			}
    		}
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","EnableField-"+field,"ToBeEnabledIsNotPresent");
    		return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","EnableField-"+field,"Error",e);
    		return false;
    	}
    }
    public static boolean disableAndEnable(WebDriver driver,String field)
    {
    	if(addField(driver,field,field))
    		if(disableField(driver,field))
    			if(enableField(driver,field))
    				return true;
    	return false;
    }
    public static boolean disableAndDelete(WebDriver driver,String field)
    {
    	if(addField(driver,field,field))
    		if(disableField(driver,field))
    			if(deleteField(driver,field,true))
    				return true;
    	return false;
    }
    public static boolean checkDepartmentView(WebDriver driver,boolean exists)
    {
    	try
    	{
            CommonFunctions.navToIntegTab(driver,etest);
            CommonFunctions.openApp(driver,etest,"Zoho Campaigns");
            CommonUtil.scrollIntoView(driver,true,By.id("integrationmain"),By.cssSelector("input[name='department']"));
            TakeScreenshot.infoScreenshot(driver,etest);

            if(CommonWait.isPresent(driver,By.id("integrationmain"),By.cssSelector("input[name='department']"))==exists)
            {
                etest.log(Status.PASS,"Campaigns Configuration Details - Department presence :"+exists);
                return true;
            }

            etest.log(Status.FAIL,"Campaigns Configuration Details - Department presence :"+(!exists));
            TakeScreenshot.screenshot(driver,etest);
            return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckDepartmentAccessInZohoCampiagns","Error",e);
    		return false;
    	}
    }
    public static boolean checkConfigurationDetailsWithTwoDept(WebDriver driver) throws Exception
	{
        CommonFunctions.addDept(driver,"Department1",etest);
        return checkDepartmentView(driver,true);
	} 
	public static boolean checkIdentifierandShow(WebDriver driver)
	{
		try
		{
			result.put("CAM21",false);
			result.put("CAM22",false);
			result.put("CAM23",false);
			result.put("CAM28",false);
			result.put("CAM24",false);
            result.put("CAM25",false);
			boolean presence = false;
    		if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("campbtm")));
    		CommonUtil.inViewPort(CommonUtil.elementfinder(driver,el,"classname","campbtm"));
    		WebElement bottom = CommonUtil.elementfinder(driver,el,"classname","campbtm");
    		WebElement identifier = CommonUtil.elementfinder(driver,bottom,"classname","idite_txt");
    		try
    		{
    			if(identifier.isDisplayed())
    				presence = true;
    		}
    		catch(Exception e){}
    		if(presence)
    		{
    			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckIdentifierAndShow","IdentifierIsPresentWithoutClickingShow");
    			return false;
    		}
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("tgidntfy")));
            CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(bottom,By.className("tgidntfy")));
    		CommonUtil.elementfinder(driver,bottom,"classname","tgidntfy").click();
    		wait.until(ExpectedConditions.visibilityOf(identifier));
    		WebElement link = CommonUtil.elementfinder(driver,identifier,"id","camplinkinput");
    		result.put("CAM21",true);
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("identifi_input")));
    		CommonUtil.inViewPort(CommonUtil.elementfinder(driver,identifier,"id","identifi_input"));
    		result.put("CAM22",true);
    		etest.log(Status.PASS,"Identifier and Smart identifier are present");
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_gbutclor")));
    		CommonUtil.inViewPort(CommonUtil.elementfinder(driver,identifier,"classname","cmn_gbutclor"));
    		identifier = CommonUtil.elementfinder(driver,bottom,"classname","idite_txt");
    		System.out.println("qwerty"+identifier.getText());
    		List<WebElement> list = identifier.findElements(By.cssSelector(".cmn_txt.mrgntop30"));
    		boolean check = false;
    		for(WebElement e : list)
    		{
    			CommonUtil.inViewPort(e);
    			System.out.println(".cmn_txt.mrgntop30--"+e.getText());
    			if(e.getText().contains(ResourceManager.getRealValue("zohocampaign_identifier_desc")))
	    		{
	    			check = true;
	    			result.put("CAM23",true);
	    			etest.log(Status.PASS,"Identifier description is checked and Generate Icon is present");
	    		}
    		}
    		if(!check)
    		{
    			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckIdentifierAndShow","MismatchIdentifierDescription");
    		}
			list = identifier.findElements(By.cssSelector(".cmn_txt.mrgntop30"));
    		boolean check1 = false;
    		check = false;
    		for(WebElement e : list)
    		{
    			CommonUtil.inViewPort(e);
    			System.out.println(".cmn_txt.mrgntop30--"+e.getText());
    			if(e.getText().contains(ResourceManager.getRealValue("zohocampaign_smartidentifier_desc")))
	    		{
	    			check = true;
	    		}
	    		if(e.getText().contains(ResourceManager.getRealValue("zohocampaign_smartidentifier_noteheader"))&&
	    			e.getText().contains(ResourceManager.getRealValue("zohocampaign_smartidentifier_note1"))&&
	    			e.getText().contains(ResourceManager.getRealValue("zohocampaign_smartidentifier_note2")))
	    		{
	    			check1 = true;
	    		}
	    	}
	    	if(check && check1)
	    	{
    			result.put("CAM28",true);
    			etest.log(Status.PASS,"Smart Identifier description and Note are checked");
	    	}
    		else
    		{
    			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckIdentifierAndShow","MismatchSmartIdentifierDescriptionAndNote");
    		}
    		generatelink(driver,"hello");
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("err_em")));
    		result.put("CAM24",true);
    		etest.log(Status.PASS,"Invalid URL alert is found");
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("clearinput")));
    		CommonUtil.elfinder(driver,"id","clearinput").click();
    		result.put("CAM25",true);
    		etest.log(Status.PASS,"Clear Icon is present and clicked");
    		return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckIdentifierAndShow","Error",e);
    		return false;
		}
	}
	public static void generatelink(WebDriver driver,String web) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    	WebElement link = CommonUtil.elfinder(driver,"id","camplinkinput");
        WebElement generate=com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(driver.findElements(By.className("cmn_gbutclor")),"campaign","campaigns");
		CommonUtil.inViewPort(link);
		wait.until(ExpectedConditions.visibilityOf(link));
		Thread.sleep(500);
		link.click();
		link.sendKeys(web);
		generate.click();
	}  
	public static boolean checkWithValidLink(WebDriver driver)
	{
		try
		{
			if(!CommonFunctions.navToIntegTab(driver,etest))
				{
					return false;
				}
			if(!CommonFunctions.openApp(driver,etest,"Zoho Campaigns"))
			{
				return false;
			}
    		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    		WebElement el = CommonUtil.elfinder(driver,"id","integrationmain");
    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("campbtm")));
    		CommonUtil.inViewPort(CommonUtil.elfinder(driver,"classname","campbtm"));
    		CommonUtil.inViewPort(CommonUtil.elfinder(driver,"classname","tgidntfy"));
    		CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","campbtm"),"classname","tgidntfy").click();
    		WebElement identifier = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","campbtm"),"classname","idite_txt");
    		wait.until(ExpectedConditions.visibilityOf(identifier));
    		generatelink(driver,"https://www.yourlink.com");
    		Thread.sleep(1500);
    		CommonUtil.inViewPort(CommonUtil.elfinder(driver,"id","urlgeneratediv"));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("urlgeneratediv")));
    		WebElement generatediv = CommonUtil.elfinder(driver,"id","urlgeneratediv");
            
//    		WebElement copy = CommonUtil.elementfinder(driver,generatediv,"tagname","span");
//    		CommonUtil.inViewPort(copy);
//    		copy.click();
//    		final WebElement ee = copy;
//    		wait.until(new Function<WebDriver,Boolean>()
//			{
//				public Boolean apply(WebDriver driver)
//				{
//					if(ee.getText().equals("Copied"))
//						return true;
//					return false;
//				}
//			});
//    		Clipboard clipboard1 = Toolkit.getDefaultToolkit().getSystemClipboard();
//		    Transferable clipData1 = clipboard1.getContents(clipboard1);
//		    String content = (String)(clipData1.getTransferData(DataFlavor.stringFlavor));
            
            String content = CommonUtil.elementfinder(driver,generatediv,"tagname","input").getAttribute("value");
            
		    if(!CommonUtil.checkStringequals(content,"https://www.yourlink.com?siq_name=$[FNAME]$ $[LNAME]$&siq_email=$[EMAIL]$",etest))
		    	return false;
		    etest.log(Status.PASS,"Valid Link is generated and checked");
    		return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckGenerateIconWithValidLink","Error",e);
    		return false;
		}
	} 
	public static boolean enableNewsletter(WebDriver driver,String listname)
	{
		try
		{
			navToWebsitesNewsLetter(driver,ExecuteStatements.getDefaultEmbedName(driver),etest);
            Websites.editNewsLetter(driver,etest);
            //popup operations
            FluentWait wait = CommonUtil.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
			WebElement popup = CommonUtil.elfinder(driver,"classname","lvd_popupsub");
			String header = CommonUtil.elementfinder(driver,popup,"classname","lvd_popuptitle").getText();
			String desc = CommonUtil.elementfinder(driver,popup,"id","popupdesc").getText();
			if(!CommonUtil.checkStringequals(header,ResourceManager.getRealValue("zohocampaign_newsletter_header"),etest)
				&&!CommonUtil.checkStringcontains(desc,ResourceManager.getRealValue("zohocampaign_newsletter_desc"),etest)
				 &&!CommonUtil.checkStringcontains(desc,ResourceManager.getRealValue("zohocampaign_newsletter_desc1"),etest))
				return false;
			CommonUtil.elementfinder(driver,popup,"id","dlgclose");
			CommonUtil.elementfinder(driver,popup,"id","cancelbtn");
			CommonUtil.elementfinder(driver,popup,"id","okbtn");
			CommonUtil.elementfinder(driver,popup,"id","syncinput_div").click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("ullist")));
			WebElement campaignlist = CommonUtil.elementfinder(driver,popup,"classname","ullist");
			CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,popup,"classname","ullist"),"tagname","li");
            Thread.sleep(500);
            List<WebElement> list1 = campaignlist.findElements(By.tagName("li"));
            for(WebElement e : list1)
            {
            	if(CommonUtil.elementfinder(driver,e,"tagname","span").getText().equals(listname))
            	{
            		e.click();
            		Thread.sleep(500);
					CommonUtil.elementfinder(driver,popup,"id","okbtn").click();
                    Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
					etest.log(Status.INFO,"Newsletter is successfully enabled");
                    WebsitesTab.closeEmbedConfig(driver,etest);
					return true;
            	}
            }

            etest.log(Status.FAIL,listname+" is not present");
            TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","EnableNewsLetter","Error");
            WebsitesTab.closeEmbedConfig(driver,etest);
            return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","EnableNewsLetter","Error",e);
			driver.navigate().refresh();
    		return false;
		}
	}
	public static boolean disableNewsLetter(WebDriver driver) throws Exception
	{
        navToWebsitesNewsLetter(driver,ExecuteStatements.getDefaultEmbedName(driver),etest);
        //remove newletter
        Websites.clickRemoveInNewsLetter(driver,etest);
        Websites.clickSave(driver,etest);
        WebsitesTab.closeEmbedConfig(driver,etest);
        etest.log(Status.INFO,"Newsletter is successfully disabled");
		return true;
			
	}
	public static boolean disableNewsletterAndCheck(WebDriver driver,WebDriver visDriver)
	{
		try
		{
			if(!disableNewsLetter(driver))
			{
				return false;
			}

			if(!checkChatWidget(visDriver,false))
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoCampaign","DisableNewsLetter","Error");
			    return false;
            }

			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DisableNewsLetter","Error",e);
    		return false;
		}
	}
	public static boolean pushDataToCampaignsList(WebDriver driver,WebDriver visDriver,boolean enable,String listname,boolean needtowait)
	{
		Long t = new Long(System.currentTimeMillis());
		String s = t.toString();
		String vemail = "email@"+s+".com";

		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			if(!enableNewsletter(driver,listname))
			{
				return false;
			}
			
			try
			{
				CommonFunctions.openVisitorWin(visDriver,WIDGET_CODE);
				
				if(enable)
				{
					VisitorWindow.clickCampaignCheckBoxInTheme(visDriver);
				}

				
				VisitorWindow.initiateChatVisTheme(visDriver,"Vis"+s,vemail,"12345","Ques"+s,etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"ZohoCampaign","PushDataToCampaigns","Error",e);
    			return false;
			}

			if(needtowait)
			{
				visDriver.get("data:,");
                ChatWindow.ignoreChat(driver);
				// Thread.sleep(65000);
			}

			Thread.sleep(30000);

			CommonUtil.elementfinder(driver,getListFromCampaigns(driver,listname),"partiallinktext",listname).click();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("showSubscribers")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("showSubscribers")));

			Thread.sleep(1000);

			CommonUtil.elfinder(driver,"id","showSubscribers").click();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leftFieldsContainer")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("leftFieldsContainer")));

			try
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='leftFieldsContainer']//a[contains(.//text(),'"+vemail+"')]")));
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='leftFieldsContainer']//a[contains(.//text(),'"+vemail+"')]")));
			
				if(!enable && !needtowait)
				{
					TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","PushDataToCampaigns","VisitorIsPresent");
    				return false;
				}
			}
			catch(Exception e)
			{
				if(enable || needtowait)
					throw e;
			}
			
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","PushDataToCampaigns","Error",e);
    		return false;
		}
	}
	public static boolean checkChatWidget(WebDriver driver,boolean presence )
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.openVisitorWin(driver,WIDGET_CODE);
			
            try
            {
                VisitorWindow.checkCampaignPresenceInTheme(driver);
                
                WebElement checkbox = CommonUtil.elfinder(driver,"id","newsletter");
                String text = CommonUtil.elfinder(driver,"classname","siq-checkbox-label").getText();
                
                if(!CommonUtil.checkStringcontains(text,ResourceManager.getRealValue("zohocampaign_newsletter_desc1"),etest))
                    return false;
                
                etest.log(Status.PASS,"Newsletter is checked in chat widget");
                return true;
            }
            catch(Exception e)
            {
                if(presence)
                    throw e;
                etest.log(Status.PASS,"Newsletter is not present in chat widget");
                return true;
            }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","CheckChatWidget","Error",e);
    		return false;
		}
	}
	public static boolean addListInTriggers(WebDriver driver,String name,String period1,String period2) throws Exception
	{
		try
		{
			if(!CommonFunctions.navToTriggersTab(driver,etest))
			{
				return false;
			}
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			final WebElement page = CommonUtil.elfinder(driver,"id","trouting");

			Trigger.clickAdd(driver,etest);
			
            WebElement trigger = page.findElements(By.className("data_row")).get(0);
			String id = trigger.getAttribute("ruleid");
            Rules.openRuleEditView(driver,id);
			CommonUtil.elfinder(driver,"id","triggerevent_"+id+"_div").click();
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("triggerevent_"+id+"0")));
    		WebElement ulist = CommonUtil.elfinder(driver,"id","triggerevent_"+id+"0");
    		for(WebElement e : ulist.findElements(By.tagName("li")))
    		{
    			if(e.getText().contains("Leaves my website"))
    			{
    				e.click();
    			}
    		}
    		Thread.sleep(500);
    		CommonUtil.elfinder(driver,"id","action_"+id).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("action_"+id+"_ddown")));
			CommonUtil.inViewPort(CommonUtil.elfinder(driver,"id","action_"+id+"1"));
			CommonUtil.elfinder(driver,"id","action_"+id+"1").click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
    		// WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Campaign");
    		com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("cmpnew")).click();
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addmaildiv")));
    		CommonUtil.elementfinder(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("addmaildiv")),"id","syncinput").click();
    		CommonUtil.elementfinder(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("addmaildiv")),"id","syncinput").sendKeys(name);
    		com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id(period1)).click();

    		if(period1.contains("yes"))
    		{
    			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("intvdiv")));
    			com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id(period2)).click();
    		}
    		com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("dlgclose"));
    		com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("cancelbtn"));
    		com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("okbtn")).click();
            Rules.saveRule(driver,etest,id);
    		etest.log(Status.INFO,"Successfully addded ");

    		String listname = name;
    		String period = "None";

    		if(period2.equals("custdept_1"))
    		{
    			listname = listname+" "+getWeek()+" "+Calendar.getInstance().get(Calendar.YEAR);
    			period = "Weekly";
    		}
    		else if(period2.equals("custdept_2"))
    		{
                Calendar now = Calendar.getInstance();
                listname = listname+" "+theMonth(now.get(Calendar.MONTH))+" "+Calendar.getInstance().get(Calendar.YEAR);
                period = "Monthly";
    		}

            CommonUtil.sleep(5000);
    		
    		if(getListFromCampaigns(driver,listname) == null)
    		{
    			etest.log(Status.FAIL,listname+" is not present");
    			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","AddListInTriggers","Error");
    			return false;
    		}

    		LISTNAME.put(period,listname);
    		etest.log(Status.PASS,"Checked");
    		return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","AddListInTriggers","Error",e);
			driver.navigate().refresh();
			Thread.sleep(5000);
    		return false;
		}
	}

	public static String getWeek()
	{
		Calendar now = Calendar.getInstance();
		int i = now.get(Calendar.WEEK_OF_MONTH);
		int j = now.get(Calendar.MONTH);
		String week = ""+i;
		switch(week)
		{
			case "1": return "1st week of "+theMonth(j);
			case "2": return "2nd week of "+theMonth(j);
			case "3": return "3rd week of "+theMonth(j);
			case "4": return "4th week of "+theMonth(j);
			case "5": return "5th week of "+theMonth(j);
            case "6": return "6th week of "+theMonth(j);
			default : return "cannot be determined";
		}
	}

	public static String theMonth(int month){
	    String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	    return monthNames[month];
	}
	public static WebElement getListFromCampaigns(WebDriver driver,String listname) throws Exception
	{
		String siteName = Util.siteNameout();
			
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        String url = "https://campaigns.zoho.com/campaigns/home.do#contacts/list";
        if(siteName.contains("salesiq.localzoho.com"))
        {
            url = "https://campaigns.localzoho.com/campaigns/home.do#contacts/list";//https://campaigns.localzoho.com/home.do#list/all
        }

        driver.get(url);

        if(!driver.getCurrentUrl().contains("#contacts/list"))
        {
            driver.get(url);
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("listviewlists")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("listviewlists")));

        List<WebElement> list = driver.findElements(By.tagName("listviewlists"));

        for(WebElement e : list)
        {
        	CommonUtil.inViewPort(e);
        	if(e.getText().contains(listname))
        	{
        		return e;
        	}
        }

        return null;
	}

	public static void deleteCampaignList(WebDriver driver)
	{
		String siteName = Util.siteNameout();
			
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            String url = "https://campaigns.zoho.com/campaigns/home.do#contacts/list";
            if(siteName.contains("salesiq.localzoho.com"))
            {
                url = "https://campaigns.localzoho.com/campaigns/home.do#contacts/list";
            }

            driver.get(url);

            driver.navigate().refresh();
            
            Thread.sleep(4000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("listviewlists")));
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("listviewlists")));

	        int j = driver.findElements(By.tagName("listviewlists")).size();
            for(int i = 1;i<j;i++)
            {
	            wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("listviewlists")));
	            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("listviewlists")));

	            List<WebElement> list = driver.findElements(By.tagName("listviewlists"));
	            System.out.println("ZohoCampaign--DeleteCampaignsList--"+list.size());
	            for(WebElement e : list)
	            {
	            	CommonUtil.inViewPort(e);
	            	System.out.println("ZohoCampaign--DeleteCampaignsList--"+list.size());
	            	System.out.println(e.getText());
	            	if(!(e.getText().contains("notallowed")))
	            	{
	            		CommonUtil.mouseHover(driver,e);
	            		CommonUtil.elementfinder(driver,e,"linktext","More Actions").click();
	            		String id = CommonUtil.elementfinder(driver,e,"tagname","div").getAttribute("id").replace("edit_","otherAct_");
	            		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
	            		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
	            		CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id",id),"linktext","Delete List").click();
	            		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zcConfirmPanel")));
	            		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zcConfirmPanel")));
	            		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zcConfirmOK")));
	            		CommonUtil.elfinder(driver,"id","zcConfirmOK").click();
	            		
	            		wait.until(new Function<WebDriver, Boolean>()
						{
								public Boolean apply(WebDriver driver)
								{
									String style = driver.findElement(By.id("ajaxLoadingImage")).getAttribute("style");
									if(style.contains("none"))
										return true;
									return false;
								}
						});

						wait.until(new Function<WebDriver, Boolean>()
						{
								public Boolean apply(WebDriver driver)
								{
									String style = driver.findElement(By.id("outPutDiv")).getAttribute("style");
									if(!style.contains("opacity"))
										return true;
									return false;
								}
						});

	            		break;
	            	}
	            }
	        }

	        driver.get(Util.siteNameout());
		}
		catch(Exception e)
		{
			System.out.println("ZohoCampaign--DeleteCampaignsList--Error");
			e.printStackTrace();
			driver.get(Util.siteNameout());
			//TakeScreenshot.screenshot(driver,etest,"ZohoCampaign","DelteCampaignsList","Error",e);
		}
	}
	// private static void swindows(WebDriver driver)
 //    {
 //        try
 //        {
 //            Thread.sleep(1000);
            
 //            String mainwindow = driver.getWindowHandle();
 //            Set<String> windows = driver.getWindowHandles();
            
 //            String currwindow = (((JavascriptExecutor) driver).executeScript("return window.document.title")).toString();
            
 //            System.out.println("Before switching window ------------- Now in --------- "+currwindow);
            
 //            if(windows.size()>1)
 //            {
 //                if(!currwindow.contains("SalesIQ Testing - Home"))
 //                {
 //                    System.out.println("Current window ---------------------- "+currwindow);
                    
 //                    try
 //                    {
                        
 //                        driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings")));
                        
 //                        for(String window : windows)
 //                        {
 //                            driver.switchTo().window(window);
 //                        }
                        
 //                        windows.remove(mainwindow);
 //                        assert windows.size()==1;
 //                        driver.close();
 //                        driver.switchTo().window(mainwindow);
                        
 //                    }
 //                    catch(Exception e)
 //                    {
 //                        System.out.println("Current window ---------------------- "+currwindow);
                        
 //                        for(String window : windows)
 //                        {
 //                            driver.switchTo().window(window);
 //                            break;
 //                        }
                        
 //                        mainwindow = driver.getWindowHandle();
 //                        windows = driver.getWindowHandles();
                        
 //                        for(String window : windows)
 //                        {
 //                            driver.switchTo().window(window);
 //                        }
                        
 //                        windows.remove(mainwindow);
 //                        assert windows.size()==1;
 //                        driver.close();
 //                        driver.switchTo().window(mainwindow);
 //                    }
 //                }
 //                else
 //                {
 //                    System.out.println("Current window ---------------------- "+currwindow);
                    
 //                    for(String window : windows)
 //                    {
 //                        driver.switchTo().window(window);
 //                        break;
 //                    }
                    
 //                    mainwindow = driver.getWindowHandle();
 //                    windows = driver.getWindowHandles();
                    
 //                    for(String window : windows)
 //                    {
 //                        driver.switchTo().window(window);
 //                    }
                    
 //                    windows.remove(mainwindow);
 //                    assert windows.size()==1;
 //                    driver.close();
 //                    driver.switchTo().window(mainwindow);
 //                }
 //            }
            
 //            System.out.println("After switching window ------------- Now in --------- "+currwindow);
            
 //        }
 //        catch(Exception e)
 //        {
 //            System.out.println("Exception while switching windows in real time float widget check : "+e);
 //        }
 //    }

    public static void accresDel(WebDriver driver)
    {
        try
        {
            com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);
            // FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            // CommonFunctions.navToTriggersTab(driver,etest);

            // Thread.sleep(3000);

            // List<WebElement> list = driver.findElements(By.className("data_row"));

            // for(int i=0;i<list.size();i++)
            // {
            //     CommonFunctions.navToTriggersTab(driver,etest);
                
            //     try
            //     {
            //         WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("data_row"));
                    
            //         new Actions(driver).moveToElement(elmtch).perform();
                    
            //         elmtch.findElement(By.className("sqico-delico")).click();
                    
            //         wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

            //         driver.findElement(By.id("okbtn")).click();
                    
            //     }
            //     catch(IndexOutOfBoundsException e)
            //     {
            //     	System.out.println("Exception while deleting rules in intelligent triggers : "+e);
            //     }
            //     catch(Exception e)
            //     {
            //     	System.out.println("Exception while deleting rules in intelligent triggers : "+e);
            //     }
            // }
        }
        catch(Exception e)
        {
            System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        }
    }

    public static WebElement selectEmbedInWebEmbed(WebDriver driver,String embedname) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("list-row")));

		List<WebElement> list = driver.findElements(By.className("list-row"));

		for(WebElement e : list)
		{
			if(e.getText().contains(embedname))
			{
				return e;
			}
		}

		return null;
	}

    public static void navToWebsitesNewsLetter(WebDriver driver,String embed_name,ExtentTest etest) throws Exception
    {
        Tab.clickSettings(driver);
        Tab.clickEmbedTab(driver);
        WebEmbed.clickWebEmbed(driver,embed_name,etest);
        WebsitesTab.clickLiveChat(driver,etest);
        WebsitesTab.clickChatWindow(driver,etest);
        WebsitesTab.clickFields(driver,etest);
    }
}
