//$Id$
package com.zoho.livedesk.client.VisitorRoutingRT;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.Cookie;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;
import org.openqa.selenium.JavascriptExecutor;
import java.lang.reflect.Method;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.common.base.Function;

public class visitorroutingRT {
    
    public static Hashtable result = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable<WebDriver,String> getUserNameFromDriver = new Hashtable<WebDriver,String>();
    public static Hashtable<String,WebDriver> getDriverFromUserName = new Hashtable<String,WebDriver>();

    public static Hashtable<String,String> rule = new Hashtable<String,String>();
    public static Hashtable<String,String> vrrule = new Hashtable<String,String>();
    public static ExtentTest etest;
    public static WebDriver driver2,driver3;
    public static Set<WebDriver> visitors = new HashSet<WebDriver>();
    public static String embed = "";
    public static String portal = "";
    public static String WIDGET_CODE="";
    public static int secondAttempt = 0;
    public static String secondAttemptIds = "";
    
    public static Hashtable vrrt(WebDriver driver)
    {
        
        try
        {
            embed = "visitorrouting";
            portal = "visitorrouting";
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

            secondAttempt = 0;
            secondAttemptIds = "";

            result = new Hashtable();
            
            init();
            ruleFormation();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            driver2 = CommonFunctionsVR.setUp();
            driver3 = CommonFunctionsVR.setUp();
            
            if(!Functions.login(driver2,"vr_rt_supervisor") | !Functions.login(driver3,"vr_rt_associate"))
            {
                etest.log(Status.FAIL,"Login failed");
                ComplexReportFactory.closeTest(etest);
                
                hashtable.put("result", result);
                hashtable.put("servicedown", servicedown);
                return hashtable;
            }
            getUserNameFromDriver.put(driver,"Admin1");
            getUserNameFromDriver.put(driver2,"Supervisor1");
            getUserNameFromDriver.put(driver3,"Associate1");

            getDriverFromUserName.put("Admin1",driver);
            getDriverFromUserName.put("Supervisor1",driver2);
            getDriverFromUserName.put("Associate1",driver3);
            
            printRSID(driver);
            printRSID(driver2);
            printRSID(driver3);

    		CommonFunctionsVR.navToVisitorRoutingTab(driver);

            etest.log(Status.PASS,"Checked");
            result.put("VRRT1",true);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT2").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT2",VRRTOneToOne.oneVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT3").replace("$CONDITION",vrrule.get("VRRT3")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT3",VRRTOneToOne.twoVisitor(driver,driver2,driver3,rule.get("VRRT3")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT4").replace("$CONDITION",vrrule.get("VRRT4")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT4",VRRTOneToOne.threeVisitor(driver,driver2,driver3,rule.get("VRRT4")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT5").replace("$CONDITION",vrrule.get("VRRT5")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT5",VRRTOneToOne.threeVisitorWithOneUserBusy(driver,driver2,driver3,rule.get("VRRT5")));
            CommonFunctionsVR.changeStatus(driver,"available");
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            // websites was removed
            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT6").replace("$CONDITION",vrrule.get("VRRT6")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            // ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            // result.put("VRRT6",VRRTOneToOne.checkWithExistingVisitor(driver,driver2,driver3,rule.get("VRRT6")));
            // CommonFunctionsVR.clearVisitorDrivers(driver);
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT7").replace("$CONDITION",vrrule.get("VRRT7")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT7",VRRTOneToOne.checkAllAvailableUsers(driver,driver2,driver3,rule.get("VRRT7")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT8").replace("$CONDITION",vrrule.get("VRRT8")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT8",VRRTOneToOne.checkAllAvailableUsersWithOneUserBusy(driver,driver2,driver3,rule.get("VRRT8")));
            CommonFunctionsVR.changeStatus(driver,"available");
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT9").replace("$CONDITION",vrrule.get("VRRT9")).replace("$USERS","Last Chat Attender,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT9",VRRTOneToOne.checkLastChatAttender(driver,driver2,driver3,rule.get("VRRT9")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT10").replace("$CONDITION",vrrule.get("VRRT10")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT10",VRRTOneToOne.checkCRMLeadOwner(driver,driver2,driver3,rule.get("VRRT10")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT11").replace("$CONDITION",vrrule.get("VRRT11")).replace("$USERS","Admin1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT11",VRRTSelected.oneUser(driver,driver2,driver3,rule.get("VRRT11")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT12").replace("$CONDITION",vrrule.get("VRRT12")).replace("$USERS","Admin1,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT12",VRRTSelected.twoUser(driver,driver2,driver3,rule.get("VRRT12")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT13").replace("$CONDITION",vrrule.get("VRRT13")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT13",VRRTSelected.allAvailableUsers(driver,driver2,driver3,rule.get("VRRT13")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT14").replace("$CONDITION",vrrule.get("VRRT14")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT14",VRRTSelected.allAvailableUsersWithOneUserBusy(driver,driver2,driver3,rule.get("VRRT14")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT15").replace("$CONDITION",vrrule.get("VRRT15")).replace("$USERS","Last Chat Attender,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT15",VRRTSelected.checkLastChatAttender(driver,driver2,driver3,rule.get("VRRT15")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT16").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT16",VRRTSelected.checkCRMLeadOwner(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT32").replace("$CONDITION",vrrule.get("VRRT2")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT32",VRRTFirstAvailable.allAvailableUsersThenOneUserBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");CommonFunctionsVR.changeStatus(driver2,"available");CommonFunctionsVR.changeStatus(driver3,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT33").replace("$CONDITION",vrrule.get("VRRT18")).replace("$USERS","Last Chat Attender/Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT33",VRRTFirstAvailable.checkLastChatAttender(driver,driver2,driver3,rule.get("VRRT18")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT34").replace("$CONDITION",vrrule.get("VRRT18")).replace("$USERS","Last Chat Attender/Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT34",VRRTFirstAvailable.checkLastChatAttenderWithStatusBusy(driver,driver2,driver3,rule.get("VRRT18")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT35").replace("$CONDITION",vrrule.get("VRRT21")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT35",VRRTFirstAvailable.checkCRMLeadOwner(driver,driver2,driver3,rule.get("VRRT21")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT36").replace("$CONDITION",vrrule.get("VRRT22")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT36",VRRTFirstAvailable.checkCRMLeadOwnerWithStatusBusy(driver,driver2,driver3,rule.get("VRRT22")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);
            
/*            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT17").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT17",VRRTLeastLoaded.oneVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT18").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT18",VRRTLeastLoaded.twoVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT19").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT19",VRRTLeastLoaded.threeVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT20").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT20",VRRTLeastLoaded.threeVisitorWithOneUserBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT21").replace("$CONDITION",vrrule.get("VRRT2")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT21",VRRTLeastLoaded.checkAllAvailableUsers(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT22").replace("$CONDITION",vrrule.get("VRRT2")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT22",VRRTLeastLoaded.checkAllAvailableUsersWithOneUserBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT23").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT23",VRRTLeastLoaded.checkWithExistingVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver2,"available");CommonFunctionsVR.changeStatus(driver3,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT24").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Last Chat Attender,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT24",VRRTLeastLoaded.checkLastChatAttender(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT25").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Last Chat Atttender,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT25",VRRTLeastLoaded.checkLastChatAttenderWithStatusBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT26").replace("$CONDITION",vrrule.get("VRRT20")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT26",VRRTLeastLoaded.checkCRMLeadOwner(driver,driver2,driver3,rule.get("VRRT20")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT27").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT27",VRRTLeastLoaded.checkCRMLeadOwnerWithStatusBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT28").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT28",VRRTFirstAvailable.oneVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT29").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT29",VRRTFirstAvailable.twoVisitor(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT30").replace("$CONDITION",vrrule.get("VRRT2")).replace("$USERS","Admin1,Supervisor1,Associate1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT30",VRRTFirstAvailable.twoVisitorWithFirstUserBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT31").replace("$CONDITION",vrrule.get("VRRT2")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT31",VRRTFirstAvailable.allAvailableUsers(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT32").replace("$CONDITION",vrrule.get("VRRT2")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT32",VRRTFirstAvailable.allAvailableUsersThenOneUserBusy(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");CommonFunctionsVR.changeStatus(driver2,"available");CommonFunctionsVR.changeStatus(driver3,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT33").replace("$CONDITION",vrrule.get("VRRT18")).replace("$USERS","Last Chat Attender/Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT33",VRRTFirstAvailable.checkLastChatAttender(driver,driver2,driver3,rule.get("VRRT18")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT34").replace("$CONDITION",vrrule.get("VRRT18")).replace("$USERS","Last Chat Attender/Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT34",VRRTFirstAvailable.checkLastChatAttenderWithStatusBusy(driver,driver2,driver3,rule.get("VRRT18")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT35").replace("$CONDITION",vrrule.get("VRRT21")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT35",VRRTFirstAvailable.checkCRMLeadOwner(driver,driver2,driver3,rule.get("VRRT21")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT36").replace("$CONDITION",vrrule.get("VRRT22")).replace("$USERS","CRM Lead/Contact Owner,Supervisor1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT36",VRRTFirstAvailable.checkCRMLeadOwnerWithStatusBusy(driver,driver2,driver3,rule.get("VRRT22")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
            CommonFunctionsVR.changeStatus(driver,"available");
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VRRT37").replace("$CONDITION",vrrule.get("VRRT2")));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");

            result.put("VRRT37",doNotRoute(driver,driver2,driver3,rule.get("VRRT2")));
            CommonFunctionsVR.clearVisitorDrivers(driver);
*/            
            if(secondAttempt != 0)
            {
                ComplexReportFactory.closeTest(etest);
                
                etest=ComplexReportFactory.getTest("Visitor Routing RT - Successfull addition only after second attempt");
                ComplexReportFactory.setValues(etest,"Automation","Visitor Routing Real Time");
                
                etest.log(Status.FAIL,"Number of second attempts:"+secondAttempt);
                etest.log(Status.FAIL,"Ids - "+secondAttemptIds);
            }
            
            Functions.logout(driver2);
            Functions.logout(driver3);
        }

    	catch(Exception e)
        {
    		System.out.println("Error While checking Visitor Routing Real Time - "+e.toString());
    		TakeScreenshot.screenshot(driver,etest,"VisitorRoutingRT","ErrorWhileSigningUp","Error",e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
    		result.put("VRRT1",false);
    	}

    	ComplexReportFactory.closeTest(etest);

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    public static void init()
    {
        rule.put("VRRT2","Browser/No Value/is equal to/Google Chrome/No Value");
        rule.put("VRRT3","Visitor Type/No Value/is equal to/New/No Value");
        rule.put("VRRT4","City/No Value/is not equal to/Checking/No Value");
        rule.put("VRRT5","Country/No Value/is equal to/United States, United Kingdom, India/No Value");
        rule.put("VRRT6","Websites/No Value/is not equal to/Automation/No Value");
        rule.put("VRRT7","IP Address/No Value/is between/1.1.1.1/200.255.255.255");
        rule.put("VRRT8","Landing Page Title/No Value/contains/SalesIQ Testing/No Value/");
        rule.put("VRRT9","Landing Page URL/No Value/contains/visitor/No Value");
        rule.put("VRRT10","Number of Past Chats/No Value/is less than/2/No Value");
        rule.put("VRRT11","Number of Visits/No Value/is less than/2/No Value");
        rule.put("VRRT12","Operating System/No Value/is not equal to/Kindle/No Value");
        rule.put("VRRT13","Referrer/No Value/is not equal to/Yahoo/No Value");
        rule.put("VRRT14","Region/No Value/is equal to/United Kingdom, Asia Pacific, North America/No Value");
        rule.put("VRRT15","State/No Value/is not equal to/Checking/No Value/");
        rule.put("VRRT16","Visitor Info/Visitor Status/is equal to/Checking/No Value");
        rule.put("VRRT17","Campaign Source/No Value/is equal to/SalesIQ Testing/No Value");
        rule.put("VRRT18","Email Address/No Value/ends with/.com/No Value");
        rule.put("VRRT19","Search Engine/No Value/is equal to/Google/No Value");
        rule.put("VRRT20","CRM Contact/Email/begins with/email@/No Value");
        rule.put("VRRT21","CRM Lead/Email/begins with/email@/No Value");
        rule.put("VRRT22","Visitor Stage in CRM/No Value/is equal to/Lead/No Value");
    }

    public static void ruleFormation()
    {
        for(int i = 2;i<=22;i++)
        {
            String useCase = "VRRT"+i;
            vrrule.put(useCase,ruleFormation(rule.get(useCase)));
        }
    }

    public static String ruleFormation(String rule)
    {
        String vrrule = "";

        String values[] = rule.split("/");

        vrrule = values[0]+" ";

        if(!values[1].equals("No Value"))
        {
            vrrule += values[1]+" ";
        }

        vrrule += values[2]+" ";

        vrrule += values[3];

        if(!values[4].equals("No Value"))
        {
            vrrule += " - "+values[4];
        }

        return vrrule;
    }

    public static boolean doNotRoute(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"",values[0],values[1],values[2],values[3],values[4],"Do not route");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            String visitorid = VisitorSite.getVisitorId();

            String user = CheckVisitorInUser.checkVisitorPresenceInUser(drivers,visitorid).replace("/","");

            if(user.contains("Admin1") || user.contains("Supervisor1") || user.contains("Associate1"))
            {
                etest.log(Status.FAIL,"Visitor should not present in any users rings");
                TakeScreenshot.screenshot(driver1,etest,"VisitorRoutingRT","DoNotRouteRule","Error");
                return false;
            }

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }
    
    public static void printRSID(WebDriver driver) throws Exception
    {
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        
        try
        {
            driver.navigate().refresh();
            Thread.sleep(2000);
            
            Functions.waitTillRegistered(driver);
            
            Thread.sleep(2000);
            
            String rsid = ExecuteStatements.getRSid(driver);
            
            etest.log(Status.INFO,"RSID for account "+getUserNameFromDriver.get(driver)+"@ "+df.format(dateobj)+" is "+rsid);
        }
        catch(Exception e)
        {
            etest.log(Status.FAIL,"Couldn't get RSID from account "+getUserNameFromDriver.get(driver)+"@ "+df.format(dateobj));
            e.printStackTrace();
        }
    }
}
