//$Id$
package com.zoho.livedesk.client.VisitorRoutingRT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;

public class VisitorSite {

	public static WebDriver setUpVisitorDriver() throws Exception
	{
		WebDriver visDriver = CommonFunctionsVR.setUp();
        visitorroutingRT.visitors.add(visDriver);
        openVis(visDriver);
        return visDriver;
	}

	public static String getVisitorId() throws Exception
	{
		WebDriver visDriver = setUpVisitorDriver();
        return CommonFunctionsVR.getVisitorIdFromVisDriver(visDriver);
	}

	public static String getVisitorId(WebDriver visDriver) throws Exception
	{
		openVis(visDriver);
        return CommonFunctionsVR.getVisitorIdFromVisDriver(visDriver);
	}

	public static void initiateChatVis(WebDriver driver,String vname,String vemail,String vphone,String vques) throws Exception
    {
        try
        {
            VisitorWindow.initiateChatVisTheme(driver,vname,vemail,vphone,vques,visitorroutingRT.etest);
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            TakeScreenshot.screenshot(driver,visitorroutingRT.etest,"VisitorRoutingRT","InitiateChat","Error",e);
            throw e;
        }
    }

    public static void switchToChatWidget(WebDriver driver) throws Exception
    {
        driver.switchTo().frame(CommonUtilVR.elfinder(driver,"id","zlsiframe"));
    }

    public static void openVis(WebDriver driver) throws Exception
    {
        try
        {
            VisitorWindow.createPage(driver,visitorroutingRT.WIDGET_CODE);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,visitorroutingRT.etest,"VisitorRoutingRT","OpenVisitor","Error",e);
            throw e;
        }
    }
}
