//$Id$
package com.zoho.livedesk.client.VisitorRoutingRT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.IntegrationSettings;


public class VRRTFirstAvailable {
    
    public static boolean oneVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,1,"Admin1","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean twoVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,2,"Admin1","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean twoVisitorWithFirstUserBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            CommonFunctionsVR.changeStatus(driver1,"busy");

            return CheckVisitorInUser.checkVisitorInUser(drivers,2,"Supervisor1","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean allAvailableUsers(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"All Available operators",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            if(!CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0))
            {
                return false;
            }

            String user = CheckVisitorInUser.lastVisitorPresentIn;

            if(!CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0))
            {
                return false;
            }

            if(!user.equals(CheckVisitorInUser.lastVisitorPresentIn))
            {
                visitorroutingRT.etest.log(Status.FAIL,"Visitor is expected in "+user+" and not in "+CheckVisitorInUser.lastVisitorPresentIn);
                CommonFunctionsVR.takeScreenshot(drivers,"RouteToFirstAvailableAlloperators");
                return false;
            }

            if(!CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0))
            {
                return false;
            }

            if(!user.equals(CheckVisitorInUser.lastVisitorPresentIn))
            {
                visitorroutingRT.etest.log(Status.FAIL,"Visitor is expected in "+user+" and not in "+CheckVisitorInUser.lastVisitorPresentIn);
                CommonFunctionsVR.takeScreenshot(drivers,"RouteToFirstAvailableAlloperators");
                return false;
            }

            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean allAvailableUsersThenOneUserBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"All Available Operators",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            if(!CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0))
            {
                return false;
            }

            String user = CheckVisitorInUser.lastVisitorPresentIn;

            CommonFunctionsVR.changeStatus(visitorroutingRT.getDriverFromUserName.get(user.replace("/","")),"busy");

            if(!CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0))
            {
                return false;
            }

            if(user.equals(CheckVisitorInUser.lastVisitorPresentIn))
            {
                visitorroutingRT.etest.log(Status.FAIL,"Visitor is not expected in "+user);
                CommonFunctionsVR.takeScreenshot(drivers,"RouteToFirstAvailableAllOperators");
                return false;
            }

            String user2 = CheckVisitorInUser.lastVisitorPresentIn;

            if(!CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0))
            {
                return false;
            }

            if(user.equals(CheckVisitorInUser.lastVisitorPresentIn))
            {
                visitorroutingRT.etest.log(Status.FAIL,"Visitor is not expected in "+user);
                CommonFunctionsVR.takeScreenshot(drivers,"RouteToFirstAvailableAllOperators");
                return false;
            }

            if(!user2.equals(CheckVisitorInUser.lastVisitorPresentIn))
            {
                visitorroutingRT.etest.log(Status.FAIL,"Visitor is expected in "+user2+" and not in "+CheckVisitorInUser.lastVisitorPresentIn);
                CommonFunctionsVR.takeScreenshot(drivers,"RouteToFirstAvailableAllOperators");
                return false;
            }

            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkLastChatAttender(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            
            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,false))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1)))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Last Chat Attender/Supervisor1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            return CheckVisitorInUser.checkVisitorInSelectedUserWithExistingVisitor(drivers,"Admin1","Supervisor1/Associate1",visDriver1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkLastChatAttenderWithStatusBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            
            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,false))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1)))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Last Chat Attender/Supervisor1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");

            CommonFunctionsVR.changeStatus(driver1,"busy");
            
            return CheckVisitorInUser.checkVisitorInSelectedUserWithExistingVisitor(drivers,"Supervisor1","Admin1/Associate1",visDriver1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkCRMLeadOwner(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            IntegrationSettings.chooseType(driver1, "vistypecrmdiv", "Attended", 1, "chk",visitorroutingRT.etest);
            IntegrationSettings.addNewVisitorTo(driver1,0,visitorroutingRT.etest);
            Thread.sleep(5000);

            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            
            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,true))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1)))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Last Chat Attender/Supervisor1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            return CheckVisitorInUser.checkVisitorInSelectedUserWithExistingVisitor(drivers,"Admin1","Supervisor1/Associate1",visDriver1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkCRMLeadOwnerWithStatusBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            IntegrationSettings.chooseType(driver1, "vistypecrmdiv", "Attended", 1, "chk",visitorroutingRT.etest);
            IntegrationSettings.addNewVisitorTo(driver1,0,visitorroutingRT.etest);
            Thread.sleep(5000);

            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            
            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,true))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1)))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Last Chat Attender/Supervisor1",values[0],values[1],values[2],values[3],values[4],"Route to the first available operator");
            
            CommonFunctionsVR.changeStatus(driver1,"busy");
            
            return CheckVisitorInUser.checkVisitorInSelectedUserWithExistingVisitor(drivers,"Supervisor1","Admin1/Associate1",visDriver1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }
}
