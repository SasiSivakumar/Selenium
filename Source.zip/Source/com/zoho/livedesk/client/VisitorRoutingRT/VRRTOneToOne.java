//$Id$
package com.zoho.livedesk.client.VisitorRoutingRT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.IntegrationSettings;


public class VRRTOneToOne {
    
    public static boolean oneVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,1,"","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean twoVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,2,"","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean threeVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,3,"","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean threeVisitorWithOneUserBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            CommonFunctionsVR.changeStatus(driver1,"busy");

            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,3,"","Admin1",3);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkAllAvailableUsers(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"All Available operators",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,3,"","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkAllAvailableUsersWithOneUserBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"All Available operators",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            CommonFunctionsVR.changeStatus(driver1,"busy");

            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInUser(drivers,3,"","Admin1",3);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkWithExistingVisitor(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            WebDriver drivers[] = {driver1,driver2,driver3};

            if(!CommonFunctionsVR.waitTillVisitorLeaves(drivers))
            {
                return false;
            }

            String rule1[] = visitorroutingRT.rule.get("VRRT2").split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1",rule1[0],rule1[1],rule1[2],rule1[3],rule1[4],"Route to selected operators");
            
            if(!CheckVisitorInUser.checkVisitorInUser(drivers,2,"Admin1","",0))
            {
                TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","RoutetoSelectedOperators","Error");
                return false;
            }

            CommonFunctionsVR.deleteVisitorRouting(driver1);
            
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1/Associate1",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            return CheckVisitorInUser.checkVisitorInUser(drivers,3,"","",0);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkLastChatAttender(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            WebDriver visDriver2 = VisitorSite.setUpVisitorDriver();

            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,false))
            {
                return false;
            }
            
            String id1 = CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1);

            Thread.sleep(3000);

            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver2,false))
            {
                return false;
            }
            
            String id2 = CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver2);

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,id1))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,id2))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Supervisor1/Last Chat Attender",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            WebDriver visDrivers[] = {visDriver1,visDriver2};

            return CheckVisitorInUser.checkVisitorInUserWithExistingVisitor(drivers,2,"","Associate1",0,visDrivers);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkCRMLeadOwner(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            IntegrationSettings.chooseType(driver1, "vistypecrmdiv", "Attended", 1, "chk",visitorroutingRT.etest);
            IntegrationSettings.addNewVisitorTo(driver1,0,visitorroutingRT.etest);
            Thread.sleep(5000);

            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            WebDriver visDriver2 = VisitorSite.setUpVisitorDriver();

            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,true))
            {
                return false;
            }

            String id1 = CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1);
            
            Thread.sleep(3000);

            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver2,true))
            {
                return false;
            }
            
            String id2 = CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver2);
            
            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,id1))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,id2))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Supervisor1/CRM Lead",values[0],values[1],values[2],values[3],values[4],"Route one by one");
            
            WebDriver visDrivers[] = {visDriver1,visDriver2};

            return CheckVisitorInUser.checkVisitorInUserWithExistingVisitor(drivers,2,"","Associate1",0,visDrivers);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }
}
