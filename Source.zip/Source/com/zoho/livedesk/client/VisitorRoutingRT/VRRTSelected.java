//$Id$
package com.zoho.livedesk.client.VisitorRoutingRT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.IntegrationSettings;


public class VRRTSelected {
    
    public static boolean oneUser(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1",values[0],values[1],values[2],values[3],values[4],"Route to selected operators");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInSelectedUser(drivers,"Admin1","Supervisor1/Associate1");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean twoUser(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Admin1/Supervisor1",values[0],values[1],values[2],values[3],values[4],"Route to selected operators");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInSelectedUser(drivers,"Admin1/Supervisor1","Associate1");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean allAvailableUsers(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"All Available operators",values[0],values[1],values[2],values[3],values[4],"Route to selected operators");
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInSelectedUser(drivers,"Admin1/Supervisor1/Associate1",null);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean allAvailableUsersWithOneUserBusy(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"All Available operators",values[0],values[1],values[2],values[3],values[4],"Route to selected operators");
            
            CommonFunctionsVR.changeStatus(driver1,"busy");

            WebDriver drivers[] = {driver1,driver2,driver3};

            return CheckVisitorInUser.checkVisitorInSelectedUser(drivers,"Supervisor1/Associate1","Admin1");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkLastChatAttender(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();

            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,false))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1)))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Supervisor1/Last Chat Attender",values[0],values[1],values[2],values[3],values[4],"Route to selected operators");
            
            return CheckVisitorInUser.checkVisitorInSelectedUserWithExistingVisitor(drivers,"Admin1/Supervisor1","Associate1",visDriver1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }

    public static boolean checkCRMLeadOwner(WebDriver driver1,WebDriver driver2,WebDriver driver3,String rule)
    {
        try
        {
            IntegrationSettings.chooseType(driver1, "vistypecrmdiv", "Attended", 1, "chk",visitorroutingRT.etest);
            IntegrationSettings.addNewVisitorTo(driver1,0,visitorroutingRT.etest);
            Thread.sleep(5000);
            
            WebDriver drivers[] = {driver1,driver2,driver3};

            WebDriver visDriver1 = VisitorSite.setUpVisitorDriver();
            
            if(!CommonFunctionsVR.initiateAndEndChat(driver1,visDriver1,true))
            {
                return false;
            }

            if(!CommonFunctionsVR.waitTillVisitorLeaves(driver1,CommonFunctionsVR.getVisitorIdFromVisDriverAndNav(visDriver1)))
            {
                return false;
            }

            String values[] = rule.split("/");

            CommonFunctionsVR.addVisitorRouting(driver1,visitorroutingRT.etest,"Supervisor1/CRM Lead",values[0],values[1],values[2],values[3],values[4],"Route to selected operators");
            
            return CheckVisitorInUser.checkVisitorInSelectedUserWithExistingVisitor(drivers,"Admin1/Supervisor1","Associate1",visDriver1);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver1,visitorroutingRT.etest,"VisitorRoutingRT","ErrorWhileAddingRule","Error",e);
            return false;
        }
    }
}
