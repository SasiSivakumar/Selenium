//$Id$
package com.zoho.livedesk.client.ConversationView;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;



import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonSikuli;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;

import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.TransferType;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;



public class ConversationViewTests{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Conversation View";
	public static String WIDGET_CODE="";
	public static String PORTAL_NAME="";
	public static String WEBSITE_NAME="";

	public static Hashtable test(WebDriver driver) throws Exception
	{
		try
		{
            result = new Hashtable<String,Boolean>();
            WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            PORTAL_NAME=ExecuteStatements.getPortal(driver);            
            System.out.println("~~~~WIDGET_CODE"+WIDGET_CODE+" WEBSITE_NAME"+WEBSITE_NAME+" PORTAL_NAME"+PORTAL_NAME);       

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV1", disableConversationView(driver,etest,WIDGET_CODE,WEBSITE_NAME));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV2"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV2", enableConversationView(driver,etest,WIDGET_CODE,WEBSITE_NAME));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV8"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV8", retreiveMultipleChats(driver,etest,WIDGET_CODE,WEBSITE_NAME));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV5"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV5", checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,ChatType.COMPLETED));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV3", checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,ChatType.MISSED));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check Ongoing Chat");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,ChatType.ONGOING);//this functions tests multiple ongoing chat usecases and adds the result to the main hashtable directly
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			ChatType blank_visitor_info_chat_type=ChatType.COMPLETED;
			blank_visitor_info_chat_type.setIsVisitorInfoBlank(true);

			result.put("CV10", checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,blank_visitor_info_chat_type));
            ComplexReportFactory.closeTest(etest);

			blank_visitor_info_chat_type.setIsVisitorInfoBlank(false);//resetting back to initial value

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			ChatType attach_file_chat_type=ChatType.COMPLETED;
			attach_file_chat_type.setIsUploadFile(true);
			attach_file_chat_type.setUploadFileType(FileType.IMAGE);
			
			result.put("CV9", checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,attach_file_chat_type));
            ComplexReportFactory.closeTest(etest);

			attach_file_chat_type.setIsUploadFile(false);//resetting back to initial value

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV16"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			ChatType js_api_chat_type=ChatType.COMPLETED;
			js_api_chat_type.setIsVisitorId(true);
			js_api_chat_type.setVisitorId( CommonUtil.getUniqueMessage() );
			
			result.put("CV16", checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,js_api_chat_type));
            ComplexReportFactory.closeTest(etest);

			js_api_chat_type.setIsVisitorId(false);//resetting back to initial value

            WebDriver driver2 = Functions.setUp();
            Functions.login(driver2,"transferchat_supervisor");

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV11", checkTransferChat(driver,driver2,etest,WIDGET_CODE,WEBSITE_NAME,TransferType.TRANSFER));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV12"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV12", checkTransferChat(driver,driver2,etest,WIDGET_CODE,WEBSITE_NAME,TransferType.INVITE));
            ComplexReportFactory.closeTest(etest);

            Functions.logout(driver2);
            Driver.quitDriver(driver2);

            try
            {
            	driver2.quit();
            }
            catch(Exception e)
            {
            	CommonUtil.doNothing();
            }

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CV4"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CV4", checkConversationViewForChatType(driver,etest,WIDGET_CODE,WEBSITE_NAME,ChatType.OFFLINE));
            ComplexReportFactory.closeTest(etest);

       }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static boolean enableConversationView(WebDriver driver,ExtentTest etest,String WIDGET_CODE,String embed_name)
	{
		return toggleConversationView(driver,etest,WIDGET_CODE,embed_name,true);
	}

	public static boolean disableConversationView(WebDriver driver,ExtentTest etest,String WIDGET_CODE,String embed_name)
	{
		return toggleConversationView(driver,etest,WIDGET_CODE,embed_name,false);
	}

	public static boolean toggleConversationView(WebDriver driver,ExtentTest etest,String WIDGET_CODE,String embed_name,boolean isEnable)
	{
		driver.navigate().refresh();

		int failcount=0;
		WebDriver visitor_driver=null;
		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_phone=null,
		// visitor_phone=label+"",		
		visitor_question="question"+label,
		visitor_feedback="feedback"+label,
		rating="3";

		String expected_result=isEnable?"displayed":"hidden";
		String operation=isEnable?"enabling conversation view":"disabling conversation view";

		try
		{
			if(isEnable)
			{
				ConversationViewCommonFunctions.enableConversationView(driver,etest,embed_name);
			}
			else
			{
				ConversationViewCommonFunctions.disableConversationView(driver,etest,embed_name);
			}

			visitor_driver=Functions.setUp();
			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,visitor_phone,null,visitor_question,visitor_feedback,rating);		
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,WIDGET_CODE,ChatType.COMPLETED_BASIC,visitor_details,null);
	        VisitorWindow.clickChatButton(visitor_driver);

	        if(ConversationViewCommonFunctions.isConversationViewContainerDisplayed(visitor_driver)==isEnable)
	        {
	        	etest.log(Status.PASS,"Conversation view was "+expected_result+" after "+operation);
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Conversation view was NOT "+expected_result+" after "+operation);
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","Operator window screenshot");		
				TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");		
				failcount++;									
	        }
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"toggleConversationView","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"toggleConversationView","Exception",e);
		}
		finally
		{
			Driver.quitDriver(visitor_driver);
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkConversationViewForChatType(WebDriver driver,ExtentTest etest,String WIDGET_CODE,String embed_name,ChatType chat_type)
	{
		driver.navigate().refresh();

		int failcount=0;
		WebDriver visitor_driver=null;
		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_phone=null,
		// visitor_phone=label+"",
		visitor_question="question"+label,
		visitor_feedback="feedback"+label,
		rating="3";

		String unique_id=null;

		String agent_name=null;

		if(chat_type.getIsVisitorInfoBlank())
		{
			visitor_name="";
			visitor_mail="";
			visitor_phone="";
		}

		try
		{
			try
			{
				CommonUtil.refreshPage(driver);
				ChatWindow.closeAllChats(driver);
				etest.log(Status.INFO,"All Chats are closed");
				TakeScreenshot.infoScreenshot(driver,etest);
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
			
			try
			{
				agent_name=ExecuteStatements.getUserName(driver);
			}
			catch(Exception e)
			{
				agent_name="Not Found";
			}

			visitor_driver=Functions.setUp();
			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,visitor_phone,null,visitor_question,visitor_feedback,rating);
			visitor_details.put(ConversationViewConstants.AGENT_NAME,agent_name);
			Hashtable<String,List<String>> messages=ConversationViewCommonFunctions.addMessageDetails(label);

	        unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,WIDGET_CODE,chat_type,visitor_details,messages);

	        if(chat_type.isVisitorId())
	        {
	        	String visitor_id=chat_type.getVisitorId();
	        	visitor_driver=ConversationViewCommonFunctions.setupVisitorId(visitor_driver,etest,WIDGET_CODE,visitor_id);
	        }

	        VisitorWindow.clickChatButton(visitor_driver);

	  		// ConversationViewCommonFunctions.waitTillConversationHistoryMenuDisplayed(visitor_driver);

	        boolean isFirstChatForVisitor=chat_type==ChatType.ONGOING?true:false;

	        ConversationViewCommonFunctions.checkConversationViewStateFoundAsExpected(visitor_driver,etest,isFirstChatForVisitor);

	        if(chat_type==ChatType.ONGOING)
	        {
	  			result=ConversationViewCommonFunctions.checkOngoingChat(visitor_driver,driver,etest,unique_id,result,messages);
	        }
	        else
	        {
		        if(ConversationViewCommonFunctions.checkPreviousChat(visitor_driver,etest,unique_id,chat_type,visitor_details,messages)==false)
		        {
		        	failcount++;
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","Operator window screenshot");		
					TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");	
		        }
	        }


		}
		catch(Exception e)
		{
			failcount++;

			if(chat_type==ChatType.OFFLINE)
			{
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			}

			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkConversationViewForChatType","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkConversationViewForChatType","Exception",e);
		}
		finally
		{
			Driver.quitDriver(visitor_driver);
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean retreiveMultipleChats(WebDriver driver,ExtentTest etest,String WIDGET_CODE,String embed_name)
	{
		ChatType chat_type=ChatType.COMPLETED;

		int NO_OF_CHATS=5;

		driver.navigate().refresh();

		int failcount=0;
		WebDriver visitor_driver=null;
		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		// visitor_phone=label+"",
		visitor_phone=label.substring(0,10),
		visitor_question="question"+label,
		visitor_feedback="feedback"+label,
		rating="3";

		String agent_name=null;

		List<String> visitor_names = new ArrayList<String>();
		List<String> visitor_mails = new ArrayList<String>();
		List<String> visitor_phones = new ArrayList<String>();
		List<String> visitor_questions = new ArrayList<String>();
		List<String> visitor_feedbacks = new ArrayList<String>();
		List<String> ratings = new ArrayList<String>();
		List<String> unique_ids = new ArrayList<String>();

		List<Hashtable> visitor_details_list = new ArrayList<Hashtable>();
		List<Hashtable> messages_list = new ArrayList<Hashtable>();

		int i=0;//for looping purpose

		//adding unique values for each chat
		for(i=0;i<NO_OF_CHATS;i++)
		{
			visitor_names.add(visitor_name+"_"+i);
			visitor_mails.add(i+"_"+visitor_mail);
			visitor_phones.add(visitor_phone+""+i);
			visitor_questions.add(visitor_question+"_"+i);
			visitor_feedbacks.add(visitor_feedback+"_"+i);
			ratings.add(rating);
		}


		try
		{
			try
			{
				agent_name=ExecuteStatements.getUserName(driver);
			}
			catch(Exception e)
			{
				agent_name="Not Found";
			}


			visitor_driver=Functions.setUp();

			//adding unique values for each chat
			for(i=0;i<NO_OF_CHATS;i++)
			{
				Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_names.get(i),visitor_mails.get(i),visitor_phones.get(i),null,visitor_questions.get(i),visitor_feedbacks.get(i),ratings.get(i));
				visitor_details.put(ConversationViewConstants.AGENT_NAME,agent_name);
				Hashtable<String,List<String>> messages=ConversationViewCommonFunctions.addMessageDetails(label+"_"+i);
				visitor_details_list.add(visitor_details);
				messages_list.add(messages);
			}

			etest.log(Status.INFO,"Starting to Initiate and End "+NO_OF_CHATS+" chats with the same visitor");

			for(i=0;i<NO_OF_CHATS;i++)
			{
				String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,WIDGET_CODE,chat_type,visitor_details_list.get(i),messages_list.get(i));
				unique_ids.add(unique_id);
			}

			etest.log(Status.INFO,NO_OF_CHATS+" chats were initiated and completed");

	        VisitorWindow.clickChatButton(visitor_driver);

	        if(ConversationViewCommonFunctions.isConversationViewContainerDisplayed(visitor_driver)==false)
	        {
	        	etest.log(Status.FAIL,"Conversation view was NOT displayed");
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","Operator window screenshot");		
				TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");	
				throw new ZohoSalesIQRuntimeException("Conversation view was NOT displayed for "+embed_name+" in "+chat_type+" chat. (WIDGET_CODE:"+WIDGET_CODE+")");
	        }

	        for(i=0;i<NO_OF_CHATS;i++)
	        {
	        	etest.log(Status.INFO,"Now checking conversation history for chat id : "+unique_ids.get(i));
		        if(ConversationViewCommonFunctions.checkPreviousChat(visitor_driver,etest,unique_ids.get(i),chat_type,visitor_details_list.get(i),messages_list.get(i))==false)
		        {
		        	failcount++;
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","Operator window screenshot");		
					TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");	
		        }
	        }

	        label = CommonUtil.getUniqueMessage();
        	Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
        	ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,WIDGET_CODE,ChatType.ONGOING,visitor_details,null);
        	ConversationViewCommonFunctions.goToAllChats(visitor_driver);
			CommonSikuli.findInWholePage(visitor_driver,"Cviewongoing.png","UI257",etest);
	        
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"retreiveMultipleChats","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"retreiveMultipleChats","Exception",e);
		}
		finally
		{
			Driver.quitDriver(visitor_driver);
			return CommonUtil.returnResult(failcount);
		}
	}

	//transfer chat

	public static boolean checkTransferChat(WebDriver agent_driver1,WebDriver agent_driver2,ExtentTest etest,String WIDGET_CODE,String embed_name,TransferType transfer_type)
	{
		agent_driver1.navigate().refresh();
		agent_driver2.navigate().refresh();

		int failcount=0;
		WebDriver visitor_driver=null;
		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		// visitor_phone=label+"",
		visitor_phone=null,		
		visitor_question="question"+label,
		visitor_feedback="feedback"+label,
		rating="3";

		String
		agent1_message="agent_1_"+label,
		agent2_message="agent_1_"+label;

		String unique_id=null;

		String agent1_name=null,agent2_name=null;

		ChatType chat_type=ChatType.ONGOING;

		try
		{
			agent1_name=ExecuteStatements.getUserName(agent_driver1);
			agent2_name=ExecuteStatements.getUserName(agent_driver2);
		}
		catch(Exception e)
		{
			agent1_name="Not Found";				
			agent2_name="Not Found";
			throw new ZohoSalesIQRuntimeException("Agent name could not be found during runtime.");
		}


		try
		{
			visitor_driver=Functions.setUp();
			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,visitor_phone,null,visitor_question,visitor_feedback,rating);
			visitor_details.put(ConversationViewConstants.AGENT_NAME,agent1_name);

	        unique_id=ConversationViewCommonFunctions.setupChatType(agent_driver1,visitor_driver,etest,WIDGET_CODE,chat_type,visitor_details,null);
			ChatWindow.sentMessage(agent_driver1,agent1_message);
	        ConversationViewCommonFunctions.setupTransferChatType(agent_driver1,agent_driver2,visitor_driver,etest,chat_type,unique_id,transfer_type);
			ChatWindow.sentMessage(agent_driver2,agent2_message);
        	VisitorWindow.endChatVisitor(visitor_driver);
	    	VisitorWindow.enterFeedbackInTheme(visitor_driver,visitor_feedback,rating);

	    	ConversationViewCommonFunctions.reloadEmbed(visitor_driver,WIDGET_CODE);

	    	chat_type=ChatType.COMPLETED;

	        VisitorWindow.clickChatButton(visitor_driver);

	        if(ConversationViewCommonFunctions.isConversationViewContainerDisplayed(visitor_driver)==false)
	        {
	        	etest.log(Status.FAIL,"Conversation view was NOT displayed");
				TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Failure","Visitor window screenshot");	
				throw new ZohoSalesIQRuntimeException("Conversation view was NOT displayed for "+embed_name+" in "+chat_type+" chat. (WIDGET_CODE:"+WIDGET_CODE+" , chid/visitorid : "+unique_id+")");
	        }

	        ConversationViewCommonFunctions.openChatByUniqueId(visitor_driver,chat_type,unique_id);

	        if(ConversationViewCommonFunctions.checkFirstAgentName(visitor_driver,etest,agent1_name)==false)
	        {
	        	ConversationViewCommonFunctions.screenshot(visitor_driver,etest);
	        	failcount++;
	        }

	        if(ConversationViewCommonFunctions.checkAgentName(visitor_driver,etest,agent2_name)==false)
	        {
	        	ConversationViewCommonFunctions.screenshot(visitor_driver,etest);	        	
	        	failcount++;
	        }

	        transfer_type.setAgentSpecificInfoMessage(agent2_name);

			if(ConversationViewCommonFunctions.checkTransferInfoMessage(visitor_driver,etest,transfer_type)==false)
			{
	        	ConversationViewCommonFunctions.screenshot(visitor_driver,etest);	      
				failcount++;
			}

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(agent_driver1,etest,MODULE_NAME,"checkTransferChat","Exception",e);
			TakeScreenshot.screenshot(agent_driver2,etest,MODULE_NAME,"checkTransferChat","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkTransferChat","Exception",e);
		}
		finally
		{
			Driver.quitDriver(visitor_driver);
			return CommonUtil.returnResult(failcount);
		}
	}

}

