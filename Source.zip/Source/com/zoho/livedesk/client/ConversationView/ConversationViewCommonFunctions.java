//$Id$
package com.zoho.livedesk.client.ConversationView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Hashtable;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonUtil;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonSikuli;

import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.TransferType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import org.openqa.selenium.TimeoutException;

import com.zoho.livedesk.client.ChatTransfer.CommonFunctionsTC;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.Util;

public class ConversationViewCommonFunctions
{

	//enable and disable functions
	public static void toggleConversationView(WebDriver driver,ExtentTest etest,String embed_name,boolean isEnable) throws Exception
	{
        Tab.navToEmbedTab(driver);	    
	    WebEmbed.clickWebEmbed(driver,embed_name,etest);	    
	    WebsitesTab.clickLiveChat(driver,etest);	    
	    WebsitesTab.clickChatWindow(driver,etest);	    
	    WebsitesTab.clickConfigurations(driver,etest);	    
	    Websites.clickShowAll(driver,etest);
	    toggleConversationViewInWebsiteSettings(driver,etest,isEnable);
        Websites.clickSave(driver,etest,false);//'false' is passed to return if already saved        
	    WebsitesTab.closeEmbedConfig(driver,etest);
		driver.navigate().refresh();
	}

	public static void enableConversationView(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		toggleConversationView(driver,etest,embed_name,true);
	}

	public static void disableConversationView(WebDriver driver,ExtentTest etest,String embed_name) throws Exception
	{
		toggleConversationView(driver,etest,embed_name,false);
	}

	public static void clickEnableConversationViewInWebsiteSettings(WebDriver driver,ExtentTest etest) throws Exception
	{
		toggleConversationViewInWebsiteSettings(driver,etest,true);
	}

	public static void clickDisableConversationViewInWebsiteSettings(WebDriver driver,ExtentTest etest) throws Exception
	{
		toggleConversationViewInWebsiteSettings(driver,etest,false);
	}

	public static void toggleConversationViewInWebsiteSettings(WebDriver driver,ExtentTest etest,boolean isEnable) throws Exception
	{
        Websites.setStatusOfToggle(driver,ConversationViewConstants.WEBSITE_SETTINGS_CONVERSATION_VIEW_ID,isEnable,etest);
	}

	public static boolean isConversationViewContainerDisplayed(WebDriver driver)
	{
		try
		{
			VisitorWindow.switchToChatWidget(driver);

			if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains(ConversationViewConstants.CONVERSATION_VIEW_CONTAINER_ID))
			{
				return driver.findElement(By.id(ConversationViewConstants.CONVERSATION_VIEW_CONTAINER_ID)).isDisplayed();
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return false;
	}

	//chat functions
	public static String setupChatType(WebDriver agent_driver,WebDriver visitor_driver,ExtentTest etest,String widget_code,ChatType chat_type,Hashtable<String,String> visitor_details,Hashtable<String,List<String>> messages) throws Exception
	{	
		//this method setups the scenario of chat based on the value passed in chat_type, according to the use case. It returns an unique chat id ('chid') which is used in DOM to identify the current chat.

		if(chat_type==ChatType.OFFLINE)
		{
			com.zoho.livedesk.util.common.actions.Status.changeStatus(agent_driver,"busy");
			agent_driver.navigate().refresh();
			CommonUtil.sleep(10000);
			reloadEmbed(visitor_driver,widget_code);
		}

		visitor_driver.navigate().refresh();
		
		VisitorWindow.createPage(visitor_driver,widget_code);
		VisitorWindow.switchToChatWidget(visitor_driver);

		if(chat_type.isVisitorId())
		{
			String visitor_id=chat_type.getVisitorId();
			createPageWithVisitorId(visitor_driver,widget_code,visitor_id);
			etest.log(Status.INFO,"Visitor Id "+visitor_id+" was set for current visitor.");
		}

		if(chat_type!=ChatType.OFFLINE)
		{
			String visitor_phone=null;

			if(visitor_details.containsKey(ConversationViewConstants.VISITOR_PHONE) && visitor_details.get(ConversationViewConstants.VISITOR_PHONE)!=null)
			{
				visitor_phone=visitor_details.get(ConversationViewConstants.VISITOR_PHONE);
			}

			String vis_dept=null;

			if(visitor_details.containsKey(ConversationViewConstants.VISITOR_DEPARTMENT))
			{
				vis_dept=visitor_details.get( ConversationViewConstants.VISITOR_DEPARTMENT );
			}

	        // VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),visitor_phone,vis_dept,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),etest);
			
			if(chat_type==ChatType.INITIATED)
			{
				return null;
			}
		}

	    else if(chat_type==ChatType.OFFLINE)
        {
        	if(VisitorWindow.checkChatWidgetOffline(visitor_driver))
        	{
				VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_NAME),visitor_details.get(ConversationViewConstants.VISITOR_EMAIL),null,null,visitor_details.get(ConversationViewConstants.VISITOR_QUESTION),false,etest,true);
        	}

        	else
        	{
        		etest.log(Status.FAIL,"Chat widget is not Offline");
				TakeScreenshot.screenshot(agent_driver,etest,ConversationViewTests.MODULE_NAME,"Failure","Operator window screenshot");		        		
				TakeScreenshot.screenshot(visitor_driver,etest,ConversationViewTests.MODULE_NAME,"Failure","Visitor window screenshot");		        		
        	}
        }

        if(chat_type==ChatType.ONGOING || chat_type==ChatType.COMPLETED || chat_type==ChatType.COMPLETED_BASIC)
        {
			ChatWindow.acceptChat(agent_driver,etest);

			if(chat_type==ChatType.COMPLETED && messages!=null)
			{
				List<String> agent_messages = messages.get(ConversationViewConstants.AGENT_MESSAGES);
				List<String> visitor_messages = messages.get(ConversationViewConstants.VISITOR_MESSAGES);

				for(int i=0;i<agent_messages.size();i++)
				{
					String agent_message=agent_messages.get(i);
					String visitor_message=visitor_messages.get(i);

					ChatWindow.sentMessage(agent_driver,agent_message);
					VisitorWindow.waitTillMessageInChat(visitor_driver,agent_message);
					ChatWindow.waitTillMessageInChat(agent_driver,agent_message);
					CommonUtil.sleep(500);
					// TakeScreenshot.screenshot(visitor_driver,etest,ConversationViewTests.MODULE_NAME,"AgentMessageSent","After",0);

					VisitorWindow.sentMessageInTheme(visitor_driver,visitor_message);
					VisitorWindow.waitTillMessageInChat(visitor_driver,visitor_message);
					ChatWindow.waitTillMessageInChat(agent_driver,visitor_message);	
					CommonUtil.sleep(500);
					// TakeScreenshot.screenshot(visitor_driver,etest,ConversationViewTests.MODULE_NAME,"MessageSent","After",0);
				}

				if(chat_type.getIsUploadFile())
				{
					FileType file_type=chat_type.getUploadFileType();
					VisitorWindow.clickMoreActions(visitor_driver);
					CommonSikuli.findInWholePage(visitor_driver,"Visitorsideendchat.png","UI255",etest);  
					CommonSikuli.findInWholePage(visitor_driver,"Visitorsideattach.png","UI252",etest);  
        			CommonSikuli.findInWholePage(visitor_driver,"Visitorsidemute.png","UI251",etest);  
					CommonSikuli.findInWholePage(visitor_driver,"Visitorsidemailtranscript.png","UI254",etest);  
        			CommonSikuli.findInWholePage(visitor_driver,"Visitorsideprint.png","UI253",etest);
					WebElement attach_file_input=VisitorWindow.getAttachFileInputElement(visitor_driver);
					FileUpload.uploadFile(attach_file_input,file_type);
					VisitorWindow.waitTillMoreActionDropdownIsDisplayed(visitor_driver,false);
					CommonUtil.sleep(1000);
				}

				TakeScreenshot.screenshot(visitor_driver,etest,ConversationViewTests.MODULE_NAME,"SendingMessages","After",0);

			}
        }
        else if(chat_type==ChatType.MISSED)
        {
            VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
        }

        //logMessagesFound(visitor_driver,etest);
		TakeScreenshot.screenshot(agent_driver,etest,ConversationViewTests.MODULE_NAME,"Agent-SendingMessages","After",0);

        if(chat_type==ChatType.COMPLETED || chat_type==ChatType.COMPLETED_BASIC)
        {
        	VisitorWindow.endChatVisitor(visitor_driver);
        	VisitorWindow.enterFeedbackInTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_FEEDBACK),visitor_details.get(ConversationViewConstants.VISITOR_RATING));
        	CommonUtil.sleep(5000);
        }

        String current_chat_id;

        if(chat_type.isGetChatId==true)
        {
       		current_chat_id=getChatIdOfCurrentChat(visitor_driver,chat_type);
        }
        else
        {
        	current_chat_id=null;
        }

		if(chat_type==ChatType.OFFLINE)
		{
			com.zoho.livedesk.util.common.actions.Status.changeStatus(agent_driver,"available");
		}

		if(chat_type!=ChatType.ONGOING)
		{
			reloadEmbed(visitor_driver,widget_code);
		}

		return current_chat_id;
	}

	public static WebDriver setupVisitorId(WebDriver visitor_driver,ExtentTest etest,String widget_code,String visitor_id) throws Exception
	{
    	visitor_driver.quit();
    	etest.log(Status.INFO,"Visitor window was closed after setting visitor id.");
    	visitor_driver=Functions.setUp();
    	etest.log(Status.INFO,"New visitor window was opened");
 		createPageWithVisitorId(visitor_driver,widget_code,visitor_id);
 	   	etest.log(Status.INFO,"Visitor Id "+visitor_id+"(visitor id of previous visitor) was set for current visitor.");
    	return visitor_driver;
	}

	public static boolean setupTransferChatType(WebDriver agent_driver1,WebDriver agent_driver2,WebDriver visitor_driver,ExtentTest etest,ChatType chat_type,String unique_id,TransferType transfer_type) throws Exception
	{
		String agent1_name=null,agent2_name=null;

		try
		{
			agent1_name=ExecuteStatements.getUserName(agent_driver1);
			agent2_name=ExecuteStatements.getUserName(agent_driver2);
		}
		catch(Exception e)
		{
			agent1_name="Not Found";				
			agent2_name="Not Found";
			throw new ZohoSalesIQRuntimeException("Agent name could not be found during runtime.");
		}

        VisitorWindow.clickChatButton(visitor_driver);
       	// openChatByUniqueId(visitor_driver,chat_type,unique_id);

       	if(transfer_type==TransferType.TRANSFER || transfer_type==TransferType.INVITE)
       	{
	       	if(transfer_type==TransferType.TRANSFER)
	       	{
		       	CommonFunctionsTC.transferChat(agent_driver1,etest,false,null,null,agent2_name);
	       	}
	       	else if(transfer_type==TransferType.INVITE)
	       	{
	       		CommonFunctionsTC.inviteUser(agent_driver1,etest,agent2_name,null);
	       	}

   	       	CommonFunctionsTC.acceptTransferedChat(agent_driver2,etest);

	       	etest.log(Status.INFO,agent2_name+" accepted "+agent1_name+"'s "+transfer_type);
       	}

       	else if(transfer_type==TransferType.JOIN)
       	{
       		String agent_side_chat_id="";

       		try
       		{
	       		agent_side_chat_id = ChatWindow.chatInMyChats(agent_driver1).findElement(By.className(ConversationViewConstants.VISITOR_QUESTION_AGENT_SIDE_CLASS)).findElement(By.className(ConversationViewConstants.VISITOR_QUESTION_AGENT_SIDE_CHAT_ID_CLASS)).getText();
       		}
       		catch(Exception e){}

            com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions.clickConnected(agent_driver2);
            com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions.selectChatInConnected(agent_driver2,"",agent_side_chat_id).click();
            com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions.clickJoinInConnected(agent_driver2);

            etest.log(Status.INFO,agent2_name+" joined the chat of "+agent1_name);
       	}

       	CommonUtil.sleep(1000);

       	return true;
	}

	public static String getChatIdOfCurrentChat(WebDriver visitor_driver,ChatType chat_type) throws Exception
	{
		VisitorWindow.switchToChatWidget(visitor_driver);
		// goToAllChats(visitor_driver);
		if(chat_type!=ChatType.OFFLINE)
		{
			return CommonUtil.getElement(visitor_driver,By.id(ConversationViewConstants.CURRENT_CHATS_CONTAINER_ID),By.className(ConversationViewConstants.CONVERSATION_CHAT_CONTAINER_CLASS)).getAttribute(ConversationViewConstants.CONVERSATION_CHAT_ID_ATTRIBUTE);
		}
		else
		{
			//NOTE : for offline chat. chat container is added under PAST_CHATS_CONTAINER_ID instead of CURRENT_CHATS_CONTAINER_ID. So we get first element in past chats to get lastest chat id.
			//NOTE : For offline message, No chat id is created so ConversationViewConstants.VISITOR_ID_ATTRIBUTE is return instead of ConversationViewConstants.CONVERSATION_CHAT_ID_ATTRIBUTE
			return CommonUtil.getElement(visitor_driver,By.id(ConversationViewConstants.PAST_CHATS_CONTAINER_ID)).findElements(By.className(ConversationViewConstants.CONVERSATION_CHAT_CONTAINER_CLASS)).get(0).getAttribute(ConversationViewConstants.VISITOR_ID_ATTRIBUTE);
		}
	}

	public static Hashtable<String,String> addVisitorDetails(String name,String email,String phone,String department,String question,String feedback,String rating)
	{
		Hashtable<String,String> visitor_details = new Hashtable<String,String>();

		if(name!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_NAME,name);
		}
		if(email!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_EMAIL,email);
		}
		if(phone!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_PHONE,phone);
		}
		if(department!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_DEPARTMENT,department);
		}
		if(question!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_QUESTION,question);
		}
		if(feedback!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_FEEDBACK,feedback);
		}
		if(rating!=null)
		{
			visitor_details.put(ConversationViewConstants.VISITOR_RATING,rating);
		}

		return visitor_details;		
	}

	public static Hashtable<String,List<String>> addMessageDetails(String label,int no_of_messages)
	{

		Hashtable<String,List<String>> messages = new Hashtable<String,List<String>>();

		List<String> agent_messages = new ArrayList<String>();
		List<String> visitor_messages = new ArrayList<String>();

		for(int i=1;i<=no_of_messages;i++)
		{	
			String
			message_label=i+"_"+label,
			agent_message="Agent_"+message_label,
			visitor_message="Visitor_"+message_label;
			agent_messages.add(agent_message);
			visitor_messages.add(visitor_message);
		}

		messages.put(ConversationViewConstants.AGENT_MESSAGES,agent_messages);
		messages.put(ConversationViewConstants.VISITOR_MESSAGES,visitor_messages);

		return messages;
	}

	public static Hashtable<String,List<String>> addMessageDetails(String label)
	{
		//to set default no of messages as 5
		return addMessageDetails(label,5);
	}

	//conversation view UI functions

	public static void clickShowAllChatsButton(WebDriver visitor_driver)
	{
		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.id(ConversationViewConstants.SHOW_ALL_CHATS_BUTTON_ID)));
		CommonUtil.waitTillWebElementDisplayed(visitor_driver,CommonUtil.getElement(visitor_driver,By.id(ConversationViewConstants.CONVERSATION_VIEW_CONTAINER_ID)));
	}

	public static void goToAllChats(WebDriver visitor_driver) throws Exception
	{
		VisitorWindow.switchToChatWidget(visitor_driver);
		if(CommonUtil.getElement(visitor_driver,By.id(ConversationViewConstants.CONVERSATION_VIEW_CONTAINER_ID)).isDisplayed()==false)
		{
			clickShowAllChatsButton(visitor_driver);
		}
	}

	public static void reloadEmbed(WebDriver visitor_driver,String widget_code) throws Exception
	{
		CommonUtil.sleep(5000);
		visitor_driver.navigate().refresh();
		try
		{
			VisitorWindow.createPage(visitor_driver,widget_code);
		}
		catch(TimeoutException e)
		{

		}
	}

	public static WebElement getChatConversationByUniqueId(WebDriver visitor_driver,ChatType chat_type,String unique_id)
	{
		if(chat_type==ChatType.OFFLINE)
		{
			return getOfflineChatConversationByVisitorId(visitor_driver,unique_id);
		}
		else
		{
			return getChatConversationByChatId(visitor_driver,unique_id);
		}
	}

	public static WebElement getChatConversationByChatId(WebDriver driver,String chat_id)
	{
		List<WebElement> previous_chats=driver.findElements(By.className(ConversationViewConstants.CHATS_CLASS_NAME));
		WebElement chat=CommonUtil.getElementByAttributeValue(previous_chats,ConversationViewConstants.CONVERSATION_CHAT_ID_ATTRIBUTE,chat_id);
		return chat;
	}

	public static WebElement getOfflineChatConversationByVisitorId(WebDriver driver,String visitor_id)
	{
		List<WebElement> previous_chats=driver.findElements(By.className(ConversationViewConstants.CHATS_CLASS_NAME));

		for(WebElement chat : previous_chats)
		{
			if(chat.getAttribute(ConversationViewConstants.VISITOR_ID_ATTRIBUTE)!=null && chat.getAttribute(ConversationViewConstants.VISITOR_ID_ATTRIBUTE).equals(visitor_id))
			{
				return chat;	
			}
		}

		return null;
	}

	public static void openChatConversationByChatId(WebDriver driver,String chat_id)
	{
		getChatConversationByChatId(driver,chat_id).click();
		waitTillConversationHistoryMenuNotDisplayed(driver);
	}

	public static void openOfflineChatConversationByVisitorId(WebDriver driver,String visitor_id)
	{
		getOfflineChatConversationByVisitorId(driver,visitor_id).click();
		waitTillConversationHistoryMenuNotDisplayed(driver);
	}

	public static void openChatByUniqueId(WebDriver driver,ChatType chat_type,String unique_id) throws ZohoSalesIQRuntimeException
	{
		try
		{
	        VisitorWindow.switchToChatWidget(driver);

			if(chat_type!=ChatType.OFFLINE)
			{
				openChatConversationByChatId(driver,unique_id);
			}
			else
			{
				openOfflineChatConversationByVisitorId(driver,unique_id);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new ZohoSalesIQRuntimeException("Could not find chat by unique_id "+unique_id+" for chat type "+chat_type);
		}
	}

	public static void waitTillConversationHistoryMenuNotDisplayed(WebDriver driver)
	{
		waitTillConversationHistoryMenuDisplay(driver,false);
	}

	public static void waitTillConversationHistoryMenuDisplayed(WebDriver driver)
	{
		waitTillConversationHistoryMenuDisplay(driver,true);
	}

	public static void waitTillConversationHistoryMenuDisplay(WebDriver driver,final boolean isDisplayed)
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);
		wait.until(new Function<WebDriver,Boolean>()
		{
            public Boolean apply(WebDriver driver)
            {
                if(isConversationViewContainerDisplayed(driver)==isDisplayed)
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static boolean checkPreviousChat(WebDriver driver,ExtentTest etest,String unique_id,ChatType chat_type,Hashtable<String,String> visitor_details,Hashtable<String,List<String>> messages)throws Exception
	{
		int failcount=0;		

		if(checkChatIcon(driver,etest,chat_type,unique_id)==false)	
		{
			failcount++;
			screenshot(driver,etest);
		}
		goToAllChats(driver);
		openChatByUniqueId(driver,chat_type,unique_id);

		String
		expected_visitor_name=visitor_details.get(ConversationViewConstants.VISITOR_NAME),
		expected_agent_name=visitor_details.get(ConversationViewConstants.AGENT_NAME);

		//in case no name was given. 'You' will be shown in visitor site
		if(expected_visitor_name.equals(""))
		{
			expected_visitor_name="You";
		}

		//in case the last message was an attachment. The visitor name will be empty
		if(chat_type.getIsUploadFile())
		{
			expected_visitor_name="";
		}		

		if(checkVisitorName(driver,etest,expected_visitor_name)==false)
		{
			failcount++;
			screenshot(driver,etest);
		}

		if(chat_type!=ChatType.MISSED && chat_type!=ChatType.OFFLINE)
		{
			if(checkAgentName(driver,etest,expected_agent_name)==false)
			{
				failcount++;
				screenshot(driver,etest);
			}

			if(checkPreviousChatMessages(driver,etest,visitor_details,messages)==false)
			{
				failcount++;
				screenshot(driver,etest);
			}

			if(chat_type.getIsUploadFile())
			{
				if(checkFileUpload(driver,etest)==false)
				{
					failcount++;					
				}
			}
		}

		String show_all_chats_use_case="CV7";

		if(CommonUtil.isChecked(show_all_chats_use_case,ConversationViewTests.result)==false)
		{
			try
			{
				goToAllChats(driver);
				ConversationViewTests.result.put(show_all_chats_use_case,true);
				etest.log(Status.PASS,"All chats menu was displayed after 'Show All Chats' was clicked.");
			}
			catch(Exception e)
			{
				ConversationViewTests.result.put(show_all_chats_use_case,false);
				etest.log(Status.FAIL,"All chats menu was NOT displayed after 'Show All Chats' was clicked.");
				TakeScreenshot.screenshot(driver,etest,e);
			}
		}

		return CommonUtil.returnResult(failcount);
	}

	public static void logMessagesFound(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String message_log="";
			List<WebElement> message_elements = CommonUtil.getElement(driver,By.className(ConversationViewConstants.PREVIOUS_CHAT_WINDOW_CONTAINER_CLASS)).findElements(By.xpath(ConversationViewConstants.MESSAGE_DIV_ATTRIBUTE_XPATH));

			if(message_elements.size()==0)
			{
				return;
			}

			for(WebElement message_element : message_elements)
			{
				message_log=message_log+"Message : "+message_element.getAttribute("innerText")+"<br>";
			}
			String messages_list_report_log=TakeScreenshot.getCustomHTMLForReport("Messages found (click here)",message_log);
			etest.log(Status.INFO,messages_list_report_log);
		}
		catch(Exception e){}
	}

	public static boolean checkPreviousChatMessages(WebDriver driver,ExtentTest etest,Hashtable<String,String> visitor_details,Hashtable<String,List<String>> messages)
	{
		int failcount=0;

		int agent_message_index=0,visitor_message_index=0;

		List<String> agent_messages = messages.get(ConversationViewConstants.AGENT_MESSAGES);
		List<String> visitor_messages = messages.get(ConversationViewConstants.VISITOR_MESSAGES);

		int messages_length=agent_messages.size()+visitor_messages.size();

		List<WebElement> message_elements = CommonUtil.getElement(driver,By.className(ConversationViewConstants.PREVIOUS_CHAT_WINDOW_CONTAINER_CLASS)).findElements(By.xpath(ConversationViewConstants.MESSAGE_DIV_ATTRIBUTE_XPATH));

		//logMessagesFound(driver,etest);

		for(int i=0;i<messages_length;i++)
		{
			WebElement message=message_elements.get(i);
			String expected=null,actual=null,message_description=null;

			if(i==0 && visitor_details.containsKey(ConversationViewConstants.VISITOR_QUESTION))
			{
				expected=visitor_details.get(ConversationViewConstants.VISITOR_QUESTION);
				actual=message.getAttribute("innerText");
				message_description="visitor question";

				if(CommonUtil.checkStringContainsAndLog(expected,actual,message_description,etest)==false)
				{
					failcount++;
					try
					{
						CommonUtil.inViewPort(message);
					}
					catch(Exception e){}

					screenshot(driver,etest);
				}
			}
			else
			{
				if(i%2==1)
				{
					expected=agent_messages.get(agent_message_index++);
					message_description="agent message "+agent_message_index;
				}
				else if(i%2==0)
				{
					expected=visitor_messages.get(visitor_message_index++);
					message_description="visitor message "+agent_message_index;
				}

				actual=message.getAttribute("innerText");

				if(CommonUtil.checkStringContainsAndLog(expected,actual,message_description,etest)==false)
				{
					failcount++;
					CommonUtil.inViewPort(message);					
					screenshot(driver,etest);
				}				

			}

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkFileUpload(WebDriver driver,ExtentTest etest)
	{
		return checkFileUpload(driver,etest,true);
	}

	public static boolean checkFileNotUpload(WebDriver driver,ExtentTest etest)
	{
		return checkFileUpload(driver,etest,false);
	}

	public static boolean checkFileUpload(WebDriver driver,ExtentTest etest,boolean isFileUploaded)
	{
		Status file_uploaded_test_status=isFileUploaded?Status.PASS:Status.FAIL;
		Status file_not_uploaded_test_status=isFileUploaded?Status.FAIL:Status.PASS;

		List<WebElement> attachment_element_link_elements=null;

		try
		{
			attachment_element_link_elements=getLastAttachedFileElement(driver).findElements(By.tagName("a"));
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			etest.log(file_not_uploaded_test_status,"No file elements were found.");
			TakeScreenshot.infoScreenshot(driver,etest);
			TakeScreenshot.log(e,etest,Status.INFO);
			return false;
		}

		WebElement attachment_link_element=CommonUtil.getElementByAttributeValue(attachment_element_link_elements,"class",ConversationViewConstants.ATTACHMENT_ANCHOR_TAG_CLASS);		
		String attachment_link=attachment_link_element.getAttribute("href");

		int failcount=0;
		
		boolean isSuccessResponseRecieved=false;

		try
		{
			isSuccessResponseRecieved=SalesIQRestAPICommonFunctions.checkResponseCodeOfURL(attachment_link);
		}
		catch(Exception e){}

		if(isSuccessResponseRecieved)
		{
			etest.log(file_uploaded_test_status,"Attached file was found with a valid link with 200 response code");
		}
		else
		{
			etest.log(file_not_uploaded_test_status,"Attached file was NOT found with a valid link with 200 response code");
			try
			{
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			catch(Exception e2){}

			failcount++;
		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkVisitorName(WebDriver driver,ExtentTest etest,String expected_name)
	{
		String actual_visitor_name=getVisitorName(driver);
		return CommonUtil.checkStringEqualsAndLog(expected_name,actual_visitor_name,"visitor name",etest);
	}

	public static boolean checkAgentName(WebDriver driver,ExtentTest etest,String expected_name)
	{
		String actual_agent_name=getAgentName(driver);
		return CommonUtil.checkStringEqualsAndLog(expected_name,actual_agent_name,"agent name",etest);
	}

	public static boolean checkFirstAgentName(WebDriver driver,ExtentTest etest,String expected_name)
	{
		String actual_agent_name=getFirstAgentName(driver);
		return CommonUtil.checkStringEqualsAndLog(expected_name,actual_agent_name,"agent name(before transfer/invite)",etest);
	}

	public static boolean checkInfoMessage(WebDriver driver,ExtentTest etest,String expected_message)
	{
		String actual_agent_name=getInfoMessage(driver);
		return CommonUtil.checkStringEqualsAndLog(expected_message,actual_agent_name,"info message",etest);
	}

	public static boolean checkTransferInfoMessage(WebDriver driver,ExtentTest etest,TransferType transfer_type)
	{
		String expected_message=transfer_type.getAgentSpecificInfoMessage();
		return checkInfoMessage(driver,etest,expected_message);	
	}

	public static boolean checkChatIcon(WebDriver driver,ExtentTest etest,ChatType chat_type,String unique_id)throws Exception
	{
		String actual_classname=null,expected_classname=null;

		if(chat_type==ChatType.ONGOING)
		{
			actual_classname=getChatTypeIconClassName(driver,chat_type,unique_id);
			expected_classname=chat_type.icon_class_name;			
		}
		else
		{
			actual_classname=getChatIconClassName(driver,chat_type,unique_id);
			expected_classname=chat_type.icon_class_name;			
		}

		checkChatIcons(driver,etest,chat_type);

		if(actual_classname.contains(expected_classname) && ( chat_type==ChatType.OFFLINE || chat_type==ChatType.MISSED || chat_type==ChatType.ONGOING ) )
		{
			etest.log(Status.PASS,"Expected chat icon was found for chat type "+chat_type);
			return true;
		}
		else if( actual_classname.equals(expected_classname) && ( chat_type==ChatType.COMPLETED || chat_type==ChatType.COMPLETED_BASIC ) )
		{
			etest.log(Status.PASS,"Expected chat icon was found for chat type "+chat_type);
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Expected chat icon was found for chat type "+chat_type+"(Expected : "+expected_classname+" Actual : "+actual_classname+")");
			try
			{
				TakeScreenshot.screenshot(driver,etest,ConversationViewTests.MODULE_NAME,"Failure","Visitor window screenshot");
			}
			catch(Exception e){}
		}
		return false;
	}

	public static void waitTillExpectedLastMessageShown(final WebDriver visitor_driver,final ChatType chat_type,final String unique_id,final String expected_last_message)
	{
		FluentWait wait=CommonUtil.waitreturner(visitor_driver,5,250);
		wait.until(new Function<WebDriver,Boolean>()
		{
            public Boolean apply(WebDriver visitor_driver)
            {
                if(getLastMessage(visitor_driver,chat_type,unique_id).contains(expected_last_message))
                {
                    return true;
                }
                return false;
            }
        });
	}

	public static String getChatIconClassName(WebDriver visitor_driver,ChatType chat_type,String unique_id)
	{
		return getChatConversationByUniqueId(visitor_driver,chat_type,unique_id).findElement(By.className(chat_type.AGENT_IMAGE_ICON_CLASS_NAME)).getAttribute("class");		
	}

	public static String getChatTypeIconClassName(WebDriver visitor_driver,ChatType chat_type,String unique_id)
	{
		return getChatTypeElementFromChatElement(visitor_driver,chat_type,unique_id).getAttribute("class");		
	}

	public static String getLastMessage(WebDriver visitor_driver,ChatType chat_type,String unique_id)
	{
		return getChatConversationByUniqueId(visitor_driver,chat_type,unique_id).findElement(By.id(chat_type.last_message_container_id)).getAttribute("innerText");
	}

	public static String getUnreadMessagesCount(WebDriver visitor_driver,ChatType chat_type,String unique_id)
	{
		return getChatTypeElementFromChatElement(visitor_driver,chat_type,unique_id).getAttribute("innerText");
	}

	public static WebElement getChatTypeElementFromChatElement(WebDriver visitor_driver,ChatType chat_type,String unique_id)
	{
		return getChatConversationByUniqueId(visitor_driver,chat_type,unique_id).findElement(By.className(chat_type.CHAT_TYPE_ICON_CLASS_NAME));
	}


	public static String getVisitorName(WebDriver driver)
	{
		return getMessageFromChatWindowByType(driver,ConversationViewConstants.NAME_TYPE_VISITOR);
	}

	public static String getAgentName(WebDriver driver)
	{
		return getMessageFromChatWindowByType(driver,ConversationViewConstants.NAME_TYPE_AGENT);
	}

	public static String getFirstAgentName(WebDriver driver)
	{
		return getMessageFromChatWindowByType(driver,ConversationViewConstants.NAME_TYPE_AGENT,0);
	}

	public static String getInfoMessage(WebDriver driver)
	{
		return getMessageFromChatWindowByType(driver,ConversationViewConstants.MESSAGE_TYPE_INFO);		
	}

	public static WebElement getAttachedFileElement(WebDriver driver,Integer index)
	{
		return getMessageElementFromChatWindowByType(driver,ConversationViewConstants.MESSAGE_TYPE_ATTACHMENT,index);
	}

	public static WebElement getLastAttachedFileElement(WebDriver driver)
	{
		return getAttachedFileElement(driver,null);
	}

	public static WebElement getMessageElementFromChatWindowByType(WebDriver driver,String name_type,Integer index)
	{
		String class_name=null;
		if(name_type.equals(ConversationViewConstants.NAME_TYPE_VISITOR))
		{
			class_name=ConversationViewConstants.VISITOR_NAME_CLASS;
		}
		else if(name_type.equals(ConversationViewConstants.NAME_TYPE_AGENT))
		{
			class_name=ConversationViewConstants.AGENT_NAME_CLASS;
		}
		else if(name_type.equals(ConversationViewConstants.MESSAGE_TYPE_INFO))
		{
			class_name=ConversationViewConstants.INFO_MESSAGE_CLASS;
		}
		else if(name_type.equals(ConversationViewConstants.MESSAGE_TYPE_ATTACHMENT))
		{
			class_name=ConversationViewConstants.ATTACHMENTS_CLASS;
		}

		List<WebElement> names=CommonUtil.getElement(driver,By.className(ConversationViewConstants.PREVIOUS_CHAT_WINDOW_CONTAINER_CLASS)).findElements(By.className(class_name));

		if(index==null)
		{
			index=names.size()-1;
		}

		WebElement message_element=names.get(index);

		try
		{
			CommonUtil.inViewPort(message_element);
		}
		catch(Exception e){}

		return message_element;
	}

	public static String getMessageFromChatWindowByType(WebDriver driver,String name_type,Integer index)
	{
		return getMessageElementFromChatWindowByType(driver,name_type,index).getAttribute("innerText");		
	}

	public static String getMessageFromChatWindowByType(WebDriver driver,String name_type)
	{
		return getMessageFromChatWindowByType(driver,name_type,null);
	}	

	public static Hashtable<String,Boolean> checkOngoingChat(WebDriver visitor_driver,WebDriver agent_driver,ExtentTest etest,String unique_id,Hashtable<String,Boolean> module_result,Hashtable<String,List<String>> messages) throws Exception
	{
		String
		chat_type_icon_use_case="CV6",
		unread_messages_count_usecase="CV13",
		typing_status_usecase="CV14",
		latest_message_usecase="CV15"
		;

		List<String> agent_messages = messages.get(ConversationViewConstants.AGENT_MESSAGES);

		if(checkChatIcon(visitor_driver,etest,ChatType.ONGOING,unique_id))
		{
			module_result.put(chat_type_icon_use_case,true);			
		}
		else
		{
			module_result.put(chat_type_icon_use_case,false);
			screenshot(visitor_driver,etest);
		}

		// goToAllChats(visitor_driver);

		ChatWindow.enterTextInMessageInChatInput(agent_driver,"typing_check"+agent_messages.get(0));

		waitTillExpectedLastMessageShown(visitor_driver,ChatType.ONGOING,unique_id,ConversationViewConstants.TYPING_STATUS_KEYWORD);

		String actual_status=getLastMessage(visitor_driver,ChatType.ONGOING,unique_id);

		if(CommonUtil.checkStringContainsAndLog(ConversationViewConstants.TYPING_STATUS_KEYWORD,actual_status,"typing status",etest))
		{
			module_result.put(typing_status_usecase,true);			
		}
		else
		{
			module_result.put(typing_status_usecase,false);
			screenshot(visitor_driver,etest);
		}


		String expected_latest_message=null;
		for(int i=0;i<agent_messages.size();i++)
		{
			String message="unread_check"+agent_messages.get(i);
			expected_latest_message=message;//test data for use case CV15
			ChatWindow.sentMessage(agent_driver,message);
			CommonUtil.sleep(1000);
		}

		String actual_unread_count=getUnreadMessagesCount(visitor_driver,ChatType.ONGOING,unique_id);
		String expected_unread_count=agent_messages.size()+"";

		//feature disabled
		module_result.put(unread_messages_count_usecase,true);			
		// if(CommonUtil.checkStringEqualsAndLog(expected_unread_count,actual_unread_count,"unread messages count",etest))
		// {
		// 	module_result.put(unread_messages_count_usecase,true);			
		// }
		// else
		// {
		// 	module_result.put(unread_messages_count_usecase,false);
		// 	screenshot(visitor_driver,etest);
		// }

		String actual_latest_message=getLastMessage(visitor_driver,ChatType.ONGOING,unique_id);

		if(CommonUtil.checkStringEqualsAndLog(expected_latest_message,actual_latest_message,"last message",etest))
		{
			module_result.put(latest_message_usecase,true);			
		}
		else
		{
			module_result.put(latest_message_usecase,false);
			screenshot(visitor_driver,etest);
		}		

		return module_result;
	}

	public static boolean clickCreateChatNowFromConversationView(WebDriver driver)
	{
		try
		{
	        VisitorWindow.switchToChatWidget(driver);
		}
		catch(Exception e)
		{

		}

		if(isConversationViewContainerDisplayed(driver))
		{
			CommonUtil.getElement(driver,By.id(ConversationViewConstants.CREATE_NEW_CHAT_FROM_CONVERSATION_VIEW_BUTTON_ID)).click();
			waitTillConversationHistoryMenuNotDisplayed(driver);	
			return true;
		}
		return false;
	}

	public static void screenshot(WebDriver driver,ExtentTest etest)
	{
		try
		{
			TakeScreenshot.screenshot(driver,etest,ConversationViewTests.MODULE_NAME,"Failure","Visitor window screenshot");
		}
		catch(Exception e){}
	}

	public static void executeVisitorIdJSAPI(WebDriver visitor_driver,String visitor_id)
	{
		String js_api=ConversationViewConstants.VISITOR_ID_JSAPI.replaceAll("<visitor-id>",visitor_id);
		((JavascriptExecutor) visitor_driver).executeScript(js_api);
	}

	public static void createPageWithVisitorId(WebDriver driver,String code,String visitor_id) throws Exception
	{
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index1.html");
        executeVisitorIdJSAPI(driver,visitor_id);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submit")));
        CommonUtil.elfinder(driver,"id","code").sendKeys(code);
        CommonUtil.elfinder(driver,"id",Util.setUptracking()).click();
        Thread.sleep(1000);
        CommonUtil.elfinder(driver,"id","submit").click();
                wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        
        WebElement e1 = CommonUtil.elfinder(driver,"id","zsiq_float");
        
        wait = CommonUtil.waitreturner(driver,5,200);

        try
        {
            wait.until(ExpectedConditions.visibilityOf(e1));
        }
        catch(Exception e)
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zsiq_floatmain")).getAttribute("class").contains("zsiqfanim"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement wind = CommonUtil.elfinder(driver,"classname","zls-sptwndw");
            
            wait.until(ExpectedConditions.visibilityOf(wind));
            
            Thread.sleep(1000);
            
            VisitorWindow.clickCloseChatWidget(driver);
        }
        
        e1 = CommonUtil.elfinder(driver,"id","zsiq_float");
        
        wait.until(ExpectedConditions.visibilityOf(e1));
	}


public static void checkChatIcons(WebDriver driver,ExtentTest etest,ChatType chat_type) throws Exception
	{
		if(chat_type==ChatType.ONGOING)
		{
			// CommonSikuli.findInWholePage(driver,"Cviewongoing.png","UI257",etest);
		}
		if(chat_type==ChatType.OFFLINE)
		{
			CommonSikuli.findInWholePage(driver,"Cviewoffline.png","UI258",etest);
			CommonSikuli.findInWholePage(driver,"Cviewchat.png","UI260",etest);

		}
		if(chat_type==ChatType.MISSED)
		{
			CommonSikuli.findInWholePage(driver,"Cviewmissed.png","UI256",etest);
			CommonSikuli.findInWholePage(driver,"Cviewchat.png","UI259",etest);
		}
	}

	public static boolean checkConversationViewStateFoundAsExpected(WebDriver visitor_driver,ExtentTest etest,boolean isFirstChatForVisitor) throws ZohoSalesIQRuntimeException
	{	
		boolean isConversationViewDisplayed=ConversationViewCommonFunctions.isConversationViewContainerDisplayed(visitor_driver);
		String state=isConversationViewDisplayed?"displayed":"NOT displayed";
		boolean expectedIsConversationViewDisplayed=(!isFirstChatForVisitor);

        if(isConversationViewDisplayed==expectedIsConversationViewDisplayed)
        {
	    	etest.log(Status.PASS,"Conversation view was "+state);
        }
        else
        {
        	etest.log(Status.FAIL,"Conversation view was "+state);
			TakeScreenshot.screenshot(visitor_driver,etest,"ConversationView","Failure","Visitor window screenshot");	
			throw new ZohoSalesIQRuntimeException("Conversation view was NOT displayed for WIDGET_CODE:"+ExecuteStatements.getWidgetCodeFromVisitorSite(visitor_driver)+" (isFirstChatForVisitor:"+isFirstChatForVisitor+")");
        }

        return true;
	}	
}
