//$Id$
package com.zoho.livedesk.client.ConversationView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonUtil;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.WebsitesTab;
import com.zoho.livedesk.util.common.actions.Websites;

import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;




public class ConversationViewConstants
{
	/*DOM CONSTANTS*/
	public static final String
	WEBSITE_SETTINGS_CONVERSATION_VIEW_ID="ISCOVERSATION2",
	CONVERSATION_VIEW_CONTAINER_ID="conversioncontainer",
	SHOW_ALL_CHATS_BUTTON_ID="showsiqconv",
	CURRENT_CHATS_CONTAINER_ID="currchatconv",
	PAST_CHATS_CONTAINER_ID="pastchatconv",
	CHATS_CLASS_NAME="siqc_cntbody",
	CONVERSATION_CHAT_CONTAINER_CLASS="siqc_cntbody",
	CONVERSATION_CHAT_ID_ATTRIBUTE="chid",
	VISITOR_ID_ATTRIBUTE="visitorid",
	VISITOR_NAME_CLASS="siq-visitor-name",
	AGENT_NAME_CLASS="siq-user-name",
	INFO_MESSAGE_CLASS="siq-info-message",
	ATTACHMENTS_CLASS="siq-file-attach",
	PREVIOUS_CHAT_WINDOW_CONTAINER_CLASS="siqc_hstrycht",
	MESSAGE_DIV_ATTRIBUTE_XPATH=".//div[@data-field='message']",
	CREATE_NEW_CHAT_FROM_CONVERSATION_VIEW_BUTTON_ID="showsiqchatui",
	ATTACHMENT_ANCHOR_TAG_CLASS="fdload"
	;
	

	/*VARIABLE CONSTANTS*/
	public static final String
	VISITOR_NAME="name",
	VISITOR_EMAIL="email",
	VISITOR_PHONE="phone",
	VISITOR_DEPARTMENT="department",
	VISITOR_QUESTION="question",
	VISITOR_FEEDBACK="feedback",
	VISITOR_RATING="rating",
	AGENT_MESSAGES="agent_messages",
	VISITOR_MESSAGES="visitor_messages",
	AGENT_NAME="agent_name",
	NAME_TYPE_VISITOR="VISITOR",
	NAME_TYPE_AGENT="AGENT",
	MESSAGE_TYPE_INFO="INFO-MESSAGE",
	MESSAGE_TYPE_ATTACHMENT="attachments",
	TYPING_STATUS_KEYWORD="typing",
	VISITOR_QUESTION_AGENT_SIDE_CLASS="t-v-questionmn",
	VISITOR_QUESTION_AGENT_SIDE_CHAT_ID_CLASS="lvst_idtxt";



	/*JSAPI*/
	public static final String
	VISITOR_ID_JSAPI="$zoho.salesiq.ready=function(embedinfo){$zoho.salesiq.visitor.id('<visitor-id>');}";
	
	/*ENUMS*/
	public enum ChatType
	{
		ONGOING("sqico-chat2",true,"convmsg"),
		COMPLETED("siqc_usrimg",true,"desc7"),
		MISSED("sqico-missed",true,"desc7"),
		OFFLINE("sqico-offline",true,"desc7"),
		COMPLETED_BASIC("siqc_usrimg",false,"desc7"),
		INITIATED(null,false,null);

		public String icon_class_name;
		public boolean isGetChatId;
		public String last_message_container_id;
		public static String AGENT_IMAGE_ICON_CLASS_NAME="siqc_usrimg";
		public static String CHAT_TYPE_ICON_CLASS_NAME="siqc_eletype";//it is also container of unread messages count

		public boolean isVisitorInfoBlank=false;
		public boolean isUploadFile=false;
		public boolean isVisitorId=false;

		public FileType file_type=null;
		public String visitor_id=null;


		ChatType(String icon_class_name,boolean isGetChatId,String last_message_container_id)
		{
			this.icon_class_name=icon_class_name;
			this.isGetChatId=isGetChatId;
			this.last_message_container_id=last_message_container_id;
		}

		public void setIsVisitorInfoBlank(boolean isVisitorNameBlank)
		{
			this.isVisitorInfoBlank=isVisitorNameBlank;
		}

		public boolean getIsVisitorInfoBlank()
		{
			return isVisitorInfoBlank;
		}

		public void setIsUploadFile(boolean isUploadFile)
		{
			this.isUploadFile=isUploadFile;
		}

		public boolean getIsUploadFile()
		{
			return isUploadFile;
		}

		public void setUploadFileType(FileType file_type)
		{
			this.file_type=file_type;
		}

		public FileType getUploadFileType() throws ZohoSalesIQRuntimeException
		{
			if(getIsUploadFile()==true)
			{
				return file_type;
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("setIsUploadFile() of file type "+file_type+" was not set as true. To use getUploadFileType(). It is mandatory to set it as true");
			}
		}

		public void setIsVisitorId(boolean isVisitorId)
		{
			this.isVisitorId=isVisitorId;
		}

		public boolean isVisitorId()
		{
			return isVisitorId;
		}

		public String getVisitorId() throws ZohoSalesIQRuntimeException
		{
			if(isVisitorId()==true)
			{
				return visitor_id;
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("isVisitorId() of enum was not set as true. To use getVisitorId(). It is mandatory to set it as true");
			}
		}

		public void setVisitorId(String visitor_id)
		{
			this.visitor_id=visitor_id;
		}
	}

	public enum TransferType
	{
		TRANSFER("Chat Transferred. Hi, <new-agent-name> here!! I'd be happy to assist you further."),
		INVITE("<new-agent-name> has joined this conversation."),
		JOIN("<new-agent-name> has joined this conversation.")
		;

		public String info_message_template;

		public String agent_specific_info_message=null;

		TransferType(String info_message_template)
		{
			this.info_message_template=info_message_template;
		}

		public void setAgentSpecificInfoMessage(String agent_name)
		{
			this.agent_specific_info_message=info_message_template.replaceAll("<new-agent-name>",agent_name);
		}

		public String getAgentSpecificInfoMessage()
		{
			return agent_specific_info_message;
		}
	}
}
