//$Id$
package com.zoho.livedesk.client.GDPR;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import org.openqa.selenium.TimeoutException;

import com.zoho.livedesk.util.common.CryptoUtil;
public class GDPRTests
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="GDPR";
	public static String WIDGET_CODE="",WEBSITE_NAME="";

	public static final String
	VISITOR_INITIATED="VISITOR_INITIATED",
	PROACTIVE="PROACTIVE";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR2")+" & "+KeyManager.getRealValue("GDPR4"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkToggleGDPR(driver,etest,WEBSITE_NAME,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR1")+" & "+KeyManager.getRealValue("GDPR3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkToggleGDPR(driver,etest,WEBSITE_NAME,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR6",checkToggleGDPRVisitorSide(driver,etest,WEBSITE_NAME,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR5"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR5",checkToggleGDPRVisitorSide(driver,etest,WEBSITE_NAME,true));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In cookies settings set 'Do not notify' and check in visitor side and portal side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTrackingConsent(driver,etest,"GDPR7",WEBSITE_NAME,GDPR.TRACKING_DO_NOT_NOTIFY,GDPR.VISITOR_ACTION_GOT_IT);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In cookies settings set 'Notify' and check in visitor side and portal side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTrackingConsent(driver,etest,"GDPR8",WEBSITE_NAME,GDPR.TRACKING_NOTIFY,GDPR.VISITOR_ACTION_GOT_IT);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In cookies settings set 'Notify' and check in visitor side and portal side. Check banner hidden after got it button is clicked");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTrackingConsent(driver,etest,"GDPR9",WEBSITE_NAME,GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT,GDPR.VISITOR_ACTION_GOT_IT);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In cookies settings set 'Notify' and check in visitor side and portal side. Check banner hidden after do not track button is clicked");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTrackingConsent(driver,etest,"GDPR9",WEBSITE_NAME,GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT,GDPR.VISITOR_ACTION_DO_NOT_TRACK);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In chat settings set 'No, I don't wish to notify', initiate chat from visitor and check in visitor side and portal side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatConsent(driver,etest,"GDPR10",WEBSITE_NAME,GDPR.CHAT_DO_NOT_NOTIFY,null,VISITOR_INITIATED);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In chat settings set 'No, I don't wish to notify' initate proactive chat from agent check in visitor side and portal side");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatConsent(driver,etest,"GDPR10",WEBSITE_NAME,GDPR.CHAT_DO_NOT_NOTIFY,null,PROACTIVE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In chat settings set 'Yes, I wish to notify', initiate chat from visitor, accept terms and conditions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatConsent(driver,etest,"GDPR11",WEBSITE_NAME,GDPR.CHAT_NOTIFY,GDPR.CHAT_GDPR_ACCEPT,VISITOR_INITIATED);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In chat settings set 'Yes, I wish to notify', initiate chat from agent, accept terms and condition");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatConsent(driver,etest,"GDPR11",WEBSITE_NAME,GDPR.CHAT_NOTIFY,GDPR.CHAT_GDPR_ACCEPT,PROACTIVE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In chat settings set 'Yes, I wish to notify', initiate chat from visitor, decline terms and conditions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatConsent(driver,etest,"GDPR11",WEBSITE_NAME,GDPR.CHAT_NOTIFY,GDPR.CHAT_GDPR_DECLINE,VISITOR_INITIATED);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("In chat settings set 'Yes, I wish to notify', initiate chat from agent, decline terms and conditions");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatConsent(driver,etest,"GDPR11",WEBSITE_NAME,GDPR.CHAT_NOTIFY,GDPR.CHAT_GDPR_DECLINE,PROACTIVE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR16"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR16",checkTrackingPolicyAffectsChatPolicy(driver,etest,WEBSITE_NAME,null));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR17"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR17",checkTrackingPolicyAffectsChatPolicy(driver,etest,WEBSITE_NAME,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR18"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR18",checkGDPRPolicyRemembered(driver,etest,WEBSITE_NAME));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check empty policy url");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmptyPolicyURL(driver,etest,WEBSITE_NAME);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR21"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR21",checkDeclineThenAcceptChatConsent(driver,etest,WEBSITE_NAME));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("GDPR22"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("GDPR22",checkSendMessageBeforeConsent(driver,etest,WEBSITE_NAME));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check offline GDPR checkbox - Accept conditions then check its not shown again.");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOfflineMessage(driver,etest,"GDPR24",WEBSITE_NAME,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check offline GDPR checkbox - Do not accept conditions then check its shown again.");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkOfflineMessage(driver,etest,"GDPR25",WEBSITE_NAME,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Enable password protection and export chat history as csv");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatHistoryExportPasswordProtection(driver,etest,"GDPR26",ChatHistory.CSV,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Disable password protection and export chat history as csv");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatHistoryExportPasswordProtection(driver,etest,"GDPR27",ChatHistory.CSV,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Enable password protection and export chat history as xlsx");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatHistoryExportPasswordProtection(driver,etest,"GDPR28",ChatHistory.XLSX,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Disable password protection and export chat history as xlsx");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatHistoryExportPasswordProtection(driver,etest,"GDPR29",ChatHistory.XLSX,false);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Enable password protection and export chat transcript as pdf");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatTranscriptPDFPasswordProtection(driver,etest,"GDPR31",WEBSITE_NAME,true);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Disable password protection and export chat transcript as pdf");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatTranscriptPDFPasswordProtection(driver,etest,"GDPR30",WEBSITE_NAME,false);
            ComplexReportFactory.closeTest(etest);
            
            
			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}            
	}

	public static void checkToggleGDPR(WebDriver driver,ExtentTest etest,String embed,Boolean isEnableGDPR) throws Exception
	{
		String portal_usecase=isEnableGDPR?"GDPR2":"GDPR1";
		String website_usecase=isEnableGDPR?"GDPR4":"GDPR3";

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.toggleGDPR(driver,etest,isEnableGDPR);

			if(isEnableGDPR)
			{
			    GDPR.setTracking(driver,GDPR.TRACKING_NOTIFY);
    		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);
			}

			if(GDPR.isAllGDPROptionsFound(driver,etest,isEnableGDPR)==isEnableGDPR)
			{
				etest.log(Status.PASS,"Expected GDPR settings state was found in portal settings");
				result.put(portal_usecase,true);
			}
			else
			{
				etest.log(Status.FAIL,"Expected GDPR settings state was NOT found in portal settings");
				TakeScreenshot.screenshot(driver,etest);
				result.put(portal_usecase,false);
			}

			boolean isToggleFound=(Websites.getGDPRSettingsForWebsite(driver,etest,embed)==null)?false:true;

			if( (isToggleFound && isEnableGDPR) || (!isToggleFound && !isEnableGDPR) )
			{
				etest.log(Status.PASS,"GDPR toggle was "+(isToggleFound?"found":"NOT found")+" in website "+embed+" after GDPR was "+(isEnableGDPR?"enabled":"disabled")+" in portal settings");
				result.put(website_usecase,true);
			}
			else
			{
				etest.log(Status.FAIL,"GDPR toggle was "+(isToggleFound?"NOT found":"found")+" in website "+embed+" after GDPR was "+(isEnableGDPR?"disabled":"enabled")+" in portal settings");
				result.put(website_usecase,false);				
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);		
		}
		finally
		{
			try
			{
				WebsitesTab.closeEmbedConfig(driver,etest);
			}
			catch(Exception e)
			{
				driver.navigate().refresh();
			}
		}
	}

	public static boolean checkToggleGDPRVisitorSide(WebDriver driver,ExtentTest etest,String embed,Boolean isEnableGDPR) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_NOTIFY);

			Websites.setGDPRSettingsForWebsite(driver,etest,embed,isEnableGDPR);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

			if(VisitorWindow.checkGDPRBannerDisplayed(visitor_driver,etest,isEnableGDPR)==false)
			{
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			try
			{
				WebsitesTab.closeEmbedConfig(driver,etest);
			}
			catch(Exception e)
			{
				driver.navigate().refresh();
			}

			return CommonUtil.returnResult(failcount);
		}
	}

	public static void checkTrackingConsent(WebDriver driver,ExtentTest etest,String usecase,String embed,String setting,String visitor_action) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

		String setting_name=GDPR.getTrackingSettingName(setting);

		String policy_url="https://www.wikipedia.org";

		boolean isLearnMoreLink=(setting.equals(GDPR.TRACKING_DO_NOT_NOTIFY)==false);

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,setting);

		    Tab.navToPortalTab(driver);

		    if(!setting.contains(GDPR.TRACKING_DO_NOT_NOTIFY))
		    {
		    	CommonUtil.inViewPort(CommonUtil.getElement(driver,By.id("trackingprivacystatement")));
		    }

		    TakeScreenshot.infoScreenshot(driver,etest);

	    	if(GDPR.setLearnMoreLink(driver,etest,policy_url)==isLearnMoreLink)
	    	{
	    		etest.log(Status.PASS,"Cookie policy url input was "+(isLearnMoreLink?"found":"NOT found")+" in portal setting after "+setting_name+" was selected in portal settings");
	    		result.put(usecase+"_1",true);
	    	}
	    	else
	    	{
	    		result.put(usecase+"_1",false);
	    		etest.log(Status.FAIL,"Cookie policy url input was "+(isLearnMoreLink?"NOT found":"found")+" in portal setting after "+setting_name+" was selected in portal settings");
	    		TakeScreenshot.screenshot(driver,etest);
	    	}

			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

    		result.put(usecase+"_2",GDPR.checkTrackingConsentBanner(visitor_driver,etest,setting));

    		boolean isVisitorTrackedWithoutConsent=setting.equals(GDPR.TRACKING_DO_NOT_NOTIFY);

    		if(VisitorsOnline.waitTillVisitorTracked(driver,visitor_driver)==isVisitorTrackedWithoutConsent)
    		{
    			etest.log(Status.PASS,"Visitor was "+(isVisitorTrackedWithoutConsent?"tracked":"NOT tracked")+" without consent when "+setting_name+" was selected in GDPR tracking settings");
    			result.put(usecase+"_8",true);
    		}
    		else
    		{
    			result.put(usecase+"_8",false);
    			etest.log(Status.FAIL,"Visitor was "+(isVisitorTrackedWithoutConsent?"NOT tracked":"tracked")+" without consent when "+setting_name+" was selected in GDPR tracking settings");
    			TakeScreenshot.screenshot(driver,etest);
    		}
            Tab.navToPortalTab(driver);


		    if(setting.equals(GDPR.TRACKING_DO_NOT_NOTIFY))
		    {
		    	//nothing more to check
		    	return;
		    }

		    if(VisitorWindow.isOkButtonFoundInGDPRBanner(visitor_driver))
		    {
	    		result.put(usecase+"_3",true);
		    	etest.log(Status.PASS,"'Got it' button was found inside GDPR banner in visitor side");
		    }
		    else
		    {
		    	result.put(usecase+"_3",false);
		    	etest.log(Status.FAIL,"'Got it' button was NOT found inside GDPR banner in visitor side");
		    	TakeScreenshot.screenshot(driver,etest);
		    }

		    boolean expected_is_do_not_track_found=setting.equals(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);

		    if(VisitorWindow.isDoNotTrackButtonFoundInGDPRBanner(visitor_driver)==expected_is_do_not_track_found)
		    {
		    	result.put(usecase+"_4",true);
		    	etest.log(Status.PASS,"Opt out option was "+(expected_is_do_not_track_found?"found":"NOT found")+" in visitor side after GDPR setting was set as "+setting_name);
		    }
		    else
		    {
		    	result.put(usecase+"_4",false);
		    	etest.log(Status.FAIL,"Opt out option was "+(expected_is_do_not_track_found?"NOT found":"found")+" in visitor side after GDPR setting was set as "+setting_name);
		    	TakeScreenshot.screenshot(driver,etest);		    	
		    }

		    if(setting.equals(GDPR.TRACKING_DO_NOT_NOTIFY)==false)
		    {
				VisitorWindow.clickGDPRPolicyURL(visitor_driver);

				CommonUtil.sleep(1000);

				CommonUtil.switchToTab(visitor_driver);

				String expected_url=policy_url.replace("https://","");
				String actual_url=visitor_driver.getCurrentUrl();


		    	result.put(usecase+"_5",CommonUtil.checkStringContainsAndLog(expected_url,actual_url,"tracking policy url",etest));

				CommonUtil.switchToTab(visitor_driver,0);
		    }

		    boolean is_banner_hidden=false,is_consent_given=false;
		    //button click

		    String button_usecase=null,tracking_usecase=null;

		    if(visitor_action.equals(GDPR.VISITOR_ACTION_GOT_IT))
		    {
		    	is_consent_given=true;
		    	button_usecase=usecase+"_6";
		    	tracking_usecase=usecase+"_9";
		    	is_banner_hidden=VisitorWindow.clickOkButtonInGDPRBanner(visitor_driver);
		    }
		    else if(visitor_action.equals(GDPR.VISITOR_ACTION_DO_NOT_TRACK))
		    {
		    	is_consent_given=false;
		    	button_usecase=usecase+"_7";
		    	tracking_usecase=usecase+"_10";
		    	is_banner_hidden=VisitorWindow.clickDoNotTrackButtonInGDPRBanner(visitor_driver);
		    }

	    	if(is_banner_hidden)
	    	{
	    		etest.log(Status.PASS,"GDPR banner was hidden after visitor clicked "+visitor_action);
		    	result.put(button_usecase,true);
	    	}
	    	else
	    	{
		    	result.put(button_usecase,false);
	    		etest.log(Status.FAIL,"GDPR banner was NOT hidden after visitor clicked "+visitor_action);
	    		TakeScreenshot.screenshot(driver,etest);
	    	}

    		if(VisitorsOnline.waitTillVisitorTracked(driver,visitor_driver)==is_consent_given)
    		{
    			etest.log(Status.PASS,"Visitor was "+(is_consent_given?"tracked when consent was given":"NOT tracked when consent was NOT given")+"  after "+setting_name+" was selected in GDPR tracking settings");
    			result.put(tracking_usecase,true);
    		}
    		else
    		{
    			result.put(tracking_usecase,false);
    			etest.log(Status.FAIL,"Visitor was "+(is_consent_given?"NOT tracked when consent was given":"tracked when consent was NOT given")+"  after "+setting_name+" was selected in GDPR tracking settings");
    			TakeScreenshot.screenshot(driver,etest);
    		}
	        Tab.navToPortalTab(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static void checkChatConsent(WebDriver driver,ExtentTest etest,String usecase,String embed,String setting,String visitor_action,String chat_type) throws Exception
	{
		String label="test_"+CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

		String setting_name=GDPR.getChatConsentSettingName(setting);

		String policy_url="https://www.wikipedia.org";

		boolean isLearnMoreLink=(setting.equals(GDPR.CHAT_DO_NOT_NOTIFY)==false);

		boolean isConsentShown=(setting.equals(GDPR.CHAT_DO_NOT_NOTIFY)==false);

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_DO_NOT_NOTIFY);//so that the GDPR banner wont affect the automation

		    GDPR.setChatConsent(driver,setting);

	    	if(GDPR.setChatConsentLearnMoreLink(driver,etest,policy_url)==isLearnMoreLink)
	    	{
	    		etest.log(Status.PASS,"Chat consent policy url input was "+(isLearnMoreLink?"found":"NOT found")+" in portal setting after "+setting_name+" was selected in portal settings");
	    		result.put(usecase+"_1",true);
	    	}
	    	else
	    	{
	    		result.put(usecase+"_1",false);
	    		etest.log(Status.FAIL,"Chat consent policy url input was "+(isLearnMoreLink?"NOT found":"found")+" in portal setting after "+setting_name+" was selected in portal settings");
	    		TakeScreenshot.screenshot(driver,etest);
	    	}

			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

		    //initaite chat by chat type
		    String chat_initiate_usecase=null;

		    if(chat_type.equals(VISITOR_INITIATED))
		    {
			    chat_initiate_usecase=usecase+"_2";

		    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);
		    }
		    else if(chat_type.equals(PROACTIVE))
		    {
			    chat_initiate_usecase=usecase+"_8";

	            String visitor_id = VisitorWindow.getVisitorId(visitor_driver,ExecuteStatements.getPortal(driver));
				Tab.clickVisitorsOnline(driver);
				VisitorsOnline.waitTillVisitorStableInRings(VisitorsOnline.getVisitor(driver,visitor_id));
				ChatWindow.initiateChat(driver,visitor_id,label);
				VisitorWindow.switchToChatWidget(visitor_driver);
				VisitorWindow.isCurrentChatDisplayed(visitor_driver);//wait till current chat displayed
				CommonUtil.sleep(3000);//if message is sent as soon as proactive chat window is opened. It is not clickable sometimes so adding after sleep
				VisitorWindow.sentMessageInTheme(visitor_driver,label);
			}

			if(VisitorWindow.isChatConsentContainerDisplayed(visitor_driver)==isConsentShown)
			{
				etest.log(Status.PASS,"Chat consent container was "+(isConsentShown?"shown":"NOT shown")+" when chat was initiated");
				result.put(chat_initiate_usecase,true);
			}
			else
			{
				result.put(chat_initiate_usecase,false);
				etest.log(Status.FAIL,"Chat consent container was "+(isConsentShown?"NOT shown":"shown")+" when chat was initiated");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

			if(setting.equals(GDPR.CHAT_DO_NOT_NOTIFY))
			{
				//nothing more to check
				return;
			}

			result.put("GDPR15",VisitorWindow.verifyChatConsentText(visitor_driver,etest));

		    //click URL
		    if(setting.equals(GDPR.CHAT_DO_NOT_NOTIFY)==false)
		    {
				VisitorWindow.clickChatConsentPolicyURL(visitor_driver);

				CommonUtil.sleep(1000);

				CommonUtil.switchToTab(visitor_driver);

				String expected_url=policy_url.replace("https://","");
				String actual_url=visitor_driver.getCurrentUrl();

				//result
		    	result.put("GDPR14",CommonUtil.checkStringContainsAndLog(expected_url,actual_url,"chat policy url",etest));

				CommonUtil.switchToTab(visitor_driver,0);
		    }

		    //click button
		    if(visitor_action.equals(GDPR.CHAT_GDPR_ACCEPT))
		    {
		    	VisitorWindow.clickAcceptInChatConsent(visitor_driver);

			    if(chat_type.equals(VISITOR_INITIATED))
			    {
			    	result.put(usecase+"_5",false);
			    	if( (VisitorWindow.checkWaitingDiv(visitor_driver)) && (ChatRouting.isChatRoutedToAgents(etest,driver).get(ExecuteStatements.getUserName(driver))) )
			    	{
			    		result.put(usecase+"_5",true);
			    		etest.log(Status.PASS,"Chat was successfully initiated by visitor after accepting the chat consent terms and conditions");
			    	}
			    	else
			    	{
			    		etest.log(Status.FAIL,"Chat was NOT successfully initiated by visitor after accepting the chat consent terms and conditions");
			    		TakeScreenshot.screenshot(driver,etest);
			    		TakeScreenshot.screenshot(visitor_driver,etest);
			    	}
			    }
				else if(chat_type.equals(PROACTIVE))
				{
					if(ChatWindow.continueChat(driver))
					{
			    		result.put(usecase+"_6",true);
						etest.log(Status.PASS,"Proactive chat was successfully initiated");
					}
					else
					{
			    		result.put(usecase+"_6",false);
						etest.log(Status.FAIL,"Proctive was not successfully initiated.");
						TakeScreenshot.screenshot(driver,etest);
						TakeScreenshot.screenshot(visitor_driver,etest);
					}

					TilesUI.forceCloseTilesUI(driver);
			    }
		    }
		    else if(visitor_action.equals(GDPR.CHAT_GDPR_DECLINE))
		    {
		    	VisitorWindow.clickDeclineInChatConsent(visitor_driver);

		    	if(VisitorWindow.isChatWindowHidden(visitor_driver))
		    	{
		    		etest.log(Status.PASS,"Chat window was hidden after visitor declined to the chat GDPR terms and conditions");
		    		result.put("GDPR12",true);

		    	}
		    	else
		    	{
		    		result.put("GDPR12",true);
		    		etest.log(Status.FAIL,"Chat window was NOT hidden after visitor declined to the chat GDPR terms and conditions");
		    		TakeScreenshot.screenshot(driver,etest);
		    		TakeScreenshot.screenshot(visitor_driver,etest);
		    	}
		    }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			driver.navigate().refresh();
		}
	}

	public static boolean checkTrackingPolicyAffectsChatPolicy(WebDriver driver,ExtentTest etest,String embed,Boolean isAcceptTracking) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
		String setting_name=GDPR.getTrackingSettingName(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		int failcount=0;

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);
			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

		    if(isAcceptTracking!=null && !isAcceptTracking)
		    {
		    	VisitorWindow.clickDoNotTrackButtonInGDPRBanner(visitor_driver);
		    }
		    else if(isAcceptTracking!=null && isAcceptTracking)
		    {
		    	throw new ZohoSalesIQRuntimeException("Unsupported function parameter passed. set as null or false ONLY. isAcceptTracking : "+isAcceptTracking);
		    }

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);

	    	VisitorWindow.clickAcceptInChatConsent(visitor_driver);

	    	if( (VisitorWindow.checkWaitingDiv(visitor_driver)) && (ChatRouting.isChatRoutedToAgents(etest,driver).get(ExecuteStatements.getUserName(driver))) )
	    	{
	    		etest.log(Status.PASS,"Chat was successfully initiated by visitor after accepting the chat consent terms and conditions");
	    	}
	    	else
	    	{
	    		failcount++;
	    		etest.log(Status.FAIL,"Chat was NOT successfully initiated by visitor after accepting the chat consent terms and conditions");
	    		TakeScreenshot.screenshot(driver,etest);
	    		TakeScreenshot.screenshot(visitor_driver,etest);
	    	}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkGDPRPolicyRemembered(WebDriver driver,ExtentTest etest,String embed) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
		String tracking_setting_name=GDPR.getTrackingSettingName(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		String chat_settting_name=GDPR.getChatConsentSettingName(GDPR.CHAT_NOTIFY);
		int failcount=0;

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);
			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

	    	VisitorWindow.clickOkButtonInGDPRBanner(visitor_driver);

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);

	    	VisitorWindow.clickAcceptInChatConsent(visitor_driver);

	    	ChatWindow.acceptChat(driver,etest);
	    	VisitorWindow.endChatVisitor(visitor_driver);
        	VisitorWindow.enterFeedbackInTheme(visitor_driver,"Feedback","3");

	    	visitor_driver.navigate().refresh();
	    	VisitorsOnline.waitTillVisitorLeaves(driver);

		    VisitorWindow.createPage(visitor_driver,widget_code);

		    if(VisitorWindow.checkGDPRBannerDisplayed(visitor_driver,etest,false)==false)
		    {
		    	failcount++;
		    }

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);

	    	if(VisitorWindow.isChatConsentContainerDisplayed(visitor_driver)==false)
	    	{
	    		etest.log(Status.PASS,"Chat consent container was not shown after visitor already accepted it during previous visit");
	    	}
	    	else
	    	{
	    		etest.log(Status.FAIL,"Chat consent container was shown even after visitor already accepted it during previous visit");
	    		TakeScreenshot.screenshot(driver,etest);
	    		failcount++;
	    	}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkEmptyPolicyURL(WebDriver driver,ExtentTest etest,String embed) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
		String tracking_setting_name=GDPR.getTrackingSettingName(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		String chat_settting_name=GDPR.getChatConsentSettingName(GDPR.CHAT_NOTIFY);

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);

			//need to perform the following actions to set url as blank

			GDPR.setLearnMoreLink(driver,etest,"");
		    GDPR.setTracking(driver,GDPR.TRACKING_DO_NOT_NOTIFY);
		    GDPR.setTracking(driver,GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);

		    GDPR.setChatConsentLearnMoreLink(driver,etest,"");
		    GDPR.setChatConsent(driver,GDPR.CHAT_DO_NOT_NOTIFY);
		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);

			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

		    if(VisitorWindow.getCookiePolicyLinkElement(visitor_driver)==null)
		    {
		    	etest.log(Status.PASS,"Cookie policy link was not found after it was left blank");
		    	result.put("GDPR19",true);
		    }
		    else
		    {
		    	result.put("GDPR19",false);
		    	etest.log(Status.FAIL,"Cookie policy link was found even after it was left blank");
		    	TakeScreenshot.screenshot(driver,etest);
		    }

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);

	    	if(VisitorWindow.getChatConsentLinkElement(visitor_driver)==null)
	    	{
		    	etest.log(Status.PASS,"Chat consent policy link was not found after it was left blank");
		    	result.put("GDPR20",true);
		    }
		    else
		    {
		    	result.put("GDPR20",false);
		    	etest.log(Status.FAIL,"Chat consent policy link was found even after it was left blank");
		    	TakeScreenshot.screenshot(driver,etest);
		    }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static boolean checkDeclineThenAcceptChatConsent(WebDriver driver,ExtentTest etest,String embed) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
		String tracking_setting_name=GDPR.getTrackingSettingName(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		String chat_settting_name=GDPR.getChatConsentSettingName(GDPR.CHAT_NOTIFY);
		int failcount=0;

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_DO_NOT_NOTIFY);
		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);
			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);
	    	VisitorWindow.clickDeclineInChatConsent(visitor_driver);

	    	visitor_driver.navigate().refresh();

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);
	    	VisitorWindow.clickAcceptInChatConsent(visitor_driver);

	    	if( (VisitorWindow.checkWaitingDiv(visitor_driver)) && (ChatRouting.isChatRoutedToAgents(etest,driver).get(ExecuteStatements.getUserName(driver))) )
	    	{
	    		etest.log(Status.PASS,"Chat was successfully initiated by visitor after declining then accepting the chat consent terms and conditions");
	    	}
	    	else
	    	{
	    		failcount++;
	    		etest.log(Status.FAIL,"Chat was NOT successfully initiated by visitor after declineing then accepting the chat consent terms and conditions");
	    		TakeScreenshot.screenshot(driver,etest);
	    		TakeScreenshot.screenshot(visitor_driver,etest);
	    	}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkSendMessageBeforeConsent(WebDriver driver,ExtentTest etest,String embed) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
		String tracking_setting_name=GDPR.getTrackingSettingName(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		String chat_settting_name=GDPR.getChatConsentSettingName(GDPR.CHAT_NOTIFY);
		int failcount=0;

		try
		{
            Tab.navToPortalTab(driver);

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_DO_NOT_NOTIFY);
		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);
			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

	    	VisitorWindow.setupChat(driver,visitor_driver,etest,widget_code,label,ChatType.INITIATED);

	    	VisitorWindow.sentMessageInTheme(visitor_driver,label+"_1");
	    	VisitorWindow.sentMessageInTheme(visitor_driver,label+"_2");
	    	VisitorWindow.sentMessageInTheme(visitor_driver,label+"_3");

	    	boolean isMessageRecieved=false;

	    	try
	    	{
		    	VisitorWindow.waitTillMessageInChat(visitor_driver,label+"_1",2);
		    	VisitorWindow.waitTillMessageInChat(visitor_driver,label+"_2",2);
		    	VisitorWindow.waitTillMessageInChat(visitor_driver,label+"_3",2);
		    	isMessageRecieved=true;
	    	}
	    	catch(TimeoutException e1)
	    	{
	    		isMessageRecieved=false;
	    	}


	    	if(!isMessageRecieved)
	    	{
	    		etest.log(Status.PASS,"Messages sent when visitor did not accept or decline the consent were not sent.");
	    	}
	    	else
	    	{
	    		failcount++;
	    		etest.log(Status.FAIL,"Messages sent when visitor did not accept or decline the consent were sent. messages--> "+(label+"_1")+" ,"+(label+"_2")+" , and "+(label+"_3"));
	    		TakeScreenshot.screenshot(driver,etest);
	    		TakeScreenshot.screenshot(visitor_driver,etest);
	    	}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkOfflineMessage(WebDriver driver,ExtentTest etest,String usecase,String embed,boolean isConsent) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
		String tracking_setting_name=GDPR.getTrackingSettingName(GDPR.TRACKING_NOTIFY_AND_PROVIDE_OPTOUT);
		String chat_settting_name=GDPR.getChatConsentSettingName(GDPR.CHAT_NOTIFY);

		try
		{
            Tab.navToPortalTab(driver);

			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

			GDPR.enableGDPR(driver,etest);
		    GDPR.setTracking(driver,GDPR.TRACKING_DO_NOT_NOTIFY);
		    GDPR.setChatConsent(driver,GDPR.CHAT_NOTIFY);
			Websites.setGDPRSettingsForWebsite(driver,etest,embed,true);

		    visitor_driver=visitor_driver_manager.getDriver(driver);
		    VisitorWindow.createPage(visitor_driver,widget_code);

		    if(VisitorWindow.checkChatWidgetOffline(visitor_driver)==false)
		    {
		    	etest.log(Status.ERROR,"Chat window was not found as offline even after agent status ws changed to busy. Test will fail");
		    }
		    else
		    {
		    	etest.log(Status.PASS,"Chat window found as offline");
		    	TakeScreenshot.infoScreenshot(visitor_driver,etest);
		    }

		    //open chat window
		    VisitorWindow.clickChatButton(visitor_driver);

		    //is checkbox shown
		    if(VisitorWindow.isOfflineConsentDisplayed(visitor_driver))
		    {
		    	etest.log(Status.PASS,"Offline consent checkbox was shown in offline chat window");
		    	result.put("GDPR23",true);
		    }
		    else
		    {
		    	result.put("GDPR23",false);
		    	etest.log(Status.FAIL,"Offline consent checkbox was NOT shown in offline chat window");
		    	TakeScreenshot.screenshot(driver,etest);
		    	TakeScreenshot.screenshot(visitor_driver,etest);
		    }

		    //set checkbox
		    VisitorWindow.setOfflineConsent(visitor_driver,isConsent);

		    //submit

		    VisitorWindow.sendKeysToXpathFromResourceFile(visitor_driver,"Theme.question",label);
		    
		    boolean isSubmitted;
		    try
		    {
			    VisitorWindow.clickSubmit(visitor_driver);
			    isSubmitted=true;
		    }
		    catch(ZohoSalesIQRuntimeException e1)
		    {
		    	isSubmitted=false;
		    }

		    //is submitted
		    if(isSubmitted==isConsent)
		    {
		    	etest.log(Status.PASS,"Offline message was "+(isSubmitted?"submitted":"NOT submitted")+" after visitor "+(isConsent?"clicked":"did not")+" accept terms and conditions");
		   		result.put(usecase+"_1",true);
		    }
		    else
		    {
		   		result.put(usecase+"_1",false);
		    	etest.log(Status.FAIL,"Offline message was "+(isSubmitted?"NOT submitted":"submitted")+" after visitor "+(isConsent?"did not":"clicked")+" accept terms and conditions");
		    	TakeScreenshot.screenshot(driver,etest);
		    	TakeScreenshot.screenshot(visitor_driver,etest);
		    }

		    //open submit again
		    VisitorWindow.createPage(visitor_driver,widget_code);
		    VisitorWindow.clickChatButton(visitor_driver);
		    ConversationViewCommonFunctions.clickCreateChatNowFromConversationView(visitor_driver);

		    //is checkbox shown
		    boolean isCheckboxShown=VisitorWindow.isOfflineConsentDisplayed(visitor_driver);
		    if(isCheckboxShown!=isConsent)
		    {
		    	etest.log(Status.PASS,"Offline consent checkbox was "+(isCheckboxShown?"shown":"NOT shown")+" in offline chat window after visitor "+(isConsent?"agreed":"did not agree")+" the terms and conditions checkbox");
   		   		result.put(usecase+"_2",true);
   		   		TakeScreenshot.infoScreenshot(visitor_driver,etest);
		    }
		    else
		    {
   		   		result.put(usecase+"_2",false);
		    	etest.log(Status.FAIL,"Offline consent checkbox was "+(isCheckboxShown?"NOT shown":"shown")+" in offline chat window after visitor "+(isConsent?"did not agree":"agreed")+" the terms and conditions checkbox");
		    	TakeScreenshot.screenshot(driver,etest);
		    	TakeScreenshot.screenshot(visitor_driver,etest);
		    }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			try
			{
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}
		}
	}

	public static void checkChatHistoryExportPasswordProtection(WebDriver driver,ExtentTest etest,String usecase,String export_type,boolean isPasswordProtected) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		String expected_extension=export_type;

		try
		{
			if(isPasswordProtected && export_type.equals(ChatHistory.CSV))
			{
				expected_extension="zip";
			}

            Tab.navToPortalTab(driver);
			GDPR.enableGDPR(driver,etest);
			GDPR.setPasswordProtection(driver,isPasswordProtected);

			Tab.clickChatHistory(driver);

			String old_file_download_text=ChromeDownloadManager.getLatestDownloadText(driver,etest);

			String password=null;

			if(isPasswordProtected)
			{
				password=CommonUtil.getUniqueMessage();
			}

			ChatHistory.exportAs(driver,export_type,password);
			etest.log(Status.INFO,"Chat history was exported with export type "+export_type+" and password "+password);

			CommonUtil.sleep(20000);//wait till file downloaded

			if(ChromeDownloadManager.isNewFileDownloaded(driver,etest,old_file_download_text)==false)
			{
				throw new ZohoSalesIQRuntimeException("File was not downloaded");
			}

			String downloaded_file_name=ChromeDownloadManager.getLatestDownloadedFileName(driver,etest);

			if( CommonUtil.checkStringEqualsAndLog( expected_extension,FileUpload.getFileExtension(downloaded_file_name),"extension",etest )  )
			{
				result.put(usecase+"_1",true);
			}
			else
			{
				result.put(usecase+"_1",false);
			}

			if(expected_extension.equals(ChatHistory.CSV))
			{
				return;
			}

			if(SCPUtil.getDownloadedFile(driver,downloaded_file_name))
			{
				etest.log(Status.PASS,"Downloaded file from node was successfully transfered to hub for password verification");
			}
			else
			{
				etest.log(Status.ERROR,"Downloaded file from node was NOT successfully transfered to hub, Cannot verify password");
				return;
			}

			String downloaded_file_in_hub_filepath=SCPUtil.getSCPFilePath(driver,downloaded_file_name);

			boolean isPasswordProtectedActual;

			if(expected_extension.equals("zip"))
			{
				isPasswordProtectedActual=CryptoUtil.isZipPasswordProtected(downloaded_file_in_hub_filepath);
			}
			else if(expected_extension.equals(ChatHistory.XLSX))
			{
				isPasswordProtectedActual=CryptoUtil.isDocumentPasswordProtected(etest,downloaded_file_in_hub_filepath);
			}
			else
			{
				throw new ZohoSalesIQRuntimeException("Unsupported extension : "+expected_extension);
			}

			if(isPasswordProtectedActual==isPasswordProtected)
			{
				etest.log(Status.PASS,expected_extension+" file was found "+(isPasswordProtected?"with password":"without password")+" as expected");
				result.put(usecase+"_2",true);
			}
			else
			{
				etest.log(Status.FAIL,expected_extension+" file was found "+(isPasswordProtected?"without password":"with password")+".");
				result.put(usecase+"_2",false);
			}

			if(isPasswordProtected)
			{
				boolean isExpectedPassword;

				if(expected_extension.equals("zip"))
				{
					isExpectedPassword=CryptoUtil.isZipPassword(etest,downloaded_file_in_hub_filepath,password);
				}
				else if(expected_extension.equals(ChatHistory.XLSX))
				{
					isExpectedPassword=CryptoUtil.isDocumentPassword(etest,downloaded_file_in_hub_filepath,password);
				}
				else
				{
					throw new ZohoSalesIQRuntimeException("Unsupported extension : "+expected_extension);
				}

				if(isExpectedPassword)
				{
					etest.log(Status.PASS,expected_extension+" file was found with password '"+password+"' as expected");
					result.put(usecase+"_3",true);
				}
				else
				{
					etest.log(Status.FAIL,expected_extension+" file was NOT found with password '"+password+"' as expected");
					result.put(usecase+"_3",false);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static void checkChatTranscriptPDFPasswordProtection(WebDriver driver,ExtentTest etest,String usecase,String embed,boolean isPasswordProtected) throws Exception
	{
		String label=CommonUtil.getUniqueMessage();
		String expected_extension="pdf";

		WebDriver visitor_driver=null;
		String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

		String current_url=driver.getCurrentUrl();

		try
		{
            Tab.navToPortalTab(driver);
			GDPR.enableGDPR(driver,etest);
			GDPR.setPasswordProtection(driver,isPasswordProtected);
		    GDPR.setChatConsent(driver,GDPR.CHAT_DO_NOT_NOTIFY);

			String old_file_download_text=ChromeDownloadManager.getLatestDownloadText(driver,etest);

			String password=null;

			if(isPasswordProtected)
			{
				password=CommonUtil.getUniqueMessage();
			}

			visitor_driver=visitor_driver_manager.getDriver(driver);

			com.zoho.livedesk.client.ChatHistory.ChatHistoryTests.quickChat(driver,visitor_driver,etest,widget_code,label,true,ChatType.COMPLETED);

			Tab.clickChatHistory(driver);
			ChatHistory.clickLatestChatFromChatHistory(driver);
			ChatHistoryChat.selectActionFromDropdown(driver,ChatHistoryChat.ACTIONS_SAVE_PDF);
			if(password!=null)
			{
				HandleCommonUI.authenticateFileDownloadPopup(driver,password);
			}

			CommonUtil.sleep(20000);//wait till file downloaded

			driver.get(current_url);//download link url is a blank page, so we are returning to salesiq url

			if(ChromeDownloadManager.isNewFileDownloaded(driver,etest,old_file_download_text)==false)
			{
				throw new ZohoSalesIQRuntimeException("File was not downloaded");
			}

			String downloaded_file_name=ChromeDownloadManager.getLatestDownloadedFileName(driver,etest);

			if( CommonUtil.checkStringEqualsAndLog( expected_extension,FileUpload.getFileExtension(downloaded_file_name),"extension",etest )  )
			{
				result.put(usecase+"_1",true);
			}
			else
			{
				result.put(usecase+"_1",false);
			}

			if(SCPUtil.getDownloadedFile(driver,downloaded_file_name))
			{
				etest.log(Status.PASS,"Downloaded file from node was successfully transfered to hub for password verification");
			}
			else
			{
				etest.log(Status.ERROR,"Downloaded file from node was NOT successfully transfered to hub, Cannot verify password");
				return;
			}

			String downloaded_file_in_hub_filepath=SCPUtil.getSCPFilePath(driver,downloaded_file_name);

			if(CryptoUtil.isPDFPasswordProtected(downloaded_file_in_hub_filepath)==isPasswordProtected)
			{
				etest.log(Status.PASS,expected_extension+" file was found "+(isPasswordProtected?"with password":"without password")+" as expected");
				result.put(usecase+"_2",true);
			}
			else
			{
				etest.log(Status.FAIL,expected_extension+" file was found "+(isPasswordProtected?"without password":"with password")+".");
				result.put(usecase+"_2",false);
			}

			if(isPasswordProtected)
			{
				if(CryptoUtil.isPDFPassword(etest,downloaded_file_in_hub_filepath,password))
				{
					etest.log(Status.PASS,expected_extension+" file was found with password '"+password+"' as expected");
					result.put(usecase+"_3",true);
				}
				else
				{
					etest.log(Status.FAIL,expected_extension+" file was NOT found with password '"+password+"' as expected");
					result.put(usecase+"_3",false);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{
			
		}
	}
}
