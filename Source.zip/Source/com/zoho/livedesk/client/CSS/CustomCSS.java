//$Id$
package com.zoho.livedesk.client.CSS;

import java.util.*;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;

public class CustomCSS
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="CustomCSS";
	public static String WIDGET_CODE="",WEBSITE_NAME="";

	public static VisitorDriverManager visitor_driver_manager;

	public static final By
    SMILEY = By.id("smiley"),
    MAIL_ICON = By.id("sqico-smail"),
    MESSAGE_AREA = By.id("msgarea"),
    VISITOR_NAME = By.id("visname"),
    SUBMIT_BUTTON = By.id("submit"),
    SMILEY_LIST = By.id("smilelist"),
    TEXT_EDITOR = By.id("txteditor"),
    VISITOR_EMAIL = By.id("visemail"),
    VISITOR_PHONE = By.id("visphone"),
    FEEDBACK_AREA = By.id("fdbkarea"),
    SEND_EMAIL_ICON = By.id("sendmail"),
    CUSTOM_CSS = By.id("customcssupload"),
    CHAT_WIDGET_FRAME = By.id("siqiframe"),
    CLOSE_ICON = By.className("sqico-close"),
    VISITOR_SIDE_MESSAGE_TIME = By.className("siq-message-time")
    ;

	public static Hashtable checkCSS(WebDriver driver)
	{
    	WebDriver visitor_driver = null;
		try
		{
            result = new Hashtable<String,Boolean>();

            visitor_driver_manager = new VisitorDriverManager(null);

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
			WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

    		visitor_driver = visitor_driver_manager.getDriver(driver);

            // // Upload CSS file
            // etest=ComplexReportFactory.getTest("upload CSS");
            // ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            // uploadCSS(driver,etest);
            // ComplexReportFactory.closeTest(etest);

            //newsletter, checkbox, label
    		etest=ComplexReportFactory.getTest("Check News Letter CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkNewsLetterCSS(driver,visitor_driver,etest);					
            ComplexReportFactory.closeTest(etest);

            //header, company logo, footer
    		etest=ComplexReportFactory.getTest("Check Visitor Window Start Page CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkChatWindowMainPageCSS(driver,visitor_driver,etest);			
            ComplexReportFactory.closeTest(etest);

            //textbox, dropdown, mandatory fields, message area
    		etest=ComplexReportFactory.getTest("Check Visitor window Visitor Info CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkVisitorInfoCSS(driver,visitor_driver,etest);					
            ComplexReportFactory.closeTest(etest);

            //information banner, timer, information message area, close icon
    		etest=ComplexReportFactory.getTest("Check Visitor window information banner CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkInformationBannerCSS(driver,visitor_driver,etest);				
            ComplexReportFactory.closeTest(etest);

            //attender name, attender description
    		etest=ComplexReportFactory.getTest("Check Visitor window Agent info CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkAgentInfoCSS(driver,visitor_driver,etest);						
            ComplexReportFactory.closeTest(etest);

            //messaging area, text typing area,operator typing status,url sharing
        	etest=ComplexReportFactory.getTest("Check Visitor window Messaging Area CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkMessagingAreaCSS(driver,visitor_driver,etest);					
            ComplexReportFactory.closeTest(etest);

            //cancel button, update button
    		etest=ComplexReportFactory.getTest("Check Visitor window edit user info CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkEditOptionsCSS(driver,visitor_driver,etest);					
            ComplexReportFactory.closeTest(etest);

            //message send button, minimize button, menu icon, chat end icon, emoji section, individual emoji, emoji icon, send email, send email text field
    		etest=ComplexReportFactory.getTest("Check Visitor window Icons CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkIconsCSS(driver,visitor_driver,etest);							
            ComplexReportFactory.closeTest(etest);

            //operator message area, name, time, message, visitor message area, name, message, attachments
    		etest=ComplexReportFactory.getTest("Check Visitor window Messages CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkMessageCSS(driver,visitor_driver,etest);						
            ComplexReportFactory.closeTest(etest);

            //feedback, rating, feedback area
    		etest=ComplexReportFactory.getTest("Check Visitor window feedback area CSS");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
    		checkFeedBackAreaCSS(driver,visitor_driver,etest);					
            ComplexReportFactory.closeTest(etest);
		 }
        catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.infoScreenshot(visitor_driver,etest);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			visitor_driver_manager.terminateAllDriverSessions();
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}
    }

    public static void setUpVisitorWindow(WebDriver visitor_driver) throws Exception
    {
        for(int i = 0 ; i < 3; i++)
        {
            try
            {
                VisitorWindow.createPage(visitor_driver,WIDGET_CODE);
                VisitorWindow.clickChatButton(visitor_driver);
                VisitorWindow.switchToChatWidget(visitor_driver);
                break;
            }
            catch(Exception e)
            {
                CommonUtil.refreshPage(visitor_driver);
            }
        }
    }

    public static void uploadCSS(WebDriver driver,ExtentTest etest) throws Exception
    {
    	Tab.navToEmbedTab(driver);

		WebEmbed.clickWebEmbed(driver,WEBSITE_NAME,etest);

		WebsitesTab.clickLiveChat(driver,etest);

		WebsitesTab.clickChatWindow(driver,etest);

		Websites.setStatusOfToggle(driver,"ISCUSTOMCSS2",true,etest);

		FileUpload.uploadFile(CommonUtil.getElement(driver,CUSTOM_CSS),FileType.CUSTOM_CSS_FILE);

		CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.getElement(driver,CUSTOM_CSS),"title","customcss.css");

		Websites.clickSave(driver,etest);

		WebsitesTab.closeEmbedConfig(driver,etest);
    }

    public static void checkVisitorInfoCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	try
    	{
    		VisitorWindow.switchToChatWidget(visitor_driver);
    		CommonUtil.sendKeysToWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_NAME),"test");
    		CommonUtil.sendKeysToWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_PHONE),"12345");
    		CommonSikuli.findInWholePage(visitor_driver,"UI392.png","UI392",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI393.png","UI393",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI394.png","UI394",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI395.png","UI395",etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkAgentInfoCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	String label = CommonUtil.getUniqueMessage();
    	String visname = "V"+label;
    	String visemail = "email@"+label+".com";
    	String visphone = "+"+label;
    	String visques = "Hi there";
    	String dept;
    	try
    	{
    		dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
    		setUpVisitorWindow(visitor_driver);
    		VisitorWindow.initiateChatVisTheme(visitor_driver,visname,visemail,visphone,dept,visques,etest);
    		ChatWindow.acceptChat(driver,etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI384.png","UI384",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI385.png","UI385",etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkMessagingAreaCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	String label = CommonUtil.getUniqueMessage();
    	try
    	{
    		ChatWindow.shareURL(driver,"www.zoho.com");
        	CommonUtil.getElement(ChatWindow.chatInMyChats(driver),TEXT_EDITOR).sendKeys(label);
        	CommonUtil.getElement(ChatWindow.chatInMyChats(driver),TEXT_EDITOR).clear();
    		CommonSikuli.findInWholePage(visitor_driver,"UI398.png","UI398",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI397.png","UI397",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI396.png","UI396",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI404.png","UI404",etest);

    		VisitorWindow.openSharedURL(visitor_driver);
			CommonUtil.sleep(1000);
			CommonUtil.switchToTab(visitor_driver,1);
			visitor_driver.close();
			CommonUtil.switchToTab(visitor_driver,0);
    		CommonWait.waitTillDisplayed(visitor_driver,SUBMIT_BUTTON);
    		CommonWait.waitTillDisplayed(visitor_driver,CHAT_WIDGET_FRAME);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkFeedBackAreaCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	try
    	{
    		ChatWindow.endChat(driver);
    		CommonUtil.sleep(2000);

    		CommonSikuli.findInWholePage(visitor_driver,"UI407.png","UI407",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI408.png","UI408",etest);
    		VisitorWindow.enterFeedbackInTheme(visitor_driver,null,"3",true,etest);
    		VisitorWindow.switchToChatWidget(visitor_driver);
            CommonWait.waitTillDisplayed(visitor_driver,FEEDBACK_AREA);
            CommonUtil.sleep(3000);
    		CommonSikuli.findInWholePage(visitor_driver,"UI409.png","UI409",etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkChatWindowMainPageCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	try
    	{
    		setUpVisitorWindow(visitor_driver);
    		CommonSikuli.findInWholePage(visitor_driver,"UI381.png","UI381",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI382.png","UI382",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI383.png","UI383",etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkIconsCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	String label = CommonUtil.getUniqueMessage();
    	String visname = "Test";
    	String visemail = "test@test.com";
    	String visphone = "+"+label;
    	try
    	{
    		VisitorWindow.switchToChatWidget(visitor_driver);
    		// VisitorWindow.clickVisitorNameInChatToEditInfo(visitor_driver);
    		VisitorWindow.editVisitorInfo(visitor_driver,true,visname,visemail,visphone);
    		VisitorWindow.switchToChatWidget(visitor_driver);
    		// CommonUtil.sendKeysToWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_NAME),visname);
    		// CommonUtil.sendKeysToWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_EMAIL),visemail);
    		// CommonUtil.sendKeysToWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_PHONE),visphone);
    		// VisitorWindow.updateEditedVisitorInfo(visitor_driver,true);

    		// CommonSikuli.findInWholePage(visitor_driver,"UI412.png","UI412",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI399.png","UI399",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI400.png","UI400",etest);

    		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,SMILEY));
    		CommonWait.waitTillDisplayed(visitor_driver,SMILEY_LIST);
            CommonSikuli.findInWholePage(visitor_driver,"UI387.png","UI387",etest);
            CommonSikuli.findInWholePage(visitor_driver,"UI388.png","UI388",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI401.png","UI401",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI402.png","UI402",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI403.png","UI403",etest);
    		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,SMILEY));

    		VisitorWindow.switchToChatWidget(visitor_driver);
			VisitorWindow.clickMoreActions(visitor_driver);
    		VisitorWindow.switchToChatWidget(visitor_driver);
    		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,SEND_EMAIL_ICON));
            CommonWait.waitTillDisplayed(visitor_driver,MAIL_ICON);
    		CommonSikuli.findInWholePage(visitor_driver,"UI413.png","UI413",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI414.png","UI414",etest);

    		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,MESSAGE_AREA));

    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkInformationBannerCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	String label = CommonUtil.getUniqueMessage();
    	String visname = "V"+label;
    	String visemail = "email@"+label+".com";
    	String visphone = "+"+label;
    	String visques = "Q"+label;
    	String dept;
    	try
    	{
    		dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
    		setUpVisitorWindow(visitor_driver);
    		VisitorWindow.initiateChatVisTheme(visitor_driver,visname,visemail,visphone,dept,visques,etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI410.png","UI410",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI411.png","UI411",etest);
            VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);
    		VisitorWindow.switchToChatWidget(visitor_driver);
    		CommonWait.waitTillDisplayed(visitor_driver,CLOSE_ICON);
    		CommonSikuli.findInWholePage(visitor_driver,"UI386.png","UI386",etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkEditOptionsCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	try
    	{
    		VisitorWindow.clickVisitorNameInChatToEditInfo(visitor_driver);
    		CommonSikuli.findInWholePage(visitor_driver,"UI405.png","UI405",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI406.png","UI406",etest);
    		VisitorWindow.updateEditedVisitorInfo(visitor_driver,false);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkMessageCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	try
    	{
    		ChatWindow.sentMessage(driver,"Hello");

    		CommonSikuli.findInWholePage(visitor_driver,"UI418.png","UI418",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI419.png","UI419",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI420.png","UI420",etest);

    		CommonSikuli.findInWholePage(visitor_driver,"UI415.png","UI415",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI416.png","UI416",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI417.png","UI417",etest);

    		VisitorWindow.switchToChatWidget(visitor_driver);
            
            // Test case deleted due to UI change
    		// CommonUtil.mouseHover(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_SIDE_MESSAGE_TIME));
    		// if(Calendar.getInstance().get(Calendar.AM_PM) == Calendar.AM)
    		// {
    		// 	CommonSikuli.findInWholePage(visitor_driver,"UI421AM.png","UI421",etest);
    		// }
    		// else
    		// {
    		// 	CommonSikuli.findInWholePage(visitor_driver,"UI421PM.png","UI421",etest);
    		// }

			FileType file_type=FileType.CUSTOM_CSS_FILE;
			WebElement attach_file_input=VisitorWindow.getAttachFileInputElement(visitor_driver);
			FileUpload.uploadFile(attach_file_input,file_type);
			CommonUtil.sleep(2000);				//wait for file upload
    		CommonSikuli.findInWholePage(visitor_driver,"UI422.png","UI422",etest);

			file_type=FileType.SMALL_IMAGE;
			attach_file_input=VisitorWindow.getAttachFileInputElement(visitor_driver);
			FileUpload.uploadFile(attach_file_input,file_type);
			CommonUtil.sleep(2000);				//wait for file upload
    		CommonSikuli.findInWholePage(visitor_driver,"UI423.png","UI423",etest);

    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkNewsLetterCSS(WebDriver driver,WebDriver visitor_driver,ExtentTest etest)
    {
    	try
    	{
    		setUpVisitorWindow(visitor_driver);
    		CommonSikuli.findInWholePage(visitor_driver,"UI389.png","UI389",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI390.png","UI390",etest);
    		CommonSikuli.findInWholePage(visitor_driver,"UI391.png","UI391",etest);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }
}
