//$Id$
package com.zoho.livedesk.client.ConcurrentChats;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Hashtable;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonUtil;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import org.openqa.selenium.TimeoutException;

import com.zoho.livedesk.client.ChatTransfer.CommonFunctionsTC;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.client.ConcurrentChats.*;

import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.util.common.*;


public class ConcurrentChatCommonFunctions
{
	public static boolean setupConcurrentChatType(WebDriver driver,ExtentTest etest,String widget_code,User user,Portal portal) throws Exception
	{
        int failcount = 0;

        if(portal!=null && user!=null)
        {
            if(portal.isReachThreshold && user.isReachThreshold)
            {
                throw new ZohoSalesIQRuntimeException("Invalid Configuration - Both portal.isReachThreshold and user.isReachThreshold are set as true.");
            }
        }

		if(user!=null)
		{
			setUserChatsLimit(driver,etest,user.username,user.threshhold_limit);
		}

		if(portal!=null)
		{
			setPortalChatsLimit(driver,etest,portal.threshhold_limit);
		}

        if(user!=null && user.isReachThreshold)
        {
            if(reachChatsLimitThreshold(driver,etest,widget_code,user.threshhold_limit,user.isCheckEngaged)==false)
            {
                failcount++;
            }   
        }

        else if(portal!=null && portal.isReachThreshold)
        {
            if(reachChatsLimitThreshold(driver,etest,widget_code,portal.threshhold_limit,portal.isCheckEngaged)==false)
            {
                failcount++;
            }   
        }

        return CommonUtil.returnResult(failcount);
	}

    public static boolean setupPortalChatType(WebDriver driver,ExtentTest etest,String widget_code,Portal portal) throws Exception
    {
        return setupConcurrentChatType(driver,etest,widget_code,null,portal);        
    }

    public static boolean setupAgentChatType(WebDriver driver,ExtentTest etest,String widget_code,User user) throws Exception
    {
        return setupConcurrentChatType(driver,etest,widget_code,user,null);        
    }

	public static boolean reachChatsLimitThreshold(WebDriver driver,ExtentTest etest,String widget_code,String threshhold_limit,boolean isCheckEngagedStatus) throws Exception
	{

        if(threshhold_limit.equals(ConcurrentChatConstants.NONE))
        {
            etest.log(Status.INFO,ExecuteStatements.getUserName(driver)+" currently has "+threshhold_limit+" ongoing chats.");
            return true;
        }
        else if(threshhold_limit.equals(ConcurrentChatConstants.UNLIMITED))
        {
            throw new ZohoSalesIQRuntimeException("Invalid threshhold limit. Please give a feasible limit");
        }

        int failcount=0;

        int limit = Integer.parseInt(threshhold_limit);

        closeAllMyChats(driver,etest);

        int current_chats=0;

        driver.navigate().refresh();

        for(int i=1;i<=limit;i++)
        {
            increaseMyChats(driver,etest,widget_code);
            current_chats++;

            if(isCheckEngagedStatus)
            {
                AgentStatus status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver);

                if(current_chats==limit && status.equals(AgentStatus.ENGAGED)==false)
                {
                    etest.log(Status.FAIL,"Agent status was not changed to "+status+" when the given threshhold limit(threshhold : "+limit+" , current_chats : "+current_chats+") was reached");
                    failcount++;
                }
                else if(current_chats!=limit && status.equals(AgentStatus.ENGAGED)==true)
                {
                    etest.log(Status.FAIL,"Agent status was changed to "+status+" before the given threshhold limit(threshhold : "+limit+" , current_chats : "+current_chats+") was reached");
                    failcount++;
                }
            }
        }

        etest.log(Status.INFO,ExecuteStatements.getUserName(driver)+" currently has "+threshhold_limit+" ongoing chats.");

        return CommonUtil.returnResult(failcount);
	}

    public static boolean reachChatsLimitThreshold(WebDriver driver,ExtentTest etest,String widget_code,String threshhold_limit) throws Exception
    {
        return reachChatsLimitThreshold(driver,etest,widget_code,threshhold_limit,false);   
    }

    public static void increaseMyChats(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
    {
        String label=CommonUtil.getUniqueMessage();
        String name="V"+label,email=name+"@email.com",question=label+"?";
        WebDriver visitor_driver = getVisitorDriver();
        VisitorWindow.createPage(visitor_driver,widget_code);

        String department=null;

        if(VisitorWindow.isContainsDepartment(visitor_driver))
        {
            department=ExecuteStatements.getSystemGeneratedDepartment(driver); 
        }

        VisitorWindow.initiateChatVisTheme(visitor_driver,name,email,null,department,question,false,etest);

        ChatWindow.acceptChat(driver,etest);
        Driver.quitDriver(visitor_driver);
    }

    public static void closeAllMyChats(WebDriver driver,ExtentTest etest) throws Exception
    {
        ChatWindow.closeAllChats(driver);
        etest.log(Status.INFO,"All concurrent chats were closed for user "+ExecuteStatements.getUserName(driver));
    } 

	public static void setPortalChatsLimit(WebDriver driver,ExtentTest etest,String portal_chats_limit) throws Exception
	{

        Tab.navToPortalTab(driver);
        selectConcurrentChatsValue(driver,portal_chats_limit);
		// PortalConfig.changeValues(driver,ConcurrentChatConstants.PORTAL_CHAT_LIMIT_ID,portal_chats_limit,etest);
        etest.log(Status.INFO,"Portals chat limit was set as "+portal_chats_limit);        
	}

	public static void setUserChatsLimit(WebDriver driver,ExtentTest etest,String user_name,String user_chats_limit) throws Exception
	{
		Tab.navToUsersTab(driver);
		UsersTab.clickUser(driver,user_name);
		UsersTab.clickEditProfile(driver);
		selectConcurrentChatsValue(driver,user_chats_limit);
    	UsersTab.clickUpdateUserInfoButton(driver);
        etest.log(Status.INFO,"Users chat limit was set as "+user_chats_limit+" for user "+user_name);
	}

    public static void selectConcurrentChatsValue(WebDriver driver,String value)
    {
    	getDropdownIntoViewPort(driver);

    	if(isConcurrentChatLimit(driver,value))
    	{
    		return;
    	}

    	clickConcurrentChatsDropdown(driver);
    	selectValueFromConcurrentChatsDropdown(driver,value);
    }

    public static void getDropdownIntoViewPort(WebDriver driver)
    {
     	CommonUtil.inViewPortSafe(driver,CommonUtil.getElement(driver,By.id(ConcurrentChatConstants.USER_CONCURRENT_CHATS_DROPDOWN_ID)));
    }

    public static void clickConcurrentChatsDropdown(WebDriver driver) throws ZohoSalesIQRuntimeException
    {
     	CommonUtil.getElement(driver,By.id(ConcurrentChatConstants.USER_CONCURRENT_CHATS_DROPDOWN_ID)).click();
     	waitTillConcurrentChatsLimitDropdownDisplayed(driver,true);
    }

    public static void waitTillConcurrentChatsLimitDropdownDisplayed(WebDriver driver,boolean isDisplayed) throws ZohoSalesIQRuntimeException
    {

        try
        {
            String expected_style="display: block";

            if(!isDisplayed)
            {
                expected_style="display: none";
            }

            CommonUtil.waitTillWebElementContainsAttributeValue( CommonUtil.getElement(driver,By.id(ConcurrentChatConstants.USER_CONCURRENT_CHATS_DROPDOWN_EXPANDED_ID)) , "style" ,expected_style);
        }
        catch(Exception e)
        {
            throw new ZohoSalesIQRuntimeException("Expected display was not found for Concurrent chats limit dropdown ==> Expected isDisplayed : "+isDisplayed+" \n Exception : "+e.toString());
        }
    }

    public static String getCurrentConcurrentChatsLimit(WebDriver driver)
    {
    	return CommonUtil.getElement(driver,By.id(ConcurrentChatConstants.USER_CONCURRENT_CHATS_DROPDOWN_ID)).getText();
    }

    public static boolean isConcurrentChatLimit(WebDriver driver,String limit)
    {
    	return getCurrentConcurrentChatsLimit(driver).equals(limit+"\n");
    }

    public static void selectValueFromConcurrentChatsDropdown(WebDriver driver,String value) throws ZohoSalesIQRuntimeException
    {
        try
        {
            List<WebElement> dropdown_values = CommonUtil.getElement(driver,By.id(ConcurrentChatConstants.USER_CONCURRENT_CHATS_DROPDOWN_EXPANDED_ID),By.tagName("ul")).findElements(By.tagName("li"));
            WebElement dropdown_value=CommonUtil.getElementByAttributeValue(dropdown_values,"innerText",value);
            CommonUtil.inViewPort(dropdown_value);
            dropdown_value.click();
            waitTillConcurrentChatsLimitDropdownDisplayed(driver,false);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw new ZohoSalesIQRuntimeException("Unable to select a value in Concurrent chats limit dropdown\n Exception : "+e.toString());            
        }
    }

    public static List<String> getConcurrentChatDropdownValues(WebDriver driver)
    {
        List<WebElement> dropdown_values = CommonUtil.getElement(driver,By.id(ConcurrentChatConstants.USER_CONCURRENT_CHATS_DROPDOWN_EXPANDED_ID),By.tagName("ul")).findElements(By.tagName("li"));

        List<String> dropdown_texts = new ArrayList<String>();

        for(WebElement dropdown_value : dropdown_values)
        {       
            dropdown_texts.add(dropdown_value.getText());
        }

        return dropdown_texts;
    }

    public static WebDriver getVisitorDriver() throws Exception
    {
        WebDriver driver = Functions.setUp();
        return driver;
    }

    public static boolean checkProactiveChat(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
    {
        int failcount=0;

        String label=CommonUtil.getUniqueMessage();
        String proactive_message="Proactive"+label,visitor_message="Reply"+label,agent_message="Agent"+label;

        String portal=ExecuteStatements.getPortal(driver);

        WebDriver visitorDriver = getVisitorDriver();

        try
        {
            VisitorWindow.createPage(visitorDriver,widget_code);
            String visitor_id = VisitorWindow.getVisitorId(visitorDriver,portal);
            Tab.clickVisitorsOnline(driver);
            VisitorsOnline.waitTillVisitorStableInRings(VisitorsOnline.getVisitor(driver,visitor_id));
            ChatWindow.initiateChat(driver,visitor_id,proactive_message);
            VisitorWindow.switchToChatWidget(visitorDriver);
            VisitorWindow.sentMessageInTheme(visitorDriver,visitor_message);
            ChatWindow.continueChat(driver);
            ChatWindow.clickChatByVisitorId(driver,visitor_id);
            ChatWindow.sentMessage(driver,agent_message);

            try
            {
                VisitorWindow.waitTillMessageInChat(visitorDriver,agent_message);
                etest.log(Status.PASS,"Proactive chat is working as expected. Expected message : "+agent_message);           
            }
            catch(Exception e)
            {
                  etest.log(Status.FAIL,"Proactive chat is not working as expected. Expected agent message in visitor side : "+agent_message);
                  TakeScreenshot.screenshot(driver,etest,"Agent","checkProactiveChat","Error");
                  TakeScreenshot.screenshot(visitorDriver,etest,"Visitor","checkProactiveChat","Error");
                  failcount++;
            }

            ChatWindow.endChat(driver);
            ChatWindow.clickClosethisWindow(driver);
        }
        catch(Exception e)
        {
             TakeScreenshot.screenshot(visitorDriver,etest,"Visitor","checkProactiveChat","Error");
             throw e;            
        }
 
        etest.log(Status.INFO,"Pro active chat is checked");
        Driver.quitDriver(visitorDriver);

        return CommonUtil.returnResult(failcount);
    }

}
