//$Id$
package com.zoho.livedesk.client.ConcurrentChats;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonUtil;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import com.zoho.livedesk.util.common.actions.Integration;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.WebsitesTab;
import com.zoho.livedesk.util.common.actions.Websites;

import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;




public class ConcurrentChatConstants
{
	/*DOM CONSTANTS*/
	public static final String
	MAX_CONCURRENT_CHAT_VALUE_FOR_UNLIMITED_CHATS="-1",
	PORTAL_CHAT_LIMIT_ID="maxconcurrentchat",
	USER_CONCURRENT_CHATS_DROPDOWN_ID="maxconcurrentchatdrpdwn",
	USER_CONCURRENT_CHATS_DROPDOWN_EXPANDED_ID="maxconcurrentchatdrpdwn_ddown",
	NONE="None",UNLIMITED="Unlimited";
	;

	public static final String[]
	USERS_TAB_CONCURRENT_SETTINGS_DROPDOWN={NONE,"1","2","3","4","5","7","10","25",UNLIMITED},
	PORTAL_TAB_CONCURRENT_SETTINGS_DROPDOWN={"1","2","3","4","5","7","10","25",UNLIMITED};	
	

	/*VARIABLE CONSTANTS*/

	
	/*ENUMS*/
	public enum AgentStatus
	{
		AVAILABLE("userstatus-1"),
		BUSY("userstatus-3"),
		ENGAGED("userstatus-6"),
		IDLE("userstatus-4"),
		OFFLINE(null);

		public String class_name;

		AgentStatus(String class_name)
		{
			this.class_name=class_name;
		}
	}
	
	/*Constant related functions*/
	public static AgentStatus getAgentStatusByClassName(String class_name)
	{
		AgentStatus[] status_enums=AgentStatus.values();

		for(AgentStatus status_enum : status_enums)
		{
			if(class_name.equals(status_enum.class_name))
			{
				return status_enum;
			}
		}

		return null;
	}


	/*Objects*/
	public static class User
	{
		public String username;
		public String threshhold_limit;
		public boolean isReachThreshold,isCheckEngaged;
		public AgentStatus status;
		public static final String default_limit=NONE;
		public UserRole role;


		public enum UserRole
		{
			ADMIN,
			ASSOCIATE,
			SUPERVISOR,
		}

		public User(String username)
		{
			this(username,default_limit,false,false);
		}

		public User(String username,String threshhold_limit,boolean isReachThreshold,boolean isCheckEngaged)
		{
			this(username,threshhold_limit,isReachThreshold,isCheckEngaged,AgentStatus.AVAILABLE);
		}

        public User(String username,String threshhold_limit,boolean isReachThreshold,boolean isCheckEngaged,AgentStatus status)
        {
        	this.username=username;
        	this.threshhold_limit=threshhold_limit;
        	this.isReachThreshold=isReachThreshold;  	
        	this.isCheckEngaged=isCheckEngaged;  	
        	this.status=status;
        	this.role=UserRole.ADMIN;//default assumption
        }

        public void setAgentStatus(AgentStatus status)
        {
        	this.status=status;
        }

        public AgentStatus getAgentStatus()
        {
        	return status;
        }

        public void setUserRole(UserRole role)
        {
        	this.role=role;
        }

        public UserRole getUserRole()
        {
        	return role;
        }
    }

	public static class Portal
	{
		public String threshhold_limit;
		public boolean isReachThreshold,isCheckEngaged;
		public static final String default_limit=UNLIMITED;

		public Portal()
		{
			this(default_limit,false,false);
		}

        public Portal(String threshhold_limit,boolean isReachThreshold,boolean isCheckEngaged)
        {
        	this.threshhold_limit=threshhold_limit;
        	this.isReachThreshold=isReachThreshold;        	
        	this.isCheckEngaged=isCheckEngaged;        	
        } 
    }

}
