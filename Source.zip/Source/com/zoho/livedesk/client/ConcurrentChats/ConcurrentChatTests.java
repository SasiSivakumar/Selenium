//$Id$
package com.zoho.livedesk.client.ConcurrentChats;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;



import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.client.ConcurrentChats.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User.UserRole;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.TransferType;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.util.common.actions.*;


public class ConcurrentChatTests{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Concurrent Chats";
	public static String WIDGET_CODE="";
	public static String PORTAL_NAME="";
	public static String WEBSITE_NAME="";

	public static Hashtable test(WebDriver driver) throws Exception
	{
		try
		{
            result = new Hashtable<String,Boolean>();
            WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            PORTAL_NAME=ExecuteStatements.getPortal(driver);            
            System.out.println("~~~~WIDGET_CODE"+WIDGET_CODE+" WEBSITE_NAME"+WEBSITE_NAME+" PORTAL_NAME"+PORTAL_NAME);       

			String user_name=ExecuteStatements.getUserName(driver);

			if(com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver)==AgentStatus.BUSY)
			{
	            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			}			

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC5"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal = new Portal();
			result.put("CC5", checkConcurrentChatDropdown(driver,etest,WIDGET_CODE,portal));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			User user = new User(user_name);
			result.put("CC6", checkConcurrentChatDropdown(driver,etest,WIDGET_CODE,user));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC7"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal1 = new Portal("2",true,true);
			User user1 = new User(user_name);
			result.put("CC7", checkBasicConcurrentChatLimit(driver,etest,WIDGET_CODE,portal1,user1));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC8"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal2 = new Portal();
			User user2 = new User(user_name,"2",true,true);
			result.put("CC8", checkBasicConcurrentChatLimit(driver,etest,WIDGET_CODE,portal2,user2));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal3 = new Portal("1",false,false);
			User user3 = new User(user_name,"2",true,true);
			result.put("CC10", checkBasicConcurrentChatLimit(driver,etest,WIDGET_CODE,portal3,user3));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC12"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal4 = new Portal("1",true,true);
			User user4 = new User(user_name);
			result.put("CC12", checkBasicConcurrentChatLimit(driver,etest,WIDGET_CODE,portal4,user4,true,false));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC13"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal5 = new Portal();
			User user5 = new User(user_name,"1",true,true);
			result.put("CC13", checkBasicConcurrentChatLimit(driver,etest,WIDGET_CODE,portal5,user5,true,false));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC22"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			Portal portal6 = new Portal("1",true,true);
			User user6 = new User(user_name);
			result.put("CC22", checkBasicConcurrentChatLimit(driver,etest,WIDGET_CODE,portal6,user6,false,true));
            ComplexReportFactory.closeTest(etest);

            WebDriver driver2 = Functions.setUp();
            Functions.login(driver2,"concurrent_chats2");

			String user_name2=ExecuteStatements.getUserName(driver2);

			if(com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver2)==AgentStatus.BUSY)
			{
	            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available");
			}	

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC16"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			User user14 = new User(user_name2);
			user14.setUserRole(UserRole.ASSOCIATE);
			result.put("CC16", checkConcurrentChatDropdown(driver2,etest,WIDGET_CODE,user14));
            ComplexReportFactory.closeTest(etest);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available");

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal14 = new Portal();
			User user14_1 = new User(user_name,"2",true,true);
			User user14_2 = new User(user_name2);

			result.put("CC9", checkConcurrentChatLimitOnMultipleAgents(driver,driver2,etest,WIDGET_CODE,portal14,user14_1,user14_2));
            ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal15 = new Portal();
			User user15_1 = new User(user_name,"2",true,true);
			User user15_2 = new User(user_name2,"3",true,true);

			result.put("CC11", checkConcurrentChatLimitOnMultipleAgents(driver,driver2,etest,WIDGET_CODE,portal15,user15_1,user15_2));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC19"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal7 = new Portal("1",false,false);
			User user7_1 = new User(user_name);
			User user7_2 = new User(user_name2);

			result.put("CC19", checkChatTransferOperations(driver,driver2,etest,WIDGET_CODE,portal7,user7_1,user7_2,TransferType.TRANSFER));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC20"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal8 = new Portal("1",false,false);
			User user8_1 = new User(user_name);
			User user8_2 = new User(user_name2);

			result.put("CC20", checkChatTransferOperations(driver,driver2,etest,WIDGET_CODE,portal8,user8_1,user8_2,TransferType.INVITE));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC21"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal9 = new Portal("1",false,false);
			User user9_1 = new User(user_name);
			User user9_2 = new User(user_name2);

			result.put("CC21", checkChatTransferOperations(driver,driver2,etest,WIDGET_CODE,portal9,user9_1,user9_2,TransferType.JOIN));
            ComplexReportFactory.closeTest(etest);

            Functions.logout(driver2);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC14"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal10 = new Portal("2",false,false);
			User user10 = new User(user_name);
			user10.setAgentStatus(AgentStatus.AVAILABLE);

			result.put("CC14", checkAgentStatusAndChatsLimitRealTime(driver,etest,WIDGET_CODE,portal10,user10,true,false));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC15"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal11 = new Portal("2",false,false);
			User user11 = new User(user_name);
			user10.setAgentStatus(AgentStatus.BUSY);

			result.put("CC15", checkAgentStatusAndChatsLimitRealTime(driver,etest,WIDGET_CODE,portal11,user11,true,false));
            ComplexReportFactory.closeTest(etest);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC17"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal12 = new Portal(ConcurrentChatConstants.UNLIMITED,false,false);
			User user12 = new User(user_name);

			result.put("CC17", checkAgentStatusAndChatsLimitRealTime(driver,etest,WIDGET_CODE,portal12,user12,false,true));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC18"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);

			Portal portal13 = new Portal("2",false,false);
			User user13 = new User(user_name);

			result.put("CC18", checkAgentStatusAndChatsLimitRealTime(driver,etest,WIDGET_CODE,portal13,user13,false,true));
            ComplexReportFactory.closeTest(etest);

       }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static boolean checkBasicConcurrentChatLimit(WebDriver driver,ExtentTest etest,String widget_code,Portal portal,User user)
	{
		return checkBasicConcurrentChatLimit(driver,etest,widget_code,portal,user,false,false);	
	}

	public static boolean checkBasicConcurrentChatLimit(WebDriver driver,ExtentTest etest,String widget_code,Portal portal,User user,boolean isCheckProactiveChat,boolean isCheckChatWidgetOffline)
	{
		driver.navigate().refresh();

		int failcount=0;
		
		try
		{
			etest.log(Status.INFO,"Current setup \n"+getCurrentSetup(portal,user));
			
			if(ConcurrentChatCommonFunctions.setupConcurrentChatType(driver,etest,widget_code,user,portal))
			{
				etest.log(Status.PASS,"Concurrent chats limit works as expected");
			}
			else
			{
				failcount++;
			}

			if(isCheckChatWidgetOffline)
			{
				WebDriver visitor_driver=ConcurrentChatCommonFunctions.getVisitorDriver();
				VisitorWindow.createPage(visitor_driver,widget_code);
				if(VisitorWindow.checkChatWidgetOffline(visitor_driver)==false)
				{
					failcount++;
					etest.log(Status.FAIL,"Chat widget was not offline");
   	                TakeScreenshot.screenshot(visitor_driver,etest,"VisitorWindow","checkBasicConcurrentChatLimit","Error");
				}
				else
				{
					etest.log(Status.PASS,"Chat widget was offline. When all users of portal were engaged");					
				}
			}

			if(isCheckProactiveChat)
			{
				if(ConcurrentChatCommonFunctions.checkProactiveChat(driver,etest,widget_code)==false)
				{
					failcount++;
				}
			}
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkBasicConcurrentChatLimit","Exception",e);
		}
		finally
		{		
			try
			{
				ConcurrentChatCommonFunctions.closeAllMyChats(driver,etest);
			}
			catch(Exception e){}

			return CommonUtil.returnResult(failcount);
		}
	}

	public static String getCurrentSetup(Portal portal,User user)
	{
		String user_info = "Agent : "+user.username+"<br>User chats limit : "+user.threshhold_limit+"<br>is Threshhold Exceed : "+user.isReachThreshold;
		String portal_info = "Portal chats limit : "+portal.threshhold_limit+"<br>is Threshhold Exceed "+portal.isReachThreshold;
		return user_info+"<br><br><br>"+portal_info;
	}


	public static boolean checkConcurrentChatLimitOnMultipleAgents(WebDriver driver1,WebDriver driver2,ExtentTest etest,String widget_code,Portal portal,User user1,User user2)
	{

		int failcount=0;
		
		try
		{			
			//resetting values just in case
			user1.isReachThreshold=false;
			user2.isReachThreshold=false;
			portal.isReachThreshold=false;

			try
			{
				ConcurrentChatCommonFunctions.closeAllMyChats(driver1,etest);
				ConcurrentChatCommonFunctions.closeAllMyChats(driver2,etest);
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available");
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}

			ConcurrentChatCommonFunctions.setupAgentChatType(driver1,etest,widget_code,user1);
			ConcurrentChatCommonFunctions.setupAgentChatType(driver1,etest,widget_code,user2);
			ConcurrentChatCommonFunctions.setupPortalChatType(driver1,etest,widget_code,portal);
			
	        if(ConcurrentChatCommonFunctions.reachChatsLimitThreshold(driver1,etest,widget_code,user1.threshhold_limit,true)==false)
            {
                failcount++;
            }

            AgentStatus agent2_status_after_agent1_engaged=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver2);

           	if(CommonUtil.checkStringEqualsAndLog(AgentStatus.AVAILABLE.toString(),agent2_status_after_agent1_engaged.toString(),user2.username+" status after "+user1.username+" engaged ",etest)==false)
           	{
           		failcount++;
        		TakeScreenshot.screenshot(driver1,etest);
        		TakeScreenshot.screenshot(driver2,etest);
           	}


	        if(ConcurrentChatCommonFunctions.reachChatsLimitThreshold(driver2,etest,widget_code,user2.threshhold_limit,true)==false)
            {
                failcount++;
            }

            if(user2.threshhold_limit.equals(ConcurrentChatConstants.NONE) && portal.threshhold_limit.equals(ConcurrentChatConstants.UNLIMITED))
            {
            	AgentStatus expected_user2_status=AgentStatus.AVAILABLE;
            	AgentStatus user2_status=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver2);
            	if(CommonUtil.checkStringEqualsAndLog(expected_user2_status.toString(),user2_status.toString(),"agent status",etest)==false)
            	{
            		failcount++;
            		TakeScreenshot.screenshot(driver1,etest);
            		TakeScreenshot.screenshot(driver2,etest);
            	}
            }

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver1,etest,MODULE_NAME,"checkConcurrentChatLimitOnMultipleAgents","Exception",e);
			TakeScreenshot.screenshot(driver2,etest,MODULE_NAME,"checkConcurrentChatLimitOnMultipleAgents","Exception",e);
		}
		finally
		{		
			try
			{
				ConcurrentChatCommonFunctions.closeAllMyChats(driver1,etest);
				ConcurrentChatCommonFunctions.closeAllMyChats(driver2,etest);
			}
			catch(Exception e){}

			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkChatTransferOperations(WebDriver driver1,WebDriver driver2,ExtentTest etest,String widget_code,Portal portal,User user1,User user2,TransferType transfer_type)
	{

		WebDriver visitor_driver=null;

		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="question"+label;

		int failcount=0;

        AgentStatus user1_status = null;
	    AgentStatus user2_status = null;

	    String unique_id=null;
		
		try
		{
			if(transfer_type==TransferType.JOIN)
			{
	            com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions.addChatMonitor(driver1,"VisitorEmail",visitor_mail);	
			}

			ConcurrentChatCommonFunctions.closeAllMyChats(driver1,etest);	
			ConcurrentChatCommonFunctions.closeAllMyChats(driver2,etest);	
			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available");
			driver1.navigate().refresh();//temp
			driver2.navigate().refresh();//temp
			CommonUtil.sleep(10000);//temp

          	user1_status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver1);
            user2_status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver2);

            if(user1_status!=AgentStatus.AVAILABLE || user2_status!=AgentStatus.AVAILABLE)
            {
            	String failure_message="Status' of agents were not found to be available even after closing all the chats (Actual Status' "+user1.username+" : "+user1_status+" , "+user2.username+" : "+user2_status+"  )";
            	etest.log(Status.FAIL,failure_message);
            	throw new ZohoSalesIQRuntimeException(failure_message);
            }

			ConcurrentChatCommonFunctions.setupAgentChatType(driver1,etest,widget_code,user1);
			ConcurrentChatCommonFunctions.setupAgentChatType(driver1,etest,widget_code,user2);
			ConcurrentChatCommonFunctions.setupPortalChatType(driver1,etest,widget_code,portal);

			visitor_driver=ConcurrentChatCommonFunctions.getVisitorDriver();

          	user1_status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver1);
            user2_status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver2);

			Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
	        unique_id=ConversationViewCommonFunctions.setupChatType(driver2,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);
	        ChatWindow.sentMessage(driver2,"test");
	        ConversationViewCommonFunctions.setupTransferChatType(driver2,driver1,visitor_driver,etest,ChatType.ONGOING,unique_id,transfer_type);

	        AgentStatus expected_user1_status = null;
	        AgentStatus expected_user2_status = null;

	        if(transfer_type==TransferType.INVITE || transfer_type==TransferType.JOIN)
	        {
	        	expected_user1_status = AgentStatus.ENGAGED;
	        	expected_user2_status = AgentStatus.ENGAGED;
	        }
	        else if(transfer_type==TransferType.TRANSFER)
	        {
	        	expected_user1_status = AgentStatus.ENGAGED;
	        	expected_user2_status = AgentStatus.AVAILABLE;
	        }

            user1_status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver1);
            user2_status = com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver2);

            if(expected_user1_status==user1_status)
            {
            	etest.log(Status.PASS,user1.username+"'s status was changed to "+expected_user1_status+" (Actual : "+user1_status+") after he "+transfer_type+"ED his chat to "+user2.username);
            }
            else
            {
            	failcount++;
	        	etest.log(Status.FAIL,user1.username+"'s status was NOT changed to "+expected_user1_status+" (Actual : "+user1_status+") after he "+transfer_type+"ED his chat to "+user2.username);
                TakeScreenshot.screenshot(driver1,etest,"Agent","checkChatTransferOperations","Error");
            }

            if(expected_user2_status==user2_status)
            {
            	etest.log(Status.PASS,user2.username+"'s status was changed to "+expected_user2_status+" (Actual : "+user2_status+") after he "+transfer_type+"ED his chat to "+user2.username);
            }
            else
            {
            	failcount++;
	        	etest.log(Status.FAIL,user2.username+"'s status was NOT changed to "+expected_user2_status+" (Actual : "+user2_status+") after he "+transfer_type+"ED his chat to "+user2.username);
                TakeScreenshot.screenshot(driver2,etest,"Agent","checkChatTransferOperations","Error");
            }
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver1,etest,MODULE_NAME,"checkChatTransferOperations","Exception",e);
			TakeScreenshot.screenshot(driver2,etest,MODULE_NAME,"checkChatTransferOperations","Exception",e);
		}
		finally
		{
			Driver.quitDriver(visitor_driver);

			if(transfer_type==TransferType.JOIN)
			{
				try
				{
					com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions.deleteChatMonitor(driver2,visitor_mail);
				}
				catch(Exception e){}
			}

			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkAgentStatusAndChatsLimitRealTime(WebDriver driver,ExtentTest etest,String widget_code,Portal portal,User user,boolean isChangeStatusDuringChat,boolean isChangeLimitDuringChat)
	{

		// for(int i=0;i<50;i++)
		// {
		// 	TakeScreenshot.logger(etest,"Secret Log : "+i);
		// }

		int failcount=0;

		WebDriver visitor_driver=null;

		String
		label=CommonUtil.getUniqueMessage(),
		visitor_name="name"+label,
		visitor_mail=label+"@email.com",
		visitor_question="question"+label;

		AgentStatus
		current_agent_status=null,
		status_to_change_during_chat=null,
		expected_user_status_after_chat=null;

		Integer portal_limit_to_change_during_chat=null;
		
		try
		{
			try
			{
				ConcurrentChatCommonFunctions.closeAllMyChats(driver,etest);
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
			}
			
			current_agent_status=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver);

			if(current_agent_status!=AgentStatus.AVAILABLE)
			{
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
			}

			etest.log(Status.INFO,"Current setup \n"+getCurrentSetup(portal,user));
			
			current_agent_status=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver);

			expected_user_status_after_chat=current_agent_status;

			etest.log(Status.INFO,"Agent status before chat : "+current_agent_status);

			//resetting isReachThreshold param in case it was wrong value was given
			user.isReachThreshold=false;
			portal.isReachThreshold=false;

			ConcurrentChatCommonFunctions.setupConcurrentChatType(driver,etest,widget_code,user,portal);

			int my_chats_count=portal.threshhold_limit.equals(ConcurrentChatConstants.UNLIMITED)?1:Integer.parseInt(portal.threshhold_limit)-1;//reaching this count so that when next chat is executed agent status will change to engaged.
			ConcurrentChatCommonFunctions.reachChatsLimitThreshold(driver,etest,widget_code,my_chats_count+"",false);

			visitor_driver=ConcurrentChatCommonFunctions.getVisitorDriver();
			VisitorWindow.createPage(visitor_driver,widget_code);
	        VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
    	    ChatWindow.acceptChat(driver,etest);
			my_chats_count++;

			current_agent_status=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver);

			if(current_agent_status!=AgentStatus.ENGAGED && portal.threshhold_limit.equals(ConcurrentChatConstants.UNLIMITED)==false)
			{
				failcount++;
				etest.log(Status.FAIL,"Agent status was not changed to "+AgentStatus.ENGAGED+" after "+portal.threshhold_limit+" chats were reached. Current Agent Status : "+current_agent_status);
                TakeScreenshot.screenshot(driver,etest,"Agent","checkAgentStatusAndChatsLimitRealTime","Error");
                TakeScreenshot.screenshot(driver,etest,"Visitor","checkAgentStatusAndChatsLimitRealTime","Error");
			}
			else if(current_agent_status==AgentStatus.ENGAGED && portal.threshhold_limit.equals(ConcurrentChatConstants.UNLIMITED)==true)
			{
				failcount++;
				etest.log(Status.FAIL,"Agent status changed to "+AgentStatus.ENGAGED+" when "+portal.threshhold_limit+" chats were not reached. Current Agent Status : "+current_agent_status);
                TakeScreenshot.screenshot(driver,etest,"Agent","checkAgentStatusAndChatsLimitRealTime","Error");
                TakeScreenshot.screenshot(driver,etest,"Visitor","checkAgentStatusAndChatsLimitRealTime","Error");
			}

			if(isChangeStatusDuringChat)
			{
				if(user.getAgentStatus()==AgentStatus.BUSY)//to change status from busy to available. i.e We cannot change status to busy before chat is initiated so we are changing to busy only after chat is initated
				{
					com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,AgentStatus.BUSY.toString().toLowerCase());
					etest.log(Status.INFO,"Agent Status was changed to "+AgentStatus.BUSY);
				}

				status_to_change_during_chat=(user.getAgentStatus()==AgentStatus.BUSY)?AgentStatus.AVAILABLE:AgentStatus.BUSY;
				String status_change_param=status_to_change_during_chat.toString().toLowerCase();
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status_change_param);
				etest.log(Status.INFO,"Agent status was changed to "+status_to_change_during_chat);
				expected_user_status_after_chat=status_to_change_during_chat;
			}

			if(isChangeLimitDuringChat)
			{
				boolean isLimitsDecreaseCheck=portal.threshhold_limit.equals(ConcurrentChatConstants.UNLIMITED);
				portal_limit_to_change_during_chat=isLimitsDecreaseCheck?my_chats_count:(my_chats_count+1);
				ConcurrentChatCommonFunctions.setPortalChatsLimit(driver,etest,portal_limit_to_change_during_chat+"");

				AgentStatus expected_user_status_after_limit_change=isLimitsDecreaseCheck?AgentStatus.ENGAGED:expected_user_status_after_chat;

				try
				{
					com.zoho.livedesk.util.common.actions.Status.waitTillCurrentAgentStatusChange(driver,expected_user_status_after_limit_change);
				}
				catch(Exception e)
				{

				}

				current_agent_status=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver);

				if(current_agent_status!=expected_user_status_after_limit_change)
				{
					etest.log(Status.FAIL,"Agent status was NOT changed to "+expected_user_status_after_limit_change+" after its portal limit was changed to "+portal_limit_to_change_during_chat+" when the no of ongoing chats for the agent was "+my_chats_count+". Current Agent Status : "+current_agent_status);
	                TakeScreenshot.screenshot(driver,etest,"Agent","checkAgentStatusAndChatsLimitRealTime","Error");
					failcount++;
				}
				else
				{
					etest.log(Status.PASS,"Agent status was changed to "+expected_user_status_after_limit_change+" after its portal limit was changed to "+portal_limit_to_change_during_chat+" when the no of ongoing chats for the agent was "+my_chats_count+". Current Agent Status : "+current_agent_status);
				}

			}

			VisitorWindow.endChatVisitor(visitor_driver);
			etest.log(Status.INFO,"Visitor ended the chat.");
			my_chats_count--;

			current_agent_status=com.zoho.livedesk.util.common.actions.Status.getAgentStatus(driver);

			if(current_agent_status!=expected_user_status_after_chat)
			{
				failcount++;
				etest.log(Status.FAIL,"Agent status was NOT found as "+expected_user_status_after_chat+" after visitor ended the chat. No of ongoing chats for the agent was "+my_chats_count+". Current Agent Status : "+current_agent_status);
                TakeScreenshot.screenshot(driver,etest,"Agent","checkAgentStatusAndChatsLimitRealTime","Error");
			}
			else
			{
				etest.log(Status.PASS,"Agent status was found as "+expected_user_status_after_chat+" after visitor ended the chat. No of ongoing chats for the agent was "+my_chats_count+". Current Agent Status : "+current_agent_status);
			}

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkAgentStatusAndChatsLimitRealTime","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkAgentStatusAndChatsLimitRealTime","Exception",e);			
		}
		finally
		{		
			try
			{
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
				ConcurrentChatCommonFunctions.closeAllMyChats(driver,etest);
			}
			catch(Exception e){}

			Driver.quitDriver(visitor_driver);

			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkConcurrentChatDropdown(WebDriver driver,ExtentTest etest,String widget_code,Portal portal)
	{
		return checkConcurrentChatDropdown(driver,etest,widget_code,portal,null);
	}

	public static boolean checkConcurrentChatDropdown(WebDriver driver,ExtentTest etest,String widget_code,User user)
	{
		return checkConcurrentChatDropdown(driver,etest,widget_code,null,user);
	}

	public static boolean checkConcurrentChatDropdown(WebDriver driver,ExtentTest etest,String widget_code,Portal portal,User user)
	{

		int failcount=0;

		List<String> dropdown_texts = new ArrayList();
		String[] expected_dropdown_values=null;

		try
		{
			if(portal!=null && user!=null)
			{
				throw new ZohoSalesIQRuntimeException("Method checkConcurrentChatDropdown is configured wrongly. Either only User object or only Portal Object should be passed. Not both");
			}

			if(user!=null)
			{
				expected_dropdown_values=ConcurrentChatConstants.USERS_TAB_CONCURRENT_SETTINGS_DROPDOWN;

				Tab.navToUsersTab(driver);
				UsersTab.clickUser(driver,user.username);
				UsersTab.clickEditProfile(driver);
			}
			else if(portal!=null)
			{
				expected_dropdown_values=ConcurrentChatConstants.PORTAL_TAB_CONCURRENT_SETTINGS_DROPDOWN;

		        Tab.navToPortalTab(driver);
			}

			ConcurrentChatCommonFunctions.getDropdownIntoViewPort(driver);

			try
			{
		    	ConcurrentChatCommonFunctions.clickConcurrentChatsDropdown(driver);

		    	if(user!=null && user.role==UserRole.ASSOCIATE)
		    	{
			    	ConcurrentChatCommonFunctions.selectValueFromConcurrentChatsDropdown(driver,"1");

			    	//if this previous line was exception free. then this would be executed, so assuming as faliure if user role is associate
		    		failcount++;
		    		etest.log(Status.FAIL,"Associate '"+user.username+"' was able to click and open concurrent chats dropdown");
		            TakeScreenshot.screenshot(driver,etest,"Agent","checkConcurrentChatDropdown","Error");
		            return false;
		    	}
			}
			catch(ZohoSalesIQRuntimeException exp)
			{
				exp.printStackTrace();
				if(user.role==UserRole.ASSOCIATE && exp.toString().contains("Concurrent chats limit dropdown"))
				{
					etest.log(Status.PASS,"Associate was not able to click and open the concurrent chats dropdown");
					return true;
				}
				else
				{
					throw exp;
				}
			}

			dropdown_texts=ConcurrentChatCommonFunctions.getConcurrentChatDropdownValues(driver);

			for(String expected_dropdown_value : expected_dropdown_values)
			{
				if(dropdown_texts.contains(expected_dropdown_value)==false)
				{
					failcount++;
					etest.log(Status.FAIL,"Expected dropdown value : "+expected_dropdown_value+" was not found in the dropdown.");
				}
			}

			if(CommonUtil.returnResult(failcount)==true)
			{
				etest.log(Status.PASS,"Expected dropdown values were found.");
			}
			else
			{
	            TakeScreenshot.screenshot(driver,etest,"Agent","checkConcurrentChatDropdowns","Error");
			}

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkConcurrentChatLimitOnMultipleAgents","Exception",e);
		}
		finally
		{		
			try
			{
				ConcurrentChatCommonFunctions.closeAllMyChats(driver,etest);
			}
			catch(Exception e){}
		}

		return CommonUtil.returnResult(failcount);
	}

}
