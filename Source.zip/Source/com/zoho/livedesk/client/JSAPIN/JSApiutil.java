//$Id$
package com.zoho.livedesk.client.JSAPIN;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class JSApiutil
{
    private static Hashtable result = new Hashtable();
    private static Hashtable hashtable = new Hashtable();
    private static Hashtable servicedown = new Hashtable();
    public static WebDriver ApiDriver = null;

    public static ExtentTest etest;

    public static Hashtable jsApiAutomation(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result = new Hashtable();

            etest = ComplexReportFactory.getTest("Open Api Site");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","Checks if the JSAPI site is accessible");

            ApiDriver = CommonFunctions.openApiSite(null);

            result.put("JS1",true);

            etest.log(Status.PASS,"Site is accessible and is opened");
            ComplexReportFactory.closeTest(etest);
            ApiDriver.quit();

            /* Working set starts here */

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigBasic(ApiDriver);
            checkConfigBasic(ApiDriver);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfig(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester5","rajkumar.natarajan+11223@zohocorp.com","8767588867","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.clickMinimize(ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.sendFeedbackandRating(ApiDriver,"4");
            checkConfig(driver,ApiDriver);
            ApiDriver.quit();

            etest = ComplexReportFactory.getTest("$zoho.salesiq.floatwindow.click()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method on clicking the float button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JS8",checkClicks(ApiDriver,"evtbuttonclk","evntbclk"));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

//            New embed doesnot support it
//            etest = ComplexReportFactory.getTest("$zoho.salesiq.floatwindow.close()");
//            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method on closing the float window.");
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            result.put("JS9",checkClicks(ApiDriver,"evtbuttoncls","evntbclose"));
//            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.online()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when the agents are online. This will be called once after the page is loaded.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JS12",checkEvHandler(ApiDriver));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"busy");
            driver.navigate().refresh();
            Thread.sleep(2000);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.offlinemessage()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method on submitting an offline request.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JS7",checkOffline(ApiDriver));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.offline()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when the agents are offline. This will be called once after the page is loaded.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JS11",checkChatHandler(ApiDriver,"evtchatoffline","evtchatoffline"));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"available");
            driver.navigate().refresh();
            Thread.sleep(2000);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.systemmessages()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","You can use this API to customize the system messages displayed in the chat widget.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys1(ApiDriver);
            checkConfigsys1(ApiDriver);
            ApiDriver.quit();

//            New embed doesnot supports pre chat message
//            ApiDriver = CommonFunctions.openApiSite("prechatembed");
//            changeConfigSys(ApiDriver);
//            checkConfigSys(ApiDriver);
//            ApiDriver.quit();

            CommonFunctions.changeStatus(driver,"busy");
            driver.navigate().refresh();
            Thread.sleep(2000);

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            checkConfigSys2(ApiDriver);
            ApiDriver.quit();

            CommonFunctions.changeStatus(driver,"available");
            driver.navigate().refresh();
            Thread.sleep(2000);

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"1");
            checkConfigSysFdbk(ApiDriver,"1","JS29");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"2");
            checkConfigSysFdbk(ApiDriver,"2","JS30");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"3");
            checkConfigSysFdbk(ApiDriver,"3","JS31");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"4");
            checkConfigSysFdbk(ApiDriver,"4","JS32");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"5");
            checkConfigSysFdbk(ApiDriver,"5","JS33");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.floatbutton.position()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","You can use this API to position the Float Button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Top Right");
            checkCSSConfig(ApiDriver,"Top Right","JS34");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Top Left");
            checkCSSConfig(ApiDriver,"Top Left","JS35");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Bottom Right");
            checkCSSConfig(ApiDriver,"Bottom Right","JS36");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Bottom Left");
            checkCSSConfig(ApiDriver,"Bottom Left","JS37");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Left");
            checkCSSConfig(ApiDriver,"Left","JS38");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Right");
            checkCSSConfig(ApiDriver,"Right","JS39");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.floatbutton.onlineicon.src()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","You can use this API to display your own icon when your agents are online. Supported only for Float Button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeFBImgConfig(ApiDriver,"floatonlinesrc",ResourceManager.getRealValue("image_salesonline"));
            checkFBImgConfig(ApiDriver,ResourceManager.getRealValue("image_salesonline"),"JS40");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"busy");
            driver.navigate().refresh();
            Thread.sleep(2000);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.floatbutton.offlineicon.src()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API allows you to display your own icon when your agents are offline. Supported only for Float Button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeFBImgConfig(ApiDriver,"floatofflinesrc",ResourceManager.getRealValue("image_salesoffline"));
            checkFBImgConfig(ApiDriver,ResourceManager.getRealValue("image_salesoffline"),"JS41");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"available");
            driver.navigate().refresh();
            Thread.sleep(2000);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.theme()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API allows you to customize your theme color.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeThemeConfig(ApiDriver,"Black");
            checkThemeConfig(ApiDriver,"rgba(99, 99, 99, 1)","JS42");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeThemeConfig(ApiDriver,"Gray");
            checkThemeConfig(ApiDriver,"rgba(244, 244, 244, 1)","JS43");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeThemeConfig(ApiDriver,"Blue");
            checkThemeConfig(ApiDriver,"rgba(135, 210, 213, 1)","JS44");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeThemeConfig(ApiDriver,"Green");
            checkThemeConfig(ApiDriver,"rgba(105, 180, 153, 1)","JS45");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeThemeConfig(ApiDriver,"Red");
            checkThemeConfig(ApiDriver,"rgba(255, 116, 113, 1)","JS46");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeThemeConfig(ApiDriver,"Purple");
            checkThemeConfig(ApiDriver,"rgba(196, 117, 193, 1)","JS47");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.feedback.visible()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API allows you to handle the visibility of feedback form, on completion of a chat.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigFeedback(ApiDriver,"Show");
            CommonFunctions.initiateChat(ApiDriver,"Tester9","rajkumar.natarajan+11236@zohocorp.com","87672688412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysFeedback(ApiDriver,"Show","JS48");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigFeedback(ApiDriver,"Hide");
            CommonFunctions.initiateChat(ApiDriver,"Tester9","rajkumar.natarajan+11236@zohocorp.com","87672688412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysFeedback(ApiDriver,"Hide","JS49");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.rating.visible()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","Use this API to handle the visibility of rating, on completion of a chat.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigRating(ApiDriver,"Show");
            CommonFunctions.initiateChat(ApiDriver,"Tester10","rajkumar.natarajan+11233@zohocorp.com","87677788412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysRating(ApiDriver,"Show","JS50");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigRating(ApiDriver,"Hide");
            CommonFunctions.initiateChat(ApiDriver,"Tester10","rajkumar.natarajan+11233@zohocorp.com","87677788412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysRating(ApiDriver,"Hide","JS51");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.custom.html()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","API allows you to have your own customized chat button. Supported for Float Chat and Embed Button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"Online Text Click Here","fctmhtmlon");
            checkConfigHTML(ApiDriver,"JS52","Online Text Click Here",null);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"<img src ='https://www.zoho.com/salesiq/img/Zilliumonline.png'>","fctmhtmlon");
            checkConfigHTML(ApiDriver,"JS53","Online Image","<img src ='https://www.zoho.com/salesiq/img/Zilliumonline.png'>");
            ApiDriver.quit();

            CommonFunctions.changeStatus(driver,"busy");
            driver.navigate().refresh();
            Thread.sleep(2000);

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"Offline Text Click Here","fctmhtmloff");
            checkConfigHTML(ApiDriver,"JS54","Offline Text Click Here",null);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"<img src ='https://www.zoho.com/salesiq/img/ZilliumOffline.png'>","fctmhtmloff");
            checkConfigHTML(ApiDriver,"JS55","Offline Image","<img src ='https://www.zoho.com/salesiq/img/ZilliumOffline.png'>");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"available");
            driver.navigate().refresh();
            Thread.sleep(2000);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.customfield.add()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","API allows you to create a new input field in the chat widget. Custom field inputs will be dispayed in visitor information section.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigField(ApiDriver,"text");
            checkConfigField(ApiDriver,"JS56","text");
            ApiDriver.quit();

//            New embed doesnot supports custom field
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigField(ApiDriver,"radio");
//            checkConfigField(ApiDriver,"JS57","radio");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigField(ApiDriver,"checkbox");
//            checkConfigField(ApiDriver,"JS58","checkbox");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigField(ApiDriver,"selectbox");
//            checkConfigField(ApiDriver,"JS59","selectbox");
//            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.info()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API allows you to add the additional information about the visitor and displays it to the agent in the visitor information section. These information are not visible to the visitors.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigInfo(ApiDriver,"{\"Payment Expiry\": \"Jan 20, 2017\"}");
            CommonFunctions.initiateChat(ApiDriver,"Tester11","rajkumar.natarajan+11239@zohocorp.com","87672688415","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            checkConfigInfo(driver,"JS60");
            CommonFunctions.endChat(driver,ApiDriver);
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chatbubble.visible()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API allows you to handle the visibility of chat bubble. Make sure to enable the chat bubble in WebEmbed settings.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigBubble(ApiDriver,"hide");
            checkConfigBubble(ApiDriver,"hide","JS21",null);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigBubble(ApiDriver,"show");
            checkConfigBubble(ApiDriver,"show","JS22","JS10");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            /*  Working set ends here */
        }
        catch(Exception e)
        {
            result.put("JS1",false);
            etest.log(Status.FATAL,"Error occurred while trying to open API Site");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiShowStopper","JSApiError",e);
        }

        ComplexReportFactory.closeTest(etest);

        hashtable.put("result",result);
        hashtable.put("servicedown",servicedown);
        return hashtable;
    }

    public static boolean checkBasic(WebDriver driver,String sname,String ename,String cname) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));

            CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();

            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");

            driver.switchTo().frame(chframe);

            String chtext = CommonUtil.elfinder(driver,"id",ename).getAttribute("value");

            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   :   >>"+chtext);

            if(chtext.equals(cname))
            {
                return true;
            }

            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApi"+sname,"Error",e);
            return false;
        }
    }

    public static boolean checkDept(WebDriver driver,String finder,String sname,String ename,String cname) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,finder,sname).click();
            CommonUtil.elfinder(driver,finder,sname).sendKeys(cname);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));

            CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();

            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");

            driver.switchTo().frame(chframe);

            String chtext = CommonUtil.elfinder(driver,"id",ename).getText();

            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   :   >>"+chtext);

            if(chtext.equals(cname))
            {
                return true;
            }

            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApi"+sname,"Error",e);
            return false;
        }
    }

    public static boolean checkOffline(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id","evntoffline").click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));

            CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();
            
            VisitorWindow.infoInvisible(driver);

            VisitorWindow.initiateChatVisTheme(driver,"Tester","rajkumar.natarajan+1243@zohocorp.com","9967682922",null,"what is zoho salesiq ? ...",false,etest,true);
            
            Thread.sleep(3000);
            
            driver.switchTo().defaultContent();

            if((CommonUtil.elfinder(driver,"id","evntdname").getText().equals("Tester"))&&(CommonUtil.elfinder(driver,"id","evntdemail").getText().equals("rajkumar.natarajan+1243@zohocorp.com"))&&(CommonUtil.elfinder(driver,"id","evntdques").getText().equals("what is zoho salesiq ? ..."))&&CommonFunctions.checkvid(driver,"evntvid","evntdvisitid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvid").getText());
                etest.log(Status.PASS,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntdname").getText());
                etest.log(Status.PASS,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntdemail").getText());
                etest.log(Status.PASS,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntdques").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntdvisitid").getText());
                return true;
            }

            etest.log(Status.FAIL,"Invalid Response : ");
            etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvid").getText());
            etest.log(Status.FAIL,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntdname").getText()+" || ( Expected : Tester)");
            etest.log(Status.FAIL,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntdemail").getText()+" || ( Expected : rajkumar.natarajan+1243@zohocorp.com)");
            etest.log(Status.FAIL,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntdques").getText()+" || ( Expected : what is zoho salesiq ? ...)");
            etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntdvisitid").getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOffline","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOffline","Error",e);
            return false;
        }
    }

    public static boolean checkClicks(WebDriver driver,String cname,String ename) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id",cname).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.clickCloseChatWidget(driver);

            Thread.sleep(1000);

            if(CommonUtil.elfinder(driver,"id",ename).getText().equals("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
                return true;
            }

            etest.log(Status.FAIL,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiClick","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiClick","Error",e);
            return false;
        }
    }

    public static boolean checkChatHandler(WebDriver driver,String cname,String ename) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id",cname).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));

            System.out.println(" <<< <<< <<< <<< <<< <<< <<< <<< : "+CommonUtil.elfinder(driver,"id",ename).getText()+" >>> >>> >>> >>>");

            if(CommonUtil.elfinder(driver,"id",ename).getText().equals("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
                return true;
            }
            etest.log(Status.FAIL,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiChat","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiChat","Error",e);
            return false;
        }
    }

    public static boolean checkEvHandler(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id","evtchatonline").click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));

            VisitorWindow.clickChatButton(driver);

            if(CommonUtil.elfinder(driver,"id","evtchatonline").getText().equals("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(driver,"id","evtchatonline").getText());
                return true;
            }
            etest.log(Status.FAIL,"Response : "+CommonUtil.elfinder(driver,"id","evtchatonline").getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiEvent","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiEvent","Error",e);
            return false;
        }
    }

    public static void changeConfig(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fvinfo").click();
            CommonUtil.elfinder(driver,"id","evtbuttonmin").click();
            CommonUtil.elfinder(driver,"id","evtwaitinghdlr").click();
            CommonUtil.elfinder(driver,"id","evtchatatnd").click();
            CommonUtil.elfinder(driver,"id","evtagentmsg").click();
            CommonUtil.elfinder(driver,"id","evtchatcomplete").click();
            CommonUtil.elfinder(driver,"id","evtvisitorchat").click();
            CommonUtil.elfinder(driver,"id","evtvisitorrating").click();
            CommonUtil.elfinder(driver,"id","evtvisitorfeedback").click();
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfig","Error",e);
        }
    }

    public static void checkConfig(WebDriver driver,WebDriver ApiDriver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JS13",false);
            result.put("JS14",false);
            result.put("JS15",false);
            result.put("JS16",false);
            result.put("JS17",false);
            result.put("JS18",false);
            result.put("JS19",false);
            result.put("JS20",false);

            String attname = CommonFunctions.getUsername(driver);
            String attemail = CommonFunctions.getUseremail(driver);

            ApiDriver.switchTo().defaultContent();

            etest = ComplexReportFactory.getTest("$zoho.salesiq.floatwindow.minimize()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method on minimizing the float window.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntbminimize").getText().contains("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(ApiDriver,"id","evntbminimize").getText());
                result.put("JS13",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : "+CommonUtil.elfinder(ApiDriver,"id","evntbminimize").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiMinimize","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.waitinghandler()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method to display your own content in the chat widget's waiting timer.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntwwaitingtime").getText().contains("60")&&CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText()!=null&&!CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText().contains("undefined")&&!CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText().equals("0"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Configured waiting Time : "+CommonUtil.elfinder(ApiDriver,"id","evntwwaitingtime").getText());
                etest.log(Status.PASS,"Current time in timer : "+CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText());
                result.put("JS14",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Configured waiting Time : "+CommonUtil.elfinder(ApiDriver,"id","evntwwaitingtime").getText()+" || ( Expected : 60)");
                etest.log(Status.FAIL,"Current time in timer : "+CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiTimerFail","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.attend()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when an agent attends the chat.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntchtatnddname").getText().contains(attname)&&CommonUtil.elfinder(ApiDriver,"id","evntchtatnddemail").getText().contains(attemail)&&CommonFunctions.checkvid(ApiDriver,"evntchtatndvid","evntchtatnddvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatndvid").getText());
                etest.log(Status.PASS,"Attender Name : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddname").getText());
                etest.log(Status.PASS,"Attender Email : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddemail").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddvid").getText());
                result.put("JS15",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatndvid").getText());
                etest.log(Status.FAIL,"Attender Name : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddname").getText()+" || ( Expected : "+attname+")");
                etest.log(Status.FAIL,"Attender Email : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddemail").getText()+" || ( Expected : "+attemail+")");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiAttender","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.agentMessage()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when a message is sent to the visitor by the agent.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntagntobjmsg").getText().contains("Second message")&&CommonFunctions.checkvid(ApiDriver,"evntagntvid","evntagntobjvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntagntvid").getText());
                etest.log(Status.PASS,"Agent Message : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjmsg").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjvid").getText());
                result.put("JS16",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntagntvid").getText());
                etest.log(Status.FAIL,"Agent Message : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjmsg").getText()+" || ( Expected : Hello there, welcome to testing team ...)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiAgentMessage","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.chat.complete()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when a chat session is completed.");

            if(!(CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText().contains("undefined"))&&CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText()!=null&&!CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText().equals("")&&CommonFunctions.checkvid(ApiDriver,"evntctcmplttvid","evntctcmpltobjvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmplttvid").getText());
                etest.log(Status.PASS,"Chat Duration : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjvid").getText());
                result.put("JS17",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmplttvid").getText());
                etest.log(Status.FAIL,"Chat Duration : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText());
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiChat","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.chat()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when a visitor initiates the chat.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntvchatdname").getText().contains("Tester5")&&CommonUtil.elfinder(ApiDriver,"id","evntvchatdemail").getText().contains("rajkumar.natarajan+11223@zohocorp.com")&&CommonUtil.elfinder(ApiDriver,"id","evntvchatdques").getText().contains("what is zoho salesiq ? ...")&&CommonFunctions.checkvid(ApiDriver,"evntvchatvid","evntvchatdvisitid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatvid").getText());
                etest.log(Status.PASS,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdname").getText());
                etest.log(Status.PASS,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdemail").getText());
                etest.log(Status.PASS,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdques").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdvisitid").getText());
                result.put("JS18",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid Response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatvid").getText());
                etest.log(Status.FAIL,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdname").getText()+" || ( Expected : Tester5)");
                etest.log(Status.FAIL,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdemail").getText()+" || ( Expected : rajkumar.natarajan+11223@zohocorp.com)");
                etest.log(Status.FAIL,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdques").getText()+" || ( Expected : what is zoho salesiq ? ...)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdvisitid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiDetails","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.rating()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method, when a visitor rates the support session.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntdratingagent").getText().contains(attemail)&&CommonUtil.elfinder(ApiDriver,"id","evntratingrating").getText().contains("4")&&CommonFunctions.checkvid(ApiDriver,"evntratingvid","evntratingdvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntratingvid").getText());
                etest.log(Status.PASS,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdratingagent").getText());
                etest.log(Status.PASS,"Rating : "+CommonUtil.elfinder(ApiDriver,"id","evntratingrating").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntratingdvid").getText());
                result.put("JS19",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntratingvid").getText());
                etest.log(Status.FAIL,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdratingagent").getText()+" || ( Expected : "+attemail+")");
                etest.log(Status.FAIL,"Rating : "+CommonUtil.elfinder(ApiDriver,"id","evntratingrating").getText()+" || ( Expected : 4)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntratingdvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiRating","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.feedback()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This event handler allows you to invoke a method on submitting the feedback message.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntdfeedbackagent").getText().contains(attemail)&&CommonUtil.elfinder(ApiDriver,"id","evntfeedbackrating").getText().contains("Feedback Positive")&&CommonFunctions.checkvid(ApiDriver,"evntfeedbackvid","evntfeedbackdvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackvid").getText());
                etest.log(Status.PASS,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdfeedbackagent").getText());
                etest.log(Status.PASS,"Feedback : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackrating").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackdvid").getText());
                result.put("JS20",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackvid").getText());
                etest.log(Status.FAIL,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdfeedbackagent").getText()+" || ( Expected : "+attemail+")");
                etest.log(Status.FAIL,"Feedback : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackrating").getText()+" || ( Expected : Feedback Positive)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackdvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiFeedback","Error");
            }

            ComplexReportFactory.closeTest(etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSAPIConfig","Error",e);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigBasic(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fname").click();
            CommonUtil.elfinder(driver,"id","fname").sendKeys("Tester");
            CommonUtil.elfinder(driver,"id","femail").click();
            CommonUtil.elfinder(driver,"id","femail").sendKeys("rajkumar.natarajan+143@zohocorp.com");
            CommonUtil.elfinder(driver,"id","fphone").click();
            CommonUtil.elfinder(driver,"id","fphone").sendKeys("9876544578");
            //CommonUtil.elfinder(driver,"name","defaultdept").click();
            //CommonUtil.elfinder(driver,"name","defaultdept").sendKeys("Automation");
            CommonUtil.elfinder(driver,"id","fquestion").click();
            CommonUtil.elfinder(driver,"id","fquestion").sendKeys("Any Question? ...");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigBasic","Error",e);
        }
    }

    public static void checkConfigBasic(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.name()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API is used to fill the visitor's name in the chat widget text box.");

            result.put("JS2",false);
            result.put("JS3",false);
            result.put("JS4",false);
            result.put("JS5",false);
            //result.put("JS6",false);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);

            String cname = CommonUtil.elfinder(driver,"id","visname").getAttribute("value");
            String cemail = CommonUtil.elfinder(driver,"id","visemail").getAttribute("value");
            String cphone = CommonUtil.elfinder(driver,"id","visphone").getAttribute("value");
            String cques = CommonUtil.elfinder(driver,"id","msgarea").getAttribute("value");
            //String cdept = CommonUtil.elfinder(driver,"id","selecteddept").getText();

            if(cname.equals("Tester"))
            {
                etest.log(Status.PASS,"Text in Field : "+cname);
                result.put("JS2",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cname+" || (Expected : Tester)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiName","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.email()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","You can use this API to fill the visitor email address in the chat widget text box.");

            if(cemail.equals("rajkumar.natarajan+143@zohocorp.com"))
            {
                etest.log(Status.PASS,"Text in Field : "+cemail);
                result.put("JS3",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cemail+" || (Expected : rajkumar.natarajan+143@zohocorp.com)");
                TakeScreenshot.screenshot(driver,etest,"JSAPIEmail","JSApi","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.contactnumber()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","This API is used to fill the visitor contact number in the chat widget text box.");

            if(cphone.equals("9876544578"))
            {
                etest.log(Status.PASS,"Text in Field : "+cphone);
                result.put("JS4",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cphone+" || (Expected : 9876544578)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiPhone","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("$zoho.salesiq.visitor.question()");
            ComplexReportFactory.setValues(etest,"Automation","JSAPI","You can use this API to pre-fill a question in the chat widget.");

            if(cques.equals("Any Question? ..."))
            {
                etest.log(Status.PASS,"Text in Field : "+cques);
                result.put("JS5",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cques+" || (Expected : Any Question? ...)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiQuestion","Error");
            }

            ComplexReportFactory.closeTest(etest);

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfig","Error",e);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigBubble(WebDriver driver,String viewCk) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"name","bubblevisible").click();
            CommonUtil.elfinder(driver,"name","bubblevisible").sendKeys(viewCk);
            CommonUtil.elfinder(driver,"name","bubblesrc").click();
            CommonUtil.elfinder(driver,"name","bubblesrc").sendKeys(ResourceManager.getRealValue("image_salesiq"));
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error",e);
        }
    }

    public static void checkConfigBubble(WebDriver driver,String viewCk,String ent1,String ent2) throws IOException, InterruptedException
    {
        try
        {
            if(viewCk.equals("hide"))
            {
                result.put(ent1,false);
                if(CommonUtil.elfinder(driver,"id","zlsbubanim").getAttribute("style").contains("none")&&CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","zlsbubanim"),"tagname","img").getAttribute("src").equals(ResourceManager.getRealValue("image_salesiq")))
                {
                    etest.log(Status.PASS,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    result.put(ent1,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error");
                }
            }
            else
            {
                result.put(ent1,false);
                result.put(ent2,false);

                if(CommonUtil.elfinder(driver,"id","zlsbubanim").getAttribute("style").contains("block")&&CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","zlsbubanim"),"tagname","img").getAttribute("src").equals(ResourceManager.getRealValue("image_salesiq")))
                {
                    etest.log(Status.PASS,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    result.put(ent1,true);
                    result.put(ent2,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error",e);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigSys1(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fsystemmessages").click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("fsysmsg")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);

            CommonFunctions.enterValueSysMsg(driver,"fsyswaiting","Waiting Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusy","Busy Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusycomplete","Busy Response Message");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void checkConfigsys1(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JS23",false);
            result.put("JS24",false);
            result.put("JS25",false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.initiateChat(driver,"Tester6","rajkumar.natarajan+1442@zohocorp.com","99887688667","is chat working properly ? ...");

            Thread.sleep(5000);
            
            VisitorWindow.switchToChatWidget(driver);
            
            String wResponse = VisitorWindow.getInfoMessage(driver);

            if(wResponse.contains("Waiting Message"))
            {
                etest.log(Status.PASS,"Waiting message : "+wResponse);
                result.put("JS23",true);
            }
            else
            {
                etest.log(Status.FAIL,"Waiting message : "+wResponse+" || (Expected : Waiting Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiWaitingMessage","Error");
            }

            Thread.sleep(60000);
            
            String bResponse = VisitorWindow.getInfoMessage(driver);

            if(bResponse.contains("Busy Message"))
            {
                etest.log(Status.PASS,"Busy message : "+bResponse);
                result.put("JS24",true);
            }
            else
            {
                etest.log(Status.FAIL,"Busy message : "+bResponse+" || (Expected : Busy Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBuyMessage","Error");
            }

            // VisitorWindow.initiateChatVisTheme(driver,null,null,null,null,"Hi",false,etest,true);
            
            // VisitorWindow.infoInvisible(driver);
            VisitorWindow.submitResponseAfterMissingChatWithAgent(driver,"Hi");
            
            String brResponse = VisitorWindow.getInfoMessage(driver,"Busy Response Message");

            if(brResponse.contains("Busy Response Message"))
            {
                etest.log(Status.PASS,"Busy response message : "+brResponse);
                result.put("JS25",true);
            }
            else
            {
                etest.log(Status.FAIL,"Busy response message : "+brResponse+" || (Expected : Busy Response Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBusyResponse","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void changeConfigSys(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fsystemmessages").click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("fsysmsg")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);

            CommonFunctions.enterValueSysMsg(driver,"fsyswaiting","Waiting Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysoffline","Offline Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusy","Busy Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusycomplete","Busy Response Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysengaged","Engaged Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysengagedcomplete","Engaged Response Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysprechatmessage","Pre Chat Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysofflinecomplete","Offline Response Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete1","Rated 1 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete2","Rated 2 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete3","Rated 3 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete4","Rated 4 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete5","Rated 5 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysagentinfomessage","Agent Info Message");
            
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Entered values",0);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
            
            Thread.sleep(1500);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void checkConfigSys(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JS26",false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);
            
            String preResponse = VisitorWindow.getInfoMessage(driver);

            if(preResponse.contains("Pre Chat Message"))
            {
                etest.log(Status.PASS,"Pre chat message : "+preResponse);
                result.put("JS26",true);
            }
            else
            {
                etest.log(Status.FAIL,"Pre chat message : "+preResponse+" || (Expected : Pre Chat Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiPrechatMessage","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiPrechatMessage","Error",e);
        }
    }

    public static void checkConfigSys2(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JS27",false);
            result.put("JS28",false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);
            
            String oResponse = VisitorWindow.getInfoMessage(driver);

            if(oResponse.contains("Offline Message"))
            {
                etest.log(Status.PASS,"Offline message : "+oResponse);
                result.put("JS27",true);
            }
            else
            {
                etest.log(Status.FAIL,"Offline message : "+oResponse+" || (Expected : Offline Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOfflineMessage","Error");
            }

            VisitorWindow.infoInvisible(driver);
            
            VisitorWindow.initiateChatVisTheme(driver,"Tester7","rajkumar.natarajan+1249@zohocorp.com","9967682922",null,"what is zoho salesiq ? ...",false,etest,true);
            
            String orResponse = VisitorWindow.getInfoMessage(driver);
            
            if(orResponse.contains("Offline Response Message"))
            {
                etest.log(Status.PASS,"Offline response message : "+orResponse);
                result.put("JS28",true);
            }
            else
            {
                etest.log(Status.FAIL,"Offline response message : "+orResponse+" || (Expected : Offline Response Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOfflineResponseMessage","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void checkConfigSysFdbk(WebDriver driver,String rating,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            VisitorWindow.switchToChatWidget(driver);
            
            String response = VisitorWindow.getInfoMessage(driver);

            if(response.contains("Rated "+rating+" Star"))
            {
                etest.log(Status.PASS,"Feedback Response for "+rating+" rating : "+response);
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Feedback Response for "+rating+" rating : "+response);
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedbackRating","Error",e);
        }
    }

    public static void changeCSSConfig(WebDriver driver,String pos) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fname").click();
            new Select(driver.findElement(By.xpath(".//select[@id='fname']"))).selectByVisibleText(pos);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSConfig","Error",e);
        }
    }

    public static void checkCSSConfig(WebDriver driver,String pos,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            WebElement elmt = CommonUtil.elfinder(driver,"classname","zls-small");

            System.out.println("<<<<<<<<<----------------- CSS Value top --------------------------->>>>>>"+elmt.getCssValue("top"));
            System.out.println("<<<<<<<<<----------------- CSS Value left --------------------------->>>>>>"+elmt.getCssValue("left"));
            System.out.println("<<<<<<<<<----------------- CSS Value right --------------------------->>>>>>"+elmt.getCssValue("right"));
            System.out.println("<<<<<<<<<----------------- CSS Value bottom --------------------------->>>>>>"+elmt.getCssValue("bottom"));
            String top = elmt.getCssValue("top");
            String bottom = elmt.getCssValue("bottom");
            String left = elmt.getCssValue("left");
            String right = elmt.getCssValue("right");

            if(CommonFunctions.checkPos(top,bottom,left,right).equals(pos))
            {
                etest.log(Status.PASS,"Current Position : "+CommonFunctions.checkPos(top,bottom,left,right)+" || (Expected : "+pos+")");
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Current Position : "+CommonFunctions.checkPos(top,bottom,left,right)+" || (Expected : "+pos+")");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSConfig","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSConfig","Error",e);
        }
    }

    public static void changeFBImgConfig(WebDriver driver,String ename,String value) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"name",ename).click();
            CommonUtil.elfinder(driver,"name",ename).sendKeys(value);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOnlineImage","Error",e);
        }
    }

    public static void checkFBImgConfig(WebDriver driver,String value,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            if(CommonUtil.elfinder(driver,"id","zlsfltimg").getAttribute("src").equals(value))
            {
                etest.log(Status.PASS,"Image Found and Uploaded Image Match");
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Image Found and Uploaded Image do not match");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiImage","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOnlineImage","Error",e);
        }
    }

    public static void changeThemeConfig(WebDriver driver,String color) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","ftheme").click();
            new Select(driver.findElement(By.xpath(".//select[@id='ftheme']"))).selectByVisibleText(color);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigTheme","Error",e);
        }
    }

    public static void checkThemeConfig(WebDriver driver,String color,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            WebElement elmt = CommonUtil.elfinder(driver,"id","zls_ctn_wrap");

            System.out.println("<<<<<<<<<----------------- CSS Value Color --------------------------->>>>>>"+elmt.getCssValue("background-color"));
            String curcol = elmt.getCssValue("background-color");

            if(curcol.equals(color))
            {
                etest.log(Status.PASS,"Current Theme : "+curcol+" || (Expected : "+color+")");
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Current Theme : "+curcol+" || (Expected : "+color+")");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSColour","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSCTheme","Error",e);
        }
    }

    public static void changeConfigFeedback(WebDriver driver,String vis) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","feedbackvisible").click();
            new Select(driver.findElement(By.xpath(".//select[@id='feedbackvisible']"))).selectByVisibleText(vis);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error",e);
        }
    }

    public static void checkConfigSysFeedback(WebDriver driver,String vis,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);
            
            VisitorWindow.switchToChatWidget(driver);
            
            if(vis.equals("Show"))
            {
                if(feedbackFound(driver))
                {
                    etest.log(Status.PASS,"Show - Feedback Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Show - Feedback Not Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error");
                }
            }
            else
            {
                if(!feedbackFound(driver))
                {
                    etest.log(Status.PASS,"Hide - Feedback Not Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Hide - Feedback Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error",e);
        }
    }

    public static boolean feedbackFound(WebDriver driver)
    {
        try
        {
            VisitorWindow.enterFeedbackInTheme(driver,"Feedback",null);
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public static void changeConfigRating(WebDriver driver,String vis) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","ratingvisible").click();
            new Select(driver.findElement(By.xpath(".//select[@id='ratingvisible']"))).selectByVisibleText(vis);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigRating","Error",e);
        }
    }

    public static void checkConfigSysRating(WebDriver driver,String vis,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            VisitorWindow.switchToChatWidget(driver);
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            if(vis.equals("Show"))
            {
                if(ratingFound(driver))
                {
                    etest.log(Status.PASS,"Show - Rating Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Show - Rating Not Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiRating","Error");
                }
            }
            else
            {
                if(!ratingFound(driver))
                {
                    etest.log(Status.PASS,"Hide - Rating Not Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Hide - Rating Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigRating","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigRating","Error",e);
        }
    }

    public static boolean ratingFound(WebDriver driver)
    {
        try
        {
            VisitorWindow.enterFeedbackInTheme(driver,null,"1");

            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public static void changeConfigHTML(WebDriver driver,String txt,String elid) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmhtml")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmhtml").click();
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",elid)).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id",elid).click();
            CommonUtil.elfinder(driver,"id",elid).sendKeys(txt);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error",e);
        }
    }

    public static void checkConfigHTML(WebDriver driver,String rkey,String verEl,String imgEl) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait flwait = CommonUtil.waitreturner(driver,30,250);

            if(imgEl==null)
            {
                if(CommonUtil.elfinder(driver,"id","salesiqchat").getText().equals(verEl))
                {
                    CommonUtil.elfinder(driver,"id","salesiqchat").click();

                    try
                    {
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(!driver.findElement(By.className("zls-small")).getAttribute("style").contains("block"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        etest.log(Status.PASS,"Custom HTML - Text : "+CommonUtil.elfinder(driver,"id","salesiqchat").getText());
                        result.put(rkey,true);
                    }
                    catch(Exception e)
                    {
                        etest.log(Status.FAIL,"Custom HTML - Text : "+CommonUtil.elfinder(driver,"id","salesiqchat").getText()+" || (Expected : "+verEl+" ) Onclick not working");
                        TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error",e);
                    }
                }
                else
                {
                    etest.log(Status.FAIL,"Custom HTML - Text : "+CommonUtil.elfinder(driver,"id","salesiqchat").getText()+" || (Expected : "+verEl+" )");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error");
                }
            }
            else
            {
                String imgsrc = "<img src ='"+CommonUtil.elfinder(driver,"id","salesiqchat").findElement(By.tagName("img")).getAttribute("src")+"'>";

                if(imgsrc.equals(imgEl))
                {
                    //CommonUtil.elfinder(driver,"id","salesiqchat").findElement(By.tagName("img")).click();
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[contains(@src,'"+CommonUtil.elfinder(driver,"id","salesiqchat").findElement(By.tagName("img")).getAttribute("src")+"')]")));

                    CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","salesiqchat"),"tagname","img").click();

                    try
                    {
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(!driver.findElement(By.className("zls-small")).getAttribute("style").contains("block"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        etest.log(Status.PASS,"Custom HTML - Image : "+imgsrc);
                        result.put(rkey,true);
                    }
                    catch(Exception e)
                    {
                        etest.log(Status.FAIL,"Custom HTML - Image : "+imgsrc+" Onclick not working");
                        TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApi","Error",e);
                    }
                }
                else
                {
                    etest.log(Status.FAIL,"Custom HTML - Image : "+imgsrc+" || (Expected : "+imgEl+")");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error",e);
        }
    }

    public static void changeConfigField(WebDriver driver,String field) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfield")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmfield").click();
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfieldname")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmfieldname").click();
            CommonUtil.elfinder(driver,"id","fctmfieldname").sendKeys("FieldName");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfieldhint")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmfieldhint").click();
            CommonUtil.elfinder(driver,"id","fctmfieldhint").sendKeys("FieldHint");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfieldhint")).getLocation().y+")");
            Thread.sleep(300);

            List<WebElement> clElmt = driver.findElements(By.name("ctmfldtype"));

            for(WebElement elmt:clElmt)
            {
                if(elmt.getAttribute("value").equals(field))
                {
                    elmt.click();
                }
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomField","Error",e);
        }
    }

    public static void checkConfigField(WebDriver driver,String rkey,String field) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);

            if(CommonUtil.elfinder(driver,"id","FieldName").getAttribute("type").equals(field))
            {
                etest.log(Status.PASS,"Field Added with the given details : "+field);
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Unable to add field : "+field);
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomField","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomField","Error",e);
        }
    }

    public static void changeConfigInfo(WebDriver driver,String txt) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fvinfo").click();
            CommonUtil.elfinder(driver,"id","fvinfo").sendKeys(txt);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiVisitorInfo","Error",e);
        }
    }

    public static void checkConfigInfo(WebDriver driver,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vdvstinfo")));

            WebElement elmt = CommonUtil.elfinder(driver,"id","cinfo");
            String keyElmt = CommonUtil.elementfinder(driver,elmt,"classname","crmld_inflft").getText();
            String valElmt = CommonUtil.elementfinder(driver,elmt,"classname","crmld_infrht").getText();

            if(keyElmt.equals("Payment Expiry")&&valElmt.equals("Jan 20, 2017"))
            {
                etest.log(Status.PASS,"Visitor Info : "+keyElmt+" : "+valElmt);
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Visitor Info : "+keyElmt+" : "+valElmt);
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiVisitorInfo","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiVisitorInfo","Error",e);
        }
    }
}
