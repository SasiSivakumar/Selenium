//$Id$
package com.zoho.livedesk.client.MobileTesting;

import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.client.TakeScreenshot;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;

public class MobileFunctions {

	/*
	
	public static void clickTabIcon(AppiumDriver driver) throws Exception
    {
		if(MobileUtil.tabIconVisible)
		{
	    	FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
	    	
	    	String tabicon = Property.getRealValue("tabicon");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className(tabicon)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(tabicon)));
			
			driver.findElement(By.className(tabicon)).click();
			
			MobileUtil.etest.log(Status.INFO, "Tab icon is clicked");
			
			String sidedrawer = Property.getRealValue("sidedrawer");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(sidedrawer)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(sidedrawer)));
			
			MobileUtil.etest.log(Status.INFO, "Side menu is visible");
		}
	}
	
	public static WebElement getTab(AppiumDriver driver, String tab) throws Exception
    {
		Thread.sleep(2000);
    	
    	String tabsPresent = "Expected:"+tab+"--Actual:";
    	
    	List<WebElement> d = driver.findElements(By.id("com.zoho.salesiq:id/item_name"));
		
		for(WebElement e : d)
		{
			String s = e.getAttribute("text");
			
			tabsPresent += s+",";
			
			if(s.equals(tab))
			{
				System.out.println(tabsPresent);
				MobileUtil.tabIconVisible = true;
				return e;
			}
		}
    	
		MobileUtil.etest.log(Status.FAIL, tabsPresent);
		
		TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "Tab", tab+"NotFound");
		
		MobileUtil.tabIconVisible = true;
		return d.get(tabOrder(tab));
	}
	
	public static void slideToTop(AppiumDriver driver) throws Exception
	{
		if(!MobileUtil.sliderPositon)
		{
			driver.swipe(100, 700, 100, 1400, 1000);
		
			MobileUtil.etest.log(Status.INFO, "Sidedrawer - slided to top");
			
			MobileUtil.sliderPositon = true;
		}
	}
	
	public static void slideToBottom(AppiumDriver driver) throws Exception
	{
		if(MobileUtil.sliderPositon)
		{
			driver.swipe(100, 1000, 100, 200, 1000);
			
			MobileUtil.etest.log(Status.INFO, "Sidedrawer - slided to bottom");
			
			MobileUtil.sliderPositon = false;
		}
	}
	
	public static void clickListView(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
    	
		String list = Property.getRealValue("visitorsonline_listview");
		
		WebElement list_icon = driver.findElement(By.id(list));
		wait.until(ExpectedConditions.visibilityOf(list_icon));
		
		list_icon.click();
		
		MobileUtil.etest.log(Status.INFO, "List view is clicked");
	}
	
	public static String getUserName(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
    	
		String headername = Property.getRealValue("headername");
		
		WebElement header = driver.findElement(By.id(headername));
		wait.until(ExpectedConditions.visibilityOf(header));
		
		String user = header.getText();
		
		MobileUtil.etest.log(Status.INFO, user+" is obtained");
		
		return user;
	}
	
	public static void closeVisitorDriver() throws Exception
	{
		if(MobileUtil.visDriver != null)
		{
			MobileUtil.visDriver.quit();
			MobileUtil.visDriver = null;
		}
	}
	
	public static void pickUp(AppiumDriver driver, String msg) throws Exception
	{
		TouchAction action = new TouchAction(driver);
		
		Dimension size = driver.manage().window().getSize();
		
		int x = size.width;
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
    	
		String pickup = Property.getRealValue("pickup");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(pickup)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(pickup)));
		
		MobileUtil.etest.log(Status.INFO, "Pickup is visible");
		
		WebElement e = driver.findElement(By.id(pickup));
		
		action.longPress(e).moveTo(x-30,1000).release().perform();
		
		MobileUtil.etest.log(Status.INFO, "Pickup is slided");
		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(pickup)));
		
		MobileUtil.etest.log(Status.INFO, "Pickup is invisible");
	
        String textarea = Property.getRealValue("textarea");
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(textarea)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(textarea)));
		
		driver.findElement(By.id(textarea)).sendKeys(msg);
		
		MobileUtil.etest.log(Status.INFO, "Message is entered");
		
		String sent = Property.getRealValue("sent");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(sent)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(sent)));
			
		driver.findElement(By.id(sent)).click();
		
		MobileUtil.etest.log(Status.INFO, "Enter is clicked");
	}
	
	public static Boolean checkMessage(AppiumDriver driver, String msg, int count ) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String message = Property.getRealValue("message");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(message)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(message)));
		
		List<WebElement> msgs = driver.findElements(By.id(message));
		
		String present = msgs.get(count).getText();
			
		if(present.contains(msg))
		{
			MobileUtil.etest.log(Status.INFO, "Message:"+msg+" is found in App");
			return true;
		}
		else
		{
			MobileUtil.etest.log(Status.INFO, "Message - "+msg+" is not found at "+(count+1)+"."+present+" is present.");
			return false;
		}
	}
	
	public static void clickChatBackButton(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String back = Property.getRealValue("chatbackicon_"+MobileUtil.device);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(back)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(back)));
		
		driver.findElement(By.xpath(back)).click();
		
		MobileUtil.etest.log(Status.INFO, "Chat Back button is clicked");
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Ongoing Chats"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Ongoing Chats--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Ongoing is opened");
	}
	
	public static WebElement getVisitorInList(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String vname = Property.getRealValue("list_visname");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(vname)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(vname)));
		
		return driver.findElement(By.id(vname));
	}
	
	public static int tabOrder(String tab)
	{
		Integer count =  null;
		switch(tab)
		{
			case "Online": count = 0;break;
							
			case "History": count = 1;break;
							
			case "Ongoing": count = 2;break;
				
			case "Missed": count = 3;break;
			
			case "User Chats": count = 2;break;
			
			case "Message Board": count = 3;break;
			
			case "Settings": count = 4;break;
			
			case "About us": count = 5;break;
			
			case "Feedback": count = 6;break;
		}
		return count;
	}
	
	public static void endChat(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String more = Property.getRealValue("more");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(more)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(more)));
		
		driver.findElement(By.xpath(more)).click();
		
		MobileUtil.etest.log(Status.INFO, "More is clicked");
		
		String endsession = Property.getRealValue("endsession");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(endsession)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(endsession)));
		
		driver.findElement(By.xpath(endsession)).click();
		
		MobileUtil.etest.log(Status.INFO, "End session is clicked");
		
		String info = Property.getRealValue("info");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(info)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(info)));
		
		MobileUtil.etest.log(Status.INFO, "Info is visible");
	}
	
	public static void clickBackButton(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String chatbackicon = Property.getRealValue("chatbackicon_"+MobileUtil.device);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(chatbackicon)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(chatbackicon)));
		
		driver.findElement(By.xpath(chatbackicon)).click();
		
		MobileUtil.etest.log(Status.INFO, "Chat back icon is clicked");
		
		Thread.sleep(2000);
	}
	
	public static void missChat(AppiumDriver driver)
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String pickup = Property.getRealValue("pickup");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(pickup)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(pickup)));
		
		MobileUtil.etest.log(Status.INFO, "Pickup is visible");
		
		wait = CommonUtil.waitreturner(driver, 150, 250);
		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(pickup)));
		
		MobileUtil.etest.log(Status.INFO, "Pickup is invisible");
	}
	
	public static void clickBack(AppiumDriver driver, String header)
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String button = "android.widget.ImageButton";
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className(button)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(button)));
		
		WebElement e = driver.findElement(By.className(button));
		
		e.click();
		
		MobileUtil.etest.log(Status.INFO, "Back button is clicked");
		
		waitTillHeaderLoaded(driver, header);
	}
	
	public static void waitTillHeaderLoaded(AppiumDriver driver,String header)
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String xpath = "//android.widget.TextView[contains(@text,'"+header+"')]";
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		
		MobileUtil.etest.log(Status.INFO, header+" is loaded");
	}
	
	public static List<WebElement> getListInSettings(AppiumDriver driver)
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String xpath = Property.getRealValue("settings_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(xpath)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(xpath)));
		
		List<WebElement> list = driver.findElements(By.id(xpath));
		
		return list;
	}
	
	public static WebElement getOptionsInSettings(AppiumDriver driver, String option)
	{
		List<WebElement> list = getListInSettings(driver);
		
		for(WebElement e : list)
		{
			if(e.getText().equals(option))
			{
				return e;
			}
		}
		
		return null;
	}
	
	public static void clickOptionsInSettings(AppiumDriver driver, String option)
	{
		getOptionsInSettings(driver, option).click();
		
		MobileUtil.etest.log(Status.INFO, option+" is clicked");
	}
	
	public static String getStatusFromSettings(AppiumDriver driver, Boolean navToSettings) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		if(navToSettings)
		{
			MobileTab.clickSettingsTab(driver);
		}
		
		String sta = Property.getRealValue("settings_status");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(sta)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(sta)));
			
		String status = driver.findElement(By.id(sta)).getText();
		
		MobileUtil.etest.log(Status.INFO, "Status - "+status+" is obtained from Settings page");
		
		return status;
	}
	
	public static void checkCurrentStatus(AppiumDriver driver, String status)
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		int i = status.equals("Available")?1:2;
				
		String xpath = Property.getRealValue("status_checked_"+MobileUtil.device).replace("$COUNT", ""+i);
		
		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			
			MobileUtil.etest.log(Status.INFO,"Current status is "+status);
		}
		catch(Exception e)
		{
			MobileUtil.etest.log(Status.INFO,"Current status is not "+status);
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation",  "CheckCurrentStatus", "Error", e);
			throw e;
		}
	}
	
	public static WebElement getStatusList(AppiumDriver driver, String status)
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String status_text = Property.getRealValue("status_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(status_text)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(status_text)));
		
		List<WebElement> list = driver.findElements(By.id(status_text));
		
		for(WebElement e : list)
		{
			if(e.getText().equals(status))
			{
				return e;
			}
		}
		
		return null;
	}
	
	public static void swipeTheme(AppiumDriver driver, Boolean toLeft) throws Exception
	{
		Dimension size = driver.manage().window().getSize();
		
		TouchAction action = new TouchAction(driver);
		
		int x = size.width;
		int y = size.height;
		if(toLeft)
		{
			action.longPress(x-1, y/2).moveTo(0, y/2).release().perform();
			MobileUtil.etest.log(Status.INFO,"Theme swiped to left");
			Thread.sleep(10000);
		}
		else
		{
			action.longPress(0, y/2).moveTo(x-1, y/2).release();
			MobileUtil.etest.log(Status.INFO,"Theme swiped to right");
			Thread.sleep(10000);
		}
	}

	*/
}
