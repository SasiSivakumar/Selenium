//$Id$
package com.zoho.livedesk.client.MobileTesting;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.util.Hashtable;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.NoSuchElementException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.ConfManager;

public class MobileUtil
{
	/*

	static String device = "emulator";
    static String emailId = "rajkumar.natarajan+1@zohocorp.com";
    static String pswd = "test1234";
	static String user = "LD1Automation";
	static String embedcode = "eb88e8f6030aa71b0630455ca52ca9c348f6730d45cc52adce07d09d957692b85726a819502f7e86df01fd47323eaaad";
	static String dept = "Raj Trial";
    static String depts = "Raj Trial, Department2";

	static AppiumDriver driver = null;
	static boolean reset = true;
	static ExtentTest etest = null;
	static WebDriver visDriver = null;
	static Hashtable<String, Boolean> result = new Hashtable<String, Boolean>();
	
	static Boolean sliderPositon = true;
	static Boolean tabIconVisible = true;
	static Long currentTime = null;
	static String[] notifications = {"Customer Chat Messages","Agent Chat Messages","New Chat Request"};
	static Hashtable<String, String[]> notifications_list = new Hashtable<>();
	
	public static void main(String args[]) throws Exception
	{
		System.out.println(test());
	}
	
	public static Hashtable<String, Boolean> test() throws Exception
	{
		result.clear();//to clear hashtable. In case it already contains keys.

		notifications_list.put(notifications[0],new String[] {"Play Sounds","Vibrate","Show Pop-up"});
		notifications_list.put(notifications[1],new String[] {"Play Sounds","Vibrate","Show Pop-up"});
		notifications_list.put(notifications[2],new String[] {"Play Sounds","Vibrate","Incoming Chat"});
	
		Long t123 = new Long(System.currentTimeMillis());
		currentTime = t123;
//		reset = false;
		
		try
		{
            etest = ComplexReportFactory.getTest("Login - Android App");
            ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
            
            driver = getAndroidDriver();
			
			if(reset)
			{
				try
				{
					login(emailId,pswd);
					result.put("MA1",true);
					
					ComplexReportFactory.closeTest(etest);
				}
				catch(Exception e)
				{
					TakeScreenshot.mobileScreenshot(driver,etest,"MobileAutomation","Login","Error",e);
					result.put("MA1",false);
					ComplexReportFactory.closeReport();
					return result;
				}
			}
			
            etest = ComplexReportFactory.getTest(Property.getRealValue("MA2"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA2", MobileUseCases.checkRings(driver,5));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA3"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA3", MobileUseCases.checkTabIcon(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA4"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA4", MobileUseCases.checkUserName(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA5"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA5", MobileUseCases.checkAllTab(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA6"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA6", MobileUseCases.checkListView(driver,true,"Cold Visitors"));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA7"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA7", MobileUseCases.checkListView(driver,false,"Just in"));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA8"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA8", MobileUseCases.checkListView(driver,false,"Spent more than 1 Minute "));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA9"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA9", MobileUseCases.checkListView(driver,false,"Spent more than 90 Seconds "));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA10"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA10", MobileUseCases.checkListView(driver,false,"Long standing"));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA11"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA11", MobileUseCases.checkListView(driver,null,"Oops no visitors found!!!"));
			
			ComplexReportFactory.closeTest(etest);
		
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA12"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA12", MobileUseCases.checkOngoingEmpty(driver));
			
			ComplexReportFactory.closeTest(etest);
			
            etest = ComplexReportFactory.getTest(Property.getRealValue("MA13"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA13", MobileUseCases.checkAcceptChat(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA14"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA14", MobileUseCases.checkChatInOngoing(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA15"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA15", MobileUseCases.endChat(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA16"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA16", MobileUseCases.checkInChatHistory(driver));
			
			ComplexReportFactory.closeTest(etest);
			
            etest = ComplexReportFactory.getTest(Property.getRealValue("MA17"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA17", MobileUseCases.checkInMissedChat(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA18"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA18",MobileUseCases.checkNameInSettings(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA19"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA19",MobileUseCases.checkUserDetailsInSettings(driver));
			
			ComplexReportFactory.closeTest(etest);
			
            etest = ComplexReportFactory.getTest(Property.getRealValue("MA20"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA20",MobileUseCases.checkNotifications(driver,0));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA21"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA21",MobileUseCases.checkNotifications(driver,1));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA22"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA22",MobileUseCases.checkNotifications(driver,2));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA23"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA23",MobileUseCases.checkStatusList(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA24"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA24",MobileUseCases.checkChangeStatus(driver,"Busy"));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA25"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA25",MobileUseCases.checkChangeStatus(driver,"Available"));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA26"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA26",MobileUseCases.checkChangeTheme(driver));
			
			ComplexReportFactory.closeTest(etest);
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("MA27"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA27",MobileUseCases.checkAboutUs(driver));
			
			ComplexReportFactory.closeTest(etest);
			
            etest = ComplexReportFactory.getTest(Property.getRealValue("MA28"));
			ComplexReportFactory.setValues(etest,"Automation","Mobile Automation");
			
			result.put("MA28",MobileUseCases.checkLogout(driver));
			
			ComplexReportFactory.closeTest(etest);
            
            driver.quit();
        }
		catch(Exception e)
		{
            result.put("MA1",false);
			e.printStackTrace();
            etest.log(Status.FAIL,"Driver initializing failed");
            ComplexReportFactory.closeTest(etest);
		}
		
		return result;
	}
	
	public static void login(String usremail, String usrpswd) throws Exception
	{
		String login = Property.getRealValue("login");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(login)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(login)));
		
		driver.findElement(By.id(login)).click();
		
		etest.log(Status.INFO,"Login clicked");
		
        String email = Property.getRealValue("email_"+device);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(email)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(email)));
		
		driver.findElement(By.xpath(email)).click();
		
		etest.log(Status.INFO,"Email clicked");
        
		email = Property.getRealValue("emailtextarea_"+device);
		
		driver.findElement(By.xpath(email)).sendKeys(usremail);
		
		etest.log(Status.INFO,"Email sent");
        
		String password = Property.getRealValue("password_"+device);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(password)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(password)));
		
		driver.findElement(By.xpath(password)).click();
		
		etest.log(Status.INFO,"Password clicked");
        
        try
        {
            password = Property.getRealValue("passwordtextarea1_"+device);
            
            driver.findElement(By.xpath(password)).sendKeys(usrpswd);
            
            etest.log(Status.INFO,"Password sent");
        }
        catch(NoSuchElementException e)
        {
            password = Property.getRealValue("passwordtextarea2_"+device);
            
            driver.findElement(By.xpath(password)).sendKeys(usrpswd);
            
            etest.log(Status.INFO,"Password sent");
        }
        
		String zoho = Property.getRealValue("zoho_"+device);
				
		driver.findElement(By.xpath(zoho)).click();
		
		etest.log(Status.INFO,"Zoho clicked");
        
		String signup = Property.getRealValue("signup_"+device);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(signup)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(signup)));
		
		driver.findElement(By.xpath(signup)).click();
		
		etest.log(Status.INFO,"Signup clicked");
        
		MobileUseCases.checkRings(driver, 1);
	}
	
	public static AppiumDriver getAndroidDriver() throws Exception
	{
		DesiredCapabilities capability = new DesiredCapabilities();
		if(device.equals("emulator"))
		{
			capability.setCapability(MobileCapabilityType.DEVICE_NAME, "Android emulator");
			capability.setCapability("avd", "TestDevice1");
		}
		else
		{
			capability.setCapability(MobileCapabilityType.DEVICE_NAME, "Samsung Galaxy S7 edge");
			capability.setCapability("platformVersion", "7.0");
		}
//		capability.setCapability(MobileCapabilityType.APP_PACKAGE, "com.zoho.salesiq");
		capability.setCapability("noReset", !reset);
        
        String appLocation = ConfManager.getRealValue("android_app");
        
        appLocation = appLocation.replace("$SETUP","local");
        
		capability.setCapability("app",appLocation);
		
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capability);
		
		return driver;
	}

	*/
}
