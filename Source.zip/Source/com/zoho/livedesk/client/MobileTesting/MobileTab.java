//$Id$
package com.zoho.livedesk.client.MobileTesting;

import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;
import com.aventstack.extentreports.Status;

public class MobileTab {

	/*

	public static void clickOnlineTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToTop(driver);
		
		MobileFunctions.getTab(driver, "Online").click();
		
		MobileUtil.etest.log(Status.INFO, "Online tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Visitors Online"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Visitors Online--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Online is opened");
	}
	
	public static void clickVisitorHistoryTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToTop(driver);
		
		MobileFunctions.getTab(driver, "History").click();
		
		MobileUtil.etest.log(Status.INFO, "Visitor history tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Visitor History"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Visitor History--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Visitor history is opened");
	}
	
	public static void clickOngoingTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToTop(driver);
		
		MobileFunctions.getTab(driver, "Ongoing").click();
		
		MobileUtil.etest.log(Status.INFO, "Ongoing tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Ongoing Chats"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Ongoing Chats--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Ongoing is opened");
	}
	
	public static void clickMissedTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToTop(driver);
		
		MobileFunctions.getTab(driver, "Missed").click();
		
		MobileUtil.etest.log(Status.INFO, "Missed tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Missed Chats"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Missed Chats--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Missed Chat is opened");
	}
	
	public static void clickChatHistoryTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToBottom(driver);
		
		MobileFunctions.getTab(driver, "History").click();
		
		MobileUtil.etest.log(Status.INFO, "Chat History tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Chat History"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Chat History--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Chat  History is opened");
	}
	
	public static void clickUserChatsTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToBottom(driver);
		
		MobileFunctions.getTab(driver, "User Chats").click();
		
		MobileUtil.etest.log(Status.INFO, "User Chats tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("User Chats"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:User Chats--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "User Chats is opened");
	}
	
	public static void clickMessageBoardTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToBottom(driver);
		
		MobileFunctions.getTab(driver, "Message Board").click();
		
		MobileUtil.etest.log(Status.INFO, "Message Board tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Message Board"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Message Board--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Message Board is opened");
	}
	
	public static void clickSettingsTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToBottom(driver);
		
		MobileFunctions.getTab(driver, "Settings").click();
		
		MobileUtil.etest.log(Status.INFO, "Settings tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Settings"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Settings--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Settings is opened");
	}
	
	public static void clickAboutUsTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToBottom(driver);
		
		MobileFunctions.getTab(driver, "About us").click();
		
		MobileUtil.etest.log(Status.INFO, "About us tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("About Us"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:About us--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "About Us is opened");
	}
	
	public static void clickFeedbackTab(AppiumDriver driver) throws Exception
	{
		MobileFunctions.clickTabIcon(driver);
		
		MobileFunctions.slideToBottom(driver);
		
		MobileFunctions.getTab(driver, "Feedback").click();
		
		MobileUtil.etest.log(Status.INFO, "Feedback tab is clicked");
		
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		try
		{
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.xpath("//android.widget.TextView")).getText().equals("Feedback"))
                    {
                        return true;
                    }
                    return false;
                }
            });
			
		}
		catch(Exception excep)
		{
			MobileUtil.etest.log(Status.FAIL,"Expected:Feedback--Actual:"+driver.findElement(By.xpath("//android.widget.TextView")).getText());
			throw excep;
		}
		
		MobileUtil.etest.log(Status.INFO, "Feedback is opened");
	}

	*/
}
