//$Id$
package com.zoho.livedesk.client.MobileTesting;

import java.util.List;

import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.client.TakeScreenshot;

public class MobileUseCases {

	/*
	
	static Long t = null;
	
	public static boolean checkRings(AppiumDriver driver, int count)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			String rings = Property.getRealValue("rings");
			
			for(int i = 1; i<= count; i++)
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(rings.replace("$RINGS", ""+i))));
				MobileUtil.etest.log(Status.INFO,"Ring "+i+" is present");
			}
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckRings", "Error", e);
			return false;
		}
	}
	
	public static boolean checkTabIcon(AppiumDriver driver)
	{
		try
		{
			MobileFunctions.clickTabIcon(driver);
			
			MobileFunctions.clickListView(driver);
			
			checkRings(driver, 1);
			
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckTabIcon", "Error", e);
			return false;
		}
	}
	
	public static boolean checkAllTab(AppiumDriver driver)
	{
		try
		{
			MobileTab.clickOnlineTab(driver);
			
			MobileTab.clickVisitorHistoryTab(driver);
			
			MobileTab.clickFeedbackTab(driver);
			
			MobileTab.clickOngoingTab(driver);
			
			MobileTab.clickAboutUsTab(driver);
			
			MobileTab.clickSettingsTab(driver);
			
			MobileTab.clickChatHistoryTab(driver);
			
			MobileTab.clickMessageBoardTab(driver);
			
			MobileTab.clickMissedTab(driver);
			
			MobileTab.clickUserChatsTab(driver);
			
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckAllTab", "Error", e);
			return false;
		}
	}
	
	public static boolean checkUserName(AppiumDriver driver) 
	{
		try
		{
			MobileFunctions.clickTabIcon(driver);
			
			String userName = MobileFunctions.getUserName(driver);
			
			if(userName.equals(MobileUtil.user))
			{
				MobileUtil.etest.log(Status.INFO, "Username is checked");
				MobileFunctions.clickListView(driver);
				return true;
			}
			
			MobileUtil.etest.log(Status.FAIL,"Expected:"+MobileUtil.user+"--Actual:"+userName+"--");
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "Username", "Mismatch");
			MobileFunctions.clickListView(driver);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "Username", "Error", e);
			return false;
		}
	}
	
	public static boolean checkListView(AppiumDriver driver,Boolean initiate, final String content) 
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			String id = "visitorsonline_list_header";
			
			if(initiate == null)
			{
				if(MobileUtil.visDriver == null)
				{
					MobileUtil.etest.log(Status.FAIL,"Visitor driver is not initialized");
					return false;
				}
				
				MobileFunctions.closeVisitorDriver();
				
				Thread.sleep(20000);
				driver.findElement(By.id(Property.getRealValue("page")));
				Thread.sleep(20000);
				driver.findElement(By.id(Property.getRealValue("page")));
				
				for(int i = 1; i<=60;i++)
				{
					Long t2 = System.currentTimeMillis();
					if(t2 - MobileUtil.currentTime >= 60000)
					{
						break;
					}
					
					Thread.sleep(1000);
				}
				
				id = "visitorsonline_empty_header";
			}
			else if(initiate)
			{
				MobileTab.clickOnlineTab(driver);
				
				MobileFunctions.clickListView(driver);
				
				MobileUtil.visDriver = Functions.setUp();
				
				try
				{
					VisitorWindow.createPage(MobileUtil.visDriver, MobileUtil.embedcode);
					MobileUtil.etest.log(Status.INFO,"Visitor driver is opened");
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "ListView", "Error", e);
					MobileFunctions.closeVisitorDriver();
					return false;
				}
			}
			else if(MobileUtil.visDriver == null)
			{
				MobileUtil.etest.log(Status.FAIL,"Visitor driver is not initialized");
				return false;
			}
			else
			{
				for(int i = 1; i<=60;i++)
				{
					Long t2 = System.currentTimeMillis();
					if(t2 - MobileUtil.currentTime >= 30000)
					{
						break;
					}
					
					Thread.sleep(1000);
				}
			}
			
			final String header = Property.getRealValue(id);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(header)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(header)));
			
			wait = CommonUtil.waitreturner(driver, 10, 250);
			
			try
			{
				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(driver.findElement(By.id(header)).getText().equals(content))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });
			}
			catch(Exception e)
			{
				MobileUtil.etest.log(Status.FAIL,content+" is  not present.Actual:"+driver.findElement(By.id(header)).getText()+"--");
				throw e;
			}
			
			
			MobileUtil.etest.log(Status.INFO,content+" is present");
			MobileUtil.currentTime = System.currentTimeMillis();
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "ListView", "Error", e);
			MobileUtil.currentTime = System.currentTimeMillis();
			return false;
		}
	}
	
	public static boolean checkOngoingEmpty(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickOngoingTab(driver);
			
			By e = By.id(Property.getRealValue("ongoing_empty_context"));
			wait.until(ExpectedConditions.presenceOfElementLocated(e));
			wait.until(ExpectedConditions.visibilityOfElementLocated(e));
			
			String content = driver.findElement(e).getText();
			
//			String expected = "Currently, you’re not connected with any website visitor.";
//			
//			if(content.equals(expected))
//			{
//				MobileUtil.etest.log(Status.INFO,"Ongoing chats empty content is checked");
//				return true;
//			}
//			
//			MobileUtil.etest.log(Status.FAIL,"Expected:"+expected+"--Actual:"+content+"--");
//			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckOngoing", "MismatchContent");
            
            String expected1 = "Currently, you";
            String expected2 = "re not connected with any website visitor.";
            
            if(content.contains(expected1) && content.contains(expected2))
            {
                MobileUtil.etest.log(Status.INFO,"Ongoing chats empty content is checked");
                return true;
            }
            
            MobileUtil.etest.log(Status.FAIL,"Expected:"+expected1+"--"+expected2+"--Actual:"+content+"--");
            TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckOngoing", "MismatchContent");
            
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckOngoing", "Error", e);
			return false;
		}
	}
	
	public static boolean checkAcceptChat(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			t = new Long(System.currentTimeMillis());
			
			MobileUtil.visDriver = Functions.setUp();
			
			try
			{
				VisitorWindow.createPage(MobileUtil.visDriver, MobileUtil.embedcode);
				VisitorWindow.initiateChatVisTheme(MobileUtil.visDriver, "V"+t, "email@"+t+".com", "12345", MobileUtil.dept, "Q"+t, MobileUtil.etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "CheckAccept", "Error", e);
				MobileFunctions.closeVisitorDriver();
				return false;
			}
			
			MobileFunctions.pickUp(driver, "A"+t);
			
			if(!MobileFunctions.checkMessage(driver, "Q"+t, 0))
			{
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckAccept", "Error");
				MobileFunctions.clickChatBackButton(driver);
				return false;
			}
			
			if(MobileFunctions.checkMessage(driver, "A"+t, 1))
			{
				MobileFunctions.clickChatBackButton(driver);
				return true;
			}
			else
			{
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckAccept", "Error");
				MobileFunctions.clickChatBackButton(driver);
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckAccept", "Error", e);
			return false;
		}
	}
	
	public static boolean checkChatInOngoing(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickOngoingTab(driver);
			
			String visname = MobileFunctions.getVisitorInList(driver).getText();
			
			if(visname.equals("V"+t))
			{
				MobileUtil.etest.log(Status.INFO,"Chat is present in Ongoing chats");
				return true;
			}
			
			MobileUtil.etest.log(Status.FAIL,"Chat V"+t+"is not present in Ongoing chats");
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckChatInOngoing", "Error");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckChatInOngoing", "Error", e);
			return false;
		}
	}
	
	public static boolean endChat(AppiumDriver driver) throws Exception
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickOngoingTab(driver);
			
			WebElement e = MobileFunctions.getVisitorInList(driver);
			
			e.click();
			
			if(!MobileFunctions.checkMessage(driver, "A"+t, 1))
			{
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "EndChat", "Error");
				MobileFunctions.clickChatBackButton(driver);
				return false;
			}
			
			MobileFunctions.endChat(driver);
			
			String info = Property.getRealValue("info");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(info)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(info)));
			
			String inf = driver.findElement(By.xpath(info)).getText();
			
			String actual = Property.getRealValue("endchat_timer_content");
			for(int i = 30; i>=1; --i)
			{
				String expected = Property.getRealValue("endchat_timer_content").replace("$TIMER", ""+i);
				
				if(inf.equals(expected));
				{
					actual = expected;
					break;
				}
			}
			
			if(actual.equals(Property.getRealValue("endchat_timer_content")))
			{
				MobileUtil.etest.log(Status.FAIL,actual+" is not present");
				TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "EndChat", "Error");
			}
			else
			{
				MobileUtil.etest.log(Status.INFO, inf+" is present");
			}
			
			Thread.sleep(3000);
			
			String textarea = Property.getRealValue("textarea");

			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(textarea)));
			
			Thread.sleep(2000);
			
			inf = driver.findElement(By.xpath(info)).getText();
			
			if(!inf.equals(Property.getRealValue("endchat_content").replace("$NAME", MobileUtil.user)))
			{
				MobileUtil.etest.log(Status.FAIL,inf+" is present.Expected:"+Property.getRealValue("endchat_content").replace("$NAME", MobileUtil.user)+"--");
				TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "EndChat", "Error");
			}
			else
			{
				MobileUtil.etest.log(Status.INFO, inf+" is present");
			}
			
			try
			{
				VisitorWindow.checkChatEndedInTheme(MobileUtil.visDriver);
				MobileUtil.etest.log(Status.INFO, "Chat is ended(in visitor side)");
				MobileFunctions.closeVisitorDriver();
				MobileFunctions.clickBackButton(driver);
				return true;
			}
			catch(Exception ee)
			{
				TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "EndChat", "Error",ee);
				MobileFunctions.closeVisitorDriver();
				MobileFunctions.clickBackButton(driver);
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "EndChat", "Error", e);
			MobileFunctions.closeVisitorDriver();
			return false;
		}
	}
	
	public static boolean checkInChatHistory(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickChatHistoryTab(driver);
			
			String visname = MobileFunctions.getVisitorInList(driver).getText();
			
			if(visname.equals("V"+t))
			{
				MobileUtil.etest.log(Status.INFO,"Chat is present in Chat History");
				return true;
			}
			
			MobileUtil.etest.log(Status.FAIL,"Chat V"+t+"is not present in Chat History");
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckInChatHistory", "Error");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckInChatHistory", "Error", e);
			return false;
		}
	}
	
	public static boolean checkInMissedChat(AppiumDriver driver) throws Exception
	{
		try
		{
			t = new Long(System.currentTimeMillis());
			
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileUtil.visDriver = Functions.setUp();
			
			try
			{
				VisitorWindow.createPage(MobileUtil.visDriver, MobileUtil.embedcode);
				VisitorWindow.initiateChatVisTheme(MobileUtil.visDriver, "V"+t, "email@"+t+".com", "12345", MobileUtil.dept, "Q"+t, MobileUtil.etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "CheckInMissedChat", "Error", e);
				MobileFunctions.closeVisitorDriver();
				return false;
			}
			
			MobileFunctions.missChat(driver);
			
			MobileTab.clickMissedTab(driver);
			
			String visname = MobileFunctions.getVisitorInList(driver).getText();
			
			if(visname.equals("V"+t))
			{
				MobileUtil.etest.log(Status.INFO,"Chat is present in Missed Chat");
				MobileFunctions.closeVisitorDriver();
				return true;
			}
			
			MobileUtil.etest.log(Status.FAIL,"Chat V"+t+"is not present in Missed Chat");
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckInMissedChat", "Error");
			MobileFunctions.closeVisitorDriver();
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckInMissedChat", "Error", e);
			MobileFunctions.closeVisitorDriver();
			return false;
		}
	}
	
	public static boolean checkNameInSettings(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickSettingsTab(driver);
			
			String usr = Property.getRealValue("settings_username");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(usr)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(usr)));
				
			String username = driver.findElement(By.id(usr)).getText();
					
			String status = MobileFunctions.getStatusFromSettings(driver, false);
			
			if(username.equals(MobileUtil.user) && status.equals("Available"))
			{
				MobileUtil.etest.log(Status.INFO, MobileUtil.user+", Available is present");
				return true;
			}
			
			MobileUtil.etest.log(Status.FAIL, "Expected:"+MobileUtil.user+"--Available--Actual:"+username+"--"+status+"--");
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckNameInSettings", "Error");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckNameInSettings", "Error", e);
			return false;
		}
	}
	
	public static boolean checkUserDetailsInSettings(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickSettingsTab(driver);
			
			String usr = Property.getRealValue("settings_username");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(usr)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(usr)));
				
			driver.findElement(By.id(usr)).click();
			
			String headers = Property.getRealValue("settings_header");
			String value = Property.getRealValue("settings_value");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(headers)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(headers)));
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(value)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(value)));
			
			List<WebElement> lhs = driver.findElements(By.id(headers));
			List<WebElement> rhs = driver.findElements(By.id(value));
			
			String lhs_expected[] = {"Your Role","Departments","Email"};
			String rhs_expected[] = {"Administrator",MobileUtil.depts,"rajkumar.natarajan+1@zohocorp.com"};
			
			for(int i = 0; i<= 2; i++)
			{
				String lhs_actual = lhs.get(i).getText();
				String rhs_actual = rhs.get(i).getText();
				
				if(lhs_actual.equals(lhs_expected[i]) && rhs_actual.equals(rhs_expected[i]))
				{
					MobileUtil.etest.log(Status.INFO, lhs_actual+", "+rhs_actual+" is present");
					continue;
				}
				
				MobileUtil.etest.log(Status.FAIL, "Expected:"+lhs_expected[i]+"--"+rhs_expected[i]+"--Actual:"+lhs_actual+"--"+rhs_actual+"--");
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckUserDetailsInSettings", "Error");
				MobileFunctions.clickBack(driver,"Settings");
				return false;
			}
 				
			MobileFunctions.clickBack(driver,"Settings");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckUserDetailsInSettings", "Error", e);
			return false;
		}
	}
	
	public static boolean checkNotifications(AppiumDriver driver, int i)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickSettingsTab(driver);
			
			MobileFunctions.clickOptionsInSettings(driver, "Notifications");
			
			MobileFunctions.waitTillHeaderLoaded(driver, "Chat Notification");
			
			MobileFunctions.clickOptionsInSettings(driver, MobileUtil.notifications[i]);
			
			MobileFunctions.waitTillHeaderLoaded(driver, MobileUtil.notifications[i]);
			
			List<WebElement> list = MobileFunctions.getListInSettings(driver);
			
			boolean result = true;
			
			int count = 0;
			
			for(WebElement e : list)
			{
				String actual = e.getText();
				
				String expected = MobileUtil.notifications_list.get(MobileUtil.notifications[i])[count++];
				
				if(!actual.equals(expected))
				{
					MobileUtil.etest.log(Status.INFO,"Expected:"+expected+"--Actual:"+actual+"--");
					TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckNotifications", "Error");
					result = false;
				}
				else
				{
					MobileUtil.etest.log(Status.INFO,actual+" is present");
				}
			}
			
			MobileFunctions.clickBack(driver,"Chat Notification");
			
			MobileFunctions.clickBack(driver,"Settings");
			
			return result;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckNotifications", "Error", e);
			return false;
		}
	}
	
	public static boolean checkStatusList(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickSettingsTab(driver);
			
			MobileFunctions.clickOptionsInSettings(driver, "Status");
			
			MobileFunctions.waitTillHeaderLoaded(driver, "Change Status");
			
			WebElement avaialble = MobileFunctions.getStatusList(driver, "Available");
			WebElement busy = MobileFunctions.getStatusList(driver, "Busy");
			
			if(avaialble == null || busy == null)
			{
				MobileUtil.etest.log(Status.FAIL,"Available or Busy is not present");
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckStatusList", "Error");
				MobileFunctions.clickBack(driver, "Settings");
				return false;
			}
			MobileUtil.etest.log(Status.INFO,"Available and Busy are present");
			
			boolean result = true;
			
			try
			{
				MobileFunctions.checkCurrentStatus(driver, "Available");
			}
			catch(Exception e)
			{
				result = false;
			}
			
			MobileFunctions.clickBack(driver, "Settings");
			return result;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckStatusList", "Error", e);
			return false;
		}
	}
	
	public static boolean checkChangeStatus(AppiumDriver driver, String status) throws Exception
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			boolean sta = status.equals("Available")?true:false;
			
			MobileTab.clickSettingsTab(driver);
			
			MobileFunctions.clickOptionsInSettings(driver, "Status");
			
			MobileFunctions.waitTillHeaderLoaded(driver, "Change Status");
			
			WebElement e = MobileFunctions.getStatusList(driver, status);
			
			e.click();
			
			MobileUtil.etest.log(Status.INFO,status+" is clicked");
			
			MobileFunctions.checkCurrentStatus(driver, status);
			
            Thread.sleep(4000);
            
            MobileFunctions.clickBack(driver, "Settings");
			
			String current = MobileFunctions.getStatusFromSettings(driver, false);
			
			if(!current.equals(status))
			{
				MobileUtil.etest.log(Status.FAIL,"Status is not changed to "+status);
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckChangeStatus", "Error");
				return false;
			}
			
			MobileUtil.etest.log(Status.INFO,"Status is changed to "+status);
			
			Thread.sleep(6000);
			
			MobileUtil.visDriver = Functions.setUp();
			
			try
			{
				VisitorWindow.createPage(MobileUtil.visDriver, MobileUtil.embedcode);
				MobileUtil.etest.log(Status.INFO,"Visitor driver is opened");
				
				if(VisitorWindow.checkChatWidgetOffline(MobileUtil.visDriver) != sta)
				{
					MobileUtil.etest.log(Status.INFO,"Status changed is reflected back in visitor chat widget");
					MobileFunctions.closeVisitorDriver();
					return true;
				}
				else
				{
					MobileUtil.etest.log(Status.FAIL,"Status changed is not reflected back in visitor chat widget");
					TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "CheckChangeStatus", "Error");
					MobileFunctions.closeVisitorDriver();
					return false;
				}
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(MobileUtil.visDriver, MobileUtil.etest, "MobileAutomation", "CheckChangeStatus", "Error", exp);
				MobileFunctions.closeVisitorDriver();
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckChangeStatus", "Error", e);
			MobileFunctions.closeVisitorDriver();
			return false;
		}
	}
	
	public static boolean checkChangeTheme(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickSettingsTab(driver);
			
			MobileFunctions.clickOptionsInSettings(driver, "Change Theme");
			
			MobileFunctions.waitTillHeaderLoaded(driver, "Select Theme");
			
			String expected = "";
			
			String apply = driver.findElement(By.id(Property.getRealValue("apply_button"))).getText();
			expected = "APPLY";
			
			if(!apply.equals(expected))
			{
				MobileUtil.etest.log(Status.FAIL,expected+" is not present");
				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckChangeTheme", "Error");
				MobileFunctions.clickBack(driver, "Settings");
				return false;
			}
			
			MobileUtil.etest.log(Status.INFO,expected+" is present");
//			MobileFunctions.swipeTheme(driver, true);
//			
//			apply = driver.findElement(By.id(Property.getRealValue("apply_button"))).getText();
//			expected = "Apply";
//			
//			if(!apply.equals(expected))
//			{
//				MobileUtil.etest.log(Status.FAIL,expected+" is not present");
//				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "CheckChangeTheme", "Error");
//				MobileFunctions.clickBack(driver, "Settings");
//				return false;
//			}
//			
//			MobileUtil.etest.log(Status.INFO,expected+" is present");
//			MobileFunctions.swipeTheme(driver, false);
//			
//			apply = driver.findElement(By.id(Property.getRealValue("apply_button"))).getText();
//			expected = "Current Theme";
//			
//			if(!apply.equals(expected))
//			{
//				MobileUtil.etest.log(Status.FAIL,expected+" is not present");
//				TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "CheckChangeTheme", "Error");
//				MobileFunctions.clickBack(driver, "Settings");
//				return false;
//			}
//			
//			MobileUtil.etest.log(Status.INFO,expected+" is present");
			MobileFunctions.clickBack(driver, "Settings");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckChangeTheme", "Error", e);
			return false;
		}
	}
	
	public static boolean checkAboutUs(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickAboutUsTab(driver);
			
			String xpath = Property.getRealValue("aboutus_content_id");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(xpath)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(xpath)));
			
			String actual1 = driver.findElement(By.id(xpath)).getText();
			
			String expected1 = Property.getRealValue("aboutus_content");
			
			String version = Property.getRealValue("aboutus_version_id");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(version)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(version)));
			
			String actual2 = driver.findElement(By.id(version)).getText();
			
			if(actual1.equals(expected1))
			{
				MobileUtil.etest.log(Status.INFO,"About us content is checked");
				MobileUtil.etest.log(Status.INFO,"Version - "+actual2);
				return true;
			}
			
			
			
			MobileUtil.etest.log(Status.FAIL,"Actual:"+actual1+"--Expected:"+expected1+"--");
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckAboutUs", "Error");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckAboutUs", "Error", e);
			return false;
		}
	}
	
	public static boolean checkLogout(AppiumDriver driver)
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
			
			MobileTab.clickSettingsTab(driver);
			
			MobileFunctions.clickOptionsInSettings(driver, "Sign Out");
			
			String signout = Property.getRealValue("logout_id");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(signout)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(signout)));
			
			driver.findElement(By.id(signout)).click();
			
			MobileUtil.etest.log(Status.INFO,"Continue Signout is clicked");
			
			String login = Property.getRealValue("login");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(login)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(login)));
			
			MobileUtil.etest.log(Status.INFO,"Login is found");
			
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.mobileScreenshot(driver, MobileUtil.etest, "MobileAutomation", "CheckLogout", "Error", e);
			return false;
		}
	}

	*/	
}
