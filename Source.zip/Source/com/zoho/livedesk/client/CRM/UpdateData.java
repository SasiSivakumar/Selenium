//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class UpdateData
{
    public static boolean updateEmailPopUp(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","UpdateData","Error",e);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(2000);
            
            CommonFunctions.sendMessage(driver,"rajkumar.natarajan+11207@zohocorp.com");

            WebElement updtelmt = CommonUtil.elementfinder(driver,ChatWindow.getLastMessageInUserWindow(driver,"rajkumar.natarajan+11207@zohocorp.com"),"tagname","a");
            
            System.out.println("updateEmailPopUp<>"+updtelmt.getText()+"<>");
            
            Thread.sleep(1000);
            
            CommonFunctions.mouseOver(driver,updtelmt);

            Thread.sleep(500);

            String updatetxt = driver.findElement(By.id("tpcrminfo")).findElement(By.id("siqupdate")).getText();

            if(updatetxt.contains(ResourceManager.getRealValue("crmemailupdate")))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctions.endChat(driver);
                return true;
            }
            etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("crmemailupdate")+"--Actual:"+updatetxt+"--");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","UpdateData","Error");
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","UpdateData","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","UpdateData","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }

    public static boolean updateEmailChat(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","UpdateData","Error",e);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(2000);
            
            CommonFunctions.sendMessage(driver,"rajkumar.natarajan+11207@zohocorp.com");

            WebElement updtelmt = CommonUtil.elementfinder(driver,ChatWindow.getLastMessageInUserWindow(driver,"rajkumar.natarajan+11207@zohocorp.com"),"tagname","a");
            
            System.out.println("updateEmailPopUp<>"+updtelmt.getText()+"<>");
            
            Thread.sleep(1000);
            
            CommonFunctions.mouseOver(driver,updtelmt);

            Thread.sleep(500);

            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","tpcrminfo"),"id","siqupdate").click();

            Thread.sleep(500);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

            CommonUtil.elfinder(driver,"id","okbtn").click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Visitor data updated successfully","updatevistdata.do",etest);

            Thread.sleep(1000);

            //String newEmail = driver.findElement(By.id("visdatapar")).findElement(By.id("visitordata")).findElement(By.id("cvemail")).getText();
            String newEmail = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visdatapar"),"id","visitordata"),"id","cvemail").getText();

            if(newEmail.equals("rajkumar.natarajan+11207@zohocorp.com"))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctions.endChat(driver);
                return true;
            }
            etest.log(Status.FAIL,"Expected:rajkumar.natarajan+11207@zohocorp.com--Actual:"+newEmail+"--");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","UpdateData","Error");
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","UpdateEmail","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","UpdateEmail","Error",e);
            CommonFunctions.endChat(driver);
            return false;
        }
    }
}
