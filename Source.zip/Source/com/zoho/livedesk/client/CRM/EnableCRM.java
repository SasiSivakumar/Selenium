//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class EnableCRM
{
    //Disable crm and check for wms bar visitors online tab
    public static boolean crmenable(WebDriver driver,WebDriver driver2,WebDriver driver3,WebDriver driver4,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            IntegrationSettings.enableCRMInteg(driver,etest);
            IntegrationSettings.chooseType(driver, "vistrackcrmdiv", "NOTIFYCRM", 0, "chk",etest);
            
            IntegrationSettings.enableCRMInteg(driver2,etest);
            IntegrationSettings.chooseType(driver2, "vistrackcrmdiv", "NOTIFYCRM", 0, "chk",etest);

            IntegrationSettings.enableCRMInteg(driver3,etest);
            IntegrationSettings.chooseType(driver3, "vistrackcrmdiv", "NOTIFYCRM", 0, "chk",etest);

            IntegrationSettings.enableCRMInteg(driver4,etest);
            IntegrationSettings.chooseType(driver4, "vistrackcrmdiv", "NOTIFYCRM", 0, "chk",etest);
            
            //Thread.sleep(1000);
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);
            
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            
            crmwindow.navigate().refresh();
            
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            try
            {
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("tabLayer")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("show")));
                
                if(!CommonFunctions.wmsbar(crmwindow,true))
                {
                    TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","EnableCRM","NotEnabledInCRMWindow");
                    CommonFunctions.endSessionAccounts(crmwindow);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","EnableCRM","CRMEnableError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            System.out.println("Initiating chat - Enable CRM");
            
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","EnableCRM","CRMEnableError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            ChatWindow.acceptChat(driver,etest);
            
            Thread.sleep(1000);
            
            String continfo = CommonUtil.elfinder(driver,"id","contactinfodiv").getAttribute("style");
            String crminfo = CommonUtil.elfinder(driver,"id","crminfocontainer").getAttribute("style");
            String addpot = CommonUtil.elfinder(driver,"id","addpotentialdiv").getAttribute("style");
            String assopot = CommonUtil.elfinder(driver,"id","associatedpotentialdiv").getAttribute("style");
            String respot = CommonUtil.elfinder(driver,"id","recentpotentialdiv").getAttribute("style");
            
            System.out.println("Enable CRM : "+continfo+" >> "+crminfo+" >> "+addpot+" >> "+assopot+" >> "+respot);
            
            if(!(continfo.contains("none")&&crminfo.contains("none")&&addpot.contains("none")&&assopot.contains("none")&&respot.contains("none")))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return true;
            }
            
            etest.log(Status.FAIL,"Expected:not none for all--Actual:"+continfo+"--"+crminfo+"--"+addpot+"--"+assopot+"--"+respot+"--");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","EnableCRM","CRMEnableError");
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm enable in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","EnableCRM","CRMEnableError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm enable in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","EnableCRM","CRMEnableError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
}
