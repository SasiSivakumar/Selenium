//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class ConvertLead
{
    //convert lead to contact without potential
    public static boolean leadToContactNoPotential(WebDriver driver,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            final FluentWait failwait = CommonUtil.waitreturner(driver,5,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();

            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(1000);

            CommonFunctions.clickLead(driver);

            Thread.sleep(500);

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","lead_div");

            CommonUtil.elementfinder(driver,crmelmt,"id","companyname").sendKeys("AutomationComp");

            new Select(CommonUtil.elementfinder(driver,crmelmt,"xpath",".//select[@id='lstatus'][@class='crmseld']")).selectByVisibleText("Junk Lead");
            Thread.sleep(1000);

            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));

            Thread.sleep(1000);
            WebElement leaddata = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","convertlead_div"),"id","convertlead");

            leaddata.findElements(By.className("rg-button")).get(1).click();

            Thread.sleep(1000);
            Tab.waitForLoadingSuccessWithBanner(driver,"Lead converted successfully","invokeaction.do",etest);

            Thread.sleep(1000);

            Functions.refreshSiteAndWaitForRSID(driver);//------>>Works only when refreshed
            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        failwait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));
                        return false;
                    }
                    catch(Exception e)
                    {
                        return true;
                    }
                }
            });

            if(!(CommonUtil.elfinder(driver,"id","addpotentialdiv").getAttribute("style").contains("none")))
            {
                etest.log(Status.FAIL,"Potential div is displayed");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                System.out.println("Convert Error Contact without potential add potential missing");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            Thread.sleep(2000);

            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(4).findElement(By.className("crmld_infrht")).getText();

            System.out.println("<<<<"+contactname+">><<"+contactemail+">><<"+contactacname+">><<"+contactphone+">><<"+contacttype+">>>>");

            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactacname.equals("AutomationComp")&&contactphone.equals(vphone)&&contacttype.equals("Contact")))
            {
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--AutomationComp--"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"--"+contactacname+"--"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                System.out.println("Convert Error Contact without potential Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            try
            {
                crmwindow.navigate().refresh();
                CommonFunctions.crmClickContact(crmwindow);

                WebElement cntctelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmcontacts = cntctelmt.findElements(By.tagName("tr"));

                String contactid;

                for(WebElement crmcontact:crmcontacts)
                {
                    contactid = crmcontact.getAttribute("id");

                    if(!contactid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+contactid).getText().equals(vname))
                    {
                        String curcontact_phone = crmcontact.findElements(By.tagName("td")).get(4).getText();
                        String curcontact_email = crmcontact.findElements(By.tagName("td")).get(5).getText();
                        String curcontact_acname = crmcontact.findElements(By.tagName("td")).get(6).getText();;

                        if(curcontact_phone.equals(vphone)&&curcontact_email.equals(vemail)&&curcontact_acname.equals("AutomationComp"))
                        {
                            etest.log(Status.PASS,"Checked");
                            CommonFunctions.endChat(driver);
                            CommonFunctions.endSessionAccounts(crmwindow);
                            return true;
                        }
                        else
                        {
                            etest.log(Status.FAIL,"Expected:"+vphone+"--"+vemail+"--AutomationComp--Actual:"+curcontact_phone+"--"+curcontact_email+"--"+curcontact_acname+"--");
                            TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                        }
                        CommonFunctions.endChat(driver);
                        CommonFunctions.endSessionAccounts(crmwindow);
                        return false;
                    }
                }
                etest.log(Status.FAIL,vname+" is not present");
                TakeScreenshot.screenshot(crmwindow,etest,"CCRMIntegration","ConvLeadNoPot","ConvLeadNoPotError");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while converting lead to contact without potential in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while converting lead to contact without potential in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadNoPot","ConvLeadNoPotError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        CommonFunctions.endChat(driver);
        CommonFunctions.endSessionAccounts(crmwindow);
        return false;
    }

    //convert lead to contact with potential
    public static boolean leadToContactWithPotential(WebDriver driver,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            final FluentWait failwait = CommonUtil.waitreturner(driver,5,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();

            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(1000);

            CommonFunctions.clickLead(driver);

            Thread.sleep(500);

            WebElement crmelmt = CommonUtil.elfinder(driver,"id","lead_div");

            CommonUtil.elementfinder(driver,crmelmt,"id","companyname").sendKeys("AutomationComp");

            new Select(CommonUtil.elementfinder(driver,crmelmt,"xpath",".//select[@id='lstatus'][@class='crmseld']")).selectByVisibleText("Junk Lead");
            Thread.sleep(1000);

            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));

            Thread.sleep(2000);
            WebElement leaddata = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","convertlead_div"),"id","convertlead");

            CommonUtil.elementfinder(driver,leaddata,"id","potential").click();
            Thread.sleep(1000);

            WebElement potdata = CommonUtil.elementfinder(driver,leaddata,"id","portentialdiv");

            CommonUtil.elementfinder(driver,potdata,"id","potentialname").sendKeys(pname);
            new Select(CommonUtil.elementfinder(driver,potdata,"xpath",".//select[@id='potentialstage'][@class='crmseld']")).selectByVisibleText("Closed Won");
            CommonUtil.elementfinder(driver,potdata,"id","potentialamount").sendKeys(pamt);
            CommonUtil.elementfinder(driver,potdata,"id","potentialclosedate").click();

            Thread.sleep(1000);
            if(!((potdata.findElement(By.id("crmdatepickerdiv")).getAttribute("style")).contains("display: block;")))
            {
                etest.log(Status.FAIL,"Date picker is not visible");
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            WebElement caelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","potentialclosedatediv"),"tagname","table");
            WebElement calelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,caelmt,"tagname","table"),"classname","datepickerDays");

            String pdatedd = calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String pdatemmyy = caelmt.findElement(By.tagName("table")).findElement(By.className("datepickerMonth")).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String mmddyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"mmddyy");
            String ddmmyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"ddmmyy");

            calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).click();

            Thread.sleep(500);
            com.zoho.livedesk.util.common.CommonUtil.inViewPortSafe(driver,leaddata.findElements(By.className("rg-button")).get(1));
            leaddata.findElements(By.className("rg-button")).get(1).click();

            Thread.sleep(1000);
            Tab.waitForLoadingSuccessWithBanner(driver,"Lead converted successfully","invokeaction.do",etest);
            
            Thread.sleep(1000);

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        failwait.until(ExpectedConditions.presenceOfElementLocated(By.id("convertlead_div")));
                        return false;
                    }
                    catch(Exception e)
                    {
                        return true;
                    }
                }
            });

            if(!(CommonUtil.elfinder(driver,"id","addpotentialdiv").getAttribute("style").contains("none")))
            {
                etest.log(Status.FAIL,"Potential div is displayed");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError");
                System.out.println("Convert Error Contact add potential missing");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            Thread.sleep(2000);

            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));

            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(4).findElement(By.className("crmld_infrht")).getText();

            System.out.println("<<<<"+contactname+">><<"+contactemail+">><<"+contactacname+">><<"+contactphone+">><<"+contacttype+">>>>");

            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactacname.equals("AutomationComp")&&contactphone.equals(vphone)&&contacttype.equals("Contact")))
            {
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--AutomationComp--"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"--"+contactacname+"--"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            Thread.sleep(2000);

            WebElement chatpot = CommonUtil.elfinder(driver,"id","associatedpotentialdiv");
            List<WebElement> potelmts = chatpot.findElements(By.className("crmld_infomn"));

            String potname = potelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String potstage = potelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String potamt = potelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String potdate = potelmts.get(3).findElement(By.className("crmld_infrht")).getText();

            if(!(potname.equals(pname)&&potstage.equals("Closed Won")&&potamt.equals(pamt)&&potdate.equals(ddmmyy)))
            {
                etest.log(Status.FAIL,"Expected:"+pname+"--Closed Won--"+pamt+"--"+ddmmyy+"--Actual:"+potname+"--"+potstage+"--"+potamt+"--"+potdate+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            try
            {
                crmwindow.navigate().refresh();

                CommonFunctions.crmClickContact(crmwindow);

                WebElement cntctelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmcontacts = cntctelmt.findElements(By.tagName("tr"));

                String contactid;

                for(WebElement crmcontact:crmcontacts)
                {
                    contactid = crmcontact.getAttribute("id");

                    if(!contactid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+contactid).getText().equals(vname))
                    {
                        String curcontact_phone = crmcontact.findElements(By.tagName("td")).get(4).getText();
                        String curcontact_email = crmcontact.findElements(By.tagName("td")).get(5).getText();
                        String curcontact_acname = crmcontact.findElements(By.tagName("td")).get(6).getText();;

                        if(curcontact_phone.equals(vphone)&&curcontact_email.equals(vemail)&&curcontact_acname.equals("AutomationComp"))
                        {
                            crmwindow.navigate().refresh();

                            CommonFunctions.crmClickPotential(crmwindow);

                            WebElement ptelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                            List<WebElement> crmpots = ptelmt.findElements(By.tagName("tr"));

                            String potid;

                            for(WebElement crmpot:crmpots)
                            {
                                potid = crmpot.getAttribute("id");

                                if(!potid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+potid).getText().equals(pname))
                                {
                                    String curpot_amt = crmpot.findElements(By.tagName("td")).get(4).getText();
                                    String curpot_stage = crmpot.findElements(By.tagName("td")).get(5).getText();
                                    //String curpot_acname = crmpot.findElements(By.tagName("td")).get(7).getText();
                                    String curpot_date = crmpot.findElements(By.tagName("td")).get(6).getText();

                                    System.out.println("Lead Potential : "+curpot_amt+" >> "+curpot_stage+" >> "+curpot_date);

                                    if(curpot_stage.equals("Closed Won")&&curpot_date.equals(ddmmyy))//curpot_amt.equals("$"+pamt+".00")&&
                                    {
                                        etest.log(Status.PASS,"Checked");
                                        CommonFunctions.endChat(driver);
                                        CommonFunctions.endSessionAccounts(crmwindow);
                                        return true;
                                    }
                                    else
                                    {
                                        etest.log(Status.FAIL,"Expected:Closed Won--"+ddmmyy+"--Actual:"+curpot_stage+"--"+curpot_date+"--");
                                        TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError");
                                    }
                                    CommonFunctions.endChat(driver);
                                    CommonFunctions.endSessionAccounts(crmwindow);
                                    return false;
                                }
                            }
                            etest.log(Status.FAIL,pname+" is not present");
                            TakeScreenshot.screenshot(crmwindow,etest,"CCRMIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                            CommonFunctions.endChat(driver);
                            CommonFunctions.endSessionAccounts(crmwindow);
                            return false;
                        }
                        else
                        {
                            etest.log(Status.FAIL,"Expected:"+vphone+"--"+vemail+"--AutomationComp--Actual:"+curcontact_phone+"--"+curcontact_email+"--"+curcontact_acname+"--");
                            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError");
                        }
                        CommonFunctions.endChat(driver);
                        CommonFunctions.endSessionAccounts(crmwindow);
                        return false;
                    }
                }
                etest.log(Status.FAIL,vname+" is not present");
                TakeScreenshot.screenshot(crmwindow,etest,"CCRMIntegration","ConvLeadNoPot","ConvLeadNoPotError");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError",e);
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while converting crm lead to contact with potential in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while converting crm lead to contact with potential in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ConvLeadPot","ConvLeadPotError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
}
