//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class ZSCKey
{
    //ZSC key regenerate
    public static boolean ZSCregenerate(WebDriver driver,final WebDriver crmwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,200);

            CommonFunctions.clickCRMInteg(driver);

            CommonUtil.elfinder(driver,"xpath","//div[text()='Zoho CRM']").click();

            IntegrationSettings.enableCRMInteg(driver,etest);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("iscdetailsdiv")));

            String newkey;

            try
            {
                CommonWait.waitTillDisplayed(crmwindow,By.id("tab_Setup"));
                com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("tab_Setup")).click();

                CommonWait.waitTillDisplayed(crmwindow,By.cssSelector("a[href*='/api/']"));
                
                try
                {
                    com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.cssSelector("a[href*='/api/']")).click();
                }
                catch(Exception e)
                {
                    com.zoho.livedesk.util.common.CommonUtil.printStackTrace(e);
                }

                try
                {
                    if(!crmwindow.getCurrentUrl().contains("api"))
                    {
                        String current_url = crmwindow.getCurrentUrl();
                        String expected_url = current_url.replaceAll(current_url.substring(current_url.indexOf("/",current_url.indexOf("org"))), "/settings/api");
                        crmwindow.get(expected_url);
                    }
                }
                catch(Exception e)
                {
                    com.zoho.livedesk.util.common.CommonUtil.doNothing();
                }

                CommonWait.waitTillDisplayed(crmwindow,By.id("setupInnerLinks"),By.cssSelector("a[href*='zsc']"));
                com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("setupInnerLinks"),By.cssSelector("a[href*='zsc']")).click();

                CommonWait.waitTillDisplayed(crmwindow,By.id("showAPIKey"));

                String oldkey = com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("showAPIKey")).getText();

                com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("regenBtn")).click();

                CommonWait.waitTillDisplayed(crmwindow,By.cssSelector("input[onclick*='genAPIKey']"));
                com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.cssSelector("input[onclick*='genAPIKey']")).click();

                for(int i = 1; i <= 10;i++)
                {
                    newkey = com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("showAPIKey")).getText();

                    if(!newkey.equals("") && !newkey.equals(oldkey))
                    {
                        break;
                    }

                    Thread.sleep(1000);
                }

                newkey = com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("showAPIKey")).getText();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegrationCRMWindow","ZSCKey","ZSCKeyError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            if(changeZSCKey(driver,newkey,etest))
            {
                CommonFunctions.endSessionAccounts(crmwindow);
                return true;
            }
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking ZSC key regenerate in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ZSCKey","ZSCKeyError",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking ZSC key regenerate in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ZSCKey","ZSCKeyError",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }

    public static boolean changeZSCKey(WebDriver driver,String newkey,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickCRMInteg(driver);

            CommonUtil.elfinder(driver,"xpath","//div[text()='Zoho CRM']").click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("iscdetailsdiv")));

            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","emailideditlink"),"linktext","Change").click();

            Thread.sleep(500);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdesc")));

            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","cntdiv"),"id","zsckey").click();
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","cntdiv"),"id","zsckey").clear();
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","cntdiv"),"id","zsckey").sendKeys(newkey);

            CommonUtil.elfinder(driver,"id","okbtn").click();

            Thread.sleep(1000);
            Tab.waitForLoadingSuccessWithBanner(driver,"ZSC Key updated successfully","upzsckey.do",etest);

            String keypresent = driver.findElement(By.id("zsckeydiv")).getText();

            if((keypresent).equals(newkey))
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            etest.log(Status.FAIL,"Expected"+newkey+"--Actual:"+keypresent+"--");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ZSCKey","ZSCKeyError");
            Functions.refreshSiteAndWaitForRSID(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking ZSC key regenerate in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ZSCKey","ZSCKeyError",e);
            return false;
        }
    }
}
