//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class CRMLead
{
    public static boolean convLeadCRM(WebDriver driver,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);
            
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);
            IntegrationSettings.addNewVisitorTo(driver,0,etest);
            
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","CRMLeadConv","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                CommonFunctions.endChat(driver);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(2000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            
            try
            {
                wait.until(new Function<WebDriver, Boolean>() {
                   public Boolean apply(WebDriver driver) {
                       try
                       {
                           if((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true"))
                               return true;
                       }
                       catch (Exception e) {}
                       return false;
                   }
                });
            }
            catch(Exception e){}

            if(!((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                etest.log(Status.FAIL,"CRM div is not present");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRMLeadConv","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            Thread.sleep(1000);
            
            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            
            String leadname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leademail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            //String leadcomp = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String leadphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String leadtype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            
            if(!(leadname.equals(vname)&&leademail.equals(vemail)&&leadphone.equals(vphone)&&leadtype.equals("Lead")))//&&leadcomp.equals("AutomationComp")
            {
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--"+vphone+"--Lead--Actual:"+leadname+"--"+leademail+"--"+leadphone+"--"+leadtype+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRMLeadConv","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            CommonFunctions.endChat(driver);
            
            Thread.sleep(2000);
            try
            {
                crmwindow.navigate().refresh();
                
                CommonFunctions.crmClickLead(crmwindow);
                
                WebElement leadelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmleads = leadelmt.findElements(By.tagName("tr"));
                
                String leadid;

                boolean presence = false;
                
                for(WebElement crmlead:crmleads)
                {
                    leadid = crmlead.getAttribute("id");
                    
                    if(!leadid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+leadid).getText().equals(vname))
                    {
                        presence = true;
                        //String curlead_company = crmlead.findElements(By.tagName("td")).get(4).getText();
                        String curlead_phone = crmlead.findElements(By.tagName("td")).get(5).getText();
                        String curlead_email = crmlead.findElements(By.tagName("td")).get(6).getText();
                        
                        if(curlead_phone.equals(vphone)&&curlead_email.equals(vemail))//curlead_company.equals("AutomationComp")&&
                        {
                            com.zoho.livedesk.util.common.CommonUtil.inViewPortSafe(crmwindow,crmlead.findElement(By.linkText(vname)));
                            
                            crmlead.findElement(By.linkText(vname)).click();
                            
                            Thread.sleep(1000);
                            waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("leftPanel")));
                            
                            Thread.sleep(1000);
                            waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("fixedBtn")));
                            
                            CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","fixedBtn"),"name","Convert2").click();
                            
                            Thread.sleep(1000);
                            waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("save")));
                            
                            CommonUtil.elfinder(crmwindow,"id","save").click();
                            
                            waitcrm.until(new Function<WebDriver,Boolean>(){
                                public Boolean apply(WebDriver crmwindow)
                                {
                                    try
                                    {
                                        if(crmwindow.findElement(By.className("msgInfo")).getText().contains("The Lead")&&crmwindow.findElement(By.className("msgInfo")).getText().contains(ResourceManager.getRealValue("crmleadconv")))
                                        {
                                            return true;
                                        }
                                        return false;
                                    }
                                    catch(Exception e)
                                    {}
                                    return false;
                                }
                            });
                            
                        }
                        else
                        {
                            etest.log(Status.FAIL,"Expected:"+vphone+"--"+vemail+"--Actual:"+curlead_phone+"--"+curlead_email+"--");
                            TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","CRMLeadConv","Error");
                            CommonFunctions.endSessionAccounts(crmwindow);
                            return false;
                        }
                        break;
                    }
                }
                if(!presence)
                {
                    etest.log(Status.FAIL,vname+" is not present");
                    TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","CRMLeadConv","Error");
                    CommonFunctions.endSessionAccounts(crmwindow);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","CRMLeadConv","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                CommonFunctions.endChat(driver);
                return false;
            }

            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            
            CommonFunctions.clickChatHistory(driver,vname);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            
            try
            {
                wait.until(new Function<WebDriver, Boolean>() {
                   public Boolean apply(WebDriver driver) {
                       try
                       {
                           if((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true"))
                               return true;
                       }
                       catch (Exception e) {}
                       return false;
                   }
                });
            }
            catch(Exception e){}

            if(!((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                etest.log(Status.FAIL,"CRM div is not present");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRMLeadConv","Error");
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            Thread.sleep(1000);
            WebElement chatcont = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts1 = chatcont.findElements(By.className("crmld_infomn"));
            
            String contactname = chatelmts1.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts1.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts1.get(2).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts1.get(3).findElement(By.className("crmld_infrht")).getText();
            
            if(contactname.equals(vname)&&contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact"))//&&contactacname.equals(vacname)
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctions.endSessionAccounts(crmwindow);
                return true;
            }
            etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"--"+contactphone+"--"+contacttype+"--");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRMLeadConv","Error");
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRMLeadConv","Error",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            CommonFunctions.endChat(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRMLeadConv","Error",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            CommonFunctions.endChat(driver);
            return false;
        }
    }
}
