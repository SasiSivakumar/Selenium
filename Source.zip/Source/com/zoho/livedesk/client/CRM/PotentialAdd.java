//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class PotentialAdd
{
    //Add potential to added contact
    public static boolean addPotential(WebDriver driver,WebDriver crmwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();
            
            CommonFunctions.chatHistoryClick(driver);
            CommonFunctions.clickAddPotenChatHis(driver);
            
            WebElement potelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","addpotentialdiv"),"id","savepotentialfrm");
            
            CommonUtil.elementfinder(driver,potelmt,"id","potentialname").sendKeys(pname);
            new Select(CommonUtil.elementfinder(driver,potelmt,"xpath",".//select[@id='potentialstage'][@class='crmseld']")).selectByVisibleText("Closed Won");
            CommonUtil.elementfinder(driver,potelmt,"id","potentialamount").sendKeys(pamt);
            CommonUtil.elementfinder(driver,potelmt,"id","potentialclosedate").click();
            
            Thread.sleep(500);
            if(!((CommonUtil.elementfinder(driver,potelmt,"id","crmdatepickerdiv").getAttribute("style")).contains("display: block;")))
            {
                etest.log(Status.FAIL,"Potential div is not displayed");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","AddPotential","AddPotentialError");
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            WebElement caelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","potentialclosedatediv"),"tagname","table");
            WebElement calelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,caelmt,"tagname","table"),"classname","datepickerDays");
            
            String pdatedd = calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String pdatemmyy = caelmt.findElement(By.tagName("table")).findElement(By.className("datepickerMonth")).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
            String mmddyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"mmddyy");
            String ddmmyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"ddmmyy");
            
            calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).click();
            
            Thread.sleep(500);
            CommonUtil.elementfinder(driver,potelmt,"classname","rg-button").click();
            
            Thread.sleep(2000);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!(driver.findElement(By.id("associatedpotentialdiv")).getAttribute("style").contains("none")))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement chatlead = CommonUtil.elfinder(driver,"id","associatedpotentialdiv");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            
            String potname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String potstage = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String potamt = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String potdate = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            
            if(!(potname.equals(pname)&&potstage.equals("Closed Won")&&potamt.equals(pamt)&&potdate.equals(ddmmyy)))
            {
                etest.log(Status.FAIL,"Expected:"+pname+"--Closed Won--"+pamt+"--"+ddmmyy+"--Actual:"+potname+"--"+potstage+"--"+potamt+"--"+potdate+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","AddPotential","AddPotentialError");
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            try
            {
                crmwindow.navigate().refresh();
                
                CommonFunctions.crmClickPotential(crmwindow);
                
                WebElement ptelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmpots = ptelmt.findElements(By.tagName("tr"));
                
                String potid;
                
                for(WebElement crmpot:crmpots)
                {
                    potid = crmpot.getAttribute("id");
                    
                    if(!potid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+potid).getText().equals(pname))
                    {
                        String curpot_amt = crmpot.findElements(By.tagName("td")).get(4).getText();
                        String curpot_stage = crmpot.findElements(By.tagName("td")).get(5).getText();
                        //String curpot_acname = crmpot.findElements(By.tagName("td")).get(7).getText();
                        String curpot_date = crmpot.findElements(By.tagName("td")).get(6).getText();
                        
                        System.out.println("Potential : "+curpot_amt+" >> "+curpot_stage+" >> "+curpot_date);
                        
                        if(curpot_stage.equals("Closed Won")&&curpot_date.equals(ddmmyy))//curpot_date.equals(mmddyy))//curpot_amt.equals("$"+pamt+".00")&&
                        {
                            etest.log(Status.PASS,"Checked");
                            CommonFunctions.endSessionAccounts(crmwindow);
                            return true;
                        }
                        else
                        {
                            etest.log(Status.FAIL,"Expected:Closed Won--"+ddmmyy+"--Actual:"+curpot_stage+"--"+curpot_date+"--");
                            TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","AddPotential","AddPotentialError"); 
                        }
                        CommonFunctions.endSessionAccounts(crmwindow);
                        return false;
                    }
                }
                etest.log(Status.FAIL,pname+" is not present");
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","AddPotential","AddPotentialError"); 
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","AddPotential","AddPotentialError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm add potential to added contact in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","AddPotential","AddPotentialError",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm add potential to added contact in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","AddPotential","AddPotentialError",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        CommonFunctions.endSessionAccounts(crmwindow);
        return false;
    }

    public static boolean addPotential(WebDriver driver,ExtentTest etest) throws Exception
    {        
        CommonFunctions.chatHistoryClick(driver);
        CommonFunctions.clickAddPotenChatHis(driver);

        return addCRMPotential(driver,etest);
    }

    public static boolean addCRMPotential(WebDriver driver,ExtentTest etest) throws Exception
    {    
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        String pname = "Pot"+System.currentTimeMillis();
        String pamt = "2"+System.currentTimeMillis();
        
        WebElement potelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","addpotentialdiv"),"id","savepotentialfrm");
        
        CommonUtil.elementfinder(driver,potelmt,"id","potentialname").sendKeys(pname);
        new Select(CommonUtil.elementfinder(driver,potelmt,"xpath",".//select[@id='potentialstage'][@class='crmseld']")).selectByVisibleText("Qualification");
        CommonUtil.elementfinder(driver,potelmt,"id","potentialamount").sendKeys(pamt);
        CommonUtil.elementfinder(driver,potelmt,"id","potentialclosedate").click();
        
        Thread.sleep(500);
        if(!((CommonUtil.elementfinder(driver,potelmt,"id","crmdatepickerdiv").getAttribute("style")).contains("display: block;")))
        {
            etest.log(Status.FAIL,"Potential div is not displayed");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","AddPotential","AddPotentialError");
            return false;
        }
        
        WebElement caelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","potentialclosedatediv"),"tagname","table");
        WebElement calelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,caelmt,"tagname","table"),"classname","datepickerDays");
        
        String pdatedd = calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
        String pdatemmyy = caelmt.findElement(By.tagName("table")).findElement(By.className("datepickerMonth")).findElement(By.tagName("a")).findElement(By.tagName("span")).getText();
        String mmddyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"mmddyy");
        String ddmmyy = CommonFunctions.dateCnstr(pdatemmyy,pdatedd,"ddmmyy");
        
        calelmt.findElements(By.tagName("tr")).get(2).findElements(By.tagName("td")).get(2).findElement(By.tagName("a")).findElement(By.tagName("span")).click();
        
        Thread.sleep(500);
        CommonUtil.elementfinder(driver,potelmt,"classname","rg-button").click();
        
        Thread.sleep(2000);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!(driver.findElement(By.id("associatedpotentialdiv")).getAttribute("style").contains("none")))
                {
                    return true;
                }
                return false;
            }
        });
        return true;
    }
}
