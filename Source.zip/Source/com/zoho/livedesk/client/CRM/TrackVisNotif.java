//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class TrackVisNotif
{
    public static boolean visNotification(WebDriver driver,WebDriver driver2,WebDriver driver3,WebDriver driver4,WebDriver crmwindow,boolean status,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            
            String checked = status?"chk":"unchk";
            
            IntegrationSettings.chooseType(driver, "vistrackcrmdiv", "NOTIFYCRM", 0, checked,etest);
            IntegrationSettings.chooseType(driver2, "vistrackcrmdiv", "NOTIFYCRM", 0, checked,etest);
            IntegrationSettings.chooseType(driver3, "vistrackcrmdiv", "NOTIFYCRM", 0, checked,etest);
            IntegrationSettings.chooseType(driver4, "vistrackcrmdiv", "NOTIFYCRM", 0, checked,etest);
            
            Thread.sleep(1000);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(2000);
            try
            {
                crmwindow.navigate().refresh();
                Thread.sleep(2000);
                
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("basic")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("tabLayer")));
                Thread.sleep(2000);

                boolean notifstatus = CommonFunctions.wmsbar(crmwindow,status);
                
               if(notifstatus)
                {
                    etest.log(Status.PASS,"Checked");
                    CommonFunctions.endSessionAccounts(crmwindow);
                    return true;
                }

                etest.log(Status.FAIL,"Mismatch Notification status in CRM Window.Expected"+status+"Actual:"+notifstatus);
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","TrackVisNotif","Error");
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","TrackVisNotif","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","TrackVisNotif","Error",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","TrackVisNotif","Error",e);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
}
