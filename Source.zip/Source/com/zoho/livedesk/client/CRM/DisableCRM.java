//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class DisableCRM
{
    //Disable crm and check for wms bar visitors online tab
    public static boolean crmdisable(WebDriver driver,WebDriver driver2,WebDriver driver3,WebDriver driver4,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            IntegrationSettings.disableCRMInteg(driver,etest);
            IntegrationSettings.disableCRMInteg(driver2,etest);
            IntegrationSettings.disableCRMInteg(driver3,etest);
            IntegrationSettings.disableCRMInteg(driver4,etest);

            //Thread.sleep(1000);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);

            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";

            crmwindow.navigate().refresh();
            
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            try
            {
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("tabLayer")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("show")));

                if(!CommonFunctions.wmsbar(crmwindow,false))
                {
                    TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","DisableCRM","NotDisabledInCRMWindow");
                    CommonFunctions.endSessionAccounts(crmwindow);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","DisableCRM","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            System.out.println("Initiating chat - Disable CRM");

            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","DisableCRM","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            ChatWindow.acceptChat(driver,etest);

            Thread.sleep(1000);

            WebElement continfo_div = CommonUtil.elfinder(driver,"id","contactinfodiv");
            WebElement crminfo_div = CommonUtil.elfinder(driver,"id","crminfocontainer");
            WebElement addpot_div = CommonUtil.elfinder(driver,"id","addpotentialdiv");
            WebElement assopot_div = CommonUtil.elfinder(driver,"id","associatedpotentialdiv");
            WebElement respot_div = CommonUtil.elfinder(driver,"id","recentpotentialdiv");

            boolean continfo_presence = continfo_div==null;
            boolean crminfo_presence = crminfo_div==null;
            boolean addpot_presence = addpot_div==null;
            boolean assopot_presence = assopot_div==null;
            boolean respot_presence = respot_div==null;

            System.out.println("Disable CRM element not present : "+continfo_presence+" >> "+crminfo_presence+" >> "+addpot_presence+" >> "+assopot_presence+" >> "+respot_presence);

            continfo_presence = continfo_presence?continfo_presence:continfo_div.getAttribute("style").contains("none");
            crminfo_presence = crminfo_presence?crminfo_presence:crminfo_div.getAttribute("style").contains("none");
            addpot_presence = addpot_presence?addpot_presence:addpot_div.getAttribute("style").contains("none");
            assopot_presence = assopot_presence?assopot_presence:assopot_div.getAttribute("style").contains("none");
            respot_presence = respot_presence?respot_presence:respot_div.getAttribute("style").contains("none");

            System.out.println("Disable CRM element hidden : "+continfo_presence+" >> "+crminfo_presence+" >> "+addpot_presence+" >> "+assopot_presence+" >> "+respot_presence);

            if(continfo_presence && crminfo_presence && addpot_presence && assopot_presence && respot_presence)
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return true;
            }
            etest.log(Status.FAIL,"CRM Div is present");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","DisableCRM","CRMDisableError");
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm disable in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","DisableCRM","CRMDisableError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm disable in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","DisableCRM","CRMDisableError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
}
