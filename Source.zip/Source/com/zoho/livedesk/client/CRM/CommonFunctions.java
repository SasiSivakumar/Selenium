//$Id$
package com.zoho.livedesk.client.CRM;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.NoSuchElementException;

import com.google.common.base.Function;
import com.zoho.qa.server.servlet.WebdriverApi;
import org.openqa.selenium.interactions.Actions;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;

public class CommonFunctions
{
    public static void login(WebDriver driver,String usrname,String pwd)throws Exception
    {
        int screenWidth = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        int screenHeight = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        Dimension targetSize = new Dimension(screenWidth,screenHeight);     //Imac - 2560*1440  Mac - 1440*900
        driver.manage().window().setSize(targetSize);
        
        driver.manage().window().maximize();
        if(Util.siteNameout().contains("local"))
            driver.get("https://accounts.localzoho.com");
        else
            driver.get("https://accounts.zoho.com");
        driver.switchTo().frame(0);
        CommonUtil.elfinder(driver,"id","lid").clear();
        CommonUtil.elfinder(driver,"id","lid").sendKeys(usrname);
        
        CommonUtil.elfinder(driver,"id","pwd").clear();
        CommonUtil.elfinder(driver,"id","pwd").sendKeys(pwd);

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","login"),"classname","redBtn").click();
        
        Thread.sleep(5000);
        if(Util.siteNameout().contains("lab"))
        {
            driver.get("https://labsalesiq.localzoho.com");
        }
        else if(Util.siteNameout().contains("local"))
            driver.get("https://salesiq.localzoho.com");
        else if(Util.siteNameout().contains("pre"))
            driver.get("https://presalesiq.zoho.com");
        else
            driver.get("https://salesiq.zoho.com");
        
        try
        {
            WebElement banner = CommonUtil.elfinder(driver,"id","dnenable");
            WebElement close = CommonUtil.elementfinder(driver,banner,"className","sqico-close");
            close.click();
        }
        catch(Exception e){}
        System.out.println("Login success for Username:"+usrname);
    }

    public static void logout(WebDriver driver) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        
        String loginsite = Util.siteNameout();
        
        System.out.println(loginsite);
        String salesiqURL = "";
        
        if(loginsite.contains("salesiq.localzoho.com"))
        {
            salesiqURL = "https://salesiq.localzoho.com/";
        }
        else if(loginsite.contains("presalesiq.zoho.com"))
        {
            salesiqURL = "https://presalesiq.zoho.com/";
        }
        else
        {
            salesiqURL = "https://salesiq.zoho.com/";
        }
        
        driver.get(salesiqURL+"logout.sas");
        
        Thread.sleep(3000);
        
        //wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
    }

    public static void clickCRMInteg(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("settings_integration")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));
    }
    
    public static boolean wmsbar(WebDriver driver,boolean chk) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        if(chk)
        {
            try
            {
                WebElement txtwms = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","wmstoolbar"),"id","wVisTitBar");
                
                if((txtwms.getAttribute("data-title")).equals("Visitors Online"))
                {
                    return true;
                }
                return false;
            }
            catch(Exception e)
            {
                return false;
            }
        }
        else
        {
            try
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("wVisTitBar")));
                //WebElement txtwms = driver.findElement(By.id("wmstoolbar")).findElement(By.id("wVisTitBar"));
                //CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","wmstoolbar"),"id","wldpop"),"id","wVisTitBar");
                
                return false;
            }
            catch(Exception e)
            {
                return true;
            }
        }
    }
    
    public static void endChat(WebDriver driver)
    {
        try
        {
            Thread.sleep(1000);
            
            WebElement e = getChatInMyChats(driver);
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            try
            {
                wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,e,"id","endsession")));
            }
            catch(Exception ee){}
            
            CommonUtil.elementfinder(driver,e,"id","endsession").click();
            
            Thread.sleep(1000);
            
            try
            {
                wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,e,"linktext",ResourceManager.getRealValue("endsession_endimd"))));
            }
            catch(Exception ee){}
            
            CommonUtil.elementfinder(driver,e,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();
            
            try
            {
                wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,e,"linktext",ResourceManager.getRealValue("closewindow"))));
            }
            catch(Exception ee){}
            
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","infodiv"),"linktext",ResourceManager.getRealValue("closewindow")).click();
            
            Thread.sleep(1000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat session in crm integration module : ");
            e.printStackTrace();
        }
    }
    
    public static WebElement getChatInMyChats(WebDriver driver) throws Exception
    {
        List<WebElement> list = CommonUtil.elfinder(driver,"id","mycurrent_div").findElements(By.className("prelative"));
        
        WebElement chat = null;
        
        for(WebElement e : list)
        {
            if(e.getAttribute("style").contains("display: block;"))
                chat = e;
        }
        
        return chat;
    }
    
    public static void missChat(WebDriver chatwindow) throws Exception
    {
        VisitorWindow.waitTillChatisMissedInTheme(chatwindow);
    }
    
    public static void endSessionAccounts(WebDriver crmwindow)
    {
        
    }
    
    public static void endSessionAccounts2(WebDriver crmwindow)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(crmwindow,30,200);
            
            String loginsite = Util.siteNameout();
            
            wait.ignoring(NoSuchElementException.class);
            
            if(loginsite.contains("salesiq.localzoho.com"))
            {
                crmwindow.get("https://accounts.localzoho.com/logout");
            }
            else if(loginsite.contains("presalesiq.zoho.com"))
            {
                crmwindow.get("https://accounts.zoho.com/logout");
            }
            else
            {
                crmwindow.get("https://accounts.zoho.com/logout");
            }
            
            //Thread.sleep(3000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending crm session : "+e);
            e.printStackTrace();
        }
    }
    
    public static void chatHistoryClick(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("common_history"))));
        Thread.sleep(1000);
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_history")).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("historylist")));
    }
    
    public static String dateCnstr(String pdatemmyy,String pdatedd,String type)
    {
        String pdateyy = "2016";
        String pdatemm = "04";
        
        if(pdatemmyy.contains("2015"))
        {
            pdateyy = "2015";
        }
        else if(pdatemmyy.contains("2016"))
        {
            pdateyy = "2016";
        }
        else if(pdatemmyy.contains("2017"))
        {
            pdateyy = "2017";
        }
        else if(pdatemmyy.contains("2018"))
        {
            pdateyy = "2018";
        }
        else if(pdatemmyy.contains("2019"))
        {
            pdateyy = "2019";
        }
        else
        {
            pdateyy = "2014";
        }
        
        if(pdatemmyy.contains("January"))
        {
            pdatemm = "01";
        }
        else if(pdatemmyy.contains("February"))
        {
            pdatemm = "02";
        }
        else if(pdatemmyy.contains("March"))
        {
            pdatemm = "03";
        }
        else if(pdatemmyy.contains("April"))
        {
            pdatemm = "04";
        }
        else if(pdatemmyy.contains("May"))
        {
            pdatemm = "05";
        }
        else if(pdatemmyy.contains("June"))
        {
            pdatemm = "06";
        }
        else if(pdatemmyy.contains("July"))
        {
            pdatemm = "07";
        }
        else if(pdatemmyy.contains("August"))
        {
            pdatemm = "08";
        }
        else if(pdatemmyy.contains("September"))
        {
            pdatemm = "09";
        }
        else if(pdatemmyy.contains("October"))
        {
            pdatemm = "10";
        }
        else if(pdatemmyy.contains("November"))
        {
            pdatemm = "11";
        }
        else if(pdatemmyy.contains("December"))
        {
            pdatemm = "12";
        }
        
        String pdateddmmyy = pdatemm+"/"+pdatedd+"/"+pdateyy;
        
        if(type.equals("ddmmyy"))
        {
            pdateddmmyy = pdatedd+"/"+pdatemm+"/"+pdateyy;
        }
        
        return pdateddmmyy;
    }
    
    public static void clickLead(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!(driver.findElement(By.id("crminfocontainer")).getAttribute("style").contains("none")))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement infoelmt = CommonUtil.elfinder(driver,"id","crminfocontainer");
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,infoelmt,"classname","spt_crtnewreqst"),"tagname","span").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lead_div")));
    }
    
    public static void crmClickLead(WebDriver crmwindow) throws Exception
    {
        for(int i = 0; i < 3; i++)
        {
            try
            {
                FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
                
                Thread.sleep(2000);
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("tabLayer")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("show")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("crm_lead"))));
                
                Thread.sleep(1000);
                CommonUtil.elfinder(crmwindow,"linktext",ResourceManager.getRealValue("crm_lead")).click();
                
                Thread.sleep(1000);
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("idForCV")));
            }
            catch(Exception e)
            {
                com.zoho.livedesk.util.common.CommonUtil.refreshPage(crmwindow);
                com.zoho.livedesk.util.common.CommonUtil.clickWebElement(crmwindow,com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("crmTopMenuLyteDrop"),By.className("lyteDot")));
                continue;
            }
        }
    }
    
    public static void clickContact(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!(driver.findElement(By.id("crminfocontainer")).getAttribute("style").contains("none")))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement infoelmt = CommonUtil.elfinder(driver,"id","crminfocontainer");
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,infoelmt,"classname","spt_crtnewreqst"),"tagname","span").click();
        
        Thread.sleep(500);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("contact_div")));
        
        CommonUtil.elfinder(driver,"id","contact_head").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!(driver.findElement(By.id("contact_div")).getAttribute("style").contains("none")))
                {
                    return true;
                }
                return false;
            }
        });
        
        Thread.sleep(500);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("accountname")));
    }
    
    public static void crmClickContact(WebDriver crmwindow) throws Exception
    {
        for(int i = 0; i < 3; i++)
        {
            try
            {
                FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
                
                Thread.sleep(2000);
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("tabLayer")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("show")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("crm_contact"))));
                
                Thread.sleep(1000);
                CommonUtil.elfinder(crmwindow,"linktext",ResourceManager.getRealValue("crm_contact")).click();
                
                Thread.sleep(1000);
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("idForCV")));
                break;
            }
            catch(Exception e)
            {
                com.zoho.livedesk.util.common.CommonUtil.refreshPage(crmwindow);
                com.zoho.livedesk.util.common.CommonUtil.clickWebElement(crmwindow,com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("crmTopMenuLyteDrop"),By.className("lyteDot")));
                continue;
            }
        }
    }
    
    public static void clickAddPotenChatHis(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement hiselmt = CommonUtil.elfinder(driver,"id","history_mcontent");
        WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,hiselmt,"id","historylist"),"tagname","table");
        WebElement elmtt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"tagname","tbody"),"classname","cursr-point");
        
        CommonUtil.elementfinder(driver,elmtt,"classname","secnd-clm").click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));
        
        WebElement crmelmt = CommonUtil.elfinder(driver,"id","contactinfodiv");
        WebElement velmt = CommonUtil.elfinder(driver,"id","chathead");
        
        CommonUtil.elementfinder(driver,crmelmt,"id","btnshowaddpoten").click();
        
        Thread.sleep(500);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addpotentialdiv")));
    }
    
    public static void crmClickPotential(WebDriver crmwindow) throws Exception
    {
        for(int i = 0; i < 3; i++)
        {
            try
            {
                FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
                
                Thread.sleep(2000);
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("tabLayer")));
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("show")));

                String potential_link_text=getPotentialLinkText(crmwindow);        
                
                Thread.sleep(1000);
                CommonUtil.elfinder(crmwindow,"linktext",potential_link_text).click();
                
                Thread.sleep(1000);
                waitcrm.until(ExpectedConditions.presenceOfElementLocated(By.id("idForCV")));
                break;
            }
            catch(Exception e)
            {
                com.zoho.livedesk.util.common.CommonUtil.refreshPage(crmwindow);
                com.zoho.livedesk.util.common.CommonUtil.clickWebElement(crmwindow,com.zoho.livedesk.util.common.CommonUtil.getElement(crmwindow,By.id("crmTopMenuLyteDrop"),By.className("lyteDot")));
                continue;
            }
        }
    }

    public static String getPotentialLinkText(final WebDriver crmwindow) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(crmwindow,30,250);

        wait.until(new Function<WebDriver,Boolean>()
        {
        public Boolean apply(WebDriver crmwindow)
        {
            if(crmwindow.findElements(By.linkText(ResourceManager.getRealValue("crm_potential"))).size()>0 || crmwindow.findElements(By.linkText(ResourceManager.getRealValue("crm_deal"))).size()>0)
            {
                return true;
            }
            return false;
        }
        });   

        if(crmwindow.findElements(By.linkText(ResourceManager.getRealValue("crm_potential"))).size()>0)
        {
            return ResourceManager.getRealValue("crm_potential");
        }
        else if(crmwindow.findElements(By.linkText(ResourceManager.getRealValue("crm_deal"))).size()>0)
        {
            return ResourceManager.getRealValue("crm_deal");
        }
        else
        {
            throw new ZohoSalesIQRuntimeException("Deals/Potential tab not found");
        }
    }
    
    public static void changeStatus(WebDriver driver,String status) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        Thread.sleep(1000);
        
        try
        {
            Thread.sleep(2000);
            Functions.closeBannersAfterLogin(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while closing the maintenance banner : "+e);
        }
        
        if(status.equals("available"))
        {
            if(!((CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","hdrstatus").getAttribute("class")).equals("userstatus-1")))
            {
                CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","hdrprt"),"id","hdrdrpdwntop").click();
                
                Thread.sleep(1000);
                
                CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","ustatus"),"tagname","a"),"tagname","span").click();
                
                Thread.sleep(1000);
                
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-1"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
        else if(status.equals("busy"))
        {
            if(!((CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","hdrstatus").getAttribute("class")).equals("userstatus-3")))
            {
                CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","hdrprt"),"id","hdrdrpdwntop").click();
                
                Thread.sleep(1000);
                
                CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","ustatus"),"tagname","a"),"tagname","span").click();
                
                Thread.sleep(1000);
                
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-3"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
        
        Thread.sleep(1000);
    }
    
    public static String curDate()
    {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        //get current date time with Date()
        Date date = new Date();
        System.out.println(dateFormat.format(date));
        
        //get current date time with Calendar()
        Calendar cal = Calendar.getInstance();
        return dateFormat.format(cal.getTime());
    }
    
    public static String datediff(String d1,String d2,TimeUnit timeUnit)
    {
        try
        {
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            //Date date1 = df.parse(df.format(new Date()));
            Date date1 = df.parse(d1);
            Date date2 = df.parse(d2);
            long diffInMillies = date2.getTime() - date1.getTime();
            long difftime = timeUnit.convert(diffInMillies,TimeUnit.MILLISECONDS);
            difftime = difftime/1440;
            
            if(difftime==7)
            {
                return "7th Day";
            }
            else if(difftime==14)
            {
                return "14th Day";
            }
            else if(difftime==1)
            {
                return "Tomorrow";
            }
            else if(difftime==0)
            {
                return "Today";
            }
            
            return "None";
        }
        catch(Exception e)
        {
            System.out.println("Exception while calculating date difference : "+e);
        }
        return "None";
    }
    
    public static void clickChatHistory(WebDriver driver,String vname) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_history")).click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("history_div")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("historylist")));
        
        WebElement celmt = driver.findElement(By.id("history_div")).findElement(By.id("historylist"));

        List<WebElement> visitor_list = celmt.findElements(By.className("cursr-point"));

        WebElement visitor_name = com.zoho.livedesk.util.common.CommonUtil.getElement(com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(visitor_list,"innerText",vname),By.className("secnd-clm"),By.tagName("h2"));

        com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,visitor_name);
        
        // CommonUtil.elementfinder(driver,celmt,"linktext",vname).click();
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("chathead")));
    }
    
    public static void sendMessage(WebDriver driver,String message) throws Exception
    {
        ChatWindow.sentMessage(driver,message);
    }
    
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
}
