//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.client.CRM.CRMIntegration;

public class CRMButton
{
    //Enable automatic push and check for push to crm button
    public static boolean pushToCRMButton(WebDriver driver,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,250);
            
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            String pname = "Pot"+System.currentTimeMillis();
            String pamt = "2"+System.currentTimeMillis();
            
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","PushToCRM","PushTocrmError",e);
                chatwindow.quit();
                return false; 
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(1000);
            
            String ptc = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfocontainer"),"classname","spt_tkadtbtnmn"),"tagname","span").getText();
            System.out.println("Disble PTC : >>"+ptc);
            
            if(ptc.contains("Push To CRM"))
            {
                CommonFunctions.endChat(driver);
                
                chatwindow.quit();
                Thread.sleep(1000);

                String WIDGET_CODE="";

                WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
                
                chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
                
                IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);
                Functions.refreshSiteAndWaitForRSID(driver);
            	Thread.sleep(1000);
                
                vemail = "email1@"+System.currentTimeMillis()+".com";
                try
                {
                    VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
                }
                catch(Exception e)
                {
                    TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","PushToCRM","PushTocrmError",e);
                    chatwindow.quit();
                    return false; 
                }
                ChatWindow.acceptChat(driver,etest);
                Thread.sleep(1000);
                
                try
                {
                    driver.findElement(By.id("crminfocontainer")).findElement(By.className("spt_tkadtbtnmn")).findElement(By.tagName("span"));
                    etest.log(Status.FAIL,"Push to CRM is present");
                    TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushToCRM","PushTocrmError");
                    CommonFunctions.endChat(driver);
                    chatwindow.quit();
                    return false;
                }
                catch(Exception e)
                {
                    CommonFunctions.endChat(driver);
                    chatwindow.quit();
                    return true;
                }
            }
            etest.log(Status.FAIL,"Expected:Push To CRM--Actual"+ptc+"--");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushToCRM","PushTocrmError");
            CommonFunctions.endChat(driver);
            chatwindow.quit();
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushToCRM","PushTocrmError",e);
            CommonFunctions.endChat(driver);
            chatwindow.quit();
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking push to crm button in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushToCRM","PushTocrmError",e);
            CommonFunctions.endChat(driver);
            chatwindow.quit();
            return false;
        }
    }
}
