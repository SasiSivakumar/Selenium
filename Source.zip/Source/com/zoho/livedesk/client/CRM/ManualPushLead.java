//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class ManualPushLead
{
    //Manual push visitor as lead in CRM
    public static boolean manualLead(WebDriver driver,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,250);
            
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","ManualLead","ManualLeadError",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }

            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(1000);
            
            CommonFunctions.clickLead(driver);
            
            Thread.sleep(500);
            
            WebElement crmelmt = CommonUtil.elfinder(driver,"id","lead_div");
            
            CommonUtil.elementfinder(driver,crmelmt,"id","companyname").sendKeys("AutomationComp");
            
            new Select(CommonUtil.elementfinder(driver,crmelmt,"xpath",".//select[@id='lstatus'][@class='crmseld']")).selectByVisibleText("Junk Lead");
            Thread.sleep(1000);
            
            CommonUtil.elementfinder(driver,crmelmt,"classname","rg-button").click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            
            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            
            String leadname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String leademail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String leadcomp = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            String leadphone = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String leadtype = chatelmts.get(4).findElement(By.className("crmld_infrht")).getText();
            
            if(!(leadname.equals(vname)&&leademail.equals(vemail)&&leadcomp.equals("AutomationComp")&&leadphone.equals(vphone)&&leadtype.equals("Lead")))
            {
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--AutomationComp--"+vphone+"--Lead--Actual:"+leadname+"--"+leademail+"--"+leadcomp+"--"+leadphone+"--"+leadtype+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ManualLead","ManualLeadError");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            try
            {
                Thread.sleep(2000);
                crmwindow.navigate().refresh();
                
                CommonFunctions.crmClickLead(crmwindow);
                
                WebElement leadelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmleads = leadelmt.findElements(By.tagName("tr"));
                
                String leadid;
                
                for(WebElement crmlead:crmleads)
                {
                    leadid = crmlead.getAttribute("id");
                    
                    if(!leadid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+leadid).getText().equals(vname))
                    {
                        String curlead_company = crmlead.findElements(By.tagName("td")).get(4).getText();
                        String curlead_phone = crmlead.findElements(By.tagName("td")).get(5).getText();
                        String curlead_email = crmlead.findElements(By.tagName("td")).get(6).getText();
                        
                        if(curlead_company.equals("AutomationComp")&&curlead_phone.equals(vphone)&&curlead_email.equals(vemail))
                        {
                            etest.log(Status.PASS,"Checked");
                            CommonFunctions.endChat(driver);
                            CommonFunctions.endSessionAccounts(crmwindow);
                            return true;
                        }
                        else
                        {
                            etest.log(Status.FAIL,"Expected:AutomationComp--"+vphone+"--"+vemail+"--Actual:"+curlead_company+"--"+curlead_phone+"--"+curlead_email+"--");
                            TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","ManualLead","ManualLeadError");
                        }
                        CommonFunctions.endChat(driver);
                        CommonFunctions.endSessionAccounts(crmwindow);
                        return false;
                    }
                }
                etest.log(Status.FAIL,vname+" is not present");
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","ManualLead","ManualLeadError");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","ManualLead","ManualLeadError",e);
            }
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking crm manually push as lead in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ManualLead","ManualLeadError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm manually push as lead in crm integration : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","ManualLead","ManualLeadError",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
}
