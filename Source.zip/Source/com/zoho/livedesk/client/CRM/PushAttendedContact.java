//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

public class PushAttendedContact
{
    public static boolean autoAttendedContact(WebDriver driver,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);
            
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);
            IntegrationSettings.addNewVisitorTo(driver,1,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","PushAttendedContactEnabled","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(2000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            
            try
            {
                wait.until(new Function<WebDriver, Boolean>() {
                   public Boolean apply(WebDriver driver) {
                       try
                       {
                           if((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true"))
                               return true;
                       }
                       catch (Exception e) {}
                       return false;
                   }
                });
            }
            catch(Exception e){}

            if(!((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                etest.log(Status.FAIL,"CRM div is not present");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactEnabled","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            Thread.sleep(1000);
            
            WebElement chatlead = CommonUtil.elfinder(driver,"id","crm_data");
            List<WebElement> chatelmts = chatlead.findElements(By.className("crmld_infomn"));
            
            String contactname = chatelmts.get(0).findElement(By.className("crmld_infrht")).getText();
            String contactemail = chatelmts.get(1).findElement(By.className("crmld_infrht")).getText();
            String contactphone = chatelmts.get(2).findElement(By.className("crmld_infrht")).getText();
            //String contactacname = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            String contacttype = chatelmts.get(3).findElement(By.className("crmld_infrht")).getText();
            
            if(!(contactname.equals(vname)&&contactemail.equals(vemail)&&contactphone.equals(vphone)&&contacttype.equals("Contact")))//&&contactacname.equals(vacname)
            {
                etest.log(Status.FAIL,"Expected:"+vname+"--"+vemail+"--"+vphone+"--Contact--Actual:"+contactname+"--"+contactemail+"--"+contactphone+"--"+contacttype+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactEnabled","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            Thread.sleep(2000);
            try
            {
                crmwindow.navigate().refresh();
                
                CommonFunctions.crmClickContact(crmwindow);
                
                WebElement cntctelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmcontacts = cntctelmt.findElements(By.tagName("tr"));
                
                String contactid;
                
                for(WebElement crm_contact:crmcontacts)
                {
                    contactid = crm_contact.getAttribute("id");
                    
                    if(!contactid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+contactid).getText().equals(vname))
                    {
                        String curcontact_phone = crm_contact.findElements(By.tagName("td")).get(4).getText();
                        String curcontact_email = crm_contact.findElements(By.tagName("td")).get(5).getText();
                        //String curcontact_acname = crm_contact.findElements(By.tagName("td")).get(6).getText();;
                        
                        if(curcontact_phone.equals(vphone)&&curcontact_email.equals(vemail))//&&curcontact_acname.equals(vacname)
                        {
                            etest.log(Status.PASS,"Checked");
                            CommonFunctions.endChat(driver);
                            CommonFunctions.endSessionAccounts(crmwindow);
                            return true;
                        }
                        etest.log(Status.FAIL,"Expected:"+vphone+"--"+vemail+"--Actual"+curcontact_phone+"--"+curcontact_email+"--");
                        TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","PushAttendedContactEnabled","Error");
                        CommonFunctions.endChat(driver);
                        CommonFunctions.endSessionAccounts(crmwindow);
                        return false;
                    }
                }
                etest.log(Status.FAIL,vname+" is not present");
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","PushAttendedContactEnabled","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","PushAttendedContactEnabled","Error",e);
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactEnabled","Error",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactEnabled","Error",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
    
    public static boolean autoAttendedContactDisabled(WebDriver driver,WebDriver crmwindow,WebDriver chatwindow,ExtentTest etest)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            FluentWait waitcrm = CommonUtil.waitreturner(crmwindow,30,200);
            FluentWait waitchat = CommonUtil.waitreturner(chatwindow,30,200);
            
            String vname = "Vis"+System.currentTimeMillis();
            String vemail = "email@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "crm chat working?...";
            String vacname = "Ac"+System.currentTimeMillis();
            
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Missed", 0, "unchk",etest);
            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "unchk",etest);
            IntegrationSettings.addNewVisitorTo(driver,1,etest);
            Functions.refreshSiteAndWaitForRSID(driver);
            Thread.sleep(1000);
            
            try
            {
                VisitorWindow.initiateChatVisTheme(chatwindow,vname,vemail,vphone,vques,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(chatwindow,etest,"CRMIntegration","PushAttendedContactDisabled","Error",e);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            ChatWindow.acceptChat(driver,etest);
            Thread.sleep(2000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("crm_data")));
            
            if(((driver.findElement(By.id("crm_data")).getAttribute("isdata")).equals("true")))
            {
                etest.log(Status.FAIL,"CRM div is present");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactDisabled","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            String ptc = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","crminfocontainer"),"classname","spt_tkadtbtnmn"),"tagname","span").getText();
            System.out.println("PTC : >>"+ptc);
            
            if(!ptc.contains("Push To CRM"))
            {
                etest.log(Status.FAIL,"Expected:Push to CRM--Actual"+ptc+"--");
                TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactDisabled","Error");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
            
            Thread.sleep(2000);
            try
            {
                crmwindow.navigate().refresh();
                
                CommonFunctions.crmClickContact(crmwindow);
                
                WebElement cntctelmt = CommonUtil.elementfinder(crmwindow,CommonUtil.elfinder(crmwindow,"id","listViewTable"),"id","lvTred");
                List<WebElement> crmcontacts = cntctelmt.findElements(By.tagName("tr"));
                
                String contactid;
                
                for(WebElement crm_contact:crmcontacts)
                {
                    contactid = crm_contact.getAttribute("id");
                    
                    if(!contactid.equals("") && CommonUtil.elfinder(crmwindow,"id","listView_"+contactid).getText().equals(vname))
                    {
                        etest.log(Status.FAIL,vname+" is present");
                        TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","PushAttendedContactDisabled","Error");
                        CommonFunctions.endChat(driver);
                        CommonFunctions.endSessionAccounts(crmwindow);
                        return false;
                    }
                }
                etest.log(Status.PASS,"Checked");
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return true;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(crmwindow,etest,"CRMIntegration","PushAttendedContactDisabled","Error",e);
                CommonFunctions.endChat(driver);
                CommonFunctions.endSessionAccounts(crmwindow);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactDisabled","Error",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking automatically push attended lead in crm integration : "+e);
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","PushAttendedContactDisabled","Error",e);
            CommonFunctions.endChat(driver);
            CommonFunctions.endSessionAccounts(crmwindow);
            return false;
        }
    }
}
