//$Id$
package com.zoho.livedesk.client.CRM;

import java.io.IOException;
import java.util.Set;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

public class CRMSite
{
    //public static WebDriver driver = null;
    
//    public static WebDriver crmdriver()
//    {
//        WebDriver driver = null;
//            
//        try
//        {
//            driver = Functions.setUp();
//            
//            Functions.loginCRM(driver,"crm");
//            
//            return driver;
//        }
//        catch(NoSuchElementException e)
//        {
//            System.out.println("Exception while creating new crm driver in crm integration test : "+e);
//            e.printStackTrace();
//        }
//        catch(Exception e)
//        {
//            System.out.println("Exception while creating new crm driver in crm integration test : "+e);
//            e.printStackTrace();
//        }
//        return driver;
//    }
}
