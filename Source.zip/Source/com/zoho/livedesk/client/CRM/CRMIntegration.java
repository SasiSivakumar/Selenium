//$Id$
package com.zoho.livedesk.client.CRM;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;

import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.common.base.Function;

import com.zoho.livedesk.util.ApiAutomation;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class CRMIntegration
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static ExtentTest etest;
    private static String url = "";

    public static WebDriver crmwindow1,crmwindow2,crmwindow3,crmwindow4;
    public static WebDriver d1,d2,d3,d4;

    public static Hashtable crminteg(WebDriver driver)
    {


        try
        {
            result = new Hashtable();
            
            d1 = driver;
            d2 = Functions.setUp();
            d3 = Functions.setUp();
            d4 = Functions.setUp();

            crmwindow1 = Functions.setUp();
            crmwindow2 = Functions.setUp();
            crmwindow3 = Functions.setUp();
            crmwindow4 = Functions.setUp();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM1"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
            
            WebDriver chatwindow;

            if(!Functions.login(d2,"crm2") || !Functions.login(d3,"crm3") || !Functions.login(d4,"crm4") || !Functions.loginCRM(crmwindow1,"crm1",1) || !Functions.loginCRM(crmwindow2,"crm2",2) || !Functions.loginCRM(crmwindow3,"crm3",3) || !Functions.loginCRM(crmwindow4,"crm4",4))
            {
                result.put("CRM1",false);
                
                etest.log(Status.FAIL,"Login failed");
                
                TakeScreenshot.screenshot(d2,etest,"CRMIntegration","CRM","IntegSettingsError");
                TakeScreenshot.screenshot(crmwindow1,etest,"CRMIntegration","CRM","IntegSettingsError");
                TakeScreenshot.screenshot(crmwindow2,etest,"CRMIntegration","CRM","IntegSettingsError");
                
                ComplexReportFactory.closeTest(etest);
                
                hashtable.put("result", result);
                hashtable.put("servicedown", servicedown);
                return hashtable;
            }

            url = ConfManager.requestURL();
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickCRMInteg(driver);

            etest.log(Status.PASS,"Checked");
            
            result.put("CRM1",true);

            ComplexReportFactory.closeTest(etest);
            
            WebDriver crmwindow = crmwindow1;
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM12"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
            
            result.put("CRM12",ZSCKeyGenerate(d1,d2,d3,d4,crmwindow1,crmwindow2,crmwindow3,crmwindow4,etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM2"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
            
            Thread.sleep(1000);
            
            //clearSessions();

            String WIDGET_CODE=ExecuteStatements.getWidgetCode(d1);

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM2",DisableCRM.crmdisable(d1,d2,d3,d4,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM3"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
            
            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM3",EnableCRM.crmenable(d1,d2,d3,d4,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM21"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
            
            result.put("CRM21",TrackVisNotif.visNotification(d1,d2,d3,d4,crmwindow,true,etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM22"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
            
            result.put("CRM22",TrackVisNotif.visNotification(d1,d2,d3,d4,crmwindow,false,etest));
            
            ComplexReportFactory.closeTest(etest);
            
            new CRMIntegration().initiate();
            
            CommonFunctions.logout(d2);
            CommonFunctions.logout(d3);
            CommonFunctions.logout(d4);

            /*
             chatwindow = chatdriver();
             potForThisChat(driver,chatwindow);
             chatwindow = chatdriver();
             crmInfo(driver,chatwindow);
             */
        }
        catch(NoSuchElementException e)
        {
            result.put("CRM1",false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("CRM Integration Show stopper : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRM","IntegSettingsError",e);
        }
        catch(Exception e)
        {
            result.put("CRM1",false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("CRM Integration Show stopper : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRM","IntegSettingsError",e);
        }
        
        d2.quit();
        
        try
        {
            CommonFunctions.endSessionAccounts2(crmwindow1);
            CommonFunctions.endSessionAccounts2(crmwindow2);
            
            crmwindow1.quit();
            crmwindow2.quit();
        }
        catch(Exception excep)
        {
            excep.printStackTrace();
        }
        
        ComplexReportFactory.closeTest(etest);
        
        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public void initiate()
    {
            ExecutorService executor = Executors.newFixedThreadPool(100);
             
            for (int i = 0; i < 4; i++)
            {
                  Runnable worker = new MyRunnable(i);
                  executor.execute(worker);
            }
            executor.shutdown();
              // Wait until all threads are finish
            while (!executor.isTerminated()) {
              }

    }

    public static void thread1(WebDriver driver,WebDriver crmwindow)
    {
      try
      {
            String portal=ExecuteStatements.getPortal(driver);

            String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);

            WebDriver chatwindow;
          
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM4"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM4",ManualPushLead.manualLead(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM5"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM5",ManualPushContact.manualContact(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM6"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            result.put("CRM6",PotentialAdd.addPotential(driver,crmwindow,etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM7"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM7",ConvertLead.leadToContactNoPotential(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM8"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM8",ConvertLead.leadToContactWithPotential(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM27"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
          
            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM27",StatusinSIQ.statusInSalesiqMissed(driver,chatwindow,etest));
          
            ComplexReportFactory.closeTest(etest);
          
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM28"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
          
            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM28",StatusinSIQ.statusInSalesiqTracked(driver,chatwindow,etest));
          
            ComplexReportFactory.closeTest(etest);
          
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM29"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM29",FollowUp.followUpTask(driver,crmwindow,chatwindow,"Tomorrow",etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM30"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM30",FollowUp.followUpTask(driver,crmwindow,chatwindow,"Today",etest));
            
            ComplexReportFactory.closeTest(etest);

         }
         catch(Exception e)
         {
            result.put("CRM1",false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("CRM Integration Show stopper : ");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRM","IntegSettingsError",e);
         }
         ComplexReportFactory.closeTest(etest);
    }

    public static void thread2(WebDriver driver,WebDriver crmwindow)
    {
      ExtentTest etest = null;
      WebDriver chatwindow;

      try
      {
            String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            String portal=ExecuteStatements.getPortal(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM13"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM13",PushMissedLead.autoMissedLead(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM14"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM14",PushMissedContact.autoMissedContact(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM15"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM15",PushAttendedLead.autoAttendedLead(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM16"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM16",PushAttendedContact.autoAttendedContact(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM17"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM17",PushAccessedLead.autoAccessedLead(driver,crmwindow,chatwindow,etest,portal));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM31"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");
          
            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM31",FollowUp.followUpTask(driver,crmwindow,chatwindow,"7th Day",etest));
          
            ComplexReportFactory.closeTest(etest);
          
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM34"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM34",AnonVisitor.anonVisit(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM39"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM39",CRMLead.convLeadCRM(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM40"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM40",UpdateData.updateEmailPopUp(driver,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM41"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM41",UpdateData.updateEmailChat(driver,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);
        }
         catch(Exception e)
         {
            result.put("CRM1",false);
            System.out.println("CRM Integration Show stopper : ");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRM","IntegSettingsError",e);
         }
          ComplexReportFactory.closeTest(etest);
    }

    public static void thread3(WebDriver driver,WebDriver crmwindow)
    {
      ExtentTest etest = null;
      WebDriver chatwindow;
        try
        {
            String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            String portal=ExecuteStatements.getPortal(driver);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM26"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM26",PushChatTrans.chatTranscript(driver,crmwindow,chatwindow,true,etest));
            
            ComplexReportFactory.closeTest(etest);
          
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM42"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM42",PushMissedLead.autoMissedLeadDisabled(driver,crmwindow,chatwindow,etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM43"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow.quit();
            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM43",PushAttendedLead.autoAttendedLeadDisabled(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM44"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM44",PushAccessedLead.autoAccessedLeadDisabled(driver,crmwindow,chatwindow,etest,portal));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM45"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM45",PushMissedContact.autoMissedContactDisabled(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM46"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM46",PushAttendedContact.autoAttendedContactDisabled(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM47"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM47",PushAccessedContact.autoAccessedContactDisabled(driver,crmwindow,chatwindow,etest,portal));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM32"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM32",FollowUp.followUpTask(driver,crmwindow,chatwindow,"14th Day",etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM33"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM33",FollowUp.followUpTask(driver,crmwindow,chatwindow,"None",etest));
            
            ComplexReportFactory.closeTest(etest);
        }
         catch(Exception e)
         {
            result.put("CRM1",false);
            System.out.println("CRM Integration Show stopper : ");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRM","IntegSettingsError",e);
         }
          ComplexReportFactory.closeTest(etest);
    }

    public static void thread4(WebDriver driver,WebDriver crmwindow)
    {
      ExtentTest etest = null;
      WebDriver chatwindow;
        try
        {
            String WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);
            String portal=ExecuteStatements.getPortal(driver);


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM18"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM18",PushAccessedContact.autoAccessedContact(driver,crmwindow,chatwindow,etest,portal));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM25"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM25",PushChatTrans.chatTranscript(driver,crmwindow,chatwindow,false,etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM9"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM9",CRMButton.pushToCRMButton(driver,chatwindow,etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM10"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM10",AddTask.addTaskLead(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM11"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM11",AddTask.addTaskContact(driver,crmwindow,chatwindow,etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM19"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);

            result.put("CRM19",RespUser.contUser(driver,crmwindow,chatwindow,"Automation Associate","Automation Associate",etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM20"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM20",RespUser.contUser(driver,crmwindow,chatwindow,"Zoho SalesIQ Attender",ExecuteStatements.getUserName(driver),etest));
            chatwindow.quit();
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM23"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM23",TrackVisitDetails.visitDetails(driver,crmwindow,chatwindow,false,etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRM24"));
            ComplexReportFactory.setValues(etest,"Automation","ZOHO CRM Integration");

            chatwindow = VisitorSite.chatdriver(WIDGET_CODE);
            result.put("CRM24",TrackVisitDetails.visitDetails(driver,crmwindow,chatwindow,true,etest));
            
            ComplexReportFactory.closeTest(etest);
        }
         catch(Exception e)
         {
            result.put("CRM1",false);
            System.out.println("CRM Integration Show stopper : ");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"CRMIntegration","CRM","IntegSettingsError",e);
         }
          ComplexReportFactory.closeTest(etest);
    }

    public class MyRunnable implements Runnable {

        private int fnum;
        
        MyRunnable(int fnum) {
            this.fnum = fnum;
        }
        
        @Override
        public void run() {
            
            //String result = "";
            try
            {
                if(fnum == 0)
                {
                  thread1(d1,crmwindow1);
                }
                else if(fnum == 1)
                {
                  thread2(d2,crmwindow2);
                }
                else if(fnum == 2)
                {
                  thread3(d3,crmwindow3);
                }
                else if(fnum == 3)
                {
                  thread4(d4,crmwindow4);
                }
            }
            catch (Exception e)
            {
                System.out.println("Status: Exception  : "+e);
                e.printStackTrace();
                //result = "->Red<-\t";
            }
            System.out.println("Status: Success");
        }
    }

    public static boolean ZSCKeyGenerate(WebDriver driver1,WebDriver driver2,WebDriver driver3,WebDriver driver4,WebDriver crmwindow1,WebDriver crmwindow2,WebDriver crmwindow3,WebDriver crmwindow4,ExtentTest etest)
    {
        try
        {
            if(ZSCKey.ZSCregenerate(driver1,crmwindow1,etest) &&
                ZSCKey.ZSCregenerate(driver2,crmwindow2,etest) &&
                ZSCKey.ZSCregenerate(driver3,crmwindow3,etest) &&
                ZSCKey.ZSCregenerate(driver4,crmwindow4,etest))
            {
                return true;
            }
            else 
            {
                return false;
            }
        }
        catch(Exception e)
        {
            return false;
        }
    }
}
