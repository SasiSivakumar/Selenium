//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class BlockedIP
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
    public static ExtentTest etest;

	public static Hashtable blockedIP(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB1"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //Thread.sleep(4000);
			//WebDriverWait wait = new WebDriverWait(driver, 20);
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			//BLOCKED IP VIEW
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

            etest.log(Status.PASS,"BlockedIPsTab is Present");

			result.put("SB1", true);
			//Thread.sleep(1000);
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB2"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB2", isPageAvail(driver));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB3"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB3", addInvalidIP(driver,"1234",null,null));
			//Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB4"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB4", addIP(driver,"15.1.1.1",null,null));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB5"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB5", addIP(driver,"15.1.1.2","Comment added 1",null));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB6"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB6", addIP(driver,"15.1.1.3",null,ConfManager.getPortalName()));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB7"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB7", addIP(driver,"15.1.1.4","Comment added 2",ConfManager.getPortalName()));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB8"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB8", checkEmbedforIP(driver,"15.1.1.4",ConfManager.getPortalName()));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB9"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB9", addComment(driver,"15.1.1.3"));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB10"));
			ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB10", deleteBlockedIP(driver,"15.1.1.1"));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB11"));
			ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB11", unblockIP(driver,"15.1.1.3"));
            //Thread.sleep(1000);

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SB12"));
			ComplexReportFactory.setValues(etest,"Automation","BlockedIP-Admin");

			result.put("SB12", blockIP(driver,"15.1.1.3"));
            //Thread.sleep(1000);
			ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorBlockedIPsTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockedIPTab","ErrorWhileCheckingBlockedTab",e);

			result.put("SB1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorBlockedIPsTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockedIPTab","ErrorWhileCheckingBlockedTab",e);

			result.put("SB1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	//Check BlockedIP Header
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_blockedips")+"')]")));
			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_blockedips")+"')]"));
			//Thread.sleep(300);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));

			if(((text.get(0).getText()).equals(ResourceManager.getRealValue("settings_blockip_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("settings_blockip_desc2"))))
			{
				etest.log(Status.PASS,"BlockedIp Description is Checked");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockedIPDescription","MismatchBlockedIPDesc");
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockedIPDescription","ErrorWhileCheckingBlockedIPDescription",e);
            System.out.println("Exception while checking if blockedIP settings page is available : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockedIPDescription","ErrorWhileCheckingBlockedIPDescription",e);
            System.out.println("Exception while checking if blockedIP settings page is available : "+e);
			return false;
		}
		return false;
	}

	//Check adding invalid IP
	private static boolean addInvalidIP(WebDriver driver, String ip, String comment, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

			//Thread.sleep(1000);
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtipname")));

		 	driver.findElement(By.id("txtipname")).clear();
		    driver.findElement(By.id("txtipname")).sendKeys(ip);
		    //Thread.sleep(300);

		    if(comment != null)
		    {
		    	driver.findElement(By.id("txtcomment")).clear();
			    driver.findElement(By.id("txtcomment")).sendKeys(comment);
			    //Thread.sleep(500);
		    }

		    if(embed != null)
		    {
		    	WebElement select = driver.findElement(By.id("getembedchats"));
			    Select dropDown = new Select(select);
			    List<WebElement> Options = dropDown.getOptions();
			    for(WebElement option:Options){
			    	if(option.getText().equals(embed)){
			           option.click();
			      }
			    }
		    }

		    //driver.findElement(By.xpath("//span[text()='"+ResourceManager.getRealValue("common_save")+"']")).click();
		    driver.findElement(By.id("ipsavebtn")).click();

		    //Thread.sleep(1000);

		    /*if(driver.findElement(By.id("txtipnameem")) != null)
		    {
		    	driver.findElement(By.linkText(ResourceManager.getRealValue("common_cancel"))).click();
		    }*/

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emnewcancategory")));

            if(driver.findElement(By.id("emnewcancategory")).getAttribute("style").equals("visibility: hidden;"))
            {
                driver.findElement(By.id("btncancel")).click();

                TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","InvalidIpAdded","AlertMessageNotPresent");

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

                return false;
            }

		    driver.findElement(By.id("btncancel")).click();
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modulelist")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

            etest.log(Status.PASS,"BlockedIP - Add Invalid IP is checked");

			return true;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","InvalidIpAdded","ErrorWhileAddingInvalidIP",e);
            System.out.println("Exception while adding invalid IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","InvalidIpAdded","ErrorWhileAddingInvalidIP",e);
            System.out.println("Exception while adding invalid IP in blockedIP settings page : "+e);
			return false;
		}
	}


	//Add IP
	public static boolean addIP(WebDriver driver, String ip, String comment, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtipname")));

		 	driver.findElement(By.id("txtipname")).clear();
		    driver.findElement(By.id("txtipname")).sendKeys(ip);
		    Thread.sleep(300);

		    if(comment != null)
		    {
		    	driver.findElement(By.id("txtcomment")).clear();
			    driver.findElement(By.id("txtcomment")).sendKeys(comment);
			    //Thread.sleep(500);
		    }

		    if(embed != null)
		    {
		    	WebElement select = driver.findElement(By.id("embedchatsid"));
                select.findElement(By.className("txtelips")).click();
			    //Select dropDown = new Select(select);
			    List<WebElement> Options = select.findElements(By.tagName("li"));
			    for(WebElement option:Options){
			    	if(option.findElement(By.tagName("span")).getText().equals(embed)){
			           option.click();
			      }
			    }
		    }

		    CommonWait.waitTillDisplayed(driver,By.id("embedchatsid"));
		    CommonUtil.sleep(2000);
		    driver.findElement(By.id("ipsavebtn")).click();

		    try
		    {
		    	CommonWait.waitTillHidden(driver,30,By.id("ipsavebtn"));
		    }
		    catch(Exception e)
		    {
		    	CommonUtil.doNothing();
		    }

            Tab.waitForLoadingSuccessWithBanner(driver,"Added successfully","blockip.do",etest);

		    //Thread.sleep(500);

		    return findIP(driver,ip,comment,embed);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddIP","ErrorWhileAddingIP",e);
            System.out.println("Exception while adding IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddIP","ErrorWhileAddingIP",e);
            System.out.println("Exception while adding IP in blockedIP settings page : "+e);
			return false;
		}
	}

	//find Blocked IP
	private static boolean findIP(WebDriver driver, String ip, String comment, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			//Thread.sleep(1000);
			WebElement elmt = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));

		 	boolean istrue = true;

		 	if(comment != null)
		 	{
		 		istrue = false;
		 		WebElement div1 = driver.findElement(By.id("commentlistcontainer"));
			    List<WebElement> div2 = div1.findElements(By.tagName("div"));
			    List<WebElement> div3 = div2.get(0).findElements(By.tagName("div"));
			    List<WebElement> div4 = div3.get(0).findElements(By.tagName("div"));

			    if((div4.get(0).getText()).contains(comment))
			    {
			    	istrue = true;
			    }
			    else{
			    	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddIP","MismatchIPAddedWithComment");
			    }

		 	}
		 	if(embed != null)
		 	{
		 		istrue = false;
		 		driver.findElement(By.xpath("//div[text()='"+embed+"']"));
			    //Thread.sleep(500);
			    istrue = true;
		 	}

		 	etest.log(Status.PASS,"Added Blocked IP is present");

		 	return istrue;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddIP","ErrorWhileCheckingAddedIP",e);
            System.out.println("Exception while finding IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddIP","ErrorWhileCheckingAddedIP",e);
            System.out.println("Exception while finding IP in blockedIP settings page : "+e);
			return false;
		}
	}

	//Check Embed for Blocked IP
	private static boolean checkEmbedforIP(WebDriver driver, String ip, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			//Thread.sleep(1000);
			WebElement elmt = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));

		 	//Thread.sleep(500);
		 	driver.findElement(By.xpath("//div[text()='"+embed+"']"));
            //Thread.sleep(500);

		 	etest.log(Status.PASS,"Embed For Added IP is cheked");

			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","CheckEmbedForAddedIP","ErrorWhileCheckingEmbedForAddedIP",e);
            System.out.println("Exception while checking embed for IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","CheckEmbedForAddedIP","ErrorWhileCheckingEmbedForAddedIP",e);
            System.out.println("Exception while checking embed for IP in blockedIP settings page : "+e);
			return false;
		}
	}

	//Add comment for already added IP
	private static boolean addComment(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			String comment = "Blocked IP Comment added at "+System.currentTimeMillis();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt1 = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));

			//Thread.sleep(2000);

			((JavascriptExecutor) driver).executeScript("document.getElementById('commenttxt').value = '"+comment+"';");
			//Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("document.getElementById('savcommbtn').click();");

            Thread.sleep(3000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			elmts = elmt.findElements(By.className("list-row"));

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					elmts2.get(1).click();
					break;
				}
			}

			//Thread.sleep(1500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='"+comment+"']")));
			driver.findElement(By.xpath("//div[text()='"+comment+"']"));
			//Thread.sleep(3000);

			etest.log(Status.PASS,"Comment Added for IP is Present");

			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddCommentForIP","ErrorWhileAddingCommentForIP",e);
            System.out.println("Exception while adding comment to IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","AddCommentForIP","ErrorWhileAddingCoomentForIP",e);
            System.out.println("Exception while adding comment to IP in blockedIP settings page : "+e);
			return false;
		}
	}

	//Delete Blocked IP
	public static boolean deleteBlockedIP(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					//Thread.sleep(1000);
					mouseOver(driver, elmts2.get(0));
					//Thread.sleep(1000);
					elmts2.get(0).click();
					//Thread.sleep(1000);
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
					driver.findElement(By.id("okbtn")).click();
					//Thread.sleep(1000);
                    Tab.waitForLoadingSuccessWithBanner(driver,"Deleted successfully","delblockedip.do",etest);
          break;
				}
			}

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			elmt = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			elmts = elmt.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","DeleteBlockedIP","DeletedIPisListed");
					return false;
				}
			}
			etest.log(Status.PASS,"Blocked IP is deleted successfully");

		    return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","DeleteBlockedIP","ErrorWhileDeletingBlockedIP",e);
            System.out.println("Exception while deleting blocked IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","DeleteBlockedIP","ErrorWhileDeletingBlockedIP",e);
            System.out.println("Exception while deleting blocked IP in blockedIP settings page : "+e);
			return false;
		}
	}

	//Unblock IP
	private static boolean unblockIP(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(3).findElements(By.tagName("em"));
					elmts2.get(0).click();
					break;
				}
			}
            if(isIPUnblocked(driver, ip,true))
			{
				etest.log(Status.PASS,"BlockedIP is unblocked successfully");
				return true;
			}
			else
				return false;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","UnBlockIP","ErrorWhileUnblockingIP",e);
            System.out.println("Exception while unblocking blocked IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","UnBlockIP","ErrorWhileUnblockingIP",e);
            System.out.println("Exception while unblocking blocked IP in blockedIP settings page : "+e);
			return false;
		}
	}

    //Check IP blocked or unblocked
    private static boolean isIPUnblocked(WebDriver driver, String ip,boolean screenshot) throws Exception
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
            //Thread.sleep(1000);

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            //Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

            WebElement elmt = driver.findElement(By.id("listview"));
            //Thread.sleep(1000);
            List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            //Thread.sleep(1000);

            for(WebElement welmt:elmts)
            {
                List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
                //Thread.sleep(1000);
                if((elmts1.get(0).getText()).contains(ip))
                {
                    String classname = welmt.getAttribute("class");
                    if(classname.contains("list_disable"))
                    {
                    	if(!screenshot)
                    		TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","CheckIPisBlocked","IPisNotBlocked");
                        return true;
                    }
                }
            }
            if(screenshot){
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","CheckIPisUnBlocked","IPisnotUnblocked");
            }
            return false;
        }
        catch(NoSuchElementException e)
        {
        	if(screenshot)
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","CheckIPisUnBlocked","ErrorWhileCheckingIPisUnBlocked");
            System.out.println("Exception while checking if IP is unblocked in blockedIP settings page : "+e);
            return false;
        }
        catch(Exception e)
        {
        	if(screenshot)
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","CheckIPisUnBlocked","ErrorWhileCheckingIPisUnBlocked");
            System.out.println("Exception while checking if IP is unblocked in blockedIP settings page : "+e);
            return false;
        }

    }

	//Block IP
	private static boolean blockIP(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			//Thread.sleep(1000);

			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
			//Thread.sleep(1000);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			WebElement elmt = driver.findElement(By.id("listview"));
			//Thread.sleep(1000);
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
			//Thread.sleep(1000);

			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				//Thread.sleep(1000);
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(3).findElements(By.tagName("em"));
					elmts2.get(0).click();
					break;
				}
			}

            if(!(isIPUnblocked(driver,ip,false)))
            {
				etest.log(Status.PASS,"Blocking UnBlockedIP is verified");
				return true;
            }
			else
				return false;
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockingUnBlockedIP","ErrorWhileBlockingUnBlockedIP",e);
            System.out.println("Exception while blocking unblocked IP in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Admin","BlockingUnBlockedIP","ErrorWhileBlockingUnBlockedIP",e);
            System.out.println("Exception while blocking unblocked IP in blockedIP settings page : "+e);
			return false;
		}
	}

	public static boolean clearBlockedIPs(WebDriver driver)
	{
		try
		{
			deleteBlockedIP(driver,"15.1.1.1");
            //Thread.sleep(1000);
			deleteBlockedIP(driver,"15.1.1.2");
            //Thread.sleep(1000);
			deleteBlockedIP(driver,"15.1.1.3");
            //Thread.sleep(1000);
			deleteBlockedIP(driver,"15.1.1.4");
            //Thread.sleep(1000);

			return true;
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while clearing blocked IP settings in blockedIP settings page : "+e);
			return false;
		}
		catch(Exception e)
		{
            System.out.println("Exception while clearing blocked IP settings in blockedIP settings page : "+e);
			return false;
		}
	}

	//Mouse over hidden element
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		//Thread.sleep(500);
		new Actions(driver).moveToElement(element).perform();
	}
}
