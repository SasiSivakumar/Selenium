//$Id$
package com.zoho.livedesk.client.WMSBar;
import com.zoho.livedesk.util.Util;
import java.io.File;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.apache.commons.io.FileUtils;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonSikuli;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.zoho.livedesk.util.common.Functions;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.MalformedURLException;
import java.net.URL;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.actions.Tab;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import com.zoho.livedesk.client.AAgentsSettings;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.*;

public class SalesIQWmsBarFunctions
{
	public static String msg;
	public static int count;
	public static int resultcount=0;
	public static int stalei=0;
	public static String portalname=null;
	public static String embedname=null; 
	public static boolean checkBarIcon(WebDriver driver,WebElement icon,String inner_id,String window_id,String procsname)throws Exception
	{	boolean result=false;
		boolean result1=false;
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOf(icon));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Verifying "+procsname+" icon in wmsbar");
			if(icon.findElements(By.className(inner_id)).size()!=0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,procsname+" icon is shown in wmsbar------>Test Passed");
				result=true;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,procsname+" icon is not shown in wmsbar------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Icon",procsname+" icon not shown in wms bar");
			}
			CommonUtil.clickWebElement(driver,icon.findElement(By.className(inner_id)));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Verifying window opening of "+procsname+" in wmsbar");
			if(driver.findElements(By.id(window_id)).size()!=0)
			{
				if(CommonUtil.elfinder(driver,"id",window_id).isDisplayed())
				{
					SalesIQWmsBarTestCases.etest.log(Status.PASS,procsname+" window is opened------>Test Passed");
					result1=true;
				}
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,procsname+" window is not opened------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Icon","Check window");
				
			}
		}
		catch(Exception exp)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Icon","Error "+procsname+" icon check up in wms bar",exp);
		}
		if(result==true && result1==true)
		{
			return true;
		}
		else
			return false;
	}

	public static void checkWMSBarIcons(WebDriver driver,ExtentTest etest) throws Exception
	{
		CommonSikuli.findInWholePage(driver,"UI364.png","UI364",etest);
		CommonSikuli.findInWholePage(driver,"UI365.png","UI365",etest);
		CommonSikuli.findInWholePage(driver,"UI366.png","UI366",etest);
		openMsgBoard(driver);
		CommonSikuli.findInWholePage(driver,"UI367.png","UI367",etest);
		CommonSikuli.findInWholePage(driver,"UI368.png","UI368",etest);
		CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("showsmiley")));
		CommonUtil.sleep(1000);
		CommonSikuli.findInWholePage(driver,"UI369.png","UI369",etest);
		closeMsgBoard(driver);
	}

	public static boolean checkInternalChatHistory(WebDriver driver,String from)
	{
		boolean result=false;
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			if(from.equals("in my profile"))
			{
				openInternalChatHistory(driver);
			}
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Verifying internal chat history "+from);
			if(driver.findElements(By.id("chathistory")).size()!=0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Internal chat history window is opened------>Test Passed");
				result=true;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Internal chat history window is not opened------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Internal chat history");
				result=false;
			}
		}
		catch(Exception exx)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error Checking internal chat history",exx);
		}
		return result;
	}

	public static boolean checkStatusUsername(WebDriver driver) throws Exception
	{	
		try
		{	
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),"Offline","sts-0",ExecuteStatements.getUserName(driver),ConfManager.getRealValue("wmsagent_profilename2"),0);
			getUser2InColleague(driver,0).click();
			//WebElement u2head=CommonUtil.elfinder(driver,"id","LD_2230642505164375131_2641827321");
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Verifying offline status of '"+ConfManager.getRealValue("wmsagent_profilename2")+"' in chat window");
			CommonSikuli.findInWholePage(driver,"UI370.png","UI370",SalesIQWmsBarTestCases.etest);
			if(getu2head(driver).findElements(By.className("sts-0")).size()!=0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Offline status of '"+ConfManager.getRealValue("wmsagent_profilename2")+"' is detected in chat window------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Offline status of '"+ConfManager.getRealValue("wmsagent_profilename2")+"' is not detected in chat window------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Offline status not visible");
			}
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Verifying user name of '"+ConfManager.getRealValue("wmsagent_profilename2")+"' in chat window header");
			if(CommonUtil.elementfinder(driver,getu2head(driver),"id","ctitle").getAttribute("innerHTML").equals(""+ConfManager.getRealValue("wmsagent_profilename2")))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+ExecuteStatements.getUserName(driver)+"'---->User name of '"+ConfManager.getRealValue("wmsagent_profilename2")+"' is detected in chat window header------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+ExecuteStatements.getUserName(driver)+"'---->User name of '"+ConfManager.getRealValue("wmsagent_profilename2")+"' is not detected in chat window header------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","User name not detected");
			}
			sendMsg(driver,getu2head(driver));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Message sent to '"+ConfManager.getRealValue("wmsagent_profilename2")+"'");
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Verifying sent msg in chat window");
			isSentMsgAppended(driver,getu2head(driver));
		}
		catch(Exception ellip)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error Checking offline status in mycolleagues, user name in chat window, offline status in chat window",ellip);
		}
		return checkResult(4);
	}
	public static boolean checkStatusAndNotification(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver1,30,200);
			checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),"Available","sts-1",ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver1),0);
			openNotification(driver1);
			Thread.sleep(1500);
			wait.until(ExpectedConditions.visibilityOf(driver1.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp"))));
			WebElement noti_content=driver1.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp"));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->Verifying notification for presence of 'Unread chats.'");
			if(noti_content.getAttribute("innerText").contains("Unread chats."))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+ExecuteStatements.getUserName(driver1)+"'----> 'You have 1 unread chats.' is present in the notification------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->'You have 1 unread chats.' is not present in the notification------>Test failed");
				TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Notification not have 'you have 1 unread chats'");
			}
			Thread.sleep(1000);
			CommonUtil.elfinder(driver1,"xpath","//div[contains(@class,'unread-infomsg')]//a").click();
			closeNotification(driver1);
			driver1.navigate().refresh();
			driver1.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("maincontainer")));
			openInternalChatHistory(driver1);
			wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver1,"xpath","//span[@class='txtelips' and contains(text(),'"+ExecuteStatements.getUserName(driver)+"')]/../../..")));
			CommonUtil.inViewPort(CommonUtil.elfinder(driver1,"xpath","//span[@class='txtelips' and contains(text(),'"+ExecuteStatements.getUserName(driver)+"')]/../../.."));
			driver1.findElement(By.xpath("//span[@class='txtelips' and contains(text(),'"+ExecuteStatements.getUserName(driver)+"')]/../../..")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rhtcont")));
			Thread.sleep(1000);
			checkMsgInInternalChatHistory(driver1);
		}
		catch(Exception ee)
		{
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error Checking Available status in mycolleagues, unread chat notification and verifying msg in internal chat history",ee);
		}
		
		return checkResult(3);
	}
	public static boolean checkEncagedMsg(WebDriver driver,WebDriver driver1,WebDriver visitordriver) throws Exception
	{
		try
		{
            String WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embedname);

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			Tab.navToPortalTab(driver);
			WebElement concurrent_chat=CommonUtil.elfinder(driver,"id","dmaxconcurrentchat");
			CommonUtil.inViewPort(concurrent_chat);
			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dmaxconcurrentchat"),"xpath",".//em[contains(@class,'sqico-arrow')]").click();
			WebElement first=CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dmaxconcurrentchat"),"xpath","//ul[contains(@class,'ullist') and contains(@id,'maxconcurrentchatdrpdwn0')]//li");
			CommonUtil.inViewPort(first);
			first.click();
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Concurrent chat user limit is changed to 1");
			VisitorWindow.createPage(visitordriver,WIDGET_CODE);
			VisitorWindow.initiateChatVisTheme(visitordriver,"TestCase4","TestCase4@selenium.com","1234","My 1st question?",SalesIQWmsBarTestCases.etest);
			ChatWindow.acceptChat(driver1,SalesIQWmsBarTestCases.etest);
			checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),"Engaged","sts-6",ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver1),0);
		}
		catch(Exception ex)
		{
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error in Setting concurrent chat limit to 1 and check engaged status",ex);
		}
		
		return checkResult(1);
	}
	public static boolean endChatAndCheckStatus(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			ChatWindow.endChat(driver1);
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->Visitor chat Ended");
			ChatWindow.clickClosethisWindow(driver1);
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->Visitor chatwindow closed");
			checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),"Available","sts-1",ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver1),0);
			closeMycolleague(driver);
            
            Tab.navToPortalTab(driver);
            WebElement concurrent_chat=CommonUtil.elfinder(driver,"id","dmaxconcurrentchat");
            CommonUtil.inViewPort(concurrent_chat);
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dmaxconcurrentchat"),"xpath",".//em[contains(@class,'sqico-arrow')]").click();
            WebElement first=CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dmaxconcurrentchat"),"xpath","//ul[contains(@class,'ullist') and contains(@id,'maxconcurrentchatdrpdwn0')]//li[@val='-1']");
            CommonUtil.inViewPort(first);
            first.click();
            SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Concurrent chat operator limit is changed to Unlimited");
		}
		catch(Exception elope)
		{
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error- End chat with visitor and check Available status in colleague window",elope);
		}
		
		return checkResult(1);
	}
	public static boolean changeBusyAndCheck(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver1,30,200);
			changeStatus(driver1,"Available","Busy",ExecuteStatements.getUserName(driver1));
			Thread.sleep(500);
			checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),"Busy","sts-3",ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver1),0);
			closeMycolleague(driver);

		}
		catch(Exception eei)
		{
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error- Checking status Busy",eei);
		}
		
		return checkResult(1);
	}
	public static boolean changeAvailableAndCheck(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver1,30,200);
			changeStatus(driver1,"Busy","Available",ExecuteStatements.getUserName(driver1));
			Thread.sleep(500);
			checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),"Available","sts-1",ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver1),0);

		}
		catch(Exception ee)
		{
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error- Checking status Available",ee);
		}
		
		return checkResult(1);
	}
	public static boolean sendMsgAndCheckTab(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			getUser2InColleague(driver,0).click();
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			sendMsg(driver,getu2head(driver));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'---->Message sent to '"+ExecuteStatements.getUserName(driver1)+"'");
			WebElement u2head_driver1=CommonUtil.elfinder(driver1,"id","h_"+getu2head(driver).getAttribute("id"));
			CommonSikuli.findInWholePage(driver1,"UI371.png","UI371",SalesIQWmsBarTestCases.etest);

			if(u2head_driver1.findElement(By.id("msgcnt")).getAttribute("innerText").equals("1"))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->Message count tab found in WMS_Bar------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->Message count tab not found in WMS_Bar------>Test failed");
				TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Message count tab not found in WMS_Bar");
			}
		}
		catch(Exception x)
		{
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- send message and check tab",x);
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- send message and check tab",x);
		}
		
		return checkResult(1);
	}
	public static boolean replyAndVerify(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver1,30,200);
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			getUser1InColleague(driver1,0).click();
			//WebElement u1head_driver1=CommonUtil.elfinder(driver1,"id","LD_2230642505164375131_2641827321");
			wait.until(ExpectedConditions.visibilityOf(getu1head(driver1)));
			verifyMsg(driver1,getu1head(driver1),ExecuteStatements.getUserName(driver1),ExecuteStatements.getUserName(driver));
			sendMsg(driver,getu1head(driver1));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver1)+"'---->Message sent to '"+ExecuteStatements.getUserName(driver)+"'");
			//WebElement u2head_driver2=CommonUtil.elfinder(driver,"id","LD_2230642505164375131_2641827321");
			waitt.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			verifyMsg(driver,getu2head(driver),ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver1));
			mouseHoverBtn(driver,getu2head(driver),"//a[@id='close' and @title='Close']");
		}
		catch(Exception s)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Verifying received message and sending a message",s);
		}
		
		return checkResult(2);
	}
	public static boolean internalChatHistoryMsgCheck(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{	
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("maincontainer")));
			openInternalChatHistory(driver);
			wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//span[@class='txtelips' and contains(text(),'"+ExecuteStatements.getUserName(driver1)+"')]/../../..")));
			CommonUtil.inViewPort(CommonUtil.elfinder(driver,"xpath","//span[@class='txtelips' and contains(text(),'"+ExecuteStatements.getUserName(driver1)+"')]/../../.."));
			CommonUtil.elfinder(driver,"xpath","//span[@class='txtelips' and contains(text(),'"+ExecuteStatements.getUserName(driver1)+"')]/../../..").click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rhtcont")));
			checkMsgInInternalChatHistory(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Checking messages in internal chat history",e);
		}
		
		return checkResult(1);
	}
	public static boolean openUserAndCheckAction(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOf(getUser2InColleague(driver,0)));
			getUser2InColleague(driver,0).click();
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			WebElement action_btn=getu2head(driver).findElement(By.xpath(".//a[@id='actionico']"));
			wait.until(ExpectedConditions.visibilityOf(action_btn));
			action_btn.click();
			actionDropDown(driver,getu2head(driver),"Add Operator");
			actionDropDown(driver,getu2head(driver),"Print");
			actionDropDown(driver,getu2head(driver),"Share Files");
			actionDropDown(driver,getu2head(driver),"View History");

		}
		catch(Exception o)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button","Error- Checking Action dropdown",o);
		}
		
		return checkResult(4);
	}
	public static boolean checkViewHistoryInAction(WebDriver driver) throws Exception
	{	boolean res=false;
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOf(getUser2InColleague(driver,0)));
			getUser2InColleague(driver,0).click();
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			WebElement action_btn=getu2head(driver).findElement(By.xpath(".//a[@id='actionico']"));
			wait.until(ExpectedConditions.visibilityOf(action_btn));
            Thread.sleep(1500);
			action_btn.click();
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver).findElement(By.xpath("//ul[@id='actiondiv']//a[contains(text(),'View History')]"))));
			getu2head(driver).findElement(By.xpath("//ul[@id='actiondiv']//a[contains(text(),'View History')]")).click();
			res=checkInternalChatHistory(driver,"from Action dropdown");
		}
		catch(Exception act)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button","Error- Checking internal chathistory from action dropdown",act);
		}
		return res;
	}
	public static boolean addUserAndCheckInfo(WebDriver driver,WebDriver driver2) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOf(getUser2InColleague(driver,0)));
			getUser2InColleague(driver,0).click();
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			clickActionAndAddUser(driver,getu2head(driver),""+ExecuteStatements.getUserName(driver2)+"");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'Group Chat')]")));
			checkTitle(driver,"Group Chat",ExecuteStatements.getUserName(driver));
			Thread.sleep(2000);
			WebElement action_btn=getgrouphead(driver).findElement(By.xpath(".//a[@id='actionico']"));
			wait.until(ExpectedConditions.visibilityOf(action_btn));
			action_btn.click();
			if(getgrouphead(driver).findElement(By.xpath("//ul[@id='actiondiv']//a[contains(text(),'View History')]")).isDisplayed())
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"View History present in Action dropdown------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button","View History present");
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"View History not present in Action dropdown------>Test Passed");
				resultcount++;
			}
			actionDropDown(driver,getgrouphead(driver),"Show Members");
			sendMsg(driver,getgrouphead(driver));
		}
		catch(Exception grp)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button","Error- Add operator and check info",grp);
		
		}
		
		return checkResult(3);
	}
	public static boolean checkGroupHeadAndSendMsg(WebDriver driver,WebDriver driver2) throws Exception
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver2,30);
			WebElement grp_wmsbar=CommonUtil.elfinder(driver2,"id","h_"+getgrouphead(driver).getAttribute("id"));
			wait.until(ExpectedConditions.visibilityOf(grp_wmsbar));
			grp_wmsbar.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'Group Chat')]")));
			checkTitle(driver,"Group Chat",ExecuteStatements.getUserName(driver2));
			sendMsg(driver2,getgrouphead(driver2));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver2)+"'---->Message '"+msg+"' sent to group chat");
			mouseHoverBtn(driver2,getgrouphead(driver2),"//a[@id='close' and @title='Close']");
		}
		catch(Exception eg)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckTitle","Error- Check title in chatwindow header and send message",eg);
		}
		
		return checkResult(1);
	}
	public static boolean verifyGrpChatMsg(WebDriver driver,WebDriver driver1,WebDriver driver2) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver1,30,200);
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			// Below 3 line is needed when user2 is newly logged in
			//WebElement grp_wmsbar=CommonUtil.elfinder(driver1,"id","h_"+getgrouphead(driver).getAttribute("id"));
			//wait.until(ExpectedConditions.visibilityOf(grp_wmsbar));
			//grp_wmsbar.click();
			verifyMsg(driver1,getgrouphead(driver1),ExecuteStatements.getUserName(driver1),ExecuteStatements.getUserName(driver2));
			mouseHoverBtn(driver1,getgrouphead(driver1),"//a[@id='close' and @title='Close']");
			verifyMsg(driver,getgrouphead(driver),ExecuteStatements.getUserName(driver),ExecuteStatements.getUserName(driver2));
			mouseHoverBtn(driver,getgrouphead(driver),"//a[@id='close' and @title='Close']");
			openInternalChatHistory(driver);
			CommonUtil.inViewPort(CommonUtil.elfinder(driver,"xpath","//span[@class='txtelips' and contains(text(),'Group Chat')]/../../.."));
			CommonUtil.elfinder(driver,"xpath","//span[@class='txtelips' and contains(text(),'Group Chat')]/../../..").click();
			waitt.until(ExpectedConditions.visibilityOfElementLocated(By.id("rhtcont")));
			checkMsgInInternalChatHistory(driver);
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckTitle","Error- verify group chat messages",e);
		
		}
		
		return checkResult(3);
	}
	public static boolean openMsgBoardAndCheckMinimised(WebDriver driver) throws Exception
	{
		try
		{
			WebElement msghead=getMsgBoardHead(driver);
			CommonUtil.mouseHoverAndClick(driver,getMsgBoardHead(driver).findElement(By.className("hrdr")));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Message board header is clicked by '"+ExecuteStatements.getUserName(driver)+"'");
			Thread.sleep(500);
			if(msghead.getCssValue("display").equals("none"))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Message board window minimised------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Message board window not minimised------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Window not minimised");
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Error- Open and minimise message board",e);
		}
		
		return checkResult(1);
	}
	public static boolean sendAndVerifyInMsgBoard(WebDriver driver,WebDriver driver1,WebDriver driver2) throws Exception
	{
		try
		{
			getMsgBoardHead(driver);
			sendMsg(driver,getMsgBoardHead(driver));
			openMsgBoard(driver1);
			verifyMsg(driver1,getMsgBoardHead(driver1),ExecuteStatements.getUserName(driver1),"Message Board");
			openMsgBoard(driver2);
			verifyMsg(driver2,getMsgBoardHead(driver2),ExecuteStatements.getUserName(driver2),"Message Board");
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Send and verify messages in message board",e);
		
		}
		
		return checkResult(2);
	}
	public static boolean refreshAndCheckMsg(WebDriver driver) throws Exception
	{
		try
		{
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 40);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("maincontainer")));
			WebElement msghead=getMsgBoardHead(driver);
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Verifying messages in message board after refresh");
			if(msghead.findElements(By.xpath(".//div[contains(@class,'nw-mess')]")).size()!=0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Messages present in the message board------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Messages not present in the message board------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Messages not present");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Verifying messages in message board after refresh",e);
		}
		
		return checkResult(1);
	}
	public static boolean openNotificationAndCheckMinimised(WebDriver driver) throws Exception
	{
		try
		{
			WebElement notihead=getNotificationHead(driver);
			CommonUtil.mouseHoverAndClick(driver,getNotificationHead(driver).findElement(By.className("hrdr")));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Notification header is clicked by '"+ExecuteStatements.getUserName(driver)+"'");
			Thread.sleep(500);
			if(notihead.getCssValue("display").equals("none"))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Notification window minimised------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Notification window not minimised------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Window not minimised");
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Error- Open and minimise notification",e);
		}
		
		return checkResult(1);
	}
	public static boolean checkCloseAndMinimiseIcon(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			getUser2InColleague(driver,0).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'----> ChatWindow of '"+ExecuteStatements.getUserName(driver1)+"' is opened");
			mouseHoverBtn(driver,getu2head(driver),".//a[@id='popout']");
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Minimise icon in chatwindow header is clicked by '"+ExecuteStatements.getUserName(driver)+"'");
			String visibility=getu2head(driver).getCssValue("display");
			if(visibility.contains("none"))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Chat window minimised------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Chat window not minimised------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Window not minimised");
			}
			getUser2InColleague(driver,0).click();
			mouseHoverBtn(driver,getu2head(driver),".//a[@id='close' and @title='Close']");
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Close icon in chatwindow header is clicked by '"+ExecuteStatements.getUserName(driver)+"'");
			if(driver.findElements(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'"+ExecuteStatements.getUserName(driver)+"')]/../../..")).size()==0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Chat window closed------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Chat window not closed------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Window not closed");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Error- Check close and minimise icon",e);
		}
		
		return checkResult(2);
	}
	public static boolean checkCloseIconInBottom(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			getUser2InColleague(driver,0).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'----> ChatWindow of '"+ExecuteStatements.getUserName(driver1)+"' is opened");
			String u2bottom_id="h_"+getu2head(driver).getAttribute("id");
			mouseHoverBtn(driver,getu2head(driver),".//a[@id='popout']");
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Chatwindow header is Minimised by '"+ExecuteStatements.getUserName(driver)+"'");
			WebElement u2bottom_driver=CommonUtil.elfinder(driver,"id",u2bottom_id);
			u2bottom_driver.findElement(By.xpath(".//em[contains(@class,'mclgclose')]")).click();
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Close icon in bottom is clicked by '"+ExecuteStatements.getUserName(driver)+"'");
			if(driver.findElements(By.id(u2bottom_id)).size()==0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Minimised chat window closed------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Minimised chat window not closed------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Window not closed");
			}
			

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Error- Check close icon in bottom",e);
		}
		
		return checkResult(1);
	}
	public static boolean clickWindowHeaderAndCheck(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			getUser2InColleague(driver,0).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(getu2head(driver)));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+ExecuteStatements.getUserName(driver)+"'----> ChatWindow of '"+ExecuteStatements.getUserName(driver1)+"' is opened");
			String u2bottom_id="h_"+getu2head(driver).getAttribute("id");
			CommonUtil.mouseHoverAndClick(driver,getu2head(driver).findElement(By.className("cname")));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Chat window header is clicked by '"+ExecuteStatements.getUserName(driver)+"'");
			String visibility=getu2head(driver).getCssValue("display");
			if(visibility.contains("none"))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Chat window minimised------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Chat window not minimised------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Window not minimised");
			}
			WebElement u2bottom_driver=CommonUtil.elfinder(driver,"id",u2bottom_id);
			u2bottom_driver.findElement(By.xpath(".//em[contains(@class,'mclgclose')]")).click();

		}
		catch(Exception e)
		{
			
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Error- Click chat window header and check if it is minimised",e);
		
		}
		
		return checkResult(1);
	}
	public static boolean missChatAndCheckNotification(WebDriver driver,WebDriver visitordriver) throws Exception
	{
		try
		{
            String WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embedname);


			VisitorWindow.createPage(visitordriver,WIDGET_CODE);
			VisitorWindow.initiateChatVisTheme(visitordriver,"misschat","TestCase@selenium.com","1234","My 1st question?",SalesIQWmsBarTestCases.etest);
			VisitorWindow.waitTillChatisMissedInTheme(visitordriver);
			//visitordriver.switchTo().frame((visitordriver.findElement(By.id("zlsiframe"))));
			// FluentWait wait = new FluentWait(driver);
			// wait.withTimeout(75,TimeUnit.SECONDS);
			// wait.pollingEvery(500, TimeUnit.MILLISECONDS);
			// wait.ignoring(NoSuchElementException.class);
			// wait.until(new Function<WebDriver,Boolean>(){
	  //               public Boolean apply(WebDriver driver)
	  //               {	
	                	
	  //               	try
	  //               	{	
			// 				if(visitordriver.findElement(By.id("missmsg")).getText().contains("Sorry"))
	  //                   	{
	  //                       	return true;
	  //                   	}
	  //                   	else
	  //                   	{
	  //                   		return false;
	  //                   	}
	  //                   }
	  //                   catch(Exception e)
	  //                   {
	   
	  //                   	return false;
	  //                   }
	  //               }
	  //           });
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Chat missed");
			openNotification(driver);
			checkNotificationContent(driver,"Your team has 1 unassigned visitors.",ExecuteStatements.getUserName(driver));

			CommonSikuli.findInWholePage(driver,"UI372.png","UI372",SalesIQWmsBarTestCases.etest);

			CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'unread-infomsg')]//a").click();
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckIcon","Error- Miss a chat and check in notifications",e);
		}
		
		return checkResult(1);
	}
	public static boolean assignChatAndCheckNotification(WebDriver driver,WebDriver driver1) throws Exception
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			WebElement missedchat_head=CommonUtil.elfinder(driver,"id","missed_mcontent");
			wait.until(ExpectedConditions.visibilityOf(missedchat_head.findElement(By.className("cursr-point"))));
			missedchat_head.findElement(By.className("cursr-point")).findElement(By.xpath(".//div[@id='linkdiv']")).click();
			wait.until(ExpectedConditions.visibilityOf(missedchat_head.findElement(By.className("mractionmn"))));
			missedchat_head.findElement(By.className("mractionmn")).findElement(By.xpath(".//a[contains(text(),'"+ExecuteStatements.getUserName(driver1)+"')]")).click();
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Missed visitor is assigned to'"+ExecuteStatements.getUserName(driver1)+"'");
			closeNotification(driver);
			closeNotification(driver1);
			openNotification(driver);
			openNotification(driver1);
			checkNotificationContent(driver,"Unread chats & missed visitor notifications will be displayed here",ExecuteStatements.getUserName(driver),0);
			checkNotificationContent(driver1,"You have 1 Missed visitors.",ExecuteStatements.getUserName(driver1));
			closeNotification(driver);
			closeNotification(driver1);
			
		}
		catch(Exception e)
		{
			
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","MissChat","Error- Assign missed chat to operator and check notifications",e);
		}
		
		return checkResult(2);
	}
	public static boolean closeMissedChatAndCheckNotification(WebDriver driver1) throws Exception
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver1, 20);
			openNotification(driver1);
			CommonUtil.elfinder(driver1,"xpath","//div[contains(@class,'unread-infomsg')]//a").click();
			WebElement missedchat_head=CommonUtil.elfinder(driver1,"id","missed_mcontent");
			wait.until(ExpectedConditions.visibilityOf(missedchat_head.findElement(By.className("cursr-point"))));
			missedchat_head.findElement(By.className("cursr-point")).click();
			wait.until(ExpectedConditions.visibilityOf(missedchat_head.findElement(By.id("zsmaincontainer"))));
			CommonUtil.elementfinder(driver1,CommonUtil.elfinder(driver1,"id","missed_div"),"xpath",".//span[@id='closebtn']").click();
			wait.until(ExpectedConditions.visibilityOf(driver1.findElement(By.xpath("//div[@id='popupdiv']//span[@id='okbtn']"))));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Missed visitor closed by '"+ExecuteStatements.getUserName(driver1)+"'");
			driver1.findElement(By.xpath("//div[@id='popupdiv']//span[@id='okbtn']")).click();
			closeNotification(driver1);
			openNotification(driver1);
			Thread.sleep(1000);
			checkNotificationContent(driver1,"Unread chats & missed visitor notifications will be displayed here",ExecuteStatements.getUserName(driver1),0);
		}
		catch(Exception e)
		{
			
			TakeScreenshot.screenshot(driver1,SalesIQWmsBarTestCases.etest,"SalesiqBar","MissChat","Error- Close assigned missed chat and check in notifications",e);
		
		}
		return checkResult(1);
	}
	public static void checkNotificationContent(WebDriver driver,String infomsg,String username) throws Exception
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp"))));
			WebElement noti_content=driver.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp"));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+username+"'----> Checking '"+infomsg+"' message in notification");
			if(noti_content.getAttribute("innerText").contains(infomsg))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+username+"'----> '"+infomsg+"' is present in the notification------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+username+"'----> '"+infomsg+"' is not present in the notification------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","checkNotification","'"+infomsg+"' info message is not present");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","checkNotification","Error- Check notification for "+infomsg,e);
		}
	}
	public static void checkNotificationContent(WebDriver driver,String infomsg,String username,int i) throws Exception
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp"))));
			WebElement noti_content=driver.findElement(By.id("offlinemsg")).findElement(By.id("msgdisp"));
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+username+"'----> Checking '"+infomsg+"' message in notification");
			if(noti_content.getAttribute("innerText").contains(infomsg))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+username+"'----> '"+infomsg+"' is present in the notification------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+username+"'---->'"+infomsg+"' is not present in the notification------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","checkNotification","'"+infomsg+"' is not present");
			}
		}
		catch(Exception e)
		{
			if(i < 4)
			{
				checkNotificationContent(driver,"Unread chats & missed visitor notifications will be displayed here",username,i+1);
			}
			else
			{
				
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","checkNotification","Error- Check notification for "+infomsg,e);
			}
		}
			//e.printStackTrace();
			//TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","checkNotification","Check notification for "+infomsg,e);
	}
	public static void mouseHoverBtn(WebDriver driver,WebElement user,String xpathExpression) throws Exception
 	{
		 try
		 {
			Actions actions = new Actions(driver);
			WebDriverWait wait = new WebDriverWait(driver, 20);  
			Thread.sleep(1000);
			actions.moveToElement(user.findElement(By.className("cname")));
			actions.moveToElement(user.findElement(By.className("cname"))).perform();
			actions.moveToElement(user.findElement(By.xpath(xpathExpression)));
			//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathExpression)));
			actions.moveToElement(user.findElement(By.xpath(xpathExpression))).click().perform();
		 }
		 catch(Exception e)
		 {
		 System.out.println("Exception in mouse hoverbtn click");
		 e.printStackTrace();
		 }
	}
	public static void checkTitle(WebDriver driver,String title,String account) throws Exception
	{
		try
		{
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+account+"'---->Verifying Group chat title");
			if(driver.findElements(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'"+title+"')]")).size()!=0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+account+"'----> Chat title is "+title+"------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+account+"'----> Chat title is not "+title+"------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","TitleCheck","Error- Chat title mismatch");
			}
		}
		catch(Exception t)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","TitleCheck","Error- Checking title",t);
		}
	}
	public static void clickActionAndAddUser(WebDriver driver,WebElement user,String username) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			WebElement action_btn=getu2head(driver).findElement(By.xpath(".//a[@id='actionico']"));
			wait.until(ExpectedConditions.visibilityOf(action_btn));
			action_btn.click();
			WebElement add_user=CommonUtil.elfinder(driver,"xpath","//ul[@id='actiondiv']//a[contains(text(),'Add Operator')]");
			wait.until(ExpectedConditions.visibilityOf(add_user));
			add_user.click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addtxt")));
			Thread.sleep(1000);
			CommonUtil.elementfinder(driver,user,"id","addtxt").sendKeys(username);
			Thread.sleep(500);
            TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","AddUser","Before",0);
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,user,"id","mlist"),"tagname","li").click();
            Thread.sleep(1000);
            TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","AddUser","After",0);
        }
		catch(Exception add)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button","Error- Add Operator in action dropdown",add);
		}
	}
	public static void actionDropDown(WebDriver driver,WebElement user,String text) throws Exception
	{
		try
		{	
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Verifing "+text+" in Action dropdown");
			if(user.findElements(By.xpath("//ul[@id='actiondiv']//a[contains(text(),'"+text+"')]")).size()!=0)
			{
				if(user.findElement(By.xpath("//ul[@id='actiondiv']//a[contains(text(),'"+text+"')]")).isDisplayed())
				{
					SalesIQWmsBarTestCases.etest.log(Status.PASS,""+text+" present in Action dropdown------>Test Passed");
					resultcount++;
				}
				else
				{
					SalesIQWmsBarTestCases.etest.log(Status.FAIL,""+text+" not present in Action dropdown------>Test failed");
					TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button",""+text+" not present in the Action dropdown");
				}
			}
			else if(user.findElements(By.xpath(".//span[contains(text(),'"+text+"')]")).size()!=0)
			{
				if(user.findElement(By.xpath(".//span[contains(text(),'"+text+"')]")).isDisplayed())
				{	
					SalesIQWmsBarTestCases.etest.log(Status.PASS,""+text+" present in Action dropdown------>Test Passed");
					resultcount++;
				}
				else
				{
					SalesIQWmsBarTestCases.etest.log(Status.FAIL,""+text+" not present in Action dropdown------>Test failed");
					TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button",""+text+" not present in the Action dropdown");
				}
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,""+text+" not present in Action dropdown------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button",""+text+" not present in the Action dropdown");
			}
		}
		catch(Exception a)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Action-button","Checking "+text+" in Action dropdown",a);
		}
	}
	public static void verifyMsg(WebDriver driver,WebElement user,String username,String username2) throws Exception
	{
		try
		{	
			String received;
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			waitt.until(ExpectedConditions.visibilityOf(user));
			Thread.sleep(2000);
			List<WebElement> list=user.findElements(By.xpath(".//div[contains(@class,'appenmess')]"));
			int count=list.size();
			if(count!=0)
			{
				received=list.get(count-1).getAttribute("innerHTML");
			}
			else
			{
				received="null";
			}
			
			if(user.findElements(By.xpath(".//div[contains(@class,'nw-mess') and contains( text(),'"+msg+"')]")).size()!=0 || msg.equals(received))
			{
				SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+username+"'----> Message ("+msg+") received from '"+username2+"'");
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Message received Successfully on user '"+username+"'----> Test passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Message not received Successfully on user '"+username+"'----> Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","VerifyMsg","Message not received Successfully on user '"+username+"'");
			}
		}
		catch(Exception ep)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","VerifyMsg","Verifying received message with sent message",ep);
		}	
	}
	public static void changeStatus(WebDriver driver,String stasname,String tostatus,String account) throws Exception
	{
		try
		{
			// FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdrdrpdwntop")));
			// CommonUtil.elfinder(driver,"id","hdrdrpdwntop").click();
			// wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//ul[contains(@id,'hdrdrpdwn')]//a[contains(text(),'"+stasname+"')]")));
			// //CommonUtil.elfinder(driver,"xpath","//ul[contains(@id,'hdrdrpdwn')]//a[contains(text(),'"+stasname+"')]").click();
			// if(driver.findElements(By.xpath("//ul[contains(@id,'hdrdrpdwn')]//a[contains(text(),'"+stasname+"')]")).size()!=0)
			// {
			// 	CommonUtil.elfinder(driver,"xpath","//ul[contains(@id,'hdrdrpdwn')]//a[contains(text(),'"+stasname+"')]").click();
			// 	SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+account+"'---->Status changed from "+stasname+" to "+tostatus+"");
			
			// }

			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,tostatus.toLowerCase(),SalesIQWmsBarTestCases.etest);
		}
		catch(Exception ei)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","ChangeStatus","Error- Changing status to "+stasname+" ",ei);
		}
	}
	public static void checkMsgInInternalChatHistory(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rhtcont")));
			Thread.sleep(2000);
			List<WebElement> li=driver.findElements(By.xpath("//div[contains(@class,'myclgsts-submn ')]"));
			int count=li.size();
			WebElement element=driver.findElements(By.xpath("//div[contains(@class,'myclgsts-submn ')]")).get(count-1);
			CommonUtil.inViewPort(element);
			if(driver.findElements(By.xpath("//div[contains(@class,'myclgsts-submn ')]")).get(li.size()-1).findElement(By.className("myclgsts-cntin")).getAttribute("innerHTML").equals(msg))
			//if(driver.findElements(By.xpath("//div[contains(@class,'myclgsts-cntin')][contains(text,'"+msg+"')]")).size()!=0)
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Message '"+msg+"' is present in Internal chat history------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Message '"+msg+"' is not present in Internal chat history------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Expected message not detected");
			}
		}
		catch(Exception ellx)
		{
		
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Checking message in internal chat history",ellx);
		}
	}
	
	public static void checkStatusInColleagueWindow(WebDriver driver,WebElement user,String status,String classname,String u1,String u2,int i)throws Exception
	{	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
		try
		{
			Thread.sleep(2000);
			openMycolleague(driver);
			Thread.sleep(4000);
			//FluentWaitFunc(driver,user,classname);
			SalesIQWmsBarTestCases.etest.log(Status.INFO,"Account '"+u1+"'---->Verifying "+status+" status of '"+u2+"' in mycolleagues window");
			if(getStatusInColleagueWindow(driver,user).equals(classname))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Account '"+u1+"'---->"+status+" status of '"+u2+"' is detected in mycolleagues window------>Test Passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Account '"+u1+"'---->"+status+" status of '"+u2+"' is not detected in mycolleagues window------>Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Status "+status+" is not detected");
			}
			closeMycolleague(driver);
		}
		catch(Exception elop)
		{
			if(i < 3)
			{
				closeMycolleague(driver);
				openMycolleague(driver);
				wait.until(ExpectedConditions.visibilityOf(getUser2InColleague(driver,0)));
				checkStatusInColleagueWindow(driver,getUser2InColleague(driver,0),status,classname,u1,u2,i+1);
			}
			else
			{
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Checkstatus","Error- Checking "+status+" status",elop);
			}
		}
	}
	public static void FluentWaitFunc(final WebDriver driver,final WebElement user,final String status) throws Exception
	{
		try
		{
		
		FluentWait wait = new FluentWait(driver);
		wait.withTimeout(20,TimeUnit.SECONDS);
		wait.pollingEvery(500, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {	
                	try
                	{
                    	if(getStatusInColleagueWindow(driver,user).equals(status))
                    	{
                        	return true;
                    	}
                    	return false;
                    }
                    catch(Exception e)
                    {
                    	return false;
                    }
                }
            });
		}
		catch(Exception flu)
		{
			flu.printStackTrace();
		}
	}
	
	public static void openInternalChatHistory(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOf(getMyProfile(driver)));
			getMyProfile(driver).click();
			wait.until(ExpectedConditions.visibilityOf(getUserChatHistory(driver)));
			getUserChatHistory(driver).click();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public static void isSentMsgAppended(WebDriver driver,WebElement user) throws Exception
	{
		try
		{
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(user));
			Thread.sleep(2000);
			List<WebElement> list=user.findElements(By.xpath(".//div[contains(@class,'appenmess')]"));
			String appendedmsg;
			int count=list.size();
			if(count!=0)
			{
				appendedmsg=list.get(count-1).getAttribute("innerHTML");
			}
			else
			{
				appendedmsg="null";
			}
			//String appendedmsg=list.get(count-1).getAttribute("innerHTML");
			if(user.findElements(By.xpath(".//div[contains(@class,'nw-mess') and contains( text(),'"+msg+"')]")).size()!=0 || SalesIQWmsBarFunctions.msg.equals(appendedmsg))
			{
				SalesIQWmsBarTestCases.etest.log(Status.PASS,"Sent message appended successfully in chat window----> Test passed");
				resultcount++;
			}
			else
			{
				SalesIQWmsBarTestCases.etest.log(Status.FAIL,"Sent message not appended successfully in chat window----> Test failed");
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Messages not appended");
			}
			//closeChatWindow(driver,user);
		}
		catch(Exception ee)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Checking sent message in chat window",ee);
		}
	}
	public static void sendMsg(WebDriver driver,WebElement user) throws Exception
	{
		msg=Datefunc();
		try
		{	
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			wait.until(ExpectedConditions.visibilityOf(user));
			getTextarea(driver,user).sendKeys(msg);
			Thread.sleep(2000);
			getTextarea(driver,user).sendKeys(Keys.ENTER);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		catch(Exception elp)
		{
			TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","CheckMsg","Error- Sending message",elp);
		}
	}
	public static void openMycolleague(WebDriver driver) throws Exception
	{
		try
		{	
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(getMyCollegue(driver)));
			if(getMyCollegue(driver).getAttribute("class").equals("myclgmbr"))
			{
				getMyCollegue(driver).click();
			}
		}
		catch(Exception ell)
		{
			ell.printStackTrace();
		}
	}
	public static void openMsgBoard(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(getMsgBoard(driver)));
			if(getMsgBoard(driver).getAttribute("class").equals("msgboard"))
			{
				getMsgBoard(driver).click();
			}
		}
		catch(Exception ell)
		{
			ell.printStackTrace();
		}
	}
	public static void closeMsgBoard(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(getMsgBoard(driver)));
			if(getMsgBoard(driver).getAttribute("class").equals("msgboard"))
			{
			}
			else
			{
				getMsgBoard(driver).click();
			}
		}
		catch(Exception ell)
		{
			ell.printStackTrace();
		}
	}
	public static void closeMycolleague(WebDriver driver) throws Exception
	{
		try
		{	
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(getMyCollegue(driver)));
			if(getMyCollegue(driver).getAttribute("class").equals("myclgmbr"))
			{
				
			}
			else
			{
				getMyCollegue(driver).click();
			}
		}
		catch(Exception ell1)
		{
			ell1.printStackTrace();
		}
	}
	public static void openNotification(WebDriver driver) throws Exception
	{
		try
		{	
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(getNotification(driver)));
			if(getNotification(driver).getAttribute("class").equals("notfy"))
			{
				getNotification(driver).click();
			}
		}
		catch(Exception ell)
		{
			ell.printStackTrace();
		}
	}
	public static void closeNotification(WebDriver driver) throws Exception
	{
		try
		{	
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(getNotification(driver)));
			if(getNotification(driver).getAttribute("class").equals("notfy"))
			{
				
			}
			else
			{
				getNotification(driver).click();
			}
		}
		catch(Exception ell)
		{
			ell.printStackTrace();
		}
	}
	public static void closeChatWindow(WebDriver driver,WebElement user) throws Exception
	{
		try
		{
			//user.click();
			AAgentsSettings.mouseOver(driver,user);
			CommonUtil.elementfinder(driver,user,"id","close").click();
		}
		catch(Exception es)
		{
			es.printStackTrace();
		}
	}
	public static String Datefunc() throws Exception
    {
    	Date date = new Date();
    	String currenttime=date.toString();
    	return currenttime;
    }

	public static WebElement getMyCollegue(WebDriver driver) throws Exception
	{	
		try
		{
			return CommonUtil.elfinder(driver,"id","h_mycolleagues");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public static WebElement getMsgBoard(WebDriver driver) throws Exception
	{	
		try
		{
			return CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'msgboard') or contains(@class,'msgboard-sel')]");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public static WebElement getMsgBoardHead(WebDriver driver) throws Exception
	{
		openMsgBoard(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'Message Board')]/../../.."))));
		return driver.findElement(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'Message Board')]/../../.."));
	}
	public static WebElement getNotificationHead(WebDriver driver) throws Exception
	{
		openNotification(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
		wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"id","offlinemsg")));
		return CommonUtil.elfinder(driver,"id","offlinemsg");
	}

	public static WebElement getNotification(WebDriver driver) throws Exception
	{	
		try
		{
			return CommonUtil.elfinder(driver,"id","h_offlinemsg");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public static WebElement getMyProfile(WebDriver driver) throws Exception
	{	
		try
		{
			return CommonUtil.elfinder(driver,"id","menu_user");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public static WebElement getUserChatHistory(WebDriver driver) throws Exception
	{	
		try
		{
			return CommonUtil.elfinder(driver,"id","user_sm_chathistory");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public static WebElement getUser1InColleague(WebDriver driver,int i) throws Exception
	{	
		try
		{
			openMycolleague(driver);
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'suprepmn') and contains(@title,'"+ConfManager.getRealValue("wmsagent_profilename1")+"')]")));
			return CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'suprepmn') and contains(@title,'"+ConfManager.getRealValue("wmsagent_profilename1")+"')]");
		}
		catch(Exception ex)
		{	
			if(i<4)
			{
				closeMycolleague(driver);
				return getUser1InColleague(driver,i+1);
			}
			else
			{
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Mycolleagues","Error get user 1 in colleague window",ex);
				return null;
			}
		}
	}
	public static WebElement getUser2InColleague(WebDriver driver,int i) throws Exception
	{
		try
		{
			openMycolleague(driver);
			FluentWait waitt = CommonUtil.waitreturner(driver,30,200);
			waitt.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(@class,'suprepmn') and contains(@title,'"+ConfManager.getRealValue("wmsagent_profilename2")+"')]"))));
			return driver.findElement(By.xpath("//div[contains(@class,'suprepmn') and contains(@title,'"+ConfManager.getRealValue("wmsagent_profilename2")+"')]"));
		
		}
		catch(Exception ex)
		{	
			if(i<4)
			{
				closeMycolleague(driver);
				return getUser2InColleague(driver,i+1);
			}
			else
			{
				TakeScreenshot.screenshot(driver,SalesIQWmsBarTestCases.etest,"SalesiqBar","Mycolleagues","Error get user 2 in colleague window",ex);
				return null;
			}
		}
	}
	public static WebElement getu1head(WebDriver driver) throws Exception
	{
		return driver.findElement(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'"+ConfManager.getRealValue("wmsagent_profilename1")+"')]/../../.."));
	}
	public static WebElement getu2head(WebDriver driver) throws Exception
	{
		return driver.findElement(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'"+ConfManager.getRealValue("wmsagent_profilename2").substring(0,10)+"')]/../../.."));
	}
	public static WebElement getgrouphead(WebDriver driver) throws Exception
	{
		return driver.findElement(By.xpath("//div[contains(@id,'ctitle') and contains(text(),'Group Chat')]/../../.."));
	}
	public static String getStatusInColleagueWindow(WebDriver driver,WebElement user) throws Exception
	{
		 return getStatusInColleagueWindow(driver,user,0);
	}
	public static String getStatusInColleagueWindow(WebDriver driver,WebElement user,int i) throws Exception
	{
		try
		{
			Thread.sleep(2000);
			return CommonUtil.elementfinder(driver,user,"tagname","span").getAttribute("class");
		}
		catch(Exception e)
		{
			// if(i < 1)
			// {
			// 	return getStatusInColleagueWindow(driver,user,i+1);
			// }
			// else
			// {
				throw e;
			//}
		}
		
	}
	public static WebElement getTextarea(WebDriver driver,WebElement user) throws Exception
	{
		return CommonUtil.elementfinder(driver,user,"xpath",".//textarea[contains(@id,'editor')]");
	}
	public static void closeBannersAfterLogin(WebDriver driver) throws Exception
    {
    	Functions.closeBannersAfterLogin(driver);
    }
	public static boolean checkResult(int i) throws Exception
	{
		if(resultcount==i)
		{
			resultcount=0;
			return true;
		}
		else
		{
			resultcount=0;
			return false;
		}
	}
}
