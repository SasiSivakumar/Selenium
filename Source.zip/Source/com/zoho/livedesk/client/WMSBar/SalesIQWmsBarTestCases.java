//$Id$
package com.zoho.livedesk.client.WMSBar;
import com.zoho.livedesk.util.Util;
import java.io.File;
import java.util.List;
import java.util.Arrays;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.net.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import java.util.Date;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class SalesIQWmsBarTestCases {
	public static WebDriver driver;
	public static WebDriver driver2;
	public static WebDriver driver3;

	public static WebDriver visitordriver;
	public static String currenttime;
	public static ExtentReports extent;
	public static ExtentTest etest;
	public static Hashtable result;
	static int count=0;
	static Hashtable hashtable=new Hashtable();
	public static Hashtable test(WebDriver driver1) throws Exception
	{
		try
		{
			result=new Hashtable();

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB1"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            SalesIQWmsBarFunctions.portalname=ExecuteStatements.getPortal(driver1);
            SalesIQWmsBarFunctions.embedname=ExecuteStatements.getDefaultEmbedName(driver1);

            SalesIQWmsBarFunctions.checkWMSBarIcons(driver1,etest);
            result.put("WB1",SalesIQWmsBarFunctions.checkBarIcon(driver1,SalesIQWmsBarFunctions.getMyCollegue(driver1),"sqico-collegue","mycolleagues","Mycolleagues"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB2"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB2",SalesIQWmsBarFunctions.checkBarIcon(driver1,SalesIQWmsBarFunctions.getMsgBoard(driver1),"sqico-msgboard",SalesIQWmsBarFunctions.getMsgBoard(driver1).getAttribute("id").substring(2),"Message Board"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB3"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB3",SalesIQWmsBarFunctions.checkBarIcon(driver1,SalesIQWmsBarFunctions.getNotification(driver1),"sqico-notify","offlinemsg","Notification"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB4"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB4",SalesIQWmsBarFunctions.checkInternalChatHistory(driver1,"in my profile"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB5"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB5",SalesIQWmsBarFunctions.checkStatusUsername(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB6"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            driver2=Functions.setUp();
			if(!(Functions.login(driver2,"wmsagent2")))
			{
				result.put("WB1",false);
				hashtable.put("result", result);
				hashtable.put("servicedown", new Hashtable());
				return hashtable;
			}

            Thread.sleep(10000);
            result.put("WB6",SalesIQWmsBarFunctions.checkStatusAndNotification(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB7"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            visitordriver=Functions.setUp();
            result.put("WB7",SalesIQWmsBarFunctions.checkEncagedMsg(driver1,driver2,visitordriver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB8"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB8",SalesIQWmsBarFunctions.endChatAndCheckStatus(driver1,driver2));
        	visitordriver.quit();
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB9"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB9",SalesIQWmsBarFunctions.changeBusyAndCheck(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB10"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB10",SalesIQWmsBarFunctions.changeAvailableAndCheck(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB11"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            result.put("WB11",SalesIQWmsBarFunctions.sendMsgAndCheckTab(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB12"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB12",SalesIQWmsBarFunctions.replyAndVerify(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB13"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB13",SalesIQWmsBarFunctions.internalChatHistoryMsgCheck(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB14"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB14",SalesIQWmsBarFunctions.openUserAndCheckAction(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB15"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB15",SalesIQWmsBarFunctions.checkViewHistoryInAction(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB16"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            driver3=Functions.setUp();
			if(!(Functions.login(driver3,"wmsagent3")))
			{
				result.put("WB1",false);
				hashtable.put("result", result);
				hashtable.put("servicedown", new Hashtable());
				return hashtable;
			}
        	result.put("WB16",SalesIQWmsBarFunctions.addUserAndCheckInfo(driver1,driver3));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB17"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB17",SalesIQWmsBarFunctions.checkGroupHeadAndSendMsg(driver1,driver3));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB18"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB18",SalesIQWmsBarFunctions.verifyGrpChatMsg(driver1,driver2,driver3));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB19"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB19",SalesIQWmsBarFunctions.openMsgBoardAndCheckMinimised(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB20"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB20",SalesIQWmsBarFunctions.sendAndVerifyInMsgBoard(driver1,driver2,driver3));

			Functions.logout(driver3);

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB21"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB21",SalesIQWmsBarFunctions.refreshAndCheckMsg(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB22"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB22",SalesIQWmsBarFunctions.openNotificationAndCheckMinimised(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB23"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB23",SalesIQWmsBarFunctions.checkCloseAndMinimiseIcon(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB24"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB24",SalesIQWmsBarFunctions.checkCloseIconInBottom(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB25"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB25",SalesIQWmsBarFunctions.clickWindowHeaderAndCheck(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB26"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            visitordriver=Functions.setUp();
        	result.put("WB26",SalesIQWmsBarFunctions.missChatAndCheckNotification(driver1,visitordriver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB27"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

            visitordriver.quit();
        	result.put("WB27",SalesIQWmsBarFunctions.assignChatAndCheckNotification(driver1,driver2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WB28"));
            ComplexReportFactory.setValues(etest,"Automation","Salesiq Bar");

        	result.put("WB28",SalesIQWmsBarFunctions.closeMissedChatAndCheckNotification(driver2));
  			Functions.logout(driver2);

            ComplexReportFactory.closeTest(etest);
		}
		catch(Exception ex)
		{
			result.put("WB1",false);
			System.out.println("Exception occured in wmsbar testing");
			etest.log(Status.FATAL,"Module breakage occurred "+ex);
            System.out.println("~~Module breakage occurred");
            ex.printStackTrace();
			etest.log(Status.FAIL,"Error:"+ex.toString());
		}

        ComplexReportFactory.closeTest(etest);
		hashtable.put("result", result);
        hashtable.put("servicedown", new Hashtable());
		return hashtable;
	}
}
