//$Id$
package com.zoho.livedesk.client.Templates;

import java.util.List;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.Articles;
import com.zoho.livedesk.util.common.actions.ChatHistory;
import com.zoho.livedesk.util.common.actions.EmailTemplates;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.ArticlesVisitorSide;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

public class EmailTemplateTests
{
	public static Hashtable finalResult = new Hashtable();
	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;

	public static final By
	SEND_BUTTON = By.id("sendbtn"),
	SUBJECT_CONTAINER = By.id("txtarea_wrapper"),
	CONTENT_CONTAINER = By.id("articlewrap"),
	SORT_ARROW = By.className("sqico-toparrow"),
	BOLD_ICON = By.className("zei-bold"),
	ITALICS_ICON = By.className("zei-italic"),
	UNDERLINE_ICON = By.className("zei-underline"),
	STRIKETHROUGH_ICON = By.className("zei-strike"),
	HORIZONTAL_LINE_ICON = By.className("zei-line"),
	FONT_ICON = By.className("zeFFce"),
	LIST_ORDER = By.xpath("//*[@id='ext-editor']/div/div[1]/ul[5]/li[2]/b/span[@class='zei-arrow']"),
	ALIGN_ICON = By.xpath("//*[@id='ext-editor']/div/div[1]/ul[5]/li[1]/b/span[@class='zei-arrow']"),
	INCREASE_INDENT_ICON = By.className("zei-indent"),
	DECREASE_INDENT_ICON = By.className("zei-outdent"),
	TEXT_COLOR = By.className("zei-textclr"),
	TEXT_BACKGROUND_COLOR = By.className("zei-bgclr"),
	QUOTE_ICON = By.className("zei-quote"),
	TABLE_ICON = By.className("zei-table"),
	INSERT_CODE_ICON = By.className("zei-html"),
	FONT_SIZE_ARROW = By.xpath("//*[@id='ext-editor']/div/div[1]/ul[3]/li/b/span[@class='zei-arrow']")
	;

	public static final String
	COURIER_NEW_FONT = "Courier New",
	COURIER_NEW_FONT_STYLE = "font-family: \"courier new\", courier, monospace, sans-serif !important;",
	INCREASE_INDENT = "Increase Indent",
	BULLETS = "Bullets",
	NUMBERING = "Numbering",
	LEFT_ALIGN = "Align Left",
	RIGHT_ALIGN = "Align Right",
	JUSTIFY_ALIGN = "Justify",
	CENTER_ALIGN = "Center",
	DECREASE_INDENT = "Decrease Indent",
	FONT_COLOR = "color: rgb(255, 0, 0) !important",
	FONT_BACKGROUND = "background-color: rgb(254, 255, 0)",
	MODULE_NAME = "Email Templates",
	ORGANISATION = "0",
	DEPARTMENT = "1",
	OPERATOR = "2"
	;

	public static String 
	widgetCode = "",
	template1 = ""
	;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

            widgetCode = ExecuteStatements.getWidgetCode(driver);

            etest = ComplexReportFactory.getTest("Check Email Templates Tab");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmailTemplatesTab(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Email Templates Empty State");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkEmptyState(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Email Template content in mail sent");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkContentInSentMail(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check email template was added when subject alone was given");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ET4",checkEmailTemplatesAdded(driver,etest,true,false,true));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check email template was not added when content alone was given");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ET5",checkEmailTemplatesAdded(driver,etest,false,true,true));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Templates not added clicking cancel");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ET6",checkEmailTemplatesAdded(driver,etest,true,false,false));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check email template was added");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ET7",checkEmailTemplatesAdded(driver,etest,true,true,true));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check formatting otions in Email Template");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkFormattingOptions(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check enable Email Template");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ET10",checkEnableEmailTemplate(driver,etest,true));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check disable Email Template");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ET11",checkEnableEmailTemplate(driver,etest,false));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check deleting an Email Template");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkDeleteEmailTemplate(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Templates option not shown when there is no email template");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkTemplatesOptionShown(driver,etest,false,18);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Templates shown while sending email");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkTemplatesOptionShown(driver,etest,true,14);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Dynamic Text Suggestions Displayed");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkDynamicTextSuggestionsDisplayed(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Dynamic Text Suggestions");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkDynamicTextSuggestions(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check edit email template");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkEditEmailTemplate(driver,etest);
            ComplexReportFactory.closeTest(etest);	

            WebDriver supervisorDriver = Functions.setUp();
            WebDriver associateDriver = Functions.setUp();

            Functions.login(supervisorDriver,"template_supervisor");
            Functions.login(associateDriver,"template_associate");

            etest = ComplexReportFactory.getTest("Check email template visible to department");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkEmailTemplateVisible(driver,supervisorDriver,associateDriver,etest,DEPARTMENT);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check email template visible to operator who created");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkEmailTemplateVisible(driver,supervisorDriver,associateDriver,etest,OPERATOR);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check email template visible to organization");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkEmailTemplateVisible(driver,supervisorDriver,associateDriver,etest,ORGANISATION);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Operators Permission for edit/delete template created by others");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkEditDeleteEmailTemplate(driver,supervisorDriver,associateDriver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check if sort by asc/desc arrow button is working for 'Sent' and 'Last Used' column");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkSentAndLastUsedSorting(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check if signature live chat icon disappeared after adding the template to email");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkSignatureIconDisappearedAfterAddingTemplate(driver,etest);
            ComplexReportFactory.closeTest(etest);

            Functions.logout(supervisorDriver);
            Functions.logout(associateDriver);
		}
		catch(Exception e)
		{
			CommonUtil.printStackTrace(e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
		}
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
		}
		return finalResult;
	}

	public static void checkEmailTemplatesTab(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToEmailTemplatesTab(driver);
			result.put("ET1",EmailTemplates.isEmailTemplatesHeaderFound(driver,etest));
			result.put("ET2",EmailTemplates.isEmailTemplatesDescriptionFound(driver,etest));
			if(CommonUtil.isFail(result,"ET1","ET2"))
			{
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Mismatch","Failure");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkEmptyState(WebDriver driver,ExtentTest etest)
	{
		try
		{
			EmailTemplates.deleteAllEmailTemplates(driver);

			result.put("ET3",Articles.isEmptySlate(driver));

			if(CommonUtil.isFail(result,"ET3"))
			{
				etest.log(Status.FAIL,"Empty state was not found");
				TakeScreenshot.screenshot(driver,etest);
			}
			else
			{
				etest.log(Status.PASS,"Empty state was verified");
				TakeScreenshot.infoScreenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static boolean checkEmailTemplatesAdded(WebDriver driver,ExtentTest etest,boolean isSubject,boolean isContent,boolean isSave)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
			String content = "content_"+label;
			
			Tab.navToEmailTemplatesTab(driver);
			Articles.clickAddButton(driver);

			if(isSubject)
			{
				Articles.setArticleName(driver,subject);
			}
			else
			{
				subject = "";
			}
			if(isContent)
			{
				Articles.setArticleContent(driver,content);
			}
			else
			{
				content = "";
			}
			if(isSubject && isContent)
			{
				Articles.clickPreviewButton(driver);
				WebElement previewWindow = ArticlesVisitorSide.getArticlePreviewContainer(driver);
				result.put("ET8",CommonUtil.checkStringContainsAndLog(subject,previewWindow.getText(),"email template subject",etest));
				result.put("ET9",CommonUtil.checkStringContainsAndLog(content,previewWindow.getText(),"email template content",etest));
				EmailTemplates.closePreviewWindow(driver);
			}
			if(isSave)
			{
				Articles.publishArticle(driver);

				if(!isSubject)
				{
					return EmailTemplates.checkErrorMessageShown(driver,etest);
				}

				if((Articles.getArticleContainerByName(driver,subject)!=null) && (EmailTemplates.checkEmailTemplate(driver,subject,content,etest)))
				{
					etest.log(Status.PASS,"Created Template was found in the list");
					return true;
				}
				else
				{
					etest.log(Status.FAIL,"Created Tempalate was not found in the list");
					TakeScreenshot.screenshot(driver,etest);
					return false;
				}
			}
			else
			{
				Articles.cancelArticle(driver);
				if(Articles.getArticleContainerByName(driver,subject)==null)
				{
					etest.log(Status.PASS,"Created Template was not found in the list");
					return true;
				}
				else
				{
					etest.log(Status.FAIL,"Created Tempalate was found in the list");
					TakeScreenshot.screenshot(driver,etest);
					return false;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			return false;
		}
	}
	public static void checkFormattingOptions(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "testing formatted text "+label;
			String content = "Formatted content";
			String link_text = "test_link";
			String link_url = "www.zoho.com";

			for(int i = 39; i <= 113; i++)
			{
				result.put("ET"+i,false);
			}

			EmailTemplates.selectPortalConfig(driver,ORGANISATION,etest);

			Tab.navToEmailTemplatesTab(driver);
			Articles.clickAddButton(driver);
			Articles.setArticleName(driver,subject);

			EmailTemplates.selectInFormattingMenu(driver,BOLD_ICON);
			Articles.editArticleContent(driver,etest,"bold text");
			EmailTemplates.selectInFormattingMenu(driver,BOLD_ICON);
			Articles.editArticleContent(driver,etest,"not bold text");

			EmailTemplates.selectInFormattingMenu(driver,ITALICS_ICON);
			Articles.editArticleContent(driver,etest,"italics text");
			EmailTemplates.selectInFormattingMenu(driver,ITALICS_ICON);
			Articles.editArticleContent(driver,etest,"not italics text");

			EmailTemplates.selectInFormattingMenu(driver,UNDERLINE_ICON);
			Articles.editArticleContent(driver,etest,"underline text");
			EmailTemplates.selectInFormattingMenu(driver,UNDERLINE_ICON);
			Articles.editArticleContent(driver,etest,"not underline text");

			EmailTemplates.selectInFormattingMenu(driver,STRIKETHROUGH_ICON);
			Articles.editArticleContent(driver,etest,"strikethrough text");
			EmailTemplates.selectInFormattingMenu(driver,STRIKETHROUGH_ICON);
			Articles.editArticleContent(driver,etest,"not strikethrough text");

			EmailTemplates.selectInFormattingDropdown(driver,FONT_ICON,COURIER_NEW_FONT);
			Articles.editArticleContent(driver,etest,"courier new font text");

			EmailTemplates.selectInFormattingDropdown(driver,FONT_SIZE_ARROW,"18");
			Articles.editArticleContent(driver,etest,"size 18 text");

			EmailTemplates.selectInFormattingDropdown(driver,TEXT_COLOR,"fontColor");
			Articles.editArticleContent(driver,etest,"colored text");

			EmailTemplates.selectInFormattingDropdown(driver,TEXT_BACKGROUND_COLOR,"fontBackground");
			Articles.editArticleContent(driver,etest,"background highlighted text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");

			EmailTemplates.selectInFormattingDropdown(driver,LIST_ORDER,BULLETS);
			EmailTemplates.editTemplatesContent(driver,"bulleted text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");

			EmailTemplates.selectInFormattingDropdown(driver,LIST_ORDER,NUMBERING);
			EmailTemplates.editTemplatesContent(driver,"numbered text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");

			EmailTemplates.selectInFormattingDropdown(driver,ALIGN_ICON,RIGHT_ALIGN);
			EmailTemplates.editTemplatesContent(driver,"right aligned text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");
			EmailTemplates.selectInFormattingDropdown(driver,ALIGN_ICON,JUSTIFY_ALIGN);
			EmailTemplates.editTemplatesContent(driver,"justify aligned text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");
			EmailTemplates.selectInFormattingDropdown(driver,ALIGN_ICON,CENTER_ALIGN);
			EmailTemplates.editTemplatesContent(driver,"center aligned text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");
			EmailTemplates.selectInFormattingDropdown(driver,ALIGN_ICON,LEFT_ALIGN);
			EmailTemplates.editTemplatesContent(driver,"left aligned text");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");

			EmailTemplates.selectInFormattingDropdown(driver,DECREASE_INDENT_ICON,INCREASE_INDENT);
			EmailTemplates.editTemplatesContent(driver,"increased indent text");
			Articles.editArticleContent(driver,etest,"");
			EmailTemplates.selectInFormattingDropdown(driver,INCREASE_INDENT_ICON,DECREASE_INDENT);
			EmailTemplates.editTemplatesContent(driver,"decreased indent text");
			Articles.editArticleContent(driver,etest,"");

			Articles.addURLToArticle(driver,etest,link_text,link_url);
			EmailTemplates.selectInFormattingMenu(driver,HORIZONTAL_LINE_ICON);
			EmailTemplates.selectInFormattingMenu(driver,INSERT_CODE_ICON);
			EmailTemplates.editTemplatesContent(driver,"sample code");
			Articles.editArticleContent(driver,etest,"");
			Articles.editArticleContent(driver,etest,"");

			EmailTemplates.selectInFormattingDropdown(driver,TABLE_ICON,"table");
			EmailTemplates.selectInFormattingMenu(driver,QUOTE_ICON);
			EmailTemplates.editTemplatesContent(driver,"quoted text");

			TakeScreenshot.infoScreenshot(driver,etest);

			driver.switchTo().defaultContent();
        	Articles.switchToArticleContainerFrame(driver);
        	WebElement contentBody = CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY);

			result.put("ET39",EmailTemplates.checkFormatting(driver,contentBody,"ET39",By.tagName("b"),"innerText","bold text",true,etest));
			result.put("ET40",EmailTemplates.checkFormatting(driver,contentBody,"ET40",By.tagName("b"),"innerText","not bold text",false,etest));
			result.put("ET41",EmailTemplates.checkFormatting(driver,contentBody,"ET41",By.tagName("i"),"innerText","italics text",true,etest));
			result.put("ET42",EmailTemplates.checkFormatting(driver,contentBody,"ET42",By.tagName("i"),"innerText","not italics text",false,etest));
			result.put("ET43",EmailTemplates.checkFormatting(driver,contentBody,"ET43",By.tagName("u"),"innerText","underline text",true,etest));
			result.put("ET44",EmailTemplates.checkFormatting(driver,contentBody,"ET44",By.tagName("u"),"innerText","not underline text",false,etest));
			result.put("ET45",EmailTemplates.checkFormatting(driver,contentBody,"ET45",By.tagName("strike"),"innerText","strikethrough text",true,etest));
			result.put("ET46",EmailTemplates.checkFormatting(driver,contentBody,"ET46",By.tagName("strike"),"innerText","not strikethrough text",false,etest));
			result.put("ET47",EmailTemplates.checkFormatting(driver,contentBody,"ET47",By.className("font"),"style",COURIER_NEW_FONT_STYLE,true,etest));
			result.put("ET48",EmailTemplates.checkFormatting(driver,contentBody,"ET48",By.className("size"),"style","18",true,etest));
			result.put("ET49",EmailTemplates.checkFormatting(driver,contentBody,"ET49",By.className("colour"),"style",FONT_COLOR,true,etest));
			result.put("ET50",EmailTemplates.checkFormatting(driver,contentBody,"ET50",By.className("highlight"),"style",FONT_BACKGROUND,true,etest));
			result.put("ET51",EmailTemplates.checkFormatting(driver,contentBody,"ET51",By.tagName("ul"),"innerHTML","bulleted text",true,etest));
			result.put("ET52",EmailTemplates.checkFormatting(driver,contentBody,"ET52",By.tagName("ol"),"innerHTML","numbered text",true,etest));
			result.put("ET53",EmailTemplates.checkFormatting(driver,contentBody,"ET53",By.className("align-right"),"innerText","right aligned text",true,etest));
			result.put("ET54",EmailTemplates.checkFormatting(driver,contentBody,"ET54",By.className("align-justify"),"innerText","justify aligned text",true,etest));
			result.put("ET55",EmailTemplates.checkFormatting(driver,contentBody,"ET55",By.className("align-center"),"innerText","center aligned text",true,etest));
			result.put("ET56",EmailTemplates.checkFormatting(driver,contentBody,"ET56",By.className("align-left"),"innerText","left aligned text",true,etest));
			result.put("ET57",EmailTemplates.checkFormatting(driver,contentBody,"ET57",By.tagName("blockquote"),"innerText","increased indent text",true,etest));
			result.put("ET58",EmailTemplates.checkFormatting(driver,contentBody,"ET58",By.tagName("blockquote"),"innerText","decreased indent text",false,etest));
			result.put("ET59",EmailTemplates.checkFormatting(driver,contentBody,"ET59",By.tagName("a"),"href",link_url,true,etest));
			result.put("ET60",EmailTemplates.checkFormatting(driver,contentBody,"ET60",By.tagName("table"),null,null,true,etest));
			result.put("ET61",EmailTemplates.checkFormatting(driver,contentBody,"ET61",By.className("code"),"innerText","sample code",true,etest));
			result.put("ET62",EmailTemplates.checkFormatting(driver,contentBody,"ET62",By.tagName("blockquote"),"style","border",true,etest));
			result.put("ET63",EmailTemplates.checkFormatting(driver,contentBody,"ET63",By.tagName("hr"),null,null,true,etest));

			driver.switchTo().defaultContent();
			Articles.clickPreviewButton(driver);
        	WebElement previewContainer = ArticlesVisitorSide.getArticlePreviewContainer(driver);
        	contentBody = CommonUtil.getElement(previewContainer,EmailTemplates.PREVIEW_CONTENT);

			result.put("ET64",EmailTemplates.checkFormatting(driver,contentBody,"ET64",By.tagName("b"),"innerText","bold text",true,etest));
			result.put("ET65",EmailTemplates.checkFormatting(driver,contentBody,"ET65",By.tagName("b"),"innerText","not bold text",false,etest));
			result.put("ET66",EmailTemplates.checkFormatting(driver,contentBody,"ET66",By.tagName("i"),"innerText","italics text",true,etest));
			result.put("ET67",EmailTemplates.checkFormatting(driver,contentBody,"ET67",By.tagName("i"),"innerText","not italics text",false,etest));
			result.put("ET68",EmailTemplates.checkFormatting(driver,contentBody,"ET68",By.tagName("u"),"innerText","underline text",true,etest));
			result.put("ET69",EmailTemplates.checkFormatting(driver,contentBody,"ET69",By.tagName("u"),"innerText","not underline text",false,etest));
			result.put("ET70",EmailTemplates.checkFormatting(driver,contentBody,"ET70",By.tagName("strike"),"innerText","strikethrough text",true,etest));
			result.put("ET71",EmailTemplates.checkFormatting(driver,contentBody,"ET71",By.tagName("strike"),"innerText","not strikethrough text",false,etest));
			result.put("ET72",EmailTemplates.checkFormatting(driver,contentBody,"ET72",By.className("font"),"style",COURIER_NEW_FONT_STYLE,true,etest));
			result.put("ET73",EmailTemplates.checkFormatting(driver,contentBody,"ET73",By.className("size"),"style","18",true,etest));
			result.put("ET74",EmailTemplates.checkFormatting(driver,contentBody,"ET74",By.className("colour"),"style",FONT_COLOR,true,etest));
			result.put("ET75",EmailTemplates.checkFormatting(driver,contentBody,"ET75",By.className("highlight"),"style",FONT_BACKGROUND,true,etest));
			result.put("ET76",EmailTemplates.checkFormatting(driver,contentBody,"ET76",By.tagName("ul"),"innerHTML","bulleted text",true,etest));
			result.put("ET77",EmailTemplates.checkFormatting(driver,contentBody,"ET77",By.tagName("ol"),"innerHTML","numbered text",true,etest));
			result.put("ET78",EmailTemplates.checkFormatting(driver,contentBody,"ET78",By.className("align-right"),"innerText","right aligned text",true,etest));
			result.put("ET79",EmailTemplates.checkFormatting(driver,contentBody,"ET79",By.className("align-justify"),"innerText","justify aligned text",true,etest));
			result.put("ET80",EmailTemplates.checkFormatting(driver,contentBody,"ET80",By.className("align-center"),"innerText","center aligned text",true,etest));
			result.put("ET81",EmailTemplates.checkFormatting(driver,contentBody,"ET81",By.className("align-left"),"innerText","left aligned text",true,etest));
			result.put("ET82",EmailTemplates.checkFormatting(driver,contentBody,"ET82",By.tagName("blockquote"),"innerText","increased indent text",true,etest));
			result.put("ET83",EmailTemplates.checkFormatting(driver,contentBody,"ET83",By.tagName("blockquote"),"innerText","decreased indent text",false,etest));
			result.put("ET84",EmailTemplates.checkFormatting(driver,contentBody,"ET84",By.tagName("a"),"href",link_url,true,etest));
			result.put("ET85",EmailTemplates.checkFormatting(driver,contentBody,"ET85",By.tagName("table"),null,null,true,etest));
			result.put("ET86",EmailTemplates.checkFormatting(driver,contentBody,"ET86",By.className("code"),"innerText","sample code",true,etest));
			result.put("ET87",EmailTemplates.checkFormatting(driver,contentBody,"ET87",By.tagName("blockquote"),"style","border",true,etest));
			result.put("ET88",EmailTemplates.checkFormatting(driver,contentBody,"ET88",By.tagName("hr"),null,null,true,etest));

			EmailTemplates.closePreviewWindow(driver);
			Articles.publishArticle(driver);

			EmailTemplates.clickLatestChatFromChatHistory(driver);
			ChatHistory.clickReplyMailButton(driver);
			EmailTemplates.clickTemplatesInSendingEmail(driver);
			EmailTemplates.selectEmailTemplateInChatHistory(driver,subject);

			driver.switchTo().defaultContent();
        	Articles.switchToArticleContainerFrame(driver);
        	contentBody = CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY);

			result.put("ET89",EmailTemplates.checkFormatting(driver,contentBody,"ET89",By.tagName("b"),"innerText","bold text",true,etest));
			result.put("ET90",EmailTemplates.checkFormatting(driver,contentBody,"ET90",By.tagName("b"),"innerText","not bold text",false,etest));
			result.put("ET91",EmailTemplates.checkFormatting(driver,contentBody,"ET91",By.tagName("i"),"innerText","italics text",true,etest));
			result.put("ET92",EmailTemplates.checkFormatting(driver,contentBody,"ET92",By.tagName("i"),"innerText","not italics text",false,etest));
			result.put("ET93",EmailTemplates.checkFormatting(driver,contentBody,"ET93",By.tagName("u"),"innerText","underline text",true,etest));
			result.put("ET94",EmailTemplates.checkFormatting(driver,contentBody,"ET94",By.tagName("u"),"innerText","not underline text",false,etest));
			result.put("ET95",EmailTemplates.checkFormatting(driver,contentBody,"ET95",By.tagName("strike"),"innerText","strikethrough text",true,etest));
			result.put("ET96",EmailTemplates.checkFormatting(driver,contentBody,"ET96",By.tagName("strike"),"innerText","not strikethrough text",false,etest));
			result.put("ET97",EmailTemplates.checkFormatting(driver,contentBody,"ET97",By.className("font"),"style",COURIER_NEW_FONT_STYLE,true,etest));
			result.put("ET98",EmailTemplates.checkFormatting(driver,contentBody,"ET98",By.className("size"),"style","18",true,etest));
			result.put("ET99",EmailTemplates.checkFormatting(driver,contentBody,"ET99",By.className("colour"),"style",FONT_COLOR,true,etest));
			result.put("ET100",EmailTemplates.checkFormatting(driver,contentBody,"ET100",By.className("highlight"),"style",FONT_BACKGROUND,true,etest));
			result.put("ET101",EmailTemplates.checkFormatting(driver,contentBody,"ET101",By.tagName("ul"),"innerHTML","bulleted text",true,etest));
			result.put("ET102",EmailTemplates.checkFormatting(driver,contentBody,"ET102",By.tagName("ol"),"innerHTML","numbered text",true,etest));
			result.put("ET103",EmailTemplates.checkFormatting(driver,contentBody,"ET103",By.className("align-right"),"innerText","right aligned text",true,etest));
			result.put("ET104",EmailTemplates.checkFormatting(driver,contentBody,"ET104",By.className("align-justify"),"innerText","justify aligned text",true,etest));
			result.put("ET105",EmailTemplates.checkFormatting(driver,contentBody,"ET105",By.className("align-center"),"innerText","center aligned text",true,etest));
			result.put("ET106",EmailTemplates.checkFormatting(driver,contentBody,"ET106",By.className("align-left"),"innerText","left aligned text",true,etest));
			result.put("ET107",EmailTemplates.checkFormatting(driver,contentBody,"ET107",By.tagName("blockquote"),"innerText","increased indent text",true,etest));
			result.put("ET108",EmailTemplates.checkFormatting(driver,contentBody,"ET108",By.tagName("blockquote"),"innerText","decreased indent text",false,etest));
			result.put("ET109",EmailTemplates.checkFormatting(driver,contentBody,"ET109",By.tagName("a"),"href",link_url,true,etest));
			result.put("ET110",EmailTemplates.checkFormatting(driver,contentBody,"ET110",By.tagName("table"),null,null,true,etest));
			result.put("ET111",EmailTemplates.checkFormatting(driver,contentBody,"ET111",By.className("code"),"innerText","sample code",true,etest));
			result.put("ET112",EmailTemplates.checkFormatting(driver,contentBody,"ET112",By.tagName("blockquote"),"style","border",true,etest));
			result.put("ET113",EmailTemplates.checkFormatting(driver,contentBody,"ET113",By.tagName("hr"),null,null,true,etest));

			driver.switchTo().defaultContent();

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static boolean checkEnableEmailTemplate(WebDriver driver,ExtentTest etest,boolean isEnable)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
    		String content = "content_"+label;
			EmailTemplates.createEmailTemplate(driver,label);
			WebElement emailTemplate = Articles.getArticleContainerByName(driver,subject);

			String status = isEnable?"sqico-enable":"sqico-disable";
			String statusEle = isEnable?"sqico-disable":"sqico-enable";

			if(emailTemplate.getAttribute("innerHTML").contains(status))
			{
				CommonUtil.clickWebElement(driver,By.className(status));
				CommonWait.waitTillDisplayed(driver,By.className(statusEle));
			}

			CommonUtil.clickWebElement(driver,By.className(statusEle));
			CommonWait.waitTillDisplayed(driver,By.className(status));

			if(emailTemplate.getAttribute("innerHTML").contains(status) && EmailTemplates.checkEmailTemplateInChatHistory(driver,subject,isEnable))
			{
				etest.log(Status.PASS,"Expected status was found for the email template("+subject+")");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Expected status was not found for the email template("+subject+")");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
			return false;
		}
	}
	public static void checkDeleteEmailTemplate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
    		String content = "content_"+label;
			EmailTemplates.createEmailTemplate(driver,label);

			EmailTemplates.deleteTemplatesBySubject(driver,subject);

			if(!EmailTemplates.checkEmailTemplateInList(driver,subject))
			{
				etest.log(Status.PASS,"Email template ("+subject+") was deleted and the deleted email template was not found in the list");
				result.put("ET12",true);
			}
			else
			{
				etest.log(Status.FAIL,"Email template ("+subject+") was not deleted");
				TakeScreenshot.screenshot(driver,etest);
				result.put("ET12",false);
			}

			if(EmailTemplates.checkEmailTemplateInChatHistory(driver,subject,false))
			{
				etest.log(Status.PASS,"Deleted email template ("+subject+") was not found in sending mail after being deleted");
				result.put("ET13",true);
			}
			else
			{
				etest.log(Status.FAIL,"Deleted email template ("+subject+") was found in sending mail even after being deleted");
				result.put("ET13",false);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkTemplatesOptionShown(WebDriver driver,ExtentTest etest,boolean isShown,int startKey)
	{
		WebDriver visitor_driver = null;
		try
		{
			String key = "ET"+startKey;
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
    		String content = "content_"+label;
    		visitor_driver = Functions.setUp();

    		VisitorWindow.setupChat(driver,visitor_driver,etest,widgetCode,label,ChatType.MISSED);

			if(isShown)
			{
				EmailTemplates.createEmailTemplate(driver,label);
			}
			else
			{
				EmailTemplates.deleteAllEmailTemplates(driver);
			}

			if(EmailTemplates.checkTemplateOptionShownInChatHistory(driver))
			{
				etest.log(Status.PASS,"Email template option was shown when the template "+((isShown)?"is present":"is not present"));
				result.put(key,true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Email template option was not shown when the template "+((isShown)?"is present":"is not present"));
				result.put(key,false);
				TakeScreenshot.screenshot(driver,etest);
			}

			key = "ET"+(++startKey);

			if(EmailTemplates.checkEmailTemplateInChatHistory(driver,subject,isShown))
			{
				etest.log(Status.PASS,"Email template was "+((isShown)?"shown":"not shown")+" in chat history");
				result.put(key,true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Email template was "+((isShown)?"not shown":"shown")+" in chat history");
				result.put(key,false);
				TakeScreenshot.screenshot(driver,etest);
			}

			key = "ET"+(++startKey);

			if(EmailTemplates.checkTemplateOptionShownInMissedTab(driver))
			{
				etest.log(Status.PASS,"Email template option was shown when the template "+((isShown)?"is present":"is not present"));
				result.put(key,true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Email template option was not shown when the template "+((isShown)?"is present":"is not present"));
				result.put(key,false);
				TakeScreenshot.screenshot(driver,etest);
			}

			key = "ET"+(++startKey);

			if(EmailTemplates.checkEmailTemplateInMissedTab(driver,subject,isShown))
			{
				etest.log(Status.PASS,"Email template was "+((isShown)?"shown":"not shown")+" in Missed tab");
				result.put(key,true);
				TakeScreenshot.infoScreenshot(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Email template was "+((isShown)?"not shown":"shown")+" in Missed tab");
				result.put(key,false);
				TakeScreenshot.screenshot(driver,etest);
			}
			CommonUtil.refreshPage(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkDynamicTextSuggestionsDisplayed(WebDriver driver,ExtentTest etest)
	{
		try
		{
			Tab.navToEmailTemplatesTab(driver);
			Articles.clickAddButton(driver);

			Articles.setArticleName(driver,"%");

			if(EmailTemplates.isSuggestionsDisplayed(driver,SUBJECT_CONTAINER))
			{
				etest.log(Status.PASS,"Dynamic Suggestions was displayed in subject on typing '%'");
				result.put("ET22",true);
			}
			else
			{
				etest.log(Status.FAIL,"Dynamic Suggestions was not displayed in subject on typinh '%'");
				result.put("ET22",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			Articles.setArticleContent(driver,"%");
			if(EmailTemplates.isSuggestionsDisplayed(driver,CONTENT_CONTAINER))
			{
				etest.log(Status.PASS,"Dynamic Suggestions was displayed in content on typing '%'");
				result.put("ET23",true);
			}
			else
			{
				etest.log(Status.FAIL,"Dynamic Suggestions was not displayed in content on typinh '%'");
				result.put("ET23",false);
				TakeScreenshot.screenshot(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}

	public static void checkDynamicTextSuggestions(WebDriver driver,ExtentTest etest)
	{
		int failcount = 0;
		String label = CommonUtil.getUniqueMessage();
		String subject = "subject_"+label;
		String visitor_name = "V"+label;
		WebDriver visitor_driver = null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@email.com";
		String visitor_question="Q"+label;
		String pagetitle="";
		String url="";
		String browser="";
		String os="";
		String browser_version="";
		try
		{
			visitor_driver = Functions.setUp();
			String UserName=ExecuteStatements.getUserName(driver);
			String UserMail=ExecuteStatements.getUserMail(driver);

			String content = "content"+label+"visitor.name:%visitor.name%attender.name:%attender.name%smart.timenow:%smart.timenow%visitor.department:%visitor.department%visitor.email:%visitor.email%attender.email:%attender.email%visitor.question:%visitor.question%visitor.id:%visitor.id%visitor.phone:%visitor.phone%visitor.country:%visitor.country%visitor.city:%visitor.city%web.embed.name:%web.embed.name%visitor.pagetitle:%visitor.pagetitle%visitor.ip:%visitor.ip%visitor.pageurl:%visitor.pageurl%visitor.referrer:%visitor.referrer%visitor.state:%visitor.state%visitor.timezone:%visitor.timezone%visitor.latitude:%visitor.latitude%visitor.longitude:%visitor.longitude%visitor.operating.system:%visitor.operating.system%visitor.browser:%visitor.browser%visitor.browser.version:%visitor.browser.version%visitor.platform:%visitor.platform%screen.resolution:%screen.resolution%search.engine:%search.engine%search.query:%search.query%";

			EmailTemplates.createEmailTemplateWithSubjAndContent(driver,subject,content);

			VisitorWindow.setupChat(driver,visitor_driver,etest,widgetCode,label,ChatType.COMPLETED);

			String keys_array[]={"visitor.name","attender.name","visitor.email","visitor.question","attender.email","visitor.pagetitle","visitor.pageurl","visitor.browser.version"};
			Hashtable<Integer,String> keys=new Hashtable<Integer,String>();
			for(int i=0;i<keys_array.length;i++)
			{
				keys.put(i,keys_array[i]);
			}

			Hashtable<String,String> expected=new Hashtable<String,String>();
			// expected.put("",);

			expected.put("visitor.name",visitor_name);
			expected.put("visitor.email",visitor_mail);
			expected.put("visitor.question",visitor_question);
			expected.put("attender.name",UserName);
			expected.put("attender.email",UserMail);
			expected.put("visitor.pagetitle",pagetitle);
			expected.put("visitor.pageurl",url);
			expected.put("visitor.timezone","GMT+0530");
			expected.put("visitor.browser.version",browser_version);
			//seperate checks
			expected.put("visitor.browser",browser);
			expected.put("visitor.operating.system",os);

			CommonUtil.refreshPage(driver);

			EmailTemplates.checkEmailTemplateInChatHistory(driver,subject,true);
			EmailTemplates.selectEmailTemplateInChatHistory(driver,subject);

			if(EmailTemplates.checkAllDynamicText(driver,keys,expected,etest))
			{
				etest.log(Status.PASS,"All Dynamic Text Suggestions were checked and verified");
				result.put("ET24",true);
			}
			else
			{
				etest.log(Status.FAIL,"Dynamic Text Suggestions check failed");
				result.put("ET24",false);
				TakeScreenshot.screenshot(driver,etest);
			}

			driver.switchTo().defaultContent();

			CommonWait.waitTillDisplayed(driver,SEND_BUTTON);
			CommonUtil.clickWebElement(driver,SEND_BUTTON);
			CommonWait.waitTillDisplayed(driver,ChatHistory.REPLY_BUTTON);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
		visitor_driver.quit();
	}
	public static void checkContentInSentMail(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
			template1 = subject;
			String content = "content_"+label;

			EmailTemplates.createEmailTemplate(driver,label);

			EmailTemplates.checkEmailTemplateInChatHistory(driver,subject,true);
			EmailTemplates.selectEmailTemplateInChatHistory(driver,subject);

			driver.switchTo().defaultContent();

			CommonWait.waitTillDisplayed(driver,SEND_BUTTON);
			CommonUtil.clickWebElement(driver,SEND_BUTTON);
			CommonWait.waitTillDisplayed(driver,ChatHistory.REPLY_BUTTON);

			CommonUtil.sleep(60000); // wait till mail received

			WebDriver apiDriver = Functions.setUp();
			String mailContent = EmailTemplates.getMailData(apiDriver,label,etest);

			if(CommonUtil.checkStringContainsAndLog(content,mailContent,"mail content",etest))
			{
				result.put("ET25",true);
			}
			else
			{
				result.put("ET25",false);
				TakeScreenshot.screenshot(driver,etest);
			}
			apiDriver.quit();
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkEditEmailTemplate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
			String editedSubject = "editedSubject_"+label;
			String content = "content_"+label;
			String editedContent = "editedContent_"+label;

			EmailTemplates.createEmailTemplate(driver,label);

			EmailTemplates.selectEmailTemplatesInList(driver,subject);

			Articles.setArticleName(driver,editedSubject);
			Articles.setArticleContent(driver,editedContent);
			Articles.publishArticle(driver);

			result.put("ET26",EmailTemplates.checkEmailTemplate(driver,editedSubject,editedContent,etest));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkEmailTemplateVisible(WebDriver driver,WebDriver supervisorDriver,WebDriver associateDriver,ExtentTest etest,String option)
	{
		try
		{
			String department = (option == DEPARTMENT)?ExecuteStatements.getSystemGeneratedDepartment(driver):null;
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
    		String content = "content_"+label;

			EmailTemplates.selectPortalConfig(driver,option,etest);

			EmailTemplates.createEmailTemplateWithSubjAndContent(driver,subject,content,department);

			boolean adminCheck = EmailTemplates.isEmailTemplatePresentInList(driver,subject);
			boolean supervisorCheck = EmailTemplates.isEmailTemplatePresentInList(supervisorDriver,subject);
			boolean associateCheck = EmailTemplates.isEmailTemplatePresentInList(associateDriver,subject);
			
			switch(option)
			{
				case ORGANISATION : 
				{
					if(adminCheck && supervisorCheck && associateCheck)
					{
						etest.log(Status.PASS,"Email template was visible to all operators in the organisation");
						result.put("ET27",true);
					}
					else
					{
						etest.log(Status.FAIL,"Email template was not visible to all operators in the organisation");
						result.put("ET27",false);
						TakeScreenshot.screenshot(driver,etest);
					}
					break;
				}
				case DEPARTMENT : 
				{
					if(adminCheck && supervisorCheck && !associateCheck)
					{
						etest.log(Status.PASS,"Email template was visible to operators present in specific department");
						result.put("ET28",true);
					}
					else
					{
						etest.log(Status.FAIL,"Email template was not visible to operators present in specific department");
						result.put("ET28",false);
						TakeScreenshot.screenshot(driver,etest);
					}
					break;
				}
				case OPERATOR : 
				{
					if(adminCheck && !supervisorCheck && !associateCheck)
					{
						etest.log(Status.PASS,"Email template was visible only to the operator who created");
						result.put("ET29",true);
					}
					else
					{
						etest.log(Status.FAIL,"Email template was not only visible to the operator who created but visible to others");
						result.put("ET29",false);
						TakeScreenshot.screenshot(driver,etest);
					}
				}
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkEditDeleteEmailTemplate(WebDriver driver,WebDriver supervisorDriver,WebDriver associateDriver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();

			EmailTemplates.createEmailTemplate(driver,"admin_"+label);

			EmailTemplates.createEmailTemplate(supervisorDriver,"supervisor_"+label);

			EmailTemplates.createEmailTemplate(associateDriver,"associate_"+label);

			etest.info("<b style=\"color:green;\">NOW CHECKING EDIT TEMPLATES FROM ADMIN");
			result.put("ET30",EmailTemplates.checkEmailTemplateEdit(driver,label,true,true,true,etest));

			etest.info("<b style=\"color:green;\">NOW CHECKING EDIT TEMPLATES FROM SUPERVISOR");
			result.put("ET31",EmailTemplates.checkEmailTemplateEdit(supervisorDriver,label,false,true,false,etest));

			etest.info("<b style=\"color:green;\">NOW CHECKING EDIT TEMPLATES FROM ASSOCIATE");
			result.put("ET32",EmailTemplates.checkEmailTemplateEdit(associateDriver,label,false,false,false,etest));

			EmailTemplates.createEmailTemplate(driver,"admin_"+label+"_1");
			EmailTemplates.createEmailTemplate(supervisorDriver,"supervisor_"+label+"_1");
			EmailTemplates.createEmailTemplate(associateDriver,"associate_"+label+"_1");

			EmailTemplates.createEmailTemplate(driver,"admin_"+label+"_2");
			EmailTemplates.createEmailTemplate(supervisorDriver,"supervisor_"+label+"_2");
			EmailTemplates.createEmailTemplate(associateDriver,"associate_"+label+"_2");

			etest.info("<b style=\"color:green;\">NOW CHECKING DELETE TEMPLATES FROM ASSOCIATE");
			result.put("ET116",EmailTemplates.checkEmailTemplateDelete(associateDriver,label,false,false,false,etest));		

			etest.info("<b style=\"color:green;\">NOW CHECKING DELETE TEMPLATES FROM SUPERVISOR");
			result.put("ET115",EmailTemplates.checkEmailTemplateDelete(supervisorDriver,label+"_2",false,true,false,etest));

			etest.info("<b style=\"color:green;\">NOW CHECKING DELETE TEMPLATES FROM ADMIN");
			result.put("ET114",EmailTemplates.checkEmailTemplateDelete(driver,label+"_1",true,true,true,etest));


		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkSentAndLastUsedSorting(WebDriver driver,ExtentTest etest)
	{
		String label = CommonUtil.getUniqueMessage();
		try
		{
			Tab.navToEmailTemplatesTab(driver);

			EmailTemplates.createEmailTemplate(driver,label);

			CommonUtil.refreshPage(driver);

			Tab.navToEmailTemplatesTab(driver);

			result.put("ET33",EmailTemplates.checkInnerElements(driver,etest));

			List<WebElement> templatesHeader = CommonUtil.getElement(driver,EmailTemplates.TEMPLATES_LIST,EmailTemplates.LIST_HEADER).findElements(EmailTemplates.LIST_CELL);

			if(EmailTemplates.checkSort(driver,etest))
			{
				etest.log(Status.PASS,"Sort icon present in the header in Templates list was verified");
				result.put("ET34",true);
			}
			else
			{
				result.put("ET34",false);
			}

			EmailTemplates.deleteAllEmailTemplates(driver);

			EmailTemplates.createEmailTemplate(driver,label);

			//check sort icon for single Templates

			templatesHeader = CommonUtil.getElement(driver,EmailTemplates.TEMPLATES_LIST,EmailTemplates.LIST_HEADER).findElements(EmailTemplates.LIST_CELL);
			WebElement header = templatesHeader.get(1);
			WebElement sortIcon = CommonUtil.getElement(header,SORT_ARROW);
			if(!CommonWait.isDisplayed(sortIcon))
			{
				etest.log(Status.PASS,"Sort icon was not displayed in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header in Templates tab for single Template");
				result.put("ET35",true);
			}
			else
			{
				etest.log(Status.FAIL,"Sort icon was displayed in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header in Templates tab for single Template");
				TakeScreenshot.screenshot(driver,etest);
				result.put("ET35",false);
			}

			header = templatesHeader.get(2);
		
			sortIcon = CommonUtil.getElement(header,SORT_ARROW);
			if(!CommonWait.isDisplayed(sortIcon))
			{
				etest.log(Status.PASS,"Sort icon was not displayed in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header in Templates tab for single Template");
				result.put("ET36",true);
			}
			else
			{
				etest.log(Status.FAIL,"Sort icon was displayed in the '"+header.findElements(By.tagName("em")).get(0).getText()+"' header in Templates tab for single Template");
				TakeScreenshot.screenshot(driver,etest);
				result.put("ET36",false);
			}

			//check sort icon for single Templates ends
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}
	public static void checkSignatureIconDisappearedAfterAddingTemplate(WebDriver driver,ExtentTest etest)
	{
		try
		{
			String label = CommonUtil.getUniqueMessage();
			String subject = "subject_"+label;
			String content = "content_"+label;
			EmailTemplates.createEmailTemplate(driver,label);

			EmailTemplates.clickLatestChatFromChatHistory(driver);
			ChatHistory.clickReplyMailButton(driver);

			Articles.switchToArticleContainerFrame(driver);
			String template_content_html = CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY).getAttribute("innerHTML");
			if(template_content_html.contains("signaturesupport.ls"))
			{
				result.put("ET37",true);
				etest.log(Status.PASS,"Signature icon was found in sending email before adding template");
			}
			else
			{
				result.put("ET37",false);
				etest.log(Status.FAIL,"Signature icon was not found in sending email before adding template");
				TakeScreenshot.screenshot(driver,etest);
			}

			driver.switchTo().defaultContent();
			EmailTemplates.clickTemplatesInSendingEmail(driver);
			EmailTemplates.selectEmailTemplateInChatHistory(driver,subject);

			Articles.switchToArticleContainerFrame(driver);
			template_content_html = CommonUtil.getElement(driver,Articles.ARTICLE_TEXT_BODY).getAttribute("innerHTML");

			if(!template_content_html.contains("signaturesupport.ls"))
			{
				result.put("ET38",true);
				etest.log(Status.PASS,"Signature icon was disappeared in sending email after adding template");
			}
			else
			{
				result.put("ET38",false);
				etest.log(Status.FAIL,"Signature icon was not disappeared in sending email after adding template");
				TakeScreenshot.screenshot(driver,etest);
			}
			driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,e);
		}
	}

}
