//$Id$
package com.zoho.livedesk.client.MailChimp;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Calendar;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.*;
import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;

import com.google.common.base.Function;

public class MailChimpIntegration
{	
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    
    public static String embedname = "mailchimp1";
    public static String widgetcode = "mailchimp1";
    
	public static ExtentTest etest; 

    public static Hashtable<String, String> listname = new Hashtable<String, String>();
    public static Hashtable<String, String> visitorname = new Hashtable<String, String>();
    public static Hashtable<String, Long> timeInterval = new Hashtable<String, Long>();
    
	public static Hashtable mailChimp(WebDriver driver)
	{
		WebDriver mailchimp = null;
		WebDriver mailChimpDriver = null;
		WebDriver driver2 = null;
		try
		{
            result = new Hashtable();
            
            listname.put("MCI20","No value");
            listname.put("MCI21","No value");
            listname.put("MCI22","No value");
            visitorname.put("MCI20","No value");
            visitorname.put("MCI21","No value");
            visitorname.put("MCI22","No value");
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI1"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			widgetcode = ExecuteStatements.getWidgetCode(driver);
            
            // if(Util.setUptracking().contains("local"))
            // {
            //     widgetcode = "284825a43222fbc461c70612e73c84b4795b0511fc0f45e727e290698177797d";
            // }
            // else
            // {
            //     widgetcode = "1478eda635beede8e1fcb83e6b004212b6103c2992f4646947f108e3f48c78e3";
            // }

			mailchimp = Functions.setUp();
			Functions.loginMailChimp(mailchimp,"mailchimpsite2");
			
			mailChimpDriver = Functions.setUp();
			Functions.loginMailChimp(mailChimpDriver,"mailchimpsite");
			
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"MailChimp");
			
			etest.log(Status.PASS,"Mail Chimp is present");
			result.put("MCI1", true);
			
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI2"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI2", disableAndCheck(driver));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI3"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI3", enableMailChimp(driver));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI4"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI4", enableCampaign(driver));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI5"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI5", enableMailChimpAndDisableCampaign(driver));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI6"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI6",checkMailChimpConfigDialogBox(driver,"test1"));
			
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI7"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI7", configureListAndCheckEdit(driver,"test1"));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI8"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			result.put("MCI8", configureAnotherListAndCheckEdit(driver,"test1"));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI9"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI9", removeList(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI10"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI10",addFieldAndCheck(driver,"test1","Visitor Name","First Name"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI12"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI12",deleteField(driver,2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI11"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI11",addFieldAndCheck(driver,"test1","Visitor Name","Last Name"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI13"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI13",checkDisableAndEnable(driver,2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI14"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI14",checkDisableAndDelete(driver,2));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI15"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			CommonFunctions.removeConfiguredNewLetter(driver,etest);
			etest.log(Status.INFO,"remove configured letter");
			TakeScreenshot.infoScreenshot(driver,etest);
            
            result.put("MCI15",checkVisitorInList(driver,mailchimp,true));
			
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI16"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			CommonFunctions.removeConfiguredNewLetter(driver,etest);
            
            result.put("MCI16",checkVisitorInList(driver,mailchimp,false));
			
			ComplexReportFactory.closeTest(etest);
            
            Thread.sleep(20000);

			driver2 = Functions.setUp();
            Functions.login(driver2,"mailchimp2");

            widgetcode = ExecuteStatements.getWidgetCode(driver2);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI17"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");

			CommonFunctions.removeConfiguredNewLetter(driver2,etest);
            CommonUtil.sleep(1000);
            Long time = new Long(System.currentTimeMillis());
			result.put("MCI17",addTrigger(driver2,mailChimpDriver,"None",""+time,"MCI20"));
			
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI20"));
            ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI20",checkVisitorInMailChimpForTriggers(mailChimpDriver,"MCI20"));
            CommonFunctions.deleteTriggerRule(driver2,etest);

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI18"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            time = new Long(System.currentTimeMillis());
            result.put("MCI18",addTrigger(driver2,mailChimpDriver,"Weekly",""+time,"MCI21"));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI21"));
            ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI21",checkVisitorInMailChimpForTriggers(mailChimpDriver,"MCI21"));
            CommonFunctions.deleteTriggerRule(driver2,etest);

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI19"));
			ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
			CommonFunctions.deleteTriggerRule(driver2,etest);
            
            time = new Long(System.currentTimeMillis());
            result.put("MCI19",addTrigger(driver2,mailChimpDriver,"Monthly",""+time,"MCI22"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("MCI22"));
            ComplexReportFactory.setValues(etest,"Automation","MailChimp Integration");
            
            result.put("MCI22",checkVisitorInMailChimpForTriggers(mailChimpDriver,"MCI22"));
            CommonFunctions.deleteTriggerRule(driver2,etest);

            Functions.logoutMailChimp(mailchimp);
            Functions.logoutMailChimp(mailChimpDriver);

            Functions.logout(driver2);
            
            ComplexReportFactory.closeTest(etest);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckInIntegrations","Error",e);
			Functions.logoutMailChimp(mailchimp);
			result.put("MCI1",false);
		}

		ComplexReportFactory.closeTest(etest);
		
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	public static boolean disableAndCheck(WebDriver driver) throws Exception
	{
		try
		{
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"MailChimp");
			Integration.clickDisableIntegration(driver,"MailChimp Integration disabled successfully",etest);

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Campaigns");
			Integration.clickDisableIntegration(driver,"Zoho Campaigns Integration disabled successfully",etest);

            navToWebsitesNewsLetter(driver);

			if(!CommonFunctions.getNewsLetterPresence(driver))
			{
				Websites.clickSave(driver,etest);
                WebsitesTab.closeEmbedConfig(driver,etest);
				etest.log(Status.PASS,"Checked");
				return true;
			}

			etest.log(Status.FAIL,"NewsLetter is present after disabling mailchimp and campaigns");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DisableAndCheck","Error");
			Websites.clickSave(driver,etest);
            WebsitesTab.closeEmbedConfig(driver,etest);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DisableAndCheck","Error",e);
		}
		return false;
	}

	public static boolean enableMailChimp(WebDriver driver) throws Exception
	{
		try
		{
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"MailChimp");
			Integration.clickEnableIntegration(driver,"MailChimp Integration enabled successfully",etest);

			navToWebsitesNewsLetter(driver);

			if(!CommonFunctions.getNewsLetterPresence(driver))
			{
				etest.log(Status.FAIL,"NewsLetter is not present after enabling mailchimp");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","DisableAndCheck","Error");
				Websites.clickSave(driver,etest);
                WebsitesTab.closeEmbedConfig(driver,etest);
				return false;
			}

			Websites.editNewsLetter(driver,etest);

			String header = PopUp.getHeader(driver).getText();
			String desc = PopUp.getDesc(driver).getText();
			String okbtn = PopUp.getOkBtn(driver).getText();

			String expected1 = "Newsletter Subscription";
			String expected2 = "You can display an option to your visitors to subscribe to your newsletters while submitting their info in the pre-chat survey. You can also customize the text you wish to display in the chat window.";

			if(!(header.contains(expected1) && desc.contains(expected2) && okbtn.contains("Next")))
			{
				etest.log(Status.FAIL,"Expected:"+expected1+"--"+expected2+"--Next--Actual:"+header+"--"+desc+"--"+okbtn+"--");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableMailChimp","Error");
				PopUp.clickClose(driver);
				Websites.clickSave(driver,etest);
                WebsitesTab.closeEmbedConfig(driver,etest);
				return false;
			}

			TakeScreenshot.infoScreenshot(driver,etest);

			closeMailChimpPopup(driver);

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableMailChimp","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static void closeMailChimpPopup(WebDriver driver) throws Exception
	{
		//click next, then click save to prevent failure due to ZLS-5625

		WebElement mailchimp_popup=null;
		//next button
		mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
		if(mailchimp_popup!=null)
		{
			HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
			CommonUtil.sleep(1500);
		}
		else
		{
			mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"Newsletter Subscription");
			if(mailchimp_popup!=null)
			{
				CommonFunctions.selectCampaignList(driver,"test1");
				PopUp.clickOkBtn(driver);
				CommonUtil.sleep(1500);
			}

			//save button
			mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}
		}
		TakeScreenshot.infoScreenshot(driver,etest);
		WebsitesTab.closeEmbedConfig(driver,etest);
		TakeScreenshot.infoScreenshot(driver,etest);
	}

	public static boolean enableCampaign(WebDriver driver) throws Exception
	{
		try
		{
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Campaigns");
			Integration.enableByDisablingOther(driver,"Zoho Campaigns Integration enabled successfully",1,etest);

			String header = PopUp.getHeader(driver).getText();
			String desc = PopUp.getDesc(driver).getText();
			String okbtn = PopUp.getOkBtn(driver).getText();

			String expected1 = "Enable Zoho Campaigns Integration";
			String expected2 = "You have already enabled MailChimp for your account. Please disable the existing integration to enable Zoho Campaigns.";
			String expected3 = "On disabling MailChimp, the data available in Visitor History, Operator Chat Window, Proactive Chat window and Newsletter subscription will also be disabled.";
			String expected4 = "Disable MailChimp & Enable Zoho Campaigns";

			if(!(header.contains(expected1) && desc.contains(expected2) && desc.contains(expected3) && okbtn.contains(expected4)))
			{
				etest.log(Status.FAIL,"Expected:"+expected1+"--"+expected2+"--"+expected3+"--"+expected4+"--Actual:"+header+"--"+desc+"--"+okbtn+"--");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error");
				Functions.refreshSiteAndWaitForRSID(driver);
				return false;
			}

			Integration.enableByDisablingOther(driver,"Zoho Campaigns Integration enabled successfully",2,etest);

			if(!Integration.checkEnable(driver))
			{
				etest.log(Status.FAIL,"Campaigns not enabled");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error");
				return false;
			}

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"MailChimp");
			
			if(Integration.checkDisable(driver))
			{
				etest.log(Status.PASS,"Checked");
				return true;
			}

			etest.log(Status.FAIL,"MailChimp is not disabled");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean enableMailChimpAndDisableCampaign(WebDriver driver) throws Exception
	{
		try
		{
			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"MailChimp");
			Integration.enableByDisablingOther(driver,"MailChimp Integration enabled successfully",1,etest);

			String header = PopUp.getHeader(driver).getText();
			String desc = PopUp.getDesc(driver).getText();
			String okbtn = PopUp.getOkBtn(driver).getText();

			String expected1 = "Enable MailChimp Integration";
			String expected2 = "You have already enabled Zoho Campaigns for your account. Please disable the existing integration to enable MailChimp.";
			String expected3 = "On disabling Zoho Campaigns, the data available in Visitor History, Operator Chat Window, Proactive Chat window and Newsletter subscription will also be disabled.";
			String expected4 = "Disable Zoho Campaigns & Enable MailChimp";

			if(!(header.contains(expected1) && desc.contains(expected2) && desc.contains(expected3) && okbtn.contains(expected4)))
			{
				etest.log(Status.FAIL,"Expected:"+expected1+"--"+expected2+"--"+expected3+"--"+expected4+"--Actual:"+header+"--"+desc+"--"+okbtn+"--");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error");
				Functions.refreshSiteAndWaitForRSID(driver);
				return false;
			}

			Integration.enableByDisablingOther(driver,"MailChimp Integration enabled successfully",2,etest);

			if(!Integration.checkEnable(driver))
			{
				etest.log(Status.FAIL,"MailChimp not enabled");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error");
				return false;
			}

			Tab.navToIntegrationTab(driver);
			Integration.selectIntegApp(driver,"Zoho Campaigns");
			
			if(Integration.checkDisable(driver))
			{
				etest.log(Status.PASS,"Checked");
				return true;
			}

			etest.log(Status.FAIL,"Zoho Campaigns is not disabled");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error");
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","EnableCampaign","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean configureListAndCheckEdit(WebDriver driver,final String list) throws Exception
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);

			CommonFunctions.selectCampaignList(driver,list);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}

			Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
			closeMailChimpPopup(driver);

			navToWebsitesNewsLetter(driver);
            
            WebElement el = Websites.getFieldEditButton(driver,"INTEGINFO0");

	        if(!Websites.getStatusFieldEditButton(el))
	        {
                etest.log(Status.FAIL,"Expected:Remove");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","ConfigureListAndCheckEdit","Error");
				Websites.clickSave(driver,etest);
                WebsitesTab.closeEmbedConfig(driver,etest);
				return false;
	        }

	        Websites.clickSave(driver,etest);
            WebsitesTab.closeEmbedConfig(driver,etest);
            
	        WebDriver visDriver = Functions.setUp();

	        try
	        {
	        	VisitorWindow.createPage(visDriver,widgetcode);
	        	if(VisitorWindow.checkCampaignPresenceInTheme(visDriver))
		        {
		        	etest.log(Status.PASS,"Checked");
		        	visDriver.quit();
		        	return true;
		        }

		        TakeScreenshot.screenshot(visDriver,etest,"MailChimp","ConfigureListAndCheckEdit","Error");
		        visDriver.quit();
	        }
	        catch(Exception e)
	        {
	        	TakeScreenshot.screenshot(visDriver,etest,"MailChimp","ConfigureListAndCheckEdit","Error",e);
	        	visDriver.quit();
	        }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","ConfigureListAndCheckEdit","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean configureAnotherListAndCheckEdit(WebDriver driver,final String list) throws Exception
	{
		try
		{
			navToWebsitesNewsLetter(driver);

			Websites.editNewsLetter(driver,etest);

			CommonFunctions.selectCampaignList(driver,list);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}

			Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
			closeMailChimpPopup(driver);

            navToWebsitesNewsLetter(driver);
            
            WebElement el = Websites.getFieldEditButton(driver,"INTEGINFO0");
            
            if(Websites.getStatusFieldEditButton(el))
	        {
	        	Websites.clickSave(driver,etest);
                WebsitesTab.closeEmbedConfig(driver,etest);
	        	etest.log(Status.PASS,"Checked");
	        	return true;
	        }

	        etest.log(Status.FAIL,"Expected:Remove");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","ConfigureAnotherListAndCheckEdit","Error");
			Websites.clickSave(driver,etest);
            WebsitesTab.closeEmbedConfig(driver,etest);
			return false;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","ConfigureAnotherListAndCheckEdit","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
        }
		return false;
	}

	public static boolean removeList(WebDriver driver) throws Exception
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.clickRemoveInNewsLetter(driver,etest);

            Websites.clickSave(driver,etest,true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            navToWebsitesNewsLetter(driver);
            
            WebElement el = Websites.getFieldEditButton(driver,"INTEGINFO0");
            
            if(Websites.getStatusFieldEditButton(el))
            {
                TakeScreenshot.screenshot(driver,etest,"MailChimp","ClickRemove","Error");
                Websites.clickSave(driver,etest);
                WebsitesTab.closeEmbedConfig(driver,etest);
                return false;
            }
            
            Websites.clickSave(driver,etest);
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = Functions.setUp();

	        try
	        {
	        	VisitorWindow.createPage(visDriver,widgetcode);
	        	if(!VisitorWindow.checkCampaignPresenceInTheme(visDriver))
		        {
		        	visDriver.quit();
		        	etest.log(Status.PASS,"Checked");
		        	return true;
		        }

		        TakeScreenshot.screenshot(visDriver,etest,"MailChimp","RemoveList","Error");
		        visDriver.quit();
	        }
	        catch(Exception e)
	        {
	        	TakeScreenshot.screenshot(visDriver,etest,"MailChimp","RemoveList","Error",e);
	        	visDriver.quit();
	        }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","RemoveList","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean checkMailChimpConfigDialogBox(WebDriver driver,String list) throws Exception
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);

			CommonFunctions.selectCampaignList(driver,list);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			// ensure popup is actually displayed -- just in case
			Thread.sleep(1000);

			WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Push visitor data from SalesIQ to MailChimp");

			String desc = CommonUtil.elementfinder(driver,popup,"classname","zc_cnfig_desc").getText();
            
            String d1 = desc.replace("A standard field ","").replace(" is mapped by default to push the data from SalesIQ to MailChimp, which cannot be edited or deleted. If you wish to push more visitor data from the SalesIQ fields to MailChimp fields, you can click on the \"Add More\" link and choose the field available in SalesIQ, and also choose the similar field in MailChimp. The data fetched by SalesIQ will be automatically reflected in the chosen fields of MailChimp.","");
			
			String expected = "A standard field $EMAIL is mapped by default to push the data from SalesIQ to MailChimp, which cannot be edited or deleted. If you wish to push more visitor data from the SalesIQ fields to MailChimp fields, you can click on the \"Add More\" link and choose the field available in SalesIQ, and also choose the similar field in MailChimp. The data fetched by SalesIQ will be automatically reflected in the chosen fields of MailChimp.";
            
            expected = expected.replace("$EMAIL",d1);
			
			if(!(desc.contains(expected)))
			{
				etest.log(Status.FAIL,"Expected:"+expected+"--Actual:"+desc+"--");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckMailChimpConfigDialogBox","Error");
                Functions.refreshSiteAndWaitForRSID(driver);
				return false;
			}

			if(CommonFunctions.verifyFields(driver,1,"Email","Email Address",etest))
			{
				closeMailChimpPopup(driver);
		        etest.log(Status.PASS,"Checked");
			    return true;
			}

			TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckMailChimpConfigDialogBox","Error");
			closeMailChimpPopup(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckMailChimpConfigDialogBox","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean addFieldAndCheck(WebDriver driver,String list,String lhs,String rhs) throws Exception
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);

			CommonFunctions.selectCampaignList(driver,list);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			CommonFunctions.clickAddmoreInMailChimpConfigDialogBox(driver);

			CommonFunctions.setFields(driver,2,1,lhs);

			CommonFunctions.setFields(driver,2,2,rhs);

			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
            closeMailChimpPopup(driver);

			navToWebsitesNewsLetter(driver);
            
            Websites.editNewsLetter(driver,etest);

			PopUp.clickOkBtn(driver);

			if(CommonFunctions.verifyFields(driver,2,lhs,rhs,etest))
			{
				closeMailChimpPopup(driver);
		        etest.log(Status.PASS,"Checked");
			    return true;
			}

			TakeScreenshot.screenshot(driver,etest,"MailChimp","AddFieldAndCheck","Error");
			closeMailChimpPopup(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","AddFieldAndCheck","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean deleteField(WebDriver driver,int row) throws Exception 
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			CommonFunctions.clickDelete(driver,row);

			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
            closeMailChimpPopup(driver);

            navToWebsitesNewsLetter(driver);
            
            Websites.editNewsLetter(driver,etest);
            
            PopUp.clickOkBtn(driver);

			final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","configtable");

			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(div.getAttribute("innerHTML").contains("col1_1"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

			if(!div.getAttribute("innerHTML").contains("col1_"+row))
			{
		        etest.log(Status.PASS,"Checked");
                closeMailChimpPopup(driver);
			    return true;
			}

			etest.log(Status.FAIL,row+" is not deleted");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error");
			closeMailChimpPopup(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean checkDisableAndEnable(WebDriver driver,int row) throws Exception 
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			CommonFunctions.clickDisable(driver,row);

			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
            closeMailChimpPopup(driver);

            navToWebsitesNewsLetter(driver);
            
            Websites.editNewsLetter(driver,etest);

			PopUp.clickOkBtn(driver);

			WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","configtable");

			if(!div.findElements(By.className("list-row")).get(row).getAttribute("class").contains("greyout"))
			{
				etest.log(Status.FAIL,row+" is not disabled");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error");
				closeMailChimpPopup(driver);
				return false;
			}

			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error",0);
			CommonFunctions.clickEnable(driver,row);

			mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
            closeMailChimpPopup(driver);

            navToWebsitesNewsLetter(driver);
            
            Websites.editNewsLetter(driver,etest);

			PopUp.clickOkBtn(driver);

			div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","configtable");

			if(div.findElements(By.className("list-row")).get(row).getAttribute("class").contains("greyout"))
			{
				etest.log(Status.FAIL,row+" is not enabled");
				TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error");
				closeMailChimpPopup(driver);
				return false;
				
			}

			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error",0);
			closeMailChimpPopup(driver);
	        etest.log(Status.PASS,"Checked");
		    return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean checkDisableAndDelete(WebDriver driver,int row) throws Exception 
	{
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);

			PopUp.clickOkBtn(driver);

			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);

			CommonFunctions.clickDisable(driver,row);

			CommonFunctions.clickDelete(driver,row);

			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}

            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
            closeMailChimpPopup(driver);

            navToWebsitesNewsLetter(driver);
            
            Websites.editNewsLetter(driver,etest);
            
            PopUp.clickOkBtn(driver);

			final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"id","configtable");

			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(div.getAttribute("innerHTML").contains("col1_1"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

			if(!div.getAttribute("innerHTML").contains("col1_"+row))
			{
				closeMailChimpPopup(driver);
		        etest.log(Status.PASS,"Checked");
			    return true;
			}

			etest.log(Status.FAIL,row+" is not deleted");
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error");
			closeMailChimpPopup(driver);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","DeleteField","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean addTrigger(WebDriver driver,WebDriver mailchimp,String period,String time, String visitorUsecase) throws Exception
	{
		try
		{
			MailChimpSite.clearMailchimpLists(mailchimp,etest);
			TakeScreenshot.infoScreenshot(mailchimp,etest);
			String embedname = ExecuteStatements.getDefaultEmbedName(driver);
			Trigger.addTrigger(driver,etest,"Leaves my website","Visitor Type","is equal to","All",null,"Add to mailing list",null,null,null);
			TakeScreenshot.infoScreenshot(driver,etest);
			String id=Trigger.getRuleId(driver,0);
			Trigger.openRuleEditView(driver,id);
			TakeScreenshot.infoScreenshot(driver,etest);
			Trigger.selectActionMailingList(driver,id);
			CommonUtil.getElement(driver,By.id("actionarea_"+id),By.tagName("input")).click();
			CommonWait.waitTillDisplayed(HandleCommonUI.getPopupByInnerText(driver,"Add visitors to the Campaign Mailing List"));
			TakeScreenshot.infoScreenshot(driver,etest);
			Trigger1.addToMailingList(driver,"Create new list/"+time+"/"+period);
			TakeScreenshot.infoScreenshot(driver,etest);
			CommonUtil.clickWebElement(driver,By.id("ruleembed_edit_div"));
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("ruleembed_edit_ddown"),By.tagName("ul")).findElements(By.tagName("li")),"title",embedname));
			TakeScreenshot.infoScreenshot(driver,etest);
	        Trigger.saveRule(driver,etest,id);
			TakeScreenshot.infoScreenshot(driver,etest);


			etest.log(Status.INFO,"TRIGGER FOR CAMPAIGNS ADDED EXCEPT POPUP?");
			TakeScreenshot.infoScreenshot(driver,etest);

			Tab.clickIntelligentTrigger(driver);
			TakeScreenshot.infoScreenshot(driver,etest);

			Thread.sleep(4000);

			String list = "L"+time;

			if(period.equals("Monthly"))
			{
                Calendar now = Calendar.getInstance();
                list = list+" "+theMonth(now.get(Calendar.MONTH))+" "+Calendar.getInstance().get(Calendar.YEAR);
                //list += " January 2017";
			}
			else if(period.equals("Weekly"))
			{
                list = list+" "+getWeek()+" "+Calendar.getInstance().get(Calendar.YEAR);
				//list += " 3rd week of January 2017";
			}

			try
			{
			TakeScreenshot.infoScreenshot(driver,etest);
				if(!MailChimpSite.checkList(mailchimp,list))
				{
					etest.log(Status.FAIL,list+" is not present");
					TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","AddTrigger"+period,"Error");
					return false;
				}
				if(!MailChimpSite.checkDetails(mailchimp,etest,list,"email@"+time+".com","N"+time,"R"+time))
				{
					TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","AddTrigger"+period,"Error");
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","AddTrigger"+period,"Error",e);
				return false;
			}

			WebDriver visDriver = Functions.setUp();

			Long visitor = new Long(System.currentTimeMillis());

			try
			{
				VisitorWindow.createPage(visDriver,widgetcode);
				VisitorsOnline.waitTillVisitorTracked(driver,visDriver);
				VisitorWindow.initiateChatVisTheme(visDriver,"V"+visitor,"email@"+visitor+".com","12345","Q"+visitor,etest);
				Thread.sleep(5000);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"MailChimp","AddTrigger"+period,"Error",e);
				visDriver.quit();
				return false;
			}

            if(!ChatWindow.chatNotificationPresence(driver,etest,20))
            {
                TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckVisitorInList","NoChatNotification");
                return false;
            }
            
            try
            {
                VisitorWindow.waitTillChatisMissedInTheme(visDriver);
                visDriver.quit();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"MailChimp","CheckVisitorInList","Error",e);
                visDriver.quit();
                return false;
            }
            
            listname.put(visitorUsecase,list);
            visitorname.put(visitorUsecase,"email@"+visitor+".com");
            timeInterval.put(visitorUsecase,new Long(System.currentTimeMillis()));
            
            etest.log(Status.INFO,"List:"+list);
            etest.log(Status.INFO,"Email:"+"email@"+visitor+".com");
            
			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","AddTrigger"+period,"Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}

	public static boolean checkVisitorInList(WebDriver driver,WebDriver mailchimp,boolean check) throws Exception
	{
		final String list = "test1";
		try
		{
			navToWebsitesNewsLetter(driver);

            Websites.editNewsLetter(driver,etest);
            			etest.log(Status.INFO,"edit news letter");
			TakeScreenshot.infoScreenshot(driver,etest);


			CommonFunctions.selectCampaignList(driver,list);
			etest.log(Status.INFO,"select camp list");
			TakeScreenshot.infoScreenshot(driver,etest);


			PopUp.clickOkBtn(driver);
						etest.log(Status.INFO,"clicked ok button  ");
			TakeScreenshot.infoScreenshot(driver,etest);


			CommonFunctions.waitTillMailChimpConfigDialogBoxOpens(driver);
						etest.log(Status.INFO,"Mail chimp dialog opens");
			TakeScreenshot.infoScreenshot(driver,etest);


			WebElement mailchimp_popup=HandleCommonUI.getPopupByInnerText(driver,"SalesIQ to MailChimp");
			if(mailchimp_popup!=null)
			{
				HandleCommonUI.clickPositivePopupButton(mailchimp_popup);
				CommonUtil.sleep(1500);
			}

			etest.log(Status.INFO,"mailchimp dialog ok clicked ");
			TakeScreenshot.infoScreenshot(driver,etest);

            Tab.waitForLoadingSuccessWithBanner(driver,"Changes saved successfully. We have reflected the changes on the website where the live chat code is embedded. You can refresh the browser and view the changes.","upembedprops.do",etest);
            closeMailChimpPopup(driver);
            
            			etest.log(Status.INFO,"Saved the changes ");
			TakeScreenshot.infoScreenshot(driver,etest);

            
            WebDriver visDriver = Functions.setUp();

	        Long visitor = new Long(System.currentTimeMillis());

			try
			{
				VisitorWindow.createPage(visDriver,widgetcode);
				if(check)
				{
					VisitorWindow.clickCampaignCheckBoxInTheme(visDriver);
								etest.log(Status.INFO,"click camp checkbox");
			TakeScreenshot.infoScreenshot(visDriver,etest);

				}
				VisitorWindow.initiateChatVisTheme(visDriver,"V"+visitor,"email@"+visitor+".com","12345","Q"+visitor,etest);
				Thread.sleep(5000);
            }
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"MailChimp","CheckVisitorInList","Error",e);
				visDriver.quit();
				return false;
			}
            
            if(!ChatWindow.chatNotificationPresence(driver,etest,20))
            {
                TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckVisitorInList","NoChatNotification");
                return false;
            }
            
            try
            {
                VisitorWindow.waitTillChatisMissedInTheme(visDriver);
                visDriver.quit();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"MailChimp","CheckVisitorInList","Error",e);
                visDriver.quit();
                return false;
            }

			try
			{

			etest.log(Status.INFO,"check list");
			TakeScreenshot.infoScreenshot(driver,etest);


				if(!MailChimpSite.checkList(mailchimp,list))
				{
					etest.log(Status.FAIL,list+" is not present");
					TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","CheckVisitorInList","Error");
					return false;
				}
				boolean presence = MailChimpSite.checkVisitor(mailchimp,"email@"+visitor+".com");
				if(presence != check)
				{
					if(check)
					{
						etest.log(Status.FAIL,"email@"+visitor+".com is not present");
					}
					else
					{
						etest.log(Status.FAIL,"email@"+visitor+".com is present");
					}
					TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","CheckVisitorInList","Error");
					return false;
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","CheckVisitorInList","Error",e);
				return false;
			}

			etest.log(Status.PASS,"Checked");
			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"MailChimp","CheckVisitorInList","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);
		}
		return false;
	}
    
    public static Boolean checkVisitorInMailChimpForTriggers(WebDriver mailchimp,String usecase) throws Exception
    {
        try
        {
            String list = listname.get(usecase);
            String email = visitorname.get(usecase);
            Long t1 = timeInterval.get(usecase);
            
            etest.log(Status.INFO,"List:"+list);
            etest.log(Status.INFO,"Email:"+email);
            
            if(list.equals("No value") || email.equals("No value"))
            {
                etest.log(Status.FAIL,"Depended use case failed");
                return false;
            }
            
            for(;;)
            {
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2 - t1 >= 300000)
                {
                    break;
                }
            }
            
            if(!MailChimpSite.checkList(mailchimp,list))
            {
                etest.log(Status.FAIL,list+" is not present");
                TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","AddTriggerAndCheck","Error");
                return false;
            }
            if(!MailChimpSite.checkVisitor(mailchimp,email))
            {
                etest.log(Status.FAIL,email+" is not present");
                TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","AddTriggerAndCheck","Error");
                return false;
            }
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(mailchimp,etest,"MailChimp","AddTriggerAndCheck","Error",e);
            return false;
        }
    }
    
    public static String getWeek()
    {
        Calendar now = Calendar.getInstance();
        int i = now.get(Calendar.WEEK_OF_MONTH);
        int j = now.get(Calendar.MONTH);
        String week = ""+i;
        switch(week)
        {
            case "1": return "1st week of "+theMonth(j);
            case "2": return "2nd week of "+theMonth(j);
            case "3": return "3rd week of "+theMonth(j);
            case "4": return "4th week of "+theMonth(j);
            case "5": return "5th week of "+theMonth(j);
            default : return "cannot be determined";
        }
    }
    
    public static String theMonth(int month){
        String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        return monthNames[month];
    }
    
    public static void navToWebsitesNewsLetter(WebDriver driver) throws Exception
    {
    	String embedname = ExecuteStatements.getDefaultEmbedName(driver);
    	Tab.clickSettings(driver);
        Tab.clickEmbedTab(driver);
        WebEmbed.clickWebEmbed(driver,embedname,etest);
        WebsitesTab.clickLiveChat(driver,etest);
        WebsitesTab.clickChatWindow(driver,etest);
        WebsitesTab.clickFields(driver,etest);
    }
}
