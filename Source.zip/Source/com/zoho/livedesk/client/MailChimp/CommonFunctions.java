//$Id$
package com.zoho.livedesk.client.MailChimp;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.*;
import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;

import com.google.common.base.Function;

public class CommonFunctions
{	
    public static boolean getNewsLetterPresence(WebDriver driver) throws Exception
    {
        return Websites.checkNewsletter(driver);
    }

	public static void hoverNewsLetter(WebDriver driver,final String content,boolean edit,boolean remove) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embeddetail"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embeddetail"))); 

        WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","embeddetail"),"id","campstr");

        CommonUtil.mouseHover(driver,div);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	            	WebElement e = driver.findElement(By.id("embeddetail")).findElement(By.id("campstr")).findElement(By.id("editnewslet"));
	            	
	            	if(content == null)
	            	{
	            		if(e.getText().contains("Configure") || e.getText().contains("Edit"))
		                {
							return true;
		                }
	            	}
	            	else
	            	{
		                if(e.getText().contains(content))
		                {
							return true;
		                }
		            }
	            }
	            catch(StaleElementReferenceException e){}
                return false;
            }
        });
        
        Thread.sleep(1500);

        div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","embeddetail"),"id","campstr");

        if(edit)
        {
        	CommonUtil.elementfinder(driver,div,"id","editnewslet").click();

        	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        	wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("mchimplogo"))
					{
						return true;
					}
	                return false;
	            }
	        });

	        WebElement logo = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","popupdiv"),"classname","mchimplogo");

	        wait.until(ExpectedConditions.visibilityOf(logo)); 
        }
        else if(remove)
        {
        	CommonUtil.elementfinder(driver,div,"id","removecamp").click();

            Tab.waitForLoadingLine(driver);

        	hoverNewsLetter(driver,"Configure",false,false);
        }
        
	}

	public static void selectCampaignList(WebDriver driver,String list_name) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("popupdiv")).getAttribute("innerHTML").contains("syncinput_div"))
                {
					return true;
                }
                return false;
            }
        });

        WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

		CommonUtil.elementfinder(driver,popup,"id","syncinput_div").click();

		WebElement div = CommonUtil.elementfinder(driver,popup,"classname","ullist");

		wait.until(ExpectedConditions.visibilityOf(div));

		WebElement x = null;

		List<WebElement> list = div.findElements(By.tagName("li"));

		for(WebElement e : list)
		{
			CommonUtil.inViewPort(e);
			if(e.getText().contains(list_name))
			{
				x = e;
				break;
			}
			else if(e.getText().contains("No search results found"))
			{
				System.out.println("<><><><><><><><><><><><><><><><><><><><>");
			}
		}

		x.click();
	}

	public static void waitTillMailChimpConfigDialogBoxOpens(WebDriver driver) throws Exception
	{
		// FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
  //       wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
  //       wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

  //       wait.until(new Function<WebDriver,Boolean>(){
  //           public Boolean apply(WebDriver driver)
  //           {
  //           	try
  //           	{
	 //                if(PopUp.getHeader(driver).getText().contains("Push visitor data from SalesIQ to MailChimp"))
	 //                {
		// 				return true;
	 //                }
	 //           	}
	 //           	catch(Exception e){}
  //               return false;
  //           }
  //       });

		WebElement popup = HandleCommonUI.getPopupByInnerText(driver,"Push visitor data from SalesIQ to MailChimp");
		CommonWait.waitTillDisplayed(popup);
	}

	public static void clickAddmoreInMailChimpConfigDialogBox(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	                if(popup.getText().contains("Add More..."))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
                return false;
            }
        });

        final WebElement add = CommonUtil.elementfinder(driver,popup,"xpath",".//div[@documentclick='campaddmore']");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	                if(add.getText().equals("Add More..."))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
                return false;
            }
        });

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        final int initial = e.findElements(By.className("list-row")).size();
		
        add.click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
            	try
            	{
	                if(add.getAttribute("style").contains("none"))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
                return false;
            }
        });

		wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	        	try
	        	{
	        		int final_count = e.findElements(By.className("list-row")).size();

	                if(final_count == initial+1)
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
	            return false;
	        }
		});
	}

	public static void setFields(WebDriver driver,final int row,int column,String value) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        CommonUtil.elementfinder(driver,e,"id","col"+column+"_"+row+"_div").click();

        final WebElement dropDown = CommonUtil.elementfinder(driver,e,"id","col"+column+"_"+row+"_ddown");

        wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	        	try
	        	{
	        		if(!dropDown.getAttribute("style").contains("none") && dropDown.getAttribute("style").contains("block"))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
	            return false;
	        }
		});

		List<WebElement> list = dropDown.findElements(By.tagName("li"));

		for(WebElement field : list)
		{
			CommonUtil.inViewPort(field);
			if(CommonUtil.elementfinder(driver,field,"tagname","span").getText().contains(value))
			{
				field.click();
                break;
			}
		}

		wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	        	try
	        	{
	        		if(dropDown.getAttribute("style").contains("none") && !dropDown.getAttribute("style").contains("block"))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
	            return false;
	        }
		});

		if(column == 1)
		{
			wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {
		        	try
		        	{
		        		if(e.getAttribute("innerHTML").contains("col2_"+row+"_div"))
		                {
							return true;
		                }
		           	}
		           	catch(Exception e){}
		            return false;
		        }
			});
		}
	}

	public static boolean verifyFields(WebDriver driver,int row,String lhs,String rhs,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        String lhs1 = CommonUtil.elementfinder(driver,e,"id","col1_"+row).getText();
        String rhs1 = CommonUtil.elementfinder(driver,e,"id","col2_"+row).getText();

        if(row != 1)
        {
        	lhs1 = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","col1_"+row),"tagname","span").getText();
        	rhs1 = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,e,"id","col2_"+row),"tagname","span").getText();
        }

        if(lhs1.contains(lhs) && rhs1.contains(rhs))
        {
        	return true;
        }

        etest.log(Status.FAIL,"Expected:"+lhs+"--"+rhs+"--Actual:"+lhs1+"--"+rhs1+"--");
        return false;
	}

	public static void clickDisable(WebDriver driver,int row) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,5,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        final WebElement field = e.findElements(By.className("list-row")).get(row);

        CommonUtil.mouseHover(driver,field);

        WebElement action = CommonUtil.elementfinder(driver,field,"classname","sqico-enable");

        action.click();

        wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	        	try
	        	{
	        		if(field.getAttribute("class").contains("greyout"))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
	            return false;
	        }
		});
	}

	public static void clickEnable(WebDriver driver,int row) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,5,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        final WebElement field = e.findElements(By.className("list-row")).get(row);

        CommonUtil.mouseHover(driver,field);

        WebElement action = CommonUtil.elementfinder(driver,field,"classname","sqico-enable");

        action.click();

        wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	        	try
	        	{
	        		if(!field.getAttribute("class").contains("greyout"))
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
	            return false;
	        }
		});
	}

	public static WebElement getDelete(WebDriver driver,int row) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        WebElement field = e.findElements(By.className("list-row")).get(row);

        CommonUtil.mouseHover(driver,field);

        WebElement action = CommonUtil.elementfinder(driver,field,"classname","sqico-delico");

        wait.until(ExpectedConditions.visibilityOf(action));

        return action;
	}

	public static void clickDelete(WebDriver driver,int row) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv"))); 
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv"))); 

        final WebElement popup = CommonUtil.elfinder(driver,"id","popupdiv");

        final WebElement e = CommonUtil.elementfinder(driver,popup,"id","configtable");

        final int initial = e.findElements(By.className("list-row")).size();

		getDelete(driver,row).click();

		wait.until(new Function<WebDriver,Boolean>(){
	        public Boolean apply(WebDriver driver)
	        {
	        	try
	        	{
	        		int final_count = e.findElements(By.className("list-row")).size();
	        		if(final_count == initial-1)
	                {
						return true;
	                }
	           	}
	           	catch(Exception e){}
	            return false;
	        }
		});
	}

	public static void removeConfiguredNewLetter(WebDriver driver,ExtentTest etest)
	{
		try
		{
            MailChimpIntegration.navToWebsitesNewsLetter(driver);
            
            Websites.clickRemoveInNewsLetter(driver,etest);

            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
        }
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void deleteTriggerRule(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);
			etest.log(Status.INFO,"Triggers were deleted");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
