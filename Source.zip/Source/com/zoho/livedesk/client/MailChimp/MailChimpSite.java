//$Id$
package com.zoho.livedesk.client.MailChimp;

import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.*;
import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;

import com.google.common.base.Function;

public class MailChimpSite
{	
    public static boolean checkList(WebDriver driver,final String list_name) throws Exception
    {
        String url="https://us14.admin.mailchimp.com/lists/";
        driver.get(url);
        By list_name_locator=By.cssSelector("[href*='lists/members/'][title*='name']");
        List<WebElement> list_elements=CommonUtil.getElements(driver,list_name_locator);
        List<String> list_names=CommonUtil.getAttributesFromList( list_elements , "innerText" );
        boolean isContains=CommonUtil.isListContains(list_names,list_name);

        WebElement list_ele=CommonUtil.getElementByAttributeValue(list_elements,"innerText",list_name);
        CommonUtil.clickWebElement(driver,list_ele);
        CommonWait.waitTillHidden(list_ele);

        return isContains;
    }

    public static boolean checkDetails(WebDriver driver,ExtentTest etest,String list,String fromMail,String fromName,String subject) throws Exception
    {
        CommonUtil.click(driver,By.cssSelector("[title='Audience settings']"));
        CommonWait.waitTillDisplayed(driver,By.cssSelector("[href*='/lists/settings/defaults']"));
        CommonUtil.click(driver,By.cssSelector("[href*='/lists/settings/defaults']"));
        CommonWait.waitTillHidden(driver,By.cssSelector("[href*='/lists/settings/defaults']"));
         
         String s1 = CommonUtil.elfinder(driver, "xpath", "//input[@id='list-name']").getAttribute("value");
         String s2 = CommonUtil.elfinder(driver, "xpath", "//input[@id='default-fromname']").getAttribute("value");
         String s3 = CommonUtil.elfinder(driver, "xpath", "//input[@id='default-fromemail']").getAttribute("value");
         String s4 = CommonUtil.elfinder(driver, "xpath", "//input[@id='default-subject']").getAttribute("value");
         
         if(s1.equals(list) && s2.equals(fromMail) && s3.equals(fromName) && s4.equals(subject))
         {
         	etest.log(Status.FAIL,"Expected:"+list+"--"+fromMail+"--"+fromName+"--"+subject+"--Actual:"+s1+"--"+s2+"--"+s3+"--"+s4+"--");
         	return false;
         }
         
         return true;
    }

    public static boolean checkVisitor(WebDriver driver,String visitor) throws Exception
    {
        By date_added_button_locator=By.cssSelector("[data-mojo-table-sort='optin_time']");
        
        WebElement date_added=CommonUtil.getElement(driver,date_added_button_locator);
        CommonWait.waitTillDisplayed(date_added);
        CommonUtil.clickWebElement(driver,date_added);
        CommonUtil.sleep(5*1000);

        date_added=CommonUtil.getElement(driver,date_added_button_locator);
        CommonWait.waitTillDisplayed(date_added);
        CommonUtil.clickWebElement(driver,date_added);
        CommonUtil.sleep(5*1000);

        return CommonUtil.isContains(visitor, CommonUtil.getElement(driver,By.className("subscriber-table-wrap")).getAttribute("innerText") );
    }

    public static void clearMailchimpLists(WebDriver driver,ExtentTest etest)
    {
        try
        {
            driver.get("https://us14.admin.mailchimp.com/lists/");
            CommonUtil.clickWebElement(driver,By.id("dojox_form_TriStateCheckBox_0"));

            List<WebElement> mailchimpList = CommonUtil.getElement(driver,By.id("lists")).findElements(By.tagName("li"));

            for(WebElement list : mailchimpList)
            {
                if(list.getText().contains("test1") || list.getText().contains("test2"))
                {
                    CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(list,By.tagName("input"),"type","checkbox"));
                }
            }
            CommonUtil.clickWebElement(driver,By.id("delete-btn"));

            CommonUtil.sleep(2000);

            if(driver.findElement(By.id("dijit_Dialog_0")).isDisplayed())
            {
                driver.findElement(By.id("dijit__Templated_0-confirm-text")).click();
                driver.findElement(By.id("dijit__Templated_0-confirm-text")).sendKeys("DELETE");
                driver.findElement(By.id("dijit_Dialog_0")).findElement(By.className("dijitDialogPaneActionBar")).findElement(By.id("dijit_form_Button_1_label")).click();
            }

            etest.log(Status.INFO,"List has been cleared");
            TakeScreenshot.infoScreenshot(driver,etest);
        }
        catch(Exception e)
        {
            CommonUtil.printStackTrace(e);
        }
    }
}
