//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class AAgentsSettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    
	private static String url = ConfManager.getLoginURL();
	private static String requrl = "";
	public static ExtentTest etest; 

    public static final String
    MODULE_NAME = "OperatorSettings-Associate"
    ;
    
	public static Hashtable agentsConfig(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU1"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            requrl = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
			etest.log(Status.PASS,"OperatorSettingsTab is present");

            result.put("ASU1", true);
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU2"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU2", isPageAvail(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU3"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU3", isaddPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU4"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU4", isHeadersPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU5"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU5", isActionPresent(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU6"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU6", !(checkprofile(driver,"LDSupervisor",true)));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU7"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU7", checkprofile(driver,"LDAssociate",false));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASU8"));
            ComplexReportFactory.setValues(etest,"Automation","OperatorSettings-Associate");

            result.put("ASU8", !(checkprofile(driver,"LDAutomation",true)));

            ComplexReportFactory.closeTest(etest);

            AgentsSettings.init();

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("ASU9"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ASU9",AgentsSettings.checkOperatorStatusChangeOption(driver,AgentsSettings.admin_email,false,etest));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("ASU10"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ASU10",AgentsSettings.checkOperatorStatusChangeOption(driver,AgentsSettings.supervisor_email,false,etest));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("ASU11"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("ASU11",AgentsSettings.checkOperatorStatusChangeOption(driver,AgentsSettings.associate_email,false,etest));
            ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","OperatorSettingsTab","ErrorWhileCheckingOperatorSettingsTab",e);

            result.put("ASU1", false);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","OperatorSettingsTab","ErrorWhileCheckingOperatorSettingsTab",e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            result.put("ASU1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	//Check Users Settings Page avail
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
			
            Thread.sleep(1000);
			List<WebElement> texts = driver.findElements(By.className("innersubinfotxt"));
            
			if(((texts.get(0).getText()).contains(ResourceManager.getRealValue("supervisor_settings_agents_desc1"))) && (((texts.get(1).getText()).contains(ResourceManager.getRealValue("supervisor_settings_agents_desc2")))))
			{
		 		etest.log(Status.PASS,"Description matched");
                return true;
			}
            else{
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","OperatorSettingsPage","DescriptionMismatch");
            }
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","OperatorSettingsPage","ErrorWhileCheckingOperatorSettingsPage",e);
            System.out.println("Exception while checking if Operators settings page is available in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"OperatorSettingss-Associate","OperatorSettingsPage","ErrorWhileCheckingOperatorSettingsPage",e);
            System.out.println("Exception while checking if Operators settings page is available in associate login : "+e);
			return false;
		}
		return false;
	}
	
	//Check for add button
    private static boolean isaddPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            try
            {
                driver.findElement(By.id("buttonuseradd")).click();
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckAddButton","AddButtonIsPresent");
                return false;
            }
            catch(NoSuchElementException e)
            {
                etest.log(Status.PASS,"Add Button is not present");
                return true;
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,"Add Button is not present");
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckAddButton","ErrorWhileCheckingAddButton",e);
            System.out.println("Exception while checking if add button is present in Operator settings in associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckAddButton","ErrorWhileCheckingAddButton",e);
            System.out.println("Exception while checking if add button is present in Operator settings in associate login : "+e);
            return false;
        }
    }
    
    //Check if headers are present
    private static boolean isHeadersPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            List<WebElement> elmts = driver.findElement(By.id("ulisttable")).findElement(By.className("list_header")).findElements(By.className("list_cell"));
            
            if(((elmts.get(0).getText()).equals("Name"))&&((elmts.get(1).getText()).equals("Role"))&&((elmts.get(2).getText()).equals("Email")))
            {
                etest.log(Status.PASS,"HeaderIsPresent");
                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckHeader","HeaderisNotPresent");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckHeader","Error",e);
            System.out.println("Exception while checking if headers are present in Operator settings in associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckHeader","Error",e);
            System.out.println("Exception while checking if headers are present in Operator settings in associate login : "+e);
            return false;
        }
    }
	
    //Check for presence of action
    private static boolean isActionPresent(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            if((driver.findElement(By.id("ulisttable")).findElement(By.className("list_header")).getText()).contains("Action"))
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckActions","ActionsIsPresent");
                return false;
            }
            etest.log(Status.PASS,"Actions is not present");
            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckActions","ErrorWhileCheckingActions",e);
            System.out.println("Exception while checking if actions header is present in Operator settings in associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckActions","ErrorWhileCheckingActions",e);
            System.out.println("Exception while checking if actions header is present in Operator settings in associate login : "+e);
            return false;
        }
    }
    
    //Check agent profiles
    private static boolean checkprofile(WebDriver driver,String agent,boolean screenshot)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_users"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_users"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
            
            List<WebElement> elmts = driver.findElement(By.id("ulisttable")).findElements(By.className("list-row"));
            
            for(WebElement elmt:elmts)
            {
                WebElement elmts1 = elmt.findElement(By.className("list_cell")).findElement(By.className("txtelips"));
                
                if((elmts1.getText()).equals(agent))
                {
                    elmts1.click();
                    break;
                }
            }
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
            Thread.sleep(1000);
            
            if((driver.findElement(By.id("userdetails")).findElement(By.className("myprfdtlmn")).findElement(By.className("myprfdtlmn_rht")).getText()).equals(agent))
            {
                if(screenshot)
                {
                    TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckProfile:"+agent,"OperatorDetailsIsPresent");
                }
                else
                {
                    etest.log(Status.PASS,"Profile is checked for:"+agent);
                }
                return true;
            }
            if(!screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckProfile:"+agent,"OperatorsDetailsIsNotPresent");
            }
            else
            {
                etest.log(Status.PASS,"Profile is checked for:"+agent);
            }
            return false;
        }
        catch(NoSuchElementException e)
        {
            if(!screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckProfile:"+agent,"ErrorWhileCheckingProfile",e);
            }
            else
            {
                etest.log(Status.PASS,"Profile is checked for:"+agent);
            }
            System.out.println("Exception while checking if supervisor profile in Operator settings in associate login : "+e);
            return false;
        }
        catch(Exception e)
        {
            if(!screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"OperatorSettings-Associate","CheckProfile:"+agent,"ErrorWhileCheckingProfile",e);
            }
            else
            {
                etest.log(Status.PASS,"Profile is checked for:"+agent);
            }
            System.out.println("Exception while checking if supervisor profile in Operator settings in associate login : "+e);
            return false;
        }
    }
	
	//Mouse Over for hidden element
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		Thread.sleep(500);
		new Actions(driver).moveToElement(element).perform();
	}
}
