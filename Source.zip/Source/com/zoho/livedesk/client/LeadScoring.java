//$Id$
package com.zoho.livedesk.client;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class LeadScoring
{
    public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

	public static String companyname = null;
	public static String website = null;
	public static String address = null;
	public static String emailid = null;
	public static String telephone = null;
	public static String fax = null;
	public static String desc = null;
	public static String language = null;
	public static String timezone = null;
	private static String url = "";

    public static int rnum = 10;

    public static int maxcount = 0;
    public static ExtentTest etest;

    public static Hashtable leadscore(WebDriver driver)
    {
        try
        {
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS1"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            url = ConfManager.requestURL();
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));

            etest.log(Status.PASS,"LeadScoring Tab is present");

            result.put("SLS1",true);

            ComplexReportFactory.closeTest(etest);


            // checking trigger count update
            String embed_name1=ExecuteStatements.getDefaultEmbedName(driver);
            String widget_Code1 = ExecuteStatements.getWidgetCode(driver);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR34"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR34", com.zoho.livedesk.client.Triggers.ITRTime.getTriggerCountOnITRule(driver, etest, widget_Code1, embed_name1));         
            ComplexReportFactory.closeTest(etest);



            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS2"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS2",isPageAvail(driver));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS3"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS3",checkNotes(driver));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS4"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS4",checkAddButton(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS5"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS5",checkFields(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS6"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS6",addEmpty(driver));

            //String uuid = checkUUID(driver);

            //System.out.println("UUID of the user --------------------------------------->"+uuid);

            //checkVHistory(driver,uuid);

            ComplexReportFactory.closeTest(etest);

            //etest=ComplexReportFactory.getTest("Add Basic Criteria For Lead Scoring");
            //ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            addFull(driver);

            //ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS7"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS7",addScoreConditionSOR(driver));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS8"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS8",addScoreConditionSAND(driver));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS9"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS9",checkCRMddown(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable CRM");
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            addCRMrules(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS10"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS10",checkAdvConfig(driver));

            ComplexReportFactory.closeTest(etest);

            checkdropdown(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS57"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");


            rnum++;
            result.put("SLS57",addBasicCriteria(driver,"1","Time on Site","is more than","7",null,"Add","50"));           //------------------ Extra use case (To be deleted) -------------------//

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS58"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS58",disableCond(driver,"Time on Site","is more than","7",null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS59"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS59",enableCond(driver,"Time on Site","is more than","7",null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS60"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS60",deleteCond(driver,"Time on Site","is more than","7",null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS61"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS61",addBasicCriteria(driver,"1","Number of Visits","is more than","7",null,"Add","100"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS62"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS62",editRule(driver,"Number of Visits","is more than","7",null,"Add","100"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS63"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS63",disableDelete(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS64"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS64",addBasicCriteria(driver,"1","Number of Visits","is more than","7",null,"Add","100"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS65"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS65",enableDelete(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS66"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS66",addBasicCriteria(driver,"1","Triggered","is equal to","Glow button",null,"Add","140"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS67"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS67",editDisabledrule(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS68"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS68",addInvalidpoint(driver,"1","Number of Past Chats","is more than","7",null,"Less","!=0"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS69"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS69",addRulenoCriteria(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS70"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS70",addInvalidCriteria(driver,"1","Time on Site","is more than","12AB",null,"Less","254"));
            //rnum++;
            //result.put("SLS"+rnum,addInvalidCriteria(driver,"1","IP Address","is equal to","!@#$%^&*()",null,"Add","687"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS71"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS71",clickCancel(driver,"1","Time on Site","is less than","7",null,"Less","962"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS72"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            rnum++;
            result.put("SLS72",clickClosecheck(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR35"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR35",com.zoho.livedesk.client.Triggers.ITRTime.checkTriggerCountOnITRule(driver,etest, widget_Code1));
            com.zoho.livedesk.client.Triggers.CommonFunctions.deleteRule(driver);
            ComplexReportFactory.closeTest(etest);

            //rnum++;
            //result.put("SLS"+rnum,remSingleOR(driver));

            //checkLScoreRealTime(driver);

            //addData(driver);
            //addData1(driver);
            //addScoreConditionSAND(driver);
            //addScoreConditionSOR(driver);
        }
        catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorLeadScoringError");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","LeadScoringTab","ErrorWhileCheckingLeadScoringTab",e);

            result.put("SLS1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorLeadScoringError");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","LeadScoringTab","ErrorWhileCheckingLeadScoringTab",e);

            result.put("SLS1", false);
		}
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    //Click Add Button
    private static void clickAddButton(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddButton","ErrorWhileCheckingAddButton",e);

            System.out.println("Exception while clicking add button in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddButton","ErrorWhileCheckingAddButton",e);

            System.out.println("Exception while clicking add button in lead scoring page : "+e);
        }
    }

    //Close popup on failure
    private static void clickClose(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            WebElement elmt = driver.findElement(By.id("ldsettings"));
            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while clicking close on error in lead scoring : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clicking close on error in lead scoring : "+e);
        }
    }

    //Add points function
    private static void addPoints(WebDriver driver,String cond,String points)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

            if(cond.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            else if(cond.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddPoints","ErrorWhileAddingPoints",e);

            System.out.println("Exception while adding points in the popup in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddPoints","ErrorWhileAddingPoints",e);

            System.out.println("Exception while adding points in the popup in lead scoring page : "+e);
        }
    }

    //Page Availability check
    private static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
            //driver.findElement(By.id("innersubinfotxt"));

            if((driver.findElement(By.className("innersubinfotxt")).getText()).equals(ResourceManager.getRealValue("leadscoring_desc1")))
            {
                etest.log(Status.PASS,"LeadScoring Description is matched");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","LeadScoringPage","MismatchDescription");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","LeadScoringPage","ErrorWhileCheckingLeadScoringPage",e);

            System.out.println("Exception while checking if lead scoring page is available : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","LeadScoringPage","ErrorWhileCheckingLeadScoringPage",e);

            System.out.println("Exception while checking if lead scoring page is available : "+e);
        }
        return false;
    }

    //Check Notes at the bottom of the page
    private static boolean checkNotes(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.innersubinfotxt.clboth")));

            String checknote = driver.findElement(By.cssSelector("div.innersubinfotxt.clboth")).getText();

            if((checknote.contains("Note :"))&&(checknote.contains(ResourceManager.getRealValue("leadscoring_desc3")))&&(checknote.contains(ResourceManager.getRealValue("leadscoring_desc4"))))
            {
                etest.log(Status.PASS,"LeadScoring Tab Notes is present");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","NotesAtTheBottom","MismatchNotesContent");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","NotesAtTheBottom","ErrorWhileCheckingNotesContent",e);

            System.out.println("Exception while checking if notes at the bottom of the page in lead scoring page is available : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","NotesAtTheBottom","ErrorWhileCheckingNotesContent",e);

            System.out.println("Exception while checking if notes at the bottom of the page in lead scoring page is available : "+e);
        }
        return false;
    }

    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    //Check if Add Button is present
    private static boolean checkAddButton(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            CommonSikuli.findInWholePage(driver,"Leadscoredelete.png","UI250",etest);

            clickAddButton(driver);

            Thread.sleep(1000);

            if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
            {
                WebElement elmt = driver.findElement(By.id("ldsettings"));
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                etest.log(Status.PASS,"LeadScoring Add Button is present");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckAddButton","AddButtonIsNotPresent");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckAddButton","ErrorWhileCheckingAddButton",e);

            System.out.println("Exception while checking add button in lead scoring popup in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckAddButton","ErrorWhileCheckingAddButton",e);

            System.out.println("Exception while checking add button in lead scoring popup in lead scoring page : "+e);
        }
        return false;
    }

    //Check for fields to be available and enabled.
    private static boolean checkFields(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));

            clickAddButton(driver);

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            if((elmt.findElement(By.cssSelector("div.hdr.advhdr")).getText()).equals(ResourceManager.getRealValue("leadscoring_addheader")))
            {
                System.out.println("comes here1");
                if((elmt.findElement(By.id("prior1_col1_div")).getText()).equals("Choose a Condition"))
                {
                    System.out.println("comes here12");
                    if((elmt.findElement(By.id("prior1_col2_div")).getText()).equals("Choose a Criteria"))
                    {
                        System.out.println("comes here22");
                        //if(!((elmt.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1")).getAttribute("title"))!=null))
                        //{
                            System.out.println("comes here23");
                            if((elmt.findElement(By.id("points")).findElement(By.tagName("div")).findElements(By.className("uprdowrap")).get(0).findElement(By.tagName("span")).getAttribute("class")).contains("rdselected"))
                            {
                                System.out.println("comes here32");
                                elmt.findElement(By.id("addpoints"));
                                elmt.findElement(By.id("lesspoints"));
                                elmt.findElement(By.id("ldaddpoints"));
                                elmt.findElement(By.id("prior1_col1"));
                                elmt.findElement(By.id("prior1_col2"));
                                elmt.findElement(By.id("prior1_col3"));
                                elmt.findElement(By.id("prior1")).findElement(By.cssSelector("div.or.floatlf.opr"));
                                elmt.findElement(By.cssSelector("div.andwrp"));
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();

                                etest.log(Status.PASS,"LeadScoring Create Window Fields is checked");

                                return true;
                            }
                            else{
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckFields","DefaultSelectedPointsIsNotAdd");
                            }
                        //}
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckFields","MismatchContent:Choose A Criteria");
                    }
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckFields","MismatchContent:Choose A Condition");
                }
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckFields","MismatchContent:LeadScoringAddWindowHeader");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckFields","ErrorWhileCheckingFieldsInCreateLeadScoringWindow",e);

            System.out.println("Exception while checking if the fields in lead scoring popup are available and enabled in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckFields","ErrorWhileCheckingFieldsInCreateLeadScoringWindow",e);

            System.out.println("Exception while checking if the fields in lead scoring popup are available and enabled in lead scoring page : "+e);
        }
        return false;
    }

    //Add A rule with Empty fields and check
    private static boolean addEmpty(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            clickAddButton(driver);

            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            elmt.findElement(By.className("cnfmbtm")).click();

            Thread.sleep(1000);

            WebElement elmtchk = driver.findElement(By.id("ldsettings")).findElement(By.id("prior1"));
            String elmt1 = elmtchk.findElement(By.id("prior1_col1")).getAttribute("class");
            String elmt2 = elmtchk.findElement(By.id("prior1_col2")).getAttribute("class");
            String elmt3 = elmtchk.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1")).getAttribute("class");

            if((elmt1.contains("errbdr"))&&(elmt2.contains("errbdr"))&&(elmt3.contains("errbdr")))
            {
                etest.log(Status.PASS,"LeadScoring Tab is present");

                clickClose(driver);
                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddEmptyFieldsAndCheck","AlertIsNotFound");
            clickClose(driver);
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddEmptyFieldsAndCheck","ErrorWhileCheckingEmptyFields",e);
            clickClose(driver);
            System.out.println("Exception while adding rule with Empty fields in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddEmptyFieldsAndCheck","ErrorWhileCheckingEmptyFields",e);
            clickClose(driver);
            System.out.println("Exception while adding rule with Empty fields in lead scoring page : "+e);
        }
        return false;
    }

    //Add Basic Criteria
    private static boolean addBasicCriteria(WebDriver driver,String pnum,String cond,String qual,String val1,String val2,String condpts,String points)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            //result.put("SLS"+rnum,false);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();
            
            etest.log(Status.INFO,"Add is clicked");

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            etest.log(Status.INFO,"Pop up is visible");
            
            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            try
            {
                elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
                elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();
                
                etest.log(Status.INFO,cond+" is selected");
            }
            catch(NoSuchElementException e)
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"ErrorDropdown",e);
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                maxcount++;
                return false;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"ErrorDropdown",e);
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                maxcount++;
                return false;
            }

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            etest.log(Status.INFO,qual+" is selected");
            
            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                etest.log(Status.INFO,val1+" is entered");
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
                etest.log(Status.INFO,val2+" is entered");
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                
                etest.log(Status.INFO,val1+" is entered");
                
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))                   //.getAttribute("style")
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
            //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

            if(condpts.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                etest.log(Status.INFO,"Add points is clicked");
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
                etest.log(Status.INFO,points+" is entered");
            }
            else if(condpts.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                etest.log(Status.INFO,"Less points is clicked");
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
                etest.log(Status.INFO,points+" is entered");
            }

            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"CheckBefore",0);
            
            elmt.findElement(By.className("cnfmbtm")).click();

            etest.log(Status.INFO,"Apply is clicked");
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addleadscorerule.do",etest);

            etest.log(Status.INFO,"Success banner is displayed");
            
            String checkcond;
            String checkcond1;
            String ptscheck = "Add "+points+" points";

            if(val2 != null)
            {
                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                //result.put("Add "+cond+" "+qual+" "+val1,false);
                checkcond = "If the visitor "+cond+" "+qual+" "+val1;
            }

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            if(cond.contains("Visitor"))
            {
                if(val2 != null)
                {
                    //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                    checkcond = "If the "+cond+" "+qual+" "+val1+" to "+val2;
                }
                else
                {
                    //result.put("Add "+cond+" "+qual+" "+val1,false);
                    checkcond = "If the "+cond+" "+qual+" "+val1;
                }
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elmt1);
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        //wait.until(ExpectedConditions.elementToBeClickable(elmt1));
                        elmt1.findElements(By.tagName("div")).get(0).click();
                        if(qual.equals("is between"))
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input2")).getAttribute("title")).equals(val2)))
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,true);
                                //result.put("AddRule-"+cond,true);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                etest.log(Status.PASS,"LeadScoring "+cond+" "+qual+" "+val1+" "+val2+" is checked");

                                return true;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                                //result.put("AddRule-"+cond,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"MismatchContent");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                        }
                        else
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&(((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))||((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1+" Minutes"))))
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1,true);
                                //result.put("AddRule-"+cond,true);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                etest.log(Status.PASS,"LeadScoring "+cond+" "+qual+" "+val1+" "+val1+" Minutes is checked");

                                return true;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1,false);
                                //result.put("AddRule-"+cond,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" Minutes","MismatchContent");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                        }
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"MismatchContent:is between");
                    }
                }
            }
            etest.log(Status.FAIL,checkcond+" is not present");
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Lead Scoring not present","Error");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileCheckingAddCriteria",e);
            clickClose(driver);
            System.out.println("Exception while adding a basic rule in lead scoring page: "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileCheckingAddCriteria",e);
            clickClose(driver);
            System.out.println("Exception while adding a basic rule in lead scoring page : "+e);
            return false;
        }
    }

    //Adding Criteria
    private static void addCriteria(WebDriver driver,String pnum,String cond,String qual,String val1,String val2)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddCriteria","ErrorWhileAddingCriteria",e);

            System.out.println("Exception while adding a basic criteria in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddCriteria","ErrorWhileAddingCriteria",e);

            System.out.println("Exception while adding a basic criteria in lead scoring page : "+e);
        }
    }

    //Add Scoring Condition (Single and) and Apply
    private static boolean addScoreConditionSAND(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            clickAddButton(driver);

            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            addCriteria(driver,"1","Country","is equal to","United States",null);
            elmt.findElement(By.className("andwrp")).findElement(By.cssSelector("div.and.opr")).click();
            //wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id="+"prior2"+"]/div[1]/div")));
            addCriteria(driver,"2","Browser","is not equal to","Google Chrome",null);

            elmt.findElement(By.id("ldaddpoints")).sendKeys("284");
            elmt.findElement(By.className("cnfmbtm")).click();

            String checkcond21 = "If the visitor Country is equal to United States";
            String checkcond22 = "If the visitor Browser is not equal to Google Chrome";

            String cond1 = "Country";
            String cond2 = "Browser";
            String qual1 = "is equal to";
            String qual2 = "is not equal to";
            String val11 = "United States";
            String val21 = "Google Chrome";

            Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addleadscorerule.do",etest);

            int pnum = 1;

            String ptscheck = "**";
            String checkcond1;

            String condpts = "Add";
            String points = "284";

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond21 + " AND " + checkcond22);

                if(((checkcond1).contains(checkcond21))&&((checkcond1).contains("AND"))&&((checkcond1).contains(checkcond22)))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elmt1);
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        //wait.until(ExpectedConditions.elementToBeClickable(elmt1));
                        elmt1.findElements(By.tagName("div")).get(0).click();
                        if(((elmt.findElement(By.id("prior"+pnum+"_col1_div")).getText()).equals(cond1))&&((elmt.findElement(By.id("prior"+pnum+"_col2_div")).getText()).equals(qual1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val11)))
                        {
                            pnum++;
                            if(((elmt.findElement(By.id("prior"+pnum+"_col1_div")).getText()).equals(cond2))&&((elmt.findElement(By.id("prior"+pnum+"_col2_div")).getText()).equals(qual2))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val21)))
                            {
                                //result.put("Add "+cond1+" "+qual1+" "+val11,true);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                etest.log(Status.PASS,"LeadScoring AND is checked");

                                return true;
                            }
                            else
                            {
                                //result.put("Add "+cond1+" "+qual1+" "+val11,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsAND","MismatchContent:"+cond2+" "+qual2+" "+val21);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return false;
                            }
                        }
                        else
                        {
                            //result.put("Add "+cond1+" "+qual1+" "+val11,false);
                            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsAND","MismatchContent:"+cond1+" "+qual1+" "+val11);
                            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                            return false;
                        }
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsAND","MismatchContent:"+ptscheck);
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsAND","MismatchContent:"+checkcond21+","+checkcond22);
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsADD","ErrorWhileCheckingAddScoreConditionsAND",e);
            clickClose(driver);
            System.out.println("Exception while adding Scoring Condition with single and in the rule in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsADD","ErrorWhileCheckingAddScoreConditionsAND",e);
            clickClose(driver);
            System.out.println("Exception while adding Scoring Condition with single and in the rule in lead scoring page : "+e);
        }
        return false;
    }

    //Add Scoring Condition (Single OR) and Apply
    private static boolean addScoreConditionSOR(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            clickAddButton(driver);

            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            addCriteria(driver,"1","Number of Visits","is more than","5",null);
            elmt.findElement(By.id("prior1")).findElement(By.cssSelector("div.or.floatlf.opr")).click();
            //wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id="+"prior2"+"]/div[1]/div")));
            addCriteria(driver,"2","Number of Past Chats","is less than","10",null);

            String checkcond21 = "If the visitor Number of Visits is more than 5";
            String checkcond22 = "If the visitor Number of Past Chats is less than 10";

            String cond1 = "Number of Visits";
            String cond2 = "Number of Past Chats";
            String qual1 = "is more than";
            String qual2 = "is less than";
            String val11 = "5";
            String val21 = "10";

            elmt.findElement(By.id("lesspoints")).click();
            elmt.findElement(By.id("ldaddpoints")).sendKeys("987");
            elmt.findElement(By.className("cnfmbtm")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addleadscorerule.do",etest);
            
            int pnum = 1;

            String ptscheck = "**";
            String checkcond1;

            String condpts = "Less";
            String points = "987";

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond21 + " OR " + checkcond22);

                if(((checkcond1).contains(checkcond21))&&((checkcond1).contains("OR"))&&((checkcond1).contains(checkcond22)))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elmt1);
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        //wait.until(ExpectedConditions.elementToBeClickable(elmt1));
                        elmt1.findElements(By.tagName("div")).get(0).click();
                        if(((elmt.findElement(By.id("prior"+pnum+"_col1_div")).getText()).equals(cond1))&&((elmt.findElement(By.id("prior"+pnum+"_col2_div")).getText()).equals(qual1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val11)))
                        {
                            pnum++;
                            if(((elmt.findElement(By.id("prior"+pnum+"_col1_div")).getText()).equals(cond2))&&((elmt.findElement(By.id("prior"+pnum+"_col2_div")).getText()).equals(qual2))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val21)))
                            {
                                //result.put("Add "+cond1+" "+qual1+" "+val11,true);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                etest.log(Status.PASS,"LeadScoring OR is checked");

                                return true;
                            }
                            else
                            {
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsOR","MismatchContent:"+cond2+" "+qual2+" "+val21);
                                //result.put("Add "+cond1+" "+qual1+" "+val11,false);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return false;
                            }
                        }
                        else
                        {
                            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsOR","MismatchContent:"+cond1+" "+qual1+" "+val11);
                            //result.put("Add "+cond1+" "+qual1+" "+val11,false);
                            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                            return false;
                        }
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsOR","MismatchContent:"+ptscheck);
                        return false;
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsOR","MismatchContent:"+checkcond21+","+checkcond22);
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsOR","ErrorWhileCheckingAddScoreConditionsOR",e);
            clickClose(driver);
            System.out.println("Exception while adding Scoring Condition with single or in the rule in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:AddScoreConditionsOR","ErrorWhileCheckingAddScoreConditionsOR",e);
            clickClose(driver);
            System.out.println("Exception while adding Scoring Condition with single or in the rule in lead scoring page : "+e);
        }
        return false;
    }

    //Condition Disabling
    private static boolean disableCond(WebDriver driver,String cond,String qual,String val1,String val2)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            WebElement elmt = driver.findElement(By.id("scoreview"));
            List<WebElement> elmts = elmt.findElements(By.className("leadscrlst"));

            //elmt.findElements(By.tagName("div")).get(0).findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(1).click();
            String checkcond;
            String checkcond1 = "****";
            if(val2 != null)
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1;
            }
            for(WebElement elmt1:elmts)
            {
                Thread.sleep(500);
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                    CommonSikuli.findInWholePage(driver,"Leadscoreenable.png","UI246",etest);
                    elmt1.findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(1).click();
                    break;
                }
            }

            Tab.waitForLoadingLine(driver);

            Thread.sleep(1000);

            for(WebElement elmt1:elmts)
            {
                Thread.sleep(500);
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(1).getAttribute("status")).equals("false"))
                    {                       
                        CommonSikuli.findInWholePage(driver,"Leadscoreenabletodisable.png","UI248",etest);
                        etest.log(Status.PASS,"Disable Rule is checked");
                        return true;
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableRule:"+cond+" "+qual+" "+val1+" "+val2,"RuleIsNotDisabled");
                    }
                }
            }
            etest.log(Status.FAIL,checkcond+" is not present");
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Lead Scoring not present","Error");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableRule:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileDisablingRule",e);
            clickClose(driver);
            System.out.println("Exception while disabling a rule in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableRule:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileDisablingRule",e);
            clickClose(driver);
            System.out.println("Exception while disabling a rule in lead scoring page : "+e);
        }
        return false;
    }

    //Enabling Condition
    private static boolean enableCond(WebDriver driver,String cond,String qual,String val1,String val2)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            WebElement elmt = driver.findElement(By.id("scoreview"));
            List<WebElement> elmts = elmt.findElements(By.className("leadscrlst"));
            //elmt.findElements(By.tagName("div")).get(0).findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(1).click();

            String checkcond;
            String checkcond1 = "****";
            if(val2 != null)
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1;
            }
            for(WebElement elmt1:elmts)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);
                if((checkcond1).contains(checkcond))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                    CommonSikuli.findInWholePage(driver,"Leadscoredisable.png","UI247",etest);
                    elmt1.findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(1).click();
                    break;
                }
            }

            Tab.waitForLoadingLine(driver);

            for(WebElement elmt1:elmts)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(1).getAttribute("status")).equals("true"))
                    {
                        CommonSikuli.findInWholePage(driver,"Leadscoredisabletoenable.png","UI249",etest);
                        etest.log(Status.PASS,"Enable Rule is checked");
                        return true;
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","EnableRule"+cond+" "+qual+" "+val1+" "+val2,"RuleIsNotEnabled");
                    }
                }
            }
            etest.log(Status.FAIL,checkcond+" is not present");
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Lead Scoring not present","Error");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","EnableRule:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileEnablingRule",e);
            clickClose(driver);
            System.out.println("Exception while enabling a rule in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","EnableRule:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileEnablingRule",e);
            clickClose(driver);
            System.out.println("Exception while enabling a rule in lead scoring page : "+e);
        }
        return false;
    }

    //Delete Condition
    private static boolean deleteCond(WebDriver driver,String cond,String qual,String val1,String val2)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            WebElement elmt = driver.findElement(By.id("scoreview"));
            List<WebElement> elmts = elmt.findElements(By.className("leadscrlst"));
            //elmt.findElements(By.tagName("div")).get(0).findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(0).click();

            String checkcond;
            String checkcond1 = "****";
            String elid = "**";

            if(val2 != null)
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1;
            }
            for(WebElement elmt1:elmts)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);
                if((checkcond1).contains(checkcond))
                {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                    elmt1.findElements(By.tagName("div")).get(2).findElements(By.tagName("span")).get(0).click();
                    break;
                }
            }

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            driver.findElement(By.id("okbtn")).click();

            Tab.waitForLoadingLine(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            WebElement elmtchk = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtschk = elmtchk.findElements(By.className("leadscrlst"));

            for(WebElement elmt1chk:elmtschk)
            {
                checkcond1 = elmt1chk.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + " and not deleted " + checkcond);
                if((checkcond1).contains(checkcond))
                {
                    //System.out.println("Comes here");
                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DeleteRule:"+cond+""+qual+""+val1+""+val2,"RuleIsNotDeleted");
                    return false;
                }
            }
            etest.log(Status.PASS,"Delete Rule is checked");

            return true;
            /*
            int trchk = 0;

            for(WebElement elmt1:elmts)
            {
                List<WebElement> elmts1 = elmt1.findElements(By.tagName("div"));
                for(WebElement elmts11:elmts1)
                {
                    trchk++;
                    if(trchk==3)
                    {
                        elmts11.findElements(By.tagName("span")).get(0).click();
                        break;
                    }
                }
            }*/
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DeleteRule:"+cond+""+qual+""+val1+""+val2,"ErrorWhileDeletingRule",e);
            clickClose(driver);
            System.out.println("Exception while deleting a rule in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DeleteRule:"+cond+""+qual+""+val1+""+val2,"ErrorWhileDeletingRule",e);
            clickClose(driver);
            System.out.println("Exception while deleting a rule in lead scoring page : "+e);
        }
        return false;
    }

    //Real time checking after 2 minutes for updated Lead Score value ----------->>>>>>>> yet to be modified for chrome browser
    private static void checkLScoreRealTime(WebDriver driver,String uuid)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_vhistory"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_vhistory"))).click();

            //driver.navigate().refresh();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("viewid-2")));

            //driver.findElement(By.id("viewid-2")).findElement(By.className("vlstcnt")).findElements(By.tagName("div")).get(0).click();
            driver.findElement(By.id("col2_"+uuid)).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_info_div")));

            WebElement lscoreelmt = driver.findElement(By.id("visitor_info_div")).findElement(By.className("vstrankinfo")).findElement(By.className("vstscore")).findElements(By.tagName("li")).get(0);
            String lscore = lscoreelmt.findElements(By.tagName("div")).get(1).getText();

            if(lscore.equals("543"))
            {
                System.out.println("Yaaaaahhhhhoooooooooooooooooooo its Working...............----------------------------------------->>>>>>>> LEAD SCORE UPDATING PROPERLY");
                result.put("SLS4",true);
            }


        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+e);
        }
    }

    //Add all the conditions in the list
    private static void addFull(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            String condlis[] = new String[100];
            //disableCRMInteg(driver);

            /*clickAddButton(driver);
            Thread.sleep(1000);

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            elmt.findElement(By.id("prior1_col1_div")).click();

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id("prior1_col1_ddown")).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement elmt1 = elmt.findElement(By.id("prior1_col1_ddown"));

            List<WebElement> elmt2 = elmt.findElement(By.id("prior1_col1_ddown")).findElement(By.id("prior1_col10")).findElements(By.tagName("li"));

            int lislen = 0;

            for(WebElement elmtchk:elmt2)
            {
                condlis[lislen] = elmtchk.findElement(By.tagName("div")).findElement(By.tagName("span")).getText();
                lislen++;
            }

            lislen--;

            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();*/
            int chk = 0;
            int chk1 = 0;
            int chk2 = 0;
            int maxcount = 0;

            rnum++;

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS11"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS11",addBasicCriteria(driver,"1","Browser","is equal to","Google Chrome",null,"Add","75"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS12"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS12",addBasicCriteria(driver,"1","Campaign Content","contains","Checking",null,"Add","123"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS13"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS13",addBasicCriteria(driver,"1","Campaign Medium","doesn't contain","Checking",null,"Less","45"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS14"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS14",addBasicCriteria(driver,"1","Campaign Name","contains","Checking",null,"Add","123"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS15"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS15",addBasicCriteria(driver,"1","Campaign Source","doesn't contain","Checking",null,"Less","45"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS16"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS16",addBasicCriteria(driver,"1","Campaign Term","contains","Checking",null,"Add","123"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS17"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS17",addBasicCriteria(driver,"1","City","is not equal to","Checking",null,"Less","45"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS18"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS18",addBasicCriteria(driver,"1","Country","is not equal to","United States",null,"Less","50"));
            rnum++;
            accresdel(driver);
            //result.put("SLS19",addBasicCriteria(driver,"1","Current Page Title","contains","Checking",null,"Add","123"));
            //rnum++;
            //result.put("SLS20",addBasicCriteria(driver,"1","Current Page URL","contains","salesiq",null,"Add","100"));
            //rnum++;
            //result.put("SLS21",addBasicCriteria(driver,"1","Department","is equal to","Automation",null,"Add","250"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS22"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS22",addBasicCriteria(driver,"1","Email Address","ends with","@gmail.com",null,"Less","20"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS23"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS23",addBasicCriteria(driver,"1","IP Address","is between","192.168.143.100","192.168.143.140","Add","75"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS24"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS24",addBasicCriteria(driver,"1","Landing Page Title","doesn't contain","Checking",null,"Less","45"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS25"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS25",addBasicCriteria(driver,"1","Landing Page URL","doesn't contain","salesiq",null,"Less","50"));
            //rnum++;
            //result.put("SLS26",addBasicCriteria(driver,"1","Last Visit Duration","is more than","7",null,"Add","50"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS27"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS27",addBasicCriteria(driver,"1","Number of Past Chats","is less than","7",null,"Less","25"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS28"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS28",addBasicCriteria(driver,"1","Number of URLs Accessed","is more than","7",null,"Add","50"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS29"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS29",addBasicCriteria(driver,"1","Number of Visits","is less than","7",null,"Less","25"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS30"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS30",addBasicCriteria(driver,"1","Operating System","is equal to","Mac OS",null,"Add","500"));
            accresdel(driver);
            //rnum++;
            //result.put("SLS31",addBasicCriteria(driver,"1","Previous Page URL","contains","salesiq",null,"Add","100"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS32"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS32",addBasicCriteria(driver,"1","Referrer","contains","Checking",null,"Add","123"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS33"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS33",addBasicCriteria(driver,"1","Region","is not equal to","Asia Pacific",null,"Less","250"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS34"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS34",addBasicCriteria(driver,"1","Search Engine","is equal to","Google",null,"Add","125"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS35"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS35",addBasicCriteria(driver,"1","State","is not equal to","Checking",null,"Less","45"));
            //rnum++;
            //result.put("SLS36",addBasicCriteria(driver,"1","System Status","is equal to","Chat Completed",null,"Less","150"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS37"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS37",addBasicCriteria(driver,"1","Time on Site","is more than","7",null,"Add","50"));
            //rnum++;
            //result.put("SLS38",addBasicCriteria(driver,"1","Time Since Last Action","is less than","7",null,"Less","25"));
            //rnum++;
            //result.put("SLS39",addBasicCriteria(driver,"1","Triggered Status","is equal to","Not Invoked",null,"Add","190"));
            //rnum++;
            //result.put("SLS"+rnum,addBasicCriteria(driver,"1","Visitor Availability","is equal to","Available",null,"Less","25"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS40"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS40",addVisInfoCriteria(driver,"1","Visitor Info","Visiting Time","is between","09:00 AM","06:00 PM","Add","300"));
            //rnum++;
            //result.put("SLS"+rnum,addBasicCriteria(driver,"1","Visitor Source","is equal to","Campaign",null,"Less","20"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS41"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS41",addBasicCriteria(driver,"1","Visitor Type","is equal to","Returning",null,"Add","100"));
            accresdel(driver);

            ComplexReportFactory.closeTest(etest);

            //accresdel(driver);
            //rnum++;
            //result.put("SLS42",addBasicCriteria(driver,"1","Web Embed","is equal to","Automation",null,"Less","225"));

            /*
            for(int i=1;i<=lislen;i++)
            {
                Thread.sleep(5000);
                String cond = condlis[i];
                System.out.println("CONDITION -----------------------------------------------------------------------------"+cond+"---------------------------->>");

                rnum++;

                result.put("SLS"+rnum,false);

                if(cond.equals("Advanced"))
                {
                    continue;
                }
                else if((cond.equals("Number of Past Chats"))||(cond.equals("Last Visit Duration"))||(cond.equals("Number of URLs Accessed"))||(cond.equals("Number of Visits"))||(cond.equals("Time on Site"))||(cond.equals("Time Since Last Action")))
                {
                    if(chk==0)
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is more than","7",null,"Add","50"));
                        chk++;
                    }
                    else
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is less than","7",null,"Less","25"));
                        chk--;
                    }
                }
                else if((cond.equals("Previous Page URL"))||(cond.equals("Current Page URL"))||(cond.equals("Landing Page URL")))
                {
                    if(chk1==0)
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"contains","salesiq",null,"Add","100"));
                        chk1++;
                    }
                    else
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"doesn't contain","salesiq",null,"Less","50"));
                        chk1--;
                    }
                }
                else if(cond.equals("Email Address"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"ends with","@gmail.com",null,"Less","20"));
                }
                else if(cond.equals("IP Address"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is between","192.168.143.100","192.168.143.140","Add","75"));
                }
                else if(cond.contains("Visitor"))
                {
                    if(cond.equals("Visitor Source"))
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Campaign",null,"Less","20"));
                    }
                    else if(cond.equals("Visitor Type"))
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Returning",null,"Add","100"));
                    }
                    else if(cond.equals("Visitor Availability"))
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Available",null,"Less","25"));
                    }
                    else if(cond.equals("Visitor Info"))
                    {
                        result.put("SLS"+rnum,addVisInfoCriteria(driver,"1",cond,"Visiting Time","is between","09:00 AM","06:00 PM","Add","300"));
                    }
                }
                else if(cond.equals("Browser"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Google Chrome",null,"Add","75"));
                }
                else if(cond.equals("Country"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is not equal to","United States",null,"Less","50"));
                }
                else if(cond.equals("Department"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Automation",null,"Add","250"));
                }
                else if(cond.equals("Operating System"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Apple Macintosh",null,"Add","500"));
                }
                else if(cond.equals("Region"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is not equal to","Asia Pacific",null,"Less","250"));
                }
                else if(cond.equals("Search Engine"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Google",null,"Add","125"));
                }
                else if(cond.equals("System Status"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Chat Completed",null,"Less","150"));
                }
                else if(cond.equals("Triggered Status"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Not Invoked",null,"Add","190"));
                }
                else if(cond.equals("Web Embed"))
                {
                    result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"is equal to","Automation",null,"Less","225"));
                }
                else
                {
                    if(chk2==0)
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"contains","Checking",null,"Add","123"));
                        chk2++;
                    }
                    else
                    {
                        result.put("SLS"+rnum,addBasicCriteria(driver,"1",cond,"doesn't contain","Checking",null,"Less","45"));
                        chk2--;
                    }
                }

                maxcount++;
                if(maxcount == 8)
                {
                    while(maxcount>0)
                    {
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
                        driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                        Thread.sleep(1000);
                        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));
                        driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

                        Thread.sleep(5000);

                        try
                        {
                            List<WebElement> elmtlslist = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst"));
                            //WebElement elmtlslist = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst")).get(1);
                            String ruleid = elmtlslist.get(1).getAttribute("id");

                            System.out.println("RULE ID ------------------------------------"+ruleid);

                            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(ruleid))).getLocation().y+")");

                            driver.findElement(By.id(ruleid)).findElements(By.tagName("div")).get(2).findElement(By.tagName("span")).click();

                            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                            driver.findElement(By.id("okbtn")).click();

                            //elmtlslist.get(1).findElements(By.tagName("div")).get(2).findElement(By.tagName("span")).click();
                            //wait.until(ExpectedConditions.not(ExpectedConditions.presenceOfElementLocated(By.id(ruleid))));
                        }
                        catch(IndexOutOfBoundsException e)
                        {
                            System.out.println("One or more condition check has failed during this execution");
                        }

                        maxcount--;
                    }
                }
            }*/
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while adding all the criteria in the list in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while adding all the criteria in the list in lead scoring page : "+e);
        }
    }

    //Access Restriced delete 8 rules
    private static void accresdel(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            while(maxcount>0)
            {
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

                Thread.sleep(5000);

                try
                {
                    List<WebElement> elmtlslist = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst"));
                    //WebElement elmtlslist = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst")).get(1);
                    String ruleid = elmtlslist.get(1).getAttribute("id");

                    System.out.println("RULE ID ------------------------------------"+ruleid);

                    //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id(ruleid))).getLocation().y+")");

                    driver.findElement(By.id(ruleid)).findElements(By.tagName("div")).get(2).findElement(By.tagName("span")).click();

                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                    driver.findElement(By.id("okbtn")).click();

                    Tab.waitForLoadingLine(driver);
                }
                catch(IndexOutOfBoundsException e)
                {
                    System.out.println("One or more condition check has failed during this execution");
                }

                maxcount--;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while deleting 8 rules to avoid access restricted in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while deleting 8 rules to avoid access restricted in lead scoring page : "+e);
        }
    }

    //Add Visitor Info Criteria
    private static boolean addVisInfoCriteria(WebDriver driver,String pnum,String cond,String cond1,String qual,String val1,String val2,String condpts,String points)
    {
        try
        {
            //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            elmt.findElement(By.id("prior"+pnum+"_col4")).findElement(By.className("col4input")).findElement(By.tagName("input")).sendKeys(cond1);

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
            //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

            if(condpts.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            else if(condpts.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            elmt.findElement(By.className("cnfmbtm")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addleadscorerule.do",etest);

            String checkcond;
            String checkcond1;
            String ptscheck = "Add "+points+" points";

            if(val2 != null)
            {
                checkcond = "If the "+cond+" "+cond1+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                checkcond = "If the "+cond+" "+cond1+" "+qual+" "+val1;
            }

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        //return true;
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        //wait.until(ExpectedConditions.elementToBeClickable(elmt1));
                        elmt1.findElements(By.tagName("div")).get(0).click();
                        if(qual.equals("is between"))
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input2")).getAttribute("title")).equals(val2)))
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,true);
                                //result.put("AddRule-"+cond,true);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                etest.log(Status.PASS,"LeadScoring "+cond+" "+qual+" "+val1+" "+val2+" is checked");

                                return true;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2+"Failed at checking after click",false);
                                //result.put("AddRule-"+cond,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"MismatchContent:"+cond+" "+qual+" "+val1+" "+val2);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                        }
                        else
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&(((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))||((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1+" Minutes"))))
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1,true);
                                //result.put("AddRule-"+cond,true);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                etest.log(Status.PASS,"LeadScoring "+cond+" "+qual+" "+val1+" "+val1+" Minutes is checked");

                                return true;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1,false);
                                //result.put("AddRule-"+cond,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val1+" Minutes","MismatchContent:"+cond+" "+qual+" "+val1+" "+val1+" Minutes");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                        }
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"MismatchContent:"+ptscheck);
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,checkcond+"IsNotPresent");
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileChecking"+cond+" "+qual+" "+val1+" "+val2,e);
            clickClose(driver);
            System.out.println("Exception while adding visitor info criteria in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check:"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileChecking"+cond+" "+qual+" "+val1+" "+val2,e);
            clickClose(driver);
            System.out.println("Exception while adding visitor info criteria in lead scoring page : "+e);
            return false;
        }
    }

    //Get the uuid of the visitor  -------------->>>>>> Yet to be modified for chrome browser
    private static String checkUUID(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver.navigate().refresh();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.linkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));

            WebElement elmt = driver.findElement(By.id("ldwrap")).findElements(By.tagName("div")).get(1);

            String uvid = elmt.getAttribute("id");

            System.out.println("UVID OF THE USER ----------------"+uvid);

            String uuid = (((JavascriptExecutor) driver).executeScript("return UTSHandler.visitors[\""+uvid+"\"].data[\"uuid\"];")).toString();

            System.out.println("UUID OF THE USER ----------------------------"+uuid);

            Thread.sleep(120000);

            //checkLScoreRealTime(driver,uuid);

            return uuid;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+e);
        }
        return "Not Found";
    }

    //Check visitor History ------------------->>>>> Yet to be modified for chrome browser
    private static void checkVHistory(WebDriver driver,String uuid)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_vhistory"))));
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_vhistory"))).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("viewid-2")));
            driver.findElement(By.id("col2_"+uuid)).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_info_div")));

            List<WebElement> elmtvstrank = driver.findElement(By.id("visitor_info_div")).findElement(By.className("vstrankinfo")).findElement(By.className("vstscore")).findElements(By.tagName("li"));

            String lscoreName = elmtvstrank.get(0).findElements(By.tagName("div")).get(0).getText();
            int lscoreval = Integer.parseInt(elmtvstrank.get(0).findElements(By.tagName("div")).get(1).getText());
            String OpName = elmtvstrank.get(1).findElements(By.tagName("div")).get(0).getText();
            String Opval = elmtvstrank.get(1).findElements(By.tagName("div")).get(1).getText();
            String VSince = elmtvstrank.get(2).findElements(By.tagName("div")).get(0).getText();
            String VSinceval = elmtvstrank.get(2).findElements(By.tagName("div")).get(1).getText();

            if(lscoreName.equals("Lead Score"))
            {
                result.put("VH1",true);
            }
            if(OpName.equals("Opportunity"))
            {
                result.put("VH2",true);
            }
            if(VSince.equals("Visitor Since"))
            {
                result.put("VH3",true);
            }
            if(lscoreval>=0)
            {
                result.put("VH4",true);
            }
            if(Opval!=null)
            {
                result.put("VH5",true);
            }
            if(VSinceval!=null)
            {
                result.put("VH6",true);
            }

        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+e);
        }
    }

    //Check CRM dropdown values
    private static boolean checkCRMddown(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("crm_intgopt") || action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();

                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
            }

            WebElement elmtss = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));

            elmtss.click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            driver.findElement(By.id("okbtn")).click();
            Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration disabled successfully","disableinteg.do",etest);

            clickAddButton(driver);

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            elmt.findElement(By.id("prior1_col1_div")).click();

            try
            {
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if((elmt.findElement(By.id("prior1_col1_ddown")).getAttribute("style")).equals("display: block;"))
                        {
                            return true;
                        }
                        return false;
                    }
                });

                WebElement elmt1 = elmt.findElement(By.id("prior1_col1_ddown")).findElement(By.id("prior1_col11"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");

                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckCRMDinropDown","CRMIsPresentAfterDisablingIt");

                return false;
            }
            catch(NoSuchElementException ex)
            {
                WebElement elmtcancel = driver.findElement(By.id("ldsettings"));
                elmtcancel.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

                driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

                WebElement elmts1 = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
                String classname1 = driver.findElement(By.id("disablecontainer")).getAttribute("class");

                String action1 = elmts1.getText();

                if(classname1.equals("crm_intgopt") || action1.contains(ResourceManager.getRealValue("common_enable")))
                {
                    elmts1.click();

                    Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
                }

                clickAddButton(driver);
                Thread.sleep(1000);

                final WebElement elmt2 = driver.findElement(By.id("ldsettings"));

                elmt2.findElement(By.id("prior1_col1_div")).click();

                try
                {
                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if((elmt2.findElement(By.id("prior1_col1_ddown")).getAttribute("style")).equals("display: block;"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });

                    WebElement elmt1 = elmt2.findElement(By.id("prior1_col1_ddown")).findElement(By.id("prior1_col11"));

                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");

                    WebElement elmtcancel1 = driver.findElement(By.id("ldsettings"));
                    elmtcancel1.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();

                    etest.log(Status.PASS,"LeadScoring CRM in Dropdown is checked");

                    return true;
                }
                catch(Exception e)
                {
                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckCRMinDropDown","CRMisNotPresent");

                    return false;
                }
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckCRMinDropDown","ErrorWhileCheckingCRMinDropDown",e);
            clickClose(driver);
            System.out.println("Exception Checking CRM dropdown values in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckCRMinDropDown","ErrorWhileCheckingCRMinDropDown",e);
            clickClose(driver);
            System.out.println("Exception Checking CRM dropdown values in lead scoring page : "+e);
        }
        return false;
    }

    //Check CRM dropdowns
    private static boolean CheckCRMvalues(WebDriver driver,final String pnum,String cond,String cond1,String qual,String val1,String val2,String condpts,String points,String rnum1)
    {
        try
        {
            //result.put("Add "+cond+" "+cond1+" "+qual+" "+val1,false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            result.put(rnum1,false);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();
            
            etest.log(Status.INFO,"Add button is clicked");
            
            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            etest.log(Status.INFO,"Pop up is visible");
            
            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            elmt.findElement(By.id("prior"+pnum+"_col4_div")).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id("prior"+pnum+"_col4_ddown")).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            etest.log(Status.INFO,cond+" is selected");
            
            try
            {
                elmt.findElement(By.id("prior"+pnum+"_col4_ddown")).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond1);
                elmt.findElement(By.id("prior"+pnum+"_col4_ddown")).findElement(By.id("prior"+pnum+"_col40")).findElement(By.tagName("li")).click();
                
                System.out.println("CheckCRMvalues1<>"+cond+"<>"+cond1+"<>"+qual+"<>"+val1+"<>"+val2+"<>");
            }
            catch(Exception e)
            {
                elmt.findElement(By.id("prior"+pnum+"_col4_ddown")).findElement(By.id("prior"+pnum+"_col40")).findElements(By.tagName("li")).get(2).click();
                
                System.out.println("CheckCRMvalues2<>"+cond+"<>"+cond1+"<>"+qual+"<>"+val1+"<>"+val2+"<>");
            }

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            etest.log(Status.INFO,qual+" is selected");
            
            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                
                etest.log(Status.INFO,val1+" is entered");
                
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
                
                etest.log(Status.INFO,val2+" is entered");
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                
                etest.log(Status.INFO,val1+" is entered");
                
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
            
            etest.log(Status.INFO,"Entering points ...");
            
            if(condpts.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                etest.log(Status.INFO,"Add points is clicked");
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
                etest.log(Status.INFO,points+" is entered");
            }
            else if(condpts.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                etest.log(Status.INFO,"Less points is clicked");
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
                etest.log(Status.INFO,points+" is entered");
            }
            
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),"CheckBefore",0);
            
            elmt.findElement(By.className("cnfmbtm")).click();
            
            etest.log(Status.INFO,"Apply is clicked");

            Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addleadscorerule.do",etest);
            
            etest.log(Status.INFO,"Success banner is displayed");
            
            String checkcond;
            String checkcond1;
            String ptscheck = "Add "+points+" points";

            if(val2 != null)
            {
                checkcond = "If the visitor "+cond+" "+cond1+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                checkcond = "If the visitor "+cond+" "+cond1+" "+qual+" "+val1;
            }

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elmt1);
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        //wait.until(ExpectedConditions.elementToBeClickable(elmt1));
                        elmt1.findElements(By.tagName("div")).get(0).click();
                        if(qual.equals("is between"))
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input2")).getAttribute("title")).equals(val2)))
                            {
                                //result.put("Add "+cond+" "+cond1+" "+qual+" "+val1,true);
                                result.put(rnum1,true);
                                etest.log(Status.PASS,KeyManager.getRealValue(rnum1)+" is checked");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return true;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2+"Failed at checking after click",false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),"MismatchContent:"+cond+""+qual+""+val1+""+val2);
                                result.put(rnum1,false);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return false;
                            }
                        }
                        else
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1)))
                            {
                                //result.put("Add "+cond+" "+cond1+" "+qual+" "+val1,true);
                                result.put(rnum1,true);
                                etest.log(Status.PASS,KeyManager.getRealValue(rnum1)+" is checked");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return true;
                            }
                            else
                            {
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),"MismatchContent:"+cond+""+qual+""+val1);
                                result.put(rnum1,false);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return false;
                            }
                        }
                    }
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),"MismatchContent:"+ptscheck);
                        return false;
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),checkcond+"IsNotPresent");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
            clickClose(driver);
            System.out.println("Exception Checking CRM dropdown in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
            clickClose(driver);
            System.out.println("Exception Checking CRM dropdown in lead scoring page : "+e);
        }
        return false;
    }

    //Add CRM rules to the list
    private static void addCRMrules(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("crm_intgopt") || action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();

                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
            }

            rnum++;

            etest.log(Status.PASS,"CRM is enabled");

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS43"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            CheckCRMvalues(driver,"1","CRM Contact","Visitor Score","is equal to","100",null,"Add","567","SLS43");
            rnum++;
            Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS44"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            CheckCRMvalues(driver,"1","CRM Lead","Annual Revenue","is less than","50000",null,"Less","789","SLS44");
            rnum++;
            Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS45"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            CheckCRMvalues(driver,"1","CRM Deal","No of Open Deals","is more than","7",null,"Add","765","SLS45");
            rnum++;
            Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS46"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS46",addBasicCriteria(driver,"1","Visitor Stage in CRM","is equal to","Not available",null,"Less","321"));
            rnum++;
            Thread.sleep(1000);
            accresdel(driver);
            Thread.sleep(2000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Enable CRM","ErrorWhileEnablingCRM",e);

            System.out.println("Exception while adding CRM based rules in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Enable CRM","ErrorWhileEnablingCRM",e);

            System.out.println("Exception while adding CRM based rules in lead scoring page : "+e);
        }
    }

    //Check Advanced Configuration
    private static boolean checkAdvConfig(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lead_advncd")));

            final WebElement elmt = driver.findElement(By.id("lead_advncd"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+")");

            elmt.findElement(By.id("lsdeprdrpdwn_div")).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id("lsdeprdrpdwn_ddown")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id("lsdeprdrpdwn0")).findElements(By.tagName("li"));

            int lislen = 0;

            int check = 0;

            String condlis[] = new String[20];

            for(WebElement elmt1:elmts)
            {
                condlis[lislen] = elmt1.findElement(By.tagName("div")).findElement(By.tagName("span")).getText();
                lislen++;
            }

            elmt.findElement(By.id("lsdeprdrpdwn_div")).click();

            for(int place=0;place<lislen;place++)
            {
                final WebElement elmt2 = driver.findElement(By.id("lead_advncd"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt2.getLocation().y+")");

                elmt2.findElement(By.id("lsdeprdrpdwn_div")).click();

                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if((elmt2.findElement(By.id("lsdeprdrpdwn_ddown")).getAttribute("style")).contains("display: block;"))
                        {
                            return true;
                        }
                        return false;
                    }
                });

                elmt2.findElement(By.id("lsdeprdrpdwn_ddown")).findElement(By.tagName("ul")).findElements(By.tagName("li")).get(place).click();

                Tab.waitForLoadingLine(driver);

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lead_advncd")));

                WebElement elmtchk = driver.findElement(By.id("lead_advncd"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmtchk.getLocation().y+")");

                if((elmtchk.findElement(By.id("lsdeprdrpdwn_div")).findElement(By.tagName("span")).getText()).equals(condlis[place]))
                {
                    check++;
                }
            }

            if(check == lislen)
            {
                etest.log(Status.PASS,"Advanced Configuration Date DropDown is checked");

                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckAdvancedConfig","MismatchCountInDropDown");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckAdvancedConfig","ErrorWhileCheckingAdvancedConfig",e);

            System.out.println("Exception while checking advanced configuration in lead scoring page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckAdvancedConfig","ErrorWhileCheckingAdvancedConfig",e);

            System.out.println("Exception while checking advanced configuration in lead scoring page : "+e);
        }
        return false;
    }

    //Check Dropdowns
    private static void checkdropdown(WebDriver driver)
    {
        try
        {
            rnum++;

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS47"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS47",checkddown(driver,"1","Browser"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS48"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS48",checkddown(driver,"1","Country"));
            //rnum++;
            //result.put("SLS49",checkddown(driver,"1","Department"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS50"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS50",checkddown(driver,"1","Operating System"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS51"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS51",checkddown(driver,"1","Region"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS52"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS52",checkddown(driver,"1","Search Engine"));
            //rnum++;
            //result.put("SLS53",checkddown(driver,"1","System Status"));
            //rnum++;
            //result.put("SLS54",checkddown(driver,"1","Triggered Status"));
            //rnum++;
            //result.put("SLS"+rnum,checkddown(driver,"1","Visitor Availability"));
            //rnum++;
            //result.put("SLS"+rnum,checkddown(driver,"1","Visitor Source"));
            rnum++;

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SLS55"));
            ComplexReportFactory.setValues(etest,"Automation","Lead Scoring");

            result.put("SLS55",checkddown(driver,"1","Visitor Type"));
            //rnum++;
            //result.put("SLS56",checkddown(driver,"1","Web Embed"));

            ComplexReportFactory.closeTest(etest);

            Thread.sleep(2000);
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+e);
        }
    }

    //Dropddown check
    private static boolean checkddown(WebDriver driver,String pnum,String cond)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            try
            {
                elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
                elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).click();
                Thread.sleep(1000);

                if((elmtip.findElement(By.id("col3_div")).getAttribute("style")).equals("display: block;"))
                {
                    elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                    etest.log(Status.PASS,cond+" in Criteria Dropdown is checked");
                    return true;
                }
            }
            catch(NoSuchElementException e)
            {
                etest.log(Status.PASS,cond+" in Criteria Dropdown is checked");
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                return true;
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,cond+" in Criteria Dropdown is checked");
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckInDropDown:"+cond,cond+"IsNotPresent");
            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckInDropDown:"+cond,"ErrorWhileCheckinginDropDown",e);
            clickClose(driver);
            System.out.println("Exception while checking if rules dropdown is available in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","CheckInDropDown:"+cond,"ErrorWhileCheckinginDropDown",e);
            clickClose(driver);
            System.out.println("Exception while checking if rules dropdown is available in lead scoring page : "+e);
            return false;
        }
    }

    //Edit rule
    private static boolean editRule(WebDriver driver,String cond,String qual,String val1,String val2,String condpts,String points)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            String pnum = "1";
            String checkcond;
            String checkcond1;
            String ptscheck = "Add "+points+" points";

            if(val2 != null)
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                checkcond = "If the visitor "+cond+" "+qual+" "+val1;
            }

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            if(cond.contains("Visitor"))
            {
                if(val2 != null)
                {
                    checkcond = "If the "+cond+" "+qual+" "+val1+" to "+val2;
                }
                else
                {
                    checkcond = "If the "+cond+" "+qual+" "+val1;
                }
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        elmt1.findElements(By.tagName("div")).get(0).click();

                        Thread.sleep(1000);

                        cond = "Number of Visits";
                        qual = "is less than";
                        val1 = "7";
                        condpts = "Less";
                        points = "58";

                        if(cond.equals("Triggered"))
                        {
                            cond = "Triggered";
                            qual = "is equal to";
                            val1 = "Animate button";
                            condpts = "Less";
                            points = "72";
                        }
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        final WebElement elmt = driver.findElement(By.id("ldsettings"));

                        String cid = "prior"+pnum+"_col1_div";
                        final String cdown = "prior"+pnum+"_col1_ddown";

                        elmt.findElement(By.id(cid)).click();

                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
                        elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

                        String qid = "prior"+pnum+"_col2_div";
                        final String qdown = "prior"+pnum+"_col2_ddown";

                        elmt.findElement(By.id(qid)).click();

                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

                        for(WebElement elmts1:elmts)
                        {
                            if((elmts1.getText()).equals(qual))
                            {
                                elmts1.click();
                                break;
                            }
                        }

                        if(qual.equals("is between"))
                        {
                            String vid = "prior"+pnum+"_col3";
                            WebElement elmtip = elmt.findElement(By.id(vid));
                            elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                            elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
                        }
                        else
                        {
                            String vid = "prior"+pnum+"_col3";
                            WebElement elmtip = elmt.findElement(By.id(vid));
                            elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                            if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))                   //.getAttribute("style")
                            {
                                elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                            }
                        }
                        //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

                        if(condpts.equals("Add"))
                        {
                            elmt.findElement(By.id("addpoints")).click();
                            elmt.findElement(By.id("ldaddpoints")).clear();
                            elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
                        }
                        else if(condpts.equals("Less"))
                        {
                            elmt.findElement(By.id("lesspoints")).click();
                            elmt.findElement(By.id("ldaddpoints")).clear();
                            elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
                        }
                        elmt.findElement(By.className("cnfmbtm")).click();

                        Thread.sleep(5000);

                        if(val2 != null)
                        {
                            checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
                        }
                        else
                        {
                            checkcond = "If the visitor "+cond+" "+qual+" "+val1;
                        }

                        if(condpts.equals("Add"))
                        {
                            ptscheck = "Add "+points+" points";
                        }
                        else if(condpts.equals("Less"))
                        {
                            ptscheck = "Less "+points+" points";
                        }

                        if(cond.contains("Visitor"))
                        {
                            if(val2 != null)
                            {
                                checkcond = "If the "+cond+" "+qual+" "+val1+" to "+val2;
                            }
                            else
                            {
                                checkcond = "If the "+cond+" "+qual+" "+val1;
                            }
                        }

                        WebElement elmtr1 = driver.findElement(By.id("scoreview"));
                        List<WebElement> elmtslst1 = elmtr1.findElements(By.className("leadscrlst"));

                        for(WebElement elmt12:elmtslst1)
                        {
                            checkcond1 = elmt12.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                            System.out.println(checkcond1 + "  and " + checkcond);

                            if((checkcond1).contains(checkcond))
                            {
                                if((elmt12.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                                {
                                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt12.getLocation().y+")");
                                    elmt12.findElements(By.tagName("div")).get(0).click();

                                    Thread.sleep(1000);

                                    if(qual.equals("is between"))
                                    {
                                        if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input2")).getAttribute("title")).equals(val2)))
                                        {
                                            //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,true);
                                            //result.put("AddRule-"+cond,true);
                                            etest.log(Status.PASS,"Edit Rule is checked");
                                            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                            maxcount++;
                                            return true;
                                        }
                                        else
                                        {
                                            //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                                            //result.put("AddRule-"+cond,false);
                                            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check"+checkcond,"MismatchContent:"+cond+" "+qual+" "+val1+" "+val2);
                                            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                            maxcount++;
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&(((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))||((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1+" Minutes"))))
                                        {
                                            //result.put("Add "+cond+" "+qual+" "+val1,true);
                                            //result.put("AddRule-"+cond,true);
                                            etest.log(Status.PASS,"Edit Rule is checked");
                                            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                            maxcount++;
                                            return true;
                                        }
                                        else
                                        {
                                            //result.put("Add "+cond+" "+qual+" "+val1,false);
                                            //result.put("AddRule-"+cond,false);
                                            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check"+checkcond,"MismatchContent:"+cond+" "+qual+" "+val1+" "+val1+" Minutes");
                                            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                            maxcount++;
                                            return false;
                                        }
                                    }
                                }
                                else{
                                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check"+checkcond,"MismatchContent:"+ptscheck);
                                    return false;
                                }
                            }
                        }
                    }
                }
            }
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check"+checkcond,"MismatchContent:"+checkcond);
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check"+cond+" "+qual+" "+val1+" "+val2,"ErrorWhileChecking",e);
            clickClose(driver);
            System.out.println("Exception while editing rule in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Check"+cond+" "+qual+" "+val1+" "+val1,"ErrorWhileChecking",e);
            clickClose(driver);
            System.out.println("Exception while editing rule in lead scoring page : "+e);
            return false;
        }
    }

    //Edit, Disable and delete rule
    private static boolean disableDelete(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(disableCond(driver,"Number of Visits","is less than","7",null))
            {
                if(deleteCond(driver,"Number of Visits","is less than","7",null))
                {
                    etest.log(Status.PASS,"Disable And Delete Rule is checked");

                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndDeleteRule","RuleIsNotDeleted");
                    return false;
                }
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndDeleteRule","RuleIsNotDisabled");
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndDeleteRule","ErrorWhileDisablingRuleAndDeleting",e);
            System.out.println("Exception while disabling and deleting rule in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndDeleteRule","ErrorWhileDisablingRuleAndDeleting",e);
            System.out.println("Exception while desabling and deleting rule in lead scoring page : "+e);
            return false;
        }
    }

    //Edit, Enable and delete rule
    private static boolean enableDelete(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(editRule(driver,"Number of Visits","is more than","7",null,"Add","100"))
            {
                if(disableCond(driver,"Number of Visits","is less than","7",null))
                {
                    if(enableCond(driver,"Number of Visits","is less than","7",null))
                    {
                        if(deleteCond(driver,"Number of Visits","is less than","7",null))
                        {
                            etest.log(Status.PASS,"Edit,Enable and Delete Rule is checked");

                            return true;
                        }
                        else
                        {
                            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Edit,EnableAndDeleteRule","RuleIsNotDeleted");
                            return false;
                        }
                    }
                    else
                    {
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Edit,EnableAndDeleteRule","RuleIsNotEnabled");
                        return false;
                    }
                }
                else
                {
                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Edit,EnableAndDeleteRule","RuleIsNotDisabled");
                    return false;
                }
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Edit,EnableAndDeleteRule","RuleIsNotEdited");
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Edit,EnableAndDeleteRule","ErrorWhileEdit,EnableAndDeleteRule",e);
            System.out.println("Exception while enabling and deleting rule in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Edit,EnableAndDeleteRule","ErrorWhile"+"Edit,EnableAndDeleteRule",e);
            System.out.println("Exception while enabling and deleting rule in lead scoring page : "+e);
            return false;
        }
    }

    //Edit disabled rule
    private static boolean editDisabledrule(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(disableCond(driver,"Triggered","is equal to","Glow button",null))
            {
                if(editRule(driver,"Triggered","is equal to","Glow button",null,"Add","140"))
                {
                    etest.log(Status.PASS,"Disable and Edit Rule is checked");

                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndEditRule","RuleIsNotEdited");
                    return false;
                }
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndEditRule","RuleIsNotDisabled");
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndEditRule","ErrorWhileCheckingDisableAndEditRule",e);
            System.out.println("Exception while editing disabled rule in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","DisableAndEditRule","ErrorWhileCheckingDisableAndEditRule",e);
            System.out.println("Exception while editing disabled rule in lead scoring page : "+e);
            return false;
        }
    }

    //Check Invalid value for Points textbox
    private static boolean addInvalidpoint(WebDriver driver,String pnum,String cond,String qual,String val1,String val2,String condpts,String points)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))                   //.getAttribute("style")
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
            //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

            if(condpts.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            else if(condpts.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            elmt.findElement(By.className("cnfmbtm")).click();

            Thread.sleep(1000);

            if((elmt.findElement(By.id("ldaddpoints")).getAttribute("class")).equals("errorbdr"))
            {
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                etest.log(Status.PASS,"Add Invalid Points in Rule is checked");
                return true;
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddInvalidPoint","AlertIsNotFound");
                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddInvalidPoint","ErrorWhileAddingInvalidPoint",e);
            clickClose(driver);
            System.out.println("Exception while adding invalid points in points textbox in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddInvalidPoint","ErrorWhileAddingInvalidPoint",e);
            clickClose(driver);
            System.out.println("Exception while adding invalid points in points textbox in lead scoring page : "+e);
            return false;
        }
    }

    //Add Rule without choosing criteria (only add points)
    private static boolean addRulenoCriteria(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            elmt.findElement(By.id("lesspoints")).click();
            elmt.findElement(By.id("ldaddpoints")).sendKeys("980");
            elmt.findElement(By.className("cnfmbtm")).click();

            Thread.sleep(1000);

            WebElement elmtchk = driver.findElement(By.id("ldsettings")).findElement(By.id("prior1"));
            String elmt1 = elmtchk.findElement(By.id("prior1_col1")).getAttribute("class");
            String elmt2 = elmtchk.findElement(By.id("prior1_col2")).getAttribute("class");
            String elmt3 = elmtchk.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1")).getAttribute("class");

            if((elmt1.contains("errbdr"))&&(elmt2.contains("errbdr"))&&(elmt3.contains("errbdr")))
            {
                etest.log(Status.PASS,"Add Rule with no criteria is checked");
                clickClose(driver);
                return true;
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddRuleWithoutCriteria","AlertIsNotFound");
                clickClose(driver);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddRuleWithoutCriteria","ErrorWhileAddingRuleWithoutCriteria",e);
            System.out.println("Exception while adding rule without criteria in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddRuleWithoutCriteria","ErrorWhileAddingRuleWithoutCriteria",e);
            System.out.println("Exception while adding rule without criteria in lead scoring page : "+e);
            return false;
        }
    }

    //Add Invalid Criteria
    private static boolean addInvalidCriteria(WebDriver driver,String pnum,String cond,String qual,String val1,String val2,String condpts,String points)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))                   //.getAttribute("style")
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
            //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

            if(condpts.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            else if(condpts.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            elmt.findElement(By.className("cnfmbtm")).click();

            String vid = "prior"+pnum+"_col3";
            WebElement elmtip = elmt.findElement(By.id(vid));
            
            final WebElement e = elmtip.findElement(By.id("col3_input1"));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((e.getAttribute("class")).contains("errbdr"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            etest.log(Status.PASS,"Add Rule with invalid criteria is checked");
            
            clickClose(driver);
            
            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddInvalidCriteria","ErrorWhileAddingInvalidCriteria",e);
            clickClose(driver);
            System.out.println("Exception while adding invalid criteria in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","AddInvalidCriteria","ErrorWhileAddingInvalidCriteria",e);
            clickClose(driver);
            System.out.println("Exception while adding invalid criteria in lead scoring page : "+e);
            return false;
        }
    }

    //Add Criteria and Cancel
    private static boolean clickCancel(WebDriver driver,String pnum,String cond,String qual,String val1,String val2,String condpts,String points)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            final WebElement elmt = driver.findElement(By.id("ldsettings"));

            String cid = "prior"+pnum+"_col1_div";
            final String cdown = "prior"+pnum+"_col1_ddown";

            elmt.findElement(By.id(cid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            elmt.findElement(By.id(cdown)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(cond);
            elmt.findElement(By.id(cdown)).findElement(By.id("prior"+pnum+"_col10")).findElement(By.tagName("li")).click();

            String qid = "prior"+pnum+"_col2_div";
            final String qdown = "prior"+pnum+"_col2_ddown";

            elmt.findElement(By.id(qid)).click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            List<WebElement> elmts = elmt.findElement(By.id(qdown)).findElement(By.id("prior"+pnum+"_col20")).findElements(By.tagName("li"));

            for(WebElement elmts1:elmts)
            {
                if((elmts1.getText()).equals(qual))
                {
                    elmts1.click();
                    break;
                }
            }

            if(qual.equals("is between"))
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                elmtip.findElement(By.id("col3_input2")).sendKeys(val2);
            }
            else
            {
                String vid = "prior"+pnum+"_col3";
                WebElement elmtip = elmt.findElement(By.id(vid));
                elmtip.findElement(By.id("col3_input1")).sendKeys(val1);
                if((elmtip.findElement(By.id("col3_div"))).equals("display: block;"))                   //.getAttribute("style")
                {
                    elmtip.findElement(By.id("col3_div")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
                }
            }
            //elmt.findElement(By.id("ldaddpoints")).sendKeys("28");

            if(condpts.equals("Add"))
            {
                elmt.findElement(By.id("addpoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }
            else if(condpts.equals("Less"))
            {
                elmt.findElement(By.id("lesspoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys(points);
            }

            elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();

            Thread.sleep(1000);

            String checkcond;
            String checkcond1;
            String ptscheck = "Add "+points+" points";

            if(val2 != null)
            {
                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                checkcond = "If the visitor "+cond+" "+qual+" "+val1+" to "+val2;
            }
            else
            {
                //result.put("Add "+cond+" "+qual+" "+val1,false);
                checkcond = "If the visitor "+cond+" "+qual+" "+val1;
            }

            if(condpts.equals("Add"))
            {
                ptscheck = "Add "+points+" points";
            }
            else if(condpts.equals("Less"))
            {
                ptscheck = "Less "+points+" points";
            }

            if(cond.contains("Visitor"))
            {
                if(val2 != null)
                {
                    //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                    checkcond = "If the "+cond+" "+qual+" "+val1+" to "+val2;
                }
                else
                {
                    //result.put("Add "+cond+" "+qual+" "+val1,false);
                    checkcond = "If the "+cond+" "+qual+" "+val1;
                }
            }

            WebElement elmtr = driver.findElement(By.id("scoreview"));
            List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

            for(WebElement elmt1:elmtslst)
            {
                checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                System.out.println(checkcond1 + "  and " + checkcond);

                if((checkcond1).contains(checkcond))
                {
                    if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                    {
                        //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elmt1);
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                        //wait.until(ExpectedConditions.elementToBeClickable(elmt1));
                        elmt1.findElements(By.tagName("div")).get(0).click();
                        if(qual.equals("is between"))
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input2")).getAttribute("title")).equals(val2)))
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,true);
                                //result.put("AddRule-"+cond,true);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCancel","RuleIsAdded");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1+" to "+val2,false);
                                //result.put("AddRule-"+cond,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCancel","RuleIsAdded");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                        }
                        else
                        {
                            if(((elmt.findElement(By.id(cid)).getText()).equals(cond))&&((elmt.findElement(By.id(qid)).getText()).equals(qual))&&(((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1))||((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val1+" Minutes"))))
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1,true);
                                //result.put("AddRule-"+cond,true);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCancel","RuleIsAdded");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                            else
                            {
                                //result.put("Add "+cond+" "+qual+" "+val1,false);
                                //result.put("AddRule-"+cond,false);
                                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCancel","RuleIsAdded");
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                maxcount++;
                                return false;
                            }
                        }
                    }
                }
            }
            etest.log(Status.PASS,"Click Cancel is checked");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCancel","ErrorWhileClickingCancelAndCheckRule",e);
            clickClose(driver);
            System.out.println("Exception while checking cancel button in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCancel","ErrorWhileClickingCancelAndCheckRule",e);
            clickClose(driver);
            System.out.println("Exception while checking cancel button in lead scoring page : "+e);
            return false;
        }
    }

    //Click Close button and check
    private static boolean clickClosecheck(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("scoreview")));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement elmt = driver.findElement(By.id("ldsettings"));

            elmt.findElement(By.className("hdr")).findElement(By.tagName("em")).click();

            Thread.sleep(1000);

            if((elmt.getAttribute("style")).contains("display: none;"))
            {
                etest.log(Status.PASS,"Click Close is checked");

                return true;
            }
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCloseInWindow","WindowIsNotClosed");
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCloseInWindow","ErrorWhileClosingWindow",e);
            System.out.println("Exception while checking close button in lead scoring page : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Lead Scoring","ClickCloseInWindow","ErrorWhileClosingWindow",e);
            System.out.println("Exception while checking close button in lead scoring page : "+e);
            return false;
        }
    }

    /*
    //Remove a rule from multiple conditions (Single OR)
    private static boolean remSingleOR(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            if(addScoreConditionSOR(driver))
            {
                Thread.sleep(1000);

                WebElement elmt = driver.findElement(By.id("ldsettings"));

                addCriteria(driver,"1","Number of Visits","is more than","5",null);
                elmt.findElement(By.id("prior1")).findElement(By.cssSelector("div.or.floatlf.opr")).click();
                //wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id="+"prior2"+"]/div[1]/div")));
                addCriteria(driver,"2","Number of Past Chats","is less than","10",null);

                String checkcond21 = "If the visitor Number of Visits is more than 5";
                String checkcond22 = "If the visitor Number of Past Chats is less than 10";

                String cond1 = "Number of Visits";
                String cond2 = "Number of Past Chats";
                String qual1 = "is more than";
                String qual2 = "is less than";
                String val11 = "5";
                String val21 = "10";

                elmt.findElement(By.id("lesspoints")).click();
                elmt.findElement(By.id("ldaddpoints")).sendKeys("987");
                elmt.findElement(By.className("cnfmbtm")).click();

                int pnum = 1;

                String ptscheck = "**";
                String checkcond1;

                String condpts = "Less";
                String points = "987";

                if(condpts.equals("Add"))
                {
                    ptscheck = "Add "+points+" points";
                }
                else if(condpts.equals("Less"))
                {
                    ptscheck = "Less "+points+" points";
                }

                WebElement elmtr = driver.findElement(By.id("scoreview"));
                List<WebElement> elmtslst = elmtr.findElements(By.className("leadscrlst"));

                for(WebElement elmt1:elmtslst)
                {
                    checkcond1 = elmt1.findElements(By.tagName("div")).get(0).getText();//+" "+elmt1.findElements(By.tagName("div")).get(0).findElements(By.tagName("span")).get(0).getText();
                    System.out.println(checkcond1 + "  and " + checkcond21 + " OR " + checkcond22);

                    if(((checkcond1).contains(checkcond21))&&((checkcond1).contains("OR"))&&((checkcond1).contains(checkcond22)))
                    {
                        if((elmt1.findElements(By.tagName("div")).get(1).getText()).equals(ptscheck))
                        {
                            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt1.getLocation().y+")");
                            elmt1.findElements(By.tagName("div")).get(0).click();
                            if(((elmt.findElement(By.id("prior"+pnum+"_col1_div")).getText()).equals(cond1))&&((elmt.findElement(By.id("prior"+pnum+"_col2_div")).getText()).equals(qual1))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val11)))
                            {
                                pnum++;
                                if(((elmt.findElement(By.id("prior"+pnum+"_col1_div")).getText()).equals(cond2))&&((elmt.findElement(By.id("prior"+pnum+"_col2_div")).getText()).equals(qual2))&&((elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals(val21)))
                                {
                                    mouseOver(driver,elmt.findElement(By.id("prior"+pnum+"_col3")));

                                    elmt.findElement(By.id("prior"+pnum+"_col3")).findElement(By.tagName("em")).click();

                                    Thread.sleep(1000);

                                    elmt.findElement(By.className("cnfmbtm")).click();



                                    elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                    return true;
                                }
                                else
                                {
                                    //result.put("Add "+cond1+" "+qual1+" "+val11,false);
                                    elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                    return false;
                                }
                            }
                            else
                            {
                                //result.put("Add "+cond1+" "+qual1+" "+val11,false);
                                elmt.findElement(By.cssSelector("div.cnfmbtm.mrgnlft_twenty")).click();
                                return false;
                            }
                        }
                    }
                }
                return false;
            }
            else
            {
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception : "+e);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+e);
            return false;
        }
    }
     */
}
