//$Id$
package com.zoho.livedesk.client.GlobalSearch;

import java.util.List;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.GlobalSearch.SearchCommonFunctions;
import com.zoho.livedesk.client.GlobalSearch.GlobalSearchModuleFunctions;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.util.common.VisitorDriverManager;

public class GlobalSearchModule{

	public static Hashtable finalResult = new Hashtable();
	public static Hashtable visitor_details = new Hashtable();
	public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String portal_name=null;
	public static String embed_name=null;
    public static String department="";

    public static String widget_code="";

    public static String ip = "123.123.123.123";
    public static int count = 0;
    public static String CHAT_ID = "";
    public static String UNIQUE_MESSAGE = "";
    public static String CANNED_MESSAGE = "";
    public static String CANNED_ID = "";
    public static String visitor_name = "";
    public static String visitor_mail = "";
    public static String visitor_phno = "";
    public static String visitor_question = "";

    public static VisitorDriverManager visitor_driver_manager;

    public static WebDriver setUpDriver() throws Exception
    {
        return Functions.setUp();
    }

	public static Hashtable test(WebDriver driver1) throws Exception
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();
			if(embed_name==null)
			{
				embed_name=ExecuteStatements.getDefaultEmbedName(driver1);
			}

			widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver1,embed_name);
			portal_name=ExecuteStatements.getPortal(driver1);

            TestResults = new Hashtable<String,Boolean>();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Global Search - Search Verify By Filters"));
			ComplexReportFactory.setValues(etest,"Automation","GlobalSearch");

			init(driver1,etest,widget_code);

            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Global Search - Search Box"));
			ComplexReportFactory.setValues(etest,"Automation","GlobalSearch");

			checkSearchBox(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Global Search - Contents Of Search Box"));
			ComplexReportFactory.setValues(etest,"Automation","GlobalSearch");

			checkContentsOfSearchBox(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Global Search - Search Tab"));
			ComplexReportFactory.setValues(etest,"Automation","GlobalSearch");

			checkContentsOfSearchTab(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Global Search - Search Verify"));
			ComplexReportFactory.setValues(etest,"Automation","GlobalSearch");

			checkSearchVerify(driver1);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Global Search - Search Verify By Filters"));

			checkSearchVerifyByFilters(driver1);

            ComplexReportFactory.closeTest(etest);

        }
		catch(Exception e)
		{
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            TakeScreenshot.screenshot(driver1,etest,"Global Search","Failure","Operator window screenshot");
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			visitor_driver_manager.closeAllDrivers(portal_name);

			finalResult.put("result",TestResults);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static void init(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		WebDriver visitor_driver = null;
		String id = "";
		try
		{
			visitor_driver = visitor_driver_manager.getDriver(driver);
			UNIQUE_MESSAGE = CommonUtil.getUniqueMessage();
			visitor_name = "visitor_"+UNIQUE_MESSAGE;
			visitor_mail = visitor_name+"@mail.com";
			visitor_phno = UNIQUE_MESSAGE;
			visitor_question = "Get details of "+UNIQUE_MESSAGE;

			visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,visitor_phno,null,visitor_question,null,null);
			CHAT_ID = ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);

			etest.log(Status.INFO,"A conversation was initiated and ended");
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","init","Exception",e);
		}
		try
		{
			//Internal chat 
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","h_mycolleagues"));
			Thread.sleep(1000);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","msgdisp"),5);
			if(CommonUtil.elfinder(driver,"id","msgdisp").isDisplayed())
			{
				etest.log(Status.PASS,"internal chat icon was displayed and was clicked");
				id = CommonUtil.elfinder(driver,"id","msgdisp").findElement(By.className("suprepmn")).getAttribute("id");
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath","//*[@id=\"msgdisp\"]/div"));
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","head"),5);
				if(CommonUtil.elfinder(driver,"id","barcontent").findElement(By.id("head")).findElement(By.id("photourl")).getAttribute("src").contains(id))
				{
					etest.log(Status.PASS,"respective chat window opened");
					CommonUtil.sendKeysToWebElement(driver,CommonUtil.elfinder(driver,"xpath","//*[@id=\"barcontent\"]/div[contains(@class,'cwindow') and contains(@style,'block')]//textarea[@id=\"editor\"]"),UNIQUE_MESSAGE+Keys.RETURN);
				}
				else
				{
					etest.log(Status.FAIL,"respective chat window didnot open");
					TakeScreenshot.screenshot(driver,etest,"Global Search","init","Operator window screenshot");
				}
			}
			else
			{
				etest.log(Status.FAIL,"internal chat was not displayed");
				TakeScreenshot.screenshot(driver,etest,"Global Search","init","Operator window screenshot");
			}

			GlobalSearchModuleFunctions.refreshPage(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","init","Exception",e);
		}
		try
		{
			//canned message creation
			CANNED_MESSAGE = "canned_"+UNIQUE_MESSAGE;
			Tab.clickCannedMessages(driver);
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","canned_sm_category"));
			if(CommonUtil.elfinder(driver,"id","emptycannedcategory").isDisplayed())
			{
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","canned_sm_message"));
				CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
				CannedMessagesCommonFunctions.createNewCannedMessage(driver,CANNED_MESSAGE,"Automation");
			}
			else
			{
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","canned_sm_message"));
				CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
				CannedMessagesCommonFunctions.createNewCannedMessage(driver,CANNED_MESSAGE,null);
			}

			List<WebElement> elements = CommonUtil.elfinder(driver,"id","cmsglist").findElements(By.className("list-row"));
			for(WebElement element : elements)
			{
				if(element.findElement(By.className("cmn_wordbr")).getText().contains(CANNED_MESSAGE))
				{
					etest.log(Status.PASS,"New unique canned message("+CANNED_MESSAGE+") was added");
					CANNED_ID = element.getAttribute("id");
					break;
				}
			}
			GlobalSearchModuleFunctions.refreshPage(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","init","Exception",e);
		}
		try
		{
			// Blocking ip
			boolean flag = true;
			Tab.clickSettings(driver);
			Tab.clickBlockedIP(driver);
			if(CommonUtil.elfinder(driver,"id","modulelist").getText().contains("No IPs blocked"))
			{
				driver.findElement(By.linkText("Add")).click();
			}
			else
			{
				List<WebElement> elements = CommonUtil.elfinder(driver,"id","listview").findElements(By.className("list-row"));
				for(WebElement element : elements)
				{
					if(element.getText().contains(ip))
					{
						etest.log(Status.INFO,"IP ("+ip+") was already blocked");
						flag = false;
						break;
					}
				}
				if(flag)
				{
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","ipaddbtn"));
				}
			}
			if(flag)
			{
				etest.log(Status.PASS,"IP ("+ip+") was blocked");
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","txtipname"),5);
				CommonUtil.sendKeysToWebElement(driver,CommonUtil.elfinder(driver,"id","txtipname"),ip);
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","ipsavebtn"),5);
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","ipsavebtn"));
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","ipaddbtn"),10);
			}
			GlobalSearchModuleFunctions.refreshPage(driver);
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","init","Exception",e);
		}
	}

	public static void checkSearchBox(WebDriver driver)
	{
		try
		{
			TestResults.put("GS1",GlobalSearchModuleFunctions.checkPlaceholderValue(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS1",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchBox","Exception",e);
		}

		try
		{
			TestResults.put("GS2",GlobalSearchModuleFunctions.checkSearchTab(driver,etest,UNIQUE_MESSAGE));
		}
		catch(Exception e)
		{
			TestResults.put("GS2",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchBox","Exception",e);
		}

		// new UI change
		// try
		// {
		// 	TestResults.put("GS3",GlobalSearchModuleFunctions.checkSearchInputSize(driver,etest));
		// }
		// catch(Exception e)
		// {
		// 	TestResults.put("GS3",false);
		// 	TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchBox","Exception",e);
		// }
		
	}

	public static void checkContentsOfSearchBox(WebDriver driver)
	{
		try
		{
			TestResults.put("GS4",GlobalSearchModuleFunctions.checkMoreResults(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS4",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkContentsOfSearchBox","Exception",e);
		}
		
		try
		{
			TestResults.put("GS5",GlobalSearchModuleFunctions.checkSearchCategories(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS5",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkContentsOfSearchBox","Exception",e);
		}

		try	
		{
			TestResults.put("GS8",GlobalSearchModuleFunctions.checkNoResults(driver,"yuo",etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS8",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkContentsOfSearchBox","Exception",e);
		}
	}

	public static void checkContentsOfSearchTab(WebDriver driver)
	{
		try
		{
			TestResults.put("GS6",GlobalSearchModuleFunctions.checkFilterMenu(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS6",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkContentsOfSearchTab","Exception",e);
		}

		try
		{
			TestResults.put("GS7",GlobalSearchModuleFunctions.checkSearchResultHeader(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS7",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkContentsOfSearchTab","Exception",e);
		}

		try
		{	
			TestResults.put("GS9",GlobalSearchModuleFunctions.checkSearchResultHighlighted(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS9",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkContentsOfSearchTab","Exception",e);
		}
	}

	public static void checkSearchVerify(WebDriver driver)
	{
		int passcount = 0;
		try
		{
			if(GlobalSearchModuleFunctions.checkSearchBy(driver,etest,visitor_name))
			{
				passcount++;
			}
			if(GlobalSearchModuleFunctions.checkSearchBy(driver,etest,visitor_question))
			{
				passcount++;
			}
			if(GlobalSearchModuleFunctions.checkSearchBy(driver,etest,visitor_mail))
			{
				passcount++;
			}
			if(GlobalSearchModuleFunctions.checkSearchBy(driver,etest,visitor_phno))
			{
				passcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerify","Exception",e);
		}
		
		if(passcount ==4)
		{
			TestResults.put("GS10",true);
		}
		else
		{
			TestResults.put("GS10",false);	
		}

		passcount = 0;
		try
		{	
			if(GlobalSearchModuleFunctions.SearchByFilter(driver,etest,"department",0))
			{
				passcount++;
			}
			if(GlobalSearchModuleFunctions.SearchByFilter(driver,etest,"embed",1))
			{
				passcount++;
			}
			if(GlobalSearchModuleFunctions.SearchByFilter(driver,etest,"user",2))
			{
				passcount++;
			}
			if(GlobalSearchModuleFunctions.SearchFilterByDate(driver,etest,"timetype",3))
			{
				passcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerify","Exception",e);
		}
		if(passcount == 4)
		{
			TestResults.put("GS13",true);
		}
		else
		{
			TestResults.put("GS13",false);
		}
	}

	public static void checkSearchVerifyByFilters(WebDriver driver)
	{
		try
		{
			TestResults.put("GS11",GlobalSearchModuleFunctions.checkSearchInCannedMessage(driver,etest,CANNED_MESSAGE,CANNED_ID));
		}
		catch(Exception e)
		{
			TestResults.put("GS11",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerifyByFilters","Exception",e);
		}
		try
		{	
			TestResults.put("GS12",GlobalSearchModuleFunctions.checkSearchByBlockedIP(driver,etest,ip));
		}
		catch(Exception e)
		{
			TestResults.put("GS12",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerifyByFilters","Exception",e);
		}
		try
		{	
			TestResults.put("GS14",GlobalSearchModuleFunctions.checkSearchAll(driver,etest));
		}
		catch(Exception e)
		{
			TestResults.put("GS14",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerifyByFilters","Exception",e);
		}
		try
		{	
			Thread.sleep(30000);
			TestResults.put("GS15",GlobalSearchModuleFunctions.checkSearchInInternalChat(driver,etest,UNIQUE_MESSAGE));
		}
		catch(Exception e)
		{
			TestResults.put("GS15",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerifyByFilters","Exception",e);
		}
		try
		{	
			TestResults.put("GS16",GlobalSearchModuleFunctions.checkNavigateButtonsInSearchResults(driver,etest));	
		}
		catch(Exception e)
		{
			TestResults.put("GS16",false);
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchVerifyByFilters","Exception",e);
		}
	}
}
