//$Id$
package com.zoho.livedesk.client.GlobalSearch;

import com.zoho.livedesk.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.client.TakeScreenshot;

public class SearchCommonFunctions
{
	public static final String
	SEARCH_TAB_TITLE = "Search",
	SEARCH_URL = "#search";

	public static final By 
	SEARCH_TAB_ID = By.id("menu_search"),
	SEARCH_BOX_ID = By.id("searchinput"),
	SEARCH_LOAD_ID = By.id("srchload"),
	RIGHT_CONTAINER_ID = By.id("rightcontainer");

	public static boolean isSearchTab(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(SEARCH_TAB_ID),5);
		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains(SEARCH_URL) && driver.findElement(SEARCH_TAB_ID).isDisplayed() && 
			driver.findElement(RIGHT_CONTAINER_ID).findElement(By.className("floatlf")).getText().contains(SEARCH_TAB_TITLE))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static boolean isSearchTab(WebDriver driver,ExtentTest etest) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(SEARCH_TAB_ID),5);
		Thread.sleep(1000);
		if(driver.getCurrentUrl().contains(SEARCH_URL))
		{
			etest.log(Status.PASS,"Search url was verified -- SUCCESS -- ");
		}
		else
		{
			etest.log(Status.FAIL,"url mismatch -- found -- "+driver.getCurrentUrl());
			TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
			return false;
		}

		if(driver.findElement(SEARCH_TAB_ID).isDisplayed())
		{
			etest.log(Status.PASS,"Search tab was found in the left pane of the main page");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Search tab was not found in the left pane of the main page");
			TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
			return false;
		}

		// if(driver.findElement(RIGHT_CONTAINER_ID).findElement(By.className("floatlf")).getText().contains(SEARCH_TAB_TITLE))
		// {
		// 	etest.log(Status.PASS,"Search tab content was verified -- contains the respective content");
		// 	return true;
		// }
		// else
		// {
		// 	etest.log(Status.FAIL,"Search tab content does not contains the expected text -- "+SEARCH_TAB_TITLE+" -- found -- "+driver.findElement(RIGHT_CONTAINER_ID).findElement(By.className("floatlf")).getText());
		// 	TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
		// 	return false;
		// }
	}

	public static void clickSearchBox(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(SEARCH_BOX_ID),5);
		CommonUtil.clickWebElement(driver,driver.findElement(SEARCH_BOX_ID));
	}

	public static void clickElement(WebDriver driver, String id) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id),5);
		CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id",id));	
		Thread.sleep(1000);
	}

	public static void clickElementByXpath(WebDriver driver,String xpath) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"xpath",xpath),5);
		CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath",xpath));
		Thread.sleep(1000);
	}

	public static boolean checkElementFound(WebDriver driver,String id) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id),5);
		Thread.sleep(1000);
		if(CommonUtil.elfinder(driver,"id",id).isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	} 
	public static boolean checkElementFound(WebDriver driver,WebElement element) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,element,5);
		Thread.sleep(1000);
		if(element.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static int findWordCountInString(String str,String findString)
	{
		int lastIndex = 0;
		int count = 0;

		while(lastIndex != -1)
		{

		    lastIndex = str.indexOf(findString,lastIndex);

		    if(lastIndex != -1)
		    {
		        count ++;
		        lastIndex += findString.length();
		    }
		}
		return count;
	}
	public static void sendTextToSearchBox(WebDriver driver,String message) throws Exception
	{
		Tab.clickVisitorsOnline(driver);
		CommonUtil.refreshPage(driver);
		CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(SEARCH_BOX_ID),5);
		clickSearchBox(driver);
		Thread.sleep(1000);
		driver.findElement(SEARCH_BOX_ID).clear();
		CommonUtil.sendKeysToWebElement(driver,driver.findElement(SEARCH_BOX_ID),message);	
		Thread.sleep(1000);
	}

	public static void sendTextToSearchBox(WebDriver driver,String message,Keys key) throws Exception
	{
		sendTextToSearchBox(driver,message);
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(SEARCH_BOX_ID)).click().build().perform();
		actions.moveToElement(driver.findElement(SEARCH_BOX_ID)).sendKeys(key).build().perform();
		// CommonUtil.sendKeysToWebElement(driver,driver.findElement(SEARCH_BOX_ID),""+key);
		Thread.sleep(1000);
		CommonWait.waitTillDisplayed(driver,By.id("header"));
	}

	public static boolean checkLoading(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(SEARCH_LOAD_ID),5);
		if(driver.findElement(SEARCH_LOAD_ID).isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static boolean isTextPresent(WebDriver driver,String search_text,String id) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id),5);
		if(CommonUtil.elfinder(driver,"id",id).getText().toLowerCase().contains(search_text.toLowerCase()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
