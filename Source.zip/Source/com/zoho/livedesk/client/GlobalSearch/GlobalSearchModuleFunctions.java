//$Id$
package com.zoho.livedesk.client.GlobalSearch;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.StaleElementReferenceException;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.*;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.CommonWait;

import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.AAgentsSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.GlobalSearch.SearchCommonFunctions;



public class GlobalSearchModuleFunctions
{
	public static String 
	GLOBAL_SEARCH_TEXT="";
	
	public static final String 
	SEARCH_PLACEHOLDER_VALUE = "Search...";

	public static final String
	NO_SEARCH_RESULTS = "No search results found.";

	public static final String 
	ADV_FILTER_OPTIONS[] = {"Select Department","Select Websites","Select Operator","Select Date"},
	SEARCH_RESULT_HEADER[] = {"Visitor Search Results","Operator Search Results","Canned Messages","Blocked IPs"},
	ID[] = {"department","embed","user","timetype"};

	public static boolean checkPlaceholderValue(WebDriver driver,ExtentTest etest) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","searchinput"),5);
		if(CommonUtil.checkStringequals(CommonUtil.elfinder(driver,"id","searchinput").getAttribute("placeholder"),SEARCH_PLACEHOLDER_VALUE,etest))
		{
			etest.log(Status.PASS,"Placeholder value ("+SEARCH_PLACEHOLDER_VALUE+") was found in search box");
			return true;
		}
		return false;
	}

	public static boolean checkSearchTab(WebDriver driver,ExtentTest etest,String search_text) throws Exception
	{
		int failcount = 0;
		try
		{
			GLOBAL_SEARCH_TEXT = search_text;
			SearchCommonFunctions.sendTextToSearchBox(driver,search_text,Keys.RETURN);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","menu_search"),5);
			Thread.sleep(1000);
			if(SearchCommonFunctions.isSearchTab(driver,etest))
			{
				etest.log(Status.PASS,"search tab was found on searching a word");
			}
			else
			{
				etest.log(Status.FAIL,"search tab was not found on searching a string");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				failcount++;
			}
			refreshPage(driver);
			Thread.sleep(1000);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","menu_search"),5);
			if(!SearchCommonFunctions.isSearchTab(driver))
			{
				etest.log(Status.PASS,"search tab disappeared on refreshing the page");
			}
			else
			{
				etest.log(Status.FAIL,"search tab didn't disappear on refreshing the page");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchTab","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static boolean checkSearchInputSize(WebDriver driver,ExtentTest etest)
	{
		try
		{
			int width_before = CommonUtil.elfinder(driver,"id","searchinput").getSize().getWidth();
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","searchinput"));
			Thread.sleep(1000);
			int width_after = CommonUtil.elfinder(driver,"id","searchinput").getSize().getWidth();
			if(width_before < width_after)
			{
				etest.log(Status.PASS,"Search box size increased when clicked");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Search box size did not increase while clicking it");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchInputSize","Exception",e);
			return false;
		}
	}

	public static boolean checkMoreResults(WebDriver driver,ExtentTest etest) throws Exception
	{
		SearchCommonFunctions.sendTextToSearchBox(driver,GLOBAL_SEARCH_TEXT);
		CommonUtil.mouseHover(driver,CommonUtil.elfinder(driver,"xpath","//*[contains(@class,'srchmore') and contains(text(),'More Results')]"));
		SearchCommonFunctions.clickElementByXpath(driver,"//*[contains(@class,'srchmore') and contains(text(),'More Results')]");
		Thread.sleep(1000);
		if(SearchCommonFunctions.isSearchTab(driver,etest))
		{
			etest.log(Status.PASS," On clicking More results option in the search drop down list, it navigates to Search tab");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"On clicking More results option in the search drop down list, it does not navigate to Search tab");
			TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
			return false;
		}
	}

	public static boolean checkSearchCategories(WebDriver driver,ExtentTest etest) throws Exception
	{
		String beforeClick = "";
		int failcount = 0;
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","srchdlt"),5);
		CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","srchdlt"));
		Thread.sleep(1000);
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","srchelpfil"),5);
		if(CommonUtil.elfinder(driver,"id","srchelpfil").isDisplayed())
		{
			Thread.sleep(1000);
			if(!checkClickCategories(driver,etest,"visitor","Visitor chats"))
			{
				failcount++;
			}
			Thread.sleep(1000);
			if(!checkClickCategories(driver,etest,"user","Operator Chats"))
			{
				failcount++;
			}
			Thread.sleep(1000);
			if(!checkClickCategories(driver,etest,"cannedmessage","Canned Message"))
			{
				failcount++;
			}
			Thread.sleep(1000);

			try
			{
				if(SearchCommonFunctions.checkElementFound(driver,"blockedip"))
				{
					beforeClick = CommonUtil.elfinder(driver,"id","blockedip").getAttribute("class");
					SearchCommonFunctions.clickElement(driver,"blockedip");
					if(CommonUtil.elfinder(driver,"id","blockedip").getAttribute("class").contentEquals(beforeClick))
					{
						etest.log(Status.PASS,"All Categories were not clicked at the same time -- checked -- SUCCESS");
					}
					else
					{
						etest.log(Status.FAIL,"All categories were clicked at the same time -- ERROR");
						TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						failcount++;
					}
				}
				else
				{
					etest.log(Status.FAIL,"blockedip element not found");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
					failcount++;
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchCategories","Exception",e);
				return false;
			}
		}
		else
		{
			etest.log(Status.FAIL,"Drop down list was not found on clicking options icon in search box");
			TakeScreenshot.screenshot(driver,etest,"Search Box","Failure","Operator window screenshot");
			failcount++;
		}
		return returnResult(failcount);
	}

	public static boolean checkClickCategories(WebDriver driver,ExtentTest etest,String id,String element)
	{
		String beforeClick = "";
		int failcount = 0;
		try
		{
			if(SearchCommonFunctions.checkElementFound(driver,id))
			{
				etest.log(Status.PASS,"'"+element+"' element was found in filter drop down list");
				
				beforeClick = CommonUtil.elfinder(driver,"id",id).getAttribute("class");
				SearchCommonFunctions.clickElement(driver,id);
				
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id),5);
				if(!CommonUtil.elfinder(driver,"id",id).getAttribute("class").contentEquals(beforeClick))
				{
					etest.log(Status.PASS,"'"+element+"' element in filter drop down list was clicked");
				}
				else
				{
					etest.log(Status.FAIL,"'"+element+"' element in filter drop down list gives a click error");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"'"+element+"' element was not found in filter drop down list");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkClickCategories","Exception",e);
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	// public static boolean checkLoadingIcon(WebDriver driver,ExtentTest etest)
	// {
	// 	int failcount = 0;
	// 	try
	// 	{
	// 		if(!checkLoader(driver,"yuo",etest))
	// 		{
	// 			failcount++;
	// 		}
	// 	}
	// 	catch(Exception e)
	// 	{
	// 		TakeScreenshot.screenshot(driver,etest,"Global Search","checkLoadingIcon","Exception",e);
	// 		failcount++;
	// 	}
	// 	finally
	// 	{
	// 		return returnResult(failcount);
	// 	}
	// }

	public static boolean checkNoResults(WebDriver driver,String message,ExtentTest etest) throws Exception
	{
		String search_text = GLOBAL_SEARCH_TEXT;
		GLOBAL_SEARCH_TEXT = message;
		SearchCommonFunctions.sendTextToSearchBox(driver,message);

		if(!CommonUtil.checkStringContainsAndLog(NO_SEARCH_RESULTS,CommonUtil.getElement(driver,By.id("srchhelp")).getText(),"No Search results",etest))
		{
			GLOBAL_SEARCH_TEXT = search_text;
			return false;
		}
		GLOBAL_SEARCH_TEXT = search_text;
		return true;

		// if(SearchCommonFunctions.checkLoading(driver))
		// {
		// 	etest.log(Status.PASS,"Loading icon was displayed in search box while searching the message : "+message);
		// 	try
		// 	{
		// 		checkMoreResults(driver,etest);
		// 		etest.log(Status.PASS,"No results were shown for invalid search string");
		// 	}
		// 	catch(Exception e)
		// 	{
		// 		etest.log(Status.FAIL,"Results were not shown for invalid search string");
		// 		TakeScreenshot.screenshot(driver,etest);
		// 	}
		// 	GLOBAL_SEARCH_TEXT = search_text;
		// 	return true;
		// }
		// else
		// {
		// 	etest.log(Status.FAIL,"Error displaying Loading icon in search box for the message : "+message);
		// 	TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
		// 	try
		// 	{
		// 		checkMoreResults(driver,etest);
		// 		etest.log(Status.PASS,"No results were shown for invalid search string");
		// 	}
		// 	catch(Exception e)
		// 	{
		// 		etest.log(Status.FAIL,"Results were not shown for invalid search string");
		// 		TakeScreenshot.screenshot(driver,etest);
		// 	}
		// 	GLOBAL_SEARCH_TEXT = search_text;
		// 	return false;
		// }
	}

	public static boolean checkWordEnter(WebDriver driver,ExtentTest etest) throws Exception
	{
		SearchCommonFunctions.sendTextToSearchBox(driver,GLOBAL_SEARCH_TEXT,Keys.RETURN);
		if(SearchCommonFunctions.isSearchTab(driver,etest))
		{
			etest.log(Status.PASS,"Searching a word in the search box navigates to Search tab");
			return true;
		}
		else
		{
			etest.log(Status.FAIL,"Searching a word in the search box does not navigate to Search tab");
			TakeScreenshot.screenshot(driver,etest,"Search Box","Failure","Operator window screenshot");
			return false;
		}
	}

	public static boolean checkFilterMenu(WebDriver driver,ExtentTest etest)
	{
		int failcount = 0;
		try
		{
			if(!checkWordEnter(driver,etest))
			{
				failcount++;
			}
			Thread.sleep(1000);

			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","filtrico"),5);
			if(SearchCommonFunctions.checkElementFound(driver,CommonUtil.elfinder(driver,"classname","filtrico")))
			{
				etest.log(Status.PASS,"Advanced filter icon was found on the Search tab");
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","filtrico"));
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","filtertype"),5);
				if(SearchCommonFunctions.checkElementFound(driver,CommonUtil.elfinder(driver,"id","filtertype")))
				{
					etest.log(Status.PASS,"Advanced filter icon was clicked");
					int i = 0;
					List<WebElement> elements = CommonUtil.elfinder(driver,"id","filtertype").findElements(By.className("filtlist"));
					for(WebElement element: elements)
					{
						if(!CommonUtil.checkStringcontains(element.getText(),ADV_FILTER_OPTIONS[i++],etest))
						{
							failcount++;
							TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						}
						else
						{
							etest.log(Status.PASS,"'"+ADV_FILTER_OPTIONS[i-1]+ "' was found in the advanced filter menu");
						}
					}
					if(!SearchCommonFunctions.checkElementFound(driver,CommonUtil.elfinder(driver,"classname","flapply")))
					{
						etest.log(Status.FAIL,"Apply option was not found in Advanced filter icon in Search tab");
						TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						failcount++;
					}
					else
					{
						etest.log(Status.PASS,"Apply option was also found in Advanced filter menu in search tab");
					}
					if(failcount == 0)
					{
						etest.log(Status.PASS,"Advanced Filter options expands on clicking the filter icon");
					}
				}
				else
				{
					failcount++;
					etest.log(Status.FAIL,"Advanced filter options icon in Search Tab was clicked but no options were shown");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				}

				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","filtrico"));
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","filtertype"),5);
				if(!SearchCommonFunctions.checkElementFound(driver,CommonUtil.elfinder(driver,"id","filtertype")))
				{
					etest.log(Status.PASS,"Advanced filter options disappears on clicking filter icon after expanding");
				}
				else
				{
					etest.log(Status.FAIL,"Advanced filter options didnot disappear on clicking it again after expanded in Saerch tab");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.FAIL,"Advanced Filter option icon in Search Tab was not displayed");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkFilterMenu","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static boolean checkSearchResultHeader(WebDriver driver,ExtentTest etest)
	{
		int failcount = 0;
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,"visitor",Keys.RETURN);

			CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("searchfield")),"1"+Keys.RETURN);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.getElement(driver,By.id("list"),By.className("listhdr")),5);
			Thread.sleep(2000);
			
			int i = 0;
			List<WebElement> elements = CommonUtil.elfinder(driver,"id","list").findElements(By.className("listhdr"));
			for(WebElement element:elements)
			{
				if(!CommonUtil.checkStringcontains(element.getText(),SEARCH_RESULT_HEADER[i++],etest))
				{
					etest.log(Status.FAIL,"'"+SEARCH_RESULT_HEADER[i-1]+" was not found in the search results");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
					failcount++;
				}
				else
				{
					etest.log(Status.PASS,"'"+SEARCH_RESULT_HEADER[i-1]+"' was found in the search results");
				}
			}
			if(failcount == 0)
			{
				etest.log(Status.PASS,"All Search results headers are checked and verified");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchResultHeader","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static boolean checkSearchResultHighlighted(WebDriver driver,ExtentTest etest)
	{
		int count = 0,search_text_count = 0;
		int failcount = 0;
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,"details",Keys.RETURN);
			Thread.sleep(500);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","list"),5);
			List<WebElement> elements = CommonUtil.elfinder(driver,"id","list").findElements(By.className("txtelips"));
			for(WebElement element : elements)
			{
				search_text_count = SearchCommonFunctions.findWordCountInString(element.getText(),"details");
				if(element.findElements(By.className("searchres_highlight")).size() < search_text_count)
				{
					failcount++;
				}
			}
			if(failcount == 0)
			{
				etest.log(Status.PASS,"All search texts were highlighted in Search results");
			}
			else
			{
				etest.log(Status.FAIL,"Search Text was not highlighted in search results");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				failcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchResultHighlighted","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);	
		}
	}

	public static boolean checkSearchBy(WebDriver driver,ExtentTest etest,String search_text)
	{
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,search_text,Keys.RETURN);
			try
			{
				CommonWait.waitTillDisplayed(driver,By.id("listview0"));
			}
			catch (Exception e) 
			{
				etest.log(Status.FAIL,search_text+" was not found in the search results in search tab");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}

			if(CommonUtil.getElement(driver,By.id("srchcntr")).getText().contains(NO_SEARCH_RESULTS))
			{
				etest.log(Status.FAIL,search_text+" was not found in the search results in search tab");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
			
			List<WebElement> elements = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
			for(WebElement element : elements)
			{
				String onClickValue = element.getAttribute("onclick");
				CommonUtil.clickWebElement(driver,element);
				etest.log(Status.INFO,"chat with --"+search_text+"-- was clicked from search results in search tab");
				Thread.sleep(3000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","zsmaincontainer"),5);
				etest.log(Status.PASS,"repective chat window opened on clicking the chat from search results in search tab");
				if(onClickValue.contains(CommonUtil.elfinder(driver,"id","zsmaincontainer").getAttribute("visitorid")))
				{
					etest.log(Status.PASS,"Search text ("+search_text+") was found in search result and also verified in chat");
					Thread.sleep(1000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","searchbck"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","searchbck"));
					Thread.sleep(1000);
					return true;
				}
				else
				{
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","searchbck"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","searchbck"));
					Thread.sleep(1000);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchBy","Exception",e);
			return false;
		}
		return false;
	}

	public static boolean checkSearchInCannedMessage(WebDriver driver,ExtentTest etest,String msg,String id)
	{
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,msg,Keys.RETURN);
			List<WebElement> filterElements =  CommonUtil.elfinder(driver,"id","srcfilter").findElements(By.tagName("li"));
			for(WebElement element : filterElements)
			{
				if(!element.getText().contains("Canned Message"))
				{
					etest.log(Status.PASS,"'"+element.getText()+"' was clicked from filter menu in search tab");
					CommonUtil.clickWebElement(driver,element);
					Thread.sleep(500);
				}
			}
			try
			{
				CommonWait.waitTillDisplayed(driver,By.id("listview2"));
			}
			catch (Exception e) 
			{
				etest.log(Status.FAIL,msg+" was not found in the search results in search tab");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
			List<WebElement> elements = CommonUtil.elfinder(driver,"id","listview2").findElements(By.className("tablegrp"));
			for(WebElement element : elements)
			{
				if(element.getAttribute("onclick").contains(id))
				{
					CommonUtil.clickWebElement(driver,element);
					Thread.sleep(1000);
					etest.log(Status.PASS,"expected canned message ("+msg+") was found in search results");
					return true;
				}
			}
			etest.log(Status.FAIL,"expected canned message ("+msg+") was not found in the search results");
			TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchInCannedMessage","Exception",e);
			return false;
		}
		return false;
	}

	public static boolean checkSearchByBlockedIP(WebDriver driver,ExtentTest etest,String ip)
	{
		String id = "";
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,ip,Keys.RETURN);
			List<WebElement> filterElements =  CommonUtil.elfinder(driver,"id","srcfilter").findElements(By.tagName("li"));
			for(WebElement element : filterElements)
			{
				if(!element.getText().contains("Blocked IP"))
				{
					etest.log(Status.PASS,"'"+element.getText()+"' was clicked from filter menu in search tab");
					CommonUtil.clickWebElement(driver,element);
					Thread.sleep(500);
				}
			}
			try
			{
				CommonWait.waitTillDisplayed(driver,By.id("listview3"));
			}
			catch (Exception e) 
			{
				etest.log(Status.FAIL,ip+" was not found in the search results in search tab");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
			List<WebElement> elements = CommonUtil.elfinder(driver,"id","listview3").findElements(By.className("tablegrp"));
			for(WebElement element : elements)
			{
				id = element.getAttribute("onclick");
				id = id.substring(id.indexOf("','")+3,id.indexOf("')"));
				CommonUtil.clickWebElement(driver,element);
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","configview"),5);
				if(driver.getCurrentUrl().contains(id) && driver.getCurrentUrl().contains("blockedip") && 
					CommonUtil.elfinder(driver,"classname","detail-view").getAttribute("innerText").contains(ip))
				{
					etest.log(Status.INFO,"blocked ip address -- page content -- url -- verified -- SUCCES");
					etest.log(Status.PASS,"Expected IP ("+ip+") was found in blocked IP search results");
					return true;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchByBlockedIP","Exception",e);
			return false;	
		}
		return false;
	}

	public static boolean checkSearchInInternalChat(WebDriver driver,ExtentTest etest,String msg)
	{
		int failcount = 0;
		String id = "";
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,msg,Keys.RETURN);
			List<WebElement> filterElements =  CommonUtil.elfinder(driver,"id","srcfilter").findElements(By.tagName("li"));
			for(WebElement element : filterElements)
			{
				if(!element.getText().contains("Operator Chats"))
				{
					etest.log(Status.PASS,"'"+element.getText()+"' was clicked from filter menu in search tab");
					CommonUtil.clickWebElement(driver,element);
					Thread.sleep(500);
				}
			}
			try
			{
				CommonWait.waitTillDisplayed(driver,By.id("listview1"));
			}
			catch (Exception e) 
			{
				etest.log(Status.FAIL,msg+" was not found in the search results in search tab");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
			List<WebElement> elements = CommonUtil.elfinder(driver,"id","listview1").findElements(By.className("tablegrp"));
			for(WebElement element : elements)
			{
				id = element.getAttribute("onclick");
				id = id.substring(id.indexOf("','")+3,id.indexOf("')"));
				CommonUtil.clickWebElement(driver,element);
				Thread.sleep(3000);
				CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","user_sm_chathistory"),5);
				if(driver.getCurrentUrl().contains(id) && driver.getCurrentUrl().contains("user/chathistory") && 
					CommonUtil.elfinder(driver,"id","user_sm_chathistory").getAttribute("innerText").contains("Internal Chat History"))
				{
					etest.log(Status.INFO,"operator chat address -- page content -- url -- verified -- SUCCES");
					etest.log(Status.PASS,"Expected text ("+msg+") was found in internal chat search results");
					return true;
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchInInternalChat","Exception",e);
			return false;
		}
		return false;
	}

	public static boolean checkNavigateButtonsInSearchResults(WebDriver driver,ExtentTest etest)
	{
		int failcount = 0;
		String id = "",pageInfo = "";
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,"visitor",Keys.RETURN);
			
			id = CommonUtil.elfinder(driver,"classname","tablegrp").getAttribute("id");
			pageInfo = CommonUtil.elfinder(driver,"id","listview0").findElement(By.className("paginate")).getText();

			if(CommonUtil.elfinder(driver,"xpath","//*[contains(@onclick,'Next')]").isDisplayed())
			{
				etest.log(Status.PASS,"Next icon was present in the search results in search tab");
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath","//*[contains(@onclick,'Next')]"));
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.elfinder(driver,"classname","listhdr"),"page","2");
				etest.log(Status.INFO,"Next icon was clicked in the search results in search tab");

				if(!CommonUtil.elfinder(driver,"classname","tablegrp").getAttribute("id").contentEquals(id) && 
					!CommonUtil.elfinder(driver,"id","listview0").findElement(By.className("paginate")).getText().contentEquals(pageInfo))
				{
					etest.log(Status.PASS,"Navigating the search results to next page -- SUCCESS --");
				}
				else
				{
					etest.log(Status.FAIL,"Error navigating to next page in search results");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
					failcount++;
				}



				id = CommonUtil.elfinder(driver,"classname","tablegrp").getAttribute("id");
				pageInfo = CommonUtil.elfinder(driver,"id","listview0").findElement(By.className("paginate")).getText();
				etest.log(Status.PASS,"Previous icon was present in the search results in search tab");
				CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath","//*[contains(@onclick,'Previous')]"));
				Thread.sleep(1000);
				CommonUtil.waitTillWebElementContainsAttributeValue(CommonUtil.elfinder(driver,"classname","listhdr"),"page","1");
				etest.log(Status.INFO,"Previous icon was clicked in the search results in search tab");

				if(!CommonUtil.elfinder(driver,"classname","tablegrp").getAttribute("id").contentEquals(id) &&
					!CommonUtil.elfinder(driver,"id","listview0").findElement(By.className("paginate")).getText().contentEquals(pageInfo))
				{
					etest.log(Status.PASS,"Navigating the search results to previous page -- SUCCESS --");
				}
				else
				{
					etest.log(Status.FAIL,"error navigating to previous page in search results");
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
					failcount++;
				}
			}
			else
			{
				etest.log(Status.INFO,"The search result was a single page result.");
				TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkNavigateButtonsInSearchResults","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static boolean SearchByFilter(WebDriver driver,ExtentTest etest,String id,int i)
	{
		int count = 0,failcount = 0;
		String str = "";
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,"visitor",Keys.RETURN);
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","srcfilter").findElement(By.className("filtrico")));
			WebElement element = CommonUtil.elfinder(driver,"id","filtertype").findElement(By.id(id));

				if(CommonUtil.checkStringcontains(element.getText(),ADV_FILTER_OPTIONS[i],etest))
				{
					etest.log(Status.PASS,"Expected filter option ("+ADV_FILTER_OPTIONS[i]+") was found in filter menu");
					Thread.sleep(3000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_div"),5);
					CommonUtil.clickWebElement(driver,element);
					Thread.sleep(1000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_ddown"),5);
					etest.log(Status.INFO,"'"+ADV_FILTER_OPTIONS[i]+"' was clicked in the filter menu in search tab");
					List<WebElement> dropdown = driver.findElement(By.id(id+"_ddown")).findElements(By.tagName("li"));
					for(WebElement element_drop : dropdown)
					{
						if(!element_drop.getAttribute("val").contentEquals("-1") && !(element_drop.getAttribute("val").contentEquals("none")))
						{
							str = element_drop.getText();
							CommonUtil.clickWebElement(driver,element_drop);
							etest.log(Status.INFO,"The "+id+" '"+str+"' was clicked from the drop down list in filter menu in search tab");
							break;
						}
					}
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","flapply"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","flapply"));
					etest.log(Status.INFO,"apply icon was clicked from the filter menu in search tab");
					try
					{
						CommonWait.waitTillDisplayed(driver,By.id("listview0"));
					}
					catch (Exception e) 
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					List<WebElement> results = null;
					try
					{
						results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
					}
					catch(Exception e)
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					int res_count = 0;

					for(int j=0;j<results.size();j++)
					{
						if(j==3)
						{
							CommonUtil.scrollToBottomOfPage(driver);
						}
						try
						{
							CommonWait.waitTillDisplayed(driver,By.id("listview0"));
						}
						catch (Exception e) 
						{
							etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
							TakeScreenshot.screenshot(driver,etest);
							return false;
						}
						results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
						WebElement element_res = results.get(j);
						if(res_count>5)break;
						res_count++;
						CommonUtil.waitTillWebElementDisplayed(driver,element_res,5);
						if(element_res.findElement(By.className("actions3")).getText().contains(str))
						{
							etest.log(Status.PASS,"Expected "+id+" ("+str+") was found in the Search results ("+res_count+") in search tab");
						}
						else
						{
							failcount++;
							etest.log(Status.FAIL,"Mismatch Content: Expected---"+str+"---not Found in---"+element_res.findElement(By.className("actions3")).getText());
							TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						}
						Thread.sleep(500);
					}
					CommonUtil.scrollToTop(driver);

					Thread.sleep(1000);
					List<WebElement> elem = CommonUtil.elfinder(driver,"xpath","//*[contains(@class,'filtlist') and contains(@purpose,'"+id+"')]").findElements(By.className("filtval"));
					for(WebElement ele : elem)
					{
						CommonUtil.clickWebElement(driver,ele.findElement(By.tagName("em")));
						etest.log(Status.PASS,"The "+id+" '"+ele.getText()+"' was removed from the filter list in Search tab");
					}

					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","flapply"),5);
					Thread.sleep(1000);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","flapply"));
					etest.log(Status.INFO,"apply icon was clicked from the filter menu in search tab");
				}
				else
				{
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","SearchByFilter","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static boolean SearchFilterByDate(WebDriver driver,ExtentTest etest,String id,int i)
	{
		int failcount = 0;
		String str = "";
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,"visitor",Keys.RETURN);
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","srcfilter").findElement(By.className("filtrico")));
			WebElement element = CommonUtil.elfinder(driver,"id","filtertype").findElement(By.id(id));

				if(CommonUtil.checkStringcontains(element.getText(),ADV_FILTER_OPTIONS[i],etest))
				{
					etest.log(Status.PASS,"Expected filter option ("+ADV_FILTER_OPTIONS[i]+") was found in filter menu");
					Thread.sleep(3000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_div"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id",id));
					Thread.sleep(1000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_ddown"),5);
					etest.log(Status.INFO,"'"+ADV_FILTER_OPTIONS[i]+"' was clicked in the filter menu in search tab");
					List<WebElement> dropdown = driver.findElement(By.id(id+"_ddown")).findElements(By.tagName("li"));
					for(WebElement element_drop : dropdown)
					{
						if(!element_drop.getAttribute("val").contentEquals("-1") && !(element_drop.getAttribute("val").contentEquals("none")))
						{
							str = element_drop.getText();
							CommonUtil.clickWebElement(driver,element_drop);
							etest.log(Status.INFO,"The "+id+" '"+str+"' was clicked from the drop down list in filter menu in search tab");
							break;
						}
					}
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","flapply"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","flapply"));
					Thread.sleep(2000);
					etest.log(Status.INFO,"apply icon was clicked from the filter menu in search tab");
					try
					{
						CommonWait.waitTillDisplayed(driver,By.id("listview0"));
					}
					catch (Exception e) 
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					List<WebElement> results = null;
					try
					{
						results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
					}
					catch(Exception e)
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					int res_count = 0;
					for(int j = 0; j < results.size(); j++)
					{
						if(j==3)
						{
							CommonUtil.scrollToBottomOfPage(driver);
						}
						try
						{
							CommonWait.waitTillDisplayed(driver,By.id("listview0"));
						}
						catch (Exception e) 
						{
							etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
							TakeScreenshot.screenshot(driver,etest);
							return false;
						}
						results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
						WebElement element_res = results.get(j);
						if(res_count>5)break;
						res_count++;
						CommonUtil.waitTillWebElementDisplayed(driver,element_res,5);
						if(element_res.getText().contains(str))
						{
							etest.log(Status.PASS,"Expected "+id+" ("+str+") was found in the Search results ("+res_count+") in search tab");
						}
						else
						{
							failcount++;
							etest.log(Status.FAIL,"Mismatch Content: Expected---"+str+"---not Found in Search results---"+element_res.getText());
							TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						}
						Thread.sleep(500);
					}
					CommonUtil.scrollToTop(driver);


					Thread.sleep(1000);
					List<WebElement> elem = CommonUtil.elfinder(driver,"xpath","//*[contains(@class,'filtlist') and contains(@purpose,'"+id+"')]").findElements(By.className("filtval"));
					for(WebElement ele : elem)
					{
						CommonUtil.clickWebElement(driver,ele.findElement(By.tagName("em")));
						etest.log(Status.PASS,"The "+id+" '"+ele.getText()+"' was removed from the filter list in Search tab");
					}

					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","flapply"),5);
					Thread.sleep(1000);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","flapply"));
					etest.log(Status.INFO,"apply icon was clicked from the filter menu in search tab");
				}
				else
				{
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","SearchFilterByDate","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static boolean checkSearchAll(WebDriver driver,ExtentTest etest) throws Exception
	{
		int failcount = 0,i;
		String str = "";
		String id = "";
		WebElement element;
		try
		{
			SearchCommonFunctions.sendTextToSearchBox(driver,"visitor",Keys.RETURN);
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","srcfilter").findElement(By.className("filtrico")));
		
			for(i = 0; i < 3 ;i++)
			{
				id = ID[i];
				element = CommonUtil.elfinder(driver,"id","filtertype").findElement(By.id(id));

				if(CommonUtil.checkStringcontains(element.getText(),ADV_FILTER_OPTIONS[i],etest))
				{
					etest.log(Status.PASS,"Expected filter option ("+ADV_FILTER_OPTIONS[i]+") was found in filter menu");
					Thread.sleep(3000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_div"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","filtertype").findElement(By.id(id)));
					Thread.sleep(1000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_ddown"),5);
					etest.log(Status.INFO,"'"+ADV_FILTER_OPTIONS[i]+"' was clicked in the filter menu in search tab");
					List<WebElement> dropdown = driver.findElement(By.id(id+"_ddown")).findElements(By.tagName("li"));
					for(WebElement element_drop : dropdown)
					{
						if(!element_drop.getAttribute("val").contentEquals("-1") && !(element_drop.getAttribute("val").contentEquals("none")))
						{
							str = element_drop.getText();
							CommonUtil.clickWebElement(driver,element_drop);
							etest.log(Status.INFO,"The "+id+" '"+str+"' was clicked from the drop down list in filter menu in search tab");
							break;
						}
					}
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","flapply"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","flapply"));
					Thread.sleep(2000);
					etest.log(Status.INFO,"apply icon was clicked from the filter menu in search tab");
					try
					{
						CommonWait.waitTillDisplayed(driver,By.id("listview0"));
					}
					catch (Exception e) 
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					List<WebElement> results = null;
					try
					{
						results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
					}
					catch(Exception e)
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					int res_count = 0;
					for(int j = 0; j < results.size(); j++)
					{
						if(j==3)
						{
							CommonUtil.scrollToBottomOfPage(driver);
						}
						try
						{
							CommonWait.waitTillDisplayed(driver,By.id("listview0"));
						}
						catch (Exception e) 
						{
							etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
							TakeScreenshot.screenshot(driver,etest);
							return false;
						}
						results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
						WebElement element_res = results.get(j);
						if(res_count>5)break;
						res_count++;
						CommonUtil.waitTillWebElementDisplayed(driver,element_res,5);
						if(element_res.findElement(By.className("actions3")).getText().contains(str))
						{
							etest.log(Status.PASS,"Expected "+id+" ("+str+") was found in the Search results ("+res_count+") in search tab");
						}
						else
						{
							failcount++;
							etest.log(Status.FAIL,"Mismatch Content: Expected---"+str+"---not Found in---"+element_res.findElement(By.className("actions3")).getText());
							TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						}
						Thread.sleep(500);
					}
					CommonUtil.scrollToTop(driver);
					Thread.sleep(500);
				}
				else
				{
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				}
			}
			id = ID[i];
			element = CommonUtil.elfinder(driver,"id","filtertype").findElement(By.id(id));

				if(CommonUtil.checkStringcontains(element.getText(),ADV_FILTER_OPTIONS[i],etest))
				{
					etest.log(Status.PASS,"Expected filter option ("+ADV_FILTER_OPTIONS[i]+") was found in filter menu");
					Thread.sleep(3000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_div"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id",id));
					Thread.sleep(1000);
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id",id+"_ddown"),5);
					etest.log(Status.INFO,"'"+ADV_FILTER_OPTIONS[i]+"' was clicked in the filter menu in search tab");
					List<WebElement> dropdown = driver.findElement(By.id(id+"_ddown")).findElements(By.tagName("li"));
					for(WebElement element_drop : dropdown)
					{
						if(!element_drop.getAttribute("val").contentEquals("-1") && !(element_drop.getAttribute("val").contentEquals("none")))
						{
							str = element_drop.getText();
							CommonUtil.clickWebElement(driver,element_drop);
							etest.log(Status.INFO,"The "+id+" '"+str+"' was clicked from the drop down list in filter menu in search tab");
							break;
						}
					}
					CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"classname","flapply"),5);
					CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"classname","flapply"));
					Thread.sleep(2000);
					etest.log(Status.INFO,"apply icon was clicked from the filter menu in search tab");
					try
					{
						CommonWait.waitTillDisplayed(driver,By.id("listview0"));
					}
					catch (Exception e) 
					{
						etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
						TakeScreenshot.screenshot(driver,etest);
						return false;
					}
					List<WebElement> results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
					int res_count = 0;
					for(int j = 0; j < results.size(); j++)
					{
						if(j==3)
						{
							CommonUtil.scrollToBottomOfPage(driver);
						}
						try
						{
							CommonWait.waitTillDisplayed(driver,By.id("listview0"));
						}
						catch (Exception e) 
						{
							etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
							TakeScreenshot.screenshot(driver,etest);
							return false;
						}
						try
						{
							results = CommonUtil.elfinder(driver,"id","listview0").findElements(By.className("tablegrp"));
						}
						catch(Exception e)
						{
							etest.log(Status.FAIL,"Expected search text was not found in the search results in search tab");
							TakeScreenshot.screenshot(driver,etest);
							return false;
						}
						WebElement element_res = results.get(j);
						if(res_count>5)break;
						res_count++;
						CommonUtil.waitTillWebElementDisplayed(driver,element_res,5);
						if(element_res.getText().contains(str))
						{
							etest.log(Status.PASS,"Expected "+id+" ("+str+") was found in the Search results ("+res_count+") in search tab");
						}
						else
						{
							failcount++;
							etest.log(Status.FAIL,"Mismatch Content: Expected---"+str+"---not Found in Search results---"+element_res.getText());
							TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
						}
						Thread.sleep(500);
					}
					CommonUtil.scrollToTop(driver);
				}
				else
				{
					failcount++;
					TakeScreenshot.screenshot(driver,etest,"Global Search","Failure","Operator window screenshot");
				}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Global Search","checkSearchAll","Exception",e);
			failcount++;
		}
		finally
		{
			return returnResult(failcount);
		}
	}

	public static void refreshPage(WebDriver driver)throws Exception
	{
		Tab.clickVisitorsOnline(driver);
		CommonUtil.refreshPage(driver);
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","searchinput"),5);
		Thread.sleep(1000);
	}

	public static boolean returnResult(int failcount)
	{
		if(failcount > 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
