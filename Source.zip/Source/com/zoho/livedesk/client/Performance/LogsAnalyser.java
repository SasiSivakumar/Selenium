//$Id$
package com.zoho.livedesk.client.Performance;
import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.utils.URIBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.zoho.livedesk.util.ChatUtil;

import com.zoho.livedesk.client.SalesIQRestAPI.SalesIQRestAPICommonFunctions;
import com.zoho.livedesk.server.ConfManager;
import java.util.TimerTask;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.LocalStorage.*;

public class LogsAnalyser extends TimerTask
{
	public static final int ALLOWED_TIME_LIMIT_BETWEEN_EACH_EXECUTION_IN_MINS=60;

	public static final String SEPERATOR="<>";

	//to create new one --> https://accounts.zoho.com/apiauthtoken/create?SCOPE=ZohoLogs/logsearchapi
	public static final String AUTH_VALUE="093f5c4ba1c05d5793f224192b462b33";
	
	public static final String
	AUTHTOKEN="authtoken",
	SERVICE="service",
	APPID="appid",
	TOTAL="total",
	FROM_DATE="fromDate",
	TO_DATE="toDate",
	FROM_DATE_TIME="fromDateTime",
	TO_DATE_TIME="toDateTime",
	ORDER="order",
	RANGE="range",
	RESPONSE_TIME_API="https://logs.zoho.com/api/stats/responsetimestats/day/",
	SEARCH_API="https://logs.zoho.com/search",
	QUERY="query",
	LAST_EXECUTED_KEY="logs_analyser_last_executed_time"
	;
	
    public void run()
    {
    	try
    	{
    		if(isCalledSimultaneously())
    		{
	    		return;
    		}

    		setLastExecutedTimeAsCurrentTime();

	    	postReportToCliq();
    	}
    	catch(Exception e)
    	{
            CommonUtil.printStackTrace(e);
            com.zoho.livedesk.util.BuildUpdateScheduler.SchedulerMain.postToCliq("Could not run Performance Logs Analyser due to exception");
    	}
    }

	public static void postReportToCliq() throws Exception
	{		
		String[] actions= {"Add Visitor","Pickup","Transfer","Accept","Send Message","End Chat - Operator","End Chat - Visitor","Rejoin"};
		String[] url_names= {"/addvist","/pickupsupport","/transferchat","/acctranschat","/sendmessage","/endsupportsession","/leavesupport","/rejoinvisitor"};
		
		ArrayList<String> response_values=new ArrayList<String>();
		
		for(int i=0;i<url_names.length;i++)
		{
			String url_name=url_names[i];
			String action=actions[i];
			
			String this_weekday_data=getSearchAPIResponse(url_name,true);
			String last_weekday_data=getSearchAPIResponse(url_name,false);
			
			response_values.add(getTableValue(action,url_name,this_weekday_data,last_weekday_data));
		}	

        ChatUtil.sendChatMessage(getCliqMessageObject(response_values).toString(),ConfManager.getRealValue("performance_channel"));
	}
	
	public static String getSearchAPIResponse(String url_name,boolean isThisWeek) throws Exception
	{
		Hashtable<String,String> params=getSearchAPIParameters();
		params.put(FROM_DATE_TIME,getDateTime(isThisWeek,true));
		params.put(TO_DATE_TIME,getDateTime(isThisWeek,false));
		params.put(QUERY, getSearchQueryByAPIURL(url_name));	
		
		return getAPI(SEARCH_API,params);
	}
	
	public static String getSearchQueryByAPIURL(String url_name)
	{		
		return "logtype=\"access\" and request_uri CONTAINS \""+url_name+"\" MAX(time_taken) MIN(time_taken) AVG(time_taken)";			
	}

	public static Hashtable<String,String> getSearchAPIParameters()
	{
		Hashtable<String,String> params=getParamsHashtable();
		params.put(ORDER, "desc");
		params.put(RANGE,"1-100");
		return params;
	}

	public static Hashtable<String,String> getCountAPIParameters()
	{
		Hashtable<String,String> params=getParamsHashtable();
		params.put(TOTAL, "true");
		return params;
	}

	public static Hashtable<String,String> getParamsHashtable()
	{
		Hashtable<String,String> params=new Hashtable<String,String>();
		params.put(AUTHTOKEN, AUTH_VALUE);
		params.put(SERVICE,"SalesIQ");
		params.put(APPID,"36064526");
		return params;
	}

	public static String getAPI(String url_string,Hashtable<String,String> query_params) throws Exception
	{
		URIBuilder url_builder = new URIBuilder(url_string);
		
        Set<String> keys = query_params.keySet();
        for(String key: keys)
        {
        		if(key.equals(FROM_DATE)==false && key.equals(TO_DATE)==false) 
        		{
            		url_builder.addParameter(key, query_params.get(key));	        			
        		}
        }
        
        url_string=url_builder.build().toString();
        
        if(url_string.contains("responsetimestats"))
        {
        		url_string=url_string+"&date="+query_params.get(FROM_DATE);
        		url_string=url_string+"&date="+query_params.get(TO_DATE);
        }
        		
        URL url =  new URL(url_string);
        HttpURLConnection httpcon = (HttpURLConnection)(url.openConnection());
        httpcon.setRequestMethod("GET");
        httpcon.setDoOutput(true);
        httpcon.setRequestProperty("Accept", "application/json");
        InputStream inn =  httpcon.getInputStream();
        String encoding = httpcon.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString( inn , encoding);
        
        return body;
	}
	
	public static JSONObject getCliqMessageObject(ArrayList<String> table_values) throws JSONException,Exception
	{
		JSONObject json=new JSONObject();
		JSONObject bot=new JSONObject();
		JSONArray slides=new JSONArray();
		JSONObject slide=new JSONObject();
		
		json.put("text", "*SalesIQ Daily Performance Report - "+getReportDate(true)+"*");
		
		bot.put("name", "Performance Analyser");
		bot.put("image", "https://www.zoho.com/salesiq/images/icon-salesiq.png");
		json.put("bot",bot);
				
		slides.put( getReportTableSlideCliqObject("Note : Change% is obtained by comparing with same day in previous week",table_values) );
		
		json.put("slides", slides);
				
		return json;
	}
	
	public static String getReportDate(boolean isLatestDate)
	{
		Calendar cal = Calendar.getInstance();

		if(isLatestDate)
		{
			cal.add(Calendar.DATE, -1);
		}
		else
		{
			cal.add(Calendar.DATE, -8);			
		}
				
		String format_str="dd/MM/yyyy";
		
		DateFormat dateFormat = new SimpleDateFormat(format_str);
		Date date = cal.getTime();
				
		return dateFormat.format(date);
	}
	
	public static String getDateTime(boolean isLatestDate,boolean isDayBegin)
	{
		Calendar cal = Calendar.getInstance();

		if(isLatestDate)
		{
			cal.add(Calendar.DATE, -1);
		}
		else
		{
			cal.add(Calendar.DATE, -8);			
		}
				
		String format_str=isDayBegin?"dd/MM/yyyy 00:00":"dd/MM/yyyy 23:59";
		
		DateFormat dateFormat = new SimpleDateFormat(format_str);
		Date date = cal.getTime();
				
		return dateFormat.format(date);
	}
	
	public static String getTableValue(String action,String url_name,String current_weekday_search_data,String last_weekday_search_data) throws Exception
	{
		String count=SalesIQRestAPICommonFunctions.jPath(current_weekday_search_data.toString(), "numFound");
		Long count_long=Long.parseLong(count);
		count=withSuffix(count_long);
		
		String this_week_avg_str=SalesIQRestAPICommonFunctions.jPath(current_weekday_search_data.toString(), "tableValues[0]/avg(time_taken)");
		double this_week_avg=Double.parseDouble(this_week_avg_str);

		String last_week_avg_str=SalesIQRestAPICommonFunctions.jPath(last_weekday_search_data.toString(), "tableValues[0]/avg(time_taken)");
		double last_week_avg=Double.parseDouble(last_week_avg_str);

		String this_week_max_str=SalesIQRestAPICommonFunctions.jPath(current_weekday_search_data.toString(), "tableValues[0]/max(time_taken)");
		double this_week_max=Double.parseDouble(this_week_max_str);

		String last_week_max_str=SalesIQRestAPICommonFunctions.jPath(last_weekday_search_data.toString(), "tableValues[0]/max(time_taken)");
		double last_week_max=Double.parseDouble(last_week_max_str);

		String this_week_min_str=SalesIQRestAPICommonFunctions.jPath(current_weekday_search_data.toString(), "tableValues[0]/min(time_taken)");
		double this_week_min=Double.parseDouble(this_week_min_str);

		String last_week_min_str=SalesIQRestAPICommonFunctions.jPath(last_weekday_search_data.toString(), "tableValues[0]/min(time_taken)");
		double last_week_min=Double.parseDouble(last_week_min_str);
		
		double avg_change_perc=((this_week_avg/last_week_avg)-1)*100;
		double max_change_perc=((this_week_max/last_week_max)-1)*100;
		double min_change_perc=((this_week_min/last_week_min)-1)*100;
		
		String avg_sign=getSign(avg_change_perc);
		String max_sign=getSign(max_change_perc);
		String min_sign=getSign(min_change_perc);
		
		avg_change_perc=(avg_change_perc<0?(avg_change_perc*-1):(avg_change_perc));
		max_change_perc=(max_change_perc<0?(max_change_perc*-1):(max_change_perc));
		min_change_perc=(min_change_perc<0?(min_change_perc*-1):(min_change_perc));
						
		String roundoff_avg_perc=roundOff(avg_change_perc);
		String roundoff_max_perc=roundOff(max_change_perc);		
		String roundoff_min_perc=roundOff(min_change_perc);
		
		this_week_avg_str=roundOff(this_week_avg);
		last_week_avg_str=roundOff(last_week_avg);

		this_week_max_str=roundOff(this_week_max);
		last_week_max_str=roundOff(last_week_max);

		this_week_min_str=roundOff(this_week_min);
		last_week_min_str=roundOff(last_week_min);

		String avg_str=addUnitsToMillis(this_week_avg_str)+getPercentage(avg_sign,roundoff_avg_perc,last_week_avg);
		String max_str=addUnitsToMillis(this_week_max_str)+getPercentage(max_sign,roundoff_max_perc,last_week_max);
		String min_str=addUnitsToMillis(this_week_min_str)+getPercentage(min_sign,roundoff_min_perc,last_week_min);
		
		String table_value=action+SEPERATOR+url_name+SEPERATOR+count+SEPERATOR+avg_str+SEPERATOR+max_str+SEPERATOR+min_str;
				
		return table_value;
	}

	public static String getPercentage(String sign,String percentage,double denominator_used_in_percentage)
	{
		if(denominator_used_in_percentage==0)
		{
			return " ("+sign+" from 0)";
		}

		return " ("+sign+" "+percentage+"%)";
	}
	
	public static String getSign(double num)
	{
		if(num==0)
		{
			return "";
		}
		else if(num>0)
		{
			return "\u2191";
		}
		else
		{
			return "\u2193";
		}
	}
	
	public static String addUnitsToMillis(String millis_str)
	{		
		double millis=Double.parseDouble(millis_str);
		
		if(millis<1000)
		{
			return millis_str+" ms";
		}
		else if(millis<60000)
		{
			double secs=millis/1000;
			return roundOff(secs)+" secs";
		}
		else
		{
			double mins= millis/60000;
			return roundOff(mins)+" mins";
		}		
	}

	public static String roundOff(double num)
	{			
		return ""+Math.round(num);
	}

	public static String trimNum(String num)
	{					
		String trimmed_num = num.contains(".") ? num.replaceAll("0*$","").replaceAll("\\.$","") : num;
		
		if(trimmed_num.trim().equals(""))
		{
			return num;
		}
		
		return  trimmed_num;
	}
	
	public static JSONObject getReportTableSlideCliqObject(String title,ArrayList<String> table_values) throws Exception
	{
		JSONObject table=new JSONObject();
		JSONObject data=new JSONObject();
		JSONArray headers=new JSONArray();
		JSONArray rows=new JSONArray();
		
		table.put("type", "table");
		table.put("title", title);

		headers.put("Action");
		headers.put("URL");
		headers.put("Count");
		headers.put("Avg");
		headers.put("Max");		
		headers.put("Min");	
		data.put("headers", headers);
		
		for(String table_value : table_values)
		{
			String action=table_value.split(SEPERATOR)[0];
			String url=table_value.split(SEPERATOR)[1];
			String count=table_value.split(SEPERATOR)[2];
			String avg_resp_time=table_value.split(SEPERATOR)[3];
			String max_resp_time=table_value.split(SEPERATOR)[4];
			String min_resp_time=table_value.split(SEPERATOR)[5];
			
			JSONObject row=new JSONObject();
			
			row.put("Action",action);
			row.put("URL",url);
			row.put("Count",count);
			row.put("Avg",avg_resp_time);
			row.put("Max",max_resp_time);
			row.put("Min",min_resp_time);
			
			rows.put(row);
		}
		
		data.put("rows",rows);
		table.put("data", data);
		
		return table;
	}
	
	public static String withSuffix(long count) 
	{
	    if(count<1000) 
    	{
    		return "" + count;
    	}

	    int exp = (int) (Math.log(count) / Math.log(1000));
	    
	    return String.format
	    (
			"%.1f %c",
			count / Math.pow(1000, exp),
			"KMGTPE".charAt(exp-1)
        );
	} 

	public static boolean isTimeout(Long executed_time)
	{
		return com.zoho.livedesk.util.common.CommonUtil.isTimeout(executed_time,ALLOWED_TIME_LIMIT_BETWEEN_EACH_EXECUTION_IN_MINS);
	}

	public static Long getLastExecutedTime()
	{
        if(LocalStorageUtil.isStored(LAST_EXECUTED_KEY))
        {
            return Long.parseLong(LocalStorageUtil.get(LAST_EXECUTED_KEY));
        }
        else
        {
        	return null;
        }
	}

	public static void setLastExecutedTimeAsCurrentTime()
	{
		Long current_time=new Long(System.currentTimeMillis());
        LocalStorageUtil.set(LAST_EXECUTED_KEY, ""+current_time);		
	}

	public static boolean isCalledSimultaneously()
	{
		if(getLastExecutedTime()==null)
		{
			return false;
		}
		else if(isTimeout(getLastExecutedTime()))
		{
			return false;
		}
		else
		{
			return true;
		}
	}

}