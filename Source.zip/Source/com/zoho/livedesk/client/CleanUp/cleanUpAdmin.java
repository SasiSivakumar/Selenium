//$Id$
package com.zoho.livedesk.client.CleanUp;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.zoho.livedesk.client.AgentsSettings;
import com.zoho.livedesk.client.CompanyInfo;
import com.zoho.livedesk.client.PortalSettings;
import com.zoho.livedesk.client.BlockedIP;
import com.zoho.livedesk.client.WebEmbedSettings;
import com.zoho.livedesk.client.CannedMessages;
import com.zoho.livedesk.client.Department;

import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.google.common.base.Function;

public class cleanUpAdmin
{
    public static String list = "Nothing";
    
    public static String CleanUp() throws Exception
    {
        list = "Nothing";
        
        ClearPortals cp = new ClearPortals();
        WebDriver driver = cp.setUp();
    
        try
        {
            cp.login(driver,"ldautomation","test1234");
            
            failures(userSettings(driver),"Operators Settings");
            failures(companyInfo(driver),"Company Settings");
            failures(portalSettings(driver),"Portal Settings");
            failures(blockedIPSettings(driver),"BlockedIP Settings");
//            failures(webEmbedSettings(driver),"WebEmbed Settings");
            failures(cannedMessages(driver),"Canned Messages");
            
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing admin module:");
            e.printStackTrace();
        }
        cp.logout(driver);
        return list;
            
    }
    
    public static void failures(boolean result,String s)
    {
        if(!result)
        {
            if(list.equals("Nothing"))
            {
                list = s;
            }
            else
            {
                list += ", "+s;
            }
        }
    }
    
    public static boolean userSettings(WebDriver driver)
    {
        try
        {
            if(AgentsSettings.deleteAgent(driver,"rajkumar.natarajan+106@zohocorp.com")&&AgentsSettings.deleteAgent(driver,"rajkumar.natarajan+105@zohocorp.com"))
            {
                AgentsSettings.deleteAgent(driver,"rajkumar.natarajan+107@zohocorp.com");
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in Operators settings page : "+e);
        }
        return false;
    }
    
    public static boolean departmentSettings(WebDriver driver)
    {
        try
        {
            if(Department.deleteDepartment(driver,"TestDepartment"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in Operators settings page : "+e);
        }
        return false;
    }
    
    public static boolean companyInfo(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
            
            if(CompanyInfo.editData(driver, "companyname", "Comp")&&
               CompanyInfo.editData(driver, "companywebsite", "http://z.z.z")&&
               CompanyInfo.editData(driver, "companyaddress", "")&&
               CompanyInfo.editData(driver, "companyemail", "")&&
               CompanyInfo.editData(driver, "companytelephone", "")&&
               CompanyInfo.editData(driver, "companyfax", "")&&
               CompanyInfo.editData(driver, "companydesc", ""))
            {
                CompanyInfo.editDDData(driver, "CC1", "companylanguage_div", "companylanguage_ddown", "English");
                CompanyInfo.editDDData(driver, "CC2", "companytimezone_div", "companytimezone_ddown", "( GMT 5:30 ) India Standard Time(IST)");
                
                if((boolean)CompanyInfo.result.get("CC1")&&(boolean)CompanyInfo.result.get("CC2"))
                {
                    return true;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in company settings page : "+e);
        }
        return false;
    }
    
    public static boolean portalSettings(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            //WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            //Portal settings info view
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_portal"))));
            
            //Thread.sleep(2000);
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_portal"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            
            PortalSettings.editDDConfig(driver,"ClearSetAgentIdleTime","inactiveperioddrpdwn_div","inactiveperioddrpdwn_ddown","Never");
            PortalSettings.editDDConfig(driver,"ClearVisitorChatTrans","vischattranscript_div","vischattranscript_ddown","Both");
            PortalSettings.editDDConfig(driver,"ClearGoogleTrans","googletranslateconfig_div","googletranslateconfig_ddown","Off");
            // PortalSettings.editDDConfig(driver,"ClearSignatureChat","signdrpdwncnt_div","signdrpdwncnt_ddown","None");
            
            if((boolean)PortalSettings.result.get("ClearSetAgentIdleTime")&&(boolean)PortalSettings.result.get("ClearVisitorChatTrans")&&(boolean)PortalSettings.result.get("ClearSignatureChat"))
            {
                PortalSettings.editFromMailAddr(driver,"CSP1","CSP2","frommailid","rajkumar.natarajan+automation111@zohocorp.com","Automation");
                
                if((boolean)PortalSettings.result.get("CSP1")&&(boolean)PortalSettings.result.get("CSP2"))
                {
                    return true;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing configuration in portal settings page : "+e);
        }
        return false;
    }
    
    public static boolean blockedIPSettings(WebDriver driver)
    {
        try
        {
            if(BlockedIP.deleteBlockedIP(driver,"15.1.1.2")&&
               BlockedIP.deleteBlockedIP(driver,"15.1.1.3")&&
               BlockedIP.deleteBlockedIP(driver,"15.1.1.4")&&
               BlockedIP.deleteBlockedIP(driver,"155.1.1.2")&&
               BlockedIP.deleteBlockedIP(driver,"155.1.1.3")&&
               BlockedIP.deleteBlockedIP(driver,"155.1.1.4"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in blockedIP settings page : "+e);
        }
        return false;
    }
    
    public static boolean webEmbedSettings(WebDriver driver)
    {
        try
        {
            if(WebEmbedSettings.deleteWebEmbed(driver,"SEmbedname1"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in Web Embed settings page : "+e);
        }
        return false;
    }
    
    public static boolean cannedMessages(WebDriver driver)
    {
        try
        {
            int delcm = 0;
            
            delcm = CannedMessages.deleteCannedCategory(driver, "Basic")?delcm+1:delcm;
            delcm = CannedMessages.deleteCannedCategory(driver, "Category @ 2")?delcm+1:delcm;
            delcm = CannedMessages.deleteCannedCategory(driver, "Test two")?delcm+1:delcm;
            delcm = CannedMessages.deleteCannedCategory(driver, "Super Category @ 1")?delcm+1:delcm;
            delcm = CannedMessages.deleteCannedCategory(driver, "Super edited Category @ 2")?delcm+1:delcm;
            delcm = CannedMessages.deleteCannedCategory(driver, "Asso Category @ 1")?delcm+1:delcm;
            delcm = CannedMessages.deleteCannedCategory(driver, "Asso edited Category @ 2")?delcm+1:delcm;
            
            if(delcm == 7)
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in canned message tab : "+e);
        }
        return false;
    }
    
    public static boolean intelligentTriggers(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            while(!ruleExistIT(driver))
            {
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
                
                WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("data_row"));
                
                mouseOver(driver,elmtch);
                
                elmtch.findElement(By.className("routeto")).findElement(By.className("delicon")).click();
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                driver.findElement(By.id("okbtn")).click();
            }
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in intelligent triggers tab : "+e);
        }
        return false;
    }
    
    public static boolean ruleExistIT(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(10,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            
            driver.findElement(By.id("addsuggtitle"));
            
            if(driver.findElement(By.id("addsuggtitle")).findElement(By.className("bstate-rht")).findElement(By.tagName("h3")).getText().equals(ResourceManager.getRealValue("intelligenttriggers_notriggers")))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if data is cleared in IT : "+e);
        }
        return false;
    }
    
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
    
    public static boolean visitorRouting(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            while(!ruleExistVR(driver))
            {
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
                
                WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("data_row"));
                
                mouseOver(driver,elmtch);
                
                elmtch.findElement(By.className("routeto")).findElement(By.className("delicon")).click();
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                driver.findElement(By.id("okbtn")).click();
            }
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in visitor routing tab : "+e);
        }
        return false;
    }
    
    public static boolean ruleExistVR(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(10,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            
            driver.findElement(By.id("addsuggtitle"));
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if data is cleared in VR : "+e);
        }
        return false;
    }
    
    public static boolean leadScoring(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            
            boolean ruleCount = true;
            
            while(ruleCount)
            {
                try
                {
                    List<WebElement> elmtlslist = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst"));
                    
                    if(elmtlslist.size() <= 1)
                    {
                        ruleCount = false;
                        break;
                    }
                    else
                    {
                        String ruleid = elmtlslist.get(1).getAttribute("id");
                        
                        System.out.println("RULE ID ------------------------------------"+ruleid);
                        
                        driver.findElement(By.id(ruleid)).findElements(By.tagName("div")).get(2).findElement(By.tagName("span")).click();
                        
                        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                        driver.findElement(By.id("okbtn")).click();
                    }
                }
                catch(IndexOutOfBoundsException e)
                {
                    System.out.println("One or more condition check has failed during this execution");
                }
            }
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in lead scoring tab : "+e);
        }
        return false;
    }
}
