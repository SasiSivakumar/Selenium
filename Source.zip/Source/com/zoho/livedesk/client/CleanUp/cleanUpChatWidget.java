//$Id$
package com.zoho.livedesk.client.CleanUp;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;

import com.zoho.livedesk.client.WebEmbedSettings;
import com.zoho.livedesk.client.CompanyInfo;
import com.zoho.livedesk.client.Department;
import com.zoho.livedesk.client.CannedMessages;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class cleanUpChatWidget
{
    public static String list = "Nothing";
    
    public static String CleanUp() throws Exception
    {
        list = "Nothing";
        
        ClearPortals cp = new ClearPortals();
        WebDriver driver = cp.setUp();
        
        try
        {
            cp.login(driver,"ldautomation2","test1234");
            
            failures(webEmbedSettings(driver),"WebEmbed RealTime Check");
            failures(companyInfo(driver),"WebEmbed RealTime Check - Business Hour");
            
            cp.logout(driver);
            
            driver = cp.setUp();
            cp.login(driver,"renganathan.k+ldautomation5@zohocorp.com","test1234");
            driver.get(Util.siteNameout()+"/chatops");
            
//            failures(WebEmbedSettings.deleteWebEmbed(driver,"Embedname1"),"WebEmbed Settings");
            failures(deleteCannedCategory(driver),"Chat Operations - Delete Canned Category");
            failures(departmentSettings(driver),"Chat Operations - Delete Department");
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing admin module:");
            e.printStackTrace();
        }
        cp.logout(driver);
        return list;
    }
    
    public static void failures(boolean result,String s)
    {
        if(!result)
        {
            if(list.equals("Nothing"))
            {
                list = s;
            }
            else
            {
                list += ", "+s;
            }
        }
    }
    
    public static boolean deleteCannedCategory(WebDriver driver)
    {
        try
        {
            if(CannedMessages.deleteCannedCategory(driver, "CheckCategory"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data : "+e);
        }
        return false;
    }
    
    public static boolean departmentSettings(WebDriver driver)
    {
        try
        {
            if(Department.deleteDepartment(driver,"TestDepartment"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data : "+e);
        }
        return false;
    }
    
    public static boolean webEmbedSettings(WebDriver driver)
    {
        try
        {
            if(WebEmbedSettings.editWaitingTime(driver, "embed2","60 seconds"))
            {
                int i = 0;
                
                i = changeDept(driver,"testfloat")?i+1:i;
                i = changeWMessage(driver,"testfloat")?i+1:i;
                i = changeMandate(driver,"testfloat")?i+1:i;
                i = disableShowUsers(driver,"testfloat")?i+1:i;
                i = configureMsg(driver,"testfloat")?i+1:i;
                
                if(i == 5)
                {
                    return true;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing settings in web embed settings : "+e);
        }
        return false;
    }
    
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
    
    public static boolean configureMsg(WebDriver driver,String wname)
    {
        try
        {
            driver = chooseEmbed(driver,ConfManager.getWEembed());
            
            Thread.sleep(2000);
            
            WebElement elwelcome = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElements(By.className("embdlstmn")).get(2).findElement(By.id("cegreet"));
            
            mouseOver(driver,elwelcome);
            
            Thread.sleep(1000);
            
            elwelcome.findElement(By.id("editegreet")).click();
            
            Thread.sleep(1000);
            
            elwelcome = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElements(By.className("embdlstmn")).get(2);
            
            elwelcome.findElement(By.id("segreet")).findElement(By.id("greet")).click();
            elwelcome.findElement(By.id("segreet")).findElement(By.id("greet")).clear();
            elwelcome.findElement(By.id("segreet")).findElement(By.id("greet")).sendKeys(" ");
            
            elwelcome.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            driver.findElement(By.id("cnfmsglink")).findElement(By.tagName("a")).click();
            
            Thread.sleep(2000);
            
            WebElement lftmsg = driver.findElement(By.id("messageconfg")).findElement(By.className("cnfmsghdr")).findElement(By.className("embdtlmn_lft"));
            WebElement rhtmsg = driver.findElement(By.id("messageconfg")).findElement(By.className("cnfmsghdr")).findElement(By.className("embdtlmn_rht"));
            
            WebElement waitmsg = lftmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cewaitingmsg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(waitmsg.getLocation().y-200)+")");
            
            mouseOver(driver,waitmsg);
            
            Thread.sleep(1000);
            
            waitmsg.findElement(By.id("editewaitingmsg")).click();
            
            Thread.sleep(1000);
            
            waitmsg = lftmsg.findElements(By.className("embdlstmn")).get(0);
            
            waitmsg.findElement(By.id("sewaitingmsg")).findElement(By.id("waitingmsg")).click();
            waitmsg.findElement(By.id("sewaitingmsg")).findElement(By.id("waitingmsg")).clear();
            waitmsg.findElement(By.id("sewaitingmsg")).findElement(By.id("waitingmsg")).sendKeys(" ");
            
            waitmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            WebElement offlinemsg = lftmsg.findElements(By.className("embdlstmn")).get(1).findElement(By.id("ceofflinemsg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(offlinemsg.getLocation().y-200)+")");
            
            mouseOver(driver,offlinemsg);
            
            Thread.sleep(1000);
            
            offlinemsg.findElement(By.id("editeofflinemsg")).click();
            
            Thread.sleep(1000);
            
            offlinemsg = lftmsg.findElements(By.className("embdlstmn")).get(1);
            
            offlinemsg.findElement(By.id("seofflinemsg")).findElement(By.id("offlinemsg")).click();
            offlinemsg.findElement(By.id("seofflinemsg")).findElement(By.id("offlinemsg")).clear();
            offlinemsg.findElement(By.id("seofflinemsg")).findElement(By.id("offlinemsg")).sendKeys(" ");
            
            offlinemsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            WebElement busymsg = lftmsg.findElements(By.className("embdlstmn")).get(2).findElement(By.id("cebusymsg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(busymsg.getLocation().y-200)+")");
            
            mouseOver(driver,busymsg);
            
            Thread.sleep(1000);
            
            busymsg.findElement(By.id("editebusymsg")).click();
            
            Thread.sleep(1000);
            
            busymsg = lftmsg.findElements(By.className("embdlstmn")).get(2);
            
            busymsg.findElement(By.id("sebusymsg")).findElement(By.id("busymsg")).click();
            busymsg.findElement(By.id("sebusymsg")).findElement(By.id("busymsg")).clear();
            busymsg.findElement(By.id("sebusymsg")).findElement(By.id("busymsg")).sendKeys(" ");
            
            busymsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            WebElement thanksmsg = rhtmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cethanksmsg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(thanksmsg.getLocation().y-200)+")");
            
            mouseOver(driver,thanksmsg);
            
            Thread.sleep(1000);
            
            thanksmsg.findElement(By.id("editethanksmsg")).click();
            
            Thread.sleep(1000);
            
            thanksmsg = rhtmsg.findElements(By.className("embdlstmn")).get(0);
            
            thanksmsg.findElement(By.id("sethanksmsg")).findElement(By.id("thanksmsg")).click();
            thanksmsg.findElement(By.id("sethanksmsg")).findElement(By.id("thanksmsg")).clear();
            thanksmsg.findElement(By.id("sethanksmsg")).findElement(By.id("thanksmsg")).sendKeys(" ");
            
            thanksmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            WebElement offlinerespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(1).findElement(By.id("ceofflinerespmsg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(offlinerespmsg.getLocation().y-200)+")");
            
            mouseOver(driver,offlinerespmsg);
            
            Thread.sleep(1000);
            
            offlinerespmsg.findElement(By.id("editeofflinerespmsg")).click();
            
            Thread.sleep(1000);
            
            offlinerespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(1);
            
            offlinerespmsg.findElement(By.id("seofflinerespmsg")).findElement(By.id("offlinerespmsg")).click();
            offlinerespmsg.findElement(By.id("seofflinerespmsg")).findElement(By.id("offlinerespmsg")).clear();
            offlinerespmsg.findElement(By.id("seofflinerespmsg")).findElement(By.id("offlinerespmsg")).sendKeys(" ");
            
            offlinerespmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            WebElement busyrespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(2).findElement(By.id("cebusyrespmsg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(busyrespmsg.getLocation().y-200)+")");
            
            mouseOver(driver,busyrespmsg);
            
            Thread.sleep(1000);
            
            busyrespmsg.findElement(By.id("editebusyrespmsg")).click();
            
            Thread.sleep(1000);
            
            busyrespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(2);
            
            busyrespmsg.findElement(By.id("sebusyrespmsg")).findElement(By.id("busyrespmsg")).click();
            busyrespmsg.findElement(By.id("sebusyrespmsg")).findElement(By.id("busyrespmsg")).clear();
            busyrespmsg.findElement(By.id("sebusyrespmsg")).findElement(By.id("busyrespmsg")).sendKeys(" ");
            
            busyrespmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing configure messages in web embed settings : "+e);
        }
        return false;
    }
    
    public static boolean changeDept(WebDriver driver,String wname)
    {
        try
        {
            driver = chooseEmbed(driver,ConfManager.getWEembed());
            
            Thread.sleep(2000);
            
            WebElement elmthid = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElement(By.className("embdlstmn")).findElement(By.id("cedept"));
            
            mouseOver(driver,elmthid);
            
            Thread.sleep(1000);
            
            elmthid.findElement(By.id("editedept")).click();
            
            new Select(driver.findElement(By.xpath(".//select[@id='departmentselect'][@class='embedit-select']"))).selectByVisibleText("Allow visitor to select department");
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();
            
            Thread.sleep(2000);
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing department settings in web embed settings : "+e);
        }
        return false;
    }
    
    public static WebDriver chooseEmbed(WebDriver driver,String emname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Tab.navToEmbedTab(driver);
            
            List<WebElement> elists = driver.findElement(By.id("embedlist")).findElements(By.className("list-row"));
            
            Thread.sleep(1000);
            
            for(WebElement elist:elists)
            {
                Thread.sleep(500);
                
                if((elist.findElement(By.className("list_cell")).getText()).equals(ConfManager.getPortalName()))
                {
                    elist.findElement(By.className("list_cell")).click();
                    
                    Thread.sleep(1000);
                    
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embeddetail")));
                    
                    break;
                }
            }
            
            Thread.sleep(1000);
            
            return driver;
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while choosing embed in real time float widget check : " + e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while choosing embed in real time float widget check : " + e);
        }
        return driver;
    }
    
    public static boolean changeWMessage(WebDriver driver,String wname)
    {
        try
        {
            driver = chooseEmbed(driver,ConfManager.getWEembed());
            
            Thread.sleep(2000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");
            
            Thread.sleep(500);
            
            driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance")).click();
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content")).click();
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content")).clear();
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content")).sendKeys(" ");
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("off1content")).click();
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("off1content")).clear();
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("off1content")).sendKeys(" ");
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();
            
            Thread.sleep(2000);
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing appearance message in web embed settings : " + e);
        }
        return false;
    }
    
    public static boolean changeMandate(WebDriver driver,String wname)
    {
        try
        {
            driver = chooseEmbed(driver,ConfManager.getWEembed());
            
            Thread.sleep(2000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance")).click();
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();
            
            Thread.sleep(1000);
            
            WebElement elmt =  driver.findElement(By.id("embdsptwndonly")).findElement(By.id("addem2")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("vcnfg"));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("ishowname"))).getLocation().y+"-400)");
            
            if((elmt.findElement(By.id("ishowname")).getAttribute("checked")) != null)
            {
                elmt.findElement(By.id("ishowname")).click();
                Thread.sleep(300);
            }
            elmt.findElement(By.id("ishowname")).click();
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("ishowemail"))).getLocation().y+"-400)");
            
            if((elmt.findElement(By.id("ishowemail")).getAttribute("checked")) != null)
            {
                elmt.findElement(By.id("ishowemail")).click();
                Thread.sleep(300);
            }
            
            elmt.findElement(By.id("ishowemail")).click();
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("ishowphone"))).getLocation().y+"-400)");
            
            if((elmt.findElement(By.id("ishowphone")).getAttribute("checked")) != null)
            {
                elmt.findElement(By.id("ishowphone")).click();
                Thread.sleep(300);
            }
            
            elmt.findElement(By.id("ishowphone")).click();
            
            Thread.sleep(1000);
            
            //driver.findElement(By.id("addem2")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();
            
            Thread.sleep(2000);
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while changing mandatory fields in web embed settings : " + e);
        }
        return false;
    }
    
    public static boolean companyInfo(WebDriver driver)
    {
        try
        {
            if(CompanyInfo.disableBusinessHour(driver))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while disabling business hours in web embed settings : " + e);
        }
        return false;
    }
    
    public static boolean disableShowUsers(WebDriver driver,String wname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            driver = chooseEmbed(driver,ConfManager.getWEembed());
            
            Thread.sleep(2000);
            
            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");
            
            //driver.findElement(By.id("Embedbtnprt")).findElement(By.linkText("Change the appearance")).click();
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem3"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("caddem3")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem3")));
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("personalsupport"))).getLocation().y+"-400)");
            
            WebElement suppelmt = driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("ipersonalsupport"));
            
            if((suppelmt.getAttribute("class")).contains("embchk-yes"))
            {
                suppelmt.click();
            }
            
            //suppelmt.click();
            
            Thread.sleep(1000);
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");
            
            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();
            
            Thread.sleep(2000);
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while disabling show Operators in web embed settings : " + e);
        }
        return false;
    }
    
    
}
