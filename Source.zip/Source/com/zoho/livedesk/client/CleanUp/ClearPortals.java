//$Id$
package com.zoho.livedesk.client.CleanUp;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Set;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.net.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.OutputStream;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import com.zoho.qa.server.servlet.WebdriverApi;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.qa.server.AppendAndExportData;

import com.zoho.livedesk.util.MailUtil;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ResourceManager;

import com.google.common.base.Function;

public class ClearPortals
{
    public static String list = "Nothing";
    private static int ncount = 0;
    //private WebDriver driver;
    public Hashtable result = new Hashtable();
    public Hashtable servicedown = new Hashtable();
    public Hashtable res = new Hashtable();
    public static String buildnamed = "";
    public static String sitenamed = "";
    public static String setUpTrack = "";
    long starttime;
    long endtime = 0L;
    String browser = "";
    Hashtable report;
    String url = "";
    
    public void portalClear()
    {
        list = "Nothing";
        
        try
        {
            ExecutorService executor = Executors.newFixedThreadPool(200);
            
            for (int i = 0; i <= 5; i++)
            {
                Runnable worker = new MyRunnable(i);
                executor.execute(worker);
            }
            executor.shutdown();
            
            while (!executor.isTerminated()) {}
            
            if(list.equals("Nothing"))
            {
                 // MailUtil.sendMailReport(ConfManager.getAdminAddr());
            }
            else
            {
               // MailUtil.sendMailReport(ConfManager.getAdminAddr(),list);
            }
            
            System.out.println("Clear Portals:"+list);
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing portal configurations : "+e);
            e.printStackTrace();
        }
    }
    
    public WebDriver setUp() throws Exception
    {
        return Functions.setUp();
    }
    
    public boolean login(WebDriver driver,String loginname,String pswd) throws Exception
    {
        try
        {
            String loginsite = Util.siteNameout();
            
            String accountsURL = "";
            
            if(loginsite.contains("salesiq.localzoho.com"))
            {
                accountsURL = "https://accounts.localzoho.com/";
            }
            else
            {
                 accountsURL = "https://accounts.zoho.com/";
            }
            
            driver.get(accountsURL);
            Thread.sleep(1000);
            
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            
            if(driver.findElements(By.tagName("iframe")).size() != 0)
            {
                driver.switchTo().frame(0);
            }
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            
            driver.findElement(By.id("lid")).clear();
            driver.findElement(By.id("lid")).sendKeys(loginname);
            
            driver.findElement(By.name("pwd")).clear();
            driver.findElement(By.name("pwd")).sendKeys(pswd);
            
            driver.findElement(By.id("login")).findElement(By.className("redBtn")).click();
            
            driver.switchTo().defaultContent();
            
            for(int ii = 1; ii <= 600;ii++)
            {
                try
                {
                    driver.findElement(By.id("zohoiam"));
                }
                catch(Exception e)
                {
                    break;
                }
                
                Thread.sleep(100);
            }
            
            Thread.sleep(5000);
            
            driver.get(loginsite);
            
            WebDriverWait wait = new WebDriverWait(driver, 40);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("maincontainer")));
            Thread.sleep(5000);
            if(driver.findElement(By.id("maincontainer")) != null)
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
                Thread.sleep(1000);
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
                Thread.sleep(2000);
                
                try
                {
                    driver.findElement(By.id("dnenable")).findElement(By.className("sqico-close")).click();
                    Thread.sleep(2000);
                }
                catch(Exception e)
                {
                    System.out.println("Exception while closing the top banner : "+e);
                }
                try
                {
                    FluentWait wait1 = CommonUtil.waitreturner(driver, 10, 500);
                    
                    wait1.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("anncmnt"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                    
                    WebElement e = driver.findElement(By.id("anncmnt")).findElement(By.id("bannerclose"));
                    wait1.until(ExpectedConditions.visibilityOf(e));
                    Thread.sleep(1500);
                    e.click();
                    
                    wait1.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if(!driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("anncmnt"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                }
                catch(Exception e)
                {}
                
                return true;
            }
            else
            {
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Login during cleanup:Username:"+loginname);
            e.printStackTrace();
            return false;
        }
    }
    
    public void logout(WebDriver driver)
    {
        try
        {
               FluentWait wait = new FluentWait(driver);
                wait.withTimeout(30,TimeUnit.SECONDS);
                wait.pollingEvery(250,TimeUnit.MILLISECONDS);
                wait.ignoring(NoSuchElementException.class);
                
                String loginsite = Util.siteNameout();
                
                System.out.println(loginsite);
                String salesiqURL = "";
                
                if(loginsite.contains("salesiq.localzoho.com"))
                {
                    salesiqURL = "https://salesiq.localzoho.com/";
                }
                else if(loginsite.contains("presalesiq.zoho.com"))
                {
                    salesiqURL = "https://presalesiq.zoho.com/";
                }
                else
                {
                    salesiqURL = "https://salesiq.zoho.com/";
                }
                
                driver.get(salesiqURL+"logout.sas");
                
                Thread.sleep(3000);
                
                //wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
            
            driver.quit();
            
        }
        catch(Exception e)
        {
            System.out.println("Excpetion while logging out :");
            e.printStackTrace();
        }
    }
    
    public class MyRunnable implements Runnable {
        private int fnum;
        
        MyRunnable(int fnum) {
            this.fnum = fnum;
        }
        
//        failedmods = adminC?failedmods:failedmods+"Admin<div><span>&nbsp;</span></div>";
//        failedmods = superC?failedmods:failedmods+"Supervisor<div><span>&nbsp;</span></div>";
//        failedmods = automation_module?failedmods:failedmods+"Automation Modules<div><span>&nbsp;</span></div>";
//        failedmods = chatwidget_module?failedmods:failedmods+"Chat Widget Modules<div><span>&nbsp;</span></div>";
//        failedmods = integration_module?failedmods:failedmods+"Integrations Module<div><span>&nbsp;</span></div>";
//        failedmods = other_module?failedmods:failedmods+"Other Modules<div><span>&nbsp;</span></div>";

        @Override
        public void run() {
            
            String mod = "";
            
            int code = 200;
            try
            {
                if(fnum == 0)
                {
                    mod = "Admin modules-";
                    
                    String s = cleanUpAdmin.CleanUp();
                    if(!s.equals("Nothing"))
                    {
                        if(list.equals("Nothing"))
                        {
                            list = "Admin:"+s+"<div><span>&nbsp;</span></div>";
                        }
                        else
                        {
                            list += "Admin:"+s+"<div><span>&nbsp;</span></div>";
                        }
                    }
                }
                else if(fnum == 1)
                {
                    mod = "Supervisor modules-";
                    
                    String s = cleanUpSupervisor.CleanUp();
                    if(!s.equals("Nothing"))
                    {
                        if(list.equals("Nothing"))
                        {
                            list = "Supervisor:"+s+"<div><span>&nbsp;</span></div>";
                        }
                        else
                        {
                            list += "Supervisor:"+s+"<div><span>&nbsp;</span></div>";
                        }
                    }
                }
                else if(fnum == 2)
                {
                    mod = "Automation modules-";
                    
                    String s = cleanUpAutomations.CleanUp();
                    if(!s.equals("Nothing"))
                    {
                        if(list.equals("Nothing"))
                        {
                            list = "Automation Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                        else
                        {
                            list += "Automation Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                    }
                }
                else if(fnum == 3)
                {
                    mod = "Chat Widget modules-";
                    
                    String s = cleanUpChatWidget.CleanUp();
                    if(!s.equals("Nothing"))
                    {
                        if(list.equals("Nothing"))
                        {
                            list = "Chat Widget Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                        else
                        {
                            list += "Chat Widget Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                    }
                }
                else if(fnum == 4)
                {
                    mod = "Other modules-";
                    
                    String s = cleanUpOthers.CleanUp();
                    if(!s.equals("Nothing"))
                    {
                        if(list.equals("Nothing"))
                        {
                            list = "Other Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                        else
                        {
                            list += "Other Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                    }
                }
                else if(fnum == 5)
                {
                    mod = "Integration modules-";
                    
                    String s = "Nothing";
                    if(!s.equals("Nothing"))
                    {
                        if(list.equals("Nothing"))
                        {
                            list = "Integration Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                        else
                        {
                            list += "Integration Modules:"+s+"<div><span>&nbsp;</span></div>";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.out.println("Status: Exception  : "+e);
                e.printStackTrace();
                if(list.equals("Nothing"))
                {
                    list = mod+"Clean Up Not done properly:<div><span>&nbsp;</span></div>";
                }
                else
                {
                    list += mod+"Clean Up Not done properly:<div><span>&nbsp;</span></div>";
                }
            }
            System.out.println("Status: Success");
        }
    }
}
