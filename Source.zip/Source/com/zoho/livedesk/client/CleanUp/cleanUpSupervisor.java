//$Id$
package com.zoho.livedesk.client.CleanUp;

import org.openqa.selenium.WebDriver;

import com.zoho.livedesk.client.SChatMonitor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.google.common.base.Function;

public class cleanUpSupervisor
{
    public static String list = "Nothing";
    
    public static String CleanUp() throws Exception
    {
        list = "Nothing";
        
        ClearPortals cp = new ClearPortals();
        WebDriver driver = cp.setUp();
        
        try
        {
            cp.login(driver,"ldautomation_supervisor","test1234");
            
            failures(chatMonitorSettings(driver),"Chat Monitor");
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing supervisor module:");
            e.printStackTrace();
        }
        cp.logout(driver);
        return list;
    }
    
    public static void failures(boolean result,String s)
    {
        if(!result)
        {
            if(list.equals("Nothing"))
            {
                list = s;
            }
            else
            {
                list += ", "+s;
            }
        }
    }
    
    public static boolean chatMonitorSettings(WebDriver driver)
    {
        try
        {
            if(SChatMonitor.deleteChatMonitor(driver,"123.1.1.1"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing settings in chat monitor settings page : "+e);
        }
        return false;
    }
}
