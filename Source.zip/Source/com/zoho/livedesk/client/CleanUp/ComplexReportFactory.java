//$Id$
package com.zoho.livedesk.client.CleanUp;

public class ComplexReportFactory extends com.zoho.livedesk.client.ComplexReportFactory
{

}
