//$Id$
package com.zoho.livedesk.client.CleanUp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import java.util.List;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.interactions.Actions;

import com.zoho.livedesk.client.Tracking.CommonFunctions;
import com.zoho.livedesk.client.TrackingCustomize;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.google.common.base.Function;

public class cleanUpOthers
{
    public static String list = "Nothing";
    
    public static String CleanUp() throws Exception
    {
        list = "Nothing";
        
        ClearPortals cp = new ClearPortals();
        WebDriver driver = cp.setUp();
        
        try
        {
            cp.login(driver,"ldautomation4","test1234");
            
            failures(deleteList(driver,"Chrome Visitors"),"Visitor History - Delete List Chrome Visitors");
            
            driver.get(Util.siteNameout()+"/trackingrings");
            
            failures(visitorTracking(driver),"Tracking Clean Up");
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing admin module:");
            e.printStackTrace();
        }
        cp.logout(driver);
        return list;
    }
    
    public static void failures(boolean result,String s)
    {
        if(!result)
        {
            if(list.equals("Nothing"))
            {
                list = s;
            }
            else
            {
                list += ", "+s;
            }
        }
    }
    
    public static boolean visitorTracking(WebDriver driver)
    {
        try
        {
            CommonFunctions.waitRings(driver);
            CommonFunctions.viewCheck(driver,"ListView");
            
            if(driver.findElement(By.id("listbox")).findElement(By.className("prioritybx")).getAttribute("priority").equals("5"))
            {
                driver.findElement(By.id("ldwrap")).findElement(By.id("innerheader")).findElement(By.className("tlistview")).click();
                
                if(driver.findElement(By.id("listbox")).findElement(By.className("prioritybx")).getAttribute("priority").equals("1"))
                {
                    CommonFunctions.viewCheck(driver,"Rings");
                    if(TrackingCustomize.checkPastChats(driver))
                    {
                        return true;
                    }
                }
            }
            else if(driver.findElement(By.id("listbox")).findElement(By.className("prioritybx")).getAttribute("priority").equals("1"))
            {
                CommonFunctions.viewCheck(driver,"Rings");
                if(TrackingCustomize.checkPastChats(driver))
                {
                    return true;
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing settings in viitor tracking module : "+e);
        }
        return false;
    }
    
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
    
    public static boolean deleteList(WebDriver driver,String listname)
    {
        try
        {
            Thread.sleep(2000);
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250, TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            clickVisitorHistory(driver);
            
            Thread.sleep(2000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0")));
            
            driver.findElement(By.id("favdrpdown0")).click();
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("favdrpdown0_ddown")));
            
            WebElement elmt = driver.findElement(By.id("favdrpdown0_ddown"));
            
            List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                if(ell.findElement(By.tagName("span")).getText().equals(listname))
                {
                    ell.findElement(By.className("drop-tick")).click();
                    
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
                    
                    driver.findElement(By.className("lvd_popupsub")).findElement(By.id("okbtn")).click();
                    
                }
            }
            
            clickSettings(driver);
            
            Thread.sleep(2000);
            
            clickVisitorHistory(driver);
            
            Thread.sleep(2000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0")));
            
            driver.findElement(By.id("favdrpdown0")).click();
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("favdrpdown0_ddown")));
            
            elmt = driver.findElement(By.id("favdrpdown0_ddown"));
            
            elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                if(ell.findElement(By.tagName("span")).getText().equals(listname))
                {
                    return false;
                }
            }
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while deleting list in visitor history or jsapi module : "+e);
        }
        return false;
    }
    
    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250, TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_vhistory"))));
        
        driver.findElement(By.linkText(ResourceManager.getRealValue("common_vhistory"))).click();
        //CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_vhistory")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innerheader")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visit_mcontent")));
    }
    
    public static void clickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250, TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
        //CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setting_sm_user")));
    }
}