//$Id$
package com.zoho.livedesk.client.CleanUp;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.ChatMonitor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.google.common.base.Function;

public class cleanUpAutomations
{
    public static String list = "Nothing";
    
    public static String CleanUp() throws Exception
    {
        list = "Nothing";
        
        ClearPortals cp = new ClearPortals();
        WebDriver driver = cp.setUp();
        
        try
        {
            cp.login(driver,"ldautomation3","test1234");
            
            failures(leadScoring(driver),"Lead Scoring");
            failures(intelligentTriggers(driver),"Intelligent Triggers RealTime");
            
            for(int i = 1;i <= 10;i++)
            {
                driver.get(Util.siteNameout()+"/leadscore"+i);
                failures(leadScoring(driver),"Lead Score in portal leadscore"+i);
            }
            
            cp.logout(driver);
            
            driver = cp.setUp();
            cp.login(driver,"renganathan.k+ldautomation5@zohocorp.com","test1234");
            driver.get(Util.siteNameout()+"/visitorrouting");
            
            failures(visitorRouting(driver),"Visitor Routing Real Time");
            
            driver.get(Util.siteNameout()+"/chatmonitor");
            failures(chatMonitorSettings(driver),"Chat Monitor Settings");
            
            cp.logout(driver);
            
            driver = cp.setUp();
            cp.login(driver,"ldautomation2","test1234");
            driver.get(Util.siteNameout()+"/ldautomation21");
            
            failures(intelligentTriggers(driver),"Intelligent Triggers");
            failures(visitorRouting(driver),"Visitor Routing CRUD");
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing automations module:");
            e.printStackTrace();
        }
        cp.logout(driver);
        return list;
    }
    
    public static void failures(boolean result,String s)
    {
        if(!result)
        {
            if(list.equals("Nothing"))
            {
                list = s;
            }
            else
            {
                list += ", "+s;
            }
        }
    }
    
    public static boolean visitorRouting(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            while(!ruleExistVR(driver))
            {
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
                
                WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("data_row"));
                
                mouseOver(driver,elmtch);
                
                elmtch.findElement(By.className("routeto")).findElement(By.className("sqico-delico")).click();
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                driver.findElement(By.id("okbtn")).click();
            }
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in visitor routing tab : "+e);
        }
        return false;
    }
    
    public static boolean ruleExistVR(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(10,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            
            driver.findElement(By.id("addsuggtitle"));
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if data is cleared in VR : "+e);
        }
        return false;
    }
    
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }
    
    public static boolean leadScoring(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
            
            for(int count = 1; count <=20;count++)
            {
                try
                {
                    List<WebElement> elmtlslist = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst"));
                    int initial = elmtlslist.size();
                    
                    if(initial <= 1)
                    {
                        break;
                    }
                    else
                    {
                        String ruleid = elmtlslist.get(1).getAttribute("id");
                        
                        System.out.println("RULE ID ------------------------------------"+ruleid);
                        
                        driver.findElement(By.id(ruleid)).findElements(By.tagName("div")).get(2).findElement(By.tagName("span")).click();
                        
                        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                        driver.findElement(By.id("okbtn")).click();
                        
                        Tab.waitForLoadingLine(driver);
                        
                        for(int i = 1; i <=20;i++)
                        {
                            int elmtlslistFinal = driver.findElement(By.id("scoreview")).findElements(By.className("leadscrlst")).size();
                            if(initial-1 == elmtlslistFinal)
                            {
                                break;
                            }
                            Thread.sleep(500);
                        }
                        
                        Thread.sleep(1000);
                    }
                }
                catch(IndexOutOfBoundsException e)
                {
                    System.out.println("One or more condition check has failed during this execution");
                }
            }
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in lead scoring tab : "+e);
        }
        return false;
    }
    
    public static boolean intelligentTriggers(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            while(!ruleExistIT(driver))
            {
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));
                
                driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();
                
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
                
                WebElement elmtch = driver.findElement(By.id("trouting")).findElement(By.className("data_row"));
                
                mouseOver(driver,elmtch);
                
                elmtch.findElement(By.className("routeto")).findElement(By.className("sqico-delico")).click();
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                driver.findElement(By.id("okbtn")).click();
            }
            
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing data in intelligent triggers tab : "+e);
        }
        return false;
    }
    
    public static boolean ruleExistIT(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(10,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            
            driver.findElement(By.id("addsuggtitle"));
            
            if(driver.findElement(By.id("addsuggtitle")).findElement(By.className("bstate-rht")).findElement(By.tagName("h3")).getText().equals(ResourceManager.getRealValue("intelligenttriggers_notriggers")))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking if data is cleared in IT : "+e);
        }
        return false;
    }
    
    public static boolean chatMonitorSettings(WebDriver driver)
    {
        try
        {
            if(ChatMonitor.deleteChatMonitor(driver,"12.1.1.1"))
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while clearing settings in chat monitor settings page : "+e);
        }
        return false;
    }
}