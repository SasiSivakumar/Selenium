//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class SReports
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	public static ExtentTest etest;

	public static final String 
	MODULE_NAME = "Reports - Supervisor"
	;

	public static Hashtable genReport(WebDriver driver)
	{
		try
		{
            result = new Hashtable();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP1"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			Tab.clickReports(driver);
			etest.log(Status.PASS,"Reports Tab is present");

			result.put("SREP1", true);

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP2"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP2", checkDescInTab(driver,"Overview"));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Supervisor - Reports - Overview Actions Dropdown"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			checkOverviewActionDropDown(driver);

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP7"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP7", sentMail(driver,"test",false));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP8"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP8", sentMail(driver,"test@salesiq.com",true));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP9"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP9", checkOverviewDeptDropDown(driver));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP10"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP10", checkOverviewPeriodDropdown(driver));

			ComplexReportFactory.closeTest(etest);

			String usecase1[] = {"11","12","13","14","15","16","17"};
			String id1[] = {"wh1","wh2","wh3","wh4","wh5","wh6","wh7"};
			String header1[] = {"Visitor Status","Top operators","Visitor regions","Operators activity","Departments usage","Visitors Analysis","Operator activity ratio"};

			checkHeaderInCharts(driver,"Overview",usecase1,id1,header1);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP19"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP19", checkDescInTab(driver,"Visitors"));

			ComplexReportFactory.closeTest(etest);

			String usecase2[] = {"20","21","22","23"};
			String id2[] = {"vh1","vh2","vh3","vh4"};
			String header2[] = {"Visitor details","Visitor waiting time","Visitor waiting time ratio","Support Info"};

			checkHeaderInCharts(driver,"Visitors",usecase2,id2,header2);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP27"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP27", checkDescInTab(driver,"Operators"));

			ComplexReportFactory.closeTest(etest);

			String usecase3[] = {"28","29","30"};
			String id3[] = {"uh1","uh2","uh3"};
			String header3[] = {"Operators activity","Operators Rating","Operators Availability"};

			checkHeaderInCharts(driver,"Operators",usecase3,id3,header3);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP32"));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			result.put("SREP32", checkDescInTab(driver,"Tracking"));

			ComplexReportFactory.closeTest(etest);

			String usecase4[] = {"33","34"};
			String header4[] = {"Tracking Summary","Tracking Analysis"};

			checkHeaderInTrackingTab(driver,usecase4,"widget",header4);

			String usecase5[] = {"35","36"};
			String header5[] = {"Visits vs Unique Visits","Contacted vs Responded"};

			checkHeaderInTrackingTab(driver,usecase5,"widget-hlf",header5);


			String usecase6[] = {"37","38","39","40"};
			String header6[] = {"Avg Time Spent","Avg Pages Visited","Total Page Views","Total Visitors"};

			checkHeaderInTrackingTab(driver,usecase6,"widget-qtr",header6);

			// Need Respective Bot for the below modules
			etest = ComplexReportFactory.getTest("Reports - Supervisor - Check Chat ended by Data when chat was ended by visitor");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.putAll(ReportsModule.checkChatEndedBy(driver,ReportsModule.VISITOR,"SREP",etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Reports - Supervisor - Check Chat ended by Data when chat was ended by operator");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.putAll(ReportsModule.checkChatEndedBy(driver,ReportsModule.OPERATOR,"SREP",etest));
			ComplexReportFactory.closeTest(etest);

			etest = ComplexReportFactory.getTest("Reports - Supervisor - Check Chat ended by Data when chat was ended by bot");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.putAll(ReportsModule.checkChatEndedBy(driver,ReportsModule.BOT,"SREP",etest));
			ComplexReportFactory.closeTest(etest);

        }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorReport(s)Tab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","ErrorReport","ErrorReport(s)Tab",e);
			result.put("SREP1", false);
		}

		ComplexReportFactory.closeTest(etest);
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	public static boolean checkDescInTab(WebDriver driver,String tab) throws Exception
	{
		try
		{
			if(!tab.equals("Overview"))
			{
				Tab.clickReports(driver,"Overview");

				if(!Reports.checkDescInTab(driver,etest,"Overview"))
				{
					return false;
				}
			}

			Tab.clickReports(driver,tab);

			if(Reports.checkDescInTab(driver,etest,tab))
			{
				etest.log(Status.PASS,"Checked");
				return true;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","Desc-"+tab,"Error",e);
		}
		return false;
	}

	public static void checkOverviewActionDropDown(WebDriver driver) throws Exception
	{
		try
		{

			result.put("SREP3",false);
			result.put("SREP4",false);
			result.put("SREP5",false);
			result.put("SREP6",false);

			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			if(!checkDescInTab(driver,"Overview"))
			{
				return;
			}

			final WebElement div = CommonUtil.elfinder(driver,"id","rightcontainer");

			CommonUtil.elementfinder(driver,div,"id","creportaction").click();

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(div.findElement(By.id("combocontainer")).getAttribute("style").contains("block"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

			String values[] = {"Save as PDF","Send as Mail","Export as .xlsx","Export as .csv"};
			String id[] = {"rpdf","rmail","exls","ecsv"};

			WebElement dropDown = CommonUtil.elementfinder(driver,div,"id","combocontainer");

			for(int i = 0;i<4;i++)
			{
				if(!CommonUtil.elementfinder(driver,dropDown,"id",id[i]).getText().equals(values[i]))
				{
					TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewDropDown-"+values[i],"Error");
				}
				else
				{
					result.put("SREP"+(i+3),true);
				}

			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewActionDropDown","Error",e);
		}
	}

	public static boolean sentMail(WebDriver driver,String mail,boolean correct) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			if(!checkDescInTab(driver,"Overview"))
			{
				return false;
			}

			final WebElement div = CommonUtil.elfinder(driver,"id","rightcontainer");

			CommonUtil.elementfinder(driver,div,"id","creportaction").click();

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(div.findElement(By.id("combocontainer")).getAttribute("style").contains("block"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

			WebElement dropDown = CommonUtil.elementfinder(driver,div,"id","combocontainer");

			WebElement e = CommonUtil.elementfinder(driver,dropDown,"id","rmail");

			wait.until(ExpectedConditions.visibilityOf(e));

			e.click();

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("sendmailfrm"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.id("sendmailfrm")).getAttribute("innerHTML").contains("toemailauto"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        final WebElement popup = CommonUtil.elfinder(driver,"id","sendmailfrm");

	        wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,popup,"id","toemail")));
	        
            if(correct)
            {
                CommonUtil.elementfinder(driver,popup,"id","toemail").click();
                CommonUtil.elementfinder(driver,popup,"id","toemail").sendKeys(mail);
                
                Thread.sleep(2000);
            }
            
            wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,popup,"classname","cnfmbtm")));
	        
            CommonUtil.elementfinder(driver,popup,"classname","cnfmbtm").click();

	        if(correct)
	        {
                Tab.waitForLoadingSuccessWithBanner(driver,"Mail Sent Successfully","expreport.do",etest);
		        return true;

	        }
	        else
	        {
	        	wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(popup.getAttribute("innerHTML").contains("errormesg"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

	        	wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(popup.findElement(By.className("errormesg")).getText().contains("Please enter the valid Email Address"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

	        	CommonUtil.elementfinder(driver,popup,"css","div.cnfmbtm.mrgnlft_twenty").click();

	        	wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(!driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("sendmailfrm"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

		        return true;
	        }

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewSentMail","Error",e);
			driver.navigate().refresh();
			Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkOverviewDeptDropDown(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			if(!checkDescInTab(driver,"Overview"))
			{
				return false;
			}

			final WebElement div = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"id","reportsdept");

			CommonUtil.elementfinder(driver,div,"id","reportsdept_div").click();

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(div.findElement(By.id("reportsdept_ddown")).getAttribute("style").contains("block"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        final WebElement allDept = CommonUtil.elementfinder(driver,div,"id","reportsdept0");
	        final WebElement otherDept = CommonUtil.elementfinder(driver,div,"id","reportsdept1");

	        wait.until(ExpectedConditions.visibilityOf(allDept));
	        wait.until(ExpectedConditions.visibilityOf(otherDept));

	        if(otherDept.getText().equals("undefined"))
	        {
	        	TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewDepartment","Error");
				return false;
	        }

	        allDept.click();

	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(!div.findElement(By.id("reportsdept_ddown")).getAttribute("style").contains("block"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

	        return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewDepartment","Error",e);
			driver.navigate().refresh();
			Thread.sleep(3000);
		}

		return false;

	}

	public static boolean checkOverviewPeriodDropdown(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			if(!checkDescInTab(driver,"Overview"))
			{
				return false;
			}

			final WebElement div = CommonUtil.elfinder(driver,"id","rightcontainer");

			String values0[] = {"Last Hour","Last Three Hours","Last Six Hours"};
			String values1[] = {"Today","Yesterday"};
			String values2[] = {"This week","Last week","This month","Last month"};

			List<WebElement> list0 = CommonUtil.elementfinder(driver,div,"id","reportscal0").findElements(By.tagName("li"));
			List<WebElement> list1 = CommonUtil.elementfinder(driver,div,"id","reportscal1").findElements(By.tagName("li"));
			List<WebElement> list2 = CommonUtil.elementfinder(driver,div,"id","reportscal2").findElements(By.tagName("li"));

			for(int i = 0;i<values0.length;i++)
			{
				CommonUtil.elementfinder(driver,div,"id","reportscal_div").click();

				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(div.findElement(By.id("reportscal_ddown")).getAttribute("style").contains("block"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

		        if(!list0.get(i).getText().equals(values0[i]))
		        {
		        	etest.log(Status.FAIL,"Expected:"+values0[i]+"--Actual:"+list0.get(0)+"--");
		        	TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewPeriodDropdown","Error");
		        	return false;
		        }

		        list0.get(i).click();

		        wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(div.findElement(By.id("reportscal_ddown")).getAttribute("style").contains("none"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });
			}

			for(int i = 0;i<values1.length;i++)
			{
				CommonUtil.elementfinder(driver,div,"id","reportscal_div").click();

				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(div.findElement(By.id("reportscal_ddown")).getAttribute("style").contains("block"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

		        if(!list1.get(i).getText().equals(values1[i]))
		        {
		        	etest.log(Status.FAIL,"Expected:"+values1[i]+"--Actual:"+list1.get(0)+"--");
		        	TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewPeriodDropdown","Error");
		        	return false;
		        }

		        list1.get(i).click();

		        wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(div.findElement(By.id("reportscal_ddown")).getAttribute("style").contains("none"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });
			}



			for(int i = 0;i<values2.length;i++)
			{
				CommonUtil.elementfinder(driver,div,"id","reportscal_div").click();

				wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(div.findElement(By.id("reportscal_ddown")).getAttribute("style").contains("block"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });

		        if(!list2.get(i).getText().equals(values2[i]))
		        {
		        	etest.log(Status.FAIL,"Expected:"+values2[i]+"--Actual:"+list2.get(0)+"--");
		        	TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewPeriodDropdown","Error");
		        	return false;
		        }

		        list2.get(i).click();

		        wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		                if(div.findElement(By.id("reportscal_ddown")).getAttribute("style").contains("none"))
		                {
		                    return true;
		                }
		                return false;
		            }
		        });
			}

			return true;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","OverviewPeriodDropdown","Error",e);
			driver.navigate().refresh();
			Thread.sleep(3000);
		}
		return false;
	}

	public static void checkHeaderInCharts(WebDriver driver,String tab,String usecase[],String id[],String header[]) throws Exception
	{
		try
		{
			int trial = 1;
			int count = usecase.length;
			for(int i = 0;i<count;i++)
			{
				etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP"+usecase[i]));
				ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

		        if(trial++ == 1)
		        {
		        	if(!checkDescInTab(driver,tab))
			        {
			        	trial = 1;
			        	result.put("SREP"+usecase[i],false);
			        	ComplexReportFactory.closeTest(etest);
			        	continue;
			        }
			    }

			    WebElement div = CommonUtil.elfinder(driver,"id","rightcontainer");
			    WebElement e = CommonUtil.elementfinder(driver,div,"id",id[i]);
			    CommonUtil.inViewPort(e);

			    String actual = e.getText();

			    if(!actual.contains(header[i]))
			    {
			    	etest.log(Status.FAIL,"Expected:"+header[i]+"--Actual:"+actual+"--");
			    	TakeScreenshot.screenshot(driver,etest,"Report-Admin","CheckChartHeaders","Error");
			    	ComplexReportFactory.closeTest(etest);
			    	result.put("SREP"+usecase[i],false);
			    	continue;
			    }
			    etest.log(Status.PASS,"Checked");
		        result.put("SREP"+usecase[i],true);
		        ComplexReportFactory.closeTest(etest);
		    }
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","CheckChartHeaders","Error",e);
		}

		ComplexReportFactory.closeTest(etest);
	}

	public static void checkHeaderInTrackingTab(WebDriver driver,String usecase[],String class_name,String header[]) throws Exception
	{
		for(int i = 0; i<usecase.length;i++)
		{
			checkHeaderInTrackingTab(driver,usecase[i],class_name,i,header[i]);
		}
	}

	public static void checkHeaderInTrackingTab(WebDriver driver,String usecase,String class_name,int num,String header) throws Exception
	{
		try
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SREP"+usecase));
			ComplexReportFactory.setValues(etest,"Automation","Reports - Supervisor");

			if(!checkDescInTab(driver,"Overview"))
	        {
	        	result.put("SREP"+usecase,false);
	        	ComplexReportFactory.closeTest(etest);
	        	return;
	        }

	        if(!checkDescInTab(driver,"Tracking"))
	        {
	        	result.put("SREP"+usecase,false);
	        	ComplexReportFactory.closeTest(etest);
	        	return;
	        }

	        WebElement e = CommonUtil.elfinder(driver,"id","rightcontainer").findElements(By.className(class_name)).get(num);

	        CommonUtil.inViewPort(e);

	        String actual = e.getText();

		    if(!actual.contains(header))
		    {
		    	etest.log(Status.FAIL,"Expected:"+header+"--Actual:"+actual+"--");
		    	TakeScreenshot.screenshot(driver,etest,"Report-Admin","CheckChartHeaders","Error");
		    	ComplexReportFactory.closeTest(etest);
		    	result.put("SREP"+usecase,false);
		    	return;
		    }
		    etest.log(Status.PASS,"Checked");
	        result.put("SREP"+usecase,true);
	        ComplexReportFactory.closeTest(etest);
	        return;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Report-Admin","CheckChartHeaders","Error",e);
		}

		result.put("SREP"+usecase,false);
		ComplexReportFactory.closeTest(etest);
	}
}
