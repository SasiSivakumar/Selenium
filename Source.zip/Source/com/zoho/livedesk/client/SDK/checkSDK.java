//$Id$
package com.zoho.livedesk.client.SDK;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDeviceActionShortcuts;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.Feedback;
import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.*;

public class checkSDK {
	
	public static void main(String args[]) throws Exception
	{
        WebDriver d = null;//Need to add login changes login(null, "rajkumar.natarajan+1@zohocorp.com", "test1234");
		
		d.get("https://salesiq.zoho.com/demodesk");
		
		Tab.clickSettings(d);
		
		Functions.closeBannersAfterLogin(d);
		
		String ratings[] = {"bad","good","wow"};
		
		for(String s : ratings)
		{
			check(d,s,true);
			check(d,s,false);
		}
		
		check(d,"",true);
	}
	
	public static void check(WebDriver d, String rating, Boolean fdb) throws Exception
	{
		AppiumDriver driver = getAndroidDriver(true);
		
		ChatWindow.acceptChat(d,null);
		
		ChatWindow.sentMessage(d, "AgentMessage");
		
		Thread.sleep(10000);
		
		System.out.println(getSenderVisitorName(driver, 0));
		System.out.println(getMessage(driver, 0));
		System.out.println(getSenderAgentName(driver, 0));
		System.out.println(getMessage(driver, 1));
		
		System.out.println(getCurrentPage(d));
		
		Thread.sleep(5000);
		
		System.out.println(getCurrentPage(d));
		
		ChatWindow.endAndCloseChat(d);
		
		System.out.println(getChatEndedContent(driver));
	}
	
	public static AppiumDriver getAndroidDriver(Boolean reset) throws Exception
	{
		DesiredCapabilities capability = new DesiredCapabilities();
		
		capability.setCapability(MobileCapabilityType.DEVICE_NAME, "Android emulator");
		capability.setCapability("avd", "TestDevice1");
		capability.setCapability("noReset", !reset);
		capability.setCapability("app", "/Users/raj-4138/Downloads/Android Apps/app-debug.apk");
		
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capability);
		
		Thread.sleep(5000);
		
		return driver;
	}
	
	public static void sendKeysName(AppiumDriver driver, String value) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String id = Property.getRealValue("name_input");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "id", id);
		
		e.click();
		
		e.sendKeys(value);
	}
	
	public static void sendKeysEmail(AppiumDriver driver, String value) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String id = Property.getRealValue("email_input");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "id", id);
		
		e.click();
		
		e.sendKeys(value);
	}
	
	public static void sendKeysPhone(AppiumDriver driver, String value) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String id = Property.getRealValue("phone_input");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "id", id);
		
		e.click();
		
		e.sendKeys(value);
	}
	
	
	

	
	
	public static void sentMessage(AppiumDriver driver, String message) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("messsgae_textarea");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "id", id);
		
		e.sendKeys(message);
		
		id = Property.getRealValue("message_send");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		e = CommonUtil.elfinder(driver, "id", id);
		
		e.click();
	}
	
	public static String getChatEndedContent(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		return CommonUtil.elfinder(driver, "id", id).getText();
	}
	
	
	

	
	public static String getFeedbackMessage(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_feedback");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		return CommonUtil.elfinder(driver, "id", id).getText();
	}
	
	public static String getFeedbackRating(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_smiley");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		return CommonUtil.elfinder(driver, "id", id).getText();
	}
	
//	
	
	public static String getSenderAgentName(AppiumDriver driver, int i) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("agentname");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		
		List<WebElement> list = driver.findElements(By.id(id));
		
		return list.get(i).getText();
	}
	
	public static String getSenderVisitorName(AppiumDriver driver, int i) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("visitorname");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		
		List<WebElement> list = driver.findElements(By.id(id));
		
		return list.get(i).getText();
	}
	
	public static String getMessage(AppiumDriver driver, int i) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("message");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		
		List<WebElement> list = driver.findElements(By.id(id));
		
		return list.get(i).getText();
	}
	
	public static String getCurrentPage(WebDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
		
		String id = "mycurrent_div";
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "xpath", "//div[@id='mycurrent_div']//div[@id='visdatapar']//div[contains(@class,'trackpath')]");
		
		String s = e.getText();
		
		return s;
	}
	
}
