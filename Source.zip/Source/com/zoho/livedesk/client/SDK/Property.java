//$Id$
package com.zoho.livedesk.client.SDK;

import java.io.FileInputStream;
import java.util.Properties;

public class Property {
	
	private static String resourcepath = "/Users/raj-4138/Downloads/ZIDE/eclipse/Eclipse.app/Contents/MacOS/ZIDE/test/src/SDK/sdkresource.properties";
	public static Properties prop = getProperties(resourcepath);
	public static String getRealValue(String key)
	{
		try
		{
			if(resourcepath.contains("null"))
			{
				resourcepath = resourcepath.replace("null","salesiq");
				prop = getProperties(resourcepath);
			}
			String val = null;
			val = prop.getProperty(key,val);
			if(val != null)
			{
				if(key.contains("Theme"))
				{
					val =  val.replace("$","'");
				}
				
				return val;
			}
		}
		catch(Exception e){}
		
		if(!key.contains("MA"))
		{
			System.out.println(key+" - not found");
		}
		return key;
	}
	
	public static Properties getProperties(String propsFile)
    {
            try
            {
                    Properties props = new Properties();
                    props.load(new FileInputStream(propsFile));
                    return props;
            }
            catch (Exception exp)
            {
                    return null;
            }
    }
}
