//$Id$
package com.zoho.livedesk.client.SDK;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDeviceActionShortcuts;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.Feedback;
import com.zoho.livedesk.util.common.actions.PopUp;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.WebEmbed;
import com.zoho.livedesk.util.common.*;

public class SDKUsecases {
//	 sdk_livechat  
	public static boolean changeStatusInLiveChat(WebDriver webdriver, Boolean status) throws Exception
	{
		try
		{
			Tab.navToEmbedTab(webdriver);
			
			String usecase = status?"Enabled":"Disabled";
			
			WebEmbed.clickWebEmbed(webdriver, "rajkumarsdk");
			
			final WebElement e = CommonUtil.elfinder(webdriver, "xpath", "//div[@boxname='livechatmobile']");
			
			e.click();
			
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(webdriver, 20, 250);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sdk_topdiv")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sdk_topdiv")));
			
			final WebElement div = CommonUtil.elfinder(webdriver,"id","sdk_topdiv");
			
			CommonUtil.elementfinder(webdriver, div, "id", "sdk_androidsel").click();
			
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                	if(div.getAttribute("class").contains("android"))
        			{
        				return true;
        			}
                	
                    return false;
                }
            });
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sdk_showsettings")));
			
			WebElement showmore = CommonUtil.elementfinder(webdriver, div, "xpath", ".//div[@id='sdk_showsettings']//em");
			
			CommonUtil.inViewPort(showmore);
			
			showmore.click();
			
			String id = status?"sdk_livechat":"sdk_tracking";
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
			
			final WebElement chat = CommonUtil.elfinder(webdriver, "id", id);
			
			CommonUtil.inViewPort(chat);
			
			Thread.sleep(1000);
			
			if(!chat.getAttribute("class").contains("sel"))
			{
				CommonUtil.elementfinder(webdriver, chat, "tagname", "em").click();
				
				wait.until(new Function<WebDriver,Boolean>(){
	                public Boolean apply(WebDriver driver)
	                {
	                	if(chat.getAttribute("class").contains("sel"))
	        			{
	        				return true;
	        			}
	                	
	                    return false;
	                }
	            });
				
				CommonUtil.elfinder(webdriver, "id", "sdk_savesettings").click();
				
				Tab.waitForLoadingSuccessWithBanner(webdriver,null,null,null);
			}
			
			CommonUtil.elementfinder(webdriver, div, "id", "sdk_close").click();
			
			Thread.sleep(10000);
			
			SDKUtil.etest.log(Status.INFO, "Successfully "+usecase);
			
			AppiumDriver driver = SDKUtil.getAndroidDriver(true);
			
			try
			{
				SDKFunctions.clickChatButton(driver, SDKUtil.etest);
				
				Boolean chatWin = SDKFunctions.checkChatWindow(driver);
				
				if(status == chatWin)
				{
					SDKUtil.etest.log(Status.INFO,"Use case checked");
					return true;
				}
				else
				{
					SDKUtil.screenshot(driver, SDKUtil.etest, "ChangeStatusInLiveChat");
					return false;
				}
			}
			catch(Exception excep)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "ChangeStatusInLiveChat", excep);
				
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(webdriver, SDKUtil.etest, "MobileSDK", "ChangeStatusInLiveChat", "Error",e);
			webdriver.navigate().refresh();Thread.sleep(4000);
		}
		
		return false;
	}
	
	public static boolean changeStatusInLibrary(WebDriver webdriver, Boolean status) throws Exception
	{
		try
		{
			Tab.navToEmbedTab(webdriver);
			
			String usecase = status?"Enabled":"Disabled";
			
			WebEmbed.clickWebEmbed(webdriver, "rajkumarsdk");
			
			final WebElement e = CommonUtil.elfinder(webdriver, "xpath", "//div[@boxname='livechatmobile']");
			
			e.click();
			
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(webdriver, 20, 250);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sdk_topdiv")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sdk_topdiv")));
			
			final WebElement div = CommonUtil.elfinder(webdriver,"id","sdk_topdiv");
			
			CommonUtil.elementfinder(webdriver, div, "id", "sdk_androidsel").click();
			
			wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                	if(div.getAttribute("class").contains("android"))
        			{
        				return true;
        			}
                	
                    return false;
                }
            });
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sdk_libstatus")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sdk_libstatus")));
			
			final WebElement toogle = CommonUtil.elementfinder(webdriver, div, "id", "sdk_libstatus");
			
			final String toogleClass = status?"sqico-enable":"sqico-disable";
			
			if(!toogle.getAttribute("class").equals(toogleClass))
			{
				toogle.click();
				
				PopUp.clickOkBtn(webdriver);
				
				Tab.waitForLoadingSuccessWithBanner(webdriver,null,null,null);
				
				wait.until(new Function<WebDriver,Boolean>(){
	                public Boolean apply(WebDriver driver)
	                {
	                	if(toogle.getAttribute("class").equals(toogleClass))
	        			{
	        				return true;
	        			}
	                	
	                    return false;
	                }
	            });
			}
			
			CommonUtil.elementfinder(webdriver, div, "id", "sdk_close").click();
			
			Thread.sleep(3000);
			
			SDKUtil.etest.log(Status.INFO,"Successfully "+usecase);
			
			AppiumDriver driver = SDKUtil.getAndroidDriver(true);
			
			try
			{
				SDKFunctions.clickChatButton(driver, SDKUtil.etest);
				
				Boolean chatWin = SDKFunctions.checkChatWindow(driver);
				
				if(status == chatWin)
				{
					SDKUtil.etest.log(Status.INFO,"Use case checked");
					return true;
				}
				else
				{
					SDKUtil.screenshot(driver, SDKUtil.etest, "ChangeStatusInLibrary");
					return false;
				}
			}
			catch(Exception excep)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "ChangeStatusInLibrary", excep);
				
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(webdriver, SDKUtil.etest, "MobileSDK", "ChangeStatusInLibrary", "Error",e);
			webdriver.navigate().refresh();Thread.sleep(4000);
		}
		
		return false;
	}
	
	public static boolean changeStatusInMobileSDK(WebDriver webdriver, Boolean status) throws Exception
	{
		try
		{
			Tab.navToEmbedTab(webdriver);
			
			String usecase = status?"Enabled":"Disabled";
			
			WebEmbed.clickWebEmbed(webdriver, "rajkumarsdk");
			
			final WebElement e = CommonUtil.elfinder(webdriver, "xpath", "//div[@boxname='livechatmobile']");
			
			final WebElement toogle = CommonUtil.elementfinder(webdriver, e, "xpath", ".//em[@documentclick='toggleEmbedStatus']");
			
			final String toogleClass = status?"sqico-enable":"sqico-disable";
			final Boolean disableBox = status?false:true;
			
			if(!(toogle.getAttribute("class").equals(toogleClass) && (e.getAttribute("class").contains("dabl") == disableBox)))
			{
				toogle.click();
				
				Tab.waitForLoadingSuccessWithBanner(webdriver,null,null,null);
				
				FluentWait<WebDriver> wait = CommonUtil.waitreturner(webdriver, 20, 250);
				
				wait.until(new Function<WebDriver,Boolean>(){
	                public Boolean apply(WebDriver driver)
	                {
	                	if(toogle.getAttribute("class").equals(toogleClass) && (e.getAttribute("class").contains("dabl") == disableBox))
	        			{
	        				return true;
	        			}
	                	
	                    return false;
	                }
	            });
			}
			
			SDKUtil.etest.log(Status.INFO,"Successfully "+usecase);
			
			Thread.sleep(2000);
			
			AppiumDriver driver = SDKUtil.getAndroidDriver(true);
			
			try
			{
				SDKFunctions.clickChatButton(driver, SDKUtil.etest);
				
				Boolean chatWin = SDKFunctions.checkChatWindow(driver);
				
				if(status == chatWin)
				{
					SDKUtil.etest.log(Status.INFO,"Use case checked");
					return true;
				}
				else
				{
					SDKUtil.screenshot(driver, SDKUtil.etest, "ChangeStatusInMobileSDK");
					return false;
				}
			}
			catch(Exception excep)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "ChangeStatusInMobileSDK", excep);
				
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(webdriver, SDKUtil.etest, "MobileSDK", "ChangeStatusInMobileSDK", "Error",e);
			webdriver.navigate().refresh();Thread.sleep(4000);
		}
		return false;
	}
	public static boolean checkChat(WebDriver webdriver) throws Exception
	{
		SDKUtil.result.put("SDK12",false);
		SDKUtil.result.put("SDK13",false);
		
		try
		{
			Long t1 = System.currentTimeMillis();
			AppiumDriver driver = SDKUtil.getAndroidDriver(true);
			
			try
			{
				SDKFunctions.clickChatButton(driver, SDKUtil.etest);
				
				SDKFunctions.sentMessage(driver, SDKUtil.etest, "There?");
			}
			catch(Exception e)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "CheckChat", e);
				
				return false;
			}
			
			ChatWindow.acceptChat(webdriver, SDKUtil.etest);
			
			ChatWindow.sentMessage(webdriver, "A"+t1);
			
			String url = checkSDK.getCurrentPage(webdriver);
			
			SDKUtil.etest.log(Status.INFO, "<>"+url+"<>");
			
			Thread.sleep(5000);
			
			try
			{
				String vn = SDKFunctions.getSenderVisitorName(driver, 0);
				String vm = SDKFunctions.getMessage(driver, 0);
				
				String an = SDKFunctions.getSenderAgentName(driver, 0);
				String am = SDKFunctions.getMessage(driver, 1);
				
				SDKUtil.etest.log(Status.INFO, "<>"+vn+"<>");
				SDKUtil.etest.log(Status.INFO, "<>"+vm+"<>");
				SDKUtil.etest.log(Status.INFO, "<>"+an+"<>");
				SDKUtil.etest.log(Status.INFO, "<>"+am+"<>");
				
				SDKUtil.result.put("SDK12",true);
				
				SDKFunctions.clickBackInMobile(driver, SDKUtil.etest);
				
				SDKFunctions.clickActivity3(driver, SDKUtil.etest);
			}
			catch(Exception e)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "CheckChat", e);
				
				return false;
			}
			
			Thread.sleep(3000);
			
			url = checkSDK.getCurrentPage(webdriver);
			
			SDKUtil.etest.log(Status.INFO, "<>"+url+"<>");
			
			SDKUtil.result.put("SDK13",true);
			
//			try
//			{
//				SDKFunctions.clickChatButton(driver, SDKUtil.etest);
//			}
//			catch(Exception e)
//			{
//				SDKUtil.screenshot(driver, SDKUtil.etest, "CheckChat", e);
//				
//				return false;
//			}
			
			ChatWindow.endAndCloseChat(webdriver);
			
			try
			{
				SDKFunctions.checkChatEnded(driver, SDKUtil.etest);
				
				String chatended = SDKFunctions.getChatEndedMessage(driver);
				
				SDKUtil.etest.log(Status.INFO, "<>"+chatended+"<>");
				
				return true;
			}
			catch(Exception e)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "CheckChat", e);
				
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(webdriver, SDKUtil.etest, "MobileSDK", "CheckChat", "Error",e);
		}
		
		return false;
	}
	
	public static Boolean checkFeedback(WebDriver webdriver, String rating, String expectedrating, Boolean feedback) throws Exception
	{
		try
		{
			int result = 0;
			
			Long t1 = System.currentTimeMillis();
			
			String fdbcontent = "No Feedback given";
			
			if(feedback)
			{
				fdbcontent = "F"+t1;
			}
			
			AppiumDriver driver = SDKUtil.getAndroidDriver(true);
			
			try
			{
				SDKFunctions.clickChatButton(driver, SDKUtil.etest);
				
				SDKFunctions.sentMessage(driver, SDKUtil.etest, "There?");
			}
			catch(Exception e)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "CheckFeedback", e);
				
				return false;
			}
			
			ChatWindow.acceptChat(webdriver, SDKUtil.etest);
			
			Thread.sleep(2000);
			
			ChatWindow.endAndCloseChat(webdriver);
			
			try
			{
				SDKFunctions.checkChatEnded(driver, SDKUtil.etest);
				
				SDKFunctions.clickChatEndedButton(driver, SDKUtil.etest);
				
				SDKFunctions.clickRating(driver, SDKUtil.etest, rating);
				
				if(feedback)
				{
					SDKFunctions.enterFeedback(driver, SDKUtil.etest, fdbcontent);
				}
				else
				{
					SDKFunctions.closeFeedback(driver, SDKUtil.etest);
				}
				
				String smiley = SDKFunctions.getFeedbackRating(driver);
				String fdbc = SDKFunctions.getFeedbackMessage(driver);
				
				String f = "RATING";//RATING_AND_FEEDBACK_COMPLETED  RATING_COMPLETED
				
				if(feedback)
				{
					f += "_AND_FEEDBACK";
				}
				
				f += "_COMPLETED"; 
						
				String rating2 = rating.substring(0, 1).toUpperCase() + rating.substring(1);
				
				if(smiley.equals(rating2) && fdbc.equals(f))
				{
					SDKUtil.etest.log(Status.INFO, "Feedback details checked in mobile");
					result++;
				}
				else
				{
					SDKUtil.etest.log(Status.FAIL, "Expected:"+rating2+"--"+f+"--Actual:"+smiley+"--"+fdbc+"--");
					SDKUtil.screenshot(driver, SDKUtil.etest, "CheckFeedback");
				}
			}
			catch(Exception e)
			{
				SDKUtil.screenshot(driver, SDKUtil.etest, "CheckFeedback", e);
				
				return false;
			}
			
			Tab.clickFeedback(webdriver);
			
			WebElement div = Feedback.getFeedbackDiv(webdriver, 0);
			
			String star = Feedback.getStar(webdriver, div);
			
			String fdb = Feedback.getDetails(webdriver,div,"thrd-clm","pre");
			
			if(star.equals(expectedrating) && fdb.equals(fdbcontent))
			{
				SDKUtil.etest.log(Status.INFO, "Feedback details checked in Agent");
				result++;
			}
			else
			{
				SDKUtil.etest.log(Status.FAIL, "Expected:"+expectedrating+"--"+fdbcontent+"--Actual:"+star+"--"+fdb+"--");
				TakeScreenshot.screenshot(webdriver, SDKUtil.etest, "MobileSDK", "CheckFeedback", "Error");
			}
			
			if(result == 2)
			{
				return true;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(webdriver, SDKUtil.etest, "MobileSDK", "CheckFeedback", "Error",e);
		}
		
		return false;
	}
}
