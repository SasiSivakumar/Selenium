//$Id$
package com.zoho.livedesk.client.SDK;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDeviceActionShortcuts;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.*;

public class SDKFunctions {
	
	public static void clickChatButton(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		TouchAction action = new TouchAction(driver);
		
		action.tap(950, 1600).perform();
		
		if(checkChatWindow(driver))
		{
			etest.log(Status.INFO,"Chat window is opened");
		}
		else
		{
			etest.log(Status.INFO,"Chat window is not opened");
		}
	}
	
	public static boolean checkChatWindow(AppiumDriver driver) throws Exception
	{
		try
		{
			FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 4, 250);
			
			String id = Property.getRealValue("messsgae_textarea");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
			
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	public static void sentMessage(AppiumDriver driver,  ExtentTest etest, String message) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("messsgae_textarea");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "id", id);
		
		e.sendKeys(message);
		
		etest.log(Status.INFO, message+" is entered");
		
		id = Property.getRealValue("message_send");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		e = CommonUtil.elfinder(driver, "id", id);
		
		e.click();
		
		etest.log(Status.INFO, "Sent is clicked");
	}
	
	public static String getSenderAgentName(AppiumDriver driver, int i) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("agentname");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		
		List<WebElement> list = driver.findElements(By.id(id));
		
		return list.get(i).getText();
	}
	
	public static String getSenderVisitorName(AppiumDriver driver, int i) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("visitorname");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		
		List<WebElement> list = driver.findElements(By.id(id));
		
		return list.get(i).getText();
	}
	
	public static String getMessage(AppiumDriver driver, int i) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("message");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		
		List<WebElement> list = driver.findElements(By.id(id));
		
		return list.get(i).getText();
	}
	
	public static void checkChatEnded(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		id = Property.getRealValue("endchat_btn");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		etest.log(Status.INFO, "Chat is ended");
	}
	
	public static void clickBackInMobile(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.BACK);
		
		etest.log(Status.INFO, "Back button in mobile is clicked");
	}
	
	public static void clickActivity3(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("activity3");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		WebElement e = CommonUtil.elfinder(driver, "id", id);
		
		e.click();
		
		etest.log(Status.INFO, "Activity 3 is clicked");
	}
	
	public static void clickSubmit(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		WebElement e = CommonUtil.elfinder(driver, "id", Property.getRealValue("submit"));
		
		clickBackInMobile(driver,etest);
			
		Thread.sleep(1000);
		
		e.click();
	}
	
	public static void clickChatEndedButton(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_btn");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		CommonUtil.elfinder(driver, "id", id).click();
		
		etest.log(Status.INFO,"Smiley is clicked");
		
		String ids[] = {"smiley_bad","smiley_good","smiley_wow"};
		
		for(String s : ids)
		{
			id = Property.getRealValue(s);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		}	
	}
	
	public static void clickRating(AppiumDriver driver, ExtentTest etest,String rating) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("smiley_"+rating);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		CommonUtil.elfinder(driver, "id", id).click();
		
		etest.log(Status.INFO,rating+" is clicked");
		
		id = Property.getRealValue("feedback_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
	}
	
	public static void enterFeedback(AppiumDriver driver, ExtentTest etest, String fdb) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("feedback_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		CommonUtil.elfinder(driver, "id", id).sendKeys(fdb);
		
		etest.log(Status.INFO,fdb+" is entered");
		
		id = Property.getRealValue("feedback_submit");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		CommonUtil.elfinder(driver, "id", id).click();
		
		id = Property.getRealValue("endchat_smiley");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
	}
	
	public static void closeFeedback(AppiumDriver driver, ExtentTest etest) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("feedback_close");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		CommonUtil.elfinder(driver, "id", id).click();
		
		etest.log(Status.INFO,"Close feedback is clicked");
		
		id = Property.getRealValue("endchat_smiley");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
	}
	
	public static String getChatEndedMessage(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_text");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		return CommonUtil.elfinder(driver, "id", id).getText();
	}
	
	public static String getFeedbackMessage(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_feedback");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		return CommonUtil.elfinder(driver, "id", id).getText();
	}
	
	public static String getFeedbackRating(AppiumDriver driver) throws Exception
	{
		FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 20, 250);
		
		String id = Property.getRealValue("endchat_smiley");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
		
		return CommonUtil.elfinder(driver, "id", id).getText();
	}
}
