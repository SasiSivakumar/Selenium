//$Id$
package com.zoho.livedesk.client.SDK;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;

public class SDKUtil {
	
	public static Hashtable<String, Boolean> result = new Hashtable<String, Boolean>();
	public static Set<AppiumDriver> visDrivers = new HashSet();
	public static ExtentTest etest;
	public static int screenShotCount = 1;

	public static void main(String[] args) throws Exception
	{
		getAndroidDriver(true);
		
		if(true)return;
		
		Long t123 = new Long(System.currentTimeMillis());
		Util.buildnamed = ""+t123;
		Util.sitenamed = "https://salesiq.zoho.com";
		Util.serverHostName = "raj-4138";
        Util.serverPortNumber = "9090";
		
        WebDriver webdriver = null;//Need to add login changes login(null, "rajkumar.natarajan+1@zohocorp.com", "test1234");
		
		webdriver.get("https://salesiq.zoho.com/demodesk");
		
		System.out.println(test(webdriver));
		
		webdriver.get("https://salesiq.zoho.com/logout.sas");
		
		Thread.sleep(3000);
		
		webdriver.quit();
	}
	
	public static Hashtable test(WebDriver webdriver) throws Exception
	{
		screenShotCount = 1;
		result = new Hashtable<String, Boolean>();
		
		try
		{
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK1"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK1",SDKUsecases.changeStatusInMobileSDK(webdriver,false));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK2"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK2",SDKUsecases.changeStatusInMobileSDK(webdriver,true));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK3"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK3",SDKUsecases.changeStatusInLibrary(webdriver,false));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK4"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK4",SDKUsecases.changeStatusInLibrary(webdriver,true));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK5"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK5",SDKUsecases.changeStatusInLiveChat(webdriver,false));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK6"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK6",SDKUsecases.changeStatusInLiveChat(webdriver,true));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK11"));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK11",SDKUsecases.checkChat(webdriver));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			testFeedback(webdriver);
		}
		catch(Exception e)
		{
			
		}
		
		return result;
	}
	
	public static void screenshot(WebDriver driver, ExtentTest etest, String error)
    {
        try
        {
        	String module = "MobileSDK";
        	
        	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            
            etest.log(Status.FAIL, module+"--"+error);
            FileUtils.copyFile(scrFile, new File("/Users/raj-4138/Documents/SalesIQ/SDK/Zoho/TestAutomation/webapps/selenium/screenshots/"+Util.buildlabel()+"/"+removeSpecialCharacters(module)+"/"+removeSpecialCharacters(error)+screenShotCount+".jpg"));
            etest.log(Status.FAIL,"Error screenshot: ");
            etest.addScreenCaptureFromPath("http://"+InetAddress.getLocalHost().getHostName()+":9090/screenshots/"+Util.buildlabel()+"/"+removeSpecialCharacters(module)+"/"+removeSpecialCharacters(error)+screenShotCount+".jpg");
            
            screenShotCount++;
        }
        catch(Exception e)
        {
            System.out.println("Exception while trying to take screenshot :");
            e.printStackTrace();
        }
    }

	public static void screenshot(WebDriver driver, ExtentTest etest, String error,Exception excep)
    {
        try
        {
        	String module = "MobileSDK";
        	
        	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            
            String reason = excep.toString();
            if(reason.contains("TimeoutException"))
            {
                reason = reason.split("Build info")[0];
                etest.log(Status.FAIL, module+"--"+error+"--"+reason);
            }
            else if(reason.contains("NoSuchElementException"))
            {
                reason = reason.split("\"}")[0]+"\"}";
                etest.log(Status.FAIL, module+"--"+error+"--"+reason);
            }
           else
           {
        	   etest.log(Status.FAIL, module+"--"+error+"--"+excep.getClass().getName());
           }  
            FileUtils.copyFile(scrFile, new File("/Users/raj-4138/Documents/SalesIQ/SDK/Zoho/TestAutomation/webapps/selenium/screenshots/"+Util.buildlabel()+"/"+removeSpecialCharacters(module)+"/"+removeSpecialCharacters(error)+screenShotCount+".jpg"));
            etest.log(Status.FAIL,"Error screenshot: ");
            etest.addScreenCaptureFromPath("http://"+InetAddress.getLocalHost().getHostName()+":9090/screenshots/"+Util.buildlabel()+"/"+removeSpecialCharacters(module)+"/"+removeSpecialCharacters(error)+screenShotCount+".jpg");
            
            excep.printStackTrace();
            
            screenShotCount++;
        }
        catch(Exception e)
        {
            System.out.println("Exception while trying to take screenshot :");
            e.printStackTrace();
        }
    }
	
	private static String removeSpecialCharacters(String s)
    {
        if(s != null)
        {
            s = s.replaceAll(" ","_");
            s = s.replaceAll("#","_");
            s = s.replaceAll("/","_");
            s = s.replaceAll("'","_");
            s = s.replaceAll("\\?","_");
            s = s.replaceAll("!","_");
        }
        return s;   
    }
	
	public static AppiumDriver getAndroidDriver(Boolean reset) throws Exception
	{
		visDrivers = new HashSet();
		
		DesiredCapabilities capability = new DesiredCapabilities();
		
		capability.setCapability(MobileCapabilityType.DEVICE_NAME, "Android emulator");
		capability.setCapability("avd", "TestDevice1");
		capability.setCapability("noReset", !reset);
		capability.setCapability("app", "/Users/raj-4138/Downloads/Android Apps/app-debugL.apk");
		
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capability);
		
		Thread.sleep(5000);
		
		visDrivers.add(driver);
		
		return driver;
	}
	
	public static void closeVisDrivers()
	{
		for(AppiumDriver d : visDrivers)
		{
			try
			{
				d.quit();
			}
			catch(Exception e){}
		}
	}
	
	public static void testFeedback(WebDriver webdriver) throws Exception
	{
		int usecase = 14;
		
		String ratings[] = {"bad","good","wow"};
		String expectedratings[] = {" star-1"," star-3"," star-5"};
		
		for(int j = 0; j <3; j++)
		{
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK"+usecase));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK"+usecase,SDKUsecases.checkFeedback(webdriver, ratings[j],expectedratings[j], false));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			usecase++;
			
			etest = ComplexReportFactory.getTest(Property.getRealValue("SDK"+usecase));
			ComplexReportFactory.setValues(etest,"Automation","Moblie SDK");
			
			result.put("SDK"+usecase,SDKUsecases.checkFeedback(webdriver, ratings[j],expectedratings[j], true));
			
			ComplexReportFactory.closeTest(etest);closeVisDrivers();
			
			usecase++;
		}
	}
}
