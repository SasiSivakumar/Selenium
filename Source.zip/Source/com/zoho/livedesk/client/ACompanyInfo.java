//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class ACompanyInfo
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    
	public static String companyname = null;
	public static String website = null;
	public static String address = null;
	public static String emailid = null;
	public static String telephone = null;
	public static String fax = null;
	public static String desc = null;
	public static String language = null;
	public static String timezone = null;
	private static String url = "";
    public static ExtentTest etest; 
        
	private static void init()
	{
		companyname = "Zoho corp";
		website = "http://people.zoho.com";
		address = "DLF IT park, Ramapuram";
		emailid = "anand.ramachandran@zohocorp.com";
		telephone = "9788160492";
		fax = "9123456789";
		desc = "AdventNet";
		language = "English";
		timezone = "( GMT 5:45 ) Nepal Time(Asia/Katmandu)";
	}
	
	public static Hashtable companydetails(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC1"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//Company info view
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
			
            etest.log(Status.PASS,"Company Tab is present");

            result.put("ASC1", true);
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC2"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            init();
			result.put("ASC2", isPageAvail(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            //etest=ComplexReportFactory.getTest("Check Data Is Editable Or Not By Associate");
            //ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            checkDataEdit(driver);

            //ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorCompanyTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Company-Associate","CompanyTab","ErrorWhileCheckingCompanytab",e);

            result.put("ASC1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorCompanyTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"Company-Associate","Companytab","ErrorWhileCheckingCompanytab",e);

            result.put("ASC1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	//Check Company Header
    private static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_comp_info")+"')]")));
            
            driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_comp_info")+"')]"));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
            
            if((driver.findElement(By.className("innersubinfotxt")).getText()).equals(ResourceManager.getRealValue("settings_company_desc")))
            {
                etest.log(Status.PASS,"Company Settings Page is present");

                return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"Company-Associate","CompanySettingsPage","MismatchDescription");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Company-Associate","CompanySettingsPage","ErrorWhileCheckingCompanySettingsPage",e);

            System.out.println("Exception while checking if company settings page is available in Associate login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Company-Associate","CompanySettingsPage","ErrorWhileCheckingCompanySettingsPage",e);

            System.out.println("Exception while checking if company settings page is available in Associate login : "+e);
        }
        return false;
    }
    
    //Check if data is editable
    private static void checkDataEdit(WebDriver driver)
    {
        try
        {
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC3"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_company"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_company"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
            
            List<WebElement> elmtchk = driver.findElement(By.id("recorddetail")).findElements(By.cssSelector("div.myprfdtlmn_rht"));
            
            try
            {
                //Company name
                elmtchk.get(0).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC3"),"CompanyIsEditable");

                result.put("ASC3",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC3")+" is checked");

                result.put("ASC3",true);
            }
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC4"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company website
                elmtchk.get(1).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC3"),"WebsiteIsEditable");

                result.put("ASC4",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC4")+" is checked");

                result.put("ASC4",true);
            }
             
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC5"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company Address
                //elmtchk.get(2).findElement(By.tagName("textarea"));
                
                if((driver.findElement(By.id("companyaddress")).getAttribute("class")).contains("siq_txtbox"))
                {
                    TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC5"),"AddressIsEditable");

                    result.put("ASC5",false);
                }
                else
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("ASC5")+" is checked");

                    result.put("ASC5",true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC5"),"ErrorWhileCheckingAddressIsEditable",e);

                result.put("ASC5",false);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC6"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company Email
                elmtchk.get(3).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC6"),"EmailIsEditable");

                result.put("ASC6",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC6")+" is checked");

                result.put("ASC6",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC7"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company phone number
                elmtchk.get(4).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC7"),"PhoneNumberIsEditable");

                result.put("ASC7",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC7")+" is checked");

                result.put("ASC7",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC8"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company fax number
                elmtchk.get(5).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC8"),"FaxNumberIsEditable");

                result.put("ASC8",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC8")+" is checked");

                result.put("ASC8",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC9"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company language
                elmtchk.get(6).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC9"),"LanguageIsEditable");

                result.put("ASC9",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC9")+" is checked");

                result.put("ASC9",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC10"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company timezone
                elmtchk.get(7).findElement(By.tagName("input"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC10"),"TimezoneIsEditable");

                result.put("ASC10",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC10")+" is checked");

                result.put("ASC10",true);
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASC11"));
            ComplexReportFactory.setValues(etest,"Automation","Company Settings - Associate");

            try
            {
                //Company about the company
                driver.findElement(By.id("recorddetail")).findElement(By.className("siq_cmndesc")).findElement(By.tagName("textarea"));
                
                TakeScreenshot.screenshot(driver,etest,"Company-Associate",KeyManager.getRealValue("ASC11"),"AboutTheCompanyIsEditable");

                result.put("ASC11",false);
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,KeyManager.getRealValue("ASC11")+" is checked");

                result.put("ASC11",true);
            }
            
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Company-Associate","CheckEditData","ErrorWhileCheckingEditData",e);

            System.out.println("Exception while checking if data is editable in company settings page in Associate login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Company-Associate","CheckEditData","ErrorWhileCheckingEditingData",e);

            System.out.println("Exception while checking if data is editable in company settings page in Associate login : "+e);
        }
        ComplexReportFactory.closeTest(etest);
    }
}
