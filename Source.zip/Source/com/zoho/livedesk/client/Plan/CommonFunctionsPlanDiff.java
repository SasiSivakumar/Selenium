//$Id$
package com.zoho.livedesk.client.Plan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;

import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;
import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class CommonFunctionsPlanDiff {
    
    static int clearcount = 0;
	static int getTextcount = 0;
	static int sendKeyscount = 0;
	static int clickcount = 0;
	static int waitcount = 0;
	static int findCount=0;
	
	public static WebElement findElement(WebDriver driver,String by,String path) throws Exception{
	
		WebElement element=null;
		try{
				switch (by){
					case "id":  element=driver.findElement(By.id(path));
								break;
					case "className": element=driver.findElement(By.className(path));
									break;
					case "cssSelector": element=driver.findElement(By.cssSelector(path));
									break;
					case "xpath": element=driver.findElement(By.xpath(path));
									break;
					case "linkText": element=driver.findElement(By.linkText(path));
									break;
					case "name": 	element=driver.findElement(By.name(path));
									break;
					case "tagName": element=driver.findElement(By.tagName(path));
									break;
		    	}
		}
		catch(StaleElementReferenceException staleException){
			if(findCount>3){
				findCount=0;
				System.out.println("staleElementReferenceException while finding by "+by+" - "+path);
				staleException.printStackTrace();
				findCount=0;
				//log(Status.FAIL,"staleElementReferenceException while finding the element:"+elementDesc,test);
			}
			else{
				Thread.sleep(2000);
				findCount++;
				element=findElement(driver,by, path);
			}
		}
		findCount=0;
		return element;
	}
	public static WebElement findElement(WebElement driver,String by,String path)throws Exception{
		
		WebElement element=null;
		try{
				switch (by){
					case "id":  element=driver.findElement(By.id(path));
								break;
					case "className": element=driver.findElement(By.className(path));
									break;
					case "cssSelector": element=driver.findElement(By.cssSelector(path));
									break;
					case "xpath": element=driver.findElement(By.xpath(path));
									break;
					case "linkText": element=driver.findElement(By.linkText(path));
									break;
					case "name": 	element=driver.findElement(By.name(path));
									break;
					case "tagName": element=driver.findElement(By.tagName(path));
									break;
		    	}
		}
		catch(StaleElementReferenceException staleException){
			if(findCount>3){
				findCount=0;
				System.out.println("staleElementReferenceException while finding by "+by+" - "+path);
				staleException.printStackTrace();
				findCount=0;
				//log(Status.FAIL,"staleElementReferenceException while finding the element:"+elementDesc,test);
			}
			else{
				Thread.sleep(2000);
				findCount++;
				element=findElement(driver,by, path);
			}
		}
		findCount=0;
		return element;
	}
	public static FluentWait waitreturner(WebDriver driver,int time,int cycle)throws Exception
	{
		FluentWait wait = new FluentWait(driver);
        wait.withTimeout(time,TimeUnit.SECONDS);
        wait.pollingEvery(cycle,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
        Thread.sleep(1000);
        return wait;
	}
	public static boolean checkString1(String s1,String s2,ExtentTest etest) 
	{
		if(!s1.equals(s2))
		{
			etest.log(Status.FAIL,"Mismatch Content: Actual---"+s1+"---;Excpected---"+s2+"---");
			return false;
		}
		return true;
	}
}
