//$Id$
package com.zoho.livedesk.client.Plan;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.TimeoutException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.LeadScoringRT.LeadScoringRealTime;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;
import com.zoho.livedesk.util.common.objects.Integration;
import com.zoho.livedesk.util.Cleanup;
import com.zoho.livedesk.util.common.VisitorWindow;

public class PlanDifference {
    
    public static Hashtable result = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    private static String requrl = "";
	public static ExtentTest etest; 
	public static WebDriver driver = null;
	public static VisitorDriverManager visitor_driver_manager;
	public static String widget_code = "", website_name = "", embed_name = "";
	

      public static String 
      CHAT_ROUTING_LIMIT_EXCEED = "Plan limit exceeded",
      LEAD_SCORE_DELETE_TEXT = "You are about to delete a lead scoring rule",
      LEAD_RULE_LIMIT_EXCEED = "Lead Rule Limit Exceeded!",
      FREEPLAN_TRIGGER_UPGRADE = "freeplan_trigger_upgrade",
      FREEPLAN_ROUTING_UPGRADE = "freeplan_routing_upgrade",
      FREEPLAN_CHAT_MONITOR_UPGRADE = "freeplan_chat_monitor_upgrade",
      FREEPLAN_EMAIL_SCHEDULES_UPGRADE = "freeplan_email_schedules_upgrade"
      ;

      public static By 
      CHAT_ROUTING_ADD_BUTTON = By.id("autobtnadd"),
      CHAT_ROUTING_ADD_RULE = By.id("addrule"),
      LEAD_SCORE_TAB = By.id("scoreview"),
      LEAD_SCORE_RULE_LIST = By.className("leadscrlst"),
      LEAD_SCORE_RULE_DELETE_ICON = By.className("deletescr"),
      LEAD_SCORE_ID = By.id("leadscore"),
      LEAD_SCORE_ADD_BUTTON = By.className("innerbtnmn"),
      EMPTY_INFO = By.className("emp_info")
      ;
	
	public static Hashtable plandiff(WebDriver d){
    	try{
            
            result = new Hashtable();
            // website_name = ExecuteStatements.getDefaultEmbedName(driver);
            // widget_code = ExecuteStatements.getWidgetCodeFromEmbedName(driver, website_name);
            // embed_name = ExecuteStatements.getEmbedNameFromWidgetCode(driver, widget_code);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF1"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");

            driver = CommonOperations.setUp();
			
            Functions.login(driver,"plan_free");
            
            result.put("PDF1",checkplanuserlimit(driver,"freeplan","users","Free Plan"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF2"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF2",checkplandepartmentlimit(driver,"freeplan","dept","Free Plan",1));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF3"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF3",checkplanembedlimit(driver,"freeplan","embed","Free Plan",1));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF4"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF4",freeplanexportvisitorhistory(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF7"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF7",CheckPresence.checkContentInPortalSettings(driver,"free","translate",false,etest));

            ComplexReportFactory.closeTest(etest);

            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF17"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF17",CheckPresence.checkContentInPortalSettings(driver,"free","dailystatics",true,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF6"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF6",checkplanBlockedIP(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Plan Difference - Free Plan -Check Automation Tab");
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            freeplancheckAutomation(driver,etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF12"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF12",checkplanEmailConfig(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF13"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF13",freeplanBusinesshours(driver));

            ComplexReportFactory.closeTest(etest);


            Integration[] integrations=Integration.values();

            for(Integration integration : integrations)
            {
                  etest=ComplexReportFactory.getTest(KeyManager.getRealValue(integration.usecase_key));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
                  result.put(integration.usecase_key,checkplanInteg(driver,"freeplan",integration.header,"Free Plan",integration.isAccessible));
                  ComplexReportFactory.closeTest(etest);
            }
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF18"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF18",CheckPresence.checkReportPresence(driver,"overview",etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF19"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF19",CheckPresence.checkReportPresence(driver,"visitors",etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF20"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF20",CheckPresence.checkReportPresence(driver,"user",etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDF21"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Free Plan");
            
            result.put("PDF21",CheckPresence.checkReportPresence(driver,"tracking",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB1"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
           
			
			 // visitor_driver_manager = new VisitorDriverManager();
		        
	   //          etest = ComplexReportFactory.getTest(KeyManager.getRealValue("PDF53"));
	   //          ComplexReportFactory.setValues(etest, "Automation", "Plan Difference - Free Plan");
	   //          result.put("PDF53",  checkChatWidgetFloatStickerChanges(driver, etest, embed_name));
	           
	   //          ComplexReportFactory.closeTest(etest);

	   //          etest = ComplexReportFactory.getTest(KeyManager.getRealValue("PDF54"));
	   //          ComplexReportFactory.setValues(etest, "Automation", "Plan Difference - Free Plan");
	   //          result.put("PDF54",  checkChatWidgetFloatContentChanges(driver, etest, embed_name));
	         
	   //          ComplexReportFactory.closeTest(etest);

	   //          etest = ComplexReportFactory.getTest(KeyManager.getRealValue("PDF55"));
	   //          ComplexReportFactory.setValues(etest, "Automation", "Plan Difference - Free Plan");
	   //          result.put("PDF55",  checkChatWindowThemeAppearenceChanges(driver, etest, embed_name));
	          
	   //          ComplexReportFactory.closeTest(etest);

	   //          visitor_driver_manager.terminateAllDriverSessions();
			
			
            Functions.logout(driver);
                      
            driver = CommonOperations.setUp();

            Functions.login(driver,"plan_basic");

            result.put("PDB1",checkplanuserlimit(driver,"basicplan","users","Basic Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB2"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB2",checkplandepartmentlimit(driver,"basicplan","dept","Basic Plan",3));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB3"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB3",checkplanembedlimit(driver,"basicplan","embed","Basic Plan",3));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB4"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB4",checkplanBlockedIP(driver));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB5"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB5",CheckPresence.checkContentInPortalSettings(driver,"Basic","translate",false,etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB6"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB6",checkplanEmailConfig(driver));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB11"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB11",CheckPresence.checkReportPresence(driver,"overview",etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB12"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB12",CheckPresence.checkReportPresence(driver,"visitors",etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB13"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB13",CheckPresence.checkReportPresence(driver,"user",etest));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB14"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB14",CheckPresence.checkReportPresence(driver,"tracking",etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB15"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB15",checkplantriggerslimit(driver,"basicplan","triggers","Basic Plan"));

            ComplexReportFactory.closeTest(etest);
 
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB16"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB16",checkplanroutinglimit(driver,"basicplan","routing","Basic Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB17"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB17",checkplanschedulelimit(driver,"basicplan","schedule","Basic Plan"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB7"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB7",basicplancheckchatmonitor(driver,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB18"));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB18",checkPlanChatRouting(driver));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDB19"));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Basic Plan");
            
            result.put("PDB19",checkPlanLeadScoring(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP1"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            Functions.logout(driver);
            
            driver = CommonOperations.setUp();
            
            Functions.login(driver,"plan_professional");

            result.put("PDP1",checkplanuserlimit(driver,"profplan","users","Professional Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP2"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP2",checkplandepartmentlimit(driver,"profplan","dept","Professional Plan",5));

            ComplexReportFactory.closeTest(etest);
  
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP3"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP3",checkplanembedlimit(driver,"profplan","embed","Professional Plan",5));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP4"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP4",checkplantriggerslimit(driver,"profplan","triggers","Professional Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP5"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP5",checkplanroutinglimit(driver,"profplan","routing","Professional Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP6"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP6",checkplanschedulelimit(driver,"profplan","schedule","Professional Plan"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP7"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP7",CheckPresence.checkContentInPortalSettings(driver,"Professional","translate",false,etest));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP8"));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP8",checkPlanChatRouting(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDP9"));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Professional Plan");
            
            result.put("PDP9",checkPlanLeadScoring(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE1"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            Functions.logout(driver);
            
            driver = CommonOperations.setUp();
            
            Functions.login(driver,"plan_enterprise");

            result.put("PDE1",checkplanuserlimit(driver,"enterpriseplan","users","Enterprise Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE2"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE2",enterpriseplandepartmentlimit(driver,"enterpriseplan","dept","Enterprise Plan"));

            ComplexReportFactory.closeTest(etest);
  
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE3"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE3",enterpriseplanembedlimit(driver,"enterpriseplan","embed","Enterprise Plan"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE4"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE4",checkplantriggerslimit(driver,"enterpriseplan","triggers","Enterprise Plan"));

            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE5"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE5",checkplanroutinglimit(driver,"enterpriseplan","routing","Enterprise Plan"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE7"));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE7",checkPlanChatRouting(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE8"));
                  ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE8",checkPlanLeadScoring(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PDE6"));
			ComplexReportFactory.setValues(etest,"Automation","Plan Difference - Enterprise Plan");
            
            result.put("PDE6",enterpriseplanschedulelimit(driver,"enterpriseplan","schedule","Enterprise Plan"));
          
            
            Functions.logout(driver);
            driver.quit();
            
        }
    	catch(Exception e)
        {
            result.put("PDF1",false);
            etest.log(Status.FATAL,e.toString());
            etest.log(Status.FATAL,"Module breakage occurred "+e);          
            TakeScreenshot.screenshot(driver,etest,"PlanDifference","LoginError","Error",e);
    
    	}
        ComplexReportFactory.closeTest(etest);
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    public static boolean checkplanuserlimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            List<WebElement> userList = UsersTab.getUsersList(driver);
            WebElement lastUser = userList.get(userList.size()-1);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+lastUser.getLocation().y+"-300)");
            String s = CommonUtil.elementfinder(driver,lastUser,"tagname","a").getText();
            String userToDelete = CommonUtil.getElement(lastUser,By.className("txtelips")).getText();
            etest.log(Status.INFO,"To delete:"+s);
            
            UsersTab.deleteUser(driver,userToDelete,etest);
            
            UsersTab.addUser(driver,s,"admin",null,etest);
            
            Tab.clickSettings(driver);
            
            if(UsersTab.getUser(driver,userToDelete) == null)
            {
                etest.log(Status.INFO,"User not added");
                TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckUserLimitFor"+plan+"Plan","Error");
                return false;
            }
            
    		if(!CommonOperations.clickSettings(driver,etest)){
    			return false;
			}
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","ulisttable");
			List<WebElement> users = list.findElements(By.className("list-row"));
			int count = users.size() - disabled(users,"list_disable");
			etest.log(Status.INFO,"Active Users Count:"+count);
            
            WebElement add = CommonFunctionsPlanDiff.findElement(driver,"id","buttonuseradd");
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0)");
            
			add.click();
			
			return CheckExceed.planlimit(driver,plan,tocheck,etest,plan1,true);
		}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckUserLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean checkplandepartmentlimit(WebDriver driver,String plan,String tocheck,String plan1, int limit){
    	try{
            if(limit != 1)
            {
                String username = ExecuteStatements.getUserName(driver);
                
                etest.log(Status.INFO,"Username:"+username);
                
                List<WebElement> depts = Department.getDepartmentList(driver);
                int current = depts.size();
                
                String dept1 = CommonUtil.elementfinder(driver,depts.get(current-1),"classname","txtelips").getText();
                
                etest.log(Status.INFO,"Need to delete - "+dept1);
                
                if(!Department.deleteDepartment(driver,dept1,null,etest))
                {
                    TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error");
                    return false;
                }
                
                Thread.sleep(3000);
                
                Department.addDept(driver,dept1,"depttype_publi",username,etest);
                
                if(Department.getDept(driver,dept1) == null)
                {
                    TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error");
                    return false;
                }
            }
            
            if(!CommonOperations.navToDeptTab(driver,etest)){
    			return false;
			}
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","module-list");
			List<WebElement> dept = driver.findElements(By.className("list-row"));
			int count = dept.size() - disabled(dept,"list_disable");
			etest.log(Status.INFO,"Active Departments Count:"+count);
			CommonFunctionsPlanDiff.findElement(driver,"id","buttonadddept").click();
			return CheckExceed.planlimit(driver,plan,tocheck,etest,plan1,true);
		}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean enterpriseplandepartmentlimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            String username = ExecuteStatements.getUserName(driver);
            
            etest.log(Status.INFO,"Username:"+username);
            
            List<WebElement> depts = Department.getDepartmentList(driver);
            int current = depts.size();
            
            String dept1 = CommonUtil.elementfinder(driver,depts.get(current-1),"classname","txtelips").getText();
            
            etest.log(Status.INFO,"Need to delete - "+dept1);
            
            if(!Department.deleteDepartment(driver,dept1,null,etest))
            {
                TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error");
                return false;
            }
            
            Thread.sleep(3000);
            
            Department.addDept(driver,dept1,"depttype_publi",username,etest);
            
            if(Department.getDept(driver,dept1) == null)
            {
                TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error");
                return false;
            }
            
            if(!CommonOperations.navToDeptTab(driver,etest)){
    			return false;
			}
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","module-list");
			List<WebElement> dept = driver.findElements(By.className("list-row"));
			int count = dept.size() - disabled(dept,"list_disable");
			etest.log(Status.INFO,"Active Departments Count:"+count);
			CommonFunctionsPlanDiff.findElement(driver,"id","buttonadddept").click();
			return CheckExceed.enterpriseplanlimit(driver,plan,tocheck,etest,plan1,true);
		}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean checkplanembedlimit(WebDriver driver,String plan,String tocheck,String plan1, int limit){
    	try{
            if(limit != 1)
            {
                List<WebElement> embeds = WebEmbed.getWebsitesList(driver);
                int current = embeds.size();
                
                String e1 = CommonUtil.elementfinder(driver,embeds.get(current-1),"classname","txtelips").getText();
                
                etest.log(Status.INFO,"Need to delete - "+e1);
                
                WebEmbed.deleteEmbed(driver,e1);
                
                WebElement e = WebEmbed.getWebEmbed(driver,e1,etest);
                
                if(e != null)
                {
                    etest.log(Status.FAIL,"Deleted embed is present");
                    TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckEmbedLimitFor"+plan+"Plan","Error");
                    return false;
                }
                
                Thread.sleep(2000);
                
                WebEmbed.addWebEmbed(driver,e1);
                
                e = WebEmbed.getWebEmbed(driver,e1,etest);
                
                if(e == null)
                {
                    etest.log(Status.FAIL,"Added embed is not present");
                    TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckEmbedLimitFor"+plan+"Plan","Error");
                    return false;
                }
            }
            
    		if(!CommonOperations.navToEmbedTab(driver,etest)){
    			return false;
			}
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","embedlist");
			List<WebElement> embed = list.findElements(By.className("list-row"));
			int count = embed.size() - disabled(embed,"list_disable");
			etest.log(Status.INFO,"Active Embed Count:"+count);
			CommonFunctionsPlanDiff.findElement(driver,"id","buttonembedadd").click();
			return CheckExceed.planlimit(driver,plan,tocheck,etest,plan1,true);
    	}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckEmbedLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean enterpriseplanembedlimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            List<WebElement> embeds = WebEmbed.getWebsitesList(driver);
            int current = embeds.size();
            
            String e1 = CommonUtil.elementfinder(driver,embeds.get(current-1),"classname","txtelips").getText();
            String embedName = e1;
            etest.log(Status.INFO,"Need to delete - "+e1);
            
            WebEmbed.deleteEmbed(driver,e1);
            
            WebElement e = WebEmbed.getWebEmbed(driver,e1,etest);
            
            if(e != null)
            {
                TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error");
                return false;
            }
            
            Thread.sleep(2000);

            do
            {
                  embedName = e1 + current;
                  WebEmbed.addWebEmbed(driver,embedName);
                  embeds = WebEmbed.getWebsitesList(driver);
                  current = embeds.size();

            }while(current != 25);
            
            e = WebEmbed.getWebEmbed(driver,embedName,etest);
            
            if(e == null)
            {
                TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDepartmentLimitFor"+plan+"Plan","Error");
                return false;
            }
            
    		if(!CommonOperations.navToEmbedTab(driver,etest)){
    			return false;
			}
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","embedlist");
			List<WebElement> embed = list.findElements(By.className("list-row"));
			int count = embed.size() - disabled(embed,"list_disable");
			etest.log(Status.INFO,"Active Embed Count:"+count);
			CommonFunctionsPlanDiff.findElement(driver,"id","buttonembedadd").click();
			return CheckExceed.enterpriseplanlimit(driver,plan,tocheck,etest,plan1,true);
    	}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckEmbedLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean checkplantriggerslimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            Tab.navToITTab(driver);
            
   //          Trigger.deleteRule(driver,etest);
            
   //          Trigger.clickAdd(driver,etest);
            
   //  		if(!CommonOperations.navToTriggers(driver,etest)){
   //  			return false;
			// }

			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","trouting");
			List<WebElement> triggers = list.findElements(By.className("data_row"));
			etest.log(Status.INFO,"Active Triggers Count:"+triggers.size());
			CommonFunctionsPlanDiff.findElement(driver,"id","autobtnadd").click();
			return CheckExceed.planlimit1(driver,plan,tocheck,etest,plan1,true);
    	}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckTriggersLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean checkplanroutinglimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            Tab.navToVRTab(driver);
            
   //          Routing.deleteRule(driver,etest);
            
   //          Routing.clickAdd(driver,etest);
            
   //          if(!CommonOperations.navToVisitorRouting(driver,etest)){
   //  			return false;
			// }
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","trouting");
			List<WebElement> routing = list.findElements(By.className("data_row"));
			etest.log(Status.INFO,"Active Visitor Routing Count:"+routing.size());
			CommonFunctionsPlanDiff.findElement(driver,"id","autobtnadd").click();
			return CheckExceed.planlimit1(driver,plan,tocheck,etest,plan1,true);
    	}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckRoutingLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean checkplanschedulelimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            String username = ExecuteStatements.getUserName(driver);
            
            etest.log(Status.INFO,"Username:"+username);
            
            String t = ""+(new Long(System.currentTimeMillis()));
            
            Tab.navToSchedulesTab(driver);
            
   //          EmailSchedule.clickDelete(driver,etest);
            
   //          if(!EmailSchedule.addSchedule(driver,etest,"All Visitors","email@"+t+".com",false,null,false,null,"Every day","xlsx",username))
   //          {
   //              etest.log(Status.FAIL,"Schedule not added");
   //              TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckScheduleLimitFor"+plan+"Plan","Error");
   //              return false;
   //          }
            
   //          if(!CommonOperations.navToEmailSchedule(driver,etest)){
   //  			return false;
			// }
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","trouting");
			List<WebElement> schedule = list.findElements(By.className("list-row"));
			int count = schedule.size() - disabled(schedule,"list_disable");
			etest.log(Status.INFO,"Active Schedule Count:"+count);
			CommonFunctionsPlanDiff.findElement(driver,"id","autobtnadd").click();
			return CheckExceed.planlimit(driver,plan,tocheck,etest,plan1,true);
    	}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckScheduleLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean enterpriseplanschedulelimit(WebDriver driver,String plan,String tocheck,String plan1){
    	try{
            String username = ExecuteStatements.getUserName(driver);
            
            etest.log(Status.INFO,"Username:"+username);
            
            String t = ""+(new Long(System.currentTimeMillis()));
            
            Tab.navToSchedulesTab(driver);
            
   //          EmailSchedule.clickDelete(driver,etest);
            
   //          if(!EmailSchedule.addSchedule(driver,etest,"All Visitors","email@"+t+".com",false,null,false,null,"Every day","xls",username))
   //          {
   //              etest.log(Status.FAIL,"Schedule not added");
   //              TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckScheduleLimitFor"+plan+"Plan","Error");
   //              return false;
   //          }
            
   //          if(!CommonOperations.navToEmailSchedule(driver,etest)){
   //  			return false;
			// }
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","trouting");
			List<WebElement> schedule = list.findElements(By.className("list-row"));
			int count = schedule.size() - disabled(schedule,"list_disable");
			etest.log(Status.INFO,"Active Schedule Count:"+count);
			CommonFunctionsPlanDiff.findElement(driver,"id","autobtnadd").click();
			return CheckExceed.planlimit(driver,plan,tocheck,etest,plan1,true);
    	}
    	catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckScheduleLimitFor"+plan+"Plan","Error",e);
			return false;
		}
	}
	public static boolean freeplanexportvisitorhistory(WebDriver driver){
    	try{
    		if(!CommonOperations.clickVisitorHistory(driver,etest)){
    			return false;
			}
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,1000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("actiondrpdown0")));
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckExportVisitorHistory","DropDownIsPresent");
			return false;
		}
    	catch(Exception e){
    			etest.log(Status.PASS,"Export Visitor History is not present");
				return true;
    	}
	}
	public static boolean checkplanBlockedIP(WebDriver driver){
    	try{
    		if(!CommonOperations.clickSettings(driver,etest)){
    			return false;
			}
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,1000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_blockedip")));
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckBlockedIP","IsPresent");
			return false;
		}
    	catch(Exception e){
    			etest.log(Status.PASS,"BlockedIP is not present");
				return true;
    	}
	}

      public static void freeplancheckAutomation(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  Tab.navToITTab(driver);
                  result.put("PDF5",checkUpgradeText(driver,FREEPLAN_TRIGGER_UPGRADE,etest));
                  Tab.navToVRTab(driver);
                  result.put("PDF8",checkUpgradeText(driver,FREEPLAN_ROUTING_UPGRADE,etest));
                  Tab.navToChatRoutingTab(driver);
                  result.put("PDF9",checkUpgradeText(driver,FREEPLAN_ROUTING_UPGRADE,etest));
                  Tab.navToCMTab(driver);
                  Tab.clickChatMonitor(driver);
                  result.put("PDF10",checkUpgradeText(driver,FREEPLAN_CHAT_MONITOR_UPGRADE,etest));
                  Tab.navToSchedulesTab(driver);
                  result.put("PDF11",checkUpgradeText(driver,FREEPLAN_EMAIL_SCHEDULES_UPGRADE,etest));
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,e);
            }
      }

      public static boolean checkUpgradeText(WebDriver driver,String upgradeText,ExtentTest etest)
      {
            try
            {
                  if(CommonUtil.checkStringContainsAndLog(ResourceManager.getRealValue(upgradeText),CommonUtil.getElement(driver,EMPTY_INFO).getText(),"Upgrade text",etest))
                  {
                        return true;
                  }
                  else
                  {
                        TakeScreenshot.screenshot(driver,etest);
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,e);
                  return false;
            }
      }

	public static boolean checkplanEmailConfig(WebDriver driver){
    	try{
    		if(!CommonOperations.navToDeptTab(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-list")));
			WebElement list = CommonFunctionsPlanDiff.findElement(driver,"id","module-list");
			List<WebElement> depts = driver.findElements(By.className("list-row"));
			depts.get(0).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("list-data")));
			try
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptconfig")));
				TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDeptEmailConfig","IsPresent");
				return false;
			}
			catch(Exception e)
			{
				etest.log(Status.PASS,"Department Email Configuration is not present");
				return true;
			}
		}
    	catch(Exception e){
    		TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckDeptEmailConfig","Error",e);
			return false;
		}
	}
	public static boolean freeplanBusinesshours(WebDriver driver)throws Exception
	{
		if(!CommonOperations.navToCompanyTab(driver,etest))
			return false;
		return CheckPresence.checkBusinessHour(driver,false,"free",etest);
	}
	public static int disabled(List<WebElement> list,String disabled){
		int count=0;
		for(WebElement e : list){
			
            
			if(e.getAttribute("class").contains(disabled))
				count++;
		}
		return count;
	}
	public static boolean checkplanInteg(WebDriver driver,String plan,String check,String plan1,boolean isAccessible){
    	try{
    		boolean exists = false;
    		if(!CommonOperations.navToIntegTab(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			WebElement integ = CommonFunctionsPlanDiff.findElement(driver,"id","integhome");
			List<WebElement> list = driver.findElements(By.className("integ_li"));
			for(WebElement e : list)
			{
				Coordinates ord = ((Locatable)e).getCoordinates();
				ord.inViewPort();
				WebElement integration = CommonFunctionsPlanDiff.findElement(e,"className","integ_linm");
				if(integration.getText().equals(check))
				{
					integration.click();

                              if(isAccessible)
                              {
                                    boolean isPopupNotFound=(CheckExceed.isPlanLimitPopupFound(driver)==false);

                                    if(isPopupNotFound)
                                    {
                                          etest.log(Status.PASS,check+" was accessible for plan : "+plan);
                                    }
                                    else
                                    {
                                          etest.log(Status.FAIL,check+" was NOT accessible for plan : "+plan);
                                          TakeScreenshot.screenshot(driver,etest);
                                    }

                                    TakeScreenshot.infoScreenshot(driver,etest);

                                    return isPopupNotFound;
                              }
                              else
                              {
                                    TakeScreenshot.infoScreenshot(driver,etest);

                                    return CheckExceed.planlimit(driver,plan,"integ",etest,plan1,false);
                              }
				}
			}
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","Check"+check+"Integrations",check+" is not present");
			return false;
		}
    	catch(Exception e){
    		TakeScreenshot.screenshot(driver,etest,"PlanDifference","Check"+check+"Integrations","Error",e);
			return false;
		}
	}

      public static boolean basicplancheckchatmonitor(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  Tab.navToCMTab(driver);
                  return checkUpgradeText(driver,FREEPLAN_CHAT_MONITOR_UPGRADE,etest);
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,e);
                  return false;
            }
      }
      
      public static boolean checkPlanChatRouting(WebDriver driver)
      {
            int chatRoutingRules = 0,failcount = 0;
            try
            {
                  Tab.navToChatRoutingTab(driver);
                  
                  //delete an existing rule
                  Routing.deleteRule(driver,etest);
                  etest.log(Status.INFO,"A chat routing rule was deleted from the chat routing rule list under Automation tab in Settings menu");
                  
                  //add a rule
                  Rules.clickAdd(driver,etest,"chatroutingtab","Chat Routing");
                  etest.log(Status.INFO,"A chat routing rule was added to chat routing in Automation tab in Settings menu");

                  //click add button to check popup
                  etest.log(Status.INFO,"trying to add another rule besides the limit");
                  WebElement addButton = CommonUtil.getElement(driver,CHAT_ROUTING_ADD_BUTTON,CHAT_ROUTING_ADD_RULE);
                  CommonWait.waitTillDisplayed(addButton);
                  CommonUtil.clickWebElement(driver,addButton);

                  WebElement popup = HandleCommonUI.getPopupByInnerText(driver,CHAT_ROUTING_LIMIT_EXCEED);
                  if(!checkPopup(driver,popup,"Chat routing",false,etest))
                  {
                        chatRoutingRules = CommonUtil.getElement(driver,By.id("trouting")).findElements(By.className("data_row")).size();
                        failcount++;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,"Chat routing","Failure","Operator window screenshot",e);
            }
            finally
            {
                  if(failcount > 0)
                  {
                        etest.log(Status.FAIL,"Total no of chat routing rules present are"+chatRoutingRules);
                        TakeScreenshot.screenshot(driver,etest,"Chat Routing","Failure","Operator window screenshot");
                        return false;
                  }
                  return true;
            }
      }

      public static boolean checkPlanLeadScoring(WebDriver driver)
      {
            int leadScoringRules = 0,failcount = 0;
            try
            {
                  Tab.clickSettings(driver);
                  Tab.clickLeadScoring(driver);

                  //deleting an existing rule
                  WebElement leadScoringRule = CommonUtil.getElement(driver,LEAD_SCORE_TAB,LEAD_SCORE_RULE_LIST);
                  CommonWait.waitTillDisplayed(CommonUtil.getElement(leadScoringRule,LEAD_SCORE_RULE_DELETE_ICON));
                  CommonUtil.getElement(leadScoringRule,LEAD_SCORE_RULE_DELETE_ICON).click();
                  WebElement deletePopup = HandleCommonUI.getPopupByInnerText(driver,LEAD_SCORE_DELETE_TEXT);
                  HandleCommonUI.clickButtonInPopup(deletePopup,true);
                  etest.log(Status.INFO,"Existing rule in the lead scoring rules was deleted");

                  //add new rule
                  LeadScoringRealTime.addRule(etest,driver,"1", "Browser", null, "is equal to", "Google Chrome", null, "96", true);

                  //add another rule check besides limit
                  etest.log(Status.INFO,"trying to add another rule besides the limit");
                  Thread.sleep(500);
                  Tab.clickSettings(driver);
                  Tab.clickLeadScoring(driver);
                  WebElement addButton = CommonUtil.getElement(driver,LEAD_SCORE_ID,LEAD_SCORE_ADD_BUTTON);
                  CommonWait.waitTillDisplayed(addButton);
                  CommonUtil.clickWebElement(driver,addButton);

                  WebElement popup = HandleCommonUI.getPopupByInnerText(driver,LEAD_RULE_LIMIT_EXCEED);
                  if(!checkPopup(driver,popup,"Lead Scoring",true,etest))
                  {
                        leadScoringRules = CommonUtil.getElement(driver,LEAD_SCORE_TAB).findElements(LEAD_SCORE_RULE_LIST).size();
                        failcount++;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Failure","Operator window screenshot",e);
            }
            finally
            {
                  if(failcount > 0)
                  {
                        etest.log(Status.FAIL,"Total no of lead scoring rules present are "+leadScoringRules);
                        TakeScreenshot.screenshot(driver,etest,"Lead Scoring","Failure","Operator window screenshot");
                        return false;
                  }
                  return true;
            }
      }

      public static boolean checkPopup(WebDriver driver,WebElement popup,String plan,boolean ok,ExtentTest etest) throws Exception
      {
            if(CommonWait.isDisplayed(popup))
            {
                  etest.log(Status.PASS,plan+" rule was not added after the limit for the plan was reached");
                  Thread.sleep(500);
              TakeScreenshot.screenshot(driver,etest,"UserWindow","checkPlan","AddAfterLimit",0);
                  HandleCommonUI.clickButtonInPopup(popup,ok);
                  return true;
            }
            etest.log(Status.FAIL,"A new "+plan+" rule was added even after the limit for the plan was reached");
            return false;
      }
      
      
      public static boolean checkIsPortalInFreePlan(WebDriver driver, ExtentTest etest) {

    	  String currentPlan = ExecuteStatements.getCurrentPlanName(driver);

    	  if (currentPlan == "Free") {
    	   etest.log(Status.INFO, "Portal is in Free Plan");

    	   return true;
    	  } else {
    	   etest.log(Status.INFO, "Portal is not in  Free Plan");
    	   return false;
    	  }

    	 }
      
      
      public static boolean checkChatWidgetFloatStickerChanges(WebDriver driver, ExtentTest etest, String website_name) throws Exception {
    	  try {

    	   WebEmbed.clickWebEmbed(driver, website_name, etest);
    	   WebsitesTab.clickLiveChat(driver, etest);
    	   WebsitesTab.clickWidget(driver, etest);
    	   FreePlanFloatWidget.clickFloatWidget(driver, etest);

    	   if (FreePlanFloatWidget.checkChatwidgetToggleStatusOn(driver, etest)) {
    	    etest.log(Status.PASS, "Chat Widget sticker change toggle is set On");
    	    TakeScreenshot.infoScreenshot(driver, etest);

    	   }

    	   if (!FreePlanFloatWidget.checkChatWidgetSticker(driver, etest)) {
    	    return false;
    	   }
    	   WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    	   VisitorWindow.createPage(visitor_driver, widget_code);
    	   if (FreePlanFloatWidget.checkChatWidgetStickerChangedinVisitorSide(visitor_driver, etest)) {
    	    etest.log(Status.FAIL, "Chat widget Sticker is Changed");
    	    TakeScreenshot.screenshot(visitor_driver, "Live Chat widget - Free Plan", "Change widget sticker", "sticker  Changed");
    	    return false;
    	   }
    	   etest.log(Status.PASS, "Chat widget Sticker is not Changed");
    	   TakeScreenshot.infoScreenshot(visitor_driver, etest);
    	   return true;

    	  } catch (Exception e) {
    	   TakeScreenshot.screenshot(driver, etest, "Chat widget in Free Plan - Float ", "Widget Sticker Change", "No Changes Found", e);
    	  }
    	  return false;
    	 }
   

      public static boolean checkChatWidgetFloatContentChanges(WebDriver driver, ExtentTest etest, String website_name) throws Exception {
       try {
        WebEmbed.clickWebEmbed(driver, website_name, etest);
        WebsitesTab.clickLiveChat(driver, etest);
        WebsitesTab.clickWidget(driver, etest);
        FreePlanFloatWidget.clickFloatWidget(driver, etest);
        FreePlanFloatWidget.clickContentButton(driver, etest);

        if (!FreePlanFloatWidget.checkContentChangeOnline(driver, etest)) {

         etest.log(Status.FAIL, "Online Message content is not changed in Operator Side");
         TakeScreenshot.screenshot(driver, "Chat Widget", "Online Content", "Not Changed");
         return false;
        }
        etest.log(Status.PASS, "Online Message content is changed in Operator Side");
        TakeScreenshot.infoScreenshot(driver, etest);

        WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
        VisitorWindow.createPage(visitor_driver, widget_code);

        if (!FreePlanFloatWidget.checkContentChangeOnlineVisitorside(visitor_driver, etest)) {
         etest.log(Status.FAIL, "Chat widget - Online Content is not Changed");
         TakeScreenshot.screenshot(visitor_driver, "Live Chat widget - Free Plan", "Change widget -Online Content", "Not  Changed");
         return false;
        }
        etest.log(Status.PASS, "Chat widget- Online Content is  Changed");
        TakeScreenshot.infoScreenshot(visitor_driver, etest);
        return true;


       } catch (Exception e) {
        TakeScreenshot.screenshot(driver, etest, "Chat widget in Free Plan - Float ", "Widget Sticker Change", "No Changes Found", e);
       }
       return false;
      }


      public static boolean checkChatWindowThemeAppearenceChanges(WebDriver driver, ExtentTest etest, String website_name) throws Exception {
       try {
        WebEmbed.clickWebEmbed(driver, website_name, etest);
        WebsitesTab.clickLiveChat(driver, etest);
        WebsitesTab.clickWidget(driver, etest);
        FreePlanFloatWidget.clickFloatWidget(driver, etest);
        FreePlanFloatWidget.clickChatWindAppearance(driver, etest);


        if (!FreePlanFloatWidget.checkWindowTheme(driver, etest)) {
         return false;
        }

        WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
        VisitorWindow.createPage(visitor_driver, widget_code);
        VisitorWindow.clickChatButton(visitor_driver);

        if (!FreePlanFloatWidget.checkVisitorWindowTheme(visitor_driver, etest)) {
         etest.log(Status.PASS, "Theme Id of Chat Window Appearence is not Changed ");
         TakeScreenshot.infoScreenshot(visitor_driver, etest);
         return true;
        }
        etest.log(Status.FAIL, "Chat widget theme appearence -  Changed");
        TakeScreenshot.screenshot(visitor_driver, "Live Chat widget - Free Plan", "Change widget -Appearence theme", "Changed");
        return false;
       } catch (Exception e) {
        TakeScreenshot.screenshot(driver, etest, "Chat widget in Free Plan - Float ", "Widget Sticker Change", "No Changes Found", e);
       }
       return false;
      }  
      
      
      
      
}
