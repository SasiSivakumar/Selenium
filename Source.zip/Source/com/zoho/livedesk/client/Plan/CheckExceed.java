//$Id$
package com.zoho.livedesk.client.Plan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;


public class CheckExceed {

	public static boolean planlimit(WebDriver driver,String plan,String tocheck,ExtentTest etest,String plan1,boolean accessible)throws Exception{
		try{
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
			
			WebElement dialogbox = CommonFunctionsPlanDiff.findElement(driver,"className","lvd_popupsub");
			String header = CommonFunctionsPlanDiff.findElement(dialogbox,"className","lvd_popuptitle").getText();
			String content = CommonFunctionsPlanDiff.findElement(dialogbox,"id","popupdesc").getText();
			String okbtn = CommonFunctionsPlanDiff.findElement(dialogbox,"id","okbtn").getText();
			String cancelbtn = CommonFunctionsPlanDiff.findElement(dialogbox,"id","cancelbtn").getText();
			WebElement close = CommonFunctionsPlanDiff.findElement(dialogbox,"id","dlgclose");
            if(CommonFunctionsPlanDiff.checkString1(header,ResourceManager.getRealValue(plan+"_"+tocheck+"_header"),etest))
				if(CommonFunctionsPlanDiff.checkString1(content,ResourceManager.getRealValue(plan+"_"+tocheck+"_content"),etest))
					if(CommonFunctionsPlanDiff.checkString1(okbtn,ResourceManager.getRealValue(plan+"_"+tocheck+"_okbtn"),etest))
						if(CommonFunctionsPlanDiff.checkString1(cancelbtn,ResourceManager.getRealValue(plan+"_"+tocheck+"_cancel"),etest))
						{
							if(accessible)
							{
								etest.log(Status.PASS,plan1+" - Contents for plan limitation alert for "+tocheck+" is checked");
								CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
								return true;
							}
							else
							{
								etest.log(Status.PASS,plan1+" - Contents in access restriction alert for "+tocheck+" is checked");
								CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
								return true;
							}
						}
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"MismatchContent");
			CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
			return false;
		}
		catch(Exception e){
			System.out.println("Exception while checking plan limit alert for "+tocheck+" - "+plan);
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"Error",e);
			driver.navigate().refresh();
			Thread.sleep(3000);
			return false;
		}
	}

    public static boolean planlimit1(WebDriver driver,String plan,String tocheck,ExtentTest etest,String plan1,boolean accessible)throws Exception{
        try{
            FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
            
            WebElement dialogbox = CommonFunctionsPlanDiff.findElement(driver,"className","lvd_popupsub");
            String header = CommonFunctionsPlanDiff.findElement(dialogbox,"className","lvd_popuptitle").getText();
            String content = dialogbox.getText();
            String okbtn = CommonFunctionsPlanDiff.findElement(dialogbox,"id","okbtn").getText();
            String cancelbtn = CommonFunctionsPlanDiff.findElement(dialogbox,"id","cancelbtn").getText();
            WebElement close = CommonFunctionsPlanDiff.findElement(dialogbox,"id","dlgclose");
            if(CommonFunctionsPlanDiff.checkString1(header,ResourceManager.getRealValue(plan+"_"+tocheck+"_header"),etest))
                if(content.contains(ResourceManager.getRealValue(plan+"_"+tocheck+"_content1")) && content.contains(ResourceManager.getRealValue("common_purchase")))
                {
                    if(CommonFunctionsPlanDiff.checkString1(okbtn,ResourceManager.getRealValue(plan+"_"+tocheck+"_okbtn"),etest))
                        if(CommonFunctionsPlanDiff.checkString1(cancelbtn,ResourceManager.getRealValue(plan+"_"+tocheck+"_cancel"),etest))
                        {
                            if(accessible)
							{
								etest.log(Status.PASS,plan1+" - Contents for plan limitation alert for "+tocheck+" is checked");
								CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
								return true;
							}
							else
							{
								etest.log(Status.PASS,plan1+" - Contents in access restriction alert for "+tocheck+" is checked");
								CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
								return true;
							}
                        }
                }
                else
                {
                    etest.log(Status.FAIL,"MismatchContent-Actual:"+content+"--Expected:"+ResourceManager.getRealValue(plan+"_"+tocheck+"_content1")+"--"+ResourceManager.getRealValue("common_purchase"));
                    TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"MismatchContent");
                    CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
                    return false;
                }
            TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"MismatchContent");
            CommonFunctionsPlanDiff.findElement(driver,"id","cancelbtn").click();
            return false;
        }
        catch(Exception e){
            System.out.println("Exception while checking plan limit alert for "+tocheck+" - "+plan);
            e.printStackTrace();
            TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }
    
    public static boolean enterpriseplanlimit(WebDriver driver,String plan,String tocheck,ExtentTest etest,String plan1,boolean accessible)throws Exception{
		try{
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("lvd_popupsub")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
			
			WebElement dialogbox = CommonFunctionsPlanDiff.findElement(driver,"className","lvd_popupsub");
			String header = CommonFunctionsPlanDiff.findElement(dialogbox,"className","lvd_popuptitle").getText();
			String content = CommonFunctionsPlanDiff.findElement(dialogbox,"id","popupdesc").getText();
			String okbtn = CommonFunctionsPlanDiff.findElement(dialogbox,"id","okbtn").getText();
			//String cancelbtn = CommonFunctionsPlanDiff.findElement(dialogbox,"id","cancelbtn").getText();
			WebElement close = CommonFunctionsPlanDiff.findElement(dialogbox,"id","dlgclose");
			if(CommonFunctionsPlanDiff.checkString1(header,ResourceManager.getRealValue(plan+"_"+tocheck+"_header"),etest))
				if(CommonFunctionsPlanDiff.checkString1(content,ResourceManager.getRealValue(plan+"_"+tocheck+"_content"),etest))
					if(CommonFunctionsPlanDiff.checkString1(okbtn,ResourceManager.getRealValue(plan+"_"+tocheck+"_okbtn"),etest))
						//if(CommonFunctionsPlanDiff.checkString1(cancelbtn,ResourceManager.getRealValue(plan+"_"+tocheck+"_cancel"),etest))
						{
							if(accessible)
							{
								etest.log(Status.PASS,plan1+" - Contents for plan limitation alert for "+tocheck+" is checked");
								CommonFunctionsPlanDiff.findElement(driver,"id","okbtn").click();
								return true;
							}
							else
							{
								etest.log(Status.PASS,plan1+" - Contents in access restriction alert for for "+tocheck+" is checked");
								CommonFunctionsPlanDiff.findElement(driver,"id","okbtn").click();
								return true;
							}
						}
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"MismatchContent");
			CommonFunctionsPlanDiff.findElement(driver,"id","okbtn").click();
			return false;
		}
		catch(Exception e){
			System.out.println("Exception while checking plan limit alert for "+tocheck+" - "+plan);
			e.printStackTrace();
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","PortalLimitFor"+plan,"Error",e);
			driver.navigate().refresh();
			Thread.sleep(3000);
			return false;
		}
	}

	public static boolean isPlanLimitPopupFound(WebDriver driver)
	{
		WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"Downgraded");
		return (popup!=null);
	}
}
