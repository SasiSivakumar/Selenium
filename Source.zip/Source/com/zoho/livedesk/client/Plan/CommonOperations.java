//$Id$
package com.zoho.livedesk.client.Plan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.common.*;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TakeScreenshot;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;

import java.util.concurrent.TimeUnit;
import java.net.*;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class CommonOperations {
    
    public static WebDriver setUp() throws Exception
    {
        return Functions.setUp();
    }

	public static boolean clickSettings(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
			WebElement settings = CommonFunctionsPlanDiff.findElement(driver,"id","menu_setting");
			settings.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickSettings","Error",e);
			return false;
		}
	}
	public static boolean clickVisitorHistory(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("suppm_visits")));
			WebElement visitorhistory = CommonFunctionsPlanDiff.findElement(driver,"id","suppm_visits");
			visitorhistory.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visit_mcontent")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickVisitorHistory","Error",e);
			return false;
		}
	}
	public static boolean navToDeptTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_department")));
			WebElement dept = CommonFunctionsPlanDiff.findElement(driver,"id","setting_sm_department");
			dept.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickDepartment","Error",e);
			return false;
		}
	}
	public static boolean navToPortalTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_configration")));
			WebElement portal = CommonFunctionsPlanDiff.findElement(driver,"id","setting_sm_configration");
			portal.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickPortal","Error",e);
			return false;
		}
	}
	public static boolean navToCompanyTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_company")));
			WebElement company = CommonFunctionsPlanDiff.findElement(driver,"id","setting_sm_company");
			company.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickCompanyTab","Error",e);
			return false;
		}
	}
	public static boolean navToIntegTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_integration")));
			WebElement integ = CommonFunctionsPlanDiff.findElement(driver,"id","setting_sm_integration");
			integ.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("integhome")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickIntegrationsTab","Error",e);
			return false;
		}
	}
	public static boolean navToAutomationTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
			WebElement auto = CommonFunctionsPlanDiff.findElement(driver,"id","setting_sm_automation");
			auto.click();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationtabs")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickAutomationTab","Error",e);
			return false;
		}
	}
	public static boolean navToTriggers(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!navToAutomationTab(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotriggerstab")));
			WebElement trigger = CommonFunctionsPlanDiff.findElement(driver,"className","autotriggerstab");
			trigger.click();
			
			wait.until(new Function<WebDriver, Boolean>() {
                public Boolean apply(WebDriver driver) {
                    String url = driver.getCurrentUrl();
                    if(url.contains("#setting/automation/triggers"))
                    	return true;
                    return false;
                }
            });

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
			
			Thread.sleep(2000);
            
            return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickIntelligentTriggersTab","Error",e);
			return false;
		}
	}
	public static boolean navToVisitorRouting(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!navToAutomationTab(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoroutingrulestab")));
			WebElement routing = CommonFunctionsPlanDiff.findElement(driver,"className","autoroutingrulestab");
			routing.click();
			
			wait.until(new Function<WebDriver, Boolean>() {
                public Boolean apply(WebDriver driver) {
                    String url = driver.getCurrentUrl();
                    if(url.contains("#setting/automation/routingrules"))
                    	return true;
                    return false;
                }
            });

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
			
			Thread.sleep(2000);
            
            return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickVisitorRoutingTab","Error",e);
			return false;
		}
	}
	public static boolean navToEmailSchedule(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!navToAutomationTab(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoschedulertab")));
			WebElement schedule = CommonFunctionsPlanDiff.findElement(driver,"className","autoschedulertab");
			schedule.click();
			
			wait.until(new Function<WebDriver, Boolean>() {
                public Boolean apply(WebDriver driver) {
                    String url = driver.getCurrentUrl();
                    if(url.contains("#setting/automation/scheduler"))
                    	return true;
                    return false;
                }
            });

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
			
			Thread.sleep(2000);
            
            return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickEmailScheduleTab","Error",e);
			return false;
		}
	}
	public static boolean clickReports(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_report")));
			WebElement reports = CommonFunctionsPlanDiff.findElement(driver,"id","menu_report");
			reports.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("report_sm_overview")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickReports","Error",e);
			return false;
		}
	}
	public static boolean navToEmbedTab(WebDriver driver,ExtentTest etest) throws Exception{
		try{
			if(!clickSettings(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,10,250);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));
			WebElement embed = CommonFunctionsPlanDiff.findElement(driver,"id","setting_sm_embedchats");
			embed.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
			return true;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","ClickEmbed","Error",e);
			return false;
		}
	}

}
