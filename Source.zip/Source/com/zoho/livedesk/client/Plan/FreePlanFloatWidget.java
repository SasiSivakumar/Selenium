//$Id$
package com.zoho.livedesk.client.Plan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Websites;
import com.zoho.livedesk.util.common.actions.WebsitesTab;



public class FreePlanFloatWidget {

 public static String defaultThemeId = "1";
 public static String changedThemeId = "4";
 public static String onlineMessageText = "Hi " + CommonUtil.getUniqueMessage() + " !!!";
 public static String bylineMessageText = "How I Shall help" + CommonUtil.getUniqueMessage();
 public static String changeWindowThemeId = "4";


 public static void clickFloatWidget(WebDriver driver, ExtentTest etest) throws Exception {
  CommonWait.waitTillDisplayed(driver, By.xpath("//span[@widget='float']"));
  CommonUtil.elfinder(driver, "xpath", "//span[@widget='float']").click();
  WebsitesTab.waitTillLoaded(driver, "apperance");
  etest.log(Status.INFO, "Float widget is clicked");
  driver.switchTo().defaultContent();
  Websites.clickSave(driver, etest, false);
 }

 public static void clickContentButton(WebDriver driver, ExtentTest etest) throws Exception {
  CommonWait.waitTillDisplayed(driver, By.xpath("//span[@subtab='content']"));
  CommonUtil.elfinder(driver, "xpath", "//span[@subtab='content']").click();
  etest.log(Status.INFO, "Content is clicked");
 }

 public static void clickChatWindAppearance(WebDriver driver, ExtentTest etest) throws Exception {
  CommonWait.waitTillDisplayed(driver, By.id("emleftnav"));
  CommonUtil.clickWebElement(driver, By.cssSelector("[documentclick='chatWindowConfig']"));
  CommonUtil.clickWebElement(driver, By.cssSelector("[documentclick='cwApperance']"));
  etest.log(Status.INFO, "ChatWindow - Appearance is clicked");
 }

 public static boolean checkChatwidgetToggleStatusOn(WebDriver driver, ExtentTest etest) {
  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[class*='set_on']"))) {
   etest.log(Status.INFO, "Chat widget sticker Toogle ON");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  } else {
   etest.log(Status.INFO, "Chat widget sticker Toogle OFF");
   TakeScreenshot.infoScreenshot(driver, etest);
   return false;
  }
 }

 public static boolean checkChatWidgetSticker(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("embedthemelist")); 
  WebElement themeIdofCurrentSticker = CommonUtil.getElement(driver, By.className("sml_emtm sel"));
  CommonWait.waitTillDisplayed(themeIdofCurrentSticker);
  String getAttributeofCurrentTheme = themeIdofCurrentSticker.getAttribute("themeid");
  etest.log(Status.INFO, "ThemeId of Current Sticker is " + getAttributeofCurrentTheme);
  WebElement mouseHoverOnArrow = CommonUtil.getElement(driver, By.id("embedthemelist"));
  WebElement clickStickertoRightArrow = CommonUtil.getElement(driver, By.cssSelector("[documentclick='toggleFloatWindow'][class*='sqico-back floatrg']"));
  CommonWait.waitTillDisplayed(clickStickertoRightArrow);
  CommonUtil.clickWebElement(driver, clickStickertoRightArrow);
  CommonUtil.clickWebElement(driver, By.cssSelector("[documentclick='saveEmbedConfig']"));
  etest.log(Status.PASS, "Right Arrow clicked and Theme Changed");
  TakeScreenshot.infoScreenshot(driver, etest);

  if (getChangedThemeId(driver, etest) != defaultThemeId) {
   etest.log(Status.INFO, "Default theme :" + defaultThemeId + " changed to :" + getChangedThemeId(driver, etest));
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  } else {
   etest.log(Status.FAIL, "Theme Id " + getChangedThemeId(driver, etest) + " not Found");
   TakeScreenshot.screenshot(driver, "Live Chat widget - Free Plan", "Change widget sticker", "sticker not Found");
   return false;
  }

 }

 public static String getChangedThemeId(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("embedthemelist"));
  WebElement themeIdofCurrentSticker = CommonUtil.getElement(driver, By.className("sml_emtm sel"));
  String getChangedThemeId = themeIdofCurrentSticker.getAttribute("themeid");
  etest.log(Status.INFO, "Changed ThemeId of Chat Widget sticker : " + getChangedThemeId);
  TakeScreenshot.infoScreenshot(driver, etest);
  return getChangedThemeId;
 }

 public static boolean checkChatWidgetStickerChangedinVisitorSide(WebDriver driver, ExtentTest etest) {
  String getChangedThemeId = getChangedThemeId(driver, etest);

  CommonWait.waitTillDisplayed(driver, By.id("zsiqwidget"));
  if (CommonWait.isPresent(driver, By.cssSelector("[class*='zsiq_theme'" + getChangedThemeId + "]"))) {

   etest.log(Status.INFO, "Theme with themeId " + getChangedThemeId + " is changed in Visitor side Window");
   TakeScreenshot.infoScreenshot(driver, etest);
   return true;
  }
  etest.log(Status.INFO, "Theme with themeId " + getChangedThemeId + " is not changed in Visitor side Window");
  TakeScreenshot.infoScreenshot(driver, etest);
  return false;

 }


 public static boolean checkContentChangeOnline(WebDriver driver, ExtentTest etest) {

  if (CommonWait.waitTillDisplayed(driver, By.id("emmiddlenav"))) {
   etest.log(Status.INFO, "Customize the Message on Chat Widget section Found");
   return true;
  }

  CommonUtil.clickWebElement(driver, By.cssSelector("[documentclick='toggleMessageConfig'][prop='online']"));
  WebElement onlineMessage = CommonUtil.getElement(driver, By.cssSelector("[field='online']"), By.className("float_msg"));
  CommonUtil.click(driver, onlineMessage);
  etest.log(Status.INFO, "Online Message for Widget is Clicked");
  TakeScreenshot.infoScreenshot(driver, etest);

  if (CommonWait.waitTillDisplayed(driver, By.cssSelector("[placeholder='We're Online!']"))) {
      CommonUtil.sendKeysToWebElement(driver, CommonUtil.getElement(driver, By.cssSelector("[placeholder='We're Online!']")), onlineMessageText);
      etest.log(Status.INFO, "Online Message for Widget is changed");
      TakeScreenshot.infoScreenshot(driver, etest);
      return true;
  }

  WebElement bylineMessage = CommonUtil.getElement(driver, By.cssSelector("[field='online_byline']"), By.className("float_msg"));
  CommonUtil.click(driver, bylineMessage);
  CommonUtil.clickWebElement(driver, By.cssSelector("[documentclick='saveEmbedConfig']"));
  etest.log(Status.INFO, "Byline Message for Widget is changed");


  etest.log(Status.FAIL, "Message for Widget is not changed");
  return false;

 }


 public static boolean checkContentChangeOnlineVisitorside(WebDriver visdriver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(visdriver, By.id("zsiqwidget"));

  if (CommonWait.waitTillDisplayed(visdriver, By.id("titlediv"))) {
   return true;
  }

  WebElement title = CommonUtil.getElement(visdriver, By.id("zsiq_maintitle"));

  if (title.getText() == onlineMessageText) {

   etest.log(Status.PASS, "Online Message title Content " + onlineMessageText + " is changed in Visitor Window");
   TakeScreenshot.infoScreenshot(visdriver, etest);

  } else {
   etest.log(Status.PASS, "Online Message title Content " + onlineMessageText + " is not  changed in Visitor Window");
   TakeScreenshot.screenshot(visdriver, "Chat Widget", "Online Content", "Not Changed");
   return false;
  }

  WebElement byline = CommonUtil.getElement(visdriver, By.id("zsiq_byline"));

  if (byline.getText() == bylineMessageText) {

   etest.log(Status.PASS, "Byline Message Content " + bylineMessageText + " is changed in Visitor Window");
   TakeScreenshot.infoScreenshot(visdriver, etest);
   return true;
  } else {
   etest.log(Status.PASS, "Byline Message title Content " + bylineMessageText + " is not  changed in Visitor Window");
   TakeScreenshot.screenshot(visdriver, "Chat Widget", "Byline Content", "Not Changed");
   return false;
  }
 }


 public static boolean checkWindowTheme(WebDriver driver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(driver, By.id("themeid_header"));

  if (!CommonWait.waitTillDisplayed(driver, By.id("embedthemelist"))) {
   etest.log(Status.FAIL, "Theme List is not  displayed");
   TakeScreenshot.screenshot(driver, "Chat Widget - Free Plan", "Embed theme List", "Not Displayed");
   return false;
  }
  WebElement mouseHoverOnArrow = CommonUtil.getElement(driver, By.id("embedthemelist"));
  WebElement clickThemetoLeftArrow = CommonUtil.getElement(driver, By.cssSelector("[documentclick='toggleFloatWindow'][class*='sqico-back']"));
  CommonWait.waitTillDisplayed(mouseHoverOnArrow);
  CommonUtil.mouseHover(driver, mouseHoverOnArrow);
  CommonWait.waitTillDisplayed(clickThemetoLeftArrow);
  CommonUtil.clickWebElement(driver, clickThemetoLeftArrow);
  CommonUtil.clickWebElement(driver, By.cssSelector("[documentclick='saveEmbedConfig']"));

  etest.log(Status.PASS, "Left Arrow clicked and Theme Changed");
  TakeScreenshot.infoScreenshot(driver, etest);
  return true;
 }


 public static boolean checkVisitorWindowTheme(WebDriver visdriver, ExtentTest etest) {

  CommonWait.waitTillDisplayed(visdriver, By.id("siqcht"));
  WebElement iframe = CommonUtil.getElement(visdriver, By.id("siqiframe"));
  visdriver.switchTo().frame(iframe);
  if (CommonWait.waitTillDisplayed(visdriver, By.cssSelector("[id='window-ribbon'][themeid='" + changeWindowThemeId + "']"))) {
   visdriver.switchTo().defaultContent();
   etest.log(Status.INFO, "Visitor Chat window Theme " + changeWindowThemeId + " is Changed.");
   TakeScreenshot.infoScreenshot(visdriver, etest);
   return true;
  }
  etest.log(Status.INFO, "Visitor Chat window Theme " + changeWindowThemeId + " is not Changed.");
  TakeScreenshot.infoScreenshot(visdriver, etest);
  return false;

 }




}