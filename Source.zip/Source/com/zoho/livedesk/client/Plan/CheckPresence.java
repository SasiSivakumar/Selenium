//$Id$
package com.zoho.livedesk.client.Plan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TakeScreenshot;

import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;

public class CheckPresence {

	public static boolean checkContentInPortalSettings(WebDriver driver,String plan,String tocheck,boolean exists,ExtentTest etest) throws Exception{
		boolean presence = false;
		try{
			if(!CommonOperations.navToPortalTab(driver,etest))
				return false;
			
			WebElement portal = CommonFunctionsPlanDiff.findElement(driver,"id","portaleditmodule");
			try{
				WebElement content = portal.findElement(By.id(tocheck));
				presence = true;
				Coordinates ord = ((Locatable)content).getCoordinates();
				ord.inViewPort();
			}
			catch(Exception e){
			}
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","Check"+tocheck,"Error",e);
			return false;
		}
		if(exists==presence){
			etest.log(Status.PASS,plan+" plan - presence of "+tocheck+" is "+exists);
			return true;
		}
		etest.log(Status.FAIL, "Mismatch for the plan:"+plan+" as "+tocheck+" exists should be:"+exists);
		TakeScreenshot.screenshot(driver,etest,"PlanDifference","Check"+tocheck,"PresenceMismatch");
		return false;
	}
	public static boolean checkBusinessHour(WebDriver driver,boolean exists,String plan,ExtentTest etest) throws Exception{
		boolean businessexists = false;
		try{
			WebElement comp = CommonFunctionsPlanDiff.findElement(driver,"id","recorddetail");
			try{
				WebElement business = comp.findElement(By.id("bhdisablelnk"));
				businessexists = true;
				Coordinates ord = ((Locatable)business).getCoordinates();
				ord.inViewPort();
			}
			catch(Exception e){
			}
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckBusinessHour","Error",e);
			return false;
		}
		if(exists==businessexists){
			etest.log(Status.PASS,plan+" plan - presence of Business Hour is "+exists);
			return true;
		}
		etest.log(Status.FAIL, "Business Hour mismatch for the plan:"+plan+" as business hour exists should be:"+exists);
		TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckTranslation","PortalPresenceMismatch");
		return false;
	}
	public static boolean checkReportPresence(WebDriver driver,String tocheck,ExtentTest etest){
		try{
			if(!CommonOperations.clickReports(driver,etest))
				return false;
			FluentWait wait = CommonFunctionsPlanDiff.waitreturner(driver,30,250);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("reprts-infomn")));
			CommonFunctionsPlanDiff.findElement(driver,"id","report_sm_"+tocheck).click();
			Thread.sleep(3000);
			WebElement reports = CommonFunctionsPlanDiff.findElement(driver,"className","reprts-infomn");
			String line1 = CommonFunctionsPlanDiff.findElement(reports,"className","reprts-inftxt").getText();
			String line2 = CommonFunctionsPlanDiff.findElement(reports,"className","reprts-infsbtxt").getText();
			String button = CommonFunctionsPlanDiff.findElement(reports,"className","grn-btn").getText();
			if(CommonFunctionsPlanDiff.checkString1(line1,ResourceManager.getRealValue("upgrade_reports1"),etest))
				if(CommonFunctionsPlanDiff.checkString1(line2,ResourceManager.getRealValue("upgrade_reports2"),etest))
					if(CommonFunctionsPlanDiff.checkString1(button,ResourceManager.getRealValue("upgrade_reportsbutton"),etest))
					{
						etest.log(Status.PASS,"Upgrade Contents Checked");
						return true;
					}
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckReports"+tocheck,"MismatchContent");
			return false;
		}
		catch(Exception e){
			TakeScreenshot.screenshot(driver,etest,"PlanDifference","CheckReports"+tocheck,"Error",e);
			return false;
		}
	}
}
