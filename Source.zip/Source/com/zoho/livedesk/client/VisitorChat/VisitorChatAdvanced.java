//$Id$
package com.zoho.livedesk.client.VisitorChat;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;


public class VisitorChatAdvanced
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Visitor Chat Advanced";
	public static String WIDGET_CODE="",WEBSITE_NAME="";

	public static VisitorDriverManager visitor_driver_manager;

	//modify visitor info actions
	public static final String
	CREATE="CREATE",
	UPDATE="UPDATE",
	CANCEL="CANCEL";

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA1",checkIllegalFileUpload(driver,etest,WIDGET_CODE,FileType.XSS_FILE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA11",checkIllegalFileUpload(driver,etest,WIDGET_CODE,FileType.UPLOAD_LIMIT_FILE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA2"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA2",checkSendingMultipleMessageBeforeAcceptingChat(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA3",checkPreviousRatingInAcceptChatContainer(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA4"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA4",checkModifyVisitorInfo(driver,etest,WIDGET_CODE,CREATE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA5"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA5",checkModifyVisitorInfo(driver,etest,WIDGET_CODE,UPDATE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA6",checkModifyVisitorInfo(driver,etest,WIDGET_CODE,CANCEL));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check mute and unmute chat");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkMuteChat(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA9",checkShareURLRealTime(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VCA10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VCA10",checkAcceptedChatOpenedWhenPreviousChatIsOpen(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}            
	}

	public static boolean checkIllegalFileUpload(WebDriver driver,ExtentTest etest,String widget_code,FileType file_type) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			if(file_type==FileType.UPLOAD_LIMIT_FILE)
			{
				FileUpload.createFileForCheckingUploadLimit();
			}
			else if(file_type==FileType.XSS_FILE)
			{
				FileUpload.createDummyFile(file_type.file_name,1);
			}
			
			visitor_driver=visitor_driver_manager.getDriver(driver);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

	        VisitorWindow.uploadFile(visitor_driver,file_type);

	        if(file_type==FileType.XSS_FILE)
	        {
	        	try
	        	{
			        if(!VisitorWindow.checkFileNotUpload(visitor_driver,etest))
			        {
			        	etest.log(Status.PASS,"XSS file was not uploaded.");
			        }
			        else
			        {
			        	etest.log(Status.FAIL,"XSS file was uploaded.");
			        	TakeScreenshot.screenshot(driver,etest);
			        	failcount++;
			        }
			    }
			    catch(Exception e)
			    {
			    	etest.log(Status.PASS,"XSS file was not uploaded.");
			    }
	        }
	        else if(file_type==FileType.UPLOAD_LIMIT_FILE)
	        {	        	
	        	String upload_limit_text=ResourceManager.getRealValue("upload_limit_exceeded").replace("<file_name>",file_type.file_name).replace("<upload_limit_in_mb>",""+FileUpload.upload_limit_in_mb);

	        	if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visitor_driver,upload_limit_text))
	        	{
	        		etest.log(Status.PASS,"Text '"+upload_limit_text+"' was found after visitor tried upload a file more than "+FileUpload.upload_limit_in_mb+" MB");
	        	}
	        	else
	        	{
	        		etest.log(Status.FAIL,"Text '"+upload_limit_text+"' was NOT found after visitor tried upload a file more than "+FileUpload.upload_limit_in_mb+" MB");	        		
	        		failcount++;
	        		TakeScreenshot.screenshot(driver,etest);
	        	}
	        }
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkSendingMultipleMessageBeforeAcceptingChat(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		String
		message1="message1"+label,
		message2="message2"+label,
		message3="message3"+label;

		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);
	        VisitorWindow.sentMessageInTheme(visitor_driver,message1);
	        CommonUtil.sleep(2000);

	        VisitorWindow.sentMessageInTheme(visitor_driver,message1,false,true);
	        VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",message1,2);

	        VisitorWindow.sentMessageInTheme(visitor_driver,message2);
	        VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",message2,3);
	        
	        VisitorWindow.sentMessageInTheme(visitor_driver,message3);
	        VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",message3,4);

	        ChatWindow.acceptChat(driver,etest);

	        if(ChatWindow.checkMessageInUserWindow(driver,"",message1) && ChatWindow.checkMessageInUserWindow(driver,"",message2) && ChatWindow.checkMessageInUserWindow(driver,"",message3))
	        {
	        	etest.log(Status.PASS,"All of the messages  '"+message1+"','"+message2+"' and '"+message3+"' which were sent before agent accepted the chat was recieved in agent side");
	        }
	        else
	        {
	        	failcount++;
	        	etest.log(Status.FAIL,"All of the messages  '"+message1+"','"+message2+"' and '"+message3+"' which were sent before agent accepted the chat was NOT recieved in agent side");
	        	TakeScreenshot.screenshot(driver,etest);
	        }
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkPreviousRatingInAcceptChatContainer(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

			int average_rating,sum=0;

			Hashtable<String,String> visitor_details=null;

			for(int i=1;i<=5;i++)
			{
		        visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,""+i);
		        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);
			}

			for(int i=1;i<=5;i++)
			{
				sum=sum+i;
			}

			average_rating=sum/5;

			etest.log(Status.INFO,"Expected average rating :"+average_rating);

	        VisitorWindow.createPage(visitor_driver,widget_code);

	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

	        int actual_average_rating=ChatWindow.getAverageRatingFromAcceptChatContainer(driver);

	        if(CommonUtil.checkStringEqualsAndLog(""+average_rating,""+actual_average_rating,"average rating of the last 5 chats",etest)==false)
	        {
	        	failcount++;
	        }

	        ChatWindow.acceptChat(driver,etest);
	        ChatWindow.endAndCloseChat(driver);
            ChatWindow.closeAllChats(driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkModifyVisitorInfo(WebDriver driver,ExtentTest etest,String widget_code,String action) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

			Hashtable<String,String> visitor_details=null;

			if(action.equals(CREATE))
			{
	        	visitor_details=ConversationViewCommonFunctions.addVisitorDetails(null,null,null,null,"Q"+label+"?",null,null);
			}
			else if(action.equals(UPDATE) || action.equals(CANCEL))
			{
		        visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"v"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?",null,null);
			}

	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);
	        TakeScreenshot.infoScreenshot(visitor_driver,etest);

	        boolean isUpdate;

	        if(action.equals(CREATE) || action.equals(UPDATE))
	        {
	        	isUpdate=true;
	        }
	        else
	        {
	        	isUpdate=false;
	        }

	       	final String
		 	new_label=CommonUtil.getUniqueMessage(),
		 	new_name="V"+new_label,
		 	new_mail="v"+new_label+"@email.com",
		 	new_phone=new_label;

	        if(VisitorWindow.editVisitorInfo(visitor_driver,isUpdate,new_name,new_mail,new_phone))
	        {
	        	etest.log(Status.PASS,"Visitor info was "+ (isUpdate?"updated":"NOT updated") +" in visitor side" );
	        }
	        else
	        {
	        	etest.log(Status.FAIL,"Visitor info was "+ (isUpdate?"NOT updated":"updated") +" in visitor side" );
	        	TakeScreenshot.screenshot(driver,etest);
	        	failcount++;
	        }

	        if(isUpdate)
	        {
	        	//visitor side

	        	CommonUtil.sleep(1000);

	        	//deprecated in new UI
	        	// try
	        	// {
	        	// 	VisitorWindow.waitTillMessageInChat(visitor_driver,ResourceManager.getRealValue("all_visitor_info_updated_info_message"));
	        	// 	etest.log(Status.PASS,"Info message "+ResourceManager.getRealValue("all_visitor_info_updated_info_message")+" was found in visitor side");
	        	// }
	        	// catch(Exception e1)
	        	// {
	        	// 	failcount++;
	        	// 	TakeScreenshot.screenshot(visitor_driver,etest);
	        	// 	etest.log(Status.FAIL,"Info message "+ResourceManager.getRealValue("all_visitor_info_updated_info_message")+" was not found in visitor side");
	        	// }

	        	//agent side
	        	if(ChatWindow.waitTillMessageInChat(driver,ResourceManager.getRealValue("all_visitor_info_updated_agent_info"))==false)
	        	{
	        		etest.log(Status.FAIL,"Info message "+ResourceManager.getRealValue("all_visitor_info_updated_agent_info")+" was not found in agent side");
	        		failcount++;
	        		TakeScreenshot.screenshot(driver,etest);
	        	}
	        	else
	        	{
	        		etest.log(Status.PASS,"Info message "+ResourceManager.getRealValue("all_visitor_info_updated_agent_info")+" was found in agent side");
	        	}

	        	etest.log(Status.INFO,"Now checking if visitor data is updated in agent side");
	        	driver.navigate().refresh();
	        	CommonWait.waitTillDisplayed(visitor_driver, By.id("cvemail"));
	        	
	        	if(ChatHistoryChat.verifyChatData(driver,etest,null,new_name,new_mail,new_phone)==false)
	        	{
	        		TakeScreenshot.screenshot(driver,etest);
	        		failcount++;
	        	}	
	        }			
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static void checkMuteChat(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		int mute_failcount=0,unmute_failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

	       	VisitorWindow.muteChat(visitor_driver);
	       	etest.log(Status.INFO,"Chat was muted in visitor side");

	       	visitor_driver.switchTo().defaultContent();

	       	CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,By.tagName("body")));

	       	if(VisitorWindow.isChatMuted(visitor_driver))
	       	{
	       		etest.log(Status.PASS,"Muted chat icon was found after chat was muted");
	       	}
	       	else
	       	{
	       		etest.log(Status.FAIL,"Muted chat icon was NOT found after chat was muted");
	       		TakeScreenshot.screenshot(visitor_driver,etest);
	       		mute_failcount++;
	       	}

   	        VisitorWindow.clickMoreActions(visitor_driver);
   	        WebElement mute_dropdown_element=VisitorWindow.getActionContainerFromMoreActions(visitor_driver,VisitorWindow.UNMUTE);
   	        if(mute_dropdown_element!=null && CommonUtil.hasClass(mute_dropdown_element,VisitorWindow.UNMUTE_CLASS_NAME))
   	        {
   	        	etest.log(Status.PASS,"'"+VisitorWindow.UNMUTE+"' was found in more actions dropdown with classname '"+VisitorWindow.UNMUTE_CLASS_NAME+"' after chat was muted");
   	        }
   	        else
   	        {
   	        	etest.log(Status.FAIL,"'"+VisitorWindow.UNMUTE+"' was NOT found in more actions dropdown with classname '"+VisitorWindow.UNMUTE_CLASS_NAME+"' after chat was muted");
	       		TakeScreenshot.screenshot(visitor_driver,etest);
	       		mute_failcount++;
   	        }
   	        result.put("VCA7",CommonUtil.returnResult(mute_failcount));
   	        VisitorWindow.focusMessageInput(visitor_driver);//to close more actions

	       	VisitorWindow.unmuteChat(visitor_driver);
	       	etest.log(Status.INFO,"Chat was unmuted in visitor side");

	       	if(!VisitorWindow.isChatMuted(visitor_driver))
	       	{
	       		etest.log(Status.PASS,"Muted chat icon was NOT found after chat was unmuted");
	       	}
	       	else
	       	{
	       		etest.log(Status.FAIL,"Muted chat icon was found after chat was unmuted");
	       		TakeScreenshot.screenshot(visitor_driver,etest);
	       		unmute_failcount++;
	       	}

   	        VisitorWindow.clickMoreActions(visitor_driver);
   	        mute_dropdown_element=VisitorWindow.getActionContainerFromMoreActions(visitor_driver,VisitorWindow.MUTE);
   	        if(mute_dropdown_element!=null && CommonUtil.hasClass(mute_dropdown_element,VisitorWindow.MUTE_CLASS_NAME))
   	        {
   	        	etest.log(Status.PASS,"'"+VisitorWindow.MUTE+"' was found in more actions dropdown with classname '"+VisitorWindow.MUTE_CLASS_NAME+"' after chat was unmuted");
   	        }
   	        else
   	        {
   	        	etest.log(Status.FAIL,"'"+VisitorWindow.MUTE+"' was NOT found in more actions dropdown with classname '"+VisitorWindow.MUTE_CLASS_NAME+"' after chat was unmuted");
	       		TakeScreenshot.screenshot(visitor_driver,etest);
	       		unmute_failcount++;
   	        }
   	        result.put("VCA8",CommonUtil.returnResult(unmute_failcount));
   	        VisitorWindow.focusMessageInput(visitor_driver);//to close more actions
		}

		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}
	}

	public static boolean checkShareURLRealTime(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		final String
		url1="www.wikipedia.org",
		url2="www.zoho.com";

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

			ChatWindow.shareURL(driver,url1);
			VisitorWindow.openSharedURL(visitor_driver);

			CommonUtil.sleep(1000);

			CommonUtil.switchToTab(visitor_driver);

			String actual_url1=visitor_driver.getCurrentUrl();

			if(CommonUtil.checkStringContainsAndLog(url1,actual_url1,"shared url 1",etest)==false)
			{
				failcount++;
			}

			ChatWindow.shareURL(driver,url2);

			String actual_url2=CommonWait.waitTillURLChanges(visitor_driver,actual_url1);

			if(CommonUtil.checkStringContainsAndLog(url2,actual_url2,"shared url 2",etest)==false)
			{
				failcount++;
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkAcceptedChatOpenedWhenPreviousChatIsOpen(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		int failcount=0;

		String label=CommonUtil.getUniqueMessage();

		WebDriver visitor_driver=null;

		try
		{
			visitor_driver=visitor_driver_manager.getDriver(driver);

	        Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
	        String unique_id=ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED,visitor_details,null);

	        label=CommonUtil.getUniqueMessage();//new label
	        visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Q"+label+"?","fb"+label,"3");
			ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

			ConversationViewCommonFunctions.goToAllChats(visitor_driver);

	        ConversationViewCommonFunctions.openChatByUniqueId(visitor_driver,ChatType.COMPLETED,unique_id);
	        etest.log(Status.INFO,"Previous chat was opened after chat was not initated");

	        ChatWindow.acceptChat(driver,etest);

			if(VisitorWindow.isCurrentChatDisplayed(visitor_driver))
			{
				etest.log(Status.PASS,"Current chat was shown after agent accepted the chat");
			}
			else
			{
				etest.log(Status.FAIL,"Current chat was NOT shown after agent accepted the chat");	
				TakeScreenshot.screenshot(driver,etest);
				failcount++;			
			}
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);			
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);			
		}
		finally
		{

		}

		return CommonUtil.returnResult(failcount);
	}
}
