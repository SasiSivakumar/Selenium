//$Id$
package com.zoho.livedesk.client.VisitorChat;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.VisitorChat.VisitorEndTests;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;

import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;

public class VisitorEndCommonFunctions
{

	public static VisitorDriverManager visitor_driver_manager = new VisitorDriverManager();

	public static final By
	MESSAGE_AREA = By.id("msgarea"),
	MORE_ACTIONS = By.id("mraction"),
	FEEDBACK_DIV = By.className("clblck"),
	SEND_EMAIL_ICON = By.className("sqico-smail"),
	VISITOR_SIDE_BANNER_DIV = By.id("consentbannerdiv"),
	VISITOR_SIDE_MESSAGE_TIME = By.className("msgbx"),
	VISITOR_MESSAGE = By.className("siq-visitor-message")
	;

	public static String more_options[] = {"sqico-attach","sqico-mute","sqico-smailico","sqico-print"};

	public static boolean checkVisitorChatWindow(WebDriver driver,ExtentTest etest,String widgetcode,boolean isEnded,boolean isMoreAction,int limit) throws Exception
	{
		int failcount = 0;
		String sessionend = "endsession_"+limit+"secs";
		String label = CommonUtil.getUniqueMessage();
		String content = "";
    	WebDriver visitor_driver = visitor_driver_manager.getDriver(driver);
    	ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label,false,ChatType.ONGOING);

    	if(isMoreAction)
    	{
        	VisitorWindow.switchToChatWidget(visitor_driver);
			VisitorWindow.clickMoreActions(visitor_driver);
    		List<WebElement> options = CommonUtil.getElement(visitor_driver,MORE_ACTIONS).findElements(By.tagName("li"));
    		content = CommonUtil.getElementByAttributeValue(options,"class",more_options[limit]).getText();
    		if(limit == 0)
    		{
				CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,MESSAGE_AREA));
    			CommonUtil.mouseHover(visitor_driver,CommonUtil.getElement(visitor_driver,VISITOR_MESSAGE));
    			CommonUtil.sleep(1000);
    			if(CommonUtil.getElement(visitor_driver,VISITOR_SIDE_MESSAGE_TIME).getAttribute("title").length() == 0)
    			{
    				etest.log(Status.PASS,"Message time was shown on hovering over the message in the visitor side");
    				VisitorEndTests.result.put("VE14",true);
    			}
    			else
    			{
    				etest.log(Status.FAIL,"Message time was not shown on hovering over the message in the visitor side");
    				TakeScreenshot.screenshot(visitor_driver,etest);
    				VisitorEndTests.result.put("VE14",false);
    			}
				FileType file_type=FileType.IMAGE;
				WebElement attach_file_input=VisitorWindow.getAttachFileInputElement(visitor_driver);
				FileUpload.uploadFile(attach_file_input,file_type);
				VisitorWindow.waitTillMoreActionDropdownIsDisplayed(visitor_driver,false);
				CommonUtil.sleep(1000);
    		}
    		else
    		{
    			CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElementByAttributeValue(options,"class",more_options[limit]));
        		VisitorWindow.waitTillMoreActionDropdownIsDisplayed(visitor_driver,false);
    			
    			if(limit == 2)
    			{
    				TakeScreenshot.infoScreenshot(visitor_driver,etest);
    				CommonWait.waitTillDisplayed(visitor_driver,SEND_EMAIL_ICON);
    				CommonSikuli.findInWholePage(visitor_driver,"UI374.png","UI374",etest);
    				CommonSikuli.findInWholePage(visitor_driver,"UI375.png","UI375",etest);
    				CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,SEND_EMAIL_ICON));
    				VisitorEndTests.result.put("VE16",checkBannerDiv(visitor_driver,ResourceManager.getRealValue("Theme.sendemail.content").replace("LABEL",label),"Email Confirmation",etest));
    			}
    			if(limit == 3)
    			{
    				CommonUtil.switchToTab(visitor_driver,1);
    				CommonUtil.closeCurrentTab(visitor_driver);
    				CommonUtil.switchToTab(visitor_driver,0);
		        	VisitorWindow.switchToChatWidget(visitor_driver);
    			}
    		}

			CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,MESSAGE_AREA));
			CommonUtil.sleep(1000);
			VisitorWindow.endChatVisitor(visitor_driver);
			CommonUtil.sleep(1000);
        	VisitorWindow.switchToChatWidget(visitor_driver);

			if(CommonUtil.checkStringContainsAndLog(CommonUtil.getElement(visitor_driver,FEEDBACK_DIV).getText(),ResourceManager.getRealValue("feedback_header"),"FeedBack description",etest))
			{
				etest.log(Status.PASS,"Chat ended after clicking '"+content+"' from more actions icon in visitor end");
			}
			else
			{
				etest.log(Status.FAIL,"Chat did not end after clicking '"+content+"' from more actions icon in visitor end");
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
				failcount++;
			}
	    }
	    else
	    {
	    	CommonFunctions.endChatUser(driver,ResourceManager.getRealValue(sessionend));

	    	if(isEnded)
	    	{
	    		if(VisitorWindow.checkEndTimer(visitor_driver,limit,true,true,etest))
	        	{
	        	    etest.log(Status.PASS,"Chat ended after "+limit+" limit");
	        	}
	        	else
	        	{
	        		etest.log(Status.FAIL,"Chat was not ended after "+limit+"limit");
	        		failcount++;
	        	    TakeScreenshot.screenshot(driver,etest);
	        	    TakeScreenshot.screenshot(visitor_driver,etest);
	        	}
	        }
	        else
	        {
	        	VisitorWindow.sentMessageInTheme(visitor_driver,label);
	        	VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",label,2);
	        	if(VisitorWindow.checkEndTimer(visitor_driver,limit,false,true,etest))
	        	{
	        	    etest.log(Status.PASS,"Chat timer ("+limit+" limit) was hidden after sending a message");
	        	}
	        	else
	        	{
	        		etest.log(Status.FAIL,"Chat timer ("+limit+" limit) was not hidden after sending a message");
	        		failcount++;
	        	    TakeScreenshot.screenshot(driver,etest);
	        	    TakeScreenshot.screenshot(visitor_driver,etest);
	        	}
	        	ChatWindow.endChat(driver);
	        }
	    }
		
		visitor_driver_manager.terminateAllDriverSessions();
        
        return CommonUtil.returnResult(failcount);
	}

    public static boolean checkBannerDiv(WebDriver visDriver,String expected_text,String description,ExtentTest etest) throws Exception
    {
    	int failcount = 0;
    	VisitorWindow.switchToChatWidget(visDriver);
    	CommonWait.waitTillDisplayed(visDriver,VISITOR_SIDE_BANNER_DIV);
    	if(CommonWait.isDisplayed(visDriver,VISITOR_SIDE_BANNER_DIV))
		{
			etest.log(Status.PASS,description+" dialogue box was displayed");
			if(!CommonUtil.checkStringContainsAndLog(expected_text,CommonUtil.getElement(visDriver,VISITOR_SIDE_BANNER_DIV).getText(),description,etest))
			{
				failcount++;
			}
		}
		else
		{
			etest.log(Status.FAIL,description+" dialogue box was not displayed");
			TakeScreenshot.screenshot(visDriver,etest);
		}
		return CommonUtil.returnResult(failcount);
    }

    public static boolean checkMessageAreaDisplayed(WebDriver visDriver,ExtentTest etest,String desc) throws Exception
    {
    	VisitorWindow.switchToChatWidget(visDriver);
    	CommonWait.waitTillDisplayed(visDriver,MESSAGE_AREA);
    	if(CommonWait.isDisplayed(visDriver,MESSAGE_AREA))
    	{
    		etest.log(Status.PASS,"Chat was continued after "+desc);
    		return true;
    	}
    	else
    	{
    		etest.log(Status.FAIL,"Chat was not continued after "+desc);
    		TakeScreenshot.screenshot(visDriver,etest);
    		return false;
    	}
    }
}
