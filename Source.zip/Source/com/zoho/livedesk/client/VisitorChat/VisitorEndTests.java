//$Id$
package com.zoho.livedesk.client.VisitorChat;

import java.util.List;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.FileUpload;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.ChatHistory.ChatHistoryTests;
import com.zoho.livedesk.client.ChatMonitorRT.CommonFunctions;
import com.zoho.livedesk.client.VisitorChat.VisitorEndCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;

import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;


public class VisitorEndTests
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Visitor Chat Advanced";
	public static String WIDGET_CODE="",WEBSITE_NAME="";

	public static VisitorDriverManager visitor_driver_manager;

	public static final By
	MINIMIZE_ICON = By.className("siq-minimize-icon"),
	CHAT_WIDGET = By.id("zsiq_float"),
    MESSAGE_TABLE_DIV = By.id("msgtablediv"),
    MESSAGE_DATA = By.className("t-v-cont"),
    MESSAGE = By.className("trans-msg"),
    AGENT_MSG_TIME = By.className("t-v-time")
	;

	public static final String
	GOOGLE = "https://www.google.com",
	SAMPLE_MESSAGE = "hello",
	TRANSLATE_CONFIRMATION_TEXT = " has opted to translate this session using Google translate OK",
	GERMAN_TEXT = "Deutschland",
    GERMAN_TRANSLATED_TEXT = "Germany"
	;


	public static Hashtable test(WebDriver driver)
	{
		try
		{
            result = new Hashtable<String,Boolean>();

            visitor_driver_manager = new VisitorDriverManager();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
			WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest("Check end chat waiting timer");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkChatEnd(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VE9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VE9",checkVisitorLeavePage(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check chat widget more options");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkVisitorEndChatEnd(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VE15"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VE15",checkTranslationEnabled(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VE17"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("VE17",checkChatReceivedAfterMinimizingAndMaximizingChatWindow(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Title of the webpage");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkTitleChange(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check preview message in Conversation View in chat window");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			checkDataSentFromAgent(driver,etest,WIDGET_CODE);
            ComplexReportFactory.closeTest(etest);

			visitor_driver_manager.terminateAllDriverSessions();

        }
        catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}
    }

    public static void checkChatEnd(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	try
    	{
    		result.put("VE1",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,false,30));
    	}
    	catch(Exception e)
    	{
    		result.put("VE1",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE2",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,false,45));
		}
    	catch(Exception e)
    	{
    		result.put("VE2",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE3",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,false,60));
    	}
    	catch(Exception e)
    	{
    		result.put("VE3",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE4",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,false,90));
    	}
    	catch(Exception e)
    	{
    		result.put("VE4",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE5",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,false,false,30));
    	}
    	catch(Exception e)
    	{
    		result.put("VE5",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE6",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,false,false,45));
    	}
    	catch(Exception e)
    	{
    		result.put("VE6",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE7",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,false,false,60));
    	}
    	catch(Exception e)
    	{
    		result.put("VE7",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE8",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,false,false,90));
    	}
    	catch(Exception e)
    	{
    		result.put("VE8",false);
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static boolean checkVisitorLeavePage(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	int failcount = 0;
    	String label = CommonUtil.getUniqueMessage();
    	WebDriver visitor_driver = null;
    	try
    	{
    		visitor_driver = visitor_driver_manager.getDriver(driver);
    		ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label,false,ChatType.ONGOING);

    		CommonUtil.sleep(1000);
    		visitor_driver.get(GOOGLE);
    		CommonUtil.sleep(1000);
    		VisitorWindow.createPage(visitor_driver,widgetcode);

        	VisitorWindow.switchToChatWidget(visitor_driver);

        	if(!VisitorEndCommonFunctions.checkMessageAreaDisplayed(visitor_driver,etest,"visitor leaving the page and returning back"))
        	{
        		TakeScreenshot.screenshot(driver,etest);
        		failcount++;
        	}
        	ChatWindow.endChat(driver);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	finally
    	{
    		return CommonUtil.returnResult(failcount);
    	}
    }

    public static void checkVisitorEndChatEnd(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	try
    	{
    		result.put("VE10",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,true,0));
    	}
    	catch(Exception e)
    	{
    		result.put("VE10",false);
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE11",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,true,1));
    	}
    	catch(Exception e)
    	{
    		result.put("VE11",false);
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE12",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,true,2));
    	}
    	catch(Exception e)
    	{
    		result.put("VE12",false);
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	try
    	{
    		result.put("VE13",VisitorEndCommonFunctions.checkVisitorChatWindow(driver,etest,widgetcode,true,true,3));
    	}
    	catch(Exception e)
    	{
    		result.put("VE13",false);
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static boolean checkTranslationEnabled(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	int failcount = 0;
    	String label = CommonUtil.getUniqueMessage();
    	WebDriver visitor_driver = null;
    	try
    	{
    		PortalInput portal_input=new PortalInput(PortalSetting.GOOGLE_TRANSLATION,true);
			PortalSettingsRealTimeCommonFunctions.setPortalSetting(driver,portal_input,etest);

            ChatWindow.closeAllChats(driver);

    		visitor_driver = visitor_driver_manager.getDriver(driver);
    		Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails("V"+label,"V"+label+"@email.com",null,ExecuteStatements.getSystemGeneratedDepartment(driver),GERMAN_TEXT,"fb"+label,"3");
            ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widgetcode,ChatType.ONGOING,visitor_details,null);

            ChatWindow.confirmAutoTranslate(driver,etest,true);

            VisitorWindow.sentMessageInTheme(visitor_driver,GERMAN_TEXT);
            VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",GERMAN_TEXT,2);
            ChatWindow.waitTillMessageInChat(driver,GERMAN_TRANSLATED_TEXT);

            VisitorWindow.sentMessageInTheme(visitor_driver,GERMAN_TEXT);
            VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",GERMAN_TEXT,3);

            WebElement visitor_message_row = CommonUtil.getElement(driver,MESSAGE_TABLE_DIV).findElements(By.tagName("tr")).get(1);
            WebElement visitor_message = visitor_message_row.findElements(By.tagName("td")).get(1);
            CommonUtil.mouseHover(driver,visitor_message);
            CommonWait.waitTillDisplayed(driver,AGENT_MSG_TIME);

            String expectedTime = CommonUtil.getElement(driver,MESSAGE_TABLE_DIV,AGENT_MSG_TIME).getAttribute("innerHTML");

    		CommonFunctions.sentMessageUser(driver,SAMPLE_MESSAGE);
            ChatWindow.waitTillMessageInChat(driver,SAMPLE_MESSAGE);

    		if(!VisitorEndCommonFunctions.checkBannerDiv(visitor_driver,ExecuteStatements.getUserName(driver)+TRANSLATE_CONFIRMATION_TEXT,"Translation enabled info message",etest))
    		{
    			failcount++;
    		}

            VisitorWindow.sentMessageInTheme(visitor_driver,GERMAN_TEXT);
            VisitorWindow.checkVisitorMessageInChatWindow(visitor_driver,false,"",GERMAN_TEXT,2);

            visitor_message_row = CommonUtil.getElement(driver,MESSAGE_TABLE_DIV).findElements(By.tagName("tr")).get(1);
            visitor_message = visitor_message_row.findElements(By.tagName("td")).get(1);
            CommonUtil.mouseHover(driver,visitor_message);

            String actualTime = CommonUtil.getElement(driver,MESSAGE_TABLE_DIV,AGENT_MSG_TIME).getAttribute("innerHTML");

            if(CommonUtil.checkStringContainsAndLog(expectedTime,actualTime,"Time in My chats during translation",etest))
            {
                result.put("VE22",true);
            }
            else
            {
                result.put("VE22",false);
                TakeScreenshot.screenshot(driver,etest);
            }

			ChatWindow.endChat(driver);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    		failcount++;
    	}
    	return CommonUtil.returnResult(failcount);
    }

    public static boolean checkChatReceivedAfterMinimizingAndMaximizingChatWindow(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	int failcount = 0;
    	String label = CommonUtil.getUniqueMessage();
    	WebDriver visitor_driver = null;
    	try
    	{
	    	visitor_driver = visitor_driver_manager.getDriver(driver);
    		ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label,false,ChatType.ONGOING);

    		VisitorWindow.switchToChatWidget(visitor_driver);
    		CommonUtil.clickWebElement(visitor_driver,CommonUtil.getElement(visitor_driver,MINIMIZE_ICON));
    		visitor_driver.switchTo().defaultContent();

    		if(CommonWait.isDisplayed(visitor_driver,CHAT_WIDGET))
    		{
    			etest.log(Status.PASS,"Chat window was minimized");
    			VisitorWindow.clickChatButton(visitor_driver);
    			CommonUtil.sleep(1000);
    			if(!VisitorEndCommonFunctions.checkMessageAreaDisplayed(visitor_driver,etest,"minimizing and maximizing the chat window"))
	        	{
	        		TakeScreenshot.screenshot(visitor_driver,etest);
	        		failcount++;
	        	}

	        	ChatWindow.endChat(driver);
	        	VisitorWindow.switchToChatWidget(visitor_driver);
	        	if(CommonUtil.checkStringContainsAndLog(CommonUtil.getElement(visitor_driver,VisitorEndCommonFunctions.FEEDBACK_DIV).getText(),ResourceManager.getRealValue("feedback_header"),"FeedBack description",etest))
	        	{
	        		etest.log(Status.PASS,"Chat ended after minimizing and maximizing the chat window");
	        	}
	        	else
	        	{
	        		etest.log(Status.FAIL,"Chat was not ended after minimizing and maximizing the chat window");
	        		failcount++;
	        		TakeScreenshot.screenshot(driver,etest);
	        		TakeScreenshot.screenshot(visitor_driver,etest);
	        	}
    		}
    		else
    		{
    			etest.log(Status.FAIL,"Chat window was not minimized");
    			failcount++;
    			TakeScreenshot.screenshot(visitor_driver,etest);
    		}
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    	finally
    	{
    		return CommonUtil.returnResult(failcount);
    	}
    }

    public static void checkTitleChange(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	String label = CommonUtil.getUniqueMessage();
    	WebDriver visitor_driver = null;
    	try
    	{
	    	visitor_driver = visitor_driver_manager.getDriver(driver);
    		ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label,false,ChatType.ONGOING);

    		CommonFunctions.sentMessageUser(driver,SAMPLE_MESSAGE);

            Tab.clickSettings(driver);
    		
    		result.put("VE18",HandleCommonUI.checkTitleChange(visitor_driver,etest,"says","Visitor window"));
    		TakeScreenshot.infoScreenshot(visitor_driver,etest);

    		VisitorWindow.sentMessageInTheme(visitor_driver,SAMPLE_MESSAGE);

    		result.put("VE19",HandleCommonUI.checkTitleChange(driver,etest,"says","Agent window"));
    		TakeScreenshot.infoScreenshot(driver,etest);

            Tab.clickMyChats(driver);

	        ChatWindow.endChat(driver);

    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }

    public static void checkDataSentFromAgent(WebDriver driver,ExtentTest etest,String widgetcode)
    {
    	String label = CommonUtil.getUniqueMessage();
    	WebDriver visitor_driver = null;
    	try
    	{
	    	visitor_driver = visitor_driver_manager.getDriver(driver);
	    	ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label);
    		ChatHistoryTests.quickChat(driver,visitor_driver,etest,widgetcode,label,false,ChatType.ONGOING);
    		ConversationViewCommonFunctions.clickShowAllChatsButton(visitor_driver);

    		FileType file_type=FileType.IMAGE;
			ChatWindow.uploadFile(driver,file_type);

			result.put("VE20",VisitorWindow.checkPreviewMessage(visitor_driver,etest,true,file_type.getFileName()));

			CommonFunctions.sentMessageUser(driver,":smile");
			CommonFunctions.sentMessageUser(driver,"");


			result.put("VE21",VisitorWindow.checkPreviewMessage(visitor_driver,etest,false,"smile"));

	        ChatWindow.endChat(driver);
            ChatWindow.closeAllChats(driver);
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
    	}
    }
}
