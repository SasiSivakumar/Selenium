//$Id$
package com.zoho.livedesk.client.JSAPIW;

import java.io.IOException;
import java.util.Set;
import java.util.List;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class CommonFunctions
{
    public static WebDriver openApiSite(String ename) throws Exception
    {
        WebDriver driver = null;
        
        try
        {
            driver = setup(driver);
            
            return driver;
        }
        catch(Exception e)
        {
            try
            {
                System.out.println("HereJSAPIN");
                driver.quit();
                System.out.println("HereJSAPIN1");
            }
            catch(Exception excep){}
        }
        
        driver = setup(driver);
        
        return driver;
    }
    
    public static WebDriver setup(WebDriver driver) throws Exception
    {
        return setup(driver,JSApiutilWC.widgetcode);
    }

	public static WebDriver setup(WebDriver driver,String widgetcode) throws Exception
	{
        driver = Functions.setUp();
        
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);

		driver.get(ConfManager.getRealValue("php_server_endurl")+"jsdev2.php");

		Thread.sleep(1000);

		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fname")));

		String siteName = Util.setUptracking();

		if(siteName.equals("local"))
		{
			siteName = "LocalZoho";
		}

		else if(siteName.equals("pre"))
		{
			siteName = "Pre SalesIQ";
		}

		else if(siteName.equals("idc"))
		{
			siteName = "IDC";
		}

		else
		{
			siteName = "IDC";
		}

		choosePortal(driver,widgetcode,siteName);

		return driver;
	}

    public static void changeStatus(WebDriver driver,String status) throws Exception
    {
        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status);
            
            Thread.sleep(6000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while changing user status in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void choosePortal(WebDriver driver,String widgetcode,String setup)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            CommonUtil.elfinder(driver,"name","domain").click();
            new Select(driver.findElement(By.xpath(".//select[@name='domain']"))).selectByVisibleText(setup);
            CommonUtil.elfinder(driver,"name","widgetcode").click();
            CommonUtil.elfinder(driver,"name","widgetcode").sendKeys(widgetcode);
        }
        catch(Exception e)
        {
            System.out.println("Exception while choosing portal in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void initiateChat(WebDriver driver,String vname,String vemail,String vphone,String vques)
    {
        try
        {
            VisitorWindow.initiateChatVisTheme(driver,vname,vemail,vphone,vques,JSApiutilWC.etest);
        }
        catch(Exception e)
        {
            System.out.println("Exception while initiating chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void acceptChat(WebDriver driver, WebDriver visDriver)
    {
        try
        {
            ChatWindow.acceptChat(driver,JSApiutilWC.etest);
            ChatWindow.sentMessage(driver,"First message");
        }
        catch(Exception e)
        {
            System.out.println("Exception while accepting chat in jsapi module : ");
            e.printStackTrace();
        }
        
        try
        {
            VisitorWindow.checkAgentMessageInChatWindow(visDriver,null,"First message",1);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void endChat(WebDriver driver, WebDriver visDriver)
    {
        try
        {
            ChatWindow.sentMessage(driver,"Second message");
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in jsapi module : ");
            e.printStackTrace();
        }
        
        try
        {
            VisitorWindow.checkAgentMessageInChatWindow(visDriver,null,"Second message",2);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in jsapi module : ");
            e.printStackTrace();
        }
        
        try
        {
            ChatWindow.endAndCloseChat(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void replyMessages(WebDriver driver,WebDriver ApiDriver)
    {
        try
        {
            VisitorWindow.sentMessageInTheme(ApiDriver,"Hello there, welcome to testing team ...");
        }
        catch(Exception e)
        {
            System.out.println("Exception while replying for chat messages in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void clickMinimize(WebDriver driver)
    {
        try
        {
            VisitorWindow.clickChatButton(driver);
            VisitorWindow.clickCloseChatWidget(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while minimiznig chat window in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void sendFeedbackandRating(WebDriver driver,String rating)
    {
        try
        {
            String star = "";
            
            VisitorWindow.clickChatButton(driver);

            switch(rating)
            {
                case "1": star = "5";break;
                case "2": star = "4";break;
                case "3": star = "3";break;
                case "4": star = "2";break;
                case "5": star = "1";break;
            }

            VisitorWindow.enterFeedbackInTheme(driver,"Feedback Positive",star);
        }
        catch(Exception e)
        {
            System.out.println("Exception while replying for chat messages in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void clickRating(WebDriver driver,String rating)
    {
        try
        {
            String star = "";
            
            VisitorWindow.clickChatButton(driver);
            
            switch(rating)
            {
                case "1": star = "5";break;
                case "2": star = "4";break;
                case "3": star = "3";break;
                case "4": star = "2";break;
                case "5": star = "1";break;
            }
            
            VisitorWindow.enterFeedbackInTheme(driver,null,star,true,JSApiutilWC.etest);
        }
        catch(Exception e)
        {
            System.out.println("Exception while replying for chat messages in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void ClickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
    }
    
    public static String getUseremail(WebDriver driver)
    {
        String uemail = "renganathan.k+automation@zohocorp.com";
        
        try
        {
            ClickSettings(driver);
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","ulisttable");
            List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
            uemail = elmts.get(0).findElement(By.xpath(".//div[contains(@class,'ulist_email')]")).findElement(By.tagName("a")).getText();
        }
        catch(Exception e)
        {
            System.out.println("Exception while getting username in jsapi module : ");
            e.printStackTrace();
        }
        return uemail;
    }
    
    public static String getUsername(WebDriver driver)
    {
        String uname = "LDAutomation";
        
        try
        {
            ClickSettings(driver);
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","ulisttable");
            List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
            uname = elmts.get(0).findElement(By.xpath(".//div[contains(@class,'ulist_uname')]")).findElement(By.className("txtelips")).getText();
        }
        catch(Exception e)
        {
            System.out.println("Exception while getting username in jsapi module : ");
            e.printStackTrace();
        }
        return uname;
    }
    
    public static boolean checkvid(WebDriver ApiDriver,String vid,String cvid) throws Exception
    {
        if(!CommonUtil.elfinder(ApiDriver,"id",vid).getText().equals("undefined")&&CommonUtil.elfinder(ApiDriver,"id",vid).getText()!=null&&!CommonUtil.elfinder(ApiDriver,"id",cvid).getText().equals("undefined")&&CommonUtil.elfinder(ApiDriver,"id",cvid).getText()!=null)
        {
            return true;
        }
        return false;
    }
    
    public static void enterValueSysMsg(WebDriver driver,String pid,String value) throws Exception
    {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",pid)).getLocation().y+"-200)");
        Thread.sleep(300);
        CommonUtil.elfinder(driver,"id",pid).click();
        CommonUtil.elfinder(driver,"id",pid).sendKeys(value);
    }
    
    public static String checkPos(String top,String bottom,String left,String right)
    {
        String curpos = "Bottom Right";
        
        if(top.equals(left)||top.equals(right))
        {
            if(top.equals(left))
            {
                return "Top Left";
            }
            return "Top Right";
        }
        else if(bottom.equals(left)||bottom.equals(right))
        {
            if(bottom.equals(left))
            {
                return "Bottom Left";
            }
            return "Bottom Right";
        }
        else if(top.equals("0px") && bottom.equals("0px"))
        {
            Integer l1 = Integer.parseInt(left.replace("px",""));
            Integer r1 = Integer.parseInt(right.replace("px",""));
            
            if(l1 < r1)
            {
                return "Left";
            }
            else
            {
                return "Right";
            }
        }
        
        return "Position not found";
    }

    public static void selectElementById(WebDriver driver,String id) throws Exception
    {
        com.zoho.livedesk.util.common.CommonUtil.inViewPort(CommonUtil.elfinder(driver,"id",id));
        com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id",id));
    }

    public static void enterValue(WebDriver driver,String id,String value) throws Exception
    {
        com.zoho.livedesk.util.common.CommonUtil.inViewPort(CommonUtil.elfinder(driver,"id",id));
        com.zoho.livedesk.util.common.CommonUtil.sendKeysToWebElement(driver,CommonUtil.elfinder(driver,"id",id),value);
    }

    public static boolean isValueSet(WebDriver driver,String id,String attr,String value,String desc,ExtentTest etest)
    {
        return isValueSet(driver,id,attr,value,desc,etest,true);
    }

    public static boolean isValueSet(WebDriver driver,String id,String attr,String value,String desc,ExtentTest etest,boolean check)
    {
        try
        {
            if(!id.contains("siqbtndiv"))
            {
                VisitorWindow.switchToChatWidget(driver);
            }
            if(com.zoho.livedesk.util.common.CommonUtil.checkStringContainsAndLog(value,CommonUtil.elfinder(driver,"id",id).getAttribute(attr),desc,etest))
            {
                etest.log(Status.PASS,"Checked");
                driver.switchTo().defaultContent();
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"FAILED");
                driver.switchTo().defaultContent();
                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,JSApiutilWC.MODULE_NAME,"Exception","Exception",e);
            return false;
        }
    }
}
