//$Id$
package com.zoho.livedesk.client.JSAPIW;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ChatTransfer.CommonFunctionsTC;

public class JSApiutilWC
{
    private static Hashtable result = new Hashtable();
    private static Hashtable hashtable = new Hashtable();
    private static Hashtable servicedown = new Hashtable();
    public static WebDriver ApiDriver = null;
    public static WebDriver driver2 = null;
    
    public static String widgetcode = "";
    public static String dept = "";
    public static String usermail = "";
    public static String deptname = "new";
    public static String embed;

    public static String 
    PORTAL_NAME = null;

    public static final String
    TITLE_TEXT = "JSAPI CHAT TITLE",
    CHAT_LOGO = "https://www.zoho.in/sites/default/files/styles/product-home-page/public/icon-salesiq_6.png?itok=oLxrRcEs",
    CHAT_BUTTON_TEXTS = "Hi thereYes please",
    MODULE_NAME = "Widget code -  JSAPI",
    JSAPI_URL = ConfManager.getRealValue("php_server_endurl")+"jsdev2.php";

    public static final By
    CALLBACK_ID = By.id("callback")
    ;

    public static final String
    CALLBACK_EXECUTED_TEXT = "callback executed",
    CUSTOM_FIELD_TEXT = "custom field text"
    ;

    public static final String
    SAMPLE_LANGUAGE[] = {
                         "Chat with us",
                         "Conversez avec nous maintenant",
                         "Chatten Sie mit uns!",
                         "Chatee con nosotros ahora!",
                         "Nu met ons chatten.",
                         "Chat med oss",
                         "bizimle sohbet edin!",
                         "Entre no bate-papo conosco agora!",
                         "Chatta con noi!",
                         "Chat med os nu!",
                         "Porozmawiaj z nami teraz!",
                         "linn anois!",
                         "cu noi acum!",
                         "Chatta med oss nu!",
                         "Chatujte",
                         "Klepetajte z nami zdaj!",
                         "Razgovarajte s nama sada!"},

    LANGUAGE[] = {
                  "English",
                  "French",
                  "German",
                  "Spanish",
                  "Dutch",
                  "Norwegian",
                  "Turkish",
                  "Portuguese",
                  "Italian",
                  "Danish",
                  "Polish",
                  "Irish",
                  "Romanian",
                  "Swedish",
                  "Slovak",
                  "Slovenian",
                  "Croatian"};

    public static ExtentTest etest;

    public static VisitorDriverManager visitor_driver_manager;

    public static Hashtable jsApiAutomation(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result = new Hashtable();

            com.zoho.livedesk.util.Cleanup.deleteAllDeparmentsExcept(driver,null);

            dept = ExecuteStatements.getSystemGeneratedDepartment(driver);
            PORTAL_NAME = ExecuteStatements.getPortal(driver);
            embed=ExecuteStatements.getDefaultEmbedName(driver);
            widgetcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

            usermail = ExecuteStatements.getUserMail(driver);

            etest = ComplexReportFactory.getTest("Widget code - Open Api Site");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","Checks if the JSAPI site is accessible");

            ApiDriver = CommonFunctions.openApiSite(null);

            result.put("JSW1",true);

            etest.log(Status.PASS,"Site is accessible and is opened");
            ComplexReportFactory.closeTest(etest);
            ApiDriver.quit();

            /* Working set starts here */

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigBasic(ApiDriver);
            checkConfigBasic(ApiDriver);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfig(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester5","rajkumar.natarajan+11223@zohocorp.com","8767588867","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.clickMinimize(ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.sendFeedbackandRating(ApiDriver,"4");
            checkConfig(driver,ApiDriver);
            ApiDriver.quit();

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatwindow.click()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on clicking the float button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW8",checkClicks(ApiDriver,"evtbuttonclk","evntbclk"));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

//            New embed doesnot support it
//            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatwindow.close()");
//            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on closing the float window.");
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            result.put("JSW9",checkClicks(ApiDriver,"evtbuttoncls","evntbclose"));
//            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.online()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when the agents are online. This will be called once after the page is loaded.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW12",checkEvHandler(ApiDriver));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"busy");
            
            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.offlinemessage()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on submitting an offline request.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW7",checkOffline(ApiDriver));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.offline()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when the agents are offline. This will be called once after the page is loaded.");

            ApiDriver = CommonFunctions.openApiSite(null);
            result.put("JSW11",checkChatHandler(ApiDriver,"evtchatoffline","evtchatoffline"));
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"available");
            
            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.systemmessages()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","You can use this API to customize the system messages displayed in the chat widget.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys1(ApiDriver);
            checkConfigsys1(ApiDriver);
            ApiDriver.quit();

//            New embed doesnot supports pre chat message
//            ApiDriver = CommonFunctions.openApiSite("prechatembed");
//            changeConfigSys(ApiDriver);
//            checkConfigSys(ApiDriver);
//            ApiDriver.quit();

            CommonFunctions.changeStatus(driver,"busy");
            
            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            checkConfigSys2(ApiDriver);
            ApiDriver.quit();

            CommonFunctions.changeStatus(driver,"available");
            
            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"1");
            checkConfigSysFdbk(ApiDriver,"1","JSW29");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"2");
            checkConfigSysFdbk(ApiDriver,"2","JSW30");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"3");
            checkConfigSysFdbk(ApiDriver,"3","JSW31");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"4");
            checkConfigSysFdbk(ApiDriver,"4","JSW32");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigSys(ApiDriver);
            CommonFunctions.initiateChat(ApiDriver,"Tester8","rajkumar.natarajan+11226@zohocorp.com","87675888412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            CommonFunctions.clickRating(ApiDriver,"5");
            checkConfigSysFdbk(ApiDriver,"5","JSW33");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatbutton.position()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","You can use this API to position the Float Button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Top Right");
            checkCSSConfig(ApiDriver,"Top Right","JSW34");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Top Left");
            checkCSSConfig(ApiDriver,"Top Left","JSW35");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Bottom Right");
            checkCSSConfig(ApiDriver,"Bottom Right","JSW36");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Bottom Left");
            checkCSSConfig(ApiDriver,"Bottom Left","JSW37");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Left");
            checkCSSConfig(ApiDriver,"Left","JSW38");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeCSSConfig(ApiDriver,"Right");
            checkCSSConfig(ApiDriver,"Right","JSW39");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

//            widgetcode does not supports
//            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatbutton.onlineicon.src()");
//            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","You can use this API to display your own icon when your agents are online. Supported only for Float Button.");
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeFBImgConfig(ApiDriver,"floatonlinesrc",ResourceManager.getRealValue("image_salesonline"));
//            checkFBImgConfig(ApiDriver,ResourceManager.getRealValue("image_salesonline"),"JS40");
//            ApiDriver.quit();
//
//            ComplexReportFactory.closeTest(etest);

//            CommonFunctions.changeStatus(driver,"busy");
//
//            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatbutton.offlineicon.src()");
//            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API allows you to display your own icon when your agents are offline. Supported only for Float Button.");
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeFBImgConfig(ApiDriver,"floatofflinesrc",ResourceManager.getRealValue("image_salesoffline"));
//            checkFBImgConfig(ApiDriver,ResourceManager.getRealValue("image_salesoffline"),"JS41");
//            ApiDriver.quit();
//
//            ComplexReportFactory.closeTest(etest);
//
//            CommonFunctions.changeStatus(driver,"available");

//                        widgetcode does not supports
//            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.theme()");
//            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API allows you to customize your theme color.");
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeThemeConfig(ApiDriver,"Black");
//            checkThemeConfig(ApiDriver,"rgba(99, 99, 99, 1)","JS42");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeThemeConfig(ApiDriver,"Gray");
//            checkThemeConfig(ApiDriver,"rgba(244, 244, 244, 1)","JS43");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeThemeConfig(ApiDriver,"Blue");
//            checkThemeConfig(ApiDriver,"rgba(135, 210, 213, 1)","JS44");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeThemeConfig(ApiDriver,"Green");
//            checkThemeConfig(ApiDriver,"rgba(105, 180, 153, 1)","JS45");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeThemeConfig(ApiDriver,"Red");
//            checkThemeConfig(ApiDriver,"rgba(255, 116, 113, 1)","JS46");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeThemeConfig(ApiDriver,"Purple");
//            checkThemeConfig(ApiDriver,"rgba(196, 117, 193, 1)","JS47");
//            ApiDriver.quit();
//
//            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.feedback.visible()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API allows you to handle the visibility of feedback form, on completion of a chat.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigFeedback(ApiDriver,"Show");
            CommonFunctions.initiateChat(ApiDriver,"Tester9","rajkumar.natarajan+11236@zohocorp.com","87672688412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysFeedback(ApiDriver,"Show","JSW48");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigFeedback(ApiDriver,"Hide");
            CommonFunctions.initiateChat(ApiDriver,"Tester9","rajkumar.natarajan+11236@zohocorp.com","87672688412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysFeedback(ApiDriver,"Hide","JSW49");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.rating.visible()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","Use this API to handle the visibility of rating, on completion of a chat.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigRating(ApiDriver,"Show");
            CommonFunctions.initiateChat(ApiDriver,"Tester10","rajkumar.natarajan+11233@zohocorp.com","87677788412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysRating(ApiDriver,"Show","JSW50");
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigRating(ApiDriver,"Hide");
            CommonFunctions.initiateChat(ApiDriver,"Tester10","rajkumar.natarajan+11233@zohocorp.com","87677788412","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            CommonFunctions.endChat(driver,ApiDriver);
            checkConfigSysRating(ApiDriver,"Hide","JSW51");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.custom.html()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","API allows you to have your own customized chat button. Supported for Float Chat and Embed Button.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"Online Text Click Here","fctmhtmlon");
            checkConfigHTML(ApiDriver,"JSW52","Online Text Click Here",null);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"<img src ='https://www.zoho.com/salesiq/img/Zilliumonline.png'>","fctmhtmlon");
            checkConfigHTML(ApiDriver,"JSW53","Online Image","<img src ='https://www.zoho.com/salesiq/img/Zilliumonline.png'>");
            ApiDriver.quit();

            CommonFunctions.changeStatus(driver,"busy");
            
            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"Offline Text Click Here","fctmhtmloff");
            checkConfigHTML(ApiDriver,"JSW54","Offline Text Click Here",null);
            ApiDriver.quit();

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigHTML(ApiDriver,"<img src ='https://www.zoho.com/salesiq/img/ZilliumOffline.png'>","fctmhtmloff");
            checkConfigHTML(ApiDriver,"JSW55","Offline Image","<img src ='https://www.zoho.com/salesiq/img/ZilliumOffline.png'>");
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            CommonFunctions.changeStatus(driver,"available");
            
            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.customfield.add()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","API allows you to create a new input field in the chat widget. Custom field inputs will be dispayed in visitor information section.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigField(ApiDriver,"text");
            checkConfigField(ApiDriver,"JSW56","text");
            ApiDriver.quit();

//            New embed doesnot supports custom field
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigField(ApiDriver,"radio");
//            checkConfigField(ApiDriver,"JS57","radio");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigField(ApiDriver,"checkbox");
//            checkConfigField(ApiDriver,"JS58","checkbox");
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigField(ApiDriver,"selectbox");
//            checkConfigField(ApiDriver,"JS59","selectbox");
//            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.info()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API allows you to add the additional information about the visitor and displays it to the agent in the visitor information section. These information are not visible to the visitors.");

            ApiDriver = CommonFunctions.openApiSite(null);
            changeConfigInfo(ApiDriver,"{\"Payment Expiry\": \"Jan 20, 2017\"}");
            CommonFunctions.initiateChat(ApiDriver,"Tester11","rajkumar.natarajan+11239@zohocorp.com","87672688415","what is zoho salesiq ? ...");
            CommonFunctions.acceptChat(driver,ApiDriver);
            checkConfigInfo(driver,"JSW60");
            CommonFunctions.endChat(driver,ApiDriver);
            ApiDriver.quit();

            ComplexReportFactory.closeTest(etest);

//            widgetcode does not supports
//            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chatbubble.visible()");
//            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API allows you to handle the visibility of chat bubble. Make sure to enable the chat bubble in WebEmbed settings.");
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigBubble(ApiDriver,"hide");
//            checkConfigBubble(ApiDriver,"hide","JS21",null);
//            ApiDriver.quit();
//
//            ApiDriver = CommonFunctions.openApiSite(null);
//            changeConfigBubble(ApiDriver,"show");
//            checkConfigBubble(ApiDriver,"show","JS22","JS10");
//            ApiDriver.quit();
//
//            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Initial Setup");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            ApiDriver = CommonFunctions.openApiSite(null);
            initialSetup(driver,ApiDriver,etest);
            ComplexReportFactory.closeTest(etest);

            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW65"));
            // ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            // result.put("JSW65",CommonFunctions.isValueSet(ApiDriver,"attname","innerText",TITLE_TEXT,"Chat title",etest));
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW62"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW62",CommonFunctions.isValueSet(ApiDriver,"dropheader","innerText",dept,"Department",etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW66"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW66",CommonFunctions.isValueSet(ApiDriver,"complogo","src",CHAT_LOGO,"Logo",etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW69"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW69",CommonFunctions.isValueSet(ApiDriver,"siqbtndiv","innerText",CHAT_BUTTON_TEXTS,"Chat Button Texts",etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW74"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW74",CommonFunctions.isValueSet(ApiDriver,"siqbtndiv","style","500px","Chat Button width",etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW85"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW85",checkTriggerValues(ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("JSW61"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW61",checkChatMode(driver,ApiDriver,etest,false));
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("JSW78"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW78",isVisitorTracked(driver,ApiDriver,etest,true));
            ComplexReportFactory.closeTest(etest);

            // etest = ComplexReportFactory.getTest(KeyManager.getRealValue("JSW88"));
            // ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            // result.put("JSW88",checkButtonClick(ApiDriver,etest,"evtchatbuttonclk"));
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW73"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW73",isCustomFieldCleared(ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            driver2=Functions.setUp();                  
            Functions.login(driver2,"jsapi_supervisor");

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW67"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW67",checkChatStarted(driver,ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW63"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW63",checkAgentRouted(driver,driver2,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW64"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW64",checkAgentForwarded(driver2,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW82"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW82",checkChatMissed(ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW80"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW80",checkIdleTime(ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW83"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW83",checkVisitorIdleStatus(ApiDriver,etest,"evntvidle"));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW84"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW84",checkVisitorIdleStatus(ApiDriver,etest,"evntvactive"));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check chat button visible");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkChatWidgetVisible(etest);
            ComplexReportFactory.closeTest(etest);

            ApiDriver.quit();
            etest = ComplexReportFactory.getTest("Setting up driver for float widget theme");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            ApiDriver = CommonFunctions.openApiSite(null);
            setupForFloatWidgetTheme(driver,ApiDriver,etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW72"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW72",checkChatMode(driver,ApiDriver,etest,true));
            ComplexReportFactory.closeTest(etest);

            CommonFunctions.acceptChat(driver,ApiDriver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW70"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW70",checkButtonClick(ApiDriver,etest,"evntbclk"));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW79"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW79",isVisitorTracked(driver,ApiDriver,etest,false));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW86"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW86",checkChatTransferred(driver,driver2,ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW87"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW87",checkChatTransferAccepted(driver,driver2,ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW17"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW17",checkChatCompleted(driver,ApiDriver,etest));
            ComplexReportFactory.closeTest(etest);

            ApiDriver.quit();

            etest=ComplexReportFactory.getTest("check Float button visible");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkFloatWidgetVisible(etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("JSW68"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("JSW68",checkLanguage(etest));
            ComplexReportFactory.closeTest(etest);

            ApiDriver.quit();

            visitor_driver_manager = new VisitorDriverManager();

            etest=ComplexReportFactory.getTest("Check $zoho.salesiq.reset()");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkResetAPI(driver,driver2,etest);
            ComplexReportFactory.closeTest(etest);

            Functions.logout(driver2);

        /*
            etest=ComplexReportFactory.getTest("Check $zoho.salesiq.domain()");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkDomainAPI(driver,etest);
            ComplexReportFactory.closeTest(etest);
        */
            visitor_driver_manager.terminateAllDriverSessions();

            /*  Working set ends here */
        }
        catch(Exception e)
        {
            ApiDriver.quit();
            result.put("JSW1",false);
            etest.log(Status.FATAL,"Error occurred while trying to open API Site");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiShowStopper","JSApiError",e);
        }

        ComplexReportFactory.closeTest(etest);

        hashtable.put("result",result);
        hashtable.put("servicedown",servicedown);
        return hashtable;
    }

    public static boolean checkBasic(WebDriver driver,String sname,String ename,String cname) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

            VisitorWindow.clickChatButton(driver);

            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");

            driver.switchTo().frame(chframe);

            String chtext = CommonUtil.elfinder(driver,"id",ename).getAttribute("value");

            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   :   >>"+chtext);

            if(chtext.equals(cname))
            {
                return true;
            }

            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApi"+sname,"Error",e);
            return false;
        }
    }

    public static boolean checkDept(WebDriver driver,String finder,String sname,String ename,String cname) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,finder,sname).click();
            CommonUtil.elfinder(driver,finder,sname).sendKeys(cname);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

            VisitorWindow.clickChatButton(driver);

            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");

            driver.switchTo().frame(chframe);

            String chtext = CommonUtil.elfinder(driver,"id",ename).getText();

            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   :   >>"+chtext);

            if(chtext.equals(cname))
            {
                return true;
            }

            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApi"+sname,"Error",e);
            return false;
        }
    }

    public static boolean checkOffline(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id","evntoffline").click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

            VisitorWindow.clickChatButton(driver);
            
            VisitorWindow.infoInvisible(driver);

            VisitorWindow.initiateChatVisTheme(driver,"Tester","rajkumar.natarajan+1243@zohocorp.com","9967682922",null,"what is zoho salesiq ? ...",false,etest,true);
            
            Thread.sleep(3000);
            
            driver.switchTo().defaultContent();

            try
            {
                com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementContainsAttributeValue(com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("eventhandlercontainer")),"innerText","Tester");
            }
            catch(Exception e)
            {
                com.zoho.livedesk.util.common.CommonUtil.sleep(3000);
            }

            if((CommonUtil.elfinder(driver,"id","evntdname").getText().equals("Tester"))&&(CommonUtil.elfinder(driver,"id","evntdemail").getText().equals("rajkumar.natarajan+1243@zohocorp.com"))&&(CommonUtil.elfinder(driver,"id","evntdques").getText().equals("what is zoho salesiq ? ..."))&&CommonFunctions.checkvid(driver,"evntvid","evntdvisitid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvid").getText());
                etest.log(Status.PASS,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntdname").getText());
                etest.log(Status.PASS,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntdemail").getText());
                etest.log(Status.PASS,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntdques").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntdvisitid").getText());
                return true;
            }

            etest.log(Status.FAIL,"Invalid Response : ");
            etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvid").getText());
            etest.log(Status.FAIL,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntdname").getText()+" || ( Expected : Tester)");
            etest.log(Status.FAIL,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntdemail").getText()+" || ( Expected : rajkumar.natarajan+1243@zohocorp.com)");
            etest.log(Status.FAIL,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntdques").getText()+" || ( Expected : what is zoho salesiq ? ...)");
            etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntdvisitid").getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOffline","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOffline","Error",e);
            return false;
        }
    }

    public static boolean checkClicks(WebDriver driver,String cname,String ename) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id",cname).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.clickCloseChatWidget(driver);

            Thread.sleep(1000);

            if(CommonUtil.elfinder(driver,"id",ename).getText().equals("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
                return true;
            }

            etest.log(Status.FAIL,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiClick","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiClick","Error",e);
            return false;
        }
    }

    public static boolean checkChatHandler(WebDriver driver,String cname,String ename) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            com.zoho.livedesk.util.common.CommonUtil.jsClick(driver,"#"+cname);
            com.zoho.livedesk.util.common.CommonUtil.scrollIntoView(driver,By.id(cname));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();
            CommonWait.waitTillDisplayed(driver, By.id("zsiq_float"));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_float")));
            
            Thread.sleep(5000);

            System.out.println(" <<< <<< <<< <<< <<< <<< <<< <<< : "+CommonUtil.elfinder(driver,"id",ename).getText()+" >>> >>> >>> >>>");

            if(CommonUtil.elfinder(driver,"id",ename).getText().equals("True")|| CommonUtil.elfinder(driver,"id",ename).getText().equals("False"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
                return true;
            }
            etest.log(Status.FAIL,"Response : "+CommonUtil.elfinder(driver,"id",ename).getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiChat","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiChat","Error",e);
            return false;
        }
    }

    public static boolean checkEvHandler(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            CommonUtil.elfinder(driver,"id","evtchatonline").click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

            VisitorWindow.clickChatButton(driver);
            
            Thread.sleep(2000);

            if(CommonUtil.elfinder(driver,"id","evtchatonline").getText().equals("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(driver,"id","evtchatonline").getText());
                return true;
            }
            etest.log(Status.FAIL,"Response : "+CommonUtil.elfinder(driver,"id","evtchatonline").getText());
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiEvent","Error");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiEvent","Error",e);
            return false;
        }
    }

    public static void changeConfig(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fvinfo").click();
            CommonUtil.elfinder(driver,"id","evtbuttonmin").click();
            CommonUtil.elfinder(driver,"id","evtwaitinghdlr").click();
            CommonUtil.elfinder(driver,"id","evtchatatnd").click();
            CommonUtil.elfinder(driver,"id","evtagentmsg").click();
            CommonUtil.elfinder(driver,"id","evtchatcomplete").click();
            CommonUtil.elfinder(driver,"id","evtvisitorchat").click();
            CommonUtil.elfinder(driver,"id","evtvisitorrating").click();
            CommonUtil.elfinder(driver,"id","evtvisitorfeedback").click();
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfig","Error",e);
        }
    }

    public static void checkConfig(WebDriver driver,WebDriver ApiDriver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JSW13",false);
//            result.put("JSW14",false);
            result.put("JSW15",false);
            result.put("JSW16",false);
            result.put("JSW17",false);
            result.put("JSW18",false);
            result.put("JSW19",false);
            result.put("JSW20",false);

            String attname = CommonFunctions.getUsername(driver);
            String attemail = CommonFunctions.getUseremail(driver);

            ApiDriver.switchTo().defaultContent();

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.floatwindow.minimize()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on minimizing the float window.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntbminimize").getText().contains("True"))
            {
                etest.log(Status.PASS,"Response : "+CommonUtil.elfinder(ApiDriver,"id","evntbminimize").getText());
                result.put("JSW13",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : "+CommonUtil.elfinder(ApiDriver,"id","evntbminimize").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiMinimize","Error");
            }

            ComplexReportFactory.closeTest(etest);

//            widgetcode does not supports
//            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.waitinghandler()");
//            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method to display your own content in the chat widget's waiting timer.");
//            
//            if(CommonUtil.elfinder(ApiDriver,"id","evntwwaitingtime").getText().contains("60")&&CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText()!=null&&!CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText().contains("undefined")&&!CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText().equals("0"))
//            {
//                etest.log(Status.PASS,"Response : ");
//                etest.log(Status.PASS,"Configured waiting Time : "+CommonUtil.elfinder(ApiDriver,"id","evntwwaitingtime").getText());
//                etest.log(Status.PASS,"Current time in timer : "+CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText());
//                result.put("JSW14",true);
//            }
//            else
//            {
//                etest.log(Status.FAIL,"Invalid response : ");
//                etest.log(Status.FAIL,"Configured waiting Time : "+CommonUtil.elfinder(ApiDriver,"id","evntwwaitingtime").getText()+" || ( Expected : 60)");
//                etest.log(Status.FAIL,"Current time in timer : "+CommonUtil.elfinder(ApiDriver,"id","evntwcurrenttime").getText());
//                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiTimerFail","Error");
//            }
//
//            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.attend()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when an agent attends the chat.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntchtatnddname").getText().contains(attname)&&CommonUtil.elfinder(ApiDriver,"id","evntchtatnddemail").getText().contains(attemail)&&CommonFunctions.checkvid(ApiDriver,"evntchtatndvid","evntchtatnddvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatndvid").getText());
                etest.log(Status.PASS,"Attender Name : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddname").getText());
                etest.log(Status.PASS,"Attender Email : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddemail").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddvid").getText());
                result.put("JSW15",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatndvid").getText());
                etest.log(Status.FAIL,"Attender Name : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddname").getText()+" || ( Expected : "+attname+")");
                etest.log(Status.FAIL,"Attender Email : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddemail").getText()+" || ( Expected : "+attemail+")");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntchtatnddvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiAttender","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.agentMessage()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when a message is sent to the visitor by the agent.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntagntobjmsg").getText().contains("Second message")&&CommonFunctions.checkvid(ApiDriver,"evntagntvid","evntagntobjvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntagntvid").getText());
                etest.log(Status.PASS,"Agent Message : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjmsg").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjvid").getText());
                result.put("JSW16",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntagntvid").getText());
                etest.log(Status.FAIL,"Agent Message : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjmsg").getText()+" || ( Expected : Second message)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntagntobjvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiAgentMessage","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.chat.complete()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when a chat session is completed.");

            if(!(CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText().contains("undefined"))&&CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText()!=null&&!CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText().equals("")&&CommonFunctions.checkvid(ApiDriver,"evntctcmplttvid","evntctcmpltobjvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmplttvid").getText());
                etest.log(Status.PASS,"Chat Duration : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjvid").getText());
                result.put("JSW17",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmplttvid").getText());
                etest.log(Status.FAIL,"Chat Duration : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjdur").getText());
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntctcmpltobjvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiChat","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.chat()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when a visitor initiates the chat.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntvchatdname").getText().contains("Tester5")&&CommonUtil.elfinder(ApiDriver,"id","evntvchatdemail").getText().contains("rajkumar.natarajan+11223@zohocorp.com")&&CommonUtil.elfinder(ApiDriver,"id","evntvchatdques").getText().contains("what is zoho salesiq ? ...")&&CommonFunctions.checkvid(ApiDriver,"evntvchatvid","evntvchatdvisitid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatvid").getText());
                etest.log(Status.PASS,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdname").getText());
                etest.log(Status.PASS,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdemail").getText());
                etest.log(Status.PASS,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdques").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdvisitid").getText());
                result.put("JSW18",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid Response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatvid").getText());
                etest.log(Status.FAIL,"Name : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdname").getText()+" || ( Expected : Tester5)");
                etest.log(Status.FAIL,"Email : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdemail").getText()+" || ( Expected : rajkumar.natarajan+11223@zohocorp.com)");
                etest.log(Status.FAIL,"Question : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdques").getText()+" || ( Expected : what is zoho salesiq ? ...)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntvchatdvisitid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiDetails","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.rating()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method, when a visitor rates the support session.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntdratingagent").getText().contains(attemail)&&CommonUtil.elfinder(ApiDriver,"id","evntratingrating").getText().contains("4")&&CommonFunctions.checkvid(ApiDriver,"evntratingvid","evntratingdvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntratingvid").getText());
                etest.log(Status.PASS,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdratingagent").getText());
                etest.log(Status.PASS,"Rating : "+CommonUtil.elfinder(ApiDriver,"id","evntratingrating").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntratingdvid").getText());
                result.put("JSW19",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntratingvid").getText());
                etest.log(Status.FAIL,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdratingagent").getText()+" || ( Expected : "+attemail+")");
                etest.log(Status.FAIL,"Rating : "+CommonUtil.elfinder(ApiDriver,"id","evntratingrating").getText()+" || ( Expected : 4)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntratingdvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiRating","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.feedback()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This event handler allows you to invoke a method on submitting the feedback message.");

            if(CommonUtil.elfinder(ApiDriver,"id","evntdfeedbackagent").getText().contains(attemail)&&CommonUtil.elfinder(ApiDriver,"id","evntfeedbackrating").getText().contains("Feedback Positive")&&CommonFunctions.checkvid(ApiDriver,"evntfeedbackvid","evntfeedbackdvid"))
            {
                etest.log(Status.PASS,"Response : ");
                etest.log(Status.PASS,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackvid").getText());
                etest.log(Status.PASS,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdfeedbackagent").getText());
                etest.log(Status.PASS,"Feedback : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackrating").getText());
                etest.log(Status.PASS,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackdvid").getText());
                result.put("JSW20",true);
            }
            else
            {
                etest.log(Status.FAIL,"Invalid response : ");
                etest.log(Status.FAIL,"Visit ID : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackvid").getText());
                etest.log(Status.FAIL,"Agent : "+CommonUtil.elfinder(ApiDriver,"id","evntdfeedbackagent").getText()+" || ( Expected : "+attemail+")");
                etest.log(Status.FAIL,"Feedback : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackrating").getText()+" || ( Expected : Feedback Positive)");
                etest.log(Status.FAIL,"Visit ID (Data Object) : "+CommonUtil.elfinder(ApiDriver,"id","evntfeedbackdvid").getText());
                TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSApiFeedback","Error");
            }

            ComplexReportFactory.closeTest(etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(ApiDriver,etest,"JSAPI","JSAPIConfig","Error",e);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigBasic(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fname").click();
            CommonUtil.elfinder(driver,"id","fname").sendKeys("Tester");
            CommonUtil.elfinder(driver,"id","femail").click();
            CommonUtil.elfinder(driver,"id","femail").sendKeys("rajkumar.natarajan+143@zohocorp.com");
            CommonUtil.elfinder(driver,"id","fphone").click();
            CommonUtil.elfinder(driver,"id","fphone").sendKeys("9876544578");
            //CommonUtil.elfinder(driver,"name","defaultdept").click();
            //CommonUtil.elfinder(driver,"name","defaultdept").sendKeys("Automation");
            CommonUtil.elfinder(driver,"id","fquestion").click();
            CommonUtil.elfinder(driver,"id","fquestion").sendKeys("Any Question? ...");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigBasic","Error",e);
        }
    }

    public static void checkConfigBasic(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.name()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API is used to fill the visitor's name in the chat widget text box.");

            result.put("JSW2",false);
            result.put("JSW3",false);
            result.put("JSW4",false);
            result.put("JSW5",false);
            //result.put("JSW6",false);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);

            String cname = CommonUtil.elfinder(driver,"id","visname").getAttribute("value");
            String cemail = CommonUtil.elfinder(driver,"id","visemail").getAttribute("value");
            String cphone = CommonUtil.elfinder(driver,"id","visphone").getAttribute("value");
            String cques = CommonUtil.elfinder(driver,"id","msgarea").getAttribute("value");
            //String cdept = CommonUtil.elfinder(driver,"id","selecteddept").getText();

            if(cname.equals("Tester"))
            {
                etest.log(Status.PASS,"Text in Field : "+cname);
                result.put("JSW2",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cname+" || (Expected : Tester)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiName","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.email()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","You can use this API to fill the visitor email address in the chat widget text box.");

            if(cemail.equals("rajkumar.natarajan+143@zohocorp.com"))
            {
                etest.log(Status.PASS,"Text in Field : "+cemail);
                result.put("JSW3",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cemail+" || (Expected : rajkumar.natarajan+143@zohocorp.com)");
                TakeScreenshot.screenshot(driver,etest,"JSAPIEmail","JSApi","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.contactnumber()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","This API is used to fill the visitor contact number in the chat widget text box.");

            if(cphone.equals("9876544578"))
            {
                etest.log(Status.PASS,"Text in Field : "+cphone);
                result.put("JSW4",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cphone+" || (Expected : 9876544578)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiPhone","Error");
            }

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Widget code - $zoho.salesiq.visitor.question()");
            ComplexReportFactory.setValues(etest,"Automation","Widget code -  JSAPI","You can use this API to pre-fill a question in the chat widget.");

            if(cques.equals("Any Question? ..."))
            {
                etest.log(Status.PASS,"Text in Field : "+cques);
                result.put("JSW5",true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cques+" || (Expected : Any Question? ...)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiQuestion","Error");
            }

            ComplexReportFactory.closeTest(etest);

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfig","Error",e);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigBubble(WebDriver driver,String viewCk) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"name","bubblevisible").click();
            CommonUtil.elfinder(driver,"name","bubblevisible").sendKeys(viewCk);
            CommonUtil.elfinder(driver,"name","bubblesrc").click();
            CommonUtil.elfinder(driver,"name","bubblesrc").sendKeys(ResourceManager.getRealValue("image_salesiq"));
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error",e);
        }
    }

    public static void checkConfigBubble(WebDriver driver,String viewCk,String ent1,String ent2) throws IOException, InterruptedException
    {
        try
        {
            if(viewCk.equals("hide"))
            {
                result.put(ent1,false);
                if(CommonUtil.elfinder(driver,"id","zlsbubanim").getAttribute("style").contains("none")&&CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","zlsbubanim"),"tagname","img").getAttribute("src").equals(ResourceManager.getRealValue("image_salesiq")))
                {
                    etest.log(Status.PASS,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    result.put(ent1,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error");
                }
            }
            else
            {
                result.put(ent1,false);
                result.put(ent2,false);

                if(CommonUtil.elfinder(driver,"id","zlsbubanim").getAttribute("style").contains("block")&&CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","zlsbubanim"),"tagname","img").getAttribute("src").equals(ResourceManager.getRealValue("image_salesiq")))
                {
                    etest.log(Status.PASS,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    result.put(ent1,true);
                    result.put(ent2,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Bubble Visibility : "+viewCk+" Image : <img src='"+ResourceManager.getRealValue("image_salesiq")+"'>");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBubble","Error",e);
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigSys1(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fsystemmessages").click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("fsysmsg")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);

            CommonFunctions.enterValueSysMsg(driver,"fsyswaiting","Waiting Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusy","Busy Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusycomplete","Busy Response Message");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void checkConfigsys1(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JSW23",false);
            result.put("JSW24",false);
            result.put("JSW25",false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.initiateChat(driver,"Tester6","rajkumar.natarajan+1442@zohocorp.com","99887688667","is chat working properly ? ...");

            Thread.sleep(5000);
            
            VisitorWindow.switchToChatWidget(driver);
            
            String wResponse = VisitorWindow.getInfoMessage(driver);

            if(wResponse.contains("Waiting Message"))
            {
                etest.log(Status.PASS,"Waiting message : "+wResponse);
                result.put("JSW23",true);
            }
            else
            {
                etest.log(Status.FAIL,"Waiting message : "+wResponse+" || (Expected : Waiting Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiWaitingMessage","Error");
            }

          	
            VisitorWindow.switchToChatWidget(driver); 
            WebElement infobanr =  com.zoho.livedesk.util.common.CommonUtil.getElement(driver, By.className("info_banr siq-info-banner relate"));
            com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementDisplayed(driver, infobanr, 30);
            CommonWait.waitTillDisplayed(driver, By.className("info_banr siq-info-banner relate"));
            CommonWait.waitTillHidden(driver, By.className("info_banr siq-info-banner relate"));
           
            
            String bResponse = VisitorWindow.getInfoMessage(driver);

            if(bResponse.contains("Busy Message"))
            {
                etest.log(Status.PASS,"Busy message : "+bResponse);
                result.put("JSW24",true);
            }
            else
            {
                etest.log(Status.FAIL,"Busy message : "+bResponse+" || (Expected : Busy Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBuyMessage","Error");
            }
            
            VisitorWindow.submitResponseAfterMissingChatWithAgent(driver,"Hi");

            VisitorWindow.infoInvisible(driver);

            com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementContainsAttributeValue(VisitorWindow.getLastMessageElement(driver),"innerText","Hi");

            String brResponse = VisitorWindow.getInfoMessage(driver);

            if(brResponse.contains("Busy Response Message"))
            {
                etest.log(Status.PASS,"Busy response message : "+brResponse);
                result.put("JSW25",true);
            }
            else
            {
                etest.log(Status.FAIL,"Busy response message : "+brResponse+" || (Expected : Busy Response Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiBusyResponse","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void changeConfigSys(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fsystemmessages").click();

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("fsysmsg")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);

            CommonFunctions.enterValueSysMsg(driver,"fsyswaiting","Waiting Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusy","Busy Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysbusycomplete","Busy Response Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysengaged","Engaged Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysengagedcomplete","Engaged Response Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysprechatmessage","Pre Chat Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysofflinecomplete","Offline Response Message");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete1","Rated 1 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete2","Rated 2 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete3","Rated 3 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete4","Rated 4 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysfeedbackcomplete5","Rated 5 Star");
            CommonFunctions.enterValueSysMsg(driver,"fsysagentinfomessage","Agent Info Message");
            
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Entered values",0);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
            
            Thread.sleep(1500);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void checkConfigSys(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JSW26",false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);
            
            String preResponse = VisitorWindow.getInfoMessage(driver);

            if(preResponse.contains("Pre Chat Message"))
            {
                etest.log(Status.PASS,"Pre chat message : "+preResponse);
                result.put("JSW26",true);
            }
            else
            {
                etest.log(Status.FAIL,"Pre chat message : "+preResponse+" || (Expected : Pre Chat Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiPrechatMessage","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiPrechatMessage","Error",e);
        }
    }

    public static void checkConfigSys2(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result.put("JSW28",false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);
            
            VisitorWindow.initiateChatVisTheme(driver,"Tester7","rajkumar.natarajan+1249@zohocorp.com","9967682922",null,"what is zoho salesiq ? ...",false,etest,true);
            
            String orResponse = VisitorWindow.getInfoMessage(driver);
            
            if(orResponse.contains("Offline Response Message"))
            {
                etest.log(Status.PASS,"Offline response message : "+orResponse);
                result.put("JSW28",true);
            }
            else
            {
                etest.log(Status.FAIL,"Offline response message : "+orResponse+" || (Expected : Offline Response Message)");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOfflineResponseMessage","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigSysMsg","Error",e);
        }
    }

    public static void checkConfigSysFdbk(WebDriver driver,String rating,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            VisitorWindow.switchToChatWidget(driver);
            
            String response = VisitorWindow.getInfoMessage(driver);

            if(response.contains("Rated "+rating+" Star"))
            {
                etest.log(Status.PASS,"Feedback Response for "+rating+" rating : "+response);
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Feedback Response for "+rating+" rating : "+response);
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedbackRating","Error",e);
        }
    }

    public static void changeCSSConfig(WebDriver driver,String pos) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fname").click();
            new Select(driver.findElement(By.xpath(".//select[@id='fname']"))).selectByVisibleText(pos);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSConfig","Error",e);
        }
    }

    public static void checkCSSConfig(WebDriver driver,String pos,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            WebElement elmt = CommonUtil.elfinder(driver,"classname","zsiq_floatmain");
            
            wait.until(ExpectedConditions.visibilityOf(elmt));

            System.out.println("<<<<<<<<<----------------- CSS Value top --------------------------->>>>>>"+elmt.getCssValue("top"));
            System.out.println("<<<<<<<<<----------------- CSS Value left --------------------------->>>>>>"+elmt.getCssValue("left"));
            System.out.println("<<<<<<<<<----------------- CSS Value right --------------------------->>>>>>"+elmt.getCssValue("right"));
            System.out.println("<<<<<<<<<----------------- CSS Value bottom --------------------------->>>>>>"+elmt.getCssValue("bottom"));
            String top = elmt.getCssValue("top");
            String bottom = elmt.getCssValue("bottom");
            String left = elmt.getCssValue("left");
            String right = elmt.getCssValue("right");

            if(CommonFunctions.checkPos(top,bottom,left,right).equals(pos))
            {
                etest.log(Status.PASS,"Current Position : "+CommonFunctions.checkPos(top,bottom,left,right)+" || (Expected : "+pos+")");
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Current Position : "+CommonFunctions.checkPos(top,bottom,left,right)+" || (Expected : "+pos+")");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSConfig","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSConfig","Error",e);
        }
    }

    public static void changeFBImgConfig(WebDriver driver,String ename,String value) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"name",ename).click();
            CommonUtil.elfinder(driver,"name",ename).sendKeys(value);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOnlineImage","Error",e);
        }
    }

    public static void checkFBImgConfig(WebDriver driver,String value,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            if(CommonUtil.elfinder(driver,"id","zlsfltimg").getAttribute("src").equals(value))
            {
                etest.log(Status.PASS,"Image Found and Uploaded Image Match");
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Image Found and Uploaded Image do not match");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiImage","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiOnlineImage","Error",e);
        }
    }

    public static void changeThemeConfig(WebDriver driver,String color) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","ftheme").click();
            new Select(driver.findElement(By.xpath(".//select[@id='ftheme']"))).selectByVisibleText(color);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigTheme","Error",e);
        }
    }

    public static void checkThemeConfig(WebDriver driver,String color,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            WebElement elmt = CommonUtil.elfinder(driver,"id","zsiq_float");

            System.out.println("<<<<<<<<<----------------- CSS Value Color --------------------------->>>>>>"+elmt.getCssValue("background-color"));
            String curcol = elmt.getCssValue("background-color");

            if(curcol.equals(color))
            {
                etest.log(Status.PASS,"Current Theme : "+curcol+" || (Expected : "+color+")");
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Current Theme : "+curcol+" || (Expected : "+color+")");
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSColour","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCSSCTheme","Error",e);
        }
    }

    public static void changeConfigFeedback(WebDriver driver,String vis) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","feedbackvisible").click();
            new Select(driver.findElement(By.xpath(".//select[@id='feedbackvisible']"))).selectByVisibleText(vis);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error",e);
        }
    }

    public static void checkConfigSysFeedback(WebDriver driver,String vis,String rkey) throws Exception
    {
        try
        {
            result.put(rkey,false);
            
            VisitorWindow.switchToChatWidget(driver);

            rateChatIfRatingFound(driver);
            
            if(vis.equals("Show"))
            {
                if(feedbackFound(driver))
                {
                    etest.log(Status.PASS,"Show - Feedback Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Show - Feedback Not Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error");
                }
            }
            else
            {
                if(!feedbackFound(driver))
                {
                    etest.log(Status.PASS,"Hide - Feedback Not Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Hide - Feedback Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiFeedback","Error",e);
        }
    }

    public static boolean feedbackFound(WebDriver driver)
    {
        try
        {
            VisitorWindow.enterFeedbackInTheme(driver,"Feedback",null);
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public static void rateChatIfRatingFound(WebDriver driver,String rating) throws Exception
    {
      if(driver.findElements(By.className("rating")).get(0).isDisplayed())
      {
            VisitorWindow.enterFeedbackInTheme(driver,null,rating,true,null);
      }
    }

    public static void rateChatIfRatingFound(WebDriver driver) throws Exception
    {
            rateChatIfRatingFound(driver,"3");
    }

    public static void changeConfigRating(WebDriver driver,String vis) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","ratingvisible").click();
            new Select(driver.findElement(By.xpath(".//select[@id='ratingvisible']"))).selectByVisibleText(vis);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigRating","Error",e);
        }
    }

    public static void checkConfigSysRating(WebDriver driver,String vis,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            VisitorWindow.switchToChatWidget(driver);
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            if(vis.equals("Show"))
            {
                if(ratingFound(driver))
                {
                    etest.log(Status.PASS,"Show - Rating Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Show - Rating Not Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiRating","Error");
                }
            }
            else
            {
                if(!ratingFound(driver))
                {
                    etest.log(Status.PASS,"Hide - Rating Not Visible");
                    result.put(rkey,true);
                }
                else
                {
                    etest.log(Status.FAIL,"Hide - Rating Visible");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigRating","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiConfigRating","Error",e);
        }
    }

    public static boolean ratingFound(WebDriver driver)
    {
        try
        {
            VisitorWindow.enterFeedbackInTheme(driver,null,"1");

            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public static void changeConfigHTML(WebDriver driver,String txt,String elid) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmhtml")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmhtml").click();
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",elid)).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id",elid).click();
            CommonUtil.elfinder(driver,"id",elid).sendKeys(txt);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error",e);
        }
    }

    public static void checkConfigHTML(WebDriver driver,String rkey,String verEl,String imgEl) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait flwait = CommonUtil.waitreturner(driver,30,250);

            if(imgEl==null)
            {
                if(CommonUtil.elfinder(driver,"id","salesiqchat").getText().equals(verEl))
                {
                    CommonUtil.elfinder(driver,"id","salesiqchat").click();

                    try
                    {
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        etest.log(Status.PASS,"Custom HTML - Text : "+CommonUtil.elfinder(driver,"id","salesiqchat").getText());
                        result.put(rkey,true);
                    }
                    catch(Exception e)
                    {
                        etest.log(Status.FAIL,"Custom HTML - Text : "+CommonUtil.elfinder(driver,"id","salesiqchat").getText()+" || (Expected : "+verEl+" ) Onclick not working");
                        TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error",e);
                    }
                }
                else
                {
                    etest.log(Status.FAIL,"Custom HTML - Text : "+CommonUtil.elfinder(driver,"id","salesiqchat").getText()+" || (Expected : "+verEl+" )");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error");
                }
            }
            else
            {
                String imgsrc = "<img src ='"+CommonUtil.elfinder(driver,"id","salesiqchat").findElement(By.tagName("img")).getAttribute("src")+"'>";

                if(imgsrc.equals(imgEl))
                {
                    //CommonUtil.elfinder(driver,"id","salesiqchat").findElement(By.tagName("img")).click();
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[contains(@src,'"+CommonUtil.elfinder(driver,"id","salesiqchat").findElement(By.tagName("img")).getAttribute("src")+"')]")));

                    CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","salesiqchat"),"tagname","img").click();

                    try
                    {
                        wait.until(new Function<WebDriver,Boolean>(){
                            public Boolean apply(WebDriver driver)
                            {
                                if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                                {
                                    return true;
                                }
                                return false;
                            }
                        });

                        etest.log(Status.PASS,"Custom HTML - Image : "+imgsrc);
                        result.put(rkey,true);
                    }
                    catch(Exception e)
                    {
                        etest.log(Status.FAIL,"Custom HTML - Image : "+imgsrc+" Onclick not working");
                        TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApi","Error",e);
                    }
                }
                else
                {
                    etest.log(Status.FAIL,"Custom HTML - Image : "+imgsrc+" || (Expected : "+imgEl+")");
                    TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error");
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomHTML","Error",e);
        }
    }

    public static void changeConfigField(WebDriver driver,String field) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfield")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmfield").click();
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfieldname")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmfieldname").click();
            CommonUtil.elfinder(driver,"id","fctmfieldname").sendKeys("FieldName");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfieldhint")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fctmfieldhint").click();
            CommonUtil.elfinder(driver,"id","fctmfieldhint").sendKeys("FieldHint");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fctmfieldhint")).getLocation().y+")");
            Thread.sleep(300);

            List<WebElement> clElmt = driver.findElements(By.name("ctmfldtype"));

            for(WebElement elmt:clElmt)
            {
                if(elmt.getAttribute("value").equals(field))
                {
                    elmt.click();
                }
            }
            
            com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(driver.findElements(By.name("ctmfldreq")),"value","false").click();
            com.zoho.livedesk.util.common.CommonUtil.sleep(300);
            com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(driver.findElements(By.name("ctmfldvisibility")),"value","both").click();               
            com.zoho.livedesk.util.common.CommonUtil.sleep(300);


            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomField","Error",e);
        }
    }

    public static void checkConfigField(WebDriver driver,String rkey,String field) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisitorWindow.clickChatButton(driver);
            VisitorWindow.switchToChatWidget(driver);

            if(CommonUtil.elfinder(driver,"id","FieldName").getAttribute("type").equals(field))
            {
                etest.log(Status.PASS,"Field Added with the given details : "+field);
                com.zoho.livedesk.util.common.CommonUtil.sendKeysToWebElement(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("FieldName")),CUSTOM_FIELD_TEXT);
                com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,By.id("msgarea"));
                driver.switchTo().defaultContent();
                if(com.zoho.livedesk.util.common.CommonUtil.getElement(driver,CALLBACK_ID).getAttribute("innerText").contains(CALLBACK_EXECUTED_TEXT))
                {
                    result.put(rkey,true);
                    com.zoho.livedesk.util.common.CommonUtil.inViewPortSafe(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,CALLBACK_ID));
                    etest.log(Status.PASS,"Expected callback was executed while custom field was entered");
                    TakeScreenshot.infoScreenshot(driver,etest);
                }
                else
                {
                    etest.log(Status.FAIL,"callback param was not executed");
                    TakeScreenshot.screenshot(driver,etest);
                }
            }
            else
            {
                etest.log(Status.FAIL,"Unable to add field : "+field);
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomField","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiCustomField","Error",e);
        }
    }

    public static void changeConfigInfo(WebDriver driver,String txt) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","fvinfo").click();
            CommonUtil.elfinder(driver,"id","fvinfo").sendKeys(txt);
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(1500);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiVisitorInfo","Error",e);
        }
    }

    public static void checkConfigInfo(WebDriver driver,String rkey) throws IOException, InterruptedException
    {
        try
        {
            result.put(rkey,false);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vdvstinfo")));

            WebElement elmt = CommonUtil.elfinder(driver,"id","cinfo");
            String keyElmt = CommonUtil.elementfinder(driver,elmt,"classname","crmld_inflft").getText();
            String valElmt = CommonUtil.elementfinder(driver,elmt,"classname","crmld_infrht").getText();

            if(keyElmt.equals("Payment Expiry")&&valElmt.equals("Jan 20, 2017"))
            {
                etest.log(Status.PASS,"Visitor Info : "+keyElmt+" : "+valElmt);
                result.put(rkey,true);
            }
            else
            {
                etest.log(Status.FAIL,"Visitor Info : "+keyElmt+" : "+valElmt);
                TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiVisitorInfo","Error");
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"JSAPI","JSApiVisitorInfo","Error",e);
        }
    }

      public static void initialSetup(WebDriver driver,WebDriver ApiDriver,ExtentTest etest)
      {
            String users = "";
            String type = "depttype_publi";
            try
            {
                  FluentWait wait = CommonUtil.waitreturner(ApiDriver,30,250);

                  Tab.clickSettings(driver);
                  List<WebElement> operatorsList = com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("ulisttable")).findElements(By.className("list-row"));
                  for(WebElement operator : operatorsList)
                  {
                      users += com.zoho.livedesk.util.common.CommonUtil.getElement(operator,By.className("ulist_uname"),By.className("txtelips")).getText();
                  }
                  Department.addDept(driver,deptname,type,users,etest);

                  Tab.navToEmbedTab(driver);

                  WebEmbed.clickWebEmbed(driver,embed,etest);

                  WebsitesTab.clickLiveChat(driver,etest);

                  WebsitesTab.clickWidget(driver,etest);

                  WebsitesTab.clickButtonWidget(driver,etest);

                  TakeScreenshot.infoScreenshot(driver,etest);

                  WebsitesTab.closeEmbedConfig(driver,etest);

                  //visitor name
                  CommonFunctions.enterValue(ApiDriver,"fname","Tester");

                  //visitor email
                  CommonFunctions.enterValue(ApiDriver,"femail","test@test.com");

                  //visitor question
                  CommonFunctions.enterValue(ApiDriver,"fquestion","Testing JSAPI");

                  //chat.department
                  CommonFunctions.enterValue(ApiDriver,"department",dept);

                  //chat.agent
                  CommonFunctions.enterValue(ApiDriver,"agentchat",usermail);

                  //chat.title
                  CommonFunctions.enterValue(ApiDriver,"fctitle",TITLE_TEXT);

                  //chat logo
                  CommonFunctions.enterValue(ApiDriver,"fclogo",CHAT_LOGO);

                  //chat button texts
                  CommonFunctions.selectElementById(ApiDriver,"fbtxt");

                  //chat button icon
                  CommonFunctions.enterValue(ApiDriver,"chatbuttonicon",CHAT_LOGO);

                  //chat button width
                  CommonFunctions.enterValue(ApiDriver,"chatbuttonwidth","500");

                  //chat button online icon
                  CommonFunctions.enterValue(ApiDriver,"chatbuttononline",CHAT_LOGO);

                  //chat button offline icon
                  CommonFunctions.enterValue(ApiDriver,"chatbuttonoffline",CHAT_LOGO);

                  //chat start()
                  CommonFunctions.selectElementById(ApiDriver,"fchatstart");

                  //chat complete
                  CommonFunctions.selectElementById(ApiDriver,"fchatcmplete");

                  //chat.mode("none");
                  CommonFunctions.enterValue(ApiDriver,"fchatmode","none");

                  //chat.forward
                  CommonFunctions.enterValue(ApiDriver,"fchatforward","true");

                  TakeScreenshot.infoScreenshot(ApiDriver,etest);

                  //adding custom field
                  CommonFunctions.selectElementById(ApiDriver,"fctmfield");
                  CommonFunctions.enterValue(ApiDriver,"fctmfieldname","CustomFieldName");
                  CommonFunctions.enterValue(ApiDriver,"fctmfieldhint","CustomFieldHint");
                  
                  List<WebElement> fieldType = ApiDriver.findElements(By.name("ctmfldtype"));
                  com.zoho.livedesk.util.common.CommonUtil.clickWebElement(ApiDriver,com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(fieldType,"value","text"));

                  List<WebElement> fieldRequired = ApiDriver.findElements(By.name("ctmfldreq"));
                  com.zoho.livedesk.util.common.CommonUtil.clickWebElement(ApiDriver,com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(fieldRequired,"value","false"));

                  List<WebElement> fieldVisibility = ApiDriver.findElements(By.name("ctmfldvisibility"));
                  com.zoho.livedesk.util.common.CommonUtil.clickWebElement(ApiDriver,com.zoho.livedesk.util.common.CommonUtil.getElementByAttributeValue(fieldVisibility,"value","both"));

                  //custom field clear
                  CommonFunctions.selectElementById(ApiDriver,"fctmfieldclear");

                  //tracking on
                  CommonFunctions.selectElementById(ApiDriver,"trackingon");

                  TakeScreenshot.infoScreenshot(ApiDriver,etest);

                  //chat button click
                  CommonFunctions.selectElementById(ApiDriver,"evtchatbuttonclk");

                  TakeScreenshot.infoScreenshot(ApiDriver,etest);

                  //visitor missed
                  CommonFunctions.selectElementById(ApiDriver,"evtvisitormissed");

                  //visitor trigger
                  CommonFunctions.selectElementById(ApiDriver,"evtvisitortrigger");

                  //visitor idle time
                  CommonFunctions.enterValue(ApiDriver,"visitoridletime","0.1");

                  //visitor idle
                  CommonFunctions.selectElementById(ApiDriver,"evtvisitoridle");

                  //visitor active
                  CommonFunctions.selectElementById(ApiDriver,"evtvisitoractive");

                  com.zoho.livedesk.util.common.CommonUtil.sleep(1000);

                  TakeScreenshot.infoScreenshot(ApiDriver,etest);

                  CommonFunctions.selectElementById(ApiDriver,"fsubbutton");

                  // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_chatbtn")));
                  wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiqbtn")));

            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(ApiDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  e.printStackTrace();
            }
      }

      public static boolean checkChatMode(WebDriver driver,WebDriver ApiDriver,ExtentTest etest,boolean isClick)
      {
            boolean isNotificationPresent = false;
            Status clickStatus = isClick?Status.PASS:Status.FAIL;
            Status noneStatus = isClick?Status.FAIL:Status.PASS;
            String clickdesc = isClick?"click":"none";

            try
            {
                  VisitorWindow.clickChatButton(ApiDriver);
                  if(ChatWindow.chatNotificationPresence(driver,etest))
                  {
                        etest.log(clickStatus,"Chat notification is present for chat.mode(\""+clickdesc+"\")");
                        isNotificationPresent = true;
                  }
                  else
                  {
                        etest.log(noneStatus,"Chat notification is not present for chat.mode(\""+clickdesc+"\")");
                  }
                  if((isClick && isNotificationPresent) || (!isClick && !isNotificationPresent))
                  {
                        return true;
                  }
                  else
                  {
                        TakeScreenshot.screenshot(driver,etest);
                        TakeScreenshot.screenshot(ApiDriver,etest);
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(ApiDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkTriggerValues(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  if(CommonUtil.elfinder(driver,"id","triggerName").getText() != "")
                  {
                        etest.log(Status.PASS,"Trigger Name : "+CommonUtil.elfinder(driver,"id","triggerName").getText());
                        etest.log(Status.PASS,"Visitor Name : "+CommonUtil.elfinder(driver,"id","triggerVisitorName").getText());
                        etest.log(Status.PASS,"Visitor Email : "+CommonUtil.elfinder(driver,"id","triggerVisitorEmail").getText());
                        etest.log(Status.PASS,"Visitor Phone : "+CommonUtil.elfinder(driver,"id","triggerVisitorPhone").getText());
                        etest.log(Status.PASS,"Visitor Browser : "+CommonUtil.elfinder(driver,"id","triggerVisitorBrowser").getText());
                        etest.log(Status.PASS,"Visitor OS :"+CommonUtil.elfinder(driver,"id","triggerVisitorOs").getText());
                        etest.log(Status.PASS,"Visitor IP Address : "+CommonUtil.elfinder(driver,"id","triggerVisitorIp").getText());
                        etest.log(Status.PASS,"Visitor Country Code : "+CommonUtil.elfinder(driver,"id","triggerVisitorCC").getText());
                        etest.log(Status.PASS,"Visitor Region : "+CommonUtil.elfinder(driver,"id","triggerVisitorRegion").getText());
                        etest.log(Status.PASS,"Visitor State : "+CommonUtil.elfinder(driver,"id","triggerVisitorState").getText());
                        etest.log(Status.PASS,"Visitor City : "+CommonUtil.elfinder(driver,"id","triggerVisitorCity").getText());
                        etest.log(Status.PASS,"Visitor Past Chats : "+CommonUtil.elfinder(driver,"id","triggerVisitorPastChats").getText());
                        etest.log(Status.PASS,"Visitor No of visits : "+CommonUtil.elfinder(driver,"id","triggerVisitorVisits").getText());
                        etest.log(Status.PASS,"Visitor No of days visited : "+CommonUtil.elfinder(driver,"id","triggerVisitorVisitDays").getText());
                        etest.log(Status.PASS,"Visitor total Time spent : "+CommonUtil.elfinder(driver,"id","triggerVisitorSpentTime").getText());
                        etest.log(Status.PASS,"Visitor First visit (in milliseconds) : "+CommonUtil.elfinder(driver,"id","triggerVisitorVisitFirstTime").getText());
                        etest.log(Status.PASS,"Visitor Last visit (in milliseconds) : "+CommonUtil.elfinder(driver,"id","triggerVisitorVisitLastTime").getText());
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
                  else
                  {
                        etest.log(Status.FAIL,"Failed");
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","triggerName")).getLocation().y+"-500)");
                        TakeScreenshot.screenshot(driver,etest);
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest);
                  return false;
            }
      }

      public static void setupForFloatWidgetTheme(WebDriver driver,WebDriver ApiDriver,ExtentTest etest)
      {
            try
            {
                  FluentWait wait = CommonUtil.waitreturner(ApiDriver,30,250);

                  Tab.navToEmbedTab(driver);

                  WebEmbed.clickWebEmbed(driver,embed,etest);

                  WebsitesTab.clickLiveChat(driver,etest);

                  WebsitesTab.clickWidget(driver,etest);

                  WebsitesTab.clickFloatWidget(driver,etest);

                  TakeScreenshot.infoScreenshot(driver,etest);

                  WebsitesTab.closeEmbedConfig(driver,etest);

                  //visitor name
                  CommonFunctions.enterValue(ApiDriver,"fname","Tester");

                  //visitor email
                  CommonFunctions.enterValue(ApiDriver,"femail","test@test.com");

                  //visitor question
                  CommonFunctions.enterValue(ApiDriver,"fquestion","Testing JSAPI");

                  //chat.department
                  CommonFunctions.enterValue(ApiDriver,"department",dept);

                  //chat start
                  CommonFunctions.selectElementById(ApiDriver,"fchatstart");

                  //chat complete
                  CommonFunctions.selectElementById(ApiDriver,"fchatcmplete");

                  //chat.mode("click");
                  CommonFunctions.enterValue(ApiDriver,"fchatmode","click");

                  //transferchat
                  CommonFunctions.selectElementById(ApiDriver,"evtchattransfer");

                  //accepttransferred chat
                  CommonFunctions.selectElementById(ApiDriver,"evtchataccepttransfer");

                  //float button click
                  CommonFunctions.selectElementById(ApiDriver,"evtbuttonclk");

                  //tracking off
                  CommonFunctions.selectElementById(ApiDriver,"trackingoff");

                  com.zoho.livedesk.util.common.CommonUtil.sleep(1000);

                  TakeScreenshot.infoScreenshot(ApiDriver,etest);

                  CommonFunctions.selectElementById(ApiDriver,"fsubbutton");

                  wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
            }
      }

      public static boolean isVisitorTracked(WebDriver driver,WebDriver ApiDriver,ExtentTest etest,boolean toBeTracked)
      {
            boolean tracked = false;
            boolean notTracked = false;
            try
            {
                  Status trackedStatus = toBeTracked?Status.PASS:Status.FAIL;
                  Status notTrackedStatus = toBeTracked?Status.FAIL:Status.PASS;
                  String trackingSetStatus = toBeTracked?"on":"off";
                  String visitorId = VisitorWindow.getVisitorId(ApiDriver,PORTAL_NAME);
                  System.out.println(PORTAL_NAME+"<><><><><><><>"+visitorId);
                  Tab.clickVisitorsOnline(driver);
                  com.zoho.livedesk.util.common.CommonUtil.sleep(1000);
                  if(CommonUtil.elfinder(driver,"id","ldwrap").getAttribute("innerHTML").contains(visitorId))
                  {
                        etest.log(trackedStatus,"Visitor was tracked in the rings after the tracking was set "+trackingSetStatus);
                        tracked = true;
                  }
                  else
                  {
                        etest.log(notTrackedStatus,"Visitor was not tracked in the rings after the tracking was set "+trackingSetStatus);
                        notTracked = true;
                  }
                  if((toBeTracked && tracked) || (!toBeTracked && notTracked))
                  {
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
                  else
                  {
                        TakeScreenshot.screenshot(driver,etest);
                        TakeScreenshot.screenshot(ApiDriver,etest);
                        etest.log(Status.FAIL,"FAILED");
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkButtonClick(WebDriver driver,ExtentTest etest,String widgetId)
      {
            int failcount = 0;
            try
            {
                  if(CommonUtil.elfinder(driver,"id",widgetId).getText().toLowerCase().contains("true"))
                  {
                        etest.log(Status.PASS,"Checked");
                  }
                  else
                  {
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",widgetId)).getLocation().y+"-500)");
                        etest.log(Status.FAIL,"FAILED");
                        TakeScreenshot.screenshot(driver,etest);
                        failcount++;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  failcount++;
            }
            return com.zoho.livedesk.util.common.CommonUtil.returnResult(failcount);
      }

      public static boolean isCustomFieldCleared(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  VisitorWindow.clickChatButton(driver);
                  CommonFunctions.selectElementById(driver,"fctmfieldclear");
                  com.zoho.livedesk.util.common.CommonUtil.sleep(1000);
                  try
                  {
                        if(CommonUtil.elfinder(driver,"id","CustomFieldName").isDisplayed())
                        {
                              etest.log(Status.FAIL,"FAILED");
                              ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","CustomFieldName")).getLocation().y+"-500)");
                              TakeScreenshot.screenshot(driver,etest);
                              return false;
                        }
                        else
                        {
                              etest.log(Status.PASS,"Checked");
                              return true;
                        }
                  }
                  catch(Exception e)
                  {
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkChatStarted(WebDriver driver,WebDriver ApiDriver,ExtentTest etest)
      {
            try
            {
                  VisitorWindow.clickChatButton(ApiDriver);

                  com.zoho.livedesk.util.common.actions.ExecuteStatements.run(ApiDriver,"$zoho.salesiq.chat.start()");

                  // com.zoho.livedesk.util.common.CommonUtil.jsClick(ApiDriver,"#"+"chatstart");
                  // com.zoho.livedesk.util.common.CommonUtil.scrollIntoView(ApiDriver,By.id("chatstart"));

                  if(ChatWindow.chatNotificationPresence(driver,etest,30))
                  {
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
                  else
                  {
                        etest.log(Status.FAIL,"FAILED");
                        TakeScreenshot.screenshot(driver,etest);
                        TakeScreenshot.screenshot(ApiDriver,etest);
                        return false;
                  }

            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(ApiDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkAgentRouted(WebDriver driver,WebDriver supDriver,ExtentTest etest)
      {
            try
            {
                  boolean isChatRoutedToSupervisor = ChatRouting.isChatRoutedToAgent(supDriver);
                  boolean isChatRoutedToAdmin = ChatRouting.isChatRoutedToAgent(driver);

                  if(isChatRoutedToAdmin && isChatRoutedToSupervisor)
                  {
                        etest.log(Status.PASS,"Routing status Checked");
                        return true;
                  }
                  else
                  {
                        etest.log(Status.FAIL,"Chat Routing FAILED");
                        TakeScreenshot.screenshot(driver,etest);
                        TakeScreenshot.screenshot(supDriver,etest);
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(supDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkIdleTime(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  //waiting for visitor to be idle
                JavascriptExecutor jse = (JavascriptExecutor)driver;
                jse.executeScript("window.open()");
                com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,1);

                Thread.sleep(10000);

                driver.close();
                com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,0);

                  if(checkVisitorIdleStatus(driver,etest,"evntvidle"))
                  {
                      CommonUtil.elfinder(driver,"id","evntvidle").click();
                      return true;
                  }
                  else
                  {
                      CommonUtil.elfinder(driver,"id","evntvidle").click();
                      return false;
                  }

            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkVisitorIdleStatus(WebDriver driver,ExtentTest etest,String id)
      {
            try
            {
                  if(CommonUtil.elfinder(driver,"id",id).getText().toLowerCase().contains("true"))
                  {
                      etest.log(Status.PASS,"Checked");
                      return true;
                  }
                  else
                  {
                      etest.log(Status.FAIL,"Failed");
                      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","evntvidle")).getLocation().y+"-500)");
                      TakeScreenshot.screenshot(driver,etest);
                      return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkAgentForwarded(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  if(ChatWindow.chatNotificationPresence(driver,etest,30))
                  {
                        etest.log(Status.PASS,"Agent forward Checked");
                        return true;
                  }
                  else
                  {
                        etest.log(Status.FAIL,"Agent forward FAILED");
                        TakeScreenshot.screenshot(driver,etest);
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkChatMissed(WebDriver driver,ExtentTest etest)
      {
            try
            {
                  //wait till chat missed
                  VisitorWindow.waitTillChatisMissedInTheme(driver);
                  driver.switchTo().defaultContent();

                  com.zoho.livedesk.util.common.CommonUtil.sleep(1000);

                  System.out.println("<><><>"+CommonUtil.elfinder(driver,"id","evntmisseddname").getText());

                  if(CommonUtil.elfinder(driver,"id","evntmisseddname").getText() != "")
                  {
                        etest.log(Status.PASS,"Visitor id : "+CommonUtil.elfinder(driver,"id","evntvmissedid").getText());
                        etest.log(Status.PASS,"Visitor Name : "+CommonUtil.elfinder(driver,"id","evntmisseddname").getText());
                        etest.log(Status.PASS,"Visitor Email : "+CommonUtil.elfinder(driver,"id","evntmisseddemail").getText());
                        etest.log(Status.PASS,"Visitor question : "+CommonUtil.elfinder(driver,"id","evntmisseddques").getText());
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
                  else
                  {
                        etest.log(Status.FAIL,"FAILED");
                        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","evntmisseddname")).getLocation().y+"-500)");
                        TakeScreenshot.screenshot(driver,etest);
                        return false;
                  }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkChatTransferred(WebDriver driver,WebDriver supDriver,WebDriver ApiDriver,ExtentTest etest)
      {
            try
            {
                  Tab.clickMyChats(driver);
                  CommonFunctionsTC.clickTransferChat(driver,etest);
                  com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("popupdiv"),By.id("usrcontainer"),By.tagName("li")));
                  CommonWait.waitTillDisplayed(driver,By.id("popupdiv"),By.id("seldiv"));
                  com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("popupdiv"),By.id("btnsub")));
                  ApiDriver.switchTo().defaultContent();
                  if(CommonUtil.elfinder(ApiDriver,"id","transferChatVisitid").getText() != "")
                  {
                        etest.log(Status.PASS,"Visitor Id :"+CommonUtil.elfinder(ApiDriver,"id","transferChatVisitid").getText());
                        etest.log(Status.PASS,"Current User :"+CommonUtil.elfinder(ApiDriver,"id","transferChatCurrentuser").getText());
                        etest.log(Status.PASS,"Transfer Type :"+CommonUtil.elfinder(ApiDriver,"id","transferChatType").getText());
                        etest.log(Status.PASS,"Transferred to :"+CommonUtil.elfinder(ApiDriver,"id","transferChatName").getText());
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
                  ((JavascriptExecutor) ApiDriver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","transferChatVisitid")).getLocation().y+"-500)");
                  TakeScreenshot.screenshot(driver,etest);
                  return false;
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(supDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(ApiDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkChatTransferAccepted(WebDriver driver,WebDriver supDriver,WebDriver ApiDriver,ExtentTest etest)
      {
            try
            {
                  CommonFunctionsTC.acceptInvite(supDriver,etest);
                  ApiDriver.switchTo().defaultContent();
                  if(CommonUtil.elfinder(ApiDriver,"id","acceptTransferVisitid").getText() != "")
                  {
                        etest.log(Status.PASS,"Visitor Id :"+CommonUtil.elfinder(ApiDriver,"id","acceptTransferVisitid").getText());
                        etest.log(Status.PASS,"Attender name :"+CommonUtil.elfinder(ApiDriver,"id","acceptTransferAttenderName").getText());
                        etest.log(Status.PASS,"Attender mail:"+CommonUtil.elfinder(ApiDriver,"id","acceptTransferAttenderEmail").getText());
                        etest.log(Status.PASS,"Department :"+CommonUtil.elfinder(ApiDriver,"id","acceptTransferDepartment").getText());
                        etest.log(Status.PASS,"Checked");
                        return true;
                  }
                  ((JavascriptExecutor) ApiDriver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","acceptTransferVisitid")).getLocation().y+"-500)");
                  TakeScreenshot.screenshot(ApiDriver,etest);
                  TakeScreenshot.screenshot(driver,etest);
                  TakeScreenshot.screenshot(supDriver,etest);
                  return false;
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(supDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(ApiDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkChatCompleted(WebDriver driver,WebDriver ApiDriver,ExtentTest etest) throws Exception
      {
            boolean success = false;
            try
            {
                  VisitorWindow.endChat(ApiDriver);
                  CommonFunctions.selectElementById(ApiDriver,"chatcomplete");
                  VisitorWindow.checkChatEndedInTheme(ApiDriver);
                  etest.log(Status.PASS,"Checked");
                  success = true;
                  Tab.clickSettings(driver);
                  Department.deleteDepartment(driver,deptname,dept,etest);
                  return success;
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(ApiDriver,etest,MODULE_NAME,"Exception","Exception",e);
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  Tab.clickSettings(driver);
                  Department.deleteDepartment(driver,deptname,dept,etest);
            }
            return success;
      }

    public static void checkChatWidgetVisible(ExtentTest etest)
    {
        WebDriver driver = null;
        try
        {
            driver = Functions.setUp();
            String siteName = Util.setUptracking();

            if(siteName.equals("local"))
            {
                siteName = "LocalZoho";
            }

            else if(siteName.equals("pre"))
            {
                siteName = "Pre SalesIQ";
            }

            else if(siteName.equals("idc"))
            {
                siteName = "IDC";
            }

            else
            {
                siteName = "IDC";
            }

            result.put("JSW710",checkElementDisplayed(driver,widgetcode,siteName,"zsiqbtn","chatbuttonshow",false,true,true,etest));
            result.put("JSW711",checkElementDisplayed(driver,widgetcode,siteName,"zsiqbtn","chatbuttonhide",false,true,false,etest));
            result.put("JSW712",checkElementDisplayed(driver,widgetcode,siteName,"zsiqbtn","chatbuttondelay",true,true,true,etest));

            result.put("JSW750",checkElementDisplayed(driver,widgetcode,siteName,"zsiqbtn","chatwindowshow",false,false,true,etest));
            result.put("JSW751",checkElementDisplayed(driver,widgetcode,siteName,"zsiqbtn","chatwindowhide",false,false,false,etest));
            result.put("JSW752",checkElementDisplayed(driver,widgetcode,siteName,"zsiqbtn","chatwindowdelay",true,false,true,etest));

            driver.quit();

        }
        catch(Exception e)
        {
              TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
        }
    }

    public static void checkFloatWidgetVisible(ExtentTest etest)
    {
        WebDriver driver = null;
        try
        {
            driver = Functions.setUp();
            String siteName = Util.setUptracking();

            if(siteName.equals("local"))
            {
                siteName = "LocalZoho";
            }

            else if(siteName.equals("pre"))
            {
                siteName = "Pre SalesIQ";
            }

            else if(siteName.equals("idc"))
            {
                siteName = "IDC";
            }

            else
            {
                siteName = "IDC";
            }

            result.put("JSW760",checkElementDisplayed(driver,widgetcode,siteName,"zsiq_float","floatbuttonshow",false,true,true,etest));
            result.put("JSW761",checkElementDisplayed(driver,widgetcode,siteName,"zsiq_float","floatbuttonhide",false,true,false,etest));
            result.put("JSW762",checkElementDisplayed(driver,widgetcode,siteName,"zsiq_float","floatbuttondelay",true,true,true,etest));

            result.put("JSW770",checkElementDisplayed(driver,widgetcode,siteName,"zsiq_float","floatwindowshow",false,false,true,etest));
            result.put("JSW771",checkElementDisplayed(driver,widgetcode,siteName,"zsiq_float","floatwindowhide",false,false,false,etest));
            result.put("JSW772",checkElementDisplayed(driver,widgetcode,siteName,"zsiq_float","floatwindowdelay",true,false,true,etest));

            driver.quit();

        }
        catch(Exception e)
        {
              TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
        }
    }

    public static boolean checkElementDisplayed(WebDriver driver,String widgetcode,String siteName,String element,String id,boolean isDelay,boolean isButton,boolean isVisible,ExtentTest etest)
    {
        try
        {
            driver.get(JSAPI_URL);
            Thread.sleep(1000);
            CommonFunctions.choosePortal(driver,widgetcode,siteName);
            CommonWait.waitTillDisplayed(driver,By.id("flang"));

            if(isDelay)
            {
                CommonFunctions.enterValue(driver,id,"3");
            }
            else
            {
                CommonFunctions.selectElementById(driver,id);
            }
            CommonFunctions.selectElementById(driver,"fsubbutton");

            Thread.sleep(1000);
            if(isButton)
            {
                if(checkButtonVisible(driver,etest,element,isDelay) == isVisible)
                {
                    etest.log(Status.PASS,id+" Checked");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,id+" FAILED");
                    return false;
                }
            }
            else
            {
                if(checkWindowVisible(driver,etest,isDelay) == isVisible)
                {
                    etest.log(Status.PASS,id+" Checked");
                    return true;
                }
                else
                {
                    etest.log(Status.FAIL,id+" FAILED");
                    return false;
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
            return false;
        }
    }

    public static boolean checkButtonVisible(WebDriver driver,ExtentTest etest,String id,boolean isDelay)
      {
            try
            {
                if(isDelay)
                {
                    com.zoho.livedesk.util.common.CommonUtil.sleep(3000);
                }
                com.zoho.livedesk.util.common.CommonUtil.sleep(1000);
                if(CommonUtil.elfinder(driver,"id",id).isDisplayed())
                {
                    TakeScreenshot.infoScreenshot(driver,etest);
                    return true;
                }
                else
                {
                    TakeScreenshot.infoScreenshot(driver,etest);
                    return false;
                }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

      public static boolean checkWindowVisible(WebDriver driver,ExtentTest etest,boolean isDelay)
      {
            try
            {
                if(isDelay)
                {
                    com.zoho.livedesk.util.common.CommonUtil.sleep(3000);
                }
                com.zoho.livedesk.util.common.CommonUtil.sleep(1000);
                if(CommonUtil.elfinder(driver,"classname","zls-sptwndw").getAttribute("class").contains("siqanim"))
                {
                    TakeScreenshot.infoScreenshot(driver,etest);
                    return true;
                }
                else
                {
                    TakeScreenshot.infoScreenshot(driver,etest);
                    return false;
                }
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
                  return false;
            }
      }

    public static boolean checkLanguage(ExtentTest etest)
    {
        WebDriver driver = null;
        int failcount = 0;
        try
        {
            driver = Functions.setUp();
            String siteName = Util.setUptracking();

            if(siteName.equals("local"))
            {
                siteName = "LocalZoho";
            }

            else if(siteName.equals("pre"))
            {
                siteName = "Pre SalesIQ";
            }

            else if(siteName.equals("idc"))
            {
                siteName = "IDC";
            }

            else
            {
                siteName = "IDC";
            }
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            for(int i = 0; i < LANGUAGE.length; i++)
            {
                driver.get(JSAPI_URL);
                Thread.sleep(1000);
                CommonFunctions.choosePortal(driver,widgetcode,siteName);
                CommonWait.waitTillDisplayed(driver,By.id("flang"));
                Select dropdown = new Select(driver.findElement(By.id("flang")));
                dropdown.selectByIndex(i);

                com.zoho.livedesk.util.common.CommonUtil.sleep(1000);
                CommonFunctions.selectElementById(driver,"fsubbutton");

                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_float")));

                VisitorWindow.clickChatButton(driver);
                VisitorWindow.switchToChatWidget(driver);
                if(!CommonFunctions.isValueSet(driver,"attname","innerText",SAMPLE_LANGUAGE[i],LANGUAGE[i]+" text ",etest))
                {
                    TakeScreenshot.screenshot(driver,etest);
                    failcount++;
                }
            }
            driver.quit();
        }
        catch(Exception e)
        {
              TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
              failcount++;
        }
        return com.zoho.livedesk.util.common.CommonUtil.returnResult(failcount);
    }

    public static void checkResetAPI(WebDriver driver,WebDriver driver2,ExtentTest etest) throws Exception
    {
        String label=com.zoho.livedesk.util.common.CommonUtil.getUniqueMessage();
        WebDriver visitor_driver=null;

        try
        {
            //visitor in rings
            visitor_driver=visitor_driver_manager.getDriver(driver);
            VisitorWindow.createPage(visitor_driver,widgetcode);
            String visitor_id_before_invoke=VisitorWindow.getVisitorId(visitor_driver,ExecuteStatements.getPortal(driver));
            VisitorsOnline.waitTillVisitorPresent(driver,visitor_id_before_invoke);

            //invoke
            invokeResetAPI(visitor_driver);
            com.zoho.livedesk.util.common.CommonUtil.sleep(5000);

            //check new visitor
            VisitorsOnline.waitTillVisitorTracked(driver,visitor_driver);
            String visitor_id_after_invoke=VisitorWindow.getVisitorId(visitor_driver,ExecuteStatements.getPortal(driver));

            if(visitor_id_before_invoke.equals(visitor_id_after_invoke))
            {
                etest.log(Status.FAIL,"New visitor was NOT found .Same visitor id was found in rings after invoking $zoho.salesiq.reset()");
                TakeScreenshot.screenshot(visitor_driver,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
                result.put("JSW90",false);
            }
            else
            {
                etest.log(Status.PASS,"New visitor was found .Same visitor id was NOT found in rings after invoking $zoho.salesiq.reset()");
                TakeScreenshot.infoScreenshot(visitor_driver,etest);
                TakeScreenshot.infoScreenshot(visitor_driver,etest);
                result.put("JSW90",true);
            }

            //check old left
            try
            {
                VisitorsOnline.waitTillVisitorLeaves(driver,visitor_id_before_invoke);
                etest.log(Status.PASS,"Visitor added before invoking reset api has left the rings");
                result.put("JSW89",true);
                TakeScreenshot.infoScreenshot(driver,etest);
                TakeScreenshot.infoScreenshot(visitor_driver,etest);
            }
            catch(Exception e)
            {
                etest.log(Status.FAIL,"Visitor added before invoking reset api has NOT left the rings");
                result.put("JSW89",false);
                TakeScreenshot.screenshot(driver,etest,e);
                TakeScreenshot.screenshot(visitor_driver,etest,e);
                com.zoho.livedesk.util.common.CommonUtil.printStackTrace(e);
            }

            String
            visitor_name="V"+label,
            visitor_mail="email@"+label+".com",
            visitor_question="Hello?"
            ;

            visitor_driver=visitor_driver_manager.getDriver(driver);
            VisitorWindow.createPage(visitor_driver,widgetcode);
            VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
            ChatWindow.acceptChat(driver,etest);

            invokeResetAPI(visitor_driver);
            com.zoho.livedesk.util.common.CommonUtil.sleep(5000);

            //is chat cleared in visitor side
            if(VisitorWindow.isVisitorQuestionInputFound(visitor_driver))
            {
                etest.log(Status.PASS,"Visitor Side : Ongoing chat was ended after invoking reset API");
                result.put("JSW94",true);
            }
            else
            {
                etest.log(Status.FAIL,"Visitor Side : Ongoing chat was NOT ended after invoking reset API");
                result.put("JSW94",false);
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
            }


            //is end in agent
            if(ChatWindow.isChatEnded(driver,visitor_name))
            {
                etest.log(Status.PASS,"Agent Side : Ongoing chat was ended after invoking reset API");
                result.put("JSW91",true);
            }
            else
            {
                etest.log(Status.FAIL,"Agent Side : Ongoing chat was NOT ended after invoking reset API");
                result.put("JSW91",false);
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
            }

            ChatWindow.closeAllChats(driver);

            //transfer chat
            visitor_driver=visitor_driver_manager.getDriver(driver);
            VisitorWindow.createPage(visitor_driver,widgetcode);
            VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
            ChatWindow.acceptChat(driver,etest);

            CommonFunctionsTC.transferChat(driver,etest,false,null,null,ExecuteStatements.getUserName(driver2));

            ChatWindow.waitTillAcceptTransferUI(driver2);
            TakeScreenshot.infoScreenshot(driver2,etest);

            invokeResetAPI(visitor_driver);
            com.zoho.livedesk.util.common.CommonUtil.sleep(5000);

            if(ChatWindow.isAgentAcceptTransferUIShown(driver2)==false)
            {
                etest.log(Status.PASS,"Tranfer UI was hidden after calling reset API");
                result.put("JSW92",true);
            }
            else
            {
                etest.log(Status.FAIL,"Tranfer UI was NOT hidden after calling reset API");
                result.put("JSW92",false);
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.screenshot(driver2,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
            }


            //is end in agent
            if(ChatWindow.isChatEnded(driver,visitor_name))
            {
                etest.log(Status.PASS,"Chat to be transfered was ended after calling reset API");
                result.put("JSW93",true);
            }
            else
            {
                etest.log(Status.FAIL,"Chat to be transfered was NOT ended after calling reset API");
                result.put("JSW93",false);
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
            }

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);          
            TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);          
        }
        finally
        {
            com.zoho.livedesk.util.common.CommonUtil.doNothing();   
        }
    }

    public static void checkDomainAPI(WebDriver driver,ExtentTest etest) throws Exception
    {
        String label=com.zoho.livedesk.util.common.CommonUtil.getUniqueMessage();

        String
        visitor_name="V"+label,
        visitor_mail="email@"+label+".com",
        visitor_question="Hello?"
        ;

        try
        {
          String code=ExecuteStatements.getWidgetCode(driver);
          String user=ExecuteStatements.getUserName(driver);

          //get domain str
          String domain=Util.getDomainName();

          //open cliq in tab2
          ExecuteStatements.openNewTab(driver,Util.getPeopleURL());

          //load widget
          ExecuteStatements.loadDomainAPIJS(driver,code);

          if(VisitorWindow.isFloatWidgetFound(driver))
          {
            etest.log(Status.INFO,"Widget was loaded successfully cross domain");
            TakeScreenshot.infoScreenshot(driver,etest);
          }

          //init chat and accept
          VisitorWindow.initiateChatVisTheme(driver,visitor_name,visitor_mail,null,visitor_question,etest);

          String
          message1="M1_"+label,
          message2="M2_"+label,
          new_msg1="NEWM1_"+label,
          new_msg2="NEWM2_"+label
          ;

          com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,0);
          ChatWindow.acceptChat(driver,etest);
          ChatWindow.sentMessage(driver,message1);

          com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,1);
          VisitorWindow.waitTillMessageInChat(driver,message1);
          VisitorWindow.sentMessageInTheme(driver,message2);

          ExecuteStatements.openNewTab(driver,Util.getCliqURL());
          ExecuteStatements.loadDomainAPIJS(driver,code);
          com.zoho.livedesk.util.common.CommonUtil.refreshPage(driver);
          com.zoho.livedesk.util.common.CommonUtil.waitreturner(driver, 10, 250);

          if(VisitorWindow.isFloatWidgetFound(driver))
          {
            etest.log(Status.INFO,"Widget was loaded successfully cross domain");
            TakeScreenshot.infoScreenshot(driver,etest);
          }

          com.zoho.livedesk.util.common.CommonUtil.sleep(5000);

          String last_message=VisitorWindow.getLastMessage(driver);
          result.put("JSW95",com.zoho.livedesk.util.common.CommonUtil.checkStringContainsAndLog(message2,last_message,"last message in chat",etest));

          VisitorWindow.sentMessageInTheme(driver,new_msg1);

          com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,0);
          com.zoho.livedesk.util.common.CommonWait.waitTillDisplayed(driver, By.id("siqcht"));
          CommonUtil.waitreturner(driver,30,250);

          //sent message and check success
          if(ChatWindow.checkMessageInUserWindow(driver,"",new_msg1))
          {
            etest.log(Status.PASS,"Chat messages sent by the visitor was sent to the agent successfully");   
            result.put("JSW96",true);         
          }
          else
          {
            result.put("JSW96",false);         
            etest.log(Status.FAIL,"Chat messages sent by the visitor was NOT sent to the agent successfully");  
            TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","Screenshot");
          }

          //receive message and check success

          ChatWindow.sentMessage(driver,new_msg2);

          com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,1);

          if(com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions.isMessageRecievedByVisitor(driver,user,new_msg2))
          {
            etest.log(Status.PASS,"Chat messages sent by the agent was sent to the visitor successfully");    
            result.put("JSW97",true);        
          }
          else
          {
            result.put("JSW97",false);
            etest.log(Status.FAIL,"Chat messages sent by the agent was NOT sent to the visitor successfully");  
            TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Failure","User window screenshot");      
          }

          VisitorWindow.endChatVisitor(driver);

          boolean isEndInVisSide=VisitorWindow.isChatEnded(driver);
          TakeScreenshot.infoScreenshot(driver,etest);
          com.zoho.livedesk.util.common.CommonUtil.switchToTab(driver,0);
          boolean isEndInAgentSide=ChatWindow.isChatEnded(driver,visitor_name);
          TakeScreenshot.infoScreenshot(driver,etest);
          com.zoho.livedesk.util.common.CommonUtil.closeAllTabs(driver);

          if(isEndInVisSide & isEndInAgentSide)
          {
            etest.log(Status.PASS,"Chat was ended");
            result.put("JSW98",true);   
          }
          else
          {
            etest.log(Status.FAIL,"Chat was NOT ended");        
            TakeScreenshot.screenshot(driver,etest);    
            result.put("JSW98",false);   
          }

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);          
        }
        finally
        {
            com.zoho.livedesk.util.common.CommonUtil.doNothing();   
        }
    }

    public static void invokeResetAPI(WebDriver visitor_driver)
    {
        String reset_api="$zoho.salesiq.reset()";
        visitor_driver.switchTo().defaultContent();
        ExecuteStatements.run(visitor_driver,reset_api);
    }
}
