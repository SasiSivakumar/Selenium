//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class ABlockedIP
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	public static String url = "";
    public static ExtentTest etest; 
    
	public static Hashtable blockedIP(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB1"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");
			
			url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			//BLOCKED IP VIEW
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
			
			result.put("ASB1", true);
			
			etest.log(Status.PASS,"BlockedIP tab is present");

			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB2"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB2", isPageAvail(driver));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB3"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB3", addIP(driver,"15.16.1.1",null,null));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB4"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB4", checkHeaders(driver));
            
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB5"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB5", checkEmbedforIP(driver,"15.1.1.4",ConfManager.getPortalName()));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB6"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB6", addComment(driver,"15.1.1.3"));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB7"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB7", !(deleteBlockedIP(driver,"15.1.1.4",false)));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB8"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB8", !(unblockIP(driver,"15.1.1.3",false)));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ASB9"));
            ComplexReportFactory.setValues(etest,"Automation","BlockedIP - Associate");

			result.put("ASB9", !(blockIP(driver,"15.1.1.3",false)));
			
			ComplexReportFactory.closeTest(etest);
        }
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockedIPTab","ErrorWhileCheckingBlockedTab",e);

			result.put("ASB1", false);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockedIPTab","ErrorWhileCheckingBlockedTab",e);
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			result.put("ASB1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}
	
	//Check BlockedIP Header
	public static boolean isPageAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_blockedips")+"')]")));
			driver.findElement(By.xpath("//*[contains(.,'"+ResourceManager.getRealValue("settings_blockedips")+"')]"));
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
			List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));
            
			if(((text.get(0).getText()).equals(ResourceManager.getRealValue("settings_blockip_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("associate_blockip_desc2"))))
			{
				etest.log(Status.PASS,"BlockedIP desciprtion is matched");

				return true;
			}
			else{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockedIPPage","MismatchDescription");
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockedIPPage","ErrorWhileCheckingBlockedIPPage",e);
			System.out.println("Exception while checking if blockedIP settings page is available in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockedIPPage","ErrorWhileCheckingBlockedIPPage",e);
			System.out.println("Exception while checking if blockedIP settings page is available in associate login : "+e);
			return false;
		}
		return false;
	}
    
    //check for unwanted headers - action (should not be visible for associate)
    public static boolean checkHeaders(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            if((driver.findElement(By.id("listview")).findElement(By.className("list_header")).getText()).contains("Action"))
            {
                TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","CheckHeaders","ActionIsPresent");
				return false;
            }
            etest.log(Status.PASS,"Actions is not present");

			return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","CheckHeaders","ErrorWhileCheckingHeaders",e);
			System.out.println("Exception while checking if blockedIP settings headers is available in associate login : "+e);
			return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","CheckHeaders","ErrorWhileCheckingHeaders",e);
			System.out.println("Exception while checking if blockedIP settings headers is available in associate login : "+e);
			return false;
        }
    }
	
	//Add IP
	public static boolean addIP(WebDriver driver, String ip, String comment, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
            try
            {
                driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();
                TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","AddIP","AddButtonIsPresent");
				return false;
            }
            catch(Exception e)
            {
                etest.log(Status.PASS,"Add button is not present");
				return true;
            }
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","AddIP","ErrorWhileAddingIP",e);
			System.out.println("Exception while adding IP in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","AddIP","ErrorWhileAddingIP",e);
			System.out.println("Exception while adding IP in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
	
	//Check Embed for Blocked IP
	public static boolean checkEmbedforIP(WebDriver driver, String ip, String embed)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					WebElement elmts2 = elmts1.get(0).findElement(By.tagName("em"));
					elmts2.click();
					break;
				}
			}
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));
            
		 	driver.findElement(By.xpath("//div[text()='"+embed+"']"));
			etest.log(Status.PASS,"Embed is visible for BlockedIP");
			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","EmbedForIP","ErrorWhileCheckingEmbedForIP",e);
			System.out.println("Exception while checking embed for IP in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","EmbedForIP","ErrorWhileCheckingEmbedForIP",e);
			System.out.println("Exception while checking embed for IP in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
	
	//Add comment for already added IP
	public static boolean addComment(WebDriver driver, String ip)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
			String comment = "Blocked IP Comment added at "+System.currentTimeMillis();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt1 = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt1.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					WebElement elmts2 = elmts1.get(0).findElement(By.tagName("em"));
					elmts2.click();
					break;
				}
			}
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("configview")));
            
 			((JavascriptExecutor) driver).executeScript("document.getElementById('commenttxt').value = '"+comment+"';");
			((JavascriptExecutor) driver).executeScript("document.getElementById('savcommbtn').click();");
            
            Thread.sleep(3000);
            
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt = driver.findElement(By.id("listview"));
			elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					WebElement elmts2 = elmts1.get(0).findElement(By.tagName("em"));
					elmts2.click();
					break;
				}
			}
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='"+comment+"']")));
			driver.findElement(By.xpath("//div[text()='"+comment+"']"));
            etest.log(Status.PASS,"Added Comment is present");
			return true;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","AddCommentForBlockedIP","ErrorWhileCheckingAddCommentForBlockedIP",e);
			System.out.println("Exception while adding comment to IP in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","AddCommentForBlockedIP","ErrorWhileCheckingAddCommentForBlockedIP",e);
			System.out.println("Exception while adding comment to IP in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
    
	//Delete Blocked IP
	public static boolean deleteBlockedIP(WebDriver driver, String ip,boolean screenshot)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					List<WebElement> elmts2 = elmts1.get(0).findElements(By.tagName("em"));
					mouseOver(driver, elmts2.get(0));
					elmts2.get(0).click();
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
					driver.findElement(By.id("okbtn")).click();
                    Tab.waitForLoadingSuccessWithBanner(driver,"Deleted successfully","delblockedip.do",etest);
					break;
				}
			}
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			elmt = driver.findElement(By.id("listview"));
			elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					if(screenshot)
                    {
						TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","DeleteBlockedIP","BlockedIPisDeleted");
                        return false;
                    }
					else
                    {
						etest.log(Status.PASS,"BlockedIP is not deleted");
                        break;
                    }
				}
			}
			if(!screenshot)
            {
                TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","DeleteBlockedIP","BlockedIPisNotDeleted");
                return false;
            }
			else
            {
                etest.log(Status.PASS,"BlockedIP is deleted");
            }
		    return true;
		}
		catch(NoSuchElementException e)
		{
			if(screenshot)
			{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","DeleteBlockedIP","ErrorWhileDeletingBlockedIP",e);
			}
			else
			{
				etest.log(Status.PASS,"BlockedIP cannot be deleted");
			}
            System.out.println("Exception while deleting blocked IP in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
			if(screenshot)
			{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","DeleteBlockedIP","ErrorWhileDeletingBlockedIP",e);
			}
			else
			{
				etest.log(Status.PASS,"BlockedIP cannot be deleted");
			}
            System.out.println("Exception while deleting blocked IP in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
	
	//Unblock IP
	public static boolean unblockIP(WebDriver driver, String ip,boolean screenshot)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					WebElement elmts2 = elmts1.get(3).findElement(By.tagName("em"));
					elmts2.click();
					break;
				}
			}
            
			return isIPUnblocked(driver, ip,screenshot);
		}
		catch(NoSuchElementException e)
		{
			if(screenshot)
			{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","UnBlockIP","ErrorWhileCheckingUnBlockIP",e);
			}
			else
			{
				etest.log(Status.PASS,"BlockedIP cannot be unblocked");
			}
            System.out.println("Exception while unblocking blocked IP in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            if(screenshot)
            {
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","UnBlockIP","ErrorWhileCheckingUnBlockIP",e);
            }
			else
			{
				etest.log(Status.PASS,"BlockedIP cannot be unblocked");
			}
            System.out.println("Exception while unblocking blocked IP in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
	
	//Check IP blocked or unblocked
	public static boolean isIPUnblocked(WebDriver driver, String ip,boolean screenshot)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					String classname = welmt.getAttribute("class");
					if(classname.contains("list_disable"))
					{
						if(!screenshot)
						{
							TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","UnBlockIP","BlockedIPisUnblocked");
						}
						else
						{
							etest.log(Status.PASS,"BlockedIP is unblocked");
						}
            			return true;
					}
				}
			}
			if(screenshot)
			{
				TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","UnBlockIP","BlockedIPisNotUnblocked");
			}
			else
			{
				etest.log(Status.PASS,"BlockedIP is not unblocked");			
			}
			
		    return false;
		    
		}
		catch(NoSuchElementException e)
		{
            if(screenshot)
            {
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","UnBlockIP","ErrorWhileCheckingIPIsUnBlockedOrNot",e);
            }
			else
			{
				etest.log(Status.PASS,"BlockedIP cannot be unblocked");
			}
            System.out.println("Exception while checking if IP is unblocked in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            if(screenshot)
            {
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","UnBlockIP","ErrorWhileCheckingIPIsUnBlockedOrNot",e);
            }
			else
			{
				etest.log(Status.PASS,"BlockedIP cannot be unblocked");
			}
            System.out.println("Exception while checking if IP is unblocked in blockedIP settings page in associate login : "+e);
			return false;
		}
		
	}
	
	//Block IP
	public static boolean blockIP(WebDriver driver, String ip,boolean screenshot)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_blockedips"))));
			
			driver.findElement(By.linkText(ResourceManager.getRealValue("settings_blockedips"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            
			WebElement elmt = driver.findElement(By.id("listview"));
			List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				if((elmts1.get(0).getText()).contains(ip))
				{
					WebElement elmts2 = elmts1.get(3).findElement(By.tagName("em"));
					elmts2.click();
					break;
				}
			}
            
			return !(isIPUnblocked(driver,ip,true));
		}
		catch(NoSuchElementException e)
		{
            if(screenshot)
            {
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockIP","ErrorWhileCheckingBlockIP",e);
            }
			else
			{
				etest.log(Status.PASS,"UnBlockedIP cannot be blocked");
			}
            System.out.println("Exception while blocking unblocked IP in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            if(screenshot)
            {
            	TakeScreenshot.screenshot(driver,etest,"BlockedIP-Associate","BlockIP","ErrorWhileCheckingBlockIP",e);
            }
			else
			{
				etest.log(Status.PASS,"UnBlockedIP cannot be blocked");
			}
            System.out.println("Exception while blocking unblocked IP in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
	
	public static boolean clearBlockedIPs(WebDriver driver)
	{
		try
		{
			deleteBlockedIP(driver,"15.1.1.1",false);
			deleteBlockedIP(driver,"15.1.1.2",false);
			deleteBlockedIP(driver,"15.1.1.3",false);
			deleteBlockedIP(driver,"15.1.1.4",false);
			
			return true;
		}
		catch(NoSuchElementException e)
		{
            System.out.println("Exception while clearing blocked IP settings in blockedIP settings page in associate login : "+e);
			return false;
		}
		catch(Exception e)
		{
            System.out.println("Exception while clearing blocked IP settings in blockedIP settings page in associate login : "+e);
			return false;
		}
	}
    
	//Mouse over hidden element
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		new Actions(driver).moveToElement(element).perform();
	}
}
