//$Id$
package com.zoho.livedesk.client.MobileSDK;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.actions.MobileSDKPages;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.WebEmbed;
import com.zoho.livedesk.util.common.actions.WebsitesTab;

public class MobileSDK {


 public static Hashtable < String, Boolean > result = new Hashtable();
 public static Hashtable < String, Hashtable < String, Boolean >> hashtable = new Hashtable();
 public static Hashtable < String, Boolean > servicedown = new Hashtable();
 public static ExtentTest etest;
 public static String module_name = "Mobile SDK";
 public static String widget_code = "", website_name = "", embed_name = "";
 static String label = CommonUtil.getUniqueMessage();


 public static Hashtable test(WebDriver driver) {
  try {

   result = new Hashtable < String, Boolean > ();
   website_name = ExecuteStatements.getDefaultEmbedName(driver);
   widget_code = ExecuteStatements.getWidgetCodeFromEmbedName(driver, website_name);
   embed_name = ExecuteStatements.getEmbedNameFromWidgetCode(driver, widget_code);


   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK1"));
   result.put("MOBSDK1", checkMobileSDKHomepage(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK2"));
   result.put("MOBSDK2", checkMobileSDKIOSpage(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK3"));
   result.put("MOBSDK3", checkMobileSDKAndriodpage(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK5"));
   result.put("MOBSDK5", checkGenerateToken(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK6"));
   result.put("MOBSDK6", checkAccessKeyRegeneration(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK8"));
   result.put("MOBSDK8", checkMailIconToSentMail(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK9"));
   result.put("MOBSDK9", checkEnableDisableAcessKeys(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK12"));
   result.put("MOBSDK12", checkAdvancedSettingsTokens(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK14"));
   result.put("MOBSDK14", checkLearnToInstallPage(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK13"));
   result.put("MOBSDK13", checkShowHideButtoninUI(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK15"));
   result.put("MOBSDK15", checkRequiredOptionPresentPageIOS(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK16"));
   result.put("MOBSDK16", checkRequiredOptionPresentPageAndriod(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);

   etest = ComplexReportFactory.getTest(KeyManager.getRealValue("MOBSDK11"));
   result.put("MOBSDK11", checkDeleteTokens(driver, etest, embed_name));
   ComplexReportFactory.setValues(etest, "Automation", module_name);
   ComplexReportFactory.closeTest(etest);


  } catch (Exception e) {
   etest.log(Status.FATAL, "Mobile SDK Module error");
   etest.log(Status.FATAL, "Module breakage occurred " + e);
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Exception", "Module breakage", e);

  }
  hashtable.put("result", result);
  hashtable.put("servicedown", servicedown);
  return hashtable;
 }


 private static Boolean checkMobileSDKHomepage(WebDriver driver, ExtentTest etest, String embed_name) throws Exception {

  try {

   WebEmbed.clickWebEmbed(driver, embed_name, etest);
   MobileSDKPages.clickLiveChatMobile(driver, etest);

   if (MobileSDKPages.isSDKHomepageRHSDescriptionFound(driver, etest)) {
    etest.log(Status.PASS, "Mobile SDK page RHS Description is Displayed");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.FAIL, "Mobile SDK page RHS Description is not Displayed");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Home-RHS", "Exception");
    return false;
   }

   if (MobileSDKPages.isSDKHomepageLHSDescriptionHeaderFound(driver, etest)) {
    etest.log(Status.PASS, "Mobile SDK page LHS Description Header is Displayed");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.FAIL, "Mobile SDK page LHS Description Header is not Displayed");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Home-LHS", "Exception");
    return false;
   }

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "HomePage ", "Exception", e);
  }
  return false;
 }



 private static Boolean checkMobileSDKIOSpage(WebDriver driver, ExtentTest etest, String embed_name) throws Exception {
  try {

   clickIOSPage(driver, etest);

   if (!MobileSDKPages.isIOSpageLHSDescriptionFound(driver, etest)) {
    etest.log(Status.FAIL, "Mobile SDK - IOS page LHS Description is not  Displayed");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "IOS", "Exception");
    return false;
   }
   etest.log(Status.PASS, "Mobile SDK - IOS page LHS Description is Displayed");
   TakeScreenshot.infoScreenshot(driver, etest);

   if (MobileSDKPages.isIOSpageLHSsubDescriptionFound(driver, etest)) {
    etest.log(Status.PASS, "Mobile SDK - IOS page LHS SubHeading -Description is Displayed");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   etest.log(Status.FAIL, "Mobile SDK - IOS page LHS SubHeading -Description is not Displayed");
   TakeScreenshot.screenshot(driver, "Mobile SDK", "IOS-LHS", "Exception");
   return false;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "IOS Page ", "Exception", e);

  }
  return false;
 }


 private static Boolean checkMobileSDKAndriodpage(WebDriver driver, ExtentTest etest, String embed_name) throws Exception {
  try {

   clickAndriodPage(driver, etest);

   if (!MobileSDKPages.isAndriodpageLHSDescriptionFound(driver, etest)) {
    etest.log(Status.FAIL, "Mobile SDK - Andriod page LHS Description is not  Displayed");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Andriod", "Exception");
    return false;
   }
   etest.log(Status.PASS, "Mobile SDK - Andriod page LHS Description is Displayed");
   TakeScreenshot.infoScreenshot(driver, etest);

   if (MobileSDKPages.isAndriodpageLHSsubDescriptionFound(driver, etest)) {
    etest.log(Status.PASS, "Mobile SDK - Andriod page LHS SubHeading -Description is Displayed");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   etest.log(Status.FAIL, "Mobile SDK - Andriod page LHS SubHeading -Description is not Displayed");
   TakeScreenshot.screenshot(driver, "Mobile SDK", "Andriod-LHS", "Exception");
   return false;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "AdriodPage ", "Exception", e);

  }
  return false;
 }


 private static Boolean checkGenerateToken(WebDriver driver, ExtentTest etest, String embed_name) throws Exception {
  try {

   clickIOSPage(driver, etest);
   if (!MobileSDKPages.isGenerateTokenButtonEnablesIOS(driver, etest)) {
    return false;
   }
   MobileSDKPages.clickGenerateButtonIOS(driver, etest);
   if (!firstGeneratedTokenDetails(driver, etest)) {
    return false;
   }

   clickAndriodPage(driver, etest);
   if (!MobileSDKPages.isGenerateTokenButtonEnablesAndriod(driver, etest)) {
    return false;
   }
   MobileSDKPages.clickGenerateButtonAndriod(driver, etest);
   if (!firstGeneratedTokenDetails(driver, etest)) {
    return false;
   }
  } catch (Exception e) {

   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Generate Token", "Exception", e);
  }
  return false;
 }



 public static boolean checkAccessKeyRegeneration(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);

   if (MobileSDKPages.isRegenerateButtonFound(driver)) {
    accessKeyRegeneration(driver, etest);
    return true;
   }


   clickAndriodPage(driver, etest);

   if (MobileSDKPages.isRegenerateButtonFound(driver)) {
    accessKeyRegeneration(driver, etest);
    return true;
   }
   return false;

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Regeneration ", "Exception", e);

  }
  return false;

 }

 public static boolean checkMailIconToSentMail(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);
   if (!MobileSDKPages.checkRegenerateAccesskeyOne(driver, etest)) {
	    etest.log(Status.FAIL, "Regenerated AccessKey is not Found");
	    TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Regeneration ", "Exception");
	   return false;
   }else {
	   CommonUtil.getElement(driver, By.id("sdk_accesskey1")).findElement(By.className("sqico-mail")).click();
	    etest.log(Status.PASS, "Mail Template for Multiple Acess key is Displayed ");
	    TakeScreenshot.infoScreenshot(driver, etest);
	    MobileSDKPages.sentMailTemplate(driver, etest);
	    etest.log(Status.PASS, "Mail sent from Template for Multiple Acess key");
	    TakeScreenshot.infoScreenshot(driver, etest);
	    return true;
   }

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Mail Sent from AccessKey ", "Exception", e);
  }
  return false;
 }




 public static boolean checkEnableDisableAcessKeys(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);
   if (MobileSDKPages.enableDisablekeys(driver, etest)) {
    etest.log(Status.PASS, "Enable and Disable keys work in IOS Page properly");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Delete Token ", "Access Key Detais", e);
  }
  return false;
 }




 public static boolean checkAdvancedSettingsTokens(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);

   if (MobileSDKPages.isAdvancedSettingPresent(driver, etest)) {
    etest.log(Status.PASS, "Advanced Settings present for IOS Page");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   } else {
    etest.log(Status.FAIL, "Advanced Settings is not Found for IOS Page");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings ", "Advanced Settings Detais");
   }


   clickAndriodPage(driver, etest);
   if (MobileSDKPages.isAdvancedSettingPresent(driver, etest)) {
    etest.log(Status.PASS, "Advanced Settings present for Andriod Page");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   } else {
    etest.log(Status.FAIL, "Advanced Settings is not Found for Andriod Page");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings ", "Advanced Settings Detais");
   }

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Advanced Settings Token ", "Access Key Detais", e);

  }
  return false;

 }





 public static boolean checkShowHideButtoninUI(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);

   if (MobileSDKPages.isAdvancedSettingPresent(driver, etest)) {

    if (MobileSDKPages.clickShowChatButton(driver, etest)) {
     CommonSikuli.findInWholePage(driver, "mobileSDKIOS_ShowButton.png", "MOBSDK13", etest);
     etest.log(Status.PASS, "Show Chat Button Image Found");
     TakeScreenshot.infoScreenshot(driver, etest);
     return true;
    }
    if (MobileSDKPages.clickHideChatButton(driver, etest)) {
     CommonSikuli.findInWholePage(driver, "mobilSDKIOS_HideButton.png", "MOBSDK13", etest);
     etest.log(Status.PASS, "Hide Chat Button Image Found");
     TakeScreenshot.infoScreenshot(driver, etest);
     return true;
    }


    clickAndriodPage(driver, etest);

    if (MobileSDKPages.clickShowChatButton(driver, etest)) {
     CommonSikuli.findInWholePage(driver, "mobileSDKAndriod_ShowChat.png", "MOBSDK13", etest);
     etest.log(Status.PASS, "Show Chat Button Image Found");
     TakeScreenshot.infoScreenshot(driver, etest);
     return true;
    }
    if (MobileSDKPages.clickHideChatButton(driver, etest)) {
     CommonSikuli.findInWholePage(driver, "mobileSDKAndriod_HideChat.png", "MOBSDK13", etest);
     etest.log(Status.PASS, "Hide Chat Button Image Found");
     TakeScreenshot.infoScreenshot(driver, etest);
     return true;
    }

   }

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Help Page-IOS ", "Exception", e);
  }
  return false;

 }


 public static boolean checkLearnToInstallPage(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);
   MobileSDKPages.clickLearntoInstallLink(driver, etest);
    CommonUtil.switchToTab(driver, 1);
    if(MobileSDKPages.isLearnToInstallPageFoundIOS(driver, etest)) {
    CommonUtil.goToSalesIQURL(driver);
    etest.log(Status.PASS, "Respective Help Page was Found");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.FAIL, "Respective Help Page was not Found");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Help Page-IOS ", "Exception");
    return false;
   }



   clickAndriodPage(driver, etest);

  MobileSDKPages.clickLearntoInstallLink(driver, etest);
    CommonUtil.switchToTab(driver, 1);
    if(MobileSDKPages.isLearnToInstallPageFoundAndriod(driver, etest)) {
    CommonUtil.goToSalesIQURL(driver);
    etest.log(Status.PASS, "Respective Help Page was Found");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.FAIL, "Respective Help Page was not Found");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Delete Token ", "Access Key Detais");
    return false;
   }


  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Help Page-IOS ", "Exception", e);
  }
  return false;

 }


 public static boolean checkRequiredOptionPresentPageIOS(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);

   if (MobileSDKPages.isAdvancedSettingPresent(driver, etest)) {
    MobileSDKPages.checkAPNsinPushNotificationIOS(driver, etest);
    MobileSDKPages.saveAdvancedNotifiction(driver);
    etest.log(Status.PASS, "Required Option for Push Notification is Checked for IOS Page");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   etest.log(Status.FAIL, "Required Option for Push Notification is not Checked for IOS Page");
   TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings Token ", "Access Key Detais");
   return false;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Advanced Settings Token ", "Access Key Detais", e);

  }
  return false;

 }

 public static boolean checkRequiredOptionPresentPageAndriod(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   MobileSDKPages.enableDisablekeys(driver, etest);
   clickAndriodPage(driver, etest);
   if (MobileSDKPages.isAdvancedSettingPresent(driver, etest)) {
    MobileSDKPages.checkAPNsinPushNotificationAndriod(driver, etest);
    MobileSDKPages.saveAdvancedNotifiction(driver);
    etest.log(Status.PASS, "Required Option for Push Notification is Checked for Andriod Page");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   etest.log(Status.FAIL, "Required Option for Push Notification is not Checked for Andriod Page");
   TakeScreenshot.screenshot(driver, "Mobile SDK", "Advanced Settings Token ", "Access Key Detais");
   return false;
  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Advanced Settings Token ", "Access Key Detais", e);

  }
  return false;

 }


 public static boolean checkDeleteTokens(WebDriver driver, ExtentTest etest, String embed_name) {
  try {

   clickIOSPage(driver, etest);
   if (!MobileSDKPages.deletekeys(driver, etest)) {

    return false;
   }
   clickAndriodPage(driver, etest);
   if (MobileSDKPages.deletekeys(driver, etest)) {
    return true;
   }

  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Delete Token ", "Access Key Detais", e);

  }
  return false;

 }





 public static boolean firstGeneratedTokenDetails(WebDriver driver, ExtentTest etest) {
  try {
   if (!MobileSDKPages.checkTokenGeneratedDetailsPresent(driver, etest)) {
    etest.log(Status.FAIL, "Token Generated for bundleID-IOS  is not present");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Generate Token - IOS", "Token Detais");
    return false;
   } else {
    etest.log(Status.PASS, "Token Generated for bundleID-IOS  is  present");
    TakeScreenshot.infoScreenshot(driver, etest);
   }

   if (!MobileSDKPages.checkAppKeyPresent(driver, etest)) {
    etest.log(Status.FAIL, "App Key is not Generated and is not present");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Generate Token - IOS", "App Key Detais");
    return false;
   }
   etest.log(Status.PASS, "App key is Generted and Displayed");
   TakeScreenshot.infoScreenshot(driver, etest);

   if (MobileSDKPages.checkAccessKeyPresent(driver, etest)) {
    etest.log(Status.PASS, "Access key is Generted and Displayed");
    TakeScreenshot.infoScreenshot(driver, etest);
    return true;
   }
   etest.log(Status.FAIL, "Access Key is not Generated and is not present");
   TakeScreenshot.screenshot(driver, "Mobile SDK", "Generate Token - IOS", "Access Key Detais");
   return false;

  } catch (Exception e) {

   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Generate Token ", "Access Key Detais", e);
   return false;
  }

 }



 public static boolean accessKeyRegeneration(WebDriver driver, ExtentTest etest) {
  try {

   MobileSDKPages.clickRegenerteButton(driver, etest);
   if (MobileSDKPages.checkRegenerateAccesskeyOne(driver, etest)) {
    MobileSDKPages.clickRegenerteButton(driver, etest);

    etest.log(Status.PASS, "Access Key Regenerated (One)");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.FAIL, "Access Key is not Regenerated (One)");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Regeneration AcessKey", "Access Key Detais");
    return false;
   }

   if (MobileSDKPages.checkRegenerateAccesskeyTwo(driver, etest)) {
    MobileSDKPages.clickRegenerteButton(driver, etest);
    etest.log(Status.PASS, "Access Key Regenerated (Two)");
    TakeScreenshot.infoScreenshot(driver, etest);

   } else {
    etest.log(Status.FAIL, "Access Key is not Regenerated (Two)");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Regeneration AcessKey", "Access Key Detais");
    return false;
   }

   if (MobileSDKPages.checkRegenerateAccesskeyThree(driver, etest)) {
    MobileSDKPages.clickRegenerteButton(driver, etest);
    etest.log(Status.PASS, "Access Key Regenerated (Three)");
    TakeScreenshot.infoScreenshot(driver, etest);
   } else {
    etest.log(Status.FAIL, "Access Key is not Regenerated (Three)");
    TakeScreenshot.screenshot(driver, "Mobile SDK", "Regeneration AcessKey", "Access Key Detais");
    return false;
   }



  } catch (Exception e) {
   TakeScreenshot.screenshot(driver, etest, "Mobile SDK", "Regeneration AcessKey", "Access Key Detais", e);

  }

  return false;

 }

 public static void clickIOSPage(WebDriver driver, ExtentTest etest) throws Exception {

  WebEmbed.clickWebEmbed(driver, embed_name, etest);
  MobileSDKPages.clickLiveChatMobile(driver, etest);
  CommonWait.waitTillDisplayed(driver, By.id("sdk_iossel"));
  CommonUtil.clickWebElement(driver, By.id("sdk_iossel"));
  etest.log(Status.INFO, "Navigated to Mobile SDK - IOS Page");
 }

 public static void clickAndriodPage(WebDriver driver, ExtentTest etest) throws Exception {
  WebEmbed.clickWebEmbed(driver, embed_name, etest);
  MobileSDKPages.clickLiveChatMobile(driver, etest);
  CommonWait.waitTillDisplayed(driver, By.id("sdk_androidsel"));
  CommonUtil.clickWebElement(driver, By.id("sdk_androidsel"));
  etest.log(Status.INFO, "Navigated to Mobile SDK - Andriod Page");
 }



}