//$Id$
package com.zoho.livedesk.client.NewEmbed;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.google.common.base.Function;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;  

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.ResourceManager;

import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import org.openqa.selenium.Cookie;
import java.util.*;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;

public class VisitorSite {

    public static WebDriver setUpVisitorDriver() throws Exception
	{
		WebDriver visDriver = setUp();
        NewEmbedUtil.visitors.add(visDriver);
        openVisitorWindow(visDriver);
        return visDriver;
	}

    public static WebDriver setUpVisitorDriver1(WebDriver visDriver) throws Exception
    {
        openVisitorWindow(visDriver);
        return visDriver;
    }

	public static String getVisitorId() throws Exception
	{
		WebDriver visDriver = setUpVisitorDriver();
        return getVisitorIdFromVisDriver(visDriver);
	}

    public static String getVisitorIdFromVisDriver(WebDriver driver) throws Exception
    {
        return VisitorWindow.getVisitorId(driver,NewEmbedUtil.portal);
    }
    
    public static void openVisitorWindow(WebDriver driver) throws Exception
    {
        try
        {
            VisitorWindow.createPage(driver,NewEmbedUtil.embed,NewEmbedUtil.portal);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,NewEmbedUtil.etest,"NewEmbed","OpenVisitor","Error",e);
            throw e;
        }
    }

    
    public static void switchToChatWidget(WebDriver driver) throws Exception
    {
        driver.switchTo().defaultContent();

        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","zlsiframe"));
    }

    public static WebDriver setUp() throws Exception
    {
        return Functions.setUp();
    }

    public static String getThemeInChatWidget(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        String theme = CommonUtil.elementfinder(visDriver,CommonUtil.elfinder(visDriver,"tagname","head"),"xpath","//link[@rel='stylesheet'][@type='text/css'][contains(@href,'.css')]").getAttribute("href");
        
        visDriver.switchTo().defaultContent();

        return theme;
    }

    public static boolean checkWaitingDiv(WebDriver visDriver,boolean presence) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        if(!presence)
        {  
            for(int i = 1; i <= 10;i++)
            {
                if(CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML").contains(ResourceManager.getRealValue("Theme.wait.path")))
                {
                    if(!CommonUtil.elfinder(visDriver,ResourceManager.getRealValue("Theme.wait.by"),ResourceManager.getRealValue("Theme.wait.path")).isDisplayed())
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }

                Thread.sleep(500);
            }

            return false;
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.wait"))));  
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.wait"))));

        String initialContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.wait")).getAttribute("innerHTML");
        
        for(int i = 1 ; i <= 3 ; i++)
        {
            Thread.sleep(1500);
            String finalContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.wait")).getAttribute("innerHTML");
            if(finalContent.equals("") || finalContent.equals(initialContent))
            {
                System.out.println("<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                NewEmbedUtil.etest.log(Status.FAIL,"Same Content in Waiting div<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                return false;
            }
            initialContent = finalContent;
        }

        return true;
    }

    public static boolean checkVisitorMessageInChatWindow(WebDriver driver,boolean namePresence,String name,String msg,int count) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        try
        {
            switchToChatWidget(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitormsg").replace("MSG",msg).replace("COUNT",""+count))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitormsg").replace("MSG",msg).replace("COUNT",""+count))));
            
            if(namePresence)
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitorname").replace("NAME",name).replace("COUNT",""+count))));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.visitorname").replace("NAME",name).replace("COUNT",""+count))));
            }
            
            driver.switchTo().defaultContent();
            return true;
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            return false;
        }
    }

    public static boolean checkAgentMessageInChatWindow(WebDriver driver,boolean userPresence,String user,String msg,int count) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        try
        {
            switchToChatWidget(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentmsg").replace("MSG",msg).replace("COUNT",""+count))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentmsg").replace("MSG",msg).replace("COUNT",""+count))));
            
            if(userPresence)
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentname").replace("NAME",user).replace("COUNT",""+count))));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.agentname").replace("NAME",user).replace("COUNT",""+count))));
            }

            driver.switchTo().defaultContent();
            return true;
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            return false;
        }
    }

    public static void visitorSentMessage(WebDriver visDriver,String msg,boolean enter) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.msgcontainer"))));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.message"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.message"))));

        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).sendKeys(msg);

        if(enter)
        {
            CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).sendKeys(Keys.ENTER);
        }
        else
        {
            CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.enter")).click();
        }

        visDriver.switchTo().defaultContent();
    }

    public static void checkChatEnded(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.header"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.header"))));

        for(int i = 1; i<= 5; i++)
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT",""+i))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT",""+i))));
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.text"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.text"))));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit"))));
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.cancel"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.cancel"))));

        visDriver.switchTo().defaultContent();
    }

    public static void enterFeedback(WebDriver visDriver,String fdkmsg,String star) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.header"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.header"))));

        if(star != null)
        {
            CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.star").replace("COUNT",star)).click();
        }
        
        if(fdkmsg != null)
        {
            CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.text")).sendKeys(fdkmsg);
        }
        
        if(fdkmsg != null && star != null)
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit.click"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit.click"))));

            Thread.sleep(1500);

            try
            {
                CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.submit.click")).click();
            }
            catch(WebDriverException e)
            {
                Thread.sleep(1500);

                CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.submit.click")).click();
            }
        }
        else
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.cancel"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.cancel"))));

            Thread.sleep(1500);

            try
            {
                CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.cancel")).click();
            }
            catch(WebDriverException e)
            {
                Thread.sleep(1500);

                CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.cancel")).click();
            }
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));

        visDriver.switchTo().defaultContent();
    }

    public static boolean checkEndTimer(WebDriver visDriver,int time,boolean presence,boolean waitTillEnds) throws Exception
    {
        return checkEndTimer(visDriver,time,presence,waitTillEnds,NewEmbedUtil.etest);
    }
    public static boolean checkEndTimer(WebDriver visDriver,int time,boolean presence,boolean waitTillEnds,ExtentTest etest) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        if(!presence)
        {
            for(int i = 1; i <= 10;i++)
            {
                if(CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML").contains(ResourceManager.getRealValue("Theme.endtimer.path")))
                {
                    if(!CommonUtil.elfinder(visDriver,ResourceManager.getRealValue("Theme.endtimer.by"),ResourceManager.getRealValue("Theme.endtimer.path")).isDisplayed())
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }

                Thread.sleep(500);
            }

            return false;
        }

        Long t1 = new Long(System.currentTimeMillis());

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer"))));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer.timer"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endtimer.timer"))));

        String contents[] = ResourceManager.getRealValue("Theme.endtimer.content").split("/");

        WebElement element = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endtimer"));

        String content = element.getText();

        for(String s : contents)
        {
            if(!content.contains(s))
            {
                etest.log(Status.FAIL,s+" is not present in end timer content - "+content);
                return false;
            }
        }

        String initialContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endtimer")).getAttribute("innerHTML");
        
        for(int i = 1 ; i <= 3 ; i++)
        {
            Thread.sleep(1500);
            
            String finalContent = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endtimer")).getAttribute("innerHTML");
            
            if(finalContent.equals("") || finalContent.equals(initialContent))
            {
                System.out.println("<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                etest.log(Status.FAIL,"Same Content in End Timer div<<<>>>"+initialContent+"<<<>>>"+finalContent+"<<<>>>");
                return false;
            }
            
            initialContent = finalContent;
        }

        if(waitTillEnds)
        {
            Long t2 = new Long(System.currentTimeMillis());

            for(int i = 1;i<=91;i++)
            {
                int diff = (int)(t2 - t1);

                if(diff/1000 > time)
                {
                    break;
                }

                Thread.sleep(1000);

                t2 = new Long(System.currentTimeMillis());
            }

            checkChatEnded(visDriver);
        }

        visDriver.switchTo().defaultContent();

        return true;
    }

    public static void continueChat(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.continuechat"))));

        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.continuechat")).click();

        visDriver.switchTo().defaultContent();
    }

    public static void checkOptions(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley"))));

        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.smiley")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley.div"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.smiley.div"))));

        final WebElement smileys = CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.smiley.div"));

        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.message")).click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(smileys.getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.options"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.options"))));

        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.options")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.optionsdiv"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.optionsdiv"))));

        String options[] = {"mute","sentmail","print","attach"};

        for(String option : options)
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme."+option))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme."+option))));
        }

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));

        visDriver.switchTo().defaultContent();
    }

    public static void endChatVisitor(WebDriver visDriver) throws Exception
    {
        switchToChatWidget(visDriver);

        FluentWait wait = CommonUtil.waitreturner(visDriver,30,200);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.endchat"))));

        CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.endchat")).click();
        
        checkChatEnded(visDriver);

        visDriver.switchTo().defaultContent();
    }
}
