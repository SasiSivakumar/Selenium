//$Id$
package com.zoho.livedesk.client.NewEmbed;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import java.net.*;
import java.util.*;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class NewEmbedUtil {
    
    public static Hashtable result = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    
    public static ExtentTest etest;
    public static Set<WebDriver> visitors = new HashSet<WebDriver>();
    public static String embed = "";
    public static String portal = "";
    public static String dept = "";
    
    public static Hashtable newEmbed(WebDriver driver)
    {
        try
        {
            int useCase = 0;
            
            embed = "ldautomation22";
            portal = "ldautomation22";
            dept = "ldautomation22";
            
            result = new Hashtable();

//            String themes[] = {"Ribbon"};
            String themes[] = {"Ribbon","Crest","Crayon","Lloyd","Airy","Crown","Connect"};
            
            for(String theme : themes)
            {
                checkTheme(driver,theme,useCase++);

                Thread.sleep(2000);
            }

            result.put("NE1",true);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("Error While checking New Embed - "+e.toString());
            TakeScreenshot.screenshot(driver,etest,"NewEmbed","ErrorWhileCheckingNewEmbed","Error",e);
            result.put("NE1",false);
        }

        System.out.println(result);

        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }
    
    public static void checkTheme(WebDriver driver,String theme,int useCase)
    {
        useCase = useCase * 40 ; 

        etest=ComplexReportFactory.getTest("New Embed - "+theme+" - Basic Usecases");
        ComplexReportFactory.setValues(etest,"Automation","New Embed");

        check1(driver,theme,useCase);
        CommonFunctions.clearVisitorDrivers(visitors);

        ComplexReportFactory.closeTest(etest);

        if((boolean)result.get("NE"+(useCase+1)))
        {
           etest=ComplexReportFactory.getTest("New Embed - "+theme+" - Check Fields mandatory");
           ComplexReportFactory.setValues(etest,"Automation","New Embed");

           check2(driver,theme,useCase);
           CommonFunctions.clearVisitorDrivers(visitors);

           ComplexReportFactory.closeTest(etest);

           etest=ComplexReportFactory.getTest("New Embed - "+theme+" - Usecases Set 1");
           ComplexReportFactory.setValues(etest,"Automation","New Embed");

           check3(driver,theme,useCase);
           CommonFunctions.clearVisitorDrivers(visitors);

           ComplexReportFactory.closeTest(etest);

           etest=ComplexReportFactory.getTest("New Embed - "+theme+" - Usecases Set 2");
           ComplexReportFactory.setValues(etest,"Automation","New Embed");

           check4(driver,theme,useCase);
           CommonFunctions.clearVisitorDrivers(visitors);

           ComplexReportFactory.closeTest(etest);

           etest=ComplexReportFactory.getTest("New Embed - "+theme+" - Usecases Set 3");
           ComplexReportFactory.setValues(etest,"Automation","New Embed");

           check5(driver,theme,useCase);
           CommonFunctions.clearVisitorDrivers(visitors);

           ComplexReportFactory.closeTest(etest);

            try
            {
                etest=ComplexReportFactory.getTest("New Embed - "+theme+" Open API Site");
                ComplexReportFactory.setValues(etest,"Automation","New Embed");

                WebDriver visDriver1 = VisitorSite.setUp();
                visDriver1 = NCommonFunctions.openApiSite(visDriver1,"ldautomation22","ldautomation22");

                changeConfigBasic(visDriver1);

                etest.log(Status.PASS,theme+" API Site is opened");
                
                ComplexReportFactory.closeTest(etest);
                
                checkConfigBasic(visDriver1,theme,useCase);
                visDriver1.quit();

                etest=ComplexReportFactory.getTest("New Embed - "+theme+" Check System Messages");
                ComplexReportFactory.setValues(etest,"Automation","New Embed");

                WebDriver visDriver2 = VisitorSite.setUp();
                visDriver2 = NCommonFunctions.openApiSite(visDriver2,"ldautomation22","ldautomation22");
                
                changeConfigSys1(visDriver2);
                checkConfigsys1(visDriver2,useCase);
                visDriver2.quit();
                
                ComplexReportFactory.closeTest(etest);
            }
            catch(Exception e)
            {
                etest.log(Status.FAIL,"Error while opening visitor site");
                e.printStackTrace();
            }

            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void check1(WebDriver driver,String theme,int useCase)
    {
        Long t = new Long(System.currentTimeMillis());
        String time = t.toString();

        String agentname ="LDAutomation";
        String agentmsg = "A"+time;
        String vismsg1 = "VM1"+time;
        String vismsg2 = "VM2"+time;
        String visname = "V"+time;
        String visemail = "email@"+time+".com";
        String visphone = "+"+time;
        String question = "Q"+time;

        try
        {
            Functions.createTabAndCloseCurrent(driver);
            CommonFunctions.openWebEmbed(driver,embed);
            CommonFunctions.clickChatWindowAppearance(driver);
            CommonFunctions.changeTheme(driver,theme);
            // CommonFunctions.clickChatWindowAppearance(driver);
            // String[] req = {"ishowname","ishowemail", "ishowphone"};
            // String[] man = {"namemandatory", "emailmandatory", "phonemandatory"};
            // CommonFunctions.changeFields(driver,req,man);


            Thread.sleep(5000);

            WebDriver visDriver = VisitorSite.setUpVisitorDriver();

            try
            {
                String css = VisitorSite.getThemeInChatWidget(visDriver);
                System.out.println(css+"<<<>>>");

                if(!css.contains(ResourceManager.getRealValue(theme+".css")))
                {
                    etest.log(Status.FAIL,ResourceManager.getRealValue(theme+".css")+" is expected");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+1),false);
                    //return;
                }
                else
                {
                    result.put("NE"+(useCase+1),true);
                }

                VisitorWindow.initiateChatVisTheme(visDriver,visname,visemail,visphone,dept,question,etest);
                
                result.put("NE"+(useCase+2),true);
                
                if(!VisitorSite.checkWaitingDiv(visDriver,true))
                {
                    etest.log(Status.FAIL,"Waiting div content is not changed");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+3),false);
                }
                else
                {
                    result.put("NE"+(useCase+3),true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+1),false);
                return;
            }

            CommonFunctions.acceptChat(driver);
            
            Thread.sleep(4000);

            String visName = CommonFunctions.getVisitorNameInAgentChatWindow(driver);
            String visEmail = CommonFunctions.getVisitorEmailInAgentChatWindow(driver);
            String visPhone = CommonFunctions.getVisitorPhoneInAgentChatWindow(driver);
            String visurl = CommonFunctions.getVisitorUrlInAgentChatWindow(driver);
            String visDept = CommonFunctions.getVisitorDepartmentInAgentChatWindow(driver);
            String visQues = CommonFunctions.getVisitorQuestionInAgentChatWindow(driver);

            String required[] = {visname,visemail,visphone,dept,question,"http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html"};
            String found[] = {visName,visEmail,visPhone,visDept,visQues,visurl};

            result.put("NE"+(useCase+4),true);

            for(int i = 0; i < 6 ; i++)
            {
                if(i == 4)
                {
                    if(!found[i].contains(required[i]))
                    {
                        etest.log(Status.FAIL,"Expected:"+required[i]+".Found:"+found[i]+"--");
                        TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                        result.put("NE"+(useCase+4),false);
                    }
                }
                else
                {
                    if(!required[i].equals(found[i]))
                    {
                        etest.log(Status.FAIL,"Expected:"+required[i]+".Found:"+found[i]+"--");
                        TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                        result.put("NE"+(useCase+4),false);
                    }
                    else
                    {
                        etest.log(Status.INFO,"<><>"+required[i]+"<><>"+found[i]+"--");
                    }
                }
            }

            CommonFunctions.sentMessageUser(driver,agentmsg);

            try
            {
                if(!VisitorSite.checkWaitingDiv(visDriver,false))
                {
                    etest.log(Status.FAIL,"Waiting div is not gone invisible after accepting chat");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+5),false);
                }
                else
                {
                    result.put("NE"+(useCase+5),true);
                }

                if(!VisitorSite.checkAgentMessageInChatWindow(visDriver,true,agentname,agentmsg,1))
                {
                    etest.log(Status.FAIL,agentmsg+" or "+agentname+" is not seen in chat window");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+6),false);
                }
                else
                {
                    result.put("NE"+(useCase+6),true);
                }
                
                VisitorSite.visitorSentMessage(visDriver,vismsg1,true);
                
                if(!VisitorSite.checkVisitorMessageInChatWindow(visDriver,true,visname,vismsg1,2))
                {
                    etest.log(Status.FAIL,visname+" or "+vismsg1+" is not seen in chat window");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+7),false);
                }
                else
                {
                    result.put("NE"+(useCase+7),true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+5),false);
                return;
            }

            if(!CommonFunctions.checkMessageInUserWindow(driver,vismsg1))
            {
                etest.log(Status.FAIL,visname+" or "+vismsg1+" is not seen in agent chat window");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                result.put("NE"+(useCase+8),false);
            }
            else
            {
                result.put("NE"+(useCase+8),true);
            }

            try
            {
                VisitorSite.visitorSentMessage(visDriver,vismsg2,false);
                
                if(!VisitorSite.checkVisitorMessageInChatWindow(visDriver,false,null,vismsg2,3))
                {
                    etest.log(Status.FAIL,visname+" or "+vismsg2+" is not seen in chat window");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+9),false);
                }
                else
                {
                    result.put("NE"+(useCase+9),true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+9),false);
                return;
            }

            if(!CommonFunctions.checkMessageInUserWindow(driver,vismsg2))
            {
                etest.log(Status.FAIL,visname+" or "+vismsg1+" is not seen in agent chat window");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                result.put("NE"+(useCase+8),false);
            }
            else
            {
                result.put("NE"+(useCase+8),true);
            }
            
            CommonFunctions.endChatUser(driver);
            CommonFunctions.clickClosethisWindow(driver);

            try
            {
                VisitorSite.checkChatEnded(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+10),false);
                return;
            }

            result.put("NE"+(useCase+10),true);

            try
            {
                VisitorSite.enterFeedback(visDriver,"Feedback1","3");

                Thread.sleep(4000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+16),false);
                return;
            }

            if(!CommonFunctions.checkFeedbackContent(driver,visname,"Feedback1","3"))
            {
                etest.log(Status.FAIL,"Feedback mismatch");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                result.put("NE"+(useCase+16),false);
            }
            else
            {
                result.put("NE"+(useCase+16),true);
            }

            String checked = "";

            for(int i = 1;i<=10;i++)
            {
                checked += KeyManager.getRealValue("NE"+(useCase+i)).replace("New Embed - "+theme+" - ","")+", ";
            }

            checked += KeyManager.getRealValue("NE"+(useCase+16)).replace("New Embed - "+theme+" - ","");
            
            etest.log(Status.INFO,checked);
            etest.log(Status.PASS,"Checked");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+1),false);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+1),false);
        }
    }

    public static void check2(WebDriver driver,String theme,int useCase)
    {
        WebDriver visDriver = null;

        try
        {
            visDriver = VisitorSite.setUpVisitorDriver();
            
            for(int i = 0 ; i <= 4; i++)
            {
                visDriver = VisitorSite.setUpVisitorDriver1(visDriver);
                try
                {
                    String fileds[] = {"Name","email@salesiq.com","54321",dept,"Question"};
                    
                    fileds[i] = null;

                    VisitorWindow.initiateChatVisTheme(visDriver,fileds[0],fileds[1],fileds[2],fileds[3],fileds[4],false,etest);

                    Thread.sleep(2000);

                    if(!VisitorSite.checkWaitingDiv(visDriver,false))
                    {
                        etest.log(Status.FAIL,"Chat is initiated");
                        TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                        result.put("NE"+(useCase+11+i),false);
                    }
                    else
                    {
                        result.put("NE"+(useCase+11+i),true);
                    }
                }
                catch(Exception e)
                {
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                    result.put("NE"+(useCase+11),false);
                    return;
                }
            }

            String checked = "";

            for(int i = 11;i<=14;i++)
            {
                checked += KeyManager.getRealValue("NE"+(useCase+i)).replace("New Embed - "+theme+" - ","")+", ";
            }

            checked += KeyManager.getRealValue("NE"+(useCase+15)).replace("New Embed - "+theme+" - ","");
            
            etest.log(Status.INFO,checked);
            etest.log(Status.PASS,"Checked");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+12),false);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+12),false);
        }
    }

    public static void check3(WebDriver driver,String theme,int useCase)
    {
        Long t = new Long(System.currentTimeMillis());
        String time = t.toString();

        String agentname ="LDAutomation";
        String agentmsg = "A"+time;
        String vismsg1 = "VM1"+time;
        String vismsg2 = "VM2"+time;
        String visname = "V"+time;
        String visemail = "email@"+time+".com";
        String visphone = "+"+time;
        String question = "Q"+time;

        WebDriver visDriver = null;

        try
        {
            visDriver = VisitorSite.setUpVisitorDriver();

            try
            {
                VisitorWindow.initiateChatVisTheme(visDriver,visname,visemail,visphone,dept,question,etest);
                
                VisitorSite.checkWaitingDiv(visDriver,true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+20),false);
                return;
            }

            CommonFunctions.acceptChat(driver);
            
            try
            {
                if(!VisitorSite.checkWaitingDiv(visDriver,false))
                {
                    etest.log(Status.FAIL,"Waiting div is not gone invisible after accepting chat");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+20),false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+20),false);
                return;
            }
            
            CommonFunctions.endChatUser(driver,ResourceManager.getRealValue("endsession_30secs"));

            try
            {
                if(!VisitorSite.checkEndTimer(visDriver,30,true,true))
                {
                    etest.log(Status.FAIL,"Chat is not ended");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+20),false);
                }
                else
                {
                    result.put("NE"+(useCase+20),true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+20),false);
                return;
            }

            CommonFunctions.clickClosethisWindow(driver);

            try
            {
                VisitorSite.enterFeedback(visDriver,null,null);

                Thread.sleep(4000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+17),false);
                return;
            }

            if(CommonFunctions.getVisitorFromFeedback(driver,visname) != null)
            {
                etest.log(Status.FAIL,"Feedback for visitor "+visname+" is present");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                result.put("NE"+(useCase+17),false);
            }
            else
            {
                result.put("NE"+(useCase+17),true);
            }

            String checked = "";

            checked += KeyManager.getRealValue("NE"+(useCase+20)).replace("New Embed - "+theme+" - ","")+", ";
            
            checked += KeyManager.getRealValue("NE"+(useCase+17)).replace("New Embed - "+theme+" - ","");
            
            etest.log(Status.INFO,checked);
            etest.log(Status.PASS,"Checked");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+20),false);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+20),false);
        }
    }

    public static void check4(WebDriver driver,String theme,int useCase)
    {
        Long t = new Long(System.currentTimeMillis());
        String time = t.toString();

        String agentname ="LDAutomation";
        String agentmsg = "A"+time;
        String vismsg1 = "VM1"+time;
        String vismsg2 = "VM2"+time;
        String visname = "V"+time;
        String visemail = "email@"+time+".com";
        String visphone = "+"+time;
        String question = "Q"+time;

        WebDriver visDriver = null;

        try
        {
            visDriver = VisitorSite.setUpVisitorDriver();
    
            try
            {
                VisitorWindow.initiateChatVisTheme(visDriver,visname,visemail,visphone,dept,question,etest);
                
                VisitorSite.checkWaitingDiv(visDriver,true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+21),false);
                return;
            }

            CommonFunctions.acceptChat(driver);
            
            try
            {
                if(!VisitorSite.checkWaitingDiv(visDriver,false))
                {
                    etest.log(Status.FAIL,"Waiting div is not gone invisible after accepting chat");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+21),false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+21),false);
                return;
            }
            
            CommonFunctions.endChatUser(driver,ResourceManager.getRealValue("endsession_45secs"));

            try
            {
                if(!VisitorSite.checkEndTimer(visDriver,45,true,false))
                {
                    etest.log(Status.FAIL,"Chat is not ended");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+21),false);
                    return;
                }
                
                VisitorSite.visitorSentMessage(visDriver,"Visitor1",false);

                if(!VisitorSite.checkEndTimer(visDriver,45,false,false))
                {
                    etest.log(Status.FAIL,"End timer is not gone invisible");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+21),false);
                }
                else
                {
                    result.put("NE"+(useCase+21),true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+21),false);
                return;
            }

            Thread.sleep(2000);

            CommonFunctions.endChatUser(driver);
            CommonFunctions.clickClosethisWindow(driver);

            try
            {
                VisitorSite.enterFeedback(visDriver,"Feedback2","3");

                Thread.sleep(4000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+18),false);
                return;
            }

            if(!CommonFunctions.checkFeedbackContent(driver,visname,"Feedback2","3"))
            {
                etest.log(Status.FAIL,"Feedback mismatch");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                result.put("NE"+(useCase+18),false);
                return;
            }
            
            try
            {
                VisitorSite.continueChat(visDriver);

                VisitorSite.checkWaitingDiv(visDriver,true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+18),false);
                return;
            }

            CommonFunctions.acceptChat(driver);
            
            try
            {
                if(!VisitorSite.checkWaitingDiv(visDriver,false))
                {
                    etest.log(Status.FAIL,"Waiting div is not gone invisible after accepting chat");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+18),false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+18),false);
                return;
            }

            result.put("NE"+(useCase+18),true);

            CommonFunctions.endChatUser(driver);
            CommonFunctions.clickClosethisWindow(driver);
            
            String checked = "";

            checked += KeyManager.getRealValue("NE"+(useCase+21)).replace("New Embed - "+theme+" - ","")+", ";
            
            checked += KeyManager.getRealValue("NE"+(useCase+18)).replace("New Embed - "+theme+" - ","");
            
            etest.log(Status.INFO,checked);
            etest.log(Status.PASS,"Checked");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+20),false);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+20),false);
        }
    }

    public static void check5(WebDriver driver,String theme,int useCase)
    {
        Long t = new Long(System.currentTimeMillis());
        String time = t.toString();

        String agentname ="LDAutomation";
        String agentmsg = "A"+time;
        String vismsg1 = "VM1"+time;
        String vismsg2 = "VM2"+time;
        String visname = "V"+time;
        String visemail = "email@"+time+".com";
        String visphone = "+"+time;
        String question = "Q"+time;

        WebDriver visDriver = null;

        try
        {
            visDriver = VisitorSite.setUpVisitorDriver();

            try
            {
                VisitorWindow.initiateChatVisTheme(visDriver,visname,visemail,visphone,dept,question,etest);
                
                VisitorSite.checkWaitingDiv(visDriver,true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+22),false);
                return;
            }

            CommonFunctions.acceptChat(driver);
            
            try
            {
                if(!VisitorSite.checkWaitingDiv(visDriver,false))
                {
                    etest.log(Status.FAIL,"Waiting div is not gone invisible after accepting chat");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+22),false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+22),false);
                return;
            }
            
            CommonFunctions.endChatUser(driver,ResourceManager.getRealValue("endsession_60secs"));

            try
            {
                if(!VisitorSite.checkEndTimer(visDriver,60,true,false))
                {
                    etest.log(Status.FAIL,"Chat is not ended");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+22),false);
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+22),false);
                return;
            }

            CommonFunctions.stopEndChatUser(driver);

            try
            {
                if(!VisitorSite.checkEndTimer(visDriver,60,false,false))
                {
                    etest.log(Status.FAIL,"End timer is not gone invisible");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+22),false);
                }
                else
                {
                    result.put("NE"+(useCase+22),true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+22),false);
                return;
            }

            Thread.sleep(2000);

            CommonFunctions.endChatUser(driver);
            CommonFunctions.clickClosethisWindow(driver);

            try
            {
                VisitorSite.enterFeedback(visDriver,null,null);

                Thread.sleep(2000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+19),false);
                return;
            }

            if(CommonFunctions.getVisitorFromFeedback(driver,visname) != null)
            {
                etest.log(Status.FAIL,"Feedback for visitor "+visname+" is present");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error");
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                result.put("NE"+(useCase+19),false);
            }
            
            try
            {
                VisitorSite.continueChat(visDriver);

                VisitorSite.checkWaitingDiv(visDriver,true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+19),false);
                return;
            }

            CommonFunctions.acceptChat(driver);
            
            try
            {
                if(!VisitorSite.checkWaitingDiv(visDriver,false))
                {
                    etest.log(Status.FAIL,"Waiting div is not gone invisible after accepting chat");
                    TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error");
                    result.put("NE"+(useCase+19),false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+19),false);
                return;
            }

            result.put("NE"+(useCase+19),true);

            try
            {
                VisitorSite.checkOptions(visDriver);

                result.put("NE"+(useCase+23),true);

                VisitorSite.endChatVisitor(visDriver);

                result.put("NE"+(useCase+24),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewEmbed",theme,"Error",e);
                result.put("NE"+(useCase+23),false);
                return;
            }

            CommonFunctions.clickClosethisWindow(driver);

            String checked = "";

            checked += KeyManager.getRealValue("NE"+(useCase+22)).replace("New Embed - "+theme+" - ","")+", ";
            
            checked += KeyManager.getRealValue("NE"+(useCase+19)).replace("New Embed - "+theme+" - ","")+", ";

            checked += KeyManager.getRealValue("NE"+(useCase+23)).replace("New Embed - "+theme+" - ","")+", ";
            
            checked += KeyManager.getRealValue("NE"+(useCase+24)).replace("New Embed - "+theme+" - ","");
            
            etest.log(Status.INFO,checked);
            etest.log(Status.PASS,"Checked");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+22),false);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed",theme,"Error",e);
            result.put("NE"+(useCase+22),false);
        }
    }
    
    public static void changeConfigBasic(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonUtil.elfinder(driver,"id","fname").click();
            CommonUtil.elfinder(driver,"id","fname").sendKeys("Tester");
            CommonUtil.elfinder(driver,"id","femail").click();
            CommonUtil.elfinder(driver,"id","femail").sendKeys("rajkumar.natarajan+143@zohocorp.com");
            CommonUtil.elfinder(driver,"id","fphone").click();
            CommonUtil.elfinder(driver,"id","fphone").sendKeys("9876544578");
            CommonUtil.elfinder(driver,"name","defaultdept").click();
            CommonUtil.elfinder(driver,"name","defaultdept").sendKeys("ldautomation22");
            CommonUtil.elfinder(driver,"id","fquestion").click();
            CommonUtil.elfinder(driver,"id","fquestion").sendKeys("Any Question? ...");
            CommonUtil.elfinder(driver,"id","fsubbutton").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            System.out.println("Exception while changing config for basic api in jsapi module : ");
            TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigBasic","JSApiConfigBasicError");
            Thread.sleep(1000);
            e.printStackTrace();
        }
    }
    
    public static void checkConfigBasic(WebDriver driver,String theme,int useCase) throws Exception
    {
        try
        {
            etest = ComplexReportFactory.getTest(theme+" - $zoho.salesiq.visitor.name()");
            ComplexReportFactory.setValues(etest,"Automation","New Embed","This API is used to fill the visitor's name in the chat widget text box.");
            
            result.put("NE"+(useCase+25),false);
            result.put("NE"+(useCase+26),false);
            result.put("NE"+(useCase+27),false);
            result.put("NE"+(useCase+28),false);
            result.put("NE"+(useCase+28),false);
            
            CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();
            
            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");
            
            driver.switchTo().frame(chframe);
            
            String cname = CommonUtil.elfinder(driver,"id","visname").getAttribute("value");
            String cemail = CommonUtil.elfinder(driver,"id","visemail").getAttribute("value");
            String cphone = CommonUtil.elfinder(driver,"id","visphone").getAttribute("value");
            String cques = CommonUtil.elfinder(driver,"id","msgarea").getAttribute("value");
            String cdept = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","sqico-drpdwn"),"id","dropheader").getText();
            
            if(cname.equals("Tester"))
            {
                etest.log(Status.PASS,"Text in Field : "+cname);
                result.put("NE"+(useCase+25),true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cname+" || (Expected : Tester)");
                TakeScreenshot.screenshot(driver,etest,"New Embed","JSApiConfigBasicCk","JSApiNameFail");
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(theme+" - $zoho.salesiq.visitor.email()");
            ComplexReportFactory.setValues(etest,"Automation","New Embed","You can use this API to fill the visitor email address in the chat widget text box.");
            
            if(cemail.equals("rajkumar.natarajan+143@zohocorp.com"))
            {
                etest.log(Status.PASS,"Text in Field : "+cemail);
                result.put("NE"+(useCase+26),true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cemail+" || (Expected : rajkumar.natarajan+143@zohocorp.com)");
                TakeScreenshot.screenshot(driver,etest,"New Embed","JSApiConfigBasicCk","JSApiEmailFail");
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(theme+" - $zoho.salesiq.visitor.contactnumber()");
            ComplexReportFactory.setValues(etest,"Automation","New Embed","This API is used to fill the visitor contact number in the chat widget text box.");
            
            if(cphone.equals("9876544578"))
            {
                etest.log(Status.PASS,"Text in Field : "+cphone);
                result.put("NE"+(useCase+27),true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cphone+" || (Expected : 9876544578)");
                TakeScreenshot.screenshot(driver,etest,"New Embed","JSApiConfigBasicCk","JSApiPhoneFail");
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(theme+" - $zoho.salesiq.visitor.question()");
            ComplexReportFactory.setValues(etest,"Automation","New Embed","You can use this API to pre-fill a question in the chat widget.");
            
            if(cques.equals("Any Question? ..."))
            {
                etest.log(Status.PASS,"Text in Field : "+cques);
                result.put("NE"+(useCase+28),true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cques+" || (Expected : Any Question? ...)");
                TakeScreenshot.screenshot(driver,etest,"New Embed","JSApiConfigBasicCk","JSApiQuesFail");
            }
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(theme+" - $zoho.salesiq.chat.defaultdepartment()");
            ComplexReportFactory.setValues(etest,"Automation","New Embed","This API allows you to set a default department in the pre-chat form and the visitors are allowed to select other department if needed. However Web Embed department settings should be configured as \"Allow user to select department\".");
            
            if(cdept.equals("ldautomation22"))
            {
                etest.log(Status.PASS,"Text in Field : "+cdept);
                result.put("NE"+(useCase+29),true);
            }
            else
            {
                etest.log(Status.FAIL,"Text in Field : "+cdept);
            }
            
            ComplexReportFactory.closeTest(etest);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking config for basic api in jsapi module : ");
            TakeScreenshot.screenshot(driver,etest,"New Embed","JSApiConfigBasicCk","JSApiConfigBasicError");
            Thread.sleep(1000);
            e.printStackTrace();
            ComplexReportFactory.closeTest(etest);
        }
    }

    public static void changeConfigSys1(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonUtil.elfinder(driver,"id","fsystemmessages").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("fsysmsg")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Thread.sleep(1000);
            
            NCommonFunctions.enterValueSysMsg(driver,"fsyswaiting","Waiting Message");
            NCommonFunctions.enterValueSysMsg(driver,"fsysbusy","Busy Message");
            NCommonFunctions.enterValueSysMsg(driver,"fsysbusycomplete","Busy Response Message");
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
        }
        catch(Exception e)
        {
            System.out.println("Exception while changing config for system messages api in jsapi module : ");
            TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgch","JSApiConfigSysMsgError");
            Thread.sleep(1000);
            e.printStackTrace();
        }
    }
    
    public static void checkConfigsys1(WebDriver driver,int useCase) throws Exception
    {
        try
        {
            result.put("NE"+(useCase+30),false);
            result.put("NE"+(useCase+31),false);
            result.put("NE"+(useCase+32),false);
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            FluentWait wait1 = CommonUtil.waitreturner(driver,5,100);
            
            NCommonFunctions.initiateChat(driver,"Tester6","rajkumar.natarajan+1442@zohocorp.com","99887688667","is chat working properly ? ...","ldautomation22");
            
            NCommonFunctions.switchToChatWidget(driver);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("wait_div"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.wait"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.wait"))));
            
            final String waitContent = VisitorWindow.getInfoMessage(driver);
            
            if(waitContent.contains("Waiting Message"))
            {
                etest.log(Status.PASS,"Waiting message : "+waitContent);
                result.put("NE"+(useCase+30),true);
            }
            else
            {
                etest.log(Status.FAIL,"Waiting message : "+waitContent+" || (Expected : Waiting Message)");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgCh","JSApiWaitFail");
            }
            
            VisitorWindow.waitTillChatisMissedInTheme(driver);

            Thread.sleep(3000);
            
            try
            {
                String busyContent = VisitorWindow.getInfoMessage(driver);
            
                if(busyContent.contains("Busy Message"))
                {
                    etest.log(Status.PASS,"Busy message : "+busyContent);
                    result.put("NE"+(useCase+31),true);
                }
                else
                {
                    etest.log(Status.FAIL,"Busy message : "+busyContent+" || (Expected : Busy Message)");
                    TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgCh","JSApiWaitFail");
                }
                
            }
            catch(Exception e)
            {
                etest.log(Status.FAIL,"Busy message failed");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgCh","JSApiBusyFail",e);
            }
            
            // VisitorWindow.initiateChatVisTheme(driver,null,null,null,null,"Hi",false,etest,true);
            
            // VisitorWindow.infoInvisible(driver);

            VisitorWindow.submitResponseAfterMissingChatWithAgent(driver,"Hi");
            
            try
            {
                String busyContent = VisitorWindow.getInfoMessage(driver,"Busy Response Message");
            
                if(busyContent.contains("Busy Response Message"))
                {
                    etest.log(Status.PASS,"Busy response message is checked");
                    result.put("NE"+(useCase+32),true);
                }
                else
                {
                    etest.log(Status.FAIL,"Busy Response Message : "+busyContent+" || (Expected : Busy Response Message)");
                    TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgCh","JSApiWaitFail");
                }
            }
            catch(Exception e)
            {
                etest.log(Status.FAIL,"Busy response message failed");
                TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgCh","JSApiBusyFail");
            }
            
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewEmbed","JSApiConfigSysMsgCh","JSApiConfigSysMsgError",e);
        }
    }


}
