//$Id$
package com.zoho.livedesk.client.NewEmbed;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import org.openqa.selenium.StaleElementReferenceException;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.*;

import com.google.common.base.Function;

import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class CommonFunctions {
    
    public static void clickSettings(WebDriver driver) throws Exception
	{
        clickVisitorsOnline(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
		WebElement settings = CommonUtil.elfinder(driver,"id","menu_setting");
		settings.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
	}
	
	public static void clickVisitorsOnline(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_monitor")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visitor_monitor")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
    }
    
    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_vhistory")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visits_div")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visits_div")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickChatHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_history")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_div")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("history_div")));
    }

    public static void clickFeedback(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext","Feedback").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("feedback_div")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("feedback_div")));
    }

    public static void clickReports(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext","Reports").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().toLowerCase().contains("reports"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
	}

    public static void clickCannedMessages(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext","Canned Messages").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("Canned Messages"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

    public static void clickMyProfile(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext","My Profile").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("My Profile"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

    public static void navToCompTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_company")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_company");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
    }

    public static void navToDeptTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_department")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_department");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
    }

    public static void navToPortalSettingsTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_configration")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_configration");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
    }

    public static void navToBlockedIPTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_blockedip")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_blockedip");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modulelist")));
    }

    public static void navToEmbedTab(WebDriver driver) throws Exception
	{
		clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));
		WebElement embed = CommonUtil.elfinder(driver,"id","setting_sm_embedchats");
		embed.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
	}

	public static void navToAutomationTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_automation");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationtabs")));
    }

	public static void navToChatMonitorTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autochatmonitortab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autochatmonitortab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    } 

    public static void navToIntelligentTriggerTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotriggerstab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autotriggerstab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }   

    public static void navToVisitorRoutingTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoroutingrulestab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autoroutingrulestab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }   

    public static void navToEmailScheduleTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoschedulertab")));
		WebElement e = CommonUtil.elfinder(driver,"classname","autoschedulertab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }

    public static void navToLeadScoringTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_leadscoring")));
		WebElement e = CommonUtil.elfinder(driver,"id","setting_sm_leadscoring");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
    }

	public static void navToIntegTab(WebDriver driver) throws Exception
	{
		clickSettings(driver);
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_integration")));
		WebElement integ = CommonUtil.elfinder(driver,"id","setting_sm_integration");
		integ.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("integhome")));
	}

	public static WebElement selectEmbedInWebEmbed(WebDriver driver,String embedname) throws Exception
	{
        navToEmbedTab(driver);

		FluentWait wait = CommonUtil.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("list-row")));

		List<WebElement> list = driver.findElements(By.className("list-row"));

		for(WebElement e : list)
		{
			if(e.getText().contains(embedname))
			{
				return e;
			}
		}

		return null;
	}

    public static void openWebEmbed(WebDriver driver,String embedname) throws Exception
    {
        selectEmbedInWebEmbed(driver,embedname).click();

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedconfigform")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedconfigform")));
    }

    public static void clickChatWindowAppearance(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='chatcode']//*[@id='caddem2']")));
        
        WebElement edit = CommonUtil.elfinder(driver,"id","caddem2");//driver.findElement(By.xpath("//*[@id='chatcode']//*[@id='caddem2']"));
        
        for(int i = 1;i<=10;i++)
        {
            edit = CommonUtil.elfinder(driver,"id","caddem2");
            
            try
            {
                edit.click();
                
                break;
            }
            catch(Exception e)
            {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(edit).getLocation().y+"-"+i+"00)");
            }
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addem2")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));
    }

    public static void changeTheme(WebDriver driver,String theme) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

        WebElement div = CommonUtil.elfinder(driver,"id","addem2");

        WebElement themes = CommonUtil.elementfinder(driver,div,"id","themes");

        Select se = new Select(themes);
        
        se.selectByVisibleText(theme);

        WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","actn-btn-base"),"tagname","span");

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt).getLocation().y+"-400)");

        elmt.click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.id("addem2")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
    }

    public static void changeFields(WebDriver driver,String[] requiredFields,String[] manFields) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
    
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

        WebElement div = CommonUtil.elfinder(driver,"id","addem2");

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(div.findElements(By.tagName("h6")).get(5)).getLocation().y+"-400)");
                
        CommonUtil.elementfinder(driver,div,"xpath","//h6[contains(text(),'Visitor Information')]").click();
        
        Thread.sleep(2000);

        String fields[] = {"ishowname","ishowemail", "ishowphone", "namemandatory", "emailmandatory", "phonemandatory"};
                
        for(String field : fields)
        {
            disableChatVisInfo(driver,field);
        }

        Thread.sleep(1000);

        for(String field : requiredFields)
        {
            enableChatVisInfo(driver,field);
        }

        Thread.sleep(1000);

        for(String field : manFields)
        {
            enableChatVisInfo(driver,field);
        }

        Thread.sleep(1000);

        WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,div,"classname","actn-btn-base"),"tagname","span");

        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt).getLocation().y+"-400)");

        elmt.click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(driver.findElement(By.id("addem2")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                }
                catch(StaleElementReferenceException e){}
                return false;
            }
        });
    }

    public static void enableChatVisInfo(WebDriver driver,final String id) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        if(CommonUtil.elfinder(driver,"id",id).getAttribute("checked") == null)
        {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",id)).getLocation().y+"-400)");
            CommonUtil.elfinder(driver,"id",id).click();
            
            Thread.sleep(1000);
        }
    }

    public static void disableChatVisInfo(WebDriver driver,final String id) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        if(CommonUtil.elfinder(driver,"id",id).getAttribute("checked") != null)
        {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",id)).getLocation().y+"-400)");
            CommonUtil.elfinder(driver,"id",id).click();
            
            Thread.sleep(1000);
        }
    }
    
    public static void acceptChat(WebDriver driver) throws Exception
    {
        ChatWindow.acceptChat(driver,NewEmbedUtil.etest);
    }

    public static void clickClosethisWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,chat,"id","infodiv"),"linktext",ResourceManager.getRealValue("closewindow")).click();
        
        Thread.sleep(1000);
        
    }
    
    public static void endChatUser(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        sentMessageUser(driver,"Bye ...");

        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);
        
        CommonUtil.elementfinder(driver,chat,"id","endsession").click();
        
        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();
            
    }

    public static void endChatUser(WebDriver driver,String action) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        sentMessageUser(driver,"Bye ...");
        
        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);
        
        CommonUtil.elementfinder(driver,chat,"id","endsession").click();
        
        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue(action)).click();
            
    }

    public static void stopEndChatUser(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);
        
        CommonUtil.elementfinder(driver,chat,"id","endsession").click();
        
        Thread.sleep(1000);

        CommonUtil.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue("endsession_endtimer")).click();
            
    }
    
    public static WebElement chatInMyChats(WebDriver driver) throws Exception
    {
        List<WebElement> list = CommonUtil.elfinder(driver,"id","mycurrent_div").findElements(By.className("prelative"));

        WebElement chat = null;

        for(WebElement e : list)
        {
            if(e.getAttribute("style").contains("display: block;"))
            {
                chat = e;
                break;
            }
        }

        return chat;
    }

    public static String getVisitorNameInAgentChatWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn");

        String s = CommonUtil.elementfinder(driver,e,"id","chatvisname").getText();

        return s;
    }

    public static String getVisitorEmailInAgentChatWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn");

        String s = CommonUtil.elementfinder(driver,e,"id","chatvisemail").getText();

        return s;
    }

    public static String getVisitorQuestionInAgentChatWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"classname","t-v-questionmn");
        
        System.out.println("New Embed - Question t-v-questionmn innerHTML:"+e.getAttribute("innerHTML"));

        String s = CommonUtil.elementfinder(driver,e,"xpath",".//h1//pre").getText();

        return s;
    }

    public static String getVisitorPhoneInAgentChatWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"id","visitordata");

        String s = CommonUtil.elementfinder(driver,e,"id","cvphone").getText();

        return s;
    }

    public static String getVisitorDepartmentInAgentChatWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        WebElement e = CommonUtil.elementfinder(driver,chat,"id","visitordata");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("visitordata")).getAttribute("innerHTML").contains("rcvstrdep-ico"))
                {
                    return true;
                }
                return false;
            }
        });

        List<WebElement> list = e.findElements(By.className("rcvstinfotxt"));

        for(WebElement l : list)
        {
            if(l.getAttribute("innerHTML").contains("rcvstrdep-ico"))
            {
                return l.getText();
            }
        }

        return "";
    }

    public static String getVisitorUrlInAgentChatWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);
        
        WebElement e = CommonUtil.elementfinder(driver,chat,"id","visitordata");
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("visitordata")).getAttribute("innerHTML").contains("sqico-device-link"))
                {
                    return true;
                }
                return false;
            }
        });
        
        List<WebElement> list = e.findElements(By.className("rcvstinfotxt"));
        
        for(WebElement l : list)
        {
            if(l.getAttribute("innerHTML").contains("sqico-device-link"))
            {
                return l.getText();
            }
        }
        
        return "";
    }
    
    public static String getUserName(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtil.waitreturner(driver,30,250);

    	clickMyProfile(driver,"My Profile");

        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
        WebElement elmt1 = CommonUtil.elfinder(driver,"id","test");

        WebElement userdetails = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt1,"classname","usr-mrgntp"),"id","userdetails");
        
        return userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
    }

    public static void sentMessageUser(WebDriver driver,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);
        
        CommonUtil.elementfinder(driver,chat,"id","txteditor").sendKeys(msg);
        CommonUtil.elementfinder(driver,chat,"id","txteditor").sendKeys(Keys.RETURN);
    }

    public static boolean checkMessageInUserWindow(WebDriver driver,final String msg) throws Exception
    {
        return checkMessageInUserWindow(driver,msg,1);
    }
    
    public static boolean checkMessageInUserWindow(WebDriver driver,final String msg, int i) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            final WebElement chat = chatInMyChats(driver);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(chat.findElement(By.id("chatdivcontainer")).getAttribute("innerHTML").contains("tr"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    List<WebElement> messages = chat.findElement(By.id("chatdivcontainer")).findElements(By.tagName("tr"));
                    if(messages.get(messages.size()-1).getText().contains(msg))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            return true;
        }
        catch(StaleElementReferenceException excep)
        {
            if(i == 4)
            {
                throw excep;
            }
            else
            {
                Thread.sleep(2000);
                
                return checkMessageInUserWindow(driver,msg,i+1);
            }
        }
    }

    public static void clearVisitorDrivers(Set<WebDriver> visitors)
    {
        for(WebDriver driver : visitors)
        {
            if(driver!=null)
            {
                driver.quit();
            }
        }
    }

    public static WebElement getVisitorFromFeedback(WebDriver driver,String visitor) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("suppm_feedback")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("suppm_feedback")));

        CommonUtil.elfinder(driver,"id","suppm_feedback").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("feedbacklist")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("feedbacklist")));

        List<WebElement> elmts = CommonUtil.elfinder(driver,"id","feedbacklist").findElements(By.xpath("//tr[@class='cursr-point']"));
        
        WebElement element = null;
        
        for(WebElement e : elmts)
        {
            if(CommonUtil.elementfinder(driver,e,"tagname","h2").getText().contains(visitor))
            {
                element = e;
                break;
            }
        }

        return element;
    }

    public static boolean checkFeedbackContent(WebDriver driver,String visitor,String feedbackmsg,String star) throws Exception
    {
        star = "fb_star star-"+star;
        
        WebElement element = getVisitorFromFeedback(driver,visitor);

        WebElement message =  CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,element,"classname","thrd-clm"),"tagname","pre");
        WebElement rating = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,element,"classname","four-clm"),"classname","fb_star");
        if((feedbackmsg.equals(message.getText())) && (star.equals(rating.getAttribute("class"))))
        {
            return true;
        }

        return false;
    }
}
