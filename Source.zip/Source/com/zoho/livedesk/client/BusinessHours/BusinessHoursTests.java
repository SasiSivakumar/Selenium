//$Id$
package com.zoho.livedesk.client.BusinessHours;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalInput;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsConstants.PortalSetting;
import com.zoho.livedesk.client.PortalSettingsRealTime.PortalSettingsRealTimeCommonFunctions;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import org.openqa.selenium.TimeoutException;

import com.zoho.livedesk.util.common.CryptoUtil;
public class BusinessHoursTests
{
	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = null;
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Business Hours";
	public static String WIDGET_CODE="",WEBSITE_NAME="";

	public static VisitorDriverManager visitor_driver_manager;

	public static Hashtable test(WebDriver driver)
	{
		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            WEBSITE_NAME=ExecuteStatements.getDefaultEmbedName(driver);
            WIDGET_CODE=ExecuteStatements.getWidgetCodeFromEmbedName(driver,WEBSITE_NAME);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH1"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH1",checkBusinessHours(driver,etest,WIDGET_CODE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH2"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH2",checkBusinessHours(driver,etest,WIDGET_CODE,true,false,VisitorWindow.OFFLINE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH3"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH3",checkBusinessHours(driver,etest,WIDGET_CODE,true,true,VisitorWindow.NOT_FOUND));
            ComplexReportFactory.closeTest(etest);
        
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH4"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH4",checkBusinessHours(driver,etest,WIDGET_CODE,true,false,VisitorWindow.ONLINE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH5"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH5",checkBusinessHours(driver,etest,WIDGET_CODE,true,true,VisitorWindow.ONLINE));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH6"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH6",checkPopup(driver,etest,WIDGET_CODE,VisitorWindow.NOT_FOUND));
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH7"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("BH7",checkPopup(driver,etest,WIDGET_CODE,VisitorWindow.OFFLINE));
            ComplexReportFactory.closeTest(etest);		
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH8"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("BH8",checkSubsequentDays(driver,etest));
            ComplexReportFactory.closeTest(etest);		

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH9"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("BH9",selectMultipleGrids(driver,etest));
            ComplexReportFactory.closeTest(etest);		

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH10"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("BH10",checkAdjacentBusinessHours(driver,etest));
            ComplexReportFactory.closeTest(etest);	

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BH11"));
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            result.put("BH11",checkBHTwoDays(driver,etest));
            ComplexReportFactory.closeTest(etest);	

			visitor_driver_manager.terminateAllDriverSessions();
        }
            
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
			TakeScreenshot.log(e,etest);
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}            
	}

	public static boolean checkBusinessHours(WebDriver driver,ExtentTest etest,String widget_code) throws Exception
	{
		return checkBusinessHours(driver,etest,widget_code,false,false,VisitorWindow.ONLINE);
	}

	public static boolean checkBusinessHours(WebDriver driver,ExtentTest etest,String widget_code,boolean isEnableBusinessHour,boolean isEnableHideChatWidget,int expected_state) throws Exception
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			//toggle settings
			Tab.navToCompTab(driver);

			Company.toggleBusinessHours(driver,isEnableBusinessHour);
			if(isEnableBusinessHour)
			{
				Company.toggleHideChatWidget(driver,isEnableHideChatWidget);
			}

			etest.log(Status.INFO,"Company settings is set as shown below");
			TakeScreenshot.infoScreenshot(driver,etest);

			//set business hours
			if(isEnableBusinessHour)
			{
				if(expected_state==VisitorWindow.ONLINE)
				{
					BusinessHours.setCurrentTimeAsBusinessHour(driver,etest);
					etest.log(Status.INFO,"Business hours are configured to current time");
				}
				else
				{
					BusinessHours.setPastTimeAsBusinessHour(driver,etest);
					etest.log(Status.INFO,"Business hours are configured to a past time");
				}
	
				BusinessHours.saveBusinessHourSettings(driver);

				TakeScreenshot.infoScreenshot(driver,etest);
			}

			//open visitor driver
			visitor_driver=visitor_driver_manager.getDriver(driver);
			boolean isWaitTillChat=(expected_state==VisitorWindow.NOT_FOUND)?false:true;
			VisitorWindow.createPage(visitor_driver,widget_code,isWaitTillChat);

			//check chat widget

			int actual_state=VisitorWindow.getChatWindowState(visitor_driver);

			if(actual_state==expected_state)
			{
				etest.log(Status.PASS,"Chat window state was found as "+VisitorWindow.getChatWindowState(expected_state));
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Chat window state was NOT found as "+VisitorWindow.getChatWindowState(expected_state)+", Actual State : "+VisitorWindow.getChatWindowState(actual_state));
				TakeScreenshot.screenshot(driver,etest);
				TakeScreenshot.screenshot(visitor_driver,etest);
			}

		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
		finally
		{
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkPopup(WebDriver driver,ExtentTest etest,String widget_code,int visitor_chat_state) throws Exception
	{
		WebDriver visitor_driver=null;

		int failcount=0;

		try
		{
			Tab.navToCompTab(driver);

			Company.toggleBusinessHours(driver,true);
			Company.toggleHideChatWidget(driver,(visitor_chat_state==VisitorWindow.NOT_FOUND));

			etest.log(Status.INFO,"Company settings is set as shown below");
			TakeScreenshot.infoScreenshot(driver,etest);

	        BusinessHours.clearAllBusinessHourConfiguration(driver);
	        BusinessHours.saveBusinessHourSettings(driver,null);

            WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"standard work hours");
            CommonWait.waitTillDisplayed(popup);

	        String usecase=(visitor_chat_state==VisitorWindow.NOT_FOUND)?"BH6":"BH7";
	        String resource_key=(visitor_chat_state==VisitorWindow.NOT_FOUND)?"business_hours_empty_popup":"business_hours_offline_popup";

			result.put(usecase,CommonUtil.checkStringContainsAndLog( ResourceManager.getRealValue(resource_key),popup.getAttribute("innerText"),"business hours save popup text",etest ) );

            HandleCommonUI.clickNegativePopupButton(popup);

            BusinessHours.cancelSave(driver);

            TakeScreenshot.infoScreenshot(driver,etest);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"Exception","Exception",e);
		}
		finally
		{
			return CommonUtil.returnResult(failcount);
		}
	}
	
	public static boolean checkSubsequentDays(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,true);
			etest.log(Status.INFO,"Business Hours is enabled");

			TakeScreenshot.infoScreenshot(driver,etest);
        	CommonUtil.scrollToBottomOfPage(driver);
			BusinessHours.clearAllBusinessHourConfiguration(driver);
	        BusinessHours.saveBusinessHourSettings(driver,true);
			Long time=System.currentTimeMillis();
			int hour = BusinessHours.getHour(time);
			etest.log(Status.INFO,"Hour "+hour); 

			int count=0;
			for(int i=1;i<=7;i++)
        	{
            	if(setBHDaily(driver,etest,hour,i))
            	{
            		++count;
            	}    
        	}
			if(count == 7)
			{
				etest.log(Status.PASS,"Business Hours is set for all the days");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Business Hours is not set for all the days");
				TakeScreenshot.screenshot(driver,etest);
				return false;	
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);	
			return false;
		}

	}

	public static boolean setBHDaily(WebDriver driver,ExtentTest etest,int hour,int day) throws Exception
    {
        try
        {
            int before_click=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
        	FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
            BusinessHours.setBusinessHour(driver,etest,day,hour);
            BusinessHours.setBusinessHour(driver,etest,day,(hour==23)?0:hour+1);
            BusinessHours.saveBusinessHourSettings(driver);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("[onclick*=updateData]")));
            Thread.sleep(1000);
            int after_click=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
            if(before_click+1 == after_click){
            	return true;
            }
            else
            {
            	return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Business Hours","Exception","Exception",e);
            return false;
        }
    }
	
	public static boolean selectMultipleGrids(WebDriver driver,ExtentTest etest) throws Exception
	{ 
		try
		{
			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,true);
			etest.log(Status.INFO,"Business Hours is enabled");
			TakeScreenshot.infoScreenshot(driver,etest);
        	CommonUtil.scrollToBottomOfPage(driver);

			BusinessHours.clearAllBusinessHourConfiguration(driver);
	        BusinessHours.saveBusinessHourSettings(driver,true);
			Long time=System.currentTimeMillis();
			int hour=BusinessHours.getHour(time);

			if((clickMultipleGrids(driver,etest))==true)
			{
				etest.log(Status.PASS,"Multiple Grid containers have been created in a single day");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"The expected grid container is not created");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			return false;
		}
	}

	public static boolean clickMultipleGrids(WebDriver driver,ExtentTest etest)
    {
        try
        {
        	FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
            Long time=System.currentTimeMillis();

            int day=BusinessHours.getDay(time);
            for(int i=6;i<24;i++)
            {
                if(i==8||i==13||i==20)
                {
                    BusinessHours.saveBusinessHourSettings(driver);
                    Thread.sleep(500); 
                    continue;       
                }
                BusinessHours.setBusinessHour(driver,etest,day,i);
            }
            BusinessHours.saveBusinessHourSettings(driver); 
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("[onclick*=updateData]")));
            Thread.sleep(1000);
            int containers=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
            if(containers == 4)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Business Hours","Exception","Exception",e);
            return false;
        }  
    }
	
	public static boolean checkAdjacentBusinessHours(WebDriver driver,ExtentTest etest) throws Exception
	{	
		try
		{
			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,true);
			etest.log(Status.INFO,"Busniess Hours is enabled");
			TakeScreenshot.infoScreenshot(driver,etest);
        	CommonUtil.scrollToBottomOfPage(driver);

			BusinessHours.clearAllBusinessHourConfiguration(driver);
	        BusinessHours.saveBusinessHourSettings(driver,true);
			
			if((setAdjacentBusinessHours(driver,etest))==true)
			{
				etest.log(Status.PASS,"The adjacent grids are merged");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"The adjacent grids is not merged");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			return false;
		}
	}

	public static boolean setAdjacentBusinessHours(WebDriver driver,ExtentTest etest)
    {
        try
        {
            Long time=System.currentTimeMillis();
            int day=BusinessHours.getDay(time);
            FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
           
            for(int i=9;i<14;i++)
            {
                BusinessHours.setBusinessHour(driver,etest,day,i);
            }
            BusinessHours.saveBusinessHourSettings(driver);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("[onclick*=updateData]")));
        	Thread.sleep(1000);
            int no_of_hour_containers_selected_before_click=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
            
            for(int i=14;i<17;i++)
            {
                BusinessHours.setBusinessHour(driver,etest,day,i);
            }

            BusinessHours.saveBusinessHourSettings(driver);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("[onclick*=updateData]")));
            Thread.sleep(2000);
            int no_of_hour_containers_selected_after_click=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
            etest.log(Status.INFO,""+no_of_hour_containers_selected_after_click);
            if(no_of_hour_containers_selected_before_click==no_of_hour_containers_selected_after_click)
            {
                return true;
            }    
            return false;

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Business Hours","Exception","Exception",e);
            return false;
        }
    }
	
	public static boolean checkBHTwoDays(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			Tab.navToCompTab(driver);
			Company.toggleBusinessHours(driver,true);
			etest.log(Status.INFO,"Busniess Hours is enabled");
			TakeScreenshot.infoScreenshot(driver,etest);
        	CommonUtil.scrollToBottomOfPage(driver);

			BusinessHours.clearAllBusinessHourConfiguration(driver);
	        BusinessHours.saveBusinessHourSettings(driver,true);
			
			if((selectTwoDays(driver,etest))==true)
			{
				etest.log(Status.PASS,"The grids are merged respective to the day");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"The grids are not merged in correct way.");
				TakeScreenshot.screenshot(driver,etest);
				return false;
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"Exception","Exception",e);
			return false;
		}
	}

	 public static boolean selectTwoDays(WebDriver driver,ExtentTest etest) throws Exception
    {
        try{
        	FluentWait<WebDriver> wait = CommonUtil.waitreturner(driver, 30, 250);
            Long time=System.currentTimeMillis();
            int day=BusinessHours.getDay(time);
            int hour=BusinessHours.getHour(time);

            int beforeclick=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
            
            BusinessHours.setBusinessHour(driver,etest,day,hour);
            BusinessHours.setBusinessHour(driver,etest,day,hour+1);
            BusinessHours.setBusinessHour(driver,etest,day+1,hour);
            BusinessHours.setBusinessHour(driver,etest,day+1,hour+1);
            BusinessHours.saveBusinessHourSettings(driver);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("[onclick*=updateData]")));
			Thread.sleep(1000);            
            int afterclick=driver.findElements(BusinessHours.SELECTION_CONTAINER).size();
            if(beforeclick+2==afterclick)
            {
                return true;
            }
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Business Hours","Exception","Exception",e);
            return false;
        }
    }



}
