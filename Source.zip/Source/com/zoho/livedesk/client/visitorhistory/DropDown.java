//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

public class DropDown
{
    public static boolean checkRuleDDowns(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            CommonFunctions.checkDDown(driver,"viewid-0","favdrpdown0");
            CommonFunctions.checkDDown(driver,"viewid-1","favdrpdown1");
            CommonFunctions.checkDDown(driver,"viewid-2","favdrpdown2");
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking dropdowns in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","DropDown","CheckDrowpDownError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkActionDDowns(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            CommonFunctions.checkDDown(driver,"viewid-0","actiondrpdown0");
            CommonFunctions.checkDDown(driver,"viewid-1","actiondrpdown1");
            CommonFunctions.checkDDown(driver,"viewid-2","actiondrpdown2");
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking dropdowns in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","DropDown","CheckDrowpDownError",e);
            Thread.sleep(1000);
            return false;
        }
    }
}
