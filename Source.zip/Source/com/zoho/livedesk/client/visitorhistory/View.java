//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonSikuli;


import com.google.common.base.Function;

public class View
{
    public static boolean createTemp(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            CommonFunctions.clickAddView(driver);
            CommonFunctions.sendValuesPopUp(driver,"Country","is equal to","India, United States");
            CommonFunctions.applyRule(driver);
            
            if(CommonFunctions.checkAddedRule(driver,"favdrpdown0","India, United States visitors"))
            {
                CommonUtil.elfinder(driver,"id","favdrpdown0").click();
                
                WebElement elmt = CommonUtil.elfinder(driver,"id","favdrpdown0_ddown");
                List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
                
                for(WebElement ell:elmts)
                {
                    if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals("India, United States visitors"))
                    {
                        vhistory.etest.log(Status.FAIL,"Temparory list is listed in dropdown");
                        TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckTempViewError");
                        return false;
                    }
                }

                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Rule is not added");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckTempViewError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating temp view in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckTempViewError",e);
            Thread.sleep(1000);
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean createPermt(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            CommonFunctions.clickAddView(driver);
            CommonFunctions.sendValuesPopUp(driver,"Browser","is equal to","Google Chrome");
            CommonFunctions.setFav(driver,"Chrome Visitors");
            CommonFunctions.applyRule(driver);
            
            if(CommonFunctions.checkAddedRule(driver,"favdrpdown0","Chrome Visitors"))
            {
                CommonUtil.elfinder(driver,"id","favdrpdown0").click();
                
                WebElement elmt = CommonUtil.elfinder(driver,"id","favdrpdown0_ddown");
                List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
                
                for(WebElement ell:elmts)
                {
                    if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals("Chrome Visitors"))
                    {
                        CommonSikuli.findInWholePage(driver,"VHdelete.png","UI280",vhistory.etest);
                        vhistory.etest.log(Status.PASS,"Checked");
                        return true;
                    }
                }
                
                vhistory.etest.log(Status.FAIL,"Permanent list is not listed in dropdown");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckPermanemtViewError");
                return false;
            }
            
            vhistory.etest.log(Status.FAIL,"Rule is not added");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckPermanemtViewError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating temp view in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckPermanemtViewError",e);
            Thread.sleep(1000);
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean checkViews(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            if(CommonFunctions.chooseView(driver,"viewid-0","0")&&CommonFunctions.chooseView(driver,"viewid-1","1")&&CommonFunctions.chooseView(driver,"viewid-2","2"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckViewsError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating temp view in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","View","CheckViewsError",e);
            Thread.sleep(1000);
            return false;
        }
    }
}
