//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class Partition
{
    public static boolean checkPartition(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            if(CommonFunctions.checkPart(driver,"viewid-0","vlstbx","0")&&CommonFunctions.checkPart(driver,"viewid-1","vlstbx","1")&&CommonFunctions.checkPart(driver,"viewid-2","vlstbx","2"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking partitions in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","Partition","CheckPartitionError",e);
            Thread.sleep(1000);
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean partInvi(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            if(CommonFunctions.checkTopVisitor(driver,"viewid-0","0")&&CommonFunctions.checkTopVisitor(driver,"viewid-1","1")&&CommonFunctions.checkTopVisitor(driver,"viewid-2","2"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking partitions in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","Partition","CheckPartitionError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkSendMail(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            if(CommonFunctions.checkMailSend(driver,"viewid-0","0")&&CommonFunctions.checkMailSend(driver,"viewid-1","1")&&CommonFunctions.checkMailSend(driver,"viewid-2","2"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking send mail in partitions in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","Partition","CheckSendMailError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean sendAnEmail(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-0"),"id","actiondrpdown0_div").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("actiondrpdown0_ddown")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","actiondrpdown00");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals(ResourceManager.getRealValue("vhist_mailsend")))
                {
                    CommonUtil.elementfinder(driver,ell,"tagname","span").click();
                    break;
                }
            }
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
            
            CommonUtil.elfinder(driver,"id","toemail").sendKeys("rajkumar.natarajan+automation@zohocorp.com");
            
            CommonUtil.elfinder(driver,"id","savedialog").click();
            
            Tab.waitForLoadingSuccessWithBanner(driver,ResourceManager.getRealValue("vhist_mailsuccess"),"exportvislist.do",vhistory.etest);
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while send email in partitions in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","Partition","CheckEMailError",e);
            Thread.sleep(1000);
            return false;
        }
    }
}
