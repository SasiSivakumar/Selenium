//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.google.common.base.Function;

public class PopUp
{
    public static boolean checkPopUp(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            CommonFunctions.clickAddView(driver);
            CommonFunctions.cancelView(driver);
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking popup in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","PopUp","CheckPopUpError",e);
            Thread.sleep(1000);
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean checkSortList(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            int ck = 0;
            
            Hashtable drpHash = new Hashtable();
            drpHash.put("VISITS",ResourceManager.getRealValue("vhist_visits"));
            drpHash.put("LVTIME",ResourceManager.getRealValue("vhist_lvtime"));
            drpHash.put("SCORE",ResourceManager.getRealValue("vhist_score"));
            drpHash.put("TIMESPENT",ResourceManager.getRealValue("vhist_timespent"));
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            CommonFunctions.clickAddView(driver);
            
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","cmpny_fltr"),"classname","txtelips").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","cmpny_fltr_ddown");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                String expected = (String)drpHash.get(ell.getAttribute("val"));
                String actual = ell.findElement(By.tagName("span")).getText();
                if(expected.equals(actual))
                {
                    ck++;
                }
                else
                {
                    vhistory.etest.log(Status.FAIL,"Expected:"+expected+"--Actual:"+actual+"--");
                }
            }

            if(ck == 4)
            {
                vhistory.etest.log(Status.PASS,"Checked");
                CommonFunctions.cancelView(driver);
                return true;
            }
            
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","CheckSortList","MismatchContent");
            CommonFunctions.cancelView(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking sort list in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","PopUp","CheckSortListError");
            Thread.sleep(1000);
            return false;
        }
    }
}