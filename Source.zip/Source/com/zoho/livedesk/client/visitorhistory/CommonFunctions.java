//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Set;
import java.util.List;
import java.util.Hashtable;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Cookie;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class CommonFunctions
{
    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_vhistory"))));
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_vhistory")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innerheader")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visit_mcontent")));
    }
    
    public static void clickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setting_sm_user")));
    }
    
    public static void clickVisitorsOnline(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_monitor")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visitor_monitor")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
    }
    
    public static boolean checkPart(WebDriver driver,String elId,String elClass,String colNum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(elId)));

        String classname = CommonUtil.elfinder(driver,"id",elId).getAttribute("class");
        String id = CommonUtil.elfinder(driver,"id",elId).getAttribute("col");
        
        if(classname.equals(elClass)&&id.equals(colNum))
        {
            return true;
        }

        vhistory.etest.log(Status.FAIL,"Expected:"+elClass+"--"+colNum+"--Actual:"+classname+"--"+id+"--");
        TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","CheckListContent","MismatchContent");
        return false;
    }
    
    public static void checkDDown(WebDriver driver,String elId,final String drId) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(elId)));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(drId)));
        
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",elId),"id",drId).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(drId+"_div")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(drId+"_ddown")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id(drId+"_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static boolean checkTopVisitor(WebDriver driver,final String elId,String colNum) throws Exception
    {
        try
        {
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
            int ck = 0;
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(elId)));
            
            final String uuid = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",elId),"classname","vlst").getAttribute("uuid");
            
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",elId),"id","name_"+uuid).click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id(elId)).getAttribute("class").contains("removedrplist"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listinfo")));

            String id = CommonUtil.elfinder(driver,"id","listinfo").getAttribute("uuid");
            String col = CommonUtil.elfinder(driver,"id","listinfo").getAttribute("clickedcol");
            
            if(!id.equals(uuid)&&!col.equals(colNum))
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+uuid+"--"+colNum+"--Actual:"+id+"--"+col+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","CheckTopVisitors","MismatchContent");
                return false;
            }
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("listinfo")).findElement(By.id("notes_"+uuid)).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            /*for(int cnum=0;cnum<3;cnum++)
             {
             if(!elId.equals("viewid-"+cnum)&&!((CommonUtil.elfinder(driver,"id","viewid-"+cnum)).getAttribute("class").contains("removedrplist")))
             {
             ck++;
             }
             }
             
             if(ck == 2)
             {
             return true;
             }*/
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking top visitor in visitor history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","CheckVisitor","CheckTopVisitorError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static void initiateChat(WebDriver driver,String vname,String vemail,String vphone,String vques)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
            
            CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();
            
            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");
            
            driver.switchTo().frame(chframe);
            
            CommonUtil.elfinder(driver,"id","name").click();
            CommonUtil.elfinder(driver,"id","name").sendKeys(vname);
            CommonUtil.elfinder(driver,"id","email").click();
            CommonUtil.elfinder(driver,"id","email").sendKeys(vemail);
            CommonUtil.elfinder(driver,"id","phone").click();
            CommonUtil.elfinder(driver,"id","phone").sendKeys(vphone);
            CommonUtil.elfinder(driver,"id","question").click();
            CommonUtil.elfinder(driver,"id","question").sendKeys(vques);
            
            CommonUtil.elfinder(driver,"id","btnaddvisitor").click();
            
            Thread.sleep(2000);
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!(driver.findElement(By.id("waitingform")).getAttribute("style").contains("none")))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Thread.sleep(2000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while initiating chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void acceptChat(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));
            
            Thread.sleep(3000);
            
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","waitinglist"),"id","wpckup").click();
            
            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lschatheader")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("msgtablediv")));
        }
        catch(Exception e)
        {
            System.out.println("Exception while accepting chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void endChat(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonUtil.elfinder(driver,"id","txteditor").sendKeys("Hello there, welcome to testing team ...");
            CommonUtil.elfinder(driver,"id","txteditor").sendKeys(Keys.RETURN);
            
            Thread.sleep(500);
            
            CommonUtil.elfinder(driver,"id","endsession").click();
            
            Thread.sleep(1000);
            
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infodiv")));
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","infodiv"),"linktext",ResourceManager.getRealValue("closewindow")).click();
            
            Thread.sleep(1000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void clickAddView(WebDriver driver) throws Exception
    {
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("createlist")));

        CommonSikuli.findInWholePage(driver,"VHadd.png","UI261",vhistory.etest);

        CommonUtil.elfinder(driver,"id","createlist").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return false;
                }
                return true;
            }
        });
    }
    
    public static void cancelView(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        CommonUtil.elfinder(driver,"xpath","//div[text()='Cancel']").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static void sendValuesPopUp(WebDriver driver,String vrow1,String vrow2,String vrow3) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        CommonUtil.elfinder(driver,"id","prior1_col1_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("prior1_col1_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col1_ddown"),"id","srchtxt"),"tagname","input").click();
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col1_ddown"),"id","srchtxt"),"tagname","input").sendKeys(vrow1);
        
        WebElement elmtr1 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col1_ddown"),"tagname","ul");
        List<WebElement> elmtsr1 = elmtr1.findElements(By.tagName("li"));
        
        /*
         for(WebElement ell1:elmtsr1)
         {
         if(CommonUtil.elementfinder(driver,ell1,"tagname","span").getText().equals(vrow1))
         {
         CommonUtil.elementfinder(driver,ell1,"tagname","span").click();
         }
         }
         */
        
        elmtsr1.get(0).click();
        
        CommonUtil.elfinder(driver,"id","prior1_col2_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("prior1_col2_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmtr2 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col2_ddown"),"tagname","ul");
        List<WebElement> elmtsr2 = elmtr2.findElements(By.tagName("li"));
        
        for(WebElement ell:elmtsr2)
        {
            if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals(vrow2))
            {
                CommonUtil.elementfinder(driver,ell,"tagname","span").click();
            }
        }
        
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col3"),"tagname","input").click();
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col3"),"tagname","input").sendKeys(vrow3);
    }
    
    public static void clickSortList(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmpny_fltr_div")));
        CommonUtil.elfinder(driver,"id","cmpny_fltr_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","cmpny_fltr_ddown"),"tagname","ul");
        List<WebElement> elmts = elmt.findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(ell.findElement(By.tagName("span")).getText().equals(ResourceManager.getRealValue("vhist_lvtime")))
            {
                ell.findElement(By.tagName("span")).click();
                break;
            }
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("cmpny_fltr_div")).findElement(By.tagName("span")).getAttribute("val").equals("LVTIME"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static void applyRule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Apply']")));
        CommonUtil.elfinder(driver,"xpath","//div[text()='Apply']").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static void checkAlert(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            Thread.sleep(1000);

            if(CommonUtil.elfinder(driver,"id","popupdiv").isDisplayed())
            {
               wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                
                CommonUtil.elfinder(driver,"id","okbtn").click();

                Thread.sleep(2000);
            }
        }
        catch(Exception e)
        {}
    }
    
    public static void setFav(WebDriver driver,String favName) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setfav")));
        CommonUtil.elfinder(driver,"id","setfav").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fav_val")));
        CommonUtil.elfinder(driver,"id","fav_val").click();
        CommonUtil.elfinder(driver,"id","fav_val").sendKeys(favName);
    }
    
    public static boolean checkAddedRule(WebDriver driver,String viewId,String ruleAd) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(viewId)));
        
        if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",viewId),"tagname","span").getText().equals(ruleAd))
        {
            return true;
        }
        return false;
    }
    
    public static String getViewID(WebDriver driver,String vname,final String colNum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        Hashtable vIDHash = new Hashtable();
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-"+colNum),"id","favdrpdown"+colNum).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown"+colNum+"_div")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown"+colNum+"_ddown")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("favdrpdown"+colNum+"_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmt = CommonUtil.elfinder(driver,"id","favdrpdown"+colNum+"_ddown");
        List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals(vname))
            {
                return ell.getAttribute("val");
            }
        }
        
        return "View not set Favourite";
    }
    
    public static boolean chooseView(WebDriver driver,String vID,final String colNum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        String curVname = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-"+colNum),"id","favdrpdown"+colNum),"tagname","span").getText();
        
        String curviewID = getViewID(driver,curVname,colNum);
        String chviewID = null;
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-"+colNum),"id","favdrpdown"+colNum).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown"+colNum+"_div")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown"+colNum+"_ddown")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("favdrpdown"+colNum+"_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmt = CommonUtil.elfinder(driver,"id","favdrpdown"+colNum+"_ddown");
        List<WebElement> elmts = elmt.findElement(By.tagName("ul")).findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(!CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals(curVname))
            {
                chviewID = ell.getAttribute("val");
                CommonUtil.elementfinder(driver,ell,"tagname","span").click();
                break;
            }
        }
        
//        wait.until(new Function<WebDriver,Boolean>(){
//            public Boolean apply(WebDriver driver)
//            {
//                if(driver.findElement(By.id("favdrpdown"+colNum+"_ddown")).getAttribute("style").contains("none"))
//                {
//                    return true;
//                }
//                return false;
//            }
//        });
        Thread.sleep(500);
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        
        if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-"+colNum),"id","favdrpdown"+colNum),"tagname","span").getText().equals(curVname))
        {
            vhistory.etest.log(Status.FAIL,"List name is not changed for column - "+colNum);
            return false;
        }
        
        curVname = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-"+colNum),"id","favdrpdown"+colNum),"tagname","span").getText();
        
        if(chviewID.equals(getViewID(driver,curVname,colNum)))
        {
            return true;
        }
        
        vhistory.etest.log(Status.FAIL,"Mismatch view id for column - "+colNum);
        return false;
    }
    
    public static void clickVisitorInfoTab(WebDriver driver,final String vinfoID) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.className("speedometer")).findElement(By.cssSelector("div.pointer.sqico-needle")).getAttribute("style").contains("transform"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(vinfoID)));
        
        //CommonUtil.elfinder(driver,"id",vinfoID).click();
        
        WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","listinfo"),"classname","vlsthd");
        List<WebElement> elmts = elmt.findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(ell.getAttribute("purpose").equals(vinfoID))
            {
                ell.click();
                break;
            }
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id(vinfoID)).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        Thread.sleep(500);
    }
    
    public static void clickAndWaitForVisInfo(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        checkTopVisitor(driver,"viewid-0","0");
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listinfo")));
    }
    
    public static void waitForInfoTab(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        clickAndWaitForVisInfo(driver);
        
        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vst_interest")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("vst_interest")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static void waitForInfoTabMod(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        setRuleEmail(driver);
        checkAlert(driver);
        checkTopVisitor(driver,"viewid-0","0");
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listinfo")));
        
        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vst_interest")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("vst_interest")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
    }
    
    public static void setRuleEmail(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        clickAddView(driver);
        sendValuesPopUp(driver,"Email Address","contains","raja123");
        clickSortList(driver);
        applyRule(driver);
    }
    
    public static boolean checkMailSend(WebDriver driver,String vID,final String colNum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",vID),"id","actiondrpdown"+colNum+"_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("actiondrpdown"+colNum+"_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmt = CommonUtil.elfinder(driver,"id","actiondrpdown"+colNum+"0");
        List<WebElement> elmts = elmt.findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals(ResourceManager.getRealValue("vhist_mailsend")))
            {
                CommonUtil.elementfinder(driver,ell,"tagname","span").click();
                break;
            }
        }
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));

        String actual = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"classname","modal-header").getText();
        
        if(!actual.contains(ResourceManager.getRealValue("vhist_emailsend")))
        {
            vhistory.etest.log(Status.FAIL,"Mismatch content for column "+colNum+" Expected:"+ResourceManager.getRealValue("vhist_emailsend")+"--Actual:"+actual+"--");
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"xpath","//div[text()='Cancel']").click();
            return false;
        }
        
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","dlgbox"),"xpath","//div[text()='Cancel']").click();
        return true;
    }
    
    public static String verifyVisitor(WebDriver driver,WebDriver visdriver,String portalname) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        String visitorId = VisitorWindow.getVisitorId(visdriver,portalname);

        final String uvid = visitorId;

        VisitorsOnline.waitTillVisitorPresent(driver,uvid);

        String uuid = (((JavascriptExecutor) driver).executeScript("return UTSHandler.visitors[\""+uvid+"\"].data[\"uuid\"];")).toString();
        
        return uuid;
    }
    
    public static void setToAllVis(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            clickSettings(driver);
            clickVisitorHistory(driver);
            
            driver.navigate().refresh();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("viewid-0")));
            
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","favdrpdown0"),"tagname","span").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0_div")));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("favdrpdown0_ddown")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","favdrpdown0_ddown");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                if(ell.findElement(By.tagName("span")).getText().equals("All Visitors"))
                {
                    ell.findElement(By.tagName("span")).click();
                    break;
                }
            }
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("viewid-0")).getAttribute("viewid").equals("-1"))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            System.out.println("Exception while setting view to all visitors in visitor history tab");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitoryHistory","CommonFunctions","SetViewAllVisitorsError",e);
        }
    }
}
