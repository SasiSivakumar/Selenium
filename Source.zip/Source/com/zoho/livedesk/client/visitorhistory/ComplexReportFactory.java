//$Id$
package com.zoho.livedesk.client.visitorhistory;

public class ComplexReportFactory extends com.zoho.livedesk.client.ComplexReportFactory
{

}
