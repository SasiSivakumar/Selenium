//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Set;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;

public class VisitorSite
{
    public static WebDriver openVis(WebDriver driver,String portalname) throws InterruptedException, IOException
    {
        try
        {
            VisitorWindow.createPage(driver,portalname,portalname);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating visitor page in visitor history module : ");
            TakeScreenshot.screenshot(driver,Util.buildlabel(),"VisitorPage","CreatePageError");
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return driver;
    }
    
    public static WebDriver openRefVis(WebDriver driver,String referrer,String portalname) throws IOException, InterruptedException
    {
        try
        {
            VisitorWindow.createPageReferrer(driver,portalname,portalname,referrer);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,Util.buildlabel(),"VisitorPage","ReferrerPageError");
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return driver;
    }
    
    public static WebDriver createCampaign(WebDriver driver,String cname,String portalname) throws IOException, InterruptedException
    {
        try
        {
            VisitorWindow.createPageCampaign(driver,portalname,portalname,cname);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating campaign visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,Util.buildlabel(),"VisitorPage","CampaignPageError");
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return driver;
    }
    
    public static WebDriver createReferralPage(WebDriver driver,String portalname) throws InterruptedException, IOException
    {
        try
        {
            VisitorWindow.createPageReferrer(driver,portalname,portalname);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,Util.buildlabel(),"VisitorPage","ReferralPageError");
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return driver;
    }
    
    public static WebDriver setUp() throws InterruptedException
    {
        try
        {
            return Functions.setUp();
        }
        catch(Exception e)
        {
            System.out.println("Exception while setting up webdriver in visitor history module : ");
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return null;
    }
}
