//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.google.common.base.Function;

public class VisitorEvent
{
    public static boolean backButton(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            if(singleView(driver,"viewid-0","0")&&singleView(driver,"viewid-1","1")&&singleView(driver,"viewid-2","2"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking back button in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckBackButtonError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean singleView(WebDriver driver,final String elID,String colNum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        CommonFunctions.clickSettings(driver);
        CommonFunctions.clickVisitorHistory(driver);

        com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("hdrdrpdwntop")));
        com.zoho.livedesk.util.common.CommonWait.waitTillDisplayed(driver,By.id("hdrdrpdwn"));
        String mute = driver.findElement(By.id("soundplayer")).findElement(By.tagName("em")).getAttribute("class");
        if (mute.contains("sqico-sound_off"))
        {
            com.zoho.livedesk.util.common.CommonSikuli.findInWholePage(driver,"VImute.png","UI277",vhistory.etest);
            com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,By.id("soundplayer"),By.tagName("em"));
        }
        else
        {
            com.zoho.livedesk.util.common.CommonSikuli.findInWholePage(driver,"VIunmute.png","UI278",vhistory.etest);
            com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,By.id("soundplayer"),By.tagName("em"));
        }

        if(CommonFunctions.checkTopVisitor(driver,elID,colNum))
        {
            WebElement backArrow = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",elID),"classname","arrwbck");
            wait.until(ExpectedConditions.visibilityOf(backArrow));
            com.zoho.livedesk.util.common.CommonUtil.sleep(500);

            CommonSikuli.findInWholePage(driver,"VHbackbutton.png","UI265",vhistory.etest);

            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",elID),"classname","arrwbck").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id(elID)).getAttribute("class").contains("removedrplist"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            return true;
        }
        
        return false;
    }
    
    public static boolean checkInfoTabs(WebDriver driver,String infoID,String infoName) throws InterruptedException, IOException
    {
        try
        {
            if(infoTabs(driver,"viewid-0","0",infoID,infoName)&&infoTabs(driver,"viewid-1","1",infoID,infoName)&&infoTabs(driver,"viewid-2","2",infoID,infoName))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckInfoTabError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor info tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckInfoTabError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean infoTabs(WebDriver driver,String viewID,String colNum,String infoID,String infoName) throws Exception
    {
        CommonFunctions.clickSettings(driver);
        CommonFunctions.clickVisitorHistory(driver);
        CommonFunctions.checkTopVisitor(driver,viewID,colNum);
        CommonFunctions.clickVisitorInfoTab(driver,infoID);
        
        // try
        // {
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","listinfo"),"classname","vlsthd");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                if(ell.getText().equals(infoName))
                {
                    String classname = ell.getAttribute("class");
                    if(classname.equals("bdr_sel"))
                    {
                        driver.findElement(By.id(infoID)).findElement(By.tagName("div"));
                        return true;
                    }
                    else
                    {
                        vhistory.etest.log(Status.FAIL,"Mismatch ClassName for "+infoName+".Expected:bdr_sel--Actual:"+classname+"--");
                    }
                }
            }
            
            vhistory.etest.log(Status.FAIL,infoName+" is not present");
            return false;
        // }
        // catch(Exception e)
        // {
        //     return false;
        // }
    }
    
    public static boolean checkNotes(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            if(notesTab(driver,"viewid-0","0")&&notesTab(driver,"viewid-1","1")&&notesTab(driver,"viewid-2","2"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckNotesError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking notes tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckNotesError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean notesTab(WebDriver driver,String viewID,String colNum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        CommonFunctions.clickSettings(driver);
        CommonFunctions.clickVisitorHistory(driver);
        CommonFunctions.checkTopVisitor(driver,viewID,colNum);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listinfo")));
        
        String uuid = CommonUtil.elfinder(driver,"id","listinfo").getAttribute("uuid");
        
        final WebElement elmt = CommonUtil.elfinder(driver,"id","notes_"+uuid);

        final String note = ResourceManager.getRealValue("shortcut_notes");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(note.equals(elmt.findElement(By.className("vlsthd")).getText()))
                {
                    return true;
                }
                return false;
            }
        });
        
        CommonUtil.elfinder(driver,"id","note_editor").sendKeys("Note Added");
        CommonUtil.elfinder(driver,"id","vstaddnotes").click();
        
        driver.findElement(By.id("vstactdata"));
        
        return true;
    }
    
    public static boolean checkOpp(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickAndWaitForVisInfo(driver);
            
            String uuid = CommonUtil.elfinder(driver,"id","listinfo").getAttribute("uuid");
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vstcrmdet"),"tagname","ul"),"tagname","li");
            List<WebElement> elmts = elmt.findElements(By.tagName("div"));
            
            String percent = elmts.get(2).getText();
            String opp = elmts.get(3).getText();
            String cname = elmts.get(0).getAttribute("class");
            
            if(cname.equals("speedometer")&&opp.equals(ResourceManager.getRealValue("vhist_opportunity"))&&percent.matches("[0-9]?[0-9].[0-9][1-9]%$"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Expected:speedometer--"+ResourceManager.getRealValue("vhist_opportunity")+"--[0-9]?[0-9].[0-9][1-9]%$--Actual:"+cname+"--"+opp+"--"+percent+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckOppError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking opportunity in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckOppError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkLeadScore(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickAndWaitForVisInfo(driver);
            
            Thread.sleep(1000);
            
            String uuid = CommonUtil.elfinder(driver,"id","listinfo").getAttribute("uuid");
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vstcrmdet"),"tagname","ul").findElements(By.tagName("li")).get(1);
            List<WebElement> elmts = elmt.findElements(By.className("vstinfotemp"));
            
            String lstext = elmts.get(0).findElement(By.tagName("span")).getText();
            String lsval = elmts.get(0).findElement(By.tagName("em")).getText();
            String vistytext = elmts.get(1).findElement(By.tagName("span")).getText();
            String vistype = elmts.get(1).findElement(By.tagName("em")).getText();
            Thread.sleep(1000);
            CommonSikuli.findInWholePage(driver,"speedometer.png","UI309",vhistory.etest);

            
            if(lstext.equals(ResourceManager.getRealValue("vhist_leadscore"))&&lsval.matches("[0-9]+")&&vistytext.equals(ResourceManager.getRealValue("vhist_vistype"))&&(vistype.equals("New")||vistype.equals("Returning")||vistype.equals("Lead")||vistype.equals("Contact")))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_leadscore")+"--"+ResourceManager.getRealValue("vhist_vistype")+"--New or Returning or Lead or Contact--Actual:"+lstext+"--a number--"+lsval+"--"+vistytext+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckLSError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking lead score in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckLSError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkPastAction(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickAndWaitForVisInfo(driver);
            
            Thread.sleep(1000);
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","vstpastaction");
            List<WebElement> elmts = elmt.findElements(By.className("vstinfotemp"));
            
            String vsinceval = elmts.get(0).getText().replace("\n"," ");
            String visitsval = elmts.get(1).getText().replace("\n"," ");
            String lastvival = elmts.get(2).getText().replace("\n"," ");
            
            System.out.println("<><><><><><>"+vsinceval+"<><><><><><>"+visitsval+"<><><><><><>"+lastvival+"<><><><><><>");
            if(vsinceval.matches("Visitor Since [ADFJMNOS][a-z][a-z], 20[0-9]{2} via [A-Z a-z]*")&&visitsval.matches("No[.] of Visits [0-9]+")&&lastvival.contains(ResourceManager.getRealValue("vhist_lastvisited"))&&!(lastvival.contains("null")&&lastvival.contains("undefined")))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Expected:Visitor Since [ADFJMNOS][a-z][a-z], 20[0-9]{2} via [A-Z a-z]*(Regex)--No[.] of Visits [0-9]+(Regex)--"+ResourceManager.getRealValue("vhist_lastvisited")+"--not contains null or undefined--Actual:"+vsinceval+"--"+visitsval+"--"+lastvival+"--"+lastvival+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckPastActionError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking past action in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckPastActionError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkBCRM(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.clickAndWaitForVisInfo(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lstintst")));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("lstintst")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","lstintst"),"classname","vsttabs");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));

            String actual1 = elmts.get(0).getAttribute("purpose");
            String actual2 = elmts.get(1).getAttribute("purpose");
            
            if(!(actual1.equals("vst_interest")&&actual2.equals("vst_crminfo")))
            {
                vhistory.etest.log(Status.FAIL,"Expected:vst_interest--vst_crminfo--Actual:"+actual1+"--"+actual2+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckTabsError");
                return false;
            }
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vst_interest")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vst_crminfo")));
            
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking behaviour and crm tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckTabsError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkActv(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.waitForInfoTab(driver);
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_interest"),"id","vst_range");
            List<WebElement> elmts = elmt.findElements(By.tagName("em"));
            
            if(elmt.getText().contains(ResourceManager.getRealValue("Activities for"))&&elmts.get(0).getText().equals(ResourceManager.getRealValue("vhist_curweek"))&&elmts.get(1).getText().equals(ResourceManager.getRealValue("vhist_curmonth")))
            {
                CommonSikuli.findInWholePage(driver,"VHcalender.png","UI267",vhistory.etest);
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Expected:vst_interest--"+ResourceManager.getRealValue("Activities for")+"--"+ResourceManager.getRealValue("vhist_curweek")+"--"+ResourceManager.getRealValue("vhist_curmonth")+"--Actual:"+elmt.getText()+"--"+elmts.get(0).getText()+"--"+elmts.get(1).getText()+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckActvError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking activities options in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckActvError",e);
            Thread.sleep(1000);
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean checkVisits(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            String sources = "$Campaigns$AdWords$Social Media$Search Engine$Referral$Direct";
            String via = "";
            
            int chk = 0;
            
            //CommonFunctions.waitForInfoTab(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            WebElement ringelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_interest"),"classname","rngvst");

            String actual1 = CommonUtil.elementfinder(driver,ringelmt,"classname","grytxt").getText();
            
            if(!actual1.equals(ResourceManager.getRealValue("vhist_Visits")))
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_Visits")+"--Actual:"+actual1+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisitsError");
                return false;
            }

            CommonSikuli.findInWholePage(driver,"VHdirecttimespent.png","UI262",vhistory.etest);
            CommonSikuli.findInWholePage(driver,"VHdirectlastvisit.png","UI263",vhistory.etest);
            CommonSikuli.findInWholePage(driver,"VHdirecttraffic.png","UI264",vhistory.etest);
            CommonSikuli.findInWholePage(driver,"VHshare.png","UI279",vhistory.etest);
            
            WebElement frelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_interest"),"classname","rngsrc");
            List<WebElement> elmts = frelmt.findElements(By.className("vstinfotemp"));

            String header1 = elmts.get(0).findElement(By.className("grytxt")).getText();
            String header2 = elmts.get(1).findElement(By.className("grytxt")).getText();
            
            if(header1.equals(ResourceManager.getRealValue("vhist_frequency"))&&header2.equals(ResourceManager.getRealValue("vhist_vsource")))
            {
                CommonSikuli.findInWholePage(driver,"VHcampaigns.png","UI268",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHadWords.png","UI269",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHsocialmedia.png","UI270",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHdirect.png","UI271",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHsearchengine.png","UI272",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHreferral.png","UI273",vhistory.etest);

                String freq = elmts.get(0).getText();
                if(freq.contains("Monthly")||freq.contains("Weekly")||freq.contains("Rarely")||freq.contains("Daily"))
                {
                    List<WebElement> selmts = elmts.get(1).findElements(By.tagName("span"));
                    
                    for(int i=1;i<7;i++)
                    {
                        String actual2 = selmts.get(i).getAttribute("title");

                        System.out.println("<<<<<<"+actual2+">>>>>>"+sources+">>>>>>");
                        
                        if(sources.contains(selmts.get(i).getAttribute("title")))
                        {
                            sources = sources.replace("$"+selmts.get(i).getAttribute("title"),"");
                            chk++;
                        }
                        else if(selmts.get(i).getAttribute("title").contains("via"))
                        {
                            via = actual2;
                        }
                        else
                        {
                            vhistory.etest.log(Status.FAIL,"Expected:"+sources+"(contains any one of these)--Actual:"+actual2+"--");
                        }
                    }
                }
                else
                {
                    vhistory.etest.log(Status.FAIL,"Expected:"+"Monthly Weekly Rarely Daily"+"(contains any one of these)--Actual:"+freq+"--");
                }
            }
            else
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_frequency")+"--"+ResourceManager.getRealValue("vhist_vsource")+"--Actual:"+header1+"--"+header2+"--");
            }
            
            sources =sources.replace("$","");
            
            if(via.contains(sources))
            {
                chk++;
            }
            else
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+sources+"(contains any one of these)--Actual:"+via+"--");
            }
            
            if(chk == 6)
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            else
            {
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisitsError");
                return false;  
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visits in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisitsError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkPages(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.waitForInfoTab(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            String tp = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_interest"),"classname","br_chart").getText();
            String rm = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_interest"),"classname","lsttble").getText();
            
            System.out.println("<<<<<<<"+tp+"><<<<><><>"+rm+">>>>>>>>>");
            
            tp = tp.replace(rm,"");
            tp = tp.replace("\n","");
            
            System.out.println("<<<<<<<<<"+tp+">>>>>>>>>>");
            
            if(!tp.equals(ResourceManager.getRealValue("vhist_toppages")))
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_toppages")+"--Actual:"+tp+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckPagesError");
                return false;
            }
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_interest"),"classname","lsttble");
            
            CommonUtil.JSScroll(driver,elmt);
            
            List<WebElement> elmts = elmt.findElements(By.className("tbl-row"));
            
            List<WebElement> hdrelmt = elmts.get(0).findElements(By.tagName("div"));
            
            System.out.println("<<<<<<<<<"+hdrelmt.get(0).getText()+"<><><>"+hdrelmt.get(1).getText()+"<><><><><>"+hdrelmt.get(2).getText()+">>>>>>>>>>>");

            String actual1 = hdrelmt.get(0).getText();
            String actual2 = hdrelmt.get(1).getText();
            String actual3 = hdrelmt.get(2).getText();
            
            if(!(actual1.equals(ResourceManager.getRealValue("vhist_pages")))&&!(actual2.equals(ResourceManager.getRealValue("vhist_Visits")))&&!(actual3.equals(ResourceManager.getRealValue("vhist_time"))))
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_pages")+"--"+ResourceManager.getRealValue("vhist_Visits")+"--"+ResourceManager.getRealValue("vhist_time")+"--Actual:"+actual1+"--"+actual2+"--"+actual3+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckPagesError");
                return false;
            }
            
            List<WebElement> ftrelmt = elmts.get(1).findElements(By.tagName("div"));
            
            System.out.println("<<<<<<"+ftrelmt.get(0).findElement(By.tagName("a")).getText()+"<><><><<>"+ftrelmt.get(1).getAttribute("class")+"<><><><><><"+ftrelmt.get(2).getText()+">>>>");

            actual1 = ftrelmt.get(0).findElement(By.tagName("a")).getText();
            actual2 = ftrelmt.get(1).getAttribute("class");
            actual3 = ftrelmt.get(2).getText();

            if(actual1!=null&&actual1!=""&&actual2.equals("barline")&&actual3!=null&&!actual3.contains("undefined")&&actual3!="")
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Expected: not null or undefined or empty--barline--not null or undefined empty--Actual:"+actual1+"--"+actual2+"--"+actual3+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckPagesError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking pages in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckPagesError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisitsInfo(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.clickAndWaitForVisInfo(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            infoTabs(driver,"viewid-0","0","visits_info_div","Visits");
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","listinfo"),"id","visits_info_div"),"classname","vists_row");
            List<WebElement> elmts = elmt.findElements(By.className("vists_col"));

            String actual1 = elmts.get(0).getAttribute("class");
            String actual2 = elmts.get(1).getAttribute("class");
            String actual3 = elmts.get(1).getAttribute("title");
            String actual4 = elmts.get(2).getAttribute("class");
            String actual5 = elmts.get(2).getAttribute("title");
            
            if(actual1.contains("lpage")&&actual2.contains("tme_spent")&&actual3.contains("Time spent")&&actual4.contains("lstvst")&&actual5.contains("Visited on"))
            {
                CommonSikuli.findInWholePage(driver,"VHlastpage.png","UI274",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHtimespent.png","UI275",vhistory.etest);
                CommonSikuli.findInWholePage(driver,"VHlastvisit.png","UI276",vhistory.etest);

                actual1 = elmts.get(0).getText();
                actual2 = elmts.get(1).getText();
                actual3 = elmts.get(2).getText();
                
                if(!(actual1.contains("undefined")||actual1.equals(""))&&actual1!=null&&!(actual2.contains("undefined")||actual2.equals(""))&&actual2!=null&&!(actual3.contains("undefined")||actual3.equals(""))&&actual3!=null)
                {
                    vhistory.etest.log(Status.PASS,"Checked");
                    return true;
                }
                else
                {
                    vhistory.etest.log(Status.FAIL,"Expected: not null or undefined or empty for all--Actual:"+actual1+"--"+actual2+"--"+actual3+"--");
                }
            }
            else
            {
                vhistory.etest.log(Status.FAIL,"Expected:lpage--tme_spent--Time spent--lstvst--Visited on--Actual:"+actual1+"--"+actual2+"--"+actual3+"--"+actual4+"--"+actual5+"--");
            }

            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisInfoTabError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visits info in visits tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisInfoTabError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisitDet(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.clickAndWaitForVisInfo(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            infoTabs(driver,"viewid-0","0","visits_info_div","Visits");
            Thread.sleep(1000);
            
            final WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visits_info_div"),"classname","vists_details");
            
            CommonUtil.elementfinder(driver,elmt,"classname","vists_col").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(elmt.findElement(By.className("clearfix")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement lelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visits_info_div"),"classname","vists_details"),"classname","clearfix");
            List<WebElement> elmts = lelmt.findElements(By.tagName("ul"));

            String actual1 = elmts.get(0).findElement(By.tagName("li")).getText();
            String actual2 = elmts.get(1).findElement(By.tagName("li")).getText();
            String actual3 = elmts.get(2).findElement(By.tagName("li")).getText();
            
            if(!(actual1.equals(ResourceManager.getRealValue("vhist_pageaccs"))&&actual2.equals(ResourceManager.getRealValue("vhist_maxtime"))&&actual3.equals(ResourceManager.getRealValue("vhist_vissource"))))
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_pageaccs")+"--"+ResourceManager.getRealValue("vhist_maxtime")+"--"+ResourceManager.getRealValue("vhist_vissource")+"--Actual:"+actual1+"--"+actual2+"--"+actual3+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisDetError");
                return false;
            }
            
            if(!(elmts.get(0).findElement(By.className("vists_col")).getText().matches("[0-9]+")&&!elmts.get(1).findElement(By.className("vists_col")).getText().contains("undefined"))||elmts.get(1).findElement(By.className("vists_col")).getText().equals(": "))
            {
                actual1 = elmts.get(2).findElement(By.className("vists_col")).getText();

                if(actual1.contains("undefined")||actual1.equals(": "))
                {
                    vhistory.etest.log(Status.FAIL,"Expected:not undefined or : --Actual"+actual1+"--");
                    TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisDetError");
                    return false;
                }
            }
            actual1 = CommonUtil.elfinder(driver,"id","vst_moreinfo").getText();
            
            if(actual1.contains(ResourceManager.getRealValue("vhist_moreinfo")))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            else
            {
                vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_moreinfo")+"--Actual"+actual1+"--");
                TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisDetError");
            }
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visits details in visits tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckVisDetError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkMoreAction(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.clickAndWaitForVisInfo(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            infoTabs(driver,"viewid-0","0","visits_info_div","Visits");
            
            final WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visits_info_div"),"classname","vists_details");
            
            CommonUtil.elementfinder(driver,elmt,"classname","vists_col").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(elmt.findElement(By.className("clearfix")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("vst_moreinfo")));
            CommonUtil.elementfinder(driver,elmt,"id","vst_moreinfo").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("actions_div")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","actions_div"),"tagname","div");
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking more navigation in visits tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckMoreError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkActions(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickAndWaitForVisInfo(driver);
            
            infoTabs(driver,"viewid-0","0","actions_div","Actions");
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","actions_div"),"classname","vst_act");
            List<WebElement> elmts = elmt.findElements(By.tagName("div"));
            
            if(elmts.size()>=2)
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Visitor Actions missing");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckActionsError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking navigation in Actions tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckActionsError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkChatConv(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.clickAndWaitForVisInfo(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            infoTabs(driver,"viewid-0","0","actions_div","Actions");
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","actions_div"),"classname","vst_act");
            List<WebElement> elmts = elmt.findElements(By.className("actionitem"));
            
            for(WebElement ell:elmts)
            {
                if(ell.getText().equals(ResourceManager.getRealValue("vhist_chatini")))
                {
                    ell.click();
                    break;
                }
            }
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@id,'chat_LD_')]//*[contains(@class,'vlsthd')]")));
            Thread.sleep(1000);
            
            String actual1 = CommonUtil.elfinder(driver,"xpath","//div[contains(@id,'chat_LD_')]//*[contains(@class,'vlsthd')]").getText();

            System.out.println("<<<<<<<<"+actual1+">>>>>>>>");
            
            if(actual1.contains(ResourceManager.getRealValue("vhist_chattrans")))
            {
                // try
                // {
                    driver.findElement(By.xpath("//div[contains(@id,'chat_LD_')]")).findElement(By.id("msgques"));
                    vhistory.etest.log(Status.PASS,"Checked");
                    return true;
                // }
                // catch(Exception e)
                // {
                //     return false;
                // }
            }
            
            vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_chattrans")+"--Actual:"+actual1+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckChatError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking chat conversation in Actions tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckChatError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkCRMInfo(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            //CommonFunctions.clickAndWaitForVisInfo(driver);
            CommonFunctions.waitForInfoTabMod(driver);
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lstintst")));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("lstintst")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","lstintst"),"classname","vsttabs");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));
            
            for(WebElement ell:elmts)
            {
                if(ell.findElement(By.tagName("span")).getText().equals(ResourceManager.getRealValue("vhist_crminfo")))
                {
                    ell.findElement(By.tagName("span")).click();
                }
            }
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vst_crminfo")));
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("vst_crminfo")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            /*
            if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vst_crminfo"),"classname","vstinfotemp"),"tagname","span").getAttribute("title").contains(ResourceManager.getRealValue("vhist_owner")))
            {
                return true;
            }
            
            return false;*/
            vhistory.etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking crm info in visitor info tab in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorEvent","CheckCRMInfoError",e);
            Thread.sleep(1000);
            return false;
        }
    }
}
