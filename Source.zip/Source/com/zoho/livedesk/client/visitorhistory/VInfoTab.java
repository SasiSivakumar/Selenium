//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.google.common.base.Function;
import com.zoho.livedesk.util.common.CommonSikuli;


public class VInfoTab
{
    public static boolean basicInfo(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            int chk = 0;
            
            /*CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            CommonFunctions.checkTopVisitor(driver,"viewid-0","0");*/
            
            CommonFunctions.waitForInfoTabMod(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vstbasicdet")));
            
            // --- get the uuid of the top visitor
            // --- wait until the details of that uuid appears
            // --- and then
            Thread.sleep(1000);
            
            //WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vstbasicdet"),"classname","vstdetails");
            List<WebElement> elmts = driver.findElements(By.xpath("//*[@id='vstbasicdet']//*[contains(@class,'vstdetails')]//*[contains(@class,'txtelips')]"));
            
            for(WebElement ell:elmts)
            {
                System.out.println(">>>>><><><><><><<><>>><<<<<<"+ell.getText()+">>>>><><><><><><<><>>><");
                if(ell.getText()!=null&&!ell.getText().equals("undefined")&&!ell.getText().equals(""))
                {
                    chk++;
                }
                else
                {
                    vhistory.etest.log(Status.FAIL,"--"+ell.getText()+"-- is not expected[Not null,undefined or empty]");
                }
            }
            
            if(chk == 3)
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorInfo","CheckBasicInfoError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking basic info in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorInfo","CheckBasicInfoError",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean sendMailButton(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.waitForInfoTabMod(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vstbasicdet")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("vstsndmail")));

            CommonSikuli.findInWholePage(driver,"VHsendmail.png","UI266",vhistory.etest);
            
            String actual = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vstbasicdet"),"id","vstsndmail").getAttribute("title");
            String actual2 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vstbasicdet"),"id","vstsndmail").getAttribute("class");
            
            if(actual.equals(ResourceManager.getRealValue("vhist_sendmail")) && actual2.equals("sqico-mail"))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }

            vhistory.etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("vhist_sendmail")+"--Actual:"+actual+"--");
            vhistory.etest.log(Status.FAIL,"Expected:sqico-mail--Actual:"+actual2+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorInfo","CheckSendMailError");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while send mail button visibility in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorInfo","CheckSendMailError",e);
            Thread.sleep(1000);
            return false;
        }
    }
}
