//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.TakeScreenshot;
import com.google.common.base.Function;

public class VisitorSource
{
    //public static WebDriver visDriver = null;
    public static Hashtable<String,Long> time = new Hashtable();
    public static Hashtable<String,String> visitorid = new Hashtable();
    public static Hashtable<String,String> portal = new Hashtable();
    public static Hashtable<String,String> searchby = new Hashtable();
    public static Hashtable<String,String> tobe = new Hashtable();
    
    public static void visitorEnd(WebDriver driver,WebDriver visDriver,String source,String rfrl,String referrer,String portalname,String usecase) throws InterruptedException, IOException
    {
        String uuid = "";
            
        try
        {
            Functions.loadSiteAndWaitForRSID(driver,portalname);
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            
                if(source.equals("Direct"))
                {
                    visDriver = VisitorSite.openVis(visDriver,portalname);
                    CommonFunctions.clickVisitorsOnline(driver);
                    uuid = CommonFunctions.verifyVisitor(driver,visDriver,portalname);
                }
                else if(source.equals("Campaign"))
                {
                    visDriver = VisitorSite.createCampaign(visDriver,referrer,portalname);
                    CommonFunctions.clickVisitorsOnline(driver);
                    uuid = CommonFunctions.verifyVisitor(driver,visDriver,portalname);
                }
                else if(source.equals("Referral"))
                {
                    visDriver = VisitorSite.createReferralPage(visDriver,portalname);
                    CommonFunctions.clickVisitorsOnline(driver);
                    uuid = CommonFunctions.verifyVisitor(driver,visDriver,portalname);
                }
                else
                {
                    visDriver = VisitorSite.openRefVis(visDriver,rfrl,portalname);
                    CommonFunctions.clickVisitorsOnline(driver);
                    uuid = CommonFunctions.verifyVisitor(driver,visDriver,portalname);
                }
            
            time.put(usecase,System.currentTimeMillis());
            visitorid.put(usecase,uuid);
            portal.put(usecase,portalname);
            searchby.put(usecase,source);
            tobe.put(usecase,referrer);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor source in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorSource","Check"+source+"Error",e);
            visitorid.put(usecase,"Error");
        }
    }

    public static boolean checkSource(WebDriver driver,WebDriver visDriver,String usecase) throws InterruptedException, IOException
    {
        if(visitorid.get(usecase).equals("Error"))
        {
            return false;
        }
        try
        {
            wait(usecase);

            String portalname = portal.get(usecase);
            String source = searchby.get(usecase);
            String referrer = tobe.get(usecase);

            Functions.loadSiteAndWaitForRSID(driver,portalname);
            
            String uuid = visitorid.get(usecase);
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonFunctions.clickSettings(driver);
            CommonFunctions.clickVisitorHistory(driver);
            CommonFunctions.clickAddView(driver);
            CommonFunctions.sendValuesPopUp(driver,"Last Visit Source","is equal to",source);
            CommonFunctions.clickSortList(driver);
            CommonFunctions.applyRule(driver);
            CommonFunctions.checkAlert(driver);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("viewid-0")).findElement(By.className("vlstcnt")).getText().contains(ResourceManager.getRealValue("vhist_listloading")))
                    {
                        return false;
                    }
                    return true;
                }
            });
            
            CommonFunctions.checkTopVisitor(driver,"viewid-0","0");

            String actual = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","viewid-0"),"classname","vlst"),"classname","lsseng"),"classname","txtelips").getText();
            
            System.out.println("<<<<<<<<<<<<<<<<<<<"+actual+">>>>>>>>>>>> Expected : "+referrer+">>>>>>>>>");

            if(actual.equals(referrer))
            {
                vhistory.etest.log(Status.PASS,"Checked");
                return true;
            }
            
            vhistory.etest.log(Status.FAIL,"Expected"+referrer+"--Actual:"+actual+"--");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorSource",referrer+"MismatchContent");
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor source in visitory history module : ");
            TakeScreenshot.screenshot(driver,vhistory.etest,"VisitorHistory","VisitorSource","CheckSourceError",e);
            Thread.sleep(1000);
            return false;
        }
    }

    public static void wait(String usecase) throws Exception
    {
          int i = 1; 
          while(true)
          {
                if(System.currentTimeMillis()>(time.get(usecase)+250000))
                      break;

                Thread.sleep(500);

                if(i++ >=500)
                      break;
          }

          System.out.println("Waited for "+usecase+":"+i*0.5);
    }
}
