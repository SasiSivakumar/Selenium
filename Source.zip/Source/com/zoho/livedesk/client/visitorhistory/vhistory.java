//$Id$
package com.zoho.livedesk.client.visitorhistory;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;

public class vhistory
{
    private static Hashtable result = new Hashtable();
    private static Hashtable hashtable = new Hashtable();
    private static Hashtable servicedown = new Hashtable();
    public static WebDriver VisDriver = null;
    public static String portalname = "visitorhistory";
    public static WebDriver visDriver = null;
    public static Hashtable<String,ExtentTest> extenttest = new Hashtable<String,ExtentTest>();
    
    public static ExtentTest etest;
    
    public static Hashtable vistHistory(WebDriver driver) throws IOException, InterruptedException
    {
        try
        {
            result = new Hashtable();
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            driver.navigate().refresh();
            Thread.sleep(5000);
            
            CommonFunctions.clickVisitorHistory(driver);
            result.put("VH1",true);
            
            etest.log(Status.PASS,"Visitor History tab available");
            
            ComplexReportFactory.closeTest(etest);

            driver.navigate().refresh();

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH14"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH14",VisitorEvent.checkInfoTabs(driver,"visitor_info_div","Visitor Info"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH15"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH15",VisitorEvent.checkInfoTabs(driver,"visits_info_div","Visits"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH16"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH16",VisitorEvent.checkInfoTabs(driver,"actions_div","Actions"));
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH12"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH12",View.checkViews(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH2"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH2",Partition.checkPartition(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH3"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH3",DropDown.checkRuleDDowns(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH4"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH4",Partition.partInvi(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            /* ---- Ignored ---- */
            
            /*VisDriver = VisitorSite.openIVis(driver,VisDriver,"Tester15","anand.ramachandran+2211@zohocorp.com","9967875476");
             result.put("VH5",VisitorBasic.checkVname(driver));
             VisDriver = VisitorSite.openVis();
             VisDriver.quit();
             result.put("VH6",VisitorBasic.checkVIP(driver));
             */
            
            etest = ComplexReportFactory.getTest("Visitor History - Check visitor");
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            initiateChat(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH7"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH7",DropDown.checkActionDDowns(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH8"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH8",PopUp.checkPopUp(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH9"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH9",PopUp.checkSortList(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH10"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH10",View.createTemp(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH11"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH11",View.createPermt(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH13"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH13",VisitorEvent.backButton(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH17"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH17",VisitorEvent.checkNotes(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = startTest("VH18");
            visDriver = VisitorSite.setUp();
            VisitorSource.visitorEnd(driver,visDriver,"Direct","","Direct",portalname+"1","VH18");

            etest = startTest("VH19");
            VisitorSource.visitorEnd(driver,visDriver,"Search Engine","http://www.google.com","Google",portalname+"2","VH19");

            etest = startTest("VH20");
            VisitorSource.visitorEnd(driver,visDriver,"Search Engine","http://www.yahoo.com","Yahoo",portalname+"3","VH20");

            etest = startTest("VH21");
            VisitorSource.visitorEnd(driver,visDriver,"Search Engine","http://www.bing.com","Bing",portalname+"4","VH21");

            etest = startTest("VH22");
            VisitorSource.visitorEnd(driver,visDriver,"Search Engine","http://www.baidu.com","Baidu",portalname+"5","VH22");

            etest = startTest("VH23");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.facebook.com","Facebook",portalname+"6","VH23");

            etest = startTest("VH24");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.twitter.com","Twitter",portalname+"7","VH24");

            etest = startTest("VH25");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.linkedin.com","LinkedIn",portalname+"8","VH25");
            
            visDriver.quit();
            visDriver = VisitorSite.setUp();

            etest = continueTest("VH18");

            result.put("VH18",VisitorSource.checkSource(driver,visDriver,"VH18"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH19");
            
            result.put("VH19",VisitorSource.checkSource(driver,visDriver,"VH19"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH20");
            
            result.put("VH20",VisitorSource.checkSource(driver,visDriver,"VH20"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH21");
            
            result.put("VH21",VisitorSource.checkSource(driver,visDriver,"VH21"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH22");
            
            result.put("VH22",VisitorSource.checkSource(driver,visDriver,"VH22"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH23");
            
            result.put("VH23",VisitorSource.checkSource(driver,visDriver,"VH23"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH24");
            
            result.put("VH24",VisitorSource.checkSource(driver,visDriver,"VH24"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH25");
            
            result.put("VH25",VisitorSource.checkSource(driver,visDriver,"VH25"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = startTest("VH26");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.pinterest.com","Pinterest",portalname+"1","VH26");
            
            etest = startTest("VH27");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.tumblr.com","Tumblr",portalname+"2","VH27");

            etest = startTest("VH28");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.reddit.com","reddit",portalname+"3","VH28");

            etest = startTest("VH29");
            VisitorSource.visitorEnd(driver,visDriver,"Social Media","http://www.youtube.com","YouTube",portalname+"4","VH29");

            etest = startTest("VH30");
            VisitorSource.visitorEnd(driver,visDriver,"Campaign","","salesiq testing",portalname+"5","VH30");

            etest = startTest("VH31");
            VisitorSource.visitorEnd(driver,visDriver,"Referral","","Referral",portalname+"6","VH31");
            visDriver.quit();

            etest = continueTest("VH26");
            
            result.put("VH26",VisitorSource.checkSource(driver,visDriver,"VH26"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH27");
            
            result.put("VH27",VisitorSource.checkSource(driver,visDriver,"VH27"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH28");
            
            result.put("VH28",VisitorSource.checkSource(driver,visDriver,"VH28"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH29");
            
            result.put("VH29",VisitorSource.checkSource(driver,visDriver,"VH29"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH30");
            
            result.put("VH30",VisitorSource.checkSource(driver,visDriver,"VH30"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = continueTest("VH31");
            
            result.put("VH31",VisitorSource.checkSource(driver,visDriver,"VH31"));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH32"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            driver.get(Util.siteNameout());
            CommonFunctions.setToAllVis(driver);
            
            result.put("VH32",VInfoTab.basicInfo(driver));
            CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH33"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH33",VInfoTab.sendMailButton(driver));
            CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH36"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH36",VisitorEvent.checkOpp(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH37"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH37",VisitorEvent.checkLeadScore(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH38"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH38",VisitorEvent.checkPastAction(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH39"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH39",VisitorEvent.checkBCRM(driver));
            CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH40"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH40",VisitorEvent.checkActv(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH41"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH41",VisitorEvent.checkVisits(driver));
            CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH42"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH42",VisitorEvent.checkPages(driver));
            CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH43"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH43",VisitorEvent.checkCRMInfo(driver));
            CommonFunctions.setToAllVis(driver);
            
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH45"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH45",VisitorEvent.checkVisitsInfo(driver));
	        CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH47"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH47",VisitorEvent.checkVisitDet(driver));
	        CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH48"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH48",VisitorEvent.checkMoreAction(driver));
	        CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH49"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH49",VisitorEvent.checkActions(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH50"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH50",VisitorEvent.checkChatConv(driver));
 	        CommonFunctions.setToAllVis(driver);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH51"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH51",Partition.checkSendMail(driver));
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("VH52"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor History");
            
            result.put("VH52",Partition.sendAnEmail(driver));

            ComplexReportFactory.closeTest(etest);
        }
        catch(Exception e)
        {
            result.put("VH1",false);
            etest.log(Status.FATAL,"Error occurred while trying to Click visitor history : "+e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("Exception while checking tab in visitor history module : ");
            TakeScreenshot.screenshot(driver,etest,"VisitorHistory","VHError","Error",e);
        }
        
        ComplexReportFactory.closeTest(etest);
        
        hashtable.put("result",result);
        hashtable.put("servicedown",servicedown);
        return hashtable;
    }

    public static ExtentTest continueTest(String usecase) throws Exception
    {
      return extenttest.get(usecase);
    }

    public static ExtentTest startTest(String usecase) throws Exception
    {
      ExtentTest test = ComplexReportFactory.getTest(KeyManager.getRealValue(usecase));
      ComplexReportFactory.setValues(test,"Automation","Visitor History");
      extenttest.put(usecase,test);
      return extenttest.get(usecase);
    }

    public static void initiateChat(WebDriver driver) throws Exception
    {
      initiateChat(driver,"embed2","automation4");
    }

    public static void initiateChat(WebDriver driver,String embed,String portal) throws Exception
    {
      WebDriver visDriver = null;
      try
      {
            visDriver = Functions.setUp();
          
            String visitorid = null;

            String widgetCode = null;

            try
            {
                  widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
                  VisitorWindow.createPage(visDriver,widgetCode);
                  VisitorWindow.initiateChatVisTheme(visDriver,null,"rajka@raja123.com",null,"there ?",etest);
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(visDriver,etest,"VisitorHistory","VHError","Error",e);
                  return;
            }
          
            try
            {
                ChatWindow.acceptChat(driver,etest);
                // ChatWindow.endChat(driver);
                // ChatWindow.clickClosethisWindow(driver);
                ChatWindow.closeAllChats(driver);
                
                visitorid = VisitorWindow.getVisitorId(visDriver,portal);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorHistory","VHError","Error",e);
            }
          
            visDriver.get("https://www.zoho.com/");

            VisitorsOnline.waitTillVisitorLeaves(driver, visitorid);

            Thread.sleep(3000);

            String id = "";

            try
            {
                  widgetCode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
                  VisitorWindow.createPage(visDriver,widgetCode);
                  id = VisitorWindow.getVisitorId(visDriver,portal);
            }
            catch(Exception e)
            {
                  TakeScreenshot.screenshot(driver,etest,"VisitorHistory","VHError","Error",e);
                  return;
            }

            VisitorsOnline.waitTillVisitorPresent(driver,id);

            driver.findElement(By.id("name_"+id+"")).click();
            Thread.sleep(1000);
            CommonSikuli.findInWholePage(driver,"VOspeedometer.png","UI310",vhistory.etest);
            // Actions action = new Actions(driver);
            // action.sendKeys(Keys.ESCAPE).perform();
            CannedMessagesCommonFunctions.sendEscapeKeyToTilesUIChat(driver,id);

            Thread.sleep(3000);

            visDriver.quit();
      }
      catch(Exception e)
      {
            TakeScreenshot.screenshot(driver,etest,"VisitorHistory","VHError","Error",e);
            visDriver.quit();
      }
    }

}
