//$Id$
package com.zoho.livedesk.client.EmbedConfigTheme;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.DistributedTest;

public class TestInitTheme implements DistributedTest
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
    public static VisitorDriverManager visitor_driver_manager;
    public static String value = null;

    public void startThread(int thread_number) throws Exception
    {
        //to do seperate the test accordingly

        WebDriver driver = Functions.setUp();

        if(thread_number==0)
        {           
            Functions.login(driver,"embed_config_theme1");
            ExtentTest etest=null;
            usecase1(driver,etest);
        }

        if(thread_number==1)
        {           
            Functions.login(driver,"embed_config_theme2");
            ExtentTest etest=null;
            usecase2(driver,etest);
        }

        if(thread_number==2)
        {           
            Functions.login(driver,"embed_config_theme3");
            ExtentTest etest=null;
            usecase3(driver,etest);
        }

        String portal=ExecuteStatements.getPortal(driver);
        visitor_driver_manager.closeAllDrivers(portal);

        Functions.logout(driver);   
    }

    public static void usecase1(WebDriver driver,ExtentTest etest) throws Exception
    {
        try
        {
            etest=ComplexReportFactory.getTest("Check Custom message - Float - Online and Offline");
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckECT.setCustomMessage(driver,value,151,"float",etest);
            // CheckECT.setCustomMessage(driver,value,null,"button");

            ComplexReportFactory.closeTest(etest);


            checkFloatTheme(driver,value,etest);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorUser(s)Tab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","usecase1","Error",e); 
        }

    }

    public static void usecase2(WebDriver driver,ExtentTest etest) throws Exception
    {
        try
        {
            checkSize(driver,etest);

            etest=ComplexReportFactory.getTest("Check Custom message - Button - Online and Offline");
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckECT.setCustomMessage(driver,value,155,"button",etest);
            // CheckECT.setCustomMessage(driver,value,null,"float");
            
            ComplexReportFactory.closeTest(etest);

            checkButtonTheme(driver,value,etest);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorUser(s)Tab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","usecase2","Error",e); 
        }
    }

    public static void usecase3(WebDriver driver,ExtentTest etest) throws Exception
    {
        WebDriver driver2 = null;
        WebDriver driver3 = null;

        try
        {
            etest=ComplexReportFactory.getTest("Check Custom message - Personalized - Online and Offline");
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            driver2 = Functions.setUp();
            driver3 = Functions.setUp();
            
            if(!Functions.login(driver2,"embed_config_theme3_admin2") || !Functions.login(driver3,"embed_config_theme3_admin3"))
            {
                result.put("EC1", false);
                ComplexReportFactory.closeTest(etest);
                
                // hashtable.put("result", result);
                // hashtable.put("servicedown", servicedown);
                // return hashtable;

                Driver.quitDriver(driver2);
                Driver.quitDriver(driver3);            

                return;
            }
            
            String portal=ExecuteStatements.getPortal(driver);
            driver2.get(Util.siteNameout()+"/"+portal+"/");                        
            driver3.get(Util.siteNameout()+"/"+portal+"/");                        
            Functions.closeBannersAfterLogin(driver2);
            Functions.closeBannersAfterLogin(driver3);

            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"busy",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","ChangeStatus","Error",e);
                throw e;
            }
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver3,"busy",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","ChangeStatus","Error",e);
                throw e;
            }
            
            CheckECT.setCustomMessage(driver,value,159,"personalized",etest);
            
            ComplexReportFactory.closeTest(etest);

            checkPersonalizedTheme(driver,value,driver2,driver3,etest);

            ComplexReportFactory.closeTest(etest);

            Functions.logout(driver2);
            Functions.logout(driver3);
        }

        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorUser(s)Tab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","usecase3","Error",e);
            TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","usecase3","Error",e); 
            TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","usecase3","Error",e); 
        }
    }

	public static Hashtable usecase() throws Exception
	{         
        value = (""+System.currentTimeMillis()).substring(4, 10);

        while(value.length() < 2)
        {
            value = (""+System.currentTimeMillis()).substring(4, 10);
        }
        
        visitor_driver_manager = new VisitorDriverManager();

        TestInitTheme usecases = new TestInitTheme();

        Distributor distributor = new Distributor(usecases,3);

        distributor.initiate();
               
        visitor_driver_manager.terminateAllDriverSessions();

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);

		return hashtable;
	}

    public static void checkFloatTheme(WebDriver driver, String value,ExtentTest etest) throws Exception
    {
        String[] themes = {"3","4","5","6","7","8","9","10","11","1"};
//        String[] themes = {"1"};
        
        int usecaseStart = 301;
        
        int i = usecaseStart;
        
        for(String s : themes)
        {
            etest=ComplexReportFactory.getTest("Check Float Theme - "+Websites.floatThemeName[Integer.parseInt(s)]);
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckECT.checkFloatTheme(driver,s,value,i,etest);
            
            ComplexReportFactory.closeTest(etest);
            
            i = i+10;
        }
    }
    
    public static void checkButtonTheme(WebDriver driver, String value,ExtentTest etest) throws Exception
    {
        String[] themes = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14"};
//        String[] themes = {"1"};
        
        int usecaseStart = 401;
        
        int i = usecaseStart;
        
        for(String s : themes)
        {
            etest=ComplexReportFactory.getTest("Check Button Theme - "+Websites.buttonThemeName[Integer.parseInt(s)]);
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckECT.checkButtonTheme(driver,s,value,i,etest);
            
            ComplexReportFactory.closeTest(etest);
            
            i = i+10;
        }
    }
    
    public static void checkPersonalizedTheme(WebDriver driver, String value, WebDriver driver2, WebDriver driver3,ExtentTest etest) throws Exception
    {
        String[] themes = {"1","2","3"};
//        String[] themes = {"1"};
        
        int usecaseStart = 701;
        
        int i = usecaseStart;
        
        for(String s : themes)
        {
            etest=ComplexReportFactory.getTest("Check Personalized Theme - "+Websites.personalizedThemeName[Integer.parseInt(s)]);
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckECT.checkPersonalizedTheme(driver,s,value,i,driver2,driver3,etest);
            
            ComplexReportFactory.closeTest(etest);
            
            i = i+20;
        }
    }
    
    public static void checkSize(WebDriver driver,ExtentTest etest) throws Exception
    {
        String[] themes = {"2","3"};
        
        int usecaseStart = 801;
        
        int i = usecaseStart;
        
        for(String s : themes)
        {
            etest=ComplexReportFactory.getTest("Check Size - "+Websites.sizeName[Integer.parseInt(s)]);
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckECT.checkSize(driver,s,Websites.sizeValue[Integer.parseInt(s)],i,etest);
            
            ComplexReportFactory.closeTest(etest);
            
            i = i+2;
        }
    }
}
