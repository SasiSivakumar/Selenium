//$Id$
package com.zoho.livedesk.client.EmbedConfigTheme;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;

public class CheckECT
{
    public static void setCustomMessage(WebDriver driver, String t, Integer usecase, String div,ExtentTest etest) throws Exception
    {
        if(usecase!=null)
        {
            if(div.equals("personalized"))
            {
                TestInitTheme.result.put("EC"+usecase,false);
                TestInitTheme.result.put("EC"+(usecase+2),false);
            }
            else
            {
                for(int i = usecase;i<=(usecase+3);i++)
                {
                    TestInitTheme.result.put("EC"+i,false);
                }
            }            
        }

        
        try
        {
            String embed=ExecuteStatements.getDefaultEmbedName(driver);

            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            if(div.equals("float"))
            {
                WebsitesTab.clickFloatWidget(driver,etest);Thread.sleep(5000);
                
                WebsitesTab.clickContentFloat(driver,etest);
            }
            else if(div.equals("button"))
            {
                WebsitesTab.clickButtonWidget(driver,etest);Thread.sleep(5000);
                
                WebsitesTab.clickContentButton(driver,etest);
            }
            else if(div.equals("personalized"))
            {
                WebsitesTab.clickPersonalizedWidget(driver,etest);Thread.sleep(5000);
                
                WebsitesTab.clickContentPersonalized(driver,etest);
            }
            
            WebsitesTab.changePreviewWindowStatus(driver,true,etest);
            
            Websites.editCustomizeMessageInWidgetTab(driver,true,"online","ON1"+t,etest);
            
            if(!div.equals("personalized"))
            {
                Websites.editCustomizeMessageInWidgetTab(driver,true,"online_byline","ON2"+t,etest);
            }
            
            WebsitesTab.changePreviewWindowStatus(driver,false,etest);
            
            Websites.editCustomizeMessageInWidgetTab(driver,false,"offline","OF1"+t,etest);
            
            if(!div.equals("personalized"))
            {
                Websites.editCustomizeMessageInWidgetTab(driver,false,"offline_byline","OF2"+t,etest);
            }
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            if(usecase==null)
            {
                //No need to check if it no test case id is given.
                return;
            }

            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            if(div.equals("float"))
            {
                WebsitesTab.clickFloatWidget(driver,etest);
                
                WebsitesTab.clickContentFloat(driver,etest);
            }
            else if(div.equals("button"))
            {
                WebsitesTab.clickButtonWidget(driver,etest);
                
                WebsitesTab.clickContentButton(driver,etest);
            }
            else if(div.equals("personalized"))
            {
                WebsitesTab.clickPersonalizedWidget(driver,etest);
                
                WebsitesTab.clickContentPersonalized(driver,etest);
            }
            
            String on1 = Websites.getCustomizeMessageInWidgetTab(driver,true,"online",etest);
            
            if(!on1.equals("ON1"+t))
            {
                etest.log(Status.FAIL,"<>"+on1+"<>"+"ON1"+t+"<>");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","SetCustomMessage","Error");
            }
            else
            {
                TestInitTheme.result.put("EC"+(usecase),true);
                etest.log(Status.INFO,"Custom online message - checked");
            }
            
            if(!div.equals("personalized"))
            {
                String on2 = Websites.getCustomizeMessageInWidgetTab(driver,true,"online_byline",etest);
            
                if(!on2.equals("ON2"+t))
                {
                    etest.log(Status.FAIL,"<>"+on2+"<>"+"ON2"+t+"<>");
                    TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","SetCustomMessage","Error");
                }
                else
                {
                    TestInitTheme.result.put("EC"+(usecase+1),true);
                    etest.log(Status.INFO,"Custom online message - checked");
                }
            }
            
            String of1 = Websites.getCustomizeMessageInWidgetTab(driver,false,"offline",etest);
            
            if(!of1.equals("OF1"+t))
            {
                etest.log(Status.FAIL,"<>"+of1+"<>"+"OF1"+t+"<>");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","SetCustomMessage","Error");
            }
            else
            {
                TestInitTheme.result.put("EC"+(usecase+2),true);
                etest.log(Status.INFO,"Custom offline message - checked");
            }
            
            if(!div.equals("personalized"))
            {
                String of2 = Websites.getCustomizeMessageInWidgetTab(driver,false,"offline_byline",etest);
                
                if(!of2.equals("OF2"+t))
                {
                    etest.log(Status.FAIL,"<>"+of2+"<>"+"OF2"+t+"<>");
                    TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","SetCustomMessage","Error");
                }
                else
                {
                    TestInitTheme.result.put("EC"+(usecase+3),true);
                    etest.log(Status.INFO,"Custom offline message - checked");
                }
            }
            
            WebsitesTab.closeEmbedConfig(driver,etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","SetCustomMessage","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }

    public static void checkFloatTheme(WebDriver driver, String theme, String value, int usecase,ExtentTest etest) throws Exception
    {
        for(int i = usecase;i<=(usecase+6);i++)
        {
            TestInitTheme.result.put("EC"+i,false);
        }
        
        try
        {
            String embed=ExecuteStatements.getDefaultEmbedName(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);Thread.sleep(2000);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickFloatWidget(driver,etest);
            
            WebElement themeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_stickers");
            
            Websites.selectTheme(driver,themeDiv,theme,etest);
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            final String headerText = Websites.floatThemeName[Integer.parseInt(theme)];
            
            final WebElement header = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","themeid_header");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickFloatWidget(driver,etest);
            
            final WebElement header2 = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","themeid_header");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header2.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            TestInitTheme.result.put("EC"+(usecase),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            Long t = new Long(System.currentTimeMillis());
            
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                final WebElement div = CommonUtil.elfinder(visDriver,"classname","zsiq_theme"+theme);
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(div.getText().contains("zsiq_float"))
                        {
                            return false;
                        }
                        return true;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+1),true);
                
                boolean checkOff = VisitorWindow.checkChatWidgetOffline(visDriver);
                
                if(checkOff)
                {
                    etest.log(Status.FAIL,"Float is offline");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error");
                    return;
                }
                
                String line1 = VisitorWindow.getLine1InFloat(visDriver);
                
                if(!line1.equals("ON1"+value))
                {
                    etest.log(Status.FAIL,"Expected:ON1"+value+"--Actual:"+line1+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error");
                    return;
                }
                
                if(!(theme.equals("8") || theme.equals("11")))
                {
                    String line2 = VisitorWindow.getLine2InFloat(visDriver);
                    
                    if(!line2.equals("ON2"+value))
                    {
                        etest.log(Status.FAIL,"Expected:ON2"+value+"--Actual:"+line2+"<>");
                        TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error");
                        return;
                    }
                }
                
                TestInitTheme.result.put("EC"+(usecase+2),true);
                
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Check1",0);
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error",e);
                return;
            }
            
            ChatWindow.acceptChat(driver,etest);
            
            try
            {
                VisitorWindow.checkWaitingDivNotPresent(visDriver);
                
                VisitorWindow.checkVisitorMessageInChatWindow(visDriver,true,"V"+t,"Q"+t,1);
                
                Thread.sleep(1000);
                
                VisitorWindow.sentMessageInTheme(visDriver,"hey!!!");
                
                VisitorWindow.checkVisitorMessageInChatWindow(visDriver,false,null,"hey!!!",2);
                
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","CheckMessage",0);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error",e);
                return;
            }
            
            ChatWindow.getLastMessageInUserWindow(driver,"hey!!!");
            
            try
            {
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Check2",0);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error",e);
                return;
            }
            
            ChatWindow.sentMessage(driver,"1");
            ChatWindow.sentMessage(driver,"2");
            
            etest.log(Status.INFO,"2 Messages are sent");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFloatTheme","Before",0);
            
            try
            {
                visDriver.switchTo().defaultContent();
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,20,250);
                
                waitV.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_unreadcnt")));
                waitV.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_unreadcnt")));
                
                final WebElement count = CommonUtil.elfinder(visDriver,"id","zsiq_unreadcnt");
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(count.getText().equals("2"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+3),true);
                
                VisitorWindow.clickChatButton(visDriver);
                
                Thread.sleep(500);
                
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                waitV.until(ExpectedConditions.not(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_unreadcnt"))));
                
                TestInitTheme.result.put("EC"+(usecase+4),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error",e);
                return;
            }
            
            ChatWindow.endAndCloseChat(driver);
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy",etest);Thread.sleep(2000);
            
            etest.log(Status.INFO,"Status changed to busy");
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                final WebElement div = CommonUtil.elfinder(visDriver,"classname","zsiq_theme"+theme);
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(div.getText().contains("zsiq_float"))
                        {
                            return false;
                        }
                        return true;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+5),true);
                
                if(!theme.equals("11"))
                {
                    boolean checkOff = VisitorWindow.checkChatWidgetOffline(visDriver);
                    
                    if(!checkOff)
                    {
                        etest.log(Status.FAIL,"Float is online");
                        TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error");
                    }
                }
                
                String line1 = VisitorWindow.getLine1InFloat(visDriver);
                
                if(!line1.equals("OF1"+value))
                {
                    etest.log(Status.FAIL,"Expected:OF1"+value+"--Actual:"+line1+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error");
                    return;
                }
                
                if(!(theme.equals("8") || theme.equals("11")))
                {
                    String line2 = VisitorWindow.getLine2InFloat(visDriver);
                    
                    if(!line2.equals("OF2"+value))
                    {
                        etest.log(Status.FAIL,"Expected:OF2"+value+"--Actual:"+line2+"<>");
                        TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error");
                        return;
                    }
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFloatTheme","Error",e);
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+6),true);
            
            etest.log(Status.INFO,"Checked");
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFloatTheme","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }
    
    public static void checkButtonTheme(WebDriver driver, String theme, String value, int usecase,ExtentTest etest) throws Exception
    {
        for(int i = usecase;i<=(usecase+8);i++)
        {
            TestInitTheme.result.put("EC"+i,false);
        }
        
        try
        {
            String embed=ExecuteStatements.getDefaultEmbedName(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);


            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);Thread.sleep(2000);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickButtonWidget(driver,etest);
            
            WebElement themeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_stickers");
            
            Websites.selectTheme(driver,themeDiv,theme,etest);
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            final String headerText = Websites.buttonThemeName[Integer.parseInt(theme)];
            
            final WebElement header = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","themeid_header");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickButtonWidget(driver,etest);
            
            final WebElement header2 = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","themeid_header");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header2.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            TestInitTheme.result.put("EC"+(usecase),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            Long t = new Long(System.currentTimeMillis());
            
            try
            {
                VisitorWindow.createPageForButton(visDriver,embedcode);
                
                final WebElement div = CommonUtil.elfinder(visDriver,"classname","zsiq_float"+theme);
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(div.getText().contains("siqbtndiv"))
                        {
                            return false;
                        }
                        return true;
                    }
                });
                
                waitV.until(ExpectedConditions.presenceOfElementLocated(By.id("siqbtndiv")));
                waitV.until(ExpectedConditions.visibilityOfElementLocated(By.id("siqbtndiv")));
                
                TestInitTheme.result.put("EC"+(usecase+1),true);
                
                String line1 = VisitorWindow.getLine1InButton(visDriver);
                
                if(!line1.equals("ON1"+value))
                {
                    etest.log(Status.FAIL,"Expected:ON1"+value+"--Actual:"+line1+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error");
                    return;
                }
                
                String line2 = VisitorWindow.getLine2InButton(visDriver);
                
                if(!line2.equals("ON2"+value))
                {
                    etest.log(Status.FAIL,"Expected:ON2"+value+"--Actual:"+line2+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+2),true);
                
                VisitorWindow.clickChatButton(visDriver);
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                Boolean minPresence = VisitorWindow.buttonMinimizedDiv(visDriver);
                
                if(minPresence)
                {
                    etest.log(Status.FAIL,"Button - minimize div is present");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error");
                }
                else
                {
                    TestInitTheme.result.put("EC"+(usecase+7),true);
                }
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error",e);
                return;
            }
            
            ChatWindow.acceptChat(driver,etest);
            
            try
            {
                VisitorWindow.checkWaitingDivNotPresent(visDriver);
                
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                VisitorWindow.clickChatButton(visDriver);
                
                VisitorWindow.checkVisitorMessageInChatWindow(visDriver,true,"V"+t,"Q"+t,1);
                
                Thread.sleep(1000);
                
                VisitorWindow.sentMessageInTheme(visDriver,"hey!!!");
                
                VisitorWindow.checkVisitorMessageInChatWindow(visDriver,false,null,"hey!!!",2);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error",e);
                return;
            }
            
            ChatWindow.getLastMessageInUserWindow(driver,"hey!!!");
            
            try
            {
                VisitorWindow.clickCloseChatWidget(visDriver);

                Boolean minPresence = VisitorWindow.buttonMinimizedDiv(visDriver);
                
                if(!minPresence)
                {
                    etest.log(Status.FAIL,"Button - minimize div is not present");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error");
                }
                else
                {
                    TestInitTheme.result.put("EC"+(usecase+8),true);
                }
                
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Check1",0);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error",e);
                return;
            }
            
            ChatWindow.sentMessage(driver,"1");
            ChatWindow.sentMessage(driver,"2");
            
            etest.log(Status.INFO,"2 Messages are sent");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckButtonTheme","Before",0);
            
            try
            {
                visDriver.switchTo().defaultContent();
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,20,250);
                
                waitV.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_unreadcnt")));
                waitV.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_unreadcnt")));
                
                final WebElement count = CommonUtil.elfinder(visDriver,"id","zsiq_unreadcnt");
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(count.getText().equals("2"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+3),true);
                
                VisitorWindow.clickChatButton(visDriver);
                
                Thread.sleep(500);
                
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                waitV.until(ExpectedConditions.not(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_unreadcnt"))));
                
                TestInitTheme.result.put("EC"+(usecase+4),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error",e);
                return;
            }
            
            ChatWindow.endAndCloseChat(driver);
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy",etest);Thread.sleep(2000);
            
            etest.log(Status.INFO,"Status changed to busy");
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPageForButton(visDriver,embedcode);
                
                final WebElement div = CommonUtil.elfinder(visDriver,"classname","zsiq_float"+theme);
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(div.getText().contains("siqbtndiv"))
                        {
                            return false;
                        }
                        return true;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+5),true);
                
                String line1 = VisitorWindow.getLine1InButton(visDriver);
                
                if(!line1.equals("OF1"+value))
                {
                    etest.log(Status.FAIL,"Expected:OF1"+value+"--Actual:"+line1+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error");
                    return;
                }
                
                String line2 = VisitorWindow.getLine2InButton(visDriver);
                
                if(!line2.equals("OF2"+value))
                {
                    etest.log(Status.FAIL,"Expected:OF2"+value+"--Actual:"+line2+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckButtonTheme","Error",e);
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+6),true);
            
            etest.log(Status.INFO,"Checked");
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckButtonTheme","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }
    
    public static void checkPersonalizedTheme(WebDriver driver, final String theme, String value, int usecase, WebDriver driver2, WebDriver driver3,ExtentTest etest) throws Exception
    {
        for(int i = usecase;i<=(usecase+8);i++)
        {
            TestInitTheme.result.put("EC"+i,false);
        }
        
        String username=ExecuteStatements.getUserName(driver);
        String username2=ExecuteStatements.getUserName(driver2);
        String username3=ExecuteStatements.getUserName(driver3);

        try
        {
            String embed=ExecuteStatements.getDefaultEmbedName(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);


            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);Thread.sleep(2000);
            
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"busy",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver3,"busy",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            WebElement themeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_stickers");
            
            Websites.selectTheme(driver,themeDiv,theme,etest);
            
            final String headerText = Websites.personalizedThemeName[Integer.parseInt(theme)];
            
            final WebElement header = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","themeid_header");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            final WebElement header2 = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"id","themeid_header");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header2.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            TestInitTheme.result.put("EC"+(usecase),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            Long t = new Long(System.currentTimeMillis());
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);
                
                final WebElement div = CommonUtil.elfinder(visDriver,"id","zsiqpersonalize");
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(div.getAttribute("class").contains("zsiq_personalizetheme"+theme))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+1),true);
                
                String line1 = VisitorWindow.getContentInPersonalizedStartChat(visDriver);
                
                if(!line1.equals("ON1"+value))
                {
                    etest.log(Status.FAIL,"Expected:ON1"+value+"--Actual:"+line1+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                List<WebElement> list = VisitorWindow.getPersonalizedAgentList(visDriver);
             
                if(list.size() != 1)
                {
                    etest.log(Status.FAIL,"Only 1 agent div is expected");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+2),true);
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            ChatWindow.acceptChat(driver,etest);
            
            try
            {
                VisitorWindow.checkWaitingDivNotPresent(visDriver);
                
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                VisitorWindow.clickChatButton(visDriver);
                
                VisitorWindow.checkVisitorMessageInChatWindow(visDriver,true,"V"+t,"Q"+t,1);
                
                Thread.sleep(1000);
                
                VisitorWindow.sentMessageInTheme(visDriver,"hey!!!");
                
                VisitorWindow.checkVisitorMessageInChatWindow(visDriver,false,null,"hey!!!",2);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            ChatWindow.getLastMessageInUserWindow(driver,"hey!!!");
            
            try
            {
                VisitorWindow.clickCloseChatWidget(visDriver);

                Boolean minPresence = VisitorWindow.buttonMinimizedDiv(visDriver);
                
                if(!minPresence)
                {
                    etest.log(Status.FAIL,"Button - minimize div is not present");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                }
                else
                {
                    TestInitTheme.result.put("EC"+(usecase+7),true);
                }
                
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Check1",0);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            ChatWindow.sentMessage(driver,"1");
            ChatWindow.sentMessage(driver,"2");
            
            etest.log(Status.INFO,"2 Messages are sent");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Before",0);
            
            try
            {
                visDriver.switchTo().defaultContent();
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,20,250);
                
                waitV.until(ExpectedConditions.presenceOfElementLocated(By.id("zsiq_unreadcnt")));
                waitV.until(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_unreadcnt")));
                
                final WebElement count = CommonUtil.elfinder(visDriver,"id","zsiq_unreadcnt");
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(count.getText().equals("2"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+3),true);
                
                VisitorWindow.clickChatButton(visDriver);
                
                Thread.sleep(500);
                
                VisitorWindow.clickCloseChatWidget(visDriver);
                
                waitV.until(ExpectedConditions.not(ExpectedConditions.visibilityOfElementLocated(By.id("zsiq_unreadcnt"))));
                
                TestInitTheme.result.put("EC"+(usecase+4),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            ChatWindow.endAndCloseChat(driver);
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy",etest);Thread.sleep(2000);
            
            etest.log(Status.INFO,"Status changed to busy");
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);
                
                final WebElement div = CommonUtil.elfinder(visDriver,"id","zsiqpersonalize");
                
                FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(div.getAttribute("class").contains("zsiq_personalizetheme"+theme))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                final WebElement img = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(visDriver,div,"xpath",".//div[@index='0']"),"tagname","img");
                
                waitV.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(img.getAttribute("class").contains("zsiq_grayscale"))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+5),true);
                
                String line1 = VisitorWindow.getContentInPersonalizedStartChat(visDriver);
                
                if(!line1.equals("OF1"+value))
                {
                    etest.log(Status.FAIL,"Expected:OF1"+value+"--Actual:"+line1+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+6),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            Websites.selectFromDropdown(driver,"emconfig_usercount","2 Operators",etest);
            
            Websites.clickSave(driver,etest,false);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            String actual = Websites.getValueFromDropdown(driver,"emconfig_usercount");
            
            if(!actual.equals("2 Operators"))
            {
                etest.log(Status.FAIL,"Expected:2 Operators-Actual:"+actual+"--");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+8),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available",etest);Thread.sleep(2000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);

                if(!checkAgent(visDriver,username,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                if(!checkAgent(visDriver,username2,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                if(checkAgent(visDriver,username3,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                List<WebElement> list = VisitorWindow.getPersonalizedAgentList(visDriver);
                
                if(list.size() != 2)
                {
                    etest.log(Status.FAIL,"Only 2 agents div is expected");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+9),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver3,"available",etest);Thread.sleep(2000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);
                
                if(!checkAgent(visDriver,username,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                if(!checkAgent(visDriver,username2,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                if(!checkAgent(visDriver,username3,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                List<WebElement> list = VisitorWindow.getPersonalizedAgentList(visDriver);
                
                if(list.size() != 2)
                {
                    etest.log(Status.FAIL,"Only 2 agents div is expected");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+10),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            Websites.selectFromDropdown(driver,"emconfig_usercount","3 Operators",etest);
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            actual = Websites.getValueFromDropdown(driver,"emconfig_usercount");
            
            if(!actual.equals("3 Operators"))
            {
                etest.log(Status.FAIL,"Expected:2 Operators-Actual:"+actual+"--");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+11),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);
                
                if(!checkAgent(visDriver,username,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                if(!checkAgent(visDriver,username2,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                if(!checkAgent(visDriver,username3,etest))
                {
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                List<WebElement> list = VisitorWindow.getPersonalizedAgentList(visDriver);
                
                if(list.size() != 3)
                {
                    etest.log(Status.FAIL,"Only 3 agents div is expected");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+12),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            Long t2 = new Long(System.currentTimeMillis());
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);
                
                String ind = VisitorWindow.getPersonalizedAgentDiv(visDriver,username).getAttribute("index");
                int index = Integer.parseInt(ind);
                
                etest.log(Status.INFO,"Index for agent "+username+" is "+index);
                
                VisitorWindow.clickChatButtonInPersonalized(visDriver,index);
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t2,"email@"+t2+".com","54321","Q"+t2,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            try
            {
                if(ChatWindow.chatNotificationPresence(driver2,etest,3))
                {
                    etest.log(Status.FAIL,"Chat initiated with "+username2+" is present");
                    TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            try
            {
                if(ChatWindow.chatNotificationPresence(driver3,etest,3))
                {
                    etest.log(Status.FAIL,"Chat initiated with "+username3+" is present");
                    TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            if(!ChatWindow.chatNotificationPresence(driver,etest,10))
            {
                etest.log(Status.FAIL,"Chat initiated with "+username+" is not present");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+13),true);
            
            Thread.sleep(14000);
            
            try
            {
                if(!ChatWindow.chatNotificationPresence(driver2,etest,10))
                {
                    etest.log(Status.FAIL,"Chat initiated with "+username2+" is not present after half waiting time");
                    TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            try
            {
                if(!ChatWindow.chatNotificationPresence(driver3,etest,5))
                {
                    etest.log(Status.FAIL,"Chat initiated with "+username3+" is not present after half waiting time");
                    TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+14),true);
            
            try
            {
                VisitorWindow.waitTillChatisMissedInTheme(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            Thread.sleep(3000);
            
            if(!MissedChat.checkFirstVisitorInMissedList(driver,"V"+t2,"email@"+t2+".com","Q"+t2,"Me",etest))
            {
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                return;
            }
            
            try
            {
                if(!MissedChat.checkFirstVisitorInMissedList(driver2,"V"+t2,"email@"+t2+".com","Q"+t2,username,etest))
                {
                    TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver2,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            try
            {
                if(!MissedChat.checkFirstVisitorInMissedList(driver3,"V"+t2,"email@"+t2+".com","Q"+t2,username,etest))
                {
                    TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver3,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            TestInitTheme.result.put("EC"+(usecase+15),true);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            Websites.clickChatWidgetColour(driver,"#FF6D42",etest);
            
            Websites.clickSave(driver,etest,false);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickPersonalizedWidget(driver,etest);
            
            String actual2 = Websites.getChatWidgetColour(driver);
            
            if(!actual2.equals("#FF6D42"))
            {
                etest.log(Status.FAIL,"Expected:2 Operators-Actual:"+actual2+"--");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                return;
            }
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPageForPersonalized(visDriver,embedcode);
                
                String e = CommonUtil.elfinder(visDriver,"id","personalizethemecss").getAttribute("innerHTML");
                
                if(!e.contains("#FF6D42"))
                {
                    System.out.println("personalizethemecss<>"+e+"<>");
                    etest.log(Status.FAIL,"Expected:#FF6D42--Actual:"+e+"--");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error");
                    return;
                }
                
                TestInitTheme.result.put("EC"+(usecase+16),true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
                return;
            }
            
            etest.log(Status.INFO,"Checked");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPersonalizedTheme","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }
    
    public static boolean checkAgent(WebDriver visDriver, String agent, ExtentTest etest) throws Exception
    {
        WebElement e1 = VisitorWindow.getPersonalizedAgentDiv(visDriver,agent);
        
        if(e1 == null)
        {
            etest.log(Status.INFO,agent+" is not present");
            return false;
        }
        
        FluentWait waitV = CommonUtil.waitreturner(visDriver,3,250);
        
        waitV.until(ExpectedConditions.visibilityOf(e1));
        
        etest.log(Status.INFO,agent+" is present");
        
        return true;
    }
    
    public static void checkSize(WebDriver driver, final String theme, final String value, Integer usecase,ExtentTest etest) throws Exception
    {
        for(int i = usecase;i<=(usecase+1);i++)
        {
            TestInitTheme.result.put("EC"+i,false);
        }
        
        try
        {
            String embed=ExecuteStatements.getDefaultEmbedName(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);Thread.sleep(2000);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
                        
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickFloatWidget(driver,etest);

            WebsitesTab.clickChatWindow(driver,etest);
            
            WebElement sizeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_size");
            
            Websites.selectEmbedSize(driver,theme,etest);
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            driver.switchTo().defaultContent();
            
            driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
            
            driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
            
            WebElement body = CommonUtil.elfinder(driver,"tagname","body");
            
            String s1 = body.getAttribute("innerHTML");
            
            Long t1 = new Long(System.currentTimeMillis());
            Long t2 = new Long(System.currentTimeMillis());
            
            for(;;)
            {
                String s2 = body.getAttribute("innerHTML");
                
                if(!s1.equals(s2))
                {
                    s1 = s2;
                    t2 = new Long(System.currentTimeMillis());
                }
                
                Long t3 = new Long(System.currentTimeMillis());

                if(t3 - t2 > 2000)
                {
                    break;
                }
                
                if(t3 - t1 > 10000)
                {
                    break;
                }
            }
            
            WebElement ques = Websites.getInputArea(driver,"question");
            
            final WebElement textarea = CommonUtil.elementfinder(driver,ques,"tagname","textarea");

            driver.switchTo().defaultContent();
            
            try
            {

                wait = CommonUtil.waitreturner(driver,3,250);
                
                final WebElement previewdiv = CommonUtil.elfinder(driver,"id","previewdiv");
                
               wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        String s = previewdiv.getAttribute("size");
                        
                        if(s != null && s.contains(theme))
                        {
                            return true;
                        }
                        return false;
                    }
                });

               driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));

               WebElement previewWindow = CommonUtil.getElement(driver,By.className("zls-sptwndw"));
                
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        String s = previewWindow.getAttribute("class");
                        
                        if(s != null && s.contains("zsiq_size"+theme))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            catch(Exception e)
            {
                System.out.println("checkSize<>"+textarea.getAttribute("style")+"<>");
                
                throw e;
            }
            
            driver.switchTo().defaultContent();
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            sizeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_size");
            
            TestInitTheme.result.put("EC"+(usecase),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                VisitorWindow.clickChatButton(visDriver);
                
                VisitorWindow.switchToChatWidget(visDriver);
                
                FluentWait visitorwait = CommonUtil.waitreturner(visDriver,3,250);
                
                final WebElement section = CommonUtil.elfinder(visDriver,"tagname","section");
                
                visitorwait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        String s = section.getAttribute("class");
                        
                        if(s != null && s.contains("zsiq_size"+theme))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+1),true);
                
                etest.log(Status.INFO,"Checked in visitor site");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckSize","Error",e);
                return;
            }

            visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);

            com.zoho.livedesk.client.EmbedConfigTheme2.CheckECT.clickContinueChatThenMissChatAndCheckSubmitButton(driver,visDriver,etest,"8",theme);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckSize","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }
    
    public static void checkChatWindowTheme(WebDriver driver, final String theme, final String value, Integer usecase,ExtentTest etest) throws Exception
    {
        for(int i = usecase;i<=(usecase+1);i++)
        {
            TestInitTheme.result.put("EC"+i,false);
        }
        
        try
        {
            String embed=ExecuteStatements.getDefaultEmbedName(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);Thread.sleep(2000);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebElement sizeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_size");
            
            WebElement themeDiv = CommonUtil.elementfinder(driver,sizeDiv,"classname","em_stickers");
            
            CommonUtil.inViewPort(themeDiv);
            
            Websites.selectTheme(driver,themeDiv,theme,etest);
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            final String headerText = Websites.sizeName[Integer.parseInt(theme)];
            
            final WebElement header = CommonUtil.elementfinder(driver,sizeDiv,"id","themeid_header");
            
            CommonUtil.inViewPort(header);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            driver.switchTo().defaultContent();
            
            driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
            
            driver.switchTo().frame(CommonUtil.elfinder(driver,"id","siqiframe"));
            
            WebElement body = CommonUtil.elfinder(driver,"tagname","body");
            
            String s1 = body.getAttribute("innerHTML");
            
            Long t1 = new Long(System.currentTimeMillis());
            Long t2 = new Long(System.currentTimeMillis());
            
            for(;;)
            {
                String s2 = body.getAttribute("innerHTML");
                
                if(!s1.equals(s2))
                {
                    s1 = s2;
                    t2 = new Long(System.currentTimeMillis());
                }
                
                Long t3 = new Long(System.currentTimeMillis());
                
                if(t3 - t2 > 2000)
                {
                    break;
                }
                
                if(t3 - t1 > 10000)
                {
                    break;
                }
            }
            
            WebElement ques = Websites.getInputArea(driver,"question");
            
            final WebElement textarea = CommonUtil.elementfinder(driver,ques,"tagname","textarea");
            
            try
            {
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        if(textarea.getAttribute("style").equals(value))
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            catch(Exception e)
            {
                System.out.println("checkSize<>"+textarea.getAttribute("style")+"<>");
                
                throw e;
            }
            
            driver.switchTo().defaultContent();
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            sizeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_size");
            
            final WebElement header2 = CommonUtil.elementfinder(driver,sizeDiv,"id","themeid_header");
            
            CommonUtil.inViewPort(header2);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header2.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            TestInitTheme.result.put("EC"+(usecase),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = TestInitTheme.visitor_driver_manager.getDriver(driver);
            
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                VisitorWindow.clickChatButton(visDriver);
                
                VisitorWindow.switchToChatWidget(visDriver);
                
                FluentWait visitorwait = CommonUtil.waitreturner(visDriver,3,250);
                
                final WebElement section = CommonUtil.elfinder(visDriver,"tagname","section");
                
                visitorwait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        String s = section.getAttribute("class");
                        
                        if(s != null && s.contains("zsiq_size"+theme))
                        {
                            return true;
                        }
                        return false;
                    }
                });
                
                TestInitTheme.result.put("EC"+(usecase+1),true);
                
                etest.log(Status.INFO,"Checked in visitor site");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckSize","Error",e);
                return;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckSize","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }
}
