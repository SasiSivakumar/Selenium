//$Id$
package com.zoho.livedesk.client;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class Swebembedsettings
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
    public static ExtentTest etest;
		public static String widgetcode = "";
    public static String embedname = "";

	public static Hashtable webembedSettings(WebDriver driver)
	{
		try
		{
            etest=ComplexReportFactory.getTest("Getting portal info for automation");
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
			String unique_embed_name=ExecuteStatements.getDefaultEmbedName(driver);

			widgetcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,unique_embed_name);
			embedname=ExecuteStatements.getEmbedNameFromWidgetCode(driver,widgetcode);
			etest.log(Status.PASS,"Success");
			ComplexReportFactory.closeTest(etest);

            result = new Hashtable();
						System.out.println("came to module");
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW1"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");

            url = ConfManager.requestURL();

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            Functions.createTabAndCloseCurrent(driver);
						Tab.navToEmbedTab(driver);
						etest.log(Status.PASS,"WebEmbed Tab is present");
						result.put("SSW1", true);
						ComplexReportFactory.closeTest(etest);

   					etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW2"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW2", isPageAvail(driver));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW3"));
						ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW3", disableWebsite(driver,embedname));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW4"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW4", enableWebsite(driver,embedname));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW5"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW5", editWaitingTime(driver, embedname,"60"));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW6"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW6", sendToWebMaster(driver,embedname));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW7"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW7", SignatureLiveChatCode(driver,embedname));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW8"));
            ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW8", AgentSpecificLiveChatCode(driver,embedname));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW9"));
						ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW9", configureWelcomeMsg(driver, embedname));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW10"));
						ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW10", deleteWebEmbed(driver,"SEmbedname2"));
						ComplexReportFactory.closeTest(etest);

						etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SSW11"));
						ComplexReportFactory.setValues(etest,"Automation","WebEmbed - Supervisor");
						result.put("SSW11", floatButtonAlignment(driver,embedname,"right_middle")); //right_middle
						ComplexReportFactory.closeTest(etest);

		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorWebEmbedTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
      System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","WebEmbedTab","ErrorWhileCheckingWebEmbedTab",e);
			result.put("SSW1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorWebEmbedTab");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
      System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","WebEmbedTab","ErrorWhileCheckingWebEmbedTab",e);
			result.put("SSW1", false);
		}
			hashtable.put("result", result);
			hashtable.put("servicedown", servicedown);
			return hashtable;
	}

	//Check Web embed Settings Header
	private static boolean isPageAvail(WebDriver driver)
	{
		try
		{
				FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);
      	Functions.createTabAndCloseCurrent(driver);Tab.navToEmbedTab(driver);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innersubinfotxt")));
				List<WebElement> text = driver.findElements(By.className("innersubinfotxt"));
        System.out.println(text.get(0).getText()+"  --------  "+text.get(1).getText());
				if(((text.get(0).getText()).equals(ResourceManager.getRealValue("setting_webembed_desc1"))) && ((text.get(1).getText()).equals(ResourceManager.getRealValue("setting_webembed_desc2"))))
		 		{
						etest.log(Status.PASS,"WebEmbed Description is Checked");
						return true;
				}
				else
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","WebEmbedPage","MismatchDescription");
				}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","WebEmbedPage","ErrorWhileCheckingWebEmbedPage",e);
            System.out.println("Exception while checking if web embed settings page is available in supervisor login : "+e);
						return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","WebEmbedPage","ErrorWhileCheckingWebEmbedPage",e);
            System.out.println("Exception while checking if web embed settings page is available in supervisor login : "+e);
						return false;
		}
		return false;
	}
	//Disable embed
    private static boolean disableWebsite(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
						Tab.navToEmbedTab(driver);
						Thread.sleep(1000);
						changeStatusForwebsite(driver,embedname,false,etest);
						Thread.sleep(1000);
						String Websiteid = CommonUtil.elfinder(driver,"xpath",".//*[@title='"+embedname+"']/ancestor::*[@class='list-row list_disable']").getAttribute("id");
            WebElement elmt = CommonUtil.elfinder(driver,"xpath",".//*[@id='"+Websiteid+"']//*[starts-with(@class, 'emlist-ico sqico')]");
          	if(elmt.getAttribute("class").contains("sqico-disable"))
            {
                    Swebembedsettings.etest.log(Status.PASS,"WebEmbed is disabled");
										return true;
          	}
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","DisableWebEmbed","WebEmbedIsNotDisabled");
            return false;
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","DisableWebEmbed","ErrorWhileDisablingWebEmbed",e);
            System.out.println("Exception while disabling added web embed in web embed settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","DisableWebEmbed","ErrorWhileDisablingWebEmbed",e);
            System.out.println("Exception while disabling added web embed in web embed settings page in supervisor login : "+e);
        }
        return false;
    }

    //Enable web embed
    private static boolean enableWebsite(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
						Tab.navToEmbedTab(driver);
						Thread.sleep(1000);
						changeStatusForwebsite(driver,embedname,true,etest);
						Thread.sleep(1000);
						String Websiteid = CommonUtil.elfinder(driver,"xpath",".//*[@title='"+embedname+"']/ancestor::*[@class='list-row']").getAttribute("id");
						WebElement elmt = CommonUtil.elfinder(driver,"xpath",".//*[@id='"+Websiteid+"']//*[starts-with(@class, 'emlist-ico sqico')]");
						if(elmt.getAttribute("class").contains("sqico-enable"))
						{
										Swebembedsettings.etest.log(Status.PASS,"WebEmbed is Enabled");
										return true;
						}
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","EnableWebEmbed","WebEmbedIsNotenabled");
						return false;
        }
        catch(NoSuchElementException e)
        {
        	TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","EnableWebEmbed","ErrorWhileEnablingWebEmbed",e);
            System.out.println("Exception while enabling added web embed in web embed settings page in supervisor login : "+e);
            return false;
        }
        catch(Exception e)
        {
        	TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","EnableWebEmbed","ErrorWhileEnablingWebEmbed",e);
            System.out.println("Exception while enabling added web embed in web embed settings page in supervisor login : "+e);
            return false;
        }
    }

	//change waiting time
	private static boolean editWaitingTime(WebDriver driver,String embedname, String waitingtime)
	{
		try
		{
						FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
          	Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						WebsitesTab.clickChatWindow(driver,Swebembedsettings.etest);
						WebsitesTab.clickConfigurations(driver,Swebembedsettings.etest);
						String time = Websites.getValueFromDropdown(driver,"emconfig_wtime");
						if(time.equals(waitingtime+" Seconds"))
						{
							Websites.selectFromDropdown(driver,"emconfig_wtime","120 Seconds",Swebembedsettings.etest);
							Websites.clickSave(driver,Swebembedsettings.etest);
						}
						Websites.selectFromDropdown(driver,"emconfig_wtime",waitingtime+" Seconds",Swebembedsettings.etest);
						Websites.clickSave(driver,Swebembedsettings.etest);
						WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
						Thread.sleep(1500);
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						WebsitesTab.clickChatWindow(driver,Swebembedsettings.etest);
						WebsitesTab.clickConfigurations(driver,Swebembedsettings.etest);
						String actual = Websites.getValueFromDropdown(driver,"emconfig_wtime");
						if(!actual.equals(waitingtime+" Seconds"))
						{
							Swebembedsettings.etest.log(Status.FAIL,"Actual:"+actual+"--Expected:"+waitingtime+" Seconds");
							TakeScreenshot.screenshot(driver,Swebembedsettings.etest,"EmbedConfiguration","CheckWaitingTimer","Error");
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							return false;
						}
						else
						{
							Swebembedsettings.etest.log(Status.PASS,"CheckWaitingTimer is success");
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							return true;
						}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","EditWaitingTime","ErrorWhileWaitingWaitingTime",e);
            System.out.println("Exception while editing waiting time in added web embed in web embed settings page in supervisor login : "+e);
        }
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","EditWaitingTime","ErrorWhileWaitingWaitingTime",e);
            System.out.println("Exception while editing waiting time in added web embed in web embed settings page in supervisor login : "+e);
        }
		return false;
	}

    //Configure welcome message
    private static boolean configureWelcomeMsg(WebDriver driver, String embedname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						WebsitesTab.clickChatWindow(driver,Swebembedsettings.etest);
						WebsitesTab.clickResponsemessage(driver,Swebembedsettings.etest);
						CommonUtil.elfinder(driver,"xpath",".//*[@id='msgconfmain'][1]//*[@class='hdrtxt'][1]/em").click();
						WebElement elmt = driver.findElement(By.id("msgfld_GREETMSG0"));
						wait.until(ExpectedConditions.visibilityOf(elmt));
						elmt.click();
            elmt.clear();
            elmt.sendKeys("Configure welcome message");
						driver.findElement(By.id("window_prv")).click();
						Websites.clickSave(driver,Swebembedsettings.etest);
						WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						WebsitesTab.clickChatWindow(driver,Swebembedsettings.etest);
						WebsitesTab.clickResponsemessage(driver,Swebembedsettings.etest);
						CommonUtil.elfinder(driver,"xpath",".//*[@id='msgconfmain'][1]//*[@class='hdrtxt'][1]/em").click();
						String elmt1 = driver.findElement(By.id("msgfld_GREETMSG0")).getAttribute("value");
						System.out.println(elmt1);
            if("Configure welcome message".equals(driver.findElement(By.id("msgfld_GREETMSG0")).getAttribute("value")))
            {
                	Swebembedsettings.etest.log(Status.PASS,"Configure Welcome Message is checked");
									Thread.sleep(2000);
									CommonUtil.elfinder(driver,"xpath",".//*[@class='sqico-close siq_cls']").click();
									try
									{
									WebElement popup = driver.findElement(By.id("popupdlg1511328190225"));
									wait.until(ExpectedConditions.visibilityOf(popup));
									driver.switchTo().activeElement();
									driver.findElement(By.id("okbtn")).click();
									}
									catch(Exception e)
									{
										System.out.println("popup not occurs" );
									}
									return true;
            }
            else
						{
            	TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","ConfigureWelcomeMsg","WelcomeMessageIsNotConfigured");
							CommonUtil.elfinder(driver,"xpath",".//*[@class='sqico-close siq_cls']").click();
							return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","ConfigureWelcomeMsg","ErrorWhileCheckingConfiguredWelcomeMsg",e);
            System.out.println("Exception while configuring welcome message in added web embed in web embed settings page in supervisor login : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","ConfigureWelcomeMsg","ErrorWhileCheckingConfiguredWelcomeMsg",e);
            System.out.println("Exception while configuring welcome message in added web embed in web embed settings page in supervisor login : "+e);
        }
        return false;
    }


		//Send code to web master
		private static boolean sendToWebMaster(WebDriver driver, String embedname)
		{
				try
				{
						FluentWait wait = new FluentWait(driver);
						wait.withTimeout(30,TimeUnit.SECONDS);
						wait.pollingEvery(250,TimeUnit.MILLISECONDS);
						wait.ignoring(NoSuchElementException.class);

						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						driver.findElement(By.className("sqico-mail")).click();  //*[@class='sqico-mail'])
						Thread.sleep(1000);
						String webmasterheading=driver.findElement(By.className("emconfig_heding")).getText();
						//System.out.println(webmasterheading);	//Send this Code to your Web Developer
						if(webmasterheading.equals(ResourceManager.getRealValue("webembed_sendtowebmasterheadingnew")))
						{
							driver.findElement(By.id("toemail")).sendKeys("aathimaniraj.b@zohocorp.com");
							driver.findElement(By.xpath(".//*[@class='rg-button cmn_gbutclor cmn_cntbx']")).click();
							Tab.waitForLoadingSuccessWithBanner(driver,"Mail sent successfully","shareembedcode.do",etest);
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							Swebembedsettings.etest.log(Status.PASS,"SentToWebMaster is checked");
							return true;
					}
					else
					{
						Swebembedsettings.etest.log(Status.FAIL,"SentToWebMaster is Not checked");
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SentToWebMaster","MismatchScript");
						driver.findElement(By.xpath(".//*[@id='sendmaildiv']//*[starts-with(@class, 'sqico-close')]")).click();
						WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
						return false;
					}
				}
				catch(NoSuchElementException e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SentToWebMaster","ErrorWhileCheckingSentToWebMaster",e);
						System.out.println("Exception while checking send to webmaster in added web embed in web embed settings page in supervisor login : "+e);
				}
				catch(Exception e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SentToWebMaster","ErrorWhileCheckingSentToWebMaster",e);
						System.out.println("Exception while checking send to webmaster in added web embed in web embed settings page in supervisor login : "+e);
				}
				return false;
		}


		private static boolean SignatureLiveChatCode(WebDriver driver, String embedname)
		{
				try
				{
						FluentWait wait = new FluentWait(driver);
						wait.withTimeout(30,TimeUnit.SECONDS);
						wait.pollingEvery(250,TimeUnit.MILLISECONDS);
						wait.ignoring(NoSuchElementException.class);
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						System.out.println(widgetcode+"widgetcode");
						WebsitesTab.clickLiveChatEmail(driver,Swebembedsettings.etest);
						CommonWait.waitTillDisplayed(driver,By.className("wdprv_main"));
						CommonSikuli.findInWholePage(driver,"Signaturechat.png","UI45",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Chatcode.png","UI46",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Usercode.png","UI47",Swebembedsettings.etest);
						Thread.sleep(1000);
						CommonSikuli.findInWholePage(driver,"Signaturelivechatcode.png","UI48",Swebembedsettings.etest);
						driver.findElement(By.xpath(".//*[@signature='chat']/a")).click();
						String Headtext = driver.findElement(By.xpath(".//*[@class='cntmin lH22 sig_min ps-container']//*[@class='big-hdrtxt mB20']")).getText();
						System.out.println(Headtext);

						CommonSikuli.findInWholePage(driver,"Zohomail.png","UI50",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Zohodesk.png","UI51",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Zohocrm.png","UI52",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Gmail.png","UI53",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Outlook.png","UI54",Swebembedsettings.etest);

						if(Headtext.contains("Add signature Live Chat to your Email"))
						{
							String signaturecode = driver.findElement(By.id("signature_code")).getText();
							System.out.println("enableSignatureChat<S>"+signaturecode+"<>");
							if(signaturecode.contains("signature.ls") && signaturecode.contains(widgetcode) && signaturecode.contains("signaturesupport.ls"))
							{
									//String imgcode = driver.findElement(By.id("scimgcode")).getAttribute("value");
									System.out.println("Text Verified in signatureLiveChatCode Area");
									driver.findElement(By.className("linkdisplay")).click();
									String ImageCode = driver.findElement(By.id("signature_userurl")).getText();
									String LinkCode = driver.findElement(By.id("signature_link")).getText();
									if(ImageCode.contains("signature.ls") && ImageCode.contains(widgetcode) && LinkCode.contains("signaturesupport.ls") && LinkCode.contains(widgetcode))
									{
									etest.log(Status.PASS,"SignatureLiveChatCode is checked");
									WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
									return true;
									}
									else
									{
										System.out.println("While Checking ImageCode & LinkCode in SignatureLiveChatCode Error Occured");
										TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SignatureLiveChatCode","MismatchContentFor:"+"signaturecode");
										WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
										return false;
									}
							}
							else
							{
								System.out.println("While Checking SignatureLiveChatCode Error Occured");
								TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SignatureLiveChatCode","MismatchContentFor:"+"signaturecode");
								WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							}
						}
						else
						{
							System.out.println("While Checking Headtext in SignatureLiveChatCode Error Occured");
							TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SignatureLiveChatCode","MismatchContentFor:"+"signaturecode");
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
						}
				}
				catch(NoSuchElementException e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SignatureLiveChatCode","ErrorWhileCheckingEnableSignatureCode",e);
						System.out.println("Exception while Checking SignatureLiveChatCode in added web embed in web embed settings page in supervisor login : "+e);
				}
				catch(Exception e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","SignatureLiveChatCode","ErrorWhileCheckingEnableSignatureCode",e);
						System.out.println("Exception while Checking SignatureLiveChatCode in added web embed in web embed settings page in supervisor login : "+e);
				}
				return false;
		}

		private static boolean AgentSpecificLiveChatCode(WebDriver driver, String embedname)
		{
				try
				{
						FluentWait wait = new FluentWait(driver);
						wait.withTimeout(30,TimeUnit.SECONDS);
						wait.pollingEvery(250,TimeUnit.MILLISECONDS);
						wait.ignoring(NoSuchElementException.class);
						System.out.println(widgetcode+"widgetcode");
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChatEmail(driver,Swebembedsettings.etest);
						Thread.sleep(1000);

						CommonSikuli.findInWholePage(driver,"Agentspecificlivechatcode.png","UI49",Swebembedsettings.etest);

						driver.findElement(By.xpath(".//*[@signature='user']/a")).click();
						String Headtext = driver.findElement(By.xpath(".//*[@class='cntmin lH22 sig_min ps-container']//*[@class='big-hdrtxt mB20']")).getText();
						System.out.println(Headtext);
						
						CommonSikuli.findInWholePage(driver,"Zohomail.png","UI50",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Zohodesk.png","UI51",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Zohocrm.png","UI52",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Gmail.png","UI53",Swebembedsettings.etest);
						CommonSikuli.findInWholePage(driver,"Outlook.png","UI54",Swebembedsettings.etest);

						if(Headtext.contains("Add Agent Specific Chat to your Email"))
						{
							String signaturecode = driver.findElement(By.id("signature_code")).getText();
							System.out.println("enableSignatureChat<S>"+signaturecode+"<>");
							if(signaturecode.contains("signature.ls") && signaturecode.contains(widgetcode) && signaturecode.contains("signaturesupport.ls"))
							{
									System.out.println("Text Verified in AgentSpecificLiveChatCode");
									driver.findElement(By.className("linkdisplay")).click();
									String ImageCode = driver.findElement(By.id("signature_userurl")).getText();
									String LinkCode = driver.findElement(By.id("signature_link")).getText();
									if(ImageCode.contains("signature.ls") && ImageCode.contains(widgetcode) && LinkCode.contains("signaturesupport.ls") && LinkCode.contains(widgetcode))
									{
										etest.log(Status.PASS,"AgentSpecificLiveChatCode is checked");
										WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
										return true;
									}
									else
									{
										System.out.println("While Checking ImageCode & LinkCode in AgentSpecificLiveChatCode Error Occured");
										TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","AgentSpecificLiveChatCode","MismatchContentFor:"+"signaturecode");
										WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
										return false;
									}
							}
							else
							{
								System.out.println("while Checking AgentSpecificLiveChatCode Error Occured");
								TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","AgentSpecificLiveChatCode","MismatchContentFor:"+"signaturecode");
								WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							}

						}
						else
						{
							System.out.println("While Checking Headtext of AgentSpecificLiveChatCode Error Occured");
							TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","AgentSpecificLiveChatCode","MismatchContentFor:"+"signaturecode");
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
						}
				}
				catch(NoSuchElementException e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","AgentSpecificLiveChatCode","ErrorWhileCheckingEnableSignatureCode",e);
						System.out.println("Exception while Checking AgentSpecificLiveChatCode in added web embed in web embed settings page in supervisor login : "+e);
				}
				catch(Exception e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","AgentSpecificLiveChatCode","ErrorWhileCheckingEnableSignatureCode",e);
						System.out.println("Exception while Checking AgentSpecificLiveChatCode in added web embed in web embed settings page in supervisor login : "+e);
				}
				return false;
		}

		//Change button alignment
		private static boolean floatButtonAlignment(WebDriver driver, String embedname, String align)
		{
				try
				{
						FluentWait wait = new FluentWait(driver);
						wait.withTimeout(30,TimeUnit.SECONDS);
						wait.pollingEvery(250,TimeUnit.MILLISECONDS);
						wait.ignoring(NoSuchElementException.class);
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						WebsitesTab.clickWidget(driver,Swebembedsettings.etest);
						WebsitesTab.clickApperanceInWidget(driver,Swebembedsettings.etest);
						Thread.sleep(1000);

						String Headtext = driver.findElement(By.xpath(".//*[@class='cntmin lH22 ps-container ps-active-y']//*[@class='big-hdrtxt mB20']")).getText();
						System.out.println(Headtext);

					if(Headtext.contains("Float widget Appearance"))
					{
						JavascriptExecutor js = ((JavascriptExecutor) driver);
						js.executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath(".//*[@class='mB20 mT10 aprs_rectxt']")));
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@class='mB20 mT10 aprs_rectxt']")));
						driver.findElement(By.xpath(".//*[@align='left_top']")).click();
						Websites.clickSave(driver,Swebembedsettings.etest);
						Thread.sleep(3000);
						System.out.println(".//*[@align='"+align+"']");
						driver.findElement(By.xpath(".//*[@align='"+align+"']")).click();
						Websites.clickSave(driver,Swebembedsettings.etest);
						Thread.sleep(1000);
						WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
						Tab.navToEmbedTab(driver);
						WebEmbed.clickWebEmbed(driver,embedname,Swebembedsettings.etest);
						WebsitesTab.clickLiveChat(driver,Swebembedsettings.etest);
						WebsitesTab.clickWidget(driver,Swebembedsettings.etest);
						WebsitesTab.clickApperanceInWidget(driver,Swebembedsettings.etest);
						js.executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath(".//*[@class='mB20 mT10 aprs_rectxt']")));
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@class='mB20 mT10 aprs_rectxt']")));

						String position = driver.findElement(By.xpath(".//*[@id='widgetposition']//*[contains(@class, 'sel')]")).getAttribute("align");
						if(position.equals(align))
						{
							System.out.println("Floatbutton position is updated");
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							return true;
						}
						else
						{
							TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","FloatButtomAlignmentError","FloatButtomIsNotAligned");
							System.out.println("Floatbutton position is not updated");
							WebsitesTab.closeEmbedConfig(driver,Swebembedsettings.etest);
							return false;

						}
					}
					else
					{
						System.out.println("Floatbutton position is not updated");
					}
				}
				catch(NoSuchElementException e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","FloatButtomAlignment","ErrorWhileCheckingFloatButtomAlignment",e);
						System.out.println("Exception while checking float button alignment in added web embed in web embed settings page in supervisor login : "+e);
				}
				catch(Exception e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","FloatButtomAlignment","ErrorWhileCheckingFloatButtomAlignment",e);
						System.out.println("Exception while checking float button alignment in added web embed in web embed settings page in supervisor login : "+e);
				}
				return false;
		}

		private static boolean deleteWebEmbed(WebDriver driver, String value)
		{
				try
				{
						FluentWait wait = new FluentWait(driver);
						wait.withTimeout(30,TimeUnit.SECONDS);
						wait.pollingEvery(250,TimeUnit.MILLISECONDS);
						wait.ignoring(NoSuchElementException.class);

						Functions.createTabAndCloseCurrent(driver);
						Tab.navToEmbedTab(driver);

						WebElement websiteaddbutton = driver.findElement(By.className("innerbtnmn"));
						wait.until(ExpectedConditions.visibilityOf(websiteaddbutton));
						websiteaddbutton.click();

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
						driver.findElement(By.id("pop-femail")).sendKeys("SEmbedname2");
						driver.findElement(By.id("okbtn")).click();
						Thread.sleep(5000);
						Tab.navToEmbedTab(driver);

						WebElement elmt1 = driver.findElement(By.id("embedlist"));
						List<WebElement> elmts = elmt1.findElements(By.className("list-row"));

						for(WebElement elmt:elmts)
						{
								String data = elmt.findElement(By.className("txtelips")).getText();
								if(data.equals(value))
								{
										List<WebElement> em = elmt.findElements(By.tagName("em"));
										mouseOver(driver,em.get(0));
										em.get(0).click();
										wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
										driver.findElement(By.id("okbtn")).click();
										break;
								}
						}

						Thread.sleep(1000);
						Tab.navToEmbedTab(driver);

						if((driver.findElement(By.id("embedlist")).getText()).contains(value))
						{
								TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","DeleteWebEmbed","WebEmbedIsNotDeleted");
								return false;
						}
						etest.log(Status.PASS,"WebEmbed is deleted");
						return true;
				}
				catch(NoSuchElementException e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","DeleteWebEmbed","ErrorWhileDeletingWebEmbed",e);
						System.out.println("Exception while deleting added web embed in web embed settings page in supervisor login : "+e);
				}
				catch(Exception e)
				{
						TakeScreenshot.screenshot(driver,etest,"WebEmbed-Supervisor","DeleteWebEmbed","ErrorWhileDeletingWebEmbed",e);
						System.out.println("Exception while deleting added web embed in web embed settings page in supervisor login : "+e);
				}
				return false;
		}

		public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

		public static void changeStatusForwebsite(WebDriver driver, String embedname, final Boolean enable, ExtentTest etest) throws Exception
		{
			FluentWait wait = CommonUtil.waitreturner(driver,20,250);
			String Websiteid = CommonUtil.elfinder(driver,"xpath",".//*[@title='"+embedname+"']/ancestor::*[starts-with(@class, 'list-row')]").getAttribute("id");
			Thread.sleep(2000);
			final WebElement eye = CommonUtil.elfinder(driver,"xpath",".//*[@id='"+Websiteid+"']//*[starts-with(@class, 'emlist-ico sqico')]");
			final String status = enable?"enable":"disable";
	    String usecase = enable?"enable":"disable";
			if(eye.getAttribute("status").equals(status))
			{
	        etest.log(Status.INFO,embedname + " is already "+usecase+"d");
				  return;
			}
			eye.click();
	    etest.log(Status.INFO,embedname + " - "+usecase+" is clicked");
		}
}
