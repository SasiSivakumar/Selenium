//$Id$
package com.zoho.livedesk.client.CannedMessage;

import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;



import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.CommonSikuli;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;




public class CannedMessagesModule{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> TestResults = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String portal_name=null;
	public static String embed_name="";
    public static String department="ldautomation12";

    public static String widget_code="";

	public static Hashtable test(WebDriver driver1) throws Exception
	{
		try
		{
			embed_name=ExecuteStatements.getDefaultEmbedName(driver1);
			widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver1,embed_name);
			portal_name=ExecuteStatements.getPortal(driver1);

            TestResults = new Hashtable<String,Boolean>();
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCM1"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Messages");

			TestResults.put("DCM1", checkAddCannedMessage(driver1));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCM2"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Messages");
            
            TestResults.put("DCM2", checkDynamicTextSuggestionDisplayed(driver1));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCM3"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Messages");
            
            TestResults.put("DCM3", checkDeleteCannedMessage(driver1));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCM7"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Messages");
            
            TestResults.put("DCM7", checkSendingMessages(driver1));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCM13"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Messages");
            
            TestResults.put("DCM13", checkCannedMessagesTilesUI(driver1));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("DCM14"));
			ComplexReportFactory.setValues(etest,"Automation","Dynamic Canned Messages");
            
            TestResults.put("DCM14",checkAllDynamicText(driver1));
            
            ComplexReportFactory.closeTest(etest);
        }
		catch(Exception e)
		{
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);

			finalResult.put("result",TestResults);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}


	public static boolean checkAddCannedMessage(WebDriver driver) throws Exception
	{
		int passcount=0;

		String UserName=ExecuteStatements.getUserName(driver);
		String UserNameReport="'"+UserName+"'";

		try
		{
			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
			etest.log(Status.INFO,UserNameReport+" clicked add canned message.");

			if(CannedMessagesCommonFunctions.checkComposeMessage(driver,etest))
			{
				passcount++;
			}

			if(CannedMessagesCommonFunctions.checkSaveButtonAndCancelButtonInAddCanned(driver,etest))
			{
				passcount++;
			}

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkAddCannedMessage","Exception",e);
		}
		finally
		{
		}

		return returnResult(passcount,2);
	}

	public static boolean checkDynamicTextSuggestionDisplayed(WebDriver driver) throws Exception
	{
		int passcount=0;

		String UserName=ExecuteStatements.getUserName(driver);
		String UserNameReport=" '"+UserName+"' ";

		try
		{
			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickAddCannedMessage(driver);

			CannedMessagesCommonFunctions.sendTextToComposeMessageTextArea(driver,"%");

			if(CannedMessagesCommonFunctions.checkDynamicTextSuggestionsDisplayed(driver))
			{
				etest.log(Status.PASS,"Dynamic text suggestions were shown after"+UserNameReport+"typed '%' in compose message text area");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Dynamic text suggestions were NOT shown after"+UserNameReport+"typed '%' in compose message text area");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkDynamicTextSuggestionDisplayed","Exception",e);
		}
		finally
		{
		}

		return returnResult(passcount,1);
	}

	public static boolean checkDeleteCannedMessage(WebDriver driver) throws Exception
	{
		int passcount=0;
		int cm4_passcount=0,cm5_passcount=0;

		String UserName=ExecuteStatements.getUserName(driver);
		String UserNameReport=" '"+UserName+"' ";
		String canned_message=getUniqueMessage();
		String category="Automation";
		Thread.sleep(147);
		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";

		TestResults.put("DCM4", false);
		TestResults.put("DCM5", false);
		try
		{
			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
			CannedMessagesCommonFunctions.createNewCannedMessage(driver,canned_message,category);

			etest.log(Status.INFO,UserNameReport+"created a new canned message(message:"+canned_message+",category:"+category+")");

			CommonUtil.refreshPage(driver);

			Tab.clickCannedMessages(driver);
			Thread.sleep(3000);
			if(CannedMessagesCommonFunctions.checkCannedMessagePresentInList(driver,canned_message))
			{
				etest.log(Status.PASS,"Newly created canned message was found in canned message list for"+UserNameReport);
				passcount++;
			}

			else
			{
				etest.log(Status.FAIL,"Newly created canned message was NOT found in canned message list for"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			//owner dept code starts

			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickCannedMessagePresentInList(driver,canned_message);
			Thread.sleep(4000);
			if(CannedMessagesCommonFunctions.checkOwner(driver,UserName))
			{
				etest.log(Status.PASS,UserNameReport+" found the expected owner of newly created chat message in canned message details");
				cm5_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,UserNameReport+" did not find the expected owner(expected owner:"+UserName+") of newly created chat message in canned message details");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}
			if(CannedMessagesCommonFunctions.checkDepartment(driver,"All Departments"))
			{
				etest.log(Status.PASS,UserNameReport+" found the expected department of newly created chat message in canned message details");
				cm5_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,UserNameReport+" did not find the expected department(expected department:'All Departments') of newly created chat message in canned message details");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			TestResults.put("DCM5", returnResult(cm5_passcount,2));

			//owner dept code ends


			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				CannedMessagesCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Messages","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,UserNameReport+" started chat from visitor(visitor name : '"+visitor_name+"' )");

			CommonSikuli.findInWholePage(visitor_driver,"Afterchataccept.png","UI318",CannedMessagesModule.etest);
			
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageSuggestionForCannedMessage(driver,canned_message))
			{
				etest.log(Status.PASS,"Newly created canned message was found in chat for"+UserNameReport);
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Newly created canned message was NOT found in chat for"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}


			String new_canned_message=getUniqueMessage();

			//edit code starts

			Tab.clickCannedMessages(driver);

			Thread.sleep(3000);

			CannedMessagesCommonFunctions.editCannedMessage(driver,canned_message,new_canned_message);
			etest.log(Status.INFO,UserNameReport+" edited newly created canned message(canned message: '"+canned_message+"' ) to '"+new_canned_message+"'");
			canned_message=new_canned_message;

			Tab.clickCannedMessages(driver);

			CommonUtil.refreshPage(driver);
			Thread.sleep(1000);

			if(CannedMessagesCommonFunctions.checkCannedMessagePresentInList(driver,canned_message))
			{
				etest.log(Status.PASS,"Canned message was updated in canned message list after "+UserNameReport+" edited it.");
				cm4_passcount++;
			}

			else
			{
				etest.log(Status.FAIL,"Canned message(edited to :"+canned_message+") was NOT updated in canned message list after "+UserNameReport+" edited it.");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			Tab.clickMyChats(driver);

			CannedMessagesCommonFunctions.selectVisitorTabInChat(driver,visitor_name);

			CannedMessagesCommonFunctions.clearChatTextArea(driver);

			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageSuggestionForCannedMessage(driver,canned_message))
			{
				etest.log(Status.PASS,"Edited canned message was found in chat after "+UserNameReport+"edited it");
				cm4_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Edited canned message("+canned_message+") was NOT found in chat after "+UserNameReport+"edited it");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.clearChatTextArea(driver);

			TestResults.put("DCM4", returnResult(cm4_passcount,2));

			//edit code ends

			Tab.clickCannedMessages(driver);

			Thread.sleep(3000);

			CannedMessagesCommonFunctions.deleteCannedMessage(driver,canned_message);
			etest.log(Status.INFO,UserNameReport+" deleted newly created canned message(canned message: '"+canned_message+"' )");

			CommonUtil.refreshPage(driver);

			Tab.clickCannedMessages(driver);
			Thread.sleep(3000);
			if(!CannedMessagesCommonFunctions.checkCannedMessagePresentInList(driver,canned_message))
			{
				etest.log(Status.PASS,"Newly created canned message was NOT found in canned message list after deletion for"+UserNameReport);
				passcount++;
			}

			else
			{
				etest.log(Status.FAIL,"Newly created canned message was found in canned message list after deletion for"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			Tab.clickMyChats(driver);

			CannedMessagesCommonFunctions.selectVisitorTabInChat(driver,visitor_name);

			CannedMessagesCommonFunctions.clearChatTextArea(driver);

			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(!CannedMessagesCommonFunctions.checkCannedMessageSuggestionForCannedMessage(driver,canned_message))
			{
				etest.log(Status.PASS,"Newly created canned message was NOT found after deletion in chat for"+UserNameReport);
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Newly created canned message was found in chat after deletion for"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.clearChatTextArea(driver);

			ChatWindow.endAndCloseChat(driver);
			etest.log(Status.INFO,UserNameReport+" ended chat from visitor(visitor name : '"+visitor_name+"' )");
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkDeleteCannedMessage","Exception",e);
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}

		return returnResult(passcount,4);
	}


	public static boolean checkSendingMessages(WebDriver driver) throws Exception
	{
		int passcount=0,cm6_passcount=0,cm8_passcount=0,cm9_passcount=0,cm10_passcount=0,cm11_passcount=0,cm12_passcount=0;

		String UserName=ExecuteStatements.getUserName(driver);
		String UserNameReport=" '"+UserName+"' ";
		String canned_message=getUniqueMessage();
		String category="Automation";
		Thread.sleep(147);
		String vstr=getUniqueMessage();
		String visitor_name="V_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		String visitor_mail="v_"+vstr.substring(3,6)+vstr.substring(9)+"@salesiqautomation.com";

        TestResults.put("DCM6",false);
        TestResults.put("DCM8",false);
        TestResults.put("DCM9",false);
        TestResults.put("DCM10",false);
        TestResults.put("DCM11",false);
        TestResults.put("DCM12",false);

		try
		{
			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
			CannedMessagesCommonFunctions.createNewCannedMessage(driver,canned_message,category);

			etest.log(Status.INFO,UserNameReport+"created a new canned message(message:"+canned_message+",category:"+category+")");

			CommonUtil.refreshPage(driver);

			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				CannedMessagesCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,"Hello,What are the available discounts?");
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Messages","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,UserNameReport+" started chat from visitor(visitor name : '"+visitor_name+"' )");

			Thread.sleep(4000);

			//checkSendingMessages starts

			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);

			if(CannedMessagesCommonFunctions.checkCannedMessageListInChat(driver))
			{
				etest.log(Status.PASS,"Canned messages were displayed after"+UserNameReport+"clicked canned messages button in chat");
				cm6_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned messages were NOT displayed after"+UserNameReport+"clicked canned messages button in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			if(CannedMessagesCommonFunctions.checkCannedMessageSearchDisplayed(driver))
			{
				etest.log(Status.PASS,"Canned messages search was displayed after"+UserNameReport+"clicked canned messages button in chat");
				cm6_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned messages search was NOT displayed after"+UserNameReport+"clicked canned messages button in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

	        TestResults.put("DCM6",returnResult(cm6_passcount,2));


			CannedMessagesCommonFunctions.clickCannedMessageFromListInChat(driver,canned_message);
			etest.log(Status.INFO,UserNameReport+"clicked a canned message from the canned message list in chat");
			Thread.sleep(500);
			if(CannedMessagesCommonFunctions.checkMessagePresentInChatTextArea(driver,canned_message))
			{
				etest.log(Status.PASS,"Selected canned message was added to chat input for"+UserNameReport);
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Selected canned message was NOT added to chat input for"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);

			if(CannedMessagesCommonFunctions.isMessageAppendedInUserSide(driver,canned_message))
			{
				etest.log(Status.PASS,"Selected canned message was sent to visitor by"+UserNameReport+"after he pressed 'Enter' key.");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Selected canned message was NOT sent to visitor by"+UserNameReport+"after he pressed 'Enter' key.");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			//checkSendingMessages ends

			//Click canned messages,search existing canned message,check if it is found,check if search text is highlighted starts

			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);
			CannedMessagesCommonFunctions.searchCannedMessage(driver,canned_message);

			if(CannedMessagesCommonFunctions.checkSearchIsHighlighted(driver,canned_message))
			{
				etest.log(Status.PASS,"Canned message("+canned_message+") was found in canned message search after it was searched by"+UserNameReport);
				cm8_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message("+canned_message+") was NOT found in canned message search after it was searched by"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			String sub_canned_message=canned_message.substring(0,canned_message.length()-3);
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.clickCannedMessageButtonInChat(driver);
			CannedMessagesCommonFunctions.searchCannedMessage(driver,sub_canned_message);

			if(CannedMessagesCommonFunctions.checkSearchIsHighlighted(driver,sub_canned_message))
			{
				etest.log(Status.PASS,"Canned message search result(search:"+sub_canned_message+") was highlighted in canned message search result after it was searched by"+UserNameReport);
				cm8_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message search result(search:"+sub_canned_message+") was highlighted in canned message search result after it was searched by"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

       		TestResults.put("DCM8",returnResult(cm8_passcount,2));


			//Click canned messages,search existing canned message,check if it is found,check if search text is highlighted ends

			//Type '#' in message box,check if canned message list is shown.click search result and check if canned message added in message input and sent starts

			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was displayed after "+UserNameReport+"pressed '#' key in chat");
				cm9_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was NOT displayed after "+UserNameReport+"pressed '#' key in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.clickCannedMessageFromInput(driver,canned_message);
			etest.log(Status.INFO,UserNameReport+"clicked a canned message from the canned message suggestion list in chat");
			Thread.sleep(500);
			if(CannedMessagesCommonFunctions.checkMessagePresentInChatTextArea(driver,canned_message))
			{
				etest.log(Status.PASS,"Selected canned message was added to chat input for"+UserNameReport);
				cm9_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Selected canned message was NOT added to chat input for"+UserNameReport);
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);

			if(CannedMessagesCommonFunctions.isMessageAppendedInUserSide(driver,canned_message))
			{
				etest.log(Status.PASS,"Selected canned message was sent to visitor by"+UserNameReport+"after he pressed 'Enter' key.");
				cm9_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Selected canned message was NOT sent to visitor by"+UserNameReport+"after he pressed 'Enter' key.");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

       		TestResults.put("DCM9",returnResult(cm9_passcount,3));


			//Type '#' in message box,check if canned message list is shown.click search result and check if canned message added in message input and sent ends

			//Type some text then type '#' in message box,check if canned message list is not shown starts
			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,getUniqueMessage()+"#");
			Thread.sleep(50);
			if(!CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was NOT displayed after "+UserNameReport+"pressed '#' key when chat input contained other text.");
				cm10_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was displayed after "+UserNameReport+"pressed '#' key when chat input contained other text.");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}
       		TestResults.put("DCM10",returnResult(cm10_passcount,1));

			//Type some text then type '#' in message box,check if canned message list is not shown ends

			//Type '#' check if canned messages list displayed,then type some text which is not present in any canned messages,check canned message suggestion disappears starts

			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was displayed after "+UserNameReport+"pressed '#' key in chat");
				cm11_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was NOT displayed after "+UserNameReport+"pressed '#' key in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,getUniqueMessage());

			if(!CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was NOT displayed after "+UserNameReport+"typed '#' key followed by an invalid search");
				cm11_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was displayed after "+UserNameReport+"typed '#' key followed by an invalid search");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}
       		TestResults.put("DCM11",returnResult(cm11_passcount,2));

			//Type '#' check if canned messages list displayed,then type some text which is not present in any canned messages,check canned message suggestion disappears ends

			//Type '#' check if canned messages suggestion appears,press esc,check if canned message suggestion disappears starts

			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");

			if(CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was displayed after "+UserNameReport+"pressed '#' key in chat");
				cm12_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was NOT displayed after "+UserNameReport+"pressed '#' key in chat");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.sendEscapeKeyInChatTextArea(driver);

			if(!CannedMessagesCommonFunctions.checkCannedMessageListFromInput(driver))
			{
				etest.log(Status.PASS,"Canned message suggestions list was NOT displayed after "+UserNameReport+"pressed 'Escape' key");
				cm12_passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions list was displayed after "+UserNameReport+"pressed 'Escape' key");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}
       		TestResults.put("DCM12",returnResult(cm12_passcount,2));

			Tab.clickCannedMessages(driver);
			Thread.sleep(3000);
			CannedMessagesCommonFunctions.deleteCannedMessage(driver,canned_message);

            Tab.clickMyChats(driver);
            ChatWindow.endAndCloseChat(driver);
 		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkSendingMessages","Exception",e);
		}
		finally
		{
			try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}

		return returnResult(passcount,2);
	}




	public static boolean checkCannedMessagesTilesUI(WebDriver driver) throws Exception
	{
		int passcount=0;
		WebDriver visitor_driver=null;
		String UserName=ExecuteStatements.getUserName(driver);
		String UserNameReport=" '"+UserName+"' ";
		String visitor_id="";
		String canned_message=getUniqueMessage();
		String category="Automation";


		try
		{
			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
			CannedMessagesCommonFunctions.createNewCannedMessage(driver,canned_message,category);

			etest.log(Status.INFO,UserNameReport+"created a new canned message(message:"+canned_message+",category:"+category+")");

			CommonUtil.refreshPage(driver);

			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				visitor_id=VisitorWindow.getVisitorId(visitor_driver,portal_name);
				passcount++;
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Messages","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			Tab.clickVisitorsOnline(driver);

			CannedMessagesCommonFunctions.clickVisitorOnline(driver,visitor_id);
            
			CannedMessagesCommonFunctions.sendTextToTilesUIChat(driver,visitor_id,"#");
			if(CannedMessagesCommonFunctions.checkCannedMessageSuggestionDisplayedTilesUI(driver,visitor_id))
			{
				etest.log(Status.PASS,"Canned message suggestions were displayed after"+UserNameReport+"pressed '#' key in Tiles UI");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message suggestions were NOT displayed after"+UserNameReport+"pressed '#' key in Tiles UI");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}
			CannedMessagesCommonFunctions.clickCannedMessageFromSuggestionTilesUI(driver,visitor_id,canned_message);

			if(CannedMessagesCommonFunctions.checkTextInTilesUIChat(driver,visitor_id,canned_message))
			{
				etest.log(Status.PASS,"Canned message was added to message input after"+UserNameReport+"clicked it from canned message suggestion in Tiles UI");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message was NOT added to message input after"+UserNameReport+"clicked it from canned message suggestion in Tiles UI");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.sendEnterKeyToTilesUIChat(driver,visitor_id);

			CommonWait.waitTillDisplayed(driver,By.id("dept_"+visitor_id));
			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("dept_"+visitor_id+"_div")));
			List<WebElement> depts = CommonUtil.getElement(driver,By.id("dept_"+visitor_id+"_ddown")).findElements(By.tagName("li"));
			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(depts,"title",department));

			if(CannedMessagesCommonFunctions.checkMessageAppendInTilesUIChat(driver,visitor_id,canned_message))
			{
				etest.log(Status.PASS,"Canned message was sent to visitor after"+UserNameReport+"pressed enter key in chat of Tiles UI");
				passcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Canned message was NOT sent to visitor after"+UserNameReport+"pressed enter key in chat of Tiles UI");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");
			}

			CannedMessagesCommonFunctions.sendEscapeKeyToTilesUIChat(driver,visitor_id);

			Thread.sleep(500);
			Tab.clickCannedMessages(driver);
			Thread.sleep(3000);
			CannedMessagesCommonFunctions.deleteCannedMessage(driver,canned_message);
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkDynamicTextSuggestionDisplayed","Exception",e);
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}

		return returnResult(passcount,4);
	}

	public static boolean checkAllDynamicText(WebDriver driver) throws Exception
	{
		int passcount=0;
		String category="Automation";
		Thread.sleep(147);
		String vstr=getUniqueMessage();
		String visitor_name="v_"+vstr.substring(3,6)+vstr.substring(9);
		WebDriver visitor_driver=null;
		visitor_name=visitor_name.toUpperCase();
		String visitor_mail=visitor_name+"@salesiqautomation.com";
		String visitor_question="Hello,What are the available discounts?";
		String pagetitle="";
		String url="";
		String browser="";
		String os="";
		String browser_version="";
		String UserName=ExecuteStatements.getUserName(driver);
		String UserMail=ExecuteStatements.getUserMail(driver);
		String UserNameReport=" '"+UserName+"' ";


		try
		{
			String canned_message_id=getUniqueMessage();
			String canned_message=canned_message_id+"visitor.name:%visitor.name%attender.name:%attender.name%smart.timenow:%smart.timenow%visitor.department:%visitor.department%visitor.email:%visitor.email%attender.email:%attender.email%visitor.question:%visitor.question%visitor.id:%visitor.id%visitor.phone:%visitor.phone%visitor.country:%visitor.country%visitor.city:%visitor.city%web.embed.name:%web.embed.name%visitor.pagetitle:%visitor.pagetitle%visitor.ip:%visitor.ip%visitor.pageurl:%visitor.pageurl%visitor.referrer:%visitor.referrer%visitor.state:%visitor.state%visitor.timezone:%visitor.timezone%visitor.latitude:%visitor.latitude%visitor.longitude:%visitor.longitude%visitor.operating.system:%visitor.operating.system%visitor.browser:%visitor.browser%visitor.browser.version:%visitor.browser.version%visitor.platform:%visitor.platform%screen.resolution:%screen.resolution%search.engine:%search.engine%search.query:%search.query%";
			Tab.clickCannedMessages(driver);
			CannedMessagesCommonFunctions.clickAddCannedMessage(driver);
			CannedMessagesCommonFunctions.createNewCannedMessage(driver,canned_message,category);

			etest.log(Status.INFO,UserNameReport+"created a new canned message with all dynamic text suggestions(category:"+category+")");

			CommonUtil.refreshPage(driver);

			try
			{
				visitor_driver=Functions.setUp(true);
				VisitorWindow.createPageReferrer1(visitor_driver,widget_code,"https://www.google.co.in/");
				CannedMessagesCommonFunctions.initiateChatInClientSide(visitor_driver,visitor_name,visitor_mail,visitor_question);
				pagetitle=visitor_driver.getTitle().toString();
				url=visitor_driver.getCurrentUrl();

				Capabilities cap = ((RemoteWebDriver) visitor_driver).getCapabilities();
				browser = cap.getBrowserName().toLowerCase();
				os = cap.getPlatform().toString();
				browser_version = cap.getVersion().toString();
			}
			catch(Exception exp)
			{
				TakeScreenshot.screenshot(visitor_driver,etest,"Canned Messages","Visitor Failure","Error at Visitor Window",exp);
				return false;
			}

			ChatWindow.acceptChat(driver,etest);
			etest.log(Status.INFO,UserNameReport+" started chat from visitor(visitor name : '"+visitor_name+"' )");

			CannedMessagesCommonFunctions.clearChatTextArea(driver);
			CannedMessagesCommonFunctions.sendTextToChatTextArea(driver,"#");
			CannedMessagesCommonFunctions.clickCannedMessageFromInput(driver,canned_message_id);
			etest.log(Status.INFO,UserNameReport+"clicked a canned message from the canned message suggestion list in chat");
			Thread.sleep(500);
			CannedMessagesCommonFunctions.sendEnterKeyInChatTextArea(driver);
			CannedMessagesCommonFunctions.isMessageAppendedInUserSide(driver,canned_message_id);
			/*
				visitor.name:%visitor.name% //done
				attender.name:%attender.name%  //done
				smart.timenow:%smart.timenow% $done
				visitor.department:%visitor.department%
				visitor.email:%visitor.email%  //done
				attender.email:%attender.email% //done
				visitor.question:%visitor.question% // done
				visitor.id:%visitor.id% $done
				visitor.phone:%visitor.phone% //not included
				visitor.country:%visitor.country% //done
				visitor.city:%visitor.city% //done
				web.embed.name:%web.embed.name%
				visitor.pagetitle:%visitor.pagetitle% //done
				visitor.ip:%visitor.ip% //done
				visitor.pageurl:%visitor.pageurl% //done
				visitor.referrer:%visitor.referrer%//done
				visitor.state:%visitor.state% //done
				visitor.timezone:%visitor.timezone% //done
				visitor.latitude:%visitor.latitude% //done
				visitor.longitude:%visitor.longitude% //done
				visitor.operating.system:%visitor.operating.system% //done
				visitor.browser:%visitor.browser% //done
				visitor.browser.version:%visitor.browser.version% //done
				visitor.platform:%visitor.platform% //not needed
				screen.resolution:%screen.resolution% //done
				search.engine:%search.engine%//done
				search.query:%search.query%//not needed

			*/

			//Hashtable insertion begins
			String keys_array[]={"visitor.name","attender.name","visitor.email","visitor.question","attender.email","visitor.pagetitle","visitor.pageurl","visitor.browser.version"};
			Hashtable<Integer,String> keys=new Hashtable<Integer,String>();
			for(int i=0;i<keys_array.length;i++)
			{
				keys.put(i,keys_array[i]);
			}

			Hashtable<String,String> expected=new Hashtable<String,String>();
			// expected.put("",);

			expected.put("visitor.name",visitor_name);
			expected.put("visitor.email",visitor_mail);
			expected.put("visitor.question",visitor_question);
			expected.put("attender.name",UserName);
			expected.put("attender.email",UserMail);
			expected.put("visitor.pagetitle",pagetitle);
			expected.put("visitor.pageurl",url);
			expected.put("visitor.timezone","GMT+0530");
			expected.put("visitor.browser.version",browser_version);
			//seperate checks
			expected.put("visitor.browser",browser);
			expected.put("visitor.operating.system",os);
			//Hashtable insertion ends

			if(CannedMessagesCommonFunctions.checkAllCannedMessages(driver,keys,expected,etest))
			{
				passcount++;
			}

			Tab.clickCannedMessages(driver);
			Thread.sleep(3000);
			CannedMessagesCommonFunctions.deleteCannedMessage(driver,canned_message);

            Tab.clickMyChats(driver);
            ChatWindow.endAndCloseChat(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"Canned Message","checkAllDynamicText","Exception",e);
            System.out.println("checkAllDynamicTextHere");
            e.printStackTrace();
		}
		finally
		{
            try
            {
                CommonUtil.CloseBrowser(visitor_driver);
            }
            catch(Exception excep){}
		}

		return returnResult(passcount,1);
	}







		//end of test case functions

	public static String getUniqueMessage()
	{
		return ""+new Long(System.currentTimeMillis());
	}

	public static boolean returnResult(int passcount,int expected_passcount)
	{
		if(passcount==expected_passcount)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static void closeBannersAfterLogin(WebDriver driver) throws Exception
    {
    	Functions.closeBannersAfterLogin(driver);
    }
}
