//$Id$
package com.zoho.livedesk.client.CannedMessage;

import com.zoho.livedesk.*;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.remote.Augmenter;



import com.google.common.base.Function;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;

import com.zoho.livedesk.util.common.CommonUtil;

import com.zoho.livedesk.client.AAgentsSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import java.util.Hashtable;

import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.CommonWait;

import com.aventstack.extentreports.ExtentTest;
import com.zoho.livedesk.server.ConfManager;



public class CannedMessagesCommonFunctions
{

	public static void initiateChatInClientSide(WebDriver driver,String name,String email_id,String message) throws Exception
	{
		VisitorWindow.clickChatButton(driver);
		VisitorWindow.initiateChatVisTheme(driver,name,email_id,null,CannedMessagesModule.department,message,CannedMessagesModule.etest);
	}

    public static void clickVisitorOnline(WebDriver driver,String id) throws Exception
    {
    	CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","name_"+id),5);
    	CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","name_"+id));
    }	

	public static void clickAddCannedMessage(WebDriver driver) throws Exception
	{
		if(CommonUtil.elfinder(driver,"id","rightcontainer").getText().contains("No canned messages found"))
		{
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath","//span[contains(text(),'Add Canned Messages')]"));			
		}
		else
		{
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","cmsgbtn"));
		}
		Tab.waitForLoadingLine(driver);
		CommonUtil.waitTillTextFound(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"Compose message");
	}

	public static boolean checkComposeMessage(WebDriver driver,ExtentTest etest) throws Exception
	{ 
		int passcount=0;

		if(CommonUtil.isTextFound(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),"Compose message"))
		{
			etest.log(Status.PASS,"Compose message header was found in add new canned message tab");
			passcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Compose message header was NOT found in add new canned message tab");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(passcount==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static boolean checkSaveButtonAndCancelButtonInAddCanned(WebDriver driver,ExtentTest etest) throws Exception
	{
		int passcount=0;
		if(CommonUtil.isTextFound(driver,CommonUtil.elfinder(driver,"id","btnsubmit"),"Save"))
		{
			etest.log(Status.PASS,"Save button was found in add new canned message tab");
			passcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Save button was NOT found in add new canned message tab");		
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");	
		}

		if(CommonUtil.isTextFound(driver,CommonUtil.elfinder(driver,"id","btncancel"),"Cancel"))
		{
			etest.log(Status.PASS,"Cancel button was found in add new canned message tab");
			passcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Cancel button was NOT found in add new canned message tab");		
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");	
		}

		if(passcount==2)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static void sendTextToComposeMessageTextArea(WebDriver driver,String message) throws Exception
	{
		CommonUtil.elfinder(driver,"id","cmsg").clear();
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.elfinder(driver,"id","cmsg"),message);	
	}

	public static boolean checkDynamicTextSuggestionsDisplayed(WebDriver driver) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","cmsgauto"),3);
		return CommonUtil.elfinder(driver,"id","cmsgauto").isDisplayed();
	}

	public static void createNewCannedMessage(WebDriver driver,String message,String category) throws Exception
	{
		sendTextToComposeMessageTextArea(driver,message);
		if(category!=null)
		{
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","toggle"));
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","addtxtbox"),3);
			CommonUtil.sendKeysToWebElement(driver,CommonUtil.elfinder(driver,"id","addtxtbox"),category);			
		}
		CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"id","btnsubmit"));
		try
		{
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","ldngtxt"),3);
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","ldngtxt"),3);			
		}
		catch(Exception e)
		{

		}
	}

	public static boolean checkCannedMessagePresentInList(WebDriver driver,String expected_text) throws Exception
	{
//		try
//		{
//			CommonUtil.waitTillWebElementDisplayed(driver,driver.findElement(By.xpath("//*[contains(@class,'cmn_wordbr') and contains(text(),'"+expected_text+"')]")),5);
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
		expected_text=expected_text.toLowerCase();

		String actual_text="";

		List<WebElement> canned_messages = driver.findElements(By.className("cmn_wordbr"));
		for(WebElement canned_message : canned_messages)
		{
			actual_text=canned_message.getText().toLowerCase();

			if(actual_text.contains(expected_text))
			{																																							
				return true;
			}
		}

		return false;
	}

	public static boolean clickCannedMessagePresentInList(WebDriver driver,String expected_text) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"xpath","//*[contains(@class,'cmn_wordbr') and contains(text(),'"+expected_text+"')]"),5);

		String actual_text="";

		List<WebElement> canned_messages = driver.findElements(By.className("list_cell"));

		for(WebElement canned_message : canned_messages)
		{
			actual_text=canned_message.getText();
			if(actual_text.contains(expected_text))
			{			
					CommonUtil.inViewPort(canned_message);
					Actions actions = new Actions(driver);
					actions.moveToElement(canned_message);
					actions.moveToElement(canned_message).click().build().perform();
					return true;					
			}
		}

		return false;
	}


	public static void waitTillChatTextAreaIsDisplayed(WebDriver driver) throws Exception
	{		
		try
		{
			FluentWait wait=CommonUtil.waitreturner(driver,10,250);

			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
  
			  		List <WebElement> textEditors=driver.findElements(By.id("txteditor"));
					Actions actions = new Actions(driver);
					for(WebElement txteditor : textEditors)
					{
						if(txteditor.isDisplayed())
						{
							return true;						
						}
					}
                  return false;
                }
            });

		}
		catch(Exception e)
		{
			e.printStackTrace();			
		}

	}

	public static void sendTextToChatTextArea(WebDriver driver,String message) throws Exception
	{
		waitTillChatTextAreaIsDisplayed(driver);

		List <WebElement> textEditors=driver.findElements(By.id("txteditor"));
		Actions actions = new Actions(driver);
		for(WebElement txteditor : textEditors)
		{
			if(txteditor.isDisplayed())
			{
				actions.moveToElement(txteditor).click().build().perform();
				actions.moveToElement(txteditor).sendKeys(message).build().perform();
				Thread.sleep(50);
			}
		}
	}

	public static WebElement getActiveChatTextArea(WebDriver driver)
	{
		List <WebElement> textEditors=driver.findElements(By.id("txteditor"));
		Actions actions = new Actions(driver);
		for(WebElement txteditor : textEditors)
		{
			if(txteditor.isDisplayed())
			{
				return txteditor;
			}
		}

		return null;
	}

	public static WebElement getActiveCannedMessageSuggestions(WebDriver driver)
	{
		List <WebElement> textEditors=driver.findElements(By.xpath("//*[contains(@class,'candmsgbx') and contains(@class,'hybridbx')]"));
		Actions actions = new Actions(driver);
		for(WebElement txteditor : textEditors)
		{
			if(txteditor.isDisplayed())
			{
				return txteditor;
			}
		}

		return null;
	}

	public static void clearChatTextArea(WebDriver driver) throws Exception
	{
		waitTillChatTextAreaIsDisplayed(driver);

		Thread.sleep(500);

		List <WebElement> textEditors=driver.findElements(By.id("txteditor"));
		Actions actions = new Actions(driver);
		for(WebElement txteditor : textEditors)
		{
			if(txteditor.isDisplayed())
			{
                txteditor.clear();
                Thread.sleep(500);
                txteditor.sendKeys(Keys.ESCAPE);
                break;
			}
		}
	}


	public static boolean checkCannedMessageSuggestionForCannedMessage(WebDriver driver,String canned_message) throws Exception
	{
		try
		{
			return CommonUtil.isTextFound(driver,getActiveCannedMessageSuggestions(driver),canned_message);
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public static void editOrDeleteCannedMessage(WebDriver driver,String canned_message,String action,String new_canned_message) throws Exception
	{
		String button_xpath=(action=="edit")?("//div[contains(@onclick,'edit') and contains(text(),'Edit')]"):("//*[@id='btncancel']");
		clickCannedMessagePresentInList(driver,canned_message);
		CommonUtil.waitTillTextFound(driver,CommonUtil.elfinder(driver,"id","rightcontainer"),canned_message);
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"xpath",button_xpath),5);
		CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath",button_xpath));

		if(action.contains("delete"))
		{
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","okbtn"),3);
			CommonUtil.clickWebElement(driver,By.id("okbtn"));
			Thread.sleep(1000);
		}

		if(action.contains("edit"))
		{
			createNewCannedMessage(driver,new_canned_message,"Automation");
		}
	}

	public static void editCannedMessage(WebDriver driver,String canned_message,String new_canned_message) throws Exception
	{
		editOrDeleteCannedMessage(driver,canned_message,"edit",new_canned_message);
	}

	public static void deleteCannedMessage(WebDriver driver,String canned_message) throws Exception
	{
		editOrDeleteCannedMessage(driver,canned_message,"delete","");
	}

	public static boolean checkDepartment(WebDriver driver,String expected_department)
	{
		return CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("dept"))).getText().contains(expected_department);
	}

	public static boolean checkOwner(WebDriver driver,String expected_owner)
	{
		List<WebElement> info_items = driver.findElements(By.className("cndmsgmn"));

		for(WebElement ele : info_items)
		{
			if(ele.getText().contains("Created") && ele.getText().contains(expected_owner))
			{
				return true;
			}
		}

		return false;
	}

	public static void clickCannedMessageButtonInChat(WebDriver driver) throws Exception
	{
		CommonUtil.clickWebElement(driver,CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("cwincannedmsg"))));
	}

	public static boolean checkCannedMessageListInChat(WebDriver driver) throws Exception
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("cannedmsglist")))!=null)
                    {
                        return true;
                    }
                    return false;
                }
            });

            if(CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("cannedmsglist")))!=null)
            {
            	return true;
            }

		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		return false;
	}

	public static boolean checkCannedMessageSearchDisplayed(WebDriver driver) throws Exception
	{
		FluentWait wait=CommonUtil.waitreturner(driver,5,250);
		try
		{
			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                    if(CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("searchcmessage")))!=null)
                    {               
                        return true;
                    }
                    return false;
                }
            });

           if(CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("searchcmessage")))!=null)
            {               
                return true;
            }

		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}

		return false;
	}

	public static void clickCannedMessageFromListInChat(WebDriver driver,String canned_message) throws Exception
	{
		WebElement ele=CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("cannedmsglist"))).findElement(By.xpath(".//a[contains(@onclick,'setCannedMessage') and contains(text(),'"+canned_message+"')]"));
		CommonUtil.inViewPort(ele);
		CommonUtil.clickWebElement(driver,ele);		
	}

	public static boolean checkMessagePresentInChatTextArea(WebDriver driver,String message) throws Exception
	{
		try
		{
			return CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("txteditor"))).getAttribute("value").toString().contains(message);		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}


	public static boolean isMessageAppendedInUserSide(WebDriver driver,final String message) throws Exception
	{
		String user_name="";//to not check for user name and only check for message
		return ChatWindow.checkLastMessageInUserWindow(driver,user_name,message);
	}

	public static void sendEnterKeyInChatTextArea(WebDriver driver) throws Exception
	{
		CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("txteditor"))).sendKeys(Keys.RETURN);
	}

	public static void sendEscapeKeyInChatTextArea(WebDriver driver) throws Exception
	{
		CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("txteditor"))).sendKeys(Keys.ESCAPE);
	}


	public static void searchCannedMessage(WebDriver driver,String canned_message) throws Exception
	{
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("searchcmessage"))),canned_message);
	}

	public static boolean checkSearchIsHighlighted(WebDriver driver,String sub_canned_message) throws Exception
	{
		try
		{
			List<WebElement> highlgt_searchres = CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.id("cannedmsglist"))).findElements(By.className("searchres_highlight"));
			for(WebElement ele : highlgt_searchres)
			{
				if(ele.getText().equals(sub_canned_message))
				{
					return true;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static boolean checkCannedMessageListFromInput(WebDriver driver) throws Exception
	{
		Thread.sleep(1000);
		try
		{

			if(CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.xpath("//ul[contains(@class,'candmsgcnt') and contains(@id,'hybdrdact')]"))).isDisplayed() && CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.xpath("//ul[contains(@class,'candmsgcnt') and contains(@id,'hybdrdact')]"))).getText().contains("No canned")==false)
			{
				return true;
			}
			else
			{
				return false;
			}					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static void clickCannedMessageFromInput(WebDriver driver,String canned_message) throws Exception
	{
		WebElement canned_message_list=CommonUtil.getVisibileWebElementFromList(driver,driver.findElements(By.xpath("//ul[contains(@class,'candmsgcnt') and contains(@id,'hybdrdact')]")));	
		List<WebElement> canned_messages=canned_message_list.findElements(By.tagName("li"));
		for(WebElement ele : canned_messages)
		{
			if(ele.getText().contains(canned_message))
			{
				CommonUtil.inViewPort(ele);
				CommonUtil.clickWebElement(driver,ele);
				break;				
			}
		}
	}

	public static void sendTextToTilesUIChat(WebDriver driver,String id,String message) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","textarea_"+id),3);
		CommonUtil.sendKeysToWebElement(driver,CommonUtil.elfinder(driver,"id","textarea_"+id),message);
	}

	public static void sendEnterKeyToTilesUIChat(WebDriver driver,String id) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","textarea_"+id),3);
		CommonUtil.elfinder(driver,"id","textarea_"+id).sendKeys(Keys.RETURN);
	}

	public static void sendEscapeKeyToTilesUIChat(WebDriver driver,String id) throws Exception
	{
		CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elfinder(driver,"id","textarea_"+id),3);
		CommonUtil.elfinder(driver,"id","textarea_"+id).sendKeys(Keys.ESCAPE);
	}


	public static boolean checkTextInTilesUIChat(WebDriver driver,String id,String expected_text) throws Exception
	{
		if(CommonUtil.elfinder(driver,"id","textarea_"+id).getAttribute("value").contains(expected_text))
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	public static boolean checkCannedMessageSuggestionDisplayedTilesUI(WebDriver driver,String id) throws Exception
	{
		try
		{
			CommonUtil.waitTillWebElementDisplayed(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","canneddiv"+id),"classname","hasedrpdwn"),4);
			return CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","canneddiv"+id),"classname","hasedrpdwn").isDisplayed();		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static void clickCannedMessageFromSuggestionTilesUI(WebDriver driver,String id,String canned_message) throws Exception
	{
		List<WebElement> canned_messages=CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","canneddiv"+id),"classname","hasedrpdwn").findElements(By.tagName("li"));	
		for(WebElement ele : canned_messages)
		{
			if(ele.getText().contains(canned_message))
			{
				CommonUtil.inViewPort(ele);
				Thread.sleep(25);
				CommonUtil.clickWebElement(driver,ele);
				break;
			}
		}
	}

	public static boolean checkMessageAppendInTilesUIChat(WebDriver driver,final String id,final String msg) throws Exception
	{
		try
		{
			FluentWait wait=CommonUtil.waitreturner(driver,5,250);

			wait.until(new Function<WebDriver,Boolean>()
			{
                public Boolean apply(WebDriver driver)
                {
                  if(driver.findElement(By.id("chat_"+id)).findElements(By.className("msgbx")).get(driver.findElement(By.id("chat_"+id)).findElements(By.className("msgbx")).size()-1).getText().contains(msg))
                  {
                  	return true;
                  }
                  return false;
                }
            });

			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static void selectVisitorTabInChat(WebDriver driver,String visitor_name) throws Exception
	{
		if(driver.findElements(By.xpath("//ul[@id='lschatheader']//li[@class='sel']//*[contains(text(),'"+visitor_name+"')]")).size()!=1)
		{
			CommonUtil.clickWebElement(driver,CommonUtil.elfinder(driver,"xpath","//ul[@id='lschatheader']//*[contains(text(),'"+visitor_name+"')]"));
		}
	}

	public static boolean checkAllCannedMessages(WebDriver driver,Hashtable<Integer,String> key,Hashtable<String,String> expected_text,ExtentTest etest) throws Exception
	{
		int failcount=0;

//		String canned_message=driver.findElements(By.className("trans-msg")).get(driver.findElements(By.className("trans-msg")).size()-1).getText().toString().toLowerCase();

        String canned_message = ChatWindow.getLastMessageInUserWindow(driver,"visitor").getText().toLowerCase();
        
        System.out.println("checkAllCannedMessages<>"+canned_message+"<>");
        
		for(int i=0;i<key.size();i++)
		{			
			if(canned_message.contains(key.get(i)+":"+expected_text.get(key.get(i)).toLowerCase()))
			{
				etest.log(Status.PASS,"Dynamic text suggestion "+"%"+key.get(i)+"% is working as expected.");
			}
			else
			{
				failcount++;
				etest.log(Status.FAIL,"Dynamic text suggestion "+"%"+key.get(i)+"% is NOT working as expected("+expected_text.get(key.get(i))+").");
				TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
			}
		}

		if(canned_message.contains("smart.timenow:Morning".toLowerCase()) || canned_message.contains("smart.timenow:Afternoon".toLowerCase()) || canned_message.contains("smart.timenow:Night".toLowerCase()) || canned_message.contains("smart.timenow:Evening".toLowerCase()))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %smart.timenow% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %smart.timenow% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(canned_message.matches(".+visitor.id:\\d+.+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion visitor.id is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion visitor.id is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

        if(canned_message.matches(".+visitor.browser:.+"+expected_text.get("visitor.browser").toLowerCase()+".+") || canned_message.matches(".+visitor.browser:"+expected_text.get("visitor.browser")+".+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %visitor.browser% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %visitor.browser% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(canned_message.matches(".+screen.resolution:\\d+\\s\\*\\s\\d+.+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %screen.resolution% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %screen.resolution% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		String ip_matching_regex="(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";

		if(canned_message.matches(".+visitor\\.ip:"+ip_matching_regex+".+"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %visitor.ip% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %visitor.ip% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(canned_message.contains("visitor.referrer:https://www.google.co.in/"))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %visitor.referrer% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %visitor.referrer% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(canned_message.contains("search.engine:Google".toLowerCase()))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %search.engine% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %search.engine% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(canned_message.contains("web.embed.name:"+ExecuteStatements.getDefaultEmbedName(driver).toLowerCase()))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %web.embed.name% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %web.embed.name% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		if(canned_message.contains("visitor.department:"+ExecuteStatements.getSystemGeneratedDepartment(driver).toLowerCase()))
		{
			etest.log(Status.PASS,"Dynamic text suggestion %visitor.department% is working as expected.");
		}
		else
		{
			failcount++;
			etest.log(Status.FAIL,"Dynamic text suggestion %visitor.department% is NOT working as expected.");
			TakeScreenshot.screenshot(driver,etest,"Canned Messages","Failure","Operator window screenshot");		
		}

		return CommonUtil.returnResult(failcount);
	}
}
