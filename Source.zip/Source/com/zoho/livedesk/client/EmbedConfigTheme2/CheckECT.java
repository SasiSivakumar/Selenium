//$Id$
package com.zoho.livedesk.client.EmbedConfigTheme2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Finder;
import org.sikuli.script.Location;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import com.google.common.base.Function;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Action;
import com.zoho.livedesk.client.CannedMessage.CannedMessagesCommonFunctions;


public class CheckECT
{
    public static final By
    CONTINUE_CHAT_BUTTON=By.cssSelector("[documentclick=restartchat]");

    public static void checkChatWindowTheme(WebDriver driver, final String theme, final String value, Integer usecase,ExtentTest etest) throws Exception
    {
        for(int i = usecase;i<=(usecase+1);i++)
        {
            TestInitTheme2.result.put("EC"+i,false);
        }
        
        try
        {

            String embed=ExecuteStatements.getDefaultEmbedName(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);Thread.sleep(2000);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebElement themeDiv = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","em_stickers");
            
            CommonUtil.inViewPort(themeDiv);
            
            Websites.selectTheme(driver,themeDiv,theme,etest);
            
            FluentWait wait = CommonUtil.waitreturner(driver,3,250);
            
            final String headerText = Websites.chatWindowThemeName[Integer.parseInt(theme)];
            
            final WebElement header = CommonUtil.elfinder(driver,"id","themeid_header");
            
            CommonUtil.inViewPort(header);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            driver.switchTo().defaultContent();
            
            driver.switchTo().frame(CommonUtil.elfinder(driver,"id","previewframe"));
            
            final WebElement div = CommonUtil.elfinder(driver,"classname","zls-sptwndw");
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(div.getAttribute("embedtheme").equals(theme))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            driver.switchTo().defaultContent();

            WebElement nav = WebsitesTab.getMiddleNav(driver);
            WebElement colour = driver.findElement(By.id("usesamecolor"));
            if (colour.isDisplayed())
            {
                Websites.clickChatWidgetDefaultColour(driver,false,etest);
                String colourneedstoselect = "#7D89EA";
                Websites.clickChatWidgetColour(driver,colourneedstoselect,etest);
            }
            else
            {
                System.out.println("no need to select colour");
            }   
          
           /*String colour = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,nav,"id","embedcolorfield"),"classname","sel").getAttribute("color");
            
            String colourneedstoselect = "#7D89EA";

            if(colour.equals("#7D89EA"))
            {
                System.out.println("colour selected already");
            }
            else
            {
                Websites.clickChatWidgetDefaultColour(driver,false,etest);
                
                Websites.clickChatWidgetColour(driver,colourneedstoselect,etest);
            }*/

            Websites.clickSave(driver,etest);

            
            String themename = Websites.chatWindowThemeName[Integer.parseInt(theme)];
            WebElement CLogo = driver.findElement(By.id("CLOGO2"));
            CommonUtil.inViewPort(CLogo);
            String cname = CLogo.getAttribute("class");
            if(cname.contains("set_on"))
            {
            driver.findElement(By.id("CLOGO2")).click();
            Websites.clickSave(driver,etest);
            }
            else
            {
            System.out.println("Already company logo Disabled.");
            }

            CommonSikuli.findInWholePage(driver,CommonSikuli.getImageNameInpreviewwindow(themename),etest);

            CommonSikuli.findInWholePage(driver,CommonSikuli.getFooterImageNameInpreviewwindowcolour(themename),etest);
	       // CommonSikuli.findInWholePage(driver,"Close.png","UI33",etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            final WebElement header2 = CommonUtil.elfinder(driver,"id","themeid_header");
            
            CommonUtil.inViewPort(header2);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(header2.getText().equals(headerText))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            TestInitTheme2.result.put("EC"+(usecase),true);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            WebDriver visDriver = TestInitTheme2.visitor_driver_manager.getDriver(driver);
            
            try
            {
              VisitorWindow.createPage(visDriver,embedcode);
              VisitorWindow.clickChatButton(visDriver);
              VisitorWindow.switchToChatWidget(visDriver);

              FluentWait visitorwait = CommonUtil.waitreturner(visDriver,3,250);

              CommonSikuli.findInWholePage(visDriver,CommonSikuli.getImageName(themename),CommonSikuli.getKeyvalue(themename),etest);
              CommonSikuli.findInWholePage(visDriver,CommonSikuli.getFooterImageName(themename),CommonSikuli.getFooterKeyvalue(themename),etest);  //getFooterImageName

              String themeVW = VisitorWindow.getThemeInChatWidget(visDriver);

                if(themeVW.contains("embedtheme"+theme+".css") || themeVW.contains("newembedtheme.css"))
                {
                    TestInitTheme2.result.put("EC"+(usecase+1),true);
                    
                    etest.log(Status.INFO,"Checked in visitor site");
                }
                else
                {
                    etest.log(Status.FAIL,themeVW);
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckChatWindowTheme","Error");
                    return;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckChatWindowTheme","Error",e);
                return;
            }


            visDriver = TestInitTheme2.visitor_driver_manager.getDriver(driver);

            clickContinueChatThenMissChatAndCheckSubmitButton(driver,visDriver,etest,theme,null);

            CheckResponseMessages.checkResponseMessages(driver,usecase+2,etest);


            checkDragAndDropChatWindow(driver,etest,theme);
            checkMessageNotificationPreview(driver,etest,theme);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckChatWindowTheme","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
    }

    public static boolean clickContinueChatThenMissChatAndCheckSubmitButton(WebDriver driver,WebDriver visitor_driver,ExtentTest etest,String theme,String size) throws Exception
    {
        int failcount=0;

        String label=CommonUtil.getUniqueMessage();

        final String
        visitor_name="V"+label,
        visitor_mail=visitor_name+"@mail.com",
        department=ExecuteStatements.getSystemGeneratedDepartment(driver),
        visitor_question="Q"+label;

        String embed=ExecuteStatements.getDefaultEmbedName(driver);
        String widget_code=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

        String image_name=getSubmitButtonImageName(theme);

        try
        {
            Hashtable<String,String> visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,department,visitor_question,"fb"+label,"3");

            ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

            VisitorWindow.endChatVisitor(visitor_driver);

            CommonSikuli.findInWholePage(visitor_driver,image_name,getSubmitButtonUseCase(theme),etest);

            VisitorWindow.enterFeedbackInTheme(visitor_driver,visitor_details.get(ConversationViewConstants.VISITOR_FEEDBACK),visitor_details.get(ConversationViewConstants.VISITOR_RATING));

            VisitorWindow.switchToChatWidget(visitor_driver);

            WebElement continue_chat=CommonUtil.getElement(visitor_driver,CONTINUE_CHAT_BUTTON);


            if(CommonWait.isDisplayed(continue_chat))
            {
                etest.log(Status.PASS,"Continue chat button was displayed after chat was ended.");
            }
            else
            {
                failcount++;
                etest.log(Status.FAIL,"Continue chat button was NOT displayed after chat was ended");
                TakeScreenshot.screenshot(driver,etest);
            }

            etest.log(Status.INFO,"Now clicking 'Continue chat' button and missing the chat");

            VisitorWindow.continueChat(visitor_driver);
            // continue_chat.click();

            CommonWait.waitTillHidden(continue_chat);
            // VisitorWindow.waitTillChatisMissedInTheme(visitor_driver);

            // CommonSikuli.findInWholePage(visitor_driver,image_name,getSubmitButtonUseCase(theme,size),etest);

            Driver.quitDriver(visitor_driver);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            TakeScreenshot.screenshot(driver,etest,e);
            TakeScreenshot.screenshot(visitor_driver,etest,e);
        }

        return CommonUtil.returnResult(failcount);
    }

    public static String getSubmitButtonUseCase(String theme)
    {
        if(theme.equals("4"))
        {
            return "EC1239";
        }
        else if(theme.equals("8"))
        {
            return "EC1244";
        }
        else if(theme.equals("9"))
        {
            return "EC1245";
        }
        else if(theme.equals("10"))
        {
            return "EC1246";
        }

        throw new ZohoSalesIQRuntimeException("Invalid use case. theme : "+theme);
    }

    public static String getSubmitButtonImageName(String theme)
    {
        String theme_name=Websites.chatWindowThemeName[Integer.parseInt(theme)];
        // String size_name=Websites.sizeName[Integer.parseInt(size)];

        if(theme_name.equals("Lloyd"))
        {
            return "submitlyod.png";
        }
        if(theme_name.equals("Crayon"))
        {
            return "submitcrayon.png";
        }

        return "submit.png";
    }

    public static void checkDragAndDropChatWindow(WebDriver driver,ExtentTest etest,String theme) throws Exception
    {
        String embed=ExecuteStatements.getDefaultEmbedName(driver);
        String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

        WebDriver visitor_driver = TestInitTheme2.visitor_driver_manager.getDriver(driver);

        driver=null;

        String theme_name=Websites.chatWindowThemeName[Integer.parseInt(theme)];

        theme_name = theme_name.replaceAll(" ","");

        String usecase_format="VisitorSide"+theme_name;
        String usecase=null;

        VisitorWindow.createPage(visitor_driver,embedcode);
        VisitorWindow.clickChatButton(visitor_driver);
        CommonUtil.sleep(5000);

        WebElement chat_window=VisitorWindow.getChatWindow(visitor_driver);
        String old_top_value=chat_window.getCssValue("top");
        String old_left_value=chat_window.getCssValue("left");

        VisitorWindow.switchToChatWidget(visitor_driver);
        
        WebElement element_to_drag=CommonUtil.getElement(visitor_driver,By.id("attname"));

        //drag and drop does not work in chat window when its done fast, so slowing the process
        for(int i=0;i<200;i++)
        {
            new Actions(visitor_driver).moveToElement(element_to_drag).clickAndHold().moveByOffset( -1, -1).release().perform();
        }

        TakeScreenshot.infoScreenshot(visitor_driver,etest);

        chat_window=VisitorWindow.getChatWindow(visitor_driver);
        String new_top_value=chat_window.getCssValue("top");
        String new_left_value=chat_window.getCssValue("left");

        usecase=usecase_format+"1";

        if(CommonUtil.isEquals(old_top_value,new_top_value)==false || CommonUtil.isEquals(old_left_value,new_left_value)==false)
        {
            etest.log(Status.PASS,"Chat window position was changed after it was dragged and dropped. (old top : "+old_top_value+" new top : "+new_top_value+" ), (old left : "+old_left_value+" new left : "+new_left_value+" )");
            TestInitTheme2.result.put(usecase,true);
        }
        else
        {
            TestInitTheme2.result.put(usecase,false);
            etest.log(Status.FAIL,"Chat window position was NOT changed after it was dragged and dropped. (old top : "+old_top_value+" new top : "+new_top_value+" ), (old left : "+old_left_value+" new left : "+new_left_value+" )");
            TakeScreenshot.screenshot(visitor_driver,etest);
        }

        usecase=usecase_format+"2";

        try
        {
            VisitorWindow.clickCloseChatWidget(visitor_driver);
            etest.log(Status.PASS,"Chat window was minimised after minimise button was clicked");
            TestInitTheme2.result.put(usecase,true);
        }
        catch(Exception e)
        {
            TestInitTheme2.result.put(usecase,false);
            etest.log(Status.FAIL,"Chat window was NOT minimised after minimise button was clicked");
            TakeScreenshot.screenshot(driver,etest,e);
        }

        usecase=usecase_format+"3";

        try
        {
            VisitorWindow.clickChatButton(visitor_driver);
            etest.log(Status.PASS,"Chat window was maximised after chat now button was clicked");
            TestInitTheme2.result.put(usecase,true);
        }
        catch(Exception e)
        {
            TestInitTheme2.result.put(usecase,false);
            etest.log(Status.FAIL,"Chat window was NOT maximised after chat now button was clicked");
            TakeScreenshot.screenshot(driver,etest,e);
        }

        usecase=usecase_format+"4";

        VisitorWindow.createPage(visitor_driver,embedcode);

        VisitorWindow.clickChatButton(visitor_driver);

        TakeScreenshot.infoScreenshot(visitor_driver,etest);

        chat_window=VisitorWindow.getChatWindow(visitor_driver);

        old_top_value=new_top_value;
        old_left_value=new_left_value;

        new_top_value=chat_window.getCssValue("top");
        new_left_value=chat_window.getCssValue("left");

        if( CommonUtil.checkStringEqualsAndLog(old_top_value,new_top_value,"top value",etest) && CommonUtil.checkStringEqualsAndLog(old_left_value,new_left_value,"left value",etest) )
        {
            etest.log(Status.PASS,"Chat window position was retained after page was reloaded. (old top : "+old_top_value+" new top : "+new_top_value+" ), (old left : "+old_left_value+" new left : "+new_left_value+" )");
            TestInitTheme2.result.put(usecase,true);
        }
        else
        {
            etest.log(Status.FAIL,"Chat window position was NOT retained after page was reloaded. (old top : "+old_top_value+" new top : "+new_top_value+" ), (old left : "+old_left_value+" new left : "+new_left_value+" )");
            TestInitTheme2.result.put(usecase,false);
            TakeScreenshot.screenshot(driver,etest);
        }
    }

    public static void checkMessageNotificationPreview(WebDriver driver,ExtentTest etest,String theme) throws Exception
    {
        String theme_name=Websites.chatWindowThemeName[Integer.parseInt(theme)];
        theme_name = theme_name.replaceAll(" ","");

        String usecase_format="VSMN"+theme_name;
        String usecase=null;

        String embed=ExecuteStatements.getDefaultEmbedName(driver);
        String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

        WebDriver visitor_driver = TestInitTheme2.visitor_driver_manager.getDriver(driver);


        try
        {
            String unique_id=com.zoho.livedesk.client.ChatHistory.ChatHistoryTests.quickChat(driver,visitor_driver,etest,embedcode,CommonUtil.getUniqueMessage());
            try
            {
                VisitorWindow.clickChatButton(visitor_driver);
            }
            catch(Exception e)
            {
                CommonUtil.doNothing();
            }
            ConversationViewCommonFunctions.openChatByUniqueId(visitor_driver,ChatType.COMPLETED,unique_id);

            String visitor_id=VisitorWindow.getVisitorId(visitor_driver,ExecuteStatements.getPortal(driver));
            Tab.clickVisitorsOnline(driver);
            CannedMessagesCommonFunctions.clickVisitorOnline(driver,visitor_id);
            CannedMessagesCommonFunctions.sendTextToTilesUIChat(driver,visitor_id,"Hello visitor");
            CannedMessagesCommonFunctions.sendEnterKeyToTilesUIChat(driver,visitor_id);

            usecase=usecase_format+"1";
            if(VisitorWindow.isCurrentChatDisplayed(visitor_driver))
            {
                etest.log(Status.PASS,"Current chat was displayed after agent initiated proactive chat");
                TestInitTheme2.result.put(usecase,true);
            }
            else
            {
                TestInitTheme2.result.put(usecase,false);
                etest.log(Status.FAIL,"Current chat was NOT displayed after agent initiated proactive chat");
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
            }

            ConversationViewCommonFunctions.goToAllChats(visitor_driver);        
            ConversationViewCommonFunctions.openChatByUniqueId(visitor_driver,ChatType.COMPLETED,unique_id);

            CannedMessagesCommonFunctions.sendTextToTilesUIChat(driver,visitor_id,"Hello visitor2");
            CannedMessagesCommonFunctions.sendEnterKeyToTilesUIChat(driver,visitor_id);
            TilesUI.closeTilesUI(driver,visitor_id);

            if(CommonWait.waitTillDisplayed(visitor_driver,By.id("convpopupmsg")))
            {
                etest.log(Status.PASS,"Conversation message popup was found");
            }

            WebElement message_notification=CommonUtil.getElement(visitor_driver,By.id("convpopupmsg"));

            CommonUtil.mouseHoverAndClick(visitor_driver,message_notification);


            usecase=usecase_format+"2";
            if(VisitorWindow.isCurrentChatDisplayed(visitor_driver))
            {
                etest.log(Status.PASS,"Current chat was displayed after proactive chat message notification was clicked by visitor");
                TestInitTheme2.result.put(usecase,true);
            }
            else
            {
                TestInitTheme2.result.put(usecase,false);
                etest.log(Status.FAIL,"Current chat was NOT displayed after proactive chat message notification was clicked by visitor");
                TakeScreenshot.screenshot(driver,etest);
                TakeScreenshot.screenshot(visitor_driver,etest);
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visitor_driver,etest,e);
            throw e;
        }
    }
}
