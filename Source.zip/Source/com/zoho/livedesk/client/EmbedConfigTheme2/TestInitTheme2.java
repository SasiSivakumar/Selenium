//$Id$
package com.zoho.livedesk.client.EmbedConfigTheme2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.DistributedTest;

public class TestInitTheme2 implements DistributedTest
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static String value=null;

    public static VisitorDriverManager visitor_driver_manager;

    public static String
    portal1=ConfManager.getRealValue("embed_config_chatwindow_theme_portal1"),
    portal2=ConfManager.getRealValue("embed_config_chatwindow_theme_portal2"),
    portal3=ConfManager.getRealValue("embed_config_chatwindow_theme_portal3");

    public static Hashtable usecase() throws Exception
    {
        value = (""+System.currentTimeMillis()).substring(4, 10);

        visitor_driver_manager = new VisitorDriverManager();

        TestInitTheme2 usecases = new TestInitTheme2();

        Distributor distributor = new Distributor(usecases,3);

        distributor.initiate();

        visitor_driver_manager.terminateAllDriverSessions();

        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public void startThread(int thread_number) throws Exception
    {
        WebDriver driver = Functions.setUp();

        ExtentTest etest=null;
        String[] themes={};

        if(thread_number==0)
        { 
            Functions.login(driver,"embed_config_chatwindow_theme1");
            themes=new String[] {"4"};
        }

        if(thread_number==1)
        {
            Functions.login(driver,"embed_config_chatwindow_theme2");
            themes=new String[] {"8"};
        }

        if(thread_number==2)
        {
            Functions.login(driver,"embed_config_chatwindow_theme3");
            themes=new String[] {"9","10"};
        }

        try
        {
            checkChatWindowTheme(driver,etest,themes);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorUser(s)Tab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","checkChatWindowTheme","Error",e);
            result.put("EC1", false);
        }

        String portal=ExecuteStatements.getPortal(driver);
        visitor_driver_manager.closeAllDrivers(portal);

        Functions.logout(driver);   
    }

    public static void checkChatWindowTheme(WebDriver driver,ExtentTest etest,String[] themes) throws Exception
    {
        if(themes==null)
        {
            themes=new String[] {"4","8","9","10"};
        }

        int usecaseStart = 901 + (Integer.parseInt(themes[0])-1)*50;//just to set result key value according to theme

        int i = usecaseStart;

        for(String s : themes)
        {
            etest=ComplexReportFactory.getTest("Check Chat window theme - "+Websites.chatWindowThemeName[Integer.parseInt(s)]);
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

            CheckECT.checkChatWindowTheme(driver,s,Websites.chatWindowThemeName[Integer.parseInt(s)],i,etest);

            ComplexReportFactory.closeTest(etest);

            i = i+50;
        }
    }
}
