//$Id$
package com.zoho.livedesk.client.GA;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class CommonFunctionsGA
{
    public static WebDriver login(WebDriver driver) throws Exception
    {
        driver = Functions.setUp();

        try
        {
            FluentWait wait2 = CommonUtil.waitreturner(driver, 30, 250);
        
            String url = "https://analytics.google.com/analytics/web/#realtime/rt-event/a98212254w144433307p149105732/";
            
            driver.get(url);
            Thread.sleep(3000);
            
            String username = "automationsalesiq@gmail.com";
            String password = "zohosalesiq";

            if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("<input id=\"Email\""))
            {
                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("Email")));
                driver.findElement(By.id("Email")).sendKeys(username);
                Thread.sleep(500);

                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("next")));
                driver.findElement(By.id("next")).click();
                Thread.sleep(1000);

                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("Passwd")));
                driver.findElement(By.id("Passwd")).sendKeys(password);
                Thread.sleep(500);

                wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("signIn")));
                driver.findElement(By.id("signIn")).click();
            }
            else
            {
                // wait2.until(ExpectedConditions.presenceOfElementLocated(By.id("identifierId")));
                // wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("identifierId")));
                // driver.findElement(By.id("identifierId")).sendKeys(username);
                // Thread.sleep(500);
                
                // wait2.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".RveJvd.snByac")));
                // wait2.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".RveJvd.snByac")));
                // driver.findElement(By.cssSelector(".RveJvd.snByac")).click();
                // Thread.sleep(1000);
                
                // wait2.until(ExpectedConditions.presenceOfElementLocated(By.name("password")));
                // wait2.until(ExpectedConditions.visibilityOfElementLocated(By.name("password")));
                // driver.findElement(By.name("password")).sendKeys(password);
                // Thread.sleep(500);
                
                // wait2.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".RveJvd.snByac")));
                // wait2.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".RveJvd.snByac")));
                // driver.findElement(By.cssSelector(".RveJvd.snByac")).click();

                CommonWait.waitTillDisplayed(driver,By.id("identifierId"));
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("identifierId")),username);

                CommonWait.waitTillDisplayed(driver,By.id("identifierNext"));
                CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("identifierNext")));

                CommonWait.waitTillDisplayed(driver,By.id("password"));
                CommonUtil.sendKeysToWebElement(driver,CommonUtil.getElement(driver,By.id("password"),By.cssSelector(".whsOnd.zHQkBf")),password);

                CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("passwordNext"),By.cssSelector(".ZFr60d.CeoRYc")));
            }
            
            Thread.sleep(5000);
            
            driver.get(url);
            
            Thread.sleep(6000);
        
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,GoogleAnalytics.etest,"GoogleAnalytics","Setup","Error",e);

            throw e;
        }

        return driver;
    }
    
    public static int getValue(WebDriver driver, String event) throws Exception
    {
        String v1 = getValue(driver, event, 1);
        
        if(v1.equals("No values"))
        {
            return 0;
        }
        else if(v1.equals("Event -"+event+"- not found in Sales IQ category"))
        {
            return 0;
        }
        else
        {
            return Integer.parseInt(v1);
        }
    }
    
    
    public static String getValue(WebDriver driver, String event, int i) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver, 30, 250);
            
            System.out.println("CommonFunctionsGA<>getValue<>Attempt<>"+i+"<>"+event+"<>");
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ID-eventPanel-Table")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ID-eventPanel-Table")));
            
            WebElement e = CommonUtil.elfinder(driver, "id", "ID-eventPanel-Table");
            
            List<WebElement> list = CommonUtil.elementfinder(driver, e, "tagname", "tbody").findElements(By.tagName("tr"));
            
            if(list.size() == 1 & list.get(0).getAttribute("innerHTML").contains("_GAcob"))
            {
                return "No values";
            }
            
            for(WebElement row : list)
            {
                List<WebElement> columns = row.findElements(By.className("_GAV8"));
                
                if(columns.get(0).getText().equals("Sales IQ") && columns.get(1).getText().equals(event))
                {
                    return CommonUtil.elementfinder(driver, row, "classname", "_GALM").getText();
                }
            }

            return "Event -"+event+"- not found in Sales IQ category";
        }
        catch(StaleElementReferenceException e)
        {
            if(i == 6)
            {
                throw e;
            }
            else
            {
                Thread.sleep(4000);
                
                return getValue(driver, event, i+1);
            }
        }
        catch(NullPointerException e)
        {
            if(i == 6)
            {
                throw e;
            }
            else
            {
                Thread.sleep(4000);
                
                return getValue(driver, event, i+1);
            }
        }
        catch(TimeoutException e)
        {
            System.out.println("CommonFunctionsGA<>getValue<>TimeoutException<>"+i+"<>"+event+"<>");
            e.printStackTrace();
            
            return "No values";
        }
    }

    public static int waitTillGettingExpectedValue(WebDriver driver, String event, int value) throws Exception
    {
        Long t1 = new Long(System.currentTimeMillis());

        while(true)
        {
            int i = getValue(driver, event);

            if(value == i)
            {
                return i;
            }

            Long t2 = new Long(System.currentTimeMillis());

            if(t2 - t1 >= 30000)
            {
                return i;
            }
        }
    }
}