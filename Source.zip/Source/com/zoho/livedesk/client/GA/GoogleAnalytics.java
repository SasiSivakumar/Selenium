//$Id$
package com.zoho.livedesk.client.GA;

import java.net.*;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.OtherAppsIntegration.CommonFunctionsOtherApps;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

public class GoogleAnalytics
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static ExtentTest etest;
    public static WebDriver visDriver = null;
    public static WebDriver gDriver = null;
    public static Set<WebDriver> visDrivers = new HashSet();
    public static Hashtable<String,Integer> lastValues = new Hashtable<String,Integer>();
    public static String portalname = "googleanalytics1";
    public static String embedname = "googleanalytics1";
//
    public static Hashtable gautil(WebDriver driver) throws Exception
    {
        try
        {
            gDriver = null;
            result = new Hashtable();
            visDrivers = new HashSet();
            lastValues = new Hashtable<String,Integer>();
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA1"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");

            Tab.navToIntegrationTab(driver);
            Integration.selectIntegApp(driver,"Google Analytics");
            
            result.put("GA1",true);

            gDriver = CommonFunctionsGA.login(gDriver);
            etest.log(Status.INFO,"GoogleAnalytics is present");
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA19"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");

            result.put("GA19",checkChatInitiate(driver,false,null,false));
            closeDrivers();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA20"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");

            result.put("GA20",checkChatInitiate(driver,true,false,false));
            closeDrivers();

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Integration enabled - Check Event while initiating chat and ending chat");
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");
            
            checkChatInitiate(driver,true,true,true);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA12"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");
            
            checkTrigger(driver,true,12);
            
            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA15"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");
            
            checkTrigger(driver,false,15);
            Trigger.deleteAllRule(driver,etest);Thread.sleep(3000);
            closeDrivers();

            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA11"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");
            
            result.put("GA11",checkMissed(driver));
            
            ComplexReportFactory.closeTest(etest);
            
//            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA10"));
//            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");
//            
//            result.put("GA10",checkVisitorChatEnded(driver));
//            
//            ComplexReportFactory.closeTest(etest);
            
            etest = ComplexReportFactory.getTest(KeyManager.getRealValue("GA18"));
            ComplexReportFactory.setValues(etest,"Automation","Google Analytics Integration");
            
            result.put("GA18",checkOfflineMessageSubmitted(driver));
            
            gDriver.get("https://accounts.google.com/Logout?service=analytics");Thread.sleep(4000);
            gDriver.quit();
            
            ComplexReportFactory.closeTest(etest);

        }
        catch(Exception e)
        {
            result.put("GA1", false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Setup","Error",e);
        }

        closeDrivers();
        
        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public static boolean checkChatInitiate(WebDriver driver, boolean enable, Boolean enableWebEmbed, boolean check) throws Exception
    {
        try
        {
            if(check)
            {    
                for(int i = 2; i<= 9;i++)
                {
                    result.put("GA"+(i),false);
                }
            }

            Tab.navToIntegrationTab(driver);
            Integration.selectIntegApp(driver,"Google Analytics");
            
            if(enable)
            {
                Integration.clickEnableIntegration(driver,"Google Analytics Integration enabled successfully",etest);
            }
            else
            {
                Integration.clickDisableIntegration(driver,"Google Analytics Integration disabled successfully",true,etest);
            }
            if(enableWebEmbed != null)
            {
                CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,true,embedname,enableWebEmbed);
            }

            visDriver = initializeDriver();

            try
            {
                String s[] = {"Button Clicked","Chat Initiated","Chat Connected"
                ,"Chat Ended","Rating Submitted","Feedback Submitted","Chat Minimized","Chat Mail sent"
                }; 

                for(String event : s)
                {
                    lastValues.put(event,CommonFunctionsGA.getValue(gDriver, event));
                }

                System.out.println(lastValues);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }

            try
            {
                createVisitorPage(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"Tester","test@test.com","12345","Question?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }

            ChatWindow.acceptChat(driver,etest);

            try
            {
                VisitorWindow.sentTranscriptInMail(visDriver,"test@test.com");

                VisitorWindow.infoInvisible(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }
            
            if(check)
            {
                Thread.sleep(15000);
            }

            ChatWindow.endAndCloseChat(driver);

            try
            {
                VisitorWindow.enterFeedbackInTheme(visDriver,"Feedback","4");

                VisitorWindow.clickCloseChatWidget(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }

            int i = 2;
            
            if(!(enable && enableWebEmbed))
            {
                Thread.sleep(15000);
            }

            try
            {
                String s[] = {"Button Clicked","Chat Initiated","Chat Connected"
                    ,"Chat Ended","Rating Submitted","Feedback Submitted","Chat Minimized","Chat Mail sent"
                };
                
                for(String event : s)
                {
                    int expected = (lastValues.get(event));

                    if(enable && enableWebEmbed)
                    {
                        expected += 1;
                    }
                    
                    int actual = CommonFunctionsGA.waitTillGettingExpectedValue(gDriver, event, expected);
                    if(expected == actual)
                    {
                        System.out.println("Success-"+event);
                        etest.log(Status.INFO,event+" is checked");
                        if(check)
                        {
                            result.put("GA"+(i++),true);
                        }
                        else
                        {
                            i++;
                        }
                    }
                    else
                    {
                        etest.log(Status.FAIL,event+" Mismatch content:Expected:"+expected+"--Actual:"+actual);
                        TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check"+event,"Error");
                    }
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }

            if(i == 10)
            {
                return true;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Check","Error",e);
        }

        return false;
    }

    public static boolean check(WebDriver driver) throws Exception
    {
        try
        {

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Check","Error",e);
        }

        return false;
    }

    public static void createVisitorPage(WebDriver visDriver) throws Exception
    {
        VisitorWindow.createPageGA(visDriver);
        
        VisitorWindow.getVisitorId(visDriver,portalname);
    }

    public static void closeDrivers() throws Exception
    {
        for(WebDriver driver : visDrivers)
        {
            try
            {
                driver.quit();
            }
            catch(Exception e)
            {}
        }
    }

    public static WebDriver initializeDriver() throws Exception
    {
        WebDriver driver = Functions.setUp();

        visDrivers.add(driver);

        return driver;
    }

    public static boolean checkMissed(WebDriver driver) throws Exception
    {
        try
        {
            Tab.navToIntegrationTab(driver);
            Integration.selectIntegApp(driver,"Google Analytics");
            
            Integration.clickEnableIntegration(driver,"Google Analytics Integration enabled successfully",etest);
            
            CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,true,embedname,true);
            
            visDriver = initializeDriver();

            try
            {
                String s[] = {"Chat Missed"}; 

                for(String event : s)
                {
                    lastValues.put(event,CommonFunctionsGA.getValue(gDriver, event));
                }

                System.out.println(lastValues);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }

            try
            {
                createVisitorPage(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"Tester","test@test.com","12345","Question?",etest);

                VisitorWindow.waitTillChatisMissedInTheme(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }

            try
            {
                String s[] = {"Chat Missed"}; 

                for(String event : s)
                {
                    int expected = (lastValues.get(event)) + 1;
                    int actual = CommonFunctionsGA.waitTillGettingExpectedValue(gDriver, event, expected);
                    
                    if(expected == actual)
                    {
                        System.out.println("Success-"+event);
                        etest.log(Status.INFO,event+" is checked");
                        return true;
                    }
                    else
                    {
                        etest.log(Status.FAIL,event+" Mismatch content:Expected:"+expected+"--Actual:"+actual);
                        TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check"+event,"Error");
                    }
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);

                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Check","Error",e);
        }

        return false;
    }
    
    public static boolean checkVisitorChatEnded(WebDriver driver) throws Exception
    {
        try
        {
            Tab.navToIntegrationTab(driver);
            Integration.selectIntegApp(driver,"Google Analytics");
            
            Integration.clickEnableIntegration(driver,"Google Analytics Integration enabled successfully",etest);
            
            CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,true,embedname,true);
            
            visDriver = initializeDriver();
            
            try
            {
                String s[] = {"Chat Ended by visitor"};
                
                for(String event : s)
                {
                    lastValues.put(event,CommonFunctionsGA.getValue(gDriver, event));
                }
                
                System.out.println(lastValues);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            try
            {
                createVisitorPage(visDriver);
                
                VisitorWindow.initiateChatVisTheme(visDriver,"Tester","test@test.com","12345","Question?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            ChatWindow.acceptChat(driver,etest);
            
            try
            {
                VisitorWindow.sentTranscriptInMail(visDriver,"test@test.com");
                
                VisitorWindow.infoInvisible(visDriver);
                
                VisitorWindow.endChatVisitor(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            try
            {
                String s[] = {"Chat Ended by visitor"};
                
                for(String event : s)
                {
                    int expected = (lastValues.get(event)) + 1;
                    int actual = CommonFunctionsGA.waitTillGettingExpectedValue(gDriver, event, expected);
                    
                    if(expected == actual)
                    {
                        System.out.println("Success-"+event);
                        etest.log(Status.INFO,event+" is checked");
                        return true;
                    }
                    else
                    {
                        etest.log(Status.FAIL,event+" Mismatch content:Expected:"+expected+"--Actual:"+actual);
                        TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check"+event,"Error");
                    }
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Check","Error",e);
        }
        
        return false;
    }
    
    public static boolean checkOfflineMessageSubmitted(WebDriver driver) throws Exception
    {
        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");
            
            Tab.navToIntegrationTab(driver);
            Integration.selectIntegApp(driver,"Google Analytics");
            
            Integration.clickEnableIntegration(driver,"Google Analytics Integration enabled successfully",etest);
            
            CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,true,embedname,true);
            
            visDriver = initializeDriver();
            
            try
            {
                String s[] = {"Offline Message Submitted"};
                
                for(String event : s)
                {
                    lastValues.put(event,CommonFunctionsGA.getValue(gDriver, event));
                }
                
                System.out.println(lastValues);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            try
            {
                createVisitorPage(visDriver);
                
                Long time = new Long(System.currentTimeMillis());
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321",null,"Q"+time,false,etest,true);
                
                VisitorWindow.getInfoMessage(visDriver);
                
                VisitorWindow.infoInvisible(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            try
            {
                String s[] = {"Offline Message Submitted"};
                
                for(String event : s)
                {
                    int expected = (lastValues.get(event)) + 1;
                    int actual = CommonFunctionsGA.waitTillGettingExpectedValue(gDriver, event, expected);
                    
                    if(expected == actual)
                    {
                        System.out.println("Success-"+event);
                        etest.log(Status.INFO,event+" is checked");
                        
                        try
                        {
                            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
                        }
                        catch(Exception excep)
                        {
                            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","ChangeStatus","Error",excep);
                        }
                        
                        return true;
                    }
                    else
                    {
                        etest.log(Status.FAIL,event+" Mismatch content:Expected:"+expected+"--Actual:"+actual);
                        TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check"+event,"Error");
                    }
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Check","Error",e);
            
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
            }
            catch(Exception excep)
            {
                TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","ChangeStatus","Error",excep);
            }
        }
        
        return false;
    }
    
    public static boolean checkTrigger(WebDriver driver, boolean proactive, int usecase) throws Exception
    {
        for(int i = 0; i<=2 ; i++)
        {
            result.put("GA"+(usecase+i),false);
        }
        
        try
        {
            Tab.navToIntegrationTab(driver);
            Integration.selectIntegApp(driver,"Google Analytics");
            
            Integration.clickEnableIntegration(driver,"Google Analytics Integration enabled successfully",etest);
            
            CommonFunctionsOtherApps.changeStatusOfWebEmbedInAnalytics(driver,true,embedname,true);
            
            if(!proactive)
            {
                Trigger.addTrigger(driver,etest,"Lands on my website","Visitor Type","is equal to","All",null,"Send chat invite","3 Seconds","Automation","Hey!!!");
                
                Thread.sleep(2000);
            }
            
            String id = null;
            
            visDriver = initializeDriver();
            
            try
            {
                String s[] = {"Chat Triggerred","Trigger Responded","Chat Initiated"};
                
                for(String event : s)
                {
                    lastValues.put(event,CommonFunctionsGA.getValue(gDriver, event));
                }
                
                System.out.println(lastValues);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            try
            {
                createVisitorPage(visDriver);
                
                id = VisitorWindow.getVisitorId(visDriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            if(proactive)
            {
                ChatWindow.initiateChat(driver,id,"hello");
            }
            
            try
            {
                VisitorWindow.sentMessageInTheme(visDriver,"hey!!!",true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"GoogleAnalytics","Check","Error",e);
                
                return false;
            }
            
            ChatWindow.acceptChat(driver,etest);
            
            Thread.sleep(3000);
            
            ChatWindow.endAndCloseChat(driver);
            
            int i = 0;
            
            try
            {
                String s[] = {"Chat Triggerred","Trigger Responded","Chat Initiated"};
                
                for(String event : s)
                {
                    int expected = (lastValues.get(event));
                    
                    if(!event.equals("Chat Initiated"))
                    {
                        expected += 1;
                    }
                    
                    int actual = CommonFunctionsGA.waitTillGettingExpectedValue(gDriver, event, expected);
                    
                    if(expected == actual)
                    {
                        System.out.println("Success-"+event);
                        etest.log(Status.INFO,event+" is checked");
                        
                        result.put("GA"+(usecase+i),true);
                    }
                    else
                    {
                        etest.log(Status.FAIL,event+" Mismatch content:Expected:"+expected+"--Actual:"+actual);
                        TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check"+event,"Error");
                    }
                    
                    i++;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(gDriver,etest,"GoogleAnalytics","Check","Error",e);
            }
            
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(2000);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"GoogleAnalytics","Check","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
        
        return false;
    }
}
