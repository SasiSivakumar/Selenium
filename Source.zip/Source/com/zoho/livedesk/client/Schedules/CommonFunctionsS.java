//$Id$
package com.zoho.livedesk.client.Schedules;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import java.net.URL;

import com.google.common.base.Function;
import com.zoho.qa.server.servlet.WebdriverApi;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonSikuli;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.CommonUtil;

public class CommonFunctionsS
{
    public static void clickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilS.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setting_sm_user")));
    }
    
    public static void navigateToAutomation(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        clickSettings(driver);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
        
        CommonUtilS.elfinder(driver,"id","setting_sm_automation").click();
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("automationcontent")));
    }

    public static void clickEmailScheduleTab(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoschedulertab")));
        WebElement e = CommonUtilS.elfinder(driver,"classname","autoschedulertab");
        e.click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.className("autotabcontainer")).findElement(By.className("autoschedulertab")).getAttribute("class").contains("sel"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void navigateToEmailScheduleTab(WebDriver driver) throws Exception
    {
        navigateToAutomation(driver);
        clickEmailScheduleTab(driver);
    }
        
    public static void clickAddSchedule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));


        Trigger.clickAddButtonAutomationTab(driver,"schedulertab");

        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
    }

    public static void clickScheduleInAddWindowAndDontWait(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("savedialog")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("savedialog")));
    
        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","savedialog");
        e.click();
    }

    public static void clickScheduleInAddWindow(WebDriver driver, int i) throws Exception
    {
        clickScheduleInAddWindowAndDontWait(driver);
        
        if(i == 0)
        {
            Tab.waitForLoading(driver,"addreportsscheduler.do",EmailSchedules.etest);
        }
        else
        {
            Tab.waitForLoading(driver,"updatereportsscheduler.do",EmailSchedules.etest);
        }
        
        waitTillDialogBoxGoesInvisible(driver);
    }

    public static void waitTillDialogBoxGoesInvisible(WebDriver driver) throws Exception
    {
        int i = 1;

        while(i++ <= 10)
        {
            try
            {
                clickEmailScheduleTab(driver);
                
                break;
            }
            catch(WebDriverException e)
            {
                if(i == 10)
                {
                    throw e;
                }
            }

            Thread.sleep(500);
        }
    }

    public static void clickCancelInAddWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("savedialog")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("savedialog")));
    
        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"css","div.cnfmbtm.mrgnlft_twenty");
        e.click();

        waitTillDialogBoxGoesInvisible(driver);
    }
    public static void clickCloseWindow(WebDriver driver) throws Exception
    {
        CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"classname","modal-header"),"classname","sqico-close").click();
        waitTillDialogBoxGoesInvisible(driver);
    }
    public static void clickccInAddWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("savedialog")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("savedialog")));
    
        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"css","a.ccemail.lvsundrlne");
        e.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccemailid")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ccemailid")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccemail")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ccemail")));
    }

    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilS.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_vhistory")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visits_div")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visits_div")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clicksetFavInAddVHList(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setfav")));
        CommonUtilS.elfinder(driver,"id","setfav").click();
    }

    public static void setNameForList(WebDriver driver,String favName) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fav_val")));
        CommonUtilS.elfinder(driver,"id","fav_val").click();
        CommonUtilS.elfinder(driver,"id","fav_val").sendKeys(favName);
    }

    public static void checkAlert(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
            
            Thread.sleep(1000);

            if(CommonUtilS.elfinder(driver,"id","popupdiv").isDisplayed())
            {
               wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                
                CommonUtilS.elfinder(driver,"id","okbtn").click();

                Thread.sleep(2000);
            }
        }
        catch(Exception e)
        {}
    }

    public static void clickAddView(WebDriver driver) throws Exception
    {
        
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("createlist")));
        
        CommonUtilS.elfinder(driver,"id","createlist").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return false;
                }
                return true;
            }
        });
    }

    public static void sendValuesPopUp(WebDriver driver,String vrow1,String vrow2,String vrow3) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        CommonUtilS.elfinder(driver,"id","prior1_col1_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("prior1_col1_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","prior1_col1_ddown"),"id","srchtxt"),"tagname","input").click();
        CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","prior1_col1_ddown"),"id","srchtxt"),"tagname","input").sendKeys(vrow1);
        
        WebElement elmtr1 = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","prior1_col1_ddown"),"tagname","ul");
        List<WebElement> elmtsr1 = elmtr1.findElements(By.tagName("li"));
        
        elmtsr1.get(0).click();
        
        CommonUtilS.elfinder(driver,"id","prior1_col2_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("prior1_col2_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmtr2 = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","prior1_col2_ddown"),"tagname","ul");
        List<WebElement> elmtsr2 = elmtr2.findElements(By.tagName("li"));
        
        for(WebElement ell:elmtsr2)
        {
            if(CommonUtilS.elementfinder(driver,ell,"tagname","span").getText().equals(vrow2))
            {
                CommonUtilS.elementfinder(driver,ell,"tagname","span").click();
            }
        }
        
        CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","prior1_col3"),"tagname","input").click();
        CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","prior1_col3"),"tagname","input").sendKeys(vrow3);
    }

    public static void clickSortList(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmpny_fltr_div")));
        CommonUtilS.elfinder(driver,"id","cmpny_fltr_div").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmt = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","cmpny_fltr_ddown"),"tagname","ul");
        List<WebElement> elmts = elmt.findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(ell.findElement(By.tagName("span")).getText().equals(ResourceManager.getRealValue("vhist_lvtime")))
            {
                ell.findElement(By.tagName("span")).click();
                break;
            }
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("cmpny_fltr_div")).findElement(By.tagName("span")).getAttribute("val").equals("LVTIME"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void applyRule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Apply']")));
        CommonUtilS.elfinder(driver,"xpath","//div[text()='Apply']").click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void addListInVH(WebDriver driver,String col1,String col2,String col3,boolean fav,String listname) throws Exception
    {
        clickVisitorHistory(driver);
        clickAddView(driver);
        sendValuesPopUp(driver,col1,col2,col3);
        clickSortList(driver);
        if(fav)
        {
            clicksetFavInAddVHList(driver);
        }
        setNameForList(driver,listname);
        applyRule(driver);
        checkAlert(driver);
    }

    public static void setToAllVis(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        clickSettings(driver);
        clickVisitorHistory(driver);
        
        driver.navigate().refresh();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("viewid-0")));
        
        CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","favdrpdown0"),"tagname","span").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0_div")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("favdrpdown0_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        WebElement elmt = CommonUtilS.elfinder(driver,"id","favdrpdown0_ddown");
        List<WebElement> elmts = elmt.findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(ell.findElement(By.tagName("span")).getText().equals("All Visitors"))
            {
                ell.findElement(By.tagName("span")).click();
                break;
            }
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("viewid-0")).getAttribute("viewid").equals("-1"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static boolean deleteListInVH(WebDriver driver,String listname) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        clickVisitorHistory(driver);
        
        Thread.sleep(2000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0")));
        
        CommonUtilS.elfinder(driver,"id","favdrpdown0").click();
        
        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("favdrpdown0_ddown")));
        
        WebElement elmt = CommonUtilS.elfinder(driver,"id","favdrpdown0_ddown");
        
        List<WebElement> elmts = CommonUtilS.elementfinder(driver,elmt,"tagname","ul").findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(CommonUtilS.elementfinder(driver,ell,"tagname","span").getText().equals(listname))
            {
                CommonUtilS.elementfinder(driver,ell,"classname","drop-tick").click();
                
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));
                
                CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"classname","lvd_popupsub"),"id","okbtn").click();
            }
        }
        
        clickSettings(driver);
        
        Thread.sleep(2000);
        
        clickVisitorHistory(driver);
        
        Thread.sleep(2000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0")));
        
        CommonUtilS.elfinder(driver,"id","favdrpdown0").click();
        
        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("favdrpdown0_ddown")));
        
        elmt = CommonUtilS.elfinder(driver,"id","favdrpdown0_ddown");
        
        elmts = CommonUtilS.elementfinder(driver,elmt,"tagname","ul").findElements(By.tagName("li"));
        
        for(WebElement ell:elmts)
        {
            if(CommonUtilS.elementfinder(driver,ell,"tagname","span").getText().equals(listname))
            {
                return false;
            }
        }
        return true;
    }

    public static WebElement getListFromDropdowninAddNewSchedule(WebDriver driver,String listname) throws Exception
    {
        WebElement e = null;

        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listdiv_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("listdiv_div")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listdiv_ddown")));

        if(!CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","listdiv_ddown").getAttribute("style").contains("block"))
        {
            CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","listdiv_div").click();
        }
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("listdiv_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        List<WebElement> list = CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","listdiv_ddown"),"tagname","ul").findElements(By.tagName("li"));
        
        for(WebElement element: list)
        {
            CommonUtilS.inViewPort(element);
            if(element.getText().equals(listname))
            {
                e = element;
                break;
            }
        }
        
        return e;
    }

    public static void clickListFromDropdowninAddNewSchedule(WebDriver driver,String listname) throws Exception
    {
        getListFromDropdowninAddNewSchedule(driver,listname).click();

        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("listdiv_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static WebElement getFrequencyFromDropdowninAddNewSchedule(WebDriver driver,String freq) throws Exception
    {
        WebElement e = null;

        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("schd_range_div")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("schd_range_div")));

        if(!CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","schd_range_ddown").getAttribute("style").contains("block"))
        {
            CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","schd_range_div").click();
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("schd_range_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        List<WebElement> list = CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","schd_range_ddown"),"tagname","ul").findElements(By.tagName("li"));
        
        for(WebElement element: list)
        {
            CommonUtilS.inViewPort(element);
            if(element.getText().equals(freq))
            {
                e = element;
                break;
            }
        }
        
        return e;
    }

    public static void clickFrequencyFromDropdowninAddNewSchedule(WebDriver driver,String freq) throws Exception
    {
        getFrequencyFromDropdowninAddNewSchedule(driver,freq).click();

        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("schd_range_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static String getFrequencyContentInBox(WebDriver driver) throws Exception
    {
        return CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","schd_range_div").getText();
    }

    public static String getFileType(WebDriver driver) throws Exception
    {
        String filetype = "";

        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rdfiletype")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdfiletype")));
    
        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","rdfiletype");

        List<WebElement> list = e.findElements(By.className("uprdowrap"));

        for(WebElement type : list)
        {
            if(CommonUtilS.elementfinder(driver,type,"tagname","span").getAttribute("class").contains("rdselected"))
            {
                filetype = CommonUtilS.elementfinder(driver,type,"tagname","input").getAttribute("id");
                break;
            }
        }
        return filetype;
    }

    public static void selectFileType(WebDriver driver,String type) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rdfiletype")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdfiletype")));
    
        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","rdfiletype"),"id",type);
        e.click();
    }

    public static String getClassNameForFileType(WebDriver driver,String type) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,10,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rdfiletype")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdfiletype")));
    
        WebElement e = null;

        List<WebElement> list =  CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","rdfiletype").findElements(By.className("uprdowrap"));
        
        for(WebElement r : list)
        {
            if(r.getText().contains(type))
            {
                e = CommonUtilS.elementfinder(driver,r,"tagname","span");
            }
        }

        return e.getAttribute("class");
    }
    public static String getNotesinAddNewSchedule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("connector")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("connector")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("connector")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        return CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","connector").getText();
    }

    public static void sendKeysfortoemail(WebDriver driver,String toemail) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("toemail")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("toemail")));

        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","toemail");

        e.click();
        e.clear();
        Thread.sleep(1000);
        e.sendKeys(toemail);
    }

    public static void sendKeysforccemail(WebDriver driver,String ccemail) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ccemail")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ccemail")));

        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","ccemail");

        e.click();
        e.clear();
        
        Thread.sleep(1000);
        e.sendKeys(ccemail);
    }

    public static String getSubject(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("subject")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("subject")));

        WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","subject");

        System.out.println("readonly:"+e.getAttribute("readonly"));

        if(e.getAttribute("readonly").equals("readonly") || e.getAttribute("readonly").equals("true"))
        {
            return e.getAttribute("value");
        }
        return "Subject is editable";
    }

    public static String getBodyContent(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        driver.switchTo().frame(CommonUtilS.elfinder(driver,"classname","ze_area"));

        WebElement e = CommonUtilS.elfinder(driver,"tagname","body");
        String bodyContent = e.getText();
        System.out.println(bodyContent);

        driver.switchTo().defaultContent();
        return bodyContent;
    }

    public static void setBodyContent(WebDriver driver,String content) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));

        driver.switchTo().frame(CommonUtilS.elfinder(driver,"classname","ze_area"));

        WebElement e = CommonUtilS.elfinder(driver,"tagname","body");
        e.click();
        e.clear();
        e.sendKeys(content);

        driver.switchTo().defaultContent();
    }

    public static void clickMyProfile(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilS.elfinder(driver,"partiallinktext","My Profile").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("My Profile"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

    public static String getUserName(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        clickMyProfile(driver,"My Profile");

        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
        WebElement elmt1 = CommonUtilS.elfinder(driver,"id","test");

        WebElement userdetails = CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,elmt1,"classname","usr-mrgntp"),"id","userdetails");
        
        return userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
    }

    public static String getSubjectFromList(WebDriver driver,WebElement e) throws Exception
    {
        return CommonUtilS.elementfinder(driver,e,"css","span.txtelips.dsply_inblk").getText();
    } 

    public static String getScheduleContentInLists(WebDriver driver,WebElement e) throws Exception
    {
        String s = "";

        s = getSubjectFromList(driver,e);

        s += "#"+CommonUtilS.elementfinder(driver,e,"css","div.list_cell.txtelips").getText();

        s += "#"+CommonUtilS.elementfinder(driver,e,"css","div.list_cell.txtelips.schfrq").getText();

        s += "#"+CommonUtilS.elementfinder(driver,e,"css","div.list_cell.txtelips.schcrby").getText();

        return s;
    } 

    public static String getScheduleContentInUpdate(WebDriver driver) throws Exception
    {
        String s = "";

        s = getSubject(driver);

        s += "#"+getBodyContent(driver);

        s += "#"+getFrequencyContentInBox(driver);

        s += "#"+getFileType(driver);

        System.out.println("Contents in Update Schedule Window:"+s);

        return s;
    } 

    public static WebElement lastScheduleInList(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        navigateToEmailScheduleTab(driver);

        List<WebElement> list = CommonUtilS.elfinder(driver,"id","schedulerwrap").findElements(By.className("list-row"));

        return list.get(list.size()-1);
    }

    public static void clickEdit(WebDriver driver) throws Exception
    {
        clickEdit(driver,lastScheduleInList(driver));
    }

    public static void clickEdit(WebDriver driver,WebElement e) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        CommonUtilS.mouseOver(driver,e);

        CommonSikuli.findInWholePage(driver,"Scheduleedit.png","UI242",EmailSchedules.etest);

        CommonUtilS.elementfinder(driver,e,"css","em.list_lefticon.list_editicon.schedit").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dlgbox")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dlgbox")));
    }

    public static boolean clickEnable(WebDriver driver) throws Exception
    {
        return clickEnable(driver,lastScheduleInList(driver));
    }

    public static boolean clickEnable(WebDriver driver,final WebElement e) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        System.out.println("Schedule class name:"+e.getAttribute("class"));

        if(e.getAttribute("class").contains("list_enable"))
        {
            return true;
        }

        CommonSikuli.findInWholePage(driver,"Scheduledisable.png","UI244",EmailSchedules.etest);

        CommonUtilS.elementfinder(driver,e,"classname","scrstatus_enb").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e.getAttribute("class").contains("list_enable"))
                {
                    return true;
                }
                return false;
            }
        });

        Tab.waitForLoading(driver,"updatereportsschedulerstatus.do",EmailSchedules.etest);
        
        return true;
    }

    public static boolean clickDisable(WebDriver driver) throws Exception
    {
        return clickDisable(driver,lastScheduleInList(driver));
    }

    public static boolean clickDisable(WebDriver driver,final WebElement e) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        System.out.println("Schedule class name:"+e.getAttribute("class"));

        if(e.getAttribute("class").contains("list_disable"))
        {
            return true;
        }

        CommonSikuli.findInWholePage(driver,"Scheduleenable.png","UI243",EmailSchedules.etest);

        CommonUtilS.elementfinder(driver,e,"classname","scrstatus_dsb").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(e.getAttribute("class").contains("list_disable"))
                {
                    return true;
                }
                return false;
            }
        });

        Tab.waitForLoading(driver,"updatereportsschedulerstatus.do",EmailSchedules.etest);

        return true;
    }

    public static boolean clickDelete(WebDriver driver,ExtentTest etest) throws Exception
    {
        return clickDelete(driver,lastScheduleInList(driver),etest);
    }

    public static boolean clickDelete(WebDriver driver,WebElement e,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

        String actual[] = {"header","desc","okbtn","cancelbtn"};

        for(int i = 0;i<actual.length;i++)
        {
            actual[i] = ResourceManager.getRealValue("delete_schedule_"+actual[i]);
        }

        actual[1] = actual[1].replace("$LIST$","\""+getSubjectFromList(driver,e)+"\"");

        final int initial = CommonUtilS.elfinder(driver,"id","schedulerwrap").findElements(By.className("list-row")).size();
        
        CommonSikuli.findInWholePage(driver,"Scheduledelete.png","UI245",EmailSchedules.etest);

        CommonUtilS.elementfinder(driver,e,"classname","deletescr").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("popupdiv")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("popupdiv")));

        final WebElement dialog = CommonUtilS.elfinder(driver,"id","popupdiv");

        String header = CommonUtilS.elementfinder(driver,dialog,"classname","lvd_popuptitle").getText();
        String desc = CommonUtilS.elementfinder(driver,dialog,"id","popupdesc").getText();
        String okbtn = CommonUtilS.elementfinder(driver,dialog,"id","okbtn").getText();
        String cancelbtn = CommonUtilS.elementfinder(driver,dialog,"id","cancelbtn").getText();
        
        String expected[] = {header,desc,okbtn,cancelbtn};
        
        for(int i = 0;i< 4;i++)
        {
            if(!actual[i].equals(expected[i]))
            {
                etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]);
                return false;
            }
        }

        CommonUtilS.elementfinder(driver,dialog,"id","okbtn").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!dialog.isDisplayed())
                {
                    return true;
                }
                return false;
            }
        });

        Tab.waitForLoading(driver,"deletereportsscheduler.do",EmailSchedules.etest);

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(initial-1 == 0)
                    {
                        WebElement e = driver.findElement(By.id("schedulerwrap"));
                        if(e.getText().contains(ResourceManager.getRealValue("no_schedule_header")))
                        {
                            return true;
                        }
                    }
                    else if(initial-1 == driver.findElement(By.id("schedulerwrap")).findElements(By.className("list-row")).size())
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });

        return true;
    }

    public static boolean checkContentInScheduleList(ExtentTest etest,String actual,String subject,String toemail,String frequency,String createdBy)
    {
        ArrayList<String> list = new ArrayList<String>(Arrays.asList(actual.split("#")));

        frequency = frequencyInList(frequency);

        String[] expected = {subject,toemail,frequency,createdBy};

        for(int i = 0;i < list.size();i++)
        {
            if(!list.get(i).equals(expected[i]))
            {
                etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+list.get(i));
                return false;
            }
        }

        return true;
    }

    public static String frequencyInList(String freq)
    {
        switch(freq)
        {
            case "Every day":return "Daily";
            case "day":return "Daily";
            case "Daily":return "Daily";
            case "Every week":return "Weekly";
            case "week":return "Weekly";
            case "Weekly":return "Weekly";
            case "Every month":return "Monthly";
            case "month":return "Monthly";
            case "Monthly":return "Monthly";
        }

        return "Cannot determine";
    }

    public static boolean checkContentInScheduleUpdate(ExtentTest etest,String actual,String subject,String bodyContent,String frequency,String type)
    {
        ArrayList<String> list = new ArrayList<String>(Arrays.asList(actual.split("#")));

        String[] expected = {subject,bodyContent,frequency,type};

        int count = expected.length;

        for(int i = 0;i < count;i++)
        {
            String expected_content=expected[i],actual_content=list.get(i);

            if(!CommonUtil.checkStringEqualsAndLog(expected_content,actual_content,"content",etest))
            {
                // etest.log(Status.FAIL,"Expected:"+expected_content+"--Actual:"+actual_content);
                return false;
            }
        }

        return true;
    }

    public static boolean addSchedule(WebDriver driver,ExtentTest etest,String listname,String toemail,boolean cc,String ccemail,boolean changeBody,String bodyContent,String frequency,String filetype,boolean checkInUpdate,boolean doActions,String actions,boolean edit,String toedit) throws Exception
    {
        String params = "";
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            navigateToEmailScheduleTab(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("schedulerwrap")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("schedulerwrap")));


            int initial = 0;
            WebElement e = CommonUtilS.elfinder(driver,"id","schedulerwrap");
            if(!e.getText().contains(ResourceManager.getRealValue("no_schedule_header")))
            {
                initial = e.findElements(By.className("list-row")).size();
            }
            
            clickAddSchedule(driver);

            clickListFromDropdowninAddNewSchedule(driver,listname);
            sendKeysfortoemail(driver,toemail);

            if(cc)
            {
                clickccInAddWindow(driver);
                sendKeysforccemail(driver,ccemail);
            }

            if(changeBody)
            {
                setBodyContent(driver,bodyContent);
            }
            else
            {
                bodyContent = EmailSchedules.bodyContent;
            }

            clickFrequencyFromDropdowninAddNewSchedule(driver,frequency);
            selectFileType(driver,filetype);
            clickScheduleInAddWindow(driver,0);

            final int finalcount = initial+1;

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(finalcount == driver.findElement(By.id("schedulerwrap")).findElements(By.className("list-row")).size())
                        {
                            return true;
                        }
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            //WebElement schedule = lastScheduleInList(driver);

            boolean inList = checkContentInScheduleList( etest, getScheduleContentInLists(driver,lastScheduleInList(driver)),"List of "+listname, toemail, frequency,EmailSchedules.username);
        
            if(!inList)
            {
                TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddSchedule","ScheduleIsNotListed");
                return false;
            }

            if(checkInUpdate)
            {
                clickEdit(driver);

                if(!checkContentInScheduleUpdate(etest,getScheduleContentInUpdate(driver),"List of "+listname,bodyContent,frequency,filetype))
                {
                    TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddSchedule","MismatchContentInUpdateWindow");
                    clickCloseWindow(driver);
                    return false;
                }

                clickCloseWindow(driver);
            }
            else if(edit)
            {
                clickEdit(driver);
                toedit(driver,toedit);
                clickScheduleInAddWindow(driver,1);

                String check = "";

                if(toedit.contains("Every"))
                {
                    check = "frequency";
                }
                else if(toedit.equals("xlsx") || toedit.equals("csv"))
                {
                    check = "filetype";
                }
                else if(toedit.contains("@"))
                {
                    check = "toemail";
                }
                else
                {
                    check = "bodyContent";
                }
                switch(check)
                {
                    case "filetype":
                    {
                        filetype = toedit;
                        break;
                    }

                    case "frequency":
                    {
                        frequency = toedit;
                        break;
                    }

                    case "toemail":
                    {
                        toemail = toedit;
                        break;
                    }

                    case "bodyContent":
                    {
                        bodyContent = toedit;
                        break;
                    }
                }

                inList = checkContentInScheduleList( etest, getScheduleContentInLists(driver,lastScheduleInList(driver)),"List of "+listname, toemail, frequency,EmailSchedules.username);
                
                if(!inList)
                {
                    TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckEditedScheduleInList","Error");
                    return false;
                }

                clickEdit(driver);

                if(!checkContentInScheduleUpdate(etest,getScheduleContentInUpdate(driver),"List of "+listname,bodyContent,frequency,filetype))
                {
                    TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddSchedule","MismatchContentInUpdateWindow");
                    clickCloseWindow(driver);
                    return false;
                }

                clickCloseWindow(driver);
            }
            else if(doActions)
            {
                ArrayList<String> list = new ArrayList<String>(Arrays.asList(actions.split("/")));

                for(String s : list)
                {
                    if(!doActions(driver,s))
                    {
                        TakeScreenshot.screenshot(driver,etest,"EmailSchedules",s+"Schedule","Error");
                        driver.navigate().refresh();
                        Thread.sleep(3000);
                        return false;
                    }
                }
            }
            else
            {
                return true;
            }

            if(!clickDelete(driver,etest))
            {
                TakeScreenshot.screenshot(driver,etest,"EmailSchedules","DeleteSchedule","MismatchContent");
                driver.navigate().refresh();
                Thread.sleep(3000);
                return false;
            }
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddSchedule","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean doActions(WebDriver driver,String action) throws Exception
    {
        switch(action)
        {
            case "enable":return clickEnable(driver);
            case "disable":return clickDisable(driver);
        }

        return false;
    }

    public static void toedit(WebDriver driver,String toedit) throws Exception
    {
        String check = "";

        if(toedit.contains("Every"))
        {
            check = "frequency";
        }
        else if(toedit.equals("xlsx") || toedit.equals("csv"))
        {
            check = "filetype";
        }
        else if(toedit.contains("@"))
        {
            check = "toemail";
        }
        else
        {
            check = "bodyContent";
        }
        switch(check)
        {
            case "filetype":
            {
                selectFileType(driver,toedit);
                break;
            }

            case "frequency":
            {
                clickFrequencyFromDropdowninAddNewSchedule(driver,toedit);
                break;
            }

            case "toemail":
            {
                sendKeysfortoemail(driver,toedit);
                break;
            }

            case "bodyContent":
            {
                setBodyContent(driver,toedit);
                break;
            }
        }
    }

    public static boolean checkRichtoPlainAlert(WebDriver driver)
    {
        try
        {
            driver.switchTo().alert();
            return true;
        }
        catch(Exception e)
        {}
        return false;
    }

    public static boolean checkRich(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","vstactiondlg_smailcont");

            List<WebElement> list = e.findElements(By.className("ze_multitoolbar"));

            int i = 0;

            for(WebElement element : list)
            {
                i++;

                if(element.getAttribute("style").contains("none"))
                {
                    System.out.println("Error while checking presence of rich text for element"+i+":"+element.getAttribute("style"));
                    return false;
                }
            }
            
            WebElement frame = CommonUtilS.elementfinder(driver,e,"css","iframe.ze_area");
            
            if(!frame.getAttribute("style").contains("none"))
            {
                return true;
            }
            System.out.println("Error while checking presence of rich text for element:"+frame.getAttribute("style"));
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking presence of rich text");
            e.printStackTrace();
        }

        return false;
    }

    public static boolean checkPlain(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","dlgbox"),"id","vstactiondlg_smailcont");

            List<WebElement> list = e.findElements(By.className("ze_multitoolbar"));

            int i = 0;

            for(WebElement element : list)
            {
                i++;

                if(element.getAttribute("style").contains("none"))
                {
                    continue;
                }
                System.out.println("Error while checking presence of plain text for element"+i+":"+element.getAttribute("style"));
                return false;
            }
            
            WebElement frame = CommonUtilS.elementfinder(driver,e,"css","iframe.ze_area");
            
            if(frame.getAttribute("style").contains("none"))
            {
                return true;
            }
            System.out.println("Error while checking presence of plain text for element:"+frame.getAttribute("style"));
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking presence of plain text");
            e.printStackTrace();
        }

        return false;
    }

}
