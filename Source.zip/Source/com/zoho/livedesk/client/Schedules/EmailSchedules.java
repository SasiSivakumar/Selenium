//$Id$
package com.zoho.livedesk.client.Schedules;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import com.zoho.livedesk.util.common.CommonWait;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.client.visitorhistory.View;
import com.zoho.livedesk.util.common.actions.HandleCommonUI;

public class EmailSchedules
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static ExtentTest etest;
    public static String username = "";
    public static String bodyContent = "";
    public static String toemail1 = "",toemail2 = "";


    public static final By
    VISITOR_HISTORY_DROPDOWN_BUTTON=By.id("favdrpdown0"),
    VISITOR_HISTORY_DROPDOWN=By.id("favdrpdown0_ddown"),
    VISITOR_HISTORY_DELETE_ICON_CLASS_NAME=By.className("drop-tick");

    
    public static Hashtable schedule(WebDriver driver) throws Exception
    {
        try
        {
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES1"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            username = CommonFunctionsS.getUserName(driver);
            bodyContent = "Dear "+username+",\n\nThe Visitors Report has been generated and attached below. \n\nRegards,\nTeam SalesIQ";
            toemail1 = "rajkumar.natarajan+automation@zohocorp.com";
            toemail2 = "rajkumar.natarajan+automation1@zohocorp.com";

            etest.log(Status.PASS,"Checked");

            result.put("ES1",true);
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES2"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES2",isPageAvail(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES3"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES3",checkNoEmailSchedulesContent(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES4"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES4",checkAddScheduleWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES5"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES5",checkDefaultListDDAddScheduleWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Clear previous history lists");
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            clearVHLists(driver,etest);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES6"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES6",checkAddedVHList(driver,false,"Temp List"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES7"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES7",checkAddedVHList(driver,true,"Permanent List"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES8"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES8",checkListDropDownAlert(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES9"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES9",checkToAlert(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES10"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES10",checkCC(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES11"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES11",checkDefaultSubject(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES12"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES12",checkSubject(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES13"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES13",checkDefaultBody(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES14"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES14",checkDefaultFrequencyDDAddScheduleWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES15"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES15",checkDefaultFileTypeAddScheduleWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES16"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES16",checkNotesForFrequency(driver,"day"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES17"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES17",checkNotesForFrequency(driver,"week"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES18"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES18",checkNotesForFrequency(driver,"month"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES19"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES19",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","xlsx",true,false,null,false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES20"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES20",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,true,"rajkumar.natarajan+cc@zohocorp.com",false,null,"Every day","csv",true,false,null,false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES21"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES21",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,true,"User Defined Body Content","Every day","xlsx",true,false,null,false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES22"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES22",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","xlsx",true,false,null,false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES23"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES23",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","csv",true,false,null,false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES24"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES24",checkUpdateScheduleWindow(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES25"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES25",checkCCInUpdateWindow(driver));

            ComplexReportFactory.closeTest(etest);
        
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES26"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES26",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every week","xlsx",false,true,"disable",false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES27"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES27",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every month","xlsx",false,true,"disable/enable",false,null));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES28"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES28",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every week","csv",false,false,null,true,"xlsx"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES29"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES29",CommonFunctionsS.addSchedule(driver,etest,"Returning Visitors",toemail1,false,null,false,null,"Every day","xlsx",false,false,null,true,"csv"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES30"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES30",CommonFunctionsS.addSchedule(driver,etest,"Returning Visitors",toemail1,false,null,false,null,"Every day","xlsx",false,false,null,true,"Every week"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES31"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES31",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","csv",false,false,null,true,"Every month"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES32"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES32",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every week","xlsx",false,false,null,true,"Every day"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES33"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES33",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every week","xlsx",false,false,null,true,"Every month"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES34"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES34",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every month","xlsx",false,false,null,true,"Every day"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES35"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES35",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every month","xlsx",false,false,null,true,"Every week"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES36"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES36",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every month","xlsx",false,false,null,true,toemail2));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES37"));
            ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            result.put("ES37",CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","xlsx",false,false,null,true,"User Updated Body Content"));

            ComplexReportFactory.closeTest(etest);

            //removed in update

            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES38"));
            // ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            // result.put("ES38",convertRichToPlain(driver,true));

            // ComplexReportFactory.closeTest(etest);

            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ES39"));
            // ComplexReportFactory.setValues(etest,"Automation","Email Schedules");

            // result.put("ES39",convertPlainToRich(driver));

            // ComplexReportFactory.closeTest(etest);
        }
        catch(Exception e)
        {
            result.put("ES1", false);
            etest.log(Status.FATAL,"Error occurred while checking network connection in EmailSchedules : "+e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            System.out.println("Exception while network connection in EmailSchedules module : ");
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","EmailSchedules","Error");
            e.printStackTrace();
        }
        
        ComplexReportFactory.closeTest(etest);

        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);

            String desc = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"classname","automationcontent"),"classname","innersubinfotxt").getText();

            if(desc.contains(ResourceManager.getRealValue("schedule_desc"))) 
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","EmailSchedulesDescription","MismatchDescription");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","EmailSchedulesDescription","Error",e);
            return false;
        }
        return false;
    }

    public static boolean checkNoEmailSchedulesContent(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);

            WebElement e = CommonUtilS.elementfinder(driver,CommonUtilS.elfinder(driver,"id","trouting"),"id","schedulerwrap");

            String header = CommonUtilS.elementfinder(driver,e,"classname","f26").getText();
            String desc = CommonUtilS.elementfinder(driver,e,"classname","f16").getText();

            if(header.contains(ResourceManager.getRealValue("no_schedule_header")) && desc.contains(ResourceManager.getRealValue("no_schedule_desc"))) 
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("no_schedule_header")+"--"+ResourceManager.getRealValue("no_schedule_desc")+"--Actual:"+header+"--"+desc+"--");
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","EmailSchedulesDescription","MismatchDescription");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","NoEmailSchedulesDescription","Error",e);
            return false;
        }
        return false;
    }

    public static boolean checkAddScheduleWindow(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            WebElement e = CommonUtilS.elfinder(driver,"id","dlgbox");

            String schedule = CommonUtilS.elementfinder(driver,e,"id","savedialog").getText();
            String cancel = CommonUtilS.elementfinder(driver,e,"css","div.cnfmbtm.mrgnlft_twenty").getText();
            String header = CommonUtilS.elementfinder(driver,e,"classname","modal-header").getText();

            if(schedule.contains(ResourceManager.getRealValue("add_schedule_button_content")) && cancel.contains(ResourceManager.getRealValue("cancel_add_schedule_button_content")) && header.contains(ResourceManager.getRealValue("add_schedule_header"))) 
            {
                WebElement list = CommonUtilS.elementfinder(driver,CommonUtilS.elementfinder(driver,e,"id","chooselistdiv"),"tagname","span");
                List<WebElement> list1 = e.findElements(By.cssSelector(".lvfedbk-lft.txtelips"));
                List<WebElement> list2 = CommonUtilS.elementfinder(driver,e,"id","vst_dlg_footer").findElements(By.className("color666"));
                
                String actual[] = {list.getText(),list1.get(1).getText(),list1.get(3).getText(),list2.get(0).getText(),list2.get(1).getText()};
                String expected[] = {"Visitor History Lists","To","Subject","Send this report:","Choose a File Type:"};
                
                for(int i = 0;i<5;i++)
                {
                    if(!actual[i].equals(expected[i]))
                    {
                        etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]+"--");
                        TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddNewEmailSchedulesDescription","MismatchContent");
                        CommonFunctionsS.clickCloseWindow(driver);
                        return false;
                    }
                }
                etest.log(Status.PASS,"Contents Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }
            etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("add_schedule_button_content")+"--"+ResourceManager.getRealValue("cancel_add_schedule_button_content")+"--"+ResourceManager.getRealValue("add_schedule_header")+"--Actual:"+schedule+"--"+cancel+"--"+header+"--");
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddNewEmailSchedulesDescription","MismatchContent");
            CommonFunctionsS.clickCloseWindow(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddNewEmailSchedulesDescription","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
        return false;
    }

    public static boolean checkDefaultListDDAddScheduleWindow(WebDriver driver) throws Exception
    {
        try
        {
            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            if(checkDefaultListDDAddScheduleWindow1(driver,true,"All Visitors") && checkDefaultListDDAddScheduleWindow1(driver,true,"Existing List") && checkDefaultListDDAddScheduleWindow1(driver,true,"Returning Visitors"))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","DefaultListDropDown","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    } 

    public static boolean checkDefaultListDDAddScheduleWindow1(WebDriver driver,boolean presence,String listname) throws Exception
    {
        try
        {
            if(CommonFunctionsS.getListFromDropdowninAddNewSchedule(driver,listname) != null && presence || CommonFunctionsS.getListFromDropdowninAddNewSchedule(driver,listname) == null && !presence )
            {
                return true; 
            }
            etest.log(Status.FAIL,"Mismatch in presence of list:"+listname+" Expected:"+presence+"--Actual:"+!presence);
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckDropDown",listname+"MismatchInPresence");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","DefaultListDropDown","Error",e);
            return false;
        }
        return false;
    }

    public static boolean checkAddedVHList(WebDriver driver,boolean permanent,String listname) throws Exception
    {
        try
        {
            CommonFunctionsS.addListInVH(driver,"Browser","is equal to","Google Chrome",permanent,listname);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            if(checkDefaultListDDAddScheduleWindow1(driver,permanent,listname))
            {
                etest.log(Status.PASS,"UseCase Checked");
                TakeScreenshot.infoScreenshot(driver,etest);
                CommonFunctionsS.clickCloseWindow(driver);
                if(permanent)
                {
                    if(!CommonFunctionsS.deleteListInVH(driver,listname))
                    {
                        TakeScreenshot.screenshot(driver,etest,"EmailSchedules","DeleteListInVH",listname+"isNotDeleted");
                        return false;
                    }
                    CommonFunctionsS.setToAllVis(driver);  
                }
                return true;
            }
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","AddedListDropDown",listname+"isNotPresent");
            CommonFunctionsS.clickCloseWindow(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckAddedVHList","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
        return false;
    }

    public static boolean checkListDropDownAlert(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);
            CommonFunctionsS.clickScheduleInAddWindowAndDontWait(driver);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("dlgbox")).findElement(By.id("listdiv_div")).getAttribute("class").contains("errorbdr"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            CommonFunctionsS.clickCloseWindow(driver);
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckListDropDownAlert","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }   

    public static boolean checkToAlert(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);
            CommonFunctionsS.clickListFromDropdowninAddNewSchedule(driver,"All Visitors");
            CommonFunctionsS.clickScheduleInAddWindowAndDontWait(driver);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("dlgbox")).findElement(By.id("toemail")).getAttribute("class").contains("errorbdr"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            CommonFunctionsS.clickCloseWindow(driver);
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckToEmailAlert","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean checkCC(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);
            CommonFunctionsS.clickccInAddWindow(driver);
            
            CommonFunctionsS.clickCloseWindow(driver);
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckCCEMail","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean checkDefaultSubject(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);
            
            String subject = "<"+ResourceManager.getRealValue("add_new_schedule_default_subject")+">";
            String actual = CommonFunctionsS.getSubject(driver);

            if(CommonUtil.checkStringEqualsAndLog(subject,actual,"email schedules subject",etest))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }

            etest.log(Status.FAIL,"MismatchSubject.Expected:"+subject+"--Actual:"+actual);
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckDefaultSubject","Error");
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckDefaultSubject","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean checkSubject(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);
            CommonFunctionsS.clickListFromDropdowninAddNewSchedule(driver,"All Visitors");
            
            String subject = "List of "+"All Visitors";
            String actual = CommonFunctionsS.getSubject(driver);

            if(CommonUtil.checkStringEqualsAndLog(subject,actual,"email schedules subject",etest))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }

            // etest.log(Status.FAIL,"MismatchSubject.Expected:"+subject+"--Actual:"+actual);
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckSubject","Error");
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckSubject","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean checkDefaultBody(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);
            
            String subject = bodyContent;
            String actual = CommonFunctionsS.getBodyContent(driver);

            if(CommonUtil.checkStringEqualsAndLog(subject,actual,"email schedules body",etest))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }

            //etest.log(Status.FAIL,"MismatchBody.Expected:"+subject+"--Actual:"+actual);
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","MismatchBody","Error");
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","MismatchBody","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    } 

    public static boolean checkDefaultFrequencyDDAddScheduleWindow(WebDriver driver) throws Exception
    {
        try
        {
            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            if(checkFrequencyDDAddScheduleWindow(driver,true,"Every day") && checkFrequencyDDAddScheduleWindow(driver,true,"Every week") && checkFrequencyDDAddScheduleWindow(driver,true,"Every month"))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","DefaultFrequencyDropDown","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    } 

    public static boolean checkFrequencyDDAddScheduleWindow(WebDriver driver,boolean presence,String freq) throws Exception
    {
        try
        {
            if(CommonFunctionsS.getFrequencyFromDropdowninAddNewSchedule(driver,freq) != null && presence || CommonFunctionsS.getFrequencyFromDropdowninAddNewSchedule(driver,freq) == null && !presence )
            {
                return true; 
            }
            etest.log(Status.FAIL,"Mismatch in presence of frequency:"+freq+" Expected:"+presence+"--Actual:"+!presence);
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckDropDown",freq+"MismatchInPresence");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","FrequencyDropDown","Error",e);
            return false;
        }
        return false;
    }

    public static boolean checkDefaultFileTypeAddScheduleWindow(WebDriver driver) throws Exception
    {
        try
        {
            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            String xls = CommonFunctionsS.getClassNameForFileType(driver,"xlsx");
            String csv = CommonFunctionsS.getClassNameForFileType(driver,"csv");
            if(xls.equals("rdobtn rdselected") && csv.equals("rdobtn "))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }
            etest.log(Status.FAIL,"Mismatch in presence of file type classname: Expected:rdobtn rdselected--rdobtn --Actual:"+xls+"--"+csv+"--");
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckDefaultFileTypeAddScheduleWindow","MismatchInClassName");
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckDefaultFileTypeAddScheduleWindow","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean checkNotesForFrequency(WebDriver driver,String freq) throws Exception
    {
        try
        {
            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            String expected = "Note: "+ResourceManager.getRealValue("schedule_every_"+freq+"_note");

            freq = "Every "+freq;

            CommonFunctionsS.clickFrequencyFromDropdowninAddNewSchedule(driver,freq);

            Thread.sleep(1500);
            
            String note = CommonFunctionsS.getNotesinAddNewSchedule(driver);
            
            if(note.equals(expected))
            {
                etest.log(Status.PASS,"Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                return true;
            }
            etest.log(Status.FAIL,"Mismatch: Expected:"+expected+"--Actual:"+note+"--");
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckNotesForFrequency","MismatchContent");
            CommonFunctionsS.clickCloseWindow(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckNotesForFrequency","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    } 

    public static boolean checkUpdateScheduleWindow(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            if(!CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","xlsx",false,false,null,false,null))
            {
                return false;
            }

            CommonFunctionsS.clickEdit(driver);

            WebElement e = CommonUtilS.elfinder(driver,"id","dlgbox");

            String schedule = CommonUtilS.elementfinder(driver,e,"id","savedialog").getText();
            String cancel = CommonUtilS.elementfinder(driver,e,"css","div.cnfmbtm.mrgnlft_twenty").getText();
            String header = CommonUtilS.elementfinder(driver,e,"classname","modal-header").getText();

            if(schedule.contains(ResourceManager.getRealValue("update_schedule_button_content")) && cancel.contains(ResourceManager.getRealValue("cancel_update_schedule_button_content")) && header.contains(ResourceManager.getRealValue("update_schedule_header"))) 
            {
                List<WebElement> list1 = e.findElements(By.cssSelector(".lvfedbk-lft.txtelips"));
                List<WebElement> list2 = CommonUtilS.elementfinder(driver,e,"id","vst_dlg_footer").findElements(By.className("color666"));
                String actual[] = {list1.get(1).getText(),list1.get(3).getText(),list2.get(0).getText(),list2.get(1).getText()};
                String expected[] = {"To","Subject","Send this report:","Choose a File Type:"};
                for(int i = 0;i<4;i++)
                {
                    if(!actual[i].equals(expected[i]))
                    {
                        etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]+"--");
                        TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckUpdateScheduleWindow","MismatchContent");
                        CommonFunctionsS.clickCloseWindow(driver);
                        return false;
                    }
                }
                etest.log(Status.PASS,"Contents Checked");
                CommonFunctionsS.clickCloseWindow(driver);
                CommonFunctionsS.clickDelete(driver,etest);
                return true;
            }
            etest.log(Status.FAIL,"Expected:"+ResourceManager.getRealValue("update_schedule_button_content")+"--"+ResourceManager.getRealValue("cancel_update_schedule_button_content")+"--"+ResourceManager.getRealValue("update_schedule_header")+"--Actual:"+schedule+"--"+cancel+"--"+header+"--");
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckUpdateScheduleWindow","MismatchContent");
            CommonFunctionsS.clickCloseWindow(driver);
            CommonFunctionsS.clickDelete(driver,etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckUpdateScheduleWindow","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
        return false;
    }

    public static boolean checkCCInUpdateWindow(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            if(!CommonFunctionsS.addSchedule(driver,etest,"All Visitors",toemail1,false,null,false,null,"Every day","xlsx",false,false,null,false,null))
            {
                return false;
            }

            CommonFunctionsS.clickEdit(driver);
            CommonFunctionsS.clickccInAddWindow(driver);
            CommonFunctionsS.clickCloseWindow(driver);
            CommonFunctionsS.clickDelete(driver,etest);
            
            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckCCInUpdateWindow","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean convertRichToPlain(WebDriver driver,boolean closeWindow) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtilS.waitreturner(driver,30,250);

            CommonFunctionsS.navigateToEmailScheduleTab(driver);
            CommonFunctionsS.clickAddSchedule(driver);

            WebElement e = CommonUtilS.elfinder(driver,"id","dlgbox");

            if(!CommonFunctionsS.checkRich(driver))
            {
                TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckRich","Error");
                CommonFunctionsS.clickCloseWindow(driver);
                return false;
            }

            CommonUtilS.elementfinder(driver,e,"classname","ze_plain").click();

            Thread.sleep(1500);

            if(!CommonFunctionsS.checkRichtoPlainAlert(driver))
            {
                etest.log(Status.FAIL,"Alert is not present while converting rich text to plain text");
                CommonFunctionsS.clickCloseWindow(driver);
                return false;
            }

            driver.switchTo().alert().accept();

            Thread.sleep(1500);
            
            if(!CommonFunctionsS.checkPlain(driver))
            {
                TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckPlain","Error");
                driver.navigate().refresh();
                Thread.sleep(3000);
                return false;
            }
            
            if(closeWindow)
            {
                CommonFunctionsS.clickCloseWindow(driver);
            }
            etest.log(Status.PASS,"Rich to Plain is Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","ConvertRichToPlain","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean convertPlainToRich(WebDriver driver) throws Exception
    {
        try
        {
            if(!convertRichToPlain(driver,false))
            {
                return false;
            }

            WebElement e = CommonUtilS.elfinder(driver,"id","dlgbox");
            
            CommonUtilS.elementfinder(driver,e,"classname","ze_plain").click();

            Thread.sleep(1500);

            if(!CommonFunctionsS.checkRich(driver))
            {
                TakeScreenshot.screenshot(driver,etest,"EmailSchedules","CheckRich","Error");
                driver.navigate().refresh();
                Thread.sleep(3000);
                return false;
            }
            
            CommonFunctionsS.clickCloseWindow(driver);
            etest.log(Status.PASS,"Plain to Rich is Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","ConvertPlainToRich","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean clearVHLists(WebDriver driver,ExtentTest etest)
    {
        try
        {
            Tab.clickVisitorHistory(driver);
            View.checkViews(driver);

            WebElement new_history_list = null;
            WebElement dropdown=CommonUtil.getElement(driver,VISITOR_HISTORY_DROPDOWN_BUTTON);
            CommonUtil.mouseHoverAndClick(driver,dropdown);
            CommonWait.waitTillDisplayed(driver,VISITOR_HISTORY_DROPDOWN_BUTTON,VISITOR_HISTORY_DROPDOWN,By.tagName("ul"));
            List<WebElement> list = CommonUtil.getElement(driver,VISITOR_HISTORY_DROPDOWN_BUTTON,VISITOR_HISTORY_DROPDOWN,By.tagName("ul")).findElements(By.tagName("li"));
            for(WebElement ele : list)
            {
                if(ele.getAttribute("val").length() > 3 && ele.getAttribute("title").equals("Permanent List"))
                {
                    new_history_list = ele;
                    break;
                }
            }
            if(new_history_list == null) 
            {
                etest.log(Status.INFO,"No VH Lists were present matching the category");
                return true;
            }

            WebElement delete=CommonUtil.getElement(new_history_list,VISITOR_HISTORY_DELETE_ICON_CLASS_NAME);
            if(delete!=null)
            {
                CommonUtil.mouseHoverAndClick(driver,delete);
                WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"delete");
                HandleCommonUI.clickPositivePopupButton(popup);
                CommonUtil.sleep(1000);
                etest.log(Status.INFO,"VH Lists were cleared");
                return true;        
            }
            else
            {
                etest.log(Status.WARNING,"VHLists were not cleared ");
                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmailSchedules","clearVHLists","Exception",e);
            return false;
        }
    }
}
