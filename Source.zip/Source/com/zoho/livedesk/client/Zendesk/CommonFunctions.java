//$Id$
package com.zoho.livedesk.client.Zendesk;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


public class CommonFunctions
{
	public static WebElement getRelatedTicket(WebDriver driver,WebElement chat) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        WebElement div = CommonUtil.elementfinder(driver,chat,"id","associateddata");

        if(!div.getAttribute("innerHTML").contains("spt_tktdatamn"))
        {
        	return null;
        }

        return CommonUtil.elementfinder(driver,div,"classname","spt_tktdatamn");
	}

	public static WebElement getRecentTicket(WebDriver driver,WebElement chat,String question) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        WebElement div = CommonUtil.elementfinder(driver,chat,"id","recentrequest");

        if(!div.getAttribute("style").contains("none"))
        {
        	return null;
        }

        List<WebElement> list = div.findElements(By.className("spt_tktdatamn"));

        for(WebElement e : list)
        {
        	if(e.getText().contains(question))
        	{
        		return e;
        	}
        }

        return null;
	}

	// public static void openTicket(WebDriver driver,WebElement chat,WebElement ticket) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        ticket.click();

 //        final WebElement div = CommonUtil.elementfinder(driver,chat,"id","zsreqdetail");

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(!div.getAttribute("style").contains("none"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        Thread.sleep(1000);
 //    }

 //    public static void openTicket(WebDriver driver,WebElement ticket) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        ticket.click();

 //        final WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(!div.getAttribute("style").contains("none"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        Thread.sleep(1000);
 //    }

 //    public static void clickMoreInTicket(WebDriver driver,WebElement ticket) throws Exception
 //    {
 //    	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        CommonUtil.elementfinder(driver,div,"xpath","//span[@id='morelink']//a").click();

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(div.findElement(By.xpath("//span[@id='morelink']")).getAttribute("style").contains("none"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(div.findElement(By.xpath("//span[@id='hidelink']")).getAttribute("style").contains("display: inline;"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(!div.findElement(By.xpath("//div[@id='morecontent']")).getAttribute("style").contains("none"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        CommonUtil.elementfinder(driver,div,"xpath","//div[@class='spt_tktcntinfotit'][contains(text(),'Ticket Information')]");
	// }

	// public static void clickHideInTicket(WebDriver driver,WebElement ticket) throws Exception
 //    {
 //    	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        CommonUtil.elementfinder(driver,div,"xpath","//span[@id='hidelink']//a").click();

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(div.findElement(By.xpath("//span[@id='hidelink']")).getAttribute("style").contains("none"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(div.findElement(By.xpath("//span[@id='morelink']")).getAttribute("style").contains("display: inline;"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(div.findElement(By.xpath("//div[@id='morecontent']")).getAttribute("style").contains("none"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });
	// }

	// public static String getDetailsInTicket(WebDriver driver,WebElement ticket,String lhs) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        List<WebElement> list = CommonUtil.elementfinder(driver,div,"id","morecontent").findElements(By.className("spt-tktmoredetlmn"));

 //        for(WebElement e : list)
 //        {
 //        	if(CommonUtil.elementfinder(driver,e,"classname","spt-tktmoredetlft").getText().contains(lhs))
 //        	{
 //        		return CommonUtil.elementfinder(driver,e,"classname","spt-tktmoredetrht").getText();
 //        	}
 //        }

 //        return null;
	// }

	// public static String getStatusInTicket(WebDriver driver,WebElement ticket) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        return CommonUtil.elementfinder(driver,div,"css","div.spt-tktsts.txtelips").getText();
	// }

	// public static void clickChatHeaderInTicket(WebDriver driver,WebElement ticket) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        final WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        final WebElement chat = div.findElements(By.className("spt-tktmsgmn")).get(0);

 //        if(chat.getAttribute("class").contains("spt-sel"))
 //        {
 //        	chat.click();
 //        }

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(chat.findElement(By.id("messagediv")).getAttribute("style").contains("block"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });
	// }

	// public static boolean clickFeebBackHeaderInTicket(WebDriver driver,WebElement ticket) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        final WebElement div = CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail");

 //        List<WebElement> list = div.findElements(By.className("spt-tktmsgmn"));

 //        if(list.size() <= 1)
 //        {
 //        	return false;
 //        }

 //        final WebElement chat = list.get(1);

 //        if(chat.getAttribute("class").contains("spt-sel"))
 //        {
 //        	chat.click();
 //        }

 //        wait.until(new Function<WebDriver,Boolean>(){
 //            public Boolean apply(WebDriver driver)
 //            {
 //                if(chat.findElement(By.id("messagediv")).getAttribute("style").contains("block"))
 //                {
 //                    return true;
 //                }
 //                return false;
 //            }
 //        });

 //        return true;
	// }

	// public static boolean checkMessageInChatTranscriptInTicket(WebDriver driver,WebElement ticket,int line,String sender,String message) throws Exception
	// {
	// 	FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
 //        WebElement msgdiv = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,ticket,"id","zsreqdetail"),"id","messagediv");

 //        CommonUtil.elementfinder(driver,msgdiv,"xpath","//h4[contains(text(),'Chat Transcript')]");

 //        List<WebElement> list = CommonUtil.elementfinder(driver,msgdiv,"tagname","tbody").findElements(By.tagName("tr"));

 //        List<WebElement> msg = list.get(line).findElements(By.tagName("td"));

 //        if(msg.get(0).equals(sender) && msg.get(1).equals(message))
 //        {
 //        	return false;
 //        }

 //        return true;
	// }

 //    
    public static boolean checkDropDownPresence(WebDriver driver,List<WebElement> list,String lhs) throws Exception
    {
        for(WebElement e : list)
        {
            if(CommonUtil.elementfinder(driver,e,"classname","crmld_inflft1").getText().contains(lhs))
            {
                return true;
            }
        }

        return false;
    }

    public static boolean createTicketPresence(WebDriver driver,final WebElement chat) throws Exception
    {
        boolean presence = false;

        FluentWait wait = CommonUtil.waitreturner(driver,6,200);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(chat.findElement(By.id("newreqdiv")).getAttribute("style") == null || (!chat.findElement(By.id("newreqdiv")).getAttribute("style").contains("none") && !chat.findElement(By.id("newreqdiv")).getAttribute("style").contains("opacity")))
                        {
                            return true;
                        }
                        return false;
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            presence = true;
        }
        catch(Exception e)
        {}

        return presence;
    }

    public static boolean createdTicketPresence(WebDriver driver,final WebElement chat) throws Exception
    {
        boolean presence = false;

        FluentWait wait = CommonUtil.waitreturner(driver,6,200);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(chat.findElement(By.id("associatedreq")).getAttribute("style") == null || (!chat.findElement(By.id("associatedreq")).getAttribute("style").contains("none") && !chat.findElement(By.id("associatedreq")).getAttribute("style").contains("opacity")))
                        {
                            return true;
                        }
                        return false;
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            presence = true;
        }
        catch(Exception e)
        {}

        return presence;
    }

    public static boolean relatedTicketPresence(WebDriver driver,final WebElement chat) throws Exception
    {
        boolean presence = false;

        FluentWait wait = CommonUtil.waitreturner(driver,6,200);

        try
        {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(chat.findElement(By.id("recentrequest")).getAttribute("style") == null || (!chat.findElement(By.id("recentrequest")).getAttribute("style").contains("none") && !chat.findElement(By.id("recentrequest")).getAttribute("style").contains("opacity")))
                        {
                            return true;
                        }
                        return false;
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            presence = true;
        }
        catch(Exception e)
        {}

        return presence;
    }

    public static boolean mapDept(WebDriver driver,String salesiqDept,String deskConfig, ExtentTest etest) throws Exception
    {
        WebElement e = CommonUtil.elfinder(driver,"id","mapsupportdept");
        List<WebElement> depts = e.findElements(By.xpath(".//div[@conf='deptlist']"));

        String id = null;

        for(WebElement d : depts)
        {
            CommonUtil.inViewPort(d);
            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+dept.getLocation().y+"-400)");
            
            if(d.getText().contains(salesiqDept))
            {
                id = d.getAttribute("id");
                break;
            }
        }

        WebElement dept = CommonUtil.elementfinder(driver,e,"id","dept"+id+"_div_div");
        
        CommonUtil.inViewPort(dept);
        //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+dept.getLocation().y+"-400)");

        dept.click();
        
        FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        final WebElement dropDown = CommonUtil.elementfinder(driver,e,"id","dept"+id+"_div_ddown");

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(dropDown.getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        Thread.sleep(500);

        List<WebElement> list = e.findElements(By.tagName("li"));

        for(WebElement l : list)
        {
            CommonUtil.inViewPort(l);
            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+l.getLocation().y+"-400)");
            
            if(l.getText().contains(deskConfig))
            {
                CommonUtil.elementfinder(driver,l,"tagname","span").click();

                Tab.waitForLoading(driver,"upintegdept.do",etest);

                return true;
            }
        }

        return false;
    }

    public static void setFeedBackConfig(WebDriver driver,boolean feedBack, ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        final String classname = feedBack? "set_on" : "set_off" ;

        final WebElement fdb = CommonUtil.elfinder(driver,"id","pushfeedback");
        
        if(fdb.getAttribute("class").contains(classname))
        {
            return ;
        }

        CommonUtil.inViewPort(fdb);
        fdb.click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(fdb.getAttribute("class").contains(classname))
                {
                    return true;
                }
                return false;
            }
        });
        
        Tab.waitForLoading(driver,"updateinteg.do",etest);
    }
}
