//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.zoho.livedesk.util.common.CommonSikuli;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.SeleniumGridUtil;

import com.zoho.livedesk.util.common.Functions;

public class KeyboardShortcuts
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	public static ExtentTest etest; 
    
	public static Hashtable shortcutkeys(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("KBSK1"));
            ComplexReportFactory.setValues(etest,"Automation","KeyboardShortcuts");

            url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

			try
			{
				Functions.closeBannersAfterLogin(driver);
			}
			catch(Exception e){}

			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("hdrprt")));

			driver.findElement(By.id("hdrdrpdwntop")).click();
            Thread.sleep(1000);
            
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			result.put("KBSK1", false);

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_shortcutkeys")))
				{
					etest.log(Status.PASS,"KeyboardShortcuts is present");

					result.put("KBSK1", true);

					break;
				}
			}
			if(!(boolean)result.get("KBSK1"))
				TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","KeyboardShortcutsinDropdown","KeyBoardShortsIsNotPresent");


			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("KBSK2"));
            ComplexReportFactory.setValues(etest,"Automation","KeyboardShortcuts");

            result.put("KBSK2", isWindowAvail(driver));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("KBSK3"));
            ComplexReportFactory.setValues(etest,"Automation","KeyboardShortcuts");

            result.put("KBSK3", closeWindow(driver));
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("KBSK4"));
            ComplexReportFactory.setValues(etest,"Automation","KeyboardShortcuts");

            result.put("KBSK4", checkHeaders(driver));
			
			ComplexReportFactory.closeTest(etest);

			driver.navigate().refresh();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("KBSK5"));
            ComplexReportFactory.setValues(etest,"Automation","KeyboardShortcuts");

            result.put("KBSK5", false);
			result.put("KBSK6", false);

			Hashtable temp = new Hashtable();

			driver.findElement(By.id("hdrdrpdwntop")).click();
            Thread.sleep(1000);
			List<WebElement> drpdwn1 = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));
            
			for(WebElement elmt:drpdwn1)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_shortcutkeys")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("shorcut_help"));
					WebElement header = window.findElement(By.className("hdr"));

					WebElement close = header.findElement(By.className("floatrg")).findElement(By.tagName("a"));

					temp.put("KBSK5", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_trackkbsc"), "t"));
                    Thread.sleep(1000);
					temp.put("KBSK6", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_chatkbsc"), "c"));
                    Thread.sleep(1000);
					temp.put("KBSK7", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_notes"), "n"));
                    Thread.sleep(1000);
					temp.put("KBSK8", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_chathis"), "h"));
                    Thread.sleep(1000);
					temp.put("KBSK9", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_search"), "/"));
                    Thread.sleep(1000);
					temp.put("KBSK10", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_help"), "?"));
                    Thread.sleep(1000);
					temp.put("KBSK11", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_nextchattab"), "tab"));
                    Thread.sleep(1000);
					temp.put("KBSK12", checkKeys(driver, "goto", ResourceManager.getRealValue("shortcut_prevchattab"), "shift + tab"));
                    Thread.sleep(1000);
					if(((Boolean)temp.get("KBSK5")) && ((Boolean)temp.get("KBSK6")) && ((Boolean)temp.get("KBSK7")) && ((Boolean)temp.get("KBSK8")) && ((Boolean)temp.get("KBSK9")) && ((Boolean)temp.get("KBSK10")) && ((Boolean)temp.get("KBSK11")) && ((Boolean)temp.get("KBSK12")))
					{
						etest.log(Status.PASS,"Goto Keys are checked");

						result.put("KBSK5", true);
					}
					else
					{
						try
						{
							String[] goto_use_case_keys={"KBSK5","KBSK6","KBSK7","KBSK8","KBSK9","KBSK10","KBSK11","KBSK12"};
							etest.log(Status.FAIL,"Goto Keys Failure");
							for(String goto_use_case_key : goto_use_case_keys)
							{
								if(temp.get(goto_use_case_key)!=null && (Boolean)temp.get(goto_use_case_key)==false)
								{
									etest.log(Status.FAIL,"Use case '"+KeyManager.getRealValue(goto_use_case_key)+"' failed");								
								}
							}

							TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts",KeyManager.getRealValue("KBSK5"),"Any One Of the above is failed");
						}
						catch(Exception e)
						{
							etest.log(Status.FAIL,"Goto Keys Failure");

							e.printStackTrace();
						}

					}

					/*else{
						TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts",KeyManager.getRealValue("KBSK5"),"Any One Of the above is failed");
					}*/

					ComplexReportFactory.closeTest(etest);
            
		            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("KBSK6"));
		            ComplexReportFactory.setValues(etest,"Automation","KeyboardShortcuts");

		            temp.put("KBSK13", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_replyviamail"), "r"));
                    Thread.sleep(1000);

				    if(CommonSikuli.machinename(driver).contains("imac"))
				    {
                        temp.put("KBSK14", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_sendmail"), "cmd + enter"));
                        Thread.sleep(1000);
                    }
                    else
                    {
                        temp.put("KBSK14", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_sendmail"), "ctrl + enter"));
                        Thread.sleep(1000);
                    }
                    
					temp.put("KBSK15", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_chattran"), ">"));
                    Thread.sleep(1000);
					temp.put("KBSK16", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_inviteagnt"), "+"));
                    Thread.sleep(1000);
					temp.put("KBSK17", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_endsess"), "q"));
                    Thread.sleep(1000);
					temp.put("KBSK18", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_sharefile"), "f"));
                    Thread.sleep(1000);
					temp.put("KBSK19", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_chattrans"), "l"));
                    Thread.sleep(1000);
					temp.put("KBSK20", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_accept"), "y"));
                    Thread.sleep(1000);
					temp.put("KBSK21", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_cancel"), "esc"));
                    Thread.sleep(1000);
					temp.put("KBSK22", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_ignorechatnotify"), "esc"));
                    Thread.sleep(1000);
					temp.put("KBSK23", checkKeys(driver, "actions", ResourceManager.getRealValue("shortcut_clrcurrfocus"), "shift + esc"));
                    Thread.sleep(1000);
					if(((Boolean)temp.get("KBSK13")) && ((Boolean)temp.get("KBSK14")) && ((Boolean)temp.get("KBSK15")) && ((Boolean)temp.get("KBSK16")) && ((Boolean)temp.get("KBSK17")) && ((Boolean)temp.get("KBSK18")) && ((Boolean)temp.get("KBSK19")) && ((Boolean)temp.get("KBSK20")) && ((Boolean)temp.get("KBSK21")) && ((Boolean)temp.get("KBSK22")) && ((Boolean)temp.get("KBSK23")))
					{
						etest.log(Status.PASS,"Actions Keys are checked");

						result.put("KBSK6", true);
					}
					/*else{
						TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts",KeyManager.getRealValue("KBSK6"),"Any one of the above is failed");
					}*/
					close.click();
					Thread.sleep(1000);
				}
			}
			ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorKeyBoardShortcuts");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","KeyboardShortcuts in Dropdown","Error",e);

			result.put("KBSK1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorKeyBoardShortcuts");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","KeyboardShortcuts in Dropdown","Error",e);

			result.put("KBSK1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	private static boolean isWindowAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_shortcutkeys")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("shorcut_help"));
					WebElement header = window.findElement(By.className("hdr"));
					WebElement close = header.findElement(By.className("floatrg")).findElement(By.tagName("a"));

					if((header.getText()).contains(ResourceManager.getRealValue("common_shortcutkeys")))
					{
						if((close.getAttribute("class")).contains("sqico-close"))
						{
							close.click();
							etest.log(Status.PASS,"KeyboardShortcuts WIndow Avialable");

							return true;
						}
						else{
							TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Window Available","Mismatch Close Icon");
						}
						close.click();
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Window Available","Mismatch Header");
					}
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Window Available","Error",e);

			System.out.println("Exception while checking Keyboard shortcuts window is available : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Window Available","Error",e);

            System.out.println("Exception while checking Keyboard shortcuts window is available : "+e);
		}
		return false;
	}

	private static boolean closeWindow(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_shortcutkeys")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("shorcut_help"));
					WebElement header = window.findElement(By.className("hdr"));

					WebElement close = header.findElement(By.className("floatrg")).findElement(By.tagName("a"));
					if((close.getAttribute("class")).contains("sqico-close"))
					{
						close.click();
						etest.log(Status.PASS,"Close WIndow is checked");

						return true;
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Close Window","Mismatch Close Icon");
					}
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Close Window","ErrorWhileClosingWindow",e);

            System.out.println("Exception while checking Keyboard shortcuts close window : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Close Window","ErrorWhileClosingWindow",e);

            System.out.println("Exception while checking Keyboard shortcuts close window : "+e);
		}
		return false;
	}

	private static boolean checkHeaders(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_shortcutkeys")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("shorcut_help"));
					WebElement header = window.findElement(By.className("hdr"));

					WebElement close = header.findElement(By.className("floatrg")).findElement(By.tagName("a"));

					List<WebElement> headers = window.findElements(By.className("help_wrap"));

					if(((headers.get(0).findElement(By.tagName("h2")).getText()).equals(ResourceManager.getRealValue("shortcut_goto"))) && ((headers.get(1).findElement(By.tagName("h2")).getText()).equals(ResourceManager.getRealValue("shortcut_actions"))))
					{
						close.click();
						etest.log(Status.PASS,"KeyboardShortcuts Windoew Header is checked");

						return true;
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Check Window Header","Mismatch Window Header");
					}
					close.click();
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Check Window Header","ErrorWhileCheckingWindowHeader",e);

            System.out.println("Exception while checking Keyboard shortcuts window header is available : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","Check Window Header","ErrorWhileCheckingWindowHeader",e);

            System.out.println("Exception while checking Keyboard shortcuts window header is available : "+e);
		}
		return false;
	}

	private static boolean checkKeys(WebDriver driver, String type, String titleval, String keyval)
	{
		try
		{
			WebElement window = driver.findElement(By.id("shorcut_help"));
			WebElement header = window.findElement(By.className("hdr"));

			WebElement close = header.findElement(By.className("floatrg")).findElement(By.tagName("a"));

			List<WebElement> headers = window.findElements(By.className("help_wrap"));

			List<WebElement> title=new ArrayList<WebElement>();
			List<WebElement> keys=new ArrayList<WebElement>();

			if(type.equals("goto"))
			{
				WebElement elmt = headers.get(0);
				title = elmt.findElements(By.className("title"));
				keys = elmt.findElements(By.className("key"));
			}
			else if(type.equals("actions"))
			{
				WebElement elmt = headers.get(1);
				title = elmt.findElements(By.className("title"));
				keys = elmt.findElements(By.className("key"));
			}
			for(int i=0;i<title.size();i++)
			{
				if(titleval.equals(title.get(i).getText()))
				{
					if(keyval.equals(keys.get(i).getText()))
					{
						return true;
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","CheckKeys-"+type,"Mismatch Key");
					}
				}
			}
			etest.log(Status.INFO,"Shortcut <><><>"+titleval+" Key <><><>"+keyval);
			TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","CheckKeys-"+type,"Mismatch Title");
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","CheckKeys-"+type,"ErrorwhilecheckingKeys",e);

			System.out.println("Exception while checking keyboard shortcuts keys : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"KeyBoardShortcuts","CheckKeys-"+type,"ErrorwhilecheckingKeys",e);

            System.out.println("Exception while checking keyboard shortcuts keys : "+e);
		}
		return false;
	}

}
