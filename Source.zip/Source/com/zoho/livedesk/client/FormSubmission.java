//$Id$
package com.zoho.livedesk.client;
import com.zoho.livedesk.util.Util;
import java.io.File;
import java.util.List;
import java.util.Arrays;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.net.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import java.util.Date;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import com.zoho.livedesk.util.common.actions.VisitorsOnline;
import java.text.SimpleDateFormat;
public class FormSubmission
{
	public static WebDriver visitordriver;
	public static String currenttime;
	public static ExtentReports extent;
	public static ExtentTest etest;
	public static Hashtable result;
	static Hashtable hashtable=new Hashtable();
	public static String msg;
	public static int resultcount=0;
	public static String portalname="ldautomation12";
	public static Hashtable test(WebDriver driver1) throws Exception
	{	
		try
		{
            visitordriver = null;
			result=new Hashtable();
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF1"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
        	
            result.put("WF1",checkVisitorOnlinee(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF2"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");

            result.put("WF2",checkVisitorStatus(driver1));

            closeVisitorDriver();
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF3"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF3",checkVisitorDetails(driver1,"yourname","emailid","id"));
            
            closeVisitorDriver();
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF4"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF4",checkVisitorDetails(driver1,"your-name","youremail","id"));
            
            closeVisitorDriver();
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF5"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF5",checkVisitorDetails(driver1,"subscribername","contactemail","id"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF6"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF6",checkVisitorDetails(driver1,"contactname","subscriberemail","id"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF7"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF7",checkVisitorDetails(driver1,"contact_name","mail","id"));
            
            closeVisitorDriver();
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF8"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF8",checkVisitorDetails(driver1,"customername","customeremail","id"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF9"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF9",checkVisitorDetails(driver1,"name","email","name"));

            closeVisitorDriver();
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF10"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF10",checkVisitorDetails(driver1,"yourname","emailid","name"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF11"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF11",checkVisitorDetails(driver1,"your-name","youremail","name"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF12"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF12",checkVisitorDetails(driver1,"subscribername","contactemail","name"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF13"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");

            result.put("WF13",checkVisitorDetails(driver1,"contactname","subscriberemail","name"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF14"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");

            result.put("WF14",checkVisitorDetails(driver1,"contact_name","mail","name"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF15"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
            
            result.put("WF15",checkVisitorDetails(driver1,"customername","customeremail","name"));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF16"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");

            result.put("WF16",refreshAndCheckDisApr(driver1));
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("WF17"));
            ComplexReportFactory.setValues(etest,"Automation","Web Form Submission");
    
            result.put("WF17",checkVisitAndInfo(driver1,"customername","customeremail","name"));
            
            closeVisitorDriver();
            ComplexReportFactory.closeTest(etest);
		}
		catch(Exception ex)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+ex);
            System.out.println("~~Module breakage occurred");
			ex.printStackTrace();
			System.out.println("Exception occured in main test");
		}
		hashtable.put("result", result);
        hashtable.put("servicedown", new Hashtable());
		return hashtable;
	}

	public static boolean checkVisitorOnlinee(WebDriver driver) throws Exception
	{
		try
		{
            visitordriver = Functions.setUp();
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			Tab.clickVisitorsOnline(driver);
            String vid = "";
            try
            {
                visitordriver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/formwithportal.html");
                submitPortalAndAttri(visitordriver,portalname,portalname,"name","email","id");
                vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Error checking visitor online",e);
                return false;
            }
            
            checkVisitorOnline(driver,vid);
			getVisitorAndClick(driver,vid);
			wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle')]")));
			checknewvisit(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Error checking visitor online",e);
		}
		return checkResult(2);
	}
	public static boolean checkVisitorStatus(WebDriver driver) throws Exception
	{
		currenttime=datetimereturner();
		try
		{
            String vid = "";
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            try
            {
                vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","webform","Error checking visitor details",e);
                return false;
            }
            
            checkVisitorNumericName(driver,vid);
			checkNoMail(driver,vid);
			closeTilesUIPopUp(driver);
			
            try
            {
                checkChangedAttribute(visitordriver,"id","name","email");
                submitForm(visitordriver,"Last"+currenttime,currenttime+"@webform.com");
                vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","webform","Error checking visitor details",e);
                closeTilesUIPopUp(driver);
                return false;
            }
            
			getVisitorAndClick(driver,vid);
			wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle')]")));
			checkVisitorName(driver,vid,currenttime);
			checkVisitorMail(driver,vid,currenttime);
			closeTilesUIPopUp(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","webform","Error checking visitor details",e);
            closeTilesUIPopUp(driver);
		}
		return checkResult(6);
	}
	public static boolean checkVisitorDetails(WebDriver driver,String nvalue,String evalue,String atrivalue) throws Exception
	{
		currenttime=datetimereturner();
		try
		{
            visitordriver = Functions.setUp();
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			Tab.clickVisitorsOnline(driver);
            String vid = "";
			
            try
            {
                visitordriver.get("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/formwithportal.html");
                submitPortalAndAttri(visitordriver,portalname,portalname,nvalue,evalue,atrivalue);
                vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Error checking visitor details",e);
                return false;
            }
			
            checkVisitorOnline(driver,vid);
			getVisitorAndClick(driver,vid);
			wait.until(ExpectedConditions.visibilityOf(CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle')]")));
			checkVisitorNumericName(driver,vid);
			checkNoMail(driver,vid);
            closeTilesUIPopUp(driver);
            
            try
            {
                checkChangedAttribute(visitordriver,atrivalue,nvalue,evalue);
                submitForm(visitordriver,"Last"+currenttime,currenttime+"@webform.com");
                vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Error checking visitor details",e);
                return false;
            }
            
			getVisitorAndClick(driver,vid);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle')]")));
			checkVisitorName(driver,vid,currenttime);
			checkVisitorMail(driver,vid,currenttime);
        
            closeTilesUIPopUp(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Error checking visitor details",e);
            closeTilesUIPopUp(driver);
		}
		return checkResult(7);
	}
	public static boolean refreshAndCheckDisApr(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            String vid= "";
            
            try
            {
                vid=VisitorWindow.getVisitorId(visitordriver,portalname);
                visitordriver.navigate().refresh();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Error checking visitor details",e);
                return false;
            }
            
			waitUntilVisDisAppr(driver,vid);
			etest.log(Status.PASS,"Visitor disappeared in tracking window------Test passed");
			resultcount++;
		}
		catch(Exception e)
		{
			etest.log(Status.FAIL,"Visitor not disappeared in tracking window------Test passed");
            TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Error checking visitor details",e);
		}
		return checkResult(1);
	}
	public static boolean checkVisitAndInfo(WebDriver driver,String nvalue,String evalue,String atrivalue) throws Exception
	{
		try
		{
            String vid = "";
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
            try
            {
                submitPortalAndAttri(visitordriver,portalname,portalname,nvalue,evalue,atrivalue);
                vid = VisitorWindow.getVisitorId(visitordriver,portalname);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","crm_webform","Error checking visitor info",e);
                return false;
            }
            
			checkVisitorOnline(driver,vid);
			getVisitorAndClick(driver,vid);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle')]")));
			checkvisit(driver);
			checkVisitorName(driver,vid,currenttime);
			checkVisitorMail(driver,vid,currenttime);
            closeTilesUIPopUp(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Error checking visitor info",e);
            closeTilesUIPopUp(driver);
        }
		return checkResult(4);
	}
	public static void checkVisitorName(WebDriver driver,String vid,String last)throws Exception
	{
		etest.log(Status.INFO,"Verifying visitor name");
		if(getVisitorName(driver,vid).contains("Last"+last))
		{
			etest.log(Status.PASS,"Visitor name 'Last"+last+"' updated in tracking window------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Visitor name 'Last"+last+"' not updated in tracking window------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","webform","Visitor name not updated in tracking window");
		}
	}
	public static void checkVisitorMail(WebDriver driver,String vid,String mail) throws Exception
	{
		etest.log(Status.INFO,"Verifying mail id");
		if(getVisitormail(driver,vid).contains(mail+"@webform.com"))
		{
			etest.log(Status.PASS,"Visitor email id '"+mail+"@webform.com' updated in tracking window------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Visitor email id '"+mail+"@webform.com' not updated in tracking window------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor email id not updated in tracking window");
		}
	}
	public static void checkChangedAttribute(WebDriver visitordriver,String attriname,String nval,String eval) throws Exception
	{
		if(visitordriver.findElement(By.xpath("//form[@id='form']//input[contains(@class,'lst')]")).getAttribute(attriname).contains(nval))
		{
			etest.log(Status.PASS,"Attribute "+attriname+" = '"+nval+"' for lastname------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Attribute "+attriname+" is not '"+nval+"' for last name------Test failed");
			TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","webform","No Expected attribute value");
		}
		if(visitordriver.findElement(By.xpath("//form[@id='form']//input[contains(@class,'e_id')]")).getAttribute(attriname).contains(eval))
		{
			etest.log(Status.PASS,"Attribute "+attriname+" = '"+eval+"' for email------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Attribute value for "+attriname+" is not '"+eval+"'------Test failed");
			TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","webform","No Expected attribute value");
		}
	}
	public static void checkVisitorNumericName(WebDriver driver,String vid) throws Exception
	{
		if(getVisitorName(driver,vid).contains("[a-zA-Z]+") == false)
		{
			etest.log(Status.PASS,"Numeric visitor name is present------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Numeric visitor name not present------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","webform","No numeric visitor name");
		}
	}
	public static void checkNoMail(WebDriver driver,String vid) throws Exception
	{
		if(getVisitormail(driver,vid).equals(""))
		{
			etest.log(Status.PASS,"Visitor email is not present------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Visitor email id is present------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","webform","emailid is present");
		}
	}
	public static void checknewvisit(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
		if(driver.findElements(By.xpath("//div[contains(@class,'visitdetails')]//p[contains(text(),'New Visitor')]")).size()!=0)
		{
			etest.log(Status.PASS,"New Visitor is present in visitor details------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"New Visitor not present in visitor details------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","webform","new visitor in visitor details not present");
		}
	}
	public static void checkvisit(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
		if(driver.findElements(By.xpath("//div[contains(@class,'visitdetails')]//p//em[contains(text(),'Visits')]")).size()!=0)
		{
			etest.log(Status.PASS,"No of visits is present in visitor details------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"No of visits not present in visitor details------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","webform","No of visits in visitor details not present");
		}
	}
	public static void submitPortalAndAttri(WebDriver visitordriver,String portal,String embed,String lst,String email,String setup1) throws Exception
	{
        FluentWait wait = CommonUtil.waitreturner(visitordriver,30,200);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Set Attribute')]")));
        CommonUtil.elfinder(visitordriver,"id","embedname").sendKeys(embed);
        CommonUtil.elfinder(visitordriver,"id","portalname").sendKeys(portal);
        CommonUtil.elfinder(visitordriver,"id",Util.setUptracking()).click();
        WebElement lastattribute=CommonUtil.elfinder(visitordriver,"id","lstattri");
        lastattribute.click();
        CommonUtil.elementfinder(visitordriver,lastattribute,"xpath",".//option[@value='"+lst+"']").click();
        WebElement emailattribute=CommonUtil.elfinder(visitordriver,"id","mailattri");
        emailattribute.click();
        CommonUtil.elementfinder(visitordriver,emailattribute,"xpath",".//option[@value='"+email+"']").click();
        CommonUtil.elfinder(visitordriver,"xpath","//input[@id='"+setup1+"' and @name='setup1']").click();
        Thread.sleep(1000);
        CommonUtil.elfinder(visitordriver,"xpath","//button[contains(text(),'Set Attribute')]").click();
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zlscht"))
                {
                    return true;
                }
                return false;
            }
        });
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));
        Thread.sleep(1000);
	}
	public static void checkVisitorOnline(WebDriver driver,String vid) throws Exception
	{
		waituntillvisitorOnline(driver,vid);
		if(driver.findElement(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]")).isDisplayed())
		{
			etest.log(Status.PASS,"Visitor online------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Visitor offline------Test failed");
			TakeScreenshot.screenshot(driver,etest,"SalesIq","crm_webform","Visitor not in online");
		}
	} 
	public static void submitForm(WebDriver visitordriver,String lastname,String email) throws Exception
	{
        FluentWait wait = CommonUtil.waitreturner(visitordriver,30,200);
        wait.until(ExpectedConditions.visibilityOf(visitordriver.findElement(By.xpath("//form[@id='form']//input[contains(@class,'lst')]"))));
        visitordriver.findElement(By.xpath("//form[@id='form']//input[contains(@class,'lst')]")).sendKeys(lastname);
        visitordriver.findElement(By.xpath("//form[@id='form']//input[contains(@class,'e_id')]")).sendKeys(email);
        visitordriver.findElement(By.xpath("//form[@id='form']//button[contains(@type,'submit')]")).click();
        visitordriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Thread.sleep(2000);
    }
	public static String getVisitorName(WebDriver driver,String id) throws Exception
	{
		WebElement visitorinfo=driver.findElement(By.xpath("//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle') and contains(@id,'infoname_"+id+"')]"));
		return visitorinfo.getAttribute("innerText");
	}
	public static String getVisitormail(WebDriver driver,String id) throws Exception
	{
		WebElement visitorinfo=CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visitdetails')]//span[contains(@class,'ptitle') and contains(@id,'infoemail_"+id+"')]");
		return visitorinfo.getAttribute("innerText");
	}
	public static void waituntillvisitorOnline(WebDriver driver,final String vid) throws Exception
	{
        VisitorsOnline.waitTillVisitorPresent(driver,vid);
	}
	public static void waitUntilVisDisAppr(WebDriver driver,final String vid) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,90,200);
		wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {	
		        	try
		        	{
		            	if(driver.findElements(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]")).size()==0)
		            	{
		                	return true;
		            	}
		            	return false;
		            }
		            catch(Exception e)
		            {
		            	return false;
		            }
		        }
		    });	
	}
	public static void getVisitorAndClick(WebDriver driver,String vid) throws Exception
	{
        VisitorsOnline.waitTillVisitorPresent(driver,vid);
//		Thread.sleep(2000);
//		return driver.findElement(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]"));
        WebElement e = driver.findElement(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]"));
        try
        {
            waitTillVisitorStableInRings(e,"1");
            e.click();
        }
        catch(WebDriverException excep)
        {
            waitTillVisitorStableInRings(e,"2");
            e.click();
        }
	}
    public static void waitTillVisitorStableInRings(WebElement e,String check) throws Exception
    {
        String s1 = e.getAttribute("style");
        
        Long t1 = new Long(System.currentTimeMillis());
        Long startingTime = new Long(System.currentTimeMillis());
        
        for(;;)
        {
            String s2 = e.getAttribute("style");
            
            if(!s2.equals(s1))
            {
                s1 = s2;
                t1 = new Long(System.currentTimeMillis());
            }
            
            Long t2 = new Long(System.currentTimeMillis());
            if(t2 - t1 > 1000)
            {
                System.out.println("waitTillVisitorStableInRings<1>"+check+"<>"+(t2-startingTime)+"<>");
                break;
            }
            if(t2 - startingTime > 5000)
            {
                System.out.println("waitTillVisitorStableInRings<2>"+check+"<>"+(t2-startingTime)+"<>");
                break;
            }
            
            Thread.sleep(200);
        }
    }
	public static boolean checkResult(int i) throws Exception
	{
		if(resultcount==i)
		{
			resultcount=0;
			return true;
		}
		else
		{
			resultcount=0;
			return false;
		}
	}
	public static String datetimereturner()
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
        String dateAsString = simpleDateFormat.format(new Date());
		System.out.println(dateAsString);
		return dateAsString;
	}
	
    public static void closeVisitorDriver() throws Exception
    {
        if(visitordriver != null)
        {
            visitordriver.quit();
            visitordriver = null;
        }
    }
    
    public static void closeTilesUIPopUp(WebDriver driver) throws Exception
    {
        if(!CommonUtil.elfinder(driver,"tagname","body").getAttribute("innerHTML").contains("visitdetails"))
        {
            return;
        }
        if(!CommonUtil.elfinder(driver,"id","ldsettings").isDisplayed())
        {
            return;
        }
        CommonUtil.elfinder(driver,"xpath","//div[@id='ldsettings']//div[@class='visitdetails']//textarea").click();
        CommonUtil.elfinder(driver,"xpath","//div[@id='ldsettings']//div[@class='visitdetails']//textarea").sendKeys(Keys.ESCAPE);
    }
}
