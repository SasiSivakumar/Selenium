//$Id$
package com.zoho.livedesk.client;
import com.zoho.livedesk.util.Util;
import java.io.File;
import java.util.List;
import java.util.Arrays;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.net.*;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import java.util.Date;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import java.text.SimpleDateFormat;
public class ConcurrentChat
{
	public static WebDriver visitordriver1,visitordriver2;
	public static String currenttime;
	public static String visitorname1,visitorname2;
	public static ExtentReports extent;
	public static ExtentTest etest;
	public static Hashtable result;
	static Hashtable hashtable=new Hashtable();
	public static String msg;
	public static int resultcount=0;
	public static String portalname="ldautomation12";
	public static String embedname="embed3";
	
    public static Hashtable test(WebDriver driver1) throws Exception
	{	
		try
		{
			result=new Hashtable();
            visitordriver1 = null;
            visitordriver2 = null;
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC1"));
            ComplexReportFactory.setValues(etest,"Automation","Concurrent Chats");
            
            result.put("CC1",initiateChatAndCheckCloseButton(driver1));
        	
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC2"));
            ComplexReportFactory.setValues(etest,"Automation","Concurrent Chats");
            
            result.put("CC2",checkMsgCount(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC3"));
            ComplexReportFactory.setValues(etest,"Automation","Concurrent Chats");
          
            result.put("CC3",openChatAndCheckCountDisapr(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CC4"));
            ComplexReportFactory.setValues(etest,"Automation","Concurrent Chats");
          
            result.put("CC4",endChatAndCheckNofify(driver1));

            ComplexReportFactory.closeTest(etest);
		}
		catch(Exception ex)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+ex);
            System.out.println("~~Module breakage occurred");
			ex.printStackTrace();
			System.out.println("Exception occured in main test");
		}
        
        closeDrivers();
        
        hashtable.put("result", result);
        hashtable.put("servicedown", new Hashtable());
		return hashtable;
	}
	
    public static boolean initiateChatAndCheckCloseButton(WebDriver driver) throws Exception
	{
		visitorname1=datetimereturner();
		try
		{
            visitordriver1 = Functions.setUp();
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            try
            {
            	String widgetCode = ExecuteStatements.getWidgetCode(driver);
                // VisitorWindow.createPage(visitordriver1,embedname,portalname);
                VisitorWindow.createPage(visitordriver1,widgetCode);
                VisitorWindow.initiateChatVisTheme(visitordriver1,visitorname1,null,null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Testing?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver1,etest,"ConcurrentChat","MyChat","Error",e);
                return false;
            }
			
            ChatWindow.acceptChat(driver,etest);
			WebElement chatheatvis1=chatheadInMyChats(driver,visitorname1);
			mouseOver(driver,chatheatvis1);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cclose")));
			etest.log(Status.INFO,"Verifing appearance of close button on mouse hover");
			checkIfCloseisVisible(driver,chatheatvis1);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error",e);
		}
		return checkResult(1);
	}
	public static boolean checkMsgCount(WebDriver driver) throws Exception
	{
		visitorname2=datetimereturner();
		try
		{
            visitordriver2 = Functions.setUp();
            
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            try
            {
            	String widgetCode = ExecuteStatements.getWidgetCode(driver);
                // VisitorWindow.createPage(visitordriver2,embedname,portalname);
                VisitorWindow.createPage(visitordriver2,widgetCode);
                VisitorWindow.initiateChatVisTheme(visitordriver2,visitorname2,null,null,ExecuteStatements.getSystemGeneratedDepartment(driver),"Testing2?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver2,etest,"ConcurrentChat","MyChat","Error",e);
                return false;
            }
            
			ChatWindow.acceptChat(driver,etest);
			
            try
            {
                for(int i=0;i<5;i++)
                {
                    VisitorWindow.sentMessageInTheme(visitordriver1,datetimereturner());
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver1,etest,"ConcurrentChat","MyChat","Error",e);
                return false;
            }
            
            WebElement chatheatvis1=chatheadInMyChats(driver,visitorname1);
			//waitUntilMsgCountVisible(driver,chatheatvis1);
			verifyMsgCount(driver,chatheatvis1,"5",visitorname1);
			String backgroudBefore=getBackgroundPosition(driver,chatheatvis1.findElement(By.id("cclose")));
			mouseOver(driver,chatheatvis1);
			String backgroudAfter=getBackgroundPosition(driver,chatheatvis1.findElement(By.id("cclose")));
			System.out.println(backgroudAfter+"--after---------before--"+backgroudBefore);
			//verifyclosebuttenbyposition(driver,backgroudBefore,backgroudAfter);
			etest.log(Status.INFO,"Verifing close button on mouse hover when message count notification is present");
			verifyclosebuttenbyposition(driver,chatheatvis1);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error",e);
		}
		return checkResult(2);
	}
	public static boolean openChatAndCheckCountDisapr(WebDriver driver) throws Exception
	{
		try
		{
			WebElement chatheatvis1=chatheadInMyChats(driver,visitorname1);
			chatheatvis1.click();
			etest.log(Status.INFO,"Verifing disappearance of message count when chat window of visitor '"+visitorname1+"' is opened");
			checkIfNoMsgCountPresent(driver,chatheatvis1);
			WebElement chatheatvis2=chatheadInMyChats(driver,visitorname2);
            
            try
            {
                for(int i=0;i<8;i++)
                {
                    VisitorWindow.sentMessageInTheme(visitordriver2,datetimereturner());
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver2,etest,"ConcurrentChat","MyChat","Error",e);
                return false;
            }
			
			etest.log(Status.INFO,"Verifing appearance of message count by sending message from visitor when chat window is not opened in Operator");
			verifyMsgCount(driver,chatheatvis2,"8",visitorname2);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error",e);
		}
		return checkResult(2);
	}
	public static boolean endChatAndCheckNofify(WebDriver driver) throws Exception
	{
		try
		{
			WebElement chatheatvis2=chatheadInMyChats(driver,visitorname2);
			endchat(visitordriver2);
			verifyMsgCount(driver,chatheatvis2,"...",visitorname2);
			mouseOver(driver,chatheatvis2);
			String backgroudAfter=getBackgroundPosition(driver,chatheatvis2.findElement(By.id("cclose")));
			etest.log(Status.INFO,"Verifing close button on mouse hover when message count notification is present");
			verifyclosebuttenbyposition(driver,chatheatvis2);
			chatheatvis2.click();
			etest.log(Status.INFO,"Verifing disappearance of message count when chat window of visitor '"+visitorname2+"' is opened");
			checkIfNoMsgCountPresent(driver,chatheatvis2);
            
            ChatWindow.clickClosethisWindow(driver);
            
            Thread.sleep(3000);
            
            ChatWindow.endAndCloseChat(driver);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error",e);
		}
		return checkResult(3);
	}
	public static void endchat(WebDriver driver) throws Exception
	{
        VisitorWindow.endChatVisitor(driver);
	}
	public static void checkIfNoMsgCountPresent(WebDriver driver,WebElement chathead) throws Exception
	{
		if(chathead.getAttribute("innerHTML").contains("mcount") || chathead.findElements(By.className("mcount")).size()==0)
		{
			etest.log(Status.PASS,"Message count disappeared after chat window is opened------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Message count not disappeared after chat window is opened------Test failed");
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error");
		}
	}
	public static void verifyclosebuttenbyposition(WebDriver driver,String pos1,String pos2) throws Exception
	{
		if(pos1 != pos2)
		{
			etest.log(Status.PASS,"Close button is visible on mouse hover when message count notification is present------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Close button is not visible on mouse hover when message count notification is present------Test failed");
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error");
		}
	}
	public static void verifyclosebuttenbyposition(WebDriver driver,WebElement chathead) throws Exception
	{
		if(getBackgroundPosition(driver,chathead.findElement(By.id("cclose"))).equals("-222px -1677px"))
		{
			etest.log(Status.PASS,"Close button is visible on mouse hover------Test passed");
			resultcount++;
		}
		else
		{
			etest.log(Status.FAIL,"Close button is not visible on mouse hover------Test failed");
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error");
		}
	}
	public static void verifyMsgCount(WebDriver driver,WebElement chathead,String count,String visnam) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			System.out.println(chathead.getAttribute("id")+"---------id of li tag");
			waitUntilMsgCountVisible(driver,chathead,count);
			System.out.println(chathead.findElement(By.id("cclose")).getText()+"---------gettext");
			//chathead.findElement(By.id("cclose")).getText();
			if(chathead.findElement(By.id("cclose")).getText().contains(count))
			{
				etest.log(Status.PASS,"Message notification ("+count+") is visible in visitor '"+visnam+"' chat head------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Message notification ("+count+") is not visible in visitor '"+visnam+"' chat head------Test failed");
				TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error");
			}
		}
		catch(Exception e)
		{
			etest.log(Status.FAIL,"Message notification ("+count+") is not visible------Test failed");
			TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error",e);
		}
		
	}
	public static String getBackgroundPosition(WebDriver driver,WebElement element) throws Exception
	{
		return element.getCssValue("background-position");
	}
	public static WebElement chatheadInMyChats(WebDriver driver,String visname) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement header = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","mycurrent_div"),"xpath","//div[@id='innerheader']//ul[@id='lschatheader']");

        List<WebElement> headers = header.findElements(By.tagName("li"));

        WebElement chat_header = null;

        for(WebElement e : headers)
        {
            if(CommonUtil.elementfinder(driver,e,"tagname","span").getText().contains(visname))
                chat_header = e;
        }
        return chat_header;
    }
	public static void checkIfCloseisVisible(WebDriver driver,WebElement parent) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			System.out.println(CommonUtil.elementfinder(driver,parent,"id","cclose").getCssValue("display")+"-------display val of close button");
			if(CommonUtil.elementfinder(driver,parent,"id","cclose").getCssValue("display").equals("block"))
			{
				etest.log(Status.PASS,"Close button is visible on mouse hover------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Close button is not visible on mouse hover------Test failed");
				TakeScreenshot.screenshot(driver,etest,"ConcurrentChat","MyChat","Error");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void mouseOver(WebDriver driver,WebElement element) throws Exception
	{
		Thread.sleep(500);
		new Actions(driver).moveToElement(element).build().perform();
	}
	public static void waitUntilMsgCountVisible(WebDriver driver,final WebElement chathead,final String count) throws Exception
	{
		FluentWait wtr = CommonUtil.waitreturner(driver,20,200);
		wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						try
						{
							if(chathead.findElement(By.id("cclose")).getText().equals(count))
							{
								return true;
							}
							else
							return false;
						}
						catch(Exception e)
						{
							return false;
						}
					}
				});
	}
	
    public static String datetimereturner()
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
        String dateAsString = simpleDateFormat.format(new Date());
		System.out.println(dateAsString);
		return dateAsString;
	}
	public static boolean checkResult(int i) throws Exception
	{
		if(resultcount==i)
		{
			resultcount=0;
			return true;
		}
		else
		{
			resultcount=0;
			return false;
		}
	}
	
    public static void closeDrivers()
    {
        try
        {
           if(visitordriver1 != null)
           {
               visitordriver1.quit();
               visitordriver1 = null;
           }
        }
        catch(Exception e){}
        
        try
        {
            if(visitordriver2 != null)
            {
                visitordriver2.quit();
                visitordriver2 = null;
            }
        }
        catch(Exception e){}
    }
    
	
}
