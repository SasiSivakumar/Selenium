//$Id$
package com.zoho.livedesk.client;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;
import org.openqa.selenium.Dimension;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.google.common.base.Function;

public class VisitorRouting
{
    public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();

    public final static String
    ROUTETOSELECTEDOPERATORS = ResourceManager.getRealValue("automationtab_visitorrouting_Routeoperators");
    private static String url = "";

    private static int wcnum = 0;

    public static ExtentTest etest;
    public static int waitingTime = 10000;

    public static Hashtable secondAttemptResult = new Hashtable();
    public static Hashtable values = new Hashtable();
    public static Hashtable etests = new Hashtable();
    public static Stack<String> usecases = new Stack();
    public static int secondAttempt = 0;
    public static String secondAttemptIds = "";
    public static String embed = "visitorrouting";      //"visitorrouting"
     
    public static Hashtable vrouting(WebDriver driver)
    {
        try
        {
            result = new Hashtable();
            secondAttempt = 0;
            secondAttemptIds = "";
            
            values = new Hashtable();
            etests = new Hashtable();
            secondAttemptResult = new Hashtable();
            usecases = new Stack();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR1"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            url = ConfManager.requestURL();
            
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("track_suggest")));

            etest.log(Status.PASS,"VisitorRouting Tab is present");

            result.put("SVR1",true);
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR2"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            result.put("SVR2",isPageAvail(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR62"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            result.put("SVR62",checkDefaultIcons(driver));
            
            ComplexReportFactory.closeTest(etest);

	accresDel(driver);           

		 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR3"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            result.put("SVR3",checkDValues(driver));
            
            ComplexReportFactory.closeTest(etest);

            checkDeleteIconSikuli(driver,etest);

            addFull(driver);
            
            checkCRM(driver);
            
            checkCRMFull(driver);
            
            if(secondAttempt != 0)
            {
                etest=ComplexReportFactory.getTest("Visitor Routing - Successfull addition only after second attempt");
                ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");
                
                etest.log(Status.FAIL,"Number of second attempts:"+secondAttempt);
                etest.log(Status.FAIL,"Ids - "+secondAttemptIds);
                
                ComplexReportFactory.closeTest(etest);
            }
            
            accresDel(driver);
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.FATAL,"ErrorVisitorRoutingTab");

            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","VisitorRoutingTab","ErrorWhileCheckingVisitorRoutingTab",e);

            result.put("SVR1", false);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorVisitorRoutingTab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","VisitorRoutingTab","ErrorWhileCheckingVisitorRoutingTab",e);

            result.put("SVR1", false);
        }
        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    //Check if page is available
    private static boolean isPageAvail(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_visitorrouting"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));

            List<WebElement> text = driver.findElement(By.className("automationcontent")).findElements(By.className("innersubinfotxt"));

            if(((text.get(0).getText()).contains(ResourceManager.getRealValue("visitorrouting_desc1"))))
            {
                etest.log(Status.PASS,"VisitorRouting Description matched");

            return true;
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting","VisitorRoutingPge","MismatchDescription");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","VisitorRoutingPge","ErrorWhileCheckingVisitorRoutingPage",e);
            System.out.println("Exception while checking if visitor routing page is available : "+e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","VisitorRoutingPge","ErrorWhileCheckingVisitorRoutingPage",e);
            System.out.println("Exception while checking if visitor routing page is available : "+e);
            return false;
        }
        return false;
    }

    //Check default rule values
    private static boolean checkDValues(WebDriver driver)
    {
        String elid = "0";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Tab.navToVRTab(driver);

            Routing.clickAdd(driver,etest);

            elid = Routing.getRuleId(driver,0);

            Tab.navToVRTab(driver);

            Rules.openRuleEditView(driver,elid);

            List<WebElement> elmts = Rules.getRuleEditContainer(driver,elid).findElements(By.className("trulesinfo"));

            WebElement elmt = Rules.getRuleEditContainer(driver,elid);

            if(((elmt.findElement(By.id("prior"+elid+"_col1_div")).getText()).equals("Visitor Type"))&&((elmt.findElement(By.id("prior"+elid+"_col2_div")).getText()).equals("is equal to"))&&((elmt.findElement(By.id("prior"+elid+"_col3")).findElement(By.id("col3_input1")).getAttribute("title")).equals("All")))
            {
                if((elmt.findElement(By.id("info_"+elid)).findElement(By.id("info_"+elid+"_div")).getText()).equals(ROUTETOSELECTEDOPERATORS))
                {
                    etest.log(Status.PASS,"Default VisitorRouting is checked");

                    Rules.cancelRule(driver,etest,elid);
                    return true;
                }
                else{
                    TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultVisitorRouting","MismatchContent");
                }
            }
            else{
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultVisitorRouting","MismatchContent");
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultVisitorRouting","ErrorWhileCheckingDefaultVisitorRouting",e);
            System.out.println("Exception while checking default values in added rule in visitor routing page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultVisitorRouting","ErrorWhileCheckingDefaultVisitorRouting",e);
            System.out.println("Exception while checking default values in added rule in visitor routing page : "+e);
        }
        Rules.cancelRule(driver,etest,elid);
        return false;
    }

    //Add Full set of rules
    private static void addFull(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR4")+" and "+KeyManager.getRealValue("SVR5"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Browser","is equal to","Google Chrome",null,"Do not route","SVR4","SVR5");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR6"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Campaign Content","contains","Checking",null,"Route one by one","SVR6",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR7"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Campaign Medium","is equal to","Checking",null,"Route to least loaded","SVR7",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR8"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Campaign Name","contains","Checking",null,ROUTETOSELECTEDOPERATORS,"SVR8",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR9"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Campaign Source","is equal to","Checking",null,"Do not route","SVR9",null);

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR10"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Campaign Term","contains","Checking",null,"Route one by one","SVR10",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR11"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"City","is not equal to","Checking",null,"Route to least loaded","SVR11",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR12")+" and "+KeyManager.getRealValue("SVR13"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Country","is equal to","United States",null,ROUTETOSELECTEDOPERATORS,"SVR12","SVR13");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR14"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Email Address","ends with","@gmail.com",null,"Do not route","SVR14",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR15"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"IP Address","is equal to","192.168.43.100",null,"Route one by one","SVR15",null);

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR16"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Landing Page Title","contains","Checking",null,"Route to least loaded","SVR16",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR17"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Landing Page URL","doesn't contain","Checking",null,ROUTETOSELECTEDOPERATORS,"SVR17",null);  //Route to selected operators

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR18"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Number of Past Chats","is more than","7",null,"Do not route","SVR18",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR19"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Number of Visits","is less than","7",null,"Route one by one","SVR19",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR20")+" and "+KeyManager.getRealValue("SVR21"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Operating System","is not equal to","Kindle",null,"Route to least loaded","SVR20","SVR21");

            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR22"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Referrer","is not equal to","Yahoo",null,ROUTETOSELECTEDOPERATORS,"SVR22",null);
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR23")+" and "+KeyManager.getRealValue("SVR24"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Region","is equal to","Asia Pacific",null,"Do not route","SVR23","SVR24");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR25")+" and "+KeyManager.getRealValue("SVR26"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Search Engine","is not equal to","Bing",null,"Route one by one","SVR25","SVR26");

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR27"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"State","is equal to","Checking",null,"Route to least loaded","SVR27",null);

            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR28"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRule(driver,"Visitor Info","is equal to","Checking",null,ROUTETOSELECTEDOPERATORS,"SVR28",null);
            
            // ComplexReportFactory.closeTest(etest);

            checkValues(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR29")+" and "+KeyManager.getRealValue("SVR30"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Visitor Type","is equal to","Returning",null,"Route one by one","SVR29","SVR30");

            // ComplexReportFactory.closeTest(etest);

                // websites was removed from triggers conditions
                // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR31")+" and "+KeyManager.getRealValue("SVR32"));
                // ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");
                // addRuleddown(driver,"Websites","is not equal to",embed,null,"Route to least loaded","SVR31","SVR32");

            // ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR41")+" and "+KeyManager.getRealValue("SVR42"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addRuleddown(driver,"Visitor Stage in CRM","is not equal to","Not available",null,ROUTETOSELECTEDOPERATORS,"SVR41","SVR42");
            
            // ComplexReportFactory.closeTest(etest);
            
            checkValues(driver);
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while adding full set of rules in visitor routing page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while adding full set of rules in visitor routing page : "+e);
        }
    }

    //Add Rule(With dropdown check)
    private static void addRuleddown(WebDriver driver,String cond,String qual,String val1,String val2,String act,String drnum,String rnum1)
    {
        String id = "";
        result.put(drnum,false);
        
        try
        {
            etests.put(rnum1,etest);
            usecases.add(rnum1);

            if(values.size() == 0)
            {
                Tab.navToVRTab(driver);
            }
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            
            Routing.clickAdd(driver,etest);

            id = Routing.getRuleId(driver,0);

            String expectedUser = "Admin1";
            
            if(act.equals("Do not route"))
            {
                expectedUser = "No User";
            }
            
            String v1 = id+"/"+cond+"/"+qual+"/"+val1+"/"+act+"/"+expectedUser;
            
            values.put(rnum1,v1);
            
            Boolean allTrue[] = {true,true,true,true,true};
            
            fillFields(driver,etest,rnum1,allTrue);

            Rules.openRuleEditView(driver,id);
            
            Routing.selectValues(driver,id,val1,etest);Thread.sleep(500);
            
            Boolean dropDownPresence = false;
            
            try
            {
                String style = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior"+id+"_col3"),"id","col3_div").getAttribute("style");
                
                if(style.contains("display: block"))
                {
                    dropDownPresence = true;
                }
                else
                {
                    etest.log(Status.FAIL,"Style param:"+style);
                }
            }
            catch(Exception e){}
            
            if(dropDownPresence)
            {
                System.out.println("DropDown True");
                etest.log(Status.PASS,KeyManager.getRealValue(drnum)+" is checked");
                result.put(drnum,true);
            }
            else
            {
                System.out.println("DropDown False");
                TakeScreenshot.screenshot(driver,etest,"Intelliget Triggers",KeyManager.getRealValue(drnum),"DropDownIsNotVisible");
            }
            
            clickHeader(driver,id);Thread.sleep(1000);
        }
        catch(NoSuchElementException e)
        {
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
        catch(Exception e)
        {
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
        Rules.saveRule(driver,etest,id);
    }

    //Add Rule only (No dropdown check)
    private static void addRule(WebDriver driver,String cond,String qual,String val1,String val2,String act,String rnum1,String drnum)
    {
        try
        {
            etests.put(rnum1,etest);
            usecases.add(rnum1);

            if(values.size() == 0)
            {
                Tab.navToVRTab(driver);
            }
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            
            Routing.clickAdd(driver,etest);

            String id = Routing.getRuleId(driver,0);

            String expectedUser = "Admin1";

            if(act.equals("Do not route"))
            {
                expectedUser = "No User";
            }

            String v1 = id+"/"+cond+"/"+qual+"/"+val1+"/"+act+"/"+expectedUser;

            values.put(rnum1,v1);
            
            Boolean allTrue[] = {true,true,true,true,true};
            
            fillFields(driver,etest,rnum1,allTrue);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
            values.put(rnum1,"Error");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(rnum1),"ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
            values.put(rnum1,"Error");
        }
    }

    public static void checkDeleteIconSikuli(WebDriver driver,ExtentTest etest)
    {
        try
        {
            Tab.navToVRTab(driver);
            WebElement delete=Cleanup.getDeleteButton(driver);
            CommonUtil.mouseHover(driver,delete);
            CommonSikuli.findInWholePage(driver,"Visitorroutingdelete.png","UI213",etest);
        }
        catch(Exception e)
        {
            etest.log(Status.WARNING,"Visitor Routing Delete icon not Verified");
            TakeScreenshot.screenshot(driver,etest,e);
        }
    }

//Delete rules when access restricted Issue
    private static void accresDel(WebDriver driver)
    {
        com.zoho.livedesk.util.Cleanup.deleteAllVisitorRouting(driver);
        etest.log(Status.PASS,"All routings were deleted successfully.");
        // try
        // {
        //     FluentWait wait = CommonUtil.waitreturner(driver,10,250);

        //     Tab.navToVRTab(driver);

        //     for(int i=0;i<=10;i++)
        //     {
        //         if(Routing.ruleExist(driver))
        //         {
        //             List<WebElement> list = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("trules"));
                    
        //             final int count = list.size();

        //             WebElement elmtch = list.get(0);

        //             mouseOver(driver,elmtch);

        //             CommonSikuli.findInWholePage(driver,"Visitorroutingdelete.png","UI213",etest);

        //             CommonUtil.elementfinder(driver,elmtch,"classname","sqico-delico").click();

        //             wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
        //             wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                    
        //             CommonUtil.elfinder(driver,"id","okbtn").click();

        //             final WebElement e = CommonUtil.elfinder(driver,"id","popupdiv");

        //             wait.until(new Function<WebDriver,Boolean>()
        //             {
        //                 public Boolean apply(WebDriver driver)
        //                 {
        //                     if(e.getAttribute("innerHTML").equals(""))
        //                     {
        //                         return true;
        //                     }
        //                     return false;
        //                 }
        //             });

        //             Tab.waitForLoadingSuccessWithBanner(driver,"Rule deleted Successfully","deleterule.do",etest);

        //             if(count == 1)
        //             {
        //                 if(!Routing.ruleExist(driver))
        //                 {
        //                     return;
        //                 }
        //             }

        //             wait.until(new Function<WebDriver,Boolean>()
        //             {
        //                 public Boolean apply(WebDriver driver)
        //                 {
        //                     try
        //                     {
        //                         int finalCount = CommonUtil.elfinder(driver,"id","trouting").findElements(By.className("trules")).size();
                            
        //                         if(finalCount == (count - 1))
        //                         {
        //                             return true;
        //                         }
        //                     }
        //                     catch(Exception e)
        //                     {}
        //                     return false;
        //                 }
        //             });

        //             Thread.sleep(500);
        //         }
        //         else
        //         {
        //             break;
        //         }
        //     }
        // }
        // catch(NoSuchElementException e)
        // {
        //     System.out.println("Exception while deleting rules to avoid access restricted issue in visitor routing : "+e);
        // }
        // catch(Exception e)
        // {
        //     System.out.println("Exception while deleting rules to avoid access restricted issue in visitor routing : "+e);
        // }
    }

    //Check CRM integration
    private static void checkCRM(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR33"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            result.put("SVR33",disableCRM(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR34"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            result.put("SVR34",enableCRM(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR35")+" and "+KeyManager.getRealValue("SVR36"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Twitter","is equal to","Checking","Do not route","SVR35","SVR36");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR37")+" and "+KeyManager.getRealValue("SVR38"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Lead","First Name","contains","Checking","Route one by one","SVR37","SVR38");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR39")+" and "+KeyManager.getRealValue("SVR40"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Deal","No of Open Deals","is equal to","8","Route to least loaded","SVR39","SVR40");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking CRM rules in visitor routing page : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking CRM rules in visitor routing page : "+e);
        }
    }

    //Add full list of crm rules
    private static void checkCRMFull(WebDriver driver)
    {
        try
        {
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR43"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Lead Source","is equal to","Checking","Do not route",null,"SVR43");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR44"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Other City","is not equal to","Chennai","Route one by one",null,"SVR44");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR45"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Other Country","is not equal to","India","Route to least loaded",null,"SVR45");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR46"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Other Phone","is not equal to","044-63447070",ROUTETOSELECTEDOPERATORS,null,"SVR46");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR47"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Other State","ends with","Checking","Do not route",null,"SVR47");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR48"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Other Street","contains","Checking","Route one by one",null,"SVR48");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR49"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Other Zip","begins with","+919600","Route to least loaded",null,"SVR49");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR50"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Home Phone","is equal to","+9198999",ROUTETOSELECTEDOPERATORS,null,"SVR50");
        
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR51"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Secondary Email","ends with","@zohocorp.com","Do not route",null,"SVR51");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR52"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Contact","Title","ends with","Check","Route one by one",null,"SVR52");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR53"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Lead","State","contains","Testerln","Route to least loaded",null,"SVR53");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR54"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Lead","Street","ends with","test",ROUTETOSELECTEDOPERATORS,null,"SVR54");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR55"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Lead","Twitter","is not equal to","Checking","Do not route",null,"SVR55");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR56"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Lead","Visitor Score","is more than","7","Route one by one",null,"SVR56");
            
            // ComplexReportFactory.closeTest(etest);

                // websites option was removed
                // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR57"));
                // ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

                // addcrmrule(driver,"CRM Lead","Website","is equal to","salesiq.zoho.com","Route to least loaded",null,"SVR57");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR58"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Lead","Zip Code","ends with","036",ROUTETOSELECTEDOPERATORS,null,"SVR58");
            
            // ComplexReportFactory.closeTest(etest);

            checkValuesCRM(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR59"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Deal","Closed Won","is more than","800","Route to least loaded",null,"SVR59");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR60"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Deal","Revenue in pipeline","is less than","50000",ROUTETOSELECTEDOPERATORS,null,"SVR60");
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("SVR61"));
            ComplexReportFactory.setValues(etest,"Automation","Visitor Routing");

            addcrmrule(driver,"CRM Deal","Closing Date","is after","Today","Route one by one",null,"SVR61");
            
            // ComplexReportFactory.closeTest(etest);
            
            checkValuesCRM(driver);
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while checking all CRM rules in visitor routing : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking all CRM rules in visitor routing : "+e);
        }
    }

    //CRM integration - disable and check
    public static boolean disableCRM(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            Thread.sleep(1000);

            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            String action = elmts.getText();

            if(classname.equals("crm_intgopt") || action.contains(ResourceManager.getRealValue("common_enable")))
            {
                elmts.click();
                Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);
            }

            Thread.sleep(1000);

            WebElement elmtss = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));

            elmtss.click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
            driver.findElement(By.id("okbtn")).click();
            Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration disabled successfully","disableinteg.do",etest);

            Tab.navToVRTab(driver);

            Routing.clickAdd(driver,etest);

            elid = Rules.getRuleId(driver,0);

            Rules.openRuleEditView(driver,elid);

            WebElement elmt = Rules.getRuleEditContainer(driver,elid); //driver.findElement(By.id("trouting")).findElement(By.className("trules"));

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();

            try
            {
                WebElement e = elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("prior"+elid+"_col11"));

                if(!e.getText().contains("CRM"))
                {
                    elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                    etest.log(Status.PASS,"Disable CRM is checked");
                    Rules.cancelRule(driver,etest,elid);
                    return true;
                }

                TakeScreenshot.screenshot(driver,etest,"VisitorRouting","DisabelCRM","CRMisnotdisabled");

                return false;
            }
            catch(NoSuchElementException e)
            {
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                etest.log(Status.PASS,"Disable CRM is checked");
                Rules.cancelRule(driver,etest,elid);
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","DisabelCRM","ErrorWhileDisablingCRM",e);

            System.out.println("Exception while checking disable CRM and check CRM rules in dropdown in visitor routing page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","DisabelCRM","ErrorWhileDisablingCRM",e);

            System.out.println("Exception while checking disable CRM and check CRM rules in dropdown in visitor routing page : "+e);
        }
        Rules.cancelRule(driver,etest,elid);
        return false;
    }

    //CRM integration - Enable and check
    public static boolean enableCRM(WebDriver driver)
    {
        String elid = "";
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();

            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_integration"))));

            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_integration"))).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho CRM']")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Zoho Desk']")));

            driver.findElement(By.xpath("//div[text()='Zoho CRM']")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'"+ResourceManager.getRealValue("settings_crmheader")+"')]")));

            Thread.sleep(1000);

            WebElement elmts = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));
            String classname = driver.findElement(By.id("disablecontainer")).getAttribute("class");

            Thread.sleep(1000);

            WebElement elmtss = driver.findElement(By.id("rightintegbtn")).findElement(By.tagName("span"));

            elmtss.click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Zoho CRM Integration enabled successfully","enableinteg.do",etest);

            Tab.navToVRTab(driver);

            Routing.clickAdd(driver,etest);

            elid = Rules.getRuleId(driver,0);   //driver.findElement(By.id("trouting")).findElement(By.className("trules")).getAttribute("ruleid");

            Rules.openRuleEditView(driver,elid);

            WebElement elmt = Rules.getRuleEditContainer(driver,elid);  //driver.findElement(By.id("trouting")).findElement(By.className("trules"));

            elmt.findElement(By.id("prior"+elid+"_col1_div")).click();

            try
            {
                elmt.findElement(By.id("prior"+elid+"_col1_ddown")).findElement(By.id("prior"+elid+"_col11"));
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                Thread.sleep(1000);

                etest.log(Status.PASS,"Enable CRM is checked");
                Rules.cancelRule(driver,etest,elid);
                return true;
            }
            catch(NoSuchElementException e)
            {
                elmt.findElement(By.id("prior"+elid+"_col1_div")).click();
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting","EnableCRM","CRMisNotEnabled");
                Rules.cancelRule(driver,etest,elid);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","EnableCRM","ErrorWhileEnablingCRM",e);

            System.out.println("Exception while checking enable CRM and check CRM rules in dropdown in visitor routing page : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","EnableCRM","ErrorWhileEnablingCRM",e);

            System.out.println("Exception while checking enable CRM and check CRM rules in dropdown in visitor routing page : "+e);
        }
        Rules.cancelRule(driver,etest,elid);
        return false;
    }

    //CRM rule add
    private static void addcrmrule(WebDriver driver,String cond1,String cond2,String qual,String val,String act,String drnum,String rnum1)
    {
        try
        {
            etests.put(rnum1,etest);
            usecases.add(rnum1);

            if(values.size() == 0)
            {
                Tab.navToVRTab(driver);
            }
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            
            Routing.clickAdd(driver,etest);

            String id = Routing.getRuleId(driver,0);

            String expectedUser = "Admin1";
            
            if(act.equals("Do not route"))
            {
                expectedUser = "No User";
            }
            
            String v1 = id+"/"+cond1+"/"+cond2+"/"+qual+"/"+val+"/"+act+"/"+expectedUser;
            
            values.put(rnum1,v1);
            
            Boolean allTrue[] = {true,true,true,true,true,true};
            
            fillFieldsCRM(driver,etest,rnum1,allTrue);
            
            if(drnum!=null)
            {
                result.put(drnum,true);
            }

            // Tab.clickIntelligentTrigger(driver);
            // Tab.clickVisitorRouting(driver);
            
            // id = Routing.getRuleId(driver,0);

            // String actualCriteria = Routing.getCriteria(driver,id);
            // String actualSubCriteria = Routing.getSubCriteria(driver,id);
            // String actualConditon = Routing.getCondition(driver,id);
            // String actualValue = "";

            // if(cond2.equals("Closing Date"))
            // {
            //     actualValue = Routing.getValueFromDropDown(driver,id);
            // }
            // else
            // {
            //     actualValue = Routing.getValue1(driver,id);
            // }

            // String actualAction = Routing.getAction(driver,id);
            // String actualUser = Routing.getUsers(driver,id);

            // String expectedUser = "LDAutomation";

            // if(act.equals("Do not route"))
            // {
            //     expectedUser = "No User";
            // }

            // if(actualUser == null)
            // {
            //     actualUser = "No User";
            // }

            // String actual[] = {actualCriteria,actualSubCriteria,actualConditon,actualValue,actualAction,actualUser};
            // String expected[] = {cond1,cond2,qual,val,act,expectedUser};

            // boolean res = true;

            // for(int i = 0 ; i < actual.length; i++)
            // {
            //     if(!actual[i].equals(expected[i]))
            //     {
            //         etest.log(Status.FAIL,"Expected:"+expected[i]+"--Actual:"+actual[i]+"--");
            //         res = false;
            //     }
            //     else
            //     {
            //         etest.log(Status.INFO,expected[i]+" is present");
            //     }
            // }

            // if(!res)
            // {
            //     TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(rnum1),"MismatchContent");
            //     result.put(rnum1,false);
            // }
            // else
            // {
            //     result.put(rnum1,true);
            // }
        }
        catch(NoSuchElementException e)
        {
            if(drnum!=null)
            {
                result.put(drnum,false);
            }
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CRMRule","ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
        catch(Exception e)
        {
            if(drnum!=null)
            {
                result.put(drnum,false);
            }
            values.put(rnum1,"Error");
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CRMRule","ErrorWhileChecking"+KeyManager.getRealValue(rnum1),e);
        }
    }

    //Mouse Over for hidden element
    public static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    public static Boolean[] checkValues(WebDriver driver, String usecase, boolean navTo, Status log) throws Exception
    {
        String id = "";
        Boolean failed[] = {false,false,false,false,false};
        etest = (ExtentTest)etests.get(usecase);

        try
        {
            String allValues = ((String)values.get(usecase));
            
            if(navTo)
            {
                Tab.clickIntelligentTrigger(driver);
                Tab.clickVisitorRouting(driver);
            }
            
            if(allValues.equals("Error"))
            {
                result.put(usecase,false);
                etest.log(Status.FAIL,"Use case failed");
                return failed;
            }
            
            id = ((String)values.get(usecase)).split("/")[0];

            allValues = allValues.replace(id+"/","");

            Rules.openRuleEditView(driver,id);

            WebElement e = Rules.getRuleEditContainer(driver,id).findElement(By.id("newrule"));

            Dimension s = driver.manage().window().getSize();
            int x = s.height;

            int f = e.getLocation().y;
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            jse.executeScript("scroll(0,"+(f-(x/2))+")");
            
            String expected[] = allValues.split("/");

            String actualCriteria = Routing.getCriteria(driver,id);
            String actualConditon = Routing.getCondition(driver,id);
            String actualValue = Routing.getValue1(driver,id);
            String actualAction = Routing.getAction(driver,id);
            String actualUser = Routing.getUsers(driver,id);

            if(actualUser == null)
            {
                actualUser = "No User";
            }

            String actual[] = {actualCriteria,actualConditon,actualValue,actualAction,actualUser};
            
            for(int i = 0 ; i < actual.length; i++)
            {
                if(!actual[i].equals(expected[i]))
                {
                    etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                    failed[i] = true;
                }
                else
                {
                    etest.log(Status.INFO,expected[i]+" is present");
                }
            }
            
            boolean res = true;
            
            for(Boolean fail : failed)
            {
                if(fail)
                {
                    res = false;
                    break;
                }
            }

            if(!res)
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(usecase),"MismatchContent",0);
                result.put(usecase,false);
            }
            else
            {
                result.put(usecase,true);
            }
        }
        catch(Exception e)
        {
            result.put(usecase,false);
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckAddedValues","Error",e);
        }
        Rules.cancelRule(driver,etest,id);
        return failed;
    }

    public static void checkValues(WebDriver driver) throws Exception
    {
        Thread.sleep(15000);

        boolean navTo = true;
        for(String s : usecases)
        {
            Boolean failed[];
            if(navTo)
            {
                failed = checkValues(driver,s,true,Status.INFO);
                navTo = false;
            }
            else
            {
                failed = checkValues(driver,s,false,Status.INFO);
            }
            
            Boolean res = true;
            
            for(Boolean f : failed)
            {
                if(f)
                {
                    res = false;
                }
            }
            
            try
            {
                ExtentTest etest = (ExtentTest)etests.get(s);
                
                if(res)
                {
                    ComplexReportFactory.closeTest(etest);
                }
                else
                {
                    secondAttemptResult.put(s,failed);
                    
                    etest.log(Status.INFO,"<pre>Second attempt ...</pre>");
                    
                    fillFields(driver,etest,s,failed);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(s),"ErrorWhileChecking"+KeyManager.getRealValue(s),e);
                values.put(s,"Error");
            }
        }

        Set<String> secondAttemptUsecases = secondAttemptResult.keySet();
        
        if(secondAttemptUsecases.size() != 0)
        {
            Thread.sleep(15000);
        }
        
        navTo = true;
        
        for(String s : secondAttemptUsecases)
        {
            try
            {
                String value = values.get(s).toString();
                
                if(!value.equals("Error"))
                {
                    secondAttempt++;
                    
                    String id = value.split("/")[0];
                    
                    secondAttemptIds += id+";";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            if(navTo)
            {
                checkValues(driver,s,true,Status.FAIL);
                navTo = false;
            }
            else
            {
                checkValues(driver,s,false,Status.FAIL);
            }
            
            ExtentTest etest = (ExtentTest)etests.get(s);
            
            ComplexReportFactory.closeTest(etest);
        }
        
        accresDel(driver);

        values = new Hashtable();
        etests = new Hashtable();
        secondAttemptResult = new Hashtable();
        usecases = new Stack();
    }

    public static Boolean[] checkValuesCRM(WebDriver driver, String usecase, boolean navTo,Status log) throws Exception
    {
        String id = "";
        Boolean failed[] = {false,false,false,false,false,false};
        etest = (ExtentTest)etests.get(usecase);

        try
        {
            String allValues = ((String)values.get(usecase));
            
            if(navTo)
            {
                Tab.clickIntelligentTrigger(driver);
                Tab.clickVisitorRouting(driver);
            }
            
            if(allValues.equals("Error"))
            {
                result.put(usecase,false);
                etest.log(Status.FAIL,"Use case failed");
            }
            
            id = ((String)values.get(usecase)).split("/")[0];

            Rules.openRuleEditView(driver,id);

            allValues = allValues.replace(id+"/","");

            WebElement e = Rules.getRuleEditContainer(driver,id).findElement(By.id("newrule"));

            Dimension s = driver.manage().window().getSize();
            int x = s.height;

            int f = e.getLocation().y;
            
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll(0,0)");
            jse.executeScript("scroll(0,"+(f-(x/2))+")");
            
            String expected[] = allValues.split("/");

            String actualCriteria = Routing.getCriteria(driver,id);
            String actualSubCriteria = Routing.getSubCriteria(driver,id);
            String actualConditon = Routing.getCondition(driver,id);
            String actualValue = "";

            if(allValues.contains("Closing Date"))
            {
                actualValue = Routing.getValueFromDropDown(driver,id);
            }
            else
            {
                actualValue = Routing.getValue1(driver,id);
            }

            String actualAction = Routing.getAction(driver,id);
            String actualUser = Routing.getUsers(driver,id);

            String expectedUser = "Admin1";

            if(actualUser == null)
            {
                actualUser = "No User";
            }
            
            String actual[] = {actualCriteria,actualSubCriteria,actualConditon,actualValue,actualAction,actualUser};

            for(int i = 0 ; i < actual.length; i++)
            {
                if(!actual[i].equals(expected[i]))
                {
                    etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                    failed[i] = true;
                }
                else
                {
                    etest.log(Status.INFO,expected[i]+" is present");
                }
            }
            
            boolean res = true;
            
            for(Boolean fail : failed)
            {
                if(fail)
                {
                    res = false;
                    break;
                }
            }

            if(!res)
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(usecase),"MismatchContent",0);
                result.put(usecase,false);
            }
            else
            {
                result.put(usecase,true);
            }
        }
        catch(Exception e)
        {
            result.put(usecase,false);
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckAddedValues","Error",e);
        }

        Rules.cancelRule(driver,etest,id);
        return failed;
    }

    public static void checkValuesCRM(WebDriver driver) throws Exception
    {
        Thread.sleep(15000);

        boolean navTo = true;
        for(String s : usecases)
        {
            Boolean failed[];
            if(navTo)
            {
                failed = checkValuesCRM(driver,s,true,Status.INFO);
                navTo = false;
            }
            else
            {
                failed = checkValuesCRM(driver,s,false,Status.INFO);
            }
            
            Boolean res = true;
            
            for(Boolean f : failed)
            {
                if(f)
                {
                    res = false;
                }
            }
            
            try
            {
                ExtentTest etest = (ExtentTest)etests.get(s);
                
                if(res)
                {
                    ComplexReportFactory.closeTest(etest);
                }
                else
                {
                    secondAttemptResult.put(s,failed);
                    
                    etest.log(Status.INFO,"<pre>Second attempt ...</pre>");
                    
                    fillFieldsCRM(driver,etest,s,failed);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"VisitorRouting",KeyManager.getRealValue(s),"ErrorWhileChecking"+KeyManager.getRealValue(s),e);
                values.put(s,"Error");
            }
        }

        Set<String> secondAttemptUsecases = secondAttemptResult.keySet();
        
        if(secondAttemptUsecases.size() != 0)
        {
            Thread.sleep(15000);
        }
        
        navTo = true;
        
        for(String s : secondAttemptUsecases)
        {
            try
            {
                String value = values.get(s).toString();
                
                if(!value.equals("Error"))
                {
                    secondAttempt++;
                    
                    String id = value.split("/")[0];
                    
                    secondAttemptIds += id+";";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            if(navTo)
            {
                checkValuesCRM(driver,s,true,Status.FAIL);
                navTo = false;
            }
            else
            {
                checkValuesCRM(driver,s,false,Status.FAIL);
            }
            
            ExtentTest etest = (ExtentTest)etests.get(s);
            
            ComplexReportFactory.closeTest(etest);
        }
        
        accresDel(driver);

        values = new Hashtable();
        etests = new Hashtable();
        secondAttemptResult = new Hashtable();
        usecases = new Stack();
    }
    
    public static void fillFields(WebDriver driver, ExtentTest etest, String usecase, Boolean failed[]) throws Exception
    {
        String value[] = values.get(usecase).toString().split("/");
        
        String id = value[0];
        
        Rules.openRuleEditView(driver,id);

        WebElement e = Rules.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        Dimension s = driver.manage().window().getSize();
        int x = s.height;
        
        int f = e.getLocation().y;
        
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,0)");
        jse.executeScript("scroll(0,"+(f-(x/2))+")");
        
        etest.log(Status.INFO,"Filling fields for trigger id - "+id);

        Rules.setRuleName(driver,id,CommonUtil.getUniqueMessage());
        
        String cond = value[1];
        String qual = value[2];
        String val1 = value[3];
        String act = value[4];
        
        if(failed[0])
        {
            Routing.selectCriteria(driver,id,cond,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[1])
        {
            Routing.selectCondition(driver,id,qual,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[2])
        {
            Routing.selectValues(driver,id,val1,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[3] || failed[4])
        {
            Routing.selectAction(driver,id,act,"Admin1",etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        Thread.sleep(2000);
        
        Rules.saveRule(driver,etest,id);

        TakeScreenshot.screenshot(driver,etest,"VisitorRouting","Check","Before",0);
    }
    
    public static void fillFieldsCRM(WebDriver driver, ExtentTest etest, String usecase, Boolean failed[]) throws Exception
    {
        String value[] = values.get(usecase).toString().split("/");
        
        String id = value[0];

        Rules.openRuleEditView(driver,id);
        
        WebElement e = Rules.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        Dimension s = driver.manage().window().getSize();
        int x = s.height;
        
        int f = e.getLocation().y;
        
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,0)");
        jse.executeScript("scroll(0,"+(f-(x/2))+")");
        
        etest.log(Status.INFO,"Filling fields for trigger id - "+id);
        
        String cond1 = value[1];
        String cond2 = value[2];
        String qual = value[3];
        String val = value[4];
        String act = value[5];
        
        if(failed[0] || failed[1])
        {
            Routing.selectCriteria(driver,id,cond1,cond2,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[2])
        {
            Routing.selectCondition(driver,id,qual,etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[3])
        {
            if(cond2.equals("Closing Date"))
            {
                Routing.selectValuesInDropDown(driver,id,val,etest);
            }
            else
            {
                Routing.selectValues(driver,id,val,etest);
            }
            clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        if(failed[4] || failed[5])
        {
            Routing.selectAction(driver,id,act,"Admin1",etest);clickHeader(driver,id);
            Thread.sleep(1000);
        }
        
        Thread.sleep(2000);

        Rules.saveRule(driver,etest,id);

        TakeScreenshot.screenshot(driver,etest,"VisitorRouting","Check","Before",0);
    }
    
    public static void clickHeader(WebDriver driver, String id) throws Exception
    {
        WebElement e = Rules.getRuleEditContainer(driver,id).findElement(By.id("newrule"));
        
        WebElement f = CommonUtil.elementfinder(driver,e,"classname","trulesinfo");
        
        mouseHoverAndClick(driver, f);
    }
    
    public static void mouseHoverAndClick(WebDriver driver,WebElement element)
    {
        int x = element.getLocation().x;
        int y = element.getLocation().y;
        
        Actions actions = new Actions(driver);
        actions.moveByOffset(x, y).build().perform();
        actions.click().build().perform();
    }

     private static boolean checkDefaultIcons(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Tab.navToVRTab(driver);

            Routing.clickAdd(driver,etest);

            Tab.navToVRTab(driver);

            if (checkingIcons(driver,etest)==false)
            {               
               try
               {
                    driver.findElement(By.id("ldsettings")).findElement(By.className("canceldrag")).click();
               }
               catch(Exception e)
               {
                    System.out.println("Exception while close Advanced popup in intelligent triggers : "+e);
               }       
              System.out.println("failed");
              etest.log(Status.FAIL,"VisitorRouting Icons not Verified");
              Rules.cancelRule(driver,etest,"0");
              return false;
            }
            else
            {
               try
               {
                    driver.findElement(By.id("ldsettings")).findElement(By.className("canceldrag")).click();
               }
               catch(Exception e)
                {
                     System.out.println("Exception while close Advanced popup in intelligent triggers : "+e);
                }             
               etest.log(Status.PASS,"VisitorRouting Icons is Verified");
               Rules.cancelRule(driver,etest,"0");
               return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultIconsVisitorRouting","ErrorWhileCheckingDefaulticonsVisitorRouting",e);
            System.out.println("Exception while checking the default Icons in the VisitorRouting : "+e);
            Rules.cancelRule(driver,etest,"0");
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultIconsVisitorRouting","ErrorWhileCheckingDefaulticonsVisitorRouting",e);
            System.out.println("Exception while checking the default Icons in the VisitorRouting : "+e);
            Rules.cancelRule(driver,etest,"0");
            return false;
        }
    }
     public static boolean checkingIcons(WebDriver driver,ExtentTest etest) throws Exception
    {
        int failcount = 0;
        try
        {

        FluentWait wait = new FluentWait(driver);
        wait.withTimeout(30,TimeUnit.SECONDS);
        wait.pollingEvery(250,TimeUnit.MILLISECONDS);
        wait.ignoring(NoSuchElementException.class);

        String elid = Routing.getRuleId(driver,0);
        Rules.openRuleEditView(driver,elid);
        Rules.setRuleName(driver,elid,CommonUtil.getUniqueMessage());

        String type = "Visitor Routing";
        
        Routing.selectCriteria(driver,elid,"Browser",etest);clickHeader(driver,elid);
        Thread.sleep(1000);        
        WebElement e = CommonUtil.elfinder(driver,"id","prior"+elid+"_col3");
        e.click();
        if(CommonSikuli.browsericons(driver,type,"Default",etest)>0)
        {
            failcount++;
        }
        Routing.selectCriteria(driver,elid,"Operating System",etest);clickHeader(driver,elid);
        Thread.sleep(1000); 
        e.click();

        if (CommonSikuli.operatingsystemicons(driver,type,"Default",etest)>0)
        {
            failcount++;
        }

        Routing.selectCriteria(driver,elid,"Region",etest);clickHeader(driver,elid);
        Thread.sleep(1000); 
        e.click();
        if (CommonSikuli.regionIcons(driver,type,"Default",etest)>0)
         {
            failcount++;
         }

        WebElement adduser = CommonUtil.elfinder(driver,"classname","addrtusr");
        adduser.click();
        CommonSikuli.findInWholePage(driver,"Allavailableoperator.png","UI240",etest);
        CommonSikuli.findInWholePage(driver,"Lastchatattender.png","UI241",etest);

        Routing.selectCriteria(driver,elid,"Advanced",etest);clickHeader(driver,elid);
        CommonSikuli.findInWholePage(driver,"Visitorroutingsettings.png","UI214",etest);
        Thread.sleep(1000);
        e.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
        
       filldata(driver,"Browser");
        if (CommonSikuli.browsericons(driver,type,"Advanced",etest)>0)
        {
            failcount++;
        }

        filldata(driver,"Operating System");
        if (CommonSikuli.operatingsystemicons(driver,type,"Advanced",etest)>0)
        {
            failcount++;
        }

        filldata(driver,"Region");
        if (CommonSikuli.regionIcons(driver,type,"Advanced",etest)>0)
        {
            failcount++;
        }

        } 
         catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultIconsVisitorRouting","ErrorWhileCheckingDefaulticonsVisitorRouting",e);
            System.out.println("Exception while checking the default Icons in the VisitorRouting : "+e);
            failcount++;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"VisitorRouting","CheckDefaultIconsVisitorRouting","ErrorWhileCheckingDefaulticonsVisitorRouting",e);
            System.out.println("Exception while checking the default Icons in the VisitorRouting : "+e);
            failcount++;
        }
      
        return CommonUtil.returnResult(failcount);

    }

    public static void filldata(WebDriver driver, String type)
    {
        try
        {   
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver.findElement(By.id("prior1_col1")).click();
            CommonSikuli.findInWholePage(driver,"Visitorroutingsearch.png","UI212",etest);
            driver.findElement(By.id("prior1_col1_ddown")).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(type);
            driver.findElement(By.xpath(".//*[@id='prior1_col1_ddown']//*[contains(@title,'"+type+"')]")).click(); 
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='col3_input1']"))); 
        }
        catch(Exception e)
        {
            System.out.println("Exception while Fill data in VisitorRouting : "+e);
        }
    }
}
