//$Id$
package com.zoho.livedesk.client.Triggers;

import java.io.IOException;
import java.util.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import java.util.StringTokenizer;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.google.common.base.Function;
import org.openqa.selenium.interactions.Actions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.IntelligentTriggers;
import com.zoho.livedesk.util.common.CommonSikuli;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class CommonFunctions
{
    public static Long startTime = new Long(System.currentTimeMillis());
    public static Long triggerStartTime = new Long(System.currentTimeMillis());
    public static Long triggerEndTime = new Long(System.currentTimeMillis());
    
    public static Hashtable<Integer, String> rgb_value = new Hashtable<Integer, String>();
    
    public static boolean checkPosition(WebDriver driver,String fPos,String iPos,int waitingTime,int limit, String movement) throws Exception
    {
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();

        Long startTime = new Long(System.currentTimeMillis());
        
        String content = "";
        String endContent = "";
        switch(iPos)
        {
                
            case "left":
            {
                content = "visibility: hidden; display: block;";
                endContent = "visibility: hidden; display: block; right: 10px; left: POSITION2px;";
                break;
            }
            case "right":
            {
                content = "visibility: hidden; display: block;";
                endContent = "visibility: hidden; display: block; left: POSITION2px; right: 10px;";
                break;
            }
            case "bottom":
            {
                content = "visibility: hidden; display: block;";
                endContent = "visibility: hidden; display: block; top: POSITION2px; bottom: 10px;";
                break;
            }
            case "top":
            {
                content = "visibility: hidden; display: block;";
                endContent = "visibility: hidden; display: block; bottom: 10px; top: POSITION2px;";
                break;
            }
        }
        
        return checkAnimate(driver, content, endContent, movement);
        
    }
    
    public static boolean checkAnimate(WebDriver driver,String content,String endContent, String action) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver, 30, 250);
    	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();

        WebElement e1 = null;
        
        // Thread.sleep(10000);
        
        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float11"))
        {
        	 e1 = driver.findElement(By.id("zsiqbtn"));
        }
        else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqpersonalize")) {
        	
        	 e1 = driver.findElement(By.id("zsiqpersonalize"));
        }
        else if(driver.findElement(By.id("zsiq_float"))!=null) {
        	
        	 e1 = driver.findElement(By.id("zsiq_float"));
        }
        
        WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", e1);

        com.zoho.livedesk.util.common.CommonUtil.waitTillWebElementContainsAttributeValue(parent,"style","px");
        
        String initialPosition = parent.getAttribute("style");
        System.out.println("Initial position: "+ initialPosition);
        int initialLocation = Integer.parseInt(initialPosition.replace(content,"").replace("px;","").replace("top:", "").replace("bottom:", "").replace("right:", "").replace("left:", "").replace("auto;", "").replaceAll(" ", ""));
        int finalLocation;
        int position1 = -1;
        int position2 = -1;
        int j = 1;
        
        String s = "";
        
        Long startTime = new Long(System.currentTimeMillis());
        System.out.println("Start time :"+startTime);
        
        boolean toBeEnded = false;
        boolean started = false;
        int oppPosition2 = -1;
        int position3 ;
        
        int point1 = -1;
        int point2 = -1;
        int point3 = -1;
        
        for(int i = 0; i<3; i++)
        {
            Thread.sleep(15000);
            String currentPosition = parent.getAttribute("style");
            System.out.println("Curr Position: "+currentPosition);
            
            if(toBeEnded)
            {
            	
            	String finalPos =  currentPosition.replace(content,"").replace(" 10px;","").replace(" top:", "").replace(" bottom:", "").replace(" right:", "").replace(" left:", "").replaceAll("px;", "").replace(" ", "");
                System.out.print(finalPos);
            	if(finalPos.contains(".")) {
                	finalLocation = (int) Double.parseDouble(finalPos);
                }
                else {
                	finalLocation = Integer.parseInt(finalPos);
                }
                
            	if(action.equals("Horizontal")) {
                           
            	if(finalLocation - initialLocation >= 500) {
                 	          return true;
                            }
            	}else
            	{
            		if(finalLocation - initialLocation >= 1) {
            			return true;
            		}
            	}
                
            	Thread.sleep(200);
                return false;
                
            }
            else if(!currentPosition.equals(initialPosition))
            {
            	
                if(!currentPosition.contains("auto"))
                {
                	toBeEnded = true;
                    continue;
                }
                if(currentPosition.contains(content))
                {
                    if(!started)
                    {
                        System.out.println("triggerStartTime :"+triggerStartTime);
                        triggerStartTime = new Long(System.currentTimeMillis());
                        started = true;
                    }
                    
                    dateobj = new Date();
                    s += df.format(dateobj)+"--"+currentPosition+"\n";
                    
                    String pos = currentPosition.replace(content,"").replace("px;","").replace("top:", "").replace("bottom:", "").replace("right:", "").replace("left:", "").replace("auto;", "").replaceAll(" ", "");
                    System.out.println("pos :"+pos);
                    position2 = Integer.parseInt(pos);
                    System.out.println(position2);
                    if(position1 == -1)
                    {
                        position1 = position2;
                    }
                    else
                    {
                        if((position2 - position1) %10 == 0)
                        {
                            if(point3 == -1)
                            {
                                point3 = position2;
                                point2 = position1;
                            }
                            else
                            {
                                point1 = point2;
                                point2 = point3;
                                point3 = position2;
                                
                                if(!(point2 == position1 && point3 > point2 && point2 > point1))
                                {
                                    System.out.println("Point3 - "+point3+"--Point2 - "+point2+"--Point1 - "+point1+"--Position1 - "+position1);
                                    s += "Point3 - "+point3+"--Point2 - "+point2+"--Point1 - "+point1+"--Position1 - "+position1;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            break;
                        }
                        
                        position1 = position2;
                    }
                    
                    initialPosition = currentPosition;
                }
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2-startTime >= 45000)
                {
                    break;
                }
            }
        
        }
        dateobj = new Date();
        System.out.println("Intelligent trigger Animate button @"+df.format(dateobj)+"\n"+s);
        return false;
    }
    
    public static boolean checkGlow(WebDriver driver,int waitingTime,int limit) throws Exception
    {
        rgb_value.put(1, "132,205,208");
        rgb_value.put(2, "129,200,203");
        rgb_value.put(3, "126,195,198");
        rgb_value.put(4, "123,190,193");
        rgb_value.put(5, "120,185,188");
        rgb_value.put(6, "117,180,183");
        rgb_value.put(7, "114,175,178");
        rgb_value.put(8, "111,170,173");
        rgb_value.put(9, "108,165,168");
        rgb_value.put(10, "108,168,170");
        rgb_value.put(11, "110,172,174");
        rgb_value.put(12, "112,176,178");
        rgb_value.put(13, "114,180,182");
        rgb_value.put(14, "116,184,186");
        rgb_value.put(15, "118,188,190");
        rgb_value.put(16, "120,192,194");
        rgb_value.put(17, "122,196,198");
        rgb_value.put(18, "124,200,202");
        rgb_value.put(19, "126,204,206");
        rgb_value.put(20, "135,210,213");
        
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        System.out.println("Testing started @"+df.format(dateobj));
        startTime = new Long(System.currentTimeMillis());
        if(!checkGlowButton(driver))
        {
            dateobj = new Date();
            System.out.println("Testing ended @"+df.format(dateobj));
            return false;
        }
        dateobj = new Date();
        triggerEndTime = new Long(System.currentTimeMillis());
        System.out.println("Testing ended @"+df.format(dateobj));
        System.out.println("Trigggered after "+(triggerStartTime-startTime));
        System.out.println("Glowed time  --- "+(triggerEndTime-triggerStartTime));
        
        if(triggerStartTime-startTime >= (waitingTime-limit)*1000 && triggerStartTime-startTime <= (waitingTime+limit)*1000)
        {
            if(triggerEndTime-triggerStartTime >= 50000 && triggerEndTime-triggerStartTime <= 70000)
            {
                return true;
            }
        }
        
        return false;
    }
    
    public static boolean checkGlowButton(WebDriver driver) throws Exception {
        FluentWait wait = CommonUtil.waitreturner(driver, 30, 250);
        
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("zlslrgbtn-on-tit1")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("zlslrgbtn-on-tit1")));
        
        String initialColour = driver.findElement(By.className("zlslrgbtn-on-tit1")).getAttribute("style");
        String endColour = "background-color: rgb(135, 210, 213);";
        Long t1 = new Long(System.currentTimeMillis());
        
        String s = "";
        String currentColour1 = "";
        int i = 0;
        int j = 0;
        int k = 0;
        
        while (true) {
            String currentColour = driver.findElement(By.className("zlslrgbtn-on-tit1")).getAttribute("style");
            if (!currentColour.equals(initialColour)) {
                i++;
                
                dateobj = new Date();
                s += i + "--" +df.format(dateobj)+"--"+ currentColour + "\n";
                currentColour1 = currentColour;
                
                if (i == 1) {
                    System.out.println("Glow started @"+df.format(dateobj));
                    triggerStartTime = new Long(System.currentTimeMillis());
                }
                
                currentColour = currentColour
                .replace("background-color: rgb(", "")
                .replace(");", "").replace(" ", "");
                
                String[] rgb = currentColour.split(",");
                
                String r = rgb[0];
                String g = rgb[1];
                String b = rgb[2];
                
                int line = i % 20;
                if (line == 0) {
                    line = 20;
                }
                String[] value = rgb_value.get(line).split(",");
                
                String r1 = value[0];
                String g1 = value[1];
                String b1 = value[2];
                
                if ((r.equals(r1) && g.equals(g1) && b.equals(b1)))
                {}
                else
                {
                    System.out.println("here1");
                    int currentValueInSet = -1;
                    
                    for(Map.Entry entry: rgb_value.entrySet())
                    {
                        if(currentColour.equals(entry.getValue()))
                        {
                            currentValueInSet = Integer.parseInt(""+entry.getKey());
                            break;
                        }
                    }
                    
                    if(currentValueInSet == -1)
                    {
                        System.out.println("here");
                        break;
                    }
                    
                    int set = i/20;
                    int position = i%20;
                    
                    int currentValue = (set*20) + currentValueInSet;
                    
                    if(currentValueInSet < position)
                    {
                        currentValue = ((set+1)*20) + currentValueInSet;
                    }
                    
                    i = currentValue;
                }
                
                initialColour = currentColour1;
                
            }
            
            Long t2 = new Long(System.currentTimeMillis());
            
            if (i >= 480) {
                if (!currentColour.equals(endColour)) {
                    break;
                } else {
                    j++;
                    if (j == 10) {
                        return true;
                    }
                }
                Thread.sleep(200);
            }
            else if(i%20 == 0 && i >= 40 && t2-triggerStartTime >= 60000){
                if(currentColour1.equals(endColour))
                {
                    if(k++ >= 10)
                    {
                        return true;
                    }
                    
                    Thread.sleep(200);
                }
            }
            
            if (t2 - t1 >= 90000) {
                break;
            }
        }
        
        System.out.println(s);
        return false;
    }
    
    public static boolean checkOpenChat(WebDriver driver, int time)
    {
            try {
    	    FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            wait.until(new Function<WebDriver,Boolean>(){
              public Boolean apply(WebDriver driver)
                   {
                      if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                      {
                          return true;
                      }
                      return false;
                  }
              });
             return true;
            }catch(Exception e) {
            	e.printStackTrace();
            	return false;
            }
    }
    
    public static boolean checkSendChat(WebDriver driver,String agname,String message, int time) throws InterruptedException
    {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            try
            {
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                         {
                            if(driver.findElement(By.className("zls-sptwndw")).getAttribute("class").contains("siqanim"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            
            WebElement elmt = driver.findElement(By.id("siqiframe"));
            
            driver.switchTo().frame(elmt);
            try
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("siq-user-name")));
            }
            catch(Exception e)
            {
                return false;
            }
            
            String attname = driver.findElement(By.id("attname")).getText();
            String attmsgname = driver.findElement(By.className("siq-user-name")).getText();
            String attmsg = driver.findElement(By.id("msgdiv")).findElement(By.className("msgbx")).findElement(By.tagName("span")).getText();
            
            System.out.println("Name : "+attname+" ATT MNAME : "+attmsgname+" ATT MSG :"+attmsg);
            
            if(attname.equals(agname)&&attmsgname.equals(agname)&&attmsg.contains(message))
            {
                return true;
            }
            return false;
    }
    
    public static boolean checkShowButton(WebDriver driver, int time)
    {
    	
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            WebElement e1 = null;
           try {
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                { 
                        if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float11"))
                        {
                            return true;
                        }
                        else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiqpersonalize")) {
                        	
                        	return true;
                        }
                        else if(driver.findElement(By.tagName("body")).getAttribute("innerHTML").contains("zsiq_float")) {
                        	
                        	return true;
                        }
                        return false;
                }
            });
            return true;
    	}catch(Exception e) {
    		
    		e.printStackTrace();
    		return false;
    	}
            
    }
    
    public static boolean checkShowBubble(WebDriver driver)
    {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("zls-small")));
            
            if(driver.findElement(By.id("zlsbub")).findElement(By.id("zlsbubanim")).getAttribute("style").contains("block"))
            {
                return false;
            }
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("zlsbub")).findElement(By.id("zlsbubanim")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            return true;
    }
    
    public static void clickIntelligentTriggers(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_settings"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("settings_automationtab"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));
            
            driver.findElement(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("filterhd")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking open chat window of widget : ");
            e.printStackTrace();
        }
    }
    
    public static boolean checkNoRule(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addsuggtitle")));
            driver.findElement(By.id("addsuggtitle"));
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }
    
    public static void clickAddRuleButton(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(checkNoRule(driver))
            {
                driver.findElement(By.id("addsuggtitle")).findElement(By.id("addrule")).click();
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("data_row")));
                
            }
            else
            {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));
                
                List<WebElement> intcnt =driver.findElement(By.id("trouting")).findElements(By.className("data_row"));
                
                int rcount1 = 0;
                
                for(WebElement elmt:intcnt)
                {
                    rcount1++;
                }
                final int rcount = rcount1;
                
                driver.findElement(By.id("autobtnadd")).findElement(By.tagName("span")).click();
                
                Thread.sleep(1000);
                wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           List<WebElement> intcnt1 = driver.findElement(By.id("trouting")).findElements(By.className("data_row"));
                           int rcountchk = 0;
                           
                           for(WebElement elmt:intcnt1)
                           {
                               rcountchk++;
                           }
                           if(rcountchk == (rcount+1))
                           {
                               return true;
                           }
                           return false;
                       }
                   });
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking open chat window of widget : ");
            e.printStackTrace();
        }
    }
    
    public static void applyRule(WebDriver driver,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
       applyRule(driver,ITRTime.etest,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,true); 
    }
    public static void applyRule(WebDriver driver,ExtentTest etest,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
        applyRule(driver,etest,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,false); 
    }
    
    public static void applyRule(WebDriver driver,ExtentTest etest,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4,boolean isSelectEmbed) throws Exception
    {        
        Tab.navToITTab(driver);
        
        Trigger.clickAdd(driver,etest);
        
        String id = Trigger.getRuleId(driver,0);
        System.out.println("ID from inside \"Apply Rule\":"+id);
        
        Boolean allTrue[] = {true,true,true,true,true,true,true,true,true};

        Trigger.openRuleEditView(driver,id);
        
        fillFields(driver,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,allTrue,isSelectEmbed);
        if(actionr1.equals("Add to mailing list"))
        {
            etest.log(Status.INFO,"Trigger is added");
            return;
        }

        id = Trigger.getRuleId(driver,0);

        boolean res = true;
        
        Boolean failed[] = checkValues(driver,etest,Status.INFO,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4);
        
        for(Boolean f : failed)
        {
            if(f)
            {
                res = false;
                break;
            }
        }
        
        if(res)
        {
            etest.log(Status.INFO,"Trigger is added");
        }
        else
        {
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggerRT","CheckRuleAdded","Error",0);
            
            etest.log(Status.INFO,"<pre>Second attempt ... </pre>");

            fillFields(driver,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,failed,isSelectEmbed);
            
            id = Trigger.getRuleId(driver,0);

            res = true;
            
            Boolean failed2[] = checkValues(driver,etest,Status.INFO,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4);
            
            for(Boolean f : failed2)
            {
                if(f)
                {
                    res = false;
                    break;
                }
            }
            
            if(res)
            {
                etest.log(Status.INFO,"Rule is added after second attempt");
                ITRTime.secondAttempt++;
                ITRTime.secondAttemptIds += id+";";
            }
            else
            {
                TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggerRT","CheckRuleAdded","Error");
                String s = null;
                s.replace("","to break the flow");
            }
        }
        
        Thread.sleep(3000);
    }
    
    public static void fillFields(WebDriver driver, ExtentTest etest, String id, String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3, String actionr4, Boolean failed[]) throws Exception
    {
        fillFields(driver,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,failed,false);
    }
    
    public static void fillFields(WebDriver driver, ExtentTest etest, String id, String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3, String actionr4, Boolean failed[],boolean isSelectEmbed) throws Exception
    {
        if(isSelectEmbed)
        {
            Rules.selectEmbed(driver,"embed2");
        }

        if(failed[0])
        {
            Trigger.selectVisitorEvent(driver,id,event,etest);

            Trigger.saveRule(driver,etest,id);
            Trigger.openRuleEditView(driver,id);
        }

        Trigger.setRuleName(driver,id,com.zoho.livedesk.util.common.CommonUtil.getUniqueMessage());
        
        if(failed[1])
        {
            Trigger.selectCriteria(driver,id,ruler1,etest);
        }
                
        if(failed[2])
        {
            Trigger.selectCondition(driver,id,ruler2,etest);
        
        }
        
        if(failed[3] || failed[4])
        {
            Trigger.selectValues(driver,id,ruler3,ruler4,etest);
        }
        
        if(failed[5] || failed[6] || failed[7] || failed[8])
        {
            if((actionr1.equals("Open chat window"))||(actionr1.equals("Glow button"))||(actionr1.equals("Show bubble"))||(actionr1.equals("Show button")))
            {
                Trigger.selectAction(driver,id,actionr1,actionr2,etest);
            }
            else if((actionr1.equals("Send chat invite")) || (actionr1.equals("Invoke JS API")))
            {
                Trigger.selectAction(driver,id,actionr1,actionr2,actionr3,actionr4,etest);
            }
            else if(actionr1.equals("Animate button"))
            {
                Trigger.selectAction(driver,id,actionr1,actionr2,etest);
                Trigger.selectActionAnimate(driver,id,actionr3,etest);
            }
            else if(actionr1.equals("Add to mailing list"))
            {
            	selectActionMailingList(driver,id);
                Thread.sleep(1500);
    	    	WebElement popup=HandleCommonUI.getPopupByInnerText(driver,"Add visitors to the Campaign Mailing List");
		    	com.zoho.livedesk.util.common.CommonWait.waitTillDisplayed(popup);
                Thread.sleep(1000); //to load completely
                etest.log(Status.INFO,"DESC "+popup.getText());
                HandleCommonUI.clickNegativePopupButton(popup);
            }
        }
        
        Trigger.saveRule(driver,etest,id);
        
        TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggerRT","Check","Before",0);
        
        Thread.sleep(10000);
        
        etest.log(Status.INFO,"Waited for 10 secs ...");
        
        driver.navigate().refresh();
    }
    
    public static Boolean[] checkValues(WebDriver driver, ExtentTest etest, Status log, String id,String event,String ruler1,String ruler2,String ruler3,String ruler4,String actionr1,String actionr2,String actionr3,String actionr4) throws Exception
    {
        Trigger.openRuleEditView(driver,id);

        Boolean failed[] = {false,false,false,false,false,false,false,false,false};
        
        String actualVisitorEvent = Trigger.getVisitorEvent(driver,id);
        String actualCriteria = Trigger.getCriteria(driver,id);
        String actualCondition = Trigger.getCondition(driver,id);
        String actualValue = Trigger.getValue1(driver,id);
        String actualAction = Trigger.getAction(driver,id);
        String actualTime = Trigger.getActionTime(driver,id);
        System.out.println("Actual visitor event :"+actualVisitorEvent+"Actual criteria: "+actualCriteria+"Actual condition: "+actualCondition+"Actual action: "+ actualAction+"Actual value :"+actualValue+"Actual action time :"+actualTime);
        
        String actualValue2 = null;
        String actualValue3 = null;
        String actualValue4 = null;
        
        if(ruler4 != null)
        {
            actualValue2 = Trigger.getValue2(driver,id);
        }
        
        if(actionr3 != null)
        {
            if(actionr1.equals("Animate button"))
            {
                actualValue3 = Trigger.getActionValueAnimate(driver,id);
            }
            else
            {
                actualValue3 = Trigger.getActionValue1(driver,id);
            }
        }
        
        if(actionr4 != null)
        {
            actualValue4 = Trigger.getActionValue2(driver,id);
        }
        
        String expected[] = {event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4};
        String actual[] = {actualVisitorEvent,actualCriteria,actualCondition,actualValue,actualValue2,actualAction,actualTime,actualValue3,actualValue4};
        
        for(int i = 0 ; i < actual.length; i++)
        {
            if(expected[i] == null)
            {
                continue;
            }
            
            if(!actual[i].equals(expected[i]))
            {
                etest.log(log,"<pre>Expected:"+expected[i]+"--Actual:"+actual[i]+"--</pre>");
                failed[i] = true;
            }
            else
            {
                etest.log(Status.INFO,expected[i]+" is present");
            }
        }

        Trigger.saveRule(driver,etest,id);
        
        return failed;
    }
    
    public static void deleteRule(WebDriver driver)
    {
        com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);
    }
    
    public static void navigateToOther(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonUtil.elfinder(driver,"id","refbutton").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.getCurrentUrl().contains("referral"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));
        }
        catch(Exception e)
        {
            System.out.println("Exception while navigating to referral page in intelligent triggers : "+e);
        }
    }

    public static void ruleView(WebDriver driver,int i,Boolean chk,ExtentTest etest) throws InterruptedException, Exception
    {
        List<WebElement> list = Trigger.getList(driver);
        final int count = list.size();
        System.out.println(count+"count");
        String ruleid = list.get(i).getAttribute("ruleid");

        if (chk==false)
        {
            if (Trigger.isRuleEnabled(driver,ruleid))
            {   
                System.out.println("trules_"+ ruleid +"" + "-----" + i);
                System.out.println("stat_"+ ruleid +"" + "-----" + i);
                enalbeDisableclick(driver,ruleid);
                Tab.waitForLoadingSuccessWithBanner(driver,"Rule has successfully been disabled!","updaterulestatus.do",ITRTime.etest);
                ITRTime.etest.log(Status.INFO,"Rule disabled"); 
            }
            else
            {
                System.out.println("Rule already disabled");
                ITRTime.etest.log(Status.INFO,"Rule Disabled"); 
            } 
        }
        if (chk==true)
        {
            if (Trigger.isRuleEnabled(driver,ruleid)==false)
            {   
                enalbeDisableclick(driver,ruleid);
                Tab.waitForLoadingSuccessWithBanner(driver,"Rule has successfully been enabled!","updaterulestatus.do",ITRTime.etest);
                ITRTime.etest.log(Status.INFO,"Rule Enabled"); 
            }
            else
            {
                System.out.println("Rule already enabled");
                ITRTime.etest.log(Status.INFO,"Rule Enabled"); 
            } 
        }
    }

    public static boolean disablerule(WebDriver driver,String ruleid)throws InterruptedException, Exception
    {   
        if (Trigger.isRuleEnabled(driver,ruleid))
        {
            enalbeDisableclick(driver,ruleid);
            Tab.waitForLoadingSuccessWithBanner(driver,"Rule has successfully been disabled!","updaterulestatus.do",ITRTime.etest);

            if (Trigger.isRuleEnabled(driver,ruleid)==false)
            {
                ITRTime.etest.log(Status.PASS,"Rule Disabled");
                return true; 
            }
            else
            {  
                TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","Disablerule","Error");
                ITRTime.etest.log(Status.FAIL,"Rule not disabled");
                return false; 
            }   
        }
       
        if (Trigger.isRuleEnabled(driver,ruleid)==false)
        {
            System.out.println("Rule already disabled");
            enalbeDisableclick(driver,ruleid);
            Tab.waitForLoadingSuccessWithBanner(driver,"Rule has successfully been enabled!","updaterulestatus.do",ITRTime.etest);
            System.out.println("Rule enable to check disabled flow..");  
            enalbeDisableclick(driver,ruleid);
            Tab.waitForLoadingSuccessWithBanner(driver,"Rule has successfully been disabled!","updaterulestatus.do",ITRTime.etest);

            if (Trigger.isRuleEnabled(driver,ruleid)==false)
            {
                ITRTime.etest.log(Status.PASS,"Rule Disabled");
                return true; 
            }
            else
            {  
                TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","Disablerule","Error");
                ITRTime.etest.log(Status.FAIL,"Rule not disabled");
                return false; 
            }   
        }
        return false;
    }

    public static void enablerule(WebDriver driver,String ruleid) throws InterruptedException, Exception
    {   
        if (Trigger.isRuleEnabled(driver,ruleid))
        {
            enalbeDisableclick(driver,ruleid);
            Tab.waitForLoadingSuccessWithBanner(driver,"Rule has successfully been enabled!","updaterulestatus.do",ITRTime.etest);
            if (Trigger.isRuleEnabled(driver,ruleid))
            {
                ITRTime.etest.log(Status.PASS,"Rule Enabled");
            }
            else
            {  
                TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","Enablerule","Error");
                ITRTime.etest.log(Status.FAIL,"Rule not Enabled");
            }   
        }
    } 

    public static void enalbeDisableclick(WebDriver driver,String ruleid) throws Exception
    {
        Trigger.toggleRuleStatus(driver,ruleid);       
    }   

    public static void accresDel(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            Tab.navToITTab(driver);

            for(int i=0;i<=10;i++)
            {
                if(Trigger.ruleExist(driver))
                {
                    List<WebElement> list = Trigger.getList(driver);
                    
                    final int count = list.size();

                    System.out.println("For deleting" + count);

                    WebElement elmtch = list.get(0);

                    IntelligentTriggers.mouseOver(driver,elmtch);

                    CommonUtil.elementfinder(driver,elmtch,"classname","sqico-delico").click();

                    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("okbtn")));
                    
                    CommonUtil.elfinder(driver,"id","okbtn").click();

                    final WebElement e = CommonUtil.elfinder(driver,"id","popupdiv");

                    wait.until(new Function<WebDriver,Boolean>()
                    {
                        public Boolean apply(WebDriver driver)
                        {
                            if(e.getAttribute("innerHTML").equals(""))
                            {
                                return true;
                            }
                            return false;
                        }
                    });

                    Tab.waitForLoadingSuccessWithBanner(driver,"Rule deleted Successfully","deleterule.do",ITRTime.etest);

                    if(count == 1)
                    {
                        if(!Routing.ruleExist(driver))
                        {
                            return;
                        }
                    }

                    wait.until(new Function<WebDriver,Boolean>()
                    {
                        public Boolean apply(WebDriver driver)
                        {
                            try
                            {
                                int finalCount = Trigger.getList(driver).size();
                            
                                if(finalCount == (count - 1))
                                {
                                    return true;
                                }
                            }
                            catch(Exception e)
                            {}
                            return false;
                        }
                    });

                    Thread.sleep(500);
                }
                else
                {
                    break;
                }
            }
        }
        catch(NoSuchElementException e)
        {
            System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        }
        catch(Exception e)
        {
            System.out.println("Exception while deleting rules to avoid access restricted issue in intelligent triggers : "+e);
        }
    }

    public static void selectActionMailingList(WebDriver driver,String id)
    {
    	WebElement action_div=com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("action_"+id));
    	com.zoho.livedesk.util.common.CommonUtil.clickWebElement(driver,action_div);
    	com.zoho.livedesk.util.common.CommonWait.waitTillDisplayed(driver,By.id("action_"+id+"_ddown"));
    	HandleCommonUI.chooseFromDropdown( com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("action_"+id+"_ddown")) , "Add to mailing list" );
    }

}
