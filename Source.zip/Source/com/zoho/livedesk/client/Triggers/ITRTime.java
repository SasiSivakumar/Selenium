//$Id$
package com.zoho.livedesk.client.Triggers;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.zoho.livedesk.client.WebEmbedSettings;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.IntelligentTriggers;


import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.AutomationRuleCountCheck;

import com.google.common.base.Function;

public class ITRTime
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    
    private static String url = "";
    public static ExtentTest etest;
    
    public static int secondAttempt = 0;
    public static String secondAttemptIds = "";
    public static String widget_Code;
    public static String widget_Code1;
    public static String embed_name;
    public static String embed_name1;
        
    public static Hashtable rTimeCheck(WebDriver driver)
    {
        try
        {
            secondAttempt = 0;
            secondAttemptIds = "";
            result = new Hashtable();
            widget_Code = ExecuteStatements.getWidgetCode(driver);
            embed_name=ExecuteStatements.getDefaultEmbedName(driver);      
            
            // This usecase needs separate portal. To reduce additional portal creation for 1 usecase, have added this usecase along with leadscoring module
            // WebDriver driver1 ;     
            // driver1 =Functions.setUp();
            // Functions.login(driver1,"it_real_time_rule_check");
            // embed_name1=ExecuteStatements.getDefaultEmbedName(driver1);
            // widget_Code1 = ExecuteStatements.getWidgetCode(driver1);
            
            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR34"));
            // ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            // result.put("ITR34", getTriggerCountOnITRule(driver1, etest, widget_Code1, embed_name1));         
            // ComplexReportFactory.closeTest(etest);
            
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR1"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");          
            url = ConfManager.requestURL();                                
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
            
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_automationtab"))));
            
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("settings_automationtab")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("automationtab_intelligenttriggers"))));
            
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("automationtab_intelligenttriggers")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("filterhd")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            
            result.put("ITR1",true);

            etest.log(Status.PASS,"Intelligent Triggers Tab is present");

            com.zoho.livedesk.util.Cleanup.deleteAllTriggers(driver);

            CommonFunctions.deleteRule(driver);
            ComplexReportFactory.closeTest(etest); 
            
                  
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR2"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR2",checkBrowser(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
            
            ComplexReportFactory.closeTest(etest);
           
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR3"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR3",checkCampaign(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                        
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR4"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR4",checkCurrTitle(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                        
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR5"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR5",checkCurrURL(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                        
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR6"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR6",checkVisSource(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                        
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR7"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

          
            result.put("ITR7",checkCurrDept(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);               
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR8"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR8",checkEmailID(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR10"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR10",checkLandPageTitle(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR11"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR11",checkLandPageURL(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR12"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR12",checkLastAction(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR13"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR13",checkPastChats(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR14"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR14",checkURLAcc(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR15"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR15",checkVisits(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR16"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR16",checkOpSys(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR18"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR18",checkRef(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR19"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR19",checkSearchEngine(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR20"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR20",checkTime(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR22"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR22",checkVisAvail(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR24"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR24",checkVisitSource(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR25"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            result.put("ITR25",checkVisType(driver, widget_Code,embed_name));
            CommonFunctions.deleteRule(driver);
                                    
            ComplexReportFactory.closeTest(etest);
            
            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR26"));
            // ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");

            // result.put("ITR26",checkEmbed(driver, widget_Code,embed_name));
            // CommonFunctions.deleteRule(driver);
            
            // ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR27"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR27",intelligenttriggerDisable(driver,embed_name,0));
            CommonFunctions.accresDel(driver);                        
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR28"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR28",intelligenttriggerEnable(driver,embed_name,0));
            CommonFunctions.accresDel(driver);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR29"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR29",checkEnableDisableRule(driver,embed_name,null,false,true,widget_Code));
            CommonFunctions.accresDel(driver);
            ComplexReportFactory.closeTest(etest);
              
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR30"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR30",checkEnableDisableRule(driver,embed_name,false,true,false, widget_Code));
            CommonFunctions.accresDel(driver);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR31"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR31",checkEnableDisableRule(driver,embed_name,false,false,true, widget_Code));
            CommonFunctions.accresDel(driver);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR32"));
            ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            result.put("ITR32",checkEnableDisableRule(driver,embed_name,null,false,false, widget_Code));
            CommonFunctions.accresDel(driver);
            ComplexReportFactory.closeTest(etest);
           
            // This usecase needs separate portal. To reduce additional portal creation for 1 usecase, have added this usecase along with leadscoring module
            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("ITR35"));
            // ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
            // result.put("ITR35",checkTriggerCountOnITRule(driver1,etest, widget_Code1));
            // CommonFunctions.deleteRule(driver1);
            // ComplexReportFactory.closeTest(etest);
            // driver1.quit();
           
            
            
            if(secondAttempt != 0)
            {
                etest=ComplexReportFactory.getTest("Intelligent Triggers RT - Successful addition only after second attempt");
                ComplexReportFactory.setValues(etest,"Automation","Intelligent Triggers - Real Time");
                
                etest.log(Status.FAIL,"Number of second attempts:"+secondAttempt);
                etest.log(Status.FAIL,"Ids - "+secondAttemptIds);
                
                ComplexReportFactory.closeTest(etest);
            }
            
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            result.put("ITR1", false);
        }
        catch(Exception e)
        {
        	e.printStackTrace();
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            
            System.out.println("~~Module breakage occurred");
            result.put("ITR1", false);
        }
        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }
    
    
	
	public static boolean getTriggerCountOnITRule(WebDriver driver1, ExtentTest etest, String widget_Code,String embedName) {		
		try {
			
            Tab.navToIntelligentTriggersTab(driver1);
            CommonFunctions.deleteRule(driver1);
            
			if(!AutomationRuleCountCheck.checkITRuleBrowser(driver1,etest,widget_Code,embedName)) 
			{				
				etest.log(Status.FAIL, "Browser Rule not Created");
				TakeScreenshot.screenshot(driver1,"Intelligent Trigger-RT", "Trigger Rule Count Check", "Browser rule not created ");
				return false;
			}
			etest.log(Status.PASS, "Browser Rule Created");
			TakeScreenshot.infoScreenshot(driver1, etest);		
			AutomationRuleCountCheck.getITRuleCount(driver1, etest);			
			return true;
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver1, etest, "Intelligent Trigger-RT", "Trigger Rule Count Check", "Count not Checked", e);
		}		
		return false;	
	}
  
	
	public static boolean checkTriggerCountOnITRule(WebDriver driver, ExtentTest etest, String widget_Code) {		
		try {
			
			Tab.navToIntelligentTriggersTab(driver);	
			
			if(!AutomationRuleCountCheck.checkITRuleCountCheck(driver, etest)) {
				etest.log(Status.FAIL, "Trigger Count Check is not Increased for Intelleigent Trigger");
		    	TakeScreenshot.screenshot(driver, "Intelligent Trigger-RT", "Trigger Rule Count Check", "Count not Checked");
		    	return false;
			}
			etest.log(Status.PASS, "Trigger Count Check is Increased for Intelleigent Trigger" );
			TakeScreenshot.infoScreenshot(driver, etest);				
		    return true;
           
		}
		catch(Exception e) {
			TakeScreenshot.screenshot(driver, etest, "Intelligent Trigger-RT", "Trigger Rule Count Check", "Count not Checked", e);
		}		
		return false;	
	}
	
	
    
    public static boolean checkBrowser(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Browser","is equal to","Google Chrome",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);

            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the browser");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Browser","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Browser","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
            
            
            
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor browser is equal to chrome in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","Browser","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkCampaign(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
        	String username=ExecuteStatements.getUserName(driver);
        	
            CommonFunctions.applyRule(driver,"Lands on my website","Campaign Name","is equal to","SalesIQ Testing",null,"Send chat invite","5 Seconds", username, "Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createCampaign(widget_Code, "SalesIQ Testing");
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver, username, "Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the campaign name");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Campaign","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Campaign","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Campaign name is equal to SalesIQ Testing in Intelligent Triggers module");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","Campaign","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkCurrTitle(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Current Page Title","is equal to","SalesIQ Testing",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on their current title");
                    visdriver.quit();
                    return true;
                }
                else
                {
                	etest.log(Status.FAIL, "Visitors are not triggered based on current title");
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentPageTitle","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentPageTitle","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking current page title is equal to SalesIQ testing in Intelligent triggers module");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","CurrentPageTitle","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    /**
     * @param driver
     * @param widget_Code
     * @return
     * @throws InterruptedException
     */
    public static boolean checkCurrURL(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username=ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Current Page URL","contains","visitor",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on their current url");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentPageURL","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentPageURL","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking current page url contains visitor in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","CurrentPageURL","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisSource(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username = ExecuteStatements.getUserName(driver);
            
            CommonFunctions.applyRule(driver,"Lands on my website","Current Visit Source","is equal to","Referral",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createReferralPage(widget_Code);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on their source");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentPageURL","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentPageURL","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking current visitor source is equal to referral in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","CurrentPageURL","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkCurrDept(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username = ExecuteStatements.getUserName(driver);
            
            CommonFunctions.applyRule(driver,"Lands on my website","Department","is equal to","automation3",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createAPIPage(widget_Code,"depbutton");
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Checked");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentDept","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","CurrentDept","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking department is equal to automation3 in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","CurrentDept","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkEmailID(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
        	String username = ExecuteStatements.getUserName(driver);
        	
            CommonFunctions.applyRule(driver,"Lands on my website","Email Address","contains","zohocorp",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createAPIPage(widget_Code, "email");
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on Email-ID");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","EmailId","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","EmailId","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Email Address contains @zohocorp.com in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","EmailId","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkIPAddr(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","IP Address","is between","100.101"+".1.1","255.255"+".255.255","Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on IP Address");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","IPAddr","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","IPAddr","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking IP Address is between 100.101.1.1 and 255.255.255.255 in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","IPAddr","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkLandPageTitle(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Landing Page Title","is not equal to","Zoho SalesIQ",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the landing page title");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","LandingPageTitle","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","LandingPageTitle","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking landing page title is not equal to Zoho SalesIQ in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","LandingPageTitle","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkLandPageURL(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username=ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Landing Page URL","doesn't contain",".zoho.com",null,"Send chat invite","5 Seconds",username,"May I help you ? ...");
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"May I help you ? ...", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the landing page url");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","LandingPageURL","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","LandingPageURL","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking Landing page url doesn't contain .zoho.com in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","LandingPageURL","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkLastAction(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
        	String username = ExecuteStatements.getUserName(driver);
        	
            CommonFunctions.applyRule(driver,"Lands on my website","Last Action Performed","is equal to","Accessed",null,"Send chat invite","5 Seconds", username, "Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver, username, "Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the last action");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","LastAction","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","LastAction","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking last action performed is equal to Accessed in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","LastAction","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkPastChats(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username = ExecuteStatements.getUserName(driver);
            
            CommonFunctions.applyRule(driver,"Lands on my website","Number of Past Chats","is less than","2",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on Past chats");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","PastChats","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","PastChats","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking number of past chats is less than 2 in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","PastChats","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkURLAcc(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username = ExecuteStatements.getUserName(driver);
            
            CommonFunctions.applyRule(driver,"Lands on my website","Number of URLs Accessed","is less than","4",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the number of URLs accessed");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","NoOfURLs","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","NoOfURLs","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking number of URLs accessed is less than 4 in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","NoOfURLs","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisits(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
        	String username = ExecuteStatements.getUserName(driver);
        	
            CommonFunctions.applyRule(driver,"Lands on my website","Number of Visits","is less than","2",null,"Send chat invite","5 Seconds", username, "Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver, username, "Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the number of visits");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","NoOfVisits","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","NoOfVisits","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking number of vsits is less than 2 in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","NoOfVisits","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkOpSys(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Operating System","is not equal to","PlayStation",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the Operating system");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","OperatingSystem","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","OperatingSystem","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking operating system is not equal to PlayStation in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","OperatingSystem","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkPrevURL(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Previous Page URL","contains","zohosites",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            CommonFunctions.navigateToOther(visdriver);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the prevoius URL visited");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","PrevURL","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","PrevURL","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checkingPrevious page URL contains \"zohosites\"chrome in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","PrevURL","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkRef(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username = ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Referrer","contains","visitor",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createReferralPage(widget_Code);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the referrer");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Referrer","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Referrer","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking referrer contains visitor in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","Referrer","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkSearchEngine(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
        	String username = ExecuteStatements.getUserName(driver);
        	
            CommonFunctions.applyRule(driver,"Lands on my website","Search Engine","is equal to","Google",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.referrerPage("http://www.google.com", widget_Code);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Checked");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","SearchEngine","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","SearchEngine","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking search engine is equal to google in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","SearchEngine","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkTime(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Time on Site","is more than","5 Seconds",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the time spent by them on the site");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","TimeonSite","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","TimeonSite","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking time on site is more than 5 seconds in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","TimeonSite","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisAvail(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Visitor Availability","is equal to","Available",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Checked");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","VisitorAvailability","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","VisitorAvailability","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking availability is equal to available in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","VisitorAvailability","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisitSource(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username=ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Visitor Source","is equal to","Campaign",null,"Send chat invite","5 Seconds",username,"May I help you ? ...");
            
            visdriver = VisitorSite.createCampaign(widget_Code,"SalesIQ Testing");
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"May I help you ? ...", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the visitor source");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","VisitSource","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","VisitSource","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor source is equal to campaign in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","VisitSource","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkVisType(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            CommonFunctions.applyRule(driver,"Lands on my website","Visitor Type","is not equal to","Returning",null,"Invoke JS API","5 Seconds","test",null);
            
            visdriver = VisitorSite.createPage(widget_Code);
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkOpenChat(visdriver, 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on their type");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","VisitorType","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","VisitorType","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor type is equal to returning in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","VisitorType","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }
    
    public static boolean checkEmbed(WebDriver driver, String widget_Code, String embedName) throws InterruptedException
    {
        WebDriver visdriver = null;
        
        try
        {
            String username = ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Websites","is equal to","embed2",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");
            
            visdriver = VisitorSite.createAPIPage(widget_Code,"button");
            
            Thread.sleep(8000);
            
            try
            {
                if(CommonFunctions.checkSendChat(visdriver,username,"Welcome to Zoho SalesIQ", 5))
                {
                    etest.log(Status.PASS,"Visitors are triggered based on the Website");
                    visdriver.quit();
                    return true;
                }
                else
                {
                    TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","WebEmbed","Error");
                    visdriver.quit();
                    Thread.sleep(1000);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","WebEmbed","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            }
        }
        catch(Exception e) {
     
            System.out.println("Exception while checking websites is equal to embed2 in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","WebEmbed","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }

    public static boolean intelligenttriggerDisable(WebDriver driver,String embedName,int i) throws InterruptedException
    {        
        try
        {
            String username = ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Browser","is equal to","Google Chrome",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");

            List<WebElement> list = Trigger.getList(driver);
            
            final int count = list.size();
            System.out.println(count+"count");
            String ruleid = list.get(i).getAttribute("ruleid");
            
            if (CommonFunctions.disablerule(driver,ruleid)==true) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }          
        catch(Exception e)
        {
            System.out.println("Exception while checking visitor browser is equal to chrome in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","WebEmbed","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }         

    public static boolean intelligenttriggerEnable(WebDriver driver,String embedName,int i) throws InterruptedException
    {        
        try
        {
            String username = ExecuteStatements.getUserName(driver);

            CommonFunctions.applyRule(driver,"Lands on my website","Browser","is equal to","Google Chrome",null,"Send chat invite","5 Seconds",username,"Welcome to Zoho SalesIQ");

            List<WebElement> list = Trigger.getList(driver);
            final int count = list.size();
            System.out.println(count+"count");
            String ruleid = list.get(i).getAttribute("ruleid");
            
            CommonFunctions.disablerule(driver,ruleid); 
            System.out.println("Rule disabled");

            
            String ruletype = list.get(i).getAttribute("status");
            if (ruletype.equals("disable"))
            {
                CommonFunctions.enablerule(driver,ruleid);
                return true;
            }

            return false;
        }          
        catch(Exception e)
        {
        	e.printStackTrace();
            System.out.println("Exception while checking visitor browser is equal to chrome in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","WebEmbed","Error",e);
            Thread.sleep(1000);
            return false;
        }
    }    

    public static boolean checkEnableDisableRule(WebDriver driver,String embedName,Boolean rule1,Boolean rule2,Boolean rule3, String widget_Code) throws InterruptedException
    {
        WebDriver visdriver = null;
        int failcount = 0;
        String username = ExecuteStatements.getUserName(driver);

        int rule_count = 1;
        
        try
        {
            if (rule1==null)
            {
                CommonFunctions.applyRule(driver,"Lands on my website","Browser","is equal to","Google Chrome",null,"Invoke JS API","10 Seconds","test",null);
                CommonFunctions.applyRule(driver,"Lands on my website","Country","is equal to","India, United Kingdom",null,"Send chat invite","10 Seconds",username,"Welcome to Zoho SalesIQ");
    
                etest.log(Status.INFO,"2 rules added");

                CommonFunctions.ruleView(driver,0,rule2,etest); 
                CommonFunctions.ruleView(driver,1,rule3,etest); 
            }

            else
            {
                          	
              CommonFunctions.applyRule(driver,"Lands on my website","Browser","is equal to","Google Chrome",null,"Invoke JS API","10 Seconds","test",null);
              CommonFunctions.applyRule(driver,"Lands on my website","Country","is equal to","India, United Kingdom",null,"Send chat invite","10 Seconds",username,"Welcome to Zoho SalesIQ");
              CommonFunctions.applyRule(driver,"Lands on my website","Campaign Name","is equal to","SalesIQ Testing",null,"Send chat invite","10 Seconds", username, "Welcome to SalesIQ");

              etest.log(Status.INFO,"3 rules added");

              CommonFunctions.ruleView(driver,0,rule1,etest); 
              CommonFunctions.ruleView(driver,1,rule2,etest);
              CommonFunctions.ruleView(driver,2,rule3,etest);
             
             }    

            try
            {   
                
                if(rule1 != null)
                {
                
                    visdriver = VisitorSite.createCampaign(widget_Code,"SalesIQ Testing");
              
                        if(CommonFunctions.checkSendChat(visdriver, username, "Welcome to SalesIQ", 10)==rule1)
                        {
                            
                            if (rule1==true)
                                {
                                    etest.log(Status.PASS,"Rule"+rule_count+" is Enabled and working");
                                    visdriver.quit();
                                }
                                else
                                {
                                    etest.log(Status.PASS,"Rule"+rule_count+" is disabled and not Working");
                                    visdriver.quit();
                                }    
                        }
                        else
                        {
                            TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Campaign","Error");
                            visdriver.quit();
                            Thread.sleep(1000);
                            etest.log(Status.FAIL,"Checked and rule 1 is triggered in disabled state or not triggered in enabled state.");
                            failcount++;
                        }
                        rule_count++;
                }
                    visdriver = Functions.setUp();
                    VisitorWindow.createPage(visdriver,widget_Code);

                    try
                    {
                        if(CommonFunctions.checkSendChat(visdriver, username, "Welcome to Zoho SalesIQ", 10)==rule2)
                        {
                            if (rule2==true)
                                {
                                    etest.log(Status.PASS,"Rule"+rule_count+" is Enabled and working");
                                    visdriver.quit();
                                }
                                else
                                {
                                    etest.log(Status.PASS,"Rule"+rule_count+" is disabled and not Working");
                                    visdriver.quit();
                                } 
                        }
                        else
                        {
                            TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Country","Error");
                            TakeScreenshot.screenshot(driver,etest);
                            visdriver.quit();
                            Thread.sleep(1000);
                            etest.log(Status.FAIL,"Checked and rule"+rule_count+" is triggered in disabled state or not triggered in enabled state.");
                            failcount++;
                        }
                    }
                    catch(Exception e)
                    {
                        if(rule2)
                        {   
                            TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Country","Error");
                            etest.log(Status.FAIL,"Rule"+rule_count+" is Enable but not triggered");
                            visdriver.quit();
                            failcount++;
                        }
                        else
                        {
                            etest.log(Status.PASS,"Rule"+rule_count+" is disabled and not Working");
                            visdriver.quit();
                            Thread.sleep(1000);
                        }
                    }
                    rule_count++;

                    visdriver = Functions.setUp();
                    VisitorWindow.createPage(visdriver,widget_Code);

                    try
                    {
                        boolean openChat = false;
                        if(CommonFunctions.checkOpenChat(visdriver, 10))
                        {
                              if(CommonFunctions.checkSendChat(visdriver, username, "Welcome to", 10))
                              {
                                    openChat = false;
                              }
                              else
                              {
                                    openChat = true;
                              }
                        }
                        if(openChat == rule3)
                        {
                              if(rule3==true)
                              {
                                    etest.log(Status.PASS,"Rule"+rule_count+" is Enabled and working");
                                    visdriver.quit();
                              }
                              else
                              {
                                    etest.log(Status.PASS,"Rule"+rule_count+" is disabled and not Working");
                                    visdriver.quit();
                              } 
                        }
                        else
                        {
                            TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Browser","Error");
                            TakeScreenshot.screenshot(driver,etest);
                            visdriver.quit();
                            Thread.sleep(1000);
                            etest.log(Status.FAIL,"Checked and rule"+rule_count+" is triggered in disabled state or not triggered in enabled state.");
                            failcount++;
                        }
                    }
                    catch(Exception e)
                    {
                        if(rule3)
                        {   
                            TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","Browser","Error");
                            etest.log(Status.FAIL,"Rule"+rule_count+" is Enabled but not triggered");
                            visdriver.quit();
                            failcount++;
                        }
                        else
                        {
                            etest.log(Status.PASS,"Rule"+rule_count+" is disabled and not Working");
                            visdriver.quit();
                            Thread.sleep(1000);
                        }
                    }
                }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visdriver,etest,"IntelligentTriggersRT","EnableDisable","Error",e);
                visdriver.quit();
                Thread.sleep(1000);
                return false;
            } 
            
            finally
            {
                System.out.println(failcount+"failcount");
                return CommonUtil.returnResult(failcount);
            }

        }   
        catch(Exception e)
        {
            System.out.println("Exception while checking EnableDisable in intelligent triggers module : ");
            TakeScreenshot.screenshot(driver,etest,"IntelligentTriggersRT","Campaign","Error",e);
            Thread.sleep(1000);
            return false;
        }

    }
}
