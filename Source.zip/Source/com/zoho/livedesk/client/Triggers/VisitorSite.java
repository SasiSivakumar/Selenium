//$Id$
package com.zoho.livedesk.client.Triggers;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.net.URL;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.common.base.Function;

import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class VisitorSite
{
    public static WebDriver setUp() throws InterruptedException
    {
        WebDriver driver = null;
        
        try
        {
            driver = Functions.setUp();
            return driver;
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","VisitorPage","CreatePageError",e);
            Thread.sleep(1000);
        }
        return driver;
    }
    
    public static WebDriver createPage(String widget_code) throws InterruptedException, IOException
    {
        WebDriver driver = null;
        
        try
        {
            driver = setUp();
            VisitorWindow.createPage(driver,widget_code);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","VisitorPage","CreatePageError",e);
            Thread.sleep(1000);
        }
        return driver;
    }
    
    public static WebDriver referrerPage(String referrer, String widget_code) throws IOException, InterruptedException
    {
        WebDriver driver = null;
        
        try
        {
            driver = setUp();
            VisitorWindow.createPageReferrer1(driver,widget_code,referrer);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","VisitorPage","ReferrerPageError",e);
            Thread.sleep(1000);
        }
        return driver;
    }
    
    public static WebDriver createCampaign(String widgetCode, String cname) throws IOException, InterruptedException
    {
        WebDriver driver = null;
        
        try
        {
            driver = setUp();
            VisitorWindow.createPageCampaign(driver,widgetCode,cname);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating campaign visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","VisitorPage","CampaignPageError",e);
            Thread.sleep(1000);
        }
        return driver;
    }
    
    public static WebDriver createReferralPage(String Widget_Code) throws InterruptedException, IOException
    {
        WebDriver driver = null;
        
        try
        {
            driver = setUp();
            VisitorWindow.createPageReferrer(driver, Widget_Code);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","VisitorPage","ReferralPageError",e);
            Thread.sleep(1000);
        }
        return driver;
    }
    
    public static WebDriver createAPIPage(String widget_code,String apichk) throws InterruptedException, IOException
    {
        WebDriver driver = null;
        
        try
        {
            driver = setUp();
            
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            driver.get(ConfManager.getRealValue("php_server_endurl")+"jsdev2.php");
            
            Thread.sleep(1000);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fname")));
            
            String siteName = Util.setUptracking();
           
            if(siteName.equals("local"))
            {
                siteName = "LocalZoho";
            }
            else if(siteName.equals("lab"))
            {
                siteName = "Lab SalesIQ";
            }
            else if(siteName.equals("pre"))
            {
                siteName = "Pre SalesIQ";
            }
            else if(siteName.equals("idc"))
            {
                siteName = "IDC";
            }
            else
            {
                siteName = "IDC";
            }
            
            CommonUtil.elfinder(driver,"name","domain").click();
            new Select(driver.findElement(By.xpath(".//select[@name='domain']"))).selectByVisibleText(siteName);
            CommonUtil.elfinder(driver, "name", "widgetcode").click();
            CommonUtil.elfinder(driver,"name","widgetcode").sendKeys(widget_code);
            
            if(apichk.equals("bubble"))
            {
                CommonUtil.elfinder(driver,"name","bubblevisible").click();
                CommonUtil.elfinder(driver,"name","bubblevisible").sendKeys("hide");
            }
            else if(apichk.equals("button"))
            {
                CommonUtil.elfinder(driver,"id","floatbuttonvisible").click();
                new Select(driver.findElement(By.xpath(".//select[@id='floatbuttonvisible']"))).selectByVisibleText("Hide");
            }
            else if(apichk.equals("email"))
            {
                CommonUtil.elfinder(driver,"id","femail").click();
                CommonUtil.elfinder(driver,"id","femail").sendKeys("pavankumar10293@zohocorp.com");
            }
            else if(apichk.equals("depbutton"))
            {
                CommonUtil.elfinder(driver,"id","floatbuttonvisible").click();
                new Select(driver.findElement(By.xpath(".//select[@id='floatbuttonvisible']"))).selectByVisibleText("Hide");
            }
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
            Thread.sleep(300);
            CommonUtil.elfinder(driver,"id","fsubbutton").click();
            
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,ITRTime.etest,"IntelligentTriggersRT","VisitorPage","ReferralPageError",e);
            Thread.sleep(1000);
        }
        return driver;
    }
}
