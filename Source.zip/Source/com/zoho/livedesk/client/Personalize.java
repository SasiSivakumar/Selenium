//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.Functions;

public class Personalize
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
	public static ExtentTest etest; 
	
	public static Hashtable personalizeSett(WebDriver driver)
	{
		try
		{
			driver.navigate().refresh();

            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PER1"));
            ComplexReportFactory.setValues(etest,"Automation","Personalize");

			url = ConfManager.requestURL();
			
            WebDriverWait wait = new WebDriverWait(driver, 20);
			try
			{
				Functions.closeBannersAfterLogin(driver);
			}
			catch(Exception e){}

			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("hdrprt")));

			driver.findElement(By.id("hdrdrpdwntop")).click();
            
            Thread.sleep(1000);
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			result.put("PER1", false);

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					etest.log(Status.PASS,"Personalize is present in DropDown");
					result.put("PER1", true);
					break;
				}
			}
			if(!(boolean)result.get("PER1"))
				TakeScreenshot.screenshot(driver,etest,"Personalize","PersonalizeinDropdown","Personalizeisnotpresent");

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PER2"));
            ComplexReportFactory.setValues(etest,"Automation","Personalize");

			result.put("PER2", isWindowAvail(driver));
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PER3"));
            ComplexReportFactory.setValues(etest,"Automation","Personalize");

			result.put("PER3", closeWindow(driver));
			
			ComplexReportFactory.closeTest(etest);

            // etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PER8"));
            // ComplexReportFactory.setValues(etest,"Automation","Personalize");

            //depreceated in new UI
			// result.put("PER8", false);
			// result.put("PER9", false);
			result.put("PER12", false);
			result.put("PER13", false);
			result.put("PER14", false);
			result.put("PER15", false);
			result.put("PER16", false);
			result.put("PER17", false);
			result.put("PER18", false);
			result.put("PER19", false);
			result.put("PER20", false);
			result.put("PER21", false);
			result.put("PER22", false);
			result.put("PER23", false);
			result.put("PER24", false);

			// checkThemes1(driver, "Charcoal");
			
			// ComplexReportFactory.closeTest(etest);

   //          etest=ComplexReportFactory.getTest(KeyManager.getRealValue("PER9"));
   //          ComplexReportFactory.setValues(etest,"Automation","Personalize");

			// checkThemes1(driver, "Aqua");

			// ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Sounds For Visitors Events");
            ComplexReportFactory.setValues(etest,"Automation","Personalize");

			checkSoundsVisitorEvents(driver);
			
			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Sounds For Operators Events");
            ComplexReportFactory.setValues(etest,"Automation","Personalize");

			checkSoundsUserEvents(driver);

			ComplexReportFactory.closeTest(etest);
		}
		catch(NoSuchElementException e)
		{
			etest.log(Status.FATAL,"ErrorPersonalizeWindow");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"Personalize","Personalize in Dropdown","ErrorWhileCheckingPersonalize",e);

			result.put("PER1", false);
		}
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorPersonalizeWindow");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");	
			TakeScreenshot.screenshot(driver,etest,"Personalize","Personalize in Dropdown","ErrorWhileCheckingPersonalize",e);

			result.put("PER1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	private static boolean isWindowAvail(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);
					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
					if((close.getAttribute("class")).contains("sqico-close"))
					{

						if(driver.findElement(By.id("sounds")).isDisplayed())
						{
							close.click();
							etest.log(Status.PASS,"Personalize Window was opened");
			
							return true;
						}
						else{
							TakeScreenshot.screenshot(driver,etest,"Personalize","WindowAvailable","Personalize window was not present");
						}
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"Personalize","WindowAvailable","Close Icon Mismatch");
					}
					close.click();
				}
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"Personalize","WindowAvailable","ErrorWhileCheckingPersonalizeWindow",e);

			System.out.println("Exception while checking if personalize window is available : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Personalize","WindowAvailable","ErrorWhileCheckingPersonalizeWindow",e);

            System.out.println("Exception while checking if personalize window is available : "+e);
		}
		return false;
	}

	private static boolean closeWindow(WebDriver driver)
	{
		try
		{
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);
					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
					if((close.getAttribute("class")).contains("sqico-close"))
					{
						close.click();
						etest.log(Status.PASS,"Close icon is present");
			
						return true;
					}
					else{
						TakeScreenshot.screenshot(driver,etest,"Personalize","Close Window","Mismatch Close Icon");
					}
                }
            }
		}
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Personalize","Close Window","ErrorWhileClosingWindow",e);

            System.out.println("Exception while checking if personalize window close window is available : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Personalize","Close Window","ErrorWhileClosingWindow",e);

            System.out.println("Exception while checking if personalize window close window is available : "+e);
        }
        return false;
    }

	private static void checkThemes1(WebDriver driver, String theme)
	{
		try
		{
            Thread.sleep(2000);
            
			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);
					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement hr = form.findElement(By.className("modal-header")).findElement(By.tagName("h4"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
					WebElement header = form.findElement(By.className("crmld_nv"));
					WebElement menu = header.findElement(By.className("crmld_sbmn"));
					List<WebElement> optns = menu.findElements(By.tagName("span"));

					optns.get(1).click();

					WebElement telmt = driver.findElement(By.id("themes"));

					List<WebElement> elmts = telmt.findElement(By.className("userWrap")).findElement(By.id("theme")).findElements(By.tagName("a"));
                    
					for(WebElement elmt1:elmts)
					{
						if(theme.equals(elmt1.findElement(By.tagName("span")).getAttribute("title")))
						{
							elmt1.findElement(By.tagName("span")).click();
							break;
						}
					}
					close.click();
					break;
				}
			}
            
            Thread.sleep(2000);
            
			if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn1 = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn1)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
                    WebElement header = form.findElement(By.className("crmld_nv"));
                    WebElement menu = header.findElement(By.className("crmld_sbmn"));
                    List<WebElement> optns = menu.findElements(By.tagName("span"));
                    
                    optns.get(1).click();
                    
					WebElement theme1 = driver.findElement(By.id("theme"));

					List<WebElement> thelmts = theme1.findElements(By.tagName("a"));
					int i=0;
					for(WebElement thelmt:thelmts)
					{
						if(theme.equals(thelmt.findElement(By.tagName("span")).getText()))
						{
							if((thelmt.getAttribute("class")).equals("thselected_"+i+" thselected")||(thelmt.getAttribute("class")).equals("thselected thselected_"+i))
							{
								if(theme.equals("Charcoal"))
								{
									etest.log(Status.PASS,"Charcoal theme is checked");
			
									result.put("PER8", true);
									break;
								}
								else if(theme.equals("Aqua"))
								{
									etest.log(Status.PASS,"Aqua theme is checked");
			
									result.put("PER9", true);
									break;
								}
							}
							else{
								TakeScreenshot.screenshot(driver,etest,"Personalize","Theme-"+theme,"Mismatch theme selected");
							}
						}
						i++;
					}
					if(i==thelmts.size())
						TakeScreenshot.screenshot(driver,etest,"Personalize","Theme-"+theme,"Mismatch theme Name");
					close.click();
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"Personalize","Theme-"+theme,"ErrorWhileChangingTheme",e);

			System.out.println("Exception while checking themes in personalize : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Personalize","Theme-"+theme,"ErrorWhileChangingTheme",e);

            System.out.println("Exception while checking themes in personalize : "+e);
		}
	}

/*	private static void checkThemes1(WebDriver driver, String layout, String edgestyle, String themes, String patterns)
	{
		try
		{
			driver.findElement(By.className("hdrprt")).click();
			driver.findElement(By.id("hdrdrpdwntop")).click();
			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);
					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement hr = form.findElement(By.className("modal-header")).findElement(By.tagName("h4"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
					WebElement header = form.findElement(By.className("crmld_nv"));
					WebElement menu = header.findElement(By.className("crmld_sbmn"));
					List<WebElement> optns = menu.findElements(By.tagName("span"));

					optns.get(1).click();

					WebElement telmt = driver.findElement(By.id("themes"));

					List<WebElement> elmts = telmt.findElements(By.className("userWrap"));

					try
					{
					if((elmts.get(0).findElement(By.className("uplayoutHead")).getText()).equals(ResourceManager.getRealValue("common_layout")))
					{
						if(layout.equals("fixed"))
						{
							driver.findElement(By.id("fixedlayout")).click();
							Thread.sleep(1000);
						}
						else if(layout.equals("stretch"))
						{
							driver.findElement(By.id("fluidlayout")).click();
							Thread.sleep(1000);
						}
					}
					}
					catch(Exception e){}

					try
					{
					if((elmts.get(1).findElement(By.className("uplayoutHead")).getText()).equals(ResourceManager.getRealValue("common_edgestyle")))
					{
						if(edgestyle.equals("sharp"))
						{
							driver.findElement(By.id("sharpEdges")).click();
							Thread.sleep(1000);
						}
						else if(edgestyle.equals("rounded"))
						{
							driver.findElement(By.id("roundedCorner")).click();
							Thread.sleep(1000);
						}
					}
					}
					catch(Exception e){}
					
					try
					{
					if((elmts.get(2).findElement(By.className("uplayoutHead")).getText()).equals(ResourceManager.getRealValue("common_themes")))
					{
						WebElement theme = driver.findElement(By.id("theme"));
						List<WebElement> thelmts = theme.findElements(By.tagName("a"));
						for(WebElement thelmt:thelmts)
						{
							if(themes.equals(thelmt.findElement(By.tagName("span")).getText()))
							{
								thelmt.click();
								Thread.sleep(1500);
								break;
							}
						}
					}
					}
					catch(Exception e){}
					
					try
					{
					if((elmts.get(3).findElement(By.className("uplayoutHead")).getText()).equals(ResourceManager.getRealValue("common_patterns")))
					{
						WebElement theme = driver.findElement(By.id("pattern"));
						List<WebElement> thelmts = theme.findElements(By.tagName("a"));
						for(WebElement thelmt:thelmts)
						{
							if(patterns.equals(thelmt.findElement(By.tagName("span")).getText()))
							{
								thelmt.click();
								Thread.sleep(1500);
								break;
							}
						}
					}
					}
					catch(Exception e){}
					close.click();
					break;
				}
			}

			driver.findElement(By.className("hdrprt")).click();
			driver.findElement(By.id("hdrdrpdwntop")).click();
			List<WebElement> drpdwn1 = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn1)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));

					WebElement wlayout = driver.findElement(By.id("layoutgrp"));
					List<WebElement> layouts = wlayout.findElements(By.className("uprdowrap"));
					if(layout.equals("fixed"))
					{
						if((layouts.get(0).findElement(By.tagName("span")).getAttribute("class")).contains("rdselected"))
						{
							result.put("PER4", true);
						}
					}
					else if(layout.equals("stretch"))
					{
						if((layouts.get(1).findElement(By.tagName("span")).getAttribute("class")).contains("rdselected"))
						{
							result.put("PER5", true);
						}
					}

					WebElement elayout = driver.findElement(By.id("edgegrp"));
					List<WebElement> elayouts = elayout.findElements(By.className("uprdowrap"));
					if(edgestyle.equals("sharp"))
					{
						if((elayouts.get(0).findElement(By.tagName("span")).getAttribute("class")).contains("rdselected"))
						{
							result.put("PER6", true);
						}
					}
					else if(edgestyle.equals("rounded"))
					{
						if((elayouts.get(1).findElement(By.tagName("span")).getAttribute("class")).contains("rdselected"))
						{
							result.put("PER7", true);
						}
					}

					WebElement theme = driver.findElement(By.id("theme"));

					List<WebElement> thelmts = theme.findElements(By.tagName("a"));
					for(WebElement thelmt:thelmts)
					{
						if(themes.equals(thelmt.findElement(By.tagName("span")).getText()))
						{
							if((thelmt.getAttribute("class")).equals("thselected"))
							{
								if(themes.equals("Phyllis"))
								{
									result.put("PER8", true);
								}
								else if(themes.equals("Neutral"))
								{
									result.put("PER9", true);
								}
							}
						}
					}

					WebElement pattern = driver.findElement(By.id("pattern"));
					List<WebElement> pthelmts = pattern.findElements(By.tagName("a"));
					for(WebElement thelmt:pthelmts)
					{
						if(patterns.equals(thelmt.findElement(By.tagName("span")).getText()))
						{
							if((thelmt.getAttribute("class")).equals("thselected"))
							{
								if(patterns.equals("Stripes"))
								{
									result.put("PER10", true);
								}
								else if(patterns.equals("Default"))
								{
									result.put("PER11", true);
								}
							}
						}
					}
					close.click();
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Personalize : Exception "+e);
		}
		catch(Exception e)
		{
			System.out.println("Personalize : Exception "+e);
		}
	}*/

	private static void checkSoundsVisitorEvents(WebDriver driver)
	{
		try
		{
            Thread.sleep(2000);
            
			Hashtable hash = new Hashtable();
			Hashtable text = new Hashtable();

			hash.put("VE1", "Cool Piano");
			hash.put("VE2", "Soft Piano");
			hash.put("VE3", "Bell");
			hash.put("VE4", "Beep");
			hash.put("VE5", "Stapler");
			hash.put("VE6", "Sword Whip");
			hash.put("VE7",  "Ding");

			text.put("VE1", "Incoming Visitor Chat");
			text.put("VE2", "Visitor About to Leave the Chat");
			text.put("VE3", "Chat Message from Visitor");
			text.put("VE4", "End of Chat");
			text.put("VE5", "Visitor has Left the Chat Session");
			text.put("VE6", "Visitor lands on site");
			text.put("VE7", "Visitor leaves site");

			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
					// WebElement header = form.findElement(By.className("crmld_nv"));
					// WebElement menu = header.findElement(By.className("crmld_sbmn"));
					// List<WebElement> optns = menu.findElements(By.tagName("span"));

					// optns.get(0).click();

					WebElement sounds = driver.findElement(By.id("sounds"));
					sounds.click();
					Thread.sleep(1000);

					List<WebElement> list = sounds.findElement(By.className("tabnav")).findElements(By.tagName("li"));

					if(!("active".equals(list.get(0).getAttribute("class"))))
					{
						list.get(0).click();
					}

					List<WebElement> snd = driver.findElement(By.id("ploop")).findElements(By.className("tuneWrap"));

					int j=0;
					int k=1;

					for(WebElement elmt1:snd)
					{
						if(j==2)
						{
							j += 1;
						}
						else if(j==6)
						{
							j += 3;
						}
						String option = "VE"+k;
						if((""+text.get(option)).equals(elmt1.findElement(By.className("tuneName")).getText()))
						{
							String ddiv = "tunediv"+j+"_div";
							String dname = "tunediv"+j+"_ddown";

							elmt1.findElement(By.id(ddiv)).click();
							WebElement elmt2 = driver.findElement(By.id(dname));
							List<WebElement> lis=elmt2.findElements(By.tagName("li"));

							for(int l=0;l<lis.size();l++)
							{
								WebElement element = lis.get(l);
								WebElement element2 = element.findElement(By.className("tunetxt"));
								WebElement element3 = element2.findElement(By.tagName("span"));
								if((""+hash.get(option)).equals(element3.getText()))
								{
									element2.click();
									Thread.sleep(1000);
									driver.findElement(By.id("userPreference")).click();
									break;
								}
							}
						}
						k++;
						j++;
					}
					close.click();
				}
			}

			if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));

					WebElement sounds = driver.findElement(By.id("sounds"));
					sounds.click();
					Thread.sleep(1000);

					List<WebElement> list = sounds.findElement(By.className("tabnav")).findElements(By.tagName("li"));

					if(!("active".equals(list.get(0).getAttribute("class"))))
					{
						list.get(0).click();
					}

					List<WebElement> snd = driver.findElement(By.id("ploop")).findElements(By.className("tuneWrap"));

					int i=0;
					int m=1;
					int n=12;

					for(WebElement elmt1:snd)
					{
						if(i==2)
						{
							i++;
						}
						else if(i==6)
						{
							i+=3;
						}
						String option = "VE"+m;
						if((""+text.get(option)).equals(elmt1.findElement(By.className("tuneName")).getText()))
						{
							WebElement ddiv = driver.findElement(By.id("tunediv"+i+"_div"));

							if((hash.get(option)).equals(ddiv.findElement(By.tagName("span")).getText()))
							{
								etest.log(Status.PASS,KeyManager.getRealValue("PER"+n)+" is checked");
			
								result.put("PER"+n, true);
							}
							else{
								TakeScreenshot.screenshot(driver,etest,"Personalize","Sounds-VisitorEvents-"+text.get("VE"+m),"Mismatch Sound");
							}
						}
						i++;
						m++;
						n++;
					}
					close.click();
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"Personalize","Sounds-VisitorEvents","ErrorWhileCheckingNotificationsSounds",e);

			System.out.println("Exception while checking sounds for visitor events : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Personalize","Sounds-VisitorEvents","ErrorWhileCheckingNotificationsSounds",e);

            System.out.println("Exception while checking sounds for visitor events : "+e);
		}
	}

	private static void checkSoundsUserEvents(WebDriver driver)
	{
		try
		{
            Thread.sleep(2000);
            
			Hashtable hash = new Hashtable();
			Hashtable text = new Hashtable();

			hash.put("UE1", "Cool Piano");
			hash.put("UE2", "Stapler");
			hash.put("UE3", "Sword Whip");
			hash.put("UE4", "Soft Shaker");
			hash.put("UE5", "Ding");
			hash.put("UE6", "Stapler");

			text.put("UE1", "Chat Transfer Alert");
			text.put("UE2", "Invitation for Group Support");
			text.put("UE3", "Chat Message from Colleague");
			text.put("UE4", "Message Board Chat Message");
			text.put("UE5", "Assigned Missed visitor");
			text.put("UE6", "Approval for Blocking IPs");

			FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);
            
            if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			List<WebElement> drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));


			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));
					// WebElement header = form.findElement(By.className("crmld_nv"));
					// WebElement menu = header.findElement(By.className("crmld_sbmn"));
					// List<WebElement> optns = menu.findElements(By.tagName("span"));

					// optns.get(0).click();

					WebElement sounds = driver.findElement(By.id("sounds"));
					sounds.click();
					Thread.sleep(1000);

					List<WebElement> list = sounds.findElement(By.className("tabnav")).findElements(By.tagName("li"));
					if(!("active".equals(list.get(1).getAttribute("class"))))
					{
						list.get(1).click();
					}

					List<WebElement> snd = driver.findElement(By.id("ponce")).findElements(By.className("tuneWrap"));

					int j=0;
					int k=1;

					for(WebElement elmt1:snd)
					{
						if(j==0)
						{
							j += 2;
						}
						else if(j==3)
						{
							j += 3;
						}
						else if(j==9)
						{
							j += 2;
						}
						String option = "UE"+k;
						if((""+text.get(option)).equals(elmt1.findElement(By.className("tuneName")).getText()))
						{
							String ddiv = "tunediv"+j+"_div";
							String dname = "tunediv"+j+"_ddown";

							elmt1.findElement(By.id(ddiv)).click();
							WebElement elmt2 = driver.findElement(By.id(dname));
							List<WebElement> lis=elmt2.findElements(By.tagName("li"));

							for(int l=0;l<lis.size();l++)
							{
								WebElement element = lis.get(l);
								WebElement element2 = element.findElement(By.className("tunetxt"));
								WebElement element3 = element2.findElement(By.tagName("span"));
								if((""+hash.get(option)).equals(element3.getText()))
								{
									element2.click();
									Thread.sleep(1000);
									driver.findElement(By.id("userPreference")).click();
									break;
								}
							}
						}
						k++;
						j++;
					}
					close.click();
				}
			}

			if(!driver.findElement(By.id("hdrdrpdwn")).getAttribute("style").contains("display: block;"))
            {
                driver.findElement(By.id("hdrdrpdwntop")).click();
            }
			
            
            wait.until(new Function<WebDriver,Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.id("hdrdrpdwn")).getAttribute("style")).contains("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });

			drpdwn = driver.findElement(By.id("hdrdrpdwn")).findElements(By.tagName("li"));

			for(WebElement elmt:drpdwn)
			{
				if(elmt.getText().equals(ResourceManager.getRealValue("common_personalize")))
				{
					elmt.findElement(By.tagName("a")).click();
					Thread.sleep(1000);

					WebElement window = driver.findElement(By.id("userPreference"));
					WebElement form = window.findElement(By.tagName("form"));
					WebElement close = form.findElement(By.className("modal-header")).findElement(By.className("floatrg")).findElement(By.tagName("a"));

					WebElement sounds = driver.findElement(By.id("sounds"));
					sounds.click();
					Thread.sleep(1000);

					List<WebElement> list = sounds.findElement(By.className("tabnav")).findElements(By.tagName("li"));

					if(!("active".equals(list.get(1).getAttribute("class"))))
					{
						list.get(1).click();
					}

					List<WebElement> snd = driver.findElement(By.id("ponce")).findElements(By.className("tuneWrap"));

					int i=0;
					int m=1;
					int n=19;

					for(WebElement elmt1:snd)
					{
						if(i==0)
						{
							i += 2;
						}
						else if(i==3)
						{
							i += 3;
						}
						else if(i==9)
						{
							i += 2;
						}

						String option = "UE"+m;
						if((""+text.get(option)).equals(elmt1.findElement(By.className("tuneName")).getText()))
						{
							WebElement ddiv = driver.findElement(By.id("tunediv"+i+"_div"));

							if((hash.get(option)).equals(ddiv.findElement(By.tagName("span")).getText()))
							{
								etest.log(Status.PASS,KeyManager.getRealValue("PER"+n)+" is checked");
			
								result.put("PER"+n, true);
							}
							else{
								TakeScreenshot.screenshot(driver,etest,"Personalize","Sounds-OperatorEvents-"+text.get("UE"+m),"Mismatch Sound");
							}
						}
						i++;
						m++;
						n++;
					}
					close.click();
					break;
				}
			}
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Personalize","Sounds-OperatorEvents","ErrorWhileCheckingNotificationsSounds",e);

            System.out.println("Exception while checking sounds for Operator events : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Personalize","Sounds-UserEvents","ErrorWhileCheckingNotificationsSounds",e);

            System.out.println("Exception while checking sounds for Operator events : "+e);
		}
	}
}
