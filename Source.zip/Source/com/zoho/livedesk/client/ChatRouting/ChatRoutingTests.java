//$Id$
package com.zoho.livedesk.client.ChatRouting;

import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;

import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;

import com.zoho.livedesk.util.common.CommonUtil;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.Driver;
import com.zoho.livedesk.util.exceptions.ZohoSalesIQRuntimeException;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.VisitorDriverManager;
import com.zoho.livedesk.util.common.actions.ChatRouting.ChatRoutingRule;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewCommonFunctions;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants;
import com.zoho.livedesk.client.ConversationView.ConversationViewConstants.ChatType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.AgentStatus;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.User;
import com.zoho.livedesk.client.ConcurrentChats.ConcurrentChatConstants.Portal;

public class ChatRoutingTests
{

	public static Hashtable finalResult = new Hashtable();

	public static Hashtable<String,Boolean> result = new Hashtable<String,Boolean>();
	public static ExtentTest etest;
	static public ExtentReports extent;

	public static String MODULE_NAME="Chat Routing Real Time";
	public static String WIDGET_CODE="";

	public static VisitorDriverManager visitor_driver_manager;

	//test data variables
	public static String
	campaign_name=null,
	country=null,
	email=null,
	dept=null;

	public static void initTestData()
	{
		String label=CommonUtil.getUniqueMessage();
		campaign_name="Camp"+label;
		email="email"+label+"@automation.com";
		dept="D"+label;

		WebDriver visitor_driver=null;

		if(Util.siteNameout().contains("local"))
		{
			country="United Kingdom";
		}
		else
		{
			country="India";
		}
	}

	public static Hashtable test(WebDriver driver)
	{
		initTestData();

		String user_name1,user_name2,user_name3;

		Hashtable<String,Boolean> expected_result=null;
		ArrayList<String> route_to=null;
		ChatRoutingRule  rule=null;

		try
		{
			visitor_driver_manager = new VisitorDriverManager();

            result = new Hashtable<String,Boolean>();

            WIDGET_CODE=ExecuteStatements.getWidgetCode(driver);

			etest=ComplexReportFactory.getTest("Chat Routing CRUD");
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            checkChatRoutingCRUD(driver,etest);
            ComplexReportFactory.closeTest(etest);

            WebDriver driver2=Functions.setUp();
            Functions.login(driver2,"chat_routing2");
            WebDriver driver3=Functions.setUp();
            Functions.login(driver3,"chat_routing3");

			user_name1=ExecuteStatements.getUserName(driver);
            user_name2=ExecuteStatements.getUserName(driver2);
            user_name3=ExecuteStatements.getUserName(driver3);

            etest = ComplexReportFactory.getTest("Setup all drivers");
            ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
            setUpAllDrivers(driver,driver2,driver3,etest);
            ComplexReportFactory.closeTest(etest);


	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        route_to.add(user_name2);
	        rule = new ChatRoutingRule(ChatRouting.CAMPAIGN_NAME,ChatRouting.EQUALS,campaign_name,ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,true,user_name3,false);

			etest=ComplexReportFactory.getTest(rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT18",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

      //	   least loaded option was removed from chat routing
	  //       route_to=new ArrayList<String>();
	  //       route_to.add(user_name1);
	  //       route_to.add(user_name2);
	  //       route_to.add(user_name3);
	  //       rule = new ChatRoutingRule(ChatRouting.COUNTRY,ChatRouting.EQUALS,country,ChatRouting.LEAST_LOADED,route_to);
	  //       expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);//expected results based on setupLeastLoaded method also
			
			// etest=ComplexReportFactory.getTest(rule.toString());
			// ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			// result.put("CRRT19",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
   //          ComplexReportFactory.closeTest(etest);

	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_URL,ChatRouting.CONTAINS,"://",ChatRouting.DO_NOT_ROUTE,null);
	        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,false,user_name3,false);
			
			etest=ComplexReportFactory.getTest(rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT21",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        route_to.add(user_name2);
	        route_to.add(user_name3);
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.ONE_BY_ONE,route_to);

			etest=ComplexReportFactory.getTest(rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT20",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,null,etest));//expected result is not required here
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(ChatRouting.LAST_CHAT_ATTENDER);//driver will be the last chat attender
	        rule = new ChatRoutingRule(ChatRouting.EMAIL,ChatRouting.EQUALS,email,ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);

			etest=ComplexReportFactory.getTest(rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT22",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(dept);//driver will be the last chat attender
	        rule = new ChatRoutingRule(ChatRouting.NUMBER_OF_PAST_CHATS,ChatRouting.MORE,"1",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);

			etest=ComplexReportFactory.getTest(rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT23",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(ChatRouting.CRM_LEAD_OR_CONTACT_OWNER);
	        rule = new ChatRoutingRule(ChatRouting.NUMBER_OF_VISITS,ChatRouting.EQUALS,"1",ChatRouting.SELECTED,route_to);//add according to use case
	        rule.setConfigureCRMAsLead(true);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);

			etest=ComplexReportFactory.getTest("For CRM Lead : "+rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT24",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(ChatRouting.CRM_LEAD_OR_CONTACT_OWNER);
	        rule = new ChatRoutingRule(ChatRouting.VISITOR_TYPE,ChatRouting.EQUALS,ChatRouting.RETURNING,ChatRouting.SELECTED,route_to);//add according to use case
	        rule.setConfigureCRMAsLead(false);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);

			etest=ComplexReportFactory.getTest("For CRM Contact : "+rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT25",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);


            ChatRoutingRule advanced_rule1,advanced_rule2;

            String label=CommonUtil.getUniqueMessage();
	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
			advanced_rule1=new ChatRoutingRule(ChatRouting.VISITOR_QUESTION,ChatRouting.CONTAINS,"Q"+label,ChatRouting.SELECTED,route_to);
			advanced_rule2=new ChatRoutingRule(ChatRouting.VISITOR_QUESTION,ChatRouting.CONTAINS,"Q"+label,ChatRouting.DO_NOT_ROUTE,null);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);

			etest=ComplexReportFactory.getTest("Top down rules : "+advanced_rule1.toString()+" & "+advanced_rule2.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT28",checkAdvancedRouting(driver,driver2,driver3,WIDGET_CODE,advanced_rule1,advanced_rule2,expected_result,etest));			
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
			advanced_rule1=new ChatRoutingRule(ChatRouting.VISITOR_QUESTION,ChatRouting.CONTAINS,"question1",ChatRouting.SELECTED,route_to);
	        route_to=new ArrayList<String>();
	        route_to.add(user_name2);
			advanced_rule2=new ChatRoutingRule(ChatRouting.VISITOR_QUESTION,ChatRouting.CONTAINS,"question2",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);

			etest=ComplexReportFactory.getTest("Contradicting rules : "+advanced_rule1.toString()+" & "+advanced_rule2.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT29",checkAdvancedRouting(driver,driver2,driver3,WIDGET_CODE,advanced_rule1,advanced_rule2,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,false,user_name3,false);
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRRT13"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT13",checkChatRoutingRulesBasedOnAvailibility(driver,driver2,driver3,WIDGET_CODE,AgentStatus.BUSY,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        route_to.add(user_name2);	        
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,true,user_name3,false);
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRRT12"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT12",checkChatRoutingRulesBasedOnAvailibility(driver,driver2,driver3,WIDGET_CODE,AgentStatus.BUSY,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,false,user_name3,false);
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRRT11"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT11",checkChatRoutingRulesBasedOnAvailibility(driver,driver2,driver3,WIDGET_CODE,AgentStatus.ENGAGED,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        route_to.add(user_name2);	        
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,true,user_name3,false);
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRRT10"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT10",checkChatRoutingRulesBasedOnAvailibility(driver,driver2,driver3,WIDGET_CODE,AgentStatus.ENGAGED,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);   

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name2,false,user_name3,false);//not passing user_name1 as he is offline
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRRT9"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT9",checkChatRoutingRulesBasedOnAvailibility(driver,driver2,driver3,WIDGET_CODE,AgentStatus.OFFLINE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

	        route_to=new ArrayList<String>();
	        route_to.add(user_name1);
	        route_to.add(user_name2);	        
	        rule = new ChatRoutingRule(ChatRouting.LANDING_PAGE_TITLE,ChatRouting.CONTAINS,"a",ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name2,true,user_name3,false);//not passing user_name2 as he is offline
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CRRT8"));
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT8",checkChatRoutingRulesBasedOnAvailibility(driver,driver2,driver3,WIDGET_CODE,AgentStatus.OFFLINE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);

            route_to=new ArrayList<String>();
	        route_to.add(ChatRouting.ALL_AVAILABLE_OPERATORS);
	        rule = new ChatRoutingRule(ChatRouting.EMAIL,ChatRouting.EQUALS,email,ChatRouting.SELECTED,route_to);
	        expected_result=getExpectedResultHashtable(user_name1,true,user_name3,true);//not passing user_name2 as he is offline

			etest=ComplexReportFactory.getTest(rule.toString());
			ComplexReportFactory.setValues(etest,"Automation",MODULE_NAME);
			result.put("CRRT32",checkRouting(driver,driver2,driver3,WIDGET_CODE,rule,expected_result,etest));
            ComplexReportFactory.closeTest(etest);
       }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			e.printStackTrace();
			System.out.println("FATAL_ERROR_OCCURRED_TEST_TERMINATED");
        }
		finally
		{
			ComplexReportFactory.closeTest(etest);
			finalResult.put("result",result);
			finalResult.put("servicedown",new Hashtable());
			return finalResult;
		}

	}

	public static void setUpAllDrivers(WebDriver driver,WebDriver driver2,WebDriver driver3,ExtentTest etest)
	{
		try
		{
			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available",etest);
			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available",etest);
			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver3,"available",etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"setupDrivers","Exception",e);
		}
	}

	public static void checkChatRoutingCRUD(WebDriver driver,ExtentTest etest)
	{
		String	
        label=CommonUtil.getUniqueMessage(),
        visitor_mail=label+"@email.com";

		try
		{
			com.zoho.livedesk.util.Cleanup.deleteAllChatRouting(driver);

	        ArrayList<String> route_to=new ArrayList<String>();
	        route_to.add(ChatRouting.LAST_CHAT_ATTENDER);//driver will be the last chat attender
	        ChatRoutingRule rule = new ChatRoutingRule(ChatRouting.EMAIL,ChatRouting.EQUALS,visitor_mail,ChatRouting.SELECTED,route_to);

	        Tab.navToChatRoutingTab(driver);
	        result.put("CRRT1",ChatRouting.isExpectedEmptyStateDisplayed(driver,etest));
	        result.put("CRRT2",ChatRouting.checkHeaderAndDescription(driver,etest));

	        ChatRouting.addChatRoutingRule(driver,etest,rule);

	        //reload values to check if its updated
	        Tab.navToITTab(driver);
	        Tab.navToChatRoutingTab(driver);
	        result.put("CRRT4",rule.isRuleFoundWithExpectedValues(driver,etest));

	      	route_to=new ArrayList<String>();
	        route_to.add(ExecuteStatements.getSystemGeneratedDepartment(driver));
	        ChatRoutingRule edited_rule = new ChatRoutingRule(ChatRouting.CURRENT_PAGE_URL,ChatRouting.CONTAINS,label,ChatRouting.SELECTED,route_to);
	        edited_rule.setRuleId(rule.rule_id);

	        ChatRouting.editChatRoutingRule(driver,etest,edited_rule);

	        //reload values to check if its updated
	        Tab.navToITTab(driver);
	        Tab.navToChatRoutingTab(driver);
	        result.put("CRRT5",edited_rule.isRuleFoundWithExpectedValues(driver,etest));
	        result.put("CRRT6",ChatRouting.deleteRule(driver,etest,edited_rule));

	        if(result.get("CRRT6")==false)
	        {
	        	etest.log(Status.FAIL,"Chat routing rule was NOT deleted. rule :"+edited_rule.toString());
	            TakeScreenshot.screenshot(driver,etest,ChatRoutingTests.MODULE_NAME,"Failure","ChatRouting");  
	        }

	        
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",e);
		}
		finally
		{		

		}
	}

	public static boolean checkRouting(WebDriver driver,WebDriver driver2,WebDriver driver3,String widget_code,ChatRoutingRule rule,Hashtable<String,Boolean> expected_result,ExtentTest etest) throws Exception
	{
		WebDriver visitor_driver=null;

		String	
        label=CommonUtil.getUniqueMessage(),
        visitor_name="name"+label,
        visitor_mail=label+"@email.com",
        visitor_question="question"+label,
        department = ExecuteStatements.getSystemGeneratedDepartment(driver)
        ;


		int failcount=0;
		Hashtable<String,Boolean> actual_result=null;
		Hashtable<String,String> visitor_details=null;

		try
		{
			if(rule.rule_criteria.equals(ChatRouting.EMAIL))
			{
				visitor_mail=email;
			}

			if(  rule.routing_parameters!=null &&  ( rule.routing_parameters.contains(ChatRouting.LAST_CHAT_ATTENDER) || rule.routing_parameters.contains(ChatRouting.CRM_LEAD_OR_CONTACT_OWNER) || rule.routing_parameters.contains(ChatRouting.ALL_AVAILABLE_OPERATORS)) )
			{				
				visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,department,visitor_question,null,null);
			}

			if(rule.routing_parameters!=null && rule.routing_parameters.contains(ChatRouting.ALL_AVAILABLE_OPERATORS))
			{
				setupStatus(driver2,etest,AgentStatus.BUSY);
			}


			com.zoho.livedesk.util.Cleanup.deleteAllChatRouting(driver);

			if(rule.routing_action.equals(ChatRouting.LEAST_LOADED))
			{
				setupLeastLoaded(driver,driver2,driver3,widget_code,etest);
			}

			quickSetup(driver,etest,rule);		

	        Tab.navToChatRoutingTab(driver);

	        ChatRouting.addChatRoutingRule(driver,etest,rule);

			if(rule.routing_action.equals(ChatRouting.ONE_BY_ONE)==false)
			{
				visitor_driver=visitor_driver_manager.getDriver(driver);

		        setupChatRoutingRealTimeCondition(driver,visitor_driver,visitor_details,widget_code,rule,etest);
		        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);

    	        if(isExpectedResultFound(expected_result,actual_result,etest)==false)
		        {
		        	failcount++;
		        }
			}
			else
			{
				//IN ROUTE ONE BY ONE RULE, THE ROUTING PARAMTERS MUST CONTAINS EXACTLY 3 RULES (Reason: to check for cyclic routing use case) ,Route ony by one condition must be given in a condition such that the routing order is driver-->driver2-->driver3
				for(int i=0;i<(3+1);i++)//extra loop to check if route one by one acts in a cyclic order. i.e after driver3 it must be routed to driver1 again
				{
					etest.log(Status.INFO,"Chat routing iteration "+(i+1)+", Expected the chats to be routed to '"+rule.routing_parameters.get(i%3)+"'");//i%3 is to get(0) for cyclick order use case

					if(i==3)
					{
						etest.log(Status.INFO,"Now checking for cyclic routing for routing action-->"+rule.routing_action);
					}

					visitor_driver=visitor_driver_manager.getDriver(driver);

					String user_name1=ExecuteStatements.getUserName(driver),user_name2=ExecuteStatements.getUserName(driver2),user_name3=ExecuteStatements.getUserName(driver3);
			       	expected_result=getExpectedResultHashtable(user_name1,(i==0|i==3),user_name2,(i==1),user_name3,(i==2));//adding expected value based on number of chats routed.

					ChatRouting.initiateChat(visitor_driver,widget_code,etest);

			        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);

        	        if(isExpectedResultFound(expected_result,actual_result,etest)==false)
			        {
			        	failcount++;
			        }			        
				}
			}

			try
			{
				quickCleanup(driver,etest,rule);
				// failcount++;disabled because not a test case
				if(rule.routing_parameters!=null && rule.routing_parameters.contains(ChatRouting.ALL_AVAILABLE_OPERATORS))
				{
					com.zoho.livedesk.util.common.actions.Status.changeStatus(driver2,"available",etest);
				}
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",e1);
			}

			Driver.quitDriver(visitor_driver);
		}
		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkRouting","Exception",e);
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static boolean checkAdvancedRouting(WebDriver driver,WebDriver driver2,WebDriver driver3,String widget_code,ChatRoutingRule rule1,ChatRoutingRule rule2,Hashtable<String,Boolean> expected_result,ExtentTest etest) throws Exception
	{
		//Rule1 and Rule2 must contain criteria as question and value must be same question

		WebDriver visitor_driver=null;

		String	
        label=CommonUtil.getUniqueMessage(),
        visitor_name="name"+label,
        visitor_mail=label+"@email.com",
        visitor_question=rule1.rule_value1,
        department=null;


		int failcount=0;
		Hashtable<String,Boolean> actual_result=null;
		Hashtable<String,String> visitor_details=null;

		boolean isSwapRulesAndDisableRulesCheck=false;

		try
		{
			if(rule1.rule_value1.contains("question1") && rule2.rule_value1.contains("question2"))//to check if contradicting rule use case is running
			{
				visitor_question=rule1.rule_value1+" "+rule2.rule_value1;		
				isSwapRulesAndDisableRulesCheck=true;
			}

			com.zoho.livedesk.util.Cleanup.deleteAllChatRouting(driver);

	        Tab.navToChatRoutingTab(driver);

	        ChatRouting.addChatRoutingRule(driver,etest,rule2);
	        ChatRouting.addChatRoutingRule(driver,etest,rule1);
	        //now chat routing from top down will be executed in rule1-->rule2

			visitor_driver=visitor_driver_manager.getDriver(driver);
			
			visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

	        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);

	        if(isExpectedResultFound(expected_result,actual_result,etest)==false)
	        {
	        	failcount++;
	        }

	        if(isSwapRulesAndDisableRulesCheck)
	        {
	        	// ChatUtil.postToAutomationDevChannel("Check Drag and drop now");
	        	// CommonUtil.sleep(10000);

		        if(ChatRouting.dragRuleToTop(driver,etest,rule2)==false)
		        {
			       result.put("CRRT30",false);
			       etest.log(Status.FAIL,"Rule position was not changed after drag and drop");
		        }
		        else
		        {
		        	result.put("CRRT30",true);
				    etest.log(Status.PASS,"Rule position was changed after drag and drop");
		        }

		        String user_name1=ExecuteStatements.getUserName(driver);
		        String user_name2=ExecuteStatements.getUserName(driver2);
		        String user_name3=ExecuteStatements.getUserName(driver3);

		        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,true,user_name3,false);//rules are swapped

				visitor_driver=visitor_driver_manager.getDriver(driver);
				
				visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

		        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);

		        if(isExpectedResultFound(expected_result,actual_result,etest)==false)
		        {
		        	result.put("CRRT31",false);
		        	etest.log(Status.FAIL,"Chats were NOT routed accordingly after drag and drop");
		        }
		        else
		        {
		        	result.put("CRRT31",true);
		        	etest.log(Status.PASS,"Chats were routed accordingly after drag and drop");
		        }

		        if(ChatRouting.disableRule(driver,etest,rule2))
		        {
		        	etest.log(Status.PASS,"Rule '"+rule2.toString()+"' was disabled successfully.");
		        	result.put("CRRT26",true);	        	
		        }
		        else
		        {
		        	etest.log(Status.FAIL,"Rule '"+rule2.toString()+"' was NOT disabled successfully.");
	                TakeScreenshot.screenshot(driver,etest,"ChatRouting","NotDisabled","Screenshot");
		        	result.put("CRRT26",false);
		        }

		        expected_result=getExpectedResultHashtable(user_name1,true,user_name2,false,user_name3,false);//rule2 disabled rule1 enabled

				visitor_driver=visitor_driver_manager.getDriver(driver);
				
				visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

		        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);

		        if(isExpectedResultFound(expected_result,actual_result,etest))
		        {
		        	etest.log(Status.PASS,"Chats were routed to expected agents after rule was disabled");		        	
					result.put("CRRT14",true);
		        }
		        else
		        {
					result.put("CRRT14",false);
		        	etest.log(Status.FAIL,"Chats were NOT routed to expected agents after rule was disabled");
                    TakeScreenshot.screenshot(driver,etest,"ChatRouting","RuleNotDisabled","Screenshot");		        	
		        }

		        if(ChatRouting.enableRule(driver,etest,rule2))
		        {
		        	etest.log(Status.PASS,"Rule '"+rule2.toString()+"' was enabled successfully.");	
		        	result.put("CRRT27",true);     	
		        }
		        else
		        {
		        	result.put("CRRT27",false);     	
		        	etest.log(Status.FAIL,"Rule '"+rule2.toString()+"' was NOT enabled successfully.");
	                TakeScreenshot.screenshot(driver,etest,"ChatRouting","RuleNotEnabled","Screenshot");
		        }

		        expected_result=getExpectedResultHashtable(user_name1,false,user_name2,true,user_name3,false);//rules are swapped

				visitor_driver=visitor_driver_manager.getDriver(driver);
				
				visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
		        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

		        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);

		        if(isExpectedResultFound(expected_result,actual_result,etest))
		        {
		        	etest.log(Status.PASS,"Chats were routed to expected agents after disabled rule was enabled back");		        	
		        	result.put("CRRT15",true);
		        }
		        else
		        {
		        	result.put("CRRT15",false);
		        	etest.log(Status.FAIL,"Chats were NOT routed to expected agents after disabled rule was enabled back");
                    TakeScreenshot.screenshot(driver,etest,"ChatRouting","RuleNotDisabled","Screenshot");
		        }

	        }

			Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkRouting","Exception",e);
		}
		finally
		{		
			return CommonUtil.returnResult(failcount);
		}
	}

	public static void setupStatus(WebDriver driver,ExtentTest etest,AgentStatus status) throws Exception
	{
		if(status==AgentStatus.OFFLINE)
		{
			driver.get("https://www.zoho.com/");
		}
		else if(status==AgentStatus.ENGAGED)
		{
			User user = new User(ExecuteStatements.getUserName(driver),"1",true,true);
			ConcurrentChatCommonFunctions.setupConcurrentChatType(driver,etest,ExecuteStatements.getWidgetCode(driver),user,null);
		}
		else if(status==AgentStatus.BUSY)
		{
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");
		}
		else if(status==AgentStatus.AVAILABLE)
		{
			if(driver.getCurrentUrl().contains("salesiq")==false)
			{
				CommonUtil.navigateToPreviousPage(driver);
			}

			User user = new User(ExecuteStatements.getUserName(driver));
			ConcurrentChatCommonFunctions.setupConcurrentChatType(driver,etest,ExecuteStatements.getWidgetCode(driver),user,null);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
		}

        etest.log(Status.INFO,"User status was set to "+status);
	}

	public static boolean checkChatRoutingRulesBasedOnAvailibility(WebDriver driver,WebDriver driver2,WebDriver driver3,String widget_code,AgentStatus driver_status,ChatRoutingRule rule,Hashtable<String,Boolean> expected_result,ExtentTest etest) throws Exception
	{
		WebDriver visitor_driver=null;

		String	
        label=CommonUtil.getUniqueMessage(),
        visitor_name="name"+label,
        visitor_mail=label+"@email.com",
        visitor_question="Q"+label,
        department=null;

		int failcount=0;
		Hashtable<String,Boolean> actual_result=null;
		Hashtable<String,String> visitor_details=null;

		try
		{
			com.zoho.livedesk.util.Cleanup.deleteAllChatRouting(driver);

			try
			{
				ChatWindow.closeAllChats(driver);
				ChatWindow.closeAllChats(driver2);
				ChatWindow.closeAllChats(driver3);
				etest.log(Status.INFO,"All chats are closed");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(driver2,etest);
				TakeScreenshot.infoScreenshot(driver3,etest);
			}
			catch(Exception e)
			{
				CommonUtil.doNothing();
				etest.log(Status.WARNING,"Some chats may not be closed");
				TakeScreenshot.infoScreenshot(driver,etest);
				TakeScreenshot.infoScreenshot(driver2,etest);
				TakeScreenshot.infoScreenshot(driver3,etest);
			}

	        Tab.navToChatRoutingTab(driver);

	        ChatRouting.addChatRoutingRule(driver,etest,rule);

			visitor_driver=visitor_driver_manager.getDriver(driver);

	        setupStatus(driver,etest,driver_status);
			
			visitor_details=ConversationViewCommonFunctions.addVisitorDetails(visitor_name,visitor_mail,null,null,visitor_question,null,null);
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.INITIATED,visitor_details,null);

	        if(driver_status==AgentStatus.OFFLINE)
	        {
		        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver2,driver3);
	        }
	        else
	        {
		        actual_result=ChatRouting.isChatRoutedToAgents(etest,driver,driver2,driver3);
	        }

	        if(isExpectedResultFound(expected_result,actual_result,etest)==false)
	        {
	        	failcount++;
	        }

			Driver.quitDriver(visitor_driver);
		}

		catch(Exception e)
		{
			failcount++;
			TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",e);
			TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"checkRouting","Exception",e);
		}
		finally
		{
			try
			{
				try
				{
					ChatWindow.acceptChat(driver,etest);
				}
				catch(Exception e)
				{
					etest.log(Status.INFO,"No chat notification were found ");
					TakeScreenshot.infoScreenshot(driver,etest);
				}
		        setupStatus(driver,etest,AgentStatus.AVAILABLE);
			}
			catch(Exception exp)
			{
				etest.log(Status.WARNING,"Agent status was not set to available. Other testing in this module may fail.");
				TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",exp);
			}

			return CommonUtil.returnResult(failcount);
		}
	}


	public static boolean isExpectedResultFound(Hashtable<String,Boolean> expected,Hashtable<String,Boolean> actual,ExtentTest etest)
	{
		int failcount=0;

		Set<String> usernames = expected.keySet();

        for(String username: usernames)
        {

        	try
        	{
	        	String status=actual.get(username)?" routed ":" NOT routed ";

	        	if(expected.get(username).equals(actual.get(username)))
	        	{
	        		etest.log(Status.PASS,"Chat was"+status+"for '"+username+"'");
	        	}
	        	else
	        	{	
	        		failcount++;
	       			etest.log(Status.FAIL,"Chat was"+status+"for '"+username+"'");
	        	}
        	}

        	catch(Exception e)
        	{
				TakeScreenshot.log(e,etest);
        		failcount++;
        	}
        }

        return CommonUtil.returnResult(failcount);
	}

	public static Hashtable<String,Boolean> getExpectedResultHashtable(String user_name1,boolean expected_result_1,String user_name2,boolean expected_result_2)
	{
		return getExpectedResultHashtable(user_name1,expected_result_1,user_name2,expected_result_2,null,null);
	}

	public static Hashtable<String,Boolean> getExpectedResultHashtable(String user_name1,Boolean expected_result_1,String user_name2,Boolean expected_result_2,String user_name3,Boolean expected_result_3)
	{
		Hashtable<String,Boolean> expected_results=new Hashtable<String,Boolean>();

		if(user_name1!=null)
		{
			expected_results.put(user_name1,expected_result_1);
		}
		if(user_name2!=null)
		{
			expected_results.put(user_name2,expected_result_2);
		}
		if(user_name3!=null)
		{
			expected_results.put(user_name3,expected_result_3);
		}

		return expected_results;
	}

	public static boolean isRuleEquals(ChatRoutingRule rule,String rule_criteria,String rule_condition,String rule_value1,String rule_value2)
	{
		if( rule.rule_criteria.equals(rule_criteria) && rule.rule_condition.equals(rule_condition) && rule.rule_value1.equals(rule_value1) )
		{

			if(rule.rule_value2!=null && rule.rule_value2.equals(rule_value2))
			{
				return true;				
			}
			else if(rule.rule_value2==null && rule_value2==null)
			{
				return true;
			}
		}

		return false;
	}

	public static boolean isRuleEquals(ChatRoutingRule rule,String rule_criteria,String rule_condition,String rule_value1)
	{
		return isRuleEquals(rule,rule_criteria,rule_condition,rule_value1,null);
	}

	public static void setupLeastLoaded(WebDriver driver,WebDriver driver2,WebDriver driver3,String widget_code,ExtentTest etest) throws Exception
	{
		//driver will be least loaded, driver chats-1,driver2 chats-2,driver3 chats-3
		String user1=ExecuteStatements.getUserName(driver),user2=ExecuteStatements.getUserName(driver2),user3=ExecuteStatements.getUserName(driver3);
		ConcurrentChatCommonFunctions.reachChatsLimitThreshold(driver,etest,widget_code,"1");
		ConcurrentChatCommonFunctions.reachChatsLimitThreshold(driver2,etest,widget_code,"2");
		ConcurrentChatCommonFunctions.reachChatsLimitThreshold(driver3,etest,widget_code,"3");
		etest.log(Status.PASS,"Current number of chats "+user1+" : 1 ,"+user2+" : 2 ,"+user3+" : 3");
	}

	public static void quickSetup(WebDriver driver,ExtentTest etest,ChatRoutingRule rule) throws Exception
	{
		if(rule.routing_parameters!=null)
		{
			if(rule.routing_parameters.contains(dept))
			{
				Department.addDept(driver,dept,"depttype_publi",ExecuteStatements.getUserName(driver),etest);
				etest.log(Status.PASS,"Department '"+dept+"' was added");
			}
			if(rule.routing_parameters.contains(ChatRouting.CRM_LEAD_OR_CONTACT_OWNER))
			{	
			    TrackingRingsCustomizeCommonFunctions.enableCRMIntegration(driver,etest);
			}			
		}
	}

	public static void quickCleanup(WebDriver driver,ExtentTest etest,ChatRoutingRule rule) throws Exception
	{
		if(rule.routing_parameters!=null && rule.routing_parameters.contains(dept))
		{
			Department.deleteDepartment(driver,dept,ExecuteStatements.getSystemGeneratedDepartment(driver),etest);
			etest.log(Status.PASS,"Department '"+dept+"' was deleted");
		}
        ChatWindow.closeAllChats(driver);
	}

	public static void setupChatRoutingRealTimeCondition(WebDriver driver,WebDriver visitor_driver,Hashtable<String,String> visitor_details,String widget_code,ChatRoutingRule rule,ExtentTest etest) throws Exception
	{
		boolean isPerformAction=false;

		String label=null,visitor_name=null,visitor_mail=null,visitor_question=null,department=null;

		if(visitor_details!=null)
		{
			visitor_name=visitor_details.get(ConversationViewConstants.VISITOR_NAME);
			visitor_mail=visitor_details.get(ConversationViewConstants.VISITOR_EMAIL);
			visitor_question=visitor_details.get(ConversationViewConstants.VISITOR_QUESTION);

			if(visitor_details.get(ConversationViewConstants.VISITOR_DEPARTMENT)!=null)
			{
				department=visitor_details.get(ConversationViewConstants.VISITOR_DEPARTMENT);
			}
		}
		else
		{
	        label=CommonUtil.getUniqueMessage();
	        visitor_name="name"+label;
	        visitor_mail=label+"@email.com";
	        visitor_question="question"+label;
		}

        visitor_driver.navigate().refresh();

		if(isRuleEquals(rule,ChatRouting.CAMPAIGN_NAME,ChatRouting.EQUALS,campaign_name))
		{
		    VisitorWindow.createPageCampaign(visitor_driver,widget_code,rule.rule_value1);
		    VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
		    isPerformAction=true;
		}

		if(isRuleEquals(rule,ChatRouting.COUNTRY,ChatRouting.EQUALS,country))
		{
			VisitorWindow.createPage(visitor_driver,widget_code);
		    VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question,etest);
			isPerformAction=true;	
		}

		if(rule.routing_action.equals(ChatRouting.DO_NOT_ROUTE))
		{
			ChatRouting.initiateChat(visitor_driver,widget_code,etest);
			isPerformAction=true;
		}

		if(isRuleEquals(rule,ChatRouting.EMAIL,ChatRouting.EQUALS,visitor_mail) && (rule.routing_parameters.contains(ChatRouting.LAST_CHAT_ATTENDER) || rule.routing_parameters.contains(ChatRouting.ALL_AVAILABLE_OPERATORS)))
		{
	        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.COMPLETED_BASIC,visitor_details,null);
	        VisitorWindow.clickCloseChatWidget(visitor_driver);
	        visitor_driver.navigate().refresh();
			VisitorWindow.createPage(visitor_driver,widget_code);
		    VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question+"2",etest);
		    isPerformAction=true;
		}

		if(rule.routing_parameters!=null)
		{
			if(rule.routing_parameters.contains(dept))
			{
				VisitorWindow.createPage(visitor_driver,widget_code);
			    VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,dept,visitor_question,etest);
				isPerformAction=true;
			}

			if(rule.routing_parameters.contains(ChatRouting.CRM_LEAD_OR_CONTACT_OWNER))
			{
	            IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);

	            int addNewVisitorTo=rule.getConfigureCRMAsLead()?0:1;

	            IntegrationSettings.addNewVisitorTo(driver,addNewVisitorTo,etest);

	            Thread.sleep(1000);
		        ConversationViewCommonFunctions.setupChatType(driver,visitor_driver,etest,widget_code,ChatType.ONGOING,visitor_details,null);

		        CommonUtil.sleep(5000);
		        try
		        {
		        	String crm_type=ChatWindow.getCRMType(driver);

			        if(crm_type.contains("Lead") || crm_type.contains("Contact"))
			        {
			        	etest.log(Status.PASS,"Visitor was successfully added as "+crm_type);
			        }
			        else
			        {
			        	etest.log(Status.PASS,"Visitor was NOT successfully added to CRM. Found CRM Type : "+crm_type);
			        	TakeScreenshot.screenshot(driver,etest);	        	
			        }
		        }
		        catch(Exception e1)
		        {
		        	etest.log(Status.PASS,"Visitor was NOT added to CRM");
					e1.printStackTrace();
					TakeScreenshot.screenshot(driver,etest,MODULE_NAME,"checkRouting","Exception",e1);
		        }

		        ChatWindow.endAndCloseChat(driver);

		        VisitorWindow.clickCloseChatWidget(visitor_driver);

		        visitor_driver.navigate().refresh();
		        VisitorsOnline.waitTillVisitorLeaves(driver);

				VisitorWindow.createPage(visitor_driver,widget_code);
			    VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_mail,null,visitor_question+"2",etest);

		        isPerformAction=true;
		    }
		}

		if(!isPerformAction)
		{
			throw new ZohoSalesIQRuntimeException("No action was performed in setup chat routing please configure in setupChatRoutingRealTimeCondition method first");
		}

		TakeScreenshot.screenshot(visitor_driver,etest,MODULE_NAME,"InitiateChat","After",0);
	    etest.log(Status.INFO,"Required setup was setup for rule "+rule.toString());
	}
}
