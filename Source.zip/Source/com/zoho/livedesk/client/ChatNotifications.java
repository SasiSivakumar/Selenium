//$Id$
package com.zoho.livedesk.client;
import com.zoho.livedesk.util.Util;
import java.io.File;
import java.util.List;
import java.util.Arrays;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;
import java.net.*;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.Functions;
import com.zoho.livedesk.client.TakeScreenshot;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.FluentWait;
import com.google.common.base.Function;
import java.util.Date;
import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.VisitorWindow;
import java.text.SimpleDateFormat;
import com.zoho.livedesk.util.common.CommonWait;

public class ChatNotifications
{
    public static WebDriver visitordriver;
	public static String currenttime;
	public static ExtentReports extent;
	public static ExtentTest etest;
	public static Hashtable result;
	static Hashtable hashtable=new Hashtable();
	public static String msg;
	public static int resultcount=0;
	public static String portalname="ldautomation12";
	public static String embedname="embed3";
	public static String deptname="ldautomation12";

	public static String widgetCode;
	public static Hashtable test(WebDriver driver1) throws Exception
	{	
		try
		{
			result=new Hashtable();

			widgetCode = ExecuteStatements.getWidgetCode(driver1);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VD1"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Notifications");
            
            result.put("VD1",checkVisitorAcptDetails(driver1));
            closeVisitorDriver();

        	ComplexReportFactory.closeTest(etest);


			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VD2"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Notifications");
            
            result.put("VD2",checkUptdUsrAndClk(driver1));
            closeVisitorDriver();
            
			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VD3"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Notifications");
          
            result.put("VD3",checkAcptwindowDisapr(driver1));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("VD4"));
            ComplexReportFactory.setValues(etest,"Automation","Chat Notifications");
          
            result.put("VD4",checkVisNmOnReturn(driver1));
            closeVisitorDriver();
            
			ComplexReportFactory.closeTest(etest);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println("Exception occured in main test");
			etest.log(Status.FATAL,"Module breakage occurred "+ex);
            System.out.println("~~Module breakage occurred");
		}
		hashtable.put("result", result);
        hashtable.put("servicedown",new Hashtable());
		return hashtable;
	}
	public static boolean templatetest(int i) throws Exception
	{
		etest.log(Status.INFO,"Test "+i+"------Test passed");
		return true;
	}

	public static boolean checkVisitorAcptDetails(WebDriver driver) throws Exception
	{
		try
		{
			CommonUtil.refreshPage(driver);
            visitordriver = Functions.setUp();
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			Tab.clickVisitorsOnline(driver);
            try
            {
                VisitorWindow.createPage(visitordriver,widgetCode);
                VisitorWindow.initiateChatVisTheme(visitordriver,null,null,null,deptname,"Testing?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","visitordetails","Error checking visitor details",e);
                return false;
            }
			
            waitTillAcptWindow(driver);
			checkVisNamInitial(driver);
			checkAskdQuestion(driver,"Testing?");
			newOrReturnVis(driver,"New Visitor");
			checkDeptName(driver,deptname);
			checkVisUrl(driver,visitordriver.getCurrentUrl());
			ChatWindow.ignoreChat(driver);
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Error checking visitor details",e);
		}
		return checkResult(5);
	}
	public static boolean checkUptdUsrAndClk(WebDriver driver) throws Exception
	{	msg=datetimereturner();
		try
		{
            visitordriver = Functions.setUp();
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			Tab.clickVisitorsOnline(driver);
            
            try
            {
                VisitorWindow.createPage(visitordriver,widgetCode);
                VisitorWindow.initiateChatVisTheme(visitordriver,"Testusername"+msg,"test"+msg+"@email.com",null,deptname,"Testing?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","InitiateChat","Error checking updated visitor name and clock time decreasing",e);
                return false;
            }
			etest.log(Status.INFO,"Name and Email is updated by visitor");
			waitTillAcptWindow(driver);
			checkVisname(driver,"Testusername"+msg);
			checkcountdown(driver);

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Error checking updated visitor name and clock time decreasing",e);
		}
		return checkResult(2);
	}
	public static boolean checkAcptwindowDisapr(WebDriver driver) throws Exception
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			waitTillClkoo(driver);
			etest.log(Status.INFO,"Acceptance window countdown ended");
			if(CommonUtil.elfinder(driver,"id","wpckup").isDisplayed())
			{
				etest.log(Status.FAIL,"Acceptance window not disappeared------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Acceptance window not disappeared after clock 00.00");
			}
			else
			{
				etest.log(Status.INFO,"Acceptance window disappeared------Test passed");
				resultcount++;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Error disappearing acceptance window",e);
		}
		return checkResult(1);
	}
	public static boolean checkVisNmOnReturn(WebDriver driver) throws Exception
	{
		try
		{
            msg=datetimereturner();
            visitordriver = Functions.setUp();
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
            try
            {
                VisitorWindow.createPage(visitordriver,widgetCode);
                VisitorWindow.initiateChatVisTheme(visitordriver,"Testusername"+msg,null,null,deptname,"Testing?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","InitiateChat","Error checking visitor details on visitor return",e);
                return false;
            }
            
            waitTillAcptWindow(driver);
			checkVisname(driver,"Testusername"+msg);
			ChatWindow.acceptChat(driver,etest);
			ChatWindow.endAndCloseChat(driver);
			
            Thread.sleep(10000);
			
            try
            {
                visitordriver.get("https://www.zoho.com/");
                VisitorWindow.createPage(visitordriver,widgetCode);
                VisitorWindow.initiateChatVisTheme(visitordriver,null,null,null,deptname,"Testing?",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visitordriver,etest,"SalesIq","InitiateChat","Error checking visitor details on visitor return",e);
                return false;
            }
            
            newOrReturnVis(driver,ExecuteStatements.getUserName(driver));
			
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Error checking visitor details on visitor return",e);
		}
		return checkResult(2);
	}
	public static void waitTillAcptWindow(WebDriver driver) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("waitinglist")));
        
        Thread.sleep(1500);
	}
	public static void waitTillClkoo(WebDriver driver) throws Exception
	{
		FluentWait wtr = CommonUtil.waitreturner(driver,70,200);
		wtr.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						try
						{
							if(driver.findElement(By.xpath("//div[@id='waitinglist']//div[@class='wtime']")).isDisplayed())
							{
								return false;
							}
							else
							return true;
						}
						catch(Exception e)
						{
							return true;
						}
					}
				});
	}
	public static void checkVisname(WebDriver driver,String visname) throws Exception
	{
		try
		{
			WebElement nam=CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'longwaithdr')]//div[@class='txtelips']");
			if(nam.getAttribute("innerText").contains(visname))
			{
				etest.log(Status.INFO,"Visitor name is present------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Visitor name is not present------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Visitor name not contains Visitor");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking updated visitor name",e);
		}
	}
	public static void checkcountdown(WebDriver driver) throws Exception
	{
		try
		{
			WebElement countdownout=CommonUtil.elfinder(driver,"xpath","//div[@id='waitinglist']//div[@class='wtime']");
			String countd=countdownout.getAttribute("innerText");
			countd=countd.replace(":",".");
			//countd = countd.substring(countd.length() - 2);
			float countdint = Float.parseFloat(countd);
			//int countdint=Integer.parseInt(countd);
			System.out.println(countdint+"-------time1");
			Thread.sleep(4000);
			String sccountd=countdownout.getAttribute("innerText");
			sccountd=sccountd.replace(":",".");
			float sccountdint = Float.parseFloat(sccountd);
			//sccountd = sccountd.substring(sccountd.length() - 2);
			//int sccountdint=Integer.parseInt(sccountd);
			System.out.println(sccountdint+"-------time2");
			if(sccountdint < countdint)
			{
				etest.log(Status.INFO,"Acceptance window clock time is decreasing------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Acceptance window clock time is decreasing------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","no decreasing in clock time");
			}
			

		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking decreasing in countdown",e);
		}
	}
	public static void checkVisNamInitial(WebDriver driver) throws Exception
	{
		try
		{
			WebElement nam=CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'longwaithdr')]//div[@class='txtelips']");
			if(nam.getAttribute("innerText").contains("Visitor"))
			{
				etest.log(Status.INFO,"Initial visitor name is present------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Initial visitor name is not present------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Visitor name does not contains Visitor");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking initial visitor name",e);
		}
	}
	public static void checkAskdQuestion(WebDriver driver,String ques) throws Exception
	{
		try
		{
			WebElement qeusout=CommonUtil.elfinder(driver,"xpath","//div[@id='waitinglist']//div[@class='longwaithvrmn']//div[@id='ques']//pre");
			if(qeusout.getAttribute("innerText").contains(ques))
			{
				etest.log(Status.INFO,"Question asked by visitor is present------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Question asked by visitor is not present------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","Question '"+ques+"' is not present");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking Question asked by visitor",e);
		}
	}
	public static void newOrReturnVis(WebDriver driver,String visstat) throws Exception
	{
		try
		{
            Thread.sleep(3000);
            
			WebElement visstatout=CommonUtil.elfinder(driver,"xpath","//div[@id='waitinglist']//div[contains(@class,'longwait-embdepmn')]//div[@id='lattender']");
            
            if(visstatout.getAttribute("innerText").contains(visstat))
			{
				etest.log(Status.INFO,visstat+" is present------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,visstat+" is not present------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","No "+visstat);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking new visitor or returning visitor",e);
		}
	}
	public static void checkDeptName(WebDriver driver,String embedn) throws Exception
	{
		try
		{
			WebElement embedout=CommonUtil.elfinder(driver,"xpath","//div[@id='waitinglist']//div[contains(@class,'longwait-embdepmn')]//span[@id='dept']");
			if(embedout.getAttribute("innerText").contains(embedn))
			{
				etest.log(Status.INFO,"Expected embedname is present------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Expected embedname is not present------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","No expected embedname");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking embed name",e);
		}
	}
	public static void checkVisUrl(WebDriver driver,String url) throws Exception
	{
		try
		{
			WebElement urlout=CommonUtil.elfinder(driver,"xpath","//div[@id='waitinglist']//div[contains(@id,'currpage')]//a");
			if(urlout.getAttribute("href").contains(url))
			{
				etest.log(Status.INFO,"Expected url is present------Test passed");
				resultcount++;
			}
			else
			{
				etest.log(Status.FAIL,"Expected url is not present------Test failed");
				TakeScreenshot.screenshot(driver,etest,"SalesIq","visitordetails","No expected url");
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"SalesIq","Visitor-details","Error checking visitor url",e);
		}
	}
	public static void waitUntilVisDisAppr(WebDriver driver,final String vid) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,90,200);
		wait.until(new Function<WebDriver,Boolean>(){
		        public Boolean apply(WebDriver driver)
		        {	
		        	try
		        	{
		            	if(driver.findElements(By.xpath("//div[@id='visitor_monitor']//div[contains(@id,'"+vid+"')]")).size()==0)
		            	{
		                	return true;
		            	}
		            	return false;
		            }
		            catch(Exception e)
		            {
		            	return false;
		            }
		        }
		    });	
	}
	public static String datetimereturner()
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
        String dateAsString = simpleDateFormat.format(new Date());
		System.out.println(dateAsString);
		return dateAsString;
	}
	public static boolean checkResult(int i) throws Exception
	{
		if(resultcount==i)
		{
			resultcount=0;
			return true;
		}
		else
		{
			resultcount=0;
			return false;
		}
	}
	
	public static void closeVisitorDriver()
    {
        if(visitordriver != null)
        {
            visitordriver.quit();
            visitordriver = null;
        }
    }
}
