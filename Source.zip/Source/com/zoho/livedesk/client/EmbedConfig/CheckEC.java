//$Id$
package com.zoho.livedesk.client.EmbedConfig;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;


import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.FileUpload.FileType;


import com.google.common.base.Function;

public class CheckEC
{

	public static final By
	SAVE_CANCEL_DIV = By.id("save_emconfig");
	
	public static void printHeaderAndDetails(WebDriver driver, String div, String id) throws Exception
	{
		WebElement e = CommonUtil.elfinder(driver,"xpath","//div[@prop_id='"+id+"']");
		CommonUtil.inViewPort(e);
		System.out.println("embed_"+div+"_header="+Websites.divHeader(driver,id));
		System.out.println("embed_"+div+"_desc="+Websites.divDesc(driver,id));
	}
	
	public static Boolean checkAddEmbed(WebDriver driver, String embedname, ExtentTest etest) throws Exception
	{
		try
		{
			WebEmbed.addWebEmbed(driver,embedname);

			Tab.navToEmbedTab(driver);

			if(WebEmbed.getWebEmbed(driver,embedname,etest) != null)
			{
				etest.log(Status.INFO,"Embed "+embedname+" is added");
				return true;
			}
			else
			{
				etest.log(Status.FAIL,"Embed "+embedname+" is not added");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","AddEmbed","Error");
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","AddEmbed","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static Boolean deleteEmbed(WebDriver driver, final String embedname, ExtentTest etest) throws Exception
	{
		try
		{
			try
			{
				WebsitesTab.closeEmbedConfig(driver,etest);
			}
			catch(Exception excep)
			{
				CommonUtil.refreshPage(driver);
			}
			WebEmbed.deleteEmbed(driver,embedname);

			FluentWait wait = CommonUtil.waitreturner(driver,10,250);

			wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.id("embedlist")).getAttribute("innerHTML").contains(embedname))
	                {
	                    return false;
	                }
	                return true;
	            }
	        });

			Thread.sleep(1000);

			Tab.navToEmbedTab(driver);

			if(WebEmbed.getWebEmbed(driver,embedname,etest) == null)
			{
				return true;
			}
			else
			{
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","DeleteEmbed","Error");
				return false;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","DeleteEmbed","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkEmbedTab(WebDriver driver, String tab,ExtentTest etest) throws Exception
	{
		try
		{
			String embed=TestInit.embed;

			int result = 2;

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			FluentWait wait = CommonUtil.waitreturner(driver,20,250);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@boxname='"+tab+"']")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@boxname='"+tab+"']")));

			WebElement e = CommonUtil.elfinder(driver,"xpath","//div[@boxname='"+tab+"']");

			String header = CommonUtil.elementfinder(driver,e,"tagname","p").getText();
			String desc = CommonUtil.elementfinder(driver,e,"tagname","div").getText();

			String expected = ResourceManager.getRealValue("embed_"+tab+"_header");

			if(!header.equals(expected))
			{
				etest.log(Status.FAIL,"Actual:"+header+"--Expected:"+expected+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckTrackingTab","Error");
				result--;
			}

			expected = ResourceManager.getRealValue("embed_"+tab+"_desc");

			if(!desc.equals(expected))
			{
				System.out.println("Actual:"+desc+"--Expected:"+expected+"--");
				etest.log(Status.FAIL,"Actual:"+desc+"--Expected:"+expected+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckTrackingTab","Error");
				result--;
			}

			if(tab.equals("visitortracking"))
			{
				WebsitesTab.clickVisitorTracking(driver,etest);

				WebsitesTab.clickInstallationInTracking(driver,etest);
			}
			else if(tab.equals("livechat"))
			{
				WebsitesTab.clickLiveChat(driver,etest);

				WebsitesTab.clickInstallationInLiveChat(driver,etest);
			}

			WebsitesTab.clickChatWindow(driver,etest);

			if(tab.equals("visitortracking"))
			{
				String leftNav = WebsitesTab.getLeftNav(driver).getText();

				if(!leftNav.toLowerCase().contains("widget"))
				{
					etest.log(Status.INFO,"Widget is not present");

					if(result == 2)
					{
						WebsitesTab.closeEmbedConfig(driver,etest);
						return true;
					}
					WebsitesTab.closeEmbedConfig(driver,etest);
					return false;
				}
				else
				{
					etest.log(Status.FAIL,"Widget is present");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckTrackingTab","Error");
				}
			}
			else
			{
				WebsitesTab.clickWidget(driver,etest);

				etest.log(Status.INFO,"Widget is present");

				WebsitesTab.clickChatWindow(driver,etest);
				WebsitesTab.closeEmbedConfig(driver,etest);

				return true;
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","Check","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkInstallationTab(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			String embed=TestInit.embed;

			int result = 2;

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickInstallationInLiveChat(driver,etest);

			String desc = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","emcnf_desc").getText();

			String expected = ResourceManager.getRealValue("embed_installation_desc");

			if(!desc.equals(expected))
			{
				System.out.println("Actual:"+desc+"--Expected:"+expected+"--");
				etest.log(Status.FAIL,"Actual:"+desc+"--Expected:"+expected+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckInstallationTab","Error");
				result--;
			}

			String code = CommonUtil.elementfinder(driver,WebsitesTab.getRightNav(driver),"tagname","pre").getText();

			String embedcode = ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			CommonSikuli.findInWholePage(driver,"Schedule.png","UI8",etest);
			CommonSikuli.findInWholePage(driver,"Webmaster.png","UI9",etest);
			CommonSikuli.findInWholePage(driver,"Wordpress.png","UI11",etest);
			// CommonSikuli.findInWholePage(driver,"Magneto.png","UI12",etest);
			CommonSikuli.findInWholePage(driver,"Opencart.png","UI13",etest);
			CommonSikuli.findInWholePage(driver,"Drupal.png","UI14",etest);
			CommonSikuli.findInWholePage(driver,"Shopify.png","UI15",etest);
			driver.findElement(By.className("sqico-calendar")).click();
			Thread.sleep(1000);
			CommonSikuli.findInWholePage(driver,"Sch.png","UI10",etest);
			
			WebElement scheduleform = CommonUtil.elfinder(driver,"id","scheduleform");
			CommonUtil.elementfinder(driver,scheduleform,"classname","cmn_rbutclor").click();

			String url = "salesiq.localzoho.com";

			if(Util.setUptracking().equals("idc"))
			{
				url = "salesiq.zoho.com";
			}
			else if(Util.setUptracking().equals("pre"))
			{
				url = "presalesiq.zoho.com";
			}
			else if(Util.setUptracking().equals("lab"))
			{
				url = "labsalesiq.localzoho.com";
			}

			String scriptFormat = "<script type=\"text/javascript\">\nvar $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || {widgetcode:\"$CODE\", values:{},ready:function(){}};var d=document;s=d.createElement(\"script\");s.type=\"text/javascript\";s.id=\"zsiqscript\";s.defer=true;s.src=\"https://"+url+"/widget\";t=d.getElementsByTagName(\"script\")[0];t.parentNode.insertBefore(s,t);d.write(\"<div id='zsiqwidget'></div>\");\n</script>";
	
			scriptFormat = scriptFormat.replace("$CODE",embedcode);

			if(code.equals(scriptFormat))
			{
				etest.log(Status.INFO,"Script is present and in correct format");
				WebsitesTab.closeEmbedConfig(driver,etest);
				if(result == 2)
				{
					return true;
				}
				return false;
			}
			else
			{
				etest.log(Status.FAIL,"<b>Expected:</b>script tag is replaced with test<pre>"+code.replaceAll("<script","<test").replaceAll("</script","</test")+"</pre>");
				etest.log(Status.FAIL,"<b>Found:</b>script tag is replaced with test<pre>"+scriptFormat.replaceAll("<script","<test").replaceAll("</script","</test")+"</pre>");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckInstallationTab","Error");
				WebsitesTab.closeEmbedConfig(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckInstallationTab","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkMultiple(WebDriver driver, Boolean enable,ExtentTest etest) throws Exception
	{
		String usecase = enable?"Enable":"Disable";
		String id = "ISRESTRICTED0";
		String embedcode;

		try
		{
			String embed=TestInit.embed;

			embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			int result = 2;

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickInstallationInLiveChat(driver,etest);

			String actual = Websites.divHeader(driver,id);

			String expected = ResourceManager.getRealValue("embed_multiplesite_header");

			if(!actual.equals(expected))
			{
				System.out.println("Actual:"+actual+"--Expected:"+expected+"--");
				etest.log(Status.FAIL,"Actual:"+actual+"--Expected:"+expected+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckMultipleSites"+usecase,"Error");
				result--;
			}

			actual = Websites.divHeader(driver,id);

			expected = ResourceManager.getRealValue("embed_multiplesite_header");

			if(!actual.equals(expected))
			{
				System.out.println("Actual:"+actual+"--Expected:"+expected+"--");
				etest.log(Status.FAIL,"Actual:"+actual+"--Expected:"+expected+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckMultipleSites"+usecase,"Error");
				result--;
			}

			if(result != 2)
			{
				return false;
			}
		
			Websites.setStatusOfToggle(driver,id,!enable,etest);

			Websites.setStatusOfToggle(driver,id,enable,etest);

			Websites.clickSave(driver,etest);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickInstallationInLiveChat(driver,etest);

			WebElement e = CommonUtil.elfinder(driver,"id",id);

			Boolean current = Websites.getStatusOfToggle(driver,e);

			if(current == enable)
			{
				WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

				try
				{
					if(enable)
					{
						VisitorWindow.createPage(visDriver,embedcode);
						etest.log(Status.INFO,"Multiple sites - "+usecase+" is checked");
						WebsitesTab.closeEmbedConfig(driver,etest);
						return true;
					}
					else
					{
						try
						{
							VisitorWindow.createPage(visDriver,embedcode);
							etest.log(Status.FAIL,"Multiple sites - "+usecase+" is failed");
							TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckMultipleSites"+usecase,"Error");
						}
						catch(Exception err)
						{
							etest.log(Status.INFO,"Multiple sites - "+usecase+" is checked");
							WebsitesTab.closeEmbedConfig(driver,etest);
							return true;
						}
					}
				}
				catch(Exception excep)
				{
					etest.log(Status.FAIL,"Multiple sites - "+usecase+" is failed");
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckMultipleSites"+usecase,"Error",excep);
				}
				WebsitesTab.closeEmbedConfig(driver,etest);
			}
			else
			{
				etest.log(Status.FAIL,"Multiple sites - "+usecase+" is failed");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckMultipleSites"+usecase,"Error");
				WebsitesTab.closeEmbedConfig(driver,etest);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckMultipleSites"+usecase,"Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkWidgetAppearancePage(WebDriver driver,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

		int result = 0;
		try
		{
			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickWidget(driver,etest);

			WebsitesTab.clickFloatWidget(driver,etest);

			WebsitesTab.clickWidget(driver,etest);

			WebsitesTab.clickApperanceInWidget(driver,etest);

			String desc = CommonUtil.elementfinder(driver,WebsitesTab.getMiddleNav(driver),"classname","emcnf_desc").getText();

			String expected = ResourceManager.getRealValue("embed_apperance_desc");

			if(!desc.equals(expected))
			{
				etest.log(Status.FAIL,"Actual:"+desc+"--Expected:"+expected+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWidgetAppearancePage","Error");
			}
			else
			{
				etest.log(Status.INFO,"Description Checked");
				result++;
			}

			String[] div = {"customsticker","choosestickers","GRAVATAR1","HIDEOFFLINE1","MDEVICE_HIDE1"};
			String[] value = {"choosesticker","customsticker","gravatar","hideoffline","hidemobile"};
			
			for(int i = 0 ; i< div.length;i++)
			{
				String actual1 = Websites.divHeader(driver,div[i]);

				String expected1 = ResourceManager.getRealValue("embed_"+value[i]+"_header");

				if(!desc.equals(expected))
				{
					etest.log(Status.FAIL,"Actual:"+actual1+"--Expected:"+expected1+"--");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWidgetAppearancePage","Error");
				}
				else
				{
					etest.log(Status.INFO,value[i].toUpperCase()+" - Header Checked");
					result++;
				}

				actual1 = Websites.divDesc(driver,div[i]);

				expected1 = ResourceManager.getRealValue("embed_"+value[i]+"_desc");

				if(!desc.equals(expected))
				{
					etest.log(Status.FAIL,"Actual:"+actual1+"--Expected:"+expected1+"--");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWidgetAppearancePage","Error");
				}
				else
				{
					etest.log(Status.INFO,value[i].toUpperCase()+" - Description Checked");
					result++;
				}
			}

			WebElement e = CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'lH22')]//div[contains(@class,'lH22')]//div[contains(@class,'hdrtxt')]");
			CommonUtil.inViewPort(e);

			String positionHeader = e.getText();
			
			e = CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'lH22')]//div[contains(@class,'lH22')]//div[contains(@class,'aprs_rectxt')]");
			CommonUtil.inViewPort(e);
			
			String positionDesc = e.getText();

			if(positionDesc.contains(ResourceManager.getRealValue("embed_widgetposition_desc")) && positionHeader.equals(ResourceManager.getRealValue("embed_widgetposition_header")))
			{
				etest.log(Status.INFO,"Position - Description  and HeaderChecked");
				result++;
			}
			else
			{
				etest.log(Status.FAIL,"Actual:"+positionHeader+"--"+positionDesc+"--Expected:"+ResourceManager.getRealValue("embed_widgetposition_header")+"--"+ResourceManager.getRealValue("embed_widgetposition_desc")+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWidgetAppearancePage","Error");
			}

			e = CommonUtil.elfinder(driver,"xpath","//div[contains(@prop_id,'COLOR1')]//div[contains(@class,'hdrtxt')]");
			CommonUtil.inViewPort(e);

			String colourHeader = e.getText();
			
			e = CommonUtil.elfinder(driver,"xpath","//div[contains(@prop_id,'COLOR1')]//div[contains(@class,'mT10')]");
			CommonUtil.inViewPort(e);
			
			String colourDesc = e.getText();

			if(colourDesc.equals(ResourceManager.getRealValue("embed_widgetcolour_desc")) && colourHeader.equals(ResourceManager.getRealValue("embed_widgetcolour_header")))
			{
				etest.log(Status.INFO,"COLOR - Description  and Header Checked");
				result++;
			}
			else
			{
				etest.log(Status.FAIL,"Actual:"+colourHeader+"--"+colourDesc+"--Expected:"+ResourceManager.getRealValue("embed_widgetcolour_header")+"--"+ResourceManager.getRealValue("embed_widgetcolour_desc")+"--");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWidgetAppearancePage","Error");
			}
            
            if(result == 13)
			{
				WebsitesTab.closeEmbedConfig(driver,etest);
				return true;
			}

			WebsitesTab.closeEmbedConfig(driver,etest);
			return false;	
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWidgetAppearancePage","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkWaitingTimer(WebDriver driver, int time,ExtentTest etest) throws Exception
	{

		String embed=TestInit.embed;

		try
		{
			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickConfigurations(driver,etest);

			Websites.selectFromDropdown(driver,"emconfig_wtime",time+" Seconds",etest);

			Websites.clickSave(driver,etest);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickConfigurations(driver,etest);

			String actual = Websites.getValueFromDropdown(driver,"emconfig_wtime");

			if(!actual.equals(time+" Seconds"))
			{
				etest.log(Status.FAIL,"Actual:"+actual+"--Expected:"+time+" Seconds");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWaitingTimer","Error");
				WebsitesTab.closeEmbedConfig(driver,etest);
			}

			int m1 = 0, m2 = 0, s1 = 0, s2 = 0;

			switch(time)
			{
				case 30: s1 = 30;s2 = 15;break;
				case 45: s1 = 45;s2 = 30;break;
				case 60: s1 = 59;s2 = 45;break;
				case 90: m1 = 1;m2 = 1;s1 = 30;s2 = 15;break;
				case 120: m1 = 1;m2 = 1;s1 = 59;s2 = 45;break;
			}

			Thread.sleep(3000);

			boolean result = false;

			WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

			String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				Long t = new Long(System.currentTimeMillis());

				VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);

				if(!VisitorWindow.checkWaitingTimer(visDriver,m1,s1,m2,s2))
				{
					etest.log(Status.FAIL,time+" seconds is failed");
				}
				else
				{
					etest.log(Status.INFO,time+" seconds is checked");
					result = true;
				}
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,time+" seconds is failed");
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckWaitingTimer","Error",e);
			}

			ChatWindow.acceptChat(driver, etest);
			Thread.sleep(1000);
			ChatWindow.endAndCloseChat(driver);
			return result;
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckWaitingTimer","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static void checkDepts(WebDriver driver,ExtentTest etest) throws Exception
	{
		String dept = ""+System.currentTimeMillis();
		try
		{

			String embed=TestInit.embed;
			String username=ExecuteStatements.getUserName(driver);

			TestInit.result.put("EC46",false);
			TestInit.result.put("EC47",false);

			Department.addDept(driver,dept,"depttype_publi",username,etest);
            
            Thread.sleep(2000);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickConfigurations(driver,etest);

			Websites.selectFromDropdown(driver,"emconfig_dept",dept,etest);

            Websites.checkChatWinAppearanceDept(driver,false);
            
			Websites.clickSave(driver,etest);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickConfigurations(driver,etest);

			String actual = Websites.getValueFromDropdown(driver,"emconfig_dept");

			if(!actual.equals(dept))
			{
				etest.log(Status.FAIL,"Actual:"+actual+"--Expected:"+dept);
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDepts","Error");
				WebsitesTab.closeEmbedConfig(driver,etest);
			}

			WebsitesTab.closeEmbedConfig(driver,etest);

			Thread.sleep(3000);

			WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
			String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				Long t = new Long(System.currentTimeMillis());

				VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
				VisitorWindow.checkWaitingDiv(visDriver,true,etest);

				etest.log(Status.INFO,dept+" is not found");

				TestInit.result.put("EC46",true);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckDepts","Error",e);
			}

			ChatWindow.acceptChat(driver,etest);
			Thread.sleep(1000);
			ChatWindow.endAndCloseChat(driver);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickConfigurations(driver,etest);

			Websites.selectFromDropdown(driver,"emconfig_dept","Allow visitor to select department",etest);

            Websites.checkChatWinAppearanceDept(driver,true);
            
            Websites.clickSave(driver,etest);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickConfigurations(driver,etest);

			actual = Websites.getValueFromDropdown(driver,"emconfig_dept");

			if(!actual.equals("Allow visitor to select department"))
			{
				etest.log(Status.FAIL,"Actual:"+actual+"--Expected:Allow visitor to select department");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDepts","Error");
			}

			WebsitesTab.closeEmbedConfig(driver,etest);

			visDriver = TestInit.visitor_driver_manager.getDriver(driver);
				
			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,dept,null,false,etest,false);

				etest.log(Status.INFO,dept+" is found");

				TestInit.result.put("EC47",true);
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,dept+" not found");
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckDepts","Error",e);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDepts","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}
		finally
		{
			try
			{
				if(Department.deleteDepartment(driver,dept,null,etest))
				{
					etest.log(Status.INFO,dept+" is deleted");
				}
				else
				{
					etest.log(Status.FAIL,dept+" is not deleted");
				}
			}
			catch(Exception e)
			{
				etest.log(Status.FAIL,"Error while deleting department - "+dept);
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDepts","Error",e);
			}
		}
	}

	public static boolean checkFields(WebDriver driver,Boolean add, int startingUsecase,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

		for(int n = 0; n<=5; n++)
		{
			TestInit.result.put("EC"+(startingUsecase+n),false);
		}

		int n = 0;

		String usecase = add?"Add":"Remove";

		String ids[] = {"ISNAME2","ISEMAIL2","ISPHONENO2"};
		String fields[] = {"name","email","phone"};

		String embedcode;

		try
		{	
			embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);

			for(String id : ids)
			{
				Websites.changeStatusFieldEditButton(driver,id,add,etest);
			}
			
			Websites.clickSave(driver,etest, false);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);

			n = startingUsecase;

			for(String id : ids)
			{
				Boolean result = Websites.getStatusFieldEditButton(Websites.getFieldEditButton(driver,id));

				if(result == add)
				{
					etest.log(Status.INFO,usecase+" - "+id+" is checked");
					TestInit.result.put("EC"+(n++),true);
				}
				else
				{
					etest.log(Status.FAIL,usecase+" - "+id+" is failed");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFields","Error");
				}
			}

			WebsitesTab.closeEmbedConfig(driver,etest);

			WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

			n = startingUsecase+3;

			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				for(String field : fields)
				{
					Boolean result = VisitorWindow.checkFields(visDriver,field);

					if(result == add)
					{
						etest.log(Status.INFO,usecase+" - "+field+" is checked in visitor site");
						TestInit.result.put("EC"+(n++),true);
					}
					else
					{
						etest.log(Status.FAIL,usecase+" - "+field+" is failed in visitor site");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFields","Error");
					}
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFields","Error",e);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFields","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkFieldsMandatory(WebDriver driver,Boolean add, int startingUsecase,ExtentTest etest) throws Exception
	{
		FluentWait wait = CommonUtil.waitreturner(driver,10,250);

		String embed=TestInit.embed;

		for(int n = 0; n<=5; n++)
		{
			TestInit.result.put("EC"+(startingUsecase+n),false);
		}

		int n = 0;

		String usecase = add?"Add":"Remove";

		String ids[] = {"ISNAME2","ISEMAIL2","ISPHONENO2"};
		String fields[] = {"name","email","phone"};

		String embedcode;

		try
		{
			embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebElement embedhome = CommonUtil.elfinder(driver,"classname","addemhome");

			WebElement editicon = CommonUtil.elementfinder(driver,embedhome,"classname","big-hdrtxt");
	
			CommonUtil.mouseHover(driver,editicon);
			
			//CommonSikuli.findInWholePage(driver,"Edit.png","UI22",etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);

			for(String id : ids)
			{
				Websites.changeStatusFieldEditButton(driver,id,true,etest);
			}

			for(String id : fields)
			{
				Websites.changeStatusMandatoryCheckbox(driver,id,add,etest);
			}
			
			Websites.clickSave(driver,etest, false);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);


			CommonSikuli.findInWholePage(driver,"Name.png","UI16",etest);
			CommonSikuli.findInWholePage(driver,"Email.png","UI17",etest);

			List<WebElement> list = CommonUtil.elfinder(driver,"id","prechat").findElements(By.tagName("em"));
			WebElement phone = CommonUtil.getElementByAttributeValue(list,"prop","ISPHONENO2");
			CommonUtil.inViewPort(phone);
			CommonSikuli.findInWholePage(driver,"Phone.png","UI18",etest);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("previewframe"));
			driver.switchTo().frame("siqiframe");
			WebElement name = driver.findElement(By.id("visname"));
			CommonUtil.mouseHover(driver,name);
			Thread.sleep(1000);
			CommonSikuli.findInWholePage(driver,"Delete.png","UI19",etest);
			driver.switchTo().defaultContent();

			n = startingUsecase;

			for(String id : fields)
			{
				Boolean result = Websites.getStatusMandatoryAlert(driver,"vis"+id);

				if(result == add)
				{
					etest.log(Status.INFO,usecase+" mandatory for "+id+" is checked");
					TestInit.result.put("EC"+(n++),true);
				}
				else
				{
					etest.log(Status.FAIL,usecase+" mandatory for "+id+" is failed");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFields","Error");
				}
			}

			WebsitesTab.closeEmbedConfig(driver,etest);

			WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

			n = startingUsecase+3;

			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				for(String field : fields)
				{
					Boolean result = VisitorWindow.checkMandatoryFields(visDriver,field);

					if(result == add)
					{
						etest.log(Status.INFO,usecase+" mandatory for "+field+" is checked in visitor site");
						TestInit.result.put("EC"+(n++),true);
					}
					else
					{
						etest.log(Status.FAIL,usecase+" mandatory for "+field+" is failed in visitor site");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFields","Error");
					}
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFields","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static boolean checkFieldsPostChat(WebDriver driver, Boolean fdb, Boolean rating,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

		try
		{
			String usecase1 = fdb?"Enable":"Disable";
			String usecase2 = rating?"Enable":"Disable";
			
			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);

			Websites.clickPostChatFields(driver,etest);
            
            WebsitesTab.clickChatWindAppearance(driver);

			Websites.setStatusOfToggle(driver,"ISFEEDBACK2",fdb,etest);
			Websites.setStatusOfToggle(driver,"ISRATING2",rating,etest);
            
            Websites.checkChatWinAppearancePostChat(driver,fdb,rating);

			Websites.clickSave(driver,etest);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);

			Websites.clickPostChatFields(driver,etest);

			CommonSikuli.findInWholePage(driver,"Feedback.png","UI20",etest);
			CommonSikuli.findInWholePage(driver,"Star.png","UI21",etest);

			WebElement e1 = CommonUtil.elfinder(driver,"id","ISFEEDBACK2");

			Boolean current = Websites.getStatusOfToggle(driver,e1);

			if(current == fdb)
			{
				etest.log(Status.INFO,usecase1+" - Feedback is checked");
			}
			else
			{
				etest.log(Status.FAIL,usecase1+" - Feedback is failed");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error");
			}

			e1 = CommonUtil.elfinder(driver,"id","ISRATING2");

			current = Websites.getStatusOfToggle(driver,e1);

			if(current == rating)
			{
				etest.log(Status.INFO,usecase1+" - Rating is checked");
			}
			else
			{
				etest.log(Status.FAIL,usecase1+" - Rating is failed");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error");
			}

			WebsitesTab.closeEmbedConfig(driver,etest);

			WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

			String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				Long time = new Long(System.currentTimeMillis());

				VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321","Q"+time,etest);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error",e);
			}

			ChatWindow.acceptChat(driver,etest);
			Thread.sleep(1000);
			ChatWindow.endAndCloseChat(driver);

			ChatWindow.closeAllChats(driver);

			etest.log(Status.INFO,"<b>After ending chat</b>");
			TakeScreenshot.infoScreenshot(driver,etest);

			try
			{
				if(fdb && rating)
				{
					VisitorWindow.checkChatEndedInTheme(visDriver);
					etest.log(Status.INFO,usecase1+" - Feedback,"+usecase2+" - Rating is checked in visitor site");
					return true;
				}
				else if(!fdb && rating)
				{
					VisitorWindow.enterFeedbackInTheme(visDriver,null,"3",true,null);

					etest.log(Status.INFO,usecase2+" - Rating is checked in visitor site");

					VisitorWindow.switchToChatWidget(visDriver);
					
					String content = CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML");

					if(!content.contains("fdbkarea"))
					{
						etest.log(Status.INFO,usecase1+" - Feedback is checked in visitor site");
						return true;
					}
					else
					{
						etest.log(Status.FAIL,usecase1+" - Feedback is failed in visitor site");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error");
					}
				}
				else if(fdb && !rating)
				{
					VisitorWindow.enterFeedbackInTheme(visDriver,"Feedback",null,true,null);

					etest.log(Status.INFO,usecase1+" - Feedback is checked in visitor site");
					
					VisitorWindow.switchToChatWidget(visDriver);

					String content = CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML");

					if(!content.contains("rating"))
					{
						etest.log(Status.INFO,usecase2+" - Rating is checked in visitor site");
						return true;
					}
					else
					{
						etest.log(Status.FAIL,usecase2+" - Rating is failed in visitor site");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error");
					}
				}
				else
				{
					int result = 0;

					VisitorWindow.continueChat(visDriver, false);

					VisitorWindow.switchToChatWidget(visDriver);
					
					String content = CommonUtil.elfinder(visDriver,"tagname","body").getAttribute("innerHTML");

					if(!content.contains("fdbkarea"))
					{
						result++;
						etest.log(Status.INFO,usecase1+" - Feedback is checked in visitor site");
					}
					else
					{
						etest.log(Status.FAIL,usecase1+" - Feedback is failed in visitor site");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error");
					}
					if(!content.contains("rating"))
					{
						result++;
						etest.log(Status.INFO,usecase2+" - Rating is checked in visitor site");
					}
					else
					{
						etest.log(Status.FAIL,usecase2+" - Rating is failed in visitor site");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error");
					}
					if(result == 2)
					{
						return true;
					}
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error",e);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckFieldsPostChat","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}

		return false;
	}

	public static void checkPosition(WebDriver driver, String position, String value, String usecase,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

		TestInit.result.put(usecase,false);

		try
		{
			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickWidget(driver,etest);

			WebsitesTab.clickApperanceInWidget(driver,etest);

			Websites.selectPosition(driver,position,etest);

			Websites.clickSave(driver, etest);

			WebsitesTab.closeEmbedConfig(driver, etest);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickWidget(driver,etest);

			WebsitesTab.clickApperanceInWidget(driver,etest);

			String current = Websites.getSelectedPosition(driver);

			if((position).equals(current))
			{
				etest.log(Status.INFO,position+" - is checked");
				WebsitesTab.closeEmbedConfig(driver, etest);
				TestInit.result.put(usecase,true);
			}
			else
			{
				etest.log(Status.FAIL,position+" - is failed."+current+"-- is present");
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPosition","Error");
				WebsitesTab.closeEmbedConfig(driver, etest);
				return;
			}

			WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

			String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

			try
			{
				VisitorWindow.createPage(visDriver,embedcode);

				String classname = VisitorWindow.getPosition(visDriver);

				String expected = "siq_"+value;

				if(classname.contains(expected))
				{
					etest.log(Status.INFO,position+" - is checked in visitor site");
				}
				else
				{
					etest.log(Status.INFO,position+" - is failed in visitor site.Actual:"+classname+"--");
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPosition","Error");
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckPosition","Error",e);
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckPosition","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}
	}

	public static void checkOptions(WebDriver driver, Boolean presence, int usecase, int usecase2,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

        for(int i = usecase;i<=(usecase+4);i++)
        {
            TestInit.result.put("EC"+i,false);
        }
        for(int i = usecase2;i<=(usecase2+4);i++)
        {
            TestInit.result.put("EC"+i,false);
        }
        try
        {
            final String useCaseName = presence?"enable":"disable";
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebsitesTab.clickConfigurations(driver,etest);
            
            Websites.clickShowAll(driver,etest);
            
            String ids[] = {"ISPRINT2","ISSENDMAILTRANSCRIPT2","ISFILESHARING2","ISMUTE2","ISSCREENSHARE2","SHOWSMILEY2"};
            
            for(String id : ids)
            {
                Websites.setStatusOfToggle(driver,id,!presence,etest);
                Websites.setStatusOfToggle(driver,id,presence,etest);
            }
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebsitesTab.clickConfigurations(driver,etest);
            
            Websites.clickShowAll(driver,etest);
            
            int count = usecase;
            
            for(String id : ids)
            {
                WebElement e = CommonUtil.elfinder(driver,"id",id);
                
                Boolean current = Websites.getStatusOfToggle(driver,e);
                
                if(current == presence)
                {
                    etest.log(Status.INFO,id+"- "+useCaseName+" is checked");
                    TestInit.result.put("EC"+count,true);
                }
                else
                {
                    etest.log(Status.FAIL,id+"- "+useCaseName+" is failed");
                    TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckOptions","Error");
                }
                
                count++;
            }
            
            WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);

            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                Long t = new Long(System.currentTimeMillis());
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckOptions","Error",e);
            }
            
            ChatWindow.acceptChat(driver, etest);
            
            Boolean res = false;
            
            try
            {
                if(presence)
                {
                    VisitorWindow.checkOptions(visDriver);
                }
                else
                {
                    VisitorWindow.checkOptionsNotPresent(visDriver);
                }
                
                res = true;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckOptions","Error",e);
            }
            
            if(res)
            {
                for(int i = usecase2;i<=(usecase2+4);i++)
                {
                    TestInit.result.put("EC"+i,true);
                }
            }
            
            ChatWindow.endAndCloseChat(driver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckOptions","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
	}
    
    public static Boolean checkOptions(WebDriver driver, String option, String value,ExtentTest etest) throws Exception
    {
    	String embed=TestInit.embed;

        try
        {
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebsitesTab.clickConfigurations(driver,etest);
            
            CommonSikuli.findInWholePage(driver,"Wait.png","UI34",etest);
			CommonSikuli.findInWholePage(driver,"Language.png","UI35",etest);
			CommonSikuli.findInWholePage(driver,"Dept.png","UI36",etest);
            Websites.clickShowAll(driver,etest);
            CommonSikuli.findInWholePage(driver,"Print.png","UI37",etest);

			WebElement chattranscript = CommonUtil.getElement(driver,By.id("ISSENDMAILTRANSCRIPT2"));
			CommonUtil.inViewPort(chattranscript);
			CommonSikuli.findInWholePage(driver,"Chattranscript.png","UI38",etest);

			WebElement fileshare = CommonUtil.getElement(driver,By.id("ISFILESHARING2"));
			CommonUtil.inViewPort(fileshare);
			CommonSikuli.findInWholePage(driver,"Fileshare.png","UI39",etest);

			WebElement mute = CommonUtil.getElement(driver,By.id("ISMUTE2"));
			CommonUtil.inViewPort(mute);
			CommonSikuli.findInWholePage(driver,"Mute.png","UI40",etest);

			WebElement screenshare = CommonUtil.getElement(driver,By.id("ISSCREENSHARE2"));
			CommonUtil.inViewPort(screenshare);
			CommonSikuli.findInWholePage(driver,"Screenshare.png","UI41",etest);

			// WebElement bot = CommonUtil.getElement(driver,By.id("emconfig_bot"));
			// CommonUtil.inViewPort(bot);
			// CommonSikuli.findInWholePage(driver,"Bot.png","UI42",etest);

			WebElement previouschat = CommonUtil.getElement(driver,By.id("ISCOVERSATION2"));
			CommonUtil.inViewPort(previouschat);
			CommonSikuli.findInWholePage(driver,"Previouschat.png","UI43",etest);

			WebElement emoji = CommonUtil.getElement(driver,By.id("SHOWSMILEY2"));
			CommonUtil.inViewPort(emoji);
			CommonSikuli.findInWholePage(driver,"Emoji.png","UI44",etest);

            String ids[] = {"ISPRINT2","ISSENDMAILTRANSCRIPT2","ISFILESHARING2","ISMUTE2","ISSCREENSHARE2"};
            
            for(String id : ids)
            {
                if(option.equals(id)){
                    Websites.setStatusOfToggle(driver,id,true,etest);
                }
                else{
                    Websites.setStatusOfToggle(driver,id,false,etest);
                }
            }
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebsitesTab.clickConfigurations(driver,etest);
            
            Websites.clickShowAll(driver,etest);
            
            for(String id : ids)
            {
                WebElement e = CommonUtil.elfinder(driver,"id",id);
                
                Boolean current = Websites.getStatusOfToggle(driver,e);
                
                if(option.equals(id) != current)
                {
                    etest.log(Status.FAIL,"Enable - "+option+" only is failed");
                    TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckOptions","Error");
                }
            }
            
            WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                Long t = new Long(System.currentTimeMillis());
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckOptions","Error",e);
            }
            
            ChatWindow.acceptChat(driver, etest);
            
            Boolean res = false;
            try
            {
                String classname = null;
                
                for(int i = 1;i<=5;i++)
                {
                    classname = VisitorWindow.getOptionClassname(visDriver);

                    if(option.equals("ISFILESHARING2"))
                    {
                    	VisitorWindow.switchToChatWidget(visDriver);
                    	if(CommonWait.isDisplayed(visDriver,By.xpath(ResourceManager.getRealValue("Theme.attach"))))
                    	{
                    		etest.log(Status.INFO,"Enable - "+option+" only is checked");
		                    res = true;
		                    visDriver.switchTo().defaultContent();
		                    break;
                    	}
                    }
                    else if(classname.equals(value))
                    {
                        etest.log(Status.INFO,"Enable - "+option+" only is checked");
                        res = true;
                        break;
                    }
                    
                    Thread.sleep(1000);
                }
                visDriver.switchTo().defaultContent();
                
                if(!res)
                {
                    etest.log(Status.INFO,"Enable - "+option+" only is failed.Actual:"+classname+"<>");
                    TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckOptions","Error");
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckOptions","Error",e);
            }
            
            ChatWindow.endAndCloseChat(driver);
            
            return res;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckOptions","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
        
        return false;
    }
    
    public static Boolean checkDp(WebDriver driver, Boolean clogo, Boolean agentDp,ExtentTest etest) throws Exception
    {
    	String embed=TestInit.embed;

        try
        {
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            Websites.setStatusOfToggle(driver,"CLOGO2",clogo,etest);

            Websites.setStatusOfToggle(driver,"ICPHOTO2",agentDp,etest);
            
            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            Boolean c1 = Websites.getStatusOfToggle(driver,CommonUtil.elfinder(driver,"id","CLOGO2"));
            Boolean c2 = Websites.getStatusOfToggle(driver,CommonUtil.elfinder(driver,"id","ICPHOTO2"));
            
            if(c1 != clogo)
            {
                etest.log(Status.FAIL,"Mismatch company logo toggle");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDp","Error");
            }
            
            if(c2 != agentDp)
            {
                etest.log(Status.FAIL,"Mismatch agent dp toggle");
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDp","Error");
            }
            
            if(c1 != clogo || c2 != agentDp)
            {
                return false;
            }
            else
            {
                WebsitesTab.closeEmbedConfig(driver,etest);
            }
            
            Thread.sleep(2000);
            
            WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
            
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

            String s1 = null, s2 = null;
            Boolean s5 = null;
            
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                WebElement e1 = VisitorWindow.getCompanylogo(visDriver);
                
                s1 = e1.getAttribute("src");
                s2 = e1.getAttribute("class");
                s5 = e1.isDisplayed();
                
                Long t = new Long(System.currentTimeMillis());
                
                VisitorWindow.initiateChatVisTheme(visDriver,"V"+t,"email@"+t+".com","54321","Q"+t,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckDp","Error",e);
            }
            
            ChatWindow.acceptChat(driver, etest);
            
            String s3 = null, s4 = null;
            Boolean s6 = null;
            
            try
            {
                VisitorWindow.sentMessageInTheme(visDriver,"hey!!!");
                
                WebElement e1 = VisitorWindow.getCompanylogo(visDriver);
                
                s3 = e1.getAttribute("src");
                s4 = e1.getAttribute("class");
                s6 = e1.isDisplayed();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckDp","Error",e);
            }
            
            Thread.sleep(1000);
            
            ChatWindow.endAndCloseChat(driver);
            
            etest.log(Status.INFO,"CLOGO:"+clogo);
            etest.log(Status.INFO,"AgentDp:"+agentDp);
            
            etest.log(Status.INFO,"Before:src:"+s1+"<>class:"+s2+"<>presence:"+s5+"<>");
            etest.log(Status.INFO,"After:src:"+s3+"<>class:"+s4+"<>presence:"+s6+"<>");

            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckDp","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
        
        return false;
    }
    
    public static Boolean checkChatWidgetColours(WebDriver driver, String colour,ExtentTest etest) throws Exception
    {
        try
        {
        	String embed=TestInit.embed;

            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            WebsitesTab.clickChatWindAppearance(driver);
            
            if(colour.equals(TestInit.DEFAULT_COLOR))
            {
                Websites.clickChatWidgetDefaultColour(driver,true,etest);
            }
            else
            {
                Websites.clickChatWidgetDefaultColour(driver,false,etest);
                
                Websites.clickChatWidgetColour(driver,colour,etest);
            }
            
            Websites.checkChatWinAppearanceColour(driver,colour);
            
            Websites.clickSave(driver,etest);
         
            WebElement clogo = driver.findElement(By.id("CLOGO2"));
			CommonUtil.inViewPort(clogo);
			String cname = clogo.getAttribute("class");
			if(cname.contains("set_on"))
			{
			driver.findElement(By.id("CLOGO2")).click();
			Websites.clickSave(driver,etest);
			}
            else
			{
			System.out.println("Already company logo Disabled.");
			}
			//--changes end
			
    	    //CommonSikuli.findInWholePage(driver,CommonSikuli.getImageNameBasedColour(colour),etest);
		    CommonSikuli.findInWholePage(driver,CommonSikuli.getImageNameInpreviewwindowcolour(colour),etest);


            WebsitesTab.closeEmbedConfig(driver,etest);
            
            Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickChatWindow(driver,etest);
            
            if(colour.equals(TestInit.DEFAULT_COLOR))
            {
                String s = Websites.getChatWidgetDefaultColourStatus(driver);
                
                if(!s.equals("true"))
                {
                    etest.log(Status.FAIL,"<>"+s+"<>");
                    TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckChatWidgetColours","Error");
                }
            }
            else
            {
                String s = Websites.getChatWidgetColour(driver);
                
                if(!s.equals(colour))
                {
                    etest.log(Status.FAIL,"<>"+s+"<>"+colour+"<>");
                    TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckChatWidgetColours","Error");
                }
            }
            
            WebsitesTab.closeEmbedConfig(driver,etest);
            
            String expected = " header:before, section.oanim header:before {border-color: "+colour+" transparent transparent transparent; }.nologo .cmplogo span { background-color: "+colour+"; }.wincustom_bg,.siqc_prochtcls:before {background-color: "+colour+" !important;}.wincustom_clr, .sqico-chat2:before{ color:"+colour+" !important; }";
            
            WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
            String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
            
            try
            {
                VisitorWindow.createPage(visDriver,embedcode);
                
                VisitorWindow.clickChatButton(visDriver);
                VisitorWindow.switchToChatWidget(visDriver);
                
                String style = CommonUtil.elfinder(visDriver,"tagname","style").getAttribute("innerHTML");
       			
       			if (CommonSikuli.findInWholePage(visDriver,CommonSikuli.getImageNameBasedColour(colour),etest) == true)
			    {
				    etest.log(Status.PASS, "Chat widget colour change is checked in visitor side");
				    return true;
			    }
			    else
			    {
			        etest.log(Status.FAIL,"Chat widget colour change is checked in visitor side Failed");
			        return false;
			    }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckChatWidgetColours","Error",e);
                return false;
            }

        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckChatWidgetColours","Error",e);
            Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
        }
        
        return false;
    }

    public static void enablePhoneNumberForEmbed(WebDriver driver,ExtentTest etest,String embed) throws Exception
    {
		Tab.navToEmbedTab(driver);

		WebEmbed.clickWebEmbed(driver,embed,etest);

		WebsitesTab.clickLiveChat(driver,etest);

		WebsitesTab.clickChatWindow(driver,etest);

		WebsitesTab.clickFields(driver,etest);

		Websites.changeStatusFieldEditButton(driver,"ISPHONENO2",true,etest);
	
		Websites.clickSave(driver,etest, false);

		WebsitesTab.closeEmbedConfig(driver,etest);

    }

    public static boolean checkUserUploadImageForChatWidget(WebDriver driver,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

		int failcount = 0;
		try
		{
			Tab.navToEmbedTab(driver);
            
            WebEmbed.clickWebEmbed(driver,embed,etest);
            
            WebsitesTab.clickLiveChat(driver,etest);
            
            WebsitesTab.clickWidget(driver,etest);
            
            WebsitesTab.clickFloatWidget(driver,etest);

			// CommonWait.waitTillDisplayed(driver,By.id("emleftnav"));
			// CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(driver,By.id("emleftnav"),By.tagName("div"),"tabname","widget"));
			// CommonWait.waitTillDisplayed(driver,By.id("emleftnav"),By.tagName("span"));

			WebsitesTab.clickWidget(driver,etest);

			// WebElement widgetTab = CommonUtil.getElementByAttributeValue(CommonUtil.getElement(driver,By.id("emleftnav")).findElements(By.className("sub_ul")),"widgetname","float");
			// CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(widgetTab,By.tagName("span"),"subtab","apperance"));

			WebsitesTab.clickApperanceInWidget(driver,etest);
			
			Websites.setStatusOfToggle(driver,"choosestickers",true,etest);

			CommonWait.waitTillDisplayed(driver,By.id("userstikermain"));

			WebElement onlineUploadElement = CommonUtil.getElementByAttributeValue(driver,By.id("userstikermain"),By.tagName("div"),"prop","online");
			WebElement offlineUploadElement = CommonUtil.getElementByAttributeValue(driver,By.id("userstikermain"),By.tagName("div"),"prop","offline");
			
			FileUpload.uploadFile(CommonUtil.getElement(onlineUploadElement,By.id("fsticker-file")),FileType.SMALL_IMAGE);
			CommonUtil.sleep(1000);
			CommonSikuli.findInWholePage(driver,"UI377.png","UI377",etest);

			if(CommonUtil.getElement(driver,By.id("widgetstatus")).getText().contains("Online"))
			{
				CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("widgetstatus_div")));
				CommonWait.waitTillDisplayed(driver,By.id("widgetstatus0"));
				if(CommonWait.isDisplayed(driver,By.id("widgetstatus0")))
				{
					etest.log(Status.PASS,"Dropdown list box displayed on clicking ONLINE in preview screen");
					CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(driver,By.id("widgetstatus0"),By.tagName("li"),"val","offline"));
					CommonSikuli.findInWholePage(driver,"UI378.png","UI378",etest);
				}
				else
				{
					etest.log(Status.FAIL,"Dropdown list box was not displayed on clicking ONLINE in preview screen");
					TakeScreenshot.screenshot(driver,etest);
					failcount++;
				}
			}
			else if(CommonUtil.getElement(driver,By.id("widgetstatus")).getText().contains("Offline"))
			{
				CommonSikuli.findInWholePage(driver,"UI378.png","UI378",etest);
			}

			FileUpload.uploadFile(CommonUtil.getElement(offlineUploadElement,By.id("fsticker-file")),FileType.SMALL_IMAGE2);
			CommonUtil.sleep(1000);
			CommonSikuli.findInWholePage(driver,"UI379.png","UI379",etest);

			CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,By.id("widgetstatus_div")));
			CommonWait.waitTillDisplayed(driver,By.id("widgetstatus0"));
			if(CommonWait.isDisplayed(driver,By.id("widgetstatus0")))
			{
				etest.log(Status.PASS,"Dropdown list box displayed on clicking ONLINE in preview screen");
				CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(driver,By.id("widgetstatus0"),By.tagName("li"),"val","online"));
				CommonSikuli.findInWholePage(driver,"UI380.png","UI380",etest);
			}
			else
			{
				etest.log(Status.FAIL,"Dropdown list box was not displayed on clicking ONLINE in preview screen");
				TakeScreenshot.screenshot(driver,etest);
				failcount++;
			}

			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(driver,SAVE_CANCEL_DIV,By.tagName("span"),"documentclick","cancelEmbedConfig"));
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"checkUserChatWidget","Exception","Exception",e);
		}
		try
		{
			WebsitesTab.closeEmbedConfig(driver,etest);
		}
		catch(Exception e)
		{

		}
		return CommonUtil.returnResult(failcount);
	}

	public static boolean checkRatingAfterCancel(WebDriver driver,ExtentTest etest)
	{
		String embed=TestInit.embed;

		int result = 0;
		try
		{
			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickWidget(driver,etest);

			WebsitesTab.clickFloatWidget(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickFields(driver,etest);

			Websites.clickPostChatFields(driver,etest);

			Websites.setStatusOfToggle(driver,"ISRATING2",false,etest);

			CommonWait.waitTillDisplayed(driver,SAVE_CANCEL_DIV);

			CommonUtil.clickWebElement(driver,CommonUtil.getElementByAttributeValue(driver,SAVE_CANCEL_DIV,By.tagName("span"),"documentclick","cancelEmbedConfig"));
			TakeScreenshot.infoScreenshot(driver,etest);

			Websites.clickPostChatFields(driver,etest);
			TakeScreenshot.infoScreenshot(driver,etest);

            Websites.checkChatWinAppearancePostChat(driver,true,true);
            TakeScreenshot.infoScreenshot(driver,etest);

            etest.log(Status.PASS,"Rating was found after toggling but not updating (click cancel)");
            WebsitesTab.closeEmbedConfig(driver,etest);
            return true;

		}
		catch(Exception e)
		{
			etest.log(Status.FAIL,"Rating was not found after toggling but not updating (click cancel)");
			TakeScreenshot.screenshot(driver,etest);
			return false;
		}
	}
}
