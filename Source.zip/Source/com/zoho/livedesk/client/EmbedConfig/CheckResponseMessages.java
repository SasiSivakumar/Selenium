//$Id$
package com.zoho.livedesk.client.EmbedConfig;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;

public class CheckResponseMessages
{
    public static void checkResponseMessages(WebDriver driver,ExtentTest etest) throws Exception
	{
		String embed=TestInit.embed;

		try
		{
			CommonUtil.refreshPage(driver);
		}
		catch(Exception e)
		{
			CommonUtil.doNothing();
		}
		
		for(int n = 58; n<=87; n++)
		{
			TestInit.result.put("EC"+n,false);
		}

		String t = ""+System.currentTimeMillis(); 
		
		try
		{
			String div[] = {"Greeting Messages","Thank you Message","Waiting Message"
				,"Busy Message","Busy Response Message","Engaged Message","Engaged Response Message"
				,"Feedback Message"};
			String values[] = {t+"GreetingMessage",t+"ThankyouMessage",t+"WaitingMessage"
				,t+"BusyMessage",t+"BusyResponseMessage",t+"EngagedMessage",t+"EngagedResponseMessage"
				,t+"FeedbackMessage"};
			
			String div1[] = {"Offline Response Message"};
			String values1[] = {t+"OfflineResponseMessage"};

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickResponsemessage(driver,etest);

			Websites.clickShowAll(driver,etest);

			for(int i = 0; i<div.length;i++)
			{
				Websites.editResponseMessages(driver,div[i],values[i],etest);
			}


            for(int i = 1; i <= 5;i++)
			{
            	Websites.editRatingMessages(driver,"siqrating-"+i,t+"Rating-"+i,etest);
            }

            Websites.clickOfflineResponse(driver,etest);

			Thread.sleep(1000);

			for(int i = 0; i<div1.length;i++)
			{
				Websites.editResponseMessages(driver,div1[i],values1[i],etest);
			}

            Websites.clickSave(driver,etest);

			WebsitesTab.closeEmbedConfig(driver,etest);

			Thread.sleep(5000);

			Tab.navToEmbedTab(driver);

			WebEmbed.clickWebEmbed(driver,embed,etest);

			WebsitesTab.clickLiveChat(driver,etest);

			WebsitesTab.clickChatWindow(driver,etest);

			WebsitesTab.clickResponsemessage(driver,etest);

			Websites.clickShowAll(driver,etest);

			int n = 58;

			for(int i = 0; i<div.length;i++)
			{
				String actual = Websites.getValueFromResponseMessages(driver,div[i]);

				if(actual.equals(values[i]))
				{
					etest.log(Status.INFO,div[i]+" - checked");
                    TestInit.result.put("EC"+(n++),true);
				} 
				else
				{
					etest.log(Status.FAIL,div[i]+" - failed.Expected:"+values[i]+"--");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
				}
			}

            n = 68;

			for(int i = 1; i<=5;i++)
			{
				String actual = Websites.getValueFromRatingMessages(driver,"siqrating-"+i);

				if(actual.equals(t+"Rating-"+i))
				{
					etest.log(Status.INFO,"Rating - "+i+" - checked");
					TestInit.result.put("EC"+(n++),true);
				} 
				else
				{
					etest.log(Status.FAIL,"Rating - "+i+" - failed.Expected:"+t+"Rating-"+i+"--");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
				}
			}
            
            Websites.clickOfflineResponse(driver,etest);

			Thread.sleep(1000);

			n = 66;

			for(int i = 0; i<div1.length;i++)
			{
				String actual = Websites.getValueFromResponseMessages(driver,div1[i]);

				if(actual.equals(values1[i]))
				{
					etest.log(Status.INFO,div1[i]+" - checked");
					TestInit.result.put("EC"+(n++),true);
				} 
				else
				{
					etest.log(Status.FAIL,div1[i]+" - failed.Expected:"+values1[i]+"--");
					TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
				}
			}

			TestInit.result.put("EC"+(n++),true); // Offline messsage

            Websites.clickSave(driver,etest);
            
            WebsitesTab.closeEmbedConfig(driver,etest);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}
        
        try
		{
			boolean check = ((boolean)TestInit.result.get("EC58")) && ((boolean)TestInit.result.get("EC59")) && ((boolean)TestInit.result.get("EC60"));
			
			if(check)
			{
				WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
				String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
				
				try
				{
                    VisitorWindow.createPage(visDriver,embedcode);
                    
                    Long time = new Long(System.currentTimeMillis());

					VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321","Q"+time,etest);

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"WaitingMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch waiting message.Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"WaitingMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Waiting message is checked in visitor site");
						TestInit.result.put("EC75",true);
					}
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
				}

				ChatWindow.acceptChat(driver,etest);

				try
				{
					String username=ExecuteStatements.getUserName(driver);

					if(VisitorWindow.checkAgentMessageInChatWindow(visDriver,username,t+"GreetingMessage",1))
					{
						etest.log(Status.INFO,"Greeting message is checked in visitor site");
						TestInit.result.put("EC73",true);
					}
					else
					{
						etest.log(Status.FAIL,"Mismatch greeting message.Expected:"+t+"GreetingMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}

					VisitorWindow.endChatVisitor(visDriver, false);

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"ThankyouMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch thank you message.Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"ThankyouMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Waiting message is checked in visitor site");
						TestInit.result.put("EC74",true);
					}

					VisitorWindow.infoInvisible(visDriver);

					VisitorWindow.enterFeedbackInTheme(visDriver,"Feedback",null,true,null);

					FluentWait wait = CommonUtil.waitreturner(visDriver,10,250);

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ResourceManager.getRealValue("Theme.feedback.submit.click"))));

					Thread.sleep(500);

					CommonUtil.elfinder(visDriver,"xpath",ResourceManager.getRealValue("Theme.feedback.submit.click")).click();

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"FeedbackMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch Feedback message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"FeedbackMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Feedback message is checked in visitor site");
						TestInit.result.put("EC80",true);
					}
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
				}
			}

			check = ((boolean)TestInit.result.get("EC68")) || ((boolean)TestInit.result.get("EC69")) || ((boolean)TestInit.result.get("EC70")) || ((boolean)TestInit.result.get("EC71")) || ((boolean)TestInit.result.get("EC72"));
			
			int count = 87;
			
			if(check)
			{
				for(int i = 1 ; i<=5;i++)
				{
					WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
					String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

					try
					{
						VisitorWindow.createPage(visDriver,embedcode);
                        
                        Long time = new Long(System.currentTimeMillis());
						
                        VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321","Q"+time,etest);
                    }
					catch(Exception e)
					{
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
					}

					ChatWindow.acceptChat(driver,etest);

					try
					{
						VisitorWindow.endChatVisitor(visDriver);

						VisitorWindow.infoInvisible(visDriver);

						VisitorWindow.enterFeedbackInTheme(visDriver,null,""+i,true,etest);

						String star = "";

						switch(i)
		                {
		                    case 1: star = "5";break;
		                    case 2: star = "4";break;
		                    case 3: star = "3";break;
		                    case 4: star = "2";break;
		                    case 5: star = "1";break;
		                }

						if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"Rating-"+star)==false)
						{
							etest.log(Status.FAIL,"Mismatch Rating message for "+star+".Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"Rating-"+star+"--");
							TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
						}
						else
						{
							etest.log(Status.INFO,"Rating message for "+star+" is checked in visitor site");
							TestInit.result.put("EC"+(count-i+1),true);
						}

						VisitorWindow.infoInvisible(visDriver);
					}
					catch(Exception e)
					{
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
					}
				}
			}

			check = ((boolean)TestInit.result.get("EC61")) && ((boolean)TestInit.result.get("EC62"));
			
			if(check)
			{
				WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
				String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);

				try
				{
					VisitorWindow.createPage(visDriver,embedcode);

					Long time = new Long(System.currentTimeMillis());

					VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321","Q"+time,etest);

					VisitorWindow.waitTillChatisMissedInTheme(visDriver);
				
					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"BusyMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch busy message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"BusyMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Busy message is checked in visitor site");
						TestInit.result.put("EC76",true);
					}

					// VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,null,"Hi",false,etest,true);
		            VisitorWindow.submitResponseAfterMissingChatWithAgent(visDriver,"Hi");

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"BusyResponseMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch busy response message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"BusyResponseMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Busy response message is checked in visitor site");
						TestInit.result.put("EC77",true);
					}

					VisitorWindow.infoInvisible(visDriver);
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
				}
			}

			check = ((boolean)TestInit.result.get("EC63")) && ((boolean)TestInit.result.get("EC64"));

			if(check)
			{
				ChatWindow.closeAllChats(driver);

				String dept=ExecuteStatements.getSystemGeneratedDepartment(driver);

				String username=ExecuteStatements.getUserName(driver);

                Department.addDept(driver,"D"+t,"depttype_publi",username,etest);
                
                Thread.sleep(2000);
                
                PortalConfig.changeValues(driver,"maxconcurrentchat","1",etest);
                
                WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
				WebDriver visDriver2 = TestInit.visitor_driver_manager.getDriver(driver,false);

				String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
	
				try
				{
					VisitorWindow.createPage(visDriver,embedcode);
					VisitorWindow.createPage(visDriver2,embedcode);

					Long time = new Long(System.currentTimeMillis());

					VisitorWindow.initiateChatVisTheme(visDriver2,"V"+time,"email@"+time+".com","54321",dept,"Q"+time,etest);
					ChatWindow.acceptChat(driver,etest);
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
				}

				try
				{
					Long time = new Long(System.currentTimeMillis());

					VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321",dept,"Q"+t,false,etest,true);

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"EngagedMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch engaged message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"EngagedMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Engaged message is checked in visitor site");
						TestInit.result.put("EC78",true);
					}

					VisitorWindow.infoInvisible(visDriver);

					VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321",dept,"Q"+t,false,etest,true);

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"EngagedResponseMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch engaged response message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"EngagedResponseMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Engaged response message is checked in visitor site");
						TestInit.result.put("EC79",true);
					}
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
				}

				ChatWindow.endAndCloseChat(driver);
			}

			check = ((boolean)TestInit.result.get("EC66")) && ((boolean)TestInit.result.get("EC67"));

			com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

			Thread.sleep(4000);

			if(check)
			{
				WebDriver visDriver = TestInit.visitor_driver_manager.getDriver(driver);
				String embedcode=ExecuteStatements.getWidgetCodeFromEmbedName(driver,embed);
				String dept=ExecuteStatements.getSystemGeneratedDepartment(driver);

				try
				{
					VisitorWindow.createPage(visDriver,embedcode);

					Long time = new Long(System.currentTimeMillis());

					TestInit.result.put("EC81",true);

					// VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,dept,null,false,etest,false);

					// if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"OfflineMessage")==false)
					// {
					// 	etest.log(Status.FAIL,"Mismatch offline message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"OfflineMessage--");
					// 	TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					// }
					// else
					// {
					// 	etest.log(Status.INFO,"Offline message is checked in visitor site");
					// 	TestInit.result.put("EC81",true);
					// }

					// VisitorWindow.infoInvisible(visDriver);

					VisitorWindow.initiateChatVisTheme(visDriver,"V"+time,"email@"+time+".com","54321",dept,"Q"+time,false,etest,true);

					if(VisitorWindow.waitAndCheckTillExpectedInfoMessage(visDriver,t+"OfflineResponseMessage")==false)
					{
						etest.log(Status.FAIL,"Mismatch offline response message .Actual:"+VisitorWindow.getInfoBannerMessage(visDriver)+"--Expected:"+t+"OfflineResponseMessage--");
						TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error");
					}
					else
					{
						etest.log(Status.INFO,"Offline response message is checked in visitor site");
						TestInit.result.put("EC82",true);
					}
				}
				catch(Exception e)
				{
					TakeScreenshot.screenshot(visDriver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
				}
			}
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckResponseMessages","Error",e);
			Functions.refreshSiteAndWaitForRSID(driver);Thread.sleep(3000);
		}
		finally
		{
            try
            {
                PortalConfig.changeValues(driver,"maxconcurrentchat","-1",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","ChangePortalConfig","Error",e);
            }
			try
			{
				if(Department.deleteDepartment(driver,"D"+t,null,etest))
				{
					etest.log(Status.INFO,"D"+t+" is deleted");
				}
				else
				{
					etest.log(Status.FAIL,"D"+t+" is not deleted");
				}
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","DeleteDepartment","Error",e);
			}
			try
			{
				com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");Thread.sleep(2000);
			}
			catch(Exception e)
			{
				TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","ChangeStatus","Error",e);
			}
        }
	}
}
