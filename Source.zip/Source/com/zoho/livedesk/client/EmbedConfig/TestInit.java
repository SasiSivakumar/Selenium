//$Id$
package com.zoho.livedesk.client.EmbedConfig;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.CommonUtil;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.common.Distributor;
import com.zoho.livedesk.util.common.DistributedTest;


public class TestInit implements DistributedTest
{
	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
		
	public static ExtentTest etest;

	public static VisitorDriverManager visitor_driver_manager;

	public static String embed;
	public static String value;

    public static final String DEFAULT_COLOR="#0066cc";

	public void startThread(int thread_number) throws Exception
	{
		WebDriver driver = Functions.setUp();

		if(thread_number==0)
		{			
			Functions.login(driver,"embedconfig1");
			ExtentTest etest=null;
			usecase1(driver,etest);
		}

		if(thread_number==1)
		{			
			Functions.login(driver,"embedconfig2");
			ExtentTest etest=null;
			usecase2(driver,etest);
		}

		String portal=ExecuteStatements.getPortal(driver);
		visitor_driver_manager.closeAllDrivers(portal);

		Functions.logout(driver);	
	}

	public static Hashtable usecase()
	{
        value = (""+System.currentTimeMillis()).substring(4, 10);
		embed = "e"+System.currentTimeMillis();

		visitor_driver_manager = new VisitorDriverManager();

		TestInit usecases = new TestInit();

		Distributor distributor = new Distributor(usecases,2);

		distributor.initiate();
      
		visitor_driver_manager.terminateAllDriverSessions();

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}


	public static void usecase1(WebDriver driver,ExtentTest etest)
	{        
        try
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC1"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC1",CheckEC.checkAddEmbed(driver,embed,etest));

			ComplexReportFactory.closeTest(etest);

			CheckEC.enablePhoneNumberForEmbed(driver,etest,embed);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC3"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC3",CheckEC.checkEmbedTab(driver,"visitortracking",etest));

			ComplexReportFactory.closeTest(etest);
			
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC4"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC4",CheckEC.checkEmbedTab(driver,"livechat",etest));

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC5"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC5",CheckEC.checkInstallationTab(driver,etest));

			ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC6"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC6",CheckEC.checkMultiple(driver,false,etest));

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC7"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC7",CheckEC.checkMultiple(driver,true,etest));

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC8"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC8",CheckEC.checkWidgetAppearancePage(driver,etest));

			 ComplexReportFactory.closeTest(etest);

             etest=ComplexReportFactory.getTest("Check Remove Fields");
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 CheckEC.checkFields(driver,false,88,etest);

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest("Check Add Fields");
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 CheckEC.checkFields(driver,true,94,etest);

			 ComplexReportFactory.closeTest(etest);

 			 etest=ComplexReportFactory.getTest("Check Remove Mandatory Fields");
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 CheckEC.checkFieldsMandatory(driver,false,100,etest);

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest("Check Add Mandatory Fields");
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 CheckEC.checkFieldsMandatory(driver,true,103,etest);

			 ComplexReportFactory.closeTest(etest);
           
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC36"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC36",CheckEC.checkChatWidgetColours(driver,"#D066E5",etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC35"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC35",CheckEC.checkChatWidgetColours(driver,"#FFB300",etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC34"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC34",CheckEC.checkChatWidgetColours(driver,DEFAULT_COLOR,etest));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC37"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC37",CheckEC.checkDp(driver,false,false,etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC38"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC38",CheckEC.checkDp(driver,false,true,etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC39"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC39",CheckEC.checkDp(driver,true,false,etest));
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC40"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC40",CheckEC.checkDp(driver,true,true,etest));
            
            ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest("Check user uploaded image for chat widget");
			ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			CheckEC.checkUserUploadImageForChatWidget(driver,etest);

			ComplexReportFactory.closeTest(etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC1243"));
			ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC1243",CheckEC.checkRatingAfterCancel(driver,etest));

			ComplexReportFactory.closeTest(etest);
            
	         etest=ComplexReportFactory.getTest("Check response messages");
	         ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 CheckResponseMessages.checkResponseMessages(driver,etest);

			 ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC2"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC2",CheckEC.deleteEmbed(driver,embed,etest));

			ComplexReportFactory.closeTest(etest);

        }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorUser(s)Tab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckTab","Error",e);
			result.put("EC1", false);
		}

		ComplexReportFactory.closeTest(etest);
	}

	public static void usecase2(WebDriver driver,ExtentTest etest)
	{                
        try
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC1"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
			CheckEC.checkAddEmbed(driver,embed,etest);
			ComplexReportFactory.closeTest(etest);

			CheckEC.enablePhoneNumberForEmbed(driver,etest,embed);

            etest=ComplexReportFactory.getTest("Check Department configuration");
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckEC.checkDepts(driver,etest);
            
            ComplexReportFactory.closeTest(etest);
            
             checkWaitingTimer(driver,etest);

             etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC106"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC106",CheckEC.checkFieldsPostChat(driver,false,false,etest));

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC107"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC107",CheckEC.checkFieldsPostChat(driver,false,true,etest));

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC108"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC108",CheckEC.checkFieldsPostChat(driver,true,false,etest));

			 ComplexReportFactory.closeTest(etest);

			 etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC109"));
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 result.put("EC109",CheckEC.checkFieldsPostChat(driver,true,true,etest));

			 ComplexReportFactory.closeTest(etest);

             checkPosition(driver,etest);

            checkOneOption(driver,221,etest);
            
			 etest=ComplexReportFactory.getTest("Disable all options and check");
             ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			 CheckEC.checkOptions(driver,false,211,216,etest);

			 ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest("Enable all options and check");
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            CheckEC.checkOptions(driver,true,201,206,etest);
            
            ComplexReportFactory.closeTest(etest);
           
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC2"));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
			CheckEC.deleteEmbed(driver,embed,etest);
			ComplexReportFactory.closeTest(etest);
        }
		catch(Exception e)
		{
			etest.log(Status.FATAL,"ErrorUser(s)Tab");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"EmbedConfiguration","CheckTab","Error",e);
			result.put("EC1", false);
		}

		ComplexReportFactory.closeTest(etest);
	}

	public static void checkWaitingTimer(WebDriver driver,ExtentTest etest) throws Exception
	{
		int time[] = {30,45,90,120,60};
		int i = 41;

		for(int s : time)
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC"+i));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			result.put("EC"+i,CheckEC.checkWaitingTimer(driver,s,etest));

			ComplexReportFactory.closeTest(etest);

			i++;
		}
	}

	public static void checkPosition(WebDriver driver,ExtentTest etest) throws Exception
	{
		String[] position = {"top_left","top_right","right_top","right_middle","right_bottom","bottom_left","bottom_right","left_top","left_middle","left_bottom"};
		String[] values = {"tL","tR","tR","rM","bR","bL","bR","tL","lM","bL"};

		int i = 121;
		for(String s : position)
		{
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC"+(i)));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");

			CheckEC.checkPosition(driver,s,values[i-121],"EC"+(i),etest);

			ComplexReportFactory.closeTest(etest);

			i++;
		}
	}
    
    public static void checkOneOption(WebDriver driver, int firstUsecase,ExtentTest etest) throws Exception
    {
        String[] ids = {"ISPRINT2","ISSENDMAILTRANSCRIPT2","ISFILESHARING2","ISMUTE2","ISSCREENSHARE2"};
        String values[] = {"sqico-print","sqico-smailico","sqico-attach","sqico-mute","sqico-share_screen"};
        
        int i = firstUsecase;
        for(String s : ids)
        {
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("EC"+(i)));
            ComplexReportFactory.setValues(etest,"Automation","Embed Configuration");
            
            result.put("EC"+i,CheckEC.checkOptions(driver,s,values[i-firstUsecase],etest));
            
            ComplexReportFactory.closeTest(etest);
            
            i++;
        }
    }
}
