//$Id$
package com.zoho.livedesk.client.JSAPI;

import java.io.IOException;
import java.util.Set;
import java.util.List;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Point;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

public class CommonFunctions
{
    public static WebDriver openApiSite(String ename) throws Exception
    {
        WebDriver driver;
        
        driver = Functions.setUp();
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        driver.get("http://"+Util.serverHostName+"/jsdev.php");
        Thread.sleep(1000);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fname")));
        
        String siteName = Util.setUptracking();
        
        if(siteName.equals("local"))
        {
            siteName = "LocalZoho";
        }
        else if(siteName.equals("pre"))
        {
            siteName = "Pre SalesIQ";
        }
        else if(siteName.equals("idc"))
        {
            siteName = "IDC";
        }
        else
        {
            siteName = "IDC";
        }
        if(ename!=null)
        {
            choosePortal(driver,ename,ConfManager.getJsPortal(),siteName);
        }
        else
        {
            choosePortal(driver,ConfManager.getJsEmbed(),ConfManager.getJsPortal(),siteName);
        }
        
        return driver;
    }
    
    public static void changeStatus(WebDriver driver,String status) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            Thread.sleep(1000);
            
            try
            {
                Thread.sleep(2000);
                Functions.closeBannersAfterLogin(driver);
            }
            catch(Exception e)
            {
                System.out.println("Exception while closing the maintenance banner : "+e);
            }
            
            if(status.equals("available"))
            {
                if(!((CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","hdrstatus").getAttribute("class")).equals("userstatus-1")))
                {
                    CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","hdrprt"),"id","hdrdrpdwntop").click();
                    
                    Thread.sleep(1000);
                    
                    CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","ustatus"),"tagname","a"),"tagname","span").click();
                    
                    Thread.sleep(1000);
                    
                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-1"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                }
            }
            else if(status.equals("busy"))
            {
                if(!((CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","hdrstatus").getAttribute("class")).equals("userstatus-3")))
                {
                    CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","hdrprt"),"id","hdrdrpdwntop").click();
                    
                    Thread.sleep(1000);
                    
                    CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","headerdropdiv"),"id","ustatus"),"tagname","a"),"tagname","span").click();
                    
                    Thread.sleep(1000);
                    
                    wait.until(new Function<WebDriver,Boolean>(){
                        public Boolean apply(WebDriver driver)
                        {
                            if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-3"))
                            {
                                return true;
                            }
                            return false;
                        }
                    });
                }
            }
            
            Thread.sleep(6000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while changing user status in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void choosePortal(WebDriver driver,String ename,String pname,String setup)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            CommonUtil.elfinder(driver,"name","domain").click();
            new Select(driver.findElement(By.xpath(".//select[@name='domain']"))).selectByVisibleText(setup);
            CommonUtil.elfinder(driver,"id","custcode").click();
            CommonUtil.elfinder(driver,"name","edname").click();
            CommonUtil.elfinder(driver,"name","edname").sendKeys(ename);
            CommonUtil.elfinder(driver,"name","portalname").click();
            CommonUtil.elfinder(driver,"name","portalname").sendKeys(pname);
        }
        catch(Exception e)
        {
            System.out.println("Exception while choosing portal in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void initiateChat(WebDriver driver,String vname,String vemail,String vphone,String vques)
    {
        try
        {
            VisitorWindow.initiateChatVis(driver,vname,vemail,vphone,vques,JSApiutil.etest);
        }
        catch(Exception e)
        {
            System.out.println("Exception while initiating chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void acceptChat(WebDriver driver)
    {
        try
        {
            ChatWindow.acceptChat(driver,JSApiutil.etest);
        }
        catch(Exception e)
        {
            System.out.println("Exception while accepting chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void endChat(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            CommonUtil.elfinder(driver,"id","txteditor").sendKeys("Hello there, welcome to testing team ...");
            CommonUtil.elfinder(driver,"id","txteditor").sendKeys(Keys.RETURN);
            
            Thread.sleep(500);
            
            CommonUtil.elfinder(driver,"id","endsession").click();
            
            Thread.sleep(1000);
            
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infodiv")));
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","infodiv"),"linktext",ResourceManager.getRealValue("closewindow")).click();
            
            Thread.sleep(1000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void replyMessages(WebDriver driver,WebDriver ApiDriver)
    {
        try
        {
            CommonUtil.elfinder(driver,"id","txteditor").sendKeys("Hello there, welcome to testing team ...");
        }
        catch(Exception e)
        {
            System.out.println("Exception while replying for chat messages in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void clickMinimize(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            driver.switchTo().defaultContent();
            
            CommonUtil.elfinder(driver,"id","zlscloseimg").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zls-small")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            CommonUtil.elfinder(driver,"id","zls_ctn_wrap").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.className("zls-sptwndw")).getAttribute("style").equals("display: block;"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");
            
            driver.switchTo().frame(chframe);
        }
        catch(Exception e)
        {
            System.out.println("Exception while minimiznig chat window in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void sendFeedbackandRating(WebDriver driver,String rating)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            
            VisitorWindow.switchToChatWidget(driver);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("submitfeedback")));
            CommonUtil.elfinder(driver,"id","submitfeedback").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ratingul")));
            
            WebElement raelmt = CommonUtil.elfinder(driver,"id","ratingul");
            List<WebElement> elmts = raelmt.findElements(By.tagName("li"));
            
            for(WebElement elmt:elmts)
            {
                if(elmt.getAttribute("star").equals(rating))
                {
                    CommonUtil.elementfinder(driver,elmt,"tagname","a").click();
                }
            }
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sprwinact")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtmsg")));
            
            CommonUtil.elfinder(driver,"id","txtmsg").sendKeys("Feedback Positive");
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("btnsavefeedback")));
            CommonUtil.elfinder(driver,"id","btnsavefeedback").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fdbksdiv")));
            
            Thread.sleep(2000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while replying for chat messages in jsapi module : ");
            e.printStackTrace();
        }
    }
    
    public static void ClickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
    }
    
    public static String getUseremail(WebDriver driver)
    {
        String uemail = "renganathan.k+automation@zohocorp.com";
        
        try
        {
            ClickSettings(driver);
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","ulisttable");
            List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
            uemail = elmts.get(0).findElement(By.xpath(".//div[contains(@class,'ulist_email')]")).findElement(By.tagName("a")).getText();
        }
        catch(Exception e)
        {
            System.out.println("Exception while getting username in jsapi module : ");
            e.printStackTrace();
        }
        return uemail;
    }
    
    public static String getUsername(WebDriver driver)
    {
        String uname = "LDAutomation";
        
        try
        {
            ClickSettings(driver);
            
            WebElement elmt = CommonUtil.elfinder(driver,"id","ulisttable");
            List<WebElement> elmts = elmt.findElements(By.className("list-row"));
            
            uname = elmts.get(0).findElement(By.xpath(".//div[contains(@class,'ulist_uname')]")).findElement(By.className("txtelips")).getText();
        }
        catch(Exception e)
        {
            System.out.println("Exception while getting username in jsapi module : ");
            e.printStackTrace();
        }
        return uname;
    }
    
    public static boolean checkvid(WebDriver ApiDriver,String vid,String cvid) throws Exception
    {
        if(!CommonUtil.elfinder(ApiDriver,"id",vid).getText().equals("undefined")&&CommonUtil.elfinder(ApiDriver,"id",vid).getText()!=null&&!CommonUtil.elfinder(ApiDriver,"id",cvid).getText().equals("undefined")&&CommonUtil.elfinder(ApiDriver,"id",cvid).getText()!=null)
        {
            return true;
        }
        return false;
    }
    
    public static void enterValueSysMsg(WebDriver driver,String pid,String value) throws Exception
    {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id",pid)).getLocation().y+"-200)");
        Thread.sleep(300);
        CommonUtil.elfinder(driver,"id",pid).click();
        CommonUtil.elfinder(driver,"id",pid).sendKeys(value);
    }
    
    public static String checkPos(String top,String bottom,String left,String right)
    {
        String curpos = "Bottom Right";
        
        if(top.equals(left)||top.equals(right))
        {
            if(top.equals(left))
            {
                return "Top Left";
            }
            return "Top Right";
        }
        else if(bottom.equals(left)||bottom.equals(right))
        {
            if(bottom.equals(left))
            {
                return "Bottom Left";
            }
            return "Bottom Right";
        }
        else if(left.contains("-"))
        {
            return "Left";
        }
        else if(right.contains("-"))
        {
            return "Right";
        }
        
        return "Position not found";
    }
}
