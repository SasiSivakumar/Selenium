//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TakeScreenshot;

public class visOnline
{
	public static boolean visCheck(WebDriver driver,int vcount) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.waitRings(driver);
			
			String visCount = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")),"tagname","span").getText();
			
			if(!visCount.equals("0")&&visCount!=null)
			{
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","VisCheckError","MismatchContent");
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor count in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","VisCheckError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
	
	public static boolean visReload(WebDriver driver) throws InterruptedException, IOException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			CommonFunctions.ruleVerifier(driver,1);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			
			String Vid = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(Vid)));
			String visID = Vid;//CommonUtil.elfinder(driver,"id","#ldwrap .visit_div").getAttribute("id");
			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",visID),"tagname","span").click();
			
			driver.navigate().refresh();
			
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#ldwrap .visit_div")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visID)));
			
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking for visitor after reload in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","VisReloadError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
	
	public static boolean visMoreReload(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			CommonFunctions.ruleVerifier(driver,1);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#ldwrap .visit_div")));
			
			WebElement visElmt = CommonUtil.elfinder(driver,"id","ldwrap");
			List<WebElement> visList = visElmt.findElements(By.cssSelector("#ldwrap .visit_div"));
            
            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","MoreVisReload",0);
            
            if(visList.size() == 0)
            {
                TrackingRings.etest.log(Status.FAIL,"No visitors");
                TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","ReloadVisitor");
                return false;
            }
            
			int vc=0;
			String visID[] = new String[visList.size()];
			
			for(WebElement vis:visList)
			{
				visID[vc] = vis.getAttribute("id");
				vc++;
			}
            
            String ids = "Visitor ids:";
            
            for(String id : visID)
            {
                ids += id+"<>";
            }
            
            TrackingRings.etest.log(Status.INFO,ids);
            
			driver.navigate().refresh();
			
			CommonFunctions.waitRings(driver);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#ldwrap .visit_div")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#ldwrap .visit_div")));
            
            wait = CommonUtil.waitreturner(driver,3,250);
			
            for(String id : visID)
            {
                TrackingRings.etest.log(Status.INFO,"Checking presence of visitor - "+id);
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
                
                TrackingRings.etest.log(Status.INFO,"Visitor - "+id+" is present");
            }
			
            return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while reloading and checking with more visitors in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","MoreVisError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
	
	public static boolean trUsrImage(WebDriver driver) throws InterruptedException, IOException
	{
		try
		{
			CommonFunctions.waitRings(driver);
			
			WebElement imgElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldwrap"),"id","p0");
			String trImg = CommonUtil.elementfinder(driver,imgElmt,"tagname","img").getAttribute("src");
			WebElement acElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","hdrdrpdwntop"),"id","usrphoto");
			String acImg = CommonUtil.elementfinder(driver,acElmt,"tagname","img").getAttribute("src");
			
			if(trImg.equals(acImg))
			{
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","UserImageError","MismatchContent");
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking user image in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisOnline","UserImageError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
}
