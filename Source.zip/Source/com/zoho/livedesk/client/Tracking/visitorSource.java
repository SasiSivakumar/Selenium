//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class visitorSource
{
	public enum VisitorSource
	{
		DIRECT("sqico-seng_1"),
		REFERRER("sqico-seng_2"),
		CAMPAIGN("sqico-seng_4"),
		ADWORDS("sqico-seng_5"),
		AOL("sqico-seng_aol"),
		ASK("sqico-seng_ask"),
		DISQUS("sqico-seng_disqus"),
		GOOGLE_PLUS("sqico-seng_googleplus"),
		STUMBLEUPON("sqico-seng_stumbleupon"),
		GOOGLE("sqico-seng_google"),
		YAHOO("sqico-seng_yahoo"),
		BING("sqico-seng_bing"),
		BAIDU("sqico-seng_baidu"),
		FACEBOOK("sqico-seng_facebook"),
		TWITTER("sqico-seng_twitter"),
		LINKEDIN("sqico-seng_linkedin"),
		PINTEREST("sqico-seng_pinterest"),
		TUMBLR("sqico-seng_tumblr"),
		REDDIT("sqico-seng_reddit"),
		YOUTUBE("sqico-seng_youtube"),

		;

		String icon_class_name;

		VisitorSource(String icon_class_name)
		{
			this.icon_class_name=icon_class_name;
		}		
	}

	public static boolean visSourceDirect(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			VisitorSource visitor_source=VisitorSource.DIRECT;

			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box6");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			String icon_class_name=CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("class");

			if("Direct Traffic".contains(partition) && icon_class_name.contains(visitor_source.icon_class_name))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}
			else
			{
				TrackingRings.etest.log(Status.FAIL,"Mismatch in Visitor Source - Expected title :Direct Traffic Actual title :"+partition+" Expected icon class name :"+visitor_source.icon_class_name+" Actual icon class name :"+icon_class_name);
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","SourceDirectError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor source direct in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","SourceDirectError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visSourceSE(WebDriver driver,String ref,VisitorSource visitor_source) throws InterruptedException, IOException
	{
		try
		{
			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box6");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			String icon_class_name=CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("class");

			if(partition.equals(ResourceManager.getRealValue(ref)) && icon_class_name.contains(visitor_source.icon_class_name))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}
			else
			{
				TrackingRings.etest.log(Status.FAIL,"Mismatch in Visitor Source - Expected title :"+ResourceManager.getRealValue(ref)+" Actual title :"+partition+" Expected icon class name :"+visitor_source.icon_class_name+" Actual icon class name :"+icon_class_name);
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","SearchEngineError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor source search engine in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","SearchEngineError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visSourceCampaign(WebDriver driver,String ref) throws InterruptedException, IOException
	{
		try
		{	
			VisitorSource visitor_source=VisitorSource.CAMPAIGN;

			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box6");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			String icon_class_name=CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("class");

			if(partition.equals(ResourceManager.getRealValue(ref)) && icon_class_name.contains(visitor_source.icon_class_name))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,partelmt,"classname","txtelips"),"tagname","em").getAttribute("title").equals("SalesIQ Automation Campaign"))
					{
						CommonFunctions.closeTilesUI(driver);
						return true;
					}
				}
			}
			else
			{
				TrackingRings.etest.log(Status.FAIL,"Mismatch in Visitor Source - Expected title :"+ResourceManager.getRealValue(ref)+" Actual title :"+partition+" Expected icon class name :"+visitor_source.icon_class_name+" Actual icon class name :"+icon_class_name);
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","CampaignSourceError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor source campaign in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","CampaignSourceError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visSourceReferral(WebDriver driver,String ref) throws InterruptedException, IOException
	{
		try
		{
			VisitorSource visitor_source=VisitorSource.REFERRER;

			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box6");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			String icon_class_name=CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("class");

			if(partition.equals(ResourceManager.getRealValue(ref)+" http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html") && icon_class_name.contains(visitor_source.icon_class_name))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}
			else
			{
				TrackingRings.etest.log(Status.FAIL,"Mismatch in Visitor Source - Expected title :"+ResourceManager.getRealValue(ref)+" Actual title :"+partition+" Expected icon class name :"+visitor_source.icon_class_name+" Actual icon class name :"+icon_class_name);
			}

            
            TrackingRings.etest.log(Status.FAIL,"Actual:"+partition+"<>");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","ReferralSourceError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor source referral in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorSource","ReferralSourceError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
}
