//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class ruleCheck
{
	public static boolean verifyRule(WebDriver driver,int ringNum) throws InterruptedException, IOException
	{
		WebDriver visdriver = null;
		try
		{
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver, "Rings");
			CommonFunctions.ruleApp(driver, ringNum);
			
			visdriver = VisitorSite.createPage();
			
			CommonFunctions.waitRings(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,60,100);
			
			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);
			
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while verifying rule in rings in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RuleRings","VisitorMovementError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
	
	public static boolean verifyView(WebDriver driver,int vnum) throws IOException, InterruptedException
	{
		//WebDriver visdriver = null;
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.ruleApp(driver,vnum);
			//visdriver = VisitorSite.createPage();
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"List");
			
			String visId = TrackingRings.vlist;
			
			if(vnum!=5)
			{
				CommonUtil.elfinder(driver,"classname","tlistview").click();
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='listpriority"+vnum+"']//*[@id='"+visId+"']")));
			}
			else
			{
				CommonUtil.elfinder(driver,"id","othervisit").click();
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listpriority5")));
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='listpriority"+vnum+"']//*[@id='"+visId+"']")));
			}
			
			//visdriver.quit();
			//Thread.sleep(80000);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while verifying rule in list view in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RuleListView","VisitorMovementError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
}
