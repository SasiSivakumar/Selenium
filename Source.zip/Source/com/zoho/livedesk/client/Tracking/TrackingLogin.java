//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.TakeScreenshot;

public class TrackingLogin
{
	private static Hashtable result = new Hashtable();
	private static Hashtable hashtable = new Hashtable();
	private static Hashtable servicedown = new Hashtable();
	private static String loginUser = "ldautomation";
	private static String loginPwd = "test1234";
	private static String setUp;
	private static WebDriver driver;

	public static String setUpreturn()
	{
		return Util.setUptracking();
	}

	public static String timeTaken(long starttime,long endtime)
	{
		long timetaken = (endtime-starttime)/1000;
		String time = "";

		if(timetaken > 60)
		{
			long s = timetaken % 60;
			long m = (timetaken / 60) % 60;
			long h = (timetaken / (60 * 60)) % 24;
			if(h > 0)
			{
				if(h == 1)
				{
					time += h+" hour ";
				}
				else
				{
					time += h+" hours ";
				}
			}
			if(m > 0)
			{
				if(m == 1)
				{
					time += m+ " min ";
				}
				else
				{
					time += m+" mins ";
				}
			}
			if(s > 0)
			{
				if(s == 1)
				{
					time += s +" sec";
				}
				else
				{
					time += s +" secs";
				}
			}
		}
		else
		{
			time = timetaken + " secs";
		}
		
		return time;
	}

	public static WebDriver setUp() throws InterruptedException
	{
		try
		{
            return Functions.setUp(true);
		}
		catch(Exception e)
		{
			System.out.println("Exception while setting up webdriver in visitor tracking module : ");
			Thread.sleep(1000);
			e.printStackTrace();
		}
		return null;
	}

	private static void login(WebDriver driver,String loginUser,String loginPwd,String setUp) throws InterruptedException, IOException
	{
		switch (setUp)
		{
		case "idc":
			loginAcc(driver,loginUser,loginPwd,"http://accounts.zoho.com");
			accessSalesIQ(driver,"http://salesiq.zoho.com");
			break;
		case "pre":
			loginAcc(driver,loginUser,loginPwd,"http://accounts.zoho.com");
			accessSalesIQ(driver,"http://presalesiq.zoho.com");
			break;
		case "local":
			loginAcc(driver,loginUser,loginPwd,"http://accounts.localzoho.com");
			accessSalesIQ(driver,"http://salesiq.localzoho.com");
			break;
		case "lab":
			loginAcc(driver,loginUser,loginPwd,"http://accounts.localzoho.com");
			accessSalesIQ(driver,"http://labsalesiq.localzoho.com");
			break;
		default:
			System.out.println("!!! Invalid SETUP !!!");
			driver.quit();
			break;
		}
	}

	private static void loginAcc(WebDriver driver,String loginUser,String loginPwd,String siteName) throws InterruptedException, IOException
	{
		try
		{
			driver.get(siteName);
			FluentWait waiter = CommonUtil.waitreturner(driver,30,250);
			driver.switchTo().frame(0);
			CommonUtil.elfinder(driver,"id","lid").sendKeys(loginUser);
			CommonUtil.elfinder(driver,"id","pwd").sendKeys(loginPwd);
			//CommonUtil.elfinder(driver,"classname","redBtn").click();
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","login"),"classname","redBtn").click();
			waiter.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("dashboardbox")));
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("Exception while trying to login to accounts in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,Util.buildlabel(),"Login","LoginFailure");
			Thread.sleep(1000);
			e.printStackTrace();
			driver.quit();
		}
	}

	private static void accessSalesIQ(WebDriver driver,String siteName) throws IOException, InterruptedException
	{
		try
		{
			driver.get(siteName);
			FluentWait waiter = CommonUtil.waitreturner(driver,50,250);
			Thread.sleep(1000);
			waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("maincontainer")));
			waiter.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("rings_settings"))));
			CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("rings_settings")).click();
			waiter.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("rings_users"))));
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			System.out.println("Exception while trying to access salesiq in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,Util.buildlabel(),"AccessSalesIQ","SalesIQSettingsTab");
			Thread.sleep(1000);
			e.printStackTrace();
			driver.quit();
		}
	}

	private static void logout(WebDriver driver,String setUp) throws IOException, InterruptedException
	{
		try
		{
			FluentWait waiter = CommonUtil.waitreturner(driver,30,200);
			switch (setUp)
			{
			case "idc":
				driver.get("http://accounts.zoho.com/logout");
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
				Thread.sleep(1000);
				break;
			case "pre":
				driver.get("http://accounts.zoho.com/logout");
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
				Thread.sleep(1000);
				break;
			case "local":
				driver.get("http://accounts.localzoho.com/logout");
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
				Thread.sleep(1000);
				break;
			case "lab":
				driver.get("http://accounts.localzoho.com/logout");
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("zohoiam")));
				Thread.sleep(1000);
				break;
			default:
				System.out.println("!!! Invalid SETUP !!!");
				break;
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception while trying to logout from account in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,Util.buildlabel(),"Logout","LogoutFailure");
			Thread.sleep(1000);
			e.printStackTrace();
		}
		driver.quit();
	}
}
