//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;
import com.zoho.qa.server.servlet.WebdriverApi;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeTests;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.TrackingRing;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.RuleCondition;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.RuleCriteria;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.RuleType;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.VisitorsViewType;
import com.zoho.livedesk.util.common.actions.VisitorsOnline;




public class CommonFunctions
{
    public static int tcheckcnt = 0;

    public static void visUVID(WebDriver driver) throws Exception
    {
        waitRings(driver);
        viewCheck(driver,"Rings");
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        final String visitorid = VisitorSite.getLastVisitorId();
        
        VisitorsOnline.waitTillVisitorPresent(driver,visitorid);
        
        TrackingRings.vlist = visitorid;
    }

    public static void waitRings(WebDriver driver) throws Exception
    {
        Tab.clickVisitorsOnline(driver);
    }

    public static void viewCheck(WebDriver driver,String viewName) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,20,250);
        if(viewName.equals("Rings"))
        {
            try
            {
                if(!CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","usrinfo"),"classname","tgl_ticon").getAttribute("class").contains("vo_ring"))
                {
                    CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","usrinfo"),"classname","sqico-vo_ring").click();
                }
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("siqcircular")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("siqcircular")));
            }
            catch(Exception e)
            {
                CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","usrinfo"),"classname","sqico-vo_ring").click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.className("siqcircular")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("siqcircular")));
            }
        }
        else
        {
            try
            {
                if(!CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","usrinfo"),"classname","tgl_ticon").getAttribute("class").contains("vo_list"))
                {
                    CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","usrinfo"),"classname","sqico-vo_list").click();
                }
                
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listbox")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("listbox")));
            }
            catch(Exception e)
            {
                CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","usrinfo"),"classname","sqico-vo_list").click();
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listbox")));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("listbox")));
            }
        }
    }

    public static void ruleApply(WebDriver driver,final int rnum,String ccheck) throws Exception
    {


        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        String rule_value=ccheck;

        TrackingRing customize_ring=getTrackingRingFromRingNumber(rnum);
        
        if(rnum == 4)
        {
            TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,TrackingRings.etest);            
            TrackingRingsCustomizeCommonFunctions.clickCustomizeIcon(driver,TrackingRings.etest);
        }
                
        if(ccheck!="")
        {
            //set visitor type as new
            TrackingRingsCustomizeCommonFunctions.addNewTrackingCustomizeRule(driver,TrackingRings.etest,customize_ring,RuleCondition.BROWSER,RuleCriteria.EQUAL,"Google Chrome");
        }
            
        else
        {
            //To make visitor not to come to corresponding rings
            //no of past chats 500
            // TrackingRingsCustomizeCommonFunctions.addNewTrackingCustomizeRule(driver,TrackingRings.etest,customize_ring,RuleCondition.PAST_CHATS,RuleCriteria.EQUAL,"500");
        }
        
        if(rnum == 1)
        {

            //save rule
            if(TrackingRingsCustomizeCommonFunctions.isApplyButtonInTrackingCustomizeVisible(driver))
            {
                String unique_label=com.zoho.livedesk.util.common.CommonUtil.getUniqueMessage(),preset_name="preset"+unique_label;
                TrackingRingsCustomizeCommonFunctions.clickApplyButtonInTrackingCustomize(driver,TrackingRings.etest);
                TrackingRingsCustomizeCommonFunctions.editPresetNameAndSave(driver,preset_name,null,TrackingRings.etest);
            }

            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ApplyCondition","CheckRule",0);
                        
            Tab.clickChatHistory(driver);
            Tab.clickVisitorsOnline(driver);
            
            Thread.sleep(1000);
        }
    }

    public static void ruleApp(WebDriver driver,int rnum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        //click customize header
        TrackingRingsCustomizeCommonFunctions.clickCustomizeIcon(driver,TrackingRings.etest);
   

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(TrackingRingsCustomizeCommonFunctions.CUSTOMIZE_MENU_CONTAINER)));

        //set first preset default preset        
        TrackingRingsCustomizeCommonFunctions.setVisitorPrioririzedBy(driver,TrackingRingsCustomizeCommonFunctions.PAST_CHATS_DEFAULT_PRESET_NAME,TrackingRings.etest);  
        
        Thread.sleep(500);
        
        Tab.clickChatHistory(driver);
        Tab.clickVisitorsOnline(driver);
        
        Thread.sleep(1000);
        
        for(int i=4;i>0;i--)
        {
            if(i==rnum)
            {
                ruleApply(driver,i,"New ");
            }
            else
            {
                ruleApply(driver,i,"");
            }
        }
    }

    public static boolean ruleCheck(WebDriver driver,int rnum) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        TrackingRingsCustomizeCommonFunctions.clickCustomizeIcon(driver,TrackingRings.etest);
             
        TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","CheckRule",0);
        
        int rclear = 0;
        
        for(int i=1;i<5;i++)
        {
            if(i==rnum)
            {
                if(ruleChecker(driver,i,"Google Chrome"))
                {
                    rclear++;
                }
            }
            else
            {
                if(ruleChecker(driver,i,""))
                {
                    rclear++;
                }
            }
        }
        
        if(rclear == 4)
        {
            TrackingRingsCustomizeCommonFunctions.closeCustomizeMenu(driver,TrackingRings.etest);
            return true;
        }
        
        TrackingRingsCustomizeCommonFunctions.closeCustomizeMenu(driver,TrackingRings.etest);

        return false;
    }

    public static boolean ruleChecker(WebDriver driver,final int rnum,String ccheck) throws Exception
    {
        int rcheck = rnum;
        String rule_value=ccheck;

        TrackingRing customize_ring=getTrackingRingFromRingNumber(rnum);

        return TrackingRingsCustomizeCommonFunctions.isRingConditionPresent(driver,customize_ring,RuleCondition.BROWSER,RuleCriteria.EQUAL,rule_value);
    }

    public static void clickVisitorRings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        String visID = TrackingRings.vlist;
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visID)));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(visID)));
        //CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",visID),"tagname","span").click();
        WebElement e = CommonUtil.elfinder(driver,"id",visID);
        
        VisitorsOnline.clickVisitor(e);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
    }

    public static void closeTilesUI(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            String cbtn = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","sqico-close").getAttribute("onclick");
            
            CommonUtil.JSExecutor(driver,cbtn);
            
            wait.until(ExpectedConditions.not(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings"))));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","CommonFunctions","CloseTilesError",e);
        }
    }

    public static boolean mouseOverTitle(WebDriver driver,WebElement elmt) throws IOException, InterruptedException
    {
        if(elmt.getAttribute("title")!=null)
        {
            if(!(elmt.getAttribute("title").contains("null")||elmt.getAttribute("title").contains("undefined")))
            {
                return true;
            }
        }
        return false;
    }

    public static void proActiveChatNDept(WebDriver driver) throws Exception
    {
        CommonFunctions.waitRings(driver);
        CommonFunctions.viewCheck(driver,"Rings");
        
//        if(!ruleCheck(driver, 1))
//        {
//            CommonFunctions.ruleApp(driver, 1);
//        }
        
        CommonFunctions.waitRings(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);
        
        String visId = TrackingRings.vlist;
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
        CommonUtil.elfinder(driver,"id",visId);
        
        CommonFunctions.clickVisitorRings(driver);
        
        Thread.sleep(500);
        
        WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");
        
        WebElement kelmt = CommonUtil.elementfinder(driver,pelmt,"tagname","textarea");
        
        kelmt.sendKeys("Welcome to Zoho");
        kelmt.sendKeys(Keys.RETURN);
        
        Thread.sleep(500);
        
        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("none"))
                           {
                               return true;
                           }
                           return false;
                       }
                   });
    }

    public static void changeStatus(WebDriver driver,String status) throws Exception
    {
        com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,status);
        // FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        // Thread.sleep(1000);
        
        // if(status.equals("available"))
        // {
        //     if(!((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-1")))
        //     {
        //         driver.findElement(By.className("hdrprt")).findElement(By.id("hdrdrpdwntop")).click();
                
        //         Thread.sleep(1000);
                
        //         driver.findElement(By.id("headerdropdiv")).findElement(By.id("ustatus")).findElement(By.tagName("a")).findElement(By.tagName("span")).click();
                
        //         Thread.sleep(1000);
                
        //         wait.until(new Function<WebDriver,Boolean>(){
        //             public Boolean apply(WebDriver driver)
        //             {
        //                 if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-1"))
        //                 {
        //                     return true;
        //                 }
        //                 return false;
        //             }
        //         });
        //     }
        // }
        // else if(status.equals("busy"))
        // {
        //     if(!((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-3")))
        //     {
        //         driver.findElement(By.className("hdrprt")).findElement(By.id("hdrdrpdwntop")).click();
                
        //         Thread.sleep(1000);
                
        //         driver.findElement(By.id("headerdropdiv")).findElement(By.id("ustatus")).findElement(By.tagName("a")).findElement(By.tagName("span")).click();
                
        //         Thread.sleep(1000);
                
        //         wait.until(new Function<WebDriver,Boolean>(){
        //             public Boolean apply(WebDriver driver)
        //             {
        //                 if((driver.findElement(By.id("headerdropdiv")).findElement(By.id("hdrstatus")).getAttribute("class")).equals("userstatus-3"))
        //                 {
        //                     return true;
        //                 }
        //                 return false;
        //             }
        //         });
        //     }
        // }
        
        // Thread.sleep(1000);
    }

    public static void acceptProActive(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlsiframe")));
        
        WebElement elmt = CommonUtil.elfinder(driver,"id","zlsiframe");
        
        driver.switchTo().frame(elmt);
        
        CommonUtil.elfinder(driver,"id","lstxteditor").sendKeys("Hello");
        CommonUtil.elfinder(driver,"id","lstxteditor").sendKeys(Keys.RETURN);
    }

    public static void clearChatWindow(WebDriver driver) throws Exception
    {
        Tab.clickMyChats(driver);
        
        ChatWindow.sentMessage(driver,"Bye");
        
        ChatWindow.endAndCloseChat(driver);
        
        Functions.closeBannersAfterLogin(driver);
    }

    public static void visSourceBox(WebDriver driver) throws Exception
    {
        visUVID(driver);
        
        CommonFunctions.waitRings(driver);
        CommonFunctions.viewCheck(driver, "Rings");
//        if(!ruleCheck(driver, 1))
//        {
//            CommonFunctions.ruleApp(driver, 1);
//        }
        
        CommonFunctions.waitRings(driver);
        
        FluentWait wait = CommonUtil.waitreturner(driver,60,100);
        
        String visId = TrackingRings.vlist;
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
        CommonUtil.elfinder(driver,"id",visId);
        
        CommonFunctions.clickVisitorRings(driver);
    }

    public static void addTrigger(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("rings_settings"))));
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("rings_settings")).click();
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("rings_automation")));
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("rings_automation")).click();
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("rings_triggers")));
        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("rings_triggers")).click();
        
        try
        {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("addrule")));
            CommonUtil.elfinder(driver,"id","addrule").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("data_row")));
            
        }
        catch(Exception e)
        {
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","autobtnadd"),"tagname","span").click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("data_row")));
            
        }
    }

    public static void reVisit(WebDriver driver,WebDriver visdriver) throws Exception
    {
        visdriver.get("https://www.zoho.com/");
        VisitorsOnline.waitTillVisitorLeaves(driver);
        
        Thread.sleep(3000);
        
        VisitorSite.createPage(visdriver);
    }

    public static void ruleVerifier(WebDriver driver,int rnum) throws Exception
    {
        if(!CommonFunctions.ruleCheck(driver,rnum))
        {
            CommonFunctions.ruleApp(driver,rnum);
        }
    }

    public static void initiateChat(WebDriver driver) throws Exception
    {
        FluentWait viswait = CommonUtil.waitreturner(driver,30,250);
        
        viswait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zlstxtcnt")));
        
        CommonUtil.elfinder(driver,"id","zlstxtcnt").click();
        
        viswait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zlsiframe")));
        
        driver.switchTo().frame(CommonUtil.elfinder(driver,"id","zlsiframe"));
        
        CommonUtil.elfinder(driver,"id","question").sendKeys("tracking pick up button ?...");
        CommonUtil.elfinder(driver,"id","btnaddvisitor").click();
        
        viswait.until(new Function<WebDriver,Boolean>() {
            public Boolean apply(WebDriver driver) {
                if(driver.findElement(By.className("timersvg"))!=null)
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void initiateChatId(WebDriver driver) throws Exception
    {
        String vname = "Anand R";
        String vemail = "rajkumar.natarajan+143@zohocorp.com";
        String phno = "9123456780";
        String question = "tracking pick up button ?...";
        
        VisitorWindow.initiateChatVis(driver,vname,vemail,phno,question,TrackingRings.etest);
    }

    public static void changeVisDetails(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);
        
        driver.switchTo().defaultContent();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlsiframe")));
        
        WebElement welmt = CommonUtil.elfinder(driver,"id","zlsiframe");
        
        driver.switchTo().frame(welmt);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("visitinfo")));
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visitinfo"),"classname","vname").sendKeys("Anand Raja");
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visitinfo"),"classname","vemail").sendKeys("rajkumar.natarajan+223311@zohocorp.com");
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","visitinfo"),"classname","vemail").sendKeys(Keys.RETURN);
        
        wait.until(new Function<WebDriver,Boolean>() {
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("msgdiv")).getText().contains(ResourceManager.getRealValue("rings_vdata")))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void changePortalSettingsCC(WebDriver driver,boolean checkenable) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("rings_settings"))));
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("rings_settings")).click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("rings_portalsettings"))));
            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("rings_portalsettings")).click();
            
            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
            
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("maxconcurrentchatdrpdwn_div"))).getLocation().y+"-400)");
            CommonUtil.elfinder(driver,"id","maxconcurrentchatdrpdwn_div").click();
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("maxconcurrentchatdrpdwn_ddown")).getAttribute("style").contains("block"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
            WebElement elmt = driver.findElement(By.id("maxconcurrentchatdrpdwn_ddown"));
            String value = "Unlimited";
            
            if(checkenable)
            {
                value = "1";
            }
            
            List<WebElement> lis=elmt.findElements(By.tagName("li"));
            
            for(int i=0;i<lis.size();i++)
            {
                WebElement element = lis.get(i);
                WebElement element2 = element.findElement(By.tagName("div"));
                WebElement element3 = element2.findElement(By.tagName("span"));
                String title = element3.getAttribute("title");
                
                if(title.equals(value))
                {
                    element.click();
                    //Thread.sleep(2000);
                    Tab.waitForLoading(driver,"addpconfig.do",TrackingRings.etest);
                }
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","CommonFunctions","PortalSettingsCCError",e);
        }
    }

    public static TrackingRing getTrackingRingFromRingNumber(int ring_number)
    {
        TrackingRing[] tracking_rings=TrackingRing.values();

        for(TrackingRing tracking_ring : tracking_rings)
        {
            if(tracking_ring.ring_number==ring_number)
            {
                return tracking_ring;
            }
        }

        return null;
    }
}
