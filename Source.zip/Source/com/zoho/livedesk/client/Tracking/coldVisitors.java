//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class coldVisitors
{
	public static boolean visSince(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"List");

			if(!(CommonFunctions.ruleCheck(driver,5)))
			{
				CommonFunctions.ruleApp(driver,5);
			}

			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldwrap"),"id","othervisit").click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listpriority5")));

			Thread.sleep(60000);
			
			String visId = TrackingRings.vlist;

			WebElement vis = CommonUtil.elfinder(driver,"id",visId);
			String vistime = CommonUtil.elementfinder(driver,vis,"classname","sqico-time").getText();

			if(vistime.contains("min")&&vistime.contains("ago"))
			{
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ColdVisitor","VisitorSinceError","MismatchContent");
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking cold visitors in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ColdVisitor","VisitorSinceError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean lastVisited(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"List");

			if(!(CommonFunctions.ruleCheck(driver,5)))
			{
				CommonFunctions.ruleApp(driver,5);
			}

			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldwrap"),"id","othervisit").click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listpriority5")));

			Thread.sleep(60000);
			
			String visId = TrackingRings.vlist;

			WebElement vis = CommonUtil.elfinder(driver,"id",visId);
			String vistime = CommonUtil.elementfinder(driver,vis,"classname","sqico-lastvisit").getText();

			if(vistime.contains("min")&&vistime.contains("ago"))
			{
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ColdVisitor","LastVisitedError","MismatchContent");
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking last visited in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ColdVisitor","LastVisitedError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
}
