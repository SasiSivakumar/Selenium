//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.VisitorsOnline;


import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.Set;

import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.client.Tracking.visitorSource.VisitorSource;//enum
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeTests;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;

public class TrackingRings
{
	public static Hashtable result = new Hashtable();
	private static Hashtable hashtable = new Hashtable();
	private static Hashtable servicedown = new Hashtable();
	private static WebDriver visdriver = null;
	public static String vlist = new String();
    //public static String oldVisit = new String();

    public static String
    EMBED_NAME=ConfManager.getRealValue("trackingembed"),
    PORTAL_NAME=ConfManager.getRealValue("trackingportal");

    public static Hashtable<String,WebDriver> continue_visitor_driver = new Hashtable<String,WebDriver>();
    public static Hashtable<String,String> continue_visitor_id = new Hashtable<String,String>();
    public static Hashtable<String,Boolean> is_continue_test = new Hashtable<String,Boolean>();
    public static Hashtable<String,ExtentTest> extent_test = new Hashtable<String,ExtentTest>();

    public static ExtentTest etest; 

    public enum TestStatus
    {
        BEGIN_TEST,
        CONTINUE_TEST;
    }
	
	public static Hashtable initial(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
            result = new Hashtable();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS1"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			FluentWait waiter = CommonUtil.waitreturner(driver,30,200);

			waiter.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("rings_tracking"))));
			CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();

			waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
			Thread.sleep(1000);
			result.put("RINGS1",true);
			visdriver = VisitorSite.createPage();
			
			if((boolean)result.get("RINGS1"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS1")+" is checked");
			
			ComplexReportFactory.closeTest(etest);
            
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("Deleting All Presets before Automation"));
			ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
			setupTrackingRingsForAutomation(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS2"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			result.put("RINGS2",initialIncomingVisitor.incomingVisitor(driver));
			visdriver.quit();
			
			if((boolean)result.get("RINGS2"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS2")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS3"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS3",initialLeavingVisitor.leavingVisitor(driver));
            //oldVisit = vlist;
			
			if((boolean)result.get("RINGS3"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS3")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS4"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS4",initialIncomingVisitorList.incomingVisitor(driver));
			visdriver.quit();
			
			if((boolean)result.get("RINGS4"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS4")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS5"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS5",initialLeavingVisitorList.leavingVisitor(driver));
            //oldVisit = vlist;
			/*result.put("RINGS6",ruleCheck.verifyRule(driver, 1));//
			result.put("RINGS7",ruleCheck.verifyRule(driver, 2));//
			result.put("RINGS8",ruleCheck.verifyRule(driver, 3));//------>>>>>>>Yet to be completed/started
			result.put("RINGS9",ruleCheck.verifyRule(driver, 4));//
			result.put("RINGS10",ruleCheck.verifyRule(driver, 5));//
			*/
			
			if((boolean)result.get("RINGS5"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS5")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);


           visStatus.checkRepeatedVisitor(driver,EMBED_NAME,PORTAL_NAME,visStatus.VisitorStatus.REPEATED_USER,TestStatus.BEGIN_TEST,"RINGS93");			            

           visStatus.checkRepeatedVisitor(driver,EMBED_NAME,PORTAL_NAME,visStatus.VisitorStatus.REPEATED_CHAT,TestStatus.BEGIN_TEST,"RINGS94");


            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS92"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
            result.put("RINGS92", visStatus.checkPageNavigationAnimationInRings(driver,EMBED_NAME,PORTAL_NAME,etest));
            ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

            //keep as last test, so that in case delete created trigger fails, other tests are not affected
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS95"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
            result.put("RINGS95", visStatus.checkTriggeredStatusInRings(driver,EMBED_NAME,PORTAL_NAME,etest));
            ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

            result.put("RINGS93", visStatus.checkRepeatedVisitor(driver,EMBED_NAME,PORTAL_NAME,visStatus.VisitorStatus.REPEATED_USER,TestStatus.CONTINUE_TEST,"RINGS93"));

            result.put("RINGS94", visStatus.checkRepeatedVisitor(driver,EMBED_NAME,PORTAL_NAME,visStatus.VisitorStatus.REPEATED_CHAT,TestStatus.CONTINUE_TEST,"RINGS94"));
                       
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS18"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS18",tilesCheck.tilesUICheckPartition(driver,"Available,Idle","div.detbox.box1"));
			
			if((boolean)result.get("RINGS18"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS18")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS19"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS19",tilesCheck.tilesUICheckPartition(driver,"Time on site","div.detbox.box2"));
			
			if((boolean)result.get("RINGS19"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS19")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS20"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS20",tilesCheck.tilesUICheckPartition(driver,"Visitor History","div.detbox.box3"));
			
			if((boolean)result.get("RINGS20"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS20")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS21"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS21",tilesCheck.tilesUICheckPartition(driver,"Visitor Location and IP","div.detbox.box4"));
			
			if((boolean)result.get("RINGS21"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS21")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS22"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS22",tilesCheck.tilesUICheckPartition(driver,"Visitor landing page","div.detbox.box5"));
			
			if((boolean)result.get("RINGS22"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS22")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS23"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS23",tilesCheck.tilesUICheckPartition(driver,"Direct Traffic,Referral","div.detbox.box6"));
			
			if((boolean)result.get("RINGS23"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS23")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS24"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS24",tilesCheck.tilesCheckQuesArea(driver));
			//visdriver.quit();
			//visdriver = VisitorSite.createPage();
			
			if((boolean)result.get("RINGS24"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS24")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS25"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS25",tilesCheck.tilesCheckVisInfo(driver,"infoname_","//div[contains(@class,'vinfohdr')]//span[contains(@class,'txtelips')][1]"));
			
			if((boolean)result.get("RINGS25"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS25")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS26"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS26",tilesCheck.tilesCheckVisInfo(driver,"ccode","//div[contains(@class,'vinfohdr')]//span[contains(@class,'gspritebg')][1]"));
			
			if((boolean)result.get("RINGS26"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS26")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS27"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS27",tilesCheck.tilesCheckVisInfo(driver,"browser","//div[contains(@class,'vinfohdr')]//span[contains(@class,'gspritebg')][2]"));
			
			if((boolean)result.get("RINGS27"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS27")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS28"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS28",tilesCheck.tilesCheckVisInfo(driver,"os","//div[contains(@class,'vinfohdr')]//span[contains(@class,'gspritebg')][3]"));
			//visdriver.quit();
			//visdriver = VisitorSite.createPage();
			
			if((boolean)result.get("RINGS28"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS28")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS29"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS29",tilesCheck.cannedText(driver));

			if((boolean)result.get("RINGS29"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS29")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            //visdriver.quit();
			/*visdriver = VisitorSite.createPage();
			result.put("RINGS30",tilesCheck.visPath(driver));//------------>Yet to be completed
			visdriver.quit();*/
			//visdriver = VisitorSite.createPage();
			
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS31"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS31",tilesCheck.closeButtonUI(driver));
			//visdriver.quit();
			//visdriver = VisitorSite.createPage();
			
			if((boolean)result.get("RINGS31"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS31")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS32"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS32",tilesCheck.outsideTilesUI(driver));
			//visdriver.quit();
			//visdriver = VisitorSite.createPage();
			
			if((boolean)result.get("RINGS32"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS32")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS33"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS33",tilesCheck.proActiveOneDept(driver));
			
			if((boolean)result.get("RINGS33"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS33")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            //result.put("RINGS34",tilesCheck.proActiveMoreDept(driver));//---Add and delete TestDepartment before this
            //oldVisit = vlist;
			visdriver.quit();
			
			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS35"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS35",proActiveBasic.tilesBox(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS35"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS35")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS36"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS36",proActiveBasic.tilesInvi(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS36"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS36")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            /*
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS37"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS37",proActiveBasic.tilesDownIcoVis(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS37"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS37")+" is checked");
			
			ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS38"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS38",proActiveBasic.tilesUpIco(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS38"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS38")+" is checked");
			
			ComplexReportFactory.closeTest(etest);*/
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS39"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS39",proActiveBasic.visStatusChat(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS39"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS39")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS40"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS40",proActiveBasic.placeHolders(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS40"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS40")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS41"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS41",proActiveBasic.buttonSend(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS41"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS41")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS42"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS42",proActiveBasic.checkChatIniName(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS42"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS42")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS43"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS43",proActiveBasic.visStatus(driver, visdriver,"available",etest));
			
			if((boolean)result.get("RINGS43"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS43")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS44"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS44",proActiveBasic.visStatus(driver, visdriver,"busy",etest));
			
			if((boolean)result.get("RINGS44"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS44")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS45"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS45",proActiveBasic.visStatus(driver, visdriver,"engaged",etest));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS45"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS45")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS46"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS46",visitorSource.visSourceDirect(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS46"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS46")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS47"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.google.com");
			result.put("RINGS47",visitorSource.visSourceSE(driver,"rings_refgoogle",VisitorSource.GOOGLE));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS47"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS47")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS48"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.yahoo.com");
			result.put("RINGS48",visitorSource.visSourceSE(driver,"rings_refyahoo",VisitorSource.YAHOO));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS48"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS48")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS49"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.bing.com");
			result.put("RINGS49",visitorSource.visSourceSE(driver,"rings_refbing",VisitorSource.BING));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS49"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS49")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS50"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.baidu.com");
			result.put("RINGS50",visitorSource.visSourceSE(driver,"rings_refbaidu",VisitorSource.BAIDU));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS50"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS50")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS51"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.facebook.com");
			result.put("RINGS51",visitorSource.visSourceSE(driver,"rings_reffacebook",VisitorSource.FACEBOOK));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS51"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS51")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS52"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.twitter.com");
			result.put("RINGS52",visitorSource.visSourceSE(driver,"rings_reftwitter",VisitorSource.TWITTER));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS52"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS52")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS53"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.linkedin.com");
			result.put("RINGS53",visitorSource.visSourceSE(driver,"rings_reflinkedin",VisitorSource.LINKEDIN));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS53"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS53")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS54"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.pinterest.com");
			result.put("RINGS54",visitorSource.visSourceSE(driver,"rings_refpinterest",VisitorSource.PINTEREST));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS54"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS54")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS55"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.tumblr.com");
			result.put("RINGS55",visitorSource.visSourceSE(driver,"rings_reftumblr",VisitorSource.TUMBLR));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS55"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS55")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS56"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.reddit.com");
			result.put("RINGS56",visitorSource.visSourceSE(driver,"rings_refreddit",VisitorSource.REDDIT));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS56"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS56")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS57"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.referrerPage("http://www.youtube.com");
			result.put("RINGS57",visitorSource.visSourceSE(driver,"rings_refyoutube",VisitorSource.YOUTUBE));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS57"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS57")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS58"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createCampaign("SalesIQ Automation");
			result.put("RINGS58",visitorSource.visSourceCampaign(driver,"rings_refcampaign"));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS58"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS58")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS59"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createReferralPage();
			result.put("RINGS59",visitorSource.visSourceReferral(driver,"rings_refby"));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS59"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS59")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest); 

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS98"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			visdriver = VisitorSite.referrerPage("https://www.sampleurl.com/?gclid=sample_gclid");
			result.put("RINGS98",visitorSource.visSourceSE(driver,"rings_refadwords",VisitorSource.ADWORDS));
            //oldVisit = vlist;
			visdriver.quit();			
			if((boolean)result.get("RINGS98"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS98")+" is checked");			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
		
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS99"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			visdriver = VisitorSite.referrerPage("https://www.aol.com/");
			result.put("RINGS99",visitorSource.visSourceSE(driver,"rings_ref_aol",VisitorSource.AOL));
            //oldVisit = vlist;
			visdriver.quit();			
			if((boolean)result.get("RINGS99"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS99")+" is checked");			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS100"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			visdriver = VisitorSite.referrerPage("https://www.ask.com/");
			result.put("RINGS100",visitorSource.visSourceSE(driver,"rings_ref_ask",VisitorSource.ASK));
            //oldVisit = vlist;
			visdriver.quit();			
			if((boolean)result.get("RINGS100"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS100")+" is checked");			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS101"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			visdriver = VisitorSite.referrerPage("https://disqus.com/");
			result.put("RINGS101",visitorSource.visSourceSE(driver,"rings_ref_disqus",VisitorSource.DISQUS));
            //oldVisit = vlist;
			visdriver.quit();			
			if((boolean)result.get("RINGS101"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS101")+" is checked");			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS102"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			visdriver = VisitorSite.referrerPage("https://plus.google.com/");
			result.put("RINGS102",visitorSource.visSourceSE(driver,"rings_ref_googleplus",VisitorSource.GOOGLE_PLUS));
            //oldVisit = vlist;
			visdriver.quit();			
			if((boolean)result.get("RINGS102"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS102")+" is checked");			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS103"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
			visdriver = VisitorSite.referrerPage("https://www.stumbleupon.com");
			result.put("RINGS103",visitorSource.visSourceSE(driver,"rings_ref_stumbleupon",VisitorSource.STUMBLEUPON));
            //oldVisit = vlist;
			visdriver.quit();			
			if((boolean)result.get("RINGS103"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS103")+" is checked");			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);          
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS60"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS60",tilesCheck.greenTextArea(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS60"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS60")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS61"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS61",visStatus.visAccessed(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS61"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS61")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS62"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS62",visStatus.visClicked(driver,visdriver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS62"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS62")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS63"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS63",visStatus.visWaiting(driver,visdriver));
			
			if((boolean)result.get("RINGS63"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS63")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS64"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS64",visStatus.visMissed(driver,visdriver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS64"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS64")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS65"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS65",visStatus.visContacted(driver,visdriver));
			
			if((boolean)result.get("RINGS65"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS65")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS66"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS66",visStatus.visResponded(driver,visdriver));
			
			if((boolean)result.get("RINGS66"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS66")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS67"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS67",visStatus.visCompleted(driver,visdriver,etest));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS67"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS67")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
                                   
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS74"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			WebDriver visdriverOnline1 = VisitorSite.createPage();
			WebDriver visdriverOnline2 = VisitorSite.createPage();
			result.put("RINGS74",visOnline.visCheck(driver,3));
            //oldVisit = vlist;
			visdriver.quit();
			visdriverOnline1.quit();
			visdriverOnline2.quit();
			
			if((boolean)result.get("RINGS74"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS74")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS75"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS75",visOnline.visReload(driver));
			visdriver.quit();
			
			if((boolean)result.get("RINGS75"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS75")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS76"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			WebDriver visdriverOnline3 = VisitorSite.createPage();
			result.put("RINGS76",visOnline.visMoreReload(driver));
            //oldVisit = vlist;
			visdriver.quit();
			visdriverOnline3.quit();
			
			if((boolean)result.get("RINGS76"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS76")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS77"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS77",visOnline.trUsrImage(driver));
			
			if((boolean)result.get("RINGS77"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS77")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS78"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS78",proActiveInter.continueButton(driver, visdriver));
			
			if((boolean)result.get("RINGS78"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS78")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS79"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS79",proActiveInter.visReplyText(driver));
			
			if((boolean)result.get("RINGS79"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS79")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS80"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS80",proActiveInter.myChatPage(driver));
			
			if((boolean)result.get("RINGS80"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS80")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS81"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS81",proActiveInter.connectedTo(driver));
			
			if((boolean)result.get("RINGS81"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS81")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS82"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS82",proActiveInter.chatCompleted(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS82"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS82")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS83"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS83",chatBasics.pickUpButton(driver,visdriver));
			
			if((boolean)result.get("RINGS83"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS83")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS84"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS84",chatBasics.pickUpAccept(driver,visdriver,etest));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS84"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS84")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS85"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS85",chatBasics.chatNameTilesUI(driver, visdriver,etest));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS85"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS85")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS86"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS86",proActiveInter.proActiveID(driver, visdriver));
            //oldVisit = vlist;
			visdriver.quit();

			if((boolean)result.get("RINGS86"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS86")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            visdriver = VisitorSite.createPage();
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS87"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            result.put("RINGS87",tilesCheck.tilesBox(driver,visdriver,"Visitor History","New Visitor"));

            if((boolean)result.get("RINGS87"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS87")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
        
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS88"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            result.put("RINGS88",tilesCheck.tilesBox(driver,visdriver,"Visitor Location and IP",null));

            if((boolean)result.get("RINGS88"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS88")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS89"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            result.put("RINGS89",tilesCheck.tilesBox(driver,visdriver,"Visitor landing page","SalesIQ Testing"));

            if((boolean)result.get("RINGS89"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS89")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS90"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            result.put("RINGS90",tilesCheck.tilesBox(driver,visdriver,"Direct Traffic","Direct"));

            if((boolean)result.get("RINGS90"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS90")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            //oldVisit = vlist;
            visdriver.quit();

           	//for above use cases Visitor prioritized settings must the defauls value and for below we will set as per use case.So below cases must be run only after above cases are completed 

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS68"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS68",coldVisitors.visSince(driver));
			
			if((boolean)result.get("RINGS68"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS68")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS69"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			CommonFunctions.reVisit(driver,visdriver);
			result.put("RINGS69",coldVisitors.lastVisited(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS69"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS69")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS70"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS70",ringsCheck.visFlag(driver));
			
			if((boolean)result.get("RINGS70"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS70")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS71"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS71",ringsCheck.visName(driver));
			
			if((boolean)result.get("RINGS71"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS71")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS72"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS72",ringsCheck.viStatus(driver,visdriver));
			//visdriver.quit();
			//visdriver = VisitorSite.createPage();
			
			if((boolean)result.get("RINGS72"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS72")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS73"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			CommonFunctions.reVisit(driver,visdriver);
			result.put("RINGS73",ringsCheck.visStar(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS73"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS73")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
 
 			//s
 			            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS11"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS11",ruleCheck.verifyView(driver, 1));
			
			if((boolean)result.get("RINGS11"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS11")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS14"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS14",ruleCheck.verifyView(driver, 4));
			
			if((boolean)result.get("RINGS14"))
			{
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS14")+" is checked");
			}
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			// for(int i=0;i<1;i++)
			// {
			// 	WebDriver extra_driver = Functions.setUp();
			// 	Functions.login(driver,"kabilan_account");
			// }
            
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS12"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS12",ruleCheck.verifyView(driver, 2));
			
			if((boolean)result.get("RINGS12"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS12")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
           
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS13"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS13",ruleCheck.verifyView(driver, 3));
			
			if((boolean)result.get("RINGS13"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS13")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
           	
			//visdriver = VisitorSite.createPage();//delete this line later. 

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS15"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS15",ruleCheck.verifyView(driver, 5));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS15"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS15")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS16"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			visdriver = VisitorSite.createPage();
			result.put("RINGS16",verifyVisitor.visRings(driver));
			
			if((boolean)result.get("RINGS16"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS16")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("RINGS17"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");
            
			result.put("RINGS17",verifyVisitor.visList(driver));
            //oldVisit = vlist;
			visdriver.quit();
			
			if((boolean)result.get("RINGS17"))
				etest.log(Status.PASS,KeyManager.getRealValue("RINGS17")+" is checked");
			
			ComplexReportFactory.closeTest(etest);

			TrackingRingsCustomizeTests.deleteAllPresetsAfterThreshhold(driver,etest);

			try
			{
				//for settings back to rings view
		        VisitorsOnline.selectRingsViewInVisitorsOnline(driver);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
 		}
		catch(Exception e)
		{
			result.put("RINGS1",false);
			System.out.println("Exception while clicking visitors online tab in visitor tracking module : ");
			etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
			TakeScreenshot.screenshot(driver,etest,"Tracking","TrackingShowStopper","Trackingtab",e);
			Thread.sleep(1000);
			//e.printStackTrace();
		}
		hashtable.put("result",result);
		hashtable.put("servicedown",servicedown);
		return hashtable;
	}

	public static void setupTrackingRingsForAutomation(WebDriver driver,ExtentTest etest) throws Exception
	{
		try
		{
			TrackingRingsCustomizeCommonFunctions.clickCustomizeIcon(driver,etest);
            Functions.closeBannersAfterLogin(driver);
            //an announcement banner will appear after clicking customize menu.So we close it.Note:closeBannersAfterLogin will close tracking customize menu also.

            TrackingRingsCustomizeTests.deleteAllPresets(driver,etest);
			TrackingRingsCustomizeCommonFunctions.clickCustomizeIcon(driver,etest);
	        TrackingRingsCustomizeCommonFunctions.setVisitorPrioririzedBy(driver,TrackingRingsCustomizeCommonFunctions.TIME_SPENT_DEFAULT_PRESET_NAME,etest);  
			TakeScreenshot.screenshot(driver,etest,"Tracking","INFO","Operator window screenshot",10);	
            TrackingRingsCustomizeCommonFunctions.closeCustomizeMenu(driver,etest);            

		}
		catch(Exception e)
		{
			etest.log(Status.FAIL,"Could'not set visitor prioritized by 'Time Spent");

			TakeScreenshot.screenshot(driver,etest,"Tracking","Failure","Operator window screenshot");		
			e.printStackTrace();
		}

		driver.navigate().refresh();
	}

    public static void closeAllDriversFromHashtable(Hashtable<String,WebDriver> drivers)
    {
        Set<String> keys = drivers.keySet();

        for(String key: keys)
        {
            try
            {
                WebDriver driver=drivers.get(key);
                quitDriver(driver);
            }
            catch(Exception e)
            {
                System.out.println("CLEAN_UP_ERROR : Could not close driver with key : "+key);
                e.printStackTrace();
            }
        }

    }

    public static void quitDriver(WebDriver driver)
    {
        if(driver!=null)
        {
           driver.quit(); 
        }
    }


}
