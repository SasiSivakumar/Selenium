//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Cookie;

import com.google.common.base.Function;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.common.VisitorWindow;

import com.zoho.livedesk.client.TakeScreenshot;

public class VisitorSite
{
	public static String lastVisitorId = "Visitor id cannot be found from cookie";

	public static WebDriver createPage() throws InterruptedException, IOException
	{
        WebDriver driver = null;
		try
		{
            lastVisitorId = "Visitor id cannot be found from cookie";
			driver = TrackingLogin.setUp();
			VisitorWindow.createPage(driver,getTrackingEmbed(),getTrackingPortal());
			lastVisitorId = getVisitorIdFromVisDriver(driver);
		}
		catch(Exception e)
		{
			System.out.println("Exception while creating visitor page in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorPage","CreatePageError",e);
			Thread.sleep(1000);
			e.printStackTrace();
		}
		return driver;
	}
    
    public static WebDriver createPage(WebDriver driver) throws InterruptedException, IOException
    {
        try
        {
            lastVisitorId = "Visitor id cannot be found from cookie";
            
            VisitorWindow.createPage(driver,getTrackingEmbed(),getTrackingPortal());
            
            lastVisitorId = getVisitorIdFromVisDriver(driver);
        }
        catch(Exception e)
        {
            System.out.println("Exception while creating visitor page in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorPage","CreatePageError",e);
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return driver;
    }

	public static WebDriver referrerPage(String referrer) throws IOException, InterruptedException
	{
        WebDriver driver = null;
        
		try
		{
            lastVisitorId = "Visitor id cannot be found from cookie";
            
            driver = TrackingLogin.setUp();
            
			VisitorWindow.createPageReferrer(driver,getTrackingEmbed(),getTrackingPortal(),referrer);

			lastVisitorId = getVisitorIdFromVisDriver(driver);
		}
		catch(Exception e)
		{
			System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorPage","ReferrerPageError",e);
			Thread.sleep(1000);
			e.printStackTrace();
		}
		return driver;
	}
	
	public static WebDriver createCampaign(String cname) throws IOException, InterruptedException
	{
        WebDriver driver = null;
        
		try
		{
            lastVisitorId = "Visitor id cannot be found from cookie";
			driver = TrackingLogin.setUp();
            VisitorWindow.createPageCampaign(driver,getTrackingEmbed(),getTrackingPortal(),cname);
			lastVisitorId = getVisitorIdFromVisDriver(driver);
		}
		catch(Exception e)
		{
			System.out.println("Exception while creating campaign visitor page in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorPage","CampaignPageError",e);
			Thread.sleep(1000);
			e.printStackTrace();
		}
		return driver;
	}
	
	public static WebDriver createReferralPage() throws InterruptedException, IOException
	{
        WebDriver driver = null;
        
		try
		{
            lastVisitorId = "Visitor id cannot be found from cookie";
			driver = TrackingLogin.setUp();
            VisitorWindow.createPageReferrer(driver,getTrackingEmbed(),getTrackingPortal());
			lastVisitorId = getVisitorIdFromVisDriver(driver);
		}
		catch(Exception e)
		{
			System.out.println("Exception while creating referral visitor page in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisitorPage","ReferralPageError",e);
			Thread.sleep(1000);
			e.printStackTrace();
		}
		return driver;
	}

	public static String getLastVisitorId()
	{
		return lastVisitorId;
	}

	public static String getVisitorIdFromVisDriver(WebDriver driver) throws Exception
    {
    	String portalname = getTrackingPortal();

        return VisitorWindow.getVisitorId(driver,portalname);
    }

    public static String getTrackingEmbed()
    {
    	if(Util.isQuickAutomationSet())
    	{
    		return ConfManager.getRealValue("quicktrackingembed");
    	}
    	else
    	{
    		return ConfManager.getRealValue("trackingembed");
    	}
    }

    public static String getTrackingPortal()
    {
    	if(Util.isQuickAutomationSet())
    	{
    		return ConfManager.getRealValue("quicktrackingportal");
    	}
    	else
    	{
    		return ConfManager.getRealValue("trackingportal");
    	}
    }
}
