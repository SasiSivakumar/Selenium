//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class proActiveInter
{
	public static boolean continueButton(WebDriver driver,WebDriver visdriver) throws InterruptedException, IOException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			CommonFunctions.ruleVerifier(driver,1);

			CommonFunctions.proActiveChatNDept(driver);
			CommonFunctions.acceptProActive(visdriver);

			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Continue")!=null)
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ContinueButtonError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking continue button in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ContinueButtonError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean visReplyText(WebDriver driver) throws InterruptedException, IOException 
	{
		try
		{
			//CommonFunctions.visUVID(driver);
			
			CommonFunctions.clickVisitorRings(driver);

			WebElement chElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","chatdiv"),"classname","chatarea");
			String chatCont = CommonUtil.elementfinder(driver,chElmt,"xpath","//div[contains(@id,\"vinfo_LD_\")]").getText();

			if(chatCont.contains(ResourceManager.getRealValue("rings_visReply")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ReplyTextError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor reply text in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ReplyTextError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean myChatPage(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			//CommonFunctions.visUVID(driver);
			
			CommonFunctions.clickVisitorRings(driver);

			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Continue")!=null)
			{
				CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Continue").click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("msgtablediv")));
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txteditor")));

				CommonFunctions.clearChatWindow(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ChatPageError","MismatchContent");
			CommonFunctions.clearChatWindow(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking mychat page in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ChatPageError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean connectedTo(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{	
			//CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);

			String uname = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","hdrdrpdwntop"),"id","hdrdname").getText();

			CommonFunctions.clickVisitorRings(driver);

			WebElement pathElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","pathdetails");
			WebElement connElmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pathElmt,"id","pathurl"),"classname","overfldiv");
			String connTo = "";
			String compWith = CommonUtil.elementfinder(driver,connElmt,"tagname","a").getText();

			List<WebElement> paths = connElmt.findElements(By.tagName("p"));

			for(WebElement path:paths)
			{
				if(!(path.getAttribute("class").contains("arrw")))
				{
					connTo = path.getText();
				}
			}

			if(connTo.equals(ResourceManager.getRealValue("rings_connectedto")+uname))
			{
				if(compWith.equals(ResourceManager.getRealValue("rings_completedwith")+uname))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ConnectedToError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking connected to* in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ConnectedToError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean chatCompleted(WebDriver driver) throws InterruptedException, IOException 
	{
		try
		{
			//CommonFunctions.visUVID(driver);
			
			CommonFunctions.clickVisitorRings(driver);

			WebElement chElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","chatdiv"),"classname","chatarea");
			
            WebElement lstMsg = CommonUtil.elementfinder(driver,chElmt,"classname","tile_info");
			
			String chatCont = lstMsg.getText();

			if(chatCont.contains(ResourceManager.getRealValue("rings_chatCompleted")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ChatCompletedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking chat completed in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ChatCompletedError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean proActiveID(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			
			CommonFunctions.proActiveChatNDept(driver);
			CommonFunctions.acceptProActive(visdriver);
			
			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Continue").click();
			
			CommonFunctions.changeVisDetails(visdriver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.clickVisitorRings(driver);
			
			String vinfoElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","chatdiv"),"classname","vinfohdr").getText();
			
			if(vinfoElmt.contains("Anand Raja")&&vinfoElmt.contains("rajkumar.natarajan+223311@zohocorp.com"))
			{
				CommonFunctions.closeTilesUI(driver);
				CommonFunctions.clearChatWindow(driver);
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ProActiveIDError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			CommonFunctions.clearChatWindow(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking pro active chat with id in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveInter","ProActiveIDError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
}
