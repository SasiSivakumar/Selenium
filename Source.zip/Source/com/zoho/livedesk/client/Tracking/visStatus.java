//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.StaleElementReferenceException;

import com.google.common.base.Function;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;


import com.aventstack.extentreports.Status;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import com.zoho.livedesk.util.ChatUtil;
import java.util.List;
import java.io.File;

import java.util.Hashtable;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.NEW;
import org.junit.Assert;

import org.openqa.selenium.Keys;

import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentReports;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.zoho.livedesk.client.Tracking.TrackingRings;
import com.zoho.qa.server.WebdriverQAUtil;
import com.zoho.livedesk.util.*;
import org.openqa.selenium.JavascriptExecutor;
import com.zoho.livedesk.util.common.Functions;

import com.zoho.livedesk.util.common.CommonUtil;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.zoho.livedesk.util.common.VisitorWindow;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Function;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.NoSuchElementException;
import com.zoho.livedesk.util.common.CommonUtil;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.server.KeyManager;


public class visStatus
{
	public static boolean visAccessed(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			if("Available".contains(partition))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1"),"tagname","p").getText().equals("Accessed"))
					{
						CommonFunctions.closeTilesUI(driver);
						return true;
					}
				}
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisAccessedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor accessed in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisAccessedError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visClicked(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{	
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);

			viswait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));

			CommonUtil.elfinder(visdriver,"id","zlstxtcnt").click();
			viswait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zlsiframe")));

			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			String visitor_id = TrackingRings.vlist;

			if("Available".contains(partition))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1"),"tagname","p").getText().equals("Clicked"))
					{
						CommonFunctions.closeTilesUI(driver);

						checkVisitorStatusInTrackingRings(driver,visitor_id,VisitorStatus.CLICKED);

						return true;
					}
				}
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisClickedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);

			checkVisitorStatusInTrackingRings(driver,visitor_id,VisitorStatus.CLICKED);

			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor clicked in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisClickedError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visWaiting(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{	
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);

			viswait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));

			CommonUtil.elfinder(visdriver,"id","zlstxtcnt").click();
			viswait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zlsiframe")));

			visdriver.switchTo().frame(CommonUtil.elfinder(visdriver,"id","zlsiframe"));

			CommonUtil.elfinder(visdriver,"id","question").click();
			CommonUtil.elfinder(visdriver,"id","question").sendKeys("Missed chat?");

			CommonUtil.elfinder(visdriver,"id","btnaddvisitor").click();

			CommonFunctions.visSourceBox(driver);
			
			Thread.sleep(2000);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			if("Available".contains(partition))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1"),"tagname","p").getText().equals("Waiting"))
					{
						CommonFunctions.closeTilesUI(driver);
						return true;
					}
				}
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisWaitingError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking waiting visitor in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisWaitingError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visMissed(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{	
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);

			/*viswait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));

			CommonUtil.elfinder(visdriver,"id","zlstxtcnt").click();
			viswait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zlsiframe")));

			visdriver.switchTo().frame(CommonUtil.elfinder(visdriver,"id","zlsiframe"));

			CommonUtil.elfinder(visdriver,"id","question").click();
			CommonUtil.elfinder(visdriver,"id","question").sendKeys("Missed chat?");

			CommonUtil.elfinder(visdriver,"id","btnaddvisitor").click();*/

			FluentWait missedWaiter = CommonUtil.waitreturner(driver,80,1000);

			CommonFunctions.visSourceBox(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			CommonFunctions.closeTilesUI(driver);

			missedWaiter.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("Missed")));

			CommonFunctions.clickVisitorRings(driver);

			missedWaiter.until(new Function<WebDriver,Boolean>() {
				public Boolean apply(WebDriver driver) {
                    try
                    {
                        if(driver.findElement(By.cssSelector("div#vistinfodiv .detbox.box1")).findElement(By.tagName("p")).getText().equals("Missed"))
                        {
                            return true;
                        }
                    }
                    catch(StaleElementReferenceException excep)
                    {}
					return false;
				}
			});

			pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			partelmt = CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1");

			partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

            if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"css","div.detbox.box1"),"tagname","p").getText().equals("Missed"))
            {
                CommonFunctions.closeTilesUI(driver);
                return true;
            }
            
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisMissedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking missed visitor in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisMissedError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean visContacted(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			String visitor_id = TrackingRings.vlist;


			CommonFunctions.proActiveChatNDept(driver);

			/*CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
					{
						return true;
					}
					return false;
				}
			});
			*/
            
			Thread.sleep(2000);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","vistinfo");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"id","vstatus");

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			if((partition.equals("Available"))&&(CommonUtil.elementfinder(driver,partelmt,"tagname","p").getText().equals("Contacted")))
			{
				CommonFunctions.closeTilesUI(driver);

				checkVisitorStatusInTrackingRings(driver,visitor_id,VisitorStatus.CONTACTED);

				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisContactedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);

			checkVisitorStatusInTrackingRings(driver,visitor_id,VisitorStatus.CONTACTED);

			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking contacted in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisContactedError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean visResponded(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{
			//CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.acceptProActive(visdriver);
			CommonFunctions.waitRings(driver);


	        String visitor_id = TrackingRings.vlist;






			CommonFunctions.clickVisitorRings(driver);

			/*CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
					{
						return true;
					}
					return false;
				}
			});
			*/

            Thread.sleep(2000);
            
            WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","vistinfo");
            
            WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"id","vstatus");
            
            String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");
			
			if((partition.equals("Available"))&&(CommonUtil.elementfinder(driver,partelmt,"tagname","p").getText().equals("Responded")))
			{
				CommonFunctions.closeTilesUI(driver);

				checkVisitorStatusInTrackingRings(driver,visitor_id,VisitorStatus.RESPONDED);

				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisRespondedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);

			checkVisitorStatusInTrackingRings(driver,visitor_id,VisitorStatus.RESPONDED);

			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor responded in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisRespondedError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean visCompleted(WebDriver driver,WebDriver visdriver,ExtentTest etest) throws InterruptedException, IOException
	{
		try
		{
			//CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			
			ChatWindow.acceptChat(driver,etest);
			CommonFunctions.clearChatWindow(driver);
			CommonFunctions.waitRings(driver);
			CommonFunctions.clickVisitorRings(driver);
			
            /*
			CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
					{
						return true;
					}
					return false;
				}
			});
			*/
            
            Thread.sleep(2000);
            
            WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","vistinfo");
            
            WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"id","vstatus");
            
            String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			if((partition.equals("Available"))&&(CommonUtil.elementfinder(driver,partelmt,"tagname","p").getText().equals("Chat Completed")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisCompletedError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking chat completed in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","VisCompletedError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static void checkVisitorStatusInTrackingRings(WebDriver driver,String visitor_id,VisitorStatus visitor_status) throws Exception
	{
			String test_case_key=getTestCaseKey(visitor_status);

			boolean isExpectedStatusFoundInRings=false;

			try
			{
	            isExpectedStatusFoundInRings=isExpectedVisitorStatusFoundInTrackingRings(driver,visitor_id,visitor_status);

	            if(isExpectedStatusFoundInRings)
	            {
	                TrackingRings.etest.log(Status.PASS,visitor_status+" visitor status is shown in Tracking Rings");
	            }
	            else
	            {
	                TrackingRings.etest.log(Status.FAIL,visitor_status+" visitor status is NOT shown in Tracking Rings");
	                TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking Rings Visitor Status","Failure","Operator window screenshot");  
	            }

			}

			catch(Exception e)
			{
				e.printStackTrace();
				TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","VisStatus","checkVisitorStatusInTrackingRings",e);
			}
 			
 			finally
 			{
	            TrackingRings.result.put(test_case_key,isExpectedStatusFoundInRings);
 			}

	}

	public static String getTestCaseKey(VisitorStatus visitor_status)
	{
		String test_case_name="RINGS";

		if(visitor_status==VisitorStatus.CLICKED)
		{
			return test_case_name+"91";
		}

		else if(visitor_status==VisitorStatus.CONTACTED)
		{
			return test_case_name+"96";
		}

		else if(visitor_status==VisitorStatus.RESPONDED)
		{
			return test_case_name+"97";
		}

		return null;
	}

    public static boolean checkPageNavigationAnimationInRings(WebDriver driver,String EMBED_NAME,String PORTAL_NAME,ExtentTest etest)
    {
        WebDriver visitor_driver=null;

        String visitor_id=null;
        int failcount=0;

        checkPageNavigationAnimationInRingsResult=false;

        try
        {

            Tab.clickVisitorsOnline(driver);
			CommonFunctions.viewCheck(driver,"Rings");

            try
            {                
                visitor_driver=Functions.setUp();
                VisitorWindow.createPage(visitor_driver,EMBED_NAME,PORTAL_NAME);
                visitor_id=VisitorWindow.getVisitorId(visitor_driver,PORTAL_NAME);
            }

            catch(Exception exp1)
            {
                exp1.printStackTrace();
                TakeScreenshot.screenshot(driver,etest,"Tracking Rings Visitor Status","Agent Failure","Error at Agent Window",exp1);
                return false;
            }



            VisitorsOnline.waitTillVisitorPresent(driver,visitor_id);                
            VisitorsOnline.waitTillVisitorStableInRings(CommonUtil.getElement(driver,By.id(visitor_id)),"");

            Thread.sleep(5000);

            startPageNavigatedUserThread(driver,visitor_id,etest);
            startPageNavigatedVisitorThread(visitor_driver,EMBED_NAME,PORTAL_NAME,etest);


            FluentWait wait=CommonUtil.waitreturner(driver,20,250);
            try
            {
                wait.until(new Function<WebDriver,Boolean>()
                {
                    public Boolean apply(WebDriver driver)
                    {
                        if(isUserAndVisitorThreadCompleted==2)
                        {
                            return true;
                        }
                        return false;
                    }
                });
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            finally
            {
                isUserAndVisitorThreadCompleted=0;
            }


        }

        catch(Exception e)
        {
            failcount++;
            e.printStackTrace();
            TakeScreenshot.screenshot(driver,etest,"Tracking Rings","checkStatusInTrackingRings","Exception",e);
        }

        finally
        {
            TrackingRings.quitDriver(visitor_driver);
        }

        return checkPageNavigationAnimationInRingsResult;
    }

    public static Boolean checkRepeatedVisitor(WebDriver driver,String EMBED_NAME,String PORTAL_NAME,VisitorStatus visitor_status,TrackingRings.TestStatus test_status,String test_case_key)
    {

        String TEST_CASE_KEY=test_case_key;        

        if(test_status==TrackingRings.TestStatus.BEGIN_TEST)
        {
		    ExtentTest etest=ComplexReportFactory.getTest(KeyManager.getRealValue(TEST_CASE_KEY));
		    ComplexReportFactory.setValues(etest,"Automation","Tracking - Rings");            
            TrackingRings.extent_test.put(TEST_CASE_KEY,etest);

            WebDriver visitor_driver=null;

            TrackingRings.is_continue_test.put(TEST_CASE_KEY,false);

            try
            {
                Tab.clickVisitorsOnline(driver);
				CommonFunctions.viewCheck(driver,"Rings");


                try
                {                
                    visitor_driver=Functions.setUp();
                    VisitorWindow.createPage(visitor_driver,EMBED_NAME,PORTAL_NAME);
                    TrackingRings.continue_visitor_driver.put(TEST_CASE_KEY,visitor_driver);                    
                    String visitor_id=VisitorWindow.getVisitorId(visitor_driver,PORTAL_NAME);
                    VisitorsOnline.waitTillVisitorPresent(driver,visitor_id);

                    if(visitor_status==VisitorStatus.REPEATED_CHAT)
                    {
                        String visitor_label=CommonUtil.getUniqueMessage();
                        String
                        visitor_name="v_"+visitor_label,
                        visitor_email=visitor_label+"@email.com",
                        visitor_phone_number="9876543210",
                        visitor_question="v_ques_"+visitor_label;

                        VisitorWindow.clickChatButton(visitor_driver);
                        VisitorWindow.initiateChatVis(visitor_driver,visitor_name,visitor_email,visitor_phone_number,visitor_question,etest);
                        //VisitorWindow.initiateChatVisTheme(visitor_driver,visitor_name,visitor_email,null,visitor_question,etest);//~ change this as per chat widget of portal

                        ChatWindow.acceptChat(driver,etest);

                        ChatWindow.endAndCloseChat(driver);

                        Tab.clickVisitorsOnline(driver);

                    }

                    visitor_driver.navigate().refresh();//to make visitor leave page

                    TrackingRings.continue_visitor_id.put(TEST_CASE_KEY,visitor_id);
                    TrackingRings.continue_visitor_driver.put(TEST_CASE_KEY,visitor_driver);
                    TrackingRings.extent_test.put(TEST_CASE_KEY,etest);
                }

                catch(Exception exp1)
                {
                    TrackingRings.continue_visitor_driver.put(TEST_CASE_KEY,visitor_driver);
                    exp1.printStackTrace();
                    TakeScreenshot.screenshot(driver,etest,"Tracking Rings Visitor Status","Agent Failure","Error at Agent Window",exp1);
                    ComplexReportFactory.closeTest(etest);
                    return false;
                }
                
            }

            catch(Exception e)
            {
                e.printStackTrace();
                TakeScreenshot.screenshot(driver,etest,"Tracking Rings","checkStatusInTrackingRings","Exception",e);
            }

            finally
            {

            }

            TrackingRings.is_continue_test.put(TEST_CASE_KEY,true);

            return null;
        }

        else if(test_status==TrackingRings.TestStatus.CONTINUE_TEST)
        {
        	System.out.println("CONTINUE_TEST "+visitor_status);

            ExtentTest etest=TrackingRings.extent_test.get(TEST_CASE_KEY);

            WebDriver visitor_driver=null;

            int failcount=0;

            try
            {

                if(TrackingRings.is_continue_test.get(TEST_CASE_KEY))
                {
                    Tab.clickVisitorsOnline(driver);
        			CommonFunctions.viewCheck(driver,"Rings");


                    String visitor_id=TrackingRings.continue_visitor_id.get(TEST_CASE_KEY);
                    visitor_driver=TrackingRings.continue_visitor_driver.get(TEST_CASE_KEY);

                    VisitorsOnline.waitTillVisitorLeaves(driver,visitor_id);

                    VisitorWindow.createPage(visitor_driver,EMBED_NAME,PORTAL_NAME);

                    VisitorsOnline.waitTillVisitorPresent(driver,visitor_id);

                    boolean isRepeatedStatusFound=isExpectedVisitorStatusFoundInTrackingRings(driver,visitor_id,visitor_status);

                    if(isRepeatedStatusFound)
                    {
                        etest.log(Status.PASS,visitor_status+" status is shown in Tracking Rings");
                    }
                    else
                    {
                        etest.log(Status.FAIL,visitor_status+" status is NOT shown in Tracking Rings");
                        TakeScreenshot.screenshot(driver,etest,"Tracking Rings Visitor Status","Failure","Operator window screenshot");  
                        failcount++;   
                    }

                    return CommonUtil.returnResult(failcount);
                }

                else
                {
                    TrackingRings.quitDriver(visitor_driver);
                    return false;
                }

            }

            catch(Exception e)
            {
                e.printStackTrace();
                TakeScreenshot.screenshot(driver,etest,"Tracking Rings","checkStatusInTrackingRings","Exception",e);
            }

            finally
            {
                TrackingRings.quitDriver(visitor_driver);
                ComplexReportFactory.closeTest(etest);
            }

            return false;
        }

        return null;
    }

    
    public static boolean checkTriggeredStatusInRings(WebDriver driver,String EMBED_NAME,String PORTAL_NAME,ExtentTest etest)
    {
        WebDriver visitor_driver=null;

        String visitor_id=null;
        int failcount=0;

        try
        {

            // Trigger.addTrigger(driver,etest,"Lands on my website","Time on Site","is more than","2 Seconds",null,"Glow button","2 Seconds",null,null);
           Trigger.addTrigger(driver,etest,"Lands on my website","Visitor Type","is equal to","All",null,"Send chat invite","3 Seconds","Automation","Hey!!!");


            Tab.clickVisitorsOnline(driver);
			CommonFunctions.viewCheck(driver,"Rings");


            try
            {                
                visitor_driver=Functions.setUp();
                VisitorWindow.createPage(visitor_driver,EMBED_NAME,PORTAL_NAME);
                visitor_id=VisitorWindow.getVisitorId(visitor_driver,PORTAL_NAME);
            }

            catch(Exception exp1)
            {
                exp1.printStackTrace();
                TakeScreenshot.screenshot(driver,etest,"Tracking Rings Visitor Status","Visitor Failure","Error at Visitor Window",exp1);
                return false;
            }

            VisitorsOnline.waitTillVisitorPresent(driver,visitor_id);                
            VisitorsOnline.waitTillVisitorStableInRings(CommonUtil.getElement(driver,By.id(visitor_id)),"");


            boolean isTriggeredStatusFound=isExpectedVisitorStatusFoundInTrackingRings(driver,visitor_id,VisitorStatus.TRIGGERED);

            if(isTriggeredStatusFound)
            {
                etest.log(Status.PASS,"Triggered status is shown in Tracking Rings");
            }
            else
            {
                etest.log(Status.FAIL,"Triggered status is NOT shown in Tracking Rings");
                TakeScreenshot.screenshot(driver,etest,"Tracking Rings Visitor Status","Failure","Operator window screenshot");  
                failcount++;     
            }


        }

        catch(Exception e)
        {
            failcount++; 
            e.printStackTrace();
            TakeScreenshot.screenshot(driver,etest,"Tracking Rings","checkTriggeredStatusInRings","Exception",e);
        }

        finally
        {
           TrackingRings.quitDriver(visitor_driver);

           try
           {
           		Cleanup.deleteAllTriggers(driver);
	           Tab.clickVisitorsOnline(driver);
           }
           catch(Exception exp)
           {
           		exp.printStackTrace();
           		System.out.println("~~CleanUpError~~Delete All Triggers");
           } 
        }

        return CommonUtil.returnResult(failcount);
    }

    public enum VisitorStatus
    {
        CLICKED("status1"),
        CONTACTED("status3"),
        RESPONDED("status4"),
        REPEATED_USER("ruser"),
        REPEATED_CHAT("rchats"),
        TRIGGERED("gspritebg"),
        PAGE_NAVIGATED("animatestr");//special use case
        
        String class_name;
        
        VisitorStatus(String status_class_name)
        {
            class_name=status_class_name;
        }
        
    }

    public static Boolean isExpectedVisitorStatusFoundInTrackingRings(WebDriver driver,final String visitor_id,final VisitorStatus expected_status)
    {

    	try
    	{
	    	if(expected_status==VisitorStatus.CLICKED || expected_status==VisitorStatus.CONTACTED || expected_status==VisitorStatus.RESPONDED)
	        {
	            String found_status=null;
	            String expected_status_string=expected_status.class_name;

	            found_status=getVisitorClassFromTrackingRings(driver,visitor_id);

	            if(found_status.contains(expected_status_string))
	            {
	                return true;
	            }

	            else
	            {
	                return false;
	            }

	        }

	        else if(expected_status==VisitorStatus.PAGE_NAVIGATED)
	        {
	            FluentWait wait=CommonUtil.waitreturner(driver,20,250);
	            try
	            {
	                wait.until(new Function<WebDriver,Boolean>()
	                {
	                    public Boolean apply(WebDriver driver)
	                    {
	                        if(CommonUtil.getElement(driver,By.id(visitor_id),By.className(expected_status.class_name)).isDisplayed())
	                        {
	                            return true;
	                        }
	                        return false;
	                    }
	                });
	            }
	            catch(Exception e)
	            {
	                e.printStackTrace();
	                return false;
	            }

	            return true;
	        }

	        else if(expected_status==VisitorStatus.REPEATED_USER || expected_status==VisitorStatus.REPEATED_CHAT)
	        {
	            FluentWait wait=CommonUtil.waitreturner(driver,10,250);
	            try
	            {
	                wait.until(new Function<WebDriver,Boolean>()
	                {
	                    public Boolean apply(WebDriver driver)
	                    {
	                        if(CommonUtil.getElement(driver,By.id(visitor_id)).findElements(By.className(expected_status.class_name)).size()==1)
	                        {
	                            return true;
	                        }
	                        return false;
	                    }
	                });
	            }
	            catch(Exception e)
	            {
	                e.printStackTrace();
	                return false;
	            }

	            return true;
	        }

	        else if(expected_status==VisitorStatus.TRIGGERED)
	        {
	            FluentWait wait=CommonUtil.waitreturner(driver,10,250);
	            try
	            {
	                wait.until(new Function<WebDriver,Boolean>()
	                {
	                    public Boolean apply(WebDriver driver)
	                    {
	                        if(CommonUtil.getElement(driver,By.id(visitor_id)).findElements(By.xpath(".//span[contains(@class,'"+expected_status.class_name+"')]")).size()==1)
	                        {
	                            return true;
	                        }
	                        return false;
	                    }
	                });
	            }
	            catch(Exception e)
	            {
	                e.printStackTrace();
	                return false;
	            }

	            return true;
	        }


	        return null;

    	}

    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return false;
    	}

    }

    public static boolean isPageNavigatedAnimationSeenInRings(WebDriver driver,String visitor_id) throws Exception
    {
        return isExpectedVisitorStatusFoundInTrackingRings(driver,visitor_id,VisitorStatus.PAGE_NAVIGATED);
    }

    public static String getVisitorClassFromTrackingRings(WebDriver driver,String visitor_id)
    {
        String visitor_element_class=CommonUtil.getElement(driver,By.id(visitor_id)).getAttribute("class").toString();
        return visitor_element_class;
    }

    public static Boolean initiateProactiveChatForLiveChatWithNoDeptSelection(WebDriver driver,String visitor_id) throws IOException, InterruptedException
    {
        try
        {            
        	VisitorsOnline.clickVisitor(CommonUtil.getElement(driver,By.id(visitor_id)));

            Thread.sleep(500);

            WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");

            WebElement kelmt = CommonUtil.elementfinder(driver,pelmt,"tagname","textarea");

            kelmt.sendKeys("Welcome to Zoho");

            Thread.sleep(500);

            kelmt.sendKeys(Keys.RETURN);

            // if(CommonUtil.elementfinder(driver,pelmt,"linktext",ResourceManager.getRealValue("rings_proactive"))==null)
            // {
            //     CommonFunctions.closeTilesUI(driver);
            //     return false;
            // }

            CommonFunctions.closeTilesUI(driver);
            return true;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking pro active chat with one dept in visitor tracking module : ");
            Thread.sleep(1000);
            e.printStackTrace();
            CommonFunctions.closeTilesUI(driver);

            return null;
        }
    }

    public enum DriverType
    {
        VISITOR_DRIVER,
        USER_DRIVER;
    }

    public static void startPageNavigatedVisitorThread(WebDriver visitor_driver,String embed_name,String portal_name,ExtentTest test) throws Exception
    {
        startPageNavigatedThread(visitor_driver,"",embed_name,portal_name,DriverType.VISITOR_DRIVER,test);
    }

    public static void startPageNavigatedUserThread(WebDriver user_driver,String visitor_id,ExtentTest test) throws Exception
    {
        startPageNavigatedThread(user_driver,visitor_id,"","",DriverType.USER_DRIVER,test);
    }


    public static int isUserAndVisitorThreadCompleted=0;
    public static boolean checkPageNavigationAnimationInRingsResult=false;

    public static void startPageNavigatedThread(final WebDriver driver,final String visitor_id,final String embed_name,final String portal_name,final DriverType driver_type,final ExtentTest test) throws Exception
    {
        Thread t = new Thread(new Runnable() 
        {
            public void run()
            {
                try
                {
                    if(driver_type==DriverType.VISITOR_DRIVER)
                    {
                          VisitorWindow.createPageCampaign(driver,embed_name,portal_name,"PAGE_NAVIGATED");//page campaign is created only for simulating page navigation
                          test.log(Status.INFO,"Page navigated in visitor window");

                          isUserAndVisitorThreadCompleted++;

                          System.out.println("~~startPageNavigatedThread VISITOR_ENDS");
                    }

                    else if(driver_type==DriverType.USER_DRIVER)
                    {
                        test.log(Status.INFO,"Checking for presence of page navigation animation.");

                        if(isPageNavigatedAnimationSeenInRings(driver,visitor_id))
                        {
                            test.log(Status.PASS,"Page navigated animation was seen in tracking rings");
                            checkPageNavigationAnimationInRingsResult=true;
                        }

                        else
                        {
                            test.log(Status.FAIL,"Page navigated animation was NOT seen in tracking rings");
                            TakeScreenshot.screenshot(driver,test,"Tracking Rings Visitor Status","Failure","Operator window screenshot");
                        }

                        isUserAndVisitorThreadCompleted++;

                        System.out.println("~~startPageNavigatedThread USER_ENDS");
                    }
                }

                catch(Exception exp)
                {
                  test.log(Status.INFO,"Exception during Page navigating in visitor window");
                  TakeScreenshot.screenshot(driver,test,"Tracking Rings","startPageNavigatedThread","Exception",exp);
                  exp.printStackTrace();

          		  isUserAndVisitorThreadCompleted++;
                  
                }


            }
        });

        t.start();

        System.out.println("~~Thread Started "+driver_type);
    }  



}
