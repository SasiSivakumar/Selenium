//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class initialIncomingVisitorList
{
	public static boolean incomingVisitor(WebDriver driver) throws InterruptedException, IOException
	{
		//WebDriver visdriver = null;
		try
		{ 
			//visdriver = VisitorSite.createPage();
			
			FluentWait waiter = CommonUtil.waitreturner(driver,30,200);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"List");
			
			/*try
			{
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'visit_div')]")));
			}
			catch(Exception e)
			{
				CommonUtil.elfinder(driver, "id", "othervisit").click();
				
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("listpriority5")));
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'visit_div')]")));
			}*/
			CommonFunctions.visUVID(driver);
			try
			{
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id(TrackingRings.vlist)));
			}
			catch(Exception e)
			{
				CommonUtil.elfinder(driver, "id", "othervisit").click();
				
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("listpriority5")));
				waiter.until(ExpectedConditions.presenceOfElementLocated(By.id(TrackingRings.vlist)));
			}
			
			//visdriver.quit();
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking incoming visitor in list view in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","IncomingVisitorList","ListVisitorError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			//visdriver.quit();
			return false;
		}
	}
}
