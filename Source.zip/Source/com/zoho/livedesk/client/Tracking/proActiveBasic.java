//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

import com.zoho.livedesk.util.common.actions.Tab;
import com.zoho.livedesk.util.common.actions.ChatWindow;

public class proActiveBasic
{
	public static boolean tilesBox(WebDriver driver) throws InterruptedException, IOException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.proActiveChatNDept(driver);

			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"classname","vistinfo"),"classname","tile_box")!=null)
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesDownIconError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while clicking tiles down icon in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesDownIconError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean tilesInvi(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.proActiveChatNDept(driver);

			if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("none"))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesInvisError","Visible");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking tiles invis in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesInvisError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean tilesDownIcoVis(WebDriver driver) throws InterruptedException, IOException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.proActiveChatNDept(driver);

			CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
					{
						return true;
					}
					return false;
				}
			});

			if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesDownIconVisError","NotVisible");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking tiles down icon vis in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesDownIconVisError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean tilesUpIco(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.proActiveChatNDept(driver);

			CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
					{
						return true;
					}
					return false;
				}
			});

			Thread.sleep(2000);

			if(CommonUtil.elfinder(driver,"id","chatdiv").getAttribute("class").contains("uparr"))
			{
				CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

				wait.until(new Function<WebDriver,Boolean>()
				{
					public Boolean apply(WebDriver driver)
					{
						if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("none"))
						{
							return true;
						}
						return false;
					}
				});
				
				Thread.sleep(1000);

				if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("none"))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesUpIconError","MismatchClassName");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking tiles up icon in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","TilesUpIconError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean visStatusChat(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonFunctions.proActiveChatNDept(driver);

			/*CommonUtil.elfinder(driver,"xpath","//div[@id='chatdiv']//div[contains(@class,'sqico-info')]").click();

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("block"))
					{
						return true;
					}
					return false;
				}
			});
			
			Thread.sleep(2000);*/

            WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","vistinfo");
            
            WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"id","vstatus");
            
            String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			if((partition.equals("Available"))&&(CommonUtil.elementfinder(driver,partelmt,"tagname","p").getText().equals("Contacted")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","VisStatusChatError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor status in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","VisStatusChatError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean placeHolders(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			
			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);
			
			CommonFunctions.clickVisitorRings(driver);
			
			String befQues = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"tagname","textarea").getAttribute("placeholder");
			
			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");

			WebElement kelmt = CommonUtil.elementfinder(driver,pelmt,"tagname","textarea");

			kelmt.sendKeys("Welcome to Zoho");
			kelmt.sendKeys(Keys.RETURN);

			Thread.sleep(500);

			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					if(driver.findElement(By.id("vistinfodiv")).getAttribute("style").contains("none"))
					{
						return true;
					}
					return false;
				}
			});
			
			String afterques = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"tagname","textarea").getAttribute("placeholder");
			
			if(befQues.equals(ResourceManager.getRealValue("rings_befques"))&&afterques.equals(ResourceManager.getRealValue("rings_afterques")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","PlaceHolderError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking placeholders in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","PlaceHolderError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean buttonSend(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.proActiveChatNDept(driver);
			
			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Send")!=null)
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","SendButtonError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking send button in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","SendButtonError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean checkChatIniName(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.proActiveChatNDept(driver);
			
			WebElement chatNameelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","pathdetails");
			String chatName = CommonUtil.elementfinder(driver,chatNameelmt,"tagname","span").getText();
			String chatStatus = CommonUtil.elementfinder(driver, chatNameelmt,"tagname","em").getAttribute("class");
			
			if(chatName.equals("Me")&&chatStatus.equals("status_1"))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","ChatIniNameError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking chat initiator name in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","ChatIniNameError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean visStatus(WebDriver driver,WebDriver visdriver,String status,ExtentTest etest) throws Exception
	{
		try
		{
            if(status.equals("engaged"))
            {
                CommonFunctions.changePortalSettingsCC(driver,true);
            }
            
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.proActiveChatNDept(driver);
			
			Thread.sleep(500);
			String excode = CommonUtil.elfinder(driver,"id","maskdiv").getAttribute("onclick");
			
			CommonUtil.JSExecutor(driver, excode);
			
			String mystat = "";
			
			if(status.equals("available"))
			{
				mystat = "status_1";
				CommonFunctions.changeStatus(driver,status);
			}
			else if(status.equals("busy"))
			{
				mystat = "status_3";
				CommonFunctions.changeStatus(driver,status);
			}
			else if(status.equals("engaged"))
			{
				mystat = "status_6";
				CommonFunctions.changeStatus(driver,"available");
				CommonFunctions.acceptProActive(visdriver);
				Thread.sleep(5000);
				ChatWindow.acceptChat(driver,etest);
			}
			
			Tab.clickVisitorsOnline(driver);
			CommonFunctions.clickVisitorRings(driver);
			
			WebElement chatNameelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","pathdetails");
			String chatStatus = CommonUtil.elementfinder(driver, chatNameelmt,"tagname","em").getAttribute("class");
			
			if(chatStatus.equals(mystat))
			{
				CommonFunctions.closeTilesUI(driver);
				if(status.equals("engaged"))
				{
                    CommonFunctions.changePortalSettingsCC(driver,false);
					CommonFunctions.clearChatWindow(driver);
					CommonFunctions.waitRings(driver);
				}
				return true;
			}
			
			if(status.equals("engaged"))
			{
                TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","VisStatusTilesError","MismatchContent");
                CommonFunctions.closeTilesUI(driver);
                CommonFunctions.changePortalSettingsCC(driver,false);
				CommonFunctions.clearChatWindow(driver);
				CommonFunctions.waitRings(driver);
				return false;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","VisStatusTilesError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor status in tilesui in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","ProActiveBasic","VisStatusTilesError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
            CommonFunctions.changePortalSettingsCC(driver,false);
			return false;
		}
	}
}
