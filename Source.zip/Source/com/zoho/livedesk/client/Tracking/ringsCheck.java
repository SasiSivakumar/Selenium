//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.google.common.base.Function;

import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ringsCheck
{
	public static boolean visFlag(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

            if(!CommonFunctions.ruleCheck(driver,1))
			{
				CommonFunctions.ruleApp(driver,1);
			}

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));

			String ringFlag = CommonUtil.elfinder(driver,"id",visId).getAttribute("class");
			String ringsCountry = CommonUtil.elfinder(driver,"id",visId).getAttribute("title");
            
            TrackingRings.etest.log(Status.INFO,"Flag in rings:"+ringFlag+"<>");
            TrackingRings.etest.log(Status.INFO,"Country in rings:"+ringsCountry+"<>");
            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","CheckBefore",0);

			CommonFunctions.clickVisitorRings(driver);

			WebElement felmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","chatdiv"),"classname","rcvstinforhtxt");

			String tilesFlag = CommonUtil.elementfinder(driver,felmt,"tagname","span").getAttribute("class").replace(" gspritebg","");
			String tilesCountry = CommonUtil.elementfinder(driver,felmt,"tagname","span").getAttribute("title");

            TrackingRings.etest.log(Status.INFO,"Flag in Popup:"+tilesFlag+"<>");
            TrackingRings.etest.log(Status.INFO,"Country in Popup:"+tilesCountry+"<>");
            
            if(ringFlag.contains(tilesFlag))
			{
				if(ringsCountry.equals(tilesCountry))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisFlagError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor flag in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisFlagError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visName(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			if(!CommonFunctions.ruleCheck(driver,1))
			{
				CommonFunctions.ruleApp(driver,1);
			}

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));

			String ringName = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id",visId),"classname","txtelips").getText();
			CommonFunctions.clickVisitorRings(driver);

			//String visid = CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visit_div')]").getAttribute("id");
			WebElement felmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","chatdiv"),"id","infoname_"+visId);
			String tilesName = felmt.getText();

			if(ringName.contains(tilesName))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisNameError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor name in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisNameError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean viStatus(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			CommonFunctions.ruleVerifier(driver,1);

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);

			viswait.until(ExpectedConditions.presenceOfElementLocated(By.id("zlscht")));

			CommonUtil.elfinder(visdriver,"id","zlstxtcnt").click();
			viswait.until(ExpectedConditions.visibilityOfElementLocated(By.id("zlsiframe")));

			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(visId)));
            
			CommonFunctions.waitRings(driver);

            final WebElement e = CommonUtil.elfinder(driver,"id",visId);
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(e.getAttribute("title").contains("Clicked"))
                    {
                        return true;
                    }
                    return false;
                }
            });
            
			String ringStatus = e.getAttribute("title");
			
			CommonFunctions.clickVisitorRings(driver);

			WebElement felmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","vistinfodiv"),"id","vstatus");
			String tilesStatusclass = CommonUtil.elementfinder(driver,felmt,"tagname","span").getAttribute("class").replace("sqico-t","");
			String tilesStatus = CommonUtil.elementfinder(driver,felmt,"tagname","p").getText();

			if(ringStatus.contains(tilesStatus))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
            
            System.out.println(ringStatus+"<>"+tilesStatus+"<>");
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisStatusError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor status in rings in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisStatusError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visStar(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			CommonFunctions.ruleVerifier(driver,1);
			CommonFunctions.clickVisitorRings(driver);
			
			WebElement felmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","chatdiv");
			WebElement selmt = CommonUtil.elementfinder(driver,felmt,"classname","repeatedstar");
			
			String ringsStar = selmt.getText();
			String ringsTitle = selmt.getAttribute("title");
			
			if(ringsStar.equals("*")&&ringsTitle.equals(ResourceManager.getRealValue("rings_repeatedVisitor")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisStarError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking star icon in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","RingsCheck","VisStarError",e);
			Thread.sleep(1000);
			//.printStackTrace();
			return false;
		}
	}
}
