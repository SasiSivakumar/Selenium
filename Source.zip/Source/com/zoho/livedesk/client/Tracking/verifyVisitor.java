//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class verifyVisitor
{
	public static boolean visRings(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			CommonFunctions.ruleApp(driver,1);

			CommonFunctions.clickVisitorRings(driver);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
			CommonFunctions.closeTilesUI(driver);

			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while verifying visitor in rings in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","tracking","onlineclick",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean visList(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"List");

			CommonFunctions.ruleApp(driver,1);

			FluentWait wait = CommonUtil.waitreturner(driver,30,250);

			CommonUtil.elfinder(driver,"classname","tlistview").click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#listpriority1 .visit_div")));
			String visID = TrackingRings.vlist;//CommonUtil.elfinder(driver,"css","#listpriority1 .visit_div").getAttribute("id");
            		CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","listpriority1"),"id",visID),"tagname","span").click();
			//CommonUtil.elfinder(driver,"id","list_name_"+visID).click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

			CommonFunctions.closeTilesUI(driver);

			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while verifying visitor in list in visitor tracking module : ");//Exception while clicking visitors online tab :
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","tracking","onlineclick",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}
}
