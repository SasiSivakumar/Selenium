//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import com.zoho.livedesk.util.common.actions.ChatWindow;
import com.aventstack.extentreports.ExtentTest;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class chatBasics	
{
	public static boolean pickUpButton(WebDriver driver,WebDriver visdriver) throws IOException, InterruptedException 
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);
			
			CommonFunctions.visUVID(driver);

			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			CommonFunctions.initiateChat(visdriver);
			CommonFunctions.clickVisitorRings(driver);

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wcancel")));

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","visitdetails");
			String chatelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"id","startcht"),"tagname","a").getText();

			if(chatelmt.equals("Pickup"))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","PickUpError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking pickup button after chat initiation in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","PickUpError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean pickUpAccept(WebDriver driver,WebDriver visdriver,ExtentTest etest) throws InterruptedException, IOException
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);

			//CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			CommonFunctions.clickVisitorRings(driver);

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wcancel")));

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","visitdetails");
			WebElement chatelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"id","startcht"),"tagname","a");

			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Pickup")!=null)
			{
				ChatWindow.acceptChat(driver,etest);

				CommonFunctions.clearChatWindow(driver);
				return true;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","PickUpAcceptError","MismatchContent");
			CommonFunctions.clearChatWindow(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking pickup accept in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","PickUpAcceptError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
	
	public static boolean chatNameTilesUI(WebDriver driver,WebDriver visdriver,ExtentTest etest) throws IOException, InterruptedException
	{
		try
		{
			FluentWait wait = CommonUtil.waitreturner(driver,30,250);
			FluentWait viswait = CommonUtil.waitreturner(visdriver,30,250);

			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			CommonFunctions.initiateChatId(visdriver);
			CommonFunctions.clickVisitorRings(driver);

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wcancel")));

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","visitdetails");
			WebElement chatelmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"id","startcht"),"tagname","a");

			if(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"linktext","Pickup")!=null)
			{
				ChatWindow.acceptChat(driver,etest);

				CommonFunctions.clearChatWindow(driver);
				
				CommonFunctions.waitRings(driver);
				CommonFunctions.clickVisitorRings(driver);
				
				String vinfoElmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","chatdiv"),"classname","vinfohdr").getText();
				
				if(vinfoElmt.contains("Anand R")&&vinfoElmt.contains("rajkumar.natarajan+143@zohocorp.com"))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
				
				TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","ChatNameError","MismatchContentInVisitorDetails");
				CommonFunctions.closeTilesUI(driver);
				return false;
			}
			
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","ChatNameError","MismatchContent");
			CommonFunctions.clearChatWindow(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking chat name in tilesui in visitor tracking : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","BasicChat","ChatNameError",e);
			Thread.sleep(1000);
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
}
