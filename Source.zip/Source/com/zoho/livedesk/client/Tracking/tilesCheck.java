//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.*;

public class tilesCheck
{
	public static boolean tilesUICheckPartition(WebDriver driver,String partName,String finder) throws InterruptedException, IOException
	{
		try
		{	
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			CommonSikuli.findInWholePage(driver,CommonSikuli.getTileNameBeforeIntiate(partName),CommonSikuli.getKeyValueBeforeIntiateChat(partName),TrackingRings.etest);

			//System.out.println(CommonSikuli.getTileNameBeforeIntiate(partName) + CommonSikuli.getKeyValueBasedTile(partName));
			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			WebElement partelmt = CommonUtil.elementfinder(driver,pelmt,"css",finder);

			String partition = CommonUtil.elementfinder(driver,partelmt,"tagname","span").getAttribute("title");

			if(partName.contains(partition))
			{
				if(CommonFunctions.mouseOverTitle(driver,CommonUtil.elementfinder(driver,partelmt,"tagname","span")))
				{
					CommonFunctions.closeTilesUI(driver);
					return true;
				}
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","TileUIPartition","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking partitions in tilesui in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","TileUIPartition",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			return false;
		}
	}

	public static boolean tilesCheckQuesArea(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","vistinfodiv");

			CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"tagname","textarea").sendKeys("Welcome to Zoho");

			Thread.sleep(500);

			//String question = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"tagname","textarea").getText();

			if(!(CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","startcht"),"tagname","textarea").getAttribute("readonly")!=null))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","QuesAreaError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking question area in tilesui in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","QuesAreaError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean tilesCheckVisInfo(WebDriver driver,String partName,String finder) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			WebElement infoelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","chatdiv");

			WebElement infelmt = CommonUtil.elementfinder(driver,infoelmt,"xpath",finder);

			if (infelmt.getAttribute("class").contains("browser"))
			{
				
			 	CommonSikuli.findInWholePage(driver,CommonSikuli.getBrowsername(infelmt),"UI84",TrackingRings.etest);
			}
			
			if (infelmt.getAttribute("class").contains("os"))
			{	
				
				CommonSikuli.findInWholePage(driver,CommonSikuli.getOSname(infelmt),"UI85",TrackingRings.etest);
			}
				
			if(infelmt.getAttribute("id")!=null&&!(infelmt.getAttribute("id").equals("")))
			{
				if(infelmt.getAttribute("id").contains(partName))
				{
					if(CommonFunctions.mouseOverTitle(driver,infelmt))
					{
						CommonFunctions.closeTilesUI(driver);
						return true;
					}
				}
			}
			else
			{
				if(infelmt.getAttribute("class").contains(partName))
				{
					if(CommonFunctions.mouseOverTitle(driver,infelmt))
					{
						CommonFunctions.closeTilesUI(driver);
						return true;
					}
				}
			}

			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","VisInfoTilesError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor info in tilesui in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","VisInfoTilesError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean cannedText(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			WebElement cannedelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");

			WebElement ctextelmt = CommonUtil.elementfinder(driver,cannedelmt,"classname","cannedtip");

			if(ctextelmt.getText().equals(ResourceManager.getRealValue("rings_canned")))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","CannedTextError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking canned text in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","CannedTextError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean visPath(WebDriver driver) throws InterruptedException, IOException
	{
		try
		{	
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'visit_div')]")));
			CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visit_div')]");

			CommonFunctions.clickVisitorRings(driver);



			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking visitor path in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","VisPathError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean closeButtonUI(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
			String visId = TrackingRings.vlist;

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			Thread.sleep(500);
			CommonFunctions.closeTilesUI(driver);

			if(CommonUtil.elfinder(driver,"id","ldsettings").getAttribute("style").contains("block"))
			{
				TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","CloseButtonUIError","WindowIsVisible");
				return false;
			}
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking close button in tilesui in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","CloseButtonUIError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean outsideTilesUI(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);
			
			String visId = TrackingRings.vlist;

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			Thread.sleep(500);
			String excode = CommonUtil.elfinder(driver,"id","maskdiv").getAttribute("onclick");

			CommonUtil.JSExecutor(driver, excode);

			if(CommonUtil.elfinder(driver,"id","ldsettings").getAttribute("style").contains("block"))
			{
				TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","OutsideTilesError","Visible");
				CommonFunctions.closeTilesUI(driver);
				return false;
			}

			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking by clicking tilesui in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","OutsideTilesError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean proActiveOneDept(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String visId = TrackingRings.vlist; 
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			Thread.sleep(500);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");

			WebElement kelmt = CommonUtil.elementfinder(driver,pelmt,"tagname","textarea");

			kelmt.sendKeys("Welcome to Zoho");

			Thread.sleep(500);

			if(CommonUtil.elementfinder(driver,pelmt,"linktext",ResourceManager.getRealValue("rings_proactive"))==null)
			{
				TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","ProActiveOneDeptError","MismatchContent");
				CommonFunctions.closeTilesUI(driver);
				return false;
			}

			CommonFunctions.closeTilesUI(driver);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking pro active chat with one dept in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","ProActiveOneDeptError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean proActiveMoreDept(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'visit_div')]")));
			CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visit_div')]");

			CommonFunctions.clickVisitorRings(driver);

			Thread.sleep(500);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");

			WebElement kelmt = CommonUtil.elementfinder(driver,pelmt,"tagname","textarea");

			kelmt.sendKeys("Welcome to Zoho");
			kelmt.sendKeys(Keys.RETURN);

			Thread.sleep(500);

			if(CommonUtil.elementfinder(driver,pelmt,"linktext",ResourceManager.getRealValue("rings_proactive"))==null)
			{
				if((CommonUtil.elementfinder(driver,pelmt,"classname","sales_dept")!=null)&&(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"classname","sales_dept"),"classname","txtelips").getText().contains("Department")))
				{
					CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"classname","sales_dept"),"classname","txtelips").click();

					if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"classname","sales_dept"),"classname","combosubdrpdwnmn").getAttribute("style").contains("block"))
					{
						CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"classname","sales_dept"),"classname","txtelips").click();
						if(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,pelmt,"classname","sales_dept"),"classname","combosubdrpdwnmn").getAttribute("style").contains("none"))
						{
							CommonFunctions.closeTilesUI(driver);
							return true;
						}
					}
				}
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","ProActiveMoreDeptError","MismatchContent");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking pro active chat with more than one dept in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","ProActiveMoreDeptError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}

	public static boolean greenTextArea(WebDriver driver) throws IOException, InterruptedException
	{
		try
		{
			CommonFunctions.visUVID(driver);
			
			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			FluentWait wait = CommonUtil.waitreturner(driver,30,200);

			String visId = TrackingRings.vlist;
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(visId)));
			CommonUtil.elfinder(driver,"id",visId);

			CommonFunctions.clickVisitorRings(driver);

			Thread.sleep(500);

			WebElement pelmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht");

			WebElement kelmt = CommonUtil.elementfinder(driver,pelmt,"tagname","textarea");

			kelmt.sendKeys(Keys.RETURN);

			Thread.sleep(500);
			
			if(CommonUtil.elementfinder(driver,pelmt,"tagname","textarea").getAttribute("class").contains("val_error"))
			{
				CommonFunctions.closeTilesUI(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","TextAreaError","MismatchClassName");
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking green text area bg in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesCheck","TextAreaError",e);
			Thread.sleep(1000);
			//e.printStackTrace();
			CommonFunctions.closeTilesUI(driver);
			return false;
		}
	}
    
    public static boolean tilesBox(WebDriver driver,WebDriver visdriver,String boxTitle,String boxVal) throws InterruptedException, IOException
    {
        try
        {
            if(boxTitle.equals("Visitor History"))
            {
                CommonFunctions.visUVID(driver);
                
                CommonFunctions.proActiveChatNDept(driver);
            }
            else
            {
                CommonFunctions.waitRings(driver);
                CommonFunctions.viewCheck(driver,"Rings");
                
                CommonFunctions.clickVisitorRings(driver);
            }

 			CommonSikuli.findInWholePage(driver,"Afterintiatetime.png","UI82",TrackingRings.etest);
			CommonSikuli.findInWholePage(driver,"Afterintiateclose.png","UI83",TrackingRings.etest);
			CommonSikuli.findInWholePage(driver,"Afterintiatecontacted.png","UI81",TrackingRings.etest);

            
            WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"classname","vistinfo"),"classname","tile_box");
            List<WebElement> tileElmts = elmt.findElements(By.xpath("//div[contains(@class,'sqico')]"));
            
            for(WebElement el:tileElmts)
            {
                if(el.getAttribute("title").equals(boxTitle))
                {
                    //CommonFunctions.mouseOverTitle(driver,el);
                    CommonSikuli.findInWholePage(driver,CommonSikuli.getTileNameAfterIntiate(boxTitle),CommonSikuli.getKeyValueAfterIntiateChat(boxTitle),TrackingRings.etest);
                  
                    CommonUtil.mouseOver(driver,el);
                    Thread.sleep(500);
                    
                    System.out.println("Current Text -------- >>>>>>>>>>>>> "+CommonUtil.elementfinder(driver,el,"classname","tileinfo").getText()+"<<<<<<<<<< ----------------------");
                    
                    if(boxVal != null && CommonUtil.elementfinder(driver,el,"classname","tileinfo").getText().equals(boxVal))
                    {
                        CommonFunctions.closeTilesUI(driver);
                        return true;
                    }
                    else if(boxVal == null && CommonUtil.elementfinder(driver,el,"classname","tileinfo").getText() != null)
                    {
                        CommonFunctions.closeTilesUI(driver);
                        return true;
                    }
                    break;
                }
            }
            
            CommonFunctions.closeTilesUI(driver);
            return false;
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking tiles box in visitor tracking module : ");
            TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","TilesBox","TextAreaError",e);
            Thread.sleep(1000);
            CommonFunctions.closeTilesUI(driver);
            return false;
        }
    }
}
