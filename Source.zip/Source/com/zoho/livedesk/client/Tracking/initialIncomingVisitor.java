//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

public class initialIncomingVisitor
{
	public static boolean incomingVisitor(WebDriver driver) throws InterruptedException, IOException
	{
		//WebDriver visdriver = null;
		try
		{
			//visdriver = VisitorSite.createPage();

			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");
			
			FluentWait viswait = CommonUtil.waitreturner(driver,60,100);
			
			CommonFunctions.visUVID(driver);
			//viswait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'visit_div')]")));
			//CommonUtil.elfinder(driver,"xpath","//div[contains(@class,'visit_div')]");
			
			viswait.until(ExpectedConditions.presenceOfElementLocated(By.id(TrackingRings.vlist)));
			CommonUtil.elfinder(driver,"id",TrackingRings.vlist);
			
			//visdriver.quit();
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking initial incoming visitor in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","IncomingVisitor","RingsError",e);
			Thread.sleep(1000);
			return false;
		}
	}
}
