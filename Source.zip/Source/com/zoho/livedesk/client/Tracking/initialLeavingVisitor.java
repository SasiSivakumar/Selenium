//$Id$
package com.zoho.livedesk.client.Tracking;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;

import com.zoho.livedesk.client.TakeScreenshot;

import java.util.concurrent.TimeUnit;

public class initialLeavingVisitor
{
	public static boolean leavingVisitor(WebDriver driver) throws InterruptedException, IOException
	{
		WebDriver visdriver = null;
		try
		{
			//visdriver = VisitorSite.createPage();

			FluentWait wait = CommonUtil.waitreturner(driver,80,200);

			CommonFunctions.waitRings(driver);
			CommonFunctions.viewCheck(driver,"Rings");

			//visdriver.quit();

			/*wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					try
					{
						if(driver.findElement(By.xpath("//div[contains(@class,'visit_div')]")).getAttribute("id")!=null)
						{
							return false;
						}
						return true;
					}
					catch(Exception e)
					{
						return true;
					}
				}
			});*/
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(TrackingRings.vlist)));
            
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			
			wait.until(new Function<WebDriver,Boolean>()
			{
				public Boolean apply(WebDriver driver)
				{
					try
					{
						if(driver.findElement(By.id(TrackingRings.vlist))!=null)
						{
							return false;
						}
						return true;
					}
					catch(Exception e)
					{
						return true;
					}
				}
			});

            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception while checking rings after visitor leaves the website in visitor tracking module : ");
			TakeScreenshot.screenshot(driver,TrackingRings.etest,"Tracking","LeavingVisitor","CleanUpError",e);
			Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			return false;
		}
	}
}
