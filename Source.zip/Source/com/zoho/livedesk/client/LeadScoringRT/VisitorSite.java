//$Id$
package com.zoho.livedesk.client.LeadScoringRT;

import java.io.IOException;
import java.util.Set;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.common.base.Function;

import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.actions.*;

public class VisitorSite
{
    public static WebDriver openVis(WebDriver driver,String widgetcode) throws InterruptedException, IOException
    {
        try
        {
            VisitorWindow.createPage(driver,widgetcode);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","OpenVisitorPage","Error",e);
        }
        return driver;
    }

    public static WebDriver openRefVis(WebDriver driver,String referrer,String widgetcode) throws IOException, InterruptedException
    {
        try
        {
            VisitorWindow.createPageReferrer1(driver,widgetcode,referrer);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","OpenVisitorPage","Error",e);
        }
        return driver;
    }

    public static WebDriver createCampaign(WebDriver driver,String cname,String widgetcode) throws IOException, InterruptedException
    {
        try
        {
            VisitorWindow.createPageCampaign(driver,widgetcode,cname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","OpenVisitorPage","Error",e);
        }
        return driver;
    }

    public static WebDriver createReferralPage(WebDriver driver,String widgetcode) throws InterruptedException, IOException
    {
        try
        {
            VisitorWindow.createPageReferrer(driver,widgetcode);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","OpenVisitorPage","Error",e);
        }
        return driver;
    }

    public static WebDriver setUp() throws InterruptedException
    {
        try
        {
            return Functions.setUp();
        }
        catch(Exception e)
        {
            System.out.println("Exception while setting up webdriver in lead scoring real time check module : ");
            Thread.sleep(1000);
            e.printStackTrace();
        }
        return null;
    }

    public static WebDriver openApiSite(WebDriver driver,String widgetcode) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);
            driver.get("http://"+Util.serverHostName+"/jsdev2.php");
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fname")));

            String siteName = Util.setUptracking();

            if(siteName.equals("local"))
            {
                siteName = "LocalZoho";
            }
            else if(siteName.equals("lab"))
            {
                siteName = "Lab SalesIQ";
            }
            else if(siteName.equals("pre"))
            {
                siteName = "Pre SalesIQ";
            }
            else if(siteName.equals("idc"))
            {
                siteName = "IDC";
            }
            else
            {
                siteName = "IDC";
            }
            
            CommonFunctions.choosePortal(driver,widgetcode,siteName);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","OpenVisitorPage","Error",e);
        }

        return driver;
    }
}
