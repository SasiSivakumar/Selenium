//$Id$
package com.zoho.livedesk.client.LeadScoringRT;

import java.util.Set;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.client.IntegrationSettings;
import com.zoho.livedesk.client.ComplexReportFactory;
import com.zoho.livedesk.client.TakeScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.google.common.base.Function;
import com.zoho.livedesk.util.common.actions.*;

public class LeadScoringRealTime
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();

    private static String url = "";

    public static ExtentTest etest;


    public static Hashtable<String,String> visitorid = new Hashtable<String,String>();
    public static Hashtable<String,Long> time = new Hashtable();
    public static Hashtable<String,ExtentTest> extenttest = new Hashtable<String,ExtentTest>();
    public static String portal = "leadscore";

    public static Hashtable rtscoring(WebDriver driver)
    {
        try
        {
            result = new Hashtable();

            etest = startTest("LSRT1");

            WebDriver VisDriver = null;

            VisDriver = VisitorSite.setUp();

            url = ConfManager.requestURL();
            
            visitorid.put("LSRT1",getVisitorId(driver,VisDriver, "Browser", null, "is equal to", "Google Chrome", null, "96", true, null,portal+"1"));
            time.put("LSRT1",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT2");

            visitorid.put("LSRT2",getVisitorId(driver,VisDriver, "Actions performed", null, "is equal to", "Clicked", null, "433", true, null,portal+"2"));
            time.put("LSRT2",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT3");

            visitorid.put("LSRT3",getVisitorId(driver,VisDriver, "Campaign Name", null, "contains", "SalesIQ Testing", null, "338", true, null,portal+"3"));
            time.put("LSRT3",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT4");

            visitorid.put("LSRT4",getVisitorId(driver,VisDriver, "Country", null, "is equal to", "United Kingdom, India, United States", null, "655", true, null,portal+"4"));
            time.put("LSRT4",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT5");

            visitorid.put("LSRT5",getVisitorId(driver,VisDriver, "Current Visit Source", null, "is equal to", "Direct", null, "821", true, null,portal+"5"));
            time.put("LSRT5",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT6");

            visitorid.put("LSRT6",getVisitorId(driver,VisDriver, "Email Address", null, "doesn't contain", "@gmail.com", null, "214", true, null,portal+"6"));
            time.put("LSRT6",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT7");

            visitorid.put("LSRT7",getVisitorId(driver,VisDriver, "IP Address", null, "is between", "100.1.1.1", "200.255.255.255", "73", true, null,portal+"7"));
            time.put("LSRT7",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT8");

            visitorid.put("LSRT8",getVisitorId(driver,VisDriver, "Landing Page Title", null, "contains", "SalesIQ", null, "98", true, null,portal+"8"));
            time.put("LSRT8",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT9");

            visitorid.put("LSRT9",getVisitorId(driver,VisDriver, "Landing Page URL", null, "contains", "visitor", null, "762", true, null,portal+"9"));
            time.put("LSRT9",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT10");

            visitorid.put("LSRT10",getVisitorId(driver,VisDriver, "Number of Past Chats", null, "is less than", "2", null, "103", true, null,portal+"10"));
            time.put("LSRT10",System.currentTimeMillis());

            VisDriver.quit();
            VisDriver = VisitorSite.setUp();

            etest = continueTest("LSRT1");
            result.put("LSRT1",checkLeadScore(driver,visitorid.get("LSRT1"),"96",portal+"1"));
            CommonFunctions.cleanUpState(driver, "Browser", null, "is equal to", "Google Chrome", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT2");
            result.put("LSRT2",checkLeadScore(driver,visitorid.get("LSRT2"),"433",portal+"2"));
            CommonFunctions.cleanUpState(driver, "Actions performed", null, "is equal to", "Clicked", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT3");
            result.put("LSRT3",checkLeadScore(driver,visitorid.get("LSRT3"),"338",portal+"3"));
            CommonFunctions.cleanUpState(driver, "Campaign Name", null, "contains", "SalesIQ Testing", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT4");
            result.put("LSRT4",checkLeadScore(driver,visitorid.get("LSRT4"),"655",portal+"4"));
            CommonFunctions.cleanUpState(driver, "Country", null, "is equal to", "United Kingdom, India, United States", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT5");
            result.put("LSRT5",checkLeadScore(driver,visitorid.get("LSRT5"),"821",portal+"5"));
            CommonFunctions.cleanUpState(driver, "Current Visit Source", null, "is equal to", "Direct", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT6");
            result.put("LSRT6",checkLeadScore(driver,visitorid.get("LSRT6"),"214",portal+"6"));
            CommonFunctions.cleanUpState(driver, "Email Address", null, "doesn't contain", "@gmail.com", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT7");
            result.put("LSRT7",checkLeadScore(driver,visitorid.get("LSRT7"),"73",portal+"7"));
            CommonFunctions.cleanUpState(driver, "IP Address", null, "is between", "100.1.1.1", "200.255.255.255");
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT8");
            result.put("LSRT8",checkLeadScore(driver,visitorid.get("LSRT8"),"98",portal+"8"));
            CommonFunctions.cleanUpState(driver, "Landing Page Title", null, "contains", "SalesIQ", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT9");
            result.put("LSRT9",checkLeadScore(driver,visitorid.get("LSRT9"),"762",portal+"9"));
            CommonFunctions.cleanUpState(driver, "Landing Page URL", null, "contains", "visitor", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT10");
            result.put("LSRT10",checkLeadScore(driver,visitorid.get("LSRT10"),"103",portal+"10"));
            CommonFunctions.cleanUpState(driver, "Number of Past Chats", null, "is less than", "2", null);
            ComplexReportFactory.closeTest(etest);

            etest = startTest("LSRT11");

            visitorid.put("LSRT11",getVisitorId(driver,VisDriver, "Number of URLs Accessed", null, "is less than", "2", null, "393", true, null,portal+"1"));
            time.put("LSRT11",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();

            etest = startTest("LSRT12");

            visitorid.put("LSRT12",getVisitorId(driver,VisDriver, "Number of Visits", null, "is more than", "1", null, "221", true, null,portal+"2"));
            time.put("LSRT12",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT13");

            visitorid.put("LSRT13",getVisitorId(driver,VisDriver, "Operating System", null, "is not equal to", "PlayStation", null, "476", true, null,portal+"3"));
            time.put("LSRT13",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT14");

            visitorid.put("LSRT14",getVisitorId(driver,VisDriver, "Referrer", null, "contains", "visitor", null, "89", true, null,portal+"4"));
            time.put("LSRT14",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT15");

            visitorid.put("LSRT15",getVisitorId(driver,VisDriver, "Region", null, "is equal to", "Asia Pacific, North America, South America, United Kingdom", null, "278", true, null,portal+"5"));
            time.put("LSRT15",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT16");

            visitorid.put("LSRT16",getVisitorId(driver,VisDriver, "Search Engine", null, "is equal to", "Google", null, "166", true, "https://www.google.com/",portal+"6"));
            time.put("LSRT16",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT19");

            visitorid.put("LSRT19",getVisitorId(driver,VisDriver, "Visitor Email Id updated", null, "before", "2nd visit", null, "136", true, null,portal+"7"));
            time.put("LSRT19",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT20");

            visitorid.put("LSRT20",getVisitorId(driver,VisDriver, "Visitor Info", "Trial", "contains", "June", null, "208", true, null,portal+"8"));
            time.put("LSRT20",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT21");

            visitorid.put("LSRT21",getVisitorId(driver,VisDriver, "Visitor Source", null, "is equal to", "Referral", null, "311", true, null,portal+"9"));
            time.put("LSRT21",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT17");

            visitorid.put("LSRT17",getVisitorId(driver,VisDriver, "Time on Site", null, "is more than", "1 Minute", null, "455", true, null,portal+"10"));
            time.put("LSRT17",System.currentTimeMillis());

            VisDriver.quit();
            VisDriver = VisitorSite.setUp();

            etest = continueTest("LSRT11");
            result.put("LSRT11",checkLeadScore(driver,visitorid.get("LSRT11"),"393",portal+"1"));
            CommonFunctions.cleanUpState(driver, "Number of URLs Accessed", null, "is less than", "2", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT12");
            result.put("LSRT12",checkLeadScore(driver,visitorid.get("LSRT12"),"221",portal+"2"));
            CommonFunctions.cleanUpState(driver, "Number of Visits", null, "is more than", "1", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT13");
            result.put("LSRT13",checkLeadScore(driver,visitorid.get("LSRT13"),"476",portal+"3"));
            CommonFunctions.cleanUpState(driver, "Operating System", null, "is not equal to", "PlayStation", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT14");
            result.put("LSRT14",checkLeadScore(driver,visitorid.get("LSRT14"),"89",portal+"4"));
            CommonFunctions.cleanUpState(driver, "Referrer", null, "contains", "visitor", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT15");
            result.put("LSRT15",checkLeadScore(driver,visitorid.get("LSRT15"),"278",portal+"5"));
            CommonFunctions.cleanUpState(driver, "Region", null, "is equal to", "Asia Pacific, North America, South America", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT16");
            result.put("LSRT16",checkLeadScore(driver,visitorid.get("LSRT16"),"166",portal+"6"));
            CommonFunctions.cleanUpState(driver, "Search Engine", null, "is equal to", "Google", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT19");
            result.put("LSRT19",checkLeadScore(driver,visitorid.get("LSRT19"),"136",portal+"7"));
            CommonFunctions.cleanUpState(driver, "Visitor Email Id updated", null, "before", "2nd visit", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT20");
            result.put("LSRT20",checkLeadScore(driver,visitorid.get("LSRT20"),"208",portal+"8"));
            CommonFunctions.cleanUpState(driver, "Visitor Info", "Trial", "contains", "June", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT21");
            result.put("LSRT21",checkLeadScore(driver,visitorid.get("LSRT21"),"311",portal+"9"));
            CommonFunctions.cleanUpState(driver, "Visitor Source", null, "is equal to", "Referral", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT17");
            result.put("LSRT17",checkLeadScore(driver,visitorid.get("LSRT17"),"455",portal+"10"));
            CommonFunctions.cleanUpState(driver, "Time on Site", null, "is more than", "1 Minute", null);
            ComplexReportFactory.closeTest(etest);

            etest = startTest("LSRT22");

            visitorid.put("LSRT22",getVisitorId(driver,VisDriver, "Visitor Type", null, "is not equal to", "Returning", null, "111", true, null,portal+"1"));
            time.put("LSRT22",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT23");

            visitorid.put("LSRT23",getVisitorIdForCrmContact(driver,VisDriver,portal+"2"));
            time.put("LSRT23",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT24");

            visitorid.put("LSRT24",getVisitorIdForCrmLead(driver,VisDriver,portal+"3"));
            time.put("LSRT24",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT26");

            visitorid.put("LSRT26",getVisitorIdForVisitorStage(driver,VisDriver,portal+"4"));
            time.put("LSRT26",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT27");

            visitorid.put("LSRT27",getVisitorIdForAdvAnd(driver,VisDriver,portal+"5"));
            time.put("LSRT27",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT28");

            visitorid.put("LSRT28",getVisitorIdForAdvOr(driver,VisDriver,portal+"6"));
            time.put("LSRT28",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT29");

            visitorid.put("LSRT29",getVisitorIdForMultipleCond(driver,VisDriver,"is equal to",portal+"7"));
            time.put("LSRT29",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT30");

            visitorid.put("LSRT30",getVisitorIdForMultipleCond(driver,VisDriver,"is not equal to",portal+"8"));
            time.put("LSRT30",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT31");

            visitorid.put("LSRT31",getVisitorIdForDisableRule(driver,VisDriver,portal+"9"));
            time.put("LSRT31",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT32");

            visitorid.put("LSRT32",getVisitorIdForEnableRule(driver,VisDriver,portal+"10"));
            time.put("LSRT32",System.currentTimeMillis());

            VisDriver.quit();
            VisDriver = VisitorSite.setUp();

            etest = continueTest("LSRT22");
            result.put("LSRT22",checkLeadScore(driver,visitorid.get("LSRT22"),"111",portal+"1"));
            CommonFunctions.cleanUpState(driver, "Visitor Type", null, "is not equal to", "Returning", null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT23");
            result.put("LSRT23",checkLeadScore(driver,visitorid.get("LSRT23"),"112",portal+"2"));
            CommonFunctions.cleanUpState(driver,"CRM Contact","Email","begins with","email@",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT24");
            result.put("LSRT24",checkLeadScore(driver,visitorid.get("LSRT24"),"178",portal+"3"));
            CommonFunctions.cleanUpState(driver,"CRM Lead","Last Name","contains","Tester",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT26");
            result.put("LSRT26",checkLeadScore(driver,visitorid.get("LSRT26"),"153",portal+"4"));
            CommonFunctions.cleanUpState(driver,"Visitor Stage in CRM",null,"is equal to","Lead",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT27");
            result.put("LSRT27",checkLeadScore(driver,visitorid.get("LSRT27"),"198",portal+"5"));
            CommonFunctions.cleanUpState(driver,"Browser",null,"is equal to","Google Chrome",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT28");
            result.put("LSRT28",checkLeadScore(driver,visitorid.get("LSRT28"),"147",portal+"6"));
            CommonFunctions.cleanUpState(driver,"Email Address",null,"contains","checkls",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT29");
            result.put("LSRT29",checkLeadScore(driver,visitorid.get("LSRT29"),"216",portal+"7"));
            CommonFunctions.cleanUpState(driver,"Browser",null,"is equal to","Google Chrome",null);
            CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT30");
            result.put("LSRT30",checkLeadScore(driver,visitorid.get("LSRT30"),"23",portal+"8"));
            CommonFunctions.cleanUpState(driver,"Browser",null,"is not equal to","Google Chrome",null);
            CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT31");
            result.put("LSRT31",checkLeadScore(driver,visitorid.get("LSRT31"),"0",portal+"9"));
            CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Campaign",null);
            ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT32");
            result.put("LSRT32",checkLeadScore(driver,visitorid.get("LSRT32"),"173",portal+"10"));
            CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
            ComplexReportFactory.closeTest(etest);

            etest = startTest("LSRT33");

            visitorid.put("LSRT33",getVisitorIdForDeleteRule(driver,VisDriver,portal+"1"));
            time.put("LSRT33",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
            etest = startTest("LSRT34");

            visitorid.put("LSRT34",getVisitorIdForAddVisRule(driver,VisDriver,portal+"2"));
            time.put("LSRT34",System.currentTimeMillis());
            VisDriver.quit();
            VisDriver = VisitorSite.setUp();
            
             etest = startTest("LSRT35");

             visitorid.put("LSRT35",getVisitorIdForEditAVisRule(driver,VisDriver,portal+"3"));
             time.put("LSRT35",System.currentTimeMillis());
             VisDriver.quit();
             VisDriver = VisitorSite.setUp();
            
             etest = startTest("LSRT36");

             visitorid.put("LSRT36",getVisitorIdForEditAVisPoints(driver,VisDriver,portal+"4"));
             time.put("LSRT36",System.currentTimeMillis());
             VisDriver.quit();
             VisDriver = VisitorSite.setUp();
            
             etest = startTest("LSRT37");

             visitorid.put("LSRT37",getVisitorIdForDisableAVisPoints(driver,VisDriver,portal+"5"));
             time.put("LSRT37",System.currentTimeMillis());
             VisDriver.quit();
             VisDriver = VisitorSite.setUp();
            
             etest = startTest("LSRT38");

             visitorid.put("LSRT38",getVisitorIdForAddDisEnRule(driver,VisDriver,portal+"6"));
             time.put("LSRT38",System.currentTimeMillis());
             VisDriver.quit();
             VisDriver = VisitorSite.setUp();
            
             etest = startTest("LSRT39");

             visitorid.put("LSRT39",getVisitorIdForAdvMultipleCondNeg(driver,VisDriver,portal+"7",false));
             time.put("LSRT39",System.currentTimeMillis());
             VisDriver.quit();
             VisDriver = VisitorSite.setUp();
            
             etest = startTest("LSRT40");

             visitorid.put("LSRT40",getVisitorIdForAdvMultipleCondNeg(driver,VisDriver,portal+"8",true));
             time.put("LSRT40",System.currentTimeMillis());

             VisDriver.quit();
             VisDriver = VisitorSite.setUp();

             etest = continueTest("LSRT33");
             result.put("LSRT33",checkLeadScore(driver,visitorid.get("LSRT33"),"0",portal+"1"));
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
             ComplexReportFactory.closeTest(etest);

            etest = continueTest("LSRT34");
            result.put("LSRT34",checkLeadScore(driver,visitorid.get("LSRT34"),"227",portal+"2"));
            CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
            ComplexReportFactory.closeTest(etest);

             etest = continueTest("LSRT35");
             result.put("LSRT35",checkLeadScore(driver,visitorid.get("LSRT35"),"0",portal+"3"));
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Campaign",null);
             ComplexReportFactory.closeTest(etest);

             etest = continueTest("LSRT36");
             result.put("LSRT36",checkLeadScore(driver,visitorid.get("LSRT36"),"237",portal+"4"));
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
             ComplexReportFactory.closeTest(etest);

             etest = continueTest("LSRT37");
             result.put("LSRT37",checkLeadScore(driver,visitorid.get("LSRT37"),"0",portal+"5"));
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
             ComplexReportFactory.closeTest(etest);

             etest = continueTest("LSRT38");
             result.put("LSRT38",checkLeadScore(driver,visitorid.get("LSRT38"),"177",portal+"6"));
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
             ComplexReportFactory.closeTest(etest);

             etest = continueTest("LSRT39");
             result.put("LSRT39",checkLeadScore(driver,visitorid.get("LSRT39"),"0",portal+"7"));
             CommonFunctions.cleanUpState(driver,"Browser",null,"is equal to","Google Chrome",null);
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
             ComplexReportFactory.closeTest(etest);

             etest = continueTest("LSRT40");
             result.put("LSRT40",checkLeadScore(driver,visitorid.get("LSRT40"),"100",portal+"8"));
             CommonFunctions.cleanUpState(driver,"Browser",null,"is equal to","Google Chrome",null);
             CommonFunctions.cleanUpState(driver,"Visitor Source",null,"is equal to","Direct",null);
             ComplexReportFactory.closeTest(etest);

            VisDriver.quit();
        }
        catch(Exception e)
        {
            result.put("LSRT1", false);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            etest.log(Status.FATAL,"Error occurred while checking network connection in lead scoring rt module : "+e);
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","LeadScoringShowStopper","LSRTError",e);
        }
        try
        {
            driver.get(Util.siteNameout());
            Thread.sleep(4000);
            driver.findElement(By.id("dnenable")).findElement(By.className("sqico-close")).click();
            Thread.sleep(2000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while closing the top banner : "+e);
        }
        ComplexReportFactory.closeTest(etest);
        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    public static void addRule(WebDriver driver,String pnum,String condition,String condition1,String criteria,String value1,String value2,String points,boolean add) throws Exception
    {
      addRule(etest,driver,pnum,condition,condition1,criteria,value1,value2,points,add);
    }

    public static void addRule(ExtentTest etest,WebDriver driver,String pnum,String condition,String condition1,String criteria,String value1,String value2,String points,boolean add) throws Exception
    {
        CommonFunctions.clickAddInLeadScoring(driver);
        etest.log(Status.INFO,"Add is clicked in Leadscoring");
        CommonFunctions.addFieldsInCreateScoringRules(driver, pnum, condition,condition1,criteria,value1,value2);
        etest.log(Status.INFO,"Fields are filled");
        CommonFunctions.addPointsForRulesInLeadScoring(driver,points,add);
        etest.log(Status.INFO,"Points are filled");
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonFunctions.clickApplyInCreateRulesLeadScoring(driver,etest);
        etest.log(Status.INFO,"Apply is clicked");
        TakeScreenshot.infoScreenshot(driver,etest);
        CommonFunctions.clickVisitorsOnline(driver);
        Thread.sleep(2000);
        etest.log(Status.INFO,"Rule is added");
    }

    public static String getVisitorId(WebDriver driver,WebDriver VisDriver,String condition,String condition1,String criteria,String value1,String value2,String points,boolean add,String url,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);
            etest.log(Status.INFO,"Navigated to "+portalname);
            addRule(driver,"1",condition,condition1,criteria,value1,value2,points,add);

            Long time = new Long(System.currentTimeMillis());

            if(condition.contains("Campaign"))
            {
                  VisitorSite.createCampaign(VisDriver,value1,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            }
            else if(condition.contains("Email"))
            {
                  VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
                  CommonFunctions.initiateChatVis(VisDriver,"CheckEmail","checkemail"+time.toString()+"@email.com","12345","salesiq pricing ? ...");
                  CommonFunctions.acceptChat(driver);
                  CommonFunctions.endChatUser(driver);
            }
            else if(condition.contains("Search Engine"))
            {
                  VisitorSite.openRefVis(VisDriver,url,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            }
            else if(condition.contains("Referrer") || value1.contains("Referral"))
            {
                VisitorSite.createReferralPage(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            }
            else if(condition.contains("Visitor Info"))
            {
                VisitorSite.openApiSite(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
                CommonFunctions.changeConfigInfo(VisDriver,"{\""+condition1+"\": \""+value1+"\"}");
            }
            else
            {
                VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            }

            if(value1.contains("Clicked"))
            {
                CommonFunctions.clickWidget(VisDriver);
            }

            if(condition.contains("Time") && !criteria.contains("less"))
            {
                Thread.sleep(60000);
            }

            if(condition.contains("Visits") && !criteria.contains("less"))
            {
                int count = Integer.parseInt(value1);
                for(int i = 1;i<=count+1;i++)
                {
                    CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
                    CommonFunctions.reVisit(driver, VisDriver,portalname);
                }
            }

            String s = CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
            
            etest.log(Status.INFO,s+" is obtained");
            
            return s;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static boolean checkLeadScore(WebDriver driver,String uuid,String points,String portalname)
    {
        try
        {
          Functions.loadSiteAndWaitForRSID(driver,portalname);
            Thread.sleep(5000);
           if(!uuid.equals("Error"))
           {
            if(CommonFunctions.verifyOppurtunity(driver,uuid,points))
            {
                etest.log(Status.PASS,"Rule verified successfully and lead score updated as : "+points);
                return true;
            }
            else
            {
                etest.log(Status.FAIL,"Actual:"+CommonFunctions.currentLeadScore(driver)+"(Expected:"+points+")");
                TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","checkLeadScore","MismatchLeadScore");
                return false;
            }
           }
           return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","CheckingLeadScore","Error",e);
            return false;
        }
    }

    public static String getVisitorIdForAdvAnd(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Browser",null,"is equal to","Google Chrome",null);
            CommonFunctions.clickMultiple(driver,"and",1);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"2","Actions Performed",null,"is equal to","Clicked",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"198",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            CommonFunctions.clickWidget(VisDriver);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForAdvOr(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Email Address",null,"contains","Checkls",null);
            CommonFunctions.clickMultiple(driver,"or",1);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"2","Current Visit Source",null,"is equal to","AdWords",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"147",true);
            
            Thread.sleep(2000);
            
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            String vname = "Vis"+System.currentTimeMillis()+" Tester";
            String vemail = "Checkls@"+System.currentTimeMillis()+".com";
            String vphone = "+1"+System.currentTimeMillis();
            String vques = "Ques"+System.currentTimeMillis();

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            CommonFunctions.initiateChatVis(VisDriver,vname,vemail,vphone,vques);

            CommonFunctions.acceptChat(driver);
            CommonFunctions.endChatUser(driver);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForMultipleCond(WebDriver driver,WebDriver VisDriver,String qual,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Browser",null,qual,"Google Chrome",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"193",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"23",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForDisableRule(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Campaign",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"173",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            CommonFunctions.disableRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Campaign",null,true);

            VisDriver = VisitorSite.createCampaign(VisDriver,"SalesIQ Testing",ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForEnableRule(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"173",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            CommonFunctions.disableRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null,true);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            CommonFunctions.waitTillVisitorLeaves(driver,VisDriver);

            CommonFunctions.clickLeadScoring(driver);
            CommonFunctions.disableRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null,false);

            CommonFunctions.visitSite(driver,VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForDeleteRule(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"203",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
            CommonFunctions.deleteRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForAddVisRule(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"227",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForEditAVisRule(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"249",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            CommonFunctions.clickLeadScoring(driver);
            CommonFunctions.editRuleLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Campaign",null);
            CommonFunctions.applyEdit(driver);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForEditAVisPoints(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"261",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            CommonFunctions.clickLeadScoring(driver);
            CommonFunctions.editRuleLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"237",true);
            CommonFunctions.applyEdit(driver);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForDisableAVisPoints(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"273",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            CommonFunctions.disableRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null,true);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }
    public static String getVisitorIdForAddDisEnRule(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"177",true);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            CommonFunctions.disableRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null,true);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            CommonFunctions.clickLeadScoring(driver);
            CommonFunctions.disableRuleInLeadScoring(driver,"Visitor Source",null,"is equal to","Direct",null,false);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForAdvMultipleCondNeg(WebDriver driver,WebDriver VisDriver,String portalname,boolean postv)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Browser",null,"is equal to","Google Chrome",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"100",!postv);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            CommonFunctions.clickAddInLeadScoring(driver);
            CommonFunctions.addFieldsInCreateScoringRules(driver,"1","Visitor Source",null,"is equal to","Direct",null);
            CommonFunctions.addPointsForRulesInLeadScoring(driver,"200",postv);
            CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

            VisDriver = VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForCrmContact(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            crmVisitor(driver,VisDriver,"CRM Contact","Email","begins with","email@",null,"112",true,1,portalname);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static void crmVisitor(WebDriver driver,WebDriver VisDriver,String c1,String c2,String qual,String v1,String v2,String pts,boolean adchk,int lnum,String portalname) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        IntegrationSettings.chooseType(driver, "vistypecrmdiv", "Attended", 1, "chk",etest);
        IntegrationSettings.addNewVisitorTo(driver,lnum,etest);

        CommonFunctions.clickAddInLeadScoring(driver);
        CommonFunctions.addFieldsInCreateScoringRules(driver,"1",c1,c2,qual,v1,v2);
        CommonFunctions.addPointsForRulesInLeadScoring(driver,pts,adchk);
        CommonFunctions.clickApplyInCreateRulesLeadScoring(driver);

        String vname = "Vis"+System.currentTimeMillis()+" Tester";
        String vemail = "email@"+System.currentTimeMillis()+".com";
        String vphone = "+1"+System.currentTimeMillis();

        VisitorSite.openVis(VisDriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
        CommonFunctions.initiateChatVis(VisDriver,vname,vemail,vphone,"Hello ..?");
        CommonFunctions.acceptChat(driver);
        CommonFunctions.endChatUser(driver);
        CommonFunctions.reVisit(driver,VisDriver,portalname);

    }

    public static String getVisitorIdForCrmLead(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            crmVisitor(driver,VisDriver,"CRM Lead","Last Name","contains","Tester",null,"178",true,0,portalname);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }

    public static String getVisitorIdForVisitorStage(WebDriver driver,WebDriver VisDriver,String portalname)
    {
        try
        {
           Functions.loadSiteAndWaitForRSID(driver,portalname);

            crmVisitor(driver,VisDriver,"Visitor Stage in CRM",null,"is equal to","Lead",null,"153",true,0,portalname);

            return CommonFunctions.getLatestVisitorUUID(driver,VisDriver,portalname);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"LeadScoringRT","GetVisitorId","Error",e);
            return "Error";
        }
    }


    public static ExtentTest continueTest(String usecase) throws Exception
    {
      int i = 1;
      while(true)
      {
            if(System.currentTimeMillis()>(time.get(usecase)+180000))
                  break;

            Thread.sleep(500);

            if(visitorid.get(usecase).contains("Error"))
                  break;

            if(i++ >=450)
                  break;
      }

      System.out.println("Waited for "+usecase+":"+i*0.5);

      return extenttest.get(usecase);
    }

    public static ExtentTest startTest(String usecase) throws Exception
    {
      ExtentTest test = ComplexReportFactory.getTest(KeyManager.getRealValue(usecase));
      ComplexReportFactory.setValues(test,"Automation","Lead Scoring Real Time");
      extenttest.put(usecase,test);
      return extenttest.get(usecase);
    }
}
