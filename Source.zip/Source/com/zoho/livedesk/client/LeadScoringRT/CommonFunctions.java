//$Id$
package com.zoho.livedesk.client.LeadScoringRT;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.Cookie;

import com.google.common.base.Function;
import com.zoho.qa.server.servlet.WebdriverApi;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.*;

public class CommonFunctions
{
    public static int ccount = 0;

    public static void clickSettings(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_settings")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innersettinglnk")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("setting_sm_user")));
    }

    public static void clickLeadScoring(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickSettings(driver);
        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("settings_leadscoring"))));

        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("settings_leadscoring")).click();

        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
    }

    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_vhistory"))));

        CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("common_vhistory")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innerheader")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visit_mcontent")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("visit_mcontent")));
    }

    public static void addVHRuleRecent(WebDriver driver) throws Exception
    {
        clickVisitorHistory(driver);
        clickAddView(driver);
        sendValuesPopUp(driver,"Visitor Type","is equal to","All");
        clickSortList(driver);
        applyRule(driver);
        checkAlert(driver);
    }

    public static void clickAddView(WebDriver driver) throws Exception
    {

        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("createlist")));

        CommonUtil.elfinder(driver,"id","createlist").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return false;
                }
                return true;
            }
        });
    }

    public static void sendValuesPopUp(WebDriver driver,String vrow1,String vrow2,String vrow3) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        CommonUtil.elfinder(driver,"id","prior1_col1_div").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("prior1_col1_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col1_ddown"),"id","srchtxt"),"tagname","input").click();
        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col1_ddown"),"id","srchtxt"),"tagname","input").sendKeys(vrow1);

        WebElement elmtr1 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col1_ddown"),"tagname","ul");
        List<WebElement> elmtsr1 = elmtr1.findElements(By.tagName("li"));

        elmtsr1.get(0).click();

        CommonUtil.elfinder(driver,"id","prior1_col2_div").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("prior1_col2_ddown")).getAttribute("style").contains("block"))
                {
                    return true;
                }
                return false;
            }
        });

        WebElement elmtr2 = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col2_ddown"),"tagname","ul");
        List<WebElement> elmtsr2 = elmtr2.findElements(By.tagName("li"));

        for(WebElement ell:elmtsr2)
        {
            if(CommonUtil.elementfinder(driver,ell,"tagname","span").getText().equals(vrow2))
            {
                CommonUtil.elementfinder(driver,ell,"tagname","span").click();
            }
        }

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col3"),"tagname","input").click();
        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","prior1_col3"),"tagname","input").sendKeys(vrow3);
    }

    public static void clickSortList(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("cmpny_fltr_div")));
        CommonUtil.elfinder(driver,"id","cmpny_fltr_div").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        WebElement elmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","cmpny_fltr_ddown"),"tagname","ul");
        List<WebElement> elmts = elmt.findElements(By.tagName("li"));

        for(WebElement ell:elmts)
        {
            if(ell.findElement(By.tagName("span")).getText().equals(ResourceManager.getRealValue("vhist_lvtime")))
            {
                ell.findElement(By.tagName("span")).click();
                break;
            }
        }

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("cmpny_fltr_div")).findElement(By.tagName("span")).getAttribute("val").equals("LVTIME"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("cmpny_fltr_ddown")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void applyRule(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Apply']")));
        CommonUtil.elfinder(driver,"xpath","//div[text()='Apply']").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("ldsettings")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void checkAlert(WebDriver driver) throws Exception
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,5,250);

            if(CommonUtil.elfinder(driver,"id","popupdiv").isDisplayed())
            {
               wait.until(ExpectedConditions.presenceOfElementLocated(By.id("okbtn")));

                CommonUtil.elfinder(driver,"id","okbtn").click();

                Thread.sleep(2000);
            }
        }
        catch(Exception e)
        {}
    }

    public static void setToAllVis(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            clickSettings(driver);
            clickVisitorHistory(driver);

            driver.navigate().refresh();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("viewid-0")));

            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","favdrpdown0"),"tagname","span").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("favdrpdown0_div")));

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!driver.findElement(By.id("favdrpdown0_ddown")).getAttribute("style").contains("none"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebElement elmt = CommonUtil.elfinder(driver,"id","favdrpdown0_ddown");
            List<WebElement> elmts = elmt.findElements(By.tagName("li"));

            for(WebElement ell:elmts)
            {
                if(ell.findElement(By.tagName("span")).getText().equals("All Visitors"))
                {
                    ell.findElement(By.tagName("span")).click();
                    break;
                }
            }

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(driver.findElement(By.id("viewid-0")).getAttribute("viewid").equals("-1"))
                    {
                        return true;
                    }
                    return false;
                }
            });
        }
        catch(Exception e)
        {
            System.out.println("Exception while setting view to all visitors in visitor history tab");
            e.printStackTrace();
        }
    }

    public static String verifyVisitor(WebDriver driver,String uvid) throws Exception
    {
        String uuid = (((JavascriptExecutor) driver).executeScript("return UTSHandler.visitors[\""+uvid+"\"].data[\"uuid\"];")).toString();

        return uuid;
    }

    public static void checkVisitorUUID(WebDriver driver,final String uuid) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        CommonFunctions.clickSettings(driver);
        CommonFunctions.clickVisitorHistory(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("viewid-0")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("viewid-0")));
        
        wait = CommonUtil.waitreturner(driver,5,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='viewid-0']//div[@uuid='"+uuid+"']")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='viewid-0']//div[@uuid='"+uuid+"']")));
        
        WebElement vis = CommonUtil.elfinder(driver,"xpath","//div[@id='viewid-0']//div[@uuid='"+uuid+"']");
        
        vis.findElement(By.id("name_"+uuid)).click();

        wait = CommonUtil.waitreturner(driver,20,250);
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if(CommonUtil.elfinder(driver,"id","listinfo").getAttribute("uuid").equals(uuid)&&CommonUtil.elfinder(driver,"id","listinfo").getAttribute("clickedcol").equals("0"))
                    {
                        return true;
                    }
                }
                catch(Exception e)
                {}
                return false;
            }
        });
    }

    public static void clickVisitorsOnline(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));

        CommonUtil.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_monitor")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visitor_monitor")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
    }

    public static void clickWidget(WebDriver driver) throws Exception
    {
        VisitorWindow.clickChatButton(driver);
    }

    public static void chooseLatestVisitor(WebDriver driver,String uuid) throws Exception
    {
        try
        {
            // addVHRuleRecent(driver);            
            com.zoho.livedesk.util.common.actions.Tab.clickVisitorHistory(driver);
            com.zoho.livedesk.client.crmplus.visitorhistory.CommonFunctionsVH.createLastVisitedTodayList(driver,false);
            checkVisitorUUID(driver,uuid);
        }
        catch(Exception e)
        {
            throw e;
        }
    }

    public static String getLatestVisitorUUID(WebDriver driver,WebDriver visdriver,String portalname) throws Exception
    {
        try
        {
            String visitorId = VisitorWindow.getVisitorId(visdriver,portalname);

            clickVisitorsOnline(driver);

            VisitorsOnline.waitTillVisitorPresent(driver,visitorId);

            String uuid = verifyVisitor(driver,visitorId);

            return uuid;
        }
        catch(Exception e)
        {
            throw e;
        }
    }

    public static boolean verifyOppurtunity(WebDriver driver,String visitorid,String actualScore) throws Exception
    {
        chooseLatestVisitor(driver,visitorid);

        WebElement lselmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","listinfo"),"id","vstcrmdet");

        String currentScore = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,lselmt,"classname","vstinfotemp"),"tagname","em").getText();

        String noOfVisitsElement = com.zoho.livedesk.util.common.CommonUtil.getElement(driver,By.id("vstpastaction")).findElements(By.className("vstinfotemp")).get(1).getText();
        String visits = noOfVisitsElement.charAt(noOfVisitsElement.length()-1)+""; 
        int noOfVisits = Integer.parseInt(visits);
        String modifiedScore = (Integer.parseInt(actualScore) * noOfVisits) + "";

        if((actualScore.equals(currentScore)) || (modifiedScore.equals(currentScore)))
        {
            return true;
        }

        return false;
    }

    public static String currentLeadScore(WebDriver driver) throws Exception
    {
        WebElement lselmt = CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","listinfo"),"id","vstcrmdet");

        return CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,lselmt,"classname","vstinfotemp"),"tagname","em").getText();
    }

    public static void navigateToAutomation(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        clickSettings(driver);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));

        CommonUtil.elfinder(driver,"id","setting_sm_automation").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotabcontainer")));
    }

    public static void clickIntelligentTriggers(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        navigateToAutomation(driver);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));

        CommonUtil.elfinder(driver,"id","setting_sm_automation").click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotabcontainer")));
    }

    public static void addFieldsInCreateScoringRules(WebDriver driver,String pnum,String condition,String condition1,String criteria,String value1,String value2) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,10,200);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        final WebElement elmt = CommonUtil.elfinder(driver,"id","ldsettings");

        String cid = "prior"+pnum+"_col1_div";
        final String cdown = "prior"+pnum+"_col1_ddown";

        CommonUtil.elementfinder(driver,elmt,"id",cid).click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });

        CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"id",cdown),"id","srchtxt"),"tagname","input").sendKeys(condition);

        WebElement cond = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"id",cdown),"id","prior"+pnum+"_col10"),"tagname","li");

        wait.until(ExpectedConditions.visibilityOf(cond));

        cond.click();

        if(condition1 != null)
        {
            WebElement cond1 = CommonUtil.elementfinder(driver,elmt,"id","prior"+pnum+"_col4");
            if(cond1.getAttribute("comp") != null)
            {
                cond1.click();
                final String cdown1 = "prior"+pnum+"_col4_ddown";

                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        try
                        {
                            if((elmt.findElement(By.id(cdown1)).getAttribute("style")).equals("display: block;"))
                            {
                                return true;
                            }
                        }
                        catch(Exception e){}
                        return false;
                    }
                });

                CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"id",cdown1),"id","srchtxt"),"tagname","input").sendKeys(condition1);

                wait.until(ExpectedConditions.visibilityOf(CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"id",cdown1),"id","prior"+pnum+"_col40"),"tagname","li")));

                CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"id",cdown1),"id","prior"+pnum+"_col40"),"tagname","li").click();
            }
            else
            {
                CommonUtil.elementfinder(driver,cond1,"tagname","input").sendKeys(condition1);
            }
        }

        String qid = "prior"+pnum+"_col2_div";
        final String qdown = "prior"+pnum+"_col2_ddown";

        CommonUtil.elementfinder(driver,elmt,"id",qid).click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });

        List<WebElement> elmts = CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,elmt,"id",qdown),"id","prior"+pnum+"_col20").findElements(By.tagName("li"));

        for(WebElement elmts1:elmts)
        {
            if((elmts1.getAttribute("innerHTML")).contains(criteria))
            {
                CommonUtil.JSScroll(driver,elmts1);
                elmts1.click();
                break;
            }
        }

        String vid = "prior"+pnum+"_col3";
        final WebElement elmtip = CommonUtil.elementfinder(driver,elmt,"id",vid);

        if(criteria.equals("is between"))
        {
            CommonUtil.elementfinder(driver,elmtip,"id","col3_input1").sendKeys(value1);
            CommonUtil.elementfinder(driver,elmtip,"id","col3_input2").sendKeys(value2);
        }
        else
        {
            CommonUtil.elementfinder(driver,elmtip,"id","col3_input1").sendKeys(value1);
        }
    }

    public static void addPointsForRulesInLeadScoring(WebDriver driver,String points,boolean add) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        WebElement elmt = CommonUtil.elfinder(driver,"id","ldsettings");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldaddpoints")));

        if(add)
        {
            CommonUtil.elementfinder(driver,elmt,"id","addpoints").click();
        }
        else
        {
            CommonUtil.elementfinder(driver,elmt,"id","lesspoints").click();
        }

        CommonUtil.elementfinder(driver,elmt,"id","ldaddpoints").click();
        CommonUtil.elementfinder(driver,elmt,"id","ldaddpoints").clear();
        CommonUtil.elementfinder(driver,elmt,"id","ldaddpoints").sendKeys(points);

    }

    public static void clickApplyInCreateRulesLeadScoring(WebDriver driver) throws Exception
    {
        clickApplyInCreateRulesLeadScoring(driver,LeadScoringRealTime.etest);
    }
    public static void clickApplyInCreateRulesLeadScoring(WebDriver driver,ExtentTest etest) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        WebElement elmt = CommonUtil.elfinder(driver,"id","ldsettings");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cnfmbtm")));

        CommonUtil.elementfinder(driver,elmt,"classname","cnfmbtm").click();

        Tab.waitForLoading(driver,"addleadscorerule.do",etest);

    }

    public static void applyEdit(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));

        WebElement elmt = CommonUtil.elfinder(driver,"id","ldsettings");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cnfmbtm")));

        CommonUtil.elementfinder(driver,elmt,"classname","cnfmbtm").click();

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickMultiple(WebDriver driver,String bchk,int prior) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","advwrap"),"classname",bchk).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("prior"+(prior+1))));
    }

    public static void clickAddInLeadScoring(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        clickLeadScoring(driver);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));

        driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();

        Thread.sleep(1000);

        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                           if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                           {
                               return true;
                           }
                           return false;
                       }
                   });
    }

    public static void initiateChatVis(WebDriver driver,String vname,String vemail,String vphone,String vques) throws Exception
    {
        try
        {
            VisitorWindow.initiateChatVisTheme(driver,vname,vemail,vphone,vques,LeadScoringRealTime.etest);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","InitiateChat","Error",e);
        }
    }

    public static void initiateChatUser(WebDriver driver,String id,String msg)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,200);

            clickVisitorsOnline(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsales")));

            CommonUtil.elfinder(driver,"id",id).click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));

            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht"),"tagname","textarea").sendKeys(msg);
            CommonUtil.elementfinder(driver,CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","ldsettings"),"id","startcht"),"tagname","textarea").sendKeys(Keys.RETURN);

        }
        catch(Exception e)
        {
            System.out.println("Exception while initiating chat in leadscoring module : ");
        }
    }

    public static WebElement selectRuleInLeadScoring(WebDriver driver,String condition,String condition1,String criteria,String value1,String value2) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        String checkcond;

        if(condition1 != null)
        {
            if((condition.contains("Visitor") || condition.contains("Current Visit Source")) && !condition.contains("Visitor Source"))
            {
                if(value2 != null)
                {
                    checkcond = "If the "+condition+" "+condition1+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the "+condition+" "+condition1+" "+criteria+" "+value1;
                }
            }
            else
            {
                if(value2 != null)
                {
                    checkcond = "If the visitor "+condition+" "+condition1+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the visitor "+condition+" "+condition1+" "+criteria+" "+value1;
                }
            }
        }
        else
        {
            if((condition.contains("Visitor") || condition.contains("Current Visit Source")) && !condition.contains("Visitor Source"))
            {
                if(value2 != null)
                {
                    checkcond = "If the "+condition+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the "+condition+" "+criteria+" "+value1;
                }
            }
            else
            {
                if(value2 != null)
                {
                    checkcond = "If the visitor "+condition+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the visitor "+condition+" "+criteria+" "+value1;
                }
            }
        }

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("leadscore")));

        List<WebElement> list = CommonUtil.elfinder(driver,"id","leadscore").findElements(By.className("leadscrlst"));

        for(WebElement e : list)
        {
            if(e.getText().contains(checkcond))
            {
                CommonUtil.JSScroll(driver,e);

                return e;
            }
        }

        return null;
    }

    public static void editRuleLeadScoring(WebDriver driver,String cond1,String cond2,String qual,String val1,String val2) throws Exception
    {
        CommonUtil.elementfinder(driver,selectRuleInLeadScoring(driver,cond1,cond2,qual,val1,val2),"tagname","em").click();
    }

    public static boolean deleteRuleInLeadScoring(WebDriver driver,String condition,String condition1,String criteria,String value1,String value2) throws Exception
    {
        clickLeadScoring(driver);
        WebElement element = selectRuleInLeadScoring(driver,condition,condition1,criteria,value1,value2);

        FluentWait wait = CommonUtil.waitreturner(driver,30,200);

        CommonUtil.JSScroll(driver,CommonUtil.elementfinder(driver,element,"classname","deletescr"));

        try
        {
            CommonUtil.elementfinder(driver,element,"classname","deletescr").click();
        }
        catch(WebDriverException e)
        {
            CommonUtil.JSExecutor(driver, "window.scrollBy(0,100)");
            CommonUtil.elementfinder(driver,element,"classname","deletescr").click();
        }

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("lvd_popupsub")));

        WebElement popup = CommonUtil.elfinder(driver, "classname", "lvd_popupsub");

        try
        {
            CommonUtil.elementfinder(driver, popup, "id", "okbtn").click();
        }
        catch(Exception e)
        {
            driver.navigate().refresh();
            return false;
        }

        clickLeadScoring(driver);

        if(selectRuleInLeadScoring(driver,condition,condition1,criteria,value1,value2) != null)
            return false;
        return true;
    }

    public static void disableRuleInLeadScoring(WebDriver driver,String condition,String condition1,String criteria,String value1,String value2,boolean dchk) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement element = selectRuleInLeadScoring(driver,condition,condition1,criteria,value1,value2);

        CommonUtil.JSScroll(driver,CommonUtil.elementfinder(driver,element,"classname","scorestatus"));

        if(CommonUtil.elementfinder(driver,element,"classname","scorestatus").getAttribute("status").equals("true") && dchk)
        {
            try
            {
                CommonUtil.elementfinder(driver,element,"classname","scorestatus").click();
            }
            catch(WebDriverException e)
            {
                CommonUtil.JSExecutor(driver, "window.scrollBy(0,100)");
                CommonUtil.elementfinder(driver,element,"classname","scorestatus").click();
            }
        }
        else
        {
            try
            {
                CommonUtil.elementfinder(driver,element,"classname","scorestatus").click();
            }
            catch(WebDriverException e)
            {
                CommonUtil.JSExecutor(driver, "window.scrollBy(0,100)");
                CommonUtil.elementfinder(driver,element,"classname","scorestatus").click();
            }
        }

        try
        {
            if(dchk)
            {
                Tab.waitForLoading(driver,"disableleadscorerule.do",LeadScoringRealTime.etest);
            }
            else
            {
                Tab.waitForLoading(driver,"enableleadscorerule.do",LeadScoringRealTime.etest);
            }
        }
        catch(Exception e){e.printStackTrace();}
    }

    public static void acceptChat(WebDriver driver) throws Exception
    {
        ChatWindow.acceptChat(driver,LeadScoringRealTime.etest);
    }

    public static void sentMessageVisitor(WebDriver driver,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");

        driver.switchTo().frame(chframe);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lstxteditor")));

        CommonUtil.elfinder(driver,"id","lstxteditor").sendKeys(msg);
        CommonUtil.elfinder(driver,"id","lstxteditor").sendKeys(Keys.RETURN);

        driver.switchTo().defaultContent();
    }

    public static void sentMessageUser(WebDriver driver,String msg) throws Exception
    {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txteditor")));

        CommonUtil.elfinder(driver,"id","txteditor").sendKeys(msg);
        CommonUtil.elfinder(driver,"id","txteditor").sendKeys(Keys.RETURN);

    }

    public static void endChatUser(WebDriver driver) throws Exception
    {
           FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            CommonUtil.elfinder(driver,"id","txteditor").sendKeys("Hello there, welcome to testing team ...");
            CommonUtil.elfinder(driver,"id","txteditor").sendKeys(Keys.RETURN);

            Thread.sleep(500);

            CommonUtil.elfinder(driver,"id","endsession").click();

            Thread.sleep(1000);

            CommonUtil.elfinder(driver,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infodiv")));
            CommonUtil.elementfinder(driver,CommonUtil.elfinder(driver,"id","infodiv"),"linktext",ResourceManager.getRealValue("closewindow")).click();

            Thread.sleep(1000);
    }

    public static void endChatVisitor(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,30,250);

            WebElement chframe = CommonUtil.elfinder(driver,"id","zlsiframe");

            driver.switchTo().frame(chframe);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lstxteditor")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("optionbtn")));

            CommonUtil.elfinder(driver,"id","optionbtn").click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("endcht")));

            CommonUtil.elfinder(driver,"classname","endcht").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fedbckinfotxtid")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("fedbckinfotxtid")));

            driver.switchTo().defaultContent();

            CommonUtil.elfinder(driver,"id","zlscloseimg").click();

            Thread.sleep(1000);
        }
        catch(Exception e)
        {
            System.out.println("Exception while ending chat in leadscoring module : ");
        }
    }

    public static void waitTillVisitorLeaves(WebDriver driver,WebDriver visdriver) throws Exception
    {
        visdriver.get("https://www.zoho.com/");
        VisitorsOnline.waitTillVisitorLeaves(driver);
    }

    public static void visitSite(WebDriver driver,WebDriver visdriver,String widgetcode)
    {
        try
        {
            VisitorSite.openVis(visdriver,widgetcode);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visdriver,LeadScoringRealTime.etest,"LeadScoringRT","CommonFunctions","VisitSite",e);
        }
    }

    public static void reVisit(WebDriver driver,WebDriver visdriver,String portalname) throws IOException, InterruptedException
    {
        try
        {
            waitTillVisitorLeaves(driver,visdriver);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","CommonFunctions","RevisitingError",e);
        }
        try
        {
            visitSite(driver,visdriver,ExecuteStatements.getWidgetCodeFromEmbedName(driver,portalname));
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(visdriver,LeadScoringRealTime.etest,"LeadScoringRT","CommonFunctions","RevisitingError",e);
        }
    }

    public static void cleanUpState(WebDriver driver,String cond,String cond1,String qual,String val1,String val2)
    {
        try
        {
            setToAllVis(driver);
            deleteRuleInLeadScoring(driver,cond,cond1,qual,val1,val2);
        }
        catch(Exception e)
        {
            System.out.println("Exception while checking clean up state in lead scoring rt module : ");
            e.printStackTrace();
        }
    }

    public static void changeConfigInfo(WebDriver driver,String txt) throws Exception
    {
      try
      {
        FluentWait wait = CommonUtil.waitreturner(driver,30,250);

        CommonUtil.elfinder(driver,"id","fvinfo").click();
        CommonUtil.elfinder(driver,"id","fvinfo").sendKeys(txt);
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(CommonUtil.elfinder(driver,"id","fsubbutton")).getLocation().y+")");
        Thread.sleep(300);
        CommonUtil.elfinder(driver,"id","fsubbutton").click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("zls_ctn_wrap")));
      }
      catch(Exception e)
      {
        TakeScreenshot.screenshot(driver,LeadScoringRealTime.etest,"LeadScoringRT","CommonFunctions","JSAPIConfig",e);
      }
    }
    public static void choosePortal(WebDriver driver,String widgetcode,String setup) throws Exception
    {
        com.zoho.livedesk.client.JSAPIW.CommonFunctions.choosePortal(driver,widgetcode,setup);
    }
}
