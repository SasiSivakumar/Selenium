//$Id$
package com.zoho.livedesk.client;

import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;

public class TrackingCustomize {

	public static Hashtable result = new Hashtable();
	public static Hashtable hashtable = new Hashtable();
	public static Hashtable servicedown = new Hashtable();
	private static String url = "";
    public static ExtentTest etest;
    public static String integCRMFieldObj = "";

	public static Hashtable customize(WebDriver driver)
	{
		try
		{
            result = new Hashtable();
            integCRMFieldObj = "";

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC1"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            	url = ConfManager.requestURL();
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            try
			{
				Functions.closeBannersAfterLogin(driver);
			}
			catch(Exception e){}

            	wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));

			//Thread.sleep(1000);
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

			//Thread.sleep(1000);

			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
            driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            etest.log(Status.PASS,"Customize Icon is present");

            result.put("TRC1",true);

            WebElement window = driver.findElement(By.id("ldsettings"));
			List<WebElement> btns = window.findElements(By.className("cnfmbtm"));
			btns.get(1).click();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC2"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC2", isWindowAvail(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Hide Visitors Check Box");
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            checkHideVisitors(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC5"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC5", checkAction(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC6"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC6", checkLastActivityTime(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC7"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC7", checkPastChats(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC8"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC8", checkTimeSpent(driver));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC9"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC9", checkByVisits(driver));


            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC10"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC10", checkRuleType(driver, "1", "Browser", "is equal to", "Fire", "Mozilla Firefox", null));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC11"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC11", checkRuleType(driver, "1", "Browser", "is not equal to", "Chro", "Google Chrome", null));
			//Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC12"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC12", checkRuleType(driver, "2", "Country", "is equal to",  "Ind", "India", null));
			//Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC13"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC13", checkRuleType(driver, "2", "Country", "is not equal to", "Alg", "Algeria", null));
			//Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC14"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC14", checkRuleType(driver, "3", "IP Address", "is equal to", null, "12.1.1.1",null));
			//Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC15"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC15", checkRuleType(driver, "3", "IP Address", "is between", null, "12.1.1.2", "12.1.1.10"));
			//Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC16"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC16", checkRuleType(driver, "4", "Visitor Type", "is equal to", "Ret", "Returning",null));
			//Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC17"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC17", checkRuleType(driver, "4", "Visitor Type", "is not equal to", "N", "New",null));
            //Thread.sleep(1000);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC18"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC18", checkDropdown(driver, "1", "Browser"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC19"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC19", checkDropdown(driver, "1", "Country"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC20"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC20", checkDropdown(driver, "1", "Current Visit Source"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC21"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC21", checkDropdown(driver, "1", "Department"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC22"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC22", checkDropdown(driver, "1", "First Visit Source"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC23"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC23", checkDropdown(driver, "1", "Last Visit Source"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC24"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC24", checkDropdown(driver, "1", "Operating System"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC25"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC25", checkDropdown(driver, "1", "Region"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC26"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC26", checkDropdown(driver, "1", "Search Engine"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC27"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC27", checkDropdown(driver, "1", "System Status"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC28"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC28", checkDropdown(driver, "1", "Triggered Status"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC29"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC29", checkDropdown(driver, "1", "Visitor Availability"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC30"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC30", checkDropdown(driver, "1", "Visitor Type"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC31"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC31", checkDropdown(driver, "1", "Web Embed"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC32"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC32", checkCRMDropdown(driver, "1", "CRM Contact"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC33"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC33", checkCRMDropdown(driver, "1", "CRM Lead"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC34"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC34", checkCRMDropdown(driver, "1", "CRM Deal"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC35"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC35", checkCRMDropdown(driver, "1", "Visitor Stage in CRM"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC36"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC36", checkCRMRule(driver, "1", "CRM Contact", "Account Name", "is equal to", "Tester1"));
            //result.put("TRC37", checkCRMRule(driver, "1", "CRM Contact", "Asst Phone", "ends with", "5433"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC38"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC38", checkCRMRule(driver, "1", "CRM Contact", "Average Time Spent", "is more than", "7"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC39"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC39", checkCRMRule(driver, "1", "CRM Contact", "Days Visited", "is less than", "7"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC40"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC40", checkCRMRule(driver, "1", "CRM Contact", "Department", "is not equal to", "TestDepartment"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC41"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC41", checkCRMRule(driver, "1", "CRM Contact", "Description", "contains", "salesiq"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC42"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC42", checkCRMRule(driver, "1", "CRM Contact", "Email", "ends with", "@gmail.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC43"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC43", checkCRMRule(driver, "1", "CRM Contact", "Fax", "begins with", "+91"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC44"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC44", checkCRMRule(driver, "1", "CRM Contact", "First Name", "is equal to", "John"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC45"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC45", checkCRMRule(driver, "1", "CRM Contact", "Home Phone", "is equal to", "044-63447070"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC46"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC46", checkCRMRule(driver, "1", "CRM Lead", "Annual Revenue", "is more than", "70000"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC47"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC47", checkCRMRule(driver, "1", "CRM Lead", "Average Time Spent", "is more than", "7"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC48"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC48", checkCRMRule(driver, "1", "CRM Lead", "City", "begins with", "chen"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC49"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC49", checkCRMRule(driver, "1", "CRM Lead", "Company", "ends with", "chat"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC50"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC50", checkCRMRule(driver, "1", "CRM Lead", "Days Visited", "is less than", "7"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC51"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC51", checkCRMRule(driver, "1", "CRM Lead", "Description", "contains", "salesiq"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC52"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC52", checkCRMRule(driver, "1", "CRM Lead", "Designation", "is equal to", "Developer"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC53"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC53", checkCRMRule(driver, "1", "CRM Lead", "Email", "ends with", "@gmail.com"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC54"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC54", checkCRMRule(driver, "1", "CRM Lead", "Fax", "begins with", "+91-"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC55"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC55", checkCRMRule(driver, "1", "CRM Lead", "First Name", "is not equal to", "Tester1"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC56"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC56", checkCRMRule(driver, "1", "CRM Deal", "Closed Won", "is equal to", "5000"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC57"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC57", checkCRMRule(driver, "1", "CRM Deal", "Closing Date", "is before", "Next Week"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC58"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC58", checkCRMRule(driver, "1", "CRM Deal", "No of Open Deals", "is more than", "70000"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC59"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC59", checkCRMRule(driver, "1", "CRM Deal", "Revenue in pipeline", "is less than", "10000"));

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("TRC60"));
            ComplexReportFactory.setValues(etest,"Automation","Tracking - Customize");

            result.put("TRC60", checkCRMRule(driver, "1", "Visitor Stage in CRM", null, "is equal to", "Not available"));

            ComplexReportFactory.closeTest(etest);

        }
		catch(NoSuchElementException e)
		{
			TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","VisitorsOnlineTab","Error",e);
                  etest.log(Status.FATAL,"Module breakage occurred "+e);
                  System.out.println("~~Module breakage occurred");

            result.put("TRC1", false);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","VisitorsOnlineTab","Error",e);
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            result.put("TRC1", false);
		}
		hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
	}

	private static boolean isWindowAvail(WebDriver driver)
	{
		try
		{
			
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
            driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            //Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
			WebElement window = driver.findElement(By.id("ldsettings"));

			if((window.findElement(By.className("hdr")).getText()).contains(ResourceManager.getRealValue("tr_priorizevisitors")))
			{
				if(window.findElement(By.id("presets")) != null)
				{
					List<WebElement> btns = window.findElements(By.className("cnfmbtm"));
					if(((btns.get(0).getText()).equals(ResourceManager.getRealValue("common_apply"))) && ((btns.get(1).getText()).equals(ResourceManager.getRealValue("common_cancel"))))
					{
						btns.get(1).click();
						//Thread.sleep(1000);
						etest.log(Status.PASS,"Window Header and Buttons are checked");
                        return true;
					}
                    else{
                        TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","PrioritizeyourvisitorsWindow","MismatchContent:"+"ApplyOrCancelButton");
                    }
				}
                else{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","PrioritizeyourvisitorsWindow","PresetIsNotFound");
               }
			}
            else
            {
                TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","PrioritizeyourvisitorsWindow","MismatchContentInHeader");
            }
        }
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","PrioritizeyourvisitorsWindow","Error",e);

            System.out.println("Exception while checking if tracking customize window is available : "+e);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","PrioritizeyourvisitorsWindow","Error",e);

            System.out.println("Exception while checking if tracking customize window is available : "+e);
		}
		return false;
	}

    private static void closePopup1(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,20,250);

            Thread.sleep(500);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
            
			WebElement window = driver.findElement(By.id("ldsettings"));
			List<WebElement> btns = window.findElements(By.className("cnfmbtm"));

            btns.get(1).click();
            
            etest.log(Status.INFO,"Cancel button is clicked");
            
            final WebElement popup = driver.findElement(By.id("ldsettings"));
            
            Long t1 = new Long(System.currentTimeMillis());
            
            for(;;)
            {
                if(!popup.isDisplayed())
                {
                    break;
                }
                
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2 - t1 >= 5000)
                {
                    break;
                }
            }
            
            wait.until(new Function<WebDriver,Boolean>()
                       {
                           public Boolean apply(WebDriver driver)
                           {
                               if(popup.getAttribute("style").contains("none"))
                               {
                                   return true;
                               }
                               return false;
                           }
                       });
            
            Thread.sleep(3000);
            
            etest.log(Status.INFO,"Customize window is closed");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CloseWindow","Error",e);
            System.out.println("Exception while closing popup in tracking customize window : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CloseWindow","Error",e);
            System.out.println("Exception while closing popup in tracking customize window : "+e);
        }
    }
    
    private static void savePopup(WebDriver driver)
    {
        try
        {
            FluentWait wait = CommonUtil.waitreturner(driver,20,250);
            
            Thread.sleep(500);
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
            
            WebElement window = driver.findElement(By.id("ldsettings"));
            List<WebElement> btns = window.findElements(By.className("cnfmbtm"));
            
            btns.get(0).click();
            
            etest.log(Status.INFO,"Save button is clicked");
            
            final WebElement popup = driver.findElement(By.id("ldsettings"));
            
            Long t1 = new Long(System.currentTimeMillis());
            
            for(;;)
            {
                if(!popup.isDisplayed())
                {
                    break;
                }
                
                Long t2 = new Long(System.currentTimeMillis());
                
                if(t2 - t1 >= 5000)
                {
                    break;
                }
            }
            
            wait.until(new Function<WebDriver,Boolean>()
                       {
                           public Boolean apply(WebDriver driver)
                           {
                               if(popup.getAttribute("style").contains("none"))
                               {
                                   return true;
                               }
                               return false;
                           }
                       });
            
            Thread.sleep(3000);
            
            etest.log(Status.INFO,"Customize window is closed");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CloseWindow","Error",e);
            System.out.println("Exception while closing popup in tracking customize window : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CloseWindow","Error",e);
            System.out.println("Exception while closing popup in tracking customize window : "+e);
        }
    }

	private static void checkHideVisitors(WebDriver driver)
	{
		try
		{
			result.put("TRC3", false);
			result.put("TRC4", false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
            driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            WebElement window = driver.findElement(By.id("ldsettings"));
            
            WebElement chkbx = window.findElement(By.id("ldchckbxmn"));
			
			if("chckbx".equals(chkbx.findElement(By.id("chckbx")).getAttribute("class")))
			{
				chkbx.findElement(By.id("connectagents")).click();
			}
			chkbx = window.findElement(By.id("ldchckbxmn"));

			if("chckbxsel".equals(chkbx.findElement(By.id("chckbx")).getAttribute("class")))
			{
				chkbx.findElement(By.id("connectagents")).click();
				savePopup(driver);
            }
			else
			{
				savePopup(driver);
			}

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            chkbx = window.findElement(By.id("ldchckbxmn"));

			if("chckbx".equals(chkbx.findElement(By.id("chckbx")).getAttribute("class")))
			{
                etest.log(Status.PASS,"Uncheck the checkbox is checked");
                result.put("TRC3", true);
			}
            else{
               TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckBox-HideVisitorsContactedByOtherOperators","CheckBoxIsNotDisabled");
            }
			
            closePopup1(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            chkbx = window.findElement(By.id("ldchckbxmn"));
			
			if("chckbxsel".equals(chkbx.findElement(By.id("chckbx")).getAttribute("class")))
			{
				chkbx.findElement(By.id("connectagents")).click();
			}
			chkbx = window.findElement(By.id("ldchckbxmn"));

			if("chckbx".equals(chkbx.findElement(By.id("chckbx")).getAttribute("class")))
			{
				chkbx.findElement(By.id("connectagents")).click();
				savePopup(driver);
			}
			else
			{
				savePopup(driver);
			}

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
			window = driver.findElement(By.id("ldsettings"));
			chkbx = window.findElement(By.id("ldchckbxmn"));
			if("chckbxsel".equals(chkbx.findElement(By.id("chckbx")).getAttribute("class")))
			{
				etest.log(Status.PASS,"Check the checkbox is checked");
                result.put("TRC4", true);
			}
            else{
                TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckBox-HideVisitorsContactedByOtherOperators","CheckBoxIsNotEnabled");
            }
			
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckBox-HideVisitorsContactedByOtherOperators","Error",e);

            System.out.println("Exception while checking hide visitors in tracking customize window : "+e);
            
            closePopup1(driver);
		}
	}

    private static boolean checkAction(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.elementToBeClickable(By.id("presets_div")));
			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
				if(title.contains(ResourceManager.getRealValue("trc_byaction")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

            savePopup(driver);

            //Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            if((ResourceManager.getRealValue("trc_byaction")).equals(driver.findElement(By.id("presets_div")).findElement(By.className("txtelips")).getText()))
			{
				WebElement col1 = driver.findElement(By.id("prior1_col1_div"));
				WebElement col2 = driver.findElement(By.id("prior1_col2_div"));
				WebElement col3 = driver.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1"));

				String col1_txt = col1.findElement(By.className("txtelips")).getText();
				String col2_txt = col2.findElement(By.className("txtelips")).getText();
				String col3_txt = col3.getAttribute("title");

                if(!(col1_txt.equals(ResourceManager.getRealValue("trc_actionsystemstatus"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_isequalto"))) || !(col3_txt.equals("Triggered Replied, Responded, Missed, Waiting")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","MismatchContentInFirstRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior2_col1_div"));
				col2 = driver.findElement(By.id("prior2_col2_div"));
				col3 = driver.findElement(By.id("prior2_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_actionsystemstatus"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_isequalto"))) || !(col3_txt.equals("Clicked")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","MismatchContentInSecondRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior3_col1_div"));
				col2 = driver.findElement(By.id("prior3_col2_div"));
				col3 = driver.findElement(By.id("prior3_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_actionsystemstatus"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_isequalto"))) || !(col3_txt.equals("Contacted, Triggered")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","MismatchContentInThirdRow");
                    closePopup1(driver);
					return false;
				}
				col1 = driver.findElement(By.id("prior4_col1_div"));
				col2 = driver.findElement(By.id("prior4_col2_div"));
				col3 = driver.findElement(By.id("prior4_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_actionsystemstatus"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_isequalto"))) || !(col3_txt.equals("Accessed")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","MismatchContentInFourthRow");
                    closePopup1(driver);
					return false;
				}
				etest.log(Status.PASS,"By Actions Default content is checked");
                closePopup1(driver);
                return true;
			}
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","MismatchContent:ByActions");
			closePopup1(driver);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","Error",e);
            System.out.println("Exception while checking sort by actions in tracking customize window : "+e);
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckActionsInWindow","Error",e);
            System.out.println("Exception while checking sort by actions in tracking customize window : "+e);
            closePopup1(driver);
		}
		return false;
	}


	private static boolean checkLastActivityTime(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.elementToBeClickable(By.id("presets_div")));
			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_bylastactivitytime")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

			savePopup(driver);

            //Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            if((ResourceManager.getRealValue("trc_bylastactivitytime")).equals(driver.findElement(By.id("presets_div")).findElement(By.className("txtelips")).getText()))
			{
				WebElement col1 = driver.findElement(By.id("prior1_col1_div"));
				WebElement col2 = driver.findElement(By.id("prior1_col2_div"));
				WebElement col3 = driver.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1"));

				String col1_txt = col1.findElement(By.className("txtelips")).getText();
				String col2_txt = col2.findElement(By.className("txtelips")).getText();
				String col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timesincelastaction"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_islessthan"))) || !(col3_txt.equals("1 "+ResourceManager.getRealValue("common_minute"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","MismatchContentInFirstRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior2_col1_div"));
				col2 = driver.findElement(By.id("prior2_col2_div"));
				col3 = driver.findElement(By.id("prior2_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timesincelastaction"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_islessthan"))) || !(col3_txt.equals("3 "+ResourceManager.getRealValue("common_minutes"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","MismatchContentInSecondRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior3_col1_div"));
				col2 = driver.findElement(By.id("prior3_col2_div"));
				col3 = driver.findElement(By.id("prior3_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timesincelastaction"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_islessthan"))) || !(col3_txt.equals("5 "+ResourceManager.getRealValue("common_minutes"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","MismatchContentInThirdRow");
                    closePopup1(driver);
					return false;
				}
				col1 = driver.findElement(By.id("prior4_col1_div"));
				col2 = driver.findElement(By.id("prior4_col2_div"));
				col3 = driver.findElement(By.id("prior4_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timesincelastaction"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_islessthan"))) || !(col3_txt.equals("10 "+ResourceManager.getRealValue("common_minutes"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","MismatchContentInFourthRow");
                    closePopup1(driver);
					return false;
				}
                etest.log(Status.PASS,"By Last Activity Time Default content is checked");
                closePopup1(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","MismatchContent:ByLastActivityTime");
            closePopup1(driver);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","Error",e);
            System.out.println("Exception while checking sort by last activity time in tracking customize window : "+e);
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByLastActivityTime","Error",e);
            System.out.println("Exception while checking sort by last activity time in tracking customize window : "+e);
            closePopup1(driver);
		}
		return false;
	}


	public static boolean checkPastChats(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.elementToBeClickable(By.id("presets_div")));
			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_bypastchats")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

            savePopup(driver);

            //Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            if((ResourceManager.getRealValue("trc_bypastchats")).equals(driver.findElement(By.id("presets_div")).findElement(By.className("txtelips")).getText()))
			{
				WebElement col1 = driver.findElement(By.id("prior1_col1_div"));
				WebElement col2 = driver.findElement(By.id("prior1_col2_div"));
				WebElement col3 = driver.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1"));

				String col1_txt = col1.findElement(By.className("txtelips")).getText();
				String col2_txt = col2.findElement(By.className("txtelips")).getText();
				String col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofpastchats"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("7")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","MismatchContentInFirstRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior2_col1_div"));
				col2 = driver.findElement(By.id("prior2_col2_div"));
				col3 = driver.findElement(By.id("prior2_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofpastchats"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("5")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","MismatchContentInSecondRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior3_col1_div"));
				col2 = driver.findElement(By.id("prior3_col2_div"));
				col3 = driver.findElement(By.id("prior3_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofpastchats"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("3")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","MismatchContentInThirdRow");
                    closePopup1(driver);
					return false;
				}
				col1 = driver.findElement(By.id("prior4_col1_div"));
				col2 = driver.findElement(By.id("prior4_col2_div"));
				col3 = driver.findElement(By.id("prior4_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofpastchats"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("1")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","MismatchContentInFourthRow");
                    closePopup1(driver);
					return false;
				}

                etest.log(Status.PASS,"By Past Chats Default content is checked");
                closePopup1(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","MismatchCotent:ByPastChats");
            closePopup1(driver);
        }
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","Error",e);
            System.out.println("Exception while checking sort by past chats in tracking customize window : "+e);
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByPastChats","Error",e);
            System.out.println("Exception while checking sort by past chats in tracking customize window : "+e);
            closePopup1(driver);
		}
		return false;
	}

	private static boolean checkTimeSpent(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("presets_div")));
			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_bytimespent")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

            savePopup(driver);

            //Thread.sleep(1000);
            wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            if((ResourceManager.getRealValue("trc_bytimespent")).equals(driver.findElement(By.id("presets_div")).findElement(By.className("txtelips")).getText()))
			{

				WebElement col1 = driver.findElement(By.id("prior1_col1_div"));
				WebElement col2 = driver.findElement(By.id("prior1_col2_div"));
				WebElement col3 = driver.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1"));

				String col1_txt = col1.findElement(By.className("txtelips")).getText();
				String col2_txt = col2.findElement(By.className("txtelips")).getText();
				String col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timeonsite"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("10 "+ResourceManager.getRealValue("common_minutes"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","MismatchContentInFirstRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior2_col1_div"));
				col2 = driver.findElement(By.id("prior2_col2_div"));
				col3 = driver.findElement(By.id("prior2_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timeonsite"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("3 "+ResourceManager.getRealValue("common_minutes"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","MismatchContentInSecondRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior3_col1_div"));
				col2 = driver.findElement(By.id("prior3_col2_div"));
				col3 = driver.findElement(By.id("prior3_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timeonsite"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("1 "+ResourceManager.getRealValue("common_minute"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","MismatchContentInThirdRow");
                    closePopup1(driver);
					return false;
				}
				col1 = driver.findElement(By.id("prior4_col1_div"));
				col2 = driver.findElement(By.id("prior4_col2_div"));
				col3 = driver.findElement(By.id("prior4_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_timeonsite"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("0 "+ResourceManager.getRealValue("common_seconds"))))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","MismatchContentInFourthRow");
                    closePopup1(driver);
					return false;
				}

                etest.log(Status.PASS,"By Time Spent Default content is checked");
                closePopup1(driver);
				return true;
			}
			TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","MismatchContent:ByTimeSpent");
            closePopup1(driver);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","Error",e);
            System.out.println("Exception while checking sort by time spent in tracking customize window : "+e);
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByTimeSpent","Error",e);
            System.out.println("Exception while checking sort by time spent in tracking customize window : "+e);
            closePopup1(driver);
		}
		return false;
	}

	private static boolean checkByVisits(WebDriver driver)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.elementToBeClickable(By.id("presets_div")));
			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_byvisits")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

            savePopup(driver);

            //Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();

            if((ResourceManager.getRealValue("trc_byvisits")).equals(driver.findElement(By.id("presets_div")).findElement(By.className("txtelips")).getText()))
			{
				WebElement col1 = driver.findElement(By.id("prior1_col1_div"));
				WebElement col2 = driver.findElement(By.id("prior1_col2_div"));
				WebElement col3 = driver.findElement(By.id("prior1_col3")).findElement(By.id("col3_input1"));

				String col1_txt = col1.findElement(By.className("txtelips")).getText();
				String col2_txt = col2.findElement(By.className("txtelips")).getText();
				String col3_txt = col3.getAttribute("title");

                if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofvisits"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("25")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","MismatchContentInFirstRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior2_col1_div"));
				col2 = driver.findElement(By.id("prior2_col2_div"));
				col3 = driver.findElement(By.id("prior2_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

                if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofvisits"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("10")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","MismatchContentInSecondRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior3_col1_div"));
				col2 = driver.findElement(By.id("prior3_col2_div"));
				col3 = driver.findElement(By.id("prior3_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofvisits"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("5")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","MismatchContentInThirdRow");
                    closePopup1(driver);
					return false;
				}

				col1 = driver.findElement(By.id("prior4_col1_div"));
				col2 = driver.findElement(By.id("prior4_col2_div"));
				col3 = driver.findElement(By.id("prior4_col3")).findElement(By.id("col3_input1"));

				col1_txt = col1.findElement(By.className("txtelips")).getText();
				col2_txt = col2.findElement(By.className("txtelips")).getText();
				col3_txt = col3.getAttribute("title");

				if(!(col1_txt.equals(ResourceManager.getRealValue("trc_noofvisits"))) || !(col2_txt.equals(ResourceManager.getRealValue("trc_ismorethan"))) || !(col3_txt.equals("0")))
				{
                    TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","MismatchContentInFourthRow");
                    closePopup1(driver);
					return false;
				}
                etest.log(Status.PASS,"By Visits Default content is checked");
                closePopup1(driver);
				return true;
			}
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","MismatchContent:ByVisits");
			closePopup1(driver);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","Error",e);
            System.out.println("Exception while checking sort by visits in tracking customize window : "+e);
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckByVisits","Error",e);
            System.out.println("Exception while checking sort by visits in tracking customize window : "+e);
            closePopup1(driver);
		}
		return false;
	}

	private static boolean checkRuleType(WebDriver driver, String row, String type, String criteria, String dropdown, String value, String value2)
	{
		try
		{
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
			
			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_bylastactivitytime")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

			String tid = "prior"+row+"_col1_div";
			String tdname = "prior"+row+"_col1_ddown";

			driver.findElement(By.id(tid)).click();
			//Thread.sleep(500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(tdname)));
			WebElement elmt = driver.findElement(By.id(tdname));

			List<WebElement> lis1=elmt.findElements(By.tagName("li"));

			for(int i=0;i<lis1.size();i++)
			{
				WebElement element = lis1.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(type))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}

			String cid = "prior"+row+"_col2_div";
			String cdname = "prior"+row+"_col2_ddown";

			driver.findElement(By.id(cid)).click();
			//Thread.sleep(500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(cdname)));
			WebElement elmt3 = driver.findElement(By.id(cdname));

			List<WebElement> lis2=elmt3.findElements(By.tagName("li"));

			for(int i=0;i<lis2.size();i++)
			{
				WebElement element = lis2.get(i);
				WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(criteria))
				{
					element.click();
					//Thread.sleep(1000);
					break;
				}
			}

			String vid = "prior"+row+"_col3";

			driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).click();
			driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).clear();

			if(dropdown != null)
			{
				typeKeys(driver,vid,driver.findElement(By.id(vid)).findElement(By.id("col3_input1")), dropdown, value);
			}
			else
			{
				driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).sendKeys(value);
			}


			if(value2 != null)
			{
				driver.findElement(By.id(vid)).findElement(By.id("col3_input2")).click();
				driver.findElement(By.id(vid)).findElement(By.id("col3_input2")).clear();
				driver.findElement(By.id(vid)).findElement(By.id("col3_input2")).sendKeys(value2);
                //wait.until(ExpectedConditions.textToBePresentInElement(By.id(vid).findElement(By.id("col3_input2")),value2));
				//Thread.sleep(1000);
			}

			savePopup(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			//Thread.sleep(1000);

            wait.until(ExpectedConditions.elementToBeClickable(By.id("ldsettings")));
			
            WebElement col1 = driver.findElement(By.id(tid));
			WebElement col2 = driver.findElement(By.id(cid));
			WebElement col3 = driver.findElement(By.id(vid)).findElement(By.id("col3_input1"));

			String col4_txt="";
			if(value2 != null)
			{
				WebElement col4 = driver.findElement(By.id(vid)).findElement(By.id("col3_input2"));
				col4_txt = col4.getAttribute("title");
			}

			String col1_txt = col1.findElement(By.className("txtelips")).getText();
			String col2_txt = col2.findElement(By.className("txtelips")).getText();
			String col3_txt = col3.getAttribute("title");

			if((col1_txt.equals(type)) && (col2_txt.equals(criteria)) && (col3_txt.equals(value)))
			{
				if(value2 == null)
				{
                    etest.log(Status.PASS,"Rule is checked");
                    closePopup1(driver);
					return true;
				}
				else
				{
					if(value2.equals(col4_txt))
					{
                        etest.log(Status.PASS,"Rule is checked");
                        closePopup1(driver);
						return true;
					}
                    else{
                       TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+type+","+criteria+","+value,"MismatchContent"+value2);
                    }
				}
			}
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+type+","+criteria+","+value,"MismatchContent");
            closePopup1(driver);
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+type+","+criteria+","+value,"Error",e);
            System.out.println("Exception while checking rule in tracking customize window : "+criteria+" - - - - - "+e);
            closePopup1(driver);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+type+","+criteria+","+value,"Error",e);
            System.out.println("Exception while checking rule in tracking customize window : "+criteria+" - - - - - "+e);
            closePopup1(driver);
		}
		return false;
	}

	public static void typeKeys(WebDriver driver, String vid, WebElement webelement, String dropdown, String value) throws Exception
	{
		webelement.sendKeys(dropdown);
		WebElement elmt = driver.findElement(By.id(vid)).findElement(By.id("col3_div"));

		List<WebElement> lis=elmt.findElements(By.tagName("li"));

		for(int i=0;i<lis.size();i++)
		{
			WebElement element = lis.get(i);
			WebElement element2 = element.findElement(By.tagName("div"));
			WebElement element3 = element2.findElement(By.tagName("em"));
			String title = element3.getAttribute("title");
			if(title.equals(value))
			{
				element.click();
				//Thread.sleep(1000);
				break;
			}
		}
		//Thread.sleep(500);
	}

    private static boolean checkDropdown(WebDriver driver,String row,String rule)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Tab.clickVisitorsOnline(driver);
            
            etest.log(Status.INFO,"Visitors Online is clicked");

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
			
            etest.log(Status.INFO,"Customize is clicked");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
            
            etest.log(Status.INFO,"Customize window is visible");
            
			WebElement window = driver.findElement(By.id("ldsettings"));
			List<WebElement> btns = window.findElements(By.className("cnfmbtm"));

			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

            for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_bylastactivitytime")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}
            
            etest.log(Status.INFO,ResourceManager.getRealValue("trc_bylastactivitytime")+" is selected");

			String tid = "prior"+row+"_col1_div";
			String tdname = "prior"+row+"_col1_ddown";

            driver.findElement(By.id(tid)).click();
			//Thread.sleep(500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(tdname)));
			WebElement elmt = driver.findElement(By.id(tdname));

			List<WebElement> lis1=elmt.findElements(By.tagName("li"));

			for(int i=0;i<lis1.size();i++)
			{
				WebElement element = lis1.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(rule))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
					element.click();
					break;
				}
			}
            
            etest.log(Status.INFO,rule+" is selected");

            String vid = "prior"+row+"_col3";

			driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).click();
			driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).clear();

            final WebElement elmtdd = driver.findElement(By.id(vid)).findElement(By.id("col3_div"));

            wait.until(new Function<WebDriver,Boolean>()
                       {
                           public Boolean apply(WebDriver driver)
                           {
                               if((elmtdd.getAttribute("style")).contains("block"))
                               {
                                   return true;
                               }
                               return false;
                           }
                       });

            etest.log(Status.PASS,"DropDown is checked");

            closePopup1(driver);
            
            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckDropDown"+rule,"Error",e);
            System.out.println("Exception while checking Dropdown in tracking customize : "+ rule + "  " +e);
            closePopup1(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckDropDown"+rule,"Error",e);
            System.out.println("Exception while checking Dropdown in tracking customize : "+ rule + "  " +e);
            closePopup1(driver);
            return false;
        }
    }

    private static boolean checkCRMDropdown(WebDriver driver, String row, String rule)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Tab.clickVisitorsOnline(driver);
            
            etest.log(Status.INFO,"Visitors Online is clicked");

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
            
            etest.log(Status.INFO,"Customize is clicked");
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
            
            etest.log(Status.INFO,"Customize window is visible");
            
			WebElement window = driver.findElement(By.id("ldsettings"));
			List<WebElement> btns = window.findElements(By.className("cnfmbtm"));


			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

            for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
//				WebElement element2 = element.findElement(By.tagName("div"));
//				WebElement element3 = element2.findElement(By.tagName("span"));
//				String title = element3.getAttribute("title");
                String title = element.getAttribute("innerHTML");
                if(title.contains(ResourceManager.getRealValue("trc_bylastactivitytime")))
				{
                    CommonUtil.inViewPort(element);Thread.sleep(500);
                    element.click();
					break;
				}
			}
            
            etest.log(Status.INFO,ResourceManager.getRealValue("trc_bylastactivitytime")+" is selected");
            
            if(rule.equals("Visitor Stage in CRM"))
            {
                String tid = "prior"+row+"_col1_div";
                String tdname = "prior"+row+"_col1_ddown";

                driver.findElement(By.id(tid)).click();
                //Thread.sleep(500);

                wait.until(ExpectedConditions.presenceOfElementLocated(By.id(tdname)));
                WebElement elmt = driver.findElement(By.id(tdname));

                List<WebElement> lis1=elmt.findElements(By.tagName("li"));

                for(int i=0;i<lis1.size();i++)
                {
                    WebElement element = lis1.get(i);
//                    WebElement element2 = element.findElement(By.tagName("div"));
//                    WebElement element3 = element2.findElement(By.tagName("span"));
//                    String title = element3.getAttribute("title");
                    String title = element.getAttribute("innerHTML");
                    if(title.contains(rule))
                    {
                        CommonUtil.inViewPort(element);Thread.sleep(500);
                        element.click();
                        break;
                    }
                }
                
                etest.log(Status.INFO,rule+" is selected");

                String vid = "prior"+row+"_col3";

                driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).click();
                driver.findElement(By.id(vid)).findElement(By.id("col3_input1")).clear();

                final WebElement elmtdd = driver.findElement(By.id(vid)).findElement(By.id("col3_div"));

                wait.until(new Function<WebDriver,Boolean>()
                           {
                               public Boolean apply(WebDriver driver)
                               {
                                   if((elmtdd.getAttribute("style")).contains("block"))
                                   {
                                       return true;
                                   }
                                   return false;
                               }
                           });

                etest.log(Status.PASS,"DropDown is checked");

                closePopup1(driver);
                
                return true;
            }
            else
            {
                String tid = "prior"+row+"_col1_div";
                String tdname = "prior"+row+"_col1_ddown";

                driver.findElement(By.id(tid)).click();
                //Thread.sleep(500);

                wait.until(ExpectedConditions.presenceOfElementLocated(By.id(tdname)));

                driver.findElement(By.id(tdname)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(rule);

                driver.findElement(By.id("prior"+row+"_col10")).findElement(By.tagName("li")).click();

                etest.log(Status.INFO,rule+" is selected");
                
                Thread.sleep(500);

                driver.findElement(By.id("prior"+row+"_col4_div")).click();

                final WebElement elmtdd = driver.findElement(By.id("prior"+row+"_col4_ddown"));

                wait.until(new Function<WebDriver,Boolean>()
                           {
                               public Boolean apply(WebDriver driver)
                               {
                                   if((elmtdd.getAttribute("style")).contains("block"))
                                   {
                                       return true;
                                   }
                                   return false;
                               }
                           });

                etest.log(Status.PASS,"DropDown is checked");

                closePopup1(driver);
                
                return true;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckDropDown:"+rule,"Error",e);
            System.out.println("Exception while checking CRM Dropdown in tracking customize : "+ rule + "  " +e);
            closePopup1(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckDropDown:"+rule,"Error",e);
            System.out.println("Exception while checking CRM Dropdown in tracking customize : "+ rule + "  " +e);
            closePopup1(driver);
            return false;
        }
    }

    private static boolean checkCRMRule(WebDriver driver, String row, String rule, String rule1, String cond, String val)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(20,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))));
			driver.findElement(By.partialLinkText(ResourceManager.getRealValue("shortcut_tracking"))).click();
            
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			
            etest.log(Status.INFO,"Visitors Online is clicked");
            
            driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
            
            etest.log(Status.INFO,"Customize is clicked");
			
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldsettings")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
            
            etest.log(Status.INFO,"Customize window is opened");
            
			WebElement window = driver.findElement(By.id("ldsettings"));
			List<WebElement> btns = window.findElements(By.className("cnfmbtm"));


			driver.findElement(By.id("presets_div")).click();
			WebElement elmt2 = driver.findElement(By.id("presets_ddown"));
			List<WebElement> lis=elmt2.findElements(By.tagName("li"));

            for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
				WebElement element2 = element.findElement(By.tagName("div"));
				WebElement element3 = element2.findElement(By.tagName("span"));
				String title = element3.getAttribute("title");
				if(title.equals(ResourceManager.getRealValue("trc_bylastactivitytime")))
				{
					element.click();
					break;
				}
			}

            etest.log(Status.INFO,ResourceManager.getRealValue("trc_bylastactivitytime")+" is selected");
            
            String integCRMFieldObj2 = ExecuteStatements.getIntegFieldCRMObjectWithOutExcep(driver);
            
            if(!integCRMFieldObj.equals(integCRMFieldObj2))
            {
                etest.log(Status.INFO,"<pre>"+integCRMFieldObj2+"</pre>");
                integCRMFieldObj = integCRMFieldObj2;
            }
            
            String tid = "prior"+row+"_col1_div";
            String tdname = "prior"+row+"_col1_ddown";

            driver.findElement(By.id(tid)).click();
            //Thread.sleep(500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(tdname)));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(tdname)));

            driver.findElement(By.id(tdname)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(rule);

            driver.findElement(By.id("prior"+row+"_col10")).findElement(By.tagName("li")).click();

            etest.log(Status.INFO,rule+" is selected");
            
            Thread.sleep(500);
            
            String tid1 = "prior"+row+"_col4_div";
            String tdname1 = "prior"+row+"_col4_ddown";

            if(!(rule.equals("Visitor Stage in CRM")))
            {
                driver.findElement(By.id(tid1)).click();

                final WebElement elmtdd = driver.findElement(By.id(tdname1));

                wait.until(new Function<WebDriver,Boolean>()
                           {
                               public Boolean apply(WebDriver driver)
                               {
                                   if((elmtdd.getAttribute("style")).contains("block"))
                                   {
                                       return true;
                                   }
                                   return false;
                               }
                           });
                if(rule.equals("CRM Deal"))
                {
                    List<WebElement> elmtspot = driver.findElement(By.id(tdname1)).findElements(By.tagName("li"));

                    for(WebElement elmtpot:elmtspot)
                    {
                        if((elmtpot.getText()).equals(rule1))
                        {
                            elmtpot.findElement(By.tagName("span")).click();
                            break;
                        }
                    }
                    
                    etest.log(Status.INFO,rule1+" is selected");
                }
                else
                {
                    driver.findElement(By.id(tdname1)).findElement(By.id("srchtxt")).findElement(By.tagName("input")).sendKeys(rule1);

                    driver.findElement(By.id("prior"+row+"_col40")).findElement(By.tagName("li")).click();
                    
                    etest.log(Status.INFO,rule1+" is selected");
                }
            }
            
            Thread.sleep(500);

            String cid = "prior"+row+"_col2_div";
            String cdname = "prior"+row+"_col2_ddown";

            driver.findElement(By.id(cid)).click();
            
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(cdname)));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(cdname)));
            
            List<WebElement> conelmts = driver.findElement(By.id(cdname)).findElements(By.tagName("li"));

            for(WebElement conelmt:conelmts)
            {
                if((conelmt.getText()).equals(cond))
                {
                    conelmt.findElement(By.tagName("span")).click();
                    break;
                }
            }
            
            etest.log(Status.INFO,cond+" is selected");

            String vid = "prior"+row+"_col3";
            String vid1 = "prior"+row+"_col3_div";
            String vdname1 = "prior"+row+"_col3_ddown";
            if(rule1!=null)
            {
                if(rule1.equals("Closing Date"))
                {
                    driver.findElement(By.id(vid1)).click();

                    List<WebElement> valelmts = driver.findElement(By.id(vdname1)).findElements(By.tagName("li"));

                    for(WebElement valelmt:valelmts)
                    {
                        if((valelmt.getText()).equals(val))
                        {
                            valelmt.findElement(By.tagName("span")).click();
                            break;
                        }
                    }
                    
                    etest.log(Status.INFO,val+" is selected");
                }
                else
                {
                    driver.findElement(By.id("col3input")).findElement(By.tagName("input")).click();
                    driver.findElement(By.id("col3input")).findElement(By.tagName("input")).clear();
                    driver.findElement(By.id("col3input")).findElement(By.tagName("input")).sendKeys(val);
                    
                    etest.log(Status.INFO,val+" is entered");
                }
            }
            else
            {
                driver.findElement(By.id("col3input")).findElement(By.tagName("input")).click();
                driver.findElement(By.id("col3input")).findElement(By.tagName("input")).clear();
                driver.findElement(By.id("col3input")).findElement(By.tagName("input")).sendKeys(val);
                
                etest.log(Status.INFO,val+" is enterred");
            }
            
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+rule+","+rule1+","+cond+","+val,"CheckBefore",0);

            savePopup(driver);
            
            Tab.clickChatHistory(driver);
            Tab.clickVisitorsOnline(driver);
            
            etest.log(Status.INFO,"Visitors Online is clicked");

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"ldsales\"]/div[2]/em")));
			driver.findElement(By.className("usrinfo")).findElement(By.tagName("em")).click();
            
            etest.log(Status.INFO,"Customize is clicked");
            
            wait.until(ExpectedConditions.elementToBeClickable(By.id("ldsettings")));
			window = driver.findElement(By.id("ldsettings"));
			btns = window.findElements(By.className("cnfmbtm"));

            if(rule1!=null)
            {
                if(rule1.equals("Average Time Spent"))
                {
                    rule1 = "Average Time Spent (Minutes)";
                }
            }

            if(!(rule.equals("Visitor Stage in CRM")))
            {
                WebElement col1 = driver.findElement(By.id(tid));
                WebElement col2 = driver.findElement(By.id(cid));
                WebElement col3;
                if(rule1.equals("Closing Date"))
                {
                    col3 = driver.findElement(By.id(vid1));
                }
                else
                {
                    col3 = driver.findElement(By.id(vid)).findElement(By.id("col3_input1"));
                }
                WebElement col4 = driver.findElement(By.id(tid1));

                String col1_txt = col1.findElement(By.className("txtelips")).getText();
                String col2_txt = col2.findElement(By.className("txtelips")).getText();
                String col3_txt;
                if(rule1.equals("Closing Date"))
                {
                    col3_txt = col3.findElement(By.className("txtelips")).getText();
                }
                else
                {
                    col3_txt = col3.getAttribute("title");
                }
                String col4_txt = col4.findElement(By.className("txtelips")).getText();

                if((col1_txt.equals(rule))&&(col2_txt.equals(cond))&&(col3_txt.equals(val))&&(col4_txt.equals(rule1)))
                {
                    etest.log(Status.PASS,"Rule is checked");
                    btns.get(1).click();
                    return true;
                }
            }
            else
            {
                WebElement col1 = driver.findElement(By.id(tid));
                WebElement col2 = driver.findElement(By.id(cid));
                WebElement col3 = driver.findElement(By.id(vid)).findElement(By.id("col3_input1"));

                String col1_txt = col1.findElement(By.className("txtelips")).getText();
                String col2_txt = col2.findElement(By.className("txtelips")).getText();
                String col3_txt = col3.getAttribute("title");

                if((col1_txt.equals(rule))&&(col2_txt.equals(cond))&&(col3_txt.equals(val)))
                {
                    etest.log(Status.PASS,"Rule is checked");
                    btns.get(1).click();
                    return true;
                }
            }
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+rule+","+rule1+","+cond+","+val,"MismatchContent");
            btns.get(1).click();
            return false;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+rule+","+rule1+","+cond+","+val,"Error",e);
            System.out.println("Exception while checking CRM Rule in tracking customize : "+ rule + "  " +e);
            closePopup1(driver);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"Tracking-Customize","CheckRule:"+rule+","+rule1+","+cond+","+val,"Error",e);
            System.out.println("Exception while checking CRM Rule in tracking customize : "+ rule + "  " +e);
            closePopup1(driver);
            return false;
        }
    }
}
