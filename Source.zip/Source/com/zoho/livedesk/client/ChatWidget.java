//$Id$
package com.zoho.livedesk.client;

import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import java.net.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import com.zoho.qa.server.WebdriverQAUtil;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.KeyManager;

import com.google.common.base.Function;

import com.zoho.livedesk.util.*;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import com.zoho.livedesk.util.common.actions.Department;

public class ChatWidget
{
    public static Hashtable result = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    public static Hashtable servicedown = new Hashtable();

    public static String user = "";
    private static String url = "";
    public static ExtentTest etest;
    public static Set<WebDriver> visDrivers = new HashSet();

    public static Hashtable widgetcheck(WebDriver driver) throws Exception
    {
        try
        {
            result = new Hashtable();
            visDrivers = new HashSet();

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CWC1"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            url = ConfManager.requestURL();
            
            user = getUserName(driver);
            result.put("CWC1",true);
            
            etest.log(Status.PASS,"Operatorname "+user+" is got from Browser");

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("CheckConfigurationInPortal");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            checkConfig(driver);

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check Widget Online and Offline");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            checkWidget(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CWC4"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            result.put("CWC4",initiateChat(driver));
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check DepartmentDropDown in Chat Widget for Public Dept when Online and offline");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            publicdeptCheck(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check DepartmentDropDown in Chat Widget for Private Dept when Online and offline");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            privdeptcheck(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("ConfigureMessages and Check in Chat Widget");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");
            
            configMessages(driver);
            closeDriver();
            
            ComplexReportFactory.closeTest(etest);
            
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CWC9"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            weinvisibility(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Configure Waiting time and Check In Chat Widget");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            wtime(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("RestrictURL for current site and another site and Check Widget Visibility");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            restrictURL(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Change appearance in WebEmbedSettings Page and Check Chat Widget");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            chngAppearance(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable and Disable Use Online theme for Offline");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            offTheme(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check VisitorInfo Mandatory in Chat Widget");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            visInfo(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Enable Chat Window Actions and Check ChatWidget");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            checkActions(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CWC40"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            checkSuppPhoto(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check CompanyLogo And Show Operators in ChatWidget");
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            checkCompLogo(driver);
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("CWC44"));
            ComplexReportFactory.setValues(etest,"Automation","Web Embed Real Time Check");

            result.put("CWC44",checkBusinessHour(driver));
            closeDriver();

            ComplexReportFactory.closeTest(etest);

            try
            {
                CompanyInfo.disableBusinessHour(driver);
            }
            catch(Exception e)
            {
                System.out.println("Error while disabling business hours - ");
                e.printStackTrace();
            }
        }
        catch(NoSuchElementException e)
        {
            etest.log(Status.FATAL,"ErrorGetOperatorInfo");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","GetOperatorInfo","GetOperatorInfoError",e);
            result.put("CWC1", false);
        }
        catch(Exception e)
        {
            etest.log(Status.FATAL,"ErrorGetOperatorInfo");
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","GetOperatorInfo","GetOperatorInfoError",e);
            result.put("CWC1", false);
        }

        closeDriver();

        hashtable.put("result", result);
        hashtable.put("servicedown", servicedown);
        return hashtable;
    }

    //Mouse Over for hidden element
    private static void mouseOver(WebDriver driver,WebElement element) throws Exception
    {
        Thread.sleep(500);
        new Actions(driver).moveToElement(element).perform();
    }

    //choose embed2 to change and apply settings
    public static WebDriver chooseEmbed(WebDriver driver,String emname)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Tab.navToEmbedTab(driver);

            List<WebElement> elists = driver.findElement(By.id("embedlist")).findElements(By.className("list-row"));

            Thread.sleep(1000);

            for(WebElement elist:elists)
            {
                Thread.sleep(500);

                if((elist.findElement(By.className("list_cell")).getText()).equals(emname))
                {
                    elist.findElement(By.className("list_cell")).click();

                    Thread.sleep(1000);

                    break;
                }
            }

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embeddetail")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embeddetail")));
            
            Thread.sleep(1000);

            return driver;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChooseEmbed","ErrorWhileChoosingEmbed",e);

            System.out.println("Exception while choosing embed in real time float widget check : " + e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChooseEmbed","ErrorWhileChoosingEmbed",e);

            System.out.println("Exception while choosing embed in real time float widget check : " + e);
        }
        return driver;
    }

    //check if widget is open/closed and click to open widget if it is closed
    private static void widgetOpen(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver.switchTo().defaultContent();
            driver.findElement(By.className("zls-sptwndw")).findElement(By.id("zlscht")).findElement(By.id("zlscloseimg")).click();

            Thread.sleep(1000);

        }
        catch(NoSuchElementException e)
        {
            //TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CloseChatWidget","ErrorWhileClosingWidget",e);

            System.out.println("Exception while checking widget open/close in real time float widget check : " + e);
        }
        catch(Exception e)
        {
            //TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CloseChatWidget","ErrorWhileClosingWidget/Close",e);

            System.out.println("Exception while checking widget open/close in real time float widget check : " + e);
        }
    }

    //Check initial confuration in portal
    private static void checkConfig(WebDriver driver)
    {
        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            Department.deleteDepartment(driver,"TestDepartment",null,etest);

            etest.log(Status.PASS,"configuration is checked in portal settings page");
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckConfigurationInPortal","ErrorWhileCheckingConfigurationInPortal",e);

            System.out.println("Exception while checking configuration in portal in real time float widget check : " + e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckConfigurationInPortal","ErrorWhileCheckingConfigurationInPortal",e);

            System.out.println("Exception while checking configuration in portal in real time float widget check : " + e);
        }
    }

    private static WebDriver createWidget(WebDriver driver) throws Exception
    {
        Thread.sleep(5000);

        VisitorWindow.createPage(driver,ConfManager.getWEembed(),ConfManager.getWEportal());

        return driver;
    }

    //Get username
    private static String getUserName(WebDriver driver)
    {
        String knownas = "Not found";
        try
        {
            knownas = ExecuteStatements.getUserName(driver);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","GetUseNameFromMyProfilePage","ErrorWhileGettingOperatorName",e);

            System.out.println("Exception while getting operatorname in chat widget check : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","GetUseNameFromMyProfilePage","ErrorWhileGettingOperatorName",e);

            System.out.println("Exception while getting operatorname in chat widget check : "+e);
        }
        return knownas;
    }

    //Check Chat widgets
    private static void checkWidget(WebDriver driver)
    {
        try
        {
            WebDriver visDriver = setUp();

            result.put("CWC2",openURL1(driver,visDriver,true));

            visDriver = setUp();

            result.put("CWC3",checkFloatWidgetOffline(driver,visDriver));
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckChatWidget","ErrorWhileCheckingChatWidgets",e);

            System.out.println("Exception while checking chat widgets : "+e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckChatWidget","ErrorWhileCheckingChatWidgets",e);

            System.out.println("Exception while checking chat widgets : "+e);
        }
    }

    //Open url
    private static boolean openURL1(WebDriver driver,WebDriver visDriver,boolean screenshot)
    {
        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            try
            {
                FluentWait wait = new FluentWait(visDriver);
                wait.withTimeout(30,TimeUnit.SECONDS);
                wait.pollingEvery(250,TimeUnit.MILLISECONDS);
                wait.ignoring(NoSuchElementException.class);

                try
                {
                    visDriver = createWidget(visDriver);

                    VisitorWindow.clickChatButton(visDriver);

                    VisitorWindow.clickCloseChatWidget(visDriver);
                }
                catch(NoSuchElementException e)
                {
                    if(screenshot)
                    {
                        TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","AccessChatWidget","OpeningChatWidgetError",e);
                    }
                    return false;
                }
                catch(Exception e)
                {
                    if(screenshot)
                    {
                        TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","AccessChatWidget","OpeningChatWidgetError",e);
                    }
                    return false;
                }
                if(!screenshot)
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","AccessChatWidget","ChatWidgetIsOpened");
                }
                else
                {
                    etest.log(Status.INFO,"Chat Widget is Opened");
                }

                return true;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","AccessChatWidget","OpeningChatWidgetError",e);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","AccessChatWidget","OpeningChatWidgetError",e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","AccessChatWidget","OpeningChatWidgetError",e);
            return false;
        }
    }

    //Check Widget offline
    private static boolean checkFloatWidgetOffline(WebDriver driver,WebDriver visDriver)
    {
        try
        {
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

            driver.navigate().refresh();
            Thread.sleep(2000);

            try
            {
                visDriver = createWidget(visDriver);

                FluentWait wait = new FluentWait(visDriver);
                wait.withTimeout(30,TimeUnit.SECONDS);
                wait.pollingEvery(250,TimeUnit.MILLISECONDS);
                wait.ignoring(NoSuchElementException.class);

                VisitorWindow.clickChatButton(visDriver);
                VisitorWindow.switchToChatWidget(visDriver);

                VisitorWindow.checkWidgetStatus(visDriver);

                etest.log(Status.PASS,"Chat Widget is present when offline");
                return true;
            }
            catch(NoSuchElementException e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","AccessChatWidgetWhenOffline","OpeningChatWidgetwhenOffline",e);
                return false;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","AccessChatWidgetWhenOffline","OpeningChatWidgetwhenOffline",e);
                return false;
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","AccessChatWidgetWhenOffline","OpeningChatWidgetwhenOfflineError",e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","AccessChatWidgetWhenOffline","OpeningChatWidgetwhenOfflineError",e);
            return false;
        }
    }

    //initiate chat and check
    private static boolean initiateChat(WebDriver driver)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"Tester1","rajkumar.natarajan@zohocorp.com","9876543210","Is it working ?",etest);
                visDriver.switchTo().defaultContent();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatInitaiate","ErrorWhileInitiatingChat",e);
                return false;
            }

            Thread.sleep(2000);

            ChatWindow.acceptChat(driver,etest);

            Thread.sleep(2000);

            try
            {
                String att = VisitorWindow.getAttenderName(visDriver);

                if((user.equals(att)))
                {
                    VisitorWindow.endChatVisitor(visDriver);

                    VisitorWindow.clickCloseChatWidget(visDriver);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatInitiate","IncorrectOperatorNameInChatWidget:"+att);
                    return false;
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatInitaiate","ErrorWhileInitiatingChat",e);
                return false;
            }

            ChatWindow.clickClosethisWindow(driver);

            etest.log(Status.PASS,"Chat Initiated successfully");

            return true;
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatInitaiate","ErrorWhileInitiatingChat",e);
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatInitaiate","ErrorWhileInitiatingChat",e);
            return false;
        }
    }

    //Add public department and check if it available in the dropdown
    private static void publicdeptCheck(WebDriver driver)
    {
        try
        {
            result.put("CWC5",false);
            result.put("CWC6",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            Thread.sleep(1000);
            
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

            driver.findElement(By.id("buttonadddept")).findElement(By.tagName("span")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));

            driver.findElement(By.id("name")).click();
            driver.findElement(By.id("name")).clear();
            driver.findElement(By.id("name")).sendKeys("CheckDepartment");
            driver.findElement(By.id("depttype_publi")).click();
            driver.findElement(By.id("desc")).click();
            driver.findElement(By.id("desc")).clear();
            driver.findElement(By.id("desc")).sendKeys("Description");

            if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
            {
                WebElement elmt = driver.findElement(By.id("unassodeptlist"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-400)");

                List<WebElement> elmts = elmt.findElements(By.tagName("div"));

                for(WebElement element:elmts)
                {
                    WebElement ptag;
                    try
                    {
                        ptag = element.findElement(By.tagName("p"));
                    }
                    catch(Exception e)
                    {
                        continue;
                    }
                    if(user.equals(ptag.getText()))
                    {
                        List<WebElement> elmts1 = element.findElements(By.tagName("div"));

                        elmts1.get(0).click();
                        break;
                    }
                }
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+")");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));
            driver.findElement(By.id("deptaddbtn")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);
            Thread.sleep(1000);

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,"CheckDepartment",null,false,etest,false);

                etest.log(Status.PASS,KeyManager.getRealValue("CWC5")+" is verified");

                result.put("CWC5",true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Public","ErrorWhileCheckingPublicDepartment",e);
            }

            Thread.sleep(2000);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

            visDriver = setUp();

            try
            {
                createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,"CheckDepartment",null,false,etest,false);

                etest.log(Status.PASS,KeyManager.getRealValue("CWC6")+" is verified");
                
                result.put("CWC6",true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Public","ErrorWhileCheckingPublicDepartment",e);
            }

        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Public","ErrorWhileCheckingPublicDepartment",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Public","ErrorWhileCheckingPublicDepartment",e);
        }
        finally
        {
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Public","ChangeStatusToAvailable",e);
            }
            try
            {
                Department.deleteDepartment(driver,"CheckDepartment",null,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Public","DeleteDepartment",e);
            }
        }
    }

    //Add private department and check if it available in the dropdown
    private static void privdeptcheck(WebDriver driver)
    {
        try
        {
            result.put("CWC7",false);
            result.put("CWC8",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Department.deleteDepartment(driver,"CheckDepartment",null,etest);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            Thread.sleep(1000);
            
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

            driver.findElement(By.id("buttonadddept")).findElement(By.tagName("span")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));

            driver.findElement(By.id("name")).click();
            driver.findElement(By.id("name")).clear();
            driver.findElement(By.id("name")).sendKeys("CheckDepartment");
            driver.findElement(By.id("depttype_privat")).click();
            driver.findElement(By.id("desc")).click();
            driver.findElement(By.id("desc")).clear();
            driver.findElement(By.id("desc")).sendKeys("Description");

            if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
            {
                WebElement elmt = driver.findElement(By.id("unassodeptlist"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-400)");

                List<WebElement> elmts = elmt.findElements(By.tagName("div"));

                for(WebElement element:elmts)
                {
                    WebElement ptag;
                    try
                    {
                        ptag = element.findElement(By.tagName("p"));
                    }
                    catch(Exception e)
                    {
                        continue;
                    }
                    if(user.equals(ptag.getText()))
                    {
                        List<WebElement> elmts1 = element.findElements(By.tagName("div"));

                        elmts1.get(0).click();
                        break;
                    }
                }
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+")");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));
            driver.findElement(By.id("deptaddbtn")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);
            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                try
                {
                    VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,"CheckDepartment",null,false,etest,false);

                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private-Online","DepartmentVisibleforPrivateDepartment");
                }
                catch(Exception e)
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC7")+" is verified");

                    result.put("CWC7",true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private-Online","DepartmentVisibleforPrivateDepartment");
            }


            Thread.sleep(1000);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                try
                {
                    VisitorWindow.initiateChatVisTheme(visDriver,null,null,null,"CheckDepartment",null,false,etest,false);

                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private-Online","DepartmentVisibleforPrivateDepartment");
                }
                catch(Exception e)
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC8")+" is verified");

                    result.put("CWC8",true);
                }
            }
            catch(Exception e)
            {

            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private","ErrorWhileCheckingPrivateDepartment",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private","ErrorWhileCheckingPrivateDepartment",e);
        }
        finally
        {
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private","ChangeStatusToAvailable",e);
            }
            try
            {
                Department.deleteDepartment(driver,"CheckDepartment",null,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","CheckDepartmentDropDown-Private","DeleteDepartment",e);
            }
        }
    }

    //Configure web embed to one department and check for invisibility of chat widget
    private static void weinvisibility(WebDriver driver)
    {
        try
        {
            result.put("CWC9",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Thread.sleep(1000);
            
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));

            driver.findElement(By.id("buttonadddept")).findElement(By.tagName("span")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));

            driver.findElement(By.id("name")).click();
            driver.findElement(By.id("name")).clear();
            driver.findElement(By.id("name")).sendKeys("CheckDepartment");
            driver.findElement(By.id("depttype_publi")).click();
            driver.findElement(By.id("desc")).click();
            driver.findElement(By.id("desc")).clear();
            driver.findElement(By.id("desc")).sendKeys("Description");

            if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
            {
                WebElement elmt = driver.findElement(By.id("unassodeptlist"));

                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+elmt.getLocation().y+"-400)");

                List<WebElement> elmts = elmt.findElements(By.tagName("div"));

                for(WebElement element:elmts)
                {
                    WebElement ptag;
                    try
                    {
                        ptag = element.findElement(By.tagName("p"));
                    }
                    catch(Exception e)
                    {
                        continue;
                    }
                    if(user.equals(ptag.getText()))
                    {
                        List<WebElement> elmts1 = element.findElements(By.tagName("div"));

                        elmts1.get(0).click();
                        break;
                    }
                }
            }

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("deptaddbtn"))).getLocation().y+")");
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));
            driver.findElement(By.id("deptaddbtn")).click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);
            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            WebElement elmthid = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElement(By.className("embdlstmn")).findElement(By.id("cedept"));

            mouseOver(driver,elmthid);

            Thread.sleep(1000);

            elmthid.findElement(By.id("editedept")).click();

            new Select(driver.findElement(By.xpath(".//select[@id='departmentselect'][@class='embedit-select']"))).selectByVisibleText("CheckDepartment");
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(3000);
            
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            driver.findElement(By.className("cmn_listviewer")).findElements(By.className("list-row")).get(1).findElement(By.tagName("div")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innerbtnmn")));

            driver.findElement(By.className("innerbtnmn")).findElement(By.tagName("span")).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if((driver.findElement(By.className("innerbtnmn")).findElement(By.tagName("span")).getText()).equals("Enable"))
                    {
                        return true;
                    }
                    return false;
                }
            });

            Thread.sleep(1000);

            WebDriver visDriver = setUp();

            try
            {
                try
                {
                    visDriver = createWidget(visDriver);

                    VisitorWindow.clickChatButton(visDriver);
                }
                catch(Exception e)
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC9")+" is verified");

                    result.put("CWC9",true);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","DisableDepartment","ChatWidgetAppearsWhenDeptIsDisabled",e);
            }


            Thread.sleep(3000);
            
            Tab.navToDeptTab(driver);

            Thread.sleep(1000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("cmn_listviewer")));

            driver.findElement(By.className("cmn_listviewer")).findElements(By.className("list-row")).get(1).findElement(By.tagName("div")).click();

            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("innerbtnmn")));

            driver.findElement(By.className("innerbtnmn")).findElement(By.tagName("span")).click();

            Thread.sleep(1000);

            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if((driver.findElement(By.className("innerbtnmn")).findElement(By.tagName("span")).getText()).equals("Disable"))
                        {
                            return true;
                        }
                    }
                    catch(StaleElementReferenceException excep){}
                    return false;
                }
            });

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            elmthid = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElement(By.className("embdlstmn")).findElement(By.id("cedept"));

            mouseOver(driver,elmthid);

            Thread.sleep(1000);

            elmthid.findElement(By.id("editedept")).click();

            Thread.sleep(1000);

            new Select(driver.findElement(By.xpath(".//select[@id='departmentselect'][@class='embedit-select']"))).selectByVisibleText("Allow visitor to select department");
            driver.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(3000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableDepartment","ErrorWhileDisablingDeptmentAndCheckingChatWidgetInvisibility",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableDepartment","ErrorWhileDisablingDeptmentAndCheckingChatWidgetInvisibility",e);
        }
        finally
        {
            try
            {
                Department.deleteDepartment(driver,"CheckDepartment",null,etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","DisableDepartment","DeleteDepartment",e);
            }
        }
    }

    //Configure messages check
    private static void configMessages(WebDriver driver)
    {
        try
        {
            result.put("CWC10",false);
            result.put("CWC11",false);
            result.put("CWC12",false);
            result.put("CWC13",false);
            result.put("CWC14",false);
            result.put("CWC15",false);
            result.put("CWC16",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            Department.deleteDepartment(driver,"CheckDepartment",null,etest);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            WebElement elwelcome = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElements(By.className("embdlstmn")).get(2).findElement(By.id("cegreet"));

            mouseOver(driver,elwelcome);

            Thread.sleep(1000);

            elwelcome.findElement(By.id("editegreet")).click();

            Thread.sleep(1000);

            elwelcome = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_lft")).findElements(By.className("embdlstmn")).get(2);

            elwelcome.findElement(By.id("segreet")).findElement(By.id("greet")).click();
            elwelcome.findElement(By.id("segreet")).findElement(By.id("greet")).clear();
            elwelcome.findElement(By.id("segreet")).findElement(By.id("greet")).sendKeys("Message1");

            elwelcome.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            driver.findElement(By.id("cnfmsglink")).findElement(By.tagName("a")).click();

            Thread.sleep(2000);

            WebElement lftmsg = driver.findElement(By.id("messageconfg")).findElement(By.className("cnfmsghdr")).findElement(By.className("embdtlmn_lft"));
            WebElement rhtmsg = driver.findElement(By.id("messageconfg")).findElement(By.className("cnfmsghdr")).findElement(By.className("embdtlmn_rht"));

            WebElement waitmsg = lftmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cewaitingmsg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(waitmsg.getLocation().y-200)+")");

            mouseOver(driver,waitmsg);

            Thread.sleep(1000);

            waitmsg.findElement(By.id("editewaitingmsg")).click();

            Thread.sleep(1000);

            waitmsg = lftmsg.findElements(By.className("embdlstmn")).get(0);

            waitmsg.findElement(By.id("sewaitingmsg")).findElement(By.id("waitingmsg")).click();
            waitmsg.findElement(By.id("sewaitingmsg")).findElement(By.id("waitingmsg")).clear();
            waitmsg.findElement(By.id("sewaitingmsg")).findElement(By.id("waitingmsg")).sendKeys("Message2");

            waitmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            WebElement offlinemsg = lftmsg.findElements(By.className("embdlstmn")).get(1).findElement(By.id("ceofflinemsg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(offlinemsg.getLocation().y-200)+")");

            mouseOver(driver,offlinemsg);

            Thread.sleep(1000);

            offlinemsg.findElement(By.id("editeofflinemsg")).click();

            Thread.sleep(1000);

            offlinemsg = lftmsg.findElements(By.className("embdlstmn")).get(1);

            offlinemsg.findElement(By.id("seofflinemsg")).findElement(By.id("offlinemsg")).click();
            offlinemsg.findElement(By.id("seofflinemsg")).findElement(By.id("offlinemsg")).clear();
            offlinemsg.findElement(By.id("seofflinemsg")).findElement(By.id("offlinemsg")).sendKeys("Message3");

            offlinemsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            WebElement busymsg = lftmsg.findElements(By.className("embdlstmn")).get(2).findElement(By.id("cebusymsg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(busymsg.getLocation().y-200)+")");

            mouseOver(driver,busymsg);

            Thread.sleep(1000);

            busymsg.findElement(By.id("editebusymsg")).click();

            Thread.sleep(1000);

            busymsg = lftmsg.findElements(By.className("embdlstmn")).get(2);

            busymsg.findElement(By.id("sebusymsg")).findElement(By.id("busymsg")).click();
            busymsg.findElement(By.id("sebusymsg")).findElement(By.id("busymsg")).clear();
            busymsg.findElement(By.id("sebusymsg")).findElement(By.id("busymsg")).sendKeys("Message4");

            busymsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            WebElement thanksmsg = rhtmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cethanksmsg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(thanksmsg.getLocation().y-200)+")");

            mouseOver(driver,thanksmsg);

            Thread.sleep(1000);

            thanksmsg.findElement(By.id("editethanksmsg")).click();

            Thread.sleep(1000);

            thanksmsg = rhtmsg.findElements(By.className("embdlstmn")).get(0);

            thanksmsg.findElement(By.id("sethanksmsg")).findElement(By.id("thanksmsg")).click();
            thanksmsg.findElement(By.id("sethanksmsg")).findElement(By.id("thanksmsg")).clear();
            thanksmsg.findElement(By.id("sethanksmsg")).findElement(By.id("thanksmsg")).sendKeys("Message5");

            thanksmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            WebElement offlinerespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(1).findElement(By.id("ceofflinerespmsg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(offlinerespmsg.getLocation().y-200)+")");

            mouseOver(driver,offlinerespmsg);

            Thread.sleep(1000);

            offlinerespmsg.findElement(By.id("editeofflinerespmsg")).click();

            Thread.sleep(1000);

            offlinerespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(1);

            offlinerespmsg.findElement(By.id("seofflinerespmsg")).findElement(By.id("offlinerespmsg")).click();
            offlinerespmsg.findElement(By.id("seofflinerespmsg")).findElement(By.id("offlinerespmsg")).clear();
            offlinerespmsg.findElement(By.id("seofflinerespmsg")).findElement(By.id("offlinerespmsg")).sendKeys("Message6");

            offlinerespmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            WebElement busyrespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(2).findElement(By.id("cebusyrespmsg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(busyrespmsg.getLocation().y-200)+")");

            mouseOver(driver,busyrespmsg);

            Thread.sleep(1000);

            busyrespmsg.findElement(By.id("editebusyrespmsg")).click();

            Thread.sleep(1000);

            busyrespmsg = rhtmsg.findElements(By.className("embdlstmn")).get(2);

            busyrespmsg.findElement(By.id("sebusyrespmsg")).findElement(By.id("busyrespmsg")).click();
            busyrespmsg.findElement(By.id("sebusyrespmsg")).findElement(By.id("busyrespmsg")).clear();
            busyrespmsg.findElement(By.id("sebusyrespmsg")).findElement(By.id("busyrespmsg")).sendKeys("Message7");

            busyrespmsg.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            String tt1;
            WebElement chframe11;
            WebElement elmt11;

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                FluentWait wait_vis = new FluentWait(visDriver);
                wait_vis.withTimeout(30,TimeUnit.SECONDS);
                wait_vis.pollingEvery(100,TimeUnit.MILLISECONDS);
                wait_vis.ignoring(NoSuchElementException.class);

                VisitorWindow.initiateChatVisTheme(visDriver,"Test1","test@test.com","12345","qwerty",etest);

                if(VisitorWindow.getInfoMessage(visDriver).contains("Message2"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC10")+" is verified");

                    result.put("CWC10",true);
                }
                else{
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","MismatchWaitingMessage");
                }

                VisitorWindow.waitTillChatisMissedInTheme(visDriver);

                Thread.sleep(3000);

                if(VisitorWindow.getInfoMessage(visDriver).contains("Message4"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC11")+" is verified");

                    result.put("CWC11",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","MismatchOperatorBusyMessage");
                }
                
                VisitorWindow.sentMessageInTheme(visDriver,"Hi there");

                VisitorWindow.infoInvisible(visDriver);
                
                if(VisitorWindow.getInfoMessage(visDriver).equals("Message7"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC12")+" is verified");

                    result.put("CWC12",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","MismatchBusyResponseMessage");
                }
                
                VisitorWindow.infoInvisible(visDriver);

                Thread.sleep(2000);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileCheckingConfigureMessages",e);
            }

            Thread.sleep(3000);

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"Test1","test@test.com","12345","qwerty",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidget","Error",e);
            }

            ChatWindow.acceptChat(driver,etest);

            try
            {
                FluentWait wait_vis = new FluentWait(visDriver);
                wait_vis.withTimeout(30,TimeUnit.SECONDS);
                wait_vis.pollingEvery(250,TimeUnit.MILLISECONDS);
                wait_vis.ignoring(NoSuchElementException.class);

                if(VisitorWindow.checkAgentMessageInChatWindow(visDriver,user,"Message1",1))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC13")+" is verified");

                    result.put("CWC13",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","Mismatch:WelcomeMessage");
                }

                VisitorWindow.endChatVisitor(visDriver);
                
                if(VisitorWindow.getInfoMessage(visDriver).equals("Message5"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC14")+" is verified");

                    result.put("CWC14",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","Mismatch:ThankyouMessage");
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidget","ErrorWhileCheckingConfigureMessages2",e);
            }

            try
            {
                driver.findElement(By.id("compdiv")).findElement(By.id("infodiv")).findElement(By.tagName("div")).findElement(By.linkText("Close this window")).click();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileCheckingConfigureMessages2",e);
            }

            Thread.sleep(3000);
            
            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");
            
            Thread.sleep(5000);
            
            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.clickChatButton(visDriver);

                if(VisitorWindow.getInfoMessage(visDriver).equals("Message3"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC15")+" is verified");
                    
                    result.put("CWC15",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","MismatchOfflineMessage");
                }
                
                VisitorWindow.infoInvisible(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"test","test@test.com","1234",null,"qwerty",false,etest,true);

                if(VisitorWindow.getInfoMessage(visDriver).equals("Message6"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC16")+" is verified");

                    result.put("CWC16",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","MismatchOfflineResponseMessage");
                }
                
                VisitorWindow.infoInvisible(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileCheckingConfigureMessages3",e);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileConfiguringMessages",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","ErrorWhileConfiguringMessages",e);
        }
        finally
        {
            try
            {
                com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ConfigureMessages","ChangeStatusToAvailable",e);
            }
        }
    }

    //Waiting time check
    private static void wtime(WebDriver driver)
    {
        try
        {
            result.put("CWC17",false);
            result.put("CWC18",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ecreator")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embdcontent")));

            WebElement elmthid = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_rht")).findElements(By.className("embdlstmn")).get(1).findElement(By.id("cewtime"));

            mouseOver(driver,elmthid);

            Thread.sleep(1000);

            elmthid.findElement(By.id("editwtime")).click();

            new Select(driver.findElement(By.xpath(".//select[@id='wtime'][@class='embedit-select']"))).selectByVisibleText("30 seconds");
            driver.findElement(By.id("sewtime")).findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(3000);

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"test","test@test.com","1234","qwer",etest);

                Thread.sleep(7000);

                if(VisitorWindow.checkWaitingTimer(visDriver,0,25))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC17")+" is verified");

                    result.put("CWC17",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","WaitingTime30secs","Waiting30SecondsError");
                    result.put("CWC17",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","WaitingTime","ErrorCheckingWaitingTime",e);
            }

            Thread.sleep(2000);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ecreator")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embdcontent")));

            elmthid = driver.findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_rht")).findElements(By.className("embdlstmn")).get(1).findElement(By.id("cewtime"));

            mouseOver(driver,elmthid);

            Thread.sleep(1000);

            elmthid.findElement(By.id("editwtime")).click();

            new Select(driver.findElement(By.xpath(".//select[@id='wtime'][@class='embedit-select']"))).selectByVisibleText("60 seconds");
            driver.findElement(By.id("sewtime")).findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(3000);

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"test","test@test.com","1234","qwer",etest);

                Thread.sleep(7000);

                if(VisitorWindow.checkWaitingTimer(visDriver,0,55))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC18")+" is verified");

                    result.put("CWC18",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","WaitingTime60secs","Waiting60SecondsError");
                    result.put("CWC18",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","WaitingTime","ErrorCheckingWaitingTime",e);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WaitingTime","ErrorCheckingWaitingTime",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","WaitingTime","ErrorCheckingWaitingTime",e);
        }
    }

    //Configure restict URL and check for visibility and invisibility of widget
    private static void restrictURL(WebDriver driver)
    {
        try
        {
            result.put("CWC19",false);
            result.put("CWC20",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            WebElement rhtmsg = driver.findElement(By.id("embeddetail")).findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_rht"));

            WebElement rurl = rhtmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cerestr"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(rurl.getLocation().y-200)+")");

            mouseOver(driver,rurl);

            Thread.sleep(1000);

            rurl.findElement(By.id("editerestr")).click();

            Thread.sleep(1000);

            rurl = rhtmsg.findElements(By.className("embdlstmn")).get(0);

            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).click();
            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).clear();
            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).sendKeys("http://"+Util.serverHostName+":"+Util.serverPortNumber+"/visitor/index.html");

            rurl.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            WebDriver visDriver = setUp();

            result.put("CWC19",openURL1(driver,visDriver,true));

            Thread.sleep(2000);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            rhtmsg = driver.findElement(By.id("embeddetail")).findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_rht"));

            rurl = rhtmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cerestr"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(rurl.getLocation().y-200)+")");

            mouseOver(driver,rurl);

            Thread.sleep(1000);

            rurl.findElement(By.id("editerestr")).click();

            Thread.sleep(1000);

            rurl = rhtmsg.findElements(By.className("embdlstmn")).get(0);

            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).click();
            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).clear();
            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).sendKeys("http://www.google.com/");

            rurl.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);

            visDriver = setUp();

            if(openURL1(driver,visDriver,false))
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","RestrictURL","RestrictedURLChatWidgetDisplayed");
                result.put("CWC20",false);
            }
            else
            {
                etest.log(Status.PASS,KeyManager.getRealValue("CWC20")+" is verified");

                result.put("CWC20",true);
            }



            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            rhtmsg = driver.findElement(By.id("embeddetail")).findElement(By.id("embdcontent")).findElement(By.className("embdtlmn_rht"));

            rurl = rhtmsg.findElements(By.className("embdlstmn")).get(0).findElement(By.id("cerestr"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(rurl.getLocation().y-200)+")");

            mouseOver(driver,rurl);

            Thread.sleep(1000);

            rurl.findElement(By.id("editerestr")).click();

            Thread.sleep(1000);

            rurl = rhtmsg.findElements(By.className("embdlstmn")).get(0);

            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).click();
            rurl.findElement(By.id("serestr")).findElement(By.id("domaintxt")).clear();

            rurl.findElement(By.linkText(ResourceManager.getRealValue("common_save"))).click();

            Thread.sleep(2000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","RestrictURL","ErrorWhileCheckingRestrictedURL",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","RestrictURL","ErrorWhileCheckingRestrictedURL",e);
        }
    }

    //Check the change appearance settings - Size, Text, Bubble, Show Users
    private static void chngAppearance(WebDriver driver)
    {
        try
        {
            result.put("CWC21",false);
            result.put("CWC22",false);
            result.put("CWC23",false);
            result.put("CWC24",false);
            result.put("CWC25",false);
            result.put("CWC26",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            Thread.sleep(500);

            driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("fltbubble"))).getLocation().y+"-400)");

            WebElement bubelmt = driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("ifltbubble"));

            if((bubelmt.getAttribute("class")).contains("embchk-yes"))
            {
                bubelmt.click();
            }

            bubelmt.click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String ttcheck = visDriver.findElement(By.className("zls-small")).findElement(By.className("zls-btnsub")).findElement(By.id("zlsbub")).findElement(By.id("zlsbubanim")).getAttribute("style");

                if(ttcheck.contains("display: block;"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC21")+" is verified");

                    result.put("CWC21",true);
                }
                else{
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatBubble","ChatBubbleisNotVisible");
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatBubble","ErrorWhileCheckingChatBubbleVisibility",e);

                result.put("CWC21",false);
            }

            Thread.sleep(3000);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            Thread.sleep(500);

            driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content")).click();

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content")).clear();

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content")).sendKeys("This is Online Line 1");

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("on1content"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("off1content")).click();

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("off1content")).clear();

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("off1content")).sendKeys("This is Offline Line 1");

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                visDriver.findElement(By.className("zls-small"));

                String tt1 = visDriver.findElement(By.className("zls-small")).findElement(By.id("zls_ctn_wrap")).findElement(By.className("zlslrgbtn-on-tit1")).findElement(By.id("zlstxtcnt")).getText();

                if(tt1.equals("This is Online Line 1"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC22")+" is verified");

                    result.put("CWC22",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","OnlineTextFirstline","MismatchOnlineTextFirstLine");

                    result.put("CWC22",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","OnlineTextFirstline","MismatchOnlineTextFirstLine",e);
            }

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                visDriver.findElement(By.className("zls-small"));

                String tt1 = visDriver.findElement(By.className("zls-small")).findElement(By.id("zls_ctn_wrap")).findElement(By.className("zlslrgbtn-on-tit1")).findElement(By.id("zlstxtcnt")).getText();

                if(tt1.equals("This is Offline Line 1"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC23")+" is verified");

                    result.put("CWC23",true);
                }

                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","OfflineTextFirstLine","MismatchOfflineTextFirstLine");

                    result.put("CWC23",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","OfflineTextFirstLine","Error",e);
            }

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            Thread.sleep(1000);

            chngSize(driver,"Small");

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String tt1 = visDriver.findElement(By.className("zls-small")).findElement(By.id("zls_ctn_wrap")).getAttribute("style");

                if(tt1.contains("height: 33px;"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC24")+" is verified");

                    result.put("CWC24",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","SmallFloatWindow","MismatchForSmallFloatWindowSize");

                    result.put("CWC24",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","SmallFloatWindow","Error",e);
            }

            Thread.sleep(3000);

            chngSize(driver,"Medium");

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String tt1 = visDriver.findElement(By.className("zls-medium")).findElement(By.id("zls_ctn_wrap")).getAttribute("style");

                if(tt1.contains("height: 44px;"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC25")+" is verified");

                    result.put("CWC25",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","MediumFloatWindow","MismatchForMediumFloatWindowSize");

                    result.put("CWC25",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","MediumFloatWindow","Error",e);
            }

            Thread.sleep(3000);

            chngSize(driver,"Large");

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String tt1 = visDriver.findElement(By.className("zls-large")).findElement(By.id("zls_ctn_wrap")).getAttribute("style");

                if(tt1.contains("height: 51px;"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC26")+" is verified");

                    result.put("CWC26",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","LargeFloatWindow","MismatchForLargeFloatWindowSize");

                    result.put("CWC26",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","LargeFloatWindow","Error",e);
            }

            Thread.sleep(3000);

            chngSize(driver,"Small");

            //-------SHOW USERS YET TO BE ADDED--------//

        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChangingAppearanceSettings","ErrorWhileCheckingChangeAppearanceSettings",e);
            chngSize(driver,"Small");
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChangingAppearanceSettings","ErrorWhileCheckingChangeAppearanceSettings",e);
            chngSize(driver,"Small");
        }
    }

    //change widget size
    private static void chngSize(WebDriver driver,String wsize)
    {
        try
        {
            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ecreator")));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdfltbtnn")).findElement(By.id("fltsize"))).getLocation().y+"-400)");

            driver.findElement(By.id("embdfltbtnn")).findElement(By.id("fltsize")).click();

            Thread.sleep(1000);

            new Select(driver.findElement(By.xpath(".//select[@id='fltsize'][@class='embtn-selctopt']"))).selectByVisibleText(wsize);

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(5000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChangingChatSize","ErrorWhileChangingChatSizeSettings",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChangingChatSize","ErrorWhileChangingChatSizeSettings",e);
        }
    }

    //Check online theme for offline
    private static void offTheme(WebDriver driver)
    {
        try
        {
            result.put("CWC27",false);
            result.put("CWC28",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"busy");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("offason"))).getLocation().y+"-400)");

            WebElement offelmt = driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("ioffason"));

            if((offelmt.getAttribute("class")).contains("embchk-no"))
            {
                offelmt.click();
            }
            offelmt.click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String chkthm = visDriver.findElement(By.className("zls-small")).findElement(By.id("zls_ctn_wrap")).getAttribute("class");

                if(chkthm.contains("zlsoff-btn"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC27")+" is verified");

                    result.put("CWC27",true);
                }
                else
                {
                    TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","OnlineThemeForOfflineDisable","MimatchUseOnlineThemeforOfflineDisable");

                    result.put("CWC27",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","OnlineThemeForOfflineDisable","Error",e);
            }

            Thread.sleep(3000);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            driver.findElement(By.id("Embedbtnprt")).findElement(By.id("embbtnprv")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            offelmt = driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndlft")).findElement(By.id("ioffason"));

            if((offelmt.getAttribute("class")).contains("embchk-yes"))
            {
                offelmt.click();
            }
            offelmt.click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String chkthm = visDriver.findElement(By.className("zls-small")).findElement(By.id("zls_ctn_wrap")).getAttribute("class");

                if(chkthm.contains("zlsblue-btn"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC28")+" is verified");

                    result.put("CWC28",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","OnlineThemeForOfflineEnable","MimatchUseOnlineThemeforOfflineEnable");

                    result.put("CWC28",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","OnlineThemeForOfflineEnable","Error",e);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","OnlineThemeForOffline","ErrorWhileCheckingOnlineThemeForOffline",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","OnlineThemeForOffline","ErrorWhileCheckingOnlineThemeForOffline",e);
        }
    }

    //Visitor Info Name, Email, Contact Number - enable and required
    private static void visInfo(WebDriver driver)
    {
        try
        {
            result.put("CWC29",false);
            result.put("CWC30",false);
            result.put("CWC31",false);
            result.put("CWC32",false);
            result.put("CWC33",false);
            result.put("CWC34",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();

            Thread.sleep(1000);

            WebElement elmt =  driver.findElement(By.id("embdsptwndonly")).findElement(By.id("addem2")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("vcnfg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("ishowname"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("ishowname")).getAttribute("checked")) != null)
            {
                elmt.findElement(By.id("ishowname")).click();
                Thread.sleep(300);
            }
            elmt.findElement(By.id("ishowname")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("ishowemail"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("ishowemail")).getAttribute("checked")) != null)
            {
                elmt.findElement(By.id("ishowemail")).click();
                Thread.sleep(300);
            }

            elmt.findElement(By.id("ishowemail")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("ishowphone"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("ishowphone")).getAttribute("checked")) != null)
            {
                elmt.findElement(By.id("ishowphone")).click();
                Thread.sleep(300);
            }

            elmt.findElement(By.id("ishowphone")).click();

            Thread.sleep(1000);

            //driver.findElement(By.id("addem2")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String nmand = VisitorWindow.checkMandatoryFields(visDriver,"name")?"true":"false";
                String emand = VisitorWindow.checkMandatoryFields(visDriver,"email")?"true":"false";
                String pmand = VisitorWindow.checkMandatoryFields(visDriver,"phone")?"true":"false";

                if(nmand.equals("false"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC29")+" is verified");

                    result.put("CWC29",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetNameNotRequired","MismatchChatWidgetNameNotRequired");
                    result.put("CWC29",false);
                }

                if(emand.equals("false"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC30")+" is verified");

                    result.put("CWC30",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetEmailNotRequired","MismatchChatWidgetEmailNotRequired");
                    result.put("CWC30",false);
                }

                if(pmand.equals("false"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC31")+" is verified");

                    result.put("CWC31",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetPhoneNUmberNotRequired","MismatchChatWidgetPhonenumberNotRequired");
                    result.put("CWC31",false);
                }

            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetFieldNotRequired","Error",e);
            }

            Thread.sleep(2000);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.xpath("//h6[contains(text(),'Visitor Information')]")).click();

            Thread.sleep(1000);

            elmt =  driver.findElement(By.id("embdsptwndonly")).findElement(By.id("addem2")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("vcnfg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("namemandatory"))).getLocation().y+"-400)");

            elmt.findElement(By.id("namemandatory")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("emailmandatory"))).getLocation().y+"-400)");

            elmt.findElement(By.id("emailmandatory")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("phonemandatory"))).getLocation().y+"-400)");

            elmt.findElement(By.id("phonemandatory")).click();

            Thread.sleep(1000);

            //driver.findElement(By.id("addem2")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                String nmand = VisitorWindow.checkMandatoryFields(visDriver,"name")?"true":"false";
                String emand = VisitorWindow.checkMandatoryFields(visDriver,"email")?"true":"false";
                String pmand = VisitorWindow.checkMandatoryFields(visDriver,"phone")?"true":"false";

                if(nmand.equals("true"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC32")+" is verified");

                    result.put("CWC32",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetNameRequired","MismatchChatWidgetNameRequired");
                    result.put("CWC32",false);
                }

                if(emand.equals("true"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC33")+" is verified");

                    result.put("CWC33",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetEmailRequired","MismatchChatWidgetEmailRequired");
                    result.put("CWC33",false);
                }

                if(pmand.equals("true"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC34")+" is verified");

                    result.put("CWC34",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetPhoneNumberRequired","MismatchChatWidgetPhoneNumberNotRequired");
                    result.put("CWC34",false);
                }

            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetFieldRequired","Error",e);
            }
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetVisitorInfo","ErrorWhileCheckingVisitorInfoSettings",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetVisitorInfo","ErrorWhileCheckingVisitorInfoSettings",e);
        }
    }

    //Check Actions - print, mail, sound, feedback, file sharing
    private static void checkActions(WebDriver driver)
    {
        try
        {
            result.put("CWC35",false);
            result.put("CWC36",false);
            result.put("CWC37",false);
            result.put("CWC38",false);
            result.put("CWC39",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");
            //driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("spt-wndlft")).findElement(By.className("embd-theme"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("icprint"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("cprint")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("cprint")).click();
            }

            elmt.findElement(By.id("cprint")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("icmail"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("cmail")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("cmail")).click();
            }

            elmt.findElement(By.id("cmail")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("icfile"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("cfile")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("cfile")).click();
            }
            elmt.findElement(By.id("cfile")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("icfeedback"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("cfeedback")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("cfeedback")).click();
            }
            elmt.findElement(By.id("cfeedback")).click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("icsound"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("csound")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("csound")).click();
            }
            elmt.findElement(By.id("csound")).click();

            Thread.sleep(1000);

            //driver.findElement(By.id("addem2")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!(driver.findElement(By.id("caddem2")).getText().contains("hide")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"test","tests@as.com","123213","qweqq",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetActions","Error",e);
            }

            ChatWindow.acceptChat(driver,etest);

            try
            {
                VisitorWindow.checkOptions(visDriver);

                for(int i = 35; i<=38 ;i++)
                {
                    result.put("CWC"+i,true);
                }
                
                VisitorWindow.endChatVisitor(visDriver);

                result.put("CWC39",true);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetActions","ErrorWhileCheckingWindowActionSettings",e);
            }
            Thread.sleep(2000);

            driver.findElement(By.id("compdiv")).findElement(By.id("infodiv")).findElement(By.tagName("div")).findElement(By.linkText("Close this window")).click();

            Thread.sleep(2000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetActions","ErrorWhileCheckingWindowActionSettings",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetActions","ErrorWhileCheckingWindowActionSettings",e);
        }
    }

    //Check Supporter photo
    private static void checkSuppPhoto(WebDriver driver)
    {
        try
        {
            result.put("CWC40",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            //driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("spt-wndmid")).findElement(By.id("hdrcnfg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("icphoto"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("cphoto")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("cphoto")).click();
            }
            elmt.findElement(By.id("cphoto")).click();

            Thread.sleep(1000);

            //driver.findElement(By.id("addem2")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!(driver.findElement(By.id("caddem2")).getText().contains("hide")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.initiateChatVisTheme(visDriver,"test","test@test.com","123123","qwerty",etest);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetSupporterImage","Error",e);
            }

            ChatWindow.acceptChat(driver,etest);

            try
            {
                VisitorWindow.clickChatButton(visDriver);
                VisitorWindow.switchToChatWidget(visDriver);

                WebElement elmt11 = visDriver.findElement(By.id("complogo"));

                String src = elmt11.getAttribute("src");

                if(!src.contains("clogo") && src.contains("/userimg/"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC40")+" is verified");

                    result.put("CWC40",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetSupporterImage","SupporterImageNotVisible");

                    result.put("CWC40",false);
                }
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetSupporterImage","Error",e);
            }

            try
            {
                VisitorWindow.endChatVisitor(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetSupporterImage","Error",e);
            }

            Thread.sleep(2000);

            driver.findElement(By.id("compdiv")).findElement(By.id("infodiv")).findElement(By.tagName("div")).findElement(By.linkText("Close this window")).click();

            Thread.sleep(2000);
        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetSupporterImage","ErrorWhileSupporterPhotoSettings",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetSupporterImage","ErrorWhileSupporterPhotoSettings",e);
        }
    }

    //Check Company Logo and enable show users and check for invisibility of company logo
    private static void checkCompLogo(WebDriver driver)
    {
        try
        {
            result.put("CWC41",false);
            result.put("CWC42",false);

            FluentWait wait = new FluentWait(driver);
            wait.withTimeout(30,TimeUnit.SECONDS);
            wait.pollingEvery(250,TimeUnit.MILLISECONDS);
            wait.ignoring(NoSuchElementException.class);

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            //driver.findElement(By.id("embdsptwndonly")).findElement(By.linkText("Change the appearance")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem2"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem2")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem2")));

            Thread.sleep(1000);

            WebElement elmt = driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("spt-wndmid")).findElement(By.id("hdrcnfg"));

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(elmt.findElement(By.id("iclogo"))).getLocation().y+"-400)");

            if((elmt.findElement(By.id("clogo")).getAttribute("class")).contains("embchk-yes"))
            {
                elmt.findElement(By.id("clogo")).click();
            }
            elmt.findElement(By.id("clogo")).click();

            Thread.sleep(1000);

            //driver.findElement(By.id("addem2")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem2")).findElement(By.className("mdchtwndw")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    if(!(driver.findElement(By.id("caddem2")).getText().contains("hide")))
                    {
                        return true;
                    }
                    return false;
                }
            });

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                VisitorWindow.clickChatButton(visDriver);
                VisitorWindow.switchToChatWidget(visDriver);

                WebElement elmt11 = visDriver.findElement(By.id("complogo"));

                String src = elmt11.getAttribute("src");

                if(src.contains("clogo"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC41")+" is verified");

                    result.put("CWC41",true);
                }
                else
                {
                    TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetCompanyLogo","CompanyLogoNotVisible");
                }

                VisitorWindow.clickCloseChatWidget(visDriver);
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetCompanyLogo","Error",e);
            }
            Thread.sleep(2000);

            driver = chooseEmbed(driver,ConfManager.getWEembed());

            Thread.sleep(2000);

            //((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("Embedbtnprt")).findElement(By.linkText("Change the appearance"))).getLocation().y+"-400)");

            //driver.findElement(By.id("Embedbtnprt")).findElement(By.linkText("Change the appearance")).click();

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("caddem3"))).getLocation().y+"-400)");

            driver.findElement(By.id("caddem3")).click();

            Thread.sleep(1000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("addem3")));

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("personalsupport"))).getLocation().y+"-400)");

            WebElement suppelmt = driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("spt-wndmid")).findElement(By.id("ipersonalsupport"));

            if((suppelmt.getAttribute("class")).contains("embchk-yes"))
            {
                suppelmt.click();
            }

            suppelmt.click();

            Thread.sleep(1000);

            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+(driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span"))).getLocation().y+"-400)");

            driver.findElement(By.id("addem3")).findElement(By.className("btnappemd")).findElement(By.className("spt-wndmn")).findElement(By.className("actn-btn-base")).findElement(By.tagName("span")).click();

            Thread.sleep(2000);

            visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);

                visDriver.findElement(By.className("zls-small")).findElement(By.id("zls_ctn_wrap")).click();

                Thread.sleep(1000);

                WebElement chframe11 = visDriver.findElement(By.id("zlscht")).findElement(By.id("zlsiframe"));

                visDriver.switchTo().frame(chframe11);

                WebElement elmt11 = visDriver.findElement(By.id("embedmaindiv"));

                if((elmt11.getAttribute("style")).contains("display: none;"))
                {
                    etest.log(Status.PASS,KeyManager.getRealValue("CWC42")+" is verified");

                    result.put("CWC42",true);
                }
                else
                {
                    TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetShowOperator","OperatorOfflineMessageErrorVisible");

                    result.put("CWC42",false);
                }

                Thread.sleep(1000);

                visDriver.switchTo().defaultContent();

                visDriver.findElement(By.className("zls-sptwndw")).findElement(By.id("zlscht")).findElement(By.id("zlscloseimg")).click();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetShowOperator","Error",e);
            }

        }
        catch(NoSuchElementException e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetCompanyLogoAndShowOperators","ErrorWhileCheckingCompanyLogoSettings",e);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetCompanyLogoAndShowOperators","ErrorWhileCheckingCompanyLogoSettings",e);
        }
    }

    //Check business hours
    public static boolean checkBusinessHour(WebDriver driver)
    {
        try
        {
            Functions.closeBannersAfterLogin(driver);

            if(!(CompanyInfo.enableBusinessHour(driver)&&CompanyInfo.hideChatWidgetwithBusinessHourDisable(driver)))
            {
                TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetBusinessHour","ErrorWhileEnablingBusinessHours");

                return false;
            }

            com.zoho.livedesk.util.common.actions.Status.changeStatus(driver,"available");

            WebDriver visDriver = setUp();

            try
            {
                visDriver = createWidget(visDriver);
                
                VisitorWindow.clickChatButton(visDriver);
                
                VisitorWindow.infoInvisible(visDriver);
                
                VisitorWindow.initiateChatVisTheme(visDriver,"Tester2","rajkumar.natarajan+2213@zohocorp.com","99698966789",null,"business hour text message ? ...",false,etest,true);
                
                etest.log(Status.INFO,VisitorWindow.getInfoMessage(visDriver));
                
                etest.log(Status.PASS,KeyManager.getRealValue("CWC44")+" is verified");

                visDriver.quit();
                
                return true;
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"WebEmbedSettings","ChatWidgetBusinessHour","ErrorWhileCheckingBusinnesHoursInChatWidget",e);

                System.out.println("Exception while checking business hours chat widget in chat widget module : "+e);
            }

            visDriver.quit();
            
            return false;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetBusinessHour","ErrorWhileCheckingBusinnesHoursInChatWidget",e);

            System.out.println("Exception while checking business hours in chat widget module : "+e);
        }
        return false;
    }
    
    public static WebDriver setUp()
    {
        WebDriver driver = null;
        
        try
        {
            driver = Functions.setUp();
            visDrivers.add(driver);
            return driver;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"WebEmbedSettings","ChatWidgetSettingUpNewPageForVisitor","ErrorWhileSettingUpWebdriverInVisitorTrackingModule",e);
            System.out.println("Exception while setting up webdriver in visitor tracking module : "+e);
        }
        return null;
    }

    public static void closeDriver() throws Exception
    {
        for(WebDriver driver : visDrivers)
        {
            try
            {
                driver.quit();
            }
            catch(Exception e){}
        }
    }
}
