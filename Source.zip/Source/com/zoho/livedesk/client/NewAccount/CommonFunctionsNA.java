//$Id$
package com.zoho.livedesk.client.NewAccount;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;

import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.util.common.actions.Rules;
import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.*;
import org.openqa.selenium.StaleElementReferenceException;
import java.util.concurrent.TimeUnit;

import java.awt.Toolkit;
import org.openqa.selenium.Dimension;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.List;

import com.google.common.base.Function;

import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class CommonFunctionsNA {
    
    public static final By
    ACCEPT_TERMS_AND_CONDITIONS = By.id("signup-termservice")
    ;
    
    public static void enterPortalName(WebDriver driver,String portal) throws Exception
    {
    	FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portalname")));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portalname")));
		
		CommonUtilNA.elfinder(driver,"id","portalname").clear();
		CommonUtilNA.elfinder(driver,"id","portalname").sendKeys(portal);

		new Actions(driver).keyDown(Keys.CONTROL).keyUp(Keys.CONTROL);
	}

	//public static boolean
    public static void clickSettings(WebDriver driver) throws Exception
	{
        clickVisitorsOnline(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu_setting")));
		WebElement settings = CommonUtilNA.elfinder(driver,"id","menu_setting");
		settings.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
	}
	
	public static void clickVisitorsOnline(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("rings_tracking")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visitor_monitor")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visitor_monitor")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ldwrap")));
    }
    
    public static void clickVisitorHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_vhistory")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("visits_div")));
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(!driver.findElement(By.id("visits_div")).getAttribute("style").contains("none"))
                {
                    return true;
                }
                return false;
            }
        });
    }

    public static void clickChatHistory(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext",ResourceManager.getRealValue("common_history")).click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("history_div")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("history_div")));
    }

    public static void clickFeedback(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext","Feedback").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("feedback_div")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("feedback_div")));
    }

    public static void clickReports(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext","Reports").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().toLowerCase().contains("reports"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
	}

    public static void clickCannedMessages(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext","Canned Messages").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("Canned Messages"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

    public static void clickMyProfile(WebDriver driver,String view) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_settings"))));
        
        CommonUtilNA.elfinder(driver,"partiallinktext","My Profile").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("rightcontainer")));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rightcontainer")));

        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                if(driver.findElement(By.id("rightcontainer")).getText().contains("My Profile"))
                {
                    return true;
                }
                return false;
            }
        });

        CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","rightcontainer"),"partiallinktext",view).click();
    }

    public static void navToCompTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_company")));
		WebElement e = CommonUtilNA.elfinder(driver,"id","setting_sm_company");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("recorddetail")));
    }

    public static void navToDeptTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_department")));
		WebElement e = CommonUtilNA.elfinder(driver,"id","setting_sm_department");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
    }

    public static void navToPortalSettingsTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_configration")));
		WebElement e = CommonUtilNA.elfinder(driver,"id","setting_sm_configration");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portaleditmodule")));
    }

    public static void navToBlockedIPTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_blockedip")));
		WebElement e = CommonUtilNA.elfinder(driver,"id","setting_sm_blockedip");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modulelist")));
    }

    public static void navToEmbedTab(WebDriver driver) throws Exception
	{
		clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_embedchats")));
		WebElement embed = CommonUtilNA.elfinder(driver,"id","setting_sm_embedchats");
		embed.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
	}

	public static void navToAutomationTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_automation")));
		WebElement e = CommonUtilNA.elfinder(driver,"id","setting_sm_automation");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationtabs")));
    }

	public static void navToChatMonitorTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autochatmonitortab")));
		WebElement e = CommonUtilNA.elfinder(driver,"classname","autochatmonitortab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    } 

    public static void navToIntelligentTriggerTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autotriggerstab")));
		WebElement e = CommonUtilNA.elfinder(driver,"classname","autotriggerstab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }   

    public static void navToVisitorRoutingTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoroutingrulestab")));
		WebElement e = CommonUtilNA.elfinder(driver,"classname","autoroutingrulestab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }   

    public static void navToEmailScheduleTab(WebDriver driver) throws Exception
    {
    	navToAutomationTab(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("autoschedulertab")));
		WebElement e = CommonUtilNA.elfinder(driver,"classname","autoschedulertab");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("automationcontent")));
    }

    public static void navToLeadScoringTab(WebDriver driver) throws Exception
    {
    	clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_leadscoring")));
		WebElement e = CommonUtilNA.elfinder(driver,"id","setting_sm_leadscoring");
		e.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
    }

	public static void navToIntegTab(WebDriver driver) throws Exception
	{
		clickSettings(driver);
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("setting_sm_integration")));
		WebElement integ = CommonUtilNA.elfinder(driver,"id","setting_sm_integration");
		integ.click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("integhome")));
	}

	public static String getCompanyInfo(WebDriver driver,String field) throws Exception
	{
		FluentWait wait = CommonUtilNA.waitreturner(driver,10,250);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("recorddetail")));

		WebElement details = CommonUtilNA.elfinder(driver,"id","recorddetail");

		WebElement e = CommonUtilNA.elementfinder(driver,details,"id",field);

		CommonUtilNA.inViewPort(e);

		return e.getAttribute("value");
	}
	public static WebElement selectEmbedInWebEmbed(WebDriver driver,String embedname) throws Exception
	{
		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("list-row")));

		List<WebElement> list = driver.findElements(By.className("list-row"));

		for(WebElement e : list)
		{
			if(e.getText().contains(embedname))
			{
				return e;
			}
		}

		return null;
	}
	
	public static WebElement selectIntegApp(WebDriver driver,String app)
	{
		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("integ_li")));

		List<WebElement> otherapps = driver.findElements(By.className("integ_li"));
		for(WebElement e: otherapps)
		{
			CommonUtilNA.inViewPort(e);
			if(e.getText().contains(app))
			{
				return e;
			}
		}

		return null;
	}

	public static void signup(WebDriver driver,String name,String email,String pwd)throws Exception
    {
    	FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
                
        if(Util.siteNameout().contains("local"))
            driver.get("https://accounts.localzoho.com");
        else
            driver.get("https://accounts.zoho.com");

        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Sign Up Now")));
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Sign Up Now")));
    	
    	Thread.sleep(1000);
        
        CommonUtilNA.elfinder(driver,"linktext","Sign Up Now").click();

    	wait.until(ExpectedConditions.presenceOfElementLocated(By.className("inner-container")));
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("inner-container")));

    	
        CommonUtilNA.elfinder(driver,"id","firstname").clear();
        CommonUtilNA.elfinder(driver,"id","firstname").sendKeys(name);

        CommonUtilNA.elfinder(driver,"id","emailfield").clear();
        CommonUtilNA.elfinder(driver,"id","emailfield").sendKeys(email);
        
        CommonUtilNA.elfinder(driver,"id","password").clear();
        CommonUtilNA.elfinder(driver,"id","password").sendKeys(pwd);

        CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,ACCEPT_TERMS_AND_CONDITIONS));

        CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"classname","inner-container"),"classname","signupbtn").click();
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("portfolio-wrap")));
        
        if(Util.siteNameout().contains("lab"))
        {
            driver.get("https://labsalesiq.localzoho.com");
        }
        else if(Util.siteNameout().contains("local"))
            driver.get("https://salesiq.localzoho.com");
        else if(Util.siteNameout().contains("pre"))
            driver.get("https://presalesiq.zoho.com");
        else
            driver.get("https://salesiq.zoho.com");

        System.out.println("Login success for Username:"+name);
    }
    
    public static void logout(WebDriver driver) throws Exception
    {
        Functions.logout(driver);
    }
	
	public static WebDriver openVis(WebDriver driver) throws Exception
    {
        driver = Functions.setUp();

        VisitorWindow.createPage(driver,NewAccountUtil.widgetCode);
        
    	return driver;
    }
    
    public static void initiateChatVis(WebDriver driver,String vname,String vemail,String vdept,String vques) throws Exception
    {
        try
        {
            VisitorWindow.initiateChatVisTheme(driver,vname,vemail,null,vdept,vques,NewAccountUtil.etest);
        }
        catch(Exception e)
        {
            driver.switchTo().defaultContent();
            System.out.println("Exception while initiating chat in new account module : ");
            throw e;
        }
    }

    public static void switchToChatWidget(WebDriver driver) throws Exception
    {
        driver.switchTo().frame(CommonUtilNA.elfinder(driver,"id","zlsiframe"));
    }

    public static void acceptChat(WebDriver driver) throws Exception
    {
        ChatWindow.acceptChat(driver,NewAccountUtil.etest);
    }

    public static void clickClosethisWindow(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("infodiv")));
        
        CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,chat,"id","infodiv"),"linktext",ResourceManager.getRealValue("closewindow")).click();
        
        Thread.sleep(1000);
        
    }
    public static void endChatUser(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        WebElement chat = chatInMyChats(driver);

        Thread.sleep(500);
        
        CommonUtilNA.elementfinder(driver,chat,"id","endsession").click();
        
        Thread.sleep(1000);

        CommonUtilNA.elementfinder(driver,chat,"linktext",ResourceManager.getRealValue("endsession_endimd")).click();
            
    }
    
    public static WebElement chatInMyChats(WebDriver driver) throws Exception
    {
        List<WebElement> list = CommonUtilNA.elfinder(driver,"id","mycurrent_div").findElements(By.className("prelative"));

        WebElement chat = null;

        for(WebElement e : list)
        {
            if(e.getAttribute("style").contains("display: block;"))
                chat = e;
        }

        return chat;
    }

    public static String getUserName(WebDriver driver) throws Exception
    {
    	FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    	clickMyProfile(driver,"My Profile");

        Thread.sleep(1000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("userdetails")));
            
        WebElement elmt1 = CommonUtilNA.elfinder(driver,"id","test");

        WebElement userdetails = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt1,"classname","usr-mrgntp"),"id","userdetails");
        
        return userdetails.findElements(By.className("myprfdtlmn_rht")).get(0).getText();
    }
    public static boolean addUser(WebDriver driver,ExtentTest etest,String type, String email) throws Exception //
	{
		try
		{
			FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
            
            clickSettings(driver);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonuseradd")));
            
			CommonUtilNA.elfinder(driver,"id","buttonuseradd").click();
			
            Thread.sleep(1000);
		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtuname")));
            
            CommonUtilNA.elfinder(driver,"id","txtuname").click();
            CommonUtilNA.elfinder(driver,"id","txtuname").sendKeys(email);
		 	Thread.sleep(1000);
		 
		 	if(!("checked".equals((CommonUtilNA.elfinder(driver,"id",type)).getAttribute("checked"))))
			{
				CommonUtilNA.elfinder(driver,"id",type).click();
			 	Thread.sleep(1000);
			}

			CommonUtilNA.elfinder(driver,"id","useradd").click();

            Tab.waitForLoadingSuccessWithBanner(driver,"Operator added successfully","addportaluser.do",etest);
            
            clickVisitorHistory(driver);
            clickSettings(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ulisttable")));
		 	
			List<WebElement> elmts = CommonUtilNA.elfinder(driver,"id","ulisttable").findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				List<WebElement> userdetails = elmt.findElements(By.className("list_cell"));
				if((userdetails.get(2).getText()).equals(email))
				{
					etest.log(Status.PASS,"Operator-"+type+" is added");
		 			return true;
				}
			}
			TakeScreenshot.screenshot(driver,etest,"NewAccount","AddUser","OperatorisNotAdded-"+email);
			return false;
		}
		catch(NoSuchElementException e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddOperator","Error",e);
			return false;
        }
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"NewAccount","AddOperator","Error",e);
			return false;
        }
	}

	public static boolean addDept(WebDriver driver,ExtentTest etest,String deptname, String type)
	{
		try
		{
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
            
			String user = getUserName(driver);
            
            Thread.sleep(1000);
            
            navToDeptTab(driver);
            
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonadddept")));
            
            CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","buttonadddept"),"tagname","span").click();
		 	
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("name")));
            
		 	CommonUtilNA.elfinder(driver,"id","name").click();
		 	CommonUtilNA.elfinder(driver,"id","name").clear();
		 	CommonUtilNA.elfinder(driver,"id","name").sendKeys(deptname);
		 	
		 	CommonUtilNA.elfinder(driver,"id",type).click();
		 	
		 	CommonUtilNA.elfinder(driver,"id","desc").click();
            CommonUtilNA.elfinder(driver,"id","desc").clear();
            CommonUtilNA.elfinder(driver,"id","desc").sendKeys("Description");
		 	
			if(!((driver.findElement(By.className("seldept_alrt")).getAttribute("style")).contains("none")))
			{
				WebElement elmt = CommonUtilNA.elfinder(driver,"id","unassodeptlist");

				CommonUtilNA.inViewPort(elmt);

				List<WebElement> elmts = elmt.findElements(By.className("associatesel"));

				for(WebElement element:elmts)
				{
					CommonUtilNA.inViewPort(element);

					WebElement ptag = CommonUtilNA.elementfinder(driver,element,"tagname","p");
					
					if(user.equals(ptag.getText()))
					{
						CommonUtilNA.elementfinder(driver,element,"tagname","div").click();
						break;
					}
				}
			}
		 	
		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("deptaddbtn")));

		 	WebElement add = CommonUtilNA.elfinder(driver,"id","deptaddbtn");

		 	CommonUtilNA.inViewPort(add);

		 	((JavascriptExecutor) driver).executeScript("window.scrollTo(0,"+add.getLocation().y+")");
            
            add.click();
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Department added successfully","adddept.do",etest);
            
            return checkAddedDept(driver,etest,deptname, type, user);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddDepartment","Error",e);
			return false;
        }
	}

	public static boolean checkAddedDept(WebDriver driver,ExtentTest etest,String deptname, String type, String username)
	{
		try
		{
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
            
            navToDeptTab(driver);

            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("module-list")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-list")));
            
            List<WebElement> elmts = CommonUtilNA.elfinder(driver,"id","module-list").findElements(By.className("list-row"));

			WebElement dept = null;

			for(WebElement elmt:elmts)
			{
				String data = CommonUtilNA.elementfinder(driver,elmt,"classname","txtelips").getText();
				
				if(data.equals(deptname))
				{
                    dept = elmt;
					break;
				}
			}

			String name = CommonUtilNA.elementfinder(driver,dept,"classname","dept_namewth").getText();
    		String desc = CommonUtilNA.elementfinder(driver,dept,"classname","dept_descwth").getText();
    		String type1 = CommonUtilNA.elementfinder(driver,dept,"classname","u_rolwt").getText();

    		String typetobe = "Public";

    		if(type.equals("depttype_privat"))
    		{
    			typetobe = "Private";
    		}

    		if(!name.contains(deptname) && !desc.contains("Description") && !type1.contains(typetobe) )
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+deptname+"--"+"Description"+"--"+typetobe+"--"+"Actual:"+name+"--"+desc+"--"+type1+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckingAddedDepartment","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckingAddedDepartment","Error",e);
            return false;
		}
	}

	public static boolean addWebEmbed(WebDriver driver,ExtentTest etest,String embed, String department)
	{
		try
		{
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
			
			navToEmbedTab(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));
		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("buttonembedadd")));
		 	
		 	CommonUtilNA.elfinder(driver,"id","buttonembedadd").click();
            
            Thread.sleep(1000);

		 	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("emname")));
		 	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("emname")));
		 	
		 	CommonUtilNA.elfinder(driver,"id","emname").click();
		 	CommonUtilNA.elfinder(driver,"id","emname").clear();
		 	CommonUtilNA.elfinder(driver,"id","emname").sendKeys(embed);
		 	
            Thread.sleep(500);

			CommonUtilNA.elfinder(driver,"id","departmentselect_div").click();

			List<WebElement> lis=CommonUtilNA.elfinder(driver,"id","departmentselect_ddown").findElements(By.tagName("li"));

			for(int i=0;i<lis.size();i++)
			{
				WebElement element = lis.get(i);
				WebElement element2 = CommonUtilNA.elementfinder(driver,element,"tagname","div");
				WebElement element3 = CommonUtilNA.elementfinder(driver,element2,"tagname","span");
				
				String title = element3.getAttribute("title");
				
				if(title.equals(department))
				{
					element.click();
					break;
				}
			}
            
			Thread.sleep(1000);

            CommonUtilNA.inViewPort(CommonUtilNA.elfinder(driver,"id","ipsavebtn"));

            CommonUtilNA.elfinder(driver,"id","ipsavebtn").click();
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Generated successfully","addembed.do",etest);
            
			return checkAddedEmbed(driver,etest,embed, department);
		}
		catch(Exception e)
		{
			TakeScreenshot.screenshot(driver,etest,"NewAccount","AddEmbed","Error",e);
            return false;
		}
	}

	public static boolean checkAddedEmbed(WebDriver driver,ExtentTest etest,String id, String department)
	{
		try
		{
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
			
			navToEmbedTab(driver);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embedlist")));

			List<WebElement> elmts = CommonUtilNA.elfinder(driver,"id","embedlist").findElements(By.className("list-row"));

			WebElement embed = null;

			for(WebElement elmt:elmts)
			{
				String data = CommonUtilNA.elementfinder(driver,elmt,"classname","txtelips").getText();

				if(data.equals(id))
				{
					List<WebElement> em = elmt.findElements(By.tagName("em"));
					
					if(department.equals(em.get(2).getText()))
					{
						embed = elmt;
					}
				}
			}

			List<WebElement> content = embed.findElements(By.className("list_cell"));

    		String embedname = content.get(0).getText();
    		String dept = content.get(1).getText();
    		String created = content.get(2).getText();

    		if(!embedname.contains(id) && !dept.contains(department) && !created.contains(NewAccountUtil.name) )
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+id+"--"+department+"--"+NewAccountUtil.name+"--"+"Actual:"+embedname+"--"+dept+"--"+created+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAddedWebEmbed","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAddedWebEmbed","Error",e);
			return false;
        }
	}

	public static boolean addIP(WebDriver driver,ExtentTest etest, String ip)
	{
		try
		{
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
            
            navToBlockedIPTab(driver);

            Thread.sleep(1500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));
            
			CommonUtilNA.elfinder(driver,"linktext",ResourceManager.getRealValue("common_add")).click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txtipname")));
			
		 	CommonUtilNA.elfinder(driver,"id","txtipname").clear();
		    CommonUtilNA.elfinder(driver,"id","txtipname").sendKeys(ip);
		    Thread.sleep(300);
		    
		    wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ipsavebtn")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ipsavebtn")));
			
		    CommonUtilNA.elfinder(driver,"id","ipsavebtn").click();
            
            Tab.waitForLoadingSuccessWithBanner(driver,"Added successfully","blockip.do",etest);
            
		    return findIP(driver,etest,ip);
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddIP","Error",e);
        	return false;
		}
	}
	
	//find Blocked IP
	private static boolean findIP(WebDriver driver,ExtentTest etest,String ip)
	{
		try
		{
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
            
            navToBlockedIPTab(driver);

            Thread.sleep(1500);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("listview")));
            
			List<WebElement> elmts = CommonUtilNA.elfinder(driver,"id","listview").findElements(By.className("list-row"));
			
			for(WebElement welmt:elmts)
			{
				List<WebElement> elmts1 = welmt.findElements(By.className("list_cell"));
				
				if((elmts1.get(0).getText()).contains(ip))
				{
					etest.log(Status.PASS,"Added Blocked IP is present");
		 			return true;
				}
			}

			etest.log(Status.FAIL,ip+" is not present");
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAddIP","NotPresent");
            return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAddIP","Error",e);
            return false;
		}
	}

	public static String getRadioButtonId(String type)
    {
        String typeid = null;
        String ipid = null;
        
        if(type.equals("VisitorEmail"))
        {
            typeid = "cmvisitoremail";
            ipid = "cmvisitoremailinput";
        }
        else if(type.equals("IpAddress"))
        {
            typeid = "cmipaddress";
            ipid = "cmipaddressinput";
        }
        else
        {
            typeid = "cmsupportrep";
            ipid = "cmsupportrepinput";
        }
        
        return typeid;
    }
    
    public static String getInputId(String type)
    {
        String typeid = null;
        String ipid = null;
        
        if(type.equals("VisitorEmail"))
        {
            typeid = "cmvisitoremail";
            ipid = "cmvisitoremailinput";
        }
        else if(type.equals("IpAddress"))
        {
            typeid = "cmipaddress";
            ipid = "cmipaddressinput";
        }
        else
        {
            typeid = "cmsupportrep";
            ipid = "cmsupportrepinput";
        }
        
        return ipid;
    }

    public static void clickAddInChatMonitor(WebDriver driver) throws Exception
    {
        Trigger.clickAddButtonAutomationTab(driver,"chatmonitortab");
    }
    public static boolean addChatMonitor(WebDriver driver,ExtentTest etest,String type,String value) throws Exception
    {
    	try
    	{
	        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
	        
	        navToChatMonitorTab(driver);
	            
	        final String typeid = getRadioButtonId(type);
	        final String ipid = getInputId(type);
	        
	        clickAddInChatMonitor(driver);

	        CommonUtilNA.elfinder(driver,"xpath","//*[contains(.,'"+ResourceManager.getRealValue("settings_addchatmonitor")+"')]");
	        
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(typeid)));
	        
	        CommonUtilNA.elfinder(driver,"id",typeid).click();
	        
	        wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(!driver.findElement(By.id(ipid)).getAttribute("class").contains("disable_cntnr"))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });
	        
	        if(type.equals("User"))
	        {
	            wait.until(ExpectedConditions.presenceOfElementLocated(By.id(ipid)));

	            CommonUtilNA.elfinder(driver,"id",ipid).click();

	            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cmsupportrepinput_ddown")));

	            List<WebElement> users = CommonUtilNA.elfinder(driver,"id","cmsupportrepinput_ddown").findElements(By.tagName("li"));

	            for(WebElement e : users)
	            {
	                if(e.getText().equals(value))
	                    e.click();
	            }

	            wait.until(new Function<WebDriver,Boolean>(){
	                public Boolean apply(WebDriver driver)
	                {
	                    if(driver.findElement(By.id("cmsupportrepinput_ddown")).getAttribute("style").contains("none"))
	                    {
	                        return true;
	                    }
	                    return false;
	                }
	            });
	        }
	        else
	        {
	            CommonUtilNA.elfinder(driver,"id",ipid).sendKeys(value);
	        }
	        Thread.sleep(300);
            
	        CommonUtilNA.elfinder(driver,"id","ipsavebtn").click();

            Thread.sleep(5000);
            
	        return checkAddedChatMonitor(driver,etest,value);
	    }
	    catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddChatMonitor","Error",e);
            return false;
		}
    }

    public static boolean checkAddedChatMonitor(WebDriver driver,ExtentTest etest ,String value)
	{
		try
		{
			FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
	        
	        navToChatMonitorTab(driver);
            
            Thread.sleep(1000);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("innsubtitle")));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("listview")));

			List<WebElement> elmts = CommonUtilNA.elfinder(driver,"id","listview").findElements(By.className("list-row"));

			for(WebElement elmt:elmts)
			{
				String data = CommonUtilNA.elementfinder(driver,elmt,"classname","txtelips").getText();
			
				if(data.equals(value))
				{
					etest.log(Status.PASS,"Added ChatMonitor is present");
					return true;
				}
			}

			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAddedChatMonitor","ChatMonitorIsNotAdded:"+value);
			return false;
		}
		catch(Exception e)
		{
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAddedChatMonitor","Error",e);
			return false;
        }
	}

	public static boolean addIntelligentTrigger(WebDriver driver,ExtentTest etest) throws Exception
    {
        String
        event="Lands on my website",
        ruler1="Browser",
        ruler2="is equal to",
        ruler3="Google Chrome",
        ruler4=null,
        actionr1="Send chat invite",
        actionr2="13 Seconds",
        actionr3="Tester",
        actionr4="Hello there";


        Tab.navToITTab(driver);
        Trigger.clickAdd(driver,etest);
        String id = Trigger.getRuleId(driver,0);
        Boolean allTrue[] = {true,true,true,true,true,true,true,true,true};
        Trigger.openRuleEditView(driver,id);
        com.zoho.livedesk.client.Triggers.CommonFunctions.fillFields(driver,etest,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4,allTrue);
        id = Trigger.getRuleId(driver,0);
        boolean res = true;
        Boolean failed[] = com.zoho.livedesk.client.Triggers.CommonFunctions.checkValues(driver,etest,Status.INFO,id,event,ruler1,ruler2,ruler3,ruler4,actionr1,actionr2,actionr3,actionr4);
        
        for(Boolean f : failed)
        {
            if(f)
            {
                res = false;
                break;
            }
        }
        
        if(res)
        {
            etest.log(Status.PASS,"Trigger is added successfully");
        }
        else
        {
            etest.log(Status.FAIL,"Trigger was not added successfully");
            TakeScreenshot.screenshot(driver,etest);
        }

        return res;
    }

    public static void addFieldsInCreateScoringRules(WebDriver driver,String pnum,String condition,String condition1,String criteria,String value1,String value2) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,10,200);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
        
        final WebElement elmt = CommonUtilNA.elfinder(driver,"id","ldsettings");
        
        String cid = "prior"+pnum+"_col1_div";
        final String cdown = "prior"+pnum+"_col1_ddown";
        
        CommonUtilNA.elementfinder(driver,elmt,"id",cid).click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if((elmt.findElement(By.id(cdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });
        
        CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id",cdown),"id","srchtxt"),"tagname","input").sendKeys(condition);
        
        WebElement cond = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id",cdown),"id","prior"+pnum+"_col10"),"tagname","li");
        
        wait.until(ExpectedConditions.visibilityOf(cond));
        
        cond.click();
        
        if(condition1 != null)
        {
            WebElement cond1 = CommonUtilNA.elementfinder(driver,elmt,"id","prior"+pnum+"_col4");
            if(cond1.getAttribute("comp") != null)
            {
                cond1.click();
                final String cdown1 = "prior"+pnum+"_col4_ddown";
                
                wait.until(new Function<WebDriver,Boolean>(){
                    public Boolean apply(WebDriver driver)
                    {
                        try
                        {
                            if((elmt.findElement(By.id(cdown1)).getAttribute("style")).equals("display: block;"))
                            {
                                return true;
                            }
                        }
                        catch(Exception e){}
                        return false;
                    }
                });
                
                CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id",cdown1),"id","srchtxt"),"tagname","input").sendKeys(condition1);
                
                wait.until(ExpectedConditions.visibilityOf(CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id",cdown1),"id","prior"+pnum+"_col40"),"tagname","li")));
                
                CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id",cdown1),"id","prior"+pnum+"_col40"),"tagname","li").click();
            }
            else
            {
                CommonUtilNA.elementfinder(driver,cond1,"tagname","input").sendKeys(condition1);
            }
        }
        
        String qid = "prior"+pnum+"_col2_div";
        final String qdown = "prior"+pnum+"_col2_ddown";
        
        CommonUtilNA.elementfinder(driver,elmt,"id",qid).click();
        
        wait.until(new Function<WebDriver,Boolean>(){
            public Boolean apply(WebDriver driver)
            {
                try
                {
                    if((elmt.findElement(By.id(qdown)).getAttribute("style")).equals("display: block;"))
                    {
                        return true;
                    }
                }
                catch(Exception e){}
                return false;
            }
        });
        
        List<WebElement> elmts = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id",qdown),"id","prior"+pnum+"_col20").findElements(By.tagName("li"));
        
        for(WebElement elmts1:elmts)
        {
            if((elmts1.getText()).equals(criteria))
            {
                CommonUtilNA.inViewPort(elmts1);
                elmts1.click();
                break;
            }
        }
        
        String vid = "prior"+pnum+"_col3";
        final WebElement elmtip = CommonUtilNA.elementfinder(driver,elmt,"id",vid);
        
        if(criteria.equals("is between"))
        {
            CommonUtilNA.elementfinder(driver,elmtip,"id","col3_input1").sendKeys(value1);
            CommonUtilNA.elementfinder(driver,elmtip,"id","col3_input2").sendKeys(value2);
        }
        else
        {
            CommonUtilNA.elementfinder(driver,elmtip,"id","col3_input1").sendKeys(value1);
        }
    }
    
    public static void addPointsForRulesInLeadScoring(WebDriver driver,String points,boolean add) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,200);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
        
        WebElement elmt = CommonUtilNA.elfinder(driver,"id","ldsettings");
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldaddpoints")));
        
        if(add)
        {
            CommonUtilNA.elementfinder(driver,elmt,"id","addpoints").click();
        }
        else
        {
            CommonUtilNA.elementfinder(driver,elmt,"id","lesspoints").click();
        }
        
        CommonUtilNA.elementfinder(driver,elmt,"id","ldaddpoints").click();
        CommonUtilNA.elementfinder(driver,elmt,"id","ldaddpoints").clear();
        CommonUtilNA.elementfinder(driver,elmt,"id","ldaddpoints").sendKeys(points);
        
    }
    
    public static void clickApplyInCreateRulesLeadScoring(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,200);
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ldsettings")));
        
        WebElement elmt = CommonUtilNA.elfinder(driver,"id","ldsettings");
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("cnfmbtm")));
        
        CommonUtilNA.elementfinder(driver,elmt,"classname","cnfmbtm").click();
        
        Tab.waitForLoadingSuccessWithBanner(driver,"Rule added successfully","addleadscorerule.do",NewAccountUtil.etest);
    }
    
    public static void clickAddInLeadScoring(WebDriver driver) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,200);
        
        navToLeadScoringTab(driver);
        
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("leadscore")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(ResourceManager.getRealValue("common_add"))));
        
        driver.findElement(By.linkText(ResourceManager.getRealValue("common_add"))).click();
        
        Thread.sleep(1000);
        
        wait.until(new Function<WebDriver,Boolean>()
           {
               public Boolean apply(WebDriver driver)
               {
                   if(!((driver.findElement(By.id("ldsettings")).getAttribute("style")).contains("display: none;")))
                   {
                       return true;
                   }
                   return false;
               }
           });
    }

    public static WebElement selectRuleInLeadScoring(WebDriver driver,String condition,String condition1,String criteria,String value1,String value2) throws Exception
    {
        FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
        
        String checkcond;
        
        if(condition1 != null)
        {
            if((condition.contains("Visitor") || condition.contains("Current Visit Source")) && !condition.contains("Visitor Source"))
            {
                if(value2 != null)
                {
                    checkcond = "If the "+condition+" "+condition1+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the "+condition+" "+condition1+" "+criteria+" "+value1;
                }
            }
            else
            {
                if(value2 != null)
                {
                    checkcond = "If the visitor "+condition+" "+condition1+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the visitor "+condition+" "+condition1+" "+criteria+" "+value1;
                }
            }
        }
        else
        {
            if((condition.contains("Visitor") || condition.contains("Current Visit Source")) && !condition.contains("Visitor Source"))
            {
                if(value2 != null)
                {
                    checkcond = "If the "+condition+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the "+condition+" "+criteria+" "+value1;
                }
            }
            else
            {
                if(value2 != null)
                {
                    checkcond = "If the visitor "+condition+" "+criteria+" "+value1+" to "+value2;
                }
                else
                {
                    checkcond = "If the visitor "+condition+" "+criteria+" "+value1;
                }
            }
        }
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("leadscore")));
        
        List<WebElement> list = CommonUtilNA.elfinder(driver,"id","leadscore").findElements(By.className("leadscrlst"));
        
        for(WebElement e : list)
        {
            if(e.getText().contains(checkcond))
            {
                CommonUtilNA.inViewPort(e);
                
                return e;
            }
        }
        
        return null;
    }

    public static boolean addVisitorRouting(WebDriver driver,ExtentTest etest,String cond,String qual,String val1,String act)
    {
        String elid = "0";
        WebElement elmt;
        try
        {
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
            
            navToVisitorRoutingTab(driver);
            
            Thread.sleep(1000);

            com.zoho.livedesk.client.VisitorRoutingRT.CommonFunctionsVR.addVisitorRouting(driver,etest,NewAccountUtil.name,cond,"No Value",qual,val1,"No Value",act);
            
            // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));
            // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("autobtnadd")));
            // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("autobtnadd")));
            
            // List<WebElement> intcnt = CommonUtilNA.elfinder(driver,"id","trouting").findElements(By.className("trules"));
            
            // final int rcount = intcnt.size();

            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","autobtnadd"),"tagname","span").click();
            
            
            // Thread.sleep(1000);
            
            // wait.until(new Function<WebDriver,Boolean>()
            // {
            //     public Boolean apply(WebDriver driver)
            //     {
            //         List<WebElement> intcnt1 = driver.findElement(By.id("trouting")).findElements(By.className("trules"));
            //         int rcountchk = 0;
                    
            //         for(WebElement elmt:intcnt1)
            //         {
            //             rcountchk++;
            //         }
            //         if(rcountchk == (rcount+1))
            //         {
            //             return true;
            //         }
            //         return false;
            //     }
            // });
            
            // Thread.sleep(1000);

            // String elid = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","trouting"),"classname","trules").getAttribute("ruleid");
            
            // WebElement elmt = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","trouting"),"classname","trules");
            
            // CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col1_div").click();
            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col1_ddown"),"id","srchtxt"),"tagname","input").sendKeys(cond);

            // Thread.sleep(500);
            
            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col1_ddown"),"tagname","ul"),"tagname","li").click();
            // Thread.sleep(500);
            
            // CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col2_div").click();
            
            // List<WebElement> quallist = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col2_ddown"),"tagname","ul").findElements(By.tagName("li"));
            
            // for(WebElement qual1:quallist)
            // {
            //     if((qual1.getText()).equals(qual))
            //     {
            //         qual1.click();
            //     }
            // }
            
            // Thread.sleep(500);

            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col3"),"id","col3_input1").click();
            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col3"),"id","col3_input1").sendKeys(val1);
            
            // Thread.sleep(500);
            
            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"classname","routeto"),"id","info_"+elid),"id","info_"+elid+"_div").click();

            // List<WebElement> rlist = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"classname","routeto"),"id","info_"+elid),"id","info_"+elid+"_ddown"),"tagname","ul").findElements(By.tagName("li"));
            
            // for(WebElement rlist1:rlist)
            // {
            //     if((rlist1.getText()).equals(act))
            //     {
            //         rlist1.click();
            //     }
            // }
            
            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"classname","routeto"),"classname","ruleval"),"id","agentcontainer"+elid),"tagname","em").click();
            
            // CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"classname","routeto"),"classname","ruleval"),"id","agentcontainer"+elid),"tagname","input").sendKeys("Name");
            
            // elmt.findElement(By.className("routeto")).findElement(By.className("ruleval")).findElement(By.id("agentcontainer"+elid)).findElement(By.id("agentmail_"+elid+"auto")).findElement(By.tagName("ul")).findElement(By.tagName("li")).click();
            
            // Thread.sleep(15000);
            
            // System.out.println("Updated Entry and waited for 5 secs - If not updated it may be because of network slowness issue");
            
            // navToVisitorRoutingTab(driver);

            // wait.until(ExpectedConditions.presenceOfElementLocated(By.id("trouting")));

            Tab.navToVRTab(driver);
            
            elid = Routing.getRuleId(driver,0);     //CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","trouting"),"classname","trules").getAttribute("ruleid");

            Rules.openRuleEditView(driver,elid);
            
            elmt = Rules.getRuleEditContainer(driver,elid);     //CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","trouting"),"classname","trules");
            
            System.out.println((CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col1_div").getText())+"++++++"+
                ((CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col2_div").getText()))+"++++++"+
                    (CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col3"),"id","col3_input1").getAttribute("title")));
            
            if(((CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col1_div").getText()).equals(cond))
                &&((CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col2_div").getText()).equals(qual))
                    &&((CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,elmt,"id","prior"+elid+"_col3"),"id","col3_input1").getAttribute("title")).equals(val1)))
            {
                if(((elmt.findElement(By.className("routeto")).findElement(By.id("info_"+elid)).findElement(By.id("info_"+elid+"_div"))).getText()).equals(act))
                {
                    CommonUtilNA.mouseHover(driver,((elmt.findElement(By.className("routeto")).findElement(By.className("ruleval")).findElement(By.tagName("span")))));
                    Thread.sleep(500);
                    
                    System.out.println((elmt.findElement(By.className("routeto")).findElement(By.className("ruleval")).findElement(By.tagName("span")).getText())+">>>>>>>>>>");
                    if(((elmt.findElement(By.className("routeto")).findElement(By.className("ruleval")).findElement(By.tagName("span")).findElement(By.className("agntname")).getText()).equals(NewAccountUtil.name)))
                    {
                        etest.log(Status.PASS,"Checked");
                        Rules.cancelRule(driver,etest,elid);
                        return true;
                    }
                    else
                    {
                        etest.log(Status.FAIL,"MismatchContent:"+NewAccountUtil.name);
                        TakeScreenshot.screenshot(driver,etest,"NewAccount","AddVisitorRouting","MismatchContent");
                        Rules.cancelRule(driver,etest,elid);
                        return false;
                    }
                }
                else
                {
                    etest.log(Status.FAIL,"MismatchContent:"+act);
                    TakeScreenshot.screenshot(driver,etest,"NewAccount","AddVisitorRouting","MismatchContent");
                    Rules.cancelRule(driver,etest,elid);
                    return false;
                }
            }
            else
            {
                etest.log(Status.FAIL,"MismatchContent:"+cond+","+qual+","+val1);
                TakeScreenshot.screenshot(driver,etest,"NewAccount","AddVisitorRouting","MismatchContent");
                Rules.cancelRule(driver,etest,elid);
                return false;
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddVisitorRouting","Error",e);
            Rules.cancelRule(driver,etest,elid);
            return false;
        }
    }

}
