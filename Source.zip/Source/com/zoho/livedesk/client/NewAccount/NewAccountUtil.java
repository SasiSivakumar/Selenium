//$Id$
package com.zoho.livedesk.client.NewAccount;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.zoho.livedesk.server.ConfManager;
import com.zoho.livedesk.server.ResourceManager;
import com.zoho.livedesk.server.KeyManager;
import com.zoho.livedesk.client.TakeScreenshot;
import com.zoho.livedesk.client.ComplexReportFactory;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.*;
import java.util.List;
import java.util.Set;
import java.util.Arrays;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import com.zoho.livedesk.util.Util;
import com.zoho.livedesk.util.common.*;
import com.zoho.livedesk.util.common.actions.ExecuteStatements;
import org.openqa.selenium.JavascriptExecutor;

import com.google.common.base.Function;

import com.zoho.livedesk.util.common.actions.Tab;

import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions;
import com.zoho.livedesk.client.TrackingRingsCustomize.TrackingRingsCustomizeCommonFunctions.VisitorsViewType;
import com.zoho.livedesk.client.CannedResponse.CannedResponseModule;
import com.zoho.livedesk.util.common.actions.Articles;
import com.zoho.livedesk.client.bots.*;

public class NewAccountUtil {
    
    public static Hashtable result = new Hashtable();
    public static Hashtable servicedown = new Hashtable();
    public static Hashtable hashtable = new Hashtable();
    private static String requrl = "";
	public static ExtentTest etest; 
	public static WebDriver driver = null;
    public static String name = null;
    public static String comp = null;
    public static String email = null;
    public static String timezone = null;
    public static String domain = null;
    public static String widgetCode = null;
    public static String apps[] = new String[]{"Zoho CRM","Zoho Desk","Zoho Campaigns","Zoho Assist","Clearbit (Reveal)","Clearbit (Enrichment)","Salesforce","Zendesk","MailChimp",
    							"Aweber","Active Campaign","Bronto","Campaign Monitor","Campaignmaster","dotMailer","GetResponse","Icontact","Aurea (Lyris)","Mad Mimi","Vertical Response",
    								"Whatcounts","Constant contact","Google Analytics","Clicky","KissMetrics","Optimizely","Woopra","Matomo","MixPanel","HubSpot","Google Tag Manager"};
    public static String mobDeskApps[] = new String[]{"App store for iPhone, iPad Get Now","Play store for Mobile, Tablet Get Now","Extension for Browsers Chrome Firefox","Desktop for OS Mac Windows Ubuntu"};
    public static Hashtable<String,String> leadscore_rule = new Hashtable();
    public static Hashtable<String,String> leadscore_points = new Hashtable();

    public static final By
    SIGNUP_PAGE_USER_ICON = By.id("authtokenuserimg");
    		
    public static void init()
    {
    	leadscore_rule.put("1","If the Visitor Email Id updated after 1st visit");
    	leadscore_rule.put("2","If the Visitor Email Id updated on 1st visit");
    	leadscore_rule.put("3","If the visitor Actions performed is equal to Triggered Replied");
    	leadscore_rule.put("4","If the visitor Actions performed is equal to Contacted");
    	leadscore_rule.put("5","If the visitor Landing Page URL contains help OR If the visitor Landing Page URL contains resource OR If the visitor Landing Page URL contains userguide OR If the visitor Landing Page URL contains knowledge");
    	leadscore_rule.put("6","If the visitor Number of URLs Accessed is more than 5");
    	leadscore_rule.put("7","If the visitor Time on Site is more than 2 Minutes AND If the visitor Number of URLs Accessed is more than 1");
    	leadscore_rule.put("8","If the visitor Time on Site is between 1 Minute to 2 Minutes AND If the visitor Number of URLs Accessed is more than 1");
    	leadscore_rule.put("9","If the Current Visit Source is equal to Direct AND If the visitor Number of URLs Accessed is more than 1");
    	leadscore_rule.put("10","If the Current Visit Source is equal to Search Engine AND If the visitor Number of URLs Accessed is more than 1");
    	leadscore_rule.put("11","If the Current Visit Source is equal to AdWords, Campaign, Social Media AND If the visitor Number of URLs Accessed is more than 1");
    	leadscore_rule.put("12","If the visitor Email Address contains "+domain);
    	leadscore_points.put("1","Add 25 points");
    	leadscore_points.put("2","Add 10 points");
    	leadscore_points.put("3","Add 50 points");
    	leadscore_points.put("4","Add 100 points");
    	leadscore_points.put("5","Less 30 points");
    	leadscore_points.put("6","Add 20 points");
    	leadscore_points.put("7","Add 15 points");
    	leadscore_points.put("8","Add 10 points");
    	leadscore_points.put("9","Add 3 points");
    	leadscore_points.put("10","Add 10 points");
    	leadscore_points.put("11","Add 20 points");
    	leadscore_points.put("12","Less 50 points");
    		
    }
    public static Hashtable newacc(WebDriver d){
    	try{

            result = new Hashtable();
            
            Long t = new Long(System.currentTimeMillis());

    		name = "Name"+t.toString();
    		email= t.toString()+"@email.com";
    		comp = "comp"+t.toString();
    		domain = t.toString()+".com";

    		etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA1"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");
            
            driver =com.zoho.livedesk.util.common.Driver.getLinuxDriver();
			
            CommonFunctionsNA.signup(driver,name,email,"qwaszxA1@");

            CommonFunctionsNA.enterPortalName(driver,"");

            String currentURL = driver.getCurrentUrl();
            if(currentURL.contains("newportal.do"))
            {
            	etest.log(Status.PASS,"Checked");
            	result.put("NA1",true);
            }
            else
            {
            	TakeScreenshot.screenshot(driver,etest,"NewAccount","PortalCreatePageURL","MismatchContent"+currentURL);
    			result.put("NA1",false);
            }

			ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA2"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA2",checkAlertInPortalName(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA3"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA3",createPortal(driver,comp));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA4"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA4",checkName(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("New Account - Check Alert for install code");
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			checkAlertForInstallCode(driver);
			
            ComplexReportFactory.closeTest(etest);

            widgetCode = ExecuteStatements.getWidgetCode(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA8"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA8",checkVisitorsOnlineTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA9"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA9",checkPortalList(driver));
			driver.get(Util.siteNameout());
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA47"));
            ComplexReportFactory.setValues(etest,"Automation","New Account");

            result.put("NA47",checkMobileAndDesktopApps(driver));
            driver.get(Util.siteNameout());
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA10"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA10",checkVisitorHistoryTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA11"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA11",checkChatHistoryTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA12"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA12",checkFeedbackTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA13"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA13",checkReportsForNoData(driver,"Overview",new String[]{"1","2","3","4","5","6"}));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA14"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA14",checkReportsForNoData(driver,"Visitors",new String[]{"1","2","3"}));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA15"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA15",checkReportsForNoData(driver,"Operators",new String[]{"2"}));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA16"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA16",checkReportsTrackingForNoData(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA17"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA17",CannedResponseModule.isEmptyState(driver,etest));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA18"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

            Tab.navToArticlesTab(driver);
            boolean isArticlesEmpty=Articles.isEmptySlate(driver);

            if(isArticlesEmpty)
            {
                etest.log(Status.PASS,"Articles tab was found empty as expecterd");
            }
            else
            {
                etest.log(Status.FAIL,"Articles tab was NOT found as empty.");
                TakeScreenshot.screenshot(driver,etest);
            }

			result.put("NA18",isArticlesEmpty);
			
            ComplexReportFactory.closeTest(etest);
            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA19"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA19",checkMyProfileDetails(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA20"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA20",checkMyProfileInternalChatHistory(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA21"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA21",checkUsersTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA22"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA22",checkCompanyTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA23"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA23",checkDepartmentTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA24"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA24",checkPortalSettingsTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA25"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA25",checkBlockedIPTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA26"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA26",checkWebEmbedTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA27"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA27",checkChatMonitorTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA28"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA28",checkIntelligentTriggerTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA29"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA29",checkVisitorRoutingTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA30"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA30",checkEmailScheduleTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA31"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA31",checkLeadScoringTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA32"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA32",checkIntegrationTab(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA33"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA33",initiateChatVis(driver));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA34"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA34",CommonFunctionsNA.addUser(driver,etest,"agentyp_super","supervisor@email.com"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA35"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA35",CommonFunctionsNA.addUser(driver,etest,"agentyp_agent","associate@email.com"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA36"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA36",CommonFunctionsNA.addDept(driver,etest,"Public Department","depttype_publi"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA37"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA37",CommonFunctionsNA.addDept(driver,etest,"Private Department","depttype_privat"));
			
            ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA38"));
//			ComplexReportFactory.setValues(etest,"Automation","New Account");
//
//			result.put("NA38",CommonFunctionsNA.addWebEmbed(driver,etest,"embed1"));
//			
//            ComplexReportFactory.closeTest(etest);

//            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA39"));
//			ComplexReportFactory.setValues(etest,"Automation","New Account");
//
//			result.put("NA39",CommonFunctionsNA.addWebEmbed(driver,etest,"embed2",comp));
//			
//            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA40"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA40",CommonFunctionsNA.addIP(driver,etest,"1.1.1.1"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA41"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA41",CommonFunctionsNA.addChatMonitor(driver,etest,"VisitorEmail","visitor@email.com"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA42"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA42",CommonFunctionsNA.addChatMonitor(driver,etest,"IpAddress","1.2.3.4"));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA43"));
			ComplexReportFactory.setValues(etest,"Automation","New Account");

			result.put("NA43",CommonFunctionsNA.addIntelligentTrigger(driver,etest));
			
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA44"));
            ComplexReportFactory.setValues(etest,"Automation","New Account");

            result.put("NA44",CommonFunctionsNA.addVisitorRouting(driver,etest,"City","is not equal to","Checking","Route to least loaded"));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA45"));
            ComplexReportFactory.setValues(etest,"Automation","New Account");

            result.put("NA45",addLeadScoreRule(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("NA46"));
            ComplexReportFactory.setValues(etest,"Automation","New Account");

            result.put("NA46",initiateChatVisWithDept(driver));
            
            ComplexReportFactory.closeTest(etest);

            etest = ComplexReportFactory.getTest("Check Integration Settings images");
            ComplexReportFactory.setValues(etest,"Automation","New Account");
            checkIntegrationImages(driver,etest);
            ComplexReportFactory.closeTest(etest);

            etest=ComplexReportFactory.getTest("Check dialogflow in new account");
            ComplexReportFactory.setValues(etest,"Automation","New Account");
            result.putAll(DialogflowBotsWidgets.checkDialogflowNewAccount(driver,etest));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            etest=ComplexReportFactory.getTest(KeyManager.getRealValue("BOTS230"));
            ComplexReportFactory.setValues(etest,"Automation","New Account");
            result.putAll(ZiaTests.checkZiaNewAccount(driver,etest));
            ComplexReportFactory.closeTest(etest);
            BotTests.closeBotUIIfOpen(driver);

            CommonFunctionsNA.logout(driver);
			driver.quit();
		}

    	catch(Exception e){
            System.out.println("Error While checking New Account - ");
            if(driver != null)
            {
                TakeScreenshot.screenshot(driver,etest,"NewAccount","SignUp","Error",e);
            }
            else
            {
                e.printStackTrace();
                etest.log(Status.FAIL,e.toString());
            }
            etest.log(Status.FATAL,"Module breakage occurred "+e);
            System.out.println("~~Module breakage occurred");
            result.put("NA1",false);
    	}

    	ComplexReportFactory.closeTest(etest);

        hashtable.put("result", result);
		hashtable.put("servicedown", servicedown);
		return hashtable;
    }

    public static boolean checkAlertInPortalName(WebDriver driver)
    {
    	try
    	{
    		CommonFunctionsNA.enterPortalName(driver,"123");

    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
		
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("port_errormsg")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("port_errormsg")));

			String alert = CommonUtilNA.elfinder(driver,"id","port_errormsg").getText();
			if(!alert.contains(ResourceManager.getRealValue("alert_portalname")))
			{
				etest.log(Status.FAIL,"MismatchContent.Expected:"+ResourceManager.getRealValue("alert_portalname")+"--Actual:"+alert+"--");
				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAlertInPortalName","MismatchContent");
				return false;
			}
			
			if(!CommonUtilNA.elfinder(driver,"id","createnewportal").getAttribute("class").contains("diable_btn"))
			{
				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAlertInPortalName","ContinueIsNotDisabled");
				return false;
			}

			etest.log(Status.PASS,"Checked");
			return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAlertInPortalName","Error",e);
			return false;
    	}
    }

    public static boolean createPortal(WebDriver driver,final String portal)
    {
    	try
    	{
    		CommonFunctionsNA.enterPortalName(driver,portal);

    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
		
			/*wait.until(ExpectedConditions.presenceOfElementLocated(By.id("screenname")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("screenname")));

			wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                       		try
                       		{
	                           if(CommonUtilNA.elfinder(driver,"id","screenname").getText().contains(portal))
	                           {
	                               return true;
	                           }
	                        }
	                        catch(Exception e){}
                           return false;
                       }
                   });*/

            TakeScreenshot.screenshot(driver,etest,"NewAccount","CreatePortal","CheckTimeZone",0);
            
            timezone = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","cportaltimezone"),"classname","ddsel_div").getText();
            
            etest.log(Status.INFO,"timezone<>"+timezone+"<>");
            
            wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                       		try
                       		{
	                           if(!CommonUtilNA.elfinder(driver,"id","createnewportal").getAttribute("class").contains("diable_btn"))
	                           {
	                               return true;
	                           }
	                        }
	                        catch(Exception e){}
                           return false;
                       }
                   });                 
    
            CommonSikuli.findInWholePage(driver,"UI360.png","UI360",etest);
            CommonSikuli.findInWholePage(driver,"UI361.png","UI361",etest);
            CommonUtil.clickWebElement(driver,CommonUtil.getElement(driver,SIGNUP_PAGE_USER_ICON));
            CommonSikuli.findInWholePage(driver,"UI362.png","UI362",etest);
            CommonSikuli.findInWholePage(driver,"UI363.png","UI363",etest);


	        CommonUtilNA.elfinder(driver,"id","createnewportal").click();

	        final String currentURL ;

	        if(Util.siteNameout().contains("lab"))
            {
                currentURL = "https://labsalesiq.localzoho.com/"+portal+"/index#welcome";
            }
            else if(Util.siteNameout().contains("local"))
                currentURL = "https://salesiq.localzoho.com/"+portal+"/index#welcome";
            else if(Util.siteNameout().contains("pre"))
                currentURL = "https://presalesiq.localzoho.com/"+portal+"/index#welcome";
            else
                currentURL = "https://salesiq.zoho.com/"+portal+"/index#welcome";

	        wait.until(new Function<WebDriver,Boolean>()
                   {
                       public Boolean apply(WebDriver driver)
                       {
                       		try
                       		{
	                           if(!driver.getCurrentUrl().contains("index#"))
	                           {
	                               return true;
	                           }
	                        }
	                        catch(Exception e){}
                           return false;
                       }
                   });           

	        try
	        {
	        	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("dnenable")));
	        	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dnenable")));
	        	
	        	WebElement banner = CommonUtilNA.elfinder(driver,"id","dnenable");
	        	WebElement close = CommonUtilNA.elfinder(driver,"classname","sqico-close");
	        	
	        	close.click();
	        }
	        catch(Exception e)
	        {
	        	Thread.sleep(4000);
	        	System.out.println("Error while closing banner  ");
	        	e.printStackTrace();
	        }
	        
	        etest.log(Status.PASS,"Checked");
			return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CreatePortal","Error",e);
			return false;
    	}
    }

    public static boolean checkName(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);
		
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdname")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdrdname")));

			String name1 = CommonUtilNA.elfinder(driver,"id","hdrdname").getText();

			if(!name1.equals(name))
			{
				etest.log(Status.FAIL,"Name at dropdown is mismatched.Expected:"+name+"--Actual:"+name1+"--");
				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckName","MismatchName");
				return false;
			}

			etest.log(Status.INFO,"Name at dropdown is matched");

			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".font20.dsply_inblk")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".font20.dsply_inblk")));

			String name2 = CommonUtilNA.elfinder(driver,"css",".font20.dsply_inblk").getText();

			if(!name2.contains(name))
			{
				etest.log(Status.FAIL,"Name at welcome page is mismatched.Expected:"+name+"--Actual:"+name2+"--");
				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckName","MismatchName");
				return false;
			}

			etest.log(Status.PASS,"Name at welcome page is matched");
			return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckName","Error",e);
			return false;
    	}
    }

    public static void checkAlertForInstallCode(WebDriver driver)
    {
    	try
    	{
    		result.put("NA5",false);
    		result.put("NA6",false);
    		result.put("NA7",false);
    		
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickVisitorsOnline(driver);
		
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embednotify")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embednotify")));

			WebElement popup = CommonUtilNA.elfinder(driver,"id","embednotify");
			String header = CommonUtilNA.elementfinder(driver,popup,"classname","siq_bnr_hd").getText();
			String content = CommonUtilNA.elementfinder(driver,popup,"id","amsg").getText();

			CommonUtilNA.elementfinder(driver,popup,"linktext",ResourceManager.getRealValue("install_code_alert_get_now"));
			CommonUtilNA.elementfinder(driver,popup,"linktext",ResourceManager.getRealValue("install_code_alert_remind_me_later"));
			
			if(!header.contains(ResourceManager.getRealValue("install_code_alert_header")) && !content.contains(ResourceManager.getRealValue("install_code_alert_content")))
			{
				etest.log(Status.FAIL,"MismatchContent.Expected"+ResourceManager.getRealValue("install_code_alert_header")+"--"+ResourceManager.getRealValue("install_code_alert_content")+"--Actual:"+header+"--"+content+"--");
				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAlertForInstallCode","MismatchContent");
			}

			etest.log(Status.INFO,"Contents Checked");
			result.put("NA5",true);

            CommonSikuli.findInWholePage(driver,"UI373.png","UI373",etest);
    		
    		CommonUtilNA.elementfinder(driver,popup,"linktext",ResourceManager.getRealValue("install_code_alert_get_now")).click();

            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("embednotify")));

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("welcomepagemain")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("welcomepagemain")));

			etest.log(Status.INFO,"Get Code Now - Checked");
			result.put("NA6",true);			

			CommonFunctionsNA.clickVisitorsOnline(driver);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("embednotify")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embednotify")));

			popup = CommonUtilNA.elfinder(driver,"id","embednotify");

			CommonUtilNA.elementfinder(driver,popup,"linktext",ResourceManager.getRealValue("install_code_alert_remind_me_later")).click();

			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("embednotify")));

			etest.log(Status.PASS,"Remind Me Later - Checked");
			result.put("NA7",true);	
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckAlertForInstallCode","Error",e);
		}
    }

    public static boolean checkVisitorsOnlineTab(WebDriver driver) throws Exception
    {
        int failcount=0;

    	try
    	{
            Tab.clickVisitorsOnline(driver);

            VisitorsViewType
            visitors_online_view_type=TrackingRingsCustomizeCommonFunctions.getCurrentVisitorsViewInVisitorsOnlineTab(driver),
            expected_view_type=VisitorsViewType.RINGS;

            if(visitors_online_view_type==expected_view_type)
            {
                etest.log(Status.PASS,"Default visitors view is "+expected_view_type+" view as expected");
            }
            else
            {
                failcount++;
                etest.log(Status.FAIL,"Default visitors view is not "+expected_view_type+" , Actual : "+visitors_online_view_type);
                TakeScreenshot.screenshot(driver,etest,"NewAccount","checkVisitorsOnlineTab","MismatchContent");
            }

            TrackingRingsCustomizeCommonFunctions.clickCustomizeIcon(driver,etest);

            String default_preset_name=TrackingRingsCustomizeCommonFunctions.NEW_ACCOUNT_TIME_SPENT_DEFAULT_PRESET_NAME;

            if(TrackingRingsCustomizeCommonFunctions.checkConditionsDefaultPreset(driver,default_preset_name,etest)==false)
            {
                failcount++;
                TakeScreenshot.screenshot(driver,etest,"NewAccount","checkVisitorsOnlineTab","MismatchContent");
            }

            TrackingRingsCustomizeCommonFunctions.closeCustomizeMenu(driver,etest);             

    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckVisitorsOnlineTab","Error",e);
    		driver.navigate().refresh();
    		Thread.sleep(5000);
    	}

        return CommonUtil.returnResult(failcount);
    } 

    public static boolean checkPortalList(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdname")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdrdname")));

			CommonUtilNA.elfinder(driver,"id","hdrdname").click();

			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdrpdwn")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdrdrpdwn")));

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("My Portals")));

			CommonUtilNA.elfinder(driver,"linktext","My Portals").click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("portal_container")));

			List<WebElement> list = CommonUtilNA.elfinder(driver,"classname","portal_container").findElements(By.tagName("li"));

			if(list.size() == 1)
			{
				etest.log(Status.PASS,"Checked");
				return true;
			}

			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalList","ContainsOtherThanDefault");
			return false;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalList","Error",e);
			return false;
    	}
    }

    public static boolean checkMobileAndDesktopApps(WebDriver driver)
    {
        int failcount = 0;
        try
        {
            FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdname")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdrdname")));

            CommonUtilNA.elfinder(driver,"id","hdrdname").click();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdrdrpdwn")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("hdrdrpdwn")));

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Mobile & Desktop Apps")));

            CommonUtilNA.elfinder(driver,"linktext","Mobile & Desktop Apps").click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("siqapp_body")));

            List<WebElement> list = CommonUtilNA.elfinder(driver,"classname","siqapp_body").findElements(By.className("siqapp_wrpchld"));

            int i = 0;

            for(WebElement app : list)
            {
                if(!CommonUtil.checkStringContainsAndLog(app.getText(),mobDeskApps[i++],"App description",etest))
                {
                    TakeScreenshot.screenshot(driver,etest,"NewAccount","checkMobileAndDesktopApps","Description differs");
                    failcount++;
                }
            }
            CommonUtil.mouseHover(driver,CommonUtil.getElement(driver,By.className("siq_app")));
            CommonSikuli.findInWholePage(driver,"UI352.png","UI352",etest);
            CommonSikuli.findInWholePage(driver,"UI353.png","UI353",etest);
            CommonSikuli.findInWholePage(driver,"UI354.png","UI354",etest);
            CommonSikuli.findInWholePage(driver,"UI355.png","UI355",etest);
            CommonSikuli.findInWholePage(driver,"UI356.png","UI356",etest);
            CommonSikuli.findInWholePage(driver,"UI357.png","UI357",etest);
            CommonSikuli.findInWholePage(driver,"UI358.png","UI358",etest);
            CommonSikuli.findInWholePage(driver,"UI359.png","UI359",etest);
            return CommonUtil.returnResult(failcount);
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewAccount","checkMobileAndDesktopApps","Error",e);
            return false;
        }
    }

    public static boolean checkVisitorHistoryTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickVisitorHistory(driver);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("empty_ldrule")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("empty_ldrule")));
    		wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	                if(driver.findElement(By.id("empty_ldrule")).getAttribute("style").contains(""))
	                {
	                    return true;
	                }
	                return false;
	            }
	        });

    		try
    		{
    			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("createlist")));
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckVisitorHistoryTab","CreateListIsPresent");
				return false;
    		}
    		catch(Exception e){}
    		String content = CommonUtilNA.elfinder(driver,"id","empty_ldrule").getText();
    		System.out.println(content);
    		System.out.println(ResourceManager.getRealValue("visitor_history_empty_header")+" "+ResourceManager.getRealValue("visitor_history_empty_content"));
    		
    		if(content.contains(ResourceManager.getRealValue("visitor_history_empty_header")) && content.contains(ResourceManager.getRealValue("visitor_history_empty_content_header")) && content.contains(ResourceManager.getRealValue("visitor_history_empty_content_line1")) 
    			&& content.contains(ResourceManager.getRealValue("visitor_history_empty_content_line2")) && content.contains(ResourceManager.getRealValue("visitor_history_empty_content_line3")) && content.contains(ResourceManager.getRealValue("visitor_history_empty_content_footer")))
    		{
    			etest.log(Status.PASS,"Checked");
	        	return true;
    		}
    		etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("visitor_history_empty_header")
    			+"--"+ResourceManager.getRealValue("visitor_history_empty_content_header")+"--"+ResourceManager.getRealValue("visitor_history_empty_content_line1")+
    			"--"+ResourceManager.getRealValue("visitor_history_empty_content_line2")+"--"+ResourceManager.getRealValue("visitor_history_empty_content_line3")+
    			"--"+ResourceManager.getRealValue("visitor_history_empty_content_footer")+"--Actual:"+content+"--");
	        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckVisitorHistoryTab","MismatchContent");
			return false;
	    }
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckVisitorHistoryTab","Error",e);
			return false;
    	}
    }

    public static boolean checkChatHistoryTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickChatHistory(driver);

    		Thread.sleep(1500);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("bstate")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bstate")));

    		WebElement empty = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"classname","bstate");
    		String header = CommonUtilNA.elementfinder(driver,empty,"tagname","h3").getText();
    		String content = empty.getText();

    		if(!header.contains(ResourceManager.getRealValue("chat_history_empty_header")) && !content.contains(ResourceManager.getRealValue("chat_history_empty_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("chat_history_empty_header")
	    			+"--"+ResourceManager.getRealValue("chat_history_empty_content")+"--Actual:"+header+"--"+content+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatHistoryTab","MismatchContent");
				return false;
    			
    		}

    		CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","hismysupport");
			CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","expdrpdown");

    		CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","cushistoryfilter"),"classname","combodrparw").click();;
    		
    		wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	            	try
	            	{
		                if(CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","cushistoryfilter"),"id","ulcontainer").getAttribute("style").contains("block"))
		                {
		                    return true;
		                }
		            }
		            catch(Exception e){}
	                return false;
	            }
	        });

    		WebElement dropdown = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","cushistoryfilter"),"id","ulcontainer");
    		
    		CommonUtilNA.elementfinder(driver,dropdown,"id","sagent");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","vstatus");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","vdeptid");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","lsid");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","timekey");

            try
            {
                CommonUtilNA.elementfinder(driver,dropdown,"id","vintegstatus");
                TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatHistoryTab","IntegrationIsPresentInFilter");
                return false;
            }
            catch(Exception e)
            {}

            CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","expdrpdown").click();;
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","expdrpdowncntnt").getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            List<WebElement> dropdown1 = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","history_div"),"id","expdrpdowncntnt"),"tagname","ul").findElements(By.tagName("li"));
            
            String[] exp = {"Export as .xlsx","Export as .csv"};
            int i = 0;
            for(WebElement e : dropdown1)
            {
                if(!e.getText().equals(exp[i]))
                {
                    etest.log(Status.FAIL,"MismatchContent.Expected:"+exp[i]+"--Actual:"+e.getText()+"--");
                    TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatHistoryTab","MismatchContent");
                    return false;
                }
                i++;
            }
            
            if(i==2)
            {
                etest.log(Status.PASS,"Checked");
                return true;    
            }

            etest.log(Status.FAIL,"MismatchExportListCount.Expected:"+2+"--Actual:"+i+"--");
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatHistoryTab","MismatchContent");
            return false;
        }
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatHistoryTab","Error",e);
			return false;
    	}
    }

    public static boolean checkFeedbackTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickFeedback(driver);

    		Thread.sleep(1500);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("bstate")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bstate")));

    		String content = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"classname","bstate").getText();

    		if(!content.contains(ResourceManager.getRealValue("feedback_empty_header")) && !content.contains(ResourceManager.getRealValue("feedback_empty_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("feedback_empty_header")
	    			+"--"+ResourceManager.getRealValue("feedback_empty_content")+"--Actual:"+content+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckFeedbackTab","MismatchContent");
				return false;
    		}

    		CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","hismysupport");
			CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","expdrpdown");

    		CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","cushistoryfilter"),"classname","combodrparw").click();;
    		
    		wait.until(new Function<WebDriver,Boolean>(){
	            public Boolean apply(WebDriver driver)
	            {
	            	try
	            	{
		                if(CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","cushistoryfilter"),"id","ulcontainer").getAttribute("style").contains("block"))
		                {
		                    return true;
		                }
		            }
		            catch(Exception e){}
	                return false;
	            }
	        });

    		WebElement dropdown = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","cushistoryfilter"),"id","ulcontainer");
    		
    		CommonUtilNA.elementfinder(driver,dropdown,"id","sagent");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","rating");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","vdeptid");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","lsid");
    		CommonUtilNA.elementfinder(driver,dropdown,"id","timekey");

    		CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","expdrpdown").click();;
            
            wait.until(new Function<WebDriver,Boolean>(){
                public Boolean apply(WebDriver driver)
                {
                    try
                    {
                        if(CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","expdrpdowncntnt").getAttribute("style").contains("block"))
                        {
                            return true;
                        }
                    }
                    catch(Exception e){}
                    return false;
                }
            });

            List<WebElement> dropdown1 = CommonUtilNA.elementfinder(driver,CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","feedback_div"),"id","expdrpdowncntnt"),"tagname","ul").findElements(By.tagName("li"));
            
            String[] exp = {"Export as .xlsx","Export as .csv"};
            int i = 0;
            for(WebElement e : dropdown1)
            {
                if(!e.getText().equals(exp[i]))
                {
                    etest.log(Status.FAIL,"MismatchContent.Expected:"+exp[i]+"--Actual:"+e.getText()+"--");
                    TakeScreenshot.screenshot(driver,etest,"NewAccount","checkFeedbackTab","MismatchContent");
                    return false;
                }
                i++;
            }
            
            if(i==2)
            {
                etest.log(Status.PASS,"Checked");
                return true;    
            }

            etest.log(Status.FAIL,"MismatchExportListCount.Expected:"+2+"--Actual:"+i+"--");
            TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckFeedbackTab","MismatchContent");
            return false;
	    }
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckFeedbackTab","Error",e);
			return false;
    	}
    }

    public static boolean checkReportsForNoData(WebDriver driver,String view,String[] list)
    {
    	try
    	{
			FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickReports(driver,view);

    		Thread.sleep(1500);

    		String id = "";
    		String id1 = "";

    		if(view.equals("Overview"))
    		{
    			id = "w";
    			id1 = "o";
    		}
    		else if(view.equals("Visitors"))
    		{
    			id = "v";
    			id1 = "v";
    		}
    		else if(view.equals("Operators"))
    		{
    			id = "u";
    			id1 = "u";
    		}

    		final WebElement container = CommonUtilNA.elfinder(driver,"id","rightcontainer");

    		for(String s : list)
    		{
    			String header_id = id+"h"+s;
    			WebElement header = CommonUtilNA.elementfinder(driver,container,"id",header_id);
    			CommonUtilNA.inViewPort(header);
    			if(!header.getText().contains(ResourceManager.getRealValue("reports_charts_header_"+header_id)))
    			{
    				etest.log(Status.FAIL,"MismatchContent.Expected"+ResourceManager.getRealValue("reports_charts_header_"+header_id)+"--Actual:"+header.getText()+"--");
    				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsForNoData","MismatchContent");
					return false;
    			}
    			
    			final String content_id = id1+"c"+s;
    			
    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,container,"id",content_id));

    			wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	try
		            	{
			                if(CommonUtilNA.elementfinder(driver,container,"id",content_id).getText().contains(ResourceManager.getRealValue("reports_no_data")))
			    			{
			    				return true;
			    			}
			            }
			            catch(Exception e){}
		                return false;
		            }
	        	});
    		}

    		etest.log(Status.PASS,"Checked");
	        return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsForNoData","Error",e);
			return false;
    	}
    }

    public static boolean checkReportsTrackingForNoData(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickReports(driver,"Tracking");

    		Thread.sleep(1500);

    		String id = "t";
    		
    		final WebElement container = CommonUtilNA.elfinder(driver,"id","rightcontainer");

    		int i = 1;

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".widget.lsrpt_mn")));
    		
    		List<WebElement> list = container.findElements(By.cssSelector(".widget.lsrpt_mn"));

    		if(list.size() != 2)
    		{
    			etest.log(Status.FAIL,"MismatchLargeChartsCount:Expected:2--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","MismatchContent");
				return false;
    		}

    		for(final WebElement e : list)
    		{
    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,e,"classname","widget-heading"));

    			String s = ""+i++;

    			String header_id = id+"h"+s;

    			String header = CommonUtilNA.elementfinder(driver,e,"classname","widget-heading").getText();

    			if(!header.contains(ResourceManager.getRealValue("reports_charts_header_"+header_id)))
    			{
    				etest.log(Status.FAIL,"MismatchContent.Expected"+ResourceManager.getRealValue("reports_charts_header_"+header_id)+"--Actual:"+header+"--");
    				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","MismatchContent");
					return false;
    			}

    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,e,"classname","widget-content"));
    			
    			wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	try
		            	{
			                if(CommonUtilNA.elementfinder(driver,container,"classname","widget-content").getText().contains(ResourceManager.getRealValue("reports_no_data")))
			    			{
			    				return true;
			    			}
			            }
			            catch(Exception e){}
		                return false;
		            }
	        	});
    		}

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("widget-hlf")));
    		
    		list = container.findElements(By.className("widget-hlf"));
    		i = 1;

    		if(list.size() != 2)
    		{
    			etest.log(Status.FAIL,"MismatchMediumChartsCount:Expected:2--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","MismatchContent");
				return false;
    		}

    		for(final WebElement e : list)
    		{
    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,e,"classname","widget-heading"));

    			String s = ""+i++;

    			String header_id = id+"hh"+s;

    			String header = CommonUtilNA.elementfinder(driver,e,"classname","widget-heading").getText();

    			if(!header.contains(ResourceManager.getRealValue("reports_charts_header_"+header_id)))
    			{
    				etest.log(Status.FAIL,"MismatchContent.Expected"+ResourceManager.getRealValue("reports_charts_header_"+header_id)+"--Actual:"+header+"--");
    				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","MismatchContent");
					return false;
    			}

    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,e,"classname","widget-content"));
    			
    			wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	try
		            	{
			                if(CommonUtilNA.elementfinder(driver,container,"classname","widget-content").getText().contains(ResourceManager.getRealValue("reports_no_data")))
			    			{
			    				return true;
			    			}
			            }
			            catch(Exception e){}
		                return false;
		            }
		        });
    		}

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("widget-qtr")));
    		
    		list = container.findElements(By.className("widget-qtr"));
    		i = 1;

    		if(list.size() != 4)
    		{
    			etest.log(Status.FAIL,"MismatchSmallChartsCount:Expected:4--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","MismatchContent");
				return false;
    		}

    		for(final WebElement e : list)
    		{
    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,e,"classname","widget-heading"));

    			String s = ""+i++;

    			String header_id = id+"hq"+s;

    			String header = CommonUtilNA.elementfinder(driver,e,"classname","widget-heading").getText();

    			if(!header.contains(ResourceManager.getRealValue("reports_charts_header_"+header_id)))
    			{
    				etest.log(Status.FAIL,"MismatchContent.Expected"+ResourceManager.getRealValue("reports_charts_header_"+header_id)+"--Actual:"+header+"--");
    				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","MismatchContent");
					return false;
    			}

    			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,e,"classname","widget-summary"));
    			
    			wait.until(new Function<WebDriver,Boolean>(){
		            public Boolean apply(WebDriver driver)
		            {
		            	try
		            	{
			                if(CommonUtilNA.elementfinder(driver,container,"classname","widget-summary").getText().contains(ResourceManager.getRealValue("reports_no_data")))
			    			{
			    				return true;
			    			}
			            }
			            catch(Exception e){}
		                return false;
		            }
		        });
    		}

    		etest.log(Status.PASS,"Checked");
	        return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckReportsTrackingForNoData","Error",e);
			return false;
    	}
    }

    public static boolean checkMyProfileDetails(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickMyProfile(driver,"My Profile");

    		List<WebElement> list = CommonUtilNA.elfinder(driver,"id","rightcontainer").findElements(By.className("myprfdtlmn"));

    		if(list.size() != 6)
    		{
    			etest.log(Status.FAIL,"MismatchDetailsCount:Expected:6--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckMyProfileDetails","MismatchContent");
				return false;
    		}

    		for(int i = 1;i<list.size();i++)
    		{
    			WebElement e = list.get(i-1);

    			String lhs = CommonUtilNA.elementfinder(driver,e,"classname","myprfdtlmn_lft").getText();
    			String rhs = CommonUtilNA.elementfinder(driver,e,"classname","myprfdtlmn_rht").getText();

    			String expected = "";

    			if(i == 1)
    			{
    				expected = name;
    			}
    			else if(i == 4)
    			{
    				expected = comp;
    			}
    			else
    			{
    				expected = ResourceManager.getRealValue("na_details_rhs"+i);
    			}

    			if(!lhs.contains(ResourceManager.getRealValue("na_details_lhs"+i)) && !rhs.contains(expected))
    			{
    				etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("na_details_lhs"+i)+"--"+expected+"--Actual:"+lhs+"--"+"--"+rhs);
			        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCannedMessagesTab","MismatchContent");
					return false;
    			}
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckMyProfileDetails","Error",e);
			return false;
    	}
    }

    public static boolean checkMyProfileInternalChatHistory(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickMyProfile(driver,"Internal Chat History");

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("bstate")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bstate")));

    		WebElement empty = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","rightcontainer"),"classname","bstate");
    		String header = CommonUtilNA.elementfinder(driver,empty,"tagname","h3").getText();
    		
    		if(!header.contains(ResourceManager.getRealValue("na_internalchathistory_content")) && !empty.getText().contains(ResourceManager.getRealValue("na_internalchathistory_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("na_internalchathistory_header")+"--"+ResourceManager.getRealValue("na_internalchathistory_content")+"--Actual:"+empty.getText()+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckMyProfileInternalChatHistory","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckMyProfileInternalChatHistory","Error",e);
			return false;
    	}
    }

    public static boolean checkUsersTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.clickSettings(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ulisttable")));

    		List<WebElement> list = CommonUtilNA.elfinder(driver,"id","ulisttable").findElements(By.className("list-row"));

    		if(list.size() != 1)
    		{
    			etest.log(Status.FAIL,"MismatchUserList:Expected:1--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckOperatorsTab","MismatchContent");
				return false;
    		}

    		WebElement e = list.get(0);

    		String username = CommonUtilNA.elementfinder(driver,e,"classname","ulist_uname").getText();
    		String role = CommonUtilNA.elementfinder(driver,e,"classname","u_rolwt").getText();
    		String email1 = CommonUtilNA.elementfinder(driver,e,"classname","ulist_email").getText();
    		String actions = CommonUtilNA.elementfinder(driver,e,"classname","list_hilight").getText();

    		if(!username.contains(name) && !role.contains(ResourceManager.getRealValue("na_details_rhs2")) && !email1.contains(email) && !actions.equals(""))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+name+"--"+ResourceManager.getRealValue("na_details_rhs2")+"--"+email+"--"+"--"+"Actual:"+username+"--"+role+"--"+email1+"--"+actions+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckOperatorsTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckOperatorsTab","Error",e);
			return false;
    	}
    }

    public static boolean checkCompanyTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToCompTab(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("recorddetail")));

    		WebElement details = CommonUtilNA.elfinder(driver,"id","recorddetail");

			List<WebElement> list = details.findElements(By.className("cinfo_wrap"));

    		if(list.size() == 0)
    		{
    			etest.log(Status.FAIL,"Details List mismatch Count.Actual:"+list.size()+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","MismatchContent");
		        return false;
    		}

    		String owner = list.get(0).getText();

    		if(!owner.contains(name) && !owner.contains(email))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+name+"--"+email+"--Actual:"+owner+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","MismatchContent");
		        return false;
    		}

    		if(!(checkCompanyInfo(driver,"companyname",comp) && checkCompanyInfo(driver,"companywebsite","")  && checkCompanyInfo(driver,"companyaddress","")
    			 && checkCompanyInfo(driver,"companyemail","")  && checkCompanyInfo(driver,"companytelephone","")  && checkCompanyInfo(driver,"companyfax","")
    			   && checkCompanyInfo(driver,"companydesc","")))
    		{
    			return false;
    		}

    		CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,details,"id","companylanguage_div"));
    		
    		String check = CommonUtilNA.elementfinder(driver,details,"id","companylanguage_div").getText();

			if(!check.equals("English"))
			{
				etest.log(Status.FAIL,"Content Mismatch.Expected:"+"English"+"--Actual:"+check+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","MismatchContent");
		        return false;
			}

			CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,details,"id","companytimezone_div"));
    		
    		check = CommonUtilNA.elementfinder(driver,details,"id","companytimezone_div").getText();

			if(!check.equals(timezone))
			{
				etest.log(Status.FAIL,"Content Mismatch.Expected:"+timezone+"--Actual:"+check+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","MismatchContent");
		        return false;
			}

			((JavascriptExecutor)driver).executeScript("scroll(0,400)");

			if(!CommonUtilNA.elfinder(driver,"id","bhdisablelnk").getAttribute("style").contains("none"))
			{
				etest.log(Status.FAIL,"Business hour toggle button is visible");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","Error");
		        return false;
			}
            
            etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","Error",e);
			return false;
    	}
    }

    public static boolean checkCompanyInfo(WebDriver driver,String field,String value) throws Exception
    {
    	String check = CommonFunctionsNA.getCompanyInfo(driver,field);

		if(!check.equals(value))
		{
			etest.log(Status.FAIL,"Content Mismatch.Expected:"+comp+"--Actual:"+check+"--");
	        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckCompanyTab","MismatchContent");
	        return false;
		}

		return true;
    }

    public static boolean checkDepartmentTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToDeptTab(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-list")));

    		List<WebElement> list = CommonUtilNA.elfinder(driver,"id","module-list").findElements(By.className("list-row"));

    		if(list.size() != 1)
    		{
    			etest.log(Status.FAIL,"MismatchDepartmentList:Expected:1--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckDepartmentTab","MismatchContent");
				return false;
    		}

    		WebElement e = list.get(0);

    		String name = CommonUtilNA.elementfinder(driver,e,"classname","dept_namewth").getText();
    		String desc = CommonUtilNA.elementfinder(driver,e,"classname","dept_descwth").getText();
    		String type = CommonUtilNA.elementfinder(driver,e,"classname","u_rolwt").getText();

    		if(!name.contains(comp) && !desc.contains("System Generated") && !type.contains("Public") )
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+comp+"--"+"System Generated"+"--"+"Public"+"--"+"Actual:"+name+"--"+desc+"--"+type+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckDepartmentTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckDepartmentTab","Error",e);
			return false;
    	}
    }

    public static boolean checkPortalSettingsTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToPortalSettingsTab(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("portaleditmodule")));

    		String[] tobechecked = new String[]{"showtyping","filetransfer","pushpage","emailtranscripts","ccemailaddr","dailystatics","weeklystats","sendemailforipblockto",
    									"visitorfeedback","sendtranasemail","offbusymsg","screensharing","audiocall"};

    		String[] tobeunchecked = new String[]{"translate","idleasoffline","isgdprenabled","isipmasking","istrackdnt"};

    		String[] dropdown = new String[]{"vischattranscript","inactiveperioddrpdwn","maxconcurrentchatdrpdwn"};

    		String[] content = new String[]{"Manual","30 Minutes","Unlimited"};

    		WebElement page = CommonUtilNA.elfinder(driver,"id","portaleditmodule");

    		List<WebElement> list = page.findElements(By.className("togglebtn"));

    		for(WebElement e : list)
    		{
    			CommonUtilNA.inViewPort(e);

    			String s = e.getAttribute("tbutid");

    			if(Arrays.asList(tobechecked).contains(s))
    			{
    				if(!e.getAttribute("class").contains("set_on"))
    				{
    					TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalSettingsTab","MismatchInStatusForCheckBox-"+s);
						return false;
    				}
    				else
    				{
    					continue;
    				}
    			}
    			else if(Arrays.asList(tobeunchecked).contains(s))
    			{
    				if(!e.getAttribute("class").contains("set_off"))
    				{
    					TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalSettingsTab","MismatchInStatusForCheckBox-"+s);
						return false;
    				}
    				else
    				{
    					continue;
    				}
    			}

    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalSettingsTab","CannotFindStatusFor"+s);
				return false;
    		}

    		for(int i = 0;i<dropdown.length;i++)
    		{
    			WebElement e = CommonUtilNA.elementfinder(driver,page,"id",dropdown[i]);

    			CommonUtilNA.inViewPort(e);

    			String present = e.getText();

    			if(!present.contains(content[i]))
    			{
    				etest.log(Status.FAIL,"Mismatch Default content for "+dropdown[i]+".Expected:"+content[i]+"--Actual:"+present+"--");
    				TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalSettingsTab","MismatchDefaultContent");
					return false;
    			}
    		}

    		WebElement frommail_div = CommonUtilNA.elementfinder(driver,page,"id","frommailconfig");

    		WebElement frommail = CommonUtilNA.elementfinder(driver,frommail_div.findElements(By.className("uprdowrap")).get(0),"tagname","span");

    		CommonUtilNA.inViewPort(CommonUtilNA.elementfinder(driver,frommail_div,"classname","rdselected"));

    		Thread.sleep(3000);

    		String user = frommail.getAttribute("class");

    		if(!user.contains("rdselected"))
    		{
    			etest.log(Status.FAIL,"Mismatch Default Radio Button for from mail.Expected:"+"rdselected"+"--Actual:"+user+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalSettingsTab","MismatchContent");
				return false;
    		}


    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckPortalSettingsTab","Error",e);
			return false;
    	}
    }

    public static boolean checkBlockedIPTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToBlockedIPTab(driver);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("bstate")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bstate")));

    		WebElement empty = CommonUtilNA.elementfinder(driver,CommonUtilNA.elfinder(driver,"id","rightcontainer"),"classname","bstate");
    		String header = CommonUtilNA.elementfinder(driver,empty,"tagname","h3").getText();
    		
    		if(!header.contains(ResourceManager.getRealValue("na_blockedip_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("na_blockedip_content")+"--Actual:"+header+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckBlockedIPTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckBlockedIPTab","Error",e);
			return false;
    	}
    }

    public static boolean checkWebEmbedTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToEmbedTab(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("embedlist")));

    		List<WebElement> list = CommonUtilNA.elfinder(driver,"id","embedlist").findElements(By.className("list-row"));

    		if(list.size() != 1)
    		{
    			etest.log(Status.FAIL,"MismatchWebEmbedList:Expected:1--Actual:"+list.size()+"--");
    			TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckWebEmbedTab","MismatchContent");
				return false;
    		}

    		WebElement e = list.get(0);

    		List<WebElement> content = e.findElements(By.className("list_cell"));

    		String embedname = content.get(0).getText();
    		String dept = content.get(1).getText();
    		String created = content.get(2).getText();

    		if(!embedname.contains(comp) && !dept.contains("Allow visitor to select department") && !created.contains(name) )
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+comp+"--"+"Allow visitor to select department"+"--"+name+"--"+"Actual:"+embedname+"--"+dept+"--"+created+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckWebEmbedTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckWebEmbedTab","Error",e);
			return false;
    	}
    }
    
    public static boolean checkChatMonitorTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToChatMonitorTab(driver);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("f26")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("f26")));

            String header = CommonUtil.getElement(driver,By.className("chatmonitortab")).findElement(By.className("f26")).getText();
    		
    		if(!header.contains(ResourceManager.getRealValue("na_chatmonitor_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("na_chatmonitor_content")+"--Actual:"+header+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatMonitorTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckChatMonitorTab","Error",e);
			return false;
    	}
    }

    public static boolean checkIntelligentTriggerTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToIntelligentTriggerTab(driver);

    		Thread.sleep(1500);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("f26")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("f26")));

            String header = CommonUtil.getElement(driver,By.className("triggerstab")).findElement(By.className("f26")).getText();
    		
    		if(!header.contains(ResourceManager.getRealValue("na_trigger_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("na_trigger_content")+"--Actual:"+header+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntelligentTriggerTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntelligentTriggerTab","Error",e);
			return false;
    	}
    }

    public static boolean checkVisitorRoutingTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToVisitorRoutingTab(driver);

    		Thread.sleep(1500);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("track_suggest")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("track_suggest")));

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckVisitorRoutingTab","Error",e);
			return false;
    	}
    }

    public static boolean checkEmailScheduleTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToEmailScheduleTab(driver);

    		Thread.sleep(1500);

    		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("f26")));
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("f26")));

    		String header = CommonUtil.getElement(driver,By.className("schedulertab")).findElement(By.className("f26")).getText();

    		if(!header.contains(ResourceManager.getRealValue("na_schedule_content")))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+ResourceManager.getRealValue("na_schedule_content")+"--Actual:"+header+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckEmailScheduleTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckEmailScheduleTab","Error",e);
			return false;
    	}
    }

    public static boolean checkLeadScoringTab(WebDriver driver)
    {
    	try
    	{
    		init();

    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToLeadScoringTab(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("leadscore")));

    		WebElement page = CommonUtilNA.elfinder(driver,"id","leadscore");

    		List<WebElement> list = page.findElements(By.className("leadscrlst"));

    		int i = 1;

    		for(WebElement e : list)
    		{
    			CommonUtilNA.inViewPort(e);
    			
    			System.out.println("LeadScoreRule"+i+e.getText());

    			String rulenumber = ""+i;

    			if(!e.getText().contains(leadscore_rule.get(rulenumber)) && !e.getText().contains(leadscore_points.get(rulenumber)))
    			{
    				etest.log(Status.FAIL,"Content Mismatch.Expected:"+leadscore_rule.get(rulenumber)+"--"+leadscore_points.get(rulenumber)+"--Actual:"+e.getText()+"--");
			        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckLeadScoringTab","MismatchContent");
					return false;
    			}

    			i++;
    		}

    		WebElement dropdown = CommonUtilNA.elementfinder(driver,page,"id","lsdeprdrpdwn_div");

    		CommonUtilNA.inViewPort(dropdown);

    		if(!dropdown.getText().equals("Weekly"))
    		{
    			etest.log(Status.FAIL,"Content Mismatch.Expected:"+"Weekly"+"--Actual:"+dropdown.getText()+"--");
		        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckLeadScoringTab","MismatchContent");
				return false;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckLeadScoringTab","Error",e);
			return false;
    	}
    }

    public static boolean checkIntegrationTab(WebDriver driver)
    {
    	try
    	{
    		FluentWait wait = CommonUtilNA.waitreturner(driver,30,250);

    		CommonFunctionsNA.navToIntegTab(driver);

    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("integhome")));

    		WebElement page = CommonUtilNA.elfinder(driver,"id","integhome");

    		List<WebElement> list = page.findElements(By.className("integ_li"));

    		int i = 0;

    		for(WebElement e : list)
    		{
    			WebElement name = CommonUtilNA.elementfinder(driver,e,"classname","integ_linm");

    			CommonUtilNA.inViewPort(name);

    			if(!name.getText().contains(apps[i]))
    			{
    				etest.log(Status.FAIL,apps[i]+" is not placed in order");
			        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntegrationTab","Error");
					return false;
    			}

    			if(apps[i].contains("Zoho") || apps[i].equals("Email Genie"))
    			{
    				if(!e.getAttribute("integtype").contains("zohoapplications"))
    				{
    					etest.log(Status.FAIL,"Mismatch in default status of app "+apps[i]+".Expected:"+"zohoapplications"+"--Actual"+e.getAttribute("integtype")+"--");
				        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntegrationTab","Error");
						return false;
    				}
    			}
    			else
    			{
    				if(!e.getAttribute("integtype").contains("otherinteg"))
    				{
    					etest.log(Status.FAIL,"Mismatch in default status of app "+apps[i]+".Expected:"+"otherinteg"+"--Actual"+e.getAttribute("integtype")+"--");
				        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntegrationTab","Error");
						return false;
    				}
    			}

    			WebElement eye = CommonUtilNA.elementfinder(driver,e,"tagname","em");

    			try
    			{
    				System.out.println(apps[i]+"-"+eye.getAttribute("class"));
    			}
    			catch(Exception e1){e1.printStackTrace();}

    			if(!eye.getAttribute("class").equals(""))
    			{
    				etest.log(Status.FAIL,"Mismatch status of eye(Enable/Disable) for "+apps[i]);
			        TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntegrationTab","Error");
					return false;
    			}
    			
    			i++;
    		}

    		etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","CheckIntegrationTab","Error",e);
			return false;
    	}
    }

    public static boolean initiateChatVis(WebDriver driver)
    {
    	try
    	{
    		WebDriver visDriver = null;

    		try
    		{
    			visDriver = CommonFunctionsNA.openVis(visDriver);
    			CommonFunctionsNA.initiateChatVis(visDriver,"VisitorName","visitor@gmail.com",null,"r u there?");
    			visDriver.quit();
    		}
    		catch(Exception e)
	    	{
	    		TakeScreenshot.screenshot(visDriver,etest,"NewAccount","InitiateChatVisitor","Error",e);
	    		visDriver.quit();
				return false;
	    	}

	    	CommonFunctionsNA.acceptChat(driver);
            CommonFunctionsNA.endChatUser(driver);
	    	CommonFunctionsNA.clickClosethisWindow(driver);

	    	etest.log(Status.PASS,"Checked");
    		return true;
    	}
    	catch(Exception e)
    	{
    		TakeScreenshot.screenshot(driver,etest,"NewAccount","InitiateChatVisitor","Error",e);
			return false;
    	}
    }

    public static boolean addLeadScoreRule(WebDriver driver) throws Exception
    {
    	try
    	{
            String condition = "Browser";
            String condition1 = null;
            String criteria = "is equal to";
            String value1 = "Google Chrome";
            String value2 = null;
            
            CommonFunctionsNA.clickAddInLeadScoring(driver);
            CommonFunctionsNA.addFieldsInCreateScoringRules(driver,"1",condition,condition1,criteria,value1,value2);
            CommonFunctionsNA.addPointsForRulesInLeadScoring(driver,"50",true);
            CommonFunctionsNA.clickApplyInCreateRulesLeadScoring(driver);
            CommonFunctionsNA.clickVisitorsOnline(driver);
            CommonFunctionsNA.navToLeadScoringTab(driver);
            
            if(CommonFunctionsNA.selectRuleInLeadScoring(driver,condition,condition1,criteria,value1,value2) != null)
            {
                etest.log(Status.PASS,"Checked");
                return true;
            }
            
            etest.log(Status.FAIL,"Browser is equal to Google Chrome - rule is not added");
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddLeadScoreRule","LeadScoreIsNotAdded");
            return false;
    	}
    	catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewAccount","AddLeadScoreRule","Error",e);
            driver.navigate().refresh();
            Thread.sleep(3000);
            return false;
        }
    }

    public static boolean initiateChatVisWithDept(WebDriver driver)
    {
        try
        {
            WebDriver visDriver = null;

            try
            {
                visDriver = CommonFunctionsNA.openVis(visDriver);
                CommonFunctionsNA.initiateChatVis(visDriver,"VisitorName","visitor@gmail.com",comp,"r u there?");
                visDriver.quit();
            }
            catch(Exception e)
            {
                TakeScreenshot.screenshot(visDriver,etest,"NewAccount","InitiateChatVisitor","Error",e);
                visDriver.quit();
                return false;
            }

            CommonFunctionsNA.acceptChat(driver);
            CommonFunctionsNA.endChatUser(driver);
            CommonFunctionsNA.clickClosethisWindow(driver);

            etest.log(Status.PASS,"Checked");
            return true;
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewAccount","InitiateChatVisitorWithDept","Error",e);
            return false;
        }
    }

    public static void checkIntegrationImages(WebDriver driver,ExtentTest etest)
    {
        try
        {
            Tab.navToIntegrationTab(driver);
            List<WebElement> integList = CommonUtil.getElement(driver,By.id("integhome")).findElements(By.className("integ_li"));

            for(WebElement integ_element: integList)
            {
                CommonUtil.inViewPort(integ_element);
                String image_key = "UI_integ_"+integ_element.getAttribute("purpose");
                String image_name = image_key+".png";
                CommonSikuli.findInWholePage(driver,image_name,image_key,etest);
            }
        }
        catch(Exception e)
        {
            TakeScreenshot.screenshot(driver,etest,"NewAccount","Exception","Exception",e);
        }
    }
}
